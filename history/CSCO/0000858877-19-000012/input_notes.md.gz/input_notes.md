# CSCO notes — 0000858877-19-000012


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-19-000012:notes:1]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-19-000012:notes:2]
|  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Compensation expense related to acquisitions | $ | 313 |  |  | $ | 203 |  |  | $ | 212 |  |


## csco:ConcentrationOfCreditRiskPolicyTextBlock

[0000858877-19-000012:notes:3]
(o) Concentrations of Risk   Cash and cash equivalents are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. We seek to mitigate our credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties.

[0000858877-19-000012:notes:4]
We perform ongoing credit evaluations of our customers and, with the exception of certain financing transactions, do not require collateral from our customers. We receive certain of our components from sole suppliers. Additionally, we rely on a limited number of contract manufacturers and suppliers to provide manufacturing services for our products. The inability of a contract manufacturer or supplier to fulfill our supply requirements could materially impact future operating results.


## csco:DepreciationAndAmortizationPeriodByTypeOfAssetTextBlock

[0000858877-19-000012:notes:5]
Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-19-000012:notes:6]
| Asset Category |  | Period |
| Buildings |  | 25 years |
| Building improvements |  | 10 years |
| Leasehold improvements |  | Shorter of remaining lease term or up to 10 years |
| Computer equipment and related software |  | 30 to 36 months |
| Production, engineering, and other equipment |  | Up to 5 years |
| Operating lease assets |  | Based on lease term |
| Furniture and fixtures |  | 5 years |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-19-000012:notes:7]
The following table presents revenue for groups of similar products and services (in millions):

[0000858877-19-000012:notes:8]
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Revenue: |  |  |  |  |  |
| Infrastructure Platforms | $ | 30,191 |  |  | $ | 28,322 |  |  | $ | 27,817 |  |
| Applications | 5,803 |  |  | 5,036 |  |  | 4,568 |  |
| Security | 2,730 |  |  | 2,352 |  |  | 2,152 |  |
| Other Products | 281 |  |  | 999 |  |  | 1,168 |  |
| Total Product | 39,005 |  |  | 36,709 |  |  | 35,705 |  |
| Services | 12,899 |  |  | 12,621 |  |  | 12,300 |  |
| Total (1) | $ | 51,904 |  |  | $ | 49,330 |  |  | $ | 48,005 |  |

[0000858877-19-000012:notes:9]
(1) Includes SPVSS business revenue of $168 million and $903 million for


## csco:OtherThanTemporaryImpairmentLossesOnInvestmentsPolicyTextBlock

[0000858877-19-000012:notes:10]
(d) Impairments of Investments   When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and we will assess whether the impairment is other than temporary. An impairment is considered other than temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of the entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost basis of the security. If impairment is considered other than temporary based on condition (i) or (ii) described earlier, the entire difference between the amortized cost and the fair value of the debt security is recognized in earnings. If an impairment is considered other than temporary based on condition (iii), the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) will be recognized in earnings, and the amount relating to all other factors will be recognized in other comprehensive income (OCI).

[0000858877-19-000012:notes:11]
We hold non-marketable equity and other investments which are included in other assets in the Consolidated Balance Sheets. We monitor these investments for impairments and make reductions in carrying values if we determine that an impairment charge is required based primarily on the financial condition and near-term prospects of these companies.


## csco:ScheduleOfCommonStockRepurchasedTextBlockTableTextBlock

[0000858877-19-000012:notes:12]
A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is as follows (in millions, except per-share amounts):

[0000858877-19-000012:notes:13]
| Years Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| July 27, 2019 |  | 418 |  |  | $ | 49.22 |  |  | $ | 20,577 |  |
| July 28, 2018 |  | 432 |  |  | $ | 40.88 |  |  | $ | 17,661 |  |
| July 29, 2017 |  | 118 |  |  | $ | 31.38 |  |  | $ | 3,706 |  |


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-19-000012:notes:14]
The effect on the Consolidated Statements of Operations of derivative instruments designated as fair value hedges and the underlying hedged items is summarized as follows (in millions):

[0000858877-19-000012:notes:15]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVE INSTRUMENTS FOR THE YEARS ENDED |  | GAINS (LOSSES) RELATED TO HEDGED ITEMS FOR THE YEARS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Interest rate derivatives |  | Interest expense |  | $ | 145 |  |  | $ | (174 | ) |  | $ | (275 | ) |  | $ | (138 | ) |  | $ | 173 |  |  | $ | 271 |  |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-19-000012:notes:16]
The following table presents the amortization of purchased intangible assets (in millions):

[0000858877-19-000012:notes:17]
| Years Ended |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 624 |  |  | $ | 640 |  |  | $ | 556 |  |
| Operating expenses |  |  |  |  |  |  |
| Amortization of purchased intangible assets |  | 150 |  |  | 221 |  |  | 259 |  |
| Restructuring and other charges |  | — |  |  | — |  |  | 38 |  |
| Total |  | $ | 774 |  |  | $ | 861 |  |  | $ | 853 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-19-000012:notes:18]
The following tables present details of our intangible assets acquired through acquisitions completed during fiscal 2019 and 2018 (in millions, except years):

[0000858877-19-000012:notes:19]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2019 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Duo | 5.0 |  | $ | 153 |  |  | 5.0 |  |  | $ | 94 |  |  | 2.5 |  |  | $ | 18 |  |  | $ | 77 |  |  | $ | 342 |  |
| Luxtera | 4.0 |  | 2 |  |  | 5.0 |  |  | 58 |  |  | 1.6 |  |  | 3 |  |  | 256 |  |  | 319 |  |
| Others (three in total) | 4.4 |  | 11 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Total |  |  | $ | 166 |  |  |  |  | $ | 152 |  |  |  |  | $ | 21 |  |  | $ | 333 |  |  | $ | 672 |  |

[0000858877-19-000012:notes:20]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2018 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Viptela | 5.0 |  | $ | 144 |  |  | 6.0 |  |  | $ | 35 |  |  | 1.0 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 180 |  |
| Springpath | 4.0 |  | 157 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | 160 |  |
| BroadSoft | 4.0 |  | 255 |  |  | 6.0 |  |  | 169 |  |  | 2.0 |  |  | 6 |  |  | — |  |  | 430 |  |
| Accompany | 4.0 |  | 55 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 55 |  |
| Others (four in total) | 3.9 |  | 39 |  |  | 4.0 |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | 42 |  |
| Total |  |  | $ | 650 |  |  |  |  | $ | 207 |  |  |  |  | $ | 7 |  |  | $ | 3 |  |  | $ | 867 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-19-000012:notes:21]
The following tables present details of our purchased intangible assets (in millions):

[0000858877-19-000012:notes:22]
| July 27, 2019 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,270 |  |  | $ | (1,933 | ) |  | $ | 1,337 |  |
| Customer relationships |  | 840 |  |  | (331 | ) |  | 509 |  |
| Other |  | 41 |  |  | (22 | ) |  | 19 |  |
| Total purchased intangible assets with finite lives |  | 4,151 |  |  | (2,286 | ) |  | 1,865 |  |
| In-process research and development, with indefinite lives |  | 336 |  |  | — |  |  | 336 |  |
| Total |  | $ | 4,487 |  |  | $ | (2,286 | ) |  | $ | 2,201 |  |

[0000858877-19-000012:notes:23]
| July 28, 2018 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,711 |  |  | $ | (1,888 | ) |  | $ | 1,823 |  |
| Customer relationships |  | 1,538 |  |  | (937 | ) |  | 601 |  |
| Other |  | 63 |  |  | (38 | ) |  | 25 |  |
| Total purchased intangible assets with finite lives |  | 5,312 |  |  | (2,863 | ) |  | 2,449 |  |
| In-process research and development, with indefinite lives |  | 103 |  |  | — |  |  | 103 |  |
| Total |  | $ | 5,415 |  |  | $ | (2,863 | ) |  | $ | 2,552 |  |


## srt:ContractualObligationFiscalYearMaturityScheduleTableTextBlock

[0000858877-19-000012:notes:24]
The following table summarizes our purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-19-000012:notes:25]
| Commitments by Period | July 27, 2019 |  | July 28, 2018 |
| Less than 1 year | $ | 4,239 |  |  | $ | 5,407 |  |
| 1 to 3 years | 728 |  |  | 710 |  |
| 3 to 5 years | — |  |  | 360 |  |
| Total | $ | 4,967 |  |  | $ | 6,477 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000858877-19-000012:notes:26]
SCHEDULE II

[0000858877-19-000012:notes:27]
VALUATION AND QUALIFYING ACCOUNTS

[0000858877-19-000012:notes:28]
(in millions)

[0000858877-19-000012:notes:29]
|  | Allowances For |
|  | FinancingReceivables |  | AccountsReceivable |
| Year ended July 29, 2017 |  |  |  |
| Balance at beginning of fiscal year | $ | 375 |  |  | $ | 249 |  |
| Provisions (benefits) | (35 | ) |  | 27 |  |
| Recoveries (write-offs), net | (49 | ) |  | (61 | ) |
| Foreign exchange and other | 4 |  |  | (4 | ) |
| Balance at end of fiscal year | $ | 295 |  |  | $ | 211 |  |
| Year ended July 28, 2018 |  |  |  |
| Balance at beginning of fiscal year | $ | 295 |  |  | $ | 211 |  |
| Provisions (benefits) | (89 | ) |  | (45 | ) |
| Recoveries (write-offs), net | (6 | ) |  | (37 | ) |
| Foreign exchange and other | 5 |  |  | — |  |
| Balance at end of fiscal year | $ | 205 |  |  | $ | 129 |  |
| Year ended July 27, 2019 |  |  |  |
| Balance at beginning of fiscal year | $ | 205 |  |  | $ | 129 |  |
| Provisions (benefits) | (16 | ) |  | 56 |  |
| Recoveries (write-offs), net | (42 | ) |  | (50 | ) |
| Foreign exchange and other | (21 | ) |  | 1 |  |
| Balance at end of fiscal year | $ | 126 |  |  | $ | 136 |  |

[0000858877-19-000012:notes:30]
Foreign exchange and other includes the impact of foreign exchange and certain immaterial reclassifications.


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000858877-19-000012:notes:31]
(q) Advertising Costs   We expense all advertising costs as incurred.


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-19-000012:notes:32]
The allowances for credit loss and the related financing receivables are summarized as follows (in millions):

[0000858877-19-000012:notes:33]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 28, 2018 | $ | 135 |  |  | $ | 60 |  |  | $ | 10 |  |  | $ | 205 |  |
| Provisions (benefits) | (54 | ) |  | 11 |  |  | 27 |  |  | (16 | ) |
| Recoveries (write-offs), net | (14 | ) |  | — |  |  | (28 | ) |  | (42 | ) |
| Foreign exchange and other | (21 | ) |  | — |  |  | — |  |  | (21 | ) |
| Allowance for credit loss as of July 27, 2019 | $ | 46 |  |  | $ | 71 |  |  | $ | 9 |  |  | $ | 126 |  |

[0000858877-19-000012:notes:34]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 29, 2017 | $ | 162 |  |  | $ | 103 |  |  | $ | 30 |  |  | $ | 295 |  |
| Provisions (benefits) | (26 | ) |  | (43 | ) |  | (20 | ) |  | (89 | ) |
| Recoveries (write-offs), net | (1 | ) |  | (5 | ) |  | — |  |  | (6 | ) |
| Foreign exchange and other | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Allowance for credit loss as of July 28, 2018 | $ | 135 |  |  | $ | 60 |  |  | $ | 10 |  |  | $ | 205 |  |

[0000858877-19-000012:notes:35]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 30, 2016 | $ | 230 |  |  | $ | 97 |  |  | $ | 48 |  |  | $ | 375 |  |
| Provisions (benefits) | (25 | ) |  | 7 |  |  | (17 | ) |  | (35 | ) |
| Recoveries (write-offs), net | (37 | ) |  | (11 | ) |  | (1 | ) |  | (49 | ) |
| Foreign exchange and other | (6 | ) |  | 10 |  |  | — |  |  | 4 |  |
| Allowance for credit loss as of July 29, 2017 | $ | 162 |  |  | $ | 103 |  |  | $ | 30 |  |  | $ | 295 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000858877-19-000012:notes:36]
The Consolidated Financial Statements include the accounts of ours and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-19-000012:notes:37]
Acquisitions and Divestitures

[0000858877-19-000012:notes:38]
| (a) | Acquisition Summary |

[0000858877-19-000012:notes:39]
We completed five acquisitions during fiscal 2019. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-19-000012:notes:40]
| Fiscal 2019 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Duo | $ | 2,025 |  |  | $ | (57 | ) |  | $ | 342 |  |  | $ | 1,740 |  |
| Luxtera | 596 |  |  | (19 | ) |  | 319 |  |  | 296 |  |
| Others (three in total) | 65 |  |  | 2 |  |  | 11 |  |  | 52 |  |
| Total | $ | 2,686 |  |  | $ | (74 | ) |  | $ | 672 |  |  | $ | 2,088 |  |

[0000858877-19-000012:notes:41]
On September 28, 2018, we completed our acquisition of privately held Duo Security, Inc. (“Duo”), a leading provider of unified access security and multi-factor authentication delivered through the cloud. Revenue from the Duo acquisition has been included in our Security product category.

[0000858877-19-000012:notes:42]
On February 6, 2019, we completed our acquisition of Luxtera, Inc. (“Luxtera”), a privately held semiconductor company. Revenue from the Luxtera acquisition has been included in our Infrastructure Platforms product category.

[0000858877-19-000012:notes:43]
The total purchase consideration related to our acquisitions completed during fiscal 2019 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $100 million.

[0000858877-19-000012:notes:44]
Fiscal 2018 Acquisitions

[0000858877-19-000012:notes:45]
Allocation of the purchase consideration for acquisitions completed in fiscal 2018 is summarized as follows (in millions):

[0000858877-19-000012:notes:46]
| Fiscal 2018 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Viptela | $ | 497 |  |  | $ | (18 | ) |  | $ | 180 |  |  | $ | 335 |  |
| Springpath | 248 |  |  | (11 | ) |  | 160 |  |  | 99 |  |
| BroadSoft | 2,179 |  |  | 353 |  |  | 430 |  |  | 1,396 |  |
| Accompany | 222 |  |  | 6 |  |  | 55 |  |  | 161 |  |
| Others (four in total) | 72 |  |  | 4 |  |  | 42 |  |  | 26 |  |
| Total | $ | 3,218 |  |  | $ | 334 |  |  | $ | 867 |  |  | $ | 2,017 |  |

[0000858877-19-000012:notes:47]
On July 31, 2017, we completed our acquisition of privately held Viptela Inc. (“Viptela”), a provider of software-defined wide area networking products. Revenue from the Viptela acquisition has been included in our Infrastructure Platforms product category.

[0000858877-19-000012:notes:48]
On September 22, 2017, we completed our acquisition of privately held Springpath, Inc. (“Springpath”), a hyperconvergence software company. Revenue from the Springpath acquisition has been included in our Infrastructure Platforms product category.

[0000858877-19-000012:notes:49]
On February 1, 2018, we completed our acquisition of publicly held BroadSoft, Inc. (“BroadSoft”), a cloud calling and contact center solutions company. Revenue from the BroadSoft acquisition has been included in our Applications product category.

[0000858877-19-000012:notes:50]
On May 10, 2018, we completed our acquisition of privately held Accompany, a provider of an AI-driven relationship intelligence platform. Results from the Accompany acquisition has been included in our Applications product category.

[0000858877-19-000012:notes:51]
The total purchase consideration related to our acquisitions completed during fiscal 2018 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $187 million.

[0000858877-19-000012:notes:52]
Fiscal 2017 Acquisitions

[0000858877-19-000012:notes:53]
In fiscal 2017, we completed seven acquisitions for total purchase consideration of $3.6 billion.

[0000858877-19-000012:notes:54]
| (b) | Divestiture of Service Provider Video Software Solutions Business |

[0000858877-19-000012:notes:55]
On October 28, 2018, we completed the sale of the Service Provider Video Software Solutions business. This business had tangible assets of approximately $160 million (primarily comprised of accounts receivables, inventories and various other current and long-term assets) and net intangible assets and goodwill (based on relative fair value) of $340 million. In addition, the business had total liabilities of approximately $200 million (primarily comprised of deferred revenue and various other current and long-term liabilities). We recognized an immaterial gain from this transaction in fiscal 2019.

[0000858877-19-000012:notes:56]
We completed two divestitures during fiscal 2018. The financial statement impact of these divestitures was not material for fiscal 2018.

[0000858877-19-000012:notes:57]
(c)   Pending Acquisition of Acacia Communications

[0000858877-19-000012:notes:58]
On July 9, 2019, we announced our intent to acquire Acacia Communications, Inc. (“Acacia”), a public fabless semiconductor company that develops, manufactures and sells high-speed coherent optical interconnect products that are designed to transform communications networks through improvements in performance, capacity and cost.

[0000858877-19-000012:notes:59]
Under the terms of the agreement, we have agreed to pay total consideration of approximately $2.6 billion, net of cash and marketable securities, to acquire Acacia. The acquisition is expected to close during the second half of fiscal 2020, subject to customary closing conditions and regulatory approvals. Upon close of the acquisition, revenue from Acacia will be included in our Infrastructure Platforms product category.

[0000858877-19-000012:notes:60]
(d)   Other Acquisition and Divestiture Information

[0000858877-19-000012:notes:61]
Total transaction costs related to our acquisition and divestiture activities during fiscal 2019, 2018, and 2017 were $21 million, $41 million, and $10 million, respectively. These transaction costs were expensed as incurred in G&A expenses in the Consolidated Statements of Operations.

[0000858877-19-000012:notes:62]
The goodwill generated from our acquisitions completed during fiscal 2019 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-19-000012:notes:63]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations for the acquisitions completed during fiscal 2019, 2018, and 2017 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.


## us-gaap:BusinessCombinationsAndOtherPurchaseOfBusinessTransactionsPolicyTextBlock

[0000858877-19-000012:notes:64]
(i) Business Combinations We allocate the fair value of the purchase consideration of our acquisitions to the tangible assets, liabilities, and intangible assets acquired, including in-process research and development (IPR&D), based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life. Acquisition-related expenses and related restructuring costs are recognized separately from the business combination and are expensed as incurred.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000858877-19-000012:notes:65]
(a) Cash and Cash Equivalents   We consider all highly liquid investments purchased with an original or remaining maturity of three months or less at the date of purchase to be cash equivalents. Cash and cash equivalents are maintained with various financial institutions.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-19-000012:notes:66]
Commitments and Contingencies

[0000858877-19-000012:notes:67]
| (a) | Operating Leases |

[0000858877-19-000012:notes:68]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Australia, Belgium, Canada, China, Germany, India, Japan, Mexico, Poland, and the United Kingdom. We also lease equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of July 27, 2019 are as follows (in millions):

[0000858877-19-000012:notes:69]
| Fiscal Year | Amount |
| 2020 | $ | 441 |  |
| 2021 | 299 |  |
| 2022 | 195 |  |
| 2023 | 120 |  |
| 2024 | 70 |  |
| Thereafter | 54 |  |
| Total | $ | 1,179 |  |

[0000858877-19-000012:notes:70]
Rent expense for office space and equipment totaled $433 million, $442 million, and $403 million in fiscal 2019, 2018, and 2017, respectively.

[0000858877-19-000012:notes:71]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-19-000012:notes:72]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-19-000012:notes:73]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 27, 2019 and July 28, 2018, the liability for these purchase commitments was $129 million and $159 million, respectively, and was included in other current liabilities.

[0000858877-19-000012:notes:74]
| (c) | Other Commitments |

[0000858877-19-000012:notes:75]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-19-000012:notes:76]
As of July 27, 2019, we estimated that future cash compensation expense of up to $440 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-19-000012:notes:77]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $326 million and $223 million as of July 27, 2019 and July 28, 2018, respectively.

[0000858877-19-000012:notes:78]
| (d) | Product Warranties |

[0000858877-19-000012:notes:79]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-19-000012:notes:80]
|  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Balance at beginning of fiscal year | $ | 359 |  |  | $ | 407 |  |  | $ | 414 |  |
| Provisions for warranties issued | 600 |  |  | 582 |  |  | 691 |  |
| Adjustments for pre-existing warranties | (12 | ) |  | (38 | ) |  | (21 | ) |
| Settlements | (603 | ) |  | (592 | ) |  | (677 | ) |
| Acquisitions and divestitures | (2 | ) |  | — |  |  | — |  |
| Balance at end of fiscal year | $ | 342 |  |  | $ | 359 |  |  | $ | 407 |  |

[0000858877-19-000012:notes:81]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-19-000012:notes:82]
| (e) | Financing and Other Guarantees |

[0000858877-19-000012:notes:83]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-19-000012:notes:84]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $29.6 billion, $28.2 billion, and $27.0 billion in fiscal 2019, 2018, and 2017, respectively. The balance of the channel partner financing subject to guarantees was $1.4 billion and $1.0 billion as of July 27, 2019 and July 28, 2018, respectively.

[0000858877-19-000012:notes:85]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $14 million, $35 million, and $51 million in fiscal 2019, 2018, and 2017, respectively.

[0000858877-19-000012:notes:86]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at July 27, 2019 and July 28, 2018, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-19-000012:notes:87]
|  | July 27, 2019 |  | July 28, 2018 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 197 |  |  | $ | 277 |  |
| End user | 21 |  |  | 31 |  |
| Total | $ | 218 |  |  | $ | 308 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (62 | ) |  | $ | (94 | ) |
| End user | (15 | ) |  | (28 | ) |
| Total | $ | (77 | ) |  | $ | (122 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 141 |  |  | $ | 186 |  |

[0000858877-19-000012:notes:88]
| (f) | Indemnifications |

[0000858877-19-000012:notes:89]
In the normal course of business, we indemnify other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-19-000012:notes:90]
We have been asked to indemnify Time Warner Cable (“TWC”) for patent infringement claims asserted against it by Sprint Communications Company, L.P. (“Sprint”) in federal court in Kansas. Sprint alleges that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied TWC's post-trial motions. TWC appealed to the U.S. Court of Appeals for the Federal Circuit, and, on November 30, 2018, a panel of the court affirmed the judgment. TWC filed a petition for rehearing en banc on January 29, 2019, which was denied on March 19, 2019. TWC has petitioned the United States Supreme Court for review of the judgment. At this time, we do not believe that our indemnity obligations under our agreement would be material.

[0000858877-19-000012:notes:91]
During fiscal 2018, we recorded legal and indemnification settlement charges of $127 million to product cost of sales related to prior indemnification matters resolved in fiscal 2018.

[0000858877-19-000012:notes:92]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-19-000012:notes:93]
It is not possible to determine the maximum potential amount under these indemnification agreements due to our limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by us under these agreements have not had a material effect on our operating results, financial position, or cash flows.

[0000858877-19-000012:notes:94]
| (g) | Legal Proceedings |

[0000858877-19-000012:notes:95]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of our former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-19-000012:notes:96]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $214 million for the alleged evasion of import and other taxes, $1.4 billion for interest, and $1.0 billion for various penalties, all determined using an exchange rate as of July 27, 2019. We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-19-000012:notes:97]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and, on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit on various grounds. On March 20, 2019, a panel of the Federal Circuit vacated the enhanced damages award; vacated and remanded in part the willful infringement finding; and affirmed the district court's other findings. Cisco filed a petition for rehearing with the Federal Circuit on May 10, 2019. On July 12, 2019, the panel granted in part Cisco’s petition for rehearing, denied Cisco’s petition for an en banc review by the entire Federal Circuit, reaffirmed its earlier determination regarding a portion of the judgment, issued a modified opinion vacating the attorneys’ fees award, and remanded portions of the judgment to the District Court of Delaware for further proceedings. Cisco’s $25.9 million payment, representing the portion of the judgment that the Federal Circuit affirmed plus interest, will be paid by September 18, 2019, and will be subject to a refund if any portion of the affirmed judgment is reversed or vacated by the United States Supreme Court. While the remanded proceedings may result in an additional loss, we do not expect it to be material.

[0000858877-19-000012:notes:98]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against us and cancelling a trial which had been set for March 12, 2018. Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit, and, on January 23, 2019, the court summarily affirmed the finding of non-infringement. On August 23, 2019, Straight Path filed a petition with the United States Supreme Court challenging the constitutionality of the Federal Circuit’s rule allowing summary affirmance.

[0000858877-19-000012:notes:99]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the court consolidated the cases alleging infringement of the ‘327 Patent. Oyster's cases against some of the defendants were resolved. The court vacated the November 4, 2018 trial date set for Oyster's claims against Cisco and one other remaining defendant, pending resolution of Oyster's appeal of the court's summary judgment ruling dismissing certain of Oyster's claims. Oyster appealed the summary judgment ruling on December 6, 2018. While we believe that we have strong non-infringement arguments and that the patent is invalid, if Oyster prevails in its appeal of the summary judgment ruling, and if we do not prevail in the District Court in a subsequent trial, we believe damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, we are unable to reasonably estimate the ultimate outcome of this litigation at this time. However, we do not anticipate that any final outcome of the dispute would be material.

[0000858877-19-000012:notes:100]
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows.

[0000858877-19-000012:notes:101]
For additional information regarding intellectual property litigation, see “Part I, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” of this Annual Report on Form 10-K.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0000858877-19-000012:notes:102]
(r) Share-Based Compensation Expense   We measure and recognize the compensation expense for all share-based awards made to employees and directors, including employee stock options, restricted stock units (RSUs), performance-based restricted stock units (PRSUs), and employee stock purchases related to the Employee Stock Purchase Plan (Employee Stock Purchase Rights) based on estimated fair values. The fair value of employee stock options is estimated on the date of grant using a lattice-binomial option-pricing model (Lattice-Binomial Model) or the Black-Scholes model, and for employee stock purchase rights we estimate the fair value using the Black-Scholes model. The fair value for time-based stock awards and stock awards that are contingent upon the achievement of financial performance metrics is based on the grant date share price reduced by the present value of the expected dividend yield prior to vesting. The fair value of market-based stock awards is estimated using an option-pricing model on the date of grant. Share-based compensation expense is reduced for forfeitures.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-19-000012:notes:103]
Comprehensive Income (Loss)

[0000858877-19-000012:notes:104]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, are summarized as follows (in millions):

[0000858877-19-000012:notes:105]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains and Losses |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 30, 2016 | $ | 413 |  |  | $ | (59 | ) |  | $ | (680 | ) |  | $ | (326 | ) |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (164 | ) |  | 22 |  |  | 318 |  |  | 176 |  |
| (Gains) losses reclassified out of AOCI | 87 |  |  | 79 |  |  | 16 |  |  | 182 |  |
| Tax benefit (expense) | 37 |  |  | (10 | ) |  | (13 | ) |  | 14 |  |
| Total change for the period | (40 | ) |  | 91 |  |  | 321 |  |  | 372 |  |
| BALANCE AT JULY 29, 2017 | 373 |  |  | 32 |  |  | (359 | ) |  | 46 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (543 | ) |  | 21 |  |  | (159 | ) |  | (681 | ) |
| (Gains) losses reclassified out of AOCI | (287 | ) |  | (68 | ) |  | 7 |  |  | (348 | ) |
| Tax benefit (expense) | 93 |  |  | 4 |  |  | (8 | ) |  | 89 |  |
| Total change for the period | (737 | ) |  | (43 | ) |  | (160 | ) |  | (940 | ) |
| Effect of adoption of accounting standard | 54 |  |  | — |  |  | (9 | ) |  | 45 |  |
| BALANCE AT JULY 28, 2018 | (310 | ) |  | (11 | ) |  | (528 | ) |  | (849 | ) |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 560 |  |  | — |  |  | (267 | ) |  | 293 |  |
| (Gains) losses reclassified out of AOCI | 13 |  |  | (3 | ) |  | 2 |  |  | 12 |  |
| Tax benefit (expense) | (95 | ) |  | — |  |  | 15 |  |  | (80 | ) |
| Total change for the period | 478 |  |  | (3 | ) |  | (250 | ) |  | 225 |  |
| Effect of adoption of accounting standards | (168 | ) |  | — |  |  | — |  |  | (168 | ) |
| BALANCE AT JULY 27, 2019 | $ | — |  |  | $ | (14 | ) |  | $ | (778 | ) |  | $ | (792 | ) |

[0000858877-19-000012:notes:106]
The net gains (losses) reclassified out of AOCI into the Consolidated Statements of Operations, with line item location, during each period were as follows (in millions):

[0000858877-19-000012:notes:107]
|  |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains and losses on available-for-sale investments |  | $ | (13 | ) |  | $ | 287 |  |  | $ | (87 | ) |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | 2 |  |  | — |  |  | — |  |  | Revenue |
| Foreign currency derivatives |  | — |  |  | 16 |  |  | (20 | ) |  | Cost of sales |
| Foreign currency derivatives |  | 1 |  |  | 52 |  |  | (59 | ) |  | Operating expenses |
|  |  | 3 |  |  | 68 |  |  | (79 | ) |  |  |
| Cumulative translation adjustment and actuarial gains and losses |  | — |  |  | (7 | ) |  | (16 | ) |  | Operating expenses |
| Cumulative translation adjustment and actuarial gains and losses |  | (2 | ) |  | — |  |  | — |  |  | Other income (loss), net |
| Total amounts reclassified out of AOCI |  | $ | (12 | ) |  | $ | 348 |  |  | $ | (182 | ) |  |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000858877-19-000012:notes:108]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 11,709 |  |  | $ | 11,431 |  |
| Product |  | 6,758 |  |  | 8,254 |  |
| Total |  | $ | 18,467 |  |  | $ | 19,685 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 10,668 |  |  | $ | 11,490 |  |
| Noncurrent |  | 7,799 |  |  | 8,195 |  |
| Total |  | $ | 18,467 |  |  | $ | 19,685 |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-19-000012:notes:109]
Borrowings

[0000858877-19-000012:notes:110]
| (a) | Short-Term Debt |

[0000858877-19-000012:notes:111]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-19-000012:notes:112]
|  | July 27, 2019 |  | July 28, 2018 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 5,998 |  |  | 3.20 | % |  | $ | 5,238 |  |  | 3.46 | % |
| Commercial paper | 4,193 |  |  | 2.34 | % |  | — |  |  | — |  |
| Total short-term debt | $ | 10,191 |  |  |  |  | $ | 5,238 |  |  |  |

[0000858877-19-000012:notes:113]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-19-000012:notes:114]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-19-000012:notes:115]
| (b) | Long-Term Debt |

[0000858877-19-000012:notes:116]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-19-000012:notes:117]
|  |  |  | July 27, 2019 |  | July 28, 2018 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.86% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.77% |  | 500 |  |  | 2.71% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.95% | February 15, 2019 |  | — |  |  | — |  | 2,000 |  |  | 5.17% |
| 1.60% | February 28, 2019 |  | — |  |  | — |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | — |  |  | — |  | 1,750 |  |  | 2.71% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.72% |  | 2,500 |  |  | 4.52% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 3.14% |  | 500 |  |  | 2.86% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 3.36% |  | 500 |  |  | 3.11% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 3.25% |  | 1,000 |  |  | 2.98% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.52% |  | 500 |  |  | 3.27% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 20,500 |  |  |  |  | 25,750 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (100 | ) |  |  |  | (116 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 73 |  |  |  |  | (65 | ) |  |  |
| Total |  |  | $ | 20,473 |  |  |  |  | $ | 25,569 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 5,998 |  |  |  |  | $ | 5,238 |  |  |  |
| Long-term debt |  |  | 14,475 |  |  |  |  | 20,331 |  |  |  |
| Total |  |  | $ | 20,473 |  |  |  |  | $ | 25,569 |  |  |  |

[0000858877-19-000012:notes:118]
We entered into interest rate swaps in prior periods with an aggregate notional amount of $4.50 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 12.

[0000858877-19-000012:notes:119]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.”  As of July 27, 2019, we were in compliance with all debt covenants.

[0000858877-19-000012:notes:120]
As of July 27, 2019, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-19-000012:notes:121]
| Fiscal Year | Amount |
| 2020 | $ | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 20,500 |  |

[0000858877-19-000012:notes:122]
| (c) | Credit Facility |

[0000858877-19-000012:notes:123]
On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.

[0000858877-19-000012:notes:124]
This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of July 27, 2019, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under this credit facility.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-19-000012:notes:125]
Derivative Instruments

[0000858877-19-000012:notes:126]
| (a) | Summary of Derivative Instruments |

[0000858877-19-000012:notes:127]
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We do, however, seek to mitigate such risks by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-19-000012:notes:128]
The fair values of our derivative instruments and the line items on the Consolidated Balance Sheets to which they were recorded are summarized as follows (in millions):

[0000858877-19-000012:notes:129]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | July 27, 2019 |  | July 28, 2018 |  | Balance Sheet Line Item |  | July 27, 2019 |  | July 28, 2018 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 5 |  |  | $ | 1 |  |  | Other current liabilities |  | $ | 8 |  |  | $ | — |  |
| Interest rate derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 1 |  |  | 10 |  |
| Interest rate derivatives | Other assets |  | 75 |  |  | — |  |  | Other long-term liabilities |  | — |  |  | 62 |  |
| Total |  |  | 80 |  |  | 1 |  |  |  |  | 9 |  |  | 72 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 9 |  |  | 1 |  |  | Other current liabilities |  | 6 |  |  | 2 |  |
| Total |  |  | 9 |  |  | 1 |  |  |  |  | 6 |  |  | 2 |  |
| Total |  |  | $ | 89 |  |  | $ | 2 |  |  |  |  | $ | 15 |  |  | $ | 74 |  |

[0000858877-19-000012:notes:130]
The effects of our cash flow and net investment hedging instruments on other comprehensive income (OCI) and the Consolidated Statements of Operations are summarized as follows (in millions):

[0000858877-19-000012:notes:131]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FORTHE YEARS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FORTHE YEARS ENDED (EFFECTIVE PORTION) |
|  |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |  | Line Item in Statements of Operations |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (1 | ) |  | $ | 20 |  |  | $ | 22 |  |  | Revenue |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |
|  |  |  |  |  |  |  |  | Cost of sales |  | — |  |  | 16 |  |  | (20 | ) |
|  |  |  |  |  |  |  |  | Operating expenses |  | 1 |  |  | 52 |  |  | (59 | ) |
| Total |  | $ | (1 | ) |  | $ | 20 |  |  | $ | 22 |  |  | Total |  | $ | 3 |  |  | $ | 68 |  |  | $ | (79 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 4 |  |  | $ | (1 | ) |  | $ | (15 | ) |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000858877-19-000012:notes:132]
As of July 27, 2019, we estimate that approximately $2 million of net derivative losses related to our cash flow hedges included in AOCI will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-19-000012:notes:133]
The effect on the Consolidated Statements of Operations of derivative instruments not designated as hedges is summarized as follows (in millions):

[0000858877-19-000012:notes:134]
|  |  |  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (60 | ) |  | $ | (24 | ) |  | $ | 13 |  |
| Total return swaps—deferred compensation |  | Operating expenses |  | 19 |  |  | 50 |  |  | 53 |  |
|  |  | Cost of sales |  | 2 |  |  | 4 |  |  | 5 |  |
|  |  | Other income (loss), net |  | (16 | ) |  | (11 | ) |  | — |  |
| Equity derivatives |  | Other income (loss), net |  | 3 |  |  | (4 | ) |  | 11 |  |
| Total |  |  |  | $ | (52 | ) |  | $ | 15 |  |  | $ | 82 |  |

[0000858877-19-000012:notes:135]
The notional amounts of our outstanding derivatives are summarized as follows (in millions):

[0000858877-19-000012:notes:136]
|  | July 27, 2019 |  | July 28, 2018 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 663 |  |  | $ | 147 |  |
| Interest rate derivatives | 4,500 |  |  | 6,750 |  |
| Net investment hedging instruments | 309 |  |  | 250 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,708 |  |  | 2,298 |  |
| Total return swaps—deferred compensation | 574 |  |  | 566 |  |
| Total | $ | 8,754 |  |  | $ | 10,011 |  |

[0000858877-19-000012:notes:137]
| (b) | Offsetting of Derivative Instruments |

[0000858877-19-000012:notes:138]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty. To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Information related to these offsetting arrangements is summarized as follows (in millions):

[0000858877-19-000012:notes:139]
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEET |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETBUT WITH LEGAL RIGHTS TO OFFSET |
| July 27, 2019 | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 89 |  |  | $ | — |  |  | $ | 89 |  |  | $ | (13 | ) |  | $ | (76 | ) |  | $ | — |  |
| Derivatives liabilities | $ | 15 |  |  | $ | — |  |  | $ | 15 |  |  | $ | (13 | ) |  | $ | — |  |  | $ | 2 |  |

[0000858877-19-000012:notes:140]
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEET |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETBUT WITH LEGAL RIGHTS TO OFFSET |
| July 28, 2018 | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |
| Derivatives liabilities | $ | 74 |  |  | $ | — |  |  | $ | 74 |  |  | $ | (2 | ) |  | $ | (53 | ) |  | $ | 19 |  |

[0000858877-19-000012:notes:141]
| (c) | Foreign Currency Exchange Risk |

[0000858877-19-000012:notes:142]
We conduct business globally in numerous currencies. Therefore, we are exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, we enter into foreign currency contracts. We do not enter into such contracts for speculative purposes.

[0000858877-19-000012:notes:143]
We hedge forecasted foreign currency transactions related to certain revenues, operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The effective portion of the derivative instrument’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion, if any, of the gain or loss is reported in earnings immediately. During the fiscal years presented, we did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-19-000012:notes:144]
We enter into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, including long-term customer financings, investments, and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of intercompany balances or other current assets, investments, or liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-19-000012:notes:145]
We hedge certain net investments in our foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on our net investment in those foreign subsidiaries. These derivative instruments generally have maturities of up to six months.

[0000858877-19-000012:notes:146]
| (d) | Interest Rate Risk |

[0000858877-19-000012:notes:147]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt   We hold interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2020 through 2025. Under these interest rate swaps, we receive fixed-rate interest payments and make interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.

[0000858877-19-000012:notes:148]
| (e) | Equity Price Risk |

[0000858877-19-000012:notes:149]
We hold marketable equity securities in our portfolio that are subject to price risk. To diversify our overall portfolio, we also hold equity derivatives that are not designated as accounting hedges. The change in the fair value of each of these investment types are included in other income (loss), net.

[0000858877-19-000012:notes:150]
We are also exposed to variability in compensation charges related to certain deferred compensation obligations to employees. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure and offset the related compensation expense.

[0000858877-19-000012:notes:151]
| (f) | Hedge Effectiveness |

[0000858877-19-000012:notes:152]
For the fiscal years presented, there were no components excluded from the assessment of hedge effectiveness for fair value or cash flow hedges, and the amounts excluded for net investment hedges was not material. In addition, hedge ineffectiveness for fair value, cash flow and net investment hedges was not material for any of the periods presented.


## us-gaap:DerivativesPolicyTextBlock

[0000858877-19-000012:notes:153]
(m) Derivative Instruments   We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the effective portion of the derivative’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion of the gain or loss is reported in earnings immediately. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. Any ineffective portion of the net investment hedges is reported in earnings during the period of change. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.

[0000858877-19-000012:notes:154]
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-19-000012:notes:155]
The following table presents this disaggregation of revenue (in millions):

[0000858877-19-000012:notes:156]
Amounts may not sum due to rounding.

[0000858877-19-000012:notes:157]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (SPVSS) business. Total revenue includes SPVSS business revenue of $168 million and $903 million for fiscal 2019 and 2018, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-19-000012:notes:158]
Employee Benefit Plans

[0000858877-19-000012:notes:159]
| (a) | Employee Stock Incentive Plans |

[0000858877-19-000012:notes:160]
Stock Incentive Plan Program Description    As of July 27, 2019, we had one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with Cisco. The number and frequency of share-based awards are based on competitive practices, operating results of Cisco, government regulations, and other factors. Our primary stock incentive plan is summarized as follows:

[0000858877-19-000012:notes:161]
2005 Plan    The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions.  Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. As of July 27, 2019, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares. The 2005 Plan may be terminated by the Board of Directors at any time and for any reason, and is currently set to terminate at the 2021 Annual Meeting unless re-adopted or extended by the shareholders prior to or on such date.

[0000858877-19-000012:notes:162]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan.

[0000858877-19-000012:notes:163]
| (b) | Employee Stock Purchase Plan |

[0000858877-19-000012:notes:164]
We have an Employee Stock Purchase Plan under which 721.4 million shares of our common stock have been reserved for issuance as of July 27, 2019. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. We issued 19 million, 22 million, and 23 million shares under the Employee Stock Purchase Plan in fiscal 2019, 2018, and 2017, respectively. As of July 27, 2019, 159 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-19-000012:notes:165]
| (c) | Summary of Share-Based Compensation Expense |

[0000858877-19-000012:notes:166]
Share-based compensation expense consists primarily of expenses for stock options, stock purchase rights, restricted stock, and RSUs granted to employees. The following table summarizes share-based compensation expense (in millions):

[0000858877-19-000012:notes:167]
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Cost of sales—product | $ | 90 |  |  | $ | 94 |  |  | $ | 85 |  |
| Cost of sales—service | 130 |  |  | 133 |  |  | 134 |  |
| Share-based compensation expense in cost of sales | 220 |  |  | 227 |  |  | 219 |  |
| Research and development | 540 |  |  | 538 |  |  | 529 |  |
| Sales and marketing | 519 |  |  | 555 |  |  | 542 |  |
| General and administrative | 250 |  |  | 246 |  |  | 236 |  |
| Restructuring and other charges | 62 |  |  | 33 |  |  | 3 |  |
| Share-based compensation expense in operating expenses | 1,371 |  |  | 1,372 |  |  | 1,310 |  |
| Total share-based compensation expense | $ | 1,591 |  |  | $ | 1,599 |  |  | $ | 1,529 |  |
| Income tax benefit for share-based compensation | $ | 542 |  |  | $ | 558 |  |  | $ | 451 |  |

[0000858877-19-000012:notes:168]
As of July 27, 2019, the total compensation cost related to unvested share-based awards not yet recognized was $3.3 billion, which is expected to be recognized over approximately 2.8 years on a weighted-average basis.

[0000858877-19-000012:notes:169]
| (d) | Share-Based Awards Available for Grant |

[0000858877-19-000012:notes:170]
A summary of share-based awards available for grant is as follows (in millions):

[0000858877-19-000012:notes:171]
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Balance at beginning of fiscal year | 245 |  |  | 272 |  |  | 242 |  |
| Restricted stock, stock units, and other share-based awards granted | (67 | ) |  | (70 | ) |  | (76 | ) |
| Share-based awards canceled/forfeited/expired | 18 |  |  | 18 |  |  | 78 |  |
| Shares withheld for taxes and not issued | 23 |  |  | 25 |  |  | 28 |  |
| Other | 1 |  |  | — |  |  | — |  |
| Balance at end of fiscal year | 220 |  |  | 245 |  |  | 272 |  |

[0000858877-19-000012:notes:172]
For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. For restricted stock units that were awarded with vesting contingent upon the achievement of future financial performance or market-based metrics, the maximum awards that can be achieved upon full vesting of such awards were reflected in the preceding table.

[0000858877-19-000012:notes:173]
| (e) | Restricted Stock and Stock Unit Awards |

[0000858877-19-000012:notes:174]
A summary of the restricted stock and stock unit activity, which includes time-based and performance-based or market-based RSUs, is as follows (in millions, except per-share amounts):

[0000858877-19-000012:notes:175]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 30, 2016 | 145 |  |  | $ | 24.26 |  |  |  |
| Granted | 50 |  |  | 27.89 |  |  |  |
| Assumed from acquisitions | 15 |  |  | 32.21 |  |  |  |
| Vested | (54 | ) |  | 23.14 |  |  | $ | 1,701 |  |
| Canceled/forfeited/other | (15 | ) |  | 23.56 |  |  |  |
| UNVESTED BALANCE AT JULY 29, 2017 | 141 |  |  | 26.94 |  |  |  |
| Granted | 46 |  |  | 35.62 |  |  |  |
| Assumed from acquisitions | 1 |  |  | 28.26 |  |  |  |
| Vested | (53 | ) |  | 26.02 |  |  | $ | 1,909 |  |
| Canceled/forfeited/other | (16 | ) |  | 28.37 |  |  |  |
| UNVESTED BALANCE AT JULY 28, 2018 | 119 |  |  | 30.56 |  |  |  |
| Granted | 45 |  |  | 47.71 |  |  |  |
| Vested | (50 | ) |  | 29.25 |  |  | $ | 2,446 |  |
| Canceled/forfeited/other | (14 | ) |  | 32.01 |  |  |  |
| UNVESTED BALANCE AT JULY 27, 2019 | 100 |  |  | $ | 38.66 |  |  |  |

[0000858877-19-000012:notes:176]
| (f) | Stock Option Awards |

[0000858877-19-000012:notes:177]
A summary of the stock option activity is as follows (in millions, except per-share amounts):

[0000858877-19-000012:notes:178]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 30, 2016 | 73 |  |  | $ | 26.78 |  |
| Assumed from acquisitions | 8 |  |  | 4.47 |  |
| Exercised | (14 | ) |  | 12.11 |  |
| Canceled/forfeited/expired | (55 | ) |  | 31.83 |  |
| BALANCE AT JULY 29, 2017 | 12 |  |  | 6.15 |  |
| Assumed from acquisitions | 3 |  |  | 8.20 |  |
| Exercised | (8 | ) |  | 5.77 |  |
| Canceled/forfeited/expired | (1 | ) |  | 8.75 |  |
| BALANCE AT JULY 28, 2018 | 6 |  |  | 7.18 |  |
| Exercised | (4 | ) |  | 7.12 |  |
| BALANCE AT JULY 27, 2019 | 2 |  |  | $ | 6.94 |  |

[0000858877-19-000012:notes:179]
The total pretax intrinsic value of stock options exercised during fiscal 2019, 2018, and 2017 was $149 million, $257 million, and $283 million, respectively.

[0000858877-19-000012:notes:180]
The total number of in-the-money stock options exercisable as of July 27, 2019 and July 28, 2018 were 2 million and 4 million, respectively. As of July 27, 2019 and July 28, 2018, 2 million and 4 million outstanding stock options were exercisable and the weighted-average exercise price was $6.75 and $6.84, respectively.

[0000858877-19-000012:notes:181]
| (g) | Valuation of Employee Share-Based Awards |

[0000858877-19-000012:notes:182]
Time-based restricted stock units and PRSUs that are based on our financial performance metrics or non-financial operating goals are valued using the market value of our common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, we estimated the fair value of the total shareholder return (TSR) component of the PRSUs using a Monte Carlo simulation model. The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-19-000012:notes:183]
|  | RESTRICTED STOCK UNITS |
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Number of shares granted (in millions) | 43 |  |  | 43 |  |  | 43 |  |
| Grant date fair value per share | $ | 47.75 |  |  | $ | 35.81 |  |  | $ | 28.38 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 2.7 | % |  | 3.2 | % |  | 3.5 | % |
| Range of risk-free interest rates | 0.0% – 2.9% |  |  | 0.0% – 2.7% |  |  | 0.0% – 1.5% |  |

[0000858877-19-000012:notes:184]
|  | PERFORMANCE BASED RESTRICTED STOCK UNITS |
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Number of shares granted (in millions) | 2 |  |  | 3 |  |  | 7 |  |
| Grant date fair value per share | $ | 47.00 |  |  | $ | 32.69 |  |  | $ | 28.94 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 2.8 | % |  | 3.5 | % |  | 3.4 | % |
| Range of risk-free interest rates | 2.1% – 3.0% |  |  | 1.0% – 2.7% |  |  | 0.1% – 1.5% |  |
| Range of expected volatilities for index | 13.0% - 65.2% |  |  | 12.5% - 82.8% |  |  | 16.7% – 46.8% |  |

[0000858877-19-000012:notes:185]
The PRSUs granted during the fiscal years presented are contingent on the achievement of our financial performance metrics, our comparative market-based returns, or the achievement of financial and non-financial operating goals. For the awards based on financial performance metrics or comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period. Generally, the remaining 50% of the PRSUs are earned based on our TSR measured against the benchmark TSR of a peer group over the same period. Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of our financial performance metrics or our comparative market-based returns, and 0% to 100% of the target shares granted contingent on the achievement of non-financial operating goals.

[0000858877-19-000012:notes:186]
The assumptions for the valuation of employee stock purchase rights are summarized as follows:

[0000858877-19-000012:notes:187]
|  | EMPLOYEE STOCK PURCHASE RIGHTS |
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Weighted-average assumptions: |  |  |  |  |  |
| Expected volatility | 20.4 | % |  | 22.1 | % |  | 24.6 | % |
| Risk-free interest rate | 1.9 | % |  | 1.3 | % |  | 0.7 | % |
| Expected dividend | 3.0 | % |  | 3.1 | % |  | 3.2 | % |
| Expected life (in years) | 1.3 |  |  | 1.3 |  |  | 1.3 |  |
| Weighted-average estimated grant date fair value per share | $ | 9.06 |  |  | $ | 7.48 |  |  | $ | 6.52 |  |

[0000858877-19-000012:notes:188]
The valuation of employee stock purchase rights and the related assumptions are for the employee stock purchases made during the respective fiscal years.

[0000858877-19-000012:notes:189]
We used third-party analyses to assist in developing the assumptions used in our Black-Scholes model. We are responsible for determining the assumptions used in estimating the fair value of our share-based payment awards.

[0000858877-19-000012:notes:190]
We used the implied volatility for traded options (with contract terms corresponding to the expected life of the employee stock purchase rights) on our stock as the expected volatility assumption required in the Black-Scholes model. The implied volatility is more representative of future stock price trends than historical volatility. The risk-free interest rate assumption is based upon observed interest rates appropriate for the term of our employee stock purchase rights. The dividend yield assumption is based on the history and expectation of dividend payouts at the grant date.

[0000858877-19-000012:notes:191]
| (h) | Employee 401(k) Plans |

[0000858877-19-000012:notes:192]
We sponsor the Cisco Systems, Inc. 401(k) Plan (the “Plan”) to provide retirement benefits for our employees. As allowed under Section 401(k) of the Internal Revenue Code, the Plan provides for tax-deferred salary contributions and after-tax contributions for eligible employees. The Plan allows employees to contribute up to 75% of their annual eligible earnings to the Plan on a pretax and after-tax basis, including Roth contributions. Employee contributions are limited to a maximum annual amount as set periodically by the Internal Revenue Code. We match pretax and Roth employee contributions up to 100% of the first 4.5% of eligible earnings that are contributed by employees. Therefore, the maximum matching contribution that we may allocate to each participant’s account will not exceed $12,600 for the 2019 calendar year due to the $280,000 annual limit on eligible earnings imposed by the Internal Revenue Code. All matching contributions vest immediately. Our matching contributions to the Plan totaled $283 million, $269 million, and $265 million in fiscal 2019, 2018, and 2017, respectively.

[0000858877-19-000012:notes:193]
The Plan allows employees who meet the age requirements and reach the Plan contribution limits to make catch-up contributions (pretax or Roth) not to exceed the lesser of 75% of their annual eligible earnings or the limit set forth in the Internal Revenue Code. Catch-up contributions are not eligible for matching contributions. In addition, the Plan provides for discretionary profit-sharing contributions as determined by the Board of Directors. Such contributions to the Plan are allocated among eligible participants in the proportion of their salaries to the total salaries of all participants. There were no discretionary profit-sharing contributions made in fiscal 2019, 2018, and 2017.

[0000858877-19-000012:notes:194]
We also sponsor other 401(k) plans as a result of acquisitions of other companies. Our contributions to these plans were not material to Cisco on either an individual or aggregate basis for any of the fiscal years presented.

[0000858877-19-000012:notes:195]
| (i) | Deferred Compensation Plans |

[0000858877-19-000012:notes:196]
The Cisco Systems, Inc. Deferred Compensation Plan (the “Deferred Compensation Plan”), a nonqualified deferred compensation plan, became effective in 2007. As required by applicable law, participation in the Deferred Compensation Plan is limited to a select group of our management employees. Under the Deferred Compensation Plan, which is an unfunded and unsecured deferred compensation arrangement, a participant may elect to defer base salary, bonus, and/or commissions, pursuant to such rules as may be established by Cisco, up to the maximum percentages for each deferral election as described in the plan. We may also, at our discretion, make a matching contribution to the employee under the Deferred Compensation Plan. A matching contribution equal to 4.5% of eligible compensation in excess of the Internal Revenue Code limit for qualified plans for calendar year 2019 that is deferred by participants under the Deferred Compensation Plan (with a $1.5 million cap on eligible compensation) will be made to eligible participants’ accounts at the end of calendar year 2019. The total deferred compensation liability under the Deferred Compensation Plan, together with deferred compensation plans assumed from acquired companies, was approximately $678 million and $651 million as of July 27, 2019 and July 28, 2018, respectively, and was recorded primarily in other long-term liabilities.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000858877-19-000012:notes:197]
(u) Computation of Net Income per Share   Basic net income per share is computed using the weighted-average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted-average number of common shares and dilutive potential common shares outstanding during the period. Diluted shares outstanding includes the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares.

[0000858877-19-000012:notes:198]
Employee equity share options, unvested shares, and similar equity instruments granted and assumed by Cisco are treated as potential common shares outstanding in computing diluted earnings per share. Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that has not yet recognized are collectively assumed to be used to repurchase shares.


## us-gaap:EarningsPerShareTextBlock

[0000858877-19-000012:notes:199]
Net Income per Share

[0000858877-19-000012:notes:200]
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-19-000012:notes:201]
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Net income | $ | 11,621 |  |  | $ | 110 |  |  | $ | 9,609 |  |
| Weighted-average shares—basic | 4,419 |  |  | 4,837 |  |  | 5,010 |  |
| Effect of dilutive potential common shares | 34 |  |  | 44 |  |  | 39 |  |
| Weighted-average shares—diluted | 4,453 |  |  | 4,881 |  |  | 5,049 |  |
| Net income per share—basic | $ | 2.63 |  |  | $ | 0.02 |  |  | $ | 1.92 |  |
| Net income per share—diluted | $ | 2.61 |  |  | $ | 0.02 |  |  | $ | 1.90 |  |
| Antidilutive employee share-based awards, excluded | 55 |  |  | 61 |  |  | 136 |  |


## us-gaap:EquitySecuritiesWithoutReadilyDeterminableFairValueTableTextBlock

[0000858877-19-000012:notes:202]
We recorded adjustments to the carrying value of our non-marketable equity securities measured using the measurement alternative during fiscal 2019 as follows (in millions):

[0000858877-19-000012:notes:203]
|  | July 27, 2019 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |
| Upward adjustments | $ | 35 |  |
| Downward adjustments, including impairments | (57 | ) |
| Net adjustments | $ | (22 | ) |

[0000858877-19-000012:notes:204]
Gains and losses recognized on our marketable and non-marketable equity securities for fiscal 2019 are as follows (in millions):

[0000858877-19-000012:notes:205]
|  | July 27, 2019 |
| Net gains and losses recognized during the period on equity investments | $ | 58 |  |
| Less: Net gains and losses recognized on equity investments sold | (69 | ) |
| Net unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | (11 | ) |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-19-000012:notes:206]
The following table presents gains and losses on assets that were measured at fair value on a nonrecurring basis (in millions):

[0000858877-19-000012:notes:207]
|  | TOTAL GAINS (LOSSES) FOR THE YEARS ENDED |
|  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Non-marketable equity securities and equity method investments | $ | (32 | ) |  | $ | (62 | ) |  | $ | (177 | ) |
| Purchased intangible assets (impaired) | — |  |  | (1 | ) |  | (47 | ) |
| Property held for sale - land and buildings | — |  |  | 20 |  |  | (30 | ) |
| Total gains (losses) for nonrecurring measurements | $ | (32 | ) |  | $ | (43 | ) |  | $ | (254 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-19-000012:notes:208]
Fair Value

[0000858877-19-000012:notes:209]
| (a) | Assets and Liabilities Measured at Fair Value on a Recurring Basis |

[0000858877-19-000012:notes:210]
Assets and liabilities measured at fair value on a recurring basis were as follows (in millions):

[0000858877-19-000012:notes:211]
|  | JULY 27, 2019 |  | JULY 28, 2018 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 10,083 |  |  | $ | — |  |  | $ | 10,083 |  |  | $ | 6,890 |  |  | $ | — |  |  | $ | 6,890 |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 808 |  |  | 808 |  |  | — |  |  | 7,275 |  |  | 7,275 |  |
| U.S. government agency securities | — |  |  | 169 |  |  | 169 |  |  | — |  |  | 727 |  |  | 727 |  |
| Non-U.S. government and agency securities | — |  |  | — |  |  | — |  |  | — |  |  | 208 |  |  | 208 |  |
| Corporate debt securities | — |  |  | 19,262 |  |  | 19,262 |  |  | — |  |  | 27,364 |  |  | 27,364 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,421 |  |  | 1,421 |  |  | — |  |  | 1,435 |  |  | 1,435 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 3 |  |  | — |  |  | 3 |  |  | 605 |  |  | — |  |  | 605 |  |
| Derivative assets | — |  |  | 89 |  |  | 89 |  |  | — |  |  | 2 |  |  | 2 |  |
| Total | $ | 10,086 |  |  | $ | 21,749 |  |  | $ | 31,835 |  |  | $ | 7,495 |  |  | $ | 37,011 |  |  | $ | 44,506 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 15 |  |  | $ | 15 |  |  | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |
| Total | $ | — |  |  | $ | 15 |  |  | $ | 15 |  |  | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |

[0000858877-19-000012:notes:212]
Level 1 marketable equity securities are determined by using quoted prices in active markets for identical assets. Level 2 available-for-sale debt investments are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. Our derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs. We did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.

[0000858877-19-000012:notes:213]
| (b) | Assets Measured at Fair Value on a Nonrecurring Basis |

[0000858877-19-000012:notes:214]
These assets were measured at fair value due to events or circumstances we identified as having significant impact on their fair value during the respective periods. The carrying value of our non-marketable equity securities recorded to fair value on a non-recurring basis is adjusted for observable transactions for identical or similar investments of the same issuer or impairment. These securities are classified as Level 3 in the fair value hierarchy because we estimate the value based on valuation methods using the observable transaction price at the transaction date and other unobservable inputs such as volatility, rights, and obligations of the securities we hold.

[0000858877-19-000012:notes:215]
The fair value for purchased intangibles assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation. Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable. See Note 5.

[0000858877-19-000012:notes:216]
The fair value of property held for sale was measured with the assistance of third-party valuation models, which used discounted cash flow techniques as part of their analysis. The fair value measurement was categorized as Level 3, as significant unobservable inputs were used in the valuation report. The impairment charges as a result of the valuations, which represented the difference between the fair value less cost to sell and the carrying amount of the assets held for sale, were included in restructuring and other charges.

[0000858877-19-000012:notes:217]
| (c) | Other Fair Value Disclosures |

[0000858877-19-000012:notes:218]
The fair value of our short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables and financed service contracts as of July 27, 2019 and July 28, 2018 was $3.7 billion and $3.6 billion, respectively. The estimated fair value of our long-term loan receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-19-000012:notes:219]
As of July 27, 2019 and July 28, 2018, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of July 27, 2019, the fair value of our senior notes and other long-term debt was $22.1 billion, with a carrying amount of $20.5 billion. This compares to a fair value of $26.4 billion and a carrying amount of $25.6 billion as of July 28, 2018. The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-19-000012:notes:220]
Gross receivables, excluding residual value, less unearned income categorized by our internal credit risk rating as of July 27, 2019 and July 28, 2018 are summarized as follows (in millions):

[0000858877-19-000012:notes:221]
|  | INTERNAL CREDIT RISK RATING |
| July 27, 2019 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,204 |  |  | $ | 991 |  |  | $ | 35 |  |  | $ | 2,230 |  |
| Loan receivables | 3,367 |  |  | 1,920 |  |  | 151 |  |  | 5,438 |  |
| Financed service contracts | 1,413 |  |  | 939 |  |  | 17 |  |  | 2,369 |  |
| Total | $ | 5,984 |  |  | $ | 3,850 |  |  | $ | 203 |  |  | $ | 10,037 |  |

[0000858877-19-000012:notes:222]
|  | INTERNAL CREDIT RISK RATING |
| July 28, 2018 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,294 |  |  | $ | 1,199 |  |  | $ | 54 |  |  | $ | 2,547 |  |
| Loan receivables | 3,184 |  |  | 1,752 |  |  | 63 |  |  | 4,999 |  |
| Financed service contracts | 1,468 |  |  | 835 |  |  | 23 |  |  | 2,326 |  |
| Total | $ | 5,946 |  |  | $ | 3,786 |  |  | $ | 140 |  |  | $ | 9,872 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-19-000012:notes:223]
Financing Receivables and Operating Leases

[0000858877-19-000012:notes:224]
| (a) | Financing Receivables |

[0000858877-19-000012:notes:225]
Financing receivables primarily consist of lease receivables, loan receivables, and financed service contracts. Lease receivables represent sales-type and direct-financing leases resulting from the sale of Cisco's and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services, which may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables have terms of three years on average. Financed service contracts include financing receivables related to technical support and advanced services. Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one to three years.

[0000858877-19-000012:notes:226]
A summary of our financing receivables is presented as follows (in millions):

[0000858877-19-000012:notes:227]
| July 27, 2019 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,367 |  |  | $ | 5,438 |  |  | $ | 2,369 |  |  | $ | 10,174 |  |
| Residual value | 142 |  |  | — |  |  | — |  |  | 142 |  |
| Unearned income | (137 | ) |  | — |  |  | — |  |  | (137 | ) |
| Allowance for credit loss | (46 | ) |  | (71 | ) |  | (9 | ) |  | (126 | ) |
| Total, net | $ | 2,326 |  |  | $ | 5,367 |  |  | $ | 2,360 |  |  | $ | 10,053 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,029 |  |  | $ | 2,653 |  |  | $ | 1,413 |  |  | $ | 5,095 |  |
| Noncurrent | 1,297 |  |  | 2,714 |  |  | 947 |  |  | 4,958 |  |
| Total, net | $ | 2,326 |  |  | $ | 5,367 |  |  | $ | 2,360 |  |  | $ | 10,053 |  |

[0000858877-19-000012:notes:228]
| July 28, 2018 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,688 |  |  | $ | 4,999 |  |  | $ | 2,326 |  |  | $ | 10,013 |  |
| Residual value | 164 |  |  | — |  |  | — |  |  | 164 |  |
| Unearned income | (141 | ) |  | — |  |  | — |  |  | (141 | ) |
| Allowance for credit loss | (135 | ) |  | (60 | ) |  | (10 | ) |  | (205 | ) |
| Total, net | $ | 2,576 |  |  | $ | 4,939 |  |  | $ | 2,316 |  |  | $ | 9,831 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,249 |  |  | $ | 2,376 |  |  | $ | 1,324 |  |  | $ | 4,949 |  |
| Noncurrent | 1,327 |  |  | 2,563 |  |  | 992 |  |  | 4,882 |  |
| Total, net | $ | 2,576 |  |  | $ | 4,939 |  |  | $ | 2,316 |  |  | $ | 9,831 |  |

[0000858877-19-000012:notes:229]
Future minimum lease payments to Cisco on lease receivables as of July 27, 2019 are summarized as follows (in millions):

[0000858877-19-000012:notes:230]
| Fiscal Year | Amount |
| 2020 | $ | 1,028 |  |
| 2021 | 702 |  |
| 2022 | 399 |  |
| 2023 | 185 |  |
| 2024 | 53 |  |
| Total | $ | 2,367 |  |

[0000858877-19-000012:notes:231]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-19-000012:notes:232]
| (b) | Credit Quality of Financing Receivables |

[0000858877-19-000012:notes:233]
We determine the adequacy of our allowance for credit loss by assessing the risks and losses inherent in our financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by us to our customers, which consist of the following: lease receivables, loan receivables, and financed service contracts.

[0000858877-19-000012:notes:234]
Our internal credit risk ratings of 1 through 4 correspond to investment-grade ratings, while credit risk ratings of 5 and 6 correspond to non-investment grade ratings. Credit risk ratings of 7 and higher correspond to substandard ratings.

[0000858877-19-000012:notes:235]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of July 27, 2019 and July 28, 2018 (in millions):

[0000858877-19-000012:notes:236]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 27, 2019 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 101 |  |  | $ | 42 |  |  | $ | 291 |  |  | $ | 434 |  |  | $ | 1,796 |  |  | $ | 2,230 |  |  | $ | 13 |  |  | $ | 13 |  |
| Loan receivables | 257 |  |  | 67 |  |  | 338 |  |  | 662 |  |  | 4,776 |  |  | 5,438 |  |  | 31 |  |  | 31 |  |
| Financed service contracts | 145 |  |  | 131 |  |  | 271 |  |  | 547 |  |  | 1,822 |  |  | 2,369 |  |  | 3 |  |  | 3 |  |
| Total | $ | 503 |  |  | $ | 240 |  |  | $ | 900 |  |  | $ | 1,643 |  |  | $ | 8,394 |  |  | $ | 10,037 |  |  | $ | 47 |  |  | $ | 47 |  |

[0000858877-19-000012:notes:237]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 28, 2018 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 72 |  |  | $ | 27 |  |  | $ | 155 |  |  | $ | 254 |  |  | $ | 2,293 |  |  | $ | 2,547 |  |  | $ | 9 |  |  | $ | 9 |  |
| Loan receivables | 104 |  |  | 55 |  |  | 252 |  |  | 411 |  |  | 4,588 |  |  | 4,999 |  |  | 30 |  |  | 30 |  |
| Financed service contracts | 138 |  |  | 78 |  |  | 304 |  |  | 520 |  |  | 1,806 |  |  | 2,326 |  |  | 3 |  |  | 3 |  |
| Total | $ | 314 |  |  | $ | 160 |  |  | $ | 711 |  |  | $ | 1,185 |  |  | $ | 8,687 |  |  | $ | 9,872 |  |  | $ | 42 |  |  | $ | 42 |  |

[0000858877-19-000012:notes:238]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract. The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $244 million and $503 million as of July 27, 2019 and July 28, 2018, respectively.

[0000858877-19-000012:notes:239]
As of July 27, 2019, we had financing receivables of $215 million, net of unbilled or current receivables, that were greater than 120 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $182 million as of July 28, 2018.

[0000858877-19-000012:notes:240]
| (c) | Allowance for Credit Loss Rollforward |

[0000858877-19-000012:notes:241]
| (d) | Operating Leases |

[0000858877-19-000012:notes:242]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-19-000012:notes:243]
|  | July 27, 2019 |  | July 28, 2018 |
| Operating lease assets | $ | 485 |  |  | $ | 356 |  |
| Accumulated depreciation | (306 | ) |  | (238 | ) |
| Operating lease assets, net | $ | 179 |  |  | $ | 118 |  |

[0000858877-19-000012:notes:244]
Minimum future rentals on noncancelable operating leases as of July 27, 2019 are summarized as follows (in millions):

[0000858877-19-000012:notes:245]
| Fiscal Year | Amount |
| 2020 | $ | 125 |  |
| 2021 | 64 |  |
| 2022 | 16 |  |
| 2023 | 1 |  |
| Total | $ | 206 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000858877-19-000012:notes:246]
(n) Foreign Currency Translation   Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated to U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of AOCI. Income and expense accounts are translated at average exchange rates during the year. Remeasurement adjustments are recorded in other income (loss), net. The effect of foreign currency exchange rates on cash and cash equivalents was not material for any of the fiscal years presented.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-19-000012:notes:247]
Goodwill and Purchased Intangible Assets

[0000858877-19-000012:notes:248]
| (a) | Goodwill |

[0000858877-19-000012:notes:249]
The following tables present the goodwill allocated to our reportable segments as of July 27, 2019 and July 28, 2018, as well as the changes to goodwill during fiscal 2019 and 2018 (in millions):

[0000858877-19-000012:notes:250]
|  | Balance at July 28, 2018 |  | Acquisitions & Divestitures |  | Other |  | Balance at July 27, 2019 |
| Americas | $ | 19,998 |  |  | $ | 1,240 |  |  | $ | (118 | ) |  | $ | 21,120 |  |
| EMEA | 7,529 |  |  | 486 |  |  | (38 | ) |  | 7,977 |  |
| APJC | 4,179 |  |  | 274 |  |  | (21 | ) |  | 4,432 |  |
| Total | $ | 31,706 |  |  | $ | 2,000 |  |  | $ | (177 | ) |  | $ | 33,529 |  |

[0000858877-19-000012:notes:251]
|  | Balance at July 29, 2017 |  | Acquisitions |  | Other |  | Balance at July 28, 2018 |
| Americas | $ | 18,691 |  |  | $ | 1,355 |  |  | $ | (48 | ) |  | $ | 19,998 |  |
| EMEA | 7,057 |  |  | 491 |  |  | (19 | ) |  | 7,529 |  |
| APJC | 4,018 |  |  | 171 |  |  | (10 | ) |  | 4,179 |  |
| Total | $ | 29,766 |  |  | $ | 2,017 |  |  | $ | (77 | ) |  | $ | 31,706 |  |

[0000858877-19-000012:notes:252]
“Other” in the tables above primarily consists of foreign currency translation as well as immaterial purchase accounting adjustments.

[0000858877-19-000012:notes:253]
| (b) | Purchased Intangible Assets |

[0000858877-19-000012:notes:254]
Purchased intangible assets include intangible assets acquired through acquisitions as well as through direct purchases or licenses.

[0000858877-19-000012:notes:255]
Impairment charges related to purchased intangible assets were approximately $47 million for fiscal 2017. Impairment charges were as a result of declines in estimated fair value resulting from the reduction or elimination of expected future cash flows associated with certain of our technology and IPR&D intangible assets.

[0000858877-19-000012:notes:256]
The estimated future amortization expense of purchased intangible assets with finite lives as of July 27, 2019 is as follows (in millions):

[0000858877-19-000012:notes:257]
| Fiscal Year | Amount |
| 2020 | $ | 761 |  |
| 2021 | $ | 565 |  |
| 2022 | $ | 307 |  |
| 2023 | $ | 165 |  |
| 2024 | $ | 67 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000858877-19-000012:notes:258]
(j) Goodwill and Purchased Intangible Assets   Goodwill is tested for impairment on an annual basis in the fourth fiscal quarter and, when specific circumstances dictate, between annual tests. When impaired, the carrying value of goodwill is written down to fair value. Identifying a potential impairment consists of comparing the fair value of a reporting unit with its carrying amount, including goodwill. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. See “Long-Lived Assets” for our policy regarding impairment testing of purchased intangible assets with finite lives. Purchased intangible assets with indefinite lives are assessed for potential impairment annually or when events or circumstances indicate that their carrying amounts might be impaired.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000858877-19-000012:notes:259]
(k) Long-Lived Assets   Long-lived assets that are held and used by us are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability of long-lived assets is based on an estimate of the undiscounted future cash flows resulting from the use of the asset and its eventual disposition. Measurement of an impairment loss for long-lived assets that management expects to hold and use is based on the difference between the fair value of the asset and its carrying value. Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-19-000012:notes:260]
Income Taxes

[0000858877-19-000012:notes:261]
| (a) | Provision for Income Taxes |

[0000858877-19-000012:notes:262]
The provision for income taxes consists of the following (in millions):

[0000858877-19-000012:notes:263]
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Federal: |  |  |  |  |  |
| Current | $ | 1,760 |  |  | $ | 9,900 |  |  | $ | 1,300 |  |
| Deferred | (84 | ) |  | 1,156 |  |  | (42 | ) |
|  | 1,676 |  |  | 11,056 |  |  | 1,258 |  |
| State: |  |  |  |  |  |
| Current | 302 |  |  | 340 |  |  | 86 |  |
| Deferred | (2 | ) |  | (232 | ) |  | 56 |  |
|  | 300 |  |  | 108 |  |  | 142 |  |
| Foreign: |  |  |  |  |  |
| Current | 1,238 |  |  | 1,789 |  |  | 1,416 |  |
| Deferred | (264 | ) |  | (24 | ) |  | (138 | ) |
|  | 974 |  |  | 1,765 |  |  | 1,278 |  |
| Total | $ | 2,950 |  |  | $ | 12,929 |  |  | $ | 2,678 |  |

[0000858877-19-000012:notes:264]
Income before provision for income taxes consists of the following (in millions):

[0000858877-19-000012:notes:265]
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| United States | $ | 7,611 |  |  | $ | 3,765 |  |  | $ | 2,393 |  |
| International | 6,960 |  |  | 9,274 |  |  | 9,894 |  |
| Total | $ | 14,571 |  |  | $ | 13,039 |  |  | $ | 12,287 |  |

[0000858877-19-000012:notes:266]
The items accounting for the difference between income taxes computed at the federal statutory rate and the provision for income taxes consist of the following:

[0000858877-19-000012:notes:267]
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Federal statutory rate | 21.0 | % |  | 27.0 | % |  | 35.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 2.0 |  |  | 0.6 |  |  | 1.1 |  |
| Foreign income at other than U.S. rates | (4.5 | ) |  | (5.2 | ) |  | (13.4 | ) |
| Tax credits | (1.7 | ) |  | (2.5 | ) |  | (1.2 | ) |
| Foreign-derived intangible income deduction | (1.3 | ) |  | — |  |  | — |  |
| Domestic manufacturing deduction | — |  |  | (0.5 | ) |  | (0.4 | ) |
| Stock-based compensation | (0.6 | ) |  | (0.1 | ) |  | 1.4 |  |
| Impact of the Tax Act | 6.1 |  |  | 80.1 |  |  | — |  |
| Other, net | (0.8 | ) |  | (0.2 | ) |  | (0.7 | ) |
| Total | 20.2 | % |  | 99.2 | % |  | 21.8 | % |

[0000858877-19-000012:notes:268]
On December 22, 2017, the Tax Act was enacted. The Tax Act significantly revises the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (“federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries.

[0000858877-19-000012:notes:269]
During fiscal 2018, we recorded a provisional tax expense of $10.4 billion related to the Tax Act. The provisional tax expense included an $863 million benefit associated with the U.S. taxation of deemed foreign dividends in the transition fiscal year. As previously disclosed, the benefit could be subject to reduction or elimination by subsequent government action. In the fourth quarter of fiscal 2019 we recorded an $872 million charge, which was the reversal of the previously recorded benefit associated with the U.S. taxation of deemed foreign dividends recorded in fiscal 2018, as a result of a retroactive final U.S. Treasury regulation issued during the quarter.

[0000858877-19-000012:notes:270]
The total tax charge as a result of the Tax Act was $11.3 billion, consisting of $9.0 billion of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries, $1.2 billion of foreign withholding tax and $1.1 billion of tax expense for DTA re-measurement.

[0000858877-19-000012:notes:271]
The Tax Act includes a Global Intangible Low-Taxed Income (GILTI) provision that imposes U.S. tax on certain foreign subsidiary income in the year it is earned. Our accounting policy is to treat tax on GILTI as a current period cost included in tax expense in the year incurred.

[0000858877-19-000012:notes:272]
Foreign taxes associated with the repatriation of earnings of foreign subsidiaries were not provided on a cumulative total of $6.6 billion of undistributed earnings for certain foreign subsidiaries as of the end of fiscal 2019. We intend to reinvest these earnings indefinitely in such foreign subsidiaries. If these earnings were distributed in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, we could be subject to additional foreign taxes. The amount of potential unrecognized deferred income tax liability related to these earnings is approximately $711 million.

[0000858877-19-000012:notes:273]
As a result of certain employment and capital investment actions, our income in certain foreign countries is subject to reduced tax rates. A portion of these incentives expired at the end of fiscal 2015. The remaining tax incentives expired at the end of fiscal 2019. The gross income tax benefit attributable to tax incentives was estimated to be $0.3 billion ($0.08 per diluted share) in fiscal 2019. As of the end of fiscal 2018 and 2017, the gross income tax benefits attributable to tax incentives were estimated to be $0.9 billion and $1.3 billion ($0.19 and $0.25 per diluted share) for the respective years. The gross income tax benefits were partially offset by accruals of U.S. income taxes on foreign earnings.

[0000858877-19-000012:notes:274]
Unrecognized Tax Benefits

[0000858877-19-000012:notes:275]
The aggregate changes in the balance of gross unrecognized tax benefits were as follows (in millions):

[0000858877-19-000012:notes:276]
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Beginning balance | $ | 2,000 |  |  | $ | 1,973 |  |  | $ | 1,627 |  |
| Additions based on tax positions related to the current year | 185 |  |  | 251 |  |  | 336 |  |
| Additions for tax positions of prior years | 84 |  |  | 84 |  |  | 180 |  |
| Reductions for tax positions of prior years | (283 | ) |  | (129 | ) |  | (78 | ) |
| Settlements | (38 | ) |  | (124 | ) |  | (43 | ) |
| Lapse of statute of limitations | (23 | ) |  | (55 | ) |  | (49 | ) |
| Ending balance | $ | 1,925 |  |  | $ | 2,000 |  |  | $ | 1,973 |  |

[0000858877-19-000012:notes:277]
As of July 27, 2019, $1.7 billion of the unrecognized tax benefits would affect the effective tax rate if realized. During fiscal 2019, we recognized $30 million of net interest expense and $6 million of penalty expense. During fiscal 2018, we recognized $10 million of net interest expense and no net penalty expense. During fiscal 2017, we recognized $26 million of net interest expense and a $4 million reduction in penalties. Our total accrual for interest and penalties was $220 million, $180 million, and $186 million as of the end of fiscal 2019, 2018, and 2017, respectively. We are no longer subject to U.S. federal income tax audit for returns covering tax years through fiscal 2010. We are no longer subject to foreign or state income tax audits for returns covering tax years through fiscal 1999 and fiscal 2008, respectively.

[0000858877-19-000012:notes:278]
We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters. We estimate that the unrecognized tax benefits at July 27, 2019 could be reduced by $50 million in the next 12 months.

[0000858877-19-000012:notes:279]
| (b) | Deferred Tax Assets and Liabilities |

[0000858877-19-000012:notes:280]
The following table presents the breakdown for net deferred tax assets (in millions):

[0000858877-19-000012:notes:281]
|  | July 27, 2019 |  | July 28, 2018 |
| Deferred tax assets | $ | 4,065 |  |  | $ | 3,219 |  |
| Deferred tax liabilities | (95 | ) |  | (141 | ) |
| Total net deferred tax assets | $ | 3,970 |  |  | $ | 3,078 |  |

[0000858877-19-000012:notes:282]
The following table presents the components of the deferred tax assets and liabilities (in millions):

[0000858877-19-000012:notes:283]
|  | July 27, 2019 |  | July 28, 2018 |
| ASSETS |  |  |  |
| Allowance for doubtful accounts and returns | $ | 127 |  |  | $ | 285 |  |
| Sales-type and direct-financing leases | 176 |  |  | 171 |  |
| Inventory write-downs and capitalization | 409 |  |  | 289 |  |
| Investment provisions | — |  |  | 54 |  |
| IPR&D, goodwill, and purchased intangible assets | 1,427 |  |  | 63 |  |
| Deferred revenue | 1,150 |  |  | 1,584 |  |
| Credits and net operating loss carryforwards | 1,241 |  |  | 1,087 |  |
| Share-based compensation expense | 164 |  |  | 190 |  |
| Accrued compensation | 342 |  |  | 370 |  |
| Other | 419 |  |  | 408 |  |
| Gross deferred tax assets | 5,455 |  |  | 4,501 |  |
| Valuation allowance | (457 | ) |  | (374 | ) |
| Total deferred tax assets | 4,998 |  |  | 4,127 |  |
| LIABILITIES |  |  |  |
| Purchased intangible assets | (705 | ) |  | (753 | ) |
| Depreciation | (141 | ) |  | (118 | ) |
| Unrealized gains on investments | (70 | ) |  | (33 | ) |
| Other | (112 | ) |  | (145 | ) |
| Total deferred tax liabilities | (1,028 | ) |  | (1,049 | ) |
| Total net deferred tax assets | $ | 3,970 |  |  | $ | 3,078 |  |

[0000858877-19-000012:notes:284]
As of July 27, 2019, our federal, state, and foreign net operating loss carryforwards for income tax purposes were $676 million, $1 billion, and $756 million, respectively. A significant amount of the net operating loss carryforwards relates to acquisitions and, as a result, is limited in the amount that can be recognized in any one year. If not utilized, the federal, state and foreign net operating loss carryforwards will begin to expire in fiscal 2020. We have provided a valuation allowance of $111 million for deferred tax assets related to foreign net operating losses that are not expected to be realized.

[0000858877-19-000012:notes:285]
As of July 27, 2019, our federal, state, and foreign tax credit carryforwards for income tax purposes were approximately $25 million, $1.1 billion, and $5 million, respectively. The federal tax credit carryforwards will begin to expire in fiscal 2020. The majority of state and foreign tax credits can be carried forward indefinitely. We have provided a valuation allowance of $346 million for deferred tax assets related to state and foreign tax credits that are not expected to be realized.


## us-gaap:IncomeTaxPolicyTextBlock

[0000858877-19-000012:notes:286]
(t) Income Taxes   Income tax expense is based on pretax financial accounting income. Deferred tax assets and liabilities are recognized for the expected tax consequences of temporary differences between the tax bases of assets and liabilities and their reported amounts. Valuation allowances are recorded to reduce deferred tax assets to the amount that will more likely than not be realized.

[0000858877-19-000012:notes:287]
We account for uncertainty in income taxes using a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. We classify the liability for unrecognized tax benefits as current to the extent that we anticipate payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.


## us-gaap:InventoryPolicyTextBlock

[0000858877-19-000012:notes:288]
(e) Inventories   Inventories are stated at the lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. We provide inventory write-downs based on excess and obsolete inventories determined primarily by future demand forecasts. The write-down is measured as the difference between the cost of the inventory and market based upon assumptions about future demand and charged to the provision for inventory, which is a component of cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In addition, we record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-19-000012:notes:289]
The following table summarizes the maturities of our available-for-sale debt investments as of July 27, 2019 (in millions):

[0000858877-19-000012:notes:290]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 6,322 |  |  | $ | 6,324 |  |
| After 1 year through 5 years | 12,191 |  |  | 12,218 |  |
| After 5 years through 10 years | 1,643 |  |  | 1,687 |  |
| After 10 years | 9 |  |  | 10 |  |
| Mortgage-backed securities with no single maturity | 1,425 |  |  | 1,421 |  |
| Total | $ | 21,590 |  |  | $ | 21,660 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-19-000012:notes:291]
Available-for-Sale Debt Investments and Equity Investments

[0000858877-19-000012:notes:292]
The following table summarizes our available-for-sale debt investments and equity investments (in millions):

[0000858877-19-000012:notes:293]
|  | July 27, 2019 |  | July 28, 2018 |
| Available-for-sale debt investments | $ | 21,660 |  |  | $ | 37,009 |  |
| Marketable equity securities | 3 |  |  | 605 |  |
| Total investments | 21,663 |  |  | 37,614 |  |
| Non-marketable equity securities included in other assets (1) | 1,113 |  |  | 978 |  |
| Equity method investments included in other assets | 87 |  |  | 118 |  |
| Total | $ | 22,863 |  |  | $ | 38,710 |  |

[0000858877-19-000012:notes:294]
(1) We held equity interests in certain private equity funds of $0.6 billion as of July 27, 2019 which are accounted for under the NAV practical expedient following the adoption of ASU 2016-01, Financial Instruments, starting in the first quarter of fiscal 2019.

[0000858877-19-000012:notes:295]
| (a) | Summary of Available-for-Sale Debt Investments |

[0000858877-19-000012:notes:296]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-19-000012:notes:297]
| July 27, 2019 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 808 |  |  | $ | 1 |  |  | $ | (1 | ) |  | $ | 808 |  |
| U.S. government agency securities | 169 |  |  | — |  |  | — |  |  | 169 |  |
| Corporate debt securities | 19,188 |  |  | 103 |  |  | (29 | ) |  | 19,262 |  |
| U.S. agency mortgage-backed securities | 1,425 |  |  | 7 |  |  | (11 | ) |  | 1,421 |  |
| Total | $ | 21,590 |  |  | $ | 111 |  |  | $ | (41 | ) |  | $ | 21,660 |  |

[0000858877-19-000012:notes:298]
| July 28, 2018 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 7,318 |  |  | $ | — |  |  | $ | (43 | ) |  | $ | 7,275 |  |
| U.S. government agency securities | 732 |  |  | — |  |  | (5 | ) |  | 727 |  |
| Non-U.S. government and agency securities | 209 |  |  | — |  |  | (1 | ) |  | 208 |  |
| Corporate debt securities | 27,765 |  |  | 44 |  |  | (445 | ) |  | 27,364 |  |
| U.S. agency mortgage-backed securities | 1,488 |  |  | — |  |  | (53 | ) |  | 1,435 |  |
| Total | $ | 37,512 |  |  | $ | 44 |  |  | $ | (547 | ) |  | $ | 37,009 |  |

[0000858877-19-000012:notes:299]
Net unsettled investment sales as of July 28, 2018 were $1.5 billion and were included in other current assets.

[0000858877-19-000012:notes:300]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-19-000012:notes:301]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-19-000012:notes:302]
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Gross realized gains | $ | 17 |  |  | $ | 16 |  |  | $ | 69 |  |
| Gross realized losses | (30 | ) |  | (258 | ) |  | (111 | ) |
| Total | $ | (13 | ) |  | $ | (242 | ) |  | $ | (42 | ) |

[0000858877-19-000012:notes:303]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at July 27, 2019 and July 28, 2018 (in millions):

[0000858877-19-000012:notes:304]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2019 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 204 |  |  | $ | — |  |  | $ | 488 |  |  | $ | (1 | ) |  | $ | 692 |  |  | $ | (1 | ) |
| U.S. government agency securities | — |  |  | — |  |  | 169 |  |  | — |  |  | 169 |  |  | — |  |
| Corporate debt securities | 2,362 |  |  | (4 | ) |  | 5,271 |  |  | (25 | ) |  | 7,633 |  |  | (29 | ) |
| U.S. agency mortgage-backed securities | 123 |  |  | — |  |  | 847 |  |  | (11 | ) |  | 970 |  |  | (11 | ) |
| Total | $ | 2,689 |  |  | $ | (4 | ) |  | $ | 6,775 |  |  | $ | (37 | ) |  | $ | 9,464 |  |  | $ | (41 | ) |

[0000858877-19-000012:notes:305]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 28, 2018 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 2,966 |  |  | $ | (20 | ) |  | $ | 4,303 |  |  | $ | (23 | ) |  | $ | 7,269 |  |  | $ | (43 | ) |
| U.S. government agency securities | 206 |  |  | (2 | ) |  | 521 |  |  | (3 | ) |  | 727 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 105 |  |  | (1 | ) |  | 103 |  |  | — |  |  | 208 |  |  | (1 | ) |
| Corporate debt securities | 16,990 |  |  | (344 | ) |  | 3,511 |  |  | (101 | ) |  | 20,501 |  |  | (445 | ) |
| U.S. agency mortgage-backed securities | 826 |  |  | (24 | ) |  | 581 |  |  | (29 | ) |  | 1,407 |  |  | (53 | ) |
| Total | $ | 21,093 |  |  | $ | (391 | ) |  | $ | 9,019 |  |  | $ | (156 | ) |  | $ | 30,112 |  |  | $ | (547 | ) |

[0000858877-19-000012:notes:306]
As of July 27, 2019, for available-for-sale debt investments that were in an unrealized loss position, we have determined that no other-than-temporary impairments were required to be recognized.

[0000858877-19-000012:notes:307]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-19-000012:notes:308]
| (b) | Summary of Equity Investments |

[0000858877-19-000012:notes:309]
Prior to the adoption of ASU 2016-01, Financial Instruments, we recognized impairment charges on our publicly traded equity securities of $52 million and $74 million in fiscal 2018 and 2017, respectively. These impairment charges were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary.

[0000858877-19-000012:notes:310]
| (c) | Securities Lending |

[0000858877-19-000012:notes:311]
We periodically engage in securities lending activities with certain of our available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for fiscal 2019 and 2018 was $1.1 billion and $0.3 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of July 27, 2019 and July 28, 2018, we had no outstanding securities lending transactions.

[0000858877-19-000012:notes:312]
| (d) | Variable Interest Entities |

[0000858877-19-000012:notes:313]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of July 27, 2019, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-19-000012:notes:314]
As of July 27, 2019, the carrying value of our investments in privately held companies was $1.2 billion. $656 million of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $326 million related to these privately held investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these privately held investments.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000858877-19-000012:notes:315]
The following table presents property and equipment information for geographic areas (in millions):

[0000858877-19-000012:notes:316]
|  | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Property and equipment, net: |  |  |  |  |  |
| United States | $ | 2,266 |  |  | $ | 2,487 |  |  | $ | 2,711 |  |
| International | 523 |  |  | 519 |  |  | 611 |  |
| Total | $ | 2,789 |  |  | $ | 3,006 |  |  | $ | 3,322 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000858877-19-000012:notes:317]
(x) New Accounting Updates Recently Adopted

[0000858877-19-000012:notes:318]
Revenue Recognition  In May 2014, the FASB issued Accounting Standards Codification (ASC) 606, a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP on revenue recognition and eliminated industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. We adopted ASC 606 using the modified retrospective method to those contracts that were not completed as of July 28, 2018. Refer to Opening Balance Adjustments below for the impact of adoption on our Consolidated Financial Statements.

[0000858877-19-000012:notes:319]
The table below details the timing of when revenue was typically recognized under the prior revenue standard compared to the timing of when revenue is typically recognized under ASC 606 for these major areas:

[0000858877-19-000012:notes:320]
|  |  | Prior Revenue Standard |  | ASC 606 |
| Software arrangements: |  |  |  |  |
| Perpetual software licenses |  | Upfront |  | Upfront |
| Term software licenses |  | Ratable |  | Upfront |
| Security software licenses |  | Ratable |  | Ratable |
| Enterprise license agreements (software licenses) |  | Ratable |  | Upfront |
| Software support (maintenance) |  | Ratable |  | Ratable |
| Software-as-a-service |  | Ratable |  | Ratable |
| Two-tier distribution |  | Sell-Through |  | Sell-In |

[0000858877-19-000012:notes:321]
In addition to the above revenue recognition timing impacts, ASC 606 requires incremental contract acquisition costs (such as sales commissions) for customer contracts to be capitalized and amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the assets relates.

[0000858877-19-000012:notes:322]
We have implemented new accounting policies, systems, processes, and internal controls necessary to support the requirements of ASC 606.

[0000858877-19-000012:notes:323]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The most significant impact of this accounting standard update is that it requires the remeasurement of investments not accounted for under the equity method to be recorded at fair value through the Consolidated Statement of Operations at the end of each reporting period. The application of this accounting standard update increases the variability of other income (loss), net.

[0000858877-19-000012:notes:324]
We adopted this accounting standard update beginning the first quarter of fiscal 2019. The standard was adopted using the modified retrospective method for our marketable equity securities and non-marketable equity securities measured using the NAV practical expedient. For our non-marketable equity securities measured using the measurement alternative, we applied the prospective method. Refer to Opening Balance Adjustments below for the impact of adoption on our Consolidated Balance Sheet.

[0000858877-19-000012:notes:325]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a modified retrospective basis. The ongoing impact of this standard will be facts and circumstances dependent on any transactions within its scope. Refer to Opening Balance Adjustments below for the impact of adoption on our Consolidated Balance Sheet.

[0000858877-19-000012:notes:326]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a retrospective basis. The application of this accounting standard update did not have an impact on our Consolidated Statements of Cash Flows.

[0000858877-19-000012:notes:327]
Restricted Cash in Statement of Cash Flows  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented. The application of this accounting standard update did not have a material impact on our Consolidated Statements of Cash Flows. Prior period information has been retrospectively adjusted due to the adoption of ASU 2016-18, Statement of Cash Flows, Restricted Cash at the beginning of the first quarter of fiscal 2019.

[0000858877-19-000012:notes:328]
Simplifying the Test for Goodwill Impairment  In January 2017, the FASB issued an accounting standard update that removes Step

[0000858877-19-000012:notes:329]
2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. We early adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a prospective basis. The application of this accounting standard update did not have any impact on our Consolidated Financial Statements.

[0000858877-19-000012:notes:330]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be fact dependent, but we expect that some transactions that were previously accounted for as business combinations or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.

[0000858877-19-000012:notes:331]
Opening Balance Adjustments

[0000858877-19-000012:notes:332]
The following table summarizes the cumulative effect of the changes made to the Consolidated Balance Sheet for the adoption of ASC 606, ASU 2016-01, Financial Instruments, and ASU 2016-16, Intra-Entity Transfers of Assets Other than Inventory (in millions):

[0000858877-19-000012:notes:333]
| Line Item in Consolidated Balance Sheet: |  | Balance at July 28, 2018 |  | New Revenue Recognition Standard |  | New Financial Instruments Standard |  | New Intra-Entity Transfers Standard |  | Adjusted Balance at July 29, 2018 |
| ASSETS |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 5,554 |  |  | $ | (104 | ) | (1) | $ | — |  |  | $ | — |  |  | $ | 5,450 |  |
| Inventories |  | $ | 1,846 |  |  | $ | (302 | ) | (2) | $ | — |  |  | $ | — |  |  | $ | 1,544 |  |
| Other current assets (includes capitalized contract acquisition costs) |  | $ | 2,940 |  |  | $ | 371 |  | (3), (4) | $ | — |  |  | $ | (25 | ) | (3) | $ | 3,286 |  |
| Deferred tax assets |  | $ | 3,219 |  |  | $ | (624 | ) | (3) | $ | (15 | ) | (3) | $ | 1,415 |  | (8) | $ | 3,995 |  |
| Other assets (includes capitalized contract acquisition costs) |  | $ | 1,582 |  |  | $ | 327 |  | (4) | $ | 136 |  | (7) | $ | (91 | ) | (3) | $ | 1,954 |  |
| TOTAL ASSETS |  | $ | 108,784 |  |  | $ | (332 | ) |  | $ | 121 |  |  | $ | 1,299 |  |  | $ | 109,872 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |  |  |
| Income taxes payable |  | $ | 1,004 |  |  | $ | — |  |  | $ | — |  |  | $ | 11 |  | (3) | $ | 1,015 |  |
| Deferred revenue — current |  | $ | 11,490 |  |  | $ | (1,702 | ) | (5) | $ | — |  |  | $ | — |  |  | $ | 9,788 |  |
| Other current liabilities |  | $ | 4,413 |  |  | $ | 33 |  | (6) | $ | — |  |  | $ | — |  |  | $ | 4,446 |  |
| Deferred revenue — non-current |  | $ | 8,195 |  |  | $ | (1,081 | ) | (5) | $ | — |  |  | $ | — |  |  | $ | 7,114 |  |
| Other long-term liabilities |  | $ | 1,434 |  |  | $ | 85 |  | (3) | $ | 13 |  | (3) | $ | — |  |  | $ | 1,532 |  |
| Retained earnings |  | $ | 1,233 |  |  | $ | 2,333 |  | (10) | $ | 283 |  | (10) | $ | 1,281 |  | (10) | $ | 5,130 |  |
| Accumulated other comprehensive income (loss) |  | $ | (849 | ) |  | $ | — |  |  | $ | (175 | ) | (9) | $ | 7 |  | (3) | $ | (1,017 | ) |
| TOTAL LIABILITIES AND EQUITY |  | $ | 108,784 |  |  | $ | (332 | ) |  | $ | 121 |  |  | $ | 1,299 |  |  | $ | 109,872 |  |

[0000858877-19-000012:notes:334]
(1) Primarily represents the decrease to accounts receivable related to the change in recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis

[0000858877-19-000012:notes:335]
(2) Primarily represents the reduction of inventory for the change from recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis

[0000858877-19-000012:notes:336]
(3) Includes the impacts to deferred tax assets, liabilities and other income tax balances

[0000858877-19-000012:notes:337]
(4) Primarily represents capitalized contract acquisition costs (e.g. commissions)

[0000858877-19-000012:notes:338]
(5) Primarily represents deferred revenue adjusted to retained earnings primarily due to the change in revenue recognition for certain software arrangements from ratable to upfront, recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis. Of this total $2.8 billion adjustment, $2.6 billion related to product deferred revenue, of which $1.3 billion relates to our recurring software and subscription offers, $0.6 billion relates to two-tier distribution, and the remainder relates to non-recurring software and other adjustments.

[0000858877-19-000012:notes:339]
(6) Primarily represents the reclassification of accounts receivable contra balances to other current liabilities, adjustments to rebate liabilities for the change from recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis, and reclassifications from other current liabilities for amounts that are not contract liabilities under ASC 606

[0000858877-19-000012:notes:340]
(7) Represents the adjustment due to the remeasurement of non-marketable equity investments at fair value

[0000858877-19-000012:notes:341]
(8) Primarily represents the change in net deferred tax assets related to unrecognized income tax effects of intra-entity asset transfers

[0000858877-19-000012:notes:342]
(9) Represents the reclassification of net unrealized gains from accumulated other comprehensive income (loss) to retained earnings

[0000858877-19-000012:notes:343]
(10) Retained earnings impact from the adjustments noted above

[0000858877-19-000012:notes:344]
Impact of ASC 606 Adoption

[0000858877-19-000012:notes:345]
The application of ASC 606 increased our total revenue by $1.0 billion in fiscal 2019. The application of ASC 606 did not have a material impact to either our cost of sales or our operating expenses in fiscal 2019. We recognized a $152 million benefit to our provision for income taxes relating to indirect effects from the adoption of ASC 606 in the first quarter of fiscal 2019. For additional information regarding ASC 606, see Note 3 to the Consolidated Financial Statements.

[0000858877-19-000012:notes:346]
In connection with the adoption of ASC 606, we recorded a transition adjustment to increase retained earnings by $2.3 billion. See above for the transition impact of ASC 606 by balance sheet line item. As of July 27, 2019, the balance sheet changes attributable to ASC 606 related to accounts receivable, inventories, and deferred revenue were not materially different than the impacts upon adoption. In connection with the adoption of ASC 606, we established contract assets for unbilled receivables. As of July 27, 2019, we had total contract assets of $860 million, of which $379 million was recorded in other current assets and $481 million was recorded in other assets. As of July 27, 2019, we had total capitalized contract acquisition costs of $750 million, of which $416 million was recorded in other current assets and $334 million was recorded in other assets. The adoption of ASC 606 did not have any impact on net cash provided by operating activities.

[0000858877-19-000012:notes:347]
(y) Recent Accounting Standards or Updates Not Yet Effective as of Fiscal Year End

[0000858877-19-000012:notes:348]
Leases  In February 2016, the FASB issued ASC 842, Leases, a new standard requiring lessees to recognize operating and finance lease liabilities on the balance sheet, as well as corresponding right-of-use (ROU) assets. This standard also made some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures are required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. ASC 842 requires adoption using the modified retrospective approach, with the option of applying the requirements of the standard either i) retrospectively to each prior comparative reporting period presented, or ii) retrospectively at the beginning of the period of adoption.

[0000858877-19-000012:notes:349]
We will adopt ASC 842 at the beginning of our first quarter of fiscal 2020 on a modified retrospective basis and will not restate prior comparative periods. Upon adopting ASC 842 at the beginning of fiscal 2020, as a lessee, we expect to recognize ROU lease assets and liabilities of approximately $1 billion on our Consolidated Balance Sheets. For lessor accounting, we do not expect that this new standard will have a material impact on our Consolidated Financial Statements.

[0000858877-19-000012:notes:350]
We do not expect that this new standard will have a material impact on our Consolidated Statement of Operations.

[0000858877-19-000012:notes:351]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2021 on a modified retrospective basis, and early adoption in fiscal 2020 is permitted. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-19-000012:notes:352]
Basis of Presentation

[0000858877-19-000012:notes:353]
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2019, fiscal 2018 and fiscal 2017 were each 52-week fiscal years. The Consolidated Financial Statements include the accounts of ours and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-19-000012:notes:354]
Our consolidated financial statements include our accounts and entities consolidated under the variable interest and voting methods. The noncontrolling interests attributed to these investments, if any, are presented as a separate component from our equity in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-19-000012:notes:355]
Certain reclassifications have been made to the amounts for prior years in order to conform to the current year’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000858877-19-000012:notes:356]
(h) Depreciation and Amortization   Property and equipment are stated at cost, less accumulated depreciation or amortization, whenever applicable.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-19-000012:notes:357]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,545 |  |  | $ | 4,710 |  |
| Computer equipment and related software |  | 922 |  |  | 1,085 |  |
| Production, engineering, and other equipment |  | 5,711 |  |  | 5,734 |  |
| Operating lease assets |  | 485 |  |  | 356 |  |
| Furniture and fixtures |  | 376 |  |  | 358 |  |
| Total gross property and equipment |  | 12,039 |  |  | 12,243 |  |
| Less: accumulated depreciation and amortization |  | (9,250 | ) |  | (9,237 | ) |
| Total |  | $ | 2,789 |  |  | $ | 3,006 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000858877-19-000012:notes:358]
Supplementary Financial Data (Unaudited)

[0000858877-19-000012:notes:359]
(in millions, except per-share amounts)

[0000858877-19-000012:notes:360]
| Quarters Ended | July 27, 2019 (1) |  | April 27, 2019 |  | January 26, 2019 |  | October 27, 2018 |
| Revenue | $ | 13,428 |  |  | $ | 12,958 |  |  | $ | 12,446 |  |  | $ | 13,072 |  |
| Gross margin | $ | 8,574 |  |  | $ | 8,173 |  |  | $ | 7,773 |  |  | $ | 8,146 |  |
| Operating income | $ | 3,690 |  |  | $ | 3,513 |  |  | $ | 3,211 |  |  | $ | 3,805 |  |
| Net income | $ | 2,206 |  |  | $ | 3,044 |  |  | $ | 2,822 |  |  | $ | 3,549 |  |
| Net income per share - basic | $ | 0.52 |  |  | $ | 0.70 |  |  | $ | 0.63 |  |  | $ | 0.78 |  |
| Net income per share - diluted | $ | 0.51 |  |  | $ | 0.69 |  |  | $ | 0.63 |  |  | $ | 0.77 |  |
| Cash dividends declared per common share | $ | 0.35 |  |  | $ | 0.35 |  |  | $ | 0.33 |  |  | $ | 0.33 |  |
| Cash and cash equivalents and investments | $ | 33,413 |  |  | $ | 34,643 |  |  | $ | 40,383 |  |  | $ | 42,593 |  |

[0000858877-19-000012:notes:361]
| Quarters Ended | July 28, 2018 (2) |  | April 28, 2018 |  | January 27, 2018 (3) |  | October 28, 2017 |
| Revenue | $ | 12,844 |  |  | $ | 12,463 |  |  | $ | 11,887 |  |  | $ | 12,136 |  |
| Gross margin | $ | 7,922 |  |  | $ | 7,759 |  |  | $ | 7,498 |  |  | $ | 7,427 |  |
| Operating income | $ | 3,346 |  |  | $ | 3,134 |  |  | $ | 3,073 |  |  | $ | 2,756 |  |
| Net income (loss) | $ | 3,803 |  |  | $ | 2,691 |  |  | $ | (8,778 | ) |  | $ | 2,394 |  |
| Net income (loss) per share - basic | $ | 0.81 |  |  | $ | 0.56 |  |  | $ | (1.78 | ) |  | $ | 0.48 |  |
| Net income (loss) per share - diluted | $ | 0.81 |  |  | $ | 0.56 |  |  | $ | (1.78 | ) |  | $ | 0.48 |  |
| Cash dividends declared per common share | $ | 0.33 |  |  | $ | 0.33 |  |  | $ | 0.29 |  |  | $ | 0.29 |  |
| Cash and cash equivalents and investments | $ | 46,548 |  |  | $ | 54,431 |  |  | $ | 73,683 |  |  | $ | 71,588 |  |

[0000858877-19-000012:notes:362]
(1) In the fourth quarter of fiscal 2019, we recorded an $872 million charge which was the reversal of the previously recorded benefit associated with the U.S. taxation of deemed foreign dividends recorded in fiscal 2018 as a result of a retroactive final U.S. Treasury regulation issued during the quarter.

[0000858877-19-000012:notes:363]
(2) In the fourth quarter of fiscal 2018, we recorded adjustments to the provisional amounts related to the U.S. transition tax on accumulated earnings of foreign subsidiaries and re-measurement of net deferred tax assets. These adjustments included an $863 million benefit to the U.S. transition tax provisional amount related to the U.S. taxation of deemed foreign dividends in the transition fiscal year.

[0000858877-19-000012:notes:364]
(3) In the second quarter of fiscal 2018, we recorded a provisional tax expense of $11.1 billion related to the Tax Act, comprised of $9.0 billion of U.S. transition tax, $1.2 billion of foreign withholding tax, and $0.9 billion re-measurement of net DTA.


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000858877-19-000012:notes:365]
(s) Software Development Costs   Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-19-000012:notes:366]
Restructuring and Other Charges

[0000858877-19-000012:notes:367]
We initiated a restructuring plan during fiscal 2018 (the “Fiscal 2018 Plan”) in order to realign our organization and enable further investment in key priority areas with estimated pretax charges of $600 million. In connection with the Fiscal 2018 Plan, we incurred charges of $322 million during fiscal 2019, and have incurred cumulative charges of $430 million. These aggregate pretax charges are primarily cash-based and consist of employee severance and other one-time termination benefits, and other associated costs. We expect the Fiscal 2018 Plan to be substantially completed in the first half of fiscal 2020.

[0000858877-19-000012:notes:368]
We announced a restructuring plan in August 2016 (the “Fiscal 2017 Plan”), in order to reinvest in our key priority areas. In connection with the Fiscal 2017 Plan, we incurred cumulative charges of $1.0 billion, which were primarily cash-based and consisted of employee severance and other one-time termination benefits, and other associated costs. We completed the Fiscal 2017 Plan in fiscal 2018.

[0000858877-19-000012:notes:369]
The following table summarizes the activities related to the restructuring and other charges, as discussed above (in millions):

[0000858877-19-000012:notes:370]
|  |  | FISCAL 2017 AND PRIOR YEAR PLANS |  | FISCAL 2018 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 30, 2016 |  | $ | 21 |  |  | $ | 24 |  |  | $ | — |  |  | $ | — |  |  | $ | 45 |  |
| Charges |  | 625 |  |  | 131 |  |  | — |  |  | — |  |  | 756 |  |
| Cash payments |  | (569 | ) |  | (37 | ) |  | — |  |  | — |  |  | (606 | ) |
| Non-cash items |  | (3 | ) |  | (75 | ) |  | — |  |  | — |  |  | (78 | ) |
| Liability as of July 29, 2017 |  | 74 |  |  | 43 |  |  | — |  |  | — |  |  | 117 |  |
| Charges |  | 227 |  |  | 23 |  |  | 92 |  |  | 16 |  |  | 358 |  |
| Cash payments |  | (262 | ) |  | (35 | ) |  | (73 | ) |  | (2 | ) |  | (372 | ) |
| Non-cash items |  | 2 |  |  | (18 | ) |  | — |  |  | (14 | ) |  | (30 | ) |
| Liability as of July 28, 2018 |  | 41 |  |  | 13 |  |  | 19 |  |  | — |  |  | 73 |  |
| Charges |  | — |  |  | (1 | ) |  | 252 |  |  | 71 |  |  | 322 |  |
| Cash payments |  | (41 | ) |  | (7 | ) |  | (248 | ) |  | (3 | ) |  | (299 | ) |
| Non-cash items |  | — |  |  | — |  |  | (1 | ) |  | (62 | ) |  | (63 | ) |
| Liability as of July 27, 2019 |  | $ | — |  |  | $ | 5 |  |  | $ | 22 |  |  | $ | 6 |  |  | $ | 33 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-19-000012:notes:371]
(p) Revenue Recognition   We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

[0000858877-19-000012:notes:372]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-19-000012:notes:373]
Significant Judgments

[0000858877-19-000012:notes:374]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-19-000012:notes:375]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes various rebate, cooperative marketing, potential penalties and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

[0000858877-19-000012:notes:376]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license's utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-19-000012:notes:377]
Revenue

[0000858877-19-000012:notes:378]
| (a) | Disaggregation of Revenue |

[0000858877-19-000012:notes:379]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category.

[0000858877-19-000012:notes:380]
Infrastructure Platforms consist of our core networking technologies of switching, routing, wireless, and data center products that are designed to work together to deliver networking capabilities and transport and/or store data. These technologies consist of both hardware and software offerings, including software licenses and software-as-a-service (SaaS), that help our customers build networks, automate, orchestrate, integrate, and digitize data. We are shifting and expanding more of our business to software and subscriptions across our core networking portfolio. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-19-000012:notes:381]
Applications consists of offerings that utilize the core networking and data center platforms to provide their functions. The products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-19-000012:notes:382]
Security primarily includes our network security, cloud and email security, identity and access management, advanced threat protection, and unified threat management products. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers' network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-19-000012:notes:383]
Other Products primarily include our Service Provider Video Software Solutions and cloud and system management products. On October 28, 2018, we completed the sale of the SPVSS. These products include both hardware and software licenses. Our offerings in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control.

[0000858877-19-000012:notes:384]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and advanced services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Advanced services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

[0000858877-19-000012:notes:385]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for all of our hardware, software and service offerings. Refer to Note 8 for additional information. For these arrangements, cash is typically received over time.

[0000858877-19-000012:notes:386]
| (b) | Contract Balances |

[0000858877-19-000012:notes:387]
Accounts receivable, net was $5.5 billion as of July 27, 2019 compared to $5.6 billion as of July 28, 2018.

[0000858877-19-000012:notes:388]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of July 27, 2019 and July 29, 2018, our contract assets for these unbilled receivables were $860 million and $122 million, respectively, and were included in other current assets and other assets.

[0000858877-19-000012:notes:389]
Contract liabilities consist of deferred revenue. Deferred revenue was $18.5 billion as of July 27, 2019 compared to $19.7 billion as of July 28, 2018. In connection with the adoption of ASC 606, we recorded an adjustment to retained earnings to reduce deferred revenue by $2.8 billion. We recognized approximately $9.6 billion of revenue during fiscal 2019 that was included in the deferred revenue balance at July 29, 2018.

[0000858877-19-000012:notes:390]
| (c) | Remaining Performance Obligations |

[0000858877-19-000012:notes:391]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of July 27, 2019, the aggregate amount of RPO was $25.3 billion, comprised of $18.5 billion of deferred revenue and $6.8 billion of unbilled contract revenue. We expect approximately 56% of this amount to be recognized as revenue over the next year. Unbilled contract revenue represents non-cancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

[0000858877-19-000012:notes:392]
| (d) | Capitalized Contract Acquisition Costs |

[0000858877-19-000012:notes:393]
In connection with the adoption of ASC 606, we began to capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $750 million as of July 27, 2019, and was included in other current assets and other assets. The amortization expense associated with these costs was $471 million for fiscal 2019 and was included in sales and marketing expenses.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0000858877-19-000012:notes:394]
A summary of the allocation of the total purchase consideration is presented as follows (in millions):


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0000858877-19-000012:notes:395]
|  |  | July 27, 2019 |  | July 28, 2018 |
| Cash and cash equivalents |  | $ | 11,750 |  |  | $ | 8,934 |  |
| Restricted cash included in other current assets |  | 21 |  |  | 32 |  |
| Restricted cash included in other assets |  | 1 |  |  | 27 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 11,772 |  |  | $ | 8,993 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000858877-19-000012:notes:396]
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 374 |  |  | $ | 423 |  |
| Work in process |  | 10 |  |  | — |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales and distributor inventory |  | 109 |  |  | 443 |  |
| Manufactured finished goods |  | 643 |  |  | 689 |  |
| Total finished goods |  | 752 |  |  | 1,132 |  |
| Service-related spares |  | 225 |  |  | 258 |  |
| Demonstration systems |  | 22 |  |  | 33 |  |
| Total |  | $ | 1,383 |  |  | $ | 1,846 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000858877-19-000012:notes:397]
Summarized financial information by segment for fiscal 2019, 2018, and 2017, based on our internal management system and as utilized by our Chief Operating Decision Maker (CODM), is as follows (in millions):

[0000858877-19-000012:notes:398]
| Years Ended | July 27, 2019 |  | July 28, 2018 |  | July 29, 2017 |
| Revenue: |  |  |  |  |  |
| Americas | $ | 30,927 |  |  | $ | 29,070 |  |  | $ | 28,351 |  |
| EMEA | 13,100 |  |  | 12,425 |  |  | 12,004 |  |
| APJC | 7,877 |  |  | 7,834 |  |  | 7,650 |  |
| Total | $ | 51,904 |  |  | $ | 49,330 |  |  | $ | 48,005 |  |
| Gross margin: |  |  |  |  |  |
| Americas | $ | 20,338 |  |  | $ | 18,792 |  |  | $ | 18,284 |  |
| EMEA | 8,457 |  |  | 7,945 |  |  | 7,855 |  |
| APJC | 4,683 |  |  | 4,726 |  |  | 4,741 |  |
| Segment total | 33,479 |  |  | 31,463 |  |  | 30,880 |  |
| Unallocated corporate items | (813 | ) |  | (857 | ) |  | (656 | ) |
| Total | $ | 32,666 |  |  | $ | 30,606 |  |  | $ | 30,224 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-19-000012:notes:399]
Segment Information and Major Customers

[0000858877-19-000012:notes:400]
| (a) | Revenue and Gross Margin by Segment |

[0000858877-19-000012:notes:401]
We conduct business globally and are managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-19-000012:notes:402]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-19-000012:notes:403]
Revenue in the United States was $27.4 billion, $25.5 billion, and $25.0 billion for fiscal 2019, 2018, and 2017, respectively.

[0000858877-19-000012:notes:404]
| (b) | Revenue for Groups of Similar Products and Services |

[0000858877-19-000012:notes:405]
We design, manufacture, and sell IP-based networking and other products related to the communications and IT industry and provide services associated with these products and their use.

[0000858877-19-000012:notes:406]
(1) Includes SPVSS business revenue of $168 million and $903 million for fiscal 2019 and 2018, respectively.

[0000858877-19-000012:notes:407]
| (c) | Additional Segment Information |

[0000858877-19-000012:notes:408]
The majority of our assets as of July 27, 2019 and July 28, 2018 were attributable to our U.S. operations. In fiscal 2019, 2018, and 2017, no single customer accounted for 10% or more of revenue.

[0000858877-19-000012:notes:409]
Property and equipment information is based on the physical location of the assets. The following table presents property and equipment information for geographic areas (in millions):


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-19-000012:notes:410]
Summary of Significant Accounting Policies

[0000858877-19-000012:notes:411]
(b) Available-for-Sale Debt Investments   We classify our investments in fixed income securities as available-for-sale debt investments. Our available-for-sale debt investments primarily consist of U.S. government, U.S. government agency, non-U.S. government and agency, corporate debt, and U.S. agency mortgage-backed securities. These available-for-sale debt investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of available-for-sale debt investments sold. These investments are recorded in the Consolidated Balance Sheets at fair value. Unrealized gains and losses on these investments, to the extent the investments are unhedged, are included as a separate component of accumulated other comprehensive income (AOCI), net of tax. We classify our investments as current based on the nature of the investments and their availability for use in current operations.

[0000858877-19-000012:notes:412]
(c) Equity Instruments   Our equity investments are accounted for as follows:

[0000858877-19-000012:notes:413]
| • | Marketable equity securities have readily determinable fair value (RDFV) that are measured and recorded at fair value through income. |

[0000858877-19-000012:notes:414]
| • | Non-marketable equity securities do not have RDFV and are measured using a measurement alternative recorded at cost less any impairment, plus or minus changes resulting from qualifying observable price changes. For certain of these securities, we have elected to apply the net asset value (NAV) practical expedient. The NAV is the estimated fair value of these investments. |

[0000858877-19-000012:notes:415]
| • | Equity method investments are securities we do not control, but are able to exert significant influence over the investee. These investments are measured at cost less any impairment, plus or minus our share of equity method investee income or loss. |

[0000858877-19-000012:notes:416]
(f) Allowance for Doubtful Accounts   The allowance for doubtful accounts is based on our assessment of the collectibility of customer accounts. We regularly review the allowance by considering factors such as historical experience, credit quality, age of the accounts receivable balances, economic conditions that may affect a customer’s ability to pay, and expected default frequency rates. Trade receivables are written off at the point when they are considered uncollectible.

[0000858877-19-000012:notes:417]
(g) Financing Receivables and Guarantees   We provide financing arrangements, including leases, financed service contracts, and loans, for certain qualified end-user customers to build, maintain, and upgrade their networks. Lease receivables primarily represent sales-type and direct-financing leases. Leases have on average a four-year term and are usually collateralized by a security interest in the underlying assets. Loan receivables include customers financing purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. Loan receivables have terms of three years on average. Financed service contracts typically have terms of one to three years and primarily relate to technical support services.

[0000858877-19-000012:notes:418]
We determine the adequacy of our allowance for credit loss by assessing the risks and losses inherent in our financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by us to our customers: lease receivables, loan receivables, and financed service contracts.

[0000858877-19-000012:notes:419]
We assess the allowance for credit loss related to financing receivables on either an individual or a collective basis. We consider various factors in evaluating lease and loan receivables and the earned portion of financed service contracts for possible impairment on an individual basis. These factors include our historical experience, credit quality and age of the receivable balances, and economic conditions that may affect a customer’s ability to pay. When the evaluation indicates that it is probable that all amounts due pursuant to the contractual terms of the financing agreement, including scheduled interest payments, are unable to be collected, the financing receivable is considered impaired. All such outstanding amounts, including any accrued interest, are assessed and reserved at the customer level. Our internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality financing receivables. Typically, we also consider financing receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. We evaluate the remainder of our financing receivables portfolio for impairment on a collective basis and record an allowance for credit loss at the portfolio segment level. When evaluating the financing receivables on a collective basis, we use historical default rates and expected default frequency rates published by major third-party credit-rating agencies as well as our own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk, and correlation.

[0000858877-19-000012:notes:420]
Expected default frequency rates and historical default rates are published quarterly by major third-party credit-rating agencies, and the internal credit risk rating is derived by taking into consideration various customer-specific factors and macroeconomic conditions. These factors, which include the strength of the customer’s business and financial performance, the quality of the customer’s banking relationships, our specific historical experience with the customer, the performance and outlook of the customer’s industry, the customer’s legal and regulatory environment, the potential sovereign risk of the geographic locations in which the customer is operating, and independent third-party evaluations, are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000858877-19-000012:notes:421]
Financing receivables are written off at the point when they are considered uncollectible, and all outstanding balances, including any previously earned but uncollected interest income, will be reversed and charged against the allowance for credit loss. We do not typically have any partially written-off financing receivables.

[0000858877-19-000012:notes:422]
Outstanding financing receivables that are aged 31 days or more from the contractual payment date are considered past due. We do not accrue interest on financing receivables that are considered impaired or more than 120 days past due unless either the receivable has not been collected due to administrative reasons or the receivable is well secured and in the process of collection. Financing receivables may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain. After a financing receivable has been categorized as nonaccrual, interest will be recognized when cash is received. A financing receivable may be returned to accrual status after all of the customer’s delinquent balances of principal and interest have been settled, and the customer remains current for an appropriate period.

[0000858877-19-000012:notes:423]
We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive a payment for the receivables from the third party based on our standard payment terms. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Deferred revenue relating to these financing arrangements is recorded in accordance with revenue recognition policies or for the fair value of the financing guarantees.

[0000858877-19-000012:notes:424]
(h) Depreciation and Amortization   Property and equipment are stated at cost, less accumulated depreciation or amortization, whenever applicable. Depreciation and amortization expenses for property and equipment were approximately $1.0 billion, $1.1 billion, and $1.1 billion for fiscal 2019, 2018, and 2017, respectively. Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-19-000012:notes:425]
(l) Fair Value   Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, we consider the principal or most advantageous market in which we would transact, and we also consider assumptions that market participants would use when pricing the asset or liability.

[0000858877-19-000012:notes:426]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. The standard establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement.

[0000858877-19-000012:notes:427]
The fair value hierarchy is as follows:

[0000858877-19-000012:notes:428]
Level 1 applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000858877-19-000012:notes:429]
Level 2 applies to assets or liabilities for which there are inputs other than quoted prices that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets); or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of assets or liabilities.

[0000858877-19-000012:notes:430]
Level 3 applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities. The fair values are determined based on model-based techniques such as discounted cash flow models using inputs that we could not corroborate with market data.

[0000858877-19-000012:notes:431]
For the additional disclosures required as part of ASC 606 see Note 3.

[0000858877-19-000012:notes:432]
(q) Advertising Costs   We expense all advertising costs as incurred. Advertising costs included within sales and marketing expenses were approximately $204 million, $166 million, and $209 million for fiscal 2019, 2018, and 2017, respectively.

[0000858877-19-000012:notes:433]
(v) Consolidation of Variable Interest Entities  Our approach in assessing the consolidation requirement for variable interest entities focuses on identifying which enterprise has the power to direct the activities that most significantly impact the variable interest entity’s economic performance and which enterprise has the obligation to absorb losses or the right to receive benefits from the variable interest entity. Should we conclude that we are the primary beneficiary of a variable interest entity, the assets, liabilities, and results of operations of the variable interest entity will be included in our Consolidated Financial Statements.

[0000858877-19-000012:notes:434]
(w) Use of Estimates   The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Estimates are used for the following, among others:

[0000858877-19-000012:notes:435]
| ▪ | Revenue recognition |

[0000858877-19-000012:notes:436]
| ▪ | Allowances for accounts receivable, sales returns, and financing receivables |

[0000858877-19-000012:notes:437]
| ▪ | Inventory valuation and liability for purchase commitments with contract manufacturers and suppliers |

[0000858877-19-000012:notes:438]
| ▪ | Loss contingencies and product warranties |

[0000858877-19-000012:notes:439]
| ▪ | Fair value measurements and other-than-temporary impairments |

[0000858877-19-000012:notes:440]
| ▪ | Goodwill and purchased intangible asset impairments |

[0000858877-19-000012:notes:441]
| ▪ | Income taxes |

[0000858877-19-000012:notes:442]
The actual results experienced by us may differ materially from management’s estimates.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-19-000012:notes:443]
Shareholders’ Equity

[0000858877-19-000012:notes:444]
| (a) | Cash Dividends on Shares of Common Stock |

[0000858877-19-000012:notes:445]
We declared and paid cash dividends of $1.36, $1.24 and $1.10 per common share, or $6.0 billion, $6.0 billion and $5.5 billion, on our outstanding common stock during fiscal 2019, 2018, and 2017, respectively.

[0000858877-19-000012:notes:446]
Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-19-000012:notes:447]
| (b) | Stock Repurchase Program |

[0000858877-19-000012:notes:448]
In September 2001, our Board of Directors authorized a stock repurchase program. On February 13, 2019, our Board of Directors authorized a $15 billion increase to the stock repurchase program. As of July 27, 2019, the remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $13.5 billion, with no termination date.

[0000858877-19-000012:notes:449]
There were $40 million, $180 million and $66 million in stock repurchases pending settlement as of July 27, 2019, July 28, 2018 and July 29, 2017, respectively.

[0000858877-19-000012:notes:450]
The purchase price for the shares of our stock repurchased is reflected as a reduction to shareholders’ equity.

[0000858877-19-000012:notes:451]
We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings or increase to accumulated deficit and (ii) a reduction of common stock and additional paid-in capital.

[0000858877-19-000012:notes:452]
| (c) | Preferred Stock |

[0000858877-19-000012:notes:453]
Under the terms of our Articles of Incorporation, the Board of Directors may determine the rights, preferences, and terms of our authorized but unissued shares of preferred stock.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-19-000012:notes:454]
Balance Sheet Details

[0000858877-19-000012:notes:455]
The following tables provide details of selected balance sheet items (in millions):
