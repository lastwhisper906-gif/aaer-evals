# CSCO 10-K controls and the auditor's report


## auditors_report

[0000858877-19-000012:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0000858877-19-000012:auditors_report:2]
To the Board of Directors and Shareholders of Cisco Systems, Inc.

[0000858877-19-000012:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0000858877-19-000012:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Cisco Systems, Inc. and its subsidiaries (the “Company”) as of July 27, 2019 and July 28, 2018, and the related consolidated statements of operations, comprehensive income (loss), cash flows and equity for each of the three years in the period ended July 27, 2019, including the related notes and schedule of valuation and qualifying accounts for each of the three years in the period ended July 27, 2019 appearing under Item 15(a)(2) (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of July 27, 2019, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0000858877-19-000012:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of July 27, 2019 and July 28, 2018, and the results of its operations and its cash flows for each of the three years in the period ended July 27, 2019 in conformity with accounting principles generally accepted in the United States of America.  Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of July 27, 2019, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0000858877-19-000012:auditors_report:6]
Change in Accounting Principle

[0000858877-19-000012:auditors_report:7]
As discussed in Note 2 to the consolidated financial statements, the Company changed the manner in which it accounts for revenues from contracts with customers in 2019.

[0000858877-19-000012:auditors_report:8]
Basis for Opinions

[0000858877-19-000012:auditors_report:9]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000858877-19-000012:auditors_report:10]
We conducted our audits in accordance with the standards of the PCAOB.  Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0000858877-19-000012:auditors_report:11]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0000858877-19-000012:auditors_report:12]
Definition and Limitations of Internal Control over Financial Reporting

[0000858877-19-000012:auditors_report:13]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles.  A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000858877-19-000012:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements.  Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000858877-19-000012:auditors_report:15]
55

[0000858877-19-000012:auditors_report:16]
Critical Audit Matters

[0000858877-19-000012:auditors_report:17]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0000858877-19-000012:auditors_report:18]
Revenue recognition — identification of contractual terms in certain customer arrangements

[0000858877-19-000012:auditors_report:19]
As described in Note 2 to the consolidated financial statements, management assesses relevant contractual terms in its customer arrangements to determine the transaction price and recognizes revenue upon transfer of control of the promised goods or services in an amount that reflects the consideration the Company expects to receive in exchange for those products or services. Management applies judgment in determining the transaction price which is dependent on the contractual terms. In order to determine the transaction price, management may be required to estimate variable consideration when determining the amount and timing of revenue recognition.

[0000858877-19-000012:auditors_report:20]
The principal considerations for our determination that performing procedures relating to the identification of contractual terms in customer arrangements to determine the transaction price is a critical audit matter are there was significant judgment by management in identifying contractual terms due to the volume and customized nature of the Company’s customer arrangements. This in turn led to significant effort in performing our audit procedures which were designed to evaluate whether the contractual terms used in the determination of the transaction price and the timing of revenue recognition were appropriately identified and determined by management and to evaluate the reasonableness of management’s estimates.

[0000858877-19-000012:auditors_report:21]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the revenue recognition process, including those related to the identification of contractual terms in customer arrangements that impact the determination of the transaction price and revenue recognition. These procedures also included, among others: (i) testing the completeness and accuracy of management’s identification of the contractual terms by examining customer arrangements on a test basis, and (ii) testing management’s process for determining the appropriate amount and timing of revenue recognition based on the contractual terms identified in the customer arrangements.

[0000858877-19-000012:auditors_report:22]
/s/ PricewaterhouseCoopers LLP

[0000858877-19-000012:auditors_report:23]
San Jose, California

[0000858877-19-000012:auditors_report:24]
September 5, 2019

[0000858877-19-000012:auditors_report:25]
We have served as the Company’s auditor since 1988.

[0000858877-19-000012:auditors_report:26]
56


## item_9a

[0000858877-19-000012:item_9a:1]
| Item 9A. | Controls and Procedures |

[0000858877-19-000012:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000858877-19-000012:item_9a:3]
Based on our management’s evaluation (with the participation of our principal executive officer and principal financial officer), as of the end of the period covered by this report, our principal executive officer and principal financial officer have concluded that our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended, (the “Exchange Act”)) are effective to ensure that information required to be disclosed by us in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in Securities and Exchange Commission rules and forms and is accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000858877-19-000012:item_9a:4]
Internal Control over Financial Reporting

[0000858877-19-000012:item_9a:5]
Management’s report on our internal control over financial reporting and the report of our independent registered public accounting firm on our internal control over financial reporting are set forth, respectively, on page 57 under the caption “Management’s Report on Internal Control Over Financial Reporting” and on page 55 of this report.

[0000858877-19-000012:item_9a:6]
There was no change in our internal control over financial reporting during our fourth quarter of fiscal 2019 that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.

[0000858877-19-000012:item_9a:7]
106
