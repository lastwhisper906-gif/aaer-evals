# CSCO 8-K — 0001193125-19-221195 filed 2019-08-14

## item codes, every 8-K on or before 2019-09-05

- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2019-09-05

- none on or before 2019-09-05

## item 2.02 — earnings release, exhibit 99.1

[0001193125-19-221195:8k_2_02:1]
EX-99.1
2
d779819dex991.htm
EX-99.1

[0001193125-19-221195:8k_2_02:2]
EX-99.1

[0001193125-19-221195:8k_2_02:3]
Exhibit 99.1

[0001193125-19-221195:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-19-221195:8k_2_02:5]
CISCO REPORTS FOURTH QUARTER AND FISCAL YEAR 2019 EARNINGS

[0001193125-19-221195:8k_2_02:6]
|  | • |  | Q4 Results:1 |

[0001193125-19-221195:8k_2_02:7]
|  | • |  | Revenue: $13.4 billion |

[0001193125-19-221195:8k_2_02:8]
|  | • |  | Growth of 6% year over year |

[0001193125-19-221195:8k_2_02:9]
|  | • |  | Earnings per Share: GAAP: $0.51; Non-GAAP: $0.83 |

[0001193125-19-221195:8k_2_02:10]
|  | • |  | Non-GAAP EPS increased 19% year over year |

[0001193125-19-221195:8k_2_02:11]
|  | • |  | FY 2019 Results:1 |

[0001193125-19-221195:8k_2_02:12]
|  | • |  | Revenue: $51.7 billion |

[0001193125-19-221195:8k_2_02:13]
|  | • |  | Growth of 7% year over year |

[0001193125-19-221195:8k_2_02:14]
|  | • |  | Earnings per Share: GAAP: $2.61; Non-GAAP: $3.10 |

[0001193125-19-221195:8k_2_02:15]
|  | • |  | Non-GAAP EPS increased 20% year over year |

[0001193125-19-221195:8k_2_02:16]
| • |  | Q1 Guidance:1 |

[0001193125-19-221195:8k_2_02:17]
|  | • |  | Revenue: 0% to 2% growth year over year |

[0001193125-19-221195:8k_2_02:18]
|  | • |  | Earnings per Share: GAAP: $0.64 to $0.69; Non-GAAP: $0.80 to $0.82 |

[0001193125-19-221195:8k_2_02:19]
1 Normalized to exclude the divested SPVSS business

[0001193125-19-221195:8k_2_02:20]
SAN JOSE, Calif. — August 14, 2019 — Cisco today reported fourth quarter and fiscal year results for the period ended July 27, 2019. Cisco
reported fourth quarter revenue of $13.4 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.2 billion or $0.51 per share, and non-GAAP net income of
$3.6 billion or $0.83 per share.

[0001193125-19-221195:8k_2_02:21]
As previously disclosed, Cisco completed the divestiture of the Service Provider Video Software Solutions (SPVSS)
business in the second quarter of fiscal 2019 on October 28, 2018. Revenue, non-GAAP financial information, and Q1 FY 2020 guidance have been normalized to exclude the SPVSS business from prior periods
for comparative purposes.

[0001193125-19-221195:8k_2_02:22]
“Our Q4 results marked a strong end to a great year. We are executing well in a dynamic environment, delivering tremendous
innovation across our portfolio and extending our market leadership,” said Chuck Robbins, chairman and CEO of Cisco. “We are committed to providing our customers ongoing value through differentiated solutions, and we are well positioned to
take advantage of the long-term growth opportunities ahead.”

[0001193125-19-221195:8k_2_02:23]
Q4 GAAP Results

[0001193125-19-221195:8k_2_02:24]
|  |  | Q4 FY 2019 |  |  | Q4 FY 2018 |  |  | Vs. Q4 FY 2018 |  |
| Revenue (including SPVSS business for all periods) |  | $ | 13.4 billion |  |  | $ | 12.8 billion |  |  |  | 5 | % |
| Revenue (excluding SPVSS business for all periods) |  | $ | 13.4 billion |  |  | $ | 12.6 billion |  |  |  | 6 | % |
| Net Income |  | $ | 2.2 billion |  |  | $ | 3.8 billion |  |  |  | (42 | )% |
| Diluted Earnings per Share (EPS) |  | $ | 0.51 |  |  | $ | 0.81 |  |  |  | (37 | )% |

[0001193125-19-221195:8k_2_02:25]
Q4 GAAP results for fiscal 2019 and 2018 include a $0.9 billion charge and $0.9 billion benefit, respectively,
related to the Tax Cuts and Jobs Act.

[0001193125-19-221195:8k_2_02:26]
1

[0001193125-19-221195:8k_2_02:27]
Q4 Non-GAAP Results

[0001193125-19-221195:8k_2_02:28]
|  |  | Q4 FY 2019 |  |  | Q4 FY 2018 |  |  | Vs. Q4 FY 2018 |  |
| Net Income (excluding SPVSS business for all periods) |  | $ | 3.6 billion |  |  | $ | 3.3 billion |  |  |  | 9 | % |
| EPS (excluding SPVSS business for all periods) |  | $ | 0.83 |  |  | $ | 0.70 |  |  |  | 19 | % |

[0001193125-19-221195:8k_2_02:29]
Fiscal Year GAAP Results

[0001193125-19-221195:8k_2_02:30]
|  |  | FY 2019 |  |  | FY 2018 |  |  | Vs. FY 2018 |  |
| Revenue (including SPVSS business for all periods) |  | $ | 51.9 billion |  |  | $ | 49.3 billion |  |  |  | 5 | % |
| Revenue (excluding SPVSS business for all periods) |  | $ | 51.7 billion |  |  | $ | 48.4 billion |  |  |  | 7 | % |
| Net Income |  | $ | 11.6 billion |  |  | $ | 0.1 billion |  |  |  | NM |  |
| EPS |  | $ | 2.61 |  |  | $ | 0.02 |  |  |  | NM |  |

[0001193125-19-221195:8k_2_02:31]
NM — Not meaningful

[0001193125-19-221195:8k_2_02:32]
GAAP
results for fiscal 2019 and 2018 include charges related to the Tax Cuts and Jobs Act of $0.9 billion and $10.4 billion, respectively.

[0001193125-19-221195:8k_2_02:33]
Fiscal Year Non-GAAP Results

[0001193125-19-221195:8k_2_02:34]
|  |  | FY 2019 |  |  | FY 2018 |  |  | Vs. FY 2018 |  |
| Net Income (excluding SPVSS business for all periods) |  | $ | 13.8 billion |  |  | $ | 12.7 billion |  |  |  | 9 | % |
| EPS (excluding SPVSS business for all periods) |  | $ | 3.10 |  |  | $ | 2.59 |  |  |  | 20 | % |

[0001193125-19-221195:8k_2_02:35]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-19-221195:8k_2_02:36]
“We are pleased with our solid execution and performance in Q4, delivering revenue growth of 6%, non-GAAP EPS growth of 19%, and strong margins,”
said Kelly Kramer, CFO of Cisco. “We continue to transform our business model with software subscriptions now at 70% of our software revenue. The returns on our investments in key strategic areas position Cisco for long-term growth and
shareholder value.”

[0001193125-19-221195:8k_2_02:37]
2

[0001193125-19-221195:8k_2_02:38]
Financial Summary

[0001193125-19-221195:8k_2_02:39]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-19-221195:8k_2_02:40]
All revenue, non-GAAP, and geographic financial information in the “Q4 FY 2019 Highlights” and “FY
2019 Highlights” sections are presented excluding the SPVSS business for all periods as it was divested during the second quarter, on October 28, 2018.

[0001193125-19-221195:8k_2_02:41]
Q4 FY 2019 Highlights

[0001193125-19-221195:8k_2_02:42]
Revenue —
Total revenue was $13.4 billion, up 6%, with product revenue up 7% and service revenue up 4%. Revenue by geographic segment was: Americas up 9%, EMEA up 7%, and APJC down 4%. Product revenue performance was broad based with growth in
Security, up 14%, Applications, up 11%, and Infrastructure Platforms, up 6%.

[0001193125-19-221195:8k_2_02:43]
Gross Margin — On a GAAP basis, total gross
margin, product gross margin, and service gross margin were 63.9%, 62.9%, and 66.8%, respectively, as compared with 61.7%, 60.2%, and 66.0%, respectively, in the fourth quarter of 2018.

[0001193125-19-221195:8k_2_02:44]
On a non-GAAP basis, total gross margin, product gross margin, and service gross margin were 65.5%, 64.7%, and 67.9%,
respectively, as compared with 63.2%, 61.9%, and 67.2%, respectively, in the fourth quarter of 2018.

[0001193125-19-221195:8k_2_02:45]
Total gross margins by geographic segment were:
66.8% for the Americas, 65.2% for EMEA and 60.8% for APJC.

[0001193125-19-221195:8k_2_02:46]
Operating Expenses — On a GAAP basis, operating expenses were
$4.9 billion, up 7%. Non-GAAP operating expenses were $4.4 billion, up 9%, and were 32.8% of revenue.

[0001193125-19-221195:8k_2_02:47]
Operating Income — GAAP operating income was $3.7 billion, up 10%, with GAAP operating margin of 27.5%.
Non-GAAP operating income was $4.4 billion, up 11%, with non-GAAP operating margin at 32.6%.

[0001193125-19-221195:8k_2_02:48]
Provision for Income Taxes — The GAAP tax provision rate was 40.4%, which includes a $0.9 billion charge related to the Tax Cuts and
Jobs Act. The non-GAAP tax provision rate was 18.8%.

[0001193125-19-221195:8k_2_02:49]
Net Income and EPS — On a GAAP basis, net
income was $2.2 billion and EPS was $0.51. On a non-GAAP basis, net income was $3.6 billion, an increase of 9%, and EPS was $0.83, an increase of 19%.

[0001193125-19-221195:8k_2_02:50]
Cash Flow from Operating Activities — $3.9 billion for the fourth quarter of fiscal 2019, a decrease of 4% compared with
$4.1 billion for the fourth quarter of fiscal 2018.

[0001193125-19-221195:8k_2_02:51]
FY 2019 Highlights

[0001193125-19-221195:8k_2_02:52]
Revenue — Total revenue was $51.7 billion, an increase of 7%.

[0001193125-19-221195:8k_2_02:53]
Net Income and EPS — On a GAAP basis, net income was $11.6 billion and EPS was $2.61. On a
non-GAAP basis, net income was $13.8 billion, up 9% compared to fiscal 2018, and EPS was $3.10, an increase of 20%.

[0001193125-19-221195:8k_2_02:54]
Cash Flow from Operating Activities — $15.8 billion for fiscal 2019 compared with $13.7 billion for fiscal 2018, an increase of
16%. Operating cash flow for fiscal 2019 and 2018 include payments of $0.8 billion and $1.4 billion, respectively, related to the Tax Cuts and Jobs Act. Fiscal 2019 also includes the receipt of $0.4 billion related to a litigation
settlement with Arista Networks. Operating cash flow increased 8%, normalized for these items.

[0001193125-19-221195:8k_2_02:55]
3

[0001193125-19-221195:8k_2_02:56]
Balance Sheet and Other Financial Highlights

[0001193125-19-221195:8k_2_02:57]
Cash and Cash Equivalents and Investments — $33.4 billion at the end of the fourth quarter of fiscal 2019, compared with
$34.6 billion at the end of the third quarter of fiscal 2019, and compared with $46.5 billion at the end of fiscal 2018.

[0001193125-19-221195:8k_2_02:58]
Deferred Revenue
— $18.5 billion, down 6% in total, with deferred product revenue down 18%. Deferred service revenue was up 2%.

[0001193125-19-221195:8k_2_02:59]
Remaining
Performance Obligations — $25.3 billion at the end of fiscal 2019.

[0001193125-19-221195:8k_2_02:60]
Capital Allocation — In the fourth quarter
of fiscal 2019, we returned $6.0 billion to shareholders through share buybacks and dividends. We declared and paid a cash dividend of $0.35 per common share, or $1.5 billion, and repurchased approximately 82 million shares of common
stock under our stock repurchase program at an average price of $54.99 per share for an aggregate purchase price of $4.5 billion.

[0001193125-19-221195:8k_2_02:61]
Acquisitions

[0001193125-19-221195:8k_2_02:62]
On July 9, 2019, we announced our intent to acquire Acacia Communications, Inc., a publicly-traded fabless semiconductor company that develops,
manufactures and sells high-speed coherent optical interconnect products that are designed to transform communications networks through improvements in performance, capacity and cost. The acquisition is expected to close during the second half of
fiscal 2020, subject to customary closing conditions and regulatory approvals.

[0001193125-19-221195:8k_2_02:63]
4

[0001193125-19-221195:8k_2_02:64]
Guidance for Q1 FY 2020

[0001193125-19-221195:8k_2_02:65]
Cisco expects to achieve the following results for the first quarter of fiscal 2020 (normalized to exclude the divested SPVSS business):

[0001193125-19-221195:8k_2_02:66]
| Q1 FY 2020 |  |  |
| Revenue |  | 0% to 2% growth Y/Y |
| Non-GAAP gross margin rate |  | 64% - 65% |
| Non-GAAP operating margin rate |  | 32% - 33% |
| Non-GAAP tax provision rate |  | 20% |
| Non-GAAP EPS |  | $0.80 - $0.82 |

[0001193125-19-221195:8k_2_02:67]
Revenue for the divested SPVSS business for the first quarter of fiscal 2019 was $168 million.

[0001193125-19-221195:8k_2_02:68]
Cisco estimates that GAAP EPS will be $0.64 to $0.69 in the first quarter of fiscal 2020.

[0001193125-19-221195:8k_2_02:69]
A reconciliation between the Guidance for Q1 FY 2020 on a GAAP and non-GAAP basis is provided in the table entitled
“GAAP to non-GAAP Guidance for Q1 FY 2020” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-19-221195:8k_2_02:70]
Editor’s Notes:

[0001193125-19-221195:8k_2_02:71]
|  | • |  | Q4 fiscal year 2019 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, August 14, 2019 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-19-221195:8k_2_02:72]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, August 14, 2019 to 4:00 p.m. Pacific Time, August 21, 2019 at 1-866-463-4969 (United States) or 1-203-369-1404 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-19-221195:8k_2_02:73]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, August 14, 2019. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-19-221195:8k_2_02:74]
5

[0001193125-19-221195:8k_2_02:75]
CISCO SYSTEMS, INC.

[0001193125-19-221195:8k_2_02:76]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-19-221195:8k_2_02:77]
(In millions, except per-share amounts)

[0001193125-19-221195:8k_2_02:78]
(Unaudited)

[0001193125-19-221195:8k_2_02:79]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 27,2019 |  |  | July 28,2018 |  |  | July 27,2019 |  |  | July 28,2018 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 10,120 |  |  | $ | 9,642 |  |  | $ | 39,005 |  |  | $ | 36,709 |  |
| Service |  |  | 3,308 |  |  |  | 3,202 |  |  |  | 12,899 |  |  |  | 12,621 |  |
| Total revenue |  |  | 13,428 |  |  |  | 12,844 |  |  |  | 51,904 |  |  |  | 49,330 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,757 |  |  |  | 3,833 |  |  |  | 14,863 |  |  |  | 14,427 |  |
| Service |  |  | 1,097 |  |  |  | 1,089 |  |  |  | 4,375 |  |  |  | 4,297 |  |
| Total cost of sales |  |  | 4,854 |  |  |  | 4,922 |  |  |  | 19,238 |  |  |  | 18,724 |  |
| GROSS MARGIN |  |  | 8,574 |  |  |  | 7,922 |  |  |  | 32,666 |  |  |  | 30,606 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,753 |  |  |  | 1,626 |  |  |  | 6,577 |  |  |  | 6,332 |  |
| Sales and marketing |  |  | 2,487 |  |  |  | 2,348 |  |  |  | 9,571 |  |  |  | 9,242 |  |
| General and administrative |  |  | 566 |  |  |  | 543 |  |  |  | 1,827 |  |  |  | 2,144 |  |
| Amortization of purchased intangible assets |  |  | 38 |  |  |  | 33 |  |  |  | 150 |  |  |  | 221 |  |
| Restructuring and other charges |  |  | 40 |  |  |  | 26 |  |  |  | 322 |  |  |  | 358 |  |
| Total operating expenses |  |  | 4,884 |  |  |  | 4,576 |  |  |  | 18,447 |  |  |  | 18,297 |  |
| OPERATING INCOME |  |  | 3,690 |  |  |  | 3,346 |  |  |  | 14,219 |  |  |  | 12,309 |  |
| Interest income |  |  | 305 |  |  |  | 353 |  |  |  | 1,308 |  |  |  | 1,508 |  |
| Interest expense |  |  | (204 | ) |  |  | (224 | ) |  |  | (859 | ) |  |  | (943 | ) |
| Other income (loss), net |  |  | (87 | ) |  |  | 117 |  |  |  | (97 | ) |  |  | 165 |  |
| Interest and other income (loss), net |  |  | 14 |  |  |  | 246 |  |  |  | 352 |  |  |  | 730 |  |
| INCOME BEFORE PROVISION FOR (BENEFIT FROM) INCOME TAXES |  |  | 3,704 |  |  |  | 3,592 |  |  |  | 14,571 |  |  |  | 13,039 |  |
| Provision for (benefit from) income taxes (1) |  |  | 1,498 |  |  |  | (211 | ) |  |  | 2,950 |  |  |  | 12,929 |  |
| NET INCOME |  | $ | 2,206 |  |  | $ | 3,803 |  |  | $ | 11,621 |  |  | $ | 110 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.52 |  |  | $ | 0.81 |  |  | $ | 2.63 |  |  | $ | 0.02 |  |
| Diluted |  | $ | 0.51 |  |  | $ | 0.81 |  |  | $ | 2.61 |  |  | $ | 0.02 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,269 |  |  |  | 4,672 |  |  |  | 4,419 |  |  |  | 4,837 |  |
| Diluted |  |  | 4,307 |  |  |  | 4,722 |  |  |  | 4,453 |  |  |  | 4,881 |  |

[0001193125-19-221195:8k_2_02:80]
The Consolidated Statements of Operations include the results of the SPVSS business prior to its divestiture during the second
quarter of fiscal 2019 on October 28, 2018. Accordingly, the fiscal year ended July 27, 2019 includes three months of financial results for this business.

[0001193125-19-221195:8k_2_02:81]
| (1) | For the three months ended July 27, 2019 and July 28, 2018, the provision for (benefit from) income taxes include a $0.9 billion charge and $0.9 billion benefit, respectively, related to the Tax Cuts and Jobs Act. Fiscal 2019 and 2018 include charges related to the Tax Cuts and Jobs Act of $0.9 billion and $10.4 billion, respectively. |

[0001193125-19-221195:8k_2_02:82]
6

[0001193125-19-221195:8k_2_02:83]
CISCO SYSTEMS, INC.

[0001193125-19-221195:8k_2_02:84]
REVENUE BY SEGMENT

[0001193125-19-221195:8k_2_02:85]
(In
millions, except percentages)

[0001193125-19-221195:8k_2_02:86]
|  |  | July 27, 2019 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | Amount |  |  | Y/Y % |  |  | Amount |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Including SPVSS business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 8,129 |  |  |  | 8 | % |  | $ | 30,927 |  |  |  | 6 | % |
| EMEA |  |  | 3,297 |  |  |  | 4 | % |  |  | 13,100 |  |  |  | 5 | % |
| APJC |  |  | 2,002 |  |  |  | (5 | )% |  |  | 7,877 |  |  |  | 1 | % |
| Total |  | $ | 13,428 |  |  |  | 5 | % |  | $ | 51,904 |  |  |  | 5 | % |
| Excluding SPVSS business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 8,129 |  |  |  | 9 | % |  | $ | 30,850 |  |  |  | 8 | % |
| EMEA |  |  | 3,297 |  |  |  | 7 | % |  |  | 13,034 |  |  |  | 8 | % |
| APJC |  |  | 2,002 |  |  |  | (4 | )% |  |  | 7,853 |  |  |  | 3 | % |
| Total |  | $ | 13,428 |  |  |  | 6 | % |  | $ | 51,737 |  |  |  | 7 | % |

[0001193125-19-221195:8k_2_02:87]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-221195:8k_2_02:88]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. SPVSS business revenue for the three
months ended July 28, 2018 was $206 million and for the fiscal years ended July 27, 2019 and July 28, 2018 was $168 million and $903 million, respectively.

[0001193125-19-221195:8k_2_02:89]
CISCO SYSTEMS, INC.

[0001193125-19-221195:8k_2_02:90]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-19-221195:8k_2_02:91]
(In percentages)

[0001193125-19-221195:8k_2_02:92]
|  |  | July 27, 2019 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Including SPVSS business for all periods: |  |  |  |  |  |  |  |  |
| Americas |  |  | 66.8 | % |  |  | 65.8 | % |
| EMEA |  |  | 65.2 | % |  |  | 64.6 | % |
| APJC |  |  | 60.8 | % |  |  | 59.5 | % |
| Excluding SPVSS business for all periods (1): |  |  |  |  |  |  |  |  |
| Americas |  |  | 66.8 | % |  |  | 65.9 | % |
| EMEA |  |  | 65.2 | % |  |  | 64.6 | % |
| APJC |  |  | 60.8 | % |  |  | 59.5 | % |

[0001193125-19-221195:8k_2_02:93]
| (1) | During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. |

[0001193125-19-221195:8k_2_02:94]
7

[0001193125-19-221195:8k_2_02:95]
CISCO SYSTEMS, INC.

[0001193125-19-221195:8k_2_02:96]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-19-221195:8k_2_02:97]
(In millions, except percentages)

[0001193125-19-221195:8k_2_02:98]
|  |  | July 27, 2019 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | Amount |  |  | Y/Y % |  |  | Amount |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Including SPVSS business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,876 |  |  |  | 6 | % |  | $ | 30,191 |  |  |  | 7 | % |
| Applications |  |  | 1,487 |  |  |  | 11 | % |  |  | 5,803 |  |  |  | 15 | % |
| Security |  |  | 714 |  |  |  | 14 | % |  |  | 2,730 |  |  |  | 16 | % |
| Other Products |  |  | 42 |  |  |  | (81 | )% |  |  | 281 |  |  |  | (72 | )% |
| Total Product |  |  | 10,120 |  |  |  | 5 | % |  |  | 39,005 |  |  |  | 6 | % |
| Services |  |  | 3,308 |  |  |  | 3 | % |  |  | 12,899 |  |  |  | 2 | % |
| Total |  | $ | 13,428 |  |  |  | 5 | % |  | $ | 51,904 |  |  |  | 5 | % |
| Excluding SPVSS business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,876 |  |  |  | 6 | % |  | $ | 30,191 |  |  |  | 7 | % |
| Applications |  |  | 1,487 |  |  |  | 11 | % |  |  | 5,803 |  |  |  | 15 | % |
| Security |  |  | 714 |  |  |  | 14 | % |  |  | 2,730 |  |  |  | 16 | % |
| Other Products |  |  | 42 |  |  |  | (4 | )% |  |  | 135 |  |  |  | (31 | )% |
| Total Product |  |  | 10,120 |  |  |  | 7 | % |  |  | 38,859 |  |  |  | 8 | % |
| Services |  |  | 3,308 |  |  |  | 4 | % |  |  | 12,879 |  |  |  | 3 | % |
| Total |  | $ | 13,428 |  |  |  | 6 | % |  | $ | 51,737 |  |  |  | 7 | % |

[0001193125-19-221195:8k_2_02:99]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-221195:8k_2_02:100]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. SPVSS business revenue for the three
months ended July 28, 2018 was $206 million and for the fiscal years ended July 27, 2019 and July 28, 2018 was $168 million and $903 million, respectively.

[0001193125-19-221195:8k_2_02:101]
8

[0001193125-19-221195:8k_2_02:102]
CISCO SYSTEMS, INC.

[0001193125-19-221195:8k_2_02:103]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-19-221195:8k_2_02:104]
(In millions)

[0001193125-19-221195:8k_2_02:105]
(Unaudited)

[0001193125-19-221195:8k_2_02:106]
|  |  | July 27,2019 |  |  | July 28,2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 11,750 |  |  | $ | 8,934 |  |
| Investments |  |  | 21,663 |  |  |  | 37,614 |  |
| Accounts receivable, net of allowance for doubtful accounts of $136 at July 27, 2019 and $129 at July 28, 2018 |  |  | 5,491 |  |  |  | 5,554 |  |
| Inventories |  |  | 1,383 |  |  |  | 1,846 |  |
| Financing receivables, net |  |  | 5,095 |  |  |  | 4,949 |  |
| Other current assets |  |  | 2,373 |  |  |  | 2,940 |  |
| Total current assets |  |  | 47,755 |  |  |  | 61,837 |  |
| Property and equipment, net |  |  | 2,789 |  |  |  | 3,006 |  |
| Financing receivables, net |  |  | 4,958 |  |  |  | 4,882 |  |
| Goodwill |  |  | 33,529 |  |  |  | 31,706 |  |
| Purchased intangible assets, net |  |  | 2,201 |  |  |  | 2,552 |  |
| Deferred tax assets |  |  | 4,065 |  |  |  | 3,219 |  |
| Other assets |  |  | 2,496 |  |  |  | 1,582 |  |
| TOTAL ASSETS |  | $ | 97,793 |  |  | $ | 108,784 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 10,191 |  |  | $ | 5,238 |  |
| Accounts payable |  |  | 2,059 |  |  |  | 1,904 |  |
| Income taxes payable |  |  | 1,149 |  |  |  | 1,004 |  |
| Accrued compensation |  |  | 3,221 |  |  |  | 2,986 |  |
| Deferred revenue |  |  | 10,668 |  |  |  | 11,490 |  |
| Other current liabilities |  |  | 4,424 |  |  |  | 4,413 |  |
| Total current liabilities |  |  | 31,712 |  |  |  | 27,035 |  |
| Long-term debt |  |  | 14,475 |  |  |  | 20,331 |  |
| Income taxes payable |  |  | 8,927 |  |  |  | 8,585 |  |
| Deferred revenue |  |  | 7,799 |  |  |  | 8,195 |  |
| Other long-term liabilities |  |  | 1,309 |  |  |  | 1,434 |  |
| Total liabilities |  |  | 64,222 |  |  |  | 65,580 |  |
| Total equity |  |  | 33,571 |  |  |  | 43,204 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 97,793 |  |  | $ | 108,784 |  |

[0001193125-19-221195:8k_2_02:107]
9

[0001193125-19-221195:8k_2_02:108]
CISCO SYSTEMS, INC.

[0001193125-19-221195:8k_2_02:109]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-19-221195:8k_2_02:110]
(In millions)

[0001193125-19-221195:8k_2_02:111]
(Unaudited)

[0001193125-19-221195:8k_2_02:112]
|  |  | Fiscal Year Ended |  |
|  |  | July 27,2019 |  |  | July 28,2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 11,621 |  |  | $ | 110 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,897 |  |  |  | 2,192 |  |
| Share-based compensation expense |  |  | 1,570 |  |  |  | 1,576 |  |
| Provision (benefit) for receivables |  |  | 40 |  |  |  | (134 | ) |
| Deferred income taxes |  |  | (350 | ) |  |  | 900 |  |
| (Gains) losses on divestitures, investments and other, net |  |  | (24 | ) |  |  | (322 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (84 | ) |  |  | (269 | ) |
| Inventories |  |  | 131 |  |  |  | (244 | ) |
| Financing receivables |  |  | (249 | ) |  |  | (219 | ) |
| Other assets |  |  | (955 | ) |  |  | 66 |  |
| Accounts payable |  |  | 87 |  |  |  | 504 |  |
| Income taxes, net |  |  | 312 |  |  |  | 8,118 |  |
| Accrued compensation |  |  | 277 |  |  |  | 100 |  |
| Deferred revenue |  |  | 1,407 |  |  |  | 1,205 |  |
| Other liabilities |  |  | 151 |  |  |  | 83 |  |
| Net cash provided by operating activities |  |  | 15,831 |  |  |  | 13,666 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (2,416 | ) |  |  | (14,285 | ) |
| Proceeds from sales of investments |  |  | 7,388 |  |  |  | 17,706 |  |
| Proceeds from maturities of investments |  |  | 12,928 |  |  |  | 15,769 |  |
| Acquisitions and divestitures |  |  | (2,175 | ) |  |  | (2,979 | ) |
| Purchases of investments in privately held companies |  |  | (148 | ) |  |  | (267 | ) |
| Return of investments in privately held companies |  |  | 159 |  |  |  | 168 |  |
| Acquisition of property and equipment |  |  | (909 | ) |  |  | (834 | ) |
| Proceeds from sales of property and equipment |  |  | 22 |  |  |  | 59 |  |
| Other |  |  | (12 | ) |  |  | (19 | ) |
| Net cash provided by investing activities |  |  | 14,837 |  |  |  | 15,318 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 640 |  |  |  | 623 |  |
| Repurchases of common stock—repurchase program |  |  | (20,717 | ) |  |  | (17,547 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (862 | ) |  |  | (703 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | 3,446 |  |  |  | (2,502 | ) |
| Issuances of debt |  |  | 2,250 |  |  |  | 6,877 |  |
| Repayments of debt |  |  | (6,780 | ) |  |  | (12,375 | ) |
| Dividends paid |  |  | (5,979 | ) |  |  | (5,968 | ) |
| Other |  |  | 113 |  |  |  | (169 | ) |
| Net cash used in financing activities |  |  | (27,889 | ) |  |  | (31,764 | ) |
| Net increase (decrease) in cash, cash equivalents, and restricted cash |  |  | 2,779 |  |  |  | (2,780 | ) |
| Cash, cash equivalents, and restricted cash, beginning of fiscal year |  |  | 8,993 |  |  |  | 11,773 |  |
| Cash, cash equivalents, and restricted cash, end of fiscal year |  | $ | 11,772 |  |  | $ | 8,993 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 839 |  |  | $ | 910 |  |
| Cash paid for income taxes, net |  | $ | 2,986 |  |  | $ | 3,911 |  |

[0001193125-19-221195:8k_2_02:113]
Prior period information has been retrospectively adjusted due to the adoption of ASU
2016-18, Statement of Cash Flows, Restricted Cash at the beginning of the first quarter of fiscal 2019.

[0001193125-19-221195:8k_2_02:114]
10

[0001193125-19-221195:8k_2_02:115]
CISCO SYSTEMS, INC.

[0001193125-19-221195:8k_2_02:116]
DEFERRED REVENUE

[0001193125-19-221195:8k_2_02:117]
(In
millions)

[0001193125-19-221195:8k_2_02:118]
|  |  | July 27,2019 |  |  | April 27,2019 |  |  | July 28,2018 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 11,709 |  |  | $ | 11,297 |  |  | $ | 11,431 |  |
| Product |  |  | 6,758 |  |  |  | 6,159 |  |  |  | 8,254 |  |
| Total |  | $ | 18,467 |  |  | $ | 17,456 |  |  | $ | 19,685 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 10,668 |  |  | $ | 10,117 |  |  | $ | 11,490 |  |
| Noncurrent |  |  | 7,799 |  |  |  | 7,339 |  |  |  | 8,195 |  |
| Total |  | $ | 18,467 |  |  | $ | 17,456 |  |  | $ | 19,685 |  |

[0001193125-19-221195:8k_2_02:119]
CISCO SYSTEMS, INC.

[0001193125-19-221195:8k_2_02:120]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-19-221195:8k_2_02:121]
(In millions, except per-share amounts)

[0001193125-19-221195:8k_2_02:122]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 27, 2019 |  | $ | 0.35 |  |  | $ | 1,490 |  |  |  | 82 |  |  | $ | 54.99 |  |  | $ | 4,515 |  |  | $ | 6,005 |  |
| April 27, 2019 |  | $ | 0.35 |  |  | $ | 1,519 |  |  |  | 116 |  |  | $ | 52.14 |  |  | $ | 6,020 |  |  | $ | 7,539 |  |
| January 26, 2019 |  | $ | 0.33 |  |  | $ | 1,470 |  |  |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |  | $ | 6,486 |  |
| October 27, 2018 |  | $ | 0.33 |  |  | $ | 1,500 |  |  |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |  | $ | 6,526 |  |
| Fiscal 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 28, 2018 |  | $ | 0.33 |  |  | $ | 1,535 |  |  |  | 138 |  |  | $ | 43.58 |  |  | $ | 6,015 |  |  | $ | 7,550 |  |
| April 28, 2018 |  | $ | 0.33 |  |  | $ | 1,572 |  |  |  | 140 |  |  | $ | 42.83 |  |  | $ | 6,015 |  |  | $ | 7,587 |  |
| January 27, 2018 |  | $ | 0.29 |  |  | $ | 1,425 |  |  |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |  | $ | 5,436 |  |
| October 28, 2017 |  | $ | 0.29 |  |  | $ | 1,436 |  |  |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |  | $ | 3,056 |  |

[0001193125-19-221195:8k_2_02:123]
11

[0001193125-19-221195:8k_2_02:124]
CISCO SYSTEMS, INC.

[0001193125-19-221195:8k_2_02:125]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-19-221195:8k_2_02:126]
GAAP TO NON-GAAP NET INCOME

[0001193125-19-221195:8k_2_02:127]
(In millions, except per-share amounts)

[0001193125-19-221195:8k_2_02:128]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 27,2019 |  |  | July 28,2018 |  |  | July 27,2019 |  |  | July 28,2018 |  |
| GAAP net income |  | $ | 2,206 |  |  | $ | 3,803 |  |  | $ | 11,621 |  |  | $ | 110 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 57 |  |  |  | 59 |  |  |  | 220 |  |  |  | 227 |  |
| Amortization of acquisition-related intangible assets |  |  | 144 |  |  |  | 134 |  |  |  | 562 |  |  |  | 578 |  |
| Supplier component remediation charge (adjustment), net |  |  | 17 |  |  |  | (36 | ) |  |  | 16 |  |  |  | (77 | ) |
| Acquisition-related/divestiture costs |  |  | 1 |  |  |  | 3 |  |  |  | 10 |  |  |  | 7 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | 122 |  |
| Total adjustments to GAAP cost of sales |  |  | 219 |  |  |  | 160 |  |  |  | 813 |  |  |  | 857 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 335 |  |  |  | 329 |  |  |  | 1,309 |  |  |  | 1,339 |  |
| Amortization of acquisition-related intangible assets |  |  | 38 |  |  |  | 33 |  |  |  | 150 |  |  |  | 221 |  |
| Acquisition-related/divestiture costs |  |  | 61 |  |  |  | 79 |  |  |  | 299 |  |  |  | 274 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | (396 | ) |  |  | — |  |
| Significant asset impairments and restructurings |  |  | 40 |  |  |  | 26 |  |  |  | 322 |  |  |  | 358 |  |
| Total adjustments to GAAP operating expenses |  |  | 474 |  |  |  | 467 |  |  |  | 1,684 |  |  |  | 2,192 |  |
| Adjustments to GAAP interest and other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | 20 |  |  |  | — |  |  |  | (57 | ) |  |  | — |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 713 |  |  |  | 627 |  |  |  | 2,440 |  |  |  | 3,049 |  |
| Income tax effect of non-GAAP adjustments |  |  | (168 | ) |  |  | (253 | ) |  |  | (722 | ) |  |  | (866 | ) |
| Significant tax matters (1) |  |  | 835 |  |  |  | (851 | ) |  |  | 448 |  |  |  | 10,410 |  |
| Total adjustments to GAAP provision for income taxes |  |  | 667 |  |  |  | (1,104 | ) |  |  | (274 | ) |  |  | 9,544 |  |
| Non-GAAP net income |  | $ | 3,586 |  |  | $ | 3,326 |  |  | $ | 13,787 |  |  | $ | 12,703 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.51 |  |  | $ | 0.81 |  |  | $ | 2.61 |  |  | $ | 0.02 |  |
| Non-GAAP (2) |  | $ | 0.83 |  |  | $ | 0.70 |  |  | $ | 3.10 |  |  | $ | 2.60 |  |

[0001193125-19-221195:8k_2_02:129]
| (1) | The three months ended July 27, 2019 and July 28, 2018 includes a $0.9 billion charge and $0.9 billion benefit, respectively, related to the Tax Cuts and Jobs Act. Fiscal 2019 and 2018 include charges related to the Tax Cuts and Jobs Act of $0.9 billion and $10.4 billion, respectively. |

[0001193125-19-221195:8k_2_02:130]
| (2) | Fiscal 2018 Non-GAAP EPS excluding the SPVSS business was $2.59. |

[0001193125-19-221195:8k_2_02:131]
12

[0001193125-19-221195:8k_2_02:132]
CISCO SYSTEMS, INC.

[0001193125-19-221195:8k_2_02:133]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-19-221195:8k_2_02:134]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-19-221195:8k_2_02:135]
(In millions, except percentages)

[0001193125-19-221195:8k_2_02:136]
|  |  | Three Months Ended |  |
|  |  | July 27, 2019 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 6,363 |  |  | $ | 2,211 |  |  | $ | 8,574 |  |  | $ | 4,884 |  |  |  | 7 | % |  | $ | 3,690 |  |  |  | 10 | % |  | $ | 14 |  |  |  | (94 | )% |  | $ | 2,206 |  |  |  | (42 | )% |
| % of revenue |  |  | 62.9 | % |  |  | 66.8 | % |  |  | 63.9 | % |  |  | 36.4 | % |  |  |  |  |  |  | 27.5 | % |  |  |  |  |  |  | 0.1 | % |  |  |  |  |  |  | 16.4 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 23 |  |  |  | 34 |  |  |  | 57 |  |  |  | 335 |  |  |  |  |  |  |  | 392 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 392 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 144 |  |  |  | — |  |  |  | 144 |  |  |  | 38 |  |  |  |  |  |  |  | 182 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 182 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | 17 |  |  |  | — |  |  |  | 17 |  |  |  | — |  |  |  |  |  |  |  | 17 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 17 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 61 |  |  |  |  |  |  |  | 62 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 62 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 40 |  |  |  |  |  |  |  | 40 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 40 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 20 |  |  |  |  |  |  |  | 20 |  |  |  |  |  |
| Income tax effect/significant tax matters (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 667 |  |  |  |  |  |
| Non-GAAP amount |  | $ | 6,547 |  |  | $ | 2,246 |  |  | $ | 8,793 |  |  | $ | 4,410 |  |  |  | 9 | % |  | $ | 4,383 |  |  |  | 11 | % |  | $ | 34 |  |  |  | (86 | )% |  | $ | 3,586 |  |  |  | 9 | % |
| % of revenue |  |  | 64.7 | % |  |  | 67.9 | % |  |  | 65.5 | % |  |  | 32.8 | % |  |  |  |  |  |  | 32.6 | % |  |  |  |  |  |  | 0.3 | % |  |  |  |  |  |  | 26.7 | % |  |  |  |  |

[0001193125-19-221195:8k_2_02:137]
| (1) | Includes a $0.9 billion charge related to the Tax Cuts and Jobs Act. |

[0001193125-19-221195:8k_2_02:138]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-221195:8k_2_02:139]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. Accordingly, the non-GAAP growth rates are normalized to exclude the SPVSS business for the fourth quarter of fiscal 2018.

[0001193125-19-221195:8k_2_02:140]
|  |  | Three Months Ended |  |
|  |  | July 28, 2018 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | NetIncome |  |
| GAAP amount |  | $ | 5,809 |  |  | $ | 2,113 |  |  | $ | 7,922 |  |  | $ | 4,576 |  |  | $ | 3,346 |  |  | $ | 3,803 |  |
| % of revenue |  |  | 60.2 | % |  |  | 66.0 | % |  |  | 61.7 | % |  |  | 35.6 | % |  |  | 26.1 | % |  |  | 29.6 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 24 |  |  |  | 35 |  |  |  | 59 |  |  |  | 329 |  |  |  | 388 |  |  |  | 388 |  |
| Amortization of acquisition-related intangible assets |  |  | 134 |  |  |  | — |  |  |  | 134 |  |  |  | 33 |  |  |  | 167 |  |  |  | 167 |  |
| Supplier component remediation charge (adjustment), net |  |  | (36 | ) |  |  | — |  |  |  | (36 | ) |  |  | — |  |  |  | (36 | ) |  |  | (36 | ) |
| Acquisition/divestiture-related costs |  |  | 2 |  |  |  | 1 |  |  |  | 3 |  |  |  | 79 |  |  |  | 82 |  |  |  | 82 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 26 |  |  |  | 26 |  |  |  | 26 |  |
| Income tax effect/significant tax matters (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,104 | ) |
| Non-GAAP amount |  | $ | 5,933 |  |  | $ | 2,149 |  |  | $ | 8,082 |  |  | $ | 4,109 |  |  | $ | 3,973 |  |  | $ | 3,326 |  |
| Less: SPVSS business (2) |  |  | (76 | ) |  |  | (13 | ) |  |  | (89 | ) |  |  | (59 | ) |  |  | (30 | ) |  |  | (24 | ) |
| Non-GAAP amount (excluding SPVSS business) |  | $ | 5,857 |  |  | $ | 2,136 |  |  | $ | 7,993 |  |  | $ | 4,050 |  |  | $ | 3,943 |  |  | $ | 3,302 |  |
| % of revenue |  |  | 61.9 | % |  |  | 67.2 | % |  |  | 63.2 | % |  |  | 32.0 | % |  |  | 31.2 | % |  |  | 26.1 | % |

[0001193125-19-221195:8k_2_02:141]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-221195:8k_2_02:142]
| (1) | Includes a $0.9 billion benefit as related to the Tax Cuts and Jobs Act. |

[0001193125-19-221195:8k_2_02:143]
| (2) | Reflects three months of operations for the SPVSS business. |

[0001193125-19-221195:8k_2_02:144]
14

[0001193125-19-221195:8k_2_02:145]
CISCO SYSTEMS, INC.

[0001193125-19-221195:8k_2_02:146]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-19-221195:8k_2_02:147]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-19-221195:8k_2_02:148]
(In millions, except percentages)

[0001193125-19-221195:8k_2_02:149]
|  |  | Fiscal Year Ended |  |
|  |  | July 27, 2019 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestand otherincome(loss),net |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 24,142 |  |  | $ | 8,524 |  |  | $ | 32,666 |  |  | $ | 18,447 |  |  |  | 1 | % |  | $ | 14,219 |  |  |  | 16 | % |  | $ | 352 |  |  |  | (52 | )% |  | $ | 11,621 |  |  |  | NM |  |
| % of revenue |  |  | 61.9 | % |  |  | 66.1 | % |  |  | 62.9 | % |  |  | 35.5 | % |  |  |  |  |  |  | 27.4 | % |  |  |  |  |  |  | 0.7 | % |  |  |  |  |  |  | 22.4 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 90 |  |  |  | 130 |  |  |  | 220 |  |  |  | 1,309 |  |  |  |  |  |  |  | 1,529 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 1,529 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 562 |  |  |  | — |  |  |  | 562 |  |  |  | 150 |  |  |  |  |  |  |  | 712 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 712 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | 16 |  |  |  | — |  |  |  | 16 |  |  |  | — |  |  |  |  |  |  |  | 16 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 16 |  |  |  |  |  |
| Legal and indemnification settlements |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | (396 | ) |  |  |  |  |  |  | (391 | ) |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (391 | ) |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 4 |  |  |  | 6 |  |  |  | 10 |  |  |  | 299 |  |  |  |  |  |  |  | 309 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 309 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 322 |  |  |  |  |  |  |  | 322 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 322 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (57 | ) |  |  |  |  |  |  | (57 | ) |  |  |  |  |
| Income tax effect/significant tax matters (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (274 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 24,819 |  |  | $ | 8,660 |  |  | $ | 33,479 |  |  | $ | 16,763 |  |  |  |  |  |  | $ | 16,716 |  |  |  |  |  |  | $ | 295 |  |  |  |  |  |  | $ | 13,787 |  |  |  |  |  |
| % of revenue |  |  | 63.6 | % |  |  | 67.1 | % |  |  | 64.5 | % |  |  | 32.3 | % |  |  |  |  |  |  | 32.2 | % |  |  |  |  |  |  | 0.6 | % |  |  |  |  |  |  | 26.6 | % |  |  |  |  |
| Less: SPVSS business (2) |  |  | (51 | ) |  |  | (9 | ) |  |  | (61 | ) |  |  | (60 | ) |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Non-GAAP amount (excluding SPVSS business) |  | $ | 24,768 |  |  | $ | 8,651 |  |  | $ | 33,418 |  |  | $ | 16,703 |  |  |  | 5 | % |  | $ | 16,716 |  |  |  | 9 | % |  | $ | 295 |  |  |  | (60 | )% |  | $ | 13,787 |  |  |  | 9 | % |
| % of revenue |  |  | 63.7 | % |  |  | 67.2 | % |  |  | 64.6 | % |  |  | 32.3 | % |  |  |  |  |  |  | 32.3 | % |  |  |  |  |  |  | 0.6 | % |  |  |  |  |  |  | 26.6 | % |  |  |  |  |

[0001193125-19-221195:8k_2_02:150]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-221195:8k_2_02:151]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. Accordingly, the non-GAAP growth rates are normalized to exclude the SPVSS business for fiscal 2018.

[0001193125-19-221195:8k_2_02:152]
| (1) | Includes a $0.9 billion charge related to the Tax Cuts and Jobs Act. |

[0001193125-19-221195:8k_2_02:153]
| (2) | Reflects three months of operations for the SPVSS business. |

[0001193125-19-221195:8k_2_02:154]
15

[0001193125-19-221195:8k_2_02:155]
|  |  | Fiscal Year Ended |  |
|  |  | July 28, 2018 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | NetIncome |  |
| GAAP amount |  | $ | 22,282 |  |  | $ | 8,324 |  |  | $ | 30,606 |  |  | $ | 18,297 |  |  | $ | 12,309 |  |  | $ | 110 |  |
| % of revenue |  |  | 60.7 | % |  |  | 66.0 | % |  |  | 62.0 | % |  |  | 37.1 | % |  |  | 25.0 | % |  |  | 0.2 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 94 |  |  |  | 133 |  |  |  | 227 |  |  |  | 1,339 |  |  |  | 1,566 |  |  |  | 1,566 |  |
| Amortization of acquisition-related intangible assets |  |  | 578 |  |  |  | — |  |  |  | 578 |  |  |  | 221 |  |  |  | 799 |  |  |  | 799 |  |
| Supplier component remediation charge (adjustment), net |  |  | (77 | ) |  |  | — |  |  |  | (77 | ) |  |  | — |  |  |  | (77 | ) |  |  | (77 | ) |
| Legal and indemnification settlements |  |  | 122 |  |  |  | — |  |  |  | 122 |  |  |  | — |  |  |  | 122 |  |  |  | 122 |  |
| Acquisition/divestiture-related costs |  |  | 3 |  |  |  | 4 |  |  |  | 7 |  |  |  | 274 |  |  |  | 281 |  |  |  | 281 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 358 |  |  |  | 358 |  |  |  | 358 |  |
| Income tax effect/significant tax matters (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 9,544 |  |
| Non-GAAP amount |  | $ | 23,002 |  |  | $ | 8,461 |  |  | $ | 31,463 |  |  | $ | 16,105 |  |  | $ | 15,358 |  |  | $ | 12,703 |  |
| Less: SPVSS business (2) |  |  | (276 | ) |  |  | (41 | ) |  |  | (316 | ) |  |  | (250 | ) |  |  | (66 | ) |  |  | (53 | ) |
| Non-GAAP amount (excluding SPVSS business) |  | $ | 22,726 |  |  | $ | 8,420 |  |  | $ | 31,147 |  |  | $ | 15,855 |  |  | $ | 15,292 |  |  | $ | 12,650 |  |
| % of revenue |  |  | 63.3 | % |  |  | 67.3 | % |  |  | 64.3 | % |  |  | 32.7 | % |  |  | 31.6 | % |  |  | 26.1 | % |

[0001193125-19-221195:8k_2_02:156]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-221195:8k_2_02:157]
| (1) | Includes a $10.4 billion charge as related to the enactment of the Tax Cuts and Jobs Act. |

[0001193125-19-221195:8k_2_02:158]
| (2) | Reflects twelve months of operations for the SPVSS business. |

[0001193125-19-221195:8k_2_02:159]
16

[0001193125-19-221195:8k_2_02:160]
CISCO SYSTEMS, INC.

[0001193125-19-221195:8k_2_02:161]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-19-221195:8k_2_02:162]
EFFECTIVE TAX RATE

[0001193125-19-221195:8k_2_02:163]
(In
percentages)

[0001193125-19-221195:8k_2_02:164]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 27, 2019 |  |  | July 28, 2018 |  |  | July 27, 2019 |  |  | July 28, 2018 |  |
| GAAP effective tax rate (1) |  |  | 40.4 | % |  |  | (5.9 | )% |  |  | 20.2 | % |  |  | 99.2 | % |
| Total adjustments to GAAP provision for income taxes |  |  | (21.6 | )% |  |  | 27.1 | % |  |  | (1.2 | )% |  |  | (78.2 | )% |
| Non-GAAP effective tax rate |  |  | 18.8 | % |  |  | 21.2 | % |  |  | 19.0 | % |  |  | 21.0 | % |

[0001193125-19-221195:8k_2_02:165]
| (1) | The three months ended July 27, 2019 and July 28, 2018 includes a $0.9 billion charge and $0.9 billion benefit, respectively, related to the Tax Cuts and Jobs Act. Fiscal 2019 and 2018 include charges related to the Tax Cuts and Jobs Act of $0.9 billion and $10.4 billion, respectively. |

[0001193125-19-221195:8k_2_02:166]
GAAP TO NON-GAAP GUIDANCE FOR Q1 FY 2020

[0001193125-19-221195:8k_2_02:167]
| Q1 FY 2020 |  | Gross MarginRate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (1) |
| GAAP |  | 62.5% - 63.5% |  | 25.5% - 26.5% |  | 18% |  | $0.64 - $0.69 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.0% |  | — |  | $0.05 - $0.06 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 1.0% |  | 2.0% |  | — |  | $0.05 - $0.06 |
| Significant asset impairments and restructurings |  | — |  | 1.5% |  | — |  | $0.03 - $0.04 |
| Income tax effect of non-GAAP adjustments |  |  |  |  |  | 2% |  |  |
| Non-GAAP |  | 64% - 65% |  | 32% - 33% |  | 20% |  | $0.80 - $0.82 |

[0001193125-19-221195:8k_2_02:168]
| (1) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-19-221195:8k_2_02:169]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and significant
tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-19-221195:8k_2_02:170]
17

[0001193125-19-221195:8k_2_02:171]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-19-221195:8k_2_02:172]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating
income and margin, non-GAAP effective tax rates, non-GAAP interest and other income (loss), net, and non-GAAP net income per
share data for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-19-221195:8k_2_02:173]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with
generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any
comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as
determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-19-221195:8k_2_02:174]
Cisco believes that the presentation of non-GAAP measures, when shown in conjunction with the corresponding GAAP
measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-19-221195:8k_2_02:175]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other contingencies, gains and losses on

[0001193125-19-221195:8k_2_02:176]
18

[0001193125-19-221195:8k_2_02:177]
equity investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures,
in addition to the corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial
measures. From time to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or
more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-19-221195:8k_2_02:178]
Cisco divested its Service Provider Video Software Solutions business (SPVSS) during the second quarter of fiscal 2019 on October 28, 2018. This release
includes, where indicated, financial measures that exclude the SPVSS business. Cisco believes that the presentation of these measures provides useful information to investors and management regarding financial and business trends relating to its
financial condition and its historical and projected results of operations because the SPVSS business will not be part of Cisco on a go forward basis. Cisco’s management also uses the financial measures excluding the SPVSS business in reviewing
the financial results of Cisco.

[0001193125-19-221195:8k_2_02:179]
About Cisco

[0001193125-19-221195:8k_2_02:180]
Cisco
(Nasdaq: CSCO) is the worldwide technology leader that has been making the Internet work since 1984. Our people, products and partners help society securely connect and seize tomorrow’s digital opportunity today. Discover more at
newsroom.cisco.com and follow us on Twitter at @Cisco.

[0001193125-19-221195:8k_2_02:181]
Copyright © 2019 Cisco and/or its
affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party
trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-19-221195:8k_2_02:182]
RSS Feed for Cisco: https://newsroom.cisco.com/rss-feeds

[0001193125-19-221195:8k_2_02:183]
19
