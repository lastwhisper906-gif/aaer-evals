# CSCO note change history — 0000858877-15-000051 → 0000858877-15-000073


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-11-19):
[0000858877-15-000073:note_history:1]
The Company leases office space in many U.S. locations.  Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland, and the United Kingdom.  The Company also leases equipment and vehicles.  Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of October 24, 2015 are as follows (in millions):
  (was, 2015-05-20, similarity 0.9716):
[0000858877-15-000051:note_history:1]
The Company leases office space in many U.S. locations.  Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Norway, and the United Kingdom.  The Company also leases equipment and vehicles.  Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 25, 2015 are as follows (in millions):

- changed (2015-11-19):
[0000858877-15-000073:note_history:2]
| Fiscal Year | Amount |
| 2016 (remaining nine months) | $ | 266 |  |
| 2017 | 263 |  |
| 2018 | 189 |  |
| 2019 | 105 |  |
| 2020 | 83 |  |
| Thereafter | 189 |  |
| Total | $ | 1,095 |  |
  (was, 2015-05-20, similarity 0.9772):
[0000858877-15-000051:note_history:2]
| Fiscal Year | Amount |
| 2015 (remaining three months) | $ | 97 |  |
| 2016 | 304 |  |
| 2017 | 210 |  |
| 2018 | 153 |  |
| 2019 | 85 |  |
| Thereafter | 228 |  |
| Total | $ | 1,077 |  |

- changed (2015-11-19):
[0000858877-15-000073:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products.  During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments.  In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of October 24, 2015 and July 25, 2015, the Company had total purchase commitments for inventory of $4,028 million and $4,078 million, respectively.
  (was, 2015-05-20, similarity 0.9869):
[0000858877-15-000051:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products.  During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that allow them to either procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments.  In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of April 25, 2015 and July 26, 2014, the Company had total purchase commitments for inventory of $4,495 million and $4,169 million, respectively.

- changed (2015-11-19):
[0000858877-15-000073:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory.  As of October 24, 2015 and July 25, 2015, the liability for these purchase commitments was $178 million and $156 million, respectively, and was included in other current liabilities.
  (was, 2015-05-20, similarity 0.9848):
[0000858877-15-000051:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory.  As of April 25, 2015 and July 26, 2014, the liability for these purchase commitments was $153 million and $162 million, respectively, and was included in other current liabilities.

- added (2015-11-19):
[0000858877-15-000073:note_history:5]
In connection with the Company’s acquisitions, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

- changed (2015-11-19):
[0000858877-15-000073:note_history:6]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Compensation expense related to acquisitions | $ | 73 |  |  | $ | 98 |  |
  (was, 2015-05-20, similarity 0.7134):
[0000858877-15-000051:note_history:6]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Compensation expense related to acquisitions | $ | 72 |  |  | $ | 95 |  |  | $ | 264 |  |  | $ | 505 |  |

- changed (2015-11-19):
[0000858877-15-000073:note_history:7]
As of October 24, 2015, the Company estimated that future cash compensation expense of up to $253 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.
  (was, 2015-05-20, similarity 0.964):
[0000858877-15-000051:note_history:7]
As of April 25, 2015, the Company estimated that future cash compensation expense of up to $366 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc., as more fully discussed immediately below.

- changed (2015-11-19):
[0000858877-15-000073:note_history:8]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market.  As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology.  Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements.  In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.
  (was, 2015-05-20, similarity 0.9855):
[0000858877-15-000051:note_history:8]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme Networks, Inc. ("Insieme"), an early stage company focused on research and development in the data center market.  As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology.  Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements.  In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

- changed (2015-11-19):
[0000858877-15-000073:note_history:9]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  The Company recorded compensation expense of $51 million and $53 million during the three months ended October 24, 2015 and October 25, 2014, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $841 million (which includes the $674 million that has been expensed to date), net of forfeitures.
  (was, 2015-05-20, similarity 0.8516):
[0000858877-15-000051:note_history:9]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  The Company recorded compensation expense of $51 million and $52 million during the three months ended April 25, 2015 and April 26, 2014, respectively, and $155 million and $363 million during the nine months ended April 25, 2015 and April 26, 2014, respectively, related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $843 million (which includes the $571 million that has been expensed to date), net of forfeitures.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.

- added (2015-11-19):
[0000858877-15-000073:note_history:10]
The former noncontrolling interest holders earned the maximum amount related to the first milestone payment and were paid   approximately $291 million for a portion of this amount during the first quarter of fiscal 2016.  The balance of the first milestone payment is expected to be paid primarily through the end of fiscal 2016.  The second milestone payment, to the extent earned, is expected to be paid primarily during the first half of fiscal 2017.

- changed (2015-11-19):
[0000858877-15-000073:note_history:11]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand.  The funding commitments were $192 million and $205 million as of October 24, 2015 and July 25, 2015, respectively.
  (was, 2015-05-20, similarity 0.9836):
[0000858877-15-000051:note_history:11]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand.  The funding commitments were $247 million and $255 million as of April 25, 2015 and July 26, 2014, respectively.

- changed (2015-11-19):
[0000858877-15-000073:note_history:12]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Balance at beginning of period | $ | 449 |  |  | $ | 446 |  |
| Provision for warranties issued | 150 |  |  | 143 |  |
| Payments | (166 | ) |  | (153 | ) |
| Balance at end of period | $ | 433 |  |  | $ | 436 |  |
  (was, 2015-05-20, similarity 0.8235):
[0000858877-15-000051:note_history:12]
|  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |
| Balance at beginning of period | $ | 446 |  |  | $ | 402 |  |
| Provision for warranties issued | 517 |  |  | 532 |  |
| Payments | (512 | ) |  | (504 | ) |
| Balance at end of period | $ | 451 |  |  | $ | 430 |  |

- changed (2015-11-19):
[0000858877-15-000073:note_history:13]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days.  These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements.  The volume of channel partner financing was $6.9 billion and $6.3 billion for the three months ended October 24, 2015 and October 25, 2014, respectively.  The balance of the channel partner financing subject to guarantees was $1.2 billion as of each October 24, 2015 and July 25, 2015.
  (was, 2015-05-20, similarity 0.8731):
[0000858877-15-000051:note_history:13]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days.  These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements.  The volume of channel partner financing was $6.3 billion and $5.8 billion for the three months ended April 25, 2015 and April 26, 2014, respectively.  The volume of channel partner financing was $19.0 billion and $17.9 billion for the nine months ended April 25, 2015 and April 26, 2014, respectively.  The balance of the channel partner financing subject to guarantees was $1.2 billion as of each April 25, 2015 and July 26, 2014.

- changed (2015-11-19):
[0000858877-15-000073:note_history:14]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years.  The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $23 million and $26 million for the three months ended October 24, 2015 and October 25, 2014, respectively.
  (was, 2015-05-20, similarity 0.8569):
[0000858877-15-000051:note_history:14]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years.  The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $22 million and $44 million for the three months ended April 25, 2015 and April 26, 2014, respectively, and was $87 million and $89 million for the nine months ended April 25, 2015 and April 26, 2014, respectively.

- changed (2015-11-19):
[0000858877-15-000073:note_history:15]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 24, 2015 and July 25, 2015, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2015-05-20, similarity 0.9807):
[0000858877-15-000051:note_history:15]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 25, 2015 and July 26, 2014, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2015-11-19):
[0000858877-15-000073:note_history:16]
|  | October 24, 2015 |  | July 25, 2015 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 250 |  |  | $ | 288 |  |
| End user | 124 |  |  | 129 |  |
| Total | $ | 374 |  |  | $ | 417 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (96 | ) |  | $ | (127 | ) |
| End user | (100 | ) |  | (107 | ) |
| Total | $ | (196 | ) |  | $ | (234 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 178 |  |  | $ | 183 |  |
  (was, 2015-05-20, similarity 0.9885):
[0000858877-15-000051:note_history:16]
|  | April 25, 2015 |  | July 26, 2014 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 299 |  |  | $ | 263 |  |
| End user | 138 |  |  | 202 |  |
| Total | $ | 437 |  |  | $ | 465 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (122 | ) |  | $ | (127 | ) |
| End user | (113 | ) |  | (166 | ) |
| Total | $ | (235 | ) |  | $ | (293 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 202 |  |  | $ | 172 |  |

- changed (2015-11-19):
[0000858877-15-000073:note_history:17]
Other Guarantees   The Company’s other guarantee arrangements as of October 24, 2015 and July 25, 2015 that were subject to recognition and disclosure requirements were not material.
  (was, 2015-05-20, similarity 0.9704):
[0000858877-15-000051:note_history:17]
Other Guarantees   The Company’s other guarantee arrangements as of April 25, 2015 and July 26, 2014 that were subject to recognition and disclosure requirements were not material.

- changed (2015-11-19):
[0000858877-15-000073:note_history:18]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010.  These components were widely used across the industry and are included in a number of the Company's products.  Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low.  However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem.  Although the majority of these products was beyond the Company's warranty terms, the Company has been proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  During the third quarter of fiscal 2015, an adjustment to product cost of sales of $164 million was recorded to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products.  The supplier component remediation liability as of October 24, 2015 and July 25, 2015 was $391 million and $408 million, respectively.
  (was, 2015-05-20, similarity 0.9425):
[0000858877-15-000051:note_history:18]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010.  These components are widely used across the industry and are included in a number of the Company's products.  Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low.  However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem.  Although the majority of these products are beyond the Company's warranty terms, the Company is proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  During the third quarter of fiscal 2015, an adjustment of $164 million  was recorded, which was a reduction to the liability to reflect net lower than estimated future costs to remediate the impacted customer products.  The supplier component remediation liability as of April 25, 2015 and July 26, 2014 was $426 million and $670 million, respectively.

- added (2015-11-19):
[0000858877-15-000073:note_history:19]
The Company is providing such indemnifications, among other cases, in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) now pending in Kansas and Delaware.  Sprint alleges that the service provider customers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers.  Sprint seeks monetary damages.  Sprint’s cases in Kansas include claims against Comcast and Time Warner Cable, and the case in Delaware for which the Company is providing indemnification involves Cox Communications.  At the request of Sprint and Comcast, on August 5, 2015, the judge in Sprint’s Kansas action ordered a six-month stay of the patent litigation between those parties for them to pursue a resolution of their dispute. In addition, on May 15, 2015, the judge in Sprint's Delaware action against Cox ruled invalid six of the patents that Sprint asserted Cox had infringed and a final judgment was entered on August 27, 2015, of invalidity, which Sprint appealed on October 1, 2015.  In May 2015 the Company filed two declaratory judgment actions against Sprint seeking declarations that the patents Sprint asserted against the Company’s customers are invalid and/or not infringed.  Cox has filed a motion for summary judgment of non-infringement for the five remaining Sprint patents that are actively being litigated against Cox in Delaware, Comcast has also won a judgment of non-infringement, now being appealed by Sprint, in a separate case brought against it by Sprint in Delaware.  In light of the invalidity rulings against Sprint in Delaware, on October 8, 2015, the judge in Sprint’s Kansas actions ordered an additional stay of Sprint’s Kansas actions including the case against Time Warner Cable, pending resolution of Sprint’s appeal of the Delaware Judge’s judgment of invalidity in the Cox case.

- added (2015-11-19):
[0000858877-15-000073:note_history:20]
The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims and/or that Sprint's patents are invalid.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should the plaintiff prevail in litigation, mediation, or settlement, the Company, in accordance with its agreement, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

- changed (2015-11-19):
[0000858877-15-000073:note_history:21]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007.  The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $222 million for the alleged evasion of import and other taxes, approximately $1.0 billion for interest, and approximately $1.0 billion for various penalties, all determined using an exchange rate as of October 24, 2015.  The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously.  While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any.  The Company does not expect a final judicial determination for several years.
  (was, 2015-05-20, similarity 0.995):
[0000858877-15-000051:note_history:21]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007.  The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $291 million for the alleged evasion of import and other taxes, approximately $1.1 billion for interest, and approximately $1.3 billion for various penalties, all determined using an exchange rate as of April 25, 2015.  The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously.  While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any.  The Company does not expect a final judicial determination for several years.

- changed (2015-11-19):
[0000858877-15-000073:note_history:22]
Russia and the Commonwealth of Independent States    At the request of the U.S. Securities and Exchange Commission (SEC) and the U.S. Department of Justice, the Company is conducting an investigation into allegations that the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries.  The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the SEC and the Department of Justice.  While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.  The countries that are the subject of the investigation collectively comprise less than 2% of the Company’s revenues.
  (was, 2015-05-20, similarity 0.9957):
[0000858877-15-000051:note_history:22]
Russia and the Commonwealth of Independent States    At the request of the U.S. Securities and Exchange Commission (SEC) and the U.S. Department of Justice, the Company is conducting an investigation into allegations which the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries.  The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the SEC and the Department of Justice.  While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.  The countries that are the subject of the investigation collectively comprise less than 2% of the Company’s revenues.

- removed (2015-11-19):
[0000858877-15-000051:note_history:23]
In connection with the Company’s business combinations, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

- removed (2015-11-19):
[0000858877-15-000051:note_history:24]
The Company has an obligation to indemnify certain expenses pursuant to such an agreement in, among other cases, a case involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) in the U.S. District Court for the District of Kansas filed on December 19, 2011 (including one case that was later transferred to the District of Delaware).  Sprint alleges that the service providers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers.  Sprint is seeking monetary damages.  Trial dates have been set for the first half of calendar year 2016 in the case proceeding in the District of Kansas.  The trial in Delaware is scheduled for February 2017.  The parties conducted mediations, and the Company participated through a mediation involving a service provider customer.  Those particular mediations did not resolve the parties’ disputes, but the parties plan to engage in additional dispute resolution efforts, including participation by the Company.  The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims and/or that the patents are invalid.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should the plaintiff prevail in litigation, mediation, or settlement, the Company, in accordance with its agreement, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

- removed (2015-11-19):
[0000858877-15-000051:note_history:25]
Rockstar    The Company and some of its service provider customers were subject to patent claims asserted in December 2013 in the Eastern District of Texas and the District of Delaware by subsidiaries of the Rockstar Consortium (“Rockstar”).  Rockstar, whose members include Apple, Microsoft, LM Ericsson, Sony, and Blackberry, had purchased a portfolio of patents out of the Nortel Networks’ bankruptcy proceedings (the “Nortel Portfolio”).  In connection with this matter, during the first quarter of fiscal 2015 the Company recorded a charge to product cost of sales of $188 million.

- removed (2015-11-19):
[0000858877-15-000051:note_history:26]
In December 2014, RPX Corporation (“RPX”) and Rockstar entered into an agreement, which closed on January 28, 2015, resulting in over 30 technology companies, including the Company and the various service provider customers described above, obtaining a license to the patents owned by Rockstar.  The Company paid approximately $300 million in connection with this transaction, with the payment recorded against the amount previously reserved and as an intangible asset to be amortized over its estimated useful life.  In connection with the closing of the transaction, Rockstar dismissed all litigation it had brought against the participating companies.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-19):
[0000858877-15-000073:note_history:27]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July.  Fiscal 2016 is a 53-week fiscal year and fiscal 2015 was a 52-week fiscal year.  The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries.  All intercompany accounts and transactions have been eliminated.  The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).
  (was, 2015-05-20, similarity 0.9436):
[0000858877-15-000051:note_history:27]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2015 and fiscal 2014 are each 52-week fiscal years.  The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries.  All intercompany accounts and transactions have been eliminated.  The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

- changed (2015-11-19):
[0000858877-15-000073:note_history:28]
The accompanying financial data as of October 24, 2015 and for the three months ended October 24, 2015 and October 25, 2014 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations.  The July 25, 2015 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States.  However, the Company believes that the disclosures are adequate to make the information presented not misleading.  These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 25, 2015.
  (was, 2015-05-20, similarity 0.9659):
[0000858877-15-000051:note_history:28]
The accompanying financial data as of April 25, 2015 and for the three and nine months ended April 25, 2015 and April 26, 2014 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations.  The July 26, 2014 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States.  However, the Company believes that the disclosures are adequate to make the information presented not misleading.  These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 26, 2014.

- added (2015-11-19):
[0000858877-15-000073:note_history:29]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 24, 2015; the results of operations, statements of comprehensive income, cash flows and equity for the three months ended October 24, 2015 and October 25, 2014, as applicable, have been made.  The results of operations for the three months ended October 24, 2015 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2015-11-19):
[0000858877-15-000051:note_history:30]
In the opinion of management, all adjustments (which include normal recurring adjustments, except as disclosed herein) necessary to present fairly the consolidated balance sheet as of April 25, 2015; the results of operations and statements of comprehensive income for the three and nine months ended April 25, 2015 and April 26, 2014; and the statements of cash flows and equity for the nine months ended April 25, 2015 and April 26, 2014, as applicable, have been made.  The results of operations for the three and nine months ended April 25, 2015 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-19):
[0000858877-15-000073:note_history:31]
Recent Accounting Standards or Updates Not Yet Effective  In May 2014, the FASB issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance.  The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services.  This accounting standard update, as amended, will be effective for the Company beginning in the first quarter of fiscal 2019.  The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption.  Early adoption is permitted, but no earlier than fiscal 2018.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.
  (was, 2015-05-20, similarity 0.7996):
[0000858877-15-000051:note_history:31]
In May 2014, the FASB issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance.  The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services.  This accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2018.  The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption.  Early adoption is not permitted.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- removed (2015-11-19):
[0000858877-15-000051:note_history:32]
| (a) | New Accounting Updates Recently Adopted |

- removed (2015-11-19):
[0000858877-15-000051:note_history:33]
In March 2013, the Financial Accounting Standards Board (FASB) issued an accounting standard update requiring an entity to release into net income the entire amount of a cumulative translation adjustment related to its investment in a foreign entity when as a parent it sells either a part or all of its investment in the foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within the foreign entity.  This accounting standard update became effective for the Company beginning in the first quarter of fiscal 2015.  The application of this accounting standard update did not have any impact to the Company's Consolidated Financial Statements.

- removed (2015-11-19):
[0000858877-15-000051:note_history:34]
In July 2013, the FASB issued an accounting standard update that provides explicit guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists.  Under the new standard update, an unrecognized tax benefit, or a portion of an unrecognized tax benefit, is to be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward or a tax credit carryforward.  This accounting standard update became effective for the Company beginning in the first quarter of fiscal 2015 and applied prospectively.  The application of this accounting standard update did not have a material impact to the Company's Consolidated Financial Statements.

- removed (2015-11-19):
[0000858877-15-000051:note_history:35]
In April 2014, the FASB issued an accounting standard update that changes the criteria for reporting discontinued operations.  This accounting standard update raises the threshold for a disposal transaction to qualify as a discontinued operation and requires additional disclosures about discontinued operations and disposals of individually significant components that do not qualify as discontinued operations.  The Company adopted this accounting standard update in the second quarter of fiscal 2015, and it did not have any impact upon adoption.

- removed (2015-11-19):
[0000858877-15-000051:note_history:36]
| (b) | Recent Accounting Standards or Updates Not Yet Effective |

- removed (2015-11-19):
[0000858877-15-000051:note_history:37]
In April 2015, the FASB issued an accounting standard update requiring debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying amount of that debt, consistent with debt discounts.  The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2017 on a retrospective basis, with early adoption permitted.  The accounting standard update is a change in balance sheet presentation only and is not expected to have a material impact on the Company's Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-19):
[0000858877-15-000073:note_history:38]
|  | October 24, 2015 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 3,025 |  |  | 3.09 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other short-term debt | 2 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total | $ | 3,027 |  |  |  |  | $ | 3,897 |  |  |  |
  (was, 2015-05-20, similarity 0.8908):
[0000858877-15-000051:note_history:38]
|  | April 25, 2015 |  | July 26, 2014 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 3,914 |  |  | 2.47 | % |  | $ | 500 |  |  | 3.11 | % |
| Commercial paper | 500 |  |  | 0.16 | % |  | — |  |  | — |  |
| Other short-term debt | 4 |  |  | 2.62 | % |  | 8 |  |  | 2.67 | % |
| Total | $ | 4,418 |  |  |  |  | $ | 508 |  |  |  |

- added (2015-11-19):
[0000858877-15-000073:note_history:39]
On September 3, 2015, the Company repaid an aggregate principal amount of $850 million upon the maturity of its 2015 Floating-Rate Notes.

- changed (2015-11-19):
[0000858877-15-000073:note_history:40]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes.  The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes.  The Company had no commercial paper notes outstanding as of each of October 24, 2015 and July 25, 2015.
  (was, 2015-05-20, similarity 0.7294):
[0000858877-15-000051:note_history:40]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes.  The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes.  The outstanding commercial paper notes as of April 25, 2015 had original maturity dates of three months or less.

- changed (2015-11-19):
[0000858877-15-000073:note_history:41]
|  |  |  | October 24, 2015 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.68% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 0.71% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.88% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.09% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.60% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.90% |  | 750 |  |  | 0.85% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.70% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.81% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.02% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.97% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.22% |  | 500 |  |  | 1.21% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.09% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.38% |  | 500 |  |  | 1.37% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  |  |  | 1 |  |  | 2.08% |
| Total |  |  | 24,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (128 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 347 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 24,619 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,025 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 21,594 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 24,619 |  |  |  |  | $ | 25,351 |  |  |  |
  (was, 2015-05-20, similarity 0.881):
[0000858877-15-000051:note_history:41]
|  |  |  | April 25, 2015 |  | July 26, 2014 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | 0.41% |  | $ | 850 |  |  | 0.35% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.61% |  | 1,000 |  |  | 0.56% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.82% |  | 500 |  |  | 0.78% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | — |  |  | — |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.06% |  | 3,000 |  |  | 3.04% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.58% |  | 2,400 |  |  | 0.56% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.83% |  | 750 |  |  | 0.79% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.69% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.79% |  | 1,750 |  |  | 0.77% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.00% |  | 2,500 |  |  | 2.98% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.95% |  | 500 |  |  | 0.93% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.07% |  | 1,000 |  |  | 1.05% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 1 |  |  | 2.08% |  | 4 |  |  | 2.39% |
| Total |  |  | 20,251 |  |  |  |  | 20,754 |  |  |  |
| Unaccreted discount |  |  | (59 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 308 |  |  |  |  | 210 |  |  |  |
| Total |  |  | $ | 20,500 |  |  |  |  | $ | 20,901 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,914 |  |  |  |  | $ | 500 |  |  |  |
| Long-term debt |  |  | 16,586 |  |  |  |  | 20,401 |  |  |  |
| Total |  |  | $ | 20,500 |  |  |  |  | $ | 20,901 |  |  |  |

- changed (2015-11-19):
[0000858877-15-000073:note_history:42]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount and issuance costs, and, if applicable, adjustments related to hedging.  Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes.  Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.
  (was, 2015-05-20, similarity 0.9768):
[0000858877-15-000051:note_history:42]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount, and, if applicable, adjustments related to hedging.  Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes.  Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

- changed (2015-11-19):
[0000858877-15-000073:note_history:43]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.”  As of October 24, 2015, the Company was in compliance with all debt covenants.
  (was, 2015-05-20, similarity 0.9781):
[0000858877-15-000051:note_history:43]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.”  As of April 25, 2015, the Company was in compliance with all debt covenants.

- changed (2015-11-19):
[0000858877-15-000073:note_history:44]
As of October 24, 2015, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2015-05-20, similarity 0.9627):
[0000858877-15-000051:note_history:44]
As of April 25, 2015, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2015-11-19):
[0000858877-15-000073:note_history:45]
| Fiscal Year | Amount |
| 2016 (remaining nine months) | $ | 3,000 |  |
| 2017 | 4,150 |  |
| 2018 | 2,500 |  |
| 2019 | 4,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 6,500 |  |
| Total | $ | 24,400 |  |
  (was, 2015-05-20, similarity 0.9642):
[0000858877-15-000051:note_history:45]
| Fiscal Year | Amount |
| 2015 (remaining three months) | $ | — |  |
| 2016 | 3,850 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| 2019 | 4,250 |  |
| Thereafter | 8,000 |  |
| Total | $ | 20,251 |  |

- changed (2015-11-19):
[0000858877-15-000073:note_history:46]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020.  Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero.  The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement.
  (was, 2015-05-20, similarity 0.9584):
[0000858877-15-000051:note_history:46]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020.  Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR or a comparable or successor rate which rate is approved by the Administrative Agent (“Eurocurrency Rate”) for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero.  The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement.

- changed (2015-11-19):
[0000858877-15-000073:note_history:47]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.  As of October 24, 2015, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.
  (was, 2015-05-20, similarity 0.7149):
[0000858877-15-000051:note_history:47]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.  The Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.

- removed (2015-11-19):
[0000858877-15-000051:note_history:48]
On November 17, 2014, upon the maturity of the Company’s 2014 Fixed-Rate Notes (2.90%), the Company repaid an aggregate principal amount of $500 million.

- removed (2015-11-19):
[0000858877-15-000051:note_history:49]
This credit facility replaces the Company’s prior credit facility that was entered into on February 17, 2012, which was terminated in connection with its entering into the new credit facility.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-19):
[0000858877-15-000073:note_history:50]
| October 24, 2015 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 27,409 |  |  | $ | 63 |  |  | $ | (1 | ) |  | $ | 27,471 |  |
| U.S. government agency securities | 3,606 |  |  | 11 |  |  | — |  |  | 3,617 |  |
| Non-U.S. government and agency securities | 1,133 |  |  | 3 |  |  | — |  |  | 1,136 |  |
| Corporate debt securities | 18,314 |  |  | 70 |  |  | (78 | ) |  | 18,306 |  |
| U.S. agency mortgage-backed securities | 1,454 |  |  | 15 |  |  | — |  |  | 1,469 |  |
| Total fixed income securities | 51,916 |  |  | 162 |  |  | (79 | ) |  | 51,999 |  |
| Publicly traded equity securities | 1,094 |  |  | 268 |  |  | (12 | ) |  | 1,350 |  |
| Total | $ | 53,010 |  |  | $ | 430 |  |  | $ | (91 | ) |  | $ | 53,349 |  |
  (was, 2015-05-20, similarity 0.9856):
[0000858877-15-000051:note_history:50]
| July 26, 2014 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 31,717 |  |  | $ | 29 |  |  | $ | (12 | ) |  | $ | 31,734 |  |
| U.S. government agency securities | 1,062 |  |  | 1 |  |  | — |  |  | 1,063 |  |
| Non-U.S. government and agency securities | 860 |  |  | 2 |  |  | (1 | ) |  | 861 |  |
| Corporate debt securities | 9,092 |  |  | 74 |  |  | (7 | ) |  | 9,159 |  |
| U.S. agency mortgage-backed securities | 574 |  |  | 5 |  |  | — |  |  | 579 |  |
| Total fixed income securities | 43,305 |  |  | 111 |  |  | (20 | ) |  | 43,396 |  |
| Publicly traded equity securities | 1,314 |  |  | 648 |  |  | (10 | ) |  | 1,952 |  |
| Total | $ | 44,619 |  |  | $ | 759 |  |  | $ | (30 | ) |  | $ | 45,348 |  |

- added (2015-11-19):
[0000858877-15-000073:note_history:51]
| July 25, 2015 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 29,904 |  |  | $ | 41 |  |  | $ | (6 | ) |  | $ | 29,939 |  |
| U.S. government agency securities | 3,662 |  |  | 2 |  |  | (1 | ) |  | 3,663 |  |
| Non-U.S. government and agency securities | 1,128 |  |  | 1 |  |  | (1 | ) |  | 1,128 |  |
| Corporate debt securities | 15,802 |  |  | 34 |  |  | (53 | ) |  | 15,783 |  |
| U.S. agency mortgage-backed securities | 1,456 |  |  | 8 |  |  | (3 | ) |  | 1,461 |  |
| Total fixed income securities | 51,952 |  |  | 86 |  |  | (64 | ) |  | 51,974 |  |
| Publicly traded equity securities | 1,092 |  |  | 480 |  |  | (7 | ) |  | 1,565 |  |
| Total | $ | 53,044 |  |  | $ | 566 |  |  | $ | (71 | ) |  | $ | 53,539 |  |

- changed (2015-11-19):
[0000858877-15-000073:note_history:52]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Gross realized gains | $ | 35 |  |  | $ | 21 |  |
| Gross realized losses | (36 | ) |  | (14 | ) |
| Total | $ | (1 | ) |  | $ | 7 |  |
  (was, 2015-05-20, similarity 0.6529):
[0000858877-15-000051:note_history:52]
|  | April 25, 2015 |  | July 26, 2014 |
| Equity method investments | $ | 561 |  |  | $ | 630 |  |
| Cost method investments | 312 |  |  | 269 |  |
| Total | $ | 873 |  |  | $ | 899 |  |

- added (2015-11-19):
[0000858877-15-000073:note_history:53]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Net losses on investments in publicly traded equity securities | $ | (9 | ) |  | $ | (4 | ) |
| Net gains on investments in fixed income securities | 8 |  |  | 11 |  |
| Total | $ | (1 | ) |  | $ | 7 |  |

- added (2015-11-19):
[0000858877-15-000073:note_history:54]
There were no impairment charges on available-for-sale investments for the periods presented.

- changed (2015-11-19):
[0000858877-15-000073:note_history:55]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at October 24, 2015 and July 25, 2015 (in millions):
  (was, 2015-05-20, similarity 0.9709):
[0000858877-15-000051:note_history:55]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at April 25, 2015 and July 26, 2014 (in millions):

- added (2015-11-19):
[0000858877-15-000073:note_history:56]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 24, 2015 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 2,566 |  |  | $ | (1 | ) |  | $ | — |  |  | $ | — |  |  | $ | 2,566 |  |  | $ | (1 | ) |
| U.S. government agency securities | 80 |  |  | — |  |  | — |  |  | — |  |  | 80 |  |  | — |  |
| Non-U.S. government and agency securities | 57 |  |  | — |  |  | 10 |  |  | — |  |  | 67 |  |  | — |  |
| Corporate debt securities | 7,421 |  |  | (66 | ) |  | 1,048 |  |  | (12 | ) |  | 8,469 |  |  | (78 | ) |
| U.S. agency mortgage-backed securities | 77 |  |  | — |  |  | — |  |  | — |  |  | 77 |  |  | — |  |
| Total fixed income securities | 10,201 |  |  | (67 | ) |  | 1,058 |  |  | (12 | ) |  | 11,259 |  |  | (79 | ) |
| Publicly traded equity securities | 103 |  |  | (11 | ) |  | 2 |  |  | (1 | ) |  | 105 |  |  | (12 | ) |
| Total | $ | 10,304 |  |  | $ | (78 | ) |  | $ | 1,060 |  |  | $ | (13 | ) |  | $ | 11,364 |  |  | $ | (91 | ) |

- added (2015-11-19):
[0000858877-15-000073:note_history:57]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 25, 2015 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 6,412 |  |  | $ | (6 | ) |  | $ | — |  |  | $ | — |  |  | $ | 6,412 |  |  | $ | (6 | ) |
| U.S. government agency securities | 1,433 |  |  | (1 | ) |  | — |  |  | — |  |  | 1,433 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 515 |  |  | (1 | ) |  | 4 |  |  | — |  |  | 519 |  |  | (1 | ) |
| Corporate debt securities | 9,552 |  |  | (49 | ) |  | 312 |  |  | (4 | ) |  | 9,864 |  |  | (53 | ) |
| U.S. agency mortgage-backed securities | 579 |  |  | (3 | ) |  | — |  |  | — |  |  | 579 |  |  | (3 | ) |
| Total fixed income securities | 18,491 |  |  | (60 | ) |  | 316 |  |  | (4 | ) |  | 18,807 |  |  | (64 | ) |
| Publicly traded equity securities | 108 |  |  | (7 | ) |  | 2 |  |  | — |  |  | 110 |  |  | (7 | ) |
| Total | $ | 18,599 |  |  | $ | (67 | ) |  | $ | 318 |  |  | $ | (4 | ) |  | $ | 18,917 |  |  | $ | (71 | ) |

- changed (2015-11-19):
[0000858877-15-000073:note_history:58]
As of October 24, 2015, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis.  In addition, as of October 24, 2015, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the three months ended October 24, 2015.
  (was, 2015-05-20, similarity 0.9422):
[0000858877-15-000051:note_history:58]
As of April 25, 2015, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis.  In addition, as of April 25, 2015, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the nine months ended April 25, 2015.

- added (2015-11-19):
[0000858877-15-000073:note_history:59]
The Company has evaluated its publicly traded equity securities as of October 24, 2015 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses.  This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

- changed (2015-11-19):
[0000858877-15-000073:note_history:60]
The following table summarizes the maturities of the Company’s fixed income securities at October 24, 2015 (in millions):
  (was, 2015-05-20, similarity 0.9565):
[0000858877-15-000051:note_history:60]
The following table summarizes the maturities of the Company’s fixed income securities at April 25, 2015 (in millions):

- changed (2015-11-19):
[0000858877-15-000073:note_history:61]
The Company periodically engages in securities lending activities with certain of its available for sale investments.  These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis.  The average daily balance of securities lending for the three months ended October 24, 2015 and October 25, 2014 was $0.5 billion and $1.0 billion, respectively.  The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets.  The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses.  The Company did not experience any losses in connection with the secured lending of securities during the periods presented.  As of October 24, 2015 and July 25, 2015, the Company had no outstanding securities lending transactions.
  (was, 2015-05-20, similarity 0.7388):
[0000858877-15-000051:note_history:61]
The Company periodically engages in securities lending activities with certain of its investments.  These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis.  The average daily balance of securities lending for the nine months ended April 25, 2015 and April 26, 2014 was $0.5 billion and $1.4 billion, respectively.  The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets.  The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses.  The Company did not experience any losses in connection with the secured lending of securities during the periods presented.  As of April 25, 2015 and July 26, 2014, the Company had no outstanding securities lending transactions.

- changed (2015-11-19):
[0000858877-15-000073:note_history:62]
The carrying value of the Company’s investments in privately held companies was included in other assets.  For such investments that were accounted for under the equity and cost method as of October 24, 2015 and July 25, 2015, the amounts are summarized in the following table (in millions):
  (was, 2015-05-20, similarity 0.9784):
[0000858877-15-000051:note_history:62]
The carrying value of the Company’s investments in privately held companies was included in other assets.  For such investments that were accounted for under the equity and cost method as of April 25, 2015 and July 26, 2014, the amounts are summarized in the following table (in millions):

- added (2015-11-19):
[0000858877-15-000073:note_history:63]
|  | October 24, 2015 |  | July 25, 2015 |
| Equity method investments | $ | 619 |  |  | $ | 578 |  |
| Cost method investments | 309 |  |  | 319 |  |
| Total | $ | 928 |  |  | $ | 897 |  |

- added (2015-11-19):
[0000858877-15-000073:note_history:64]
For additional information on impairment charges related to investments in privately held companies, see Note 9.

- changed (2015-11-19):
[0000858877-15-000073:note_history:65]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers.  These privately held companies and customers may be considered to be variable interest entities.  The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings and has determined that as of October 24, 2015 there were no variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.
  (was, 2015-05-20, similarity 0.9623):
[0000858877-15-000051:note_history:65]
Other Variable Interest Entities    In the ordinary course of business, the Company has investments in other privately held companies and provides financing to certain customers.  These other privately held companies and customers may be considered to be variable interest entities.  The Company evaluates on an ongoing basis its investments in these other privately held companies and its customer financings and has determined that as of April 25, 2015 there were no other variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

- removed (2015-11-19):
[0000858877-15-000051:note_history:66]
| April 25, 2015 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 29,364 |  |  | $ | 59 |  |  | $ | (1 | ) |  | $ | 29,422 |  |
| U.S. government agency securities | 3,257 |  |  | 6 |  |  | (1 | ) |  | 3,262 |  |
| Non-U.S. government and agency securities | 1,184 |  |  | 2 |  |  | — |  |  | 1,186 |  |
| Corporate debt securities | 13,321 |  |  | 86 |  |  | (13 | ) |  | 13,394 |  |
| U.S. agency mortgage-backed securities | 1,346 |  |  | 16 |  |  | — |  |  | 1,362 |  |
| Total fixed income securities | 48,472 |  |  | 169 |  |  | (15 | ) |  | 48,626 |  |
| Publicly traded equity securities | 1,328 |  |  | 598 |  |  | (3 | ) |  | 1,923 |  |
| Total | $ | 49,800 |  |  | $ | 767 |  |  | $ | (18 | ) |  | $ | 50,549 |  |

- removed (2015-11-19):
[0000858877-15-000051:note_history:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Gross realized gains | $ | 55 |  |  | $ | 75 |  |  | $ | 168 |  |  | $ | 267 |  |
| Gross realized losses | (11 | ) |  | (6 | ) |  | (48 | ) |  | (33 | ) |
| Total | $ | 44 |  |  | $ | 69 |  |  | $ | 120 |  |  | $ | 234 |  |

- removed (2015-11-19):
[0000858877-15-000051:note_history:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Net gains on investments in publicly traded equity securities | $ | 38 |  |  | $ | 55 |  |  | $ | 94 |  |  | $ | 199 |  |
| Net gains on investments in fixed income securities | 6 |  |  | 14 |  |  | 26 |  |  | 35 |  |
| Total | $ | 44 |  |  | $ | 69 |  |  | $ | 120 |  |  | $ | 234 |  |

- removed (2015-11-19):
[0000858877-15-000051:note_history:69]
There were no impairment charges on available-for-sale investments for the nine months ended April 25, 2015.  For the three months ended April 26, 2014, there were no impairment charges on available-for-sale investments.  For the nine months ended April 26, 2014, the Company had impairment charges of $11 million for publicly traded equity securities, which were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary.

- removed (2015-11-19):
[0000858877-15-000051:note_history:70]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 25, 2015 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 4,096 |  |  | $ | (1 | ) |  | $ | — |  |  | $ | — |  |  | $ | 4,096 |  |  | $ | (1 | ) |
| U.S. government agency securities | 702 |  |  | (1 | ) |  | — |  |  | — |  |  | 702 |  |  | (1 | ) |
| Corporate debt securities | 3,587 |  |  | (12 | ) |  | 157 |  |  | (1 | ) |  | 3,744 |  |  | (13 | ) |
| Total fixed income securities | 8,385 |  |  | (14 | ) |  | 157 |  |  | (1 | ) |  | 8,542 |  |  | (15 | ) |
| Publicly traded equity securities | 42 |  |  | (3 | ) |  | 1 |  |  | — |  |  | 43 |  |  | (3 | ) |
| Total | $ | 8,427 |  |  | $ | (17 | ) |  | $ | 158 |  |  | $ | (1 | ) |  | $ | 8,585 |  |  | $ | (18 | ) |

- removed (2015-11-19):
[0000858877-15-000051:note_history:71]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 26, 2014 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 7,676 |  |  | $ | (12 | ) |  | $ | 45 |  |  | $ | — |  |  | $ | 7,721 |  |  | $ | (12 | ) |
| Non-U.S. government and agency securities | 361 |  |  | (1 | ) |  | 22 |  |  | — |  |  | 383 |  |  | (1 | ) |
| Corporate debt securities | 1,875 |  |  | (3 | ) |  | 491 |  |  | (4 | ) |  | 2,366 |  |  | (7 | ) |
| Total fixed income securities | 9,912 |  |  | (16 | ) |  | 558 |  |  | (4 | ) |  | 10,470 |  |  | (20 | ) |
| Publicly traded equity securities | 132 |  |  | (10 | ) |  | — |  |  | — |  |  | 132 |  |  | (10 | ) |
| Total | $ | 10,044 |  |  | $ | (26 | ) |  | $ | 558 |  |  | $ | (4 | ) |  | $ | 10,602 |  |  | $ | (30 | ) |

- removed (2015-11-19):
[0000858877-15-000051:note_history:72]
The Company has evaluated its publicly traded equity securities as of April 25, 2015 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses.  This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

- removed (2015-11-19):
[0000858877-15-000051:note_history:73]
Variable Interest Entities

- removed (2015-11-19):
[0000858877-15-000051:note_history:74]
VCE Joint Venture  VCE is a joint venture formed in fiscal 2010 between the Company and EMC Corporation (“EMC”), with investments from VMware, Inc. (“VMware”) and Intel Capital Corporation ("Intel").  In October 2014, the Company, EMC, VMware, and Intel agreed to restructure VCE, and this transaction was completed in the second quarter of fiscal 2015.  Prior to the restructuring, the Company’s cumulative gross investment in VCE was approximately $716 million inclusive of convertible notes and accrued interest on convertible notes.  The Company recorded cumulative losses from VCE under the equity method of $691 million since inception.  The Company ceased accounting for the VCE investment under the equity method in October 2014 and recorded no losses during the three months ended April 25, 2015, compared with losses of $52 million recorded for the three months ended April 26, 2014, and losses of $47 million and $163 million were recorded for the nine months ended April 25, 2015 and April 26, 2014, respectively.  Under the terms of the restructuring, VCE paid $152 million to the Company for a portion of the outstanding principal balance of the convertible notes held by it and accrued interest on such notes, and the remaining principal balance of other such notes, and the accrued interest thereon, was cancelled.  Pursuant to the restructuring, VCE also redeemed a portion of the Company’s equity interest in VCE, reducing the Company’s ownership interest in VCE from 35% prior to the restructuring to 10%.  In connection with this transaction, the Company has written this investment down to a book value of zero and has recognized a gain of $126 million for the nine months ended April 25, 2015.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-19):
[0000858877-15-000073:note_history:75]
|  |  |  | October 24, 2015 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.68% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 0.71% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.88% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.09% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.60% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.90% |  | 750 |  |  | 0.85% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.70% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.81% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.02% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.97% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.22% |  | 500 |  |  | 1.21% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.09% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.38% |  | 500 |  |  | 1.37% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  |  |  | 1 |  |  | 2.08% |
| Total |  |  | 24,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (128 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 347 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 24,619 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,025 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 21,594 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 24,619 |  |  |  |  | $ | 25,351 |  |  |  |
  (was, 2015-05-20, similarity 0.881):
[0000858877-15-000051:note_history:75]
|  |  |  | April 25, 2015 |  | July 26, 2014 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | 0.41% |  | $ | 850 |  |  | 0.35% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.61% |  | 1,000 |  |  | 0.56% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.82% |  | 500 |  |  | 0.78% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | — |  |  | — |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.06% |  | 3,000 |  |  | 3.04% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.58% |  | 2,400 |  |  | 0.56% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.83% |  | 750 |  |  | 0.79% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.69% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.79% |  | 1,750 |  |  | 0.77% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.00% |  | 2,500 |  |  | 2.98% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.95% |  | 500 |  |  | 0.93% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.07% |  | 1,000 |  |  | 1.05% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 1 |  |  | 2.08% |  | 4 |  |  | 2.39% |
| Total |  |  | 20,251 |  |  |  |  | 20,754 |  |  |  |
| Unaccreted discount |  |  | (59 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 308 |  |  |  |  | 210 |  |  |  |
| Total |  |  | $ | 20,500 |  |  |  |  | $ | 20,901 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,914 |  |  |  |  | $ | 500 |  |  |  |
| Long-term debt |  |  | 16,586 |  |  |  |  | 20,401 |  |  |  |
| Total |  |  | $ | 20,500 |  |  |  |  | $ | 20,901 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-19):
[0000858877-15-000073:note_history:76]
As of October 24, 2015, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2015-05-20, similarity 0.9627):
[0000858877-15-000051:note_history:76]
As of April 25, 2015, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2015-11-19):
[0000858877-15-000073:note_history:77]
| Fiscal Year | Amount |
| 2016 (remaining nine months) | $ | 3,000 |  |
| 2017 | 4,150 |  |
| 2018 | 2,500 |  |
| 2019 | 4,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 6,500 |  |
| Total | $ | 24,400 |  |
  (was, 2015-05-20, similarity 0.9642):
[0000858877-15-000051:note_history:77]
| Fiscal Year | Amount |
| 2015 (remaining three months) | $ | — |  |
| 2016 | 3,850 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| 2019 | 4,250 |  |
| Thereafter | 8,000 |  |
| Total | $ | 20,251 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-19):
[0000858877-15-000073:note_history:78]
|  | October 24, 2015 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 3,025 |  |  | 3.09 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other short-term debt | 2 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total | $ | 3,027 |  |  |  |  | $ | 3,897 |  |  |  |
  (was, 2015-05-20, similarity 0.8908):
[0000858877-15-000051:note_history:78]
|  | April 25, 2015 |  | July 26, 2014 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 3,914 |  |  | 2.47 | % |  | $ | 500 |  |  | 3.11 | % |
| Commercial paper | 500 |  |  | 0.16 | % |  | — |  |  | — |  |
| Other short-term debt | 4 |  |  | 2.62 | % |  | 8 |  |  | 2.67 | % |
| Total | $ | 4,418 |  |  |  |  | $ | 508 |  |  |  |
