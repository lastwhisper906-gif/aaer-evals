# CSCO 8-K — 0001193125-15-375655 filed 2015-11-12

## item codes, every 8-K on or before 2015-11-19

- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2015-11-19

- none on or before 2015-11-19

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-375655:8k_2_02:1]
EX-99.1
2
d96339dex991.htm
EX-99.1

[0001193125-15-375655:8k_2_02:2]
EX-99.1

[0001193125-15-375655:8k_2_02:3]
Exhibit 99.1

[0001193125-15-375655:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Andrea Duffy |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (646) 295-5241 |  |  |  | 1 (408) 527-7452 |
| anduffy@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-15-375655:8k_2_02:5]
CISCO REPORTS FIRST QUARTER EARNINGS

[0001193125-15-375655:8k_2_02:6]
Strong Results and Great Execution in Q1, Guided for Growth in Q2, Well Positioned for Second Half

[0001193125-15-375655:8k_2_02:7]
|  | • |  | Q1 Revenue: $12.7 billion (increase of 4% year over year) |

[0001193125-15-375655:8k_2_02:8]
|  | • |  | Q1 Earnings per Share: $0.48 GAAP; $0.59 non-GAAP |

[0001193125-15-375655:8k_2_02:9]
|  | • |  | Q2 Guidance (normalized to exclude SP Video CPE business): |

[0001193125-15-375655:8k_2_02:10]
|  | • |  | Revenue: 0% - 2% growth year over year |

[0001193125-15-375655:8k_2_02:11]
|  | • |  | Non-GAAP Earnings per Share: $0.53 - $0.55 |

[0001193125-15-375655:8k_2_02:12]
SAN JOSE, Calif. — November 12, 2015 —
Cisco, the worldwide leader in networking that transforms how people connect, communicate and collaborate, today reported its first quarter results for the period ended October 24, 2015. Cisco reported first quarter revenue of $12.7 billion,
net income on a generally accepted accounting principles (GAAP) basis of $2.4 billion or $0.48 per share, and non-GAAP net income of $3.0 billion or $0.59 per share.

[0001193125-15-375655:8k_2_02:13]
“Q1 was a very strong quarter. We are accelerating our ability to deliver on growth opportunities, aggressively driving our cloud business, and
delivering continued strength in our deferred product revenue, as we sell more of our portfolio in software and cloud models,” said Chuck Robbins, Cisco chief executive officer.

[0001193125-15-375655:8k_2_02:14]
“We guided to solid growth in Q2. Our guidance reflects lower than expected order growth in Q1, driven largely by the uncertainty of the macro
environment and currency impacts. Despite these headwinds, I believe we are executing very well. We are moving very fast to capture new opportunities and I feel good about how we are positioned for the second half of the year.”

[0001193125-15-375655:8k_2_02:15]
GAAP Results

[0001193125-15-375655:8k_2_02:16]
|  |  | Q1 2016 |  |  | Q1 2015 |  |  | Vs. Q1 2015 |  |
| Revenue |  | $ | 12.7 billion |  |  | $ | 12.2 billion |  |  |  | 3.6 | % |
| Net Income |  | $ | 2.4 billion |  |  | $ | 1.8 billion |  |  |  | 32.9 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.48 |  |  | $ | 0.35 |  |  |  | 37.1 | % |

[0001193125-15-375655:8k_2_02:17]
Non-GAAP Results

[0001193125-15-375655:8k_2_02:18]
|  |  | Q1 2016 |  |  | Q1 2015 |  |  | Vs. Q1 2015 |  |
| Net Income |  | $ | 3.0 billion |  |  | $ | 2.8 billion |  |  |  | 7.9 | % |
| EPS |  | $ | 0.59 |  |  | $ | 0.54 |  |  |  | 9.3 | % |

[0001193125-15-375655:8k_2_02:19]
A reconciliation between net income and EPS on a GAAP and non-GAAP basis is provided in the table following the Consolidated
Statements of Operations. Supplementary information related to other GAAP and non-GAAP measures is also provided in the tables below.

[0001193125-15-375655:8k_2_02:20]
1

[0001193125-15-375655:8k_2_02:21]
Financial Highlights for Q1 FY16

[0001193125-15-375655:8k_2_02:22]
(All comparative percentages are on a year-over-year basis unless otherwise noted)

[0001193125-15-375655:8k_2_02:23]
Revenue — Total revenue was $12.7 billion, up 4%. Product revenue increased by 4% and service revenue increased by 1%. Total revenue by
geographic segment was: Americas up 4%, and each of EMEA and APJC up 3%. Product revenue growth was led by Data Center and Collaboration at 24% and 17%, respectively. Wireless and Security each grew 7%, Switching grew 5%, NGN Routing decreased 8%,
and Service Provider Video decreased 2%.

[0001193125-15-375655:8k_2_02:24]
Gross Margin — On a non-GAAP basis, total gross margin and product gross margin
were 63.2% and 62.3% respectively. The increase in non-GAAP product gross margin as compared to the fourth quarter of fiscal 2015 was driven by continued productivity improvements, partially offset by pricing and to a lesser extent product mix.
Non-GAAP service gross margin was 66.2%. Total gross margins by geographic segment were: 63.5% for the Americas, 64.2% for EMEA, and 60.0% for APJC. On a GAAP basis, total gross margin, product gross margin, and service gross margin were at 61.8%,
60.9% and 64.9%, respectively.

[0001193125-15-375655:8k_2_02:25]
Operating Expenses — Non-GAAP operating expenses were $4.1 billion, down 1%, and at 32.7%
of revenue. Headcount increased from the fourth quarter of fiscal 2015 by 230 to 72,063, reflecting additional headcount from acquisitions and investments in key growth areas such as security, cloud and software. On a GAAP basis, operating expenses
were $4.8 billion, down 5%.

[0001193125-15-375655:8k_2_02:26]
Operating Income — Non-GAAP operating income was $3.9 billion, up 8%, with non-GAAP
operating margin at 30.5%. GAAP operating income was $3.1 billion, up 31%, with GAAP operating margin of 24.3%.

[0001193125-15-375655:8k_2_02:27]
Provision for Income
Taxes — The non-GAAP tax provision rate was 23.0%. The GAAP tax provision rate was 22.5%.

[0001193125-15-375655:8k_2_02:28]
Net Income and EPS
— On a non-GAAP basis, net income was $3.0 billion, an increase of 8%, and EPS was $0.59, an increase of 9%. On a GAAP basis, net income was $2.4 billion and EPS was $0.48.

[0001193125-15-375655:8k_2_02:29]
Cash Flow from Operating Activities — was $2.8 billion an increase of 11% compared with $2.5 billion for the first quarter of fiscal 2015.

[0001193125-15-375655:8k_2_02:30]
Cash and Cash Equivalents and Investments — were $59.1 billion at the end of the first quarter of fiscal 2016, compared
with $60.4 billion at the end of fiscal 2015. The total cash and cash equivalents and investments available in the United States at the end of the first quarter of fiscal 2016 was $5.0 billion.

[0001193125-15-375655:8k_2_02:31]
Deferred Revenue — was $15.2 billion, up 10% in total, with deferred product revenue up 16%, driven largely by subscription based and
software offerings, and deferred service revenue up 7%. Cisco continued to build a greater mix of recurring revenue as reflected in deferred revenue.

[0001193125-15-375655:8k_2_02:32]
Days Sales Outstanding in Accounts Receivable (DSO) — was 34 days at the end of the first quarter of fiscal 2016, compared to 38 days at
the end of the fourth quarter of fiscal 2015.

[0001193125-15-375655:8k_2_02:33]
Capital Allocation

[0001193125-15-375655:8k_2_02:34]
In the first quarter of fiscal 2016, Cisco declared and paid a cash dividend of $0.21 per common share, or $1.1 billion. For the first quarter of fiscal 2016,
Cisco repurchased approximately 45 million shares of common stock under its stock repurchase program at an average price of $26.83 per share for an aggregate purchase price of $1.2 billion.

[0001193125-15-375655:8k_2_02:35]
As of October 24, 2015, Cisco had repurchased and retired 4.5 billion shares of Cisco common stock at an average price of $20.92 per share for an
aggregate purchase price of approximately $93.9 billion since the inception of the stock repurchase program. The remaining authorized amount for stock repurchases under this program is approximately $3.1 billion with no termination date.

[0001193125-15-375655:8k_2_02:36]
“We delivered a strong first quarter as we executed on our financial model of driving profitable growth, managing our portfolio and delivering
shareholder value,” said Kelly Kramer, Cisco executive vice president and chief financial officer. “Despite a challenging environment, we are executing very well and making the right investments that position us for future growth. We are
continuing our commitment to shareholders as we returned $2.3 billion of our free cash flow back through dividends and share repurchases in Q1.”

[0001193125-15-375655:8k_2_02:37]
Acquisitions

[0001193125-15-375655:8k_2_02:38]
During the first quarter of fiscal 2016,
Cisco completed the acquisitions of OpenDNS, MaintenanceNet, and Pawaa Software to further complement its security, services, software, and cloud offerings. These moves are consistent with Cisco’s strategy of increasing innovation and R&D
investment in growth areas. Cisco also recently announced the acquisitions of Portcullis, ParStream, Lancope, and 1 Mainstream in the security, data analytics and video areas, all of which are expected to close in the second quarter of fiscal 2016.

[0001193125-15-375655:8k_2_02:39]
2

[0001193125-15-375655:8k_2_02:40]
Business Outlook for the Second Quarter of Fiscal Year 2016

[0001193125-15-375655:8k_2_02:41]
In the fourth quarter of fiscal 2015, Cisco announced an agreement to sell the Client Premises Equipment portion of its Service Provider Video Connected
Devices business (CPE business) to Technicolor. The transaction is currently going through regulatory approval and Cisco is working to close it during the second quarter of fiscal 2016. In order to provide a clear view of Cisco’s continuing
expected financial performance, the guidance for the second quarter of fiscal 2016 is normalized to exclude the CPE business for both the second quarter of fiscal 2016 and the second quarter of fiscal 2015. The corresponding revenue in the
second quarter of fiscal 2015 for the CPE business was $361 million.

[0001193125-15-375655:8k_2_02:42]
Cisco expects to achieve the following results for the second quarter of fiscal year
2016:

[0001193125-15-375655:8k_2_02:43]
| Q2 2016 (normalized to exclude SP Video CPE business) |  |  |
| Revenue |  | 0% - 2% growth Y/Y |
| Non-GAAP gross margin rate |  | 62% - 63% |
| Non-GAAP operating margin rate |  | 28.5% - 29.5% |
| Non-GAAP tax provision rate |  | 23% |
| Non-GAAP EPS |  | $0.53 - $0.55 |

[0001193125-15-375655:8k_2_02:44]
The non-GAAP tax provision rate does not include any effects of a potential reinstatement of the U.S. federal R&D tax
credit. If the U.S. federal R&D tax credit is reinstated, Cisco would reflect that benefit in the effective tax rate.

[0001193125-15-375655:8k_2_02:45]
Cisco estimates that GAAP EPS
will be lower than non-GAAP EPS by $0.10 to $0.14 cents per share in the second quarter of fiscal 2016 as follows:

[0001193125-15-375655:8k_2_02:46]
| Q2 2016 |  |  |  |
| Share-based compensation expense |  | $ | 0.05 - $0.06 |  |
| Amortization of purchased intangible assets and other acquisition-related/divestiture costs |  |  | 0.04 - 0.06 |  |
| Subtotal |  |  | 0.09 - 0.12 |  |
| Restructuring and other charges |  |  | 0.01 - 0.02 |  |
| Total |  | $ | 0.10 - $0.14 |  |

[0001193125-15-375655:8k_2_02:47]
Share-based compensation expense is expected to impact Cisco’s results of operations in similar proportions as the first
quarter of fiscal 2016. Amortization of purchased intangible assets, and other acquisition-related/divestiture costs will be reported as GAAP operating expenses, cost of sales, or other income/(loss) as applicable.

[0001193125-15-375655:8k_2_02:48]
The range for restructuring and other charges includes a pretax charge of up to $100 million as a result of the restructuring that Cisco announced in August
2014. During the first quarter of fiscal 2016, Cisco recognized pretax restructuring charges of $141 million to the GAAP financial statements related to these actions and expects that the total charges related to these actions will be approximately
$700 million for this plan.

[0001193125-15-375655:8k_2_02:49]
Except as noted above, this guidance does not include the effects of the divestiture of the CPE business, and any future
acquisitions/divestitures, asset impairments, restructurings, and tax or other events, which may or may not be significant unless specifically stated.

[0001193125-15-375655:8k_2_02:50]
Editor’s Notes:

[0001193125-15-375655:8k_2_02:51]
|  | • |  | Q1 fiscal year 2016 conference call to discuss Cisco’s results along with its business outlook will be held on Thursday, November 12, 2015 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-15-375655:8k_2_02:52]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, November 12, 2015 to 4:00 p.m. Pacific Time, November 20, 2015 at 1-800-835-5808 (United States) or 1-203-369-3353 (international). The replay will also be available via webcast from November 12, 2015 through January 15, 2016 on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-15-375655:8k_2_02:53]
3

[0001193125-15-375655:8k_2_02:54]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, November 12, 2015. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-15-375655:8k_2_02:55]
4

[0001193125-15-375655:8k_2_02:56]
CISCO SYSTEMS, INC.

[0001193125-15-375655:8k_2_02:57]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-15-375655:8k_2_02:58]
(In millions, except per-share amounts)

[0001193125-15-375655:8k_2_02:59]
(Unaudited)

[0001193125-15-375655:8k_2_02:60]
|  |  | Three Months Ended |  |
|  |  | October 24,2015 |  |  | October 25,2014 |  |
| REVENUE: |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,844 |  |  | $ | 9,435 |  |
| Service |  |  | 2,838 |  |  |  | 2,810 |  |
| Total revenue |  |  | 12,682 |  |  |  | 12,245 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |
| Product |  |  | 3,853 |  |  |  | 3,919 |  |
| Service |  |  | 997 |  |  |  | 993 |  |
| Total cost of sales |  |  | 4,850 |  |  |  | 4,912 |  |
| GROSS MARGIN |  |  | 7,832 |  |  |  | 7,333 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,560 |  |  |  | 1,583 |  |
| Sales and marketing |  |  | 2,443 |  |  |  | 2,515 |  |
| General and administrative |  |  | 539 |  |  |  | 504 |  |
| Amortization of purchased intangible assets |  |  | 69 |  |  |  | 71 |  |
| Restructuring and other charges |  |  | 142 |  |  |  | 318 |  |
| Total operating expenses |  |  | 4,753 |  |  |  | 4,991 |  |
| OPERATING INCOME |  |  | 3,079 |  |  |  | 2,342 |  |
| Interest income |  |  | 225 |  |  |  | 179 |  |
| Interest expense |  |  | (159 | ) |  |  | (139 | ) |
| Other income (loss), net |  |  | (8 | ) |  |  | (22 | ) |
| Interest and other income (loss), net |  |  | 58 |  |  |  | 18 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,137 |  |  |  | 2,360 |  |
| Provision for income taxes |  |  | 707 |  |  |  | 532 |  |
| NET INCOME |  | $ | 2,430 |  |  | $ | 1,828 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.48 |  |  | $ | 0.36 |  |
| Diluted |  | $ | 0.48 |  |  | $ | 0.35 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,080 |  |  |  | 5,112 |  |
| Diluted |  |  | 5,113 |  |  |  | 5,156 |  |
| Cash dividends declared per common share |  | $ | 0.21 |  |  | $ | 0.19 |  |

[0001193125-15-375655:8k_2_02:61]
5

[0001193125-15-375655:8k_2_02:62]
CISCO SYSTEMS, INC.

[0001193125-15-375655:8k_2_02:63]
RECONCILIATION OF GAAP TO NON-GAAP NET INCOME

[0001193125-15-375655:8k_2_02:64]
(In millions, except per-share amounts)

[0001193125-15-375655:8k_2_02:65]
|  |  | Three Months Ended |  |
|  |  | October 24,2015 |  |  | October 25,2014 |  |
| GAAP net income |  | $ | 2,430 |  |  | $ | 1,828 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 51 |  |  |  | 48 |  |
| Amortization of acquisition-related intangible assets |  |  | 128 |  |  |  | 181 |  |
| Rockstar patent portfolio charge |  |  | — |  |  |  | 188 |  |
| Significant asset impairments and restructurings |  |  | (1 | ) |  |  | — |  |
| Total adjustments to GAAP cost of sales |  |  | 178 |  |  |  | 417 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 310 |  |  |  | 325 |  |
| Amortization of acquisition-related intangible assets |  |  | 69 |  |  |  | 71 |  |
| Acquisition-related/divestiture costs |  |  | 91 |  |  |  | 101 |  |
| Significant asset impairments and restructurings |  |  | 142 |  |  |  | 318 |  |
| Total adjustments to GAAP operating expenses |  |  | 612 |  |  |  | 815 |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 790 |  |  |  | 1,232 |  |
| Income tax effect of non-GAAP adjustments |  |  | (196 | ) |  |  | (258 | ) |
| Non-GAAP net income |  | $ | 3,024 |  |  | $ | 2,802 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.48 |  |  | $ | 0.35 |  |
| Non-GAAP |  | $ | 0.59 |  |  | $ | 0.54 |  |

[0001193125-15-375655:8k_2_02:66]
6

[0001193125-15-375655:8k_2_02:67]
CISCO SYSTEMS, INC.

[0001193125-15-375655:8k_2_02:68]
REVENUE BY SEGMENT

[0001193125-15-375655:8k_2_02:69]
(In
millions, except percentages)

[0001193125-15-375655:8k_2_02:70]
|  |  | Three Months EndedOctober 24, 2015 |
| Revenue: |  | Amount |  |  | Y/Y % |
| Americas |  | $ | 7,799 |  |  | 4% |
| EMEA |  |  | 3,087 |  |  | 3% |
| APJC |  |  | 1,796 |  |  | 3% |
| Total |  | $ | 12,682 |  |  | 4% |

[0001193125-15-375655:8k_2_02:71]
CISCO SYSTEMS, INC.

[0001193125-15-375655:8k_2_02:72]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-15-375655:8k_2_02:73]
(In percentages)

[0001193125-15-375655:8k_2_02:74]
|  |  | Three Months Ended |
|  |  | October 24, 2015 |
| Gross Margin Percentage: |  |  |
| Americas |  | 63.5% |
| EMEA |  | 64.2% |
| APJC |  | 60.0% |

[0001193125-15-375655:8k_2_02:75]
CISCO SYSTEMS, INC.

[0001193125-15-375655:8k_2_02:76]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-15-375655:8k_2_02:77]
(In millions, except percentages)

[0001193125-15-375655:8k_2_02:78]
|  |  | Three Months Ended |  |
|  |  | October 24, 2015 |  |
| Revenue: |  | Amount |  |  | Y/Y % |  |
| Switching |  | $ | 4,022 |  |  |  | 5% |  |
| NGN Routing |  |  | 1,793 |  |  |  | (8)% |  |
| Collaboration |  |  | 1,115 |  |  |  | 17% |  |
| Data Center |  |  | 859 |  |  |  | 24% |  |
| Service Provider Video |  |  | 850 |  |  |  | (2)% |  |
| Wireless |  |  | 645 |  |  |  | 7% |  |
| Security |  |  | 485 |  |  |  | 7% |  |
| Other |  |  | 75 |  |  |  | 12% |  |
| Product |  |  | 9,844 |  |  |  | 4% |  |
| Service |  |  | 2,838 |  |  |  | 1% |  |
| Total |  | $ | 12,682 |  |  |  | 4% |  |

[0001193125-15-375655:8k_2_02:79]
7

[0001193125-15-375655:8k_2_02:80]
CISCO SYSTEMS, INC.

[0001193125-15-375655:8k_2_02:81]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-15-375655:8k_2_02:82]
(In millions)

[0001193125-15-375655:8k_2_02:83]
(Unaudited)

[0001193125-15-375655:8k_2_02:84]
|  |  | October 24,2015 |  |  | July 25,2015 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 5,758 |  |  | $ | 6,877 |  |
| Investments |  |  | 53,349 |  |  |  | 53,539 |  |
| Accounts receivable, net of allowance for doubtful accounts of $300 at October 24, 2015 and $302 at July 25, 2015 |  |  | 4,712 |  |  |  | 5,344 |  |
| Inventories |  |  | 1,482 |  |  |  | 1,627 |  |
| Financing receivables, net |  |  | 4,506 |  |  |  | 4,491 |  |
| Deferred tax assets |  |  | 2,706 |  |  |  | 2,915 |  |
| Other current assets |  |  | 1,433 |  |  |  | 1,490 |  |
| Total current assets |  |  | 73,946 |  |  |  | 76,283 |  |
| Property and equipment, net |  |  | 3,346 |  |  |  | 3,332 |  |
| Financing receivables, net |  |  | 4,037 |  |  |  | 3,858 |  |
| Goodwill |  |  | 24,882 |  |  |  | 24,469 |  |
| Purchased intangible assets, net |  |  | 2,292 |  |  |  | 2,376 |  |
| Other assets |  |  | 3,270 |  |  |  | 3,163 |  |
| TOTAL ASSETS |  | $ | 111,773 |  |  | $ | 113,481 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 3,027 |  |  | $ | 3,897 |  |
| Accounts payable |  |  | 1,119 |  |  |  | 1,104 |  |
| Income taxes payable |  |  | 122 |  |  |  | 62 |  |
| Accrued compensation |  |  | 2,611 |  |  |  | 3,049 |  |
| Deferred revenue |  |  | 9,821 |  |  |  | 9,824 |  |
| Other current liabilities |  |  | 5,400 |  |  |  | 5,687 |  |
| Total current liabilities |  |  | 22,100 |  |  |  | 23,623 |  |
| Long-term debt |  |  | 21,594 |  |  |  | 21,457 |  |
| Income taxes payable |  |  | 1,490 |  |  |  | 1,876 |  |
| Deferred revenue |  |  | 5,341 |  |  |  | 5,359 |  |
| Other long-term liabilities |  |  | 1,263 |  |  |  | 1,459 |  |
| Total liabilities |  |  | 51,788 |  |  |  | 53,774 |  |
| Total equity |  |  | 59,985 |  |  |  | 59,707 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 111,773 |  |  | $ | 113,481 |  |

[0001193125-15-375655:8k_2_02:85]
8

[0001193125-15-375655:8k_2_02:86]
CISCO SYSTEMS, INC.

[0001193125-15-375655:8k_2_02:87]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-15-375655:8k_2_02:88]
(In millions)

[0001193125-15-375655:8k_2_02:89]
(Unaudited)

[0001193125-15-375655:8k_2_02:90]
|  |  | Three Months Ended |  |
|  |  | October 24,2015 |  |  | October 25,2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 2,430 |  |  | $ | 1,828 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 507 |  |  |  | 599 |  |
| Share-based compensation expense |  |  | 376 |  |  |  | 369 |  |
| Provision for receivables |  |  | 7 |  |  |  | 43 |  |
| Deferred income taxes |  |  | 193 |  |  |  | 236 |  |
| Excess tax benefits from share-based compensation |  |  | (73 | ) |  |  | (71 | ) |
| (Gains) losses on investments and other, net |  |  | (4 | ) |  |  | 29 |  |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 631 |  |  |  | 723 |  |
| Inventories |  |  | 130 |  |  |  | (107 | ) |
| Financing receivables |  |  | (206 | ) |  |  | (2 | ) |
| Other assets |  |  | 129 |  |  |  | 2 |  |
| Accounts payable |  |  | 4 |  |  |  | (5 | ) |
| Income taxes, net |  |  | (315 | ) |  |  | (398 | ) |
| Accrued compensation |  |  | (434 | ) |  |  | (495 | ) |
| Deferred revenue |  |  | (19 | ) |  |  | (328 | ) |
| Other liabilities |  |  | (590 | ) |  |  | 68 |  |
| Net cash provided by operating activities |  |  | 2,766 |  |  |  | 2,491 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (10,823 | ) |  |  | (9,761 | ) |
| Proceeds from sales of investments |  |  | 6,675 |  |  |  | 3,450 |  |
| Proceeds from maturities of investments |  |  | 4,133 |  |  |  | 3,906 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (614 | ) |  |  | (184 | ) |
| Purchases of investments in privately held companies |  |  | (78 | ) |  |  | (50 | ) |
| Return of investments in privately held companies |  |  | 24 |  |  |  | 42 |  |
| Acquisition of property and equipment |  |  | (262 | ) |  |  | (285 | ) |
| Proceeds from sales of property and equipment |  |  | 6 |  |  |  | 3 |  |
| Other |  |  | (11 | ) |  |  | 2 |  |
| Net cash used in investing activities |  |  | (950 | ) |  |  | (2,877 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 385 |  |  |  | 353 |  |
| Repurchases of common stock—repurchase program |  |  | (1,210 | ) |  |  | (1,088 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (382 | ) |  |  | (342 | ) |
| Short-term borrowings, original maturities less than 90 days, net |  |  | (4 | ) |  |  | (4 | ) |
| Repayments of debt |  |  | (852 | ) |  |  | (3 | ) |
| Excess tax benefits from share-based compensation |  |  | 73 |  |  |  | 71 |  |
| Dividends paid |  |  | (1,068 | ) |  |  | (973 | ) |
| Other |  |  | 123 |  |  |  | 33 |  |
| Net cash used in financing activities |  |  | (2,935 | ) |  |  | (1,953 | ) |
| Net decrease in cash and cash equivalents |  |  | (1,119 | ) |  |  | (2,339 | ) |
| Cash and cash equivalents, beginning of period |  |  | 6,877 |  |  |  | 6,726 |  |
| Cash and cash equivalents, end of period |  | $ | 5,758 |  |  | $ | 4,387 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 264 |  |  | $ | 263 |  |
| Cash paid for income taxes, net |  | $ | 828 |  |  | $ | 694 |  |

[0001193125-15-375655:8k_2_02:91]
Certain reclassifications have been made to prior year amounts to conform to the current year’s
presentation.

[0001193125-15-375655:8k_2_02:92]
CISCO SYSTEMS, INC.

[0001193125-15-375655:8k_2_02:93]
DEFERRED REVENUE

[0001193125-15-375655:8k_2_02:94]
(In
millions)

[0001193125-15-375655:8k_2_02:95]
|  |  | October 24,2015 |  |  | July 25,2015 |  |  | October 25,2014 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 9,689 |  |  | $ | 9,757 |  |  | $ | 9,029 |  |
| Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  |  | 4,888 |  |  |  | 4,766 |  |  |  | 4,056 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  |  | 585 |  |  |  | 660 |  |  |  | 659 |  |
| Total product deferred revenue |  |  | 5,473 |  |  |  | 5,426 |  |  |  | 4,715 |  |
| Total |  | $ | 15,162 |  |  | $ | 15,183 |  |  | $ | 13,744 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 9,821 |  |  | $ | 9,824 |  |  | $ | 9,449 |  |
| Noncurrent |  |  | 5,341 |  |  |  | 5,359 |  |  |  | 4,295 |  |
| Total |  | $ | 15,162 |  |  | $ | 15,183 |  |  | $ | 13,744 |  |

[0001193125-15-375655:8k_2_02:96]
CISCO SYSTEMS, INC.

[0001193125-15-375655:8k_2_02:97]
INVENTORIES AND INVENTORY TURNS

[0001193125-15-375655:8k_2_02:98]
(In millions, except annualized inventory turns)

[0001193125-15-375655:8k_2_02:99]
|  |  | October 24,2015 |  |  | July 25,2015 |  |  | October 25,2014 |  |
| Inventories: |  |  |  |  |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 107 |  |  | $ | 114 |  |  | $ | 173 |  |
| Work in process |  |  | 1 |  |  |  | 2 |  |  |  | 3 |  |
| Finished goods: |  |  |  |  |  |  |  |  |  |  |  |  |
| Distributor inventory and deferred cost of sales |  |  | 631 |  |  |  | 610 |  |  |  | 654 |  |
| Manufactured finished goods |  |  | 464 |  |  |  | 593 |  |  |  | 535 |  |
| Total finished goods |  |  | 1,095 |  |  |  | 1,203 |  |  |  | 1,189 |  |
| Service-related spares |  |  | 240 |  |  |  | 258 |  |  |  | 275 |  |
| Demonstration systems |  |  | 39 |  |  |  | 50 |  |  |  | 36 |  |
| Total |  | $ | 1,482 |  |  | $ | 1,627 |  |  | $ | 1,676 |  |
| Annualized inventory turns - GAAP |  |  | 12.5 |  |  |  | 12.1 |  |  |  | 12.0 |  |
| Cost of sales adjustments |  |  | (0.5 | ) |  |  | (0.6 | ) |  |  | (1.0 | ) |
| Annualized inventory turns - non-GAAP |  |  | 12.0 |  |  |  | 11.5 |  |  |  | 11.0 |  |

[0001193125-15-375655:8k_2_02:100]
10

[0001193125-15-375655:8k_2_02:101]
CISCO SYSTEMS, INC.

[0001193125-15-375655:8k_2_02:102]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-15-375655:8k_2_02:103]
(In millions, except per-share amounts)

[0001193125-15-375655:8k_2_02:104]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| October 24, 2015 |  | $ | 0.21 |  |  | $ | 1,068 |  |  |  | 45 |  |  | $ | 26.83 |  |  | $ | 1,207 |  |  | $ | 2,275 |  |
| Fiscal 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 25, 2015 |  | $ | 0.21 |  |  | $ | 1,069 |  |  |  | 35 |  |  | $ | 28.62 |  |  | $ | 1,005 |  |  | $ | 2,074 |  |
| April 25, 2015 |  |  | 0.21 |  |  |  | 1,070 |  |  |  | 35 |  |  |  | 28.39 |  |  |  | 1,008 |  |  |  | 2,078 |  |
| January 24, 2015 |  |  | 0.19 |  |  |  | 974 |  |  |  | 44 |  |  |  | 27.63 |  |  |  | 1,208 |  |  |  | 2,182 |  |
| October 25, 2014 |  |  | 0.19 |  |  |  | 973 |  |  |  | 41 |  |  |  | 24.58 |  |  |  | 1,013 |  |  |  | 1,986 |  |
| Total |  | $ | 0.80 |  |  | $ | 4,086 |  |  |  | 155 |  |  | $ | 27.22 |  |  | $ | 4,234 |  |  | $ | 8,320 |  |

[0001193125-15-375655:8k_2_02:105]
CISCO SYSTEMS, INC.

[0001193125-15-375655:8k_2_02:106]
FREE CASH FLOW

[0001193125-15-375655:8k_2_02:107]
(In
millions)

[0001193125-15-375655:8k_2_02:108]
|  |  | Three Months Ended |  |
|  |  | October 24, 2015 |  |  | October 25, 2014 |  |
| Net cash provided by operating activities |  | $ | 2,766 |  |  | $ | 2,491 |  |
| Acquisition of property and equipment |  |  | (262 | ) |  |  | (285 | ) |
| Free cash flow |  | $ | 2,504 |  |  | $ | 2,206 |  |

[0001193125-15-375655:8k_2_02:109]
CISCO SYSTEMS, INC.

[0001193125-15-375655:8k_2_02:110]
SUPPLEMENTARY INFORMATION - RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-15-375655:8k_2_02:111]
GROSS MARGINS, OPERATING EXPENSES, AND OPERATING MARGINS

[0001193125-15-375655:8k_2_02:112]
(In millions, except percentages)

[0001193125-15-375655:8k_2_02:113]
|  |  | Three Months EndedOctober 24, 2015 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,991 |  |  | $ | 1,841 |  |  | $ | 7,832 |  |  | $ | 4,753 |  |  |  | (5 | )% |  | $ | 3,079 |  |  |  | 31 | % |
| GAAP (% of revenue) |  |  | 60.9 | % |  |  | 64.9 | % |  |  | 61.8 | % |  |  | 37.5 | % |  |  |  |  |  |  | 24.3 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 13 |  |  |  | 38 |  |  |  | 51 |  |  |  | 310 |  |  |  |  |  |  |  | 361 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 128 |  |  |  | — |  |  |  | 128 |  |  |  | 69 |  |  |  |  |  |  |  | 197 |  |  |  |  |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 91 |  |  |  |  |  |  |  | 91 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | 142 |  |  |  |  |  |  |  | 141 |  |  |  |  |  |
| Non-GAAP amount |  | $ | 6,131 |  |  | $ | 1,879 |  |  | $ | 8,010 |  |  | $ | 4,141 |  |  |  | (1 | )% |  | $ | 3,869 |  |  |  | 8 | % |
| Non-GAAP (% of revenue) |  |  | 62.3 | % |  |  | 66.2 | % |  |  | 63.2 | % |  |  | 32.7 | % |  |  |  |  |  |  | 30.5 | % |  |  |  |  |

[0001193125-15-375655:8k_2_02:114]
EFFECTIVE TAX RATE

[0001193125-15-375655:8k_2_02:115]
(In percentages)

[0001193125-15-375655:8k_2_02:116]
|  |  | Three Months Ended |  |
|  |  | October 24, 2015 |  |  | October 25, 2014 |  |
| GAAP effective tax rate |  |  | 22.5 | % |  |  | 22.5 | % |
| Tax effect of non-GAAP adjustments to net income |  |  | 0.5 | % |  |  | (0.5 | )% |
| Non-GAAP effective tax rate |  |  | 23.0 | % |  |  | 22.0 | % |

[0001193125-15-375655:8k_2_02:117]
COST OF SALES USED IN INVENTORY TURNS

[0001193125-15-375655:8k_2_02:118]
(In millions)

[0001193125-15-375655:8k_2_02:119]
|  |  | Three Months Ended |  |
|  |  | October 24,2015 |  |  | July 25,2015 |  |  | October 25,2014 |  |
| GAAP cost of sales |  | $ | 4,850 |  |  | $ | 5,110 |  |  | $ | 4,912 |  |
| Cost of sales adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | (51 | ) |  |  | (58 | ) |  |  | (48 | ) |
| Amortization of acquisition-related intangible assets |  |  | (128 | ) |  |  | (179 | ) |  |  | (181 | ) |
| Rockstar patent portfolio charge |  |  | — |  |  |  | — |  |  |  | (188 | ) |
| Significant asset impairments and restructurings |  |  | 1 |  |  |  | (5 | ) |  |  | — |  |
| Non-GAAP cost of sales |  | $ | 4,672 |  |  | $ | 4,868 |  |  | $ | 4,495 |  |

[0001193125-15-375655:8k_2_02:120]
Forward Looking Statements and Non-GAAP Information

[0001193125-15-375655:8k_2_02:121]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax
rates, non-GAAP net income per share data, non-GAAP inventory turns and free cash flow for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-15-375655:8k_2_02:122]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles and
may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do
not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding
GAAP measures.

[0001193125-15-375655:8k_2_02:123]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP measures, provides useful
information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations. In addition, Cisco believes that the presentation of non-GAAP inventory turns
provides useful information to investors and management regarding financial and business trends relating to inventory management based on the operating activities of the periods presented. Cisco believes that the presentation of free cash flow,
which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because of its intent to return a stated
percentage of free cash flow to shareholders in the form of dividends and stock repurchases. Cisco further

[0001193125-15-375655:8k_2_02:124]
13

[0001193125-15-375655:8k_2_02:125]
regards free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay
dividends on its common stock, after deducting capital investments.

[0001193125-15-375655:8k_2_02:126]
For its internal budgeting process, Cisco’s management uses financial statements
that do not include, when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, impact to cost of sales from purchase accounting adjustments to inventory, acquisition-related/divestiture costs,
significant asset impairments and restructurings, significant litigation and other contingencies, the income tax effects of the foregoing, and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to
the corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be
other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the
Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-15-375655:8k_2_02:127]
About Cisco

[0001193125-15-375655:8k_2_02:128]
Cisco (NASDAQ: CSCO) is the worldwide technology leader that has been making the Internet work since 1984. Our people, products, and partners help society
securely connect and seize tomorrow’s digital opportunity today. Discover more at thenetwork.cisco.com and follow us on Twitter at @Cisco.

[0001193125-15-375655:8k_2_02:129]
Copyright © 2015 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are
trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their
respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.
