# CSCO MD&A — 0000858877-15-000073


## mdna

[0000858877-15-000073:mdna:1]
[same as prior period, unchanged from 0000858877-15-000051:mdna:1]

[0000858877-15-000073:mdna:2]
[same as prior period, unchanged from 0000858877-15-000051:mdna:2]

[0000858877-15-000073:mdna:3]
[same as prior period, unchanged from 0000858877-15-000051:mdna:3]

[0000858877-15-000073:mdna:4]
Cisco designs and sells broad lines of products, provides services and delivers integrated solutions to develop and connect networks around the world, building the Internet.  Over the last 30-plus years, we have been the world’s leader in connecting people, things and technologies - to each other and to the Internet - realizing our vision of changing the way the world works, lives, plays and learns.

[0000858877-15-000073:mdna:5]
Today, we have over 70,000 employees in over 400 offices worldwide who design, produce, sell, and deliver integrated products, services, and solutions. Over time, we have expanded to new markets that are a natural extension of our core networking business, as the network has become the platform for automating, orchestrating, integrating, and delivering an ever-increasing array of information technology (IT)–based products and services.

[0000858877-15-000073:mdna:6]
[same as prior period, unchanged from 0000858877-15-000051:mdna:5]

[0000858877-15-000073:mdna:7]
|  | Three Months Ended |  |
|  | October 24, 2015 |  | October 25, 2014 |  | Variance |  |
| Revenue | $ | 12,682 |  |  | $ | 12,245 |  |  | 3.6 | % |  |
| Gross margin percentage | 61.8 | % |  | 59.9 | % |  | 1.9 |  | pts |
| Research and development | $ | 1,560 |  |  | $ | 1,583 |  |  | (1.5 | )% |  |
| Sales and marketing | $ | 2,443 |  |  | $ | 2,515 |  |  | (2.9 | )% |  |
| General and administrative | $ | 539 |  |  | $ | 504 |  |  | 6.9 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,542 |  |  | $ | 4,602 |  |  | (1.3 | )% |  |
| Total as a percentage of revenue | 35.8 | % |  | 37.6 | % |  | (1.8 | ) | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 69 |  |  | $ | 71 |  |  | (2.8 | )% |  |
| Restructuring and other charges included in operating expenses | $ | 142 |  |  | $ | 318 |  |  | (55.3 | )% |  |
| Operating income as a percentage of revenue | 24.3 | % |  | 19.1 | % |  | 5.2 |  | pts |
| Income tax percentage | 22.5 | % |  | 22.5 | % |  | — |  | pts |
| Net income | $ | 2,430 |  |  | $ | 1,828 |  |  | 32.9 | % |  |
| Net income as a percentage of revenue | 19.2 | % |  | 14.9 | % |  | 4.3 |  | pts |
| Earnings per share—diluted | $ | 0.48 |  |  | $ | 0.35 |  |  | 37.1 | % |  |

[0000858877-15-000073:mdna:8]
[same as prior period, unchanged from 0000858877-15-000051:mdna:7]

[0000858877-15-000073:mdna:9]
[same as prior period, unchanged from 0000858877-15-000051:mdna:8]

[0000858877-15-000073:mdna:10]
Three Months Ended October 24, 2015 Compared with Three Months Ended October 25, 2014

[0000858877-15-000073:mdna:11]
In the first quarter of fiscal 2016, revenue increased by 4% as compared with the first quarter of fiscal 2015. Within the total revenue change, product revenue increased 4% while service revenue increased 1%. Total gross margin increased by 1.9 percentage points, driven in large part by the $188 million charge to product cost of sales recorded in the first quarter of fiscal 2015 related to the Rockstar patent portfolio. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 1.8 percentage points. Operating income as a percentage of revenue increased by 5.2 percentage points, driven by the factors discussed above, as well as a decrease in restructuring and other charges. Diluted earnings per share increased by 37% from the prior year, driven by a 33% increase in net income.

[0000858877-15-000073:mdna:12]
In the first quarter of fiscal 2016, total revenue increased by $0.4 billion compared with the first quarter of fiscal 2015. Revenue from the Americas increased by $0.3 billion, driven in part by higher product revenue in the United States. EMEA revenue increased $0.1 billion, led by higher product revenue in the United Kingdom. Revenue in our APJC segment increased $0.1 billion, led by product revenue growth in China.  We saw improvements in our revenue from many emerging countries, and in particular we experienced increased product revenue in the emerging countries of Mexico, China and India.  These increases were partially offset by decreased product revenue in Russia and Brazil, as the “BRICM” countries experienced, in the aggregate, product revenue growth of 4%.

[0000858877-15-000073:mdna:13]
From a customer market standpoint, in the first quarter of fiscal 2016 we experienced solid product revenue growth in the commercial, public sector and enterprise markets.  Although our revenue in the enterprise market increased, we experienced declining business momentum in the enterprise market, driven by weakness outside of the United States largely due to, we believe, the uncertainty of the macro environment and currency impacts.  Conversely, while our revenue declined in the service provider market, during the first quarter of fiscal 2016, we experienced some positive business momentum in this customer market.

[0000858877-15-000073:mdna:14]
During the prior two fiscal years we encountered challenges in the service provider market and certain emerging countries. Although we saw positive business momentum in these areas during the first quarter of fiscal 2016, we continue to assess the sustainability of improvements in these areas.

[0000858877-15-000073:mdna:15]
From a product category perspective, the product revenue increase of 4% year-over-year was led by product revenue growth in Data Center and Collaboration products which grew 24% and 17%, respectively.  We also experienced an increase in revenue from our core Switching products which grew 5%. Our other major product categories experienced revenue changes ranging from a 7% increase in each of Security and Wireless to an 8% decrease in NGN Routing. Service revenue increased by 1% year over year, reflecting slower growth compared to prior quarters.

[0000858877-15-000073:mdna:16]
40

[0000858877-15-000073:mdna:17]
[same as prior period, unchanged from 0000858877-15-000051:mdna:18]

[0000858877-15-000073:mdna:18]
[same as prior period, unchanged from 0000858877-15-000051:mdna:19]

[0000858877-15-000073:mdna:19]
[same as prior period, unchanged from 0000858877-15-000051:mdna:20]

[0000858877-15-000073:mdna:20]
We see our customers, in every industry, increasingly using technology—and, specifically, the network—to grow their business, drive efficiencies, and try to gain a competitive advantage.  In this increasingly digital world, data is the most strategic asset and is increasingly distributed across every organization and ecosystem—on customer premises, at the edge of the network, and in the cloud.  The network also plays an increasingly important role enabling our customers to aggregate, automate, and draw insights from this highly distributed data where there is a premium on security and speed. This is driving them to adopt entirely new IT architectures and organizational structures. We understand how technology can deliver the outcomes our customers want to achieve, and our strategy is to lead our customers in their digital transition with solutions including pervasive, industry-leading security that intelligently connect nearly everything that can be connected.

[0000858877-15-000073:mdna:21]
To deliver on our strategy, we are focused on providing highly secure, automated and intelligent solutions built on infrastructure that connects data that is highly distributed (globally dispersed across organizations).  Together with our ecosystem of partners and developers, we aim to provide the technology, services, and solutions that we believe will enable our customers to gain insight and advantage from this distributed data with scale, security and agility.

[0000858877-15-000073:mdna:22]
For a full discussion of our strategy and focus areas, see Item 1. Business in our Annual Report on Form 10-K for the year ended July 25, 2015.

[0000858877-15-000073:mdna:23]
[same as prior period, unchanged from 0000858877-15-000051:mdna:25]

[0000858877-15-000073:mdna:24]
The following is a summary of our other key financial measures for the first quarter of fiscal 2016 (in millions, except days sales outstanding in accounts receivable (DSO) and annualized inventory turns):

[0000858877-15-000073:mdna:25]
|  |  | October 24, 2015 |  | July 25, 2015 |
| Cash and cash equivalents and investments |  | $ | 59,107 |  |  | $ | 60,416 |  |
| Deferred revenue |  | $ | 15,162 |  |  | $ | 15,183 |  |
| DSO |  | 34 days |  |  | 38 days |  |
| Inventories |  | $ | 1,482 |  |  | $ | 1,627 |  |
| Annualized inventory turns |  | 12.5 |  |  | 12.1 |  |

[0000858877-15-000073:mdna:26]
|  |  | Three Months Ended |
|  |  | October 24, 2015 |  | October 25, 2014 |
| Cash provided by operating activities |  | $ | 2,766 |  |  | $ | 2,491 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 1,207 |  |  | $ | 1,013 |  |
| Dividends |  | $ | 1,068 |  |  | $ | 973 |  |

[0000858877-15-000073:mdna:27]
41

[0000858877-15-000073:mdna:28]
[same as prior period, unchanged from 0000858877-15-000051:mdna:29]

[0000858877-15-000073:mdna:29]
[same as prior period, unchanged from 0000858877-15-000051:mdna:30]

[0000858877-15-000073:mdna:30]
[same as prior period, unchanged from 0000858877-15-000051:mdna:31]

[0000858877-15-000073:mdna:31]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes.  Note 2 to the Consolidated Financial Statements in our Annual Report on Form 10-K for the year ended July 25, 2015, as updated as applicable in Note 2 to the Consolidated Financial Statements herein, describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements.  The accounting policies described below are significantly affected by critical accounting estimates.  Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-15-000073:mdna:32]
[same as prior period, unchanged from 0000858877-15-000051:mdna:33]

[0000858877-15-000073:mdna:33]
[same as prior period, unchanged from 0000858877-15-000051:mdna:34]

[0000858877-15-000073:mdna:34]
[same as prior period, unchanged from 0000858877-15-000051:mdna:35]

[0000858877-15-000073:mdna:35]
[same as prior period, unchanged from 0000858877-15-000051:mdna:36]

[0000858877-15-000073:mdna:36]
[same as prior period, unchanged from 0000858877-15-000051:mdna:37]

[0000858877-15-000073:mdna:37]
[same as prior period, unchanged from 0000858877-15-000051:mdna:38]

[0000858877-15-000073:mdna:38]
[same as prior period, unchanged from 0000858877-15-000051:mdna:39]

[0000858877-15-000073:mdna:39]
[same as prior period, unchanged from 0000858877-15-000051:mdna:40]

[0000858877-15-000073:mdna:40]
[same as prior period, unchanged from 0000858877-15-000051:mdna:41]

[0000858877-15-000073:mdna:41]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during the first quarter of fiscal 2016, nor do we currently expect a material impact in the next 12 months on our revenue recognition due to any changes in our VSOE, TPE, or ESP.

[0000858877-15-000073:mdna:42]
[same as prior period, unchanged from 0000858877-15-000051:mdna:43]

[0000858877-15-000073:mdna:43]
[same as prior period, unchanged from 0000858877-15-000051:mdna:44]

[0000858877-15-000073:mdna:44]
Revenue deferrals relate to the timing of revenue recognition for specific transactions based on financing arrangements, service, support, and other factors. Financing arrangements may include sales-type, direct-financing, and operating leases, loans, and guarantees of third-party financing. Our deferred revenue for products was $5.5 billion and $5.4 billion as of October 24, 2015 and July 25, 2015, respectively. Technical support services revenue is deferred and recognized ratably over the period during which the services are to be performed, which typically is from one to three years. Advanced services revenue is recognized upon delivery or completion of performance milestones. Our deferred revenue for services was $9.7 billion and $9.8 billion as of October 24, 2015 and July 25, 2015, respectively.

[0000858877-15-000073:mdna:45]
[same as prior period, unchanged from 0000858877-15-000051:mdna:46]

[0000858877-15-000073:mdna:46]
[same as prior period, unchanged from 0000858877-15-000051:mdna:47]

[0000858877-15-000073:mdna:47]
[same as prior period, unchanged from 0000858877-15-000051:mdna:48]

[0000858877-15-000073:mdna:48]
|  |  | October 24, 2015 |  | July 25, 2015 |
| Allowance for doubtful accounts |  | $ | 300 |  |  | $ | 302 |  |
| Percentage of gross accounts receivable |  | 6.0 | % |  | 5.4 | % |
| Allowance for credit loss—lease receivables |  | $ | 255 |  |  | $ | 259 |  |
| Percentage of gross lease receivables(1) |  | 7.2 | % |  | 7.2 | % |
| Allowance for credit loss—loan receivables |  | $ | 90 |  |  | $ | 87 |  |
| Percentage of gross loan receivables |  | 4.6 | % |  | 4.9 | % |

[0000858877-15-000073:mdna:49]
(1) Calculated as allowance for credit loss on lease receivables as a percentage of gross lease receivables and residual value before unearned income.

[0000858877-15-000073:mdna:50]
[same as prior period, unchanged from 0000858877-15-000051:mdna:51]

[0000858877-15-000073:mdna:51]
[same as prior period, unchanged from 0000858877-15-000051:mdna:52]

[0000858877-15-000073:mdna:52]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of October 24, 2015 and July 25, 2015 was $127 million and $129 million, respectively, and was recorded as a reduction of our accounts receivable.  If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-15-000073:mdna:53]
[same as prior period, unchanged from 0000858877-15-000051:mdna:55]

[0000858877-15-000073:mdna:54]
[same as prior period, unchanged from 0000858877-15-000051:mdna:56]

[0000858877-15-000073:mdna:55]
[same as prior period, unchanged from 0000858877-15-000051:mdna:57]

[0000858877-15-000073:mdna:56]
Our inventory balance was $1.5 billion and $1.6 billion as of October 24, 2015 and July 25, 2015, respectively. Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and market, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-15-000073:mdna:57]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 24, 2015, the liability for these purchase commitments was $178 million, compared with $156 million as of July 25, 2015, and was included in other current liabilities.

[0000858877-15-000073:mdna:58]
Our provision for inventory was $27 million and $11 million for the first quarter of fiscal 2016 and 2015, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $41 million and $32 million for the first quarter of fiscal 2016 and 2015, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence, particularly in light of current macroeconomic uncertainties and conditions and the resulting potential for changes in future demand forecast.

[0000858877-15-000073:mdna:59]
Loss Contingencies and Product Warranties

[0000858877-15-000073:mdna:60]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-15-000073:mdna:61]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-15-000073:mdna:62]
We have recorded a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. In February 2014, on the basis of the growing number of failures as described in Note 12 (f) to the Consolidated Financial Statements, we decided to expand our approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  During the third quarter of fiscal 2015, we recorded an adjustment to product cost of sales of $164 million to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products. Estimating this liability is complex and subjective, and if we experience changes in a number of underlying assumptions and estimates such as a change in claims compared with our expectations, or if the cost of servicing these claims is different than expected, our estimated liability may be impacted.

[0000858877-15-000073:mdna:63]
Our liability for product warranties, included in other current liabilities, was $433 million as of October 24, 2015, compared with $449 million as of July 25, 2015. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty. We accrue for warranty costs as part of our cost of sales based on associated material costs, technical support labor costs, and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends in the rate of customer cases and the cost to support the customer cases within the warranty period. Overhead cost is applied based on estimated time to support warranty activities.

[0000858877-15-000073:mdna:64]
The provision for product warranties during the first quarter of fiscal 2016 and 2015 was $150 million and $143 million, respectively. If we experience an increase in warranty claims compared with our historical experience, or if the cost of servicing warranty claims is greater than expected, our profitability could be adversely affected.

[0000858877-15-000073:mdna:65]
[same as prior period, unchanged from 0000858877-15-000051:mdna:17]

[0000858877-15-000073:mdna:66]
[same as prior period, unchanged from 0000858877-15-000051:mdna:67]

[0000858877-15-000073:mdna:67]
[same as prior period, unchanged from 0000858877-15-000051:mdna:68]

[0000858877-15-000073:mdna:68]
[same as prior period, unchanged from 0000858877-15-000051:mdna:69]

[0000858877-15-000073:mdna:69]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $53.3 billion as of October 24, 2015, compared with $53.5 billion as of July 25, 2015. Our fixed income investment portfolio as of October 24, 2015 consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-15-000073:mdna:70]
[same as prior period, unchanged from 0000858877-15-000051:mdna:71]

[0000858877-15-000073:mdna:71]
[same as prior period, unchanged from 0000858877-15-000051:mdna:72]

[0000858877-15-000073:mdna:72]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of October 24, 2015. Level 3 assets do not represent a significant portion of our total assets measured at fair value on a recurring basis as of October 24, 2015 and July 25, 2015.

[0000858877-15-000073:mdna:73]
[same as prior period, unchanged from 0000858877-15-000051:mdna:74]

[0000858877-15-000073:mdna:74]
[same as prior period, unchanged from 0000858877-15-000051:mdna:75]

[0000858877-15-000073:mdna:75]
[same as prior period, unchanged from 0000858877-15-000051:mdna:76]

[0000858877-15-000073:mdna:76]
[same as prior period, unchanged from 0000858877-15-000051:mdna:77]

[0000858877-15-000073:mdna:77]
There were no impairment charges on our investments in publicly traded equity securities and fixed income securities in the first quarters of fiscal 2016 and 2015. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-15-000073:mdna:78]
45

[0000858877-15-000073:mdna:79]
[same as prior period, unchanged from 0000858877-15-000051:mdna:79]

[0000858877-15-000073:mdna:80]
[same as prior period, unchanged from 0000858877-15-000051:mdna:80]

[0000858877-15-000073:mdna:81]
We also have investments in privately held companies, some of which are in the startup or development stages. Our investments in privately held companies as of October 24, 2015 were $928 million, compared with $897 million as of July 25, 2015, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize. Our impairment charges on investments in privately held companies were $17 million and $1 million for the first quarters of fiscal 2016 and 2015, respectively.

[0000858877-15-000073:mdna:82]
[same as prior period, unchanged from 0000858877-15-000051:mdna:82]

[0000858877-15-000073:mdna:83]
[same as prior period, unchanged from 0000858877-15-000051:mdna:83]

[0000858877-15-000073:mdna:84]
The goodwill recorded in the Consolidated Balance Sheets as of October 24, 2015 and July 25, 2015 was $24.9 billion and $24.5 billion, respectively.  In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in the first quarters of fiscal 2016 and 2015.

[0000858877-15-000073:mdna:85]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. There were no impairment charges related to purchased intangible assets for the first quarters of fiscal 2016 and 2015. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-15-000073:mdna:86]
[same as prior period, unchanged from 0000858877-15-000051:mdna:86]

[0000858877-15-000073:mdna:87]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 22.5% for each of the first quarters of fiscal 2016 and 2015.

[0000858877-15-000073:mdna:88]
[same as prior period, unchanged from 0000858877-15-000051:mdna:88]

[0000858877-15-000073:mdna:89]
[same as prior period, unchanged from 0000858877-15-000051:mdna:89]

[0000858877-15-000073:mdna:90]
46

[0000858877-15-000073:mdna:91]
[same as prior period, unchanged from 0000858877-15-000051:mdna:91]

[0000858877-15-000073:mdna:92]
[same as prior period, unchanged from 0000858877-15-000051:mdna:92]

[0000858877-15-000073:mdna:93]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by expiration of or lapses in the R&D tax credit or domestic manufacturing deduction laws; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our intercompany R&D cost-sharing arrangement and legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including possible changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, or the foreign tax credit rules.  Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes.  The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 34 countries, including the United States, has recently made changes to numerous long-standing tax principles.  There can be no assurance that these changes, once adopted by countries, will not have an adverse impact on our provision for income taxes.  As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-15-000073:mdna:94]
[same as prior period, unchanged from 0000858877-15-000051:mdna:54]

[0000858877-15-000073:mdna:95]
[same as prior period, unchanged from 0000858877-15-000051:mdna:95]

[0000858877-15-000073:mdna:96]
[same as prior period, unchanged from 0000858877-15-000051:mdna:96]

[0000858877-15-000073:mdna:97]
[same as prior period, unchanged from 0000858877-15-000051:mdna:97]

[0000858877-15-000073:mdna:98]
[same as prior period, unchanged from 0000858877-15-000051:mdna:98]

[0000858877-15-000073:mdna:99]
[same as prior period, unchanged from 0000858877-15-000051:mdna:99]

[0000858877-15-000073:mdna:100]
|  |  | Three Months Ended |
|  |  | October 24, 2015 |  | October 25, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,844 |  |  | $ | 9,435 |  |  | $ | 409 |  |  | 4.3 | % |
| Percentage of revenue |  | 77.6 | % |  | 77.1 | % |  |  |  |  |  |  |
| Service |  | 2,838 |  |  | 2,810 |  |  | 28 |  |  | 1.0 | % |
| Percentage of revenue |  | 22.4 | % |  | 22.9 | % |  |  |  |  |  |  |
| Total |  | $ | 12,682 |  |  | $ | 12,245 |  |  | $ | 437 |  |  | 3.6 | % |

[0000858877-15-000073:mdna:101]
[same as prior period, unchanged from 0000858877-15-000051:mdna:101]

[0000858877-15-000073:mdna:102]
|  |  | Three Months Ended |
|  |  | October 24, 2015 |  | October 25, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,799 |  |  | $ | 7,501 |  |  | $ | 298 |  |  | 4.0 | % |
| Percentage of revenue |  | 61.5 | % |  | 61.3 | % |  |  |  |  |
| EMEA |  | 3,087 |  |  | 3,002 |  |  | 85 |  |  | 2.8 | % |
| Percentage of revenue |  | 24.3 | % |  | 24.5 | % |  |  |  |  |
| APJC |  | 1,796 |  |  | 1,742 |  |  | 54 |  |  | 3.1 | % |
| Percentage of revenue |  | 14.2 | % |  | 14.2 | % |  |  |  |  |
| Total |  | $ | 12,682 |  |  | $ | 12,245 |  |  | $ | 437 |  |  | 3.6 | % |

[0000858877-15-000073:mdna:103]
Three Months Ended October 24, 2015 Compared with Three Months Ended October 25, 2014

[0000858877-15-000073:mdna:104]
For the first quarter of fiscal 2016, as compared with the first quarter of fiscal 2015, total revenue increased by 4%.  Product revenue increased by 4%, while service revenue increased by 1%.  Our total revenue reflected growth across each of our geographic segments. The emerging countries of BRICM, in the aggregate, experienced a 4% product revenue growth, with growth in Mexico, China and India partially offset by decreases in the other two BRICM countries.

[0000858877-15-000073:mdna:105]
We conduct business globally in numerous currencies. The direct effect of foreign currency fluctuations on revenue has not been material because our revenue is primarily denominated in U.S. dollars. However, if the U.S. dollar strengthens relative to other currencies, as was the case during the first quarter of fiscal 2016, such strengthening could have an indirect effect on our revenue to the extent it raises the cost of our products to non-U.S. customers and thereby reduces demand. A weaker U.S. dollar could have the opposite effect. However, the precise indirect effect of currency fluctuations is difficult to measure or predict because our revenue is influenced by many factors in addition to the impact of such currency fluctuations. Our revenue in the first quarter of fiscal 2016 was adversely affected by the depreciation of certain currencies relative to the U.S. dollar and especially currencies in certain emerging countries, although the indirect effects are difficult to measure.

[0000858877-15-000073:mdna:106]
In addition to the impact of macroeconomic factors, including a reduced IT spending environment and reductions in spending by government entities, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple-element arrangements; the mix of financing arrangements provided to our channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment. As has been the case in certain of our emerging countries from time to time, customers require greater levels of financing arrangements, service, and support, and these activities may occur in future periods, which may also impact the timing of the recognition of revenue.

[0000858877-15-000073:mdna:107]
48

[0000858877-15-000073:mdna:108]
[same as prior period, unchanged from 0000858877-15-000051:mdna:108]

[0000858877-15-000073:mdna:109]
[same as prior period, unchanged from 0000858877-15-000051:mdna:109]

[0000858877-15-000073:mdna:110]
[same as prior period, unchanged from 0000858877-15-000051:mdna:112]

[0000858877-15-000073:mdna:111]
[same as prior period, unchanged from 0000858877-15-000051:mdna:113]

[0000858877-15-000073:mdna:112]
|  |  | Three Months Ended |
|  |  | October 24, 2015 |  | October 25, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,954 |  |  | $ | 5,684 |  |  | $ | 270 |  |  | 4.8 | % |
| Percentage of product revenue |  | 60.4 | % |  | 60.2 | % |  |  |  |  |
| EMEA |  | 2,476 |  |  | 2,396 |  |  | 80 |  |  | 3.3 | % |
| Percentage of product revenue |  | 25.2 | % |  | 25.4 | % |  |  |  |  |
| APJC |  | 1,414 |  |  | 1,355 |  |  | 59 |  |  | 4.4 | % |
| Percentage of product revenue |  | 14.4 | % |  | 14.4 | % |  |  |  |  |
| Total |  | $ | 9,844 |  |  | $ | 9,435 |  |  | $ | 409 |  |  | 4.3 | % |

[0000858877-15-000073:mdna:113]
Three Months Ended October 24, 2015 Compared with Three Months Ended October 25, 2014

[0000858877-15-000073:mdna:114]
[same as prior period, unchanged from 0000858877-15-000051:mdna:115]

[0000858877-15-000073:mdna:115]
The increase in product revenue in the Americas segment of 5% was led by solid growth in the enterprise, commercial and public sector markets. The product revenue growth in the public sector market was due primarily to higher sales to state and local governments and higher sales to the U.S. federal government.  The product revenue growth in the enterprise and commercial markets was driven by solid growth in the United States. We experienced a product revenue decline in the service provider market in this geographic segment. From a country perspective, product revenue increased by 8% in the United States and 44% in Mexico, partially offset by decreases of 34% in Brazil and 28% in Canada.

[0000858877-15-000073:mdna:116]
[same as prior period, unchanged from 0000858877-15-000051:mdna:120]

[0000858877-15-000073:mdna:117]
Product revenue in the EMEA segment increased by 3%, driven by solid growth in the commercial market and, to a lesser extent, in the public sector market. These increases were partially offset by product revenue declines in the service provider and enterprise markets.  Product revenue in EMEA other than from emerging countries within EMEA, which primarily consists of countries in Western Europe, grew 5%, while product revenue from the emerging countries within EMEA was flat, as a product revenue decline in Russia of 40% offset the collective product revenue growth in the rest of the emerging countries within EMEA.

[0000858877-15-000073:mdna:118]
[same as prior period, unchanged from 0000858877-15-000051:mdna:128]

[0000858877-15-000073:mdna:119]
The increase in product revenue in the APJC segment of 4% was led by solid growth in the service provider market and, to a lesser extent, in the commercial market.  These increases were partially offset by declines in the enterprise and public sector markets. From a country perspective, product revenue increased by 17% in China and 13% in India. We experienced product revenue declines of 9% in Japan and 8% in Australia.

[0000858877-15-000073:mdna:120]
[same as prior period, unchanged from 0000858877-15-000051:mdna:126]

[0000858877-15-000073:mdna:121]
[same as prior period, unchanged from 0000858877-15-000051:mdna:127]

[0000858877-15-000073:mdna:122]
[same as prior period, unchanged from 0000858877-15-000051:mdna:135]

[0000858877-15-000073:mdna:123]
In addition to the primary view on a geographic basis, we also prepare financial information related to groups of similar products and customer markets for various purposes. Our product categories consist of the following categories (with subcategories in parentheses): Switching (fixed switching, modular switching, and storage); NGN Routing (high-end routers, mid-range and low-end routers, and other NGN Routing products); Collaboration (unified communications, Cisco TelePresence, and conferencing); Data Center; Service Provider Video (infrastructure, video software, and solutions and cable access); Wireless; Security; and Other Products. The Other Products category consists primarily of emerging technology products and other networking products.

[0000858877-15-000073:mdna:124]
[same as prior period, unchanged from 0000858877-15-000051:mdna:137]

[0000858877-15-000073:mdna:125]
|  |  | Three Months Ended |
|  |  | October 24, 2015 |  | October 25, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Switching |  | $ | 4,022 |  |  | $ | 3,846 |  |  | $ | 176 |  |  | 4.6 | % |
| Percentage of product revenue |  | 40.9 | % |  | 40.8 | % |  |  |  |  |  |  |
| NGN Routing |  | 1,793 |  |  | 1,949 |  |  | (156 | ) |  | (8.0 | )% |
| Percentage of product revenue |  | 18.2 | % |  | 20.7 | % |  |  |  |  |  |  |
| Collaboration |  | 1,115 |  |  | 950 |  |  | 165 |  |  | 17.4 | % |
| Percentage of product revenue |  | 11.3 | % |  | 10.1 | % |  |  |  |  |  |  |
| Data Center |  | 859 |  |  | 692 |  |  | 167 |  |  | 24.1 | % |
| Percentage of product revenue |  | 8.7 | % |  | 7.3 | % |  |  |  |  |  |  |
| Service Provider Video |  | 850 |  |  | 871 |  |  | (21 | ) |  | (2.4 | )% |
| Percentage of product revenue |  | 8.6 | % |  | 9.2 | % |  |  |  |  |
| Wireless |  | 645 |  |  | 605 |  |  | 40 |  |  | 6.6 | % |
| Percentage of product revenue |  | 6.6 | % |  | 6.4 | % |  |  |  |  |  |  |
| Security |  | 485 |  |  | 455 |  |  | 30 |  |  | 6.6 | % |
| Percentage of product revenue |  | 4.9 | % |  | 4.8 | % |  |  |  |  |  |  |
| Other |  | 75 |  |  | 67 |  |  | 8 |  |  | 11.9 | % |
| Percentage of product revenue |  | 0.8 | % |  | 0.7 | % |  |  |  |  |  |  |
| Total |  | $ | 9,844 |  |  | $ | 9,435 |  |  | $ | 409 |  |  | 4.3 | % |

[0000858877-15-000073:mdna:126]
[same as prior period, unchanged from 0000858877-15-000051:mdna:139]

[0000858877-15-000073:mdna:127]
Three Months Ended October 24, 2015 Compared with Three Months Ended October 25, 2014

[0000858877-15-000073:mdna:128]
[same as prior period, unchanged from 0000858877-15-000051:mdna:140]

[0000858877-15-000073:mdna:129]
The increase in revenue in our Switching product category of 5%, or $176 million, was driven by a 10%, or $243 million, increase in revenue from our LAN fixed-configuration switches partially offset by a 42%, or $66 million, decrease in sales of storage products.  Revenue from LAN fixed-configuration switches increased due to higher sales of our Cisco Catalyst 3850 Series Switches, Cisco Catalyst 3650 Series Switches, and Cisco Nexus 9300 Series Switches. Revenue from our modular switches was flat as higher sales of Cisco Catalyst Series Switches and Cisco Nexus 9500 Series Switches within this product category were offset by lower sales of other Cisco Nexus Series Switches within this product category.

[0000858877-15-000073:mdna:130]
[same as prior period, unchanged from 0000858877-15-000051:mdna:148]

[0000858877-15-000073:mdna:131]
Revenue in our NGN Routing product category decreased by 8%, or $156 million, driven by an 18%, or $212 million, decrease in revenue from our high-end router products partially offset by a 47%, or $52 million, increase in revenue from what we categorize as other NGN Routing products and a 1%, or $5 million, increase in revenue from our midrange and low-end router products. Within the high-end router product category, we experienced lower sales of most of our legacy high-end router products, lower sales within our Cisco Aggregation Services Router category and Cisco Network Convergence System platform, partially offset by increased in sales of our CRS-X products. Revenue from other NGN Routing products increased due to higher sales of certain optical networking products.  The increase in revenue from our midrange and low-end router products was due to higher sales of our Cisco Integrated Services Router products.

[0000858877-15-000073:mdna:132]
[same as prior period, unchanged from 0000858877-15-000051:mdna:133]

[0000858877-15-000073:mdna:133]
[same as prior period, unchanged from 0000858877-15-000051:mdna:134]

[0000858877-15-000073:mdna:134]
[same as prior period, unchanged from 0000858877-15-000051:mdna:153]

[0000858877-15-000073:mdna:135]
Revenue in our Collaboration product category increased by 17%, or $165 million, due to increased revenue from our Cisco TelePresence, Conferencing and Unified Communications products. Revenue from Cisco TelePresence products grew due to higher revenue in endpoint products as momentum continued as a result of new product introductions. The growth in Conferencing revenue was a result of higher usage and recurring revenue. The increase in Unified Communications revenue was driven by higher software revenue and increased revenue from phones due to customer migration to our newer endpoints. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Collaboration product category.

[0000858877-15-000073:mdna:136]
[same as prior period, unchanged from 0000858877-15-000051:mdna:166]

[0000858877-15-000073:mdna:137]
Revenue in our Data Center product category grew by 24%, or $167 million, with sales growth of our Cisco Unified Computing System products across all geographic segments and customer markets. The increase was due in large part to the continued momentum we are experiencing in both data center and cloud environments, as current customers increase their data center build-outs and as new customers deploy these offerings.

[0000858877-15-000073:mdna:138]
[same as prior period, unchanged from 0000858877-15-000051:mdna:158]

[0000858877-15-000073:mdna:139]
The decrease in revenue from our Service Provider Video product category of 2%, or $21 million, was driven by an 11%, or $52 million, decrease in sales of our Service Provider Video infrastructure products, due primarily to lower sales of set-top boxes. These decreases were partially offset by increase in revenue from cable access and Service Provider Video software and solutions products.

[0000858877-15-000073:mdna:140]
On July 22, 2015, we entered into an exclusive agreement to sell the client premises equipment portion of our Service Provider Video connected devices business unit to French-based Technicolor. We are working to close the transaction during the second quarter of fiscal 2016, subject to customary closing conditions, including the receipt of certain regulatory approvals. We plan to continue to refocus our investments in Service Provider Video towards cloud, security and software-based services.

[0000858877-15-000073:mdna:141]
[same as prior period, unchanged from 0000858877-15-000051:mdna:171]

[0000858877-15-000073:mdna:142]
Revenue in our Wireless product category increased by 7%, or $40 million, driven by continued growth in sales of Meraki products and, to a lesser extent, growth in sales of our access point products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Wireless product category.

[0000858877-15-000073:mdna:143]
[same as prior period, unchanged from 0000858877-15-000051:mdna:176]

[0000858877-15-000073:mdna:144]
Revenue in our Security product category was up 7%, or $30 million, driven by higher sales of advance threat security and unified threat management products, partially offset by a slight decrease in revenue from our traditional firewall products and e-mail products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Security product category.

[0000858877-15-000073:mdna:145]
[same as prior period, unchanged from 0000858877-15-000051:mdna:181]

[0000858877-15-000073:mdna:146]
We experienced a year-over-year increase in revenue in our Other Products category for the first quarter of fiscal 2016, due in large part to the increase in sales of our other networking products.

[0000858877-15-000073:mdna:147]
[same as prior period, unchanged from 0000858877-15-000051:mdna:94]

[0000858877-15-000073:mdna:148]
[same as prior period, unchanged from 0000858877-15-000051:mdna:144]

[0000858877-15-000073:mdna:149]
[same as prior period, unchanged from 0000858877-15-000051:mdna:145]

[0000858877-15-000073:mdna:150]
[same as prior period, unchanged from 0000858877-15-000051:mdna:185]

[0000858877-15-000073:mdna:151]
[same as prior period, unchanged from 0000858877-15-000051:mdna:186]

[0000858877-15-000073:mdna:152]
|  |  | Three Months Ended |
|  |  | October 24, 2015 |  | October 25, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,845 |  |  | $ | 1,817 |  |  | $ | 28 |  |  | 1.5 | % |
| Percentage of service revenue |  | 65.0 | % |  | 64.6 | % |  |  |  |  |
| EMEA |  | 611 |  |  | 606 |  |  | 5 |  |  | 0.8 | % |
| Percentage of service revenue |  | 21.5 | % |  | 21.6 | % |  |  |  |  |
| APJC |  | 382 |  |  | 387 |  |  | (5 | ) |  | (1.3 | )% |
| Percentage of service revenue |  | 13.5 | % |  | 13.8 | % |  |  |  |  |
| Total |  | $ | 2,838 |  |  | $ | 2,810 |  |  | $ | 28 |  |  | 1.0 | % |

[0000858877-15-000073:mdna:153]
Three Months Ended October 24, 2015 Compared with Three Months Ended October 25, 2014

[0000858877-15-000073:mdna:154]
Service revenue increased in the Americas and EMEA geographic segments, while service revenue declined in the APJC segment. Worldwide technical support services revenue decreased by 1% and worldwide advanced services revenue increased by 9%, driven by growth in transaction revenues. Technical support services revenue experienced declines across all geographic segments, driven by weakness in the service provider market.  Advanced services revenue, which relates to professional services for specific customer network needs, grew across all geographic segments, led by solid growth in our Americas segment.

[0000858877-15-000073:mdna:155]
[same as prior period, unchanged from 0000858877-15-000051:mdna:164]

[0000858877-15-000073:mdna:156]
[same as prior period, unchanged from 0000858877-15-000051:mdna:165]

[0000858877-15-000073:mdna:157]
[same as prior period, unchanged from 0000858877-15-000051:mdna:194]

[0000858877-15-000073:mdna:158]
[same as prior period, unchanged from 0000858877-15-000051:mdna:195]

[0000858877-15-000073:mdna:159]
|  |  | Three Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |
|  |  | October 24, 2015 |  | October 25, 2014 |  | October 24, 2015 |  | October 25, 2014 |
| Gross margin: |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,991 |  |  | $ | 5,516 |  |  | 60.9 | % |  | 58.5 | % |
| Service |  | 1,841 |  |  | 1,817 |  |  | 64.9 | % |  | 64.7 | % |
| Total |  | $ | 7,832 |  |  | $ | 7,333 |  |  | 61.8 | % |  | 59.9 | % |

[0000858877-15-000073:mdna:160]
[same as prior period, unchanged from 0000858877-15-000051:mdna:197]

[0000858877-15-000073:mdna:161]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the first quarter of fiscal 2016 as compared with the corresponding prior year period:

[0000858877-15-000073:mdna:162]
|  |  | Product Gross Margin Percentage |
| Fiscal 2015 |  | 58.5 | % |
| Productivity (1) |  | 3.7 | % |
| Rockstar patent portfolio charge |  | 2.0 | % |
| Amortization of purchased intangible assets |  | 0.6 | % |
| Product pricing |  | (2.2 | )% |
| Mix of products sold |  | (1.7 | )% |
| Fiscal 2016 |  | 60.9 | % |

[0000858877-15-000073:mdna:163]
[same as prior period, unchanged from 0000858877-15-000051:mdna:200]

[0000858877-15-000073:mdna:164]
Three Months Ended October 24, 2015 Compared with Three Months Ended October 25, 2014

[0000858877-15-000073:mdna:165]
Product gross margin increased by 2.4 percentage points as compared with the first quarter of fiscal 2015.

[0000858877-15-000073:mdna:166]
The increase in product gross margin was due in large part to the favorable impact of a $188 million charge to product cost of sales recorded in the first quarter of fiscal 2015 related to the Rockstar patent portfolio, see Note 4 to the Consolidated Financial Statements. The increase was also due to the productivity improvements, which were driven by value engineering efforts; favorable component pricing; and continued operational efficiency in manufacturing operations. Value engineering is the process by which production costs are reduced through component redesign, board configuration, test processes, and transformation processes. Our product gross margin also benefited from lower amortization expense of purchased intangible assets.

[0000858877-15-000073:mdna:167]
The various factors contributing to the product gross margin increase were partially offset by unfavorable impacts from product pricing, which were driven by typical market factors and impacted each of our geographic segments and customer markets, and unfavorable mix of products sold. The unfavorable product mix impact was due to increased revenue from our relatively lower margin Cisco Unified Computing System products and unfavorable mix within our NGN routing products.

[0000858877-15-000073:mdna:168]
Our future gross margins could be impacted by our product mix and could be adversely affected by further growth in sales of products that have lower gross margins, such as Cisco Unified Computing System products. Our gross margins may also be impacted by the geographic mix of our revenue and, as was the case in the first quarter of fiscal 2016 and in fiscal 2015, may be adversely affected by product pricing attributable to competitive factors. Additionally, our manufacturing-related costs may be negatively impacted by constraints in our supply chain, which in turn could negatively affect gross margin. If any of the preceding factors that in the past have negatively impacted our gross margins arise in future periods, our gross margins could continue to decline.

[0000858877-15-000073:mdna:169]
[same as prior period, unchanged from 0000858877-15-000051:mdna:183]

[0000858877-15-000073:mdna:170]
[same as prior period, unchanged from 0000858877-15-000051:mdna:184]

[0000858877-15-000073:mdna:171]
[same as prior period, unchanged from 0000858877-15-000051:mdna:212]

[0000858877-15-000073:mdna:172]
Three Months Ended October 24, 2015 Compared with Three Months Ended October 25, 2014

[0000858877-15-000073:mdna:173]
Our service gross margin percentage increased by 0.2 percentage points as compared with the first quarter of fiscal 2015 driven by lower headcount-related costs and, to a lesser extent, higher sales volume. These benefits to gross margin were partially offset by increased partner delivery costs and unfavorable mix. The mix impacts were due to our lower gross margin advanced services business contributing a higher proportion of service revenue for the first quarter of fiscal 2016, as compared with first quarter of fiscal 2015.

[0000858877-15-000073:mdna:174]
Our service gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-15-000073:mdna:175]
[same as prior period, unchanged from 0000858877-15-000051:mdna:220]

[0000858877-15-000073:mdna:176]
[same as prior period, unchanged from 0000858877-15-000051:mdna:221]

[0000858877-15-000073:mdna:177]
|  |  | Three Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |
|  |  | October 24, 2015 |  | October 25, 2014 |  | October 24, 2015 |  | October 25, 2014 |
| Gross margin: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 4,950 |  |  | $ | 4,810 |  |  | 63.5 | % |  | 64.1 | % |
| EMEA |  | 1,982 |  |  | 1,915 |  |  | 64.2 | % |  | 63.8 | % |
| APJC |  | 1,078 |  |  | 1,025 |  |  | 60.0 | % |  | 58.8 | % |
| Segment total |  | 8,010 |  |  | 7,750 |  |  | 63.2 | % |  | 63.3 | % |
| Unallocated corporate items (1) |  | (178 | ) |  | (417 | ) |  |  |  |  |
| Total |  | $ | 7,832 |  |  | $ | 7,333 |  |  | 61.8 | % |  | 59.9 | % |

[0000858877-15-000073:mdna:178]
(1) The unallocated corporate items for the periods presented include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-15-000073:mdna:179]
Three Months Ended October 24, 2015 Compared with Three Months Ended October 25, 2014

[0000858877-15-000073:mdna:180]
The Americas segment experienced a gross margin percentage decrease due primarily to unfavorable pricing and mix impacts, partially offset by productivity improvements in this geographic segment. The unfavorable mix impact was driven by revenue decreases from certain of our higher margin core products and an increase in revenue from our lower margin Cisco Unified Computing System products.

[0000858877-15-000073:mdna:181]
The gross margin percentage increase in our EMEA segment was due primarily to the impact of productivity improvements in this geographic segment. Partially offsetting this favorable impact to gross margin were negative impacts from pricing and an unfavorable mix. The unfavorable mix impact was driven by revenue decreases from certain of our higher margin core products and an increase in revenue from our lower margin Cisco Unified Computing System products. Higher service gross margin also contributed to the increase in the overall gross margin in this segment.

[0000858877-15-000073:mdna:182]
Our APJC segment gross margin percentage increased primarily due to the impact of productivity improvements in this geographic segment. Partially offsetting this favorable impact to gross margin were negative impacts from pricing and an unfavorable mix. The unfavorable mix impact was driven by revenue increases in our relatively lower margin Service Provider Video and Cisco Unified Computing System products. Revenue decreases from certain of our higher margin core products also contributed to the unfavorable mix impact. Higher service gross margin also contributed to the increase in the overall gross margin in this segment.

[0000858877-15-000073:mdna:183]
[same as prior period, unchanged from 0000858877-15-000051:mdna:228]

[0000858877-15-000073:mdna:184]
54

[0000858877-15-000073:mdna:185]
[same as prior period, unchanged from 0000858877-15-000051:mdna:192]

[0000858877-15-000073:mdna:186]
[same as prior period, unchanged from 0000858877-15-000051:mdna:193]

[0000858877-15-000073:mdna:187]
[same as prior period, unchanged from 0000858877-15-000051:mdna:236]

[0000858877-15-000073:mdna:188]
Product revenue may continue to be affected by factors, including global economic downturns and related market uncertainty, that have resulted in reduced IT-related capital spending in certain segments within our enterprise, service provider, public sector, and commercial markets; changes in the geopolitical environment and global economic conditions; competition, including price-focused competitors from Asia, especially from China; new product introductions; sales cycles and product implementation cycles; changes in the mix of our customers between service provider and enterprise markets; changes in the mix of direct sales and indirect sales; variations in sales channels; and final acceptance criteria of the product, system, or solution as specified by the customer. Sales to the service provider market have been and may be in the future characterized by large and sporadic purchases, especially relating to our NGN Routing sales and sales of certain products within our Collaboration, Data Center, and Service Provider Video product categories. In addition, service provider customers typically have longer implementation cycles; require a broader range of services, including network design services; and often have acceptance provisions that can lead to a delay in revenue recognition. Certain of our customers in certain emerging countries also tend to make large and sporadic purchases, and the revenue related to these transactions may similarly be affected by the timing of revenue recognition. As we focus on new market opportunities, customers may require greater levels of financing arrangements, service, and support, especially in certain emerging countries, which in turn may result in a delay in the timing of revenue recognition. To improve customer satisfaction, we continue to focus on managing our manufacturing lead-time performance, which may result in corresponding reductions in order backlog. A decline in backlog levels could result in more variability and less predictability in our quarter-to-quarter revenue and operating results.

[0000858877-15-000073:mdna:189]
[same as prior period, unchanged from 0000858877-15-000051:mdna:238]

[0000858877-15-000073:mdna:190]
[same as prior period, unchanged from 0000858877-15-000051:mdna:239]

[0000858877-15-000073:mdna:191]
[same as prior period, unchanged from 0000858877-15-000051:mdna:240]

[0000858877-15-000073:mdna:192]
[same as prior period, unchanged from 0000858877-15-000051:mdna:207]

[0000858877-15-000073:mdna:193]
[same as prior period, unchanged from 0000858877-15-000051:mdna:208]

[0000858877-15-000073:mdna:194]
[same as prior period, unchanged from 0000858877-15-000051:mdna:243]

[0000858877-15-000073:mdna:195]
[same as prior period, unchanged from 0000858877-15-000051:mdna:244]

[0000858877-15-000073:mdna:196]
|  |  | Three Months Ended |
|  |  | October 24, 2015 |  | October 25, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Research and development |  | $ | 1,560 |  |  | $ | 1,583 |  |  | $ | (23 | ) |  | (1.5 | )% |
| Percentage of revenue |  | 12.3 | % |  | 12.9 | % |  |  |  |  |
| Sales and marketing |  | 2,443 |  |  | 2,515 |  |  | (72 | ) |  | (2.9 | )% |
| Percentage of revenue |  | 19.3 | % |  | 20.5 | % |  |  |  |  |
| General and administrative |  | 539 |  |  | 504 |  |  | 35 |  |  | 6.9 | % |
| Percentage of revenue |  | 4.3 | % |  | 4.1 | % |  |  |  |  |
| Total |  | $ | 4,542 |  |  | $ | 4,602 |  |  | $ | (60 | ) |  | (1.3 | )% |
| Percentage of revenue |  | 35.8 | % |  | 37.6 | % |  |  |  |  |

[0000858877-15-000073:mdna:197]
[same as prior period, unchanged from 0000858877-15-000051:mdna:246]

[0000858877-15-000073:mdna:198]
R&D expenses decreased for the first quarter of fiscal 2016, as compared with the first quarter of fiscal 2015, primarily due to lower acquisition-related costs and lower contracted services. Lower share-based compensation expense also contributed to the decrease.

[0000858877-15-000073:mdna:199]
[same as prior period, unchanged from 0000858877-15-000051:mdna:249]

[0000858877-15-000073:mdna:200]
[same as prior period, unchanged from 0000858877-15-000051:mdna:250]

[0000858877-15-000073:mdna:201]
Sales and marketing expenses decreased for the first quarter of fiscal 2016, as compared with the first quarter of fiscal 2015, due to lower headcount-related expenses and, to a lesser extent, lower share-based compensation expense and lower contracted services. Lower headcount-related expenses were due primarily to efficiencies related to our restructuring actions.

[0000858877-15-000073:mdna:202]
[same as prior period, unchanged from 0000858877-15-000051:mdna:253]

[0000858877-15-000073:mdna:203]
G&A expenses increased in the first quarter of fiscal 2016, as compared with the first quarter of fiscal 2015, primarily due to the timing of corporate-level expenses, which tend to vary from period to period, higher headcount-related expenses and higher acquisition-related costs. Corporate-level expenses included operational infrastructure activities such as IT project implementations, which included investments in our global data center infrastructure, and investments related to operational and financial systems.

[0000858877-15-000073:mdna:204]
[same as prior period, unchanged from 0000858877-15-000051:mdna:256]

[0000858877-15-000073:mdna:205]
In the first quarter of fiscal 2016, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $208 million, or approximately 4.5%, compared with the first quarter of fiscal 2015.

[0000858877-15-000073:mdna:206]
[same as prior period, unchanged from 0000858877-15-000051:mdna:261]

[0000858877-15-000073:mdna:207]
The increase in headcount of approximately 230 employees in the first quarter of fiscal 2016 as compared with the total headcount at the end of fiscal 2015 was due to targeted hiring in key growth areas in engineering, services and sales, and headcount additions from our recent acquisitions. These headcount additions were partially offset by headcount reductions from attrition and from our restructuring plan announced in August 2014.

[0000858877-15-000073:mdna:208]
[same as prior period, unchanged from 0000858877-15-000051:mdna:218]

[0000858877-15-000073:mdna:209]
[same as prior period, unchanged from 0000858877-15-000051:mdna:219]

[0000858877-15-000073:mdna:210]
[same as prior period, unchanged from 0000858877-15-000051:mdna:264]

[0000858877-15-000073:mdna:211]
[same as prior period, unchanged from 0000858877-15-000051:mdna:265]

[0000858877-15-000073:mdna:212]
|  |  | Three Months Ended |
|  |  | October 24, 2015 |  | October 25, 2014 |
| Cost of sales—product |  | $ | 13 |  |  | $ | 11 |  |
| Cost of sales—service |  | 38 |  |  | 37 |  |
| Share-based compensation expense in cost of sales |  | 51 |  |  | 48 |  |
| Research and development |  | 114 |  |  | 119 |  |
| Sales and marketing |  | 139 |  |  | 147 |  |
| General and administrative |  | 57 |  |  | 59 |  |
| Restructuring and other charges |  | 15 |  |  | (4 | ) |
| Share-based compensation expense in operating expenses |  | 325 |  |  | 321 |  |
| Total share-based compensation expense |  | $ | 376 |  |  | $ | 369 |  |

[0000858877-15-000073:mdna:213]
The slight increase in share-based compensation expense in the first quarter of fiscal 2016, as compared with the corresponding period in fiscal 2015, was due primarily to the higher expense associated with accelerated and modified awards and the timing of RSU grants, partially offset by lower expense related to equity awards assumed with respect to our recent acquisitions.

[0000858877-15-000073:mdna:214]
[same as prior period, unchanged from 0000858877-15-000051:mdna:268]

[0000858877-15-000073:mdna:215]
[same as prior period, unchanged from 0000858877-15-000051:mdna:269]

[0000858877-15-000073:mdna:216]
|  |  | Three Months Ended |
|  |  | October 24, 2015 |  | October 25, 2014 |
| Amortization of purchased intangible assets: |  |  |  |  |
| Cost of sales |  | $ | 146 |  |  | $ | 189 |  |
| Operating expenses |  | 69 |  |  | 71 |  |
| Total |  | $ | 215 |  |  | $ | 260 |  |

[0000858877-15-000073:mdna:217]
Amortization of purchased intangible assets decreased for the first quarter of fiscal 2016, as compared with the first quarter of fiscal 2015, due to certain purchased intangible assets having become fully amortized or impaired, partially offset by amortization of purchased intangible assets from our recent acquisitions.

[0000858877-15-000073:mdna:218]
[same as prior period, unchanged from 0000858877-15-000051:mdna:273]

[0000858877-15-000073:mdna:219]
[same as prior period, unchanged from 0000858877-15-000051:mdna:277]

[0000858877-15-000073:mdna:220]
In the first quarter of fiscal 2016, we incurred restructuring and other charges of approximately $141 million net of a $1 million credit to cost of sales, which were related primarily to employee severance charges for employees impacted by the restructuring action announced in August 2014.  We expect this plan to be substantially completed during the first half of fiscal 2016. We plan to reinvest substantially all of the cost savings from the restructuring actions in key growth areas of our business such as data center, software, security, and cloud. The overall cost savings from these restructuring actions were not material for the periods presented and are not expected to be material for future periods.

[0000858877-15-000073:mdna:221]
In the first quarter of fiscal 2015, we incurred restructuring and other charges of $318 million which were related primarily to employee severance charges for employees impacted by the restructuring action announced in August 2014. See Note 5 to the Consolidated Financial Statements.

[0000858877-15-000073:mdna:222]
57

[0000858877-15-000073:mdna:223]
[same as prior period, unchanged from 0000858877-15-000051:mdna:234]

[0000858877-15-000073:mdna:224]
[same as prior period, unchanged from 0000858877-15-000051:mdna:235]

[0000858877-15-000073:mdna:225]
[same as prior period, unchanged from 0000858877-15-000051:mdna:280]

[0000858877-15-000073:mdna:226]
[same as prior period, unchanged from 0000858877-15-000051:mdna:281]

[0000858877-15-000073:mdna:227]
|  |  | Three Months Ended |
|  |  | October 24, 2015 |  | October 25, 2014 |
| Operating income |  | $ | 3,079 |  |  | $ | 2,342 |  |
| Operating income as a percentage of revenue |  | 24.3 | % |  | 19.1 | % |

[0000858877-15-000073:mdna:228]
For the first quarter of fiscal 2016, as compared with the first quarter of fiscal 2015, operating income increased by 31%, and as a percentage of revenue operating income increased by 5.2 percentage points. The increase resulted from the following: an increase in revenue; a gross margin percentage increase, driven in part by the Rockstar patent portfolio charge of $188 million (or 1.5 percentage points of the prior period revenue); and a decrease in restructuring and other charges related to the restructuring action announced in August 2014.

[0000858877-15-000073:mdna:229]
[same as prior period, unchanged from 0000858877-15-000051:mdna:285]

[0000858877-15-000073:mdna:230]
[same as prior period, unchanged from 0000858877-15-000051:mdna:286]

[0000858877-15-000073:mdna:231]
|  |  | Three Months Ended |
|  |  | October 24, 2015 |  | October 25, 2014 |  | Variancein Dollars |
| Interest income |  | $ | 225 |  |  | $ | 179 |  |  | $ | 46 |  |
| Interest expense |  | (159 | ) |  | (139 | ) |  | (20 | ) |
| Interest income (expense), net |  | $ | 66 |  |  | $ | 40 |  |  | $ | 26 |  |

[0000858877-15-000073:mdna:232]
For the first quarter of fiscal 2016, interest income increased by 26% compared with the corresponding period in fiscal 2015, driven by an increase in our portfolio of cash, cash equivalents, and fixed income investments as well as higher yields on our portfolio of cash and investments.  Interest expense in the first quarter of fiscal 2016, compared with the corresponding period in fiscal 2015, increased by 14%, driven by additional interest expense due to the net increase in debt.

[0000858877-15-000073:mdna:233]
[same as prior period, unchanged from 0000858877-15-000051:mdna:291]

[0000858877-15-000073:mdna:234]
|  |  | Three Months Ended |
|  |  | October 24, 2015 |  | October 25, 2014 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |
| Publicly traded equity securities |  | $ | (9 | ) |  | $ | (4 | ) |  | $ | (5 | ) |
| Fixed income securities |  | 8 |  |  | 11 |  |  | (3 | ) |
| Total available-for-sale investments |  | (1 | ) |  | 7 |  |  | (8 | ) |
| Privately held companies |  | (11 | ) |  | (33 | ) |  | 22 |  |
| Net gains (losses) on investments |  | (12 | ) |  | (26 | ) |  | 14 |  |
| Other gains (losses), net |  | 4 |  |  | 4 |  |  | — |  |
| Other income (loss), net |  | $ | (8 | ) |  | $ | (22 | ) |  | $ | 14 |  |

[0000858877-15-000073:mdna:235]
The decrease in total net gains on available-for-sale investments in the first quarter of fiscal 2016, as compared with the corresponding period in fiscal 2015, was primarily attributable to lower gains on publicly traded equity securities in the current period as a result of market conditions and the timing of sales of these securities.

[0000858877-15-000073:mdna:236]
The change in net gains (losses) on investments in privately held companies for the first quarter of fiscal 2016 as compared with the first quarter of fiscal 2015, was primarily due to the absence of losses from VCE Company, LLC for the first quarter of fiscal 2016, partially offset by higher impairment charges on certain investments in privately held companies and lower realized gains from various  investments in privately held companies.

[0000858877-15-000073:mdna:237]
[same as prior period, unchanged from 0000858877-15-000051:mdna:241]

[0000858877-15-000073:mdna:238]
[same as prior period, unchanged from 0000858877-15-000051:mdna:242]

[0000858877-15-000073:mdna:239]
Other gains (losses), net was flat in the first quarter of fiscal 2016, as compared with the corresponding period in fiscal 2015, as the favorable impacts from equity derivatives were offset by net unfavorable foreign exchange impacts and higher donation expenses.

[0000858877-15-000073:mdna:240]
[same as prior period, unchanged from 0000858877-15-000051:mdna:296]

[0000858877-15-000073:mdna:241]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates, higher than anticipated in countries that have higher tax rates, and expiration of or lapses in tax incentives. Our provision for income taxes does not include provisions for U.S. income taxes and foreign withholding taxes associated with the repatriation of undistributed earnings of certain foreign subsidiaries that we intend to reinvest indefinitely in our foreign subsidiaries. If these earnings were distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. Further, as a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes.

[0000858877-15-000073:mdna:242]
The provision for income taxes resulted in an effective tax rate of 22.5% for each of the first quarters of fiscal 2016 and 2015.  The effective tax rate was unchanged largely because a decrease in foreign income taxed at lower than U.S. rates was offset by a decrease in non-deductible compensation.

[0000858877-15-000073:mdna:243]
[same as prior period, unchanged from 0000858877-15-000051:mdna:206]

[0000858877-15-000073:mdna:244]
[same as prior period, unchanged from 0000858877-15-000051:mdna:259]

[0000858877-15-000073:mdna:245]
[same as prior period, unchanged from 0000858877-15-000051:mdna:260]

[0000858877-15-000073:mdna:246]
[same as prior period, unchanged from 0000858877-15-000051:mdna:303]

[0000858877-15-000073:mdna:247]
[same as prior period, unchanged from 0000858877-15-000051:mdna:304]

[0000858877-15-000073:mdna:248]
[same as prior period, unchanged from 0000858877-15-000051:mdna:305]

[0000858877-15-000073:mdna:249]
[same as prior period, unchanged from 0000858877-15-000051:mdna:306]

[0000858877-15-000073:mdna:250]
|  | October 24, 2015 |  | July 25, 2015 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 5,758 |  |  | $ | 6,877 |  |  | $ | (1,119 | ) |
| Fixed income securities | 51,999 |  |  | 51,974 |  |  | 25 |  |
| Publicly traded equity securities | 1,350 |  |  | 1,565 |  |  | (215 | ) |
| Total | $ | 59,107 |  |  | $ | 60,416 |  |  | $ | (1,309 | ) |

[0000858877-15-000073:mdna:251]
The net decrease in cash and cash equivalents and investments in the first quarter of fiscal 2016 was driven by cash returned to shareholders in the form of repurchase of common stock of $1.2 billion under the stock repurchase program and cash dividends of $1.1 billion. Other significant uses of cash in the first quarter of fiscal 2016 included repayment of debt of $0.9 billion, net cash paid for acquisitions of $0.6 billion, and capital expenditures of $0.3 billion. Partially offsetting these cash outflows were cash provided by operating activities of $2.8 billion.

[0000858877-15-000073:mdna:252]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $54.1 billion and $53.4 billion as of October 24, 2015 and July 25, 2015, respectively. Under current tax laws and regulations, if these assets were to be distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. The balance of cash and cash equivalents and investments available in the United States as of October 24, 2015 and July 25, 2015 was $5.0 billion and $7.0 billion, respectively.

[0000858877-15-000073:mdna:253]
[same as prior period, unchanged from 0000858877-15-000051:mdna:310]

[0000858877-15-000073:mdna:254]
[same as prior period, unchanged from 0000858877-15-000051:mdna:311]

[0000858877-15-000073:mdna:255]
[same as prior period, unchanged from 0000858877-15-000051:mdna:312]

[0000858877-15-000073:mdna:256]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Net cash provided by operating activities | $ | 2,766 |  |  | $ | 2,491 |  |
| Acquisition of property and equipment | (262 | ) |  | (285 | ) |
| Free cash flow | $ | 2,504 |  |  | $ | 2,206 |  |

[0000858877-15-000073:mdna:257]
[same as prior period, unchanged from 0000858877-15-000051:mdna:314]

[0000858877-15-000073:mdna:258]
[same as prior period, unchanged from 0000858877-15-000051:mdna:275]

[0000858877-15-000073:mdna:259]
[same as prior period, unchanged from 0000858877-15-000051:mdna:276]

[0000858877-15-000073:mdna:260]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases.  We further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period.  In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness.  Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net income provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-15-000073:mdna:261]
[same as prior period, unchanged from 0000858877-15-000051:mdna:319]

[0000858877-15-000073:mdna:262]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2016 |  |  |  |  |  |  |  |  |  |  |  |  |
| October 24, 2015 |  | $ | 0.21 |  |  | $ | 1,068 |  |  | 45 |  |  | $ | 26.83 |  |  | $ | 1,207 |  |  | $ | 2,275 |  |
| Fiscal 2015 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 25, 2015 |  | $ | 0.21 |  |  | $ | 1,069 |  |  | 35 |  |  | $ | 28.62 |  |  | $ | 1,005 |  |  | $ | 2,074 |  |
| April 25, 2015 |  | $ | 0.21 |  |  | $ | 1,070 |  |  | 35 |  |  | $ | 28.39 |  |  | $ | 1,008 |  |  | $ | 2,078 |  |
| January 24, 2015 |  | $ | 0.19 |  |  | $ | 974 |  |  | 44 |  |  | $ | 27.63 |  |  | $ | 1,208 |  |  | $ | 2,182 |  |
| October 25, 2014 |  | $ | 0.19 |  |  | $ | 973 |  |  | 41 |  |  | $ | 24.58 |  |  | $ | 1,013 |  |  | $ | 1,986 |  |

[0000858877-15-000073:mdna:263]
On November 18, 2015, our Board of Directors declared a quarterly dividend of $0.21 per common share to be paid on January 20, 2016 to all shareholders of record as of the close of business on January 6, 2016.  Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-15-000073:mdna:264]
[same as prior period, unchanged from 0000858877-15-000051:mdna:322]

[0000858877-15-000073:mdna:265]
|  | October 24, 2015 |  | July 25, 2015 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,712 |  |  | $ | 5,344 |  |  | $ | (632 | ) |
| DSO | 34 |  |  | 38 |  |  | (4 | ) |

[0000858877-15-000073:mdna:266]
Our accounts receivable net, as of October 24, 2015 decreased by approximately 12% compared with the end of fiscal 2015. Our DSO as of October 24, 2015 was lower by four days as compared with the end of fiscal 2015, primarily due to product and service billings being more linear in the first quarter of fiscal 2016 compared with the fourth quarter of fiscal 2015.

[0000858877-15-000073:mdna:267]
[same as prior period, unchanged from 0000858877-15-000051:mdna:325]

[0000858877-15-000073:mdna:268]
|  | October 24, 2015 |  | July 25, 2015 |  | Increase (Decrease) |
| Inventories | $ | 1,482 |  |  | $ | 1,627 |  |  | $ | (145 | ) |
| Annualized inventory turns | 12.5 |  |  | 12.1 |  |  | 0.4 |  |
| Purchase commitments with contract manufacturers and suppliers | $ | 4,028 |  |  | $ | 4,078 |  |  | $ | (50 | ) |

[0000858877-15-000073:mdna:269]
Inventory as of October 24, 2015 decreased by 9% from our inventory balance at the end of fiscal 2015, and for the same period purchase commitments with contract manufacturers and suppliers decreased by approximately 1%.  On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers decreased by 3% compared with the end of fiscal 2015. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-15-000073:mdna:270]
[same as prior period, unchanged from 0000858877-15-000051:mdna:329]

[0000858877-15-000073:mdna:271]
[same as prior period, unchanged from 0000858877-15-000051:mdna:289]

[0000858877-15-000073:mdna:272]
[same as prior period, unchanged from 0000858877-15-000051:mdna:290]

[0000858877-15-000073:mdna:273]
[same as prior period, unchanged from 0000858877-15-000051:mdna:332]

[0000858877-15-000073:mdna:274]
[same as prior period, unchanged from 0000858877-15-000051:mdna:333]

[0000858877-15-000073:mdna:275]
[same as prior period, unchanged from 0000858877-15-000051:mdna:334]

[0000858877-15-000073:mdna:276]
Financing Receivables and Guarantees We measure our net balance sheet exposure position related to our financing receivables and financing guarantees by reducing the total of gross financing receivables and financing guarantees by the associated allowances for credit loss and deferred revenue. As of October 24, 2015, our net balance sheet exposure position related to financing receivables and financing guarantees was as follows (in millions):

[0000858877-15-000073:mdna:277]
|  | FINANCING RECEIVABLES |  | FINANCING GUARANTEES |  |  |
| October 24, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |  | Channel Partner |  | End-User Customers |  | Total |  | TOTAL |
| Financing receivables and guarantees | $ | 3,360 |  |  | $ | 1,963 |  |  | $ | 3,598 |  |  | $ | 8,921 |  |  | $ | 250 |  |  | $ | 124 |  |  | $ | 374 |  |  | $ | 9,295 |  |
| Allowance for credit loss | (255 | ) |  | (90 | ) |  | (33 | ) |  | (378 | ) |  | — |  |  | — |  |  | — |  |  | (378 | ) |
| Deferred revenue | (7 | ) |  | (12 | ) |  | (1,911 | ) |  | (1,930 | ) |  | (96 | ) |  | (100 | ) |  | (196 | ) |  | (2,126 | ) |
| Net balance sheet exposure | $ | 3,098 |  |  | $ | 1,861 |  |  | $ | 1,654 |  |  | $ | 6,613 |  |  | $ | 154 |  |  | $ | 24 |  |  | $ | 178 |  |  | $ | 6,791 |  |

[0000858877-15-000073:mdna:278]
Financing Receivables  Financing receivables less unearned income increased by 2% compared with the end of fiscal 2015. The change was due to an 11% increase in loan receivables and, to a lesser extent, a 1% increase in financed service contracts and other, partially offset by a 1% decrease in lease receivables. We provide financing to certain end-user customers and channel partners to enable sales of our products, services, and networking solutions. These financing arrangements include leases, financed service contracts, and loans. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Lease receivables include sales-type and direct-financing leases. We also provide certain qualified customers financing for long-term service contracts, which primarily relate to technical support services. Our loan financing arrangements may include not only financing the acquisition of our products and services but also providing additional funds for other costs associated with network installation and integration of our products and services. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-15-000073:mdna:279]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements to customers provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms. The volume of channel partner financing was $6.9 billion and $6.3 billion for the three months ended October 24, 2015 and October 25, 2014, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.2 billion as of each October 24, 2015 and July 25, 2015. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed.

[0000858877-15-000073:mdna:280]
[same as prior period, unchanged from 0000858877-15-000051:mdna:301]

[0000858877-15-000073:mdna:281]
[same as prior period, unchanged from 0000858877-15-000051:mdna:302]

[0000858877-15-000073:mdna:282]
[same as prior period, unchanged from 0000858877-15-000051:mdna:342]

[0000858877-15-000073:mdna:283]
[same as prior period, unchanged from 0000858877-15-000051:mdna:343]

[0000858877-15-000073:mdna:284]
[same as prior period, unchanged from 0000858877-15-000051:mdna:344]

[0000858877-15-000073:mdna:285]
|  | Maturity Date |  | October 24, 2015 |  | July 25, 2015 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | $ | 850 |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 1,000 |  |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 900 |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3,000 |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 2,400 |  |
| 3.15% | March 14, 2017 |  | 750 |  |  | 750 |  |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1,600 |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 24,400 |  |  | $ | 25,250 |  |

[0000858877-15-000073:mdna:286]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of October 24, 2015.

[0000858877-15-000073:mdna:287]
We repaid the floating-rate notes due on September 3, 2015 for an aggregate principal amount of $850 million upon maturity.

[0000858877-15-000073:mdna:288]
Other Debt  Other debt as of October 24, 2015 and July 25, 2015 includes secured borrowings associated with customer financing arrangements.  The amount of borrowings outstanding under these arrangements was $2 million and $4 million as of October 24, 2015 and July 25, 2015, respectively.

[0000858877-15-000073:mdna:289]
Commercial Paper  In fiscal 2011, we established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of each of October 24, 2015 and July 25, 2015.

[0000858877-15-000073:mdna:290]
[same as prior period, unchanged from 0000858877-15-000051:mdna:316]

[0000858877-15-000073:mdna:291]
[same as prior period, unchanged from 0000858877-15-000051:mdna:317]

[0000858877-15-000073:mdna:292]
Credit Facility On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. The credit agreement requires that we comply with certain covenants, including that it maintains an interest coverage ratio as defined in the agreement.

[0000858877-15-000073:mdna:293]
We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.  We were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-15-000073:mdna:294]
[same as prior period, unchanged from 0000858877-15-000051:mdna:356]

[0000858877-15-000073:mdna:295]
|  | October 24, 2015 |  | July 25, 2015 |  | Increase (Decrease) |
| Service | $ | 9,689 |  |  | $ | 9,757 |  |  | $ | (68 | ) |
| Product | 5,473 |  |  | 5,426 |  |  | 47 |  |
| Total | $ | 15,162 |  |  | $ | 15,183 |  |  | $ | (21 | ) |
| Reported as: |  |  |  |  |  |
| Current | $ | 9,821 |  |  | $ | 9,824 |  |  | $ | (3 | ) |
| Noncurrent | 5,341 |  |  | 5,359 |  |  | (18 | ) |
| Total | $ | 15,162 |  |  | $ | 15,183 |  |  | $ | (21 | ) |

[0000858877-15-000073:mdna:296]
The 1% decrease in deferred service revenue in the first quarter of fiscal 2016 as compared with the fourth quarter of fiscal 2015 reflects what, in our view, is a typical seasonal decline as we tend to experience higher service initiations as well as renewals in our fiscal fourth quarter. The 1% increase in deferred product revenue was primarily due to increased deferrals related to subscription revenue arrangements and also was due, to a lesser extent, to an increase in shipments not having met revenue recognition criteria as of October 24, 2015, partially offset by lower deferred revenue related to two-tier distributors.

[0000858877-15-000073:mdna:297]
[same as prior period, unchanged from 0000858877-15-000051:mdna:359]

[0000858877-15-000073:mdna:298]
[same as prior period, unchanged from 0000858877-15-000051:mdna:360]

[0000858877-15-000073:mdna:299]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland, and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of October 24, 2015 were $1.1 billion.

[0000858877-15-000073:mdna:300]
[same as prior period, unchanged from 0000858877-15-000051:mdna:362]

[0000858877-15-000073:mdna:301]
In connection with our acquisitions and asset purchases, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or the continued employment with us of certain employees of the acquired entities. See Note 12 to the Consolidated Financial Statements.

[0000858877-15-000073:mdna:302]
[same as prior period, unchanged from 0000858877-15-000051:mdna:364]

[0000858877-15-000073:mdna:303]
During the first quarter of fiscal 2014, we exercised our call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  During the three months ended October 24, 2015 and October 25, 2014,

[0000858877-15-000073:mdna:304]
[same as prior period, unchanged from 0000858877-15-000051:mdna:330]

[0000858877-15-000073:mdna:305]
[same as prior period, unchanged from 0000858877-15-000051:mdna:331]

[0000858877-15-000073:mdna:306]
we recorded compensation expense of $51 million and $53 million, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods. Based on the terms of the agreement, we have determined that the maximum amount that could be recorded as compensation expense by us is approximately $841 million (which includes the $674 million that has been expensed to date), net of forfeitures.

[0000858877-15-000073:mdna:307]
The former noncontrolling interest holders earned the maximum amount related to the first milestone payment and were paid   approximately $291 million for a portion of this amount during the first quarter of fiscal 2016.  The balance of the first milestone payment is expected to be paid primarily through the end of fiscal 2016.  The second milestone payment, to the extent earned, is expected to be paid primarily during the first half of fiscal 2017.

[0000858877-15-000073:mdna:308]
Other Funding Commitments  We also have certain funding commitments primarily related to our investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $192 million as of October 24, 2015, compared with $205 million as of July 25, 2015.

[0000858877-15-000073:mdna:309]
[same as prior period, unchanged from 0000858877-15-000051:mdna:370]

[0000858877-15-000073:mdna:310]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and customer financings, and we have determined that as of October 24, 2015 there were no material unconsolidated variable interest entities.

[0000858877-15-000073:mdna:311]
[same as prior period, unchanged from 0000858877-15-000051:mdna:372]

[0000858877-15-000073:mdna:312]
[same as prior period, unchanged from 0000858877-15-000051:mdna:373]

[0000858877-15-000073:mdna:313]
[same as prior period, unchanged from 0000858877-15-000051:mdna:374]

[0000858877-15-000073:mdna:314]
We periodically engage in securities lending activities with certain of our available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the three months ended October 24, 2015 and October 25, 2014 was $0.5 billion and $1.0 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of October 24, 2015 and July 25, 2015, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-15-000073:mdna:315]
[same as prior period, unchanged from 0000858877-15-000051:mdna:376]

[0000858877-15-000073:mdna:316]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, pending acquisitions, principal and interest payments on debt, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.
