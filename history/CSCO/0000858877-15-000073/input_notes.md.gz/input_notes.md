# CSCO notes — 0000858877-15-000073


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-15-000073:notes:1]
[same as prior period, unchanged from 0000858877-15-000051:notes:1]

[0000858877-15-000073:notes:2]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Compensation expense related to acquisitions | $ | 73 |  |  | $ | 98 |  |


## csco:DescriptionOfNewAccountingPronouncementsNotYetAdoptedPolicyTextBlock

[0000858877-15-000073:notes:3]
Recent Accounting Standards or Updates Not Yet Effective  In May 2014, the FASB issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance.  The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services.  This accounting standard update, as amended, will be effective for the Company beginning in the first quarter of fiscal 2019.  The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption.  Early adoption is permitted, but no earlier than fiscal 2018.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-15-000073:notes:4]
In February 2015, the FASB issued an accounting standard update that changes the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2017, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.


## csco:EntityWideDisclosureOnGeographicAreasLongLivedAssetsTableTextBlock

[0000858877-15-000073:notes:5]
[same as prior period, unchanged from 0000858877-15-000051:notes:7]

[0000858877-15-000073:notes:6]
|  | October 24, 2015 |  | July 25, 2015 |
| Property and equipment, net: |  |  |  |
| United States | $ | 2,727 |  |  | $ | 2,733 |  |
| International | 619 |  |  | 599 |  |
| Total | $ | 3,346 |  |  | $ | 3,332 |  |


## csco:IncometaxprovisionTableTextBlock

[0000858877-15-000073:notes:7]
[same as prior period, unchanged from 0000858877-15-000051:notes:9]

[0000858877-15-000073:notes:8]
|  |  | Three Months Ended |
|  |  | October 24, 2015 |  | October 25, 2014 |
| Income before provision for income taxes |  | $ | 3,137 |  |  | $ | 2,360 |  |
| Provision for income taxes |  | $ | 707 |  |  | $ | 532 |  |
| Effective tax rate |  | 22.5 | % |  | 22.5 | % |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-15-000073:notes:9]
[same as prior period, unchanged from 0000858877-15-000051:notes:11]

[0000858877-15-000073:notes:10]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Revenue: |  |  |  |
| Switching | $ | 4,022 |  |  | $ | 3,846 |  |
| NGN Routing | 1,793 |  |  | 1,949 |  |
| Collaboration | 1,115 |  |  | 950 |  |
| Data Center | 859 |  |  | 692 |  |
| Service Provider Video | 850 |  |  | 871 |  |
| Wireless | 645 |  |  | 605 |  |
| Security | 485 |  |  | 455 |  |
| Other | 75 |  |  | 67 |  |
| Product | 9,844 |  |  | 9,435 |  |
| Service | 2,838 |  |  | 2,810 |  |
| Total | $ | 12,682 |  |  | $ | 12,245 |  |


## csco:ScheduleOfCommonStockRepurchasedTextBlock

[0000858877-15-000073:notes:11]
[same as prior period, unchanged from 0000858877-15-000051:notes:13]

[0000858877-15-000073:notes:12]
|  | SharesRepurchased |  | Weighted-Average Priceper Share |  | AmountRepurchased |
| Cumulative balance at July 25, 2015 | 4,443 |  |  | $ | 20.86 |  |  | $ | 92,679 |  |
| Repurchase of common stock under the stock repurchase program (1) | 45 |  |  | 26.83 |  |  | 1,207 |  |
| Cumulative balance at October 24, 2015 | 4,488 |  |  | $ | 20.92 |  |  | $ | 93,886 |  |

[0000858877-15-000073:notes:13]
(1) Includes stock repurchases of $33 million, which were pending settlement as of October 24, 2015. There were $36 million of stock repurchases that were pending settlement as of July 25, 2015.


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-15-000073:notes:14]
[same as prior period, unchanged from 0000858877-15-000051:notes:16]

[0000858877-15-000073:notes:15]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE THREE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | October 24, 2015 |  | October 25, 2014 |  | October 24, 2015 |  | October 25, 2014 |
| Equity derivatives |  | Other income (loss), net |  | $ | — |  |  | $ | 6 |  |  | $ | — |  |  | $ | (6 | ) |
| Interest rate derivatives |  | Interest expense |  | 127 |  |  | 73 |  |  | (125 | ) |  | (73 | ) |
| Total |  |  |  | $ | 127 |  |  | $ | 79 |  |  | $ | (125 | ) |  | $ | (79 | ) |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-15-000073:notes:16]
[same as prior period, unchanged from 0000858877-15-000051:notes:19]

[0000858877-15-000073:notes:17]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Amortization of purchased intangible assets: |  |  |  |
| Cost of sales | $ | 146 |  |  | $ | 189 |  |
| Operating expenses | 69 |  |  | 71 |  |
| Total | $ | 215 |  |  | $ | 260 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-15-000073:notes:18]
[same as prior period, unchanged from 0000858877-15-000051:notes:21]

[0000858877-15-000073:notes:19]
The following table presents details of the Company’s intangible assets acquired through acquisitions completed during the three months ended October 24, 2015 (in millions, except years):

[0000858877-15-000073:notes:20]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| MaintenanceNet | 5.0 |  | $ | 50 |  |  | 5.0 |  | $ | 2 |  |  | 2.0 |  | $ | 2 |  |  | $ | 11 |  |  | $ | 65 |  |
| OpenDNS | 5.0 |  | 43 |  |  | 7.0 |  | 15 |  |  | 1.0 |  | 2 |  |  | 1 |  |  | $ | 61 |  |
| Other | 5.0 |  | 4 |  |  | 0.0 |  | — |  |  | 0.0 |  | — |  |  | — |  |  | $ | 4 |  |
| Total |  |  | $ | 97 |  |  |  |  | $ | 17 |  |  |  |  | $ | 4 |  |  | $ | 12 |  |  | $ | 130 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-15-000073:notes:21]
[same as prior period, unchanged from 0000858877-15-000051:notes:24]

[0000858877-15-000073:notes:22]
| October 24, 2015 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,454 |  |  | $ | (1,902 | ) |  | $ | 1,552 |  |
| Customer relationships |  | 1,716 |  |  | (1,036 | ) |  | 680 |  |
| Other |  | 58 |  |  | (27 | ) |  | 31 |  |
| Total purchased intangible assets with finite lives |  | 5,228 |  |  | (2,965 | ) |  | 2,263 |  |
| In-process research and development, with indefinite lives |  | 29 |  |  | — |  |  | 29 |  |
| Total |  | $ | 5,257 |  |  | $ | (2,965 | ) |  | $ | 2,292 |  |

[0000858877-15-000073:notes:23]
| July 25, 2015 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,418 |  |  | $ | (1,818 | ) |  | $ | 1,600 |  |
| Customer relationships |  | 1,699 |  |  | (971 | ) |  | 728 |  |
| Other |  | 55 |  |  | (24 | ) |  | 31 |  |
| Total purchased intangible assets with finite lives |  | 5,172 |  |  | (2,813 | ) |  | 2,359 |  |
| In-process research and development, with indefinite lives |  | 17 |  |  | — |  |  | 17 |  |
| Total |  | $ | 5,189 |  |  | $ | (2,813 | ) |  | $ | 2,376 |  |


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-15-000073:notes:24]
[same as prior period, unchanged from 0000858877-15-000051:notes:27]

[0000858877-15-000073:notes:25]
[same as prior period, unchanged from 0000858877-15-000051:notes:28]

[0000858877-15-000073:notes:26]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC.  The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system.  Sales are attributed to a segment based on the ordering location of the customer.  The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments.  In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, impacts to cost of sales from purchase accounting adjustments to inventory, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-15-000073:notes:27]
Summarized financial information by segment for the three months ended October 24, 2015 and October 25, 2014, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker ("CODM"), is as follows (in millions):

[0000858877-15-000073:notes:28]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Revenue: |  |  |  |
| Americas | $ | 7,799 |  |  | $ | 7,501 |  |
| EMEA | 3,087 |  |  | 3,002 |  |
| APJC | 1,796 |  |  | 1,742 |  |
| Total | $ | 12,682 |  |  | $ | 12,245 |  |
| Gross margin: |  |  |  |
| Americas | $ | 4,950 |  |  | $ | 4,810 |  |
| EMEA | 1,982 |  |  | 1,915 |  |
| APJC | 1,078 |  |  | 1,025 |  |
| Segment total | 8,010 |  |  | 7,750 |  |
| Unallocated corporate items | (178 | ) |  | (417 | ) |
| Total | $ | 7,832 |  |  | $ | 7,333 |  |

[0000858877-15-000073:notes:29]
Revenue in the United States was $6.9 billion and $6.5 billion for the three months ended October 24, 2015 and October 25, 2014, respectively.

[0000858877-15-000073:notes:30]
[same as prior period, unchanged from 0000858877-15-000051:notes:33]

[0000858877-15-000073:notes:31]
The Company designs and sells broad lines of products, provides services and delivers integrated solutions to develop and connect networks around the world, building the Internet.  The Company groups its products and technologies into the following categories: Switching, NGN Routing, Collaboration, Data Center, Service Provider Video, Wireless, Security, and Other Products.  These products, primarily integrated by Cisco IOS Software, link geographically dispersed local-area networks (LANs), metropolitan-area networks (MANs), and wide-area networks (WANs).

[0000858877-15-000073:notes:32]
[same as prior period, unchanged from 0000858877-15-000051:notes:35]

[0000858877-15-000073:notes:33]
[same as prior period, unchanged from 0000858877-15-000051:notes:36]

[0000858877-15-000073:notes:34]
The majority of the Company’s assets, excluding cash and cash equivalents and investments, were attributable to its U.S. operations as of each of October 24, 2015 and July 25, 2015.  The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $54.1 billion and $53.4 billion as of October 24, 2015 and July 25, 2015, respectively, and the remaining $5.0 billion and $7.0 billion at the respective period ends were available in the United States.


## csco:StockRepurchasesSinceInceptionOfProgramTableTextBlock

[0000858877-15-000073:notes:35]
[same as prior period, unchanged from 0000858877-15-000051:notes:38]

[0000858877-15-000073:notes:36]
|  | Shares ofCommonStock |  | Common Stockand AdditionalPaid-In Capital |  | RetainedEarnings |  | Total CiscoShareholders’Equity |
| Repurchases of common stock under the repurchase program | 4,488 |  |  | $ | 23,001 |  |  | $ | 70,885 |  |  | $ | 93,886 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-15-000073:notes:37]
[same as prior period, unchanged from 0000858877-15-000051:notes:40]

[0000858877-15-000073:notes:38]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 25, 2015 | $ | 259 |  |  | $ | 87 |  |  | $ | 36 |  |  | $ | 382 |  |
| Provisions | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Recoveries (write-offs), net | (4 | ) |  | — |  |  | (3 | ) |  | (7 | ) |
| Foreign exchange and other | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Allowance for credit loss as of October 24, 2015 | $ | 255 |  |  | $ | 90 |  |  | $ | 33 |  |  | $ | 378 |  |
| Financing receivables as of October 24, 2015 (1) | $ | 3,360 |  |  | $ | 1,963 |  |  | $ | 3,598 |  |  | $ | 8,921 |  |

[0000858877-15-000073:notes:39]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 26, 2014 | $ | 233 |  |  | $ | 98 |  |  | $ | 18 |  |  | $ | 349 |  |
| Provisions | 22 |  |  | (13 | ) |  | 19 |  |  | 28 |  |
| Recoveries (write-offs), net | (4 | ) |  | 1 |  |  | — |  |  | (3 | ) |
| Foreign exchange and other | (3 | ) |  | (2 | ) |  | (1 | ) |  | (6 | ) |
| Allowance for credit loss as of October 25, 2014 | $ | 248 |  |  | $ | 84 |  |  | $ | 36 |  |  | $ | 368 |  |
| Financing receivables as of October 25, 2014 (1) | $ | 3,509 |  |  | $ | 1,744 |  |  | $ | 3,071 |  |  | $ | 8,324 |  |

[0000858877-15-000073:notes:40]
[same as prior period, unchanged from 0000858877-15-000051:notes:45]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-15-000073:notes:41]
| 3. | Acquisitions and Divestitures |

[0000858877-15-000073:notes:42]
The Company completed three acquisitions during the three months ended October 24, 2015.  A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-15-000073:notes:43]
|  | Purchase Consideration |  | Net Liabilities Assumed |  | Purchased Intangible Assets |  | Goodwill |
| MaintenanceNet | $ | 105 |  |  | $ | (21 | ) |  | $ | 65 |  |  | $ | 61 |  |
| OpenDNS | 545 |  |  | (9 | ) |  | 61 |  |  | 493 |  |
| Other | 6 |  |  | (1 | ) |  | 4 |  |  | 3 |  |
| Total | $ | 656 |  |  | $ | (31 | ) |  | $ | 130 |  |  | $ | 557 |  |

[0000858877-15-000073:notes:44]
On August 6, 2015, the Company completed its acquisition of privately held MaintenanceNet, Inc. ("MaintenanceNet"), a provider  of a cloud-based software platform that uses data analytics and automation to manage renewals of recurring customer contracts.  This acquisition is a component of the Company's strategy for its Services organization to simplify and digitize its business processes.

[0000858877-15-000073:notes:45]
On August 26, 2015, the Company completed its acquisition of privately held OpenDNS, Inc. ("OpenDNS"), a provider of advanced threat protection for endpoint devices. With the OpenDNS acquisition, the Company aims to strengthen its security offerings by adding broad visibility and threat intelligence delivered through a software-as-a-service platform.  Revenue from the OpenDNS acquisition has been included in the Company's Security product category.

[0000858877-15-000073:notes:46]
The total purchase consideration related to the Company’s acquisitions completed during the three months ended October 24, 2015 consisted of cash consideration and the assumption of vested share-based awards.  The total cash and cash equivalents acquired from these business combinations was approximately $9 million.  Total transaction costs related to the Company’s acquisition activities were $5 million and $2 million for the three months ended October 24, 2015 and October 25, 2014, respectively.  These transaction costs were expensed as incurred in general and administrative expenses ("G&A") in the Consolidated Statements of Operations.

[0000858877-15-000073:notes:47]
The Company’s purchase price allocation for acquisitions completed during recent periods is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available.  Additional information that existed as of the acquisition date but at that time was unknown to the Company may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date.  Adjustments in the purchase price allocation may require a recasting of the amounts allocated to goodwill retroactive to the period in which the acquisition occurred.

[0000858877-15-000073:notes:48]
The goodwill generated from the Company’s acquisitions completed during the three months ended October 24, 2015 is primarily related to expected synergies.  The goodwill is generally not deductible for income tax purposes.

[0000858877-15-000073:notes:49]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition.  Pro forma results of operations for the acquisitions completed during the three months ended October 24, 2015 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.

[0000858877-15-000073:notes:50]
Pending Divestiture  On July 22, 2015, the Company entered into an exclusive agreement to sell the client premises equipment portion of its Service Provider Video connected devices business to French-based Technicolor for approximately $600 million in cash and stock subject to certain adjustments provided for in the agreement.  In connection with this transaction, the Company had tangible assets of approximately $100 million which were held for sale (of which the most significant component is inventories of approximately $80 million), and current liabilities of approximately $120 million (primarily comprised of supply chain-related liabilities, warranties, rebates and other accrued liabilities), which were held for sale as of October 24, 2015.  The Company estimates that approximately $150 million of goodwill is attributable to this business, based on its relative fair value.  The Company is working to close the transaction during the second quarter of fiscal 2016, subject to customary closing conditions including the receipt of certain regulatory approvals.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-15-000073:notes:51]
| 12. | Commitments and Contingencies |

[0000858877-15-000073:notes:52]
| (a) | Operating Leases |

[0000858877-15-000073:notes:53]
The Company leases office space in many U.S. locations.  Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland, and the United Kingdom.  The Company also leases equipment and vehicles.  Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of October 24, 2015 are as follows (in millions):

[0000858877-15-000073:notes:54]
| Fiscal Year | Amount |
| 2016 (remaining nine months) | $ | 266 |  |
| 2017 | 263 |  |
| 2018 | 189 |  |
| 2019 | 105 |  |
| 2020 | 83 |  |
| Thereafter | 189 |  |
| Total | $ | 1,095 |  |

[0000858877-15-000073:notes:55]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-15-000073:notes:56]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products.  During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments.  In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of October 24, 2015 and July 25, 2015, the Company had total purchase commitments for inventory of $4,028 million and $4,078 million, respectively.

[0000858877-15-000073:notes:57]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory.  As of October 24, 2015 and July 25, 2015, the liability for these purchase commitments was $178 million and $156 million, respectively, and was included in other current liabilities.

[0000858877-15-000073:notes:58]
| (c) | Other Commitments |

[0000858877-15-000073:notes:59]
In connection with the Company’s acquisitions, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-15-000073:notes:60]
As of October 24, 2015, the Company estimated that future cash compensation expense of up to $253 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.

[0000858877-15-000073:notes:61]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market.  As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology.  Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements.  In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

[0000858877-15-000073:notes:62]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  The Company recorded compensation expense of $51 million and $53 million during the three months ended October 24, 2015 and October 25, 2014, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $841 million (which includes the $674 million that has been expensed to date), net of forfeitures.

[0000858877-15-000073:notes:63]
The former noncontrolling interest holders earned the maximum amount related to the first milestone payment and were paid   approximately $291 million for a portion of this amount during the first quarter of fiscal 2016.  The balance of the first milestone payment is expected to be paid primarily through the end of fiscal 2016.  The second milestone payment, to the extent earned, is expected to be paid primarily during the first half of fiscal 2017.

[0000858877-15-000073:notes:64]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand.  The funding commitments were $192 million and $205 million as of October 24, 2015 and July 25, 2015, respectively.

[0000858877-15-000073:notes:65]
| (d) | Product Warranties |

[0000858877-15-000073:notes:66]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-15-000073:notes:67]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Balance at beginning of period | $ | 449 |  |  | $ | 446 |  |
| Provision for warranties issued | 150 |  |  | 143 |  |
| Payments | (166 | ) |  | (153 | ) |
| Balance at end of period | $ | 433 |  |  | $ | 436 |  |

[0000858877-15-000073:notes:68]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead.  The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-15-000073:notes:69]
| (e) | Financing and Other Guarantees |

[0000858877-15-000073:notes:70]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers.  Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-15-000073:notes:71]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days.  These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements.  The volume of channel partner financing was $6.9 billion and $6.3 billion for the three months ended October 24, 2015 and October 25, 2014, respectively.  The balance of the channel partner financing subject to guarantees was $1.2 billion as of each October 24, 2015 and July 25, 2015.

[0000858877-15-000073:notes:72]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years.  The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $23 million and $26 million for the three months ended October 24, 2015 and October 25, 2014, respectively.

[0000858877-15-000073:notes:73]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 24, 2015 and July 25, 2015, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-15-000073:notes:74]
|  | October 24, 2015 |  | July 25, 2015 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 250 |  |  | $ | 288 |  |
| End user | 124 |  |  | 129 |  |
| Total | $ | 374 |  |  | $ | 417 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (96 | ) |  | $ | (127 | ) |
| End user | (100 | ) |  | (107 | ) |
| Total | $ | (196 | ) |  | $ | (234 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 178 |  |  | $ | 183 |  |

[0000858877-15-000073:notes:75]
Other Guarantees   The Company’s other guarantee arrangements as of October 24, 2015 and July 25, 2015 that were subject to recognition and disclosure requirements were not material.

[0000858877-15-000073:notes:76]
| (f) | Supplier Component Remediation Liability |

[0000858877-15-000073:notes:77]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010.  These components were widely used across the industry and are included in a number of the Company's products.  Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low.  However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem.  Although the majority of these products was beyond the Company's warranty terms, the Company has been proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  During the third quarter of fiscal 2015, an adjustment to product cost of sales of $164 million was recorded to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products.  The supplier component remediation liability as of October 24, 2015 and July 25, 2015 was $391 million and $408 million, respectively.

[0000858877-15-000073:notes:78]
| (g) | Indemnifications |

[0000858877-15-000073:notes:79]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters.  The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties.  These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-15-000073:notes:80]
The Company is providing such indemnifications, among other cases, in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) now pending in Kansas and Delaware.  Sprint alleges that the service provider customers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers.  Sprint seeks monetary damages.  Sprint’s cases in Kansas include claims against Comcast and Time Warner Cable, and the case in Delaware for which the Company is providing indemnification involves Cox Communications.  At the request of Sprint and Comcast, on August 5, 2015, the judge in Sprint’s Kansas action ordered a six-month stay of the patent litigation between those parties for them to pursue a resolution of their dispute. In addition, on May 15, 2015, the judge in Sprint's Delaware action against Cox ruled invalid six of the patents that Sprint asserted Cox had infringed and a final judgment was entered on August 27, 2015, of invalidity, which Sprint appealed on October 1, 2015.  In May 2015 the Company filed two declaratory judgment actions against Sprint seeking declarations that the patents Sprint asserted against the Company’s customers are invalid and/or not infringed.  Cox has filed a motion for summary judgment of non-infringement for the five remaining Sprint patents that are actively being litigated against Cox in Delaware, Comcast has also won a judgment of non-infringement, now being appealed by Sprint, in a separate case brought against it by Sprint in Delaware.  In light of the invalidity rulings against Sprint in Delaware, on October 8, 2015, the judge in Sprint’s Kansas actions ordered an additional stay of Sprint’s Kansas actions including the case against Time Warner Cable, pending resolution of Sprint’s appeal of the Delaware Judge’s judgment of invalidity in the Cox case.

[0000858877-15-000073:notes:81]
The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims and/or that Sprint's patents are invalid.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should the plaintiff prevail in litigation, mediation, or settlement, the Company, in accordance with its agreement, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

[0000858877-15-000073:notes:82]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-15-000073:notes:83]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement.  Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-15-000073:notes:84]
| (h) | Legal Proceedings |

[0000858877-15-000073:notes:85]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer.  Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties.  In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.  In the first quarter of fiscal 2013, the Brazilian federal tax authorities asserted an additional claim against the Company’s Brazilian subsidiary based on a theory of joint liability with respect to an alleged underpayment of income taxes, social taxes, interest, and penalties by a Brazilian distributor.

[0000858877-15-000073:notes:86]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007.  The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $222 million for the alleged evasion of import and other taxes, approximately $1.0 billion for interest, and approximately $1.0 billion for various penalties, all determined using an exchange rate as of October 24, 2015.  The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously.  While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any.  The Company does not expect a final judicial determination for several years.

[0000858877-15-000073:notes:87]
Russia and the Commonwealth of Independent States    At the request of the U.S. Securities and Exchange Commission (SEC) and the U.S. Department of Justice, the Company is conducting an investigation into allegations that the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries.  The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the SEC and the Department of Justice.  While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.  The countries that are the subject of the investigation collectively comprise less than 2% of the Company’s revenues.

[0000858877-15-000073:notes:88]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation.  While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-15-000073:notes:89]
[same as prior period, unchanged from 0000858877-15-000051:notes:92]

[0000858877-15-000073:notes:90]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, for the three months ended October 24, 2015 and October 25, 2014 are summarized as follows (in millions):

[0000858877-15-000073:notes:91]
|  | Net Unrealized Gains on Available-for-Sale Investments |  | Net Unrealized Losses Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains and Losses |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 25, 2015 | $ | 310 |  |  | $ | (16 | ) |  | $ | (233 | ) |  | $ | 61 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (155 | ) |  | (4 | ) |  | (178 | ) |  | (337 | ) |
| (Gains) losses reclassified out of AOCI | 1 |  |  | 3 |  |  | 1 |  |  | 5 |  |
| Tax benefit (expense) | 56 |  |  | 2 |  |  | (39 | ) |  | 19 |  |
| BALANCE AT OCTOBER 24, 2015 | $ | 212 |  |  | $ | (15 | ) |  | $ | (449 | ) |  | $ | (252 | ) |

[0000858877-15-000073:notes:92]
|  | Net Unrealized Gains on Available-for-Sale Investments |  | Net Unrealized Losses Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains and Losses |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 26, 2014 | $ | 424 |  |  | $ | (12 | ) |  | $ | 265 |  |  | $ | 677 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (36 | ) |  | (56 | ) |  | (161 | ) |  | (253 | ) |
| (Gains) losses reclassified out of AOCI | (7 | ) |  | 4 |  |  | — |  |  | (3 | ) |
| Tax benefit (expense) | 16 |  |  | 3 |  |  | 11 |  |  | 30 |  |
| BALANCE AT OCTOBER 25, 2014 | $ | 397 |  |  | $ | (61 | ) |  | $ | 115 |  |  | $ | 451 |  |

[0000858877-15-000073:notes:93]
The net gains (losses) reclassified out of AOCI into the Consolidated Statements of Operations, with line item location, during each period were as follows (in millions):

[0000858877-15-000073:notes:94]
|  |  | Three Months Ended |  |  |
|  |  | October 24, 2015 |  | October 25, 2014 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains on available-for-sale investments |  |  |  |  |  |  |
|  |  | $ | (1 | ) |  | $ | 7 |  |  | Other income (loss), net |
| Net unrealized losses on cash flow hedging instruments |  |  |  |  |  |  |
| Foreign currency derivatives |  | (2 | ) |  | (3 | ) |  | Operating expenses |
| Foreign currency derivatives |  | (1 | ) |  | (1 | ) |  | Cost of sales—service |
|  |  | (3 | ) |  | (4 | ) |  |  |
| Cumulative translation adjustment and actuarial gains and losses |  |  |  |  |  |  |
|  |  | (1 | ) |  | — |  |  | Operating expenses |
| Total amounts reclassified out of AOCI |  | $ | (5 | ) |  | $ | 3 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-15-000073:notes:95]
| 10. | Borrowings |

[0000858877-15-000073:notes:96]
| (a) | Short-Term Debt |

[0000858877-15-000073:notes:97]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-15-000073:notes:98]
|  | October 24, 2015 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 3,025 |  |  | 3.09 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other short-term debt | 2 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total | $ | 3,027 |  |  |  |  | $ | 3,897 |  |  |  |

[0000858877-15-000073:notes:99]
The effective interest rate on the current portion of long-term debt includes the impact of interest rate swaps, as discussed further in "

[0000858877-15-000073:notes:100]
| (b) | Long-Term Debt |

[0000858877-15-000073:notes:101]
."  Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements.  These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.

[0000858877-15-000073:notes:102]
On September 3, 2015, the Company repaid an aggregate principal amount of $850 million upon the maturity of its 2015 Floating-Rate Notes.

[0000858877-15-000073:notes:103]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes.  The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes.  The Company had no commercial paper notes outstanding as of each of October 24, 2015 and July 25, 2015.

[0000858877-15-000073:notes:104]
(b)

[0000858877-15-000073:notes:105]
Long-Term Debt

[0000858877-15-000073:notes:106]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-15-000073:notes:107]
|  |  |  | October 24, 2015 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.68% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 0.71% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.88% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.09% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.60% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.90% |  | 750 |  |  | 0.85% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.70% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.81% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.02% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.97% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.22% |  | 500 |  |  | 1.21% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.09% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.38% |  | 500 |  |  | 1.37% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  |  |  | 1 |  |  | 2.08% |
| Total |  |  | 24,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (128 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 347 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 24,619 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,025 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 21,594 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 24,619 |  |  |  |  | $ | 25,351 |  |  |  |

[0000858877-15-000073:notes:108]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps in prior periods with an aggregate notional amount of $11.4 billion designated as fair value hedges of certain of its fixed-rate senior notes.  In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR).  The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.  For additional information, see Note 11.

[0000858877-15-000073:notes:109]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount and issuance costs, and, if applicable, adjustments related to hedging.  Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes.  Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

[0000858877-15-000073:notes:110]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.”  As of October 24, 2015, the Company was in compliance with all debt covenants.

[0000858877-15-000073:notes:111]
As of October 24, 2015, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-15-000073:notes:112]
| Fiscal Year | Amount |
| 2016 (remaining nine months) | $ | 3,000 |  |
| 2017 | 4,150 |  |
| 2018 | 2,500 |  |
| 2019 | 4,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 6,500 |  |
| Total | $ | 24,400 |  |

[0000858877-15-000073:notes:113]
| (c) | Credit Facility |

[0000858877-15-000073:notes:114]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020.  Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero.  The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement.

[0000858877-15-000073:notes:115]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.  As of October 24, 2015, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-15-000073:notes:116]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 9,689 |  |  | $ | 9,757 |  |
| Product: |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  | 4,888 |  |  | 4,766 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  | 585 |  |  | 660 |  |
| Total product deferred revenue |  | 5,473 |  |  | 5,426 |  |
| Total |  | $ | 15,162 |  |  | $ | 15,183 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,821 |  |  | $ | 9,824 |  |
| Noncurrent |  | 5,341 |  |  | 5,359 |  |
| Total |  | $ | 15,162 |  |  | $ | 15,183 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-15-000073:notes:117]
[same as prior period, unchanged from 0000858877-15-000051:notes:121]

[0000858877-15-000073:notes:118]
[same as prior period, unchanged from 0000858877-15-000051:notes:122]

[0000858877-15-000073:notes:119]
[same as prior period, unchanged from 0000858877-15-000051:notes:123]

[0000858877-15-000073:notes:120]
[same as prior period, unchanged from 0000858877-15-000051:notes:124]

[0000858877-15-000073:notes:121]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | October 24, 2015 |  | July 25, 2015 |  | Balance Sheet Line Item |  | October 24, 2015 |  | July 25, 2015 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 9 |  |  | $ | 10 |  |  | Other current liabilities |  | $ | 11 |  |  | $ | 11 |  |
| Interest rate derivatives | Other assets |  | 330 |  |  | 202 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 339 |  |  | 212 |  |  |  |  | 11 |  |  | 11 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 1 |  |  | 2 |  |  | Other current liabilities |  | 3 |  |  | 1 |  |
| Equity derivatives | Other assets |  | 3 |  |  | 4 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 4 |  |  | 6 |  |  |  |  | 3 |  |  | 1 |  |
| Total |  |  | $ | 343 |  |  | $ | 218 |  |  |  |  | $ | 14 |  |  | $ | 12 |  |

[0000858877-15-000073:notes:122]
[same as prior period, unchanged from 0000858877-15-000051:notes:126]

[0000858877-15-000073:notes:123]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE THREE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THETHREE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | October 24, 2015 |  | October 25, 2014 |  | Line Item in Statements of Operations |  | October 24, 2015 |  | October 25, 2014 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (4 | ) |  | $ | (56 | ) |  | Operating expenses |  | $ | (2 | ) |  | $ | (3 | ) |
|  |  |  |  |  |  | Cost of sales—service |  | (1 | ) |  | (1 | ) |
| Total |  | $ | (4 | ) |  | $ | (56 | ) |  |  |  | $ | (3 | ) |  | $ | (4 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 20 |  |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-15-000073:notes:124]
As of October 24, 2015, the Company estimates that approximately $7 million of net derivative losses related to its cash flow hedges included in accumulated other comprehensive income/loss (AOCI) will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-15-000073:notes:125]
[same as prior period, unchanged from 0000858877-15-000051:notes:130]

[0000858877-15-000073:notes:126]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | October 24, 2015 |  | October 25, 2014 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | 4 |  |  | $ | (58 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | (16 | ) |  | (13 | ) |
| Equity derivatives |  | Other income (loss), net |  | 10 |  |  | (4 | ) |
| Total |  |  |  | $ | (2 | ) |  | $ | (75 | ) |

[0000858877-15-000073:notes:127]
[same as prior period, unchanged from 0000858877-15-000051:notes:132]

[0000858877-15-000073:notes:128]
|  | October 24, 2015 |  | July 25, 2015 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 1,083 |  |  | $ | 1,201 |  |
| Interest rate derivatives | 11,400 |  |  | 11,400 |  |
| Net investment hedging instruments | 219 |  |  | 192 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,244 |  |  | 2,023 |  |
| Total return swaps—deferred compensation | 473 |  |  | 462 |  |
| Total | $ | 15,419 |  |  | $ | 15,278 |  |

[0000858877-15-000073:notes:129]
[same as prior period, unchanged from 0000858877-15-000051:notes:134]

[0000858877-15-000073:notes:130]
[same as prior period, unchanged from 0000858877-15-000051:notes:135]

[0000858877-15-000073:notes:131]
|  | October 24, 2015 |
|  | Gross Amounts Offset in the Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 343 |  |  | $ | — |  |  | $ | 343 |  |  | $ | (14 | ) |  | $ | (225 | ) |  | $ | 104 |  |
| Derivatives liabilities | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |  | $ | (14 | ) |  | $ | — |  |  | $ | — |  |

[0000858877-15-000073:notes:132]
|  | July 25, 2015 |
|  | Gross Amounts Offset in the Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 218 |  |  | $ | — |  |  | $ | 218 |  |  | $ | (12 | ) |  | $ | (124 | ) |  | $ | 82 |  |
| Derivatives liabilities | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |  | $ | (12 | ) |  | $ | — |  |  | $ | — |  |

[0000858877-15-000073:notes:133]
[same as prior period, unchanged from 0000858877-15-000051:notes:138]

[0000858877-15-000073:notes:134]
[same as prior period, unchanged from 0000858877-15-000051:notes:139]

[0000858877-15-000073:notes:135]
[same as prior period, unchanged from 0000858877-15-000051:notes:140]

[0000858877-15-000073:notes:136]
[same as prior period, unchanged from 0000858877-15-000051:notes:141]

[0000858877-15-000073:notes:137]
[same as prior period, unchanged from 0000858877-15-000051:notes:142]

[0000858877-15-000073:notes:138]
[same as prior period, unchanged from 0000858877-15-000051:notes:143]

[0000858877-15-000073:notes:139]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk.  To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges.  As of October 24, 2015 and July 25, 2015, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-15-000073:notes:140]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt   In fiscal 2016, the Company did not enter into any interest rate swaps.  In prior fiscal years, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal years 2016 through 2025.  Under these interest rate swaps, the Company receives fixed-rate interest payments and makes interest payments based on LIBOR plus a fixed number of basis points.  The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR.  The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.  The fair value of the interest rate swaps was reflected in other assets and other long-term liabilities.

[0000858877-15-000073:notes:141]
[same as prior period, unchanged from 0000858877-15-000051:notes:146]

[0000858877-15-000073:notes:142]
[same as prior period, unchanged from 0000858877-15-000051:notes:147]

[0000858877-15-000073:notes:143]
[same as prior period, unchanged from 0000858877-15-000051:notes:148]

[0000858877-15-000073:notes:144]
[same as prior period, unchanged from 0000858877-15-000051:notes:149]

[0000858877-15-000073:notes:145]
[same as prior period, unchanged from 0000858877-15-000051:notes:150]

[0000858877-15-000073:notes:146]
[same as prior period, unchanged from 0000858877-15-000051:notes:151]

[0000858877-15-000073:notes:147]
[same as prior period, unchanged from 0000858877-15-000051:notes:152]

[0000858877-15-000073:notes:148]
In addition, certain derivative instruments are executed under agreements that have provisions requiring the Company and the counterparty to maintain a specified credit rating from certain credit-rating agencies.  Under such agreements, if the Company’s or the counterparty’s credit rating falls below a specified credit rating, either party has the right to request collateral on the derivatives’ net liability position.  No such derivatives were in a net liability position as of October 24, 2015 or July 25, 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-15-000073:notes:149]
[same as prior period, unchanged from 0000858877-15-000051:notes:154]

[0000858877-15-000073:notes:150]
[same as prior period, unchanged from 0000858877-15-000051:notes:155]

[0000858877-15-000073:notes:151]
Stock Incentive Plan Program Description    As of October 24, 2015, the Company had four stock incentive plans: the 2005 Stock Incentive Plan (the “2005 Plan”); the 1996 Stock Incentive Plan (the “1996 Plan”); the Cisco Systems, Inc. SA Acquisition Long-Term Incentive Plan (the “SA Acquisition Plan”); and the Cisco Systems, Inc. WebEx Acquisition Long-Term Incentive Plan (the “WebEx Acquisition Plan”).  In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof.  Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company.  The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors.  Since the inception of the stock incentive plans, the Company has granted share-based awards to a significant percentage of its employees, and the majority has been granted to employees below the vice president level.  The Company’s primary stock incentive plans are summarized as follows:

[0000858877-15-000073:notes:152]
2005 Plan    As of October 24, 2015, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus the number of any shares underlying awards outstanding on November 15, 2007 under the 1996 Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that are forfeited or are terminated for any other reason before being exercised or settled.  If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan.  Starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-15-000073:notes:153]
Pursuant to an amendment approved by the Company’s shareholders on November 12, 2009, the number of shares available for issuance under the 2005 Plan is reduced by 1.5 shares for each share awarded as a stock grant or a stock unit, and any shares underlying awards outstanding under the 1996 Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that expire unexercised at the end of their maximum terms become available for reissuance under the 2005 Plan.  The 2005 Plan permits the granting of stock options, restricted stock, and restricted stock units ("RSUs"), the vesting of which may be performance-based or market-based along with the requisite service requirement, and stock appreciation rights to employees (including employee directors and officers), consultants of the Company and its subsidiaries and affiliates, and non-employee directors of the Company. Stock options and stock appreciation rights granted under the 2005 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date and prior to November 12, 2009 have an expiration date no later than nine years from the grant date.  The expiration date for stock options and stock appreciation rights granted subsequent to the amendment approved on November 12, 2009 shall be no later than 10 years from the grant date.

[0000858877-15-000073:notes:154]
The stock options will generally become exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively.  Time-based stock grants and time-based RSUs will generally vest with respect to 20% or 25% of the shares or share units covered by the grant annually over the vesting period.  The majority of the performance-based and market-based RSUs vests at the end of the three-year requisite service period or earlier if the award recipient meets certain retirement eligibility conditions.  Certain performance-based RSUs, that are based on the achievement of financial and/or non-financial operating goals, typically vest upon the achievement of milestones (and may require subsequent service periods), with overall vesting of the shares underlying the award ranging from six months to three years.  The Compensation and Management Development Committee of the Board of Directors has the discretion to use different vesting schedules.  Stock appreciation rights may be awarded in combination with stock options or stock grants, and such awards shall provide that the stock appreciation rights will not be exercisable unless the related stock options or stock grants are forfeited.  Stock grants may be awarded in combination with non-statutory stock options, and such awards may provide that the stock grants will be forfeited in the event that the related non-statutory stock options are exercised.

[0000858877-15-000073:notes:155]
[same as prior period, unchanged from 0000858877-15-000051:notes:160]

[0000858877-15-000073:notes:156]
[same as prior period, unchanged from 0000858877-15-000051:notes:161]

[0000858877-15-000073:notes:157]
[same as prior period, unchanged from 0000858877-15-000051:notes:162]

[0000858877-15-000073:notes:158]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 621 million shares of the Company’s common stock have been reserved for issuance as of October 24, 2015.  Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods.  Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period.  The Purchase Plan is scheduled to terminate on January 3, 2020.  No shares were issued under the Purchase Plan during each of the three months ended October 24, 2015 and October 25, 2014.  As of October 24, 2015, 148 million shares were available for issuance under the Purchase Plan.

[0000858877-15-000073:notes:159]
[same as prior period, unchanged from 0000858877-15-000051:notes:164]

[0000858877-15-000073:notes:160]
[same as prior period, unchanged from 0000858877-15-000051:notes:165]

[0000858877-15-000073:notes:161]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Cost of sales—product | $ | 13 |  |  | $ | 11 |  |
| Cost of sales—service | 38 |  |  | 37 |  |
| Share-based compensation expense in cost of sales | 51 |  |  | 48 |  |
| Research and development | 114 |  |  | 119 |  |
| Sales and marketing | 139 |  |  | 147 |  |
| General and administrative | 57 |  |  | 59 |  |
| Restructuring and other charges | 15 |  |  | (4 | ) |
| Share-based compensation expense in operating expenses | 325 |  |  | 321 |  |
| Total share-based compensation expense | $ | 376 |  |  | $ | 369 |  |
| Income tax benefit for share-based compensation | $ | 95 |  |  | $ | 94 |  |

[0000858877-15-000073:notes:162]
As of October 24, 2015, the total compensation cost related to unvested share-based awards not yet recognized was $2.3 billion, which is expected to be recognized over approximately 2.6 years on a weighted-average basis.

[0000858877-15-000073:notes:163]
[same as prior period, unchanged from 0000858877-15-000051:notes:168]

[0000858877-15-000073:notes:164]
[same as prior period, unchanged from 0000858877-15-000051:notes:169]

[0000858877-15-000073:notes:165]
|  | Share-Based Awards Available for Grant |
| BALANCE AT JULY 26, 2014 | 310 |  |
| Restricted stock, stock units, and other share-based awards granted | (101 | ) |
| Share-based awards canceled/forfeited/expired | 40 |  |
| Shares withheld for taxes and not issued | 27 |  |
| BALANCE AT JULY 25, 2015 | 276 |  |
| Restricted stock, stock units, and other share-based awards granted | (23 | ) |
| Share-based awards canceled/forfeited/expired | 8 |  |
| Shares withheld for taxes and not issued | 22 |  |
| Other | 1 |  |
| BALANCE AT OCTOBER 24, 2015 | 284 |  |

[0000858877-15-000073:notes:166]
[same as prior period, unchanged from 0000858877-15-000051:notes:171]

[0000858877-15-000073:notes:167]
[same as prior period, unchanged from 0000858877-15-000051:notes:172]

[0000858877-15-000073:notes:168]
[same as prior period, unchanged from 0000858877-15-000051:notes:173]

[0000858877-15-000073:notes:169]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 26, 2014 | 149 |  |  | $ | 19.54 |  |  |  |
| Granted and assumed | 67 |  |  | 25.29 |  |  |  |
| Vested | (57 | ) |  | 19.82 |  |  | $ | 1,517 |  |
| Canceled/forfeited | (16 | ) |  | 20.17 |  |  |  |
| UNVESTED BALANCE AT JULY 25, 2015 | 143 |  |  | 22.08 |  |  |  |
| Granted and assumed | 15 |  |  | 24.07 |  |  |  |
| Vested | (37 | ) |  | 20.24 |  |  | $ | 970 |  |
| Canceled/forfeited | (5 | ) |  | 22.10 |  |  |  |
| UNVESTED BALANCE AT OCTOBER 24, 2015 | 116 |  |  | $ | 22.93 |  |  |  |

[0000858877-15-000073:notes:170]
[same as prior period, unchanged from 0000858877-15-000051:notes:175]

[0000858877-15-000073:notes:171]
[same as prior period, unchanged from 0000858877-15-000051:notes:176]

[0000858877-15-000073:notes:172]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 26, 2014 | 187 |  |  | $ | 26.03 |  |
| Assumed from acquisitions | 1 |  |  | 2.60 |  |
| Exercised | (71 | ) |  | 21.15 |  |
| Canceled/forfeited/expired | (14 | ) |  | 29.68 |  |
| BALANCE AT JULY 25, 2015 | 103 |  |  | 28.68 |  |
| Assumed from acquisitions | 3 |  |  | 2.13 |  |
| Exercised | (17 | ) |  | 22.10 |  |
| Canceled/forfeited/expired | (5 | ) |  | 30.15 |  |
| BALANCE AT OCTOBER 24, 2015 | 84 |  |  | $ | 29.09 |  |

[0000858877-15-000073:notes:173]
The following table summarizes significant ranges of outstanding and exercisable stock options as of October 24, 2015 (in millions, except years and share prices):

[0000858877-15-000073:notes:174]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 20.00 |  | 5 |  |  | 6.1 |  | $ | 3.88 |  |  | $ | 150 |  |  | 2 |  |  | $ | 5.14 |  |  | $ | 76 |  |
| $ 20.01 – 25.00 |  | 3 |  |  | 0.9 |  | 23.12 |  |  | 16 |  |  | 3 |  |  | 23.12 |  |  | 16 |  |
| $ 25.01 – 30.00 |  | 13 |  |  | 0.8 |  | 26.84 |  |  | 32 |  |  | 13 |  |  | 26.85 |  |  | 32 |  |
| $ 30.01 – 35.00 |  | 63 |  |  | 0.9 |  | 32.16 |  |  | — |  |  | 63 |  |  | 32.16 |  |  | — |  |
| Total |  | 84 |  |  | 1.2 |  | $ | 29.09 |  |  | $ | 198 |  |  | 81 |  |  | $ | 29.99 |  |  | $ | 124 |  |

[0000858877-15-000073:notes:175]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on the Company’s closing stock price of $29.35 as of October 23, 2015, that would have been received by the option holders had those option holders exercised their stock options as of that date.  The total number of in-the-money stock options exercisable as of October 24, 2015 was 18 million.  As of July 25, 2015, 102 million outstanding stock options were exercisable and the weighted-average exercise price was $29.02.

[0000858877-15-000073:notes:176]
[same as prior period, unchanged from 0000858877-15-000051:notes:181]

[0000858877-15-000073:notes:177]
Time-based restricted stock units and performance-based restricted stock units ("PRSUs") that are based on the Company’s financial performance metrics or non-financial operating goals are valued using the market value of the Company’s common stock on the date of grant, discounted for the present value of expected dividends.  On the date of grant, the Company estimated the fair value of the total shareholder return (TSR) component of the PRSUs using a Monte Carlo simulation model.  The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-15-000073:notes:178]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE RESTRICTED STOCK UNITS |
| Three Months Ended | October 24, 2015 |  | October 25, 2014 |  | October 24, 2015 |  | October 25, 2014 |
| Number of shares granted (in millions) | 9 |  |  | 9 |  |  | 4 |  |  | 6 |  |
| Grant date fair value per share | $ | 24.02 |  |  | $ | 23.10 |  |  | $ | 24.61 |  |  | $ | 23.31 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.2 | % |  | 3.0 | % |  | 3.2 | % |  | 3.0 | % |
| Range of risk-free interest rates | 0.0% – 1.1% |  |  | 0.0% – 1.8% |  |  | 0.0% – 1.1% |  |  | 0.0% – 1.8% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 15.3% – 54.3% |  |  | 15.1% – 70.0% |  |

[0000858877-15-000073:notes:179]
The PRSUs granted during the periods presented are contingent on the achievement of the Company’s financial performance metrics, its comparative market-based returns, or the achievement of financial and non-financial operating goals.  For the awards based on financial performance metrics or comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period.  Generally, the remaining 50% of the PRSUs are earned based on the Company’s TSR measured against the benchmark TSR of a peer group over the same period.  Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of the Company's financial performance metrics or its comparative market-based returns and 0% to 100% of the target shares granted contingent on the achievement of non-financial operating goals.


## us-gaap:EarningsPerShareTextBlock

[0000858877-15-000073:notes:180]
[same as prior period, unchanged from 0000858877-15-000051:notes:186]

[0000858877-15-000073:notes:181]
[same as prior period, unchanged from 0000858877-15-000051:notes:187]

[0000858877-15-000073:notes:182]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Net income | $ | 2,430 |  |  | $ | 1,828 |  |
| Weighted-average shares—basic | 5,080 |  |  | 5,112 |  |
| Effect of dilutive potential common shares | 33 |  |  | 44 |  |
| Weighted-average shares—diluted | 5,113 |  |  | 5,156 |  |
| Net income per share—basic | $ | 0.48 |  |  | $ | 0.36 |  |
| Net income per share—diluted | $ | 0.48 |  |  | $ | 0.35 |  |
| Antidilutive employee share-based awards, excluded | 86 |  |  | 114 |  |

[0000858877-15-000073:notes:183]
[same as prior period, unchanged from 0000858877-15-000051:notes:189]


## us-gaap:EquityMethodInvestmentsTextBlock

[0000858877-15-000073:notes:184]
For such investments that were accounted for under the equity and cost method as of October 24, 2015 and July 25, 2015, the amounts are summarized in the following table (in millions):

[0000858877-15-000073:notes:185]
|  | October 24, 2015 |  | July 25, 2015 |
| Equity method investments | $ | 619 |  |  | $ | 578 |  |
| Cost method investments | 309 |  |  | 319 |  |
| Total | $ | 928 |  |  | $ | 897 |  |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-15-000073:notes:186]
[same as prior period, unchanged from 0000858877-15-000051:notes:192]

[0000858877-15-000073:notes:187]
|  | LOSSES FOR THETHREE MONTHS ENDED |
|  | October 24, 2015 |  | October 25, 2014 |
| Investments in privately held companies (impaired) | $ | (17 | ) |  | $ | (1 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-15-000073:notes:188]
[same as prior period, unchanged from 0000858877-15-000051:notes:194]

[0000858877-15-000073:notes:189]
[same as prior period, unchanged from 0000858877-15-000051:notes:195]

[0000858877-15-000073:notes:190]
[same as prior period, unchanged from 0000858877-15-000051:notes:196]

[0000858877-15-000073:notes:191]
[same as prior period, unchanged from 0000858877-15-000051:notes:197]

[0000858877-15-000073:notes:192]
[same as prior period, unchanged from 0000858877-15-000051:notes:198]

[0000858877-15-000073:notes:193]
[same as prior period, unchanged from 0000858877-15-000051:notes:199]

[0000858877-15-000073:notes:194]
[same as prior period, unchanged from 0000858877-15-000051:notes:200]

[0000858877-15-000073:notes:195]
[same as prior period, unchanged from 0000858877-15-000051:notes:201]

[0000858877-15-000073:notes:196]
Assets and liabilities measured at fair value on a recurring basis as of October 24, 2015 and July 25, 2015 were as follows (in millions):

[0000858877-15-000073:notes:197]
|  | OCTOBER 24, 2015FAIR VALUE MEASUREMENTS |  | JULY 25, 2015FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,317 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,317 |  |  | $ | 5,336 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,336 |  |
| Corporate debt securities | — |  |  | 25 |  |  | — |  |  | 25 |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 27,471 |  |  | — |  |  | 27,471 |  |  | — |  |  | 29,939 |  |  | — |  |  | 29,939 |  |
| U.S. government agency securities | — |  |  | 3,617 |  |  | — |  |  | 3,617 |  |  | — |  |  | 3,663 |  |  | — |  |  | 3,663 |  |
| Non-U.S. government and agency securities | — |  |  | 1,136 |  |  | — |  |  | 1,136 |  |  | — |  |  | 1,128 |  |  | — |  |  | 1,128 |  |
| Corporate debt securities | — |  |  | 18,306 |  |  | — |  |  | 18,306 |  |  | — |  |  | 15,783 |  |  | — |  |  | 15,783 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,469 |  |  | — |  |  | 1,469 |  |  | — |  |  | 1,461 |  |  | — |  |  | 1,461 |  |
| Publicly traded equity securities | 1,350 |  |  | — |  |  | — |  |  | 1,350 |  |  | 1,565 |  |  | — |  |  | — |  |  | 1,565 |  |
| Derivative assets | — |  |  | 340 |  |  | 3 |  |  | 343 |  |  | — |  |  | 214 |  |  | 4 |  |  | 218 |  |
| Total | $ | 5,667 |  |  | $ | 52,364 |  |  | $ | 3 |  |  | $ | 58,034 |  |  | $ | 6,901 |  |  | $ | 52,202 |  |  | $ | 4 |  |  | $ | 59,107 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |  | $ | — |  |  | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |
| Total | $ | — |  |  | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |  | $ | — |  |  | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |

[0000858877-15-000073:notes:198]
[same as prior period, unchanged from 0000858877-15-000051:notes:204]

[0000858877-15-000073:notes:199]
[same as prior period, unchanged from 0000858877-15-000051:notes:205]

[0000858877-15-000073:notes:200]
[same as prior period, unchanged from 0000858877-15-000051:notes:206]

[0000858877-15-000073:notes:201]
[same as prior period, unchanged from 0000858877-15-000051:notes:207]

[0000858877-15-000073:notes:202]
The fair value measurement of the impaired investments was classified as Level 3 because significant unobservable inputs were used in the valuation due to the absence of quoted market prices and inherent lack of liquidity.  Significant unobservable inputs, which included financial metrics of comparable private and public companies, financial condition and near-term prospects of the investees, recent  financing activities of the investees, and the investees’ capital structure as well as other economic variables, reflected the assumptions market participants would use in pricing these assets.  The impairment charges, representing the difference between the net book value and the fair value as a result of the evaluation, were recorded to other income (loss), net.  The remaining carrying value of the investments that were impaired was $6 million as of October 24, 2015.

[0000858877-15-000073:notes:203]
[same as prior period, unchanged from 0000858877-15-000051:notes:211]

[0000858877-15-000073:notes:204]
The carrying value of the Company’s investments in privately held companies that were accounted for under the cost method was $309 million and $319 million as of October 24, 2015 and July 25, 2015, respectively.  It was not practicable to estimate the fair value of this portfolio.

[0000858877-15-000073:notes:205]
The fair value of the Company’s short-term loan receivables and financed service contracts approximates their carrying value due to their short duration.  The aggregate carrying value of the Company’s long-term loan receivables and financed service contracts and other as of October 24, 2015 and July 25, 2015 was $2.4 billion and $2.2 billion, respectively.  The estimated fair value of the Company’s long-term loan receivables and financed service contracts and other approximates their carrying value.  The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-15-000073:notes:206]
As of October 24, 2015, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.  As of October 24, 2015, the fair value of the Company’s senior notes and other long-term debt was $26.0 billion with a carrying amount of $24.6 billion.  This compares to a fair value of $26.6 billion and a carrying amount of $25.4 billion as of July 25, 2015.  The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-15-000073:notes:207]
Gross receivables less unearned income categorized by the Company’s internal credit risk rating as of October 24, 2015 and July 25, 2015 are summarized as follows (in millions):

[0000858877-15-000073:notes:208]
|  | INTERNAL CREDIT RISK RATING |
| October 24, 2015 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,670 |  |  | $ | 1,336 |  |  | $ | 129 |  |  | $ | 3,135 |  |
| Loan receivables | 1,039 |  |  | 783 |  |  | 141 |  |  | 1,963 |  |
| Financed service contracts and other | 2,111 |  |  | 1,437 |  |  | 50 |  |  | 3,598 |  |
| Total | $ | 4,820 |  |  | $ | 3,556 |  |  | $ | 320 |  |  | $ | 8,696 |  |

[0000858877-15-000073:notes:209]
|  | INTERNAL CREDIT RISK RATING |
| July 25, 2015 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,688 |  |  | $ | 1,342 |  |  | $ | 141 |  |  | $ | 3,171 |  |
| Loan receivables | 788 |  |  | 823 |  |  | 152 |  |  | 1,763 |  |
| Financed service contracts and other | 2,133 |  |  | 1,389 |  |  | 51 |  |  | 3,573 |  |
| Total | $ | 4,609 |  |  | $ | 3,554 |  |  | $ | 344 |  |  | $ | 8,507 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-15-000073:notes:210]
[same as prior period, unchanged from 0000858877-15-000051:notes:218]

[0000858877-15-000073:notes:211]
[same as prior period, unchanged from 0000858877-15-000051:notes:219]

[0000858877-15-000073:notes:212]
[same as prior period, unchanged from 0000858877-15-000051:notes:220]

[0000858877-15-000073:notes:213]
[same as prior period, unchanged from 0000858877-15-000051:notes:221]

[0000858877-15-000073:notes:214]
| October 24, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Gross | $ | 3,317 |  |  | $ | 1,963 |  |  | $ | 3,598 |  |  | $ | 8,878 |  |
| Residual value | 225 |  |  | — |  |  | — |  |  | 225 |  |
| Unearned income | (182 | ) |  | — |  |  | — |  |  | (182 | ) |
| Allowance for credit loss | (255 | ) |  | (90 | ) |  | (33 | ) |  | (378 | ) |
| Total, net | $ | 3,105 |  |  | $ | 1,873 |  |  | $ | 3,565 |  |  | $ | 8,543 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,447 |  |  | $ | 931 |  |  | $ | 2,128 |  |  | $ | 4,506 |  |
| Noncurrent | 1,658 |  |  | 942 |  |  | 1,437 |  |  | 4,037 |  |
| Total, net | $ | 3,105 |  |  | $ | 1,873 |  |  | $ | 3,565 |  |  | $ | 8,543 |  |

[0000858877-15-000073:notes:215]
| July 25, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Gross | $ | 3,361 |  |  | $ | 1,763 |  |  | $ | 3,573 |  |  | $ | 8,697 |  |
| Residual value | 224 |  |  | — |  |  | — |  |  | 224 |  |
| Unearned income | (190 | ) |  | — |  |  | — |  |  | (190 | ) |
| Allowance for credit loss | (259 | ) |  | (87 | ) |  | (36 | ) |  | (382 | ) |
| Total, net | $ | 3,136 |  |  | $ | 1,676 |  |  | $ | 3,537 |  |  | $ | 8,349 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,468 |  |  | $ | 856 |  |  | $ | 2,167 |  |  | $ | 4,491 |  |
| Noncurrent | 1,668 |  |  | 820 |  |  | 1,370 |  |  | 3,858 |  |
| Total, net | $ | 3,136 |  |  | $ | 1,676 |  |  | $ | 3,537 |  |  | $ | 8,349 |  |

[0000858877-15-000073:notes:216]
As of October 24, 2015 and July 25, 2015, the deferred service revenue related to "Financed Service Contracts and Other" was $1,911 million and $1,853 million, respectively.

[0000858877-15-000073:notes:217]
Future minimum lease payments at October 24, 2015 are summarized as follows (in millions):

[0000858877-15-000073:notes:218]
| Fiscal Year | Amount |
| 2016 (remaining nine months) | $ | 1,307 |  |
| 2017 | 1,079 |  |
| 2018 | 606 |  |
| 2019 | 254 |  |
| 2020 | 70 |  |
| Thereafter | 1 |  |
| Total | $ | 3,317 |  |

[0000858877-15-000073:notes:219]
[same as prior period, unchanged from 0000858877-15-000051:notes:227]

[0000858877-15-000073:notes:220]
[same as prior period, unchanged from 0000858877-15-000051:notes:228]

[0000858877-15-000073:notes:221]
[same as prior period, unchanged from 0000858877-15-000051:notes:229]

[0000858877-15-000073:notes:222]
[same as prior period, unchanged from 0000858877-15-000051:notes:230]

[0000858877-15-000073:notes:223]
In circumstances when collectibility is not deemed reasonably assured, the associated revenue is deferred in accordance with the Company’s revenue recognition policies, and the related allowance for credit loss, if any, is included in deferred revenue.  The Company also records deferred revenue associated with financing receivables when there are remaining performance obligations, as it does for financed service contracts.  Total allowances for credit loss and deferred revenue as of October 24, 2015 and July 25, 2015 were $2,308 million and $2,253 million, respectively, and they were associated with total financing receivables before allowance for credit loss of $8,921 million and $8,731 million as of their respective period ends.

[0000858877-15-000073:notes:224]
The following tables present the aging analysis of gross receivables less unearned income as of October 24, 2015 and July 25, 2015 (in millions):

[0000858877-15-000073:notes:225]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| October 24, 2015 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 100 |  |  | $ | 51 |  |  | $ | 176 |  |  | $ | 327 |  |  | $ | 2,808 |  |  | $ | 3,135 |  |  | $ | 83 |  |  | $ | 72 |  |
| Loan receivables | 22 |  |  | 85 |  |  | 69 |  |  | 176 |  |  | 1,787 |  |  | 1,963 |  |  | 17 |  |  | 17 |  |
| Financed service contracts and other | 152 |  |  | 50 |  |  | 249 |  |  | 451 |  |  | 3,147 |  |  | 3,598 |  |  | 26 |  |  | 6 |  |
| Total | $ | 274 |  |  | $ | 186 |  |  | $ | 494 |  |  | $ | 954 |  |  | $ | 7,742 |  |  | $ | 8,696 |  |  | $ | 126 |  |  | $ | 95 |  |

[0000858877-15-000073:notes:226]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 25, 2015 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 90 |  |  | $ | 27 |  |  | $ | 185 |  |  | $ | 302 |  |  | $ | 2,869 |  |  | $ | 3,171 |  |  | $ | 73 |  |  | $ | 73 |  |
| Loan receivables | 21 |  |  | 3 |  |  | 25 |  |  | 49 |  |  | 1,714 |  |  | 1,763 |  |  | 32 |  |  | 32 |  |
| Financed service contracts and other | 396 |  |  | 152 |  |  | 414 |  |  | 962 |  |  | 2,611 |  |  | 3,573 |  |  | 29 |  |  | 9 |  |
| Total | $ | 507 |  |  | $ | 182 |  |  | $ | 624 |  |  | $ | 1,313 |  |  | $ | 7,194 |  |  | $ | 8,507 |  |  | $ | 134 |  |  | $ | 114 |  |

[0000858877-15-000073:notes:227]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms.  The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract.  The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $333 million and $496 million as of October 24, 2015 and July 25, 2015, respectively.

[0000858877-15-000073:notes:228]
As of October 24, 2015, the Company had financing receivables of $119 million, net of unbilled or current receivables from the same contract, that were in the category of 91 days plus past due but remained on accrual status as they are well-secured and in the process of collection.  Such balance was $70 million as of July 25, 2015.

[0000858877-15-000073:notes:229]
[same as prior period, unchanged from 0000858877-15-000051:notes:237]

[0000858877-15-000073:notes:230]
[same as prior period, unchanged from 0000858877-15-000051:notes:238]

[0000858877-15-000073:notes:231]
Typically, the Company also considers receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance.  These balances, as of October 24, 2015 and July 25, 2015, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-15-000073:notes:232]
[same as prior period, unchanged from 0000858877-15-000051:notes:240]

[0000858877-15-000073:notes:233]
[same as prior period, unchanged from 0000858877-15-000051:notes:241]

[0000858877-15-000073:notes:234]
[same as prior period, unchanged from 0000858877-15-000051:notes:242]

[0000858877-15-000073:notes:235]
|  | October 24, 2015 |  | July 25, 2015 |
| Operating lease assets | $ | 372 |  |  | $ | 372 |  |
| Accumulated depreciation | (207 | ) |  | (205 | ) |
| Operating lease assets, net | $ | 165 |  |  | $ | 167 |  |

[0000858877-15-000073:notes:236]
Minimum future rentals on noncancelable operating leases at October 24, 2015 were approximately $0.1 billion for the remaining nine months of fiscal 2016, $0.1 billion for fiscal 2017, and less than $0.1 billion per year for each of fiscal 2018 through fiscal 2020.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-15-000073:notes:237]
[same as prior period, unchanged from 0000858877-15-000051:notes:245]

[0000858877-15-000073:notes:238]
[same as prior period, unchanged from 0000858877-15-000051:notes:246]

[0000858877-15-000073:notes:239]
The following table presents the goodwill allocated to the Company’s reportable segments as of and during the three months ended October 24, 2015 (in millions):

[0000858877-15-000073:notes:240]
|  | Balance at |  |  |  |  |  | Balance at |
|  | July 25, 2015 |  | Acquisitions |  | Other |  | October 24, 2015 |
| Americas | $ | 15,212 |  |  | $ | 361 |  |  | $ | (90 | ) |  | $ | 15,483 |  |
| EMEA | 5,791 |  |  | 141 |  |  | (34 | ) |  | 5,898 |  |
| APJC | 3,466 |  |  | 55 |  |  | (20 | ) |  | 3,501 |  |
| Total | $ | 24,469 |  |  | $ | 557 |  |  | $ | (144 | ) |  | $ | 24,882 |  |

[0000858877-15-000073:notes:241]
“Other” in the table above primarily consists of foreign currency translation, as well as immaterial purchase accounting adjustments.

[0000858877-15-000073:notes:242]
[same as prior period, unchanged from 0000858877-15-000051:notes:250]

[0000858877-15-000073:notes:243]
Purchased intangible assets include intangible assets acquired through acquisitions as well as through direct purchases or licenses.  In fiscal 2015, the Company, along with a number of other companies, entered into an agreement to obtain a license to the patents owned by the Rockstar Consortium, and the Company paid approximately $300 million, of which $188 million was expensed to product cost of sales in the first quarter of fiscal 2015 related to the settlement of patent infringement claims, and the remainder was capitalized as an intangible asset to be amortized over its estimated useful life.

[0000858877-15-000073:notes:244]
There were no impairment charges related to purchased intangible assets during the periods presented.

[0000858877-15-000073:notes:245]
The estimated future amortization expense of purchased intangible assets with finite lives as of October 24, 2015 is as follows (in millions):

[0000858877-15-000073:notes:246]
| Fiscal Year | Amount |
| 2016 (remaining nine months) | $ | 574 |  |
| 2017 | 619 |  |
| 2018 | 476 |  |
| 2019 | 379 |  |
| 2020 | 162 |  |
| Thereafter | 53 |  |
| Total | $ | 2,263 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-15-000073:notes:247]
[same as prior period, unchanged from 0000858877-15-000051:notes:255]

[0000858877-15-000073:notes:248]
As of October 24, 2015, the Company had $2.1 billion of unrecognized tax benefits, of which $1.8 billion, if recognized, would favorably impact the effective tax rate.  The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions.  The Company believes it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months.  Specific positions that may be resolved include issues involving transfer pricing and various other matters.  Accordingly, the Company estimates that it is reasonably possible that the unrecognized tax benefits at October 24, 2015 could be reduced in the next 12 months by approximately $825 million, a portion of which could increase earnings.


## us-gaap:InventoryDisclosureTextBlock

[0000858877-15-000073:notes:249]
[same as prior period, unchanged from 0000858877-15-000051:notes:258]

[0000858877-15-000073:notes:250]
|  |  | October 24, 2015 |  | July 25, 2015 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 107 |  |  | $ | 114 |  |
| Work in process |  | 1 |  |  | 2 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 631 |  |  | 610 |  |
| Manufactured finished goods |  | 464 |  |  | 593 |  |
| Total finished goods |  | 1,095 |  |  | 1,203 |  |
| Service-related spares |  | 240 |  |  | 258 |  |
| Demonstration systems |  | 39 |  |  | 50 |  |
| Total |  | $ | 1,482 |  |  | $ | 1,627 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-15-000073:notes:251]
The following table summarizes the maturities of the Company’s fixed income securities at October 24, 2015 (in millions):

[0000858877-15-000073:notes:252]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 17,274 |  |  | $ | 17,276 |  |
| Due in 1 to 2 years | 15,914 |  |  | 15,950 |  |
| Due in 2 to 5 years | 17,105 |  |  | 17,138 |  |
| Due after 5 years | 1,623 |  |  | 1,635 |  |
| Total | $ | 51,916 |  |  | $ | 51,999 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-15-000073:notes:253]
| 8. | Investments |

[0000858877-15-000073:notes:254]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-15-000073:notes:255]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-15-000073:notes:256]
| October 24, 2015 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 27,409 |  |  | $ | 63 |  |  | $ | (1 | ) |  | $ | 27,471 |  |
| U.S. government agency securities | 3,606 |  |  | 11 |  |  | — |  |  | 3,617 |  |
| Non-U.S. government and agency securities | 1,133 |  |  | 3 |  |  | — |  |  | 1,136 |  |
| Corporate debt securities | 18,314 |  |  | 70 |  |  | (78 | ) |  | 18,306 |  |
| U.S. agency mortgage-backed securities | 1,454 |  |  | 15 |  |  | — |  |  | 1,469 |  |
| Total fixed income securities | 51,916 |  |  | 162 |  |  | (79 | ) |  | 51,999 |  |
| Publicly traded equity securities | 1,094 |  |  | 268 |  |  | (12 | ) |  | 1,350 |  |
| Total | $ | 53,010 |  |  | $ | 430 |  |  | $ | (91 | ) |  | $ | 53,349 |  |

[0000858877-15-000073:notes:257]
| July 25, 2015 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 29,904 |  |  | $ | 41 |  |  | $ | (6 | ) |  | $ | 29,939 |  |
| U.S. government agency securities | 3,662 |  |  | 2 |  |  | (1 | ) |  | 3,663 |  |
| Non-U.S. government and agency securities | 1,128 |  |  | 1 |  |  | (1 | ) |  | 1,128 |  |
| Corporate debt securities | 15,802 |  |  | 34 |  |  | (53 | ) |  | 15,783 |  |
| U.S. agency mortgage-backed securities | 1,456 |  |  | 8 |  |  | (3 | ) |  | 1,461 |  |
| Total fixed income securities | 51,952 |  |  | 86 |  |  | (64 | ) |  | 51,974 |  |
| Publicly traded equity securities | 1,092 |  |  | 480 |  |  | (7 | ) |  | 1,565 |  |
| Total | $ | 53,044 |  |  | $ | 566 |  |  | $ | (71 | ) |  | $ | 53,539 |  |

[0000858877-15-000073:notes:258]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-15-000073:notes:259]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-15-000073:notes:260]
The following table presents the gross realized gains and gross realized losses related to the Company’s available-for-sale investments (in millions):

[0000858877-15-000073:notes:261]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Gross realized gains | $ | 35 |  |  | $ | 21 |  |
| Gross realized losses | (36 | ) |  | (14 | ) |
| Total | $ | (1 | ) |  | $ | 7 |  |

[0000858877-15-000073:notes:262]
The following table presents the realized net gains (losses) related to the Company’s available-for-sale investments by security type (in millions):

[0000858877-15-000073:notes:263]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Net losses on investments in publicly traded equity securities | $ | (9 | ) |  | $ | (4 | ) |
| Net gains on investments in fixed income securities | 8 |  |  | 11 |  |
| Total | $ | (1 | ) |  | $ | 7 |  |

[0000858877-15-000073:notes:264]
There were no impairment charges on available-for-sale investments for the periods presented.

[0000858877-15-000073:notes:265]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at October 24, 2015 and July 25, 2015 (in millions):

[0000858877-15-000073:notes:266]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 24, 2015 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 2,566 |  |  | $ | (1 | ) |  | $ | — |  |  | $ | — |  |  | $ | 2,566 |  |  | $ | (1 | ) |
| U.S. government agency securities | 80 |  |  | — |  |  | — |  |  | — |  |  | 80 |  |  | — |  |
| Non-U.S. government and agency securities | 57 |  |  | — |  |  | 10 |  |  | — |  |  | 67 |  |  | — |  |
| Corporate debt securities | 7,421 |  |  | (66 | ) |  | 1,048 |  |  | (12 | ) |  | 8,469 |  |  | (78 | ) |
| U.S. agency mortgage-backed securities | 77 |  |  | — |  |  | — |  |  | — |  |  | 77 |  |  | — |  |
| Total fixed income securities | 10,201 |  |  | (67 | ) |  | 1,058 |  |  | (12 | ) |  | 11,259 |  |  | (79 | ) |
| Publicly traded equity securities | 103 |  |  | (11 | ) |  | 2 |  |  | (1 | ) |  | 105 |  |  | (12 | ) |
| Total | $ | 10,304 |  |  | $ | (78 | ) |  | $ | 1,060 |  |  | $ | (13 | ) |  | $ | 11,364 |  |  | $ | (91 | ) |

[0000858877-15-000073:notes:267]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 25, 2015 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 6,412 |  |  | $ | (6 | ) |  | $ | — |  |  | $ | — |  |  | $ | 6,412 |  |  | $ | (6 | ) |
| U.S. government agency securities | 1,433 |  |  | (1 | ) |  | — |  |  | — |  |  | 1,433 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 515 |  |  | (1 | ) |  | 4 |  |  | — |  |  | 519 |  |  | (1 | ) |
| Corporate debt securities | 9,552 |  |  | (49 | ) |  | 312 |  |  | (4 | ) |  | 9,864 |  |  | (53 | ) |
| U.S. agency mortgage-backed securities | 579 |  |  | (3 | ) |  | — |  |  | — |  |  | 579 |  |  | (3 | ) |
| Total fixed income securities | 18,491 |  |  | (60 | ) |  | 316 |  |  | (4 | ) |  | 18,807 |  |  | (64 | ) |
| Publicly traded equity securities | 108 |  |  | (7 | ) |  | 2 |  |  | — |  |  | 110 |  |  | (7 | ) |
| Total | $ | 18,599 |  |  | $ | (67 | ) |  | $ | 318 |  |  | $ | (4 | ) |  | $ | 18,917 |  |  | $ | (71 | ) |

[0000858877-15-000073:notes:268]
As of October 24, 2015, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis.  In addition, as of October 24, 2015, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the three months ended October 24, 2015.

[0000858877-15-000073:notes:269]
The Company has evaluated its publicly traded equity securities as of October 24, 2015 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses.  This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-15-000073:notes:270]
| (c) | Maturities of Fixed Income Securities |

[0000858877-15-000073:notes:271]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.  The remaining contractual principal maturities for mortgage-backed securities were allocated assuming no prepayments.

[0000858877-15-000073:notes:272]
| (d) | Securities Lending |

[0000858877-15-000073:notes:273]
The Company periodically engages in securities lending activities with certain of its available for sale investments.  These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis.  The average daily balance of securities lending for the three months ended October 24, 2015 and October 25, 2014 was $0.5 billion and $1.0 billion, respectively.  The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets.  The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses.  The Company did not experience any losses in connection with the secured lending of securities during the periods presented.  As of October 24, 2015 and July 25, 2015, the Company had no outstanding securities lending transactions.

[0000858877-15-000073:notes:274]
| (e) | Investments in Privately Held Companies |

[0000858877-15-000073:notes:275]
The carrying value of the Company’s investments in privately held companies was included in other assets.  For such investments that were accounted for under the equity and cost method as of October 24, 2015 and July 25, 2015, the amounts are summarized in the following table (in millions):

[0000858877-15-000073:notes:276]
For additional information on impairment charges related to investments in privately held companies, see Note 9.

[0000858877-15-000073:notes:277]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers.  These privately held companies and customers may be considered to be variable interest entities.  The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings and has determined that as of October 24, 2015 there were no variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-15-000073:notes:278]
[same as prior period, unchanged from 0000858877-15-000051:notes:288]

[0000858877-15-000073:notes:279]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July.  Fiscal 2016 is a 53-week fiscal year and fiscal 2015 was a 52-week fiscal year.  The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries.  All intercompany accounts and transactions have been eliminated.  The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-15-000073:notes:280]
The accompanying financial data as of October 24, 2015 and for the three months ended October 24, 2015 and October 25, 2014 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations.  The July 25, 2015 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States.  However, the Company believes that the disclosures are adequate to make the information presented not misleading.  These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 25, 2015.

[0000858877-15-000073:notes:281]
[same as prior period, unchanged from 0000858877-15-000051:notes:291]

[0000858877-15-000073:notes:282]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 24, 2015; the results of operations, statements of comprehensive income, cash flows and equity for the three months ended October 24, 2015 and October 25, 2014, as applicable, have been made.  The results of operations for the three months ended October 24, 2015 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-15-000073:notes:283]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000858877-15-000073:notes:284]
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 1,583 |  |  | $ | 1,648 |  |
| Investments in privately held companies |  | 928 |  |  | 897 |  |
| Other |  | 759 |  |  | 618 |  |
| Total |  | $ | 3,270 |  |  | $ | 3,163 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-15-000073:notes:285]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,561 |  |  | $ | 4,495 |  |
| Computer equipment and related software |  | 1,276 |  |  | 1,310 |  |
| Production, engineering, and other equipment |  | 5,742 |  |  | 5,753 |  |
| Operating lease assets |  | 372 |  |  | 372 |  |
| Furniture and fixtures |  | 502 |  |  | 497 |  |
| Total gross property and equipment |  | 12,453 |  |  | 12,427 |  |
| Less: accumulated depreciation and amortization |  | (9,107 | ) |  | (9,095 | ) |
| Total |  | $ | 3,346 |  |  | $ | 3,332 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-15-000073:notes:286]
[same as prior period, unchanged from 0000858877-15-000051:notes:296]

[0000858877-15-000073:notes:287]
Fiscal 2015 Plan  The Company announced a restructuring action in August 2014 (the "Fiscal 2015 Plan"), in order to realign its workforce towards key growth areas of its business such as data center, software, security, and cloud.  The Company's aggregate pre-tax estimated charges pursuant to the restructuring are expected to be approximately $700 million, consisting of severance and other one-time termination benefits and other associated costs, and the Company has incurred cumulative charges of approximately $630 million in connection with this plan through October 24, 2015.  The Company incurred charges of $141 million, net of a $1 million credit to cost of sales, and $318 million for the three months ended October 24, 2015 and October 25, 2014, respectively.  These charges are primarily cash-based, and the Company expects the Fiscal 2015 Plan to be substantially completed during the first half of fiscal 2016.

[0000858877-15-000073:notes:288]
Fiscal 2014 Plan  In connection with a restructuring action announced in August 2013 (the "Fiscal 2014 Plan"), the Company incurred cumulative charges of approximately $418 million.  The Company completed the Fiscal 2014 Plan at the end of fiscal 2014.

[0000858877-15-000073:notes:289]
[same as prior period, unchanged from 0000858877-15-000051:notes:301]

[0000858877-15-000073:notes:290]
|  |  | FISCAL 2014 PLAN |  | FISCAL 2015 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 25, 2015 |  | $ | 11 |  |  | $ | 14 |  |  | $ | 49 |  |  | $ | 15 |  |  | $ | 89 |  |
| Charges |  | — |  |  | — |  |  | 125 |  |  | 17 |  |  | 142 |  |
| Cash payments |  | (4 | ) |  | (1 | ) |  | (119 | ) |  | (5 | ) |  | (129 | ) |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (16 | ) |  | (16 | ) |
| Liability as of October 24, 2015 |  | $ | 7 |  |  | $ | 13 |  |  | $ | 55 |  |  | $ | 11 |  |  | $ | 86 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-15-000073:notes:291]
[same as prior period, unchanged from 0000858877-15-000051:notes:307]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-15-000073:notes:292]
[same as prior period, unchanged from 0000858877-15-000051:notes:310]

[0000858877-15-000073:notes:293]
[same as prior period, unchanged from 0000858877-15-000051:notes:311]

[0000858877-15-000073:notes:294]
During the three months ended October 24, 2015, the Company declared and paid cash dividends of $0.21 per common share, or $1.1 billion, on the Company’s outstanding common stock.  During the three months ended October 25, 2014, the Company declared and paid cash dividends of $0.19 per common share, or $973 million, on the Company’s outstanding common stock.

[0000858877-15-000073:notes:295]
On November 18, 2015, the Company's Board of Directors declared a quarterly dividend of $0.21 per common share to be paid on January 20, 2016 to all shareholders of record as of the close of business on January 6, 2016.  Any future dividends will be subject to the approval of the Company's Board of Directors.

[0000858877-15-000073:notes:296]
[same as prior period, unchanged from 0000858877-15-000051:notes:314]

[0000858877-15-000073:notes:297]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program.  As of October 24, 2015, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program, and the remaining authorized repurchase amount was $3.1 billion, with no termination date.  A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-15-000073:notes:298]
[same as prior period, unchanged from 0000858877-15-000051:notes:316]

[0000858877-15-000073:notes:299]
[same as prior period, unchanged from 0000858877-15-000051:notes:317]

[0000858877-15-000073:notes:300]
For the three months ended October 24, 2015 and October 25, 2014, the Company repurchased approximately 15 million and 14 million shares, or $382 million and $342 million, of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-15-000073:notes:301]
[same as prior period, unchanged from 0000858877-15-000051:notes:319]


## us-gaap:TreasuryStockTextBlock

[0000858877-15-000073:notes:302]
[same as prior period, unchanged from 0000858877-15-000051:notes:320]

[0000858877-15-000073:notes:303]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of October 24, 2015, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program with no termination date. The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):
