# CSCO 10-K controls and the auditor's report


## auditors_report

[0000858877-25-000111:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0000858877-25-000111:auditors_report:2]
To the Board of Directors and Stockholders of Cisco Systems, Inc.

[0000858877-25-000111:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0000858877-25-000111:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Cisco Systems, Inc. and its subsidiaries (the “Company”) as of July 26, 2025 and July 27, 2024, and the related consolidated statements of operations, of comprehensive income, of stockholders' equity and of cash flows for each of the three years in the period ended July 26, 2025, including the related notes (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of July 26, 2025, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0000858877-25-000111:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of July 26, 2025 and July 27, 2024, and the results of its operations and its cash flows for each of the three years in the period ended July 26, 2025 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of July 26, 2025, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0000858877-25-000111:auditors_report:6]
Basis for Opinions

[0000858877-25-000111:auditors_report:7]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000858877-25-000111:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0000858877-25-000111:auditors_report:9]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0000858877-25-000111:auditors_report:10]
Definition and Limitations of Internal Control over Financial Reporting

[0000858877-25-000111:auditors_report:11]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000858877-25-000111:auditors_report:12]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000858877-25-000111:auditors_report:13]
53

[0000858877-25-000111:auditors_report:14]
Critical Audit Matters

[0000858877-25-000111:auditors_report:15]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0000858877-25-000111:auditors_report:16]
Revenue Recognition for Certain Products and Services

[0000858877-25-000111:auditors_report:17]
As described in Note 2 to the consolidated financial statements, the Company derives revenue from contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. The Company recognizes revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration the Company expects to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. For the year ended July 26, 2025, the Company’s total revenue was $56.7 billion, of which the majority relates to certain product and services revenue.

[0000858877-25-000111:auditors_report:18]
The principal consideration for our determination that performing procedures relating to revenue recognition for certain products and services is a critical audit matter is a high degree of auditor effort in performing procedures related to the Company's revenue recognition.

[0000858877-25-000111:auditors_report:19]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the revenue recognition process. These procedures also included, among others (i) testing revenue recognized for a sample of revenue transactions by obtaining and inspecting source documents, such as executed contracts, purchase orders, invoices, and proof of delivery; (ii) testing the appropriate amount and timing of revenue recognition based on the contractual terms identified in certain customer arrangements; and (iii) confirming a sample of outstanding customer invoice balances as of July 26, 2025 and, for confirmations not returned, obtaining and inspecting source documents, such as purchase orders, invoices, proof of delivery, and subsequent cash receipts.

[0000858877-25-000111:auditors_report:20]
/s/ PricewaterhouseCoopers LLP

[0000858877-25-000111:auditors_report:21]
San Jose, California

[0000858877-25-000111:auditors_report:22]
September 3, 2025

[0000858877-25-000111:auditors_report:23]
We have served as the Company’s auditor since 1988.

[0000858877-25-000111:auditors_report:24]
54


## item_9a

[0000858877-25-000111:item_9a:1]
| Item 9A. | Controls and Procedures |

[0000858877-25-000111:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000858877-25-000111:item_9a:3]
Based on our management’s evaluation (with the participation of our principal executive officer and principal financial officer), as of the end of the period covered by this report, our principal executive officer and principal financial officer have concluded that our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”)), are effective to ensure that information required to be disclosed by us in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in Securities and Exchange Commission rules and forms and is accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000858877-25-000111:item_9a:4]
Internal Control over Financial Reporting

[0000858877-25-000111:item_9a:5]
Management’s report on our internal control over financial reporting and the report of our independent registered public accounting firm on our internal control over financial reporting are set forth, respectively, on page 55 under the caption “Management’s Report on Internal Control Over Financial Reporting” and on page 53 of this report.

[0000858877-25-000111:item_9a:6]
There was no change in our internal control over financial reporting during our fourth quarter of fiscal 2025 that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.
