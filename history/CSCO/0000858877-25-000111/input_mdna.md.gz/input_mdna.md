# CSCO MD&A — 0000858877-25-000111


## mdna

[0000858877-25-000111:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000858877-25-000111:mdna:2]
Forward-Looking Statements

[0000858877-25-000111:mdna:3]
OVERVIEW

[0000858877-25-000111:mdna:4]
Cisco designs and sells a broad range of technologies that help to power, secure, and draw insights from the Internet. We are incorporating artificial intelligence (AI) into our product portfolios across networking, security, collaboration and observability as well as integrating our products more tightly together. We are simplifying how our technology is delivered, managed and optimized and helping customers maximize the business value of their technology investments.

[0000858877-25-000111:mdna:5]
A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-25-000111:mdna:6]
|  | Three Months Ended |  | Years Ended |  |
|  | July 26, 2025 |  | July 27, 2024 |  | Variance |  | July 26, 2025 |  | July 27, 2024 |  | Variance |  |
| Revenue | $ | 14,673 |  |  | $ | 13,642 |  |  | 8 | % |  | $ | 56,654 |  |  | $ | 53,803 |  |  | 5 | % |  |
| Gross margin percentage | 63.2 | % |  | 64.4 | % |  | (1.2) |  | pts | 64.9 | % |  | 64.7 | % |  | 0.2 |  | pts |
| Research and development | $ | 2,380 |  |  | $ | 2,179 |  |  | 9 | % |  | $ | 9,300 |  |  | $ | 7,983 |  |  | 16 | % |  |
| Sales and marketing | $ | 2,818 |  |  | $ | 2,841 |  |  | (1) | % |  | $ | 10,966 |  |  | $ | 10,364 |  |  | 6 | % |  |
| General and administrative | $ | 706 |  |  | $ | 763 |  |  | (8) | % |  | $ | 2,992 |  |  | $ | 2,813 |  |  | 6 | % |  |
| Total R&D, sales and marketing, general and administrative | $ | 5,904 |  |  | $ | 5,783 |  |  | 2 | % |  | $ | 23,258 |  |  | $ | 21,160 |  |  | 10 | % |  |
| Total as a percentage of revenue | 40.2 | % |  | 42.4 | % |  | (2.2) |  | pts | 41.1 | % |  | 39.3 | % |  | 1.8 |  | pts |
| Restructuring and other charges included in operating expenses | $ | 35 |  |  | $ | 112 |  |  | (69) | % |  | $ | 744 |  |  | $ | 789 |  |  | (6) | % |  |
| Operating income as a percentage of revenue | 21.0 | % |  | 19.2 | % |  | 1.8 |  | pts | 20.8 | % |  | 22.6 | % |  | (1.8) |  | pts |
| Interest and other income (loss), net | $ | (88) |  |  | $ | (222) |  |  | (60) | % |  | $ | (660) |  |  | $ | 53 |  |  | NM |  |
| Income tax percentage | 15.0 | % |  | 9.8 | % |  | 5.2 |  | pts | 8.3 | % |  | 15.6 | % |  | (7.3) |  | pts |
| Net income | $ | 2,550 |  |  | $ | 2,162 |  |  | 18 | % |  | $ | 10,180 |  |  | $ | 10,320 |  |  | (1) | % |  |
| Net income as a percentage of revenue | 17.4 | % |  | 15.8 | % |  | 1.6 |  | pts | 18.0 | % |  | 19.2 | % |  | (1.2) |  | pts |
| Earnings per share—diluted | $ | 0.64 |  |  | $ | 0.54 |  |  | 19 | % |  | $ | 2.55 |  |  | $ | 2.54 |  |  | — | % |  |

[0000858877-25-000111:mdna:7]
Percentages may not recalculate due to rounding.

[0000858877-25-000111:mdna:8]
NM — Not meaningful

[0000858877-25-000111:mdna:9]
30

[0000858877-25-000111:mdna:10]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:11]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:12]
Fiscal 2025 Compared with Fiscal 2024

[0000858877-25-000111:mdna:13]
In fiscal 2025, we delivered strong revenue growth across all geographies and solid margins as we saw a positive demand environment. Total revenue increased by 5% compared with fiscal 2024. Our results for fiscal 2025 include a full year of Splunk's results compared to approximately four months for fiscal 2024. Within total revenue, product revenue increased by 6% and services revenue increased by 3%. In fiscal 2025, total software revenue was $22.3 billion, an increase of 21%, driven by the contribution of Splunk. Total subscription revenue increased 15%, driven by the contribution of Splunk.

[0000858877-25-000111:mdna:14]
Total gross margin increased by 0.2 percentage points. Product gross margin increased by 0.2 percentage points, driven by benefits from Splunk and productivity improvements, partially offset by negative impacts from pricing, a charge as a result of a legal dispute with a supplier, and the amortization of purchased intangible assets primarily related to Splunk. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 1.8 percentage points. Operating income as a percentage of revenue decreased by 1.8 percentage points primarily due to increases in amortization of purchased intangible assets and share-based compensation expense in fiscal 2025, and a charge in the fourth quarter of fiscal 2025 as a result of a legal dispute with a supplier. Diluted earnings per share was flat compared with fiscal 2024.

[0000858877-25-000111:mdna:15]
In terms of our geographic segments, revenue from the Americas increased by $1.7 billion, EMEA revenue increased by $0.7 billion and revenue in our APJC segment increased by $0.5 billion. From a customer market perspective, product revenue growth was led by the enterprise market and the service provider and cloud market. The revenue increase in our service provider and cloud market was driven by AI infrastructure revenue from webscale customers. From a product category perspective, the product revenue increased 6% year over year, driven by a growth in revenue in Security of 59%, Observability of 26%, and Collaboration of 1%, partially offset by a decline in Networking of 3%. The product revenue growth in Security and Observability were each driven in large part by the contribution of Splunk.

[0000858877-25-000111:mdna:16]
We continue to operate in a highly competitive environment, and one that is complex especially with respect to tariffs and trade policy. We plan to continue to invest in key priority areas with the objective of driving profitable growth over the long term. We remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformations and on accelerating innovation across our portfolio. We believe that we are making progress on our strategic priorities.

[0000858877-25-000111:mdna:17]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:18]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:19]
Fourth Quarter Snapshot

[0000858877-25-000111:mdna:20]
For the fourth quarter of fiscal 2025, as compared with the fourth quarter of fiscal 2024, total revenue increased by 8%. Within total revenue, product revenue increased by 10% and services revenue was flat. With regard to our geographic segment performance, on a year-over-year basis, revenue in Americas increased by 9%, EMEA increased by 4% and APJC increased by 7%. From a product category perspective, we experienced product revenue growth in Networking, Security, Observability, and Collaboration. Total gross margin decreased by 1.2 percentage points, driven primarily by a charge as a result of a legal dispute with a supplier. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 2.2 percentage points. Operating income as a percentage of revenue increased by 1.8 percentage points primarily driven by lower amortization of purchased intangible assets, lower restructuring and other charges, and a decrease in cash compensation expenses from acquisitions, partially offset by a charge as a result of a legal dispute with a supplier. Diluted earnings per share increased by 19%, primarily driven by the revenue increase and the increase in our operating margin percentage.

[0000858877-25-000111:mdna:21]
Strategy and Priorities

[0000858877-25-000111:mdna:22]
In today's digital-first world, businesses and organizations globally are deploying technology to pursue their strategic objectives, from accelerating growth to enhancing operational efficiency and fostering innovation. Our strategy is to securely connect everything to make those desired outcomes possible.

[0000858877-25-000111:mdna:23]
For a full discussion of our strategy and priorities, see “Item 1. Business.”

[0000858877-25-000111:mdna:24]
Other Key Financial Measures

[0000858877-25-000111:mdna:25]
The following is a summary of our other key financial measures for fiscal 2025 compared with fiscal 2024 (in millions):

[0000858877-25-000111:mdna:26]
|  |  | Fiscal 2025 |  | Fiscal 2024 |
| Cash and cash equivalents and investments |  | $16,110 |  | $17,854 |
| Cash provided by operating activities |  | $14,193 |  | $10,880 |
| Remaining performance obligations |  | $43,533 |  | $41,048 |
| Repurchases of common stock—stock repurchase program |  | $5,995 |  | $5,764 |
| Dividends paid |  | $6,437 |  | $6,384 |
| Inventories |  | $3,164 |  | $3,373 |
| Total debt |  | $28,093 |  | $30,962 |

[0000858877-25-000111:mdna:27]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:28]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:29]
CRITICAL ACCOUNTING ESTIMATES

[0000858877-25-000111:mdna:30]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-25-000111:mdna:31]
Revenue Recognition

[0000858877-25-000111:mdna:32]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations, resulting in contracts that may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis.

[0000858877-25-000111:mdna:33]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-25-000111:mdna:34]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-25-000111:mdna:35]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers that we sell to directly. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable. If actual credits received by customers under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-25-000111:mdna:36]
See Note 3 to the Consolidated Financial Statements for more details.

[0000858877-25-000111:mdna:37]
Inventory Valuation and Liability for Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-25-000111:mdna:38]
Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and net realizable value, based upon assumptions about future demand, and are charged to the provision for inventory. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-25-000111:mdna:39]
33

[0000858877-25-000111:mdna:40]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:41]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:42]
We record a provision for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.  Both provisions are a component of cost of sales.

[0000858877-25-000111:mdna:43]
Our total provisions for inventory and the liability related to purchase commitments with contract manufacturers and suppliers were $493 million, $819 million, and $730 million in fiscal 2025, 2024, and 2023, respectively. If there were to be a sudden and significant decrease in demand for our products, or a higher incidence of inventory obsolescence because of rapidly changing technology or customer requirements, then we could be required to increase our inventory write-downs and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs, and the adequacy of our liability for purchase commitments. For further discussion around the supply chain impacts and risks, see “—Results of Operations—Gross Margin—Supply Chain Impacts and Risks” and “—Liquidity and Capital Resources—Inventory Supply Chain” under Item 7 of this report.

[0000858877-25-000111:mdna:44]
Loss Contingencies

[0000858877-25-000111:mdna:45]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-25-000111:mdna:46]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-25-000111:mdna:47]
Valuation of Goodwill and Purchased Intangible Assets

[0000858877-25-000111:mdna:48]
Goodwill

[0000858877-25-000111:mdna:49]
Our methodology for allocating the purchase price relating to purchase acquisitions is determined through established valuation techniques. Goodwill represents a residual value as of the acquisition date, which in most cases results in measuring goodwill as an excess of the purchase consideration transferred plus the fair value of any noncontrolling interest in the acquired company over the fair value of net assets acquired, including contingent consideration. We perform goodwill impairment tests on an annual basis in the fourth fiscal quarter and between annual tests in certain circumstances for each reporting unit. The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the guidance for the fair value measurement of nonfinancial assets.

[0000858877-25-000111:mdna:50]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in fiscal 2025, 2024, and 2023. For the annual impairment testing in fiscal 2025, the excess of the fair value over the carrying value for each of our reporting units was $56.5 billion for the Americas, $80.1 billion for EMEA, and $32.9 billion for APJC.

[0000858877-25-000111:mdna:51]
During the fourth quarter of fiscal 2025, we performed a sensitivity analysis for goodwill impairment with respect to each of our respective reporting units and determined that a hypothetical 10% decline in the fair value of each reporting unit would not result in an impairment of goodwill for any reporting unit.

[0000858877-25-000111:mdna:52]
Purchased Intangible Assets

[0000858877-25-000111:mdna:53]
The accounting for acquisitions requires significant estimates and judgments in the valuation of purchased intangible assets. Critical estimates used in the valuation of purchased intangible assets include, but are not limited to, the amount and timing of expected future cash flows, useful lives and discount rates. While our estimates of fair value are based on assumptions that are believed to be reasonable, these assumptions are inherently uncertain and unpredictable and would not reflect unanticipated events and circumstances that may occur.

[0000858877-25-000111:mdna:54]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured

[0000858877-25-000111:mdna:55]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:56]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:57]
by comparing the carrying amount of the asset group to the future undiscounted cash flows the asset group is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. Our ongoing consideration of all the factors described previously could result in impairment charges in the future, which could adversely affect our net income.

[0000858877-25-000111:mdna:58]
Income Taxes

[0000858877-25-000111:mdna:59]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was 8.3%, 15.6%, and 17.7% in fiscal 2025, 2024, and 2023, respectively.

[0000858877-25-000111:mdna:60]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves due to changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, and the related net interest and penalties.

[0000858877-25-000111:mdna:61]
Significant judgment is also required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. If we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000858877-25-000111:mdna:62]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to foreign-derived intangible income deduction, global intangible low-tax income and base erosion and anti-abuse tax, research and development capitalization and amortization, and corporate alternative minimum tax laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The OECD, an international association comprised of 38 countries, including the United States, has made changes, including a Pillar Two framework that imposes a minimum tax rate of 15% in each taxing jurisdiction, and is contemplating additional changes to numerous long-standing tax principles. There can be no assurance that these changes and any contemplated changes if finalized, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries was subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the IRS and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-25-000111:mdna:63]
35

[0000858877-25-000111:mdna:64]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:65]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:66]
RESULTS OF OPERATIONS

[0000858877-25-000111:mdna:67]
Subsequent to the issuance of our earnings release on August 13, 2025, we settled a legal dispute with a supplier, resulting in a GAAP charge to product cost of sales, which is described in Note 21 to the Consolidated Financial Statements. The information in this Annual Report on Form 10-K supersedes the information contained in our earnings release.

[0000858877-25-000111:mdna:68]
A discussion regarding our financial condition and results of operations for fiscal 2025 compared to fiscal 2024 is presented below. A discussion regarding our financial condition and results of operations for fiscal 2024 compared to fiscal 2023 can be found under Item 7 in our Annual Report on Form 10-K for the fiscal year ended July 27, 2024, filed with the SEC on September 5, 2024.

[0000858877-25-000111:mdna:69]
Revenue

[0000858877-25-000111:mdna:70]
The following table presents the breakdown of revenue between product and services (in millions, except percentages):

[0000858877-25-000111:mdna:71]
|  |  | Years Ended |  | 2025 vs. 2024 |
|  |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 41,608 |  |  | $ | 39,253 |  |  | $ | 43,142 |  |  | $ | 2,355 |  |  | 6 | % |
| Percentage of revenue |  | 73.4 | % |  | 73.0 | % |  | 75.7 | % |  |  |  |  |
| Services |  | 15,046 |  |  | 14,550 |  |  | 13,856 |  |  | 496 |  |  | 3 | % |
| Percentage of revenue |  | 26.6 | % |  | 27.0 | % |  | 24.3 | % |  |  |  |  |
| Total |  | $ | 56,654 |  |  | $ | 53,803 |  |  | $ | 56,998 |  |  | $ | 2,851 |  |  | 5 | % |

[0000858877-25-000111:mdna:72]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-25-000111:mdna:73]
We manage our business primarily on a geographic basis, organized into three geographic segments. Our revenue, which includes product and services for each segment, is summarized in the following table (in millions, except percentages):

[0000858877-25-000111:mdna:74]
|  |  | Years Ended |  | 2025 vs. 2024 |
|  |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 33,656 |  |  | $ | 31,971 |  |  | $ | 33,447 |  |  | $ | 1,685 |  |  | 5 | % |
| Percentage of revenue |  | 59.4 | % |  | 59.4 | % |  | 58.7 | % |  |  |  |  |
| EMEA |  | 14,824 |  |  | 14,117 |  |  | 15,135 |  |  | 707 |  |  | 5 | % |
| Percentage of revenue |  | 26.2 | % |  | 26.2 | % |  | 26.6 | % |  |  |  |  |
| APJC |  | 8,174 |  |  | 7,716 |  |  | 8,417 |  |  | 458 |  |  | 6 | % |
| Percentage of revenue |  | 14.4 | % |  | 14.3 | % |  | 14.8 | % |  |  |  |  |
| Total |  | $ | 56,654 |  |  | $ | 53,803 |  |  | $ | 56,998 |  |  | $ | 2,851 |  |  | 5 | % |

[0000858877-25-000111:mdna:75]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-25-000111:mdna:76]
Total revenue in fiscal 2025 increased by 5% compared with fiscal 2024. Product revenue increased by 6% and services revenue increased by 3%. Our total revenue reflected growth across each of our geographic segments.

[0000858877-25-000111:mdna:77]
In addition to the impact of macroeconomic factors, including the IT spending environment and the level of spending by government entities, revenue by segment in a particular period may be significantly impacted by the timing of revenue recognition for complex transactions with multiple performance obligations. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment.

[0000858877-25-000111:mdna:78]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:79]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:80]
Product Revenue by Segment

[0000858877-25-000111:mdna:81]
The following table presents the breakdown of product revenue by segment (in millions, except percentages):

[0000858877-25-000111:mdna:82]
|  |  | Years Ended |  | 2025 vs. 2024 |
|  |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 24,637 |  |  | $ | 23,142 |  |  | $ | 25,019 |  |  | $ | 1,495 |  |  | 6 | % |
| Percentage of product revenue |  | 59.2 | % |  | 59.0 | % |  | 58.0 | % |  |  |  |  |
| EMEA |  | 11,122 |  |  | 10,645 |  |  | 11,866 |  |  | 477 |  |  | 4 | % |
| Percentage of product revenue |  | 26.7 | % |  | 27.1 | % |  | 27.5 | % |  |  |  |  |
| APJC |  | 5,849 |  |  | 5,466 |  |  | 6,257 |  |  | 383 |  |  | 7 | % |
| Percentage of product revenue |  | 14.1 | % |  | 13.9 | % |  | 14.5 | % |  |  |  |  |
| Total |  | $ | 41,608 |  |  | $ | 39,253 |  |  | $ | 43,142 |  |  | $ | 2,355 |  |  | 6 | % |

[0000858877-25-000111:mdna:83]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-25-000111:mdna:84]
Americas

[0000858877-25-000111:mdna:85]
Product revenue in the Americas segment increased by 6%, with growth in the enterprise market and the service provider and cloud market. The growth in the service provider and cloud market was driven by AI infrastructure revenue from webscale customers. These increases were partially offset by a decline in the public sector market. From a country perspective, product revenue increased in the United States, Canada, and Brazil by 7%, 4%, and 8%, respectively.

[0000858877-25-000111:mdna:86]
EMEA

[0000858877-25-000111:mdna:87]
Product revenue in the EMEA segment increased by 4%, driven by growth in the public sector and enterprise markets, partially offset by a slight decline in the service provider and cloud market. From a country perspective, product revenue increased in the United Kingdom, Germany, and France by 9%, 4%, and 6%, respectively.

[0000858877-25-000111:mdna:88]
APJC

[0000858877-25-000111:mdna:89]
Product revenue in the APJC segment increased by 7%, with growth across each of our customer markets. From a country perspective, product revenue increased in Japan, Australia, India, and China by 7%, 11%, 11%, and 10% respectively.

[0000858877-25-000111:mdna:90]
37

[0000858877-25-000111:mdna:91]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:92]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:93]
Product Revenue by Category

[0000858877-25-000111:mdna:94]
In addition to the primary view on a geographic basis, we also prepare financial information related to product categories and customer markets for various purposes.

[0000858877-25-000111:mdna:95]
The following table presents product revenue by category (in millions, except percentages):

[0000858877-25-000111:mdna:96]
|  |  | Years Ended |  | 2025 vs. 2024 |
|  |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |
| Networking |  | $ | 28,304 |  |  | $ | 29,229 |  |  | $ | 34,570 |  |  | $ | (925) |  |  | (3) | % |
| Security |  | 8,094 |  |  | 5,075 |  |  | 3,859 |  |  | 3,019 |  |  | 59 | % |
| Collaboration |  | 4,154 |  |  | 4,113 |  |  | 4,052 |  |  | 41 |  |  | 1 | % |
| Observability |  | 1,055 |  |  | 837 |  |  | 661 |  |  | 218 |  |  | 26 | % |
| Total |  | $ | 41,608 |  |  | $ | 39,253 |  |  | $ | 43,142 |  |  | $ | 2,355 |  |  | 6 | % |

[0000858877-25-000111:mdna:97]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-25-000111:mdna:98]
Networking

[0000858877-25-000111:mdna:99]
The Networking product category consists of our core networking technologies of switching, routing, wireless, and servers. Revenue from the Networking product category decreased by 3%, or $0.9 billion. Revenue declined across the portfolio as a result of product shipments returning to normalized levels during the first half of fiscal 2025 from the elevated levels of product shipments we experienced in the first half of fiscal 2024. Within the portfolio, the revenue decline was primarily driven by servers. We also experienced a revenue decline in switching as a result of a decline in campus switching.

[0000858877-25-000111:mdna:100]
Security

[0000858877-25-000111:mdna:101]
The Security product category consists of our Network Security, Identity and Access Management, SASE and Threat Intelligence, Detection, and Response offerings. Revenue in our Security product category increased by 59%, or $3.0 billion, primarily driven by Threat Intelligence, Detection, and Response offerings, which includes the offerings from Splunk, and to a lesser extent, growth in our SASE and Network Security offerings.

[0000858877-25-000111:mdna:102]
Collaboration

[0000858877-25-000111:mdna:103]
The Collaboration product category consists of our Webex Suite, Collaboration Devices, Contact Center and CPaaS offerings. Revenue in our Collaboration product category increased 1%, or $41 million, primarily driven by revenue growth in our Collaboration Devices, CPaaS and Contact Center offerings, partially offset by a decline in our Webex Suite offerings.

[0000858877-25-000111:mdna:104]
Observability

[0000858877-25-000111:mdna:105]
The Observability product category consists of our network assurance, monitoring and analytics and observability suite offerings. Revenue in our Observability product category increased by 26%, or $218 million, primarily driven by our Observability Suite offerings from Splunk and growth in our ThousandEyes network services offerings, partially offset by a decline in monitoring and analytics.

[0000858877-25-000111:mdna:106]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:107]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:108]
Services Revenue by Segment

[0000858877-25-000111:mdna:109]
The following table presents the breakdown of services revenue by segment (in millions, except percentages):

[0000858877-25-000111:mdna:110]
|  | Years Ended |  | 2025 vs. 2024 |
|  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |  | Variance in Dollars |  | Variance in Percent |
| Services revenue: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 9,019 |  |  | $ | 8,829 |  |  | $ | 8,427 |  |  | $ | 190 |  |  | 2 | % |
| Percentage of service revenue | 59.9 | % |  | 60.7 | % |  | 60.8 | % |  |  |  |  |
| EMEA | 3,702 |  |  | 3,472 |  |  | 3,269 |  |  | 230 |  |  | 7 | % |
| Percentage of service revenue | 24.6 | % |  | 23.9 | % |  | 23.6 | % |  |  |  |  |
| APJC | 2,325 |  |  | 2,249 |  |  | 2,160 |  |  | 76 |  |  | 3 | % |
| Percentage of service revenue | 15.5 | % |  | 15.5 | % |  | 15.6 | % |  |  |  |  |
| Total | $ | 15,046 |  |  | $ | 14,550 |  |  | $ | 13,856 |  |  | $ | 496 |  |  | 3 | % |

[0000858877-25-000111:mdna:111]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-25-000111:mdna:112]
Services revenue increased 3%, primarily driven by software, cloud and virtualization support from Splunk and product offering support services. Services revenue increased across each of our geographic segments.

[0000858877-25-000111:mdna:113]
Gross Margin

[0000858877-25-000111:mdna:114]
The following table presents the gross margin for products and services (in millions, except percentages):

[0000858877-25-000111:mdna:115]
|  | AMOUNT |  | PERCENTAGE |
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 26,487 |  |  | $ | 24,914 |  |  | $ | 26,552 |  |  | 63.7 | % |  | 63.5 | % |  | 61.5 | % |
| Services | 10,303 |  |  | 9,914 |  |  | 9,201 |  |  | 68.5 | % |  | 68.1 | % |  | 66.4 | % |
| Total | $ | 36,790 |  |  | $ | 34,828 |  |  | $ | 35,753 |  |  | 64.9 | % |  | 64.7 | % |  | 62.7 | % |

[0000858877-25-000111:mdna:116]
Product Gross Margin

[0000858877-25-000111:mdna:117]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2024 to fiscal 2025:

[0000858877-25-000111:mdna:118]
|  |  | Product Gross Margin Percentage |
| Fiscal 2024 |  | 63.5 | % |
| Productivity (1) |  | 2.0 | % |
| Product pricing |  | (1.6) | % |
| Mix of products sold |  | 1.1 | % |
| Legal dispute with supplier |  | (0.8) | % |
| Amortization of purchased intangible assets |  | (0.4) | % |
| Others |  | (0.1) | % |
| Fiscal 2025 |  | 63.7 | % |

[0000858877-25-000111:mdna:119]
(1) Productivity includes overall manufacturing-related costs, such as component costs, warranty expense, provisions for inventory and the liability related to purchase commitments with contract manufacturers and suppliers, freight, logistics, shipment volume, and other items not categorized elsewhere.

[0000858877-25-000111:mdna:120]
Product gross margin increased by 0.2 percentage points primarily driven by benefits from Splunk and productivity improvements, partially offset by negative impacts from pricing, a charge as a result of a legal dispute with a supplier, and amortization of purchased intangible assets primarily related to Splunk. The productivity improvements were primarily driven

[0000858877-25-000111:mdna:121]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:122]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:123]
by the effects of higher shipment volume and lower total provisions for inventory and the liability related to purchase commitments with contract manufacturers and suppliers.

[0000858877-25-000111:mdna:124]
Supply Chain Impacts and Risks

[0000858877-25-000111:mdna:125]
In past periods, we took multiple actions in order to mitigate component shortages and address significant supply constraints, which resulted in the need to secure long-term supply and increased our inventory supply chain balances compared to historical levels. In fiscal 2025, we entered into additional purchase commitments with contract manufacturers and suppliers related to manufacturing Cisco Silicon One and other products to meet demand from webscale and other customers. We expect to continue entering into these additional purchase commitments in fiscal 2026. These actions and additional purchase commitments have in turn significantly increased our supply chain exposure, which has resulted in negative impacts to our product gross margin in recent periods and may result in further negative impacts in future periods. In addition, on August 26, 2025, we settled a legal dispute with a supplier relating to purchase obligations arising under long-term supply arrangements, which resulted in a charge to product cost of sales, which is described in Note 21 to the Consolidated Financial Statements. The remaining and new supply chain exposures include potential material excess and obsolete or other charges if product demand significantly decreases for a sustained duration, we are unable to generate demand for certain products planned for development, or we are otherwise unable to mitigate these supply chain exposures. Additionally, while we are exposed to new and proposed tariffs and other trade policies, the extent of such exposure is uncertain but could be significant if the exposure remains and we are unable to mitigate it.

[0000858877-25-000111:mdna:126]
Services Gross Margin

[0000858877-25-000111:mdna:127]
Our services gross margin percentage increased by 0.4 percentage points primarily due to higher sales volume and lower delivery costs, partially offset by higher headcount-related costs.

[0000858877-25-000111:mdna:128]
Our services gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-25-000111:mdna:129]
Gross Margin by Segment

[0000858877-25-000111:mdna:130]
The following table presents the total gross margin for each segment (in millions, except percentages):

[0000858877-25-000111:mdna:131]
|  |  | AMOUNT |  | PERCENTAGE |
| Years Ended |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 22,962 |  |  | $ | 21,372 |  |  | $ | 21,350 |  |  | 68.2 | % |  | 66.8 | % |  | 63.8 | % |
| EMEA |  | 10,545 |  |  | 9,755 |  |  | 10,016 |  |  | 71.1 | % |  | 69.1 | % |  | 66.2 | % |
| APJC |  | 5,431 |  |  | 5,187 |  |  | 5,424 |  |  | 66.4 | % |  | 67.2 | % |  | 64.4 | % |
| Segment total |  | 38,938 |  |  | 36,312 |  |  | 36,788 |  |  | 68.7 | % |  | 67.5 | % |  | 64.5 | % |
| Unallocated corporate items (1) |  | (2,148) |  |  | (1,484) |  |  | (1,035) |  |  |  |  |  |  |  |
| Total |  | $ | 36,790 |  |  | $ | 34,828 |  |  | $ | 35,753 |  |  | 64.9 | % |  | 64.7 | % |  | 62.7 | % |

[0000858877-25-000111:mdna:132]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements (which includes the supplier-related legal settlement as described in Note 21 to the Consolidated Financial Statements) and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-25-000111:mdna:133]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-25-000111:mdna:134]
The Americas segment had a gross margin percentage increase driven by positive impacts from productivity improvements and favorable product mix, partially offset by pricing erosion.

[0000858877-25-000111:mdna:135]
The gross margin percentage increase in our EMEA segment was primarily due to positive impacts from productivity improvements and favorable product mix, partially offset by pricing erosion.

[0000858877-25-000111:mdna:136]
The APJC segment had a gross margin percentage decrease driven primarily by pricing erosion and lower services gross margin, partially offset by positive impacts from productivity improvements and favorable product mix.

[0000858877-25-000111:mdna:137]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:138]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:139]
Research and Development (“R&D”), Sales and Marketing, and General and Administrative (“G&A”) Expenses

[0000858877-25-000111:mdna:140]
R&D, sales and marketing, and G&A expenses are summarized in the following table (in millions, except percentages):

[0000858877-25-000111:mdna:141]
|  |  | Years Ended |  | 2025 vs. 2024 |
|  |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |  | Variance in Dollars |  | Variance in Percent |
| Research and development |  | $ | 9,300 |  |  | $ | 7,983 |  |  | $ | 7,551 |  |  | $ | 1,317 |  |  | 16 | % |
| Percentage of revenue |  | 16.4 | % |  | 14.8 | % |  | 13.2 | % |  |  |  |  |
| Sales and marketing |  | 10,966 |  |  | 10,364 |  |  | 9,880 |  |  | 602 |  |  | 6 | % |
| Percentage of revenue |  | 19.4 | % |  | 19.3 | % |  | 17.3 | % |  |  |  |  |
| General and administrative |  | 2,992 |  |  | 2,813 |  |  | 2,478 |  |  | 179 |  |  | 6 | % |
| Percentage of revenue |  | 5.3 | % |  | 5.2 | % |  | 4.3 | % |  |  |  |  |
| Total |  | $ | 23,258 |  |  | $ | 21,160 |  |  | $ | 19,909 |  |  | $ | 2,098 |  |  | 10 | % |
| Percentage of revenue |  | 41.1 | % |  | 39.3 | % |  | 34.9 | % |  |  |  |  |

[0000858877-25-000111:mdna:142]
R&D Expenses

[0000858877-25-000111:mdna:143]
R&D expenses increased primarily due to higher headcount-related expenses reflecting our investments in AI, share-based compensation expense, cash compensation expenses from acquisitions, and discretionary spending.

[0000858877-25-000111:mdna:144]
Sales and Marketing Expenses

[0000858877-25-000111:mdna:145]
Sales and marketing expenses increased primarily due to higher headcount-related expenses, cash compensation expenses from acquisitions, share-based compensation expense, and discretionary spending, partially offset by lower contracted services spending.

[0000858877-25-000111:mdna:146]
G&A Expenses

[0000858877-25-000111:mdna:147]
G&A expenses increased primarily due to higher headcount-related expenses, share-based compensation expense, and  discretionary spending, partially offset by lower acquisition-related costs and lower contracted services spending.

[0000858877-25-000111:mdna:148]
Effect of Foreign Currency

[0000858877-25-000111:mdna:149]
In fiscal 2025, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $16 million, or 0.1%, compared with fiscal 2024.

[0000858877-25-000111:mdna:150]
Amortization of Purchased Intangible Assets

[0000858877-25-000111:mdna:151]
The following table presents the amortization of purchased intangible assets including impairment charges (in millions):

[0000858877-25-000111:mdna:152]
| Years Ended |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 1,174 |  |  | $ | 955 |  |  | $ | 649 |  |
| Operating expenses |  | 1,028 |  |  | 698 |  |  | 282 |  |
| Total |  | $ | 2,202 |  |  | $ | 1,653 |  |  | $ | 931 |  |

[0000858877-25-000111:mdna:153]
The increase in amortization of purchased intangible assets was primarily due to the acquisition of Splunk and other recent acquisitions, partially offset by certain purchased intangible assets that became fully amortized in larger part from our fiscal 2021 acquisition of Acacia, and lower impairment charges in fiscal 2025. Impairment charges related to purchased intangible assets were $40 million and $145 million for fiscal 2025 and fiscal 2024, respectively. The impairment charges were a result of declines in estimated fair values resulting from the reductions in or the elimination of expected future cash flows associated with certain in-process research and development and technology intangible assets.

[0000858877-25-000111:mdna:154]
Restructuring and Other Charges

[0000858877-25-000111:mdna:155]
We recognized total restructuring and other charges, which are included in operating expenses, of $744 million and $789 million in fiscal 2025 and 2024, respectively.

[0000858877-25-000111:mdna:156]
41

[0000858877-25-000111:mdna:157]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:158]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:159]
In the first quarter of fiscal 2025, we announced a restructuring plan in order to allow us to invest in key growth opportunities and drive more efficiencies in our business. This restructuring plan is expected to impact approximately 7% of our global workforce with estimated pre-tax charges of approximately $1 billion. In connection with this restructuring plan, we incurred charges of $744 million during fiscal 2025. We expect this plan to be substantially completed by the end of the second quarter of fiscal 2026.

[0000858877-25-000111:mdna:160]
In the third quarter of fiscal 2024, we initiated a restructuring plan in order to realign the organization and enable further investment in key priority areas. In connection with this plan, we incurred charges of $654 million for fiscal 2024 and the plan is complete.

[0000858877-25-000111:mdna:161]
Operating Income

[0000858877-25-000111:mdna:162]
The following table presents our operating income and our operating income as a percentage of revenue (in millions, except percentages):

[0000858877-25-000111:mdna:163]
| Years Ended |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Operating income |  | $ | 11,760 |  |  | $ | 12,181 |  |  | $ | 15,031 |  |
| Operating income as a percentage of revenue |  | 20.8 | % |  | 22.6 | % |  | 26.4 | % |

[0000858877-25-000111:mdna:164]
Operating income decreased by 3%, and as a percentage of revenue operating income decreased by 1.8 percentage points. These changes resulted primarily from higher share-based compensation expense, higher amortization of purchased intangible assets, a charge as a result of a legal dispute with a supplier, and higher cash compensation expenses from acquisitions.

[0000858877-25-000111:mdna:165]
Interest and Other Income (Loss), Net

[0000858877-25-000111:mdna:166]
Interest Income (Expense), Net   The following table summarizes interest income and interest expense (in millions):

[0000858877-25-000111:mdna:167]
|  | Years Ended |  | 2025 vs. 2024 |
|  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |  | Variance in Dollars |
| Interest income | $ | 1,001 |  |  | $ | 1,365 |  |  | $ | 962 |  |  | $ | (364) |  |
| Interest expense | (1,593) |  |  | (1,006) |  |  | (427) |  |  | (587) |  |
| Interest income (expense), net | $ | (592) |  |  | $ | 359 |  |  | $ | 535 |  |  | $ | (951) |  |

[0000858877-25-000111:mdna:168]
The decrease in interest income was driven by a lower average balance of cash and available-for-sale debt investments and lower interest rates. The increase in interest expense was primarily driven by a higher average balance of debt outstanding during the period.

[0000858877-25-000111:mdna:169]
Other Income (Loss), Net   The components of other income (loss), net, are summarized as follows (in millions):

[0000858877-25-000111:mdna:170]
|  | Years Ended |  | 2025 vs. 2024 |
|  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |
| Available-for-sale debt investments | $ | (100) |  |  | $ | (67) |  |  | $ | (21) |  |  | $ | (33) |  |
| Marketable equity investments | 126 |  |  | 65 |  |  | 37 |  |  | 61 |  |
| Privately held investments | 56 |  |  | (164) |  |  | (193) |  |  | 220 |  |
| Net gains (losses) on investments | 82 |  |  | (166) |  |  | (177) |  |  | 248 |  |
| Other gains (losses), net | (150) |  |  | (140) |  |  | (71) |  |  | (10) |  |
| Other income (loss), net | $ | (68) |  |  | $ | (306) |  |  | $ | (248) |  |  | $ | 238 |  |

[0000858877-25-000111:mdna:171]
The change in our other income (loss), net was primarily driven by lower impairment charges, higher unrealized gains on our privately held investments, and higher gains on our marketable equity investments.

[0000858877-25-000111:mdna:172]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:173]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:174]
Provision for Income Taxes

[0000858877-25-000111:mdna:175]
The provision for income taxes resulted in an effective tax rate of 8.3% for fiscal 2025, compared with 15.6% for fiscal 2024. The net 7.3 percentage points decrease in the effective tax rate was primarily due to a $720 million tax benefit related to the U.S. Tax Court opinion issued during the first quarter of fiscal 2025 regarding the U.S. taxation of deemed foreign dividends in the transition year of the Tax Cut and Job Act ("Tax Act") (our fiscal 2018) and an increase in stock-based compensation windfall.

[0000858877-25-000111:mdna:176]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 21% and for further explanation of our provision for income taxes, see Note 18 to the Consolidated Financial Statements.

[0000858877-25-000111:mdna:177]
43

[0000858877-25-000111:mdna:178]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:179]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:180]
LIQUIDITY AND CAPITAL RESOURCES

[0000858877-25-000111:mdna:181]
The following sections discuss the effects of changes in our balance sheet, our capital allocation strategy including stock repurchase program and dividends, our contractual obligations, and certain other commitments and activities on our liquidity and capital resources.

[0000858877-25-000111:mdna:182]
Balance Sheet and Cash Flows

[0000858877-25-000111:mdna:183]
Cash and Cash Equivalents and Investments  The following table summarizes our cash and cash equivalents and investments (in millions):

[0000858877-25-000111:mdna:184]
|  | July 26, 2025 |  | July 27, 2024 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 8,346 |  |  | $ | 7,508 |  |  | $ | 838 |  |
| Available-for-sale debt investments | 7,381 |  |  | 9,865 |  |  | (2,484) |  |
| Marketable equity securities | 383 |  |  | 481 |  |  | (98) |  |
| Total | $ | 16,110 |  |  | $ | 17,854 |  |  | $ | (1,744) |  |

[0000858877-25-000111:mdna:185]
The net decrease in cash and cash equivalents and investments from fiscal 2024 to fiscal 2025 was primarily driven by cash returned to stockholders in the form of cash dividends of $6.4 billion and repurchases of common stock of $6.0 billion, net repayments of debt and short-term borrowing of $2.8 billion, and capital expenditures of $0.9 billion. These uses of cash were partially offset by net cash provided by operating activities of $14.2 billion. The net cash provided by operating activities during fiscal 2025 benefited from lower tax payments.

[0000858877-25-000111:mdna:186]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our available-for-sale debt investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-25-000111:mdna:187]
Securities Lending  We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of July 26, 2025 and July 27, 2024, we had no outstanding securities lending transactions.

[0000858877-25-000111:mdna:188]
Free Cash Flow and Capital Allocation  As part of our capital allocation strategy, we target to return a minimum of 50% of our free cash flow annually to our stockholders through cash dividends and repurchases of common stock.

[0000858877-25-000111:mdna:189]
We define free cash flow as net cash provided by operating activities less cash used to acquire property and equipment. The following table reconciles our net cash provided by operating activities to free cash flow (in millions):

[0000858877-25-000111:mdna:190]
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Net cash provided by operating activities | $ | 14,193 |  |  | $ | 10,880 |  |  | $ | 19,886 |  |
| Acquisition of property and equipment | (905) |  |  | (670) |  |  | (849) |  |
| Free cash flow | $ | 13,288 |  |  | $ | 10,210 |  |  | $ | 19,037 |  |

[0000858877-25-000111:mdna:191]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue and the timing and amount of tax and other payments. For additional discussion, see “Part I, Item 1A. Risk Factors” in this report.

[0000858877-25-000111:mdna:192]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to stockholders in the form of dividends and stock repurchases. We

[0000858877-25-000111:mdna:193]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:194]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:195]
further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness. Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net cash provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-25-000111:mdna:196]
The following table summarizes the dividends paid and stock repurchases (in millions, except per-share amounts):

[0000858877-25-000111:mdna:197]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  | TOTAL |
| Years Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | Amount |
| July 26, 2025 |  | $ | 1.62 |  |  | $ | 6,437 |  |  | 105 |  |  | $ | 56.53 |  |  | $ | 5,995 |  |  | $ | 12,432 |  |
| July 27, 2024 |  | $ | 1.58 |  |  | $ | 6,384 |  |  | 117 |  |  | $ | 49.45 |  |  | $ | 5,764 |  |  | $ | 12,148 |  |
| July 29, 2023 |  | 1.54 |  |  | 6,302 |  |  | 88 |  |  | 48.49 |  |  | $ | 4,271 |  |  | $ | 10,573 |  |

[0000858877-25-000111:mdna:198]
On August 13, 2025, our Board of Directors declared a quarterly dividend of $0.41 per common share to be paid on October 22, 2025, to all stockholders of record as of the close of business on October 3, 2025. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-25-000111:mdna:199]
The remaining authorized amount for stock repurchases under this program is approximately $14.2 billion, with no termination date.

[0000858877-25-000111:mdna:200]
Accounts Receivable, Net  The following table summarizes our accounts receivable, net (in millions):

[0000858877-25-000111:mdna:201]
|  | July 26, 2025 |  | July 27, 2024 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 6,701 |  |  | $ | 6,685 |  |  | $ | 16 |  |

[0000858877-25-000111:mdna:202]
Our accounts receivable net, as of July 26, 2025 was flat year over year as the increase in the amount of product and service billings was substantially offset by improved shipment linearity in the fourth quarter of fiscal 2025.

[0000858877-25-000111:mdna:203]
Inventory Supply Chain  The following table summarizes our inventories and inventory purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-25-000111:mdna:204]
|  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |  | Variance vs. July 27, 2024 |  | Variance vs. July 29, 2023 |
| Inventories | $ | 3,164 |  |  | $ | 3,373 |  |  | $ | 3,644 |  |  | $ | (209) |  |  | $ | (480) |  |
| Inventory purchase commitments | $ | 7,599 |  |  | $ | 5,158 |  |  | $ | 7,253 |  |  | $ | 2,441 |  |  | $ | 346 |  |
| Inventory deposits and prepayments | $ | 825 |  |  | $ | 973 |  |  | $ | 1,109 |  |  | $ | (148) |  |  | $ | (284) |  |

[0000858877-25-000111:mdna:205]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-25-000111:mdna:206]
|  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |  | Variance vs. July 27, 2024 |  | Variance vs. July 29, 2023 |
| Less than 1 year | $ | 7,202 |  |  | $ | 3,952 |  |  | $ | 5,270 |  |  | $ | 3,250 |  |  | $ | 1,932 |  |
| 1 to 3 years | 320 |  |  | 1,085 |  |  | 1,783 |  |  | (765) |  |  | (1,463) |  |
| 3 to 5 years | 77 |  |  | 121 |  |  | 200 |  |  | (44) |  |  | (123) |  |
| Total(1) | $ | 7,599 |  |  | $ | 5,158 |  |  | $ | 7,253 |  |  | $ | 2,441 |  |  | $ | 346 |  |

[0000858877-25-000111:mdna:207]
(1) The purchase commitments with contract manufacturers and suppliers as of July 26, 2025 has been reduced to give effect to the settlement of a legal dispute with a supplier over purchase obligations arising under certain long-term supply arrangements. See Note 21 to the Consolidated Financial Statements.

[0000858877-25-000111:mdna:208]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:209]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:210]
Inventory as of July 26, 2025 decreased by 6% and inventory purchase commitments with contract manufacturers and suppliers increased by 47% from our balances at the end of fiscal 2024. The combined increase of 26% in our inventory and inventory purchase commitments as compared with the end of fiscal 2024 was primarily related to commitments with contract manufacturers and suppliers related to manufacturing Cisco Silicon One and other products to meet the demand from webscale and other customers.  We expect our inventory balances may increase in future quarters as we work to fulfill this demand.

[0000858877-25-000111:mdna:211]
In addition, we have increased our levels of inventory in recent years in order to help mitigate risks in our supply chain, and began increasing our inventory supply chain balances starting in fiscal 2021 in order to address significant supply constraints seen industry-wide at the time. The increases were primarily due to arrangements to secure supply and pricing for certain product components and commitments with contract manufacturers to meet customer demand and to address extended lead times, as well as advance payments with suppliers to secure future supply, as a result of the supply constraints. Our risks of future material excess and obsolete inventory and related losses are further outlined in the Result of Operations—Product Gross Margin section.

[0000858877-25-000111:mdna:212]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity.

[0000858877-25-000111:mdna:213]
Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments are entered into directly with suppliers and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-25-000111:mdna:214]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of supply constraints, rapidly changing technology and customer requirements. We believe the amount of our inventory and inventory purchase commitments is appropriate for our current and expected customer demand and revenue levels.

[0000858877-25-000111:mdna:215]
Financing Receivables and Guarantees  The following table summarizes our financing receivables (in millions):

[0000858877-25-000111:mdna:216]
|  | July 26, 2025 |  | July 27, 2024 |  | Increase (Decrease) |
| Loan receivables, net | $ | 5,591 |  |  | $ | 5,808 |  |  | $ | (217) |  |
| Lease receivables, net | 936 |  |  | 906 |  |  | 30 |  |
| Total, net | $ | 6,527 |  |  | $ | 6,714 |  |  | $ | (187) |  |

[0000858877-25-000111:mdna:217]
Financing Receivables  Our financing arrangements include loans and leases. Our loan receivables include customer financing for purchases of our hardware, software and services (including technical support and advanced services), and also may include additional funds for other costs associated with network installation and integration of our products and services. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Financing receivables decreased by 3% as compared with the end of fiscal 2024.

[0000858877-25-000111:mdna:218]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, with payment terms generally ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-25-000111:mdna:219]
The volume of channel partner financing was $24.9 billion, $27.1 billion, and $32.1 billion in fiscal 2025, 2024, and 2023, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.2 billion as of July 26, 2025 and July 27, 2024, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner

[0000858877-25-000111:mdna:220]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:221]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:222]
financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of July 26, 2025, the total maximum potential future payments related to these guarantees was approximately $123 million, of which approximately $13 million was recorded as deferred revenue.

[0000858877-25-000111:mdna:223]
Borrowings

[0000858877-25-000111:mdna:224]
Senior Notes  The following table summarizes the principal amount of our senior notes (in millions):

[0000858877-25-000111:mdna:225]
|  | Maturity Date |  | July 26, 2025 |  | July 27, 2024 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | — |  |  | $ | 500 |  |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 1,000 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 2,000 |  |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | — |  |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 2,500 |  |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | — |  |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 2,500 |  |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | — |  |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 2,500 |  |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | — |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | February 24, 2055 |  | 750 |  |  | — |  |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 1,000 |  |
| Total |  |  | $ | 24,750 |  |  | $ | 20,250 |  |

[0000858877-25-000111:mdna:226]
In February 2025, we issued senior notes for an aggregate principal amount of $5.0 billion.

[0000858877-25-000111:mdna:227]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of July 26, 2025.

[0000858877-25-000111:mdna:228]
Commercial Paper  We have a short-term debt financing program in which up to $15.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had $3.5 billion and $10.9 billion in commercial paper notes outstanding as of July 26, 2025, and July 27, 2024, respectively.

[0000858877-25-000111:mdna:229]
Credit Facility  On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of July 26, 2025, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.

[0000858877-25-000111:mdna:230]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:231]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:232]
Remaining Performance Obligations   The following table presents the breakdown of remaining performance obligations (in millions):

[0000858877-25-000111:mdna:233]
|  | July 26, 2025 |  | July 27, 2024 |  | Increase (Decrease) |
| Product | $ | 21,572 |  |  | $ | 20,055 |  |  | $ | 1,517 |  |
| Services | 21,961 |  |  | 20,993 |  |  | 968 |  |
| Total | $ | 43,533 |  |  | $ | 41,048 |  |  | $ | 2,485 |  |
| Short-term RPO | $ | 21,723 |  |  | $ | 20,882 |  |  | $ | 841 |  |
| Long-term RPO | 21,810 |  |  | 20,166 |  |  | 1,644 |  |
| Total | $ | 43,533 |  |  | $ | 41,048 |  |  | $ | 2,485 |  |

[0000858877-25-000111:mdna:234]
Total remaining performance obligations increased 6% in fiscal 2025. Remaining performance obligations for product increased 8% and remaining performance obligations for services increased 5%, compared to fiscal 2024. We expect approximately 50% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-25-000111:mdna:235]
Deferred Revenue   The following table presents the breakdown of deferred revenue (in millions):

[0000858877-25-000111:mdna:236]
|  | July 26, 2025 |  | July 27, 2024 |  | Increase (Decrease) |
| Product | $ | 13,490 |  |  | $ | 13,219 |  |  | $ | 271 |  |
| Services | 15,289 |  |  | 15,256 |  |  | 33 |  |
| Total | $ | 28,779 |  |  | $ | 28,475 |  |  | $ | 304 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 16,416 |  |  | $ | 16,249 |  |  | $ | 167 |  |
| Noncurrent | 12,363 |  |  | 12,226 |  |  | 137 |  |
| Total | $ | 28,779 |  |  | $ | 28,475 |  |  | $ | 304 |  |

[0000858877-25-000111:mdna:237]
Total deferred revenue increased 1% in fiscal 2025. The increase in deferred product revenue of 2% was primarily due to increased deferrals related to our recurring software offerings. Deferred service revenue was flat year over year.

[0000858877-25-000111:mdna:238]
Contractual Obligations

[0000858877-25-000111:mdna:239]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. In addition, we plan for and measure our liquidity and capital resources through an annual budgeting process. The following table summarizes our contractual obligations at July 26, 2025 (in millions):

[0000858877-25-000111:mdna:240]
|  | PAYMENTS DUE BY PERIOD |
| July 26, 2025 | Total |  | Less than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than 5 Years |
| Operating leases | $ | 1,748 |  |  | $ | 429 |  |  | $ | 569 |  |  | $ | 381 |  |  | $ | 369 |  |
| Purchase commitments with contract manufacturers and suppliers | 7,599 |  |  | 7,202 |  |  | 320 |  |  | 77 |  |  | — |  |
| Other purchase obligations | 8,136 |  |  | 2,399 |  |  | 3,247 |  |  | 2,383 |  |  | 107 |  |
| Long-term debt | 24,753 |  |  | 1,751 |  |  | 4,502 |  |  | 3,500 |  |  | 15,000 |  |
| Transition tax payable | 1,595 |  |  | 1,595 |  |  | — |  |  | — |  |  | — |  |
| Other long-term liabilities | 1,745 |  |  | — |  |  | 298 |  |  | 221 |  |  | 1,226 |  |
| Total by period | $ | 45,576 |  |  | $ | 13,376 |  |  | $ | 8,936 |  |  | $ | 6,562 |  |  | $ | 16,702 |  |
| Other long-term liabilities (uncertainty in the timing of future payments) | 2,240 |  |  |  |  |  |  |  |  |  |
| Total | $ | 47,816 |  |  |  |  |  |  |  |  |  |

[0000858877-25-000111:mdna:241]
CISCO SYSTEMS, INC.

[0000858877-25-000111:mdna:242]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000111:mdna:243]
Operating Leases  For more information on our operating leases, see Note 8 to the Consolidated Financial Statements.

[0000858877-25-000111:mdna:244]
Purchase Commitments with Contract Manufacturers and Suppliers  We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments are directly with suppliers and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. The purchase commitments with contract manufacturers and suppliers as of July 26, 2025 has been reduced to give effect to the settlement of a legal dispute with a supplier over purchase obligations arising under certain long-term supply arrangements. See Note 21 to the Consolidated Financial Statements. We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. See further discussion in “Inventory Supply Chain.”

[0000858877-25-000111:mdna:245]
Other Purchase Obligations  Other purchase obligations represent an estimate of all contractual obligations in the ordinary course of business, other than operating leases and commitments with contract manufacturers and suppliers, for which we have not received the goods or services. Purchase orders are not included in the preceding table as they typically represent our authorization to purchase rather than binding contractual purchase obligations.

[0000858877-25-000111:mdna:246]
Long-Term Debt  The amount of long-term debt in the preceding table represents the principal amount of the respective debt instruments. See Note 12 to the Consolidated Financial Statements.

[0000858877-25-000111:mdna:247]
Transition Tax Payable  Transition tax payable represents future cash tax payments associated with the one-time U.S. transition tax on accumulated earnings for foreign subsidiaries as a result of the Tax Act.

[0000858877-25-000111:mdna:248]
Other Long-Term Liabilities  Other long-term liabilities primarily include noncurrent income taxes payable, accrued liabilities for deferred compensation, deferred tax liabilities, and certain other long-term liabilities. Due to the uncertainty in the timing of future payments, our noncurrent income taxes payable of approximately $2.2 billion and deferred tax liabilities of $75 million were presented as one aggregated amount in the total column on a separate line in the preceding table. Noncurrent income taxes payable include uncertain tax positions. See Note 18 to the Consolidated Financial Statements.

[0000858877-25-000111:mdna:249]
Other Commitments

[0000858877-25-000111:mdna:250]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the continued employment with us of certain employees of the acquired entities. See Note 4 to the Consolidated Financial Statements.

[0000858877-25-000111:mdna:251]
Of the total carrying value of our investments in privately held companies as of July 26, 2025, $0.8 billion of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $0.3 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments. See Note 10 to the Consolidated Financial Statements.

[0000858877-25-000111:mdna:252]
We provide financing guarantees, which are generally for various third-party financing arrangements extended to our channel partners. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. See the previous discussion of these financing guarantees under “Financing Receivables and Guarantees.”

[0000858877-25-000111:mdna:253]
Liquidity and Capital Resource Requirements

[0000858877-25-000111:mdna:254]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs (including inventory and other supply related payments), capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.
