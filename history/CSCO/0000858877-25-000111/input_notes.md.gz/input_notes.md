# CSCO notes — 0000858877-25-000111


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000858877-25-000111:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to the 2025 Annual Meeting of Stockholders, to be held on December 16, 2025, are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000858877-25-000111:notes:2]
We recognize the critical importance of maintaining the trust and confidence of our customers, employees, and other stakeholders. To help mitigate the cybersecurity risks that we face, we maintain processes for identifying, assessing, and managing such risks.

[0000858877-25-000111:notes:3]
Our incident response functions, which include our Security and Trust Organization (“S&TO”) under the leadership of our Chief Security and Trust Officer, have established internal policies, processes, and procedures to monitor, detect, investigate, respond to, and escalate management of internal and external cybersecurity threats and incidents. We maintain policies and procedures for the escalation of cybersecurity incidents, assessed as potentially being or becoming material, to designated members of our senior management for further assessment. We also, as necessary, inform our independent registered public accounting firm of significant cybersecurity matters and any relevant developments.

[0000858877-25-000111:notes:4]
To help identify, assess, and mitigate cybersecurity threats that we face to our business, S&TO, in addition to its own capabilities, partners with Cisco’s Talos Threat Intelligence Group and third parties, including governments and peer companies, to share and receive threat intelligence and other information. S&TO actively monitors for and evaluates cybersecurity vulnerabilities, threats, and incidents observable on the Internet and the dark web. In addition to monitoring risks from threats to our own business, we operate third-party risk management programs to help identify and manage risks from cybersecurity threats arising from third-party suppliers and service providers on which we rely. These programs leverage on-going security-focused risk assessments based on industry practices, audits, and contractual requirements.

[0000858877-25-000111:notes:5]
We strive to embed security into our products and services through the Cisco Secure Development Lifecycle (CSDL). The CSDL introduces security and privacy considerations throughout the lifecycle of our products and services. In addition, S&TO advises business units and functional areas on addressing cybersecurity risks and monitors initiatives to mitigate and manage such risks over time. Our business units or functional areas are responsible for managing risks and ensuring that security policies and standards are implemented within the respective business unit or function. S&TO also conducts mandatory cybersecurity training for our employees and provides employees with tools to report suspected incidents.

[0000858877-25-000111:notes:6]
S&TO engages third parties in connection with our cybersecurity risk management processes, including cybersecurity consultants and auditors, to conduct evaluations of our IT security controls and provide certifications for industry-standard security frameworks. In addition, we maintain a global privacy program to assess and manage privacy risks related to how we are collecting, using, sharing, and storing personal data, which is subject to assessment by an independent, third-party privacy assessor.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0000858877-25-000111:notes:7]
Our Chief Security and Trust Officer, who reports to our Executive Vice President, Operations, works collaboratively across our business to implement policies and procedures designed to protect our IT environment and our products and services from cybersecurity threats, and to promptly respond to cybersecurity incidents in accordance with our incident response policies and procedures. Our Chief Security and Trust Officer has extensive cybersecurity experience and has served in various roles in information technology and information security for over 25 years.

[0000858877-25-000111:notes:8]
The Chief Security and Trust Officer provides regular reports on the status of cybersecurity risks, priorities, and focus areas to our executive leadership team. In addition, information on cybersecurity risks is further integrated into our broader enterprise risk management program through our internal audit function, which incorporates such information in regular audits of our cybersecurity and data protection controls and processes.

[0000858877-25-000111:notes:9]
Our Board of Directors oversees risks related to cybersecurity threats to our business directly and through its Audit Committee. The Audit Committee receives regular reports on cybersecurity risks, priorities, and focus areas from our Chief Security and Trust Officer at least four times a year and receives a live presentation at least twice a year. Our Board of Directors also regularly receives updates from the Audit Committee on its oversight activities and, on occasion, receives updates directly from our Chief Security and Trust Officer. Additionally, the Chief Security and Trust Officer provides more frequent updates to the Board of Directors and Audit Committee if necessary due to a cybersecurity threat, incident, or other development.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-25-000111:notes:10]
Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2025, fiscal 2024 and fiscal 2023 were each 52-week fiscal years. The Consolidated Financial Statements include our accounts and those of our subsidiaries and those of our investments consolidated under the voting interest method. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-25-000111:notes:11]
Certain reclassifications have been made to the amounts for prior years in order to conform to the current year’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-25-000111:notes:12]
Summary of Significant Accounting Policies
(a) Cash and Cash Equivalents  We consider all highly liquid investments purchased with an original or remaining maturity of three months or less at the date of purchase to be cash equivalents.

[0000858877-25-000111:notes:13]
(b) Available-for-Sale Debt Investments  We classify our investments in fixed income securities as available-for-sale debt investments. Our available-for-sale debt investments primarily consist of U.S. government, U.S. government agency, non-U.S. government and agency, corporate debt, U.S. agency mortgage-backed securities, commercial paper and certificates of deposit. These available-for-sale debt investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of available-for-sale debt investments sold. These investments are recorded in the Consolidated Balance Sheets at fair value and unrealized gains and losses on these investments are included as a separate component of accumulated other comprehensive income (loss) (AOCI), net of tax. We classify our investments as current based on the nature of the investments and their availability for use in current operations.

[0000858877-25-000111:notes:14]
(c) Equity Instruments  Our equity investments are accounted for as follows:

[0000858877-25-000111:notes:15]
•Marketable equity securities have readily determinable fair value (RDFV) that are measured and recorded at fair value through income.

[0000858877-25-000111:notes:16]
•Non-marketable equity securities do not have RDFV and are measured using a measurement alternative recorded at cost less any impairment, plus or minus changes resulting from qualifying observable price changes. For certain of these securities, we have elected to apply the net asset value (NAV) practical expedient. The NAV is the estimated fair value of these investments.

[0000858877-25-000111:notes:17]
•Equity method investments are securities we do not control, but are able to exert significant influence over the investee. These investments are measured at cost less any impairment, plus or minus our share of equity method investee income or loss.

[0000858877-25-000111:notes:18]
(d) Impairments of Investments  For our available-for-sale debt securities in an unrealized loss position, we determine whether a credit loss exists. In this assessment, among other factors, we consider the extent to which the fair value is less than the amortized cost, any changes to the rating of the security by a rating agency, and adverse conditions specifically related to the security. If factors indicate a credit loss exists, an allowance for credit loss is recorded to other income (loss), net, limited by the amount that the fair value is less than the amortized cost basis. The amount of fair value change relating to all other factors is recognized in other comprehensive income (OCI).

[0000858877-25-000111:notes:19]
We hold non-marketable equity and other investments (“privately held investments”) which are included in other assets in the Consolidated Balance Sheets. We monitor these investments for impairments and make reductions in carrying values if we determine that an impairment charge is required based primarily on the financial condition and near-term prospects of these companies.

[0000858877-25-000111:notes:20]
(e) Inventories  Inventories are stated at the lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. We provide inventory write-downs based on excess and obsolete inventories determined primarily by future demand forecasts. The write-down is measured as the difference between the cost of the inventory and net realizable value based upon assumptions about future demand and charged to the provision for inventory, which is a component of cost of sales. At the point of loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost

[0000858877-25-000111:notes:21]
basis. In addition, we record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0000858877-25-000111:notes:22]
(f) Allowance for Accounts Receivable, Contract Assets and Financing Receivables  We estimate our allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, we determine collectibility by pooling our assets with similar characteristics.

[0000858877-25-000111:notes:23]
The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. Our internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality. Assets that do not share risk characteristics are evaluated on an individual basis. The allowances for credit losses are each measured by multiplying the exposure probability of default, the probability the asset will default within a given time frame, by the loss given default rate, the percentage of the asset not expected to be collected due to default, based on the pool of assets.

[0000858877-25-000111:notes:24]
Probability of default rates are published quarterly by third-party credit agencies. Adjustments to our internal credit risk ratings may take into account including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000858877-25-000111:notes:25]
(g) Financing Receivables and Guarantees  We provide financing arrangements, including loan receivables and lease receivables, for certain qualified channel partners and end-users to build, maintain, and upgrade their networks, and we record accrued interest on the portfolio. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services (including technical support and advanced services), and also may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables have terms of one year to three years on average. Lease receivables represent sales-type leases resulting from the sale of Cisco’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average.

[0000858877-25-000111:notes:26]
Outstanding financing receivables that are aged 31 days or more from the contractual payment date are considered past due. We do not accrue interest on financing receivables that are considered impaired and more than 120 days past due unless either the receivable has not been collected due to administrative reasons or the receivable is well secured and in the process of collection. Financing receivables may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain. After a financing receivable has been categorized as nonaccrual, interest will be recognized when cash is received. A financing receivable may be returned to accrual status after all of the customer’s delinquent balances of principal and interest have been settled, and the customer remains current for an appropriate period.

[0000858877-25-000111:notes:27]
We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as a sale, and we receive a payment for the receivables from the third party based on our standard payment terms. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. We could be called upon to make payments under these guarantees if the channel partners do not pay. Deferred revenue relating to these financing arrangements is recorded in accordance with revenue recognition policies or for the fair value of the financing guarantees.

[0000858877-25-000111:notes:28]
(h) Leases  We lease real estate, information technology (IT) and other equipment and vehicles. We also have arrangements with certain suppliers and contract manufacturers which includes the leasing of dedicated space and equipment costs. Our leases have the option to extend or terminate the lease when it is reasonably certain that we will exercise that option.

[0000858877-25-000111:notes:29]
As a lessee, we determine if an arrangement is a lease at commencement. Our right-of-use (ROU) lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments related to the lease. Operating lease ROU assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. We use incremental borrowing rates based on information available at the commencement date to determine the present value of our lease payments. Certain of our lease agreements contain variable lease payments. Our variable lease payments can fluctuate depending on the level of activity or the cost of certain services where we have elected to combine lease and non-lease components. While these payments are not included as part of our lease liabilities, they are recognized as variable lease expense in the period they are incurred.

[0000858877-25-000111:notes:30]
We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. As a lessor, we determine if an arrangement is a lease at inception. We provide leasing arrangements for our equipment to certain qualified customers. Our lease portfolio primarily consists of sales-type leases. We allocate the consideration in a bundled contract with our customers based on relative standalone selling prices of our lease and non-lease components. The residual value on our leased equipment is determined at the inception of the lease based on an analysis of estimates of the value of equipment, market factors and historical customer behavior. Residual value estimates are reviewed on a periodic basis and other-than-temporary declines are expensed in the period they occur. Our leases generally provide an end-of-term option for the customer to extend the lease under mutually-agreed terms, return the leased equipment, or purchase the equipment for either the then-market value of the equipment or a pre-determined purchase price. If a customer chooses to terminate their lease prior to the original end of termination date, the customer is required to pay all remaining lease payments in full.

[0000858877-25-000111:notes:31]
(i) Depreciation and Amortization  Property and equipment are stated at cost, less accumulated depreciation or amortization, whenever applicable. Depreciation and amortization expenses for property and equipment were approximately $0.7 billion for each of fiscal 2025, 2024, and 2023. Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-25-000111:notes:32]
| Asset Category |  | Period |
| Buildings |  | 25 years |
| Building improvements |  | Up to 15 years |
| Leasehold improvements |  | Shorter of remaining lease term or up to 15 years |
| Production, engineering, computer and other equipment and related software |  | Up to 5 years |
| Operating lease assets |  | Based on lease term |
| Furniture and fixtures |  | 5 years |

[0000858877-25-000111:notes:33]
(j) Business Combinations  We allocate the fair value of the purchase consideration of our acquisitions to the tangible assets, liabilities, and intangible assets acquired, including in-process research and development (IPR&D), based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life. Acquisition-related expenses and related restructuring costs are recognized separately from the business combination and are expensed as incurred.

[0000858877-25-000111:notes:34]
(k) Goodwill and Purchased Intangible Assets  Goodwill is tested for impairment on an annual basis in the fourth fiscal quarter and, when specific circumstances dictate, between annual tests. When impaired, the carrying value of goodwill is written down to fair value. Identifying a potential impairment consists of comparing the fair value of a reporting unit with its carrying amount, including goodwill. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. See “Long-Lived Assets” for our policy regarding impairment testing of purchased intangible assets with finite lives. Purchased intangible assets with indefinite lives are assessed for potential impairment annually or when events or circumstances indicate that their carrying amounts might be impaired.

[0000858877-25-000111:notes:35]
(l) Long-Lived Assets  Long-lived assets that are held and used by us are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability of long-lived assets is based on an estimate of the undiscounted future cash flows resulting from the use of the asset and its eventual disposition. Measurement of an impairment loss for long-lived assets that management expects to hold and use is based on the difference between the fair value of the asset and its carrying value. Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0000858877-25-000111:notes:36]
(m) Fair Value  Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, we consider the principal or most advantageous market in which we would transact, and we also consider assumptions that market participants would use when pricing the asset or liability.

[0000858877-25-000111:notes:37]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. The standard establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement.

[0000858877-25-000111:notes:38]
The fair value hierarchy is as follows:

[0000858877-25-000111:notes:39]
Level 1 applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000858877-25-000111:notes:40]
Level 2 applies to assets or liabilities for which there are inputs other than quoted prices that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets); or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of assets or liabilities.

[0000858877-25-000111:notes:41]
Level 3 applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities. The fair values are determined based on model-based techniques such as discounted cash flow models using inputs that we could not corroborate with market data.

[0000858877-25-000111:notes:42]
(n) Derivative Instruments  We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.

[0000858877-25-000111:notes:43]
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.

[0000858877-25-000111:notes:44]
(o) Foreign Currency Translation  Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated to U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of AOCI. Income and expense accounts are translated at average exchange rates during the year. Remeasurement adjustments are recorded in other income (loss), net.

[0000858877-25-000111:notes:45]
(p) Concentrations of Risk  Cash and cash equivalents are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. We seek to mitigate our credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties.

[0000858877-25-000111:notes:46]
We perform ongoing credit evaluations of our customers and, with the exception of certain financing transactions, do not require collateral from our customers. We receive certain of our components from sole suppliers. Additionally, we rely on a limited number of contract manufacturers and suppliers to provide manufacturing services for our products. The inability of a contract manufacturer or supplier to fulfill our supply requirements could materially impact future operating results.

[0000858877-25-000111:notes:47]
(q) Revenue Recognition  We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations, resulting in contracts that may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our

[0000858877-25-000111:notes:48]
commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers. Revenue from subscription offers includes revenue recognized over time as well as upfront.

[0000858877-25-000111:notes:49]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes. An allowance for future sales returns is established based on historical trends in product return rates and the related provision is recorded as a reduction to revenue.

[0000858877-25-000111:notes:50]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-25-000111:notes:51]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and direct sale customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.

[0000858877-25-000111:notes:52]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license’s utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

[0000858877-25-000111:notes:53]
(r) Advertising Costs  We expense advertising costs as incurred. Advertising costs included within sales and marketing expenses were approximately $186 million, $210 million, and $205 million for fiscal 2025, 2024, and 2023, respectively.

[0000858877-25-000111:notes:54]
(s) Share-Based Compensation Expense  We measure and recognize the compensation expense for all share-based awards made to employees and directors, including restricted stock units (RSUs), performance-based restricted stock units (PRSUs), employee stock purchases related to the Employee Stock Purchase Plan (Employee Stock Purchase Rights) and employee stock options based on estimated fair values. Share-based compensation expense is reduced for forfeitures as they occur.

[0000858877-25-000111:notes:55]
(t) Software Development Costs  Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized. Costs incurred during the application development stage for internal-use software and cloud-based applications are capitalized. Such software development costs capitalized during the periods presented were not material.

[0000858877-25-000111:notes:56]
(u) Income Taxes  Income tax expense is based on pretax financial accounting income. Deferred tax assets and liabilities are recognized for the expected tax consequences of temporary differences between the tax bases of assets and liabilities and their reported amounts. Valuation allowances are recorded to reduce deferred tax assets to the amount that will more likely than not be realized.

[0000858877-25-000111:notes:57]
We account for uncertainty in income taxes using a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. We classify the liability for unrecognized tax benefits as current to the extent that we anticipate payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.

[0000858877-25-000111:notes:58]
(v) Computation of Net Income per Share  Basic net income per share is computed using the weighted-average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted-average number of common shares and dilutive potential common shares outstanding during the period. Diluted shares outstanding includes the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares.

[0000858877-25-000111:notes:59]
(w) Consolidation of Variable Interest Entities  Our approach in assessing the consolidation requirement for variable interest entities focuses on identifying which enterprise has the power to direct the activities that most significantly impact the variable interest entity’s economic performance and which enterprise has the obligation to absorb losses or the right to receive benefits from the variable interest entity. Should we conclude that we are the primary beneficiary of a variable interest entity, the assets, liabilities, and results of operations of the variable interest entity will be included in our Consolidated Financial Statements.

[0000858877-25-000111:notes:60]
(x) Use of Estimates  The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Estimates are used for the following, among others:

[0000858877-25-000111:notes:61]
•Revenue recognition

[0000858877-25-000111:notes:62]
•Allowances for accounts receivable, sales returns, and financing receivables

[0000858877-25-000111:notes:63]
•Inventory valuation and liability for purchase commitments with contract manufacturers and suppliers

[0000858877-25-000111:notes:64]
•Loss contingencies and product warranties

[0000858877-25-000111:notes:65]
•Fair value measurements

[0000858877-25-000111:notes:66]
•Valuation of goodwill and purchased intangible assets

[0000858877-25-000111:notes:67]
•Income taxes

[0000858877-25-000111:notes:68]
The actual results that we experience may differ materially from our estimates.

[0000858877-25-000111:notes:69]
(y) Recent Accounting Updates Recently Adopted

[0000858877-25-000111:notes:70]
Segment Reporting  In November 2023, the Financial Accounting Standards Board (FASB) issued an accounting standard update that expands the disclosure requirements for reportable segments, primarily through enhanced disclosures around significant segment expenses. We adopted this accounting standard update for our fiscal 2025 Form 10-K with comparative periods updated to reflect additional disclosures. See Note 19.

[0000858877-25-000111:notes:71]
(z) Recent Accounting Standards or Updates Not Yet Effective as of Fiscal Year End

[0000858877-25-000111:notes:72]
Improvements on Income Tax Disclosures  In December 2023, the FASB issued an accounting standard update expanding the requirements for disclosure of disaggregated information about the effective tax rate reconciliation and income taxes paid. The accounting standard update will be effective for our fiscal 2026 Form 10-K. We are currently evaluating the impact of this accounting standard update on our income tax disclosures.

[0000858877-25-000111:notes:73]
Disaggregation of Income Statement Expenses  In November 2024, the FASB issued an accounting standard update expanding the disclosure requirements about specific expense categories, primarily through disaggregated information on income statement line items. The accounting standard update will be effective for our fiscal 2028 Form 10-K, and early adoption is permitted. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-25-000111:notes:74]
Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-25-000111:notes:75]
Property and Equipment, Net

[0000858877-25-000111:notes:76]
|  |  | July 26, 2025 |  | July 27, 2024 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,045 |  |  | $ | 4,247 |  |
| Production, engineering, computer and other equipment and related software |  | 5,178 |  |  | 5,160 |  |
| Operating lease assets |  | 51 |  |  | 115 |  |
| Furniture, fixtures and other |  | 316 |  |  | 351 |  |
| Total gross property and equipment |  | 9,590 |  |  | 9,873 |  |
| Less: accumulated depreciation and amortization |  | (7,477) |  |  | (7,783) |  |
| Total |  | $ | 2,113 |  |  | $ | 2,090 |  |


## us-gaap:DerivativesPolicyTextBlock

[0000858877-25-000111:notes:77]
(n) Derivative Instruments  We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risks by limiting our counterparties to major financial institutions and requiring collateral in certain cases. In addition, the potential risk of loss with any one counterparty resulting from credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-25-000111:notes:78]
Observability consists of our network assurance, monitoring and analytics and observability suite offerings. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-25-000111:notes:79]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and advanced services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Advanced services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

[0000858877-25-000111:notes:80]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing

[0000858877-25-000111:notes:81]
arrangements to customers for our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.
Subscription revenue includes revenue recognized from our term software licenses, security software licenses, SaaS, and associated service arrangements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-25-000111:notes:82]
Revenue
(a)Disaggregation of Revenue

[0000858877-25-000111:notes:83]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category.

[0000858877-25-000111:notes:84]
The following table presents this disaggregation of revenue (in millions):

[0000858877-25-000111:notes:85]
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Product revenue: |  |  |  |  |  |
| Networking | $ | 28,304 |  |  | $ | 29,229 |  |  | $ | 34,570 |  |
| Security | 8,094 |  |  | 5,075 |  |  | 3,859 |  |
| Collaboration | 4,154 |  |  | 4,113 |  |  | 4,052 |  |
| Observability | 1,055 |  |  | 837 |  |  | 661 |  |
| Total Product | 41,608 |  |  | 39,253 |  |  | 43,142 |  |
| Services | 15,046 |  |  | 14,550 |  |  | 13,856 |  |
| Total revenue | $ | 56,654 |  |  | $ | 53,803 |  |  | $ | 56,998 |  |

[0000858877-25-000111:notes:86]
Amounts may not sum due to rounding.

[0000858877-25-000111:notes:87]
Networking consists of our core networking technologies of switching, routing, wireless, and servers. These technologies consist of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-25-000111:notes:88]
Security consists of our Network Security, Identity and Access Management, SASE and Threat Intelligence, Detection, and Response offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-25-000111:notes:89]
Collaboration consists of our Webex Suite, Collaboration Devices, Contact Center and CPaaS offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-25-000111:notes:90]
arrangements to customers for our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.

[0000858877-25-000111:notes:91]
Subscription revenue includes revenue recognized from our term software licenses, security software licenses, SaaS, and associated service arrangements. Our subscription revenue is recorded in product and services revenue in our Consolidated Statements of Operations as follows (in millions):

[0000858877-25-000111:notes:92]
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Product | $ | 17,783 |  |  | $ | 14,078 |  |  | $ | 11,931 |  |
| Services | 13,743 |  |  | 13,302 |  |  | 12,709 |  |
| Total | $ | 31,526 |  |  | $ | 27,380 |  |  | $ | 24,640 |  |

[0000858877-25-000111:notes:93]
The majority of our product subscription revenue is recognized over time and the remainder is recognized upfront. Substantially all of our services subscription revenue is recognized over time based on the contract term.

[0000858877-25-000111:notes:94]
(b)Contract Balances

[0000858877-25-000111:notes:95]
Accounts Receivable

[0000858877-25-000111:notes:96]
Accounts receivable, net was $6.7 billion as of each of July 26, 2025 and July 27, 2024, as reported on the Consolidated Balance Sheets.

[0000858877-25-000111:notes:97]
The allowances for credit loss for our accounts receivable are summarized as follows (in millions):

[0000858877-25-000111:notes:98]
|  |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Allowance for credit loss at beginning of fiscal year |  | $ | 87 |  |  | $ | 85 |  |  | $ | 83 |  |
| Provisions |  | 33 |  |  | 36 |  |  | 39 |  |
| Recoveries (write-offs), net |  | (51) |  |  | (34) |  |  | (37) |  |
| Allowance for credit loss at end of fiscal year |  | $ | 69 |  |  | $ | 87 |  |  | $ | 85 |  |

[0000858877-25-000111:notes:99]
Contract Assets and Liabilities

[0000858877-25-000111:notes:100]
Gross contract assets by our internal risk ratings are summarized as follows (in millions):

[0000858877-25-000111:notes:101]
|  | July 26, 2025 |  | July 27, 2024 |
| 1 to 4 | $ | 1,358 |  |  | $ | 1,266 |  |
| 5 to 6 | 1,868 |  |  | 1,456 |  |
| 7 and Higher | 73 |  |  | 72 |  |
| Total | $ | 3,299 |  |  | $ | 2,794 |  |

[0000858877-25-000111:notes:102]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of July 26, 2025 and July 27, 2024, our contract assets for these unbilled receivables, net of allowances, were $3.2 billion and $2.7 billion, respectively, of which $1.7 billion and $1.4 billion, respectively, were included in other current assets, with remaining balances included in other assets.

[0000858877-25-000111:notes:103]
Contract liabilities consist of deferred revenue. Deferred revenue was $28.8 billion as of July 26, 2025 compared to $28.5 billion as of July 27, 2024. We recognized approximately $16.1 billion of revenue during fiscal 2025 that was included in the deferred revenue balance at July 27, 2024.

[0000858877-25-000111:notes:104]
(c)Capitalized Contract Acquisition Costs

[0000858877-25-000111:notes:105]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Capitalized contract acquisition costs were $1.5 billion and $1.3 billion as of July 26, 2025 and July 27, 2024, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $957 million, $742 million, and $723 million for fiscal 2025, 2024, and 2023, respectively, and was included in sales and marketing expenses.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-25-000111:notes:106]
Our subscription revenue is recorded in product and services revenue in our Consolidated Statements of Operations as follows (in millions):

[0000858877-25-000111:notes:107]
The following table presents revenue for groups of similar products and services (in millions):

[0000858877-25-000111:notes:108]
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Revenue: |  |  |  |  |  |
| Networking | $ | 28,304 |  |  | $ | 29,229 |  |  | $ | 34,570 |  |
| Security | 8,094 |  |  | 5,075 |  |  | 3,859 |  |
| Collaboration | 4,154 |  |  | 4,113 |  |  | 4,052 |  |
| Observability | 1,055 |  |  | 837 |  |  | 661 |  |
| Total Product | 41,608 |  |  | 39,253 |  |  | 43,142 |  |
| Services | 15,046 |  |  | 14,550 |  |  | 13,856 |  |
| Total | $ | 56,654 |  |  | $ | 53,803 |  |  | $ | 56,998 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-25-000111:notes:109]
Acquisitions 
(a)  Fiscal 2025 Acquisitions Summary

[0000858877-25-000111:notes:110]
Allocation of the total purchase consideration for acquisitions we completed during fiscal 2025 is summarized as follows (in millions):

[0000858877-25-000111:notes:111]
| Fiscal 2025 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions | $ | 293 |  |  | $ | (21) |  |  | $ | 121 |  |  | $ | 193 |  |

[0000858877-25-000111:notes:112]
The total purchase consideration of $293 million related to our acquisitions completed during fiscal 2025 consisted primarily of cash consideration. The total cash and cash equivalents acquired from these acquisitions was approximately $15 million.

[0000858877-25-000111:notes:113]
The purchase price allocation for acquisitions completed during fiscal 2025 is preliminary and subject to revision as additional information about fair value of assets and liabilities become available. Additional information that existed as of the acquisition date but is currently unknown to us may become known during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date.

[0000858877-25-000111:notes:114]
(b)  Fiscal 2024 Acquisitions Summary

[0000858877-25-000111:notes:115]
Allocation of the total purchase consideration for acquisitions we completed during fiscal 2024 is summarized as follows (in millions):

[0000858877-25-000111:notes:116]
| Fiscal 2024 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Splunk | $ | 27,090 |  |  | $ | (2,761) |  |  | $ | 10,550 |  |  | $ | 19,301 |  |
| Other acquisitions | 1,370 |  |  | (47) |  |  | 500 |  |  | 917 |  |
| Total acquisitions | $ | 28,460 |  |  | $ | (2,808) |  |  | $ | 11,050 |  |  | $ | 20,218 |  |

[0000858877-25-000111:notes:117]
Acquisition of Splunk Inc.

[0000858877-25-000111:notes:118]
On March 18, 2024, we completed the acquisition of Splunk Inc. (“Splunk”), a public cybersecurity and observability company. Under the terms of the agreement, we agreed to pay $157 per share in cash, representing approximately $27 billion in merger consideration.

[0000858877-25-000111:notes:119]
Purchase Consideration

[0000858877-25-000111:notes:120]
The following table summarizes the purchase consideration for the Splunk acquisition (in millions):

[0000858877-25-000111:notes:121]
|  |  | Amount |
| Cash paid for outstanding Splunk common stock |  | $ | 26,950 |  |
| Fair value of converted Splunk equity awards attributable to pre-acquisition services |  | 137 |  |
| Settlement of pre-existing relationships |  | 3 |  |
| Total purchase consideration |  | $ | 27,090 |  |

[0000858877-25-000111:notes:122]
Allocation of the total purchase consideration for Splunk is presented as follows (in millions):

[0000858877-25-000111:notes:123]
|  |  | Amount |
| Cash and cash equivalents |  | $ | 2,422 |  |
| Investments |  | 285 |  |
| Accounts receivable, net |  | 623 |  |
| Goodwill |  | 19,301 |  |
| Purchased intangible assets |  | 10,550 |  |
| Deferred tax assets |  | 1,308 |  |
| Other current and noncurrent assets |  | 1,176 |  |
| Accounts payable |  | (39) |  |
| Accrued compensation |  | (337) |  |
| Current portion of deferred revenue |  | (1,768) |  |
| Splunk convertible notes |  | (3,344) |  |
| Deferred tax liabilities |  | (2,523) |  |
| Noncurrent portion of deferred revenue |  | (86) |  |
| Other current and other noncurrent liabilities |  | (478) |  |
| Total |  | $ | 27,090 |  |

[0000858877-25-000111:notes:124]
Our Consolidated Statements of Operations for fiscal 2024 includes revenue of approximately $1.4 billion and a net loss of $557 million attributable to Splunk since the date of acquisition.

[0000858877-25-000111:notes:125]
We incurred $82 million of transaction costs related to the Splunk acquisition and these costs were expensed as incurred in G&A in the Consolidated Statements of Operations. We incurred $79 million of these transaction costs in fiscal 2024.

[0000858877-25-000111:notes:126]
The goodwill generated from Splunk is primarily related to expected synergies. Goodwill is not deductible for income tax purposes. Refer to Note 5. Goodwill and Purchased Intangible Assets for details about our intangible assets acquired through the Splunk acquisition.

[0000858877-25-000111:notes:127]
Pro forma Financial Information

[0000858877-25-000111:notes:128]
The unaudited pro forma financial information in the table below summarizes the combined results of our operations and Splunk’s operations, as though the acquisition of Splunk had been completed as of the beginning of fiscal 2023. The pro forma financial information for fiscal 2024 combines our results for this period with the results of Splunk for the period beginning August 1, 2023, through July 27, 2024. The pro forma financial information for fiscal 2023 combines our historical results for that period with the historical results of Splunk for the year ended July 31, 2023.

[0000858877-25-000111:notes:129]
The following table summarizes the pro forma financial information (in millions):

[0000858877-25-000111:notes:130]
| Years Ended | July 27, 2024 |  | July 29, 2023 |
| Total revenue | $ | 56,761 |  |  | $ | 60,841 |  |
| Net income | $ | 9,280 |  |  | $ | 10,078 |  |

[0000858877-25-000111:notes:131]
The pro forma financial information is presented for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition and the cost of financing the acquisition had taken place at the beginning of fiscal 2023. The financial information for the periods presented above includes pro forma adjustments for amortization of purchased intangible assets, costs related to financing the acquisition and transaction costs.

[0000858877-25-000111:notes:132]
Other 2024 Acquisitions

[0000858877-25-000111:notes:133]
The total purchase consideration of $1.4 billion related to the other acquisitions we completed during fiscal 2024 consisted primarily of cash consideration. The total cash and cash equivalents acquired from these other acquisitions was approximately $24 million.

[0000858877-25-000111:notes:134]
(c)  Fiscal 2023 Acquisitions

[0000858877-25-000111:notes:135]
Allocation of the total purchase consideration for acquisitions completed during fiscal 2023 is summarized as follows (in millions):

[0000858877-25-000111:notes:136]
| Fiscal 2023 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions | $ | 315 |  |  | $ | (18) |  |  | $ | 150 |  |  | $ | 183 |  |

[0000858877-25-000111:notes:137]
The total purchase consideration related to our acquisitions completed during fiscal 2023 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately  $7 million.

[0000858877-25-000111:notes:138]
(d)  Compensation Expense Related to Acquisitions

[0000858877-25-000111:notes:139]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-25-000111:notes:140]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-25-000111:notes:141]
|  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Compensation expense related to acquisitions | $ | 876 |  |  | $ | 618 |  |  | $ | 222 |  |

[0000858877-25-000111:notes:142]
As of July 26, 2025, we estimated that future cash compensation expense of up to $618 million may be required to be recognized pursuant to these applicable acquisition agreements.

[0000858877-25-000111:notes:143]
(e)  Other Acquisition and Divestiture Information

[0000858877-25-000111:notes:144]
Total transaction costs related to acquisition and divestiture activities during fiscal 2025, 2024, and 2023, inclusive of Splunk, were $12 million, $104 million and $26 million, respectively. These transaction costs were expensed as incurred in G&A in the Consolidated Statements of Operations.

[0000858877-25-000111:notes:145]
The goodwill generated from acquisitions completed during fiscal 2025, 2024, and 2023 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-25-000111:notes:146]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during fiscal 2025, 2024, and 2023, with the exception of Splunk, have not been presented because the effects of the acquisitions were not material to our financial results.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-25-000111:notes:147]
Goodwill and Purchased Intangible Assets 
(a)Goodwill

[0000858877-25-000111:notes:148]
The following tables present the goodwill allocated to our reportable segments as of July 26, 2025 and July 27, 2024, as well as the changes to goodwill during fiscal 2025 and 2024 (in millions):

[0000858877-25-000111:notes:149]
|  | Balance at July 27, 2024 |  | Acquisitions, net of Divestitures |  | Foreign Currency Translation and Other |  | Balance at July 26, 2025 |
| Americas | $ | 36,169 |  |  | $ | 121 |  |  | $ | 178 |  |  | $ | 36,468 |  |
| EMEA | 14,283 |  |  | 47 |  |  | 67 |  |  | 14,397 |  |
| APJC | 8,208 |  |  | 23 |  |  | 40 |  |  | 8,271 |  |
| Total | $ | 58,660 |  |  | $ | 191 |  |  | $ | 285 |  |  | $ | 59,136 |  |

[0000858877-25-000111:notes:150]
|  | Balance at July 29, 2023 |  | Splunk |  | Other Acquisitions |  | Foreign Currency Translation and Other |  | Balance at July 27, 2024 |
| Americas | $ | 24,035 |  |  | $ | 11,619 |  |  | $ | 573 |  |  | $ | (58) |  |  | $ | 36,169 |  |
| EMEA | 9,118 |  |  | 4,980 |  |  | 207 |  |  | (22) |  |  | 14,283 |  |
| APJC | 5,382 |  |  | 2,702 |  |  | 137 |  |  | (13) |  |  | 8,208 |  |
| Total | $ | 38,535 |  |  | $ | 19,301 |  |  | $ | 917 |  |  | $ | (93) |  |  | $ | 58,660 |  |

[0000858877-25-000111:notes:151]
(b)Purchased Intangible Assets

[0000858877-25-000111:notes:152]
The following tables present details of our intangible assets acquired through acquisitions completed during fiscal 2025 and 2024 (in millions, except years):

[0000858877-25-000111:notes:153]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | CUSTOMERRELATED |  | TECHNOLOGY |  | TRADE NAME |  | IPR&D |  |
| Fiscal 2025 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions | 3.5 |  | $ | 16 |  |  | 3.8 |  | $ | 105 |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 121 |  |

[0000858877-25-000111:notes:154]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | CUSTOMERRELATED |  | TECHNOLOGY |  | TRADE NAME |  | IPR&D |  |
| Fiscal 2024 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Splunk | 9.1 |  | $ | 6,140 |  |  | 6.0 |  | $ | 3,900 |  |  | 12.0 |  | $ | 510 |  |  | $ | — |  |  | $ | 10,550 |  |
| Others | 4.9 |  | 83 |  |  | 4.8 |  | 400 |  |  | 1.3 |  | 3 |  |  | 14 |  |  | 500 |  |
| Total acquisitions |  |  | $ | 6,223 |  |  |  |  | $ | 4,300 |  |  |  |  | $ | 513 |  |  | $ | 14 |  |  | $ | 11,050 |  |

[0000858877-25-000111:notes:155]
The following tables present details of our purchased intangible assets (in millions):

[0000858877-25-000111:notes:156]
| July 26, 2025 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Customer related |  | $ | 6,341 |  |  | $ | (1,268) |  |  | $ | 5,073 |  |
| Technology |  | 5,254 |  |  | (1,606) |  |  | 3,648 |  |
| Trade name |  | 526 |  |  | (72) |  |  | 454 |  |
| Total purchased intangible assets with finite lives |  | 12,121 |  |  | (2,946) |  |  | 9,175 |  |
| In-process research and development, with indefinite lives |  | — |  |  | — |  |  | — |  |
| Total |  | $ | 12,121 |  |  | $ | (2,946) |  |  | $ | 9,175 |  |

[0000858877-25-000111:notes:157]
| July 27, 2024 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Customer related |  | $ | 6,844 |  |  | $ | (829) |  |  | $ | 6,015 |  |
| Technology |  | 6,680 |  |  | (2,006) |  |  | 4,674 |  |
| Trade name |  | 553 |  |  | (49) |  |  | 504 |  |
| Total purchased intangible assets with finite lives |  | 14,077 |  |  | (2,884) |  |  | 11,193 |  |
| In-process research and development, with indefinite lives |  | 26 |  |  | — |  |  | 26 |  |
| Total |  | $ | 14,103 |  |  | $ | (2,884) |  |  | $ | 11,219 |  |

[0000858877-25-000111:notes:158]
Purchased intangible assets include intangible assets acquired through acquisitions as well as through direct purchases or licenses.

[0000858877-25-000111:notes:159]
Impairment charges related to purchased intangible assets were $40 million for fiscal 2025 and $145 million for fiscal 2024. Impairment charges were as a result of declines in estimated fair value resulting from the reductions in or the elimination of expected future cash flows associated with certain in-process research and development and technology intangible assets.

[0000858877-25-000111:notes:160]
The following table presents the amortization of purchased intangible assets, including impairment charges (in millions):

[0000858877-25-000111:notes:161]
| Years Ended |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 1,174 |  |  | $ | 955 |  |  | $ | 649 |  |
| Operating expenses |  | 1,028 |  |  | 698 |  |  | 282 |  |
| Total |  | $ | 2,202 |  |  | $ | 1,653 |  |  | $ | 931 |  |

[0000858877-25-000111:notes:162]
The estimated future amortization expense of purchased intangible assets with finite lives as of July 26, 2025 is as follows (in millions):

[0000858877-25-000111:notes:163]
| Fiscal Year | Amount |
| 2026 | $ | 1,828 |  |
| 2027 | 1,480 |  |
| 2028 | 1,401 |  |
| 2029 | 1,275 |  |
| 2030 | 991 |  |
| Thereafter | 2,200 |  |
| Total | $ | 9,175 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-25-000111:notes:164]
Restructuring and Other Charges
In the first quarter of fiscal 2025, we announced a restructuring plan (the “Fiscal 2025 Plan”), in order to allow us to invest in key growth opportunities and drive more efficiencies in our business. The Fiscal 2025 Plan is expected to impact approximately 7% of our global workforce, with estimated pre-tax charges of up to $1 billion consisting of severance and other one-time termination benefits, and other costs. In connection with the Fiscal 2025 Plan, we incurred charges of $744 million in fiscal 2025 and the plan is expected to be substantially completed in the second quarter of fiscal 2026. The aggregate pre-tax charges are primarily cash-based and consist of severance and other one-time termination benefits, and other costs.

[0000858877-25-000111:notes:165]
We initiated a restructuring plan in fiscal 2024 (the “Fiscal 2024 Plan”), in order to realign the organization and enable further investment in key priority areas. In connection with the Fiscal 2024 Plan, we incurred cumulative charges of $654 million and the plan is complete. The aggregate pretax charges related to this plan were primarily cash-based and consist of severance and other one-time termination benefits and other costs.

[0000858877-25-000111:notes:166]
We initiated a restructuring plan in fiscal 2023 (the “Fiscal 2023 Plan”), which was completed in fiscal 2024. In connection with the Fiscal 2023 Plan, we incurred cumulative charges of $670 million and the plan is complete. The aggregate pretax charges related to this plan were primarily cash-based and consist of severance and other one-time termination benefits, real estate-related charges, and other costs.

[0000858877-25-000111:notes:167]
The following table summarizes the activities related to our restructuring liability, which is included in other current liabilities on our Consolidated Balance Sheets (in millions):

[0000858877-25-000111:notes:168]
|  |  | FISCAL 2025 PLAN |  | FISCAL 2024 AND PRIOR PLANS |  |  |
|  |  | Employee Severance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 30, 2022 |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 7 |  |  | $ | 9 |  |
| Charges |  | — |  |  | — |  |  | 465 |  |  | 66 |  |  | 531 |  |
| Cash payments |  | — |  |  | — |  |  | (302) |  |  | (12) |  |  | (314) |  |
| Non-cash items |  | — |  |  | — |  |  | 2 |  |  | (15) |  |  | (13) |  |
| Liability as of July 29, 2023 |  | — |  |  | — |  |  | 167 |  |  | 46 |  |  | 213 |  |
| Charges |  | — |  |  | — |  |  | 731 |  |  | 58 |  |  | 789 |  |
| Cash payments |  | — |  |  | — |  |  | (677) |  |  | (14) |  |  | (691) |  |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (37) |  |  | (37) |  |
| Liability as of July 27, 2024 |  | — |  |  | — |  |  | 221 |  |  | 53 |  |  | 274 |  |
| Charges |  | 617 |  |  | 127 |  |  | — |  |  | — |  |  | 744 |  |
| Cash payments |  | (582) |  |  | (9) |  |  | (170) |  |  | (9) |  |  | (770) |  |
| Non-cash items |  | 31 |  |  | (72) |  |  | (29) |  |  | (31) |  |  | (101) |  |
| Liability as of July 26, 2025 |  | $ | 66 |  |  | $ | 46 |  |  | $ | 22 |  |  | $ | 13 |  |  | $ | 147 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-25-000111:notes:169]
Balance Sheet and Other Details 
The following tables provide details of selected balance sheet and other items (in millions, except percentages):

[0000858877-25-000111:notes:170]
Cash, Cash Equivalents, Restricted Cash and Restricted Cash Equivalents

[0000858877-25-000111:notes:171]
|  |  | July 26, 2025 |  | July 27, 2024 |
| Cash and cash equivalents |  | $ | 8,346 |  |  | $ | 7,508 |  |
| Restricted cash and restricted cash equivalents included in other current assets |  | 564 |  |  | 765 |  |
| Restricted cash and restricted cash equivalents included in other assets |  | — |  |  | 569 |  |
| Total |  | $ | 8,910 |  |  | $ | 8,842 |  |

[0000858877-25-000111:notes:172]
Our restricted cash and restricted cash equivalents are funds primarily related to contractual obligations with suppliers.

[0000858877-25-000111:notes:173]
Inventories

[0000858877-25-000111:notes:174]
|  |  | July 26, 2025 |  | July 27, 2024 |
| Raw materials |  | $ | 1,744 |  |  | $ | 2,039 |  |
| Work in process |  | 261 |  |  | 83 |  |
| Finished goods |  | 933 |  |  | 1,027 |  |
| Service-related spares |  | 220 |  |  | 216 |  |
| Demonstration systems |  | 6 |  |  | 8 |  |
| Total |  | $ | 3,164 |  |  | $ | 3,373 |  |

[0000858877-25-000111:notes:175]
Remaining Performance Obligations (RPO)

[0000858877-25-000111:notes:176]
|  |  | July 26, 2025 |  | July 27, 2024 |
| Product |  | $ | 21,572 |  |  | $ | 20,055 |  |
| Services |  | 21,961 |  |  | 20,993 |  |
| Total |  | $ | 43,533 |  |  | $ | 41,048 |  |
| Short-term RPO |  | $ | 21,723 |  |  | $ | 20,882 |  |
| Long-term RPO |  | 21,810 |  |  | 20,166 |  |
| Total |  | $ | 43,533 |  |  | $ | 41,048 |  |
| Amount to be recognized as revenue over the next 12 months |  | 50 | % |  | 51 | % |
| Deferred revenue |  | $ | 28,779 |  |  | $ | 28,475 |  |
| Unbilled contract revenue |  | 14,754 |  |  | 12,573 |  |
| Total |  | $ | 43,533 |  |  | $ | 41,048 |  |

[0000858877-25-000111:notes:177]
Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

[0000858877-25-000111:notes:178]
Deferred Revenue

[0000858877-25-000111:notes:179]
|  |  | July 26, 2025 |  | July 27, 2024 |
| Product |  | $ | 13,490 |  |  | $ | 13,219 |  |
| Services |  | 15,289 |  |  | 15,256 |  |
| Total |  | $ | 28,779 |  |  | $ | 28,475 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 16,416 |  |  | $ | 16,249 |  |
| Noncurrent |  | 12,363 |  |  | 12,226 |  |
| Total |  | $ | 28,779 |  |  | $ | 28,475 |  |

[0000858877-25-000111:notes:180]
Transition Tax Payable

[0000858877-25-000111:notes:181]
Our income tax payable associated with the one-time U.S. transition tax on accumulated earnings for foreign subsidiaries as a result of the Tax Act is as follows:

[0000858877-25-000111:notes:182]
|  |  | July 26, 2025 |  | July 27, 2024 |
| Current |  | $ | 1,595 |  |  | $ | 1,819 |  |
| Noncurrent |  | — |  |  | 2,273 |  |
| Total |  | $ | 1,595 |  |  | $ | 4,092 |  |

[0000858877-25-000111:notes:183]
Our remaining transition tax payable as of July 26, 2025 has been reduced to reflect the transition tax benefit of the U.S. Tax Court opinion in Varian Medical Systems, Inc. v. Commissioner. See Note 18.


## us-gaap:OperatingLeasesOfLessorDisclosureTextBlock

[0000858877-25-000111:notes:184]
Leases
(a)Lessee Arrangements

[0000858877-25-000111:notes:185]
The following table presents our operating lease balances (in millions):

[0000858877-25-000111:notes:186]
|  | Balance Sheet Line Item |  | July 26, 2025 |  | July 27, 2024 |
| Operating lease ROU assets | Other assets |  | $ | 1,301 |  |  | $ | 1,066 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 375 |  |  | $ | 364 |  |
| Operating lease liabilities | Other long-term liabilities |  | 1,175 |  |  | 906 |  |
| Total operating lease liabilities |  |  | $ | 1,550 |  |  | $ | 1,270 |  |

[0000858877-25-000111:notes:187]
The components of our lease expenses were as follows (in millions):

[0000858877-25-000111:notes:188]
| Years Ended |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Operating lease expense |  | $ | 495 |  |  | $ | 420 |  |  | $ | 425 |  |
| Short-term lease expense |  | 77 |  |  | 75 |  |  | 65 |  |
| Variable lease expense |  | 191 |  |  | 194 |  |  | 242 |  |
| Total lease expense |  | $ | 763 |  |  | $ | 689 |  |  | $ | 732 |  |

[0000858877-25-000111:notes:189]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-25-000111:notes:190]
| Years Ended |  | July 26, 2025 |  | July 27, 2024 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows |  | $ | 457 |  |  | $ | 394 |  |
| ROU assets obtained in exchange for operating leases liabilities |  | $ | 660 |  |  | $ | 459 |  |

[0000858877-25-000111:notes:191]
The weighted-average lease term was 5.7 years and 4.9 years as of July 26, 2025 and July 27, 2024, respectively. The weighted-average discount rate was 4.1% and 4.0% as of July 26, 2025 and July 27, 2024, respectively.

[0000858877-25-000111:notes:192]
The maturities of our operating leases (undiscounted) as of July 26, 2025 are as follows (in millions):

[0000858877-25-000111:notes:193]
| Fiscal Year | Amount |
| 2026 | $ | 429 |  |
| 2027 | 322 |  |
| 2028 | 247 |  |
| 2029 | 200 |  |
| 2030 | 181 |  |
| Thereafter | 369 |  |
| Total lease payments | 1,748 |  |
| Less interest | (198) |  |
| Total | $ | 1,550 |  |

[0000858877-25-000111:notes:194]
(b)Lessor Arrangements

[0000858877-25-000111:notes:195]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income for fiscal 2025, 2024, and 2023 was $66 million, $65 million and $51 million, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-25-000111:notes:196]
Future minimum lease payments on our lease receivables as of July 26, 2025 are summarized as follows (in millions):

[0000858877-25-000111:notes:197]
| Fiscal Year | Amount |
| 2026 | $ | 342 |  |
| 2027 | 163 |  |
| 2028 | 234 |  |
| 2029 | 177 |  |
| 2030 | 34 |  |
| Thereafter | 32 |  |
| Total | 982 |  |
| Less: Present value of lease payments | 883 |  |
| Unearned income | $ | 99 |  |

[0000858877-25-000111:notes:198]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-25-000111:notes:199]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-25-000111:notes:200]
|  | July 26, 2025 |  | July 27, 2024 |
| Operating lease assets | $ | 51 |  |  | $ | 115 |  |
| Accumulated depreciation | (17) |  |  | (61) |  |
| Operating lease assets, net | $ | 34 |  |  | $ | 54 |  |

[0000858877-25-000111:notes:201]
Our operating lease income for fiscal 2025, 2024, and 2023 was $37 million, $58 million and $73 million, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-25-000111:notes:202]
Minimum future rentals on noncancelable operating leases as of July 26, 2025 are summarized as follows (in millions):

[0000858877-25-000111:notes:203]
| Fiscal Year | Amount |
| 2026 | $ | 16 |  |
| 2027 | 7 |  |
| 2028 | 2 |  |
| Total | $ | 25 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-25-000111:notes:204]
Financing Receivables  
(a)Financing Receivables

[0000858877-25-000111:notes:205]
Financing receivables primarily consist of loan receivables and lease receivables. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services (including technical support and advanced services), and also may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables have terms of one year to three years on average. Lease receivables represent sales-type leases resulting from the sale of Cisco’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average.

[0000858877-25-000111:notes:206]
A summary of our financing receivables is presented as follows (in millions):

[0000858877-25-000111:notes:207]
| July 26, 2025 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,628 |  |  | $ | 982 |  |  | $ | 6,610 |  |
| Residual value | — |  |  | 66 |  |  | 66 |  |
| Unearned income | — |  |  | (99) |  |  | (99) |  |
| Allowance for credit loss | (37) |  |  | (13) |  |  | (50) |  |
| Total, net | $ | 5,591 |  |  | $ | 936 |  |  | $ | 6,527 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 2,715 |  |  | $ | 346 |  |  | $ | 3,061 |  |
| Noncurrent | 2,876 |  |  | 590 |  |  | 3,466 |  |
| Total, net | $ | 5,591 |  |  | $ | 936 |  |  | $ | 6,527 |  |

[0000858877-25-000111:notes:208]
| July 27, 2024 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,858 |  |  | $ | 965 |  |  | $ | 6,823 |  |
| Residual value | — |  |  | 67 |  |  | 67 |  |
| Unearned income | — |  |  | (111) |  |  | (111) |  |
| Allowance for credit loss | (50) |  |  | (15) |  |  | (65) |  |
| Total, net | $ | 5,808 |  |  | $ | 906 |  |  | $ | 6,714 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 3,071 |  |  | $ | 267 |  |  | $ | 3,338 |  |
| Noncurrent | 2,737 |  |  | 639 |  |  | 3,376 |  |
| Total, net | $ | 5,808 |  |  | $ | 906 |  |  | $ | 6,714 |  |

[0000858877-25-000111:notes:209]
(b)Credit Quality of Financing Receivables

[0000858877-25-000111:notes:210]
The tables below present our gross financing receivables, excluding residual value, less unearned income, categorized by our internal credit risk rating by period of origination (in millions):

[0000858877-25-000111:notes:211]
| July 26, 2025 |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 31, 2021 |  | July 30, 2022 |  | July 29, 2023 |  | July 27, 2024 |  | July 26, 2025 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 83 |  |  | $ | 236 |  |  | $ | 371 |  |  | $ | 1,258 |  |  | $ | 1,556 |  |  | $ | 3,506 |  |
| 5 to 6 | 2 |  |  | 56 |  |  | 53 |  |  | 167 |  |  | 561 |  |  | 1,248 |  |  | 2,087 |  |
| 7 and Higher | — |  |  | — |  |  | 6 |  |  | 9 |  |  | 4 |  |  | 16 |  |  | 35 |  |
| Total Loan Receivables | $ | 4 |  |  | $ | 139 |  |  | $ | 295 |  |  | $ | 547 |  |  | $ | 1,823 |  |  | $ | 2,820 |  |  | $ | 5,628 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | — |  |  | $ | 9 |  |  | $ | 23 |  |  | $ | 112 |  |  | $ | 187 |  |  | $ | 207 |  |  | $ | 538 |  |
| 5 to 6 | — |  |  | 6 |  |  | 25 |  |  | 77 |  |  | 120 |  |  | 103 |  |  | 331 |  |
| 7 and Higher | — |  |  | — |  |  | 1 |  |  | 3 |  |  | 8 |  |  | 2 |  |  | 14 |  |
| Total Lease Receivables | $ | — |  |  | $ | 15 |  |  | $ | 49 |  |  | $ | 192 |  |  | $ | 315 |  |  | $ | 312 |  |  | $ | 883 |  |
| Total | $ | 4 |  |  | $ | 154 |  |  | $ | 344 |  |  | $ | 739 |  |  | $ | 2,138 |  |  | $ | 3,132 |  |  | $ | 6,511 |  |

[0000858877-25-000111:notes:212]
| July 27, 2024 |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 25, 2020 |  | July 31, 2021 |  | July 30, 2022 |  | July 29, 2023 |  | July 27, 2024 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 78 |  |  | $ | 341 |  |  | $ | 555 |  |  | $ | 945 |  |  | $ | 1,803 |  |  | $ | 3,724 |  |
| 5 to 6 | 2 |  |  | 29 |  |  | 127 |  |  | 130 |  |  | 426 |  |  | 1,314 |  |  | 2,028 |  |
| 7 and Higher | 3 |  |  | 1 |  |  | 10 |  |  | 74 |  |  | 14 |  |  | 4 |  |  | 106 |  |
| Total Loan Receivables | $ | 7 |  |  | $ | 108 |  |  | $ | 478 |  |  | $ | 759 |  |  | $ | 1,385 |  |  | $ | 3,121 |  |  | $ | 5,858 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 1 |  |  | $ | 8 |  |  | $ | 38 |  |  | $ | 46 |  |  | $ | 176 |  |  | $ | 341 |  |  | $ | 610 |  |
| 5 to 6 | 1 |  |  | 11 |  |  | 22 |  |  | 44 |  |  | 129 |  |  | 21 |  |  | 228 |  |
| 7 and Higher | — |  |  | — |  |  | 1 |  |  | 3 |  |  | 4 |  |  | 8 |  |  | 16 |  |
| Total Lease Receivables | $ | 2 |  |  | $ | 19 |  |  | $ | 61 |  |  | $ | 93 |  |  | $ | 309 |  |  | $ | 370 |  |  | $ | 854 |  |
| Total | $ | 9 |  |  | $ | 127 |  |  | $ | 539 |  |  | $ | 852 |  |  | $ | 1,694 |  |  | $ | 3,491 |  |  | $ | 6,712 |  |

[0000858877-25-000111:notes:213]
The following tables present the aging analysis of gross receivables as of July 26, 2025 and July 27, 2024 (in millions):

[0000858877-25-000111:notes:214]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| July 26, 2025 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 18 |  |  | $ | 18 |  |  | $ | 16 |  |  | $ | 52 |  |  | $ | 5,576 |  |  | $ | 5,628 |  |  | $ | 4 |  |  | $ | 5 |  |  | $ | 5 |  |
| Lease receivables | 7 |  |  | 3 |  |  | 6 |  |  | 16 |  |  | 867 |  |  | 883 |  |  | 4 |  |  | 1 |  |  | 1 |  |
| Total | $ | 25 |  |  | $ | 21 |  |  | $ | 22 |  |  | $ | 68 |  |  | $ | 6,443 |  |  | $ | 6,511 |  |  | $ | 8 |  |  | $ | 6 |  |  | $ | 6 |  |

[0000858877-25-000111:notes:215]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| July 27, 2024 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 34 |  |  | $ | 17 |  |  | $ | 35 |  |  | $ | 86 |  |  | $ | 5,772 |  |  | $ | 5,858 |  |  | $ | 14 |  |  | $ | 7 |  |  | $ | 7 |  |
| Lease receivables | 14 |  |  | 4 |  |  | 5 |  |  | 23 |  |  | 831 |  |  | 854 |  |  | 1 |  |  | — |  |  | — |  |
| Total | $ | 48 |  |  | $ | 21 |  |  | $ | 40 |  |  | $ | 109 |  |  | $ | 6,603 |  |  | $ | 6,712 |  |  | $ | 15 |  |  | $ | 7 |  |  | $ | 7 |  |

[0000858877-25-000111:notes:216]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract.

[0000858877-25-000111:notes:217]
(c)Allowance for Credit Loss Rollforward

[0000858877-25-000111:notes:218]
The allowances for credit loss and the related financing receivables are summarized as follows (in millions):

[0000858877-25-000111:notes:219]
|  | CREDIT LOSS ALLOWANCES |
|  | LoanReceivables |  | LeaseReceivables |  | Total |
| Allowance for credit loss as of July 27, 2024 | $ | 50 |  |  | $ | 15 |  |  | $ | 65 |  |
| Provisions (benefits) | (6) |  |  | (3) |  |  | (9) |  |
| Recoveries (write-offs), net | (9) |  |  | — |  |  | (9) |  |
| Foreign exchange and other | 2 |  |  | 1 |  |  | 3 |  |
| Allowance for credit loss as of July 26, 2025 | $ | 37 |  |  | $ | 13 |  |  | $ | 50 |  |

[0000858877-25-000111:notes:220]
|  | CREDIT LOSS ALLOWANCES |
|  | LoanReceivables |  | LeaseReceivables |  | Total |
| Allowance for credit loss as of July 29, 2023 | $ | 53 |  |  | $ | 19 |  |  | $ | 72 |  |
| Provisions (benefits) | 1 |  |  | (3) |  |  | (2) |  |
| Recoveries (write-offs), net | (4) |  |  | (1) |  |  | (5) |  |
| Allowance for credit loss as of July 27, 2024 | $ | 50 |  |  | $ | 15 |  |  | $ | 65 |  |

[0000858877-25-000111:notes:221]
|  | CREDIT LOSS ALLOWANCES |
|  | LoanReceivables |  | LeaseReceivables |  | Total |
| Allowance for credit loss as of July 30, 2022 | $ | 103 |  |  | $ | 23 |  |  | $ | 126 |  |
| Provisions (benefits) | (7) |  |  | (1) |  |  | (8) |  |
| Recoveries (write-offs), net | (38) |  |  | (3) |  |  | (41) |  |
| Foreign exchange and other | (5) |  |  | — |  |  | (5) |  |
| Allowance for credit loss as of July 29, 2023 | $ | 53 |  |  | $ | 19 |  |  | $ | 72 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-25-000111:notes:222]
Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-25-000111:notes:223]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-25-000111:notes:224]
| July 26, 2025 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,971 |  |  | $ | 2 |  |  | $ | (12) |  |  | $ | 1,961 |  |
| U.S. government agency securities | 67 |  |  | — |  |  | — |  |  | 67 |  |
| Non-U.S. government and agency securities | 458 |  |  | — |  |  | — |  |  | 458 |  |
| Corporate debt securities | 3,138 |  |  | 13 |  |  | (61) |  |  | 3,090 |  |
| U.S. agency mortgage-backed securities | 320 |  |  | — |  |  | (34) |  |  | 286 |  |
| Commercial paper | 950 |  |  | — |  |  | — |  |  | 950 |  |
| Certificates of deposit | 569 |  |  | — |  |  | — |  |  | 569 |  |
| Total | $ | 7,473 |  |  | $ | 15 |  |  | $ | (107) |  |  | $ | 7,381 |  |

[0000858877-25-000111:notes:225]
| July 27, 2024 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,380 |  |  | $ | 1 |  |  | $ | (28) |  |  | $ | 2,353 |  |
| U.S. government agency securities | 223 |  |  | — |  |  | (2) |  |  | 221 |  |
| Non-U.S. government and agency securities | 370 |  |  | 1 |  |  | — |  |  | 371 |  |
| Corporate debt securities | 3,818 |  |  | 5 |  |  | (146) |  |  | 3,677 |  |
| U.S. agency mortgage-backed securities | 1,959 |  |  | — |  |  | (178) |  |  | 1,781 |  |
| Commercial paper | 1,023 |  |  | — |  |  | — |  |  | 1,023 |  |
| Certificates of deposit | 439 |  |  | — |  |  | — |  |  | 439 |  |
| Total | $ | 10,212 |  |  | $ | 7 |  |  | $ | (354) |  |  | $ | 9,865 |  |

[0000858877-25-000111:notes:226]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-25-000111:notes:227]
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Gross realized gains | $ | 10 |  |  | $ | 7 |  |  | $ | 4 |  |
| Gross realized losses | (110) |  |  | (74) |  |  | (25) |  |
| Total | $ | (100) |  |  | $ | (67) |  |  | $ | (21) |  |

[0000858877-25-000111:notes:228]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at July 26, 2025 and July 27, 2024 (in millions):

[0000858877-25-000111:notes:229]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 26, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,076 |  |  | $ | (6) |  |  | $ | 302 |  |  | $ | (6) |  |  | $ | 1,378 |  |  | $ | (12) |  |
| U.S. government agency securities | 8 |  |  | — |  |  | 21 |  |  | — |  |  | 29 |  |  | — |  |
| Non-U.S. government and agency securities | 292 |  |  | — |  |  | — |  |  | — |  |  | 292 |  |  | — |  |
| Corporate debt securities | 106 |  |  | — |  |  | 1,800 |  |  | (35) |  |  | 1,906 |  |  | (35) |  |
| U.S. agency mortgage-backed securities | 5 |  |  | — |  |  | 279 |  |  | (34) |  |  | 284 |  |  | (34) |  |
| Commercial paper | 30 |  |  | — |  |  | — |  |  | — |  |  | 30 |  |  | — |  |
| Total | $ | 1,517 |  |  | $ | (6) |  |  | $ | 2,402 |  |  | $ | (75) |  |  | $ | 3,919 |  |  | $ | (81) |  |

[0000858877-25-000111:notes:230]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 598 |  |  | $ | (2) |  |  | $ | 1,399 |  |  | $ | (26) |  |  | $ | 1,997 |  |  | $ | (28) |  |
| U.S. government agency securities | 89 |  |  | — |  |  | 109 |  |  | (2) |  |  | 198 |  |  | (2) |  |
| Non-U.S. government and agency securities | 17 |  |  | — |  |  | — |  |  | — |  |  | 17 |  |  | — |  |
| Corporate debt securities | 276 |  |  | (1) |  |  | 2,818 |  |  | (115) |  |  | 3,094 |  |  | (116) |  |
| U.S. agency mortgage-backed securities | 238 |  |  | (1) |  |  | 1,438 |  |  | (177) |  |  | 1,676 |  |  | (178) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 1,228 |  |  | $ | (4) |  |  | $ | 5,764 |  |  | $ | (320) |  |  | $ | 6,992 |  |  | $ | (324) |  |

[0000858877-25-000111:notes:231]
The following table summarizes the maturities of our available-for-sale debt investments as of July 26, 2025 (in millions):

[0000858877-25-000111:notes:232]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 3,959 |  |  | $ | 3,911 |  |
| After 1 year through 5 years | 3,194 |  |  | 3,184 |  |
| Mortgage-backed securities with no single maturity | 320 |  |  | 286 |  |
| Total | $ | 7,473 |  |  | $ | 7,381 |  |

[0000858877-25-000111:notes:233]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-25-000111:notes:234]
(b)Marketable Equity Securities

[0000858877-25-000111:notes:235]
We held marketable equity securities of $383 million and $481 million as of July 26, 2025 and July 27, 2024, respectively. We recognized net unrealized gains of $108 million, $71 million and $36 million for fiscal 2025, 2024, and 2023, respectively, on our marketable securities still held as of the reporting date.

[0000858877-25-000111:notes:236]
(c)  Investments in Privately Held Companies

[0000858877-25-000111:notes:237]
The carrying value of our investments in privately held companies was $1.9 billion and $1.8 billion as of July 26, 2025 and July 27, 2024, respectively. We have total funding commitments of $0.3 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.

[0000858877-25-000111:notes:238]
Investments in privately held companies measured using the measurement alternative had a carrying value of $0.6 billion as of each of July 26, 2025 and July 27, 2024. We recorded adjustments to the carrying value of our investments in privately held companies measured using the measurement alternative as follows (in millions):

[0000858877-25-000111:notes:239]
|  | July 26, 2025 |  | July 27, 2024 |
| Cumulative upward adjustments | $ | 195 |  |  | $ | 207 |  |
| Cumulative downward adjustments, including impairments | (597) |  |  | (537) |  |
| Net adjustments | $ | (402) |  |  | $ | (330) |  |

[0000858877-25-000111:notes:240]
We held equity interests in certain private equity funds of $0.7 billion and $0.8 billion as of July 26, 2025 and July 27, 2024, respectively, which are accounted for under the NAV practical expedient.

[0000858877-25-000111:notes:241]
Of the total carrying value of our investments in privately held companies as of July 26, 2025, $0.8 billion of such investments are considered to be in variable interest entities which are unconsolidated.

[0000858877-25-000111:notes:242]
Certain of our investments in privately held companies are required to be consolidated under the voting interest entity model. The noncontrolling interest attributed to these investments was $162 million and $99 million as of July 26, 2025 and July 27, 2024, respectively, and is included in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interest attributed to these investments is not material for any of the fiscal years presented and is included in other income (loss), net in the Consolidated Statements of Operations.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-25-000111:notes:243]
Fair Value 
(a)Assets and Liabilities Measured at Fair Value on a Recurring Basis

[0000858877-25-000111:notes:244]
Assets and liabilities measured at fair value on a recurring basis were as follows (in millions):

[0000858877-25-000111:notes:245]
|  | JULY 26, 2025 |  | JULY 27, 2024 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 5,885 |  |  | $ | — |  |  | $ | 5,885 |  |  | $ | 3,334 |  |  | $ | — |  |  | $ | 3,334 |  |
| Commercial paper | — |  |  | 336 |  |  | 336 |  |  | — |  |  | 468 |  |  | 468 |  |
| Certificates of deposit | — |  |  | — |  |  | — |  |  | — |  |  | 14 |  |  | 14 |  |
| Corporate debt securities | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 25 |  |  | 25 |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 1,961 |  |  | 1,961 |  |  | — |  |  | 2,353 |  |  | 2,353 |  |
| U.S. government agency securities | — |  |  | 67 |  |  | 67 |  |  | — |  |  | 221 |  |  | 221 |  |
| Non-U.S. government and agency securities | — |  |  | 458 |  |  | 458 |  |  | — |  |  | 371 |  |  | 371 |  |
| Corporate debt securities | — |  |  | 3,090 |  |  | 3,090 |  |  | — |  |  | 3,677 |  |  | 3,677 |  |
| U.S. agency mortgage-backed securities | — |  |  | 286 |  |  | 286 |  |  | — |  |  | 1,781 |  |  | 1,781 |  |
| Commercial paper | — |  |  | 950 |  |  | 950 |  |  | — |  |  | 1,023 |  |  | 1,023 |  |
| Certificates of deposit | — |  |  | 569 |  |  | 569 |  |  | — |  |  | 439 |  |  | 439 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 383 |  |  | — |  |  | 383 |  |  | 481 |  |  | — |  |  | 481 |  |
| Other current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 563 |  |  | — |  |  | 563 |  |  | 750 |  |  | — |  |  | 750 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | — |  |  | — |  |  | — |  |  | 563 |  |  | — |  |  | 563 |  |
| Derivative assets | — |  |  | 32 |  |  | 32 |  |  | — |  |  | 64 |  |  | 64 |  |
| Total | $ | 6,831 |  |  | $ | 7,750 |  |  | $ | 14,581 |  |  | $ | 5,128 |  |  | $ | 10,436 |  |  | $ | 15,564 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 31 |  |  | $ | 31 |  |  | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |
| Total | $ | — |  |  | $ | 31 |  |  | $ | 31 |  |  | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |

[0000858877-25-000111:notes:246]
(b)Assets Measured at Fair Value on a Nonrecurring Basis

[0000858877-25-000111:notes:247]
Our non-marketable equity securities using the measurement alternative are adjusted to fair value on a non-recurring basis. Adjustments are made when observable transactions for identical or similar investments of the same issuer occur, or due to impairment. These securities are classified as Level 3 in the fair value hierarchy because we estimate the value based on valuation methods using the observable transaction price at the transaction date and other unobservable inputs such as volatility, rights, and obligations of the securities we hold.

[0000858877-25-000111:notes:248]
The fair value for purchased intangible assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation. Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable. See Note 5.

[0000858877-25-000111:notes:249]
(c)  Other Fair Value Disclosures

[0000858877-25-000111:notes:250]
The fair value of our short-term loan receivables approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables as of July 26, 2025 and July 27, 2024 was $2.9 billion and $2.7 billion,

[0000858877-25-000111:notes:251]
respectively. The estimated fair value of our long-term loan receivables approximates their carrying value. We use unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables, and therefore they are categorized as Level 3.
As of July 26, 2025 and July 27, 2024, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of July 26, 2025, the fair value of our senior notes was $25.0 billion, with a carrying amount of $24.6 billion. This compares to a fair value of $20.4 billion and a carrying amount of $20.1 billion as of July 27, 2024. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2.


## us-gaap:DebtDisclosureTextBlock

[0000858877-25-000111:notes:252]
Borrowings 
(a)Short-Term Debt

[0000858877-25-000111:notes:253]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-25-000111:notes:254]
|  | July 26, 2025 |  | July 27, 2024 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 1,749 |  |  | 4.15 | % |  | $ | 488 |  |  | 6.66 | % |
| Commercial paper | 3,482 |  |  | 4.37 | % |  | 10,853 |  |  | 5.43 | % |
| Current portion of other debt | 1 |  |  | 1.13 | % |  | — |  |  | — |  |
| Total | $ | 5,232 |  |  |  |  | $ | 11,341 |  |  |  |

[0000858877-25-000111:notes:255]
We have a short-term debt financing program of up to $15.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-25-000111:notes:256]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-25-000111:notes:257]
(b)Long-Term Debt

[0000858877-25-000111:notes:258]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-25-000111:notes:259]
|  |  |  | July 26, 2025 |  | July 27, 2024 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | — |  |  | — |  | $ | 500 |  |  | 6.66% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | 4.61% |  | — |  |  | — |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | 4.73% |  | — |  |  | — |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | 4.94% |  | — |  |  | — |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | 5.11% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.50% | February 24, 2055 |  | 750 |  |  | 5.49% |  | — |  |  | — |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 3 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 24,753 |  |  |  |  | 20,253 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (142) |  |  |  |  | (133) |  |  |  |
| Hedge accounting fair value adjustments |  |  | — |  |  |  |  | (11) |  |  |  |
| Total |  |  | $ | 24,611 |  |  |  |  | $ | 20,109 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,750 |  |  |  |  | $ | 488 |  |  |  |
| Long-term debt |  |  | 22,861 |  |  |  |  | 19,621 |  |  |  |
| Total |  |  | $ | 24,611 |  |  |  |  | $ | 20,109 |  |  |  |

[0000858877-25-000111:notes:260]
In February 2025, we issued senior notes for an aggregate principal amount of $5.0 billion.

[0000858877-25-000111:notes:261]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of July 26, 2025, we were in compliance with all debt covenants.

[0000858877-25-000111:notes:262]
As of July 26, 2025, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-25-000111:notes:263]
| Fiscal Year | Amount |
| 2026 | $ | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | 1,000 |  |
| 2029 | 2,500 |  |
| 2030 | 1,000 |  |
| Thereafter | 15,000 |  |
| Total | $ | 24,753 |  |

[0000858877-25-000111:notes:264]
(c)Credit Facility

[0000858877-25-000111:notes:265]
On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of July 26, 2025, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-25-000111:notes:266]
Derivative Instruments 
(a)Summary of Derivative Instruments

[0000858877-25-000111:notes:267]
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risks by limiting our counterparties to major financial institutions and requiring collateral in certain cases. In addition, the potential risk of loss with any one counterparty resulting from credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-25-000111:notes:268]
The fair values of our derivative instruments and the line items on the Consolidated Balance Sheets to which they were recorded are summarized as follows (in millions):

[0000858877-25-000111:notes:269]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | July 26, 2025 |  | July 27, 2024 |  | Balance Sheet Line Item |  | July 26, 2025 |  | July 27, 2024 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 17 |  |  | $ | 47 |  |  | Other current liabilities |  | $ | 2 |  |  | $ | 1 |  |
| Foreign currency derivatives | Other assets |  | 10 |  |  | 15 |  |  | Other long-term liabilities |  | 2 |  |  | — |  |
| Interest rate derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | — |  |  | 11 |  |
| Total |  |  | 27 |  |  | 62 |  |  |  |  | 4 |  |  | 12 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 3 |  |  | 2 |  |  | Other current liabilities |  | 17 |  |  | 47 |  |
| Foreign currency derivatives | Other assets |  | 2 |  |  | — |  |  | Other long-term liabilities |  | 10 |  |  | 15 |  |
| Total |  |  | 5 |  |  | 2 |  |  |  |  | 27 |  |  | 62 |  |
| Total |  |  | $ | 32 |  |  | $ | 64 |  |  |  |  | $ | 31 |  |  | $ | 74 |  |

[0000858877-25-000111:notes:270]
The following amounts were recorded on the Consolidated Balance Sheets related to cumulative basis adjustments for our fair value hedges (in millions):

[0000858877-25-000111:notes:271]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | July 26,2025 |  | July 27,2024 |  | July 26,2025 |  | July 27,2024 |
| Short-term debt |  | $ | — |  |  | $ | (488) |  |  | $ | — |  |  | $ | 11 |  |

[0000858877-25-000111:notes:272]
The effect of derivative instruments designated as fair value hedges, recognized in interest and other income (loss), net is summarized as follows (in millions):

[0000858877-25-000111:notes:273]
|  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
|  |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Interest rate derivatives: |  |  |  |  |  |  |
| Hedged items |  | $ | (11) |  |  | $ | (30) |  |  | $ | 31 |  |
| Derivatives designated as hedging instruments |  | 11 |  |  | 30 |  |  | (31) |  |
| Total |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000858877-25-000111:notes:274]
The effect on the Consolidated Statements of Operations of derivative instruments not designated as hedges is summarized as follows (in millions):

[0000858877-25-000111:notes:275]
|  |  |  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | 102 |  |  | $ | (162) |  |  | $ | 1 |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | 56 |  |  | 91 |  |  | 58 |  |
| Equity derivatives |  | Other income (loss), net |  | — |  |  | 2 |  |  | 13 |  |
| Total |  |  |  | $ | 158 |  |  | $ | (69) |  |  | $ | 72 |  |

[0000858877-25-000111:notes:276]
The notional amounts of our outstanding derivatives are summarized as follows (in millions):

[0000858877-25-000111:notes:277]
|  | July 26, 2025 |  | July 27, 2024 |
| Foreign currency derivatives | $ | 8,978 |  |  | $ | 7,434 |  |
| Interest rate derivatives | — |  |  | 500 |  |
| Total return swaps—deferred compensation | 1,087 |  |  | 985 |  |
| Total | $ | 10,065 |  |  | $ | 8,919 |  |

[0000858877-25-000111:notes:278]
(b)Offsetting of Derivative Instruments

[0000858877-25-000111:notes:279]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty.

[0000858877-25-000111:notes:280]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash provided for collateral was not material as of either July 26, 2025 or July 27, 2024.

[0000858877-25-000111:notes:281]
(c)Foreign Currency Exchange Risk

[0000858877-25-000111:notes:282]
We conduct business globally in numerous currencies. Therefore, we are exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, we enter into foreign currency contracts. We do not enter into such contracts for speculative purposes.

[0000858877-25-000111:notes:283]
We may hedge forecasted foreign currency transactions related to certain revenues, operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The derivative instrument’s gain or loss is initially reported as a component of accumulated other comprehensive income (AOCI) and subsequently reclassified into earnings when the hedged exposure affects earnings.

[0000858877-25-000111:notes:284]
We enter into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, long-term customer financings and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of monetary assets and liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-25-000111:notes:285]
We hedge certain net investments in our foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on our net investment in those foreign subsidiaries. These derivative instruments generally have maturities of up to six months.

[0000858877-25-000111:notes:286]
(d)Interest Rate Risk

[0000858877-25-000111:notes:287]
We periodically enter into treasury lock agreements, designated as cash flow hedges, in order to hedge the impact of changes in the U.S. benchmark interest rate on future interest payments in anticipation of future debt offerings. Changes in the fair value of treasury lock agreements are recorded to AOCI and reclassified into earnings when the hedged exposure affects earnings.

[0000858877-25-000111:notes:288]
(e)Equity Price Risk 
We are exposed to variability in compensation charges related to certain deferred compensation obligations to employees and directors. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure and offset the related compensation expense.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-25-000111:notes:289]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-25-000111:notes:290]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments are directly with suppliers, and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-25-000111:notes:291]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-25-000111:notes:292]
|  | July 26, 2025 |  | July 27, 2024 |
| Less than 1 year | $ | 7,202 |  |  | $ | 3,952 |  |
| 1 to 3 years | 320 |  |  | 1,085 |  |
| 3 to 5 years | 77 |  |  | 121 |  |
| Total | $ | 7,599 |  |  | $ | 5,158 |  |

[0000858877-25-000111:notes:293]
The purchase commitments with contract manufacturers and suppliers as of July 26, 2025 has been reduced to give effect to the settlement of a legal dispute with a supplier over purchase obligations arising under certain long-term supply arrangements.  See Note 21.

[0000858877-25-000111:notes:294]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 26, 2025 and July 27, 2024, the liability for these purchase commitments was $206 million and $498 million, respectively, and was included in other current liabilities.

[0000858877-25-000111:notes:295]
(b)Other Commitments

[0000858877-25-000111:notes:296]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.3 billion and $0.2 billion as of July 26, 2025 and July 27, 2024, respectively.

[0000858877-25-000111:notes:297]
(c)Product Warranties

[0000858877-25-000111:notes:298]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-25-000111:notes:299]
|  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Balance at beginning of fiscal year | $ | 362 |  |  | $ | 329 |  |  | $ | 333 |  |
| Provisions for warranties issued | 403 |  |  | 425 |  |  | 386 |  |
| Adjustments for pre-existing warranties | 42 |  |  | 22 |  |  | 18 |  |
| Settlements | (408) |  |  | (414) |  |  | (408) |  |
| Balance at end of fiscal year | $ | 399 |  |  | $ | 362 |  |  | $ | 329 |  |

[0000858877-25-000111:notes:300]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-25-000111:notes:301]
(d)Financing and Other Guarantees

[0000858877-25-000111:notes:302]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-25-000111:notes:303]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $24.9 billion, $27.1 billion, and $32.1 billion in fiscal 2025, 2024, and 2023, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.2 billion as of July 26, 2025 and July 27, 2024, respectively.

[0000858877-25-000111:notes:304]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at July 26, 2025 and July 27, 2024, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-25-000111:notes:305]
|  | July 26, 2025 |  | July 27, 2024 |
| Maximum potential future payments | $ | 123 |  |  | $ | 127 |  |
| Deferred revenue | (13) |  |  | (13) |  |
| Total | $ | 110 |  |  | $ | 114 |  |

[0000858877-25-000111:notes:306]
(e)Indemnifications

[0000858877-25-000111:notes:307]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-25-000111:notes:308]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-25-000111:notes:309]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-25-000111:notes:310]
(f)Legal Proceedings

[0000858877-25-000111:notes:311]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-25-000111:notes:312]
The remaining asserted claims by Brazilian federal tax authorities are for calendar years 2004 through 2007, and the remaining asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total remaining asserted claims by Brazilian state and federal tax authorities aggregate to $141 million for the alleged evasion of import and other taxes, $816 million for interest, and $289 million for various penalties, all determined using an exchange rate as of July 26, 2025.

[0000858877-25-000111:notes:313]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-25-000111:notes:314]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. After two bench trials and various administrative actions and appeals, we have been found either to not have infringed any of the patents or the patents have been invalidated. Centripetal appealed one of the invalidity decisions and we are awaiting the decision following the Federal Circuit hearing on that appeal on February 6, 2025. Centripetal's appeal of the non-infringement judgment of the District Court is ongoing.

[0000858877-25-000111:notes:315]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringed three patents, one patent was invalidated, and the utility model was invalidated. The infringement action on the final patent is stayed due to an invalidity action heard on June 6, 2024 in the Federal Patent Court, in which all claims, aside from one auxiliary claim, were found invalid, and for which we are awaiting a decision on appeal from the German Federal Court of Justice. Centripetal’s appeals of two of the non-infringement findings remain pending and, on March 27, 2024, the Court of Appeals rejected Centripetal’s appeal of the third non-infringement finding. In an appellate decision on December 11, 2024, the German Federal Court of Justice revoked one of the two patents for which Centripetal appealed the finding of non-infringement, rendering moot the non-infringement appeal of that patent.

[0000858877-25-000111:notes:316]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement. We have filed our response and defenses to the complaint and the case briefing is ongoing. While the Court has not set a final hearing date, we anticipate that it will occur in the third calendar quarter of 2026.

[0000858877-25-000111:notes:317]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of the litigations at this time. If we do not prevail in these litigations, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-25-000111:notes:318]
Ramot     On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents and those proceedings are ongoing. The Court set trial in the D. Del. cases for November 3, 2025.

[0000858877-25-000111:notes:319]
While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-25-000111:notes:320]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023. The Federal Circuit heard oral argument on October 11, 2024 and on July 7, 2025, the Federal Circuit affirmed the final judgment of the District Court that was in Cisco's favor.

[0000858877-25-000111:notes:321]
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. 
For additional information regarding intellectual property litigation, see “Part I, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-25-000111:notes:322]
Stockholders’ Equity 
(a)Stock Repurchase Program

[0000858877-25-000111:notes:323]
In September 2001, our Board of Directors authorized a stock repurchase program. As of July 26, 2025, the remaining authorized amount for stock repurchases under this program was approximately $14.2 billion with no termination date.

[0000858877-25-000111:notes:324]
Our stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-25-000111:notes:325]
| Years Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| July 26, 2025 |  | 105 |  |  | $ | 56.53 |  |  | $ | 5,995 |  |
| July 27, 2024 |  | 117 |  |  | $ | 49.45 |  |  | $ | 5,764 |  |
| July 29, 2023 |  | 88 |  |  | $ | 48.49 |  |  | $ | 4,271 |  |

[0000858877-25-000111:notes:326]
There were $20 million, $25 million and $48 million in stock repurchases that were pending settlement as of July 26, 2025, July 27, 2024 and July 29, 2023, respectively.

[0000858877-25-000111:notes:327]
The purchase price for the shares of our stock repurchased is reflected as a reduction to stockholders’ equity.

[0000858877-25-000111:notes:328]
We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings or an increase to accumulated deficit and (ii) a reduction of common stock and additional paid-in capital.

[0000858877-25-000111:notes:329]
(b)Dividends Declared

[0000858877-25-000111:notes:330]
On August 13, 2025, our Board of Directors declared a quarterly dividend of $0.41 per common share to be paid on October 22, 2025, to all stockholders of record as of the close of business on October 3, 2025. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-25-000111:notes:331]
(c)Preferred Stock

[0000858877-25-000111:notes:332]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock in one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights, if any, of such series, and any qualifications, limitations or restrictions thereof, of the shares of such series. As of July 26, 2025, we have not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-25-000111:notes:333]
Employee Benefit Plans  
(a)Employee Stock Incentive Plans

[0000858877-25-000111:notes:334]
We have one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with us. The number and frequency of share-based awards are based on competitive practices, our operating results, government regulations, and other factors.

[0000858877-25-000111:notes:335]
The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions. Time-based and performance-based RSUs generally vest over three years with certain awards containing retirement eligible provisions. Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. The 2005 Plan may be terminated by our Board of Directors at any time and for any reason, and is currently set to terminate at the 2030 Annual Meeting unless re-adopted or extended by our stockholders prior to or on such date.

[0000858877-25-000111:notes:336]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of July 26, 2025, 100 million shares were authorized for future grant under the 2005 Plan.

[0000858877-25-000111:notes:337]
(b)Employee Stock Purchase Plan

[0000858877-25-000111:notes:338]
We have an Employee Stock Purchase Plan under which eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. We issued 18 million, 20 million, and 19 million shares under the Employee Stock Purchase Plan in fiscal 2025, 2024, and 2023, respectively. As of July 26, 2025, 50 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-25-000111:notes:339]
(c)Summary of Share-Based Compensation Expense

[0000858877-25-000111:notes:340]
Share-based compensation expense consists of expenses for RSUs, stock purchase rights, and stock options, granted to employees or assumed from acquisitions. The following table summarizes share-based compensation expense (in millions):

[0000858877-25-000111:notes:341]
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Cost of sales—product | $ | 255 |  |  | $ | 214 |  |  | $ | 151 |  |
| Cost of sales—services | 329 |  |  | 300 |  |  | 245 |  |
| Share-based compensation expense in cost of sales | 584 |  |  | 514 |  |  | 396 |  |
| Research and development | 1,625 |  |  | 1,316 |  |  | 1,008 |  |
| Sales and marketing | 918 |  |  | 846 |  |  | 673 |  |
| General and administrative | 476 |  |  | 375 |  |  | 270 |  |
| Restructuring and other charges | 38 |  |  | 23 |  |  | 6 |  |
| Share-based compensation expense in operating expenses | 3,057 |  |  | 2,560 |  |  | 1,957 |  |
| Total share-based compensation expense | $ | 3,641 |  |  | $ | 3,074 |  |  | $ | 2,353 |  |
| Income tax benefit for share-based compensation | $ | 871 |  |  | $ | 696 |  |  | $ | 449 |  |

[0000858877-25-000111:notes:342]
As of July 26, 2025, the total compensation cost related to unvested share-based awards not yet recognized was $4.5 billion, which is expected to be recognized over approximately 1.9 years on a weighted-average basis.

[0000858877-25-000111:notes:343]
(d)Restricted Stock Unit Awards

[0000858877-25-000111:notes:344]
A summary of the restricted stock and stock unit activity, which includes time-based and performance-based or market-based RSUs, is as follows (in millions, except per-share amounts):

[0000858877-25-000111:notes:345]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 30, 2022 | 97 |  |  | $ | 46.67 |  |  |  |
| Granted and assumed | 72 |  |  | 42.08 |  |  |  |
| Vested | (39) |  |  | 46.69 |  |  | $ | 1,746 |  |
| Canceled/forfeited/other | (8) |  |  | 45.17 |  |  |  |
| UNVESTED BALANCE AT JULY 29, 2023 | 122 |  |  | 44.04 |  |  |  |
| Granted and assumed | 63 |  |  | 48.97 |  |  |  |
| Vested | (58) |  |  | 43.46 |  |  | $ | 2,906 |  |
| Canceled/forfeited/other | (10) |  |  | 45.65 |  |  |  |
| UNVESTED BALANCE AT JULY 27, 2024 | 117 |  |  | 46.86 |  |  |  |
| Granted and assumed | 70 |  |  | 55.73 |  |  |  |
| Vested | (65) |  |  | 46.95 |  |  | $ | 3,707 |  |
| Canceled/forfeited/other | (9) |  |  | 48.04 |  |  |  |
| UNVESTED BALANCE AT JULY 26, 2025 | 113 |  |  | $ | 52.26 |  |  |  |

[0000858877-25-000111:notes:346]
(e)Valuation of Employee Share-Based Awards

[0000858877-25-000111:notes:347]
Time-based restricted stock units and PRSUs that are based on our financial performance metrics or non-financial operating goals are valued using the market value of our common stock on the date of grant, discounted for the present value of expected dividends. For PRSUs granted, we included a relative total shareholder return (TSR) modifier to determine the number of shares earned at the end of the performance period. The TSR modifier is determined using a Monte Carlo simulation model. The PRSUs granted during the fiscal years presented are contingent on the achievement of our financial performance metrics, our comparative market-based returns, or the achievement of financial and non-financial operating goals.

[0000858877-25-000111:notes:348]
The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-25-000111:notes:349]
|  | RESTRICTED STOCK UNITS |
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Number of shares granted (in millions) | 65 |  |  | 60 |  |  | 70 |  |
| Grant date fair value per share | $ | 55.93 |  |  | $ | 48.71 |  |  | $ | 42.13 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 2.7 | % |  | 3.0 | % |  | 3.4 | % |
| Range of risk-free interest rates | 3.5% – 4.9% |  | 4.2% – 5.6% |  | 3.7% – 5.7% |

[0000858877-25-000111:notes:350]
|  | PERFORMANCE BASED RESTRICTED STOCK UNITS |
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Number of shares granted (in millions) | 4 |  |  | 3 |  |  | 2 |  |
| Grant date fair value per share | $ | 54.50 |  |  | $ | 59.31 |  |  | $ | 40.44 |  |

[0000858877-25-000111:notes:351]
The assumptions for the valuation of employee stock purchase rights are summarized as follows:

[0000858877-25-000111:notes:352]
|  | EMPLOYEE STOCK PURCHASE RIGHTS |
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Weighted-average assumptions: |  |  |  |  |  |
| Expected volatility | 22.5 | % |  | 28.3 | % |  | 28.7 | % |
| Risk-free interest rate | 5.0 | % |  | 2.9 | % |  | 2.8 | % |
| Expected dividend | 3.3 | % |  | 3.5 | % |  | 3.6 | % |
| Expected life (in years) | 1.3 |  | 1.2 |  | 1.2 |
| Weighted-average estimated grant date fair value per share | $ | 12.18 |  |  | $ | 11.59 |  |  | $ | 12.40 |  |

[0000858877-25-000111:notes:353]
The valuation of employee stock purchase rights and the related assumptions are for the employee stock purchases made during the respective fiscal years.

[0000858877-25-000111:notes:354]
We used the implied volatility for traded options (with contract terms corresponding to the expected life of the employee stock purchase rights) on our stock as the expected volatility assumption required in the Black-Scholes model. The implied volatility is more representative of future stock price trends than historical volatility. The risk-free interest rate assumption is based upon observed interest rates appropriate for the term of our employee stock purchase rights. The dividend yield assumption is based on the history and expectation of dividend payouts at the grant date.

[0000858877-25-000111:notes:355]
(f)Employee 401(k) Plans

[0000858877-25-000111:notes:356]
We sponsor the Cisco Systems, Inc. 401(k) Plan (the “Plan”) to provide retirement benefits for our employees. As allowed under Section 401(k) of the Internal Revenue Code, the Plan provides for tax-deferred salary contributions and after-tax contributions for eligible employees. The Plan allows employees to contribute up to 75% of their annual eligible earnings to the Plan on a pretax and after-tax basis, including Roth contributions. Employee contributions are limited to a maximum annual amount as set periodically by the Internal Revenue Code. We match pretax and Roth employee contributions up to 100% of the first 4.5% of eligible earnings that are contributed by employees. Therefore, the maximum matching contribution that we may allocate to each participant’s account will not exceed $15,750 for the 2025 calendar year due to the $350,000 annual limit on eligible earnings imposed by the Internal Revenue Code. All matching contributions vest immediately. Our matching contributions to the Plan totaled $373 million, $358 million, and $342 million in fiscal 2025, 2024, and 2023, respectively.

[0000858877-25-000111:notes:357]
The Plan allows employees who meet the age requirements and reach the Plan contribution limits to make catch-up contributions (pretax or Roth) not to exceed the lesser of 75% of their annual eligible earnings or the limit set forth in the Internal Revenue Code. Catch-up contributions are not eligible for matching contributions. In addition, the Plan provides for discretionary profit-sharing contributions as determined by the Board of Directors. Such contributions to the Plan are allocated among eligible participants in the proportion of their salaries to the total salaries of all participants. There were no discretionary profit-sharing contributions made in fiscal 2025, 2024, and 2023.

[0000858877-25-000111:notes:358]
We also sponsor other 401(k) plans as a result of acquisitions of other companies. Our contributions to these plans were not material to Cisco on either an individual or aggregate basis for any of the fiscal years presented.

[0000858877-25-000111:notes:359]
(g)Deferred Compensation Plans
The Cisco Systems, Inc. Deferred Compensation Plan (the “Deferred Compensation Plan”), a nonqualified deferred compensation plan, became effective in 2007. As required by applicable law, participation in the Deferred Compensation Plan is limited to a select group of our management employees. Under the Deferred Compensation Plan, which is an unfunded and unsecured deferred compensation arrangement, a participant may elect to defer base salary, bonus, and/or commissions, pursuant to such rules as may be established by Cisco, up to the maximum percentages for each deferral election as described in the plan. We may also, at our discretion, make a matching contribution to the employee under the Deferred Compensation Plan. A matching contribution equal to 4.5% of eligible compensation in excess of the Internal Revenue Code limit for qualified plans for calendar year 2025 that is deferred by participants under the Deferred Compensation Plan (with a $1.5 million cap on eligible compensation) will be made to eligible participants’ accounts at the end of calendar year 2025. The total deferred compensation liability under the Deferred Compensation Plan, together with deferred compensation plans assumed from acquired companies, was approximately $1.2 billion and $1.1 billion as of July 26, 2025 and July 27, 2024, respectively, and was recorded primarily in other long-term liabilities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-25-000111:notes:360]
Accumulated Other Comprehensive Income (Loss)  
The components of AOCI, net of tax, and the other comprehensive income (loss) are summarized as follows (in millions):

[0000858877-25-000111:notes:361]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 30, 2022 | $ | (379) |  |  | $ | 44 |  |  | $ | (1,287) |  |  | $ | (1,622) |  |
| Other comprehensive income (loss) before reclassifications | (113) |  |  | 29 |  |  | 116 |  |  | 32 |  |
| (Gains) losses reclassified out of AOCI | 21 |  |  | (63) |  |  | (1) |  |  | (43) |  |
| Tax benefit (expense) | 31 |  |  | 8 |  |  | 19 |  |  | 58 |  |
| BALANCE AT JULY 29, 2023 | (440) |  |  | 18 |  |  | (1,153) |  |  | (1,575) |  |
| Other comprehensive income (loss) before reclassifications | 193 |  |  | 128 |  |  | (115) |  |  | 206 |  |
| (Gains) losses reclassified out of AOCI | 67 |  |  | (49) |  |  | (2) |  |  | 16 |  |
| Tax benefit (expense) | (61) |  |  | (18) |  |  | 2 |  |  | (77) |  |
| BALANCE AT JULY 27, 2024 | (241) |  |  | 79 |  |  | (1,268) |  |  | (1,430) |  |
| Other comprehensive income (loss) before reclassifications | 152 |  |  | 29 |  |  | 304 |  |  | 485 |  |
| (Gains) losses reclassified out of AOCI | 100 |  |  | (47) |  |  | — |  |  | 53 |  |
| Tax benefit (expense) | (68) |  |  | 4 |  |  | 2 |  |  | (62) |  |
| BALANCE AT JULY 26, 2025 | $ | (57) |  |  | $ | 65 |  |  | $ | (962) |  |  | $ | (954) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-25-000111:notes:362]
Income Taxes
(a)Provision for Income Taxes

[0000858877-25-000111:notes:363]
The provision for income taxes consists of the following (in millions):

[0000858877-25-000111:notes:364]
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Federal: |  |  |  |  |  |
| Current | $ | 956 |  |  | $ | 1,939 |  |  | $ | 3,754 |  |
| Deferred | (838) |  |  | (883) |  |  | (1,955) |  |
|  | 118 |  |  | 1,056 |  |  | 1,799 |  |
| State: |  |  |  |  |  |
| Current | 431 |  |  | 388 |  |  | 623 |  |
| Deferred | (250) |  |  | 11 |  |  | (175) |  |
|  | 181 |  |  | 399 |  |  | 448 |  |
| Foreign: |  |  |  |  |  |
| Current | 665 |  |  | 559 |  |  | 412 |  |
| Deferred | (44) |  |  | (100) |  |  | 46 |  |
|  | 621 |  |  | 459 |  |  | 458 |  |
| Total | $ | 920 |  |  | $ | 1,914 |  |  | $ | 2,705 |  |

[0000858877-25-000111:notes:365]
Income before provision for income taxes consists of the following (in millions):

[0000858877-25-000111:notes:366]
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| United States | $ | 9,500 |  |  | $ | 10,790 |  |  | $ | 14,074 |  |
| International | 1,600 |  |  | 1,444 |  |  | 1,244 |  |
| Total | $ | 11,100 |  |  | $ | 12,234 |  |  | $ | 15,318 |  |

[0000858877-25-000111:notes:367]
The items accounting for the difference between income taxes computed at the federal statutory rate and the provision for income taxes consist of the following:

[0000858877-25-000111:notes:368]
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Federal statutory rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 1.3 |  |  | 2.8 |  |  | 2.4 |  |
| Foreign income at other than U.S. rates | 0.7 |  |  | (0.3) |  |  | (0.1) |  |
| Tax credits | (2.7) |  |  | (2.4) |  |  | (0.3) |  |
| Foreign-derived intangible income deduction | (6.0) |  |  | (5.5) |  |  | (5.8) |  |
| Stock-based compensation | 0.7 |  |  | 0.7 |  |  | 1.1 |  |
| Impact of the Tax Act | (6.5) |  |  | — |  |  | — |  |
| Other, net | (0.2) |  |  | (0.7) |  |  | (0.6) |  |
| Total | 8.3 | % |  | 15.6 | % |  | 17.7 | % |

[0000858877-25-000111:notes:369]
On August 26, 2024, the U.S. Tax Court issued an opinion in Varian Medical Systems, Inc. v. Commissioner. The opinion related to the U.S. taxation of deemed foreign dividends in the transition year of the Tax Act (our fiscal 2018). While we were not a party to the case, the opinion resulted in a change to our tax position. As such, we recorded a tax benefit of $720 million as a reduction to the provision for income taxes in fiscal 2025 due to this U.S. Tax Court opinion.

[0000858877-25-000111:notes:370]
During fiscal 2023, we resolved certain items with the Internal Revenue Service (IRS) related to the audit of our federal income tax returns for the fiscal years ended July 26, 2014 through July 30, 2016. As a result of this resolution, we recognized a net benefit to the provision for income taxes of $145 million, which included a reduction of interest expense of $53 million. During fiscal 2024, we resolved all remaining items with the IRS related to the audit of our federal income tax returns for the fiscal years ended July 26, 2014 through July 30, 2016. As a result of this resolution, we recognized a net benefit to the provision for income taxes of $55 million, which included a reduction of interest expense of $18 million.

[0000858877-25-000111:notes:371]
During the fourth quarter of fiscal 2025, we changed our assertion regarding our intent to indefinitely reinvest $6.5 billion of undistributed earnings for certain foreign subsidiaries and determined that those earnings are no longer considered permanently reinvested. The deferred income tax impact of this change is not material.

[0000858877-25-000111:notes:372]
Unrecognized Tax Benefits

[0000858877-25-000111:notes:373]
The aggregate changes in the balance of gross unrecognized tax benefits were as follows (in millions):

[0000858877-25-000111:notes:374]
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Beginning balance | $ | 2,156 |  |  | $ | 2,137 |  |  | $ | 3,101 |  |
| Additions based on tax positions related to the current year | 283 |  |  | 205 |  |  | 159 |  |
| Additions for tax positions of prior years | 81 |  |  | 256 |  |  | 261 |  |
| Reductions for tax positions of prior years | (68) |  |  | (344) |  |  | (265) |  |
| Settlements | (75) |  |  | (53) |  |  | (1,063) |  |
| Lapse of statute of limitations | (40) |  |  | (45) |  |  | (56) |  |
| Ending balance | $ | 2,337 |  |  | $ | 2,156 |  |  | $ | 2,137 |  |

[0000858877-25-000111:notes:375]
As a result of the resolution of the IRS audit of our federal tax income tax returns for the fiscal years ended July 26, 2014 through July 30, 2016, the amount of gross unrecognized tax benefits was reduced by approximately $1.1 billion in fiscal 2023 and $245 million in fiscal 2024.

[0000858877-25-000111:notes:376]
As of July 26, 2025, $1.6 billion of the unrecognized tax benefits would affect the effective tax rate if realized. We recognized net interest expense of $77 million, $21 million and $27 million during fiscal 2025, 2024, and 2023, respectively. Our net penalty expense for fiscal 2025, 2024, and 2023 was not material. Our total accrual for interest and penalties was $497 million, $401 million, and $523 million as of the end of fiscal 2025, 2024, and 2023, respectively. We are no longer subject to U.S. federal income tax audit for returns covering tax years through fiscal 2016. We are no longer subject to foreign or state income tax audits for returns covering tax years through fiscal 2003 and fiscal 2008, respectively.

[0000858877-25-000111:notes:377]
We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters. We estimate that the unrecognized tax benefits at July 26, 2025 could be reduced by approximately $250 million in the next 12 months.

[0000858877-25-000111:notes:378]
(b)Deferred Tax Assets and Liabilities

[0000858877-25-000111:notes:379]
The following table presents the breakdown for net deferred tax assets (in millions):

[0000858877-25-000111:notes:380]
|  | July 26, 2025 |  | July 27, 2024 |
| Deferred tax assets | $ | 7,356 |  |  | $ | 6,262 |  |
| Deferred tax liabilities | (75) |  |  | (76) |  |
| Total net deferred tax assets | $ | 7,281 |  |  | $ | 6,186 |  |

[0000858877-25-000111:notes:381]
The following table presents the components of the deferred tax assets and liabilities (in millions):

[0000858877-25-000111:notes:382]
|  | July 26, 2025 |  | July 27, 2024 |
| ASSETS |  |  |  |
| Inventory write-downs and capitalization | $ | 532 |  |  | $ | 530 |  |
| Deferred foreign income | 221 |  |  | 277 |  |
| IPR&D and purchased intangible assets | 961 |  |  | 1,039 |  |
| Depreciation | 242 |  |  | 184 |  |
| Deferred revenue | 1,933 |  |  | 2,034 |  |
| Credits and net operating loss carryforwards | 1,350 |  |  | 1,863 |  |
| Share-based compensation expense | 319 |  |  | 297 |  |
| Accrued compensation | 175 |  |  | 275 |  |
| Lease liabilities | 379 |  |  | 308 |  |
| Capitalized research expenditures | 4,182 |  |  | 3,030 |  |
| Other | 678 |  |  | 559 |  |
| Gross deferred tax assets | 10,972 |  |  | 10,396 |  |
| Valuation allowance | (910) |  |  | (1,024) |  |
| Total deferred tax assets | 10,062 |  |  | 9,372 |  |
| LIABILITIES |  |  |  |
| Goodwill and purchased intangible assets | (2,288) |  |  | (2,808) |  |
| ROU lease assets | (315) |  |  | (259) |  |
| Other | (178) |  |  | (119) |  |
| Total deferred tax liabilities | (2,781) |  |  | (3,186) |  |
| Total net deferred tax assets | $ | 7,281 |  |  | $ | 6,186 |  |

[0000858877-25-000111:notes:383]
The changes in the valuation allowance for deferred tax assets are summarized as follows (in millions):

[0000858877-25-000111:notes:384]
|  |  | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Balance at beginning of fiscal year |  | $ | 1,024 |  |  | $ | 754 |  |  | $ | 834 |  |
| Additions |  | 33 |  |  | 148 |  |  | 35 |  |
| Additions from Splunk |  | — |  |  | 147 |  |  | — |  |
| Deductions |  | (4) |  |  | (4) |  |  | (18) |  |
| Write-offs |  | (145) |  |  | (20) |  |  | (93) |  |
| Foreign exchange and other |  | 2 |  |  | (1) |  |  | (4) |  |
| Balance at end of fiscal year |  | $ | 910 |  |  | $ | 1,024 |  |  | $ | 754 |  |

[0000858877-25-000111:notes:385]
As of July 26, 2025, our federal, state, and foreign net operating loss carryforwards before valuation allowance for income tax purposes were $284 million, $2.1 billion, and $533 million, respectively. A significant amount of the net operating loss carryforwards relates to acquisitions and, as a result, is limited in the amount that can be recognized in any one year. If not utilized, the federal, state, and foreign net operating loss carryforwards will begin to expire in fiscal 2026. We have provided a valuation allowance of $10 million and $96 million for deferred tax assets related to state and foreign net operating losses respectively that are not expected to be realized.
As of July 26, 2025, our federal, state, and foreign tax credit carryforwards for income tax purposes before valuation allowance were approximately $7 million, $1.8 billion, and $8 million, respectively. The federal tax credit carryforwards will begin to expire in fiscal 2027. The majority of state and foreign tax credits can be carried forward indefinitely. We have provided a valuation allowance of $752 million for deferred tax assets related to state and foreign tax credits carryforwards that are not expected to be realized.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-25-000111:notes:386]
Segment Information and Major Customers 
(a)Revenue and Gross Margin by Segment

[0000858877-25-000111:notes:387]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our chief executive officer is the chief operating decision maker (CODM). The CODM reviews certain financial information for each segment, to evaluate performance and allocate resources by comparing actual performance to our annual targets. Performance of each segment is measured based on segment revenue and segment gross margin.

[0000858877-25-000111:notes:388]
We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because the CODM does not include this information in our measurement of performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements (which includes the supplier-related legal settlement as described in Note 21) and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the cost of sales and gross margin for each segment because the CODM does not include this information in the measurement of the performance of our operating segments.

[0000858877-25-000111:notes:389]
The following summarizes our revenue and gross margin by segment and the significant expenses by each segment for fiscal 2025, 2024, and 2023 (in millions):

[0000858877-25-000111:notes:390]
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Revenue: |  |  |  |  |  |
| Americas | $ | 33,656 |  |  | $ | 31,971 |  |  | $ | 33,447 |  |
| EMEA | 14,824 |  |  | 14,117 |  |  | 15,135 |  |
| APJC | 8,174 |  |  | 7,716 |  |  | 8,417 |  |
| Total | $ | 56,654 |  |  | $ | 53,803 |  |  | $ | 56,998 |  |
| Gross margin: |  |  |  |  |  |
| Americas | $ | 22,962 |  |  | $ | 21,372 |  |  | $ | 21,350 |  |
| EMEA | 10,545 |  |  | 9,755 |  |  | 10,016 |  |
| APJC | 5,431 |  |  | 5,187 |  |  | 5,424 |  |
| Segment total | 38,938 |  |  | 36,312 |  |  | 36,788 |  |
| Unallocated corporate items | (2,148) |  |  | (1,484) |  |  | (1,035) |  |
| Total | $ | 36,790 |  |  | $ | 34,828 |  |  | $ | 35,753 |  |
| Supplemental information about our significant expenses: |  |  |  |  |  |
| Americas: |  |  |  |  |  |
| Cost of sales — product | $ | 8,206 |  |  | $ | 8,077 |  |  | $ | 9,479 |  |
| Cost of sales — services | 2,487 |  |  | 2,523 |  |  | 2,619 |  |
| Segment total | $ | 10,694 |  |  | $ | 10,600 |  |  | $ | 12,097 |  |
| EMEA: |  |  |  |  |  |
| Cost of sales — product | $ | 3,138 |  |  | $ | 3,264 |  |  | $ | 3,998 |  |
| Cost of sales — services | 1,140 |  |  | 1,098 |  |  | 1,121 |  |
| Segment total | $ | 4,279 |  |  | $ | 4,362 |  |  | $ | 5,119 |  |
| APJC: |  |  |  |  |  |
| Cost of sales — product | $ | 2,010 |  |  | $ | 1,838 |  |  | $ | 2,324 |  |
| Cost of sales — services | 734 |  |  | 690 |  |  | 668 |  |
| Segment total | $ | 2,743 |  |  | $ | 2,529 |  |  | $ | 2,992 |  |

[0000858877-25-000111:notes:391]
Revenue in the United States was $30.4 billion, $28.7 billion, and $29.9 billion for fiscal 2025, 2024, and 2023, respectively.

[0000858877-25-000111:notes:392]
(b)Revenue for Groups of Similar Products and Services

[0000858877-25-000111:notes:393]
We design and sell IP-based networking and other products related to the communications and IT industry and provide services associated with these products and their use.

[0000858877-25-000111:notes:394]
(c)Additional Segment Information

[0000858877-25-000111:notes:395]
No single customer accounted for 10% or more of revenue in fiscal 2025, 2024, and 2023.

[0000858877-25-000111:notes:396]
Our long-lived assets are based on the physical location of the assets. The following table presents our long-lived assets, which consists of property and equipment, net and operating lease ROU assets information for geographic areas (in millions):

[0000858877-25-000111:notes:397]
|  | July 26, 2025 |  | July 27, 2024 |
| Long-lived assets: |  |  |  |
| United States | $ | 2,370 |  |  | $ | 2,253 |  |
| International | 1,044 |  |  | 903 |  |
| Total | $ | 3,414 |  |  | $ | 3,156 |  |


## us-gaap:EarningsPerShareTextBlock

[0000858877-25-000111:notes:398]
Net Income per Share 
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-25-000111:notes:399]
| Years Ended | July 26, 2025 |  | July 27, 2024 |  | July 29, 2023 |
| Net income | $ | 10,180 |  |  | $ | 10,320 |  |  | $ | 12,613 |  |
| Weighted-average shares—basic | 3,976 |  |  | 4,043 |  |  | 4,093 |  |
| Effect of dilutive potential common shares | 22 |  |  | 19 |  |  | 12 |  |
| Weighted-average shares—diluted | 3,998 |  |  | 4,062 |  |  | 4,105 |  |
| Net income per share—basic | $ | 2.56 |  |  | $ | 2.55 |  |  | $ | 3.08 |  |
| Net income per share—diluted | $ | 2.55 |  |  | $ | 2.54 |  |  | $ | 3.07 |  |
| Antidilutive employee share-based awards, excluded | 78 |  |  | 82 |  |  | 86 |  |


## us-gaap:SubsequentEventsTextBlock

[0000858877-25-000111:notes:400]
Subsequent EventOn August 26, 2025, we settled a legal dispute with a supplier over purchase obligations arising under certain long-term supply arrangements entered into to help us mitigate significant supply chain constraints seen in prior periods. Under the terms of the settlement, the parties agreed to the dismissal of all pending actions in exchange for mutual releases of claims related to the long-term supply arrangements with the supplier, the termination of such arrangements between the parties, the release back to us of approximately $563 million held in escrow under the arrangements (which is reported as restricted cash within other current assets), and the forfeiture by us of approximately $450 million in supplier-held prepayments, after giving effect to certain amounts to be applied against such prepayments. No incremental cash consideration is to be paid in connection with the settlement. As a result of this settlement, we recorded a charge in the fourth quarter of fiscal 2025 of approximately $355 million to product cost of sales and a corresponding income tax benefit of approximately $82 million.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000858877-25-000111:notes:401]
On June 20, 2025, Oliver Tuszik, Cisco's Executive Vice President, Global Sales, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Mr. Tuszik’s trading plan provides for the sale of approximately 49,067 gross shares (with any shares underlying performance-based equity awards being calculated at target), plus any related dividend-equivalent shares earned with respect to such shares and shares from purchases made pursuant to Cisco’s employee stock purchase plan, and excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Mr. Tuszik’s trading plan is scheduled to terminate on December 31, 2025, subject to early termination for certain specified events set forth therein.
