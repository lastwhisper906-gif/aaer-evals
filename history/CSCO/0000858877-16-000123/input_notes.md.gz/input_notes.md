# CSCO notes — 0000858877-16-000123


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-16-000123:notes:1]
[same as prior period, unchanged from 0000858877-16-000109:notes:1]

[0000858877-16-000123:notes:2]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Compensation expense related to acquisitions | $ | 64 |  |  | $ | 73 |  |


## csco:EntityWideDisclosureOnGeographicAreasLongLivedAssetsTableTextBlock

[0000858877-16-000123:notes:3]
The following table presents property and equipment information for geographic areas (in millions):

[0000858877-16-000123:notes:4]
|  | October 29, 2016 |  | July 30, 2016 |
| Property and equipment, net: |  |  |  |
| United States | $ | 2,847 |  |  | $ | 2,822 |  |
| International | 652 |  |  | 684 |  |
| Total | $ | 3,499 |  |  | $ | 3,506 |  |


## csco:IncometaxprovisionTableTextBlock

[0000858877-16-000123:notes:5]
[same as prior period, unchanged from 0000858877-16-000109:notes:12]

[0000858877-16-000123:notes:6]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Income before provision for income taxes | $ | 2,953 |  |  | $ | 3,137 |  |
| Provision for income taxes | $ | 631 |  |  | $ | 707 |  |
| Effective tax rate | 21.4 | % |  | 22.5 | % |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-16-000123:notes:7]
[same as prior period, unchanged from 0000858877-16-000109:notes:14]

[0000858877-16-000123:notes:8]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Revenue: |  |  |  |
| Switching | $ | 3,716 |  |  | $ | 4,009 |  |
| NGN Routing | 2,089 |  |  | 1,969 |  |
| Collaboration | 1,081 |  |  | 1,115 |  |
| Data Center | 834 |  |  | 859 |  |
| Wireless | 632 |  |  | 646 |  |
| Security | 540 |  |  | 485 |  |
| Service Provider Video(1) | 271 |  |  | 687 |  |
| Other | 139 |  |  | 74 |  |
| Product | 9,302 |  |  | 9,844 |  |
| Service | 3,050 |  |  | 2,838 |  |
| Total | $ | 12,352 |  |  | $ | 12,682 |  |

[0000858877-16-000123:notes:9]
(1) During the second quarter of fiscal 2016, the Company completed the sale of the Customer Premises Equipment portion of its Service Provider Video Connected Devices business (“SP Video CPE Business”). As a result, revenue from this portion of the Service Provider Video product category will not recur in future periods. Includes SP Video CPE Business revenue of $411 million for the first quarter of fiscal 2016.


## csco:ScheduleOfCommonStockRepurchasedTextBlock

[0000858877-16-000123:notes:10]
[same as prior period, unchanged from 0000858877-16-000109:notes:17]

[0000858877-16-000123:notes:11]
|  | SharesRepurchased |  | Weighted-Average Priceper Share |  | AmountRepurchased |
| Cumulative balance at July 30, 2016 | 4,591 |  |  | $ | 21.04 |  |  | $ | 96,597 |  |
| Repurchase of common stock under the stock repurchase program (1) | 32 |  |  | 31.12 |  |  | 1,001 |  |
| Cumulative balance at October 29, 2016 | 4,623 |  |  | $ | 21.11 |  |  | $ | 97,598 |  |

[0000858877-16-000123:notes:12]
(1) There were $23 million of stock repurchases pending settlement as of October 29, 2016. There were $45 million of stock repurchases that were pending settlement as of July 30, 2016.


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-16-000123:notes:13]
[same as prior period, unchanged from 0000858877-16-000109:notes:20]

[0000858877-16-000123:notes:14]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE THREE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | October 29, 2016 |  | October 24, 2015 |  | October 29, 2016 |  | October 24, 2015 |
| Interest rate derivatives |  | Interest expense |  | $ | (91 | ) |  | $ | 127 |  |  | $ | 90 |  |  | $ | (125 | ) |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-16-000123:notes:15]
The following table presents the amortization of purchased intangible assets including impairment charges related to purchased intangible assets (in millions):

[0000858877-16-000123:notes:16]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Amortization of purchased intangible assets: |  |  |  |
| Cost of sales | $ | 129 |  |  | $ | 146 |  |
| Operating expenses |  |  |  |  |
| Amortization of purchased intangible assets | 78 |  |  | 69 |  |
| Restructuring and other charges | 38 |  |  | — |  |
| Total | $ | 245 |  |  | $ | 215 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-16-000123:notes:17]
The following table presents details of the Company’s intangible assets acquired through acquisitions completed during the three months ended October 29, 2016 (in millions, except years):

[0000858877-16-000123:notes:18]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| CloudLock | 6.0 |  | $ | 32 |  |  | 4.0 |  | $ | 3 |  |  | 1.5 |  | $ | 1 |  |  | $ | — |  |  | $ | 36 |  |
| Others (two in total) | 3.0 |  | 5 |  |  | 0.0 |  | — |  |  | 0.0 |  | — |  |  | — |  |  | 5 |  |
| Total |  |  | $ | 37 |  |  |  |  | $ | 3 |  |  |  |  | $ | 1 |  |  | $ | — |  |  | $ | 41 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-16-000123:notes:19]
[same as prior period, unchanged from 0000858877-16-000109:notes:28]

[0000858877-16-000123:notes:20]
| October 29, 2016 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 2,861 |  |  | $ | (1,334 | ) |  | $ | 1,527 |  |
| Customer relationships |  | 1,737 |  |  | (1,220 | ) |  | 517 |  |
| Other |  | 58 |  |  | (21 | ) |  | 37 |  |
| Total purchased intangible assets with finite lives |  | 4,656 |  |  | (2,575 | ) |  | 2,081 |  |
| In-process research and development, with indefinite lives |  | 216 |  |  | — |  |  | 216 |  |
| Total |  | $ | 4,872 |  |  | $ | (2,575 | ) |  | $ | 2,297 |  |

[0000858877-16-000123:notes:21]
| July 30, 2016 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,038 |  |  | $ | (1,391 | ) |  | $ | 1,647 |  |
| Customer relationships |  | 1,793 |  |  | (1,203 | ) |  | 590 |  |
| Other |  | 85 |  |  | (43 | ) |  | 42 |  |
| Total purchased intangible assets with finite lives |  | 4,916 |  |  | (2,637 | ) |  | 2,279 |  |
| In-process research and development, with indefinite lives |  | 222 |  |  | — |  |  | 222 |  |
| Total |  | $ | 5,138 |  |  | $ | (2,637 | ) |  | $ | 2,501 |  |


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-16-000123:notes:22]
Segment Information and Major Customers

[0000858877-16-000123:notes:23]
[same as prior period, unchanged from 0000858877-16-000109:notes:32]

[0000858877-16-000123:notes:24]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system. Sales are attributed to a segment based on the ordering location of the customer. The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments. In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-16-000123:notes:25]
Summarized financial information by segment for the three months ended October 29, 2016 and October 24, 2015, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker ("CODM"), is as follows (in millions):

[0000858877-16-000123:notes:26]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Revenue: |  |  |  |
| Americas | $ | 7,443 |  |  | $ | 7,792 |  |
| EMEA | 3,013 |  |  | 3,094 |  |
| APJC | 1,896 |  |  | 1,796 |  |
| Total | $ | 12,352 |  |  | $ | 12,682 |  |
| Gross margin: |  |  |  |
| Americas | $ | 4,833 |  |  | $ | 4,943 |  |
| EMEA | 2,013 |  |  | 1,989 |  |
| APJC | 1,204 |  |  | 1,078 |  |
| Segment total | 8,050 |  |  | 8,010 |  |
| Unallocated corporate items | (166 | ) |  | (178 | ) |
| Total | $ | 7,884 |  |  | $ | 7,832 |  |

[0000858877-16-000123:notes:27]
Revenue in the United States was $6.6 billion and $6.9 billion for the three months ended October 29, 2016 and October 24, 2015, respectively.

[0000858877-16-000123:notes:28]
[same as prior period, unchanged from 0000858877-16-000109:notes:37]

[0000858877-16-000123:notes:29]
The Company designs, manufactures, and sells Internet Protocol (IP)-based networking and other products related to the communications and IT industry and provides services associated with these products and their use. The Company groups its products and technologies into the following categories: Switching, NGN Routing, Collaboration, Data Center, Wireless, Security, Service Provider Video, and Other Products. These products, primarily integrated by Cisco IOS Software, link geographically dispersed local-area networks (LANs), metropolitan-area networks (MANs), and wide-area networks (WANs).

[0000858877-16-000123:notes:30]
[same as prior period, unchanged from 0000858877-16-000109:notes:39]

[0000858877-16-000123:notes:31]
[same as prior period, unchanged from 0000858877-16-000109:notes:40]

[0000858877-16-000123:notes:32]
The majority of the Company’s assets, excluding cash and cash equivalents and investments, was attributable to its U.S. operations as of each of October 29, 2016 and July 30, 2016.  The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $60.6 billion and $59.8 billion as of October 29, 2016 and July 30, 2016, respectively, and the remaining $10.4 billion and $5.9 billion at the respective period ends were available in the United States.

[0000858877-16-000123:notes:33]
Property and equipment information is based on the physical location of the assets. The following table presents property and equipment information for geographic areas (in millions):


## csco:StockRepurchasesSinceInceptionOfProgramTableTextBlock

[0000858877-16-000123:notes:34]
[same as prior period, unchanged from 0000858877-16-000109:notes:42]

[0000858877-16-000123:notes:35]
|  | Shares ofCommonStock |  | Common Stockand AdditionalPaid-In Capital |  | RetainedEarnings |  | Total CiscoShareholders’Equity |
| Repurchases of common stock under the repurchase program | 4,623 |  |  | $ | 24,180 |  |  | $ | 73,418 |  |  | $ | 97,598 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-16-000123:notes:36]
[same as prior period, unchanged from 0000858877-16-000109:notes:44]

[0000858877-16-000123:notes:37]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 30, 2016 | $ | 230 |  |  | $ | 97 |  |  | $ | 48 |  |  | $ | 375 |  |
| Provisions | (4 | ) |  | 12 |  |  | — |  |  | 8 |  |
| Foreign exchange and other | 1 |  |  | 2 |  |  | — |  |  | 3 |  |
| Allowance for credit loss as of October 29, 2016 | $ | 227 |  |  | $ | 111 |  |  | $ | 48 |  |  | $ | 386 |  |

[0000858877-16-000123:notes:38]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 25, 2015 | $ | 259 |  |  | $ | 87 |  |  | $ | 36 |  |  | $ | 382 |  |
| Provisions | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Recoveries (write-offs), net | (4 | ) |  | — |  |  | (3 | ) |  | (7 | ) |
| Foreign exchange and other | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Allowance for credit loss as of October 24, 2015 | $ | 255 |  |  | $ | 90 |  |  | $ | 33 |  |  | $ | 378 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000858877-16-000123:notes:39]
The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated. The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-16-000123:notes:40]
The accompanying financial data as of October 29, 2016 and for the three months ended October 29, 2016 and October 24, 2015 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 30, 2016 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 30, 2016.

[0000858877-16-000123:notes:41]
The Company consolidates its investments in a venture fund managed by SOFTBANK Corp. and its affiliates (“SOFTBANK”) as this is a variable interest entity and the Company is the primary beneficiary. The noncontrolling interests attributed to SOFTBANK are presented as a separate component from the Company’s equity in the equity section of the Consolidated Balance Sheets. SOFTBANK’s share of the earnings in the venture fund are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-16-000123:notes:42]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 29, 2016; the results of operations, the statements of comprehensive income, the statements of cash flows and equity for the three months ended October 29, 2016 and October 24, 2015 as applicable, have been made. The results of operations for the three months ended October 29, 2016 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-16-000123:notes:43]
Acquisitions and Divestitures

[0000858877-16-000123:notes:44]
The Company completed three acquisitions during the three months ended October 29, 2016. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-16-000123:notes:45]
|  | Purchase Consideration |  | Purchased Intangible Assets |  | Goodwill |
| CloudLock | $ | 249 |  |  | $ | 36 |  |  | $ | 213 |  |
| Others (two in total) | 9 |  |  | 5 |  |  | 4 |  |
| Total | $ | 258 |  |  | $ | 41 |  |  | $ | 217 |  |

[0000858877-16-000123:notes:46]
On August 1, 2016, the Company completed its acquisition of privately held CloudLock Inc. ("CloudLock"), a provider of cloud security that specializes in cloud access security broker technology that provides enterprises with visibility and analytics around user behavior and sensitive data in cloud services. Revenue from the CloudLock acquisition has been included in the Company's Security product category.

[0000858877-16-000123:notes:47]
The total purchase consideration related to the Company’s acquisitions completed during the three months ended October 29, 2016 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $1 million. Total transaction costs related to the Company’s acquisition activities were $1 million and $5 million for the three months ended October 29, 2016 and October 24, 2015, respectively. These transaction costs were expensed as incurred in general and administrative expenses ("G&A") in the Consolidated Statements of Operations.

[0000858877-16-000123:notes:48]
[same as prior period, unchanged from 0000858877-16-000109:notes:60]

[0000858877-16-000123:notes:49]
The goodwill generated from the Company’s acquisitions completed during the three months ended October 29, 2016 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-16-000123:notes:50]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations for the acquisitions completed during the three months ended October 29, 2016 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-16-000123:notes:51]
Commitments and Contingencies

[0000858877-16-000123:notes:52]
| (a) | Operating Leases |

[0000858877-16-000123:notes:53]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Australia, Belgium, Canada, China, Germany, India, Israel, Japan, the Netherlands and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of October 29, 2016 are as follows (in millions):

[0000858877-16-000123:notes:54]
| Fiscal Year | Amount |
| 2017 (remaining nine months) | $ | 280 |  |
| 2018 | 292 |  |
| 2019 | 178 |  |
| 2020 | 128 |  |
| 2021 | 76 |  |
| Thereafter | 162 |  |
| Total | $ | 1,116 |  |

[0000858877-16-000123:notes:55]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-16-000123:notes:56]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of October 29, 2016 and July 30, 2016, the Company had total purchase commitments for inventory of $3,920 million and $3,896 million, respectively.

[0000858877-16-000123:notes:57]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of October 29, 2016 and July 30, 2016, the liability for these purchase commitments was $161 million and $159 million, respectively, and was included in other current liabilities.

[0000858877-16-000123:notes:58]
| (c) | Other Commitments |

[0000858877-16-000123:notes:59]
In connection with the Company’s acquisitions, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-16-000123:notes:60]
As of October 29, 2016, the Company estimated that future cash compensation expense of up to $299 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.

[0000858877-16-000123:notes:61]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology. Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and has consolidated the results of Insieme in its Consolidated Financial Statements. In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

[0000858877-16-000123:notes:62]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $20 million and $51 million during the three months ended October 29, 2016 and October 24, 2015, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting will result in additional compensation expense in future periods. Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $834 million (which includes the $803 million that has been expensed to date), net of forfeitures. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $323 million and $291 million during the first quarters of fiscal 2017 and fiscal 2016, respectively.  As of October 29, 2016, the Company paid a total of approximately $712 million pursuant to these two milestone payments.

[0000858877-16-000123:notes:63]
| (d) | Product Warranties |

[0000858877-16-000123:notes:64]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-16-000123:notes:65]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Balance at beginning of period | $ | 414 |  |  | $ | 449 |  |
| Provisions for warranty issued | 176 |  |  | 160 |  |
| Adjustments for pre-existing warranties | — |  |  | (10 | ) |
| Settlements | (177 | ) |  | (166 | ) |
| Balance at end of period | $ | 413 |  |  | $ | 433 |  |

[0000858877-16-000123:notes:66]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-16-000123:notes:67]
| (e) | Financing and Other Guarantees |

[0000858877-16-000123:notes:68]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-16-000123:notes:69]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.9 billion for each of the three months ended October 29, 2016 and October 24, 2015. The balance of the channel partner financing subject to guarantees was $1.0 billion and $1.1 billion as of October 29, 2016 and July 30, 2016, respectively.

[0000858877-16-000123:notes:70]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $6 million and $23 million for the three months ended October 29, 2016 and October 24, 2015, respectively.

[0000858877-16-000123:notes:71]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 29, 2016 and July 30, 2016, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-16-000123:notes:72]
|  | October 29, 2016 |  | July 30, 2016 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 248 |  |  | $ | 281 |  |
| End user | 88 |  |  | 96 |  |
| Total | $ | 336 |  |  | $ | 377 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (77 | ) |  | $ | (85 | ) |
| End user | (70 | ) |  | (76 | ) |
| Total | $ | (147 | ) |  | $ | (161 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 189 |  |  | $ | 216 |  |

[0000858877-16-000123:notes:73]
Other Guarantees   The Company’s other guarantee arrangements as of October 29, 2016 and July 30, 2016 that were subject to recognition and disclosure requirements were not material.

[0000858877-16-000123:notes:74]
| (f) | Supplier Component Remediation Liability |

[0000858877-16-000123:notes:75]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components were widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products were beyond the Company's warranty terms, the Company has been proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014. During fiscal 2016 and 2015, adjustments to product cost of sales of $74 million and $164 million, respectively, were recorded to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products. The supplier component remediation liability as of October 29, 2016 and July 30, 2016 was $265 million and $276 million, respectively.

[0000858877-16-000123:notes:76]
| (g) | Indemnifications |

[0000858877-16-000123:notes:77]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-16-000123:notes:78]
The Company has been asked to provide indemnification in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. in Kansas and Delaware. Sprint alleges that the service provider customers infringe Sprint’s patents by offering VoIP telephone services utilizing products provided by the Company and other manufacturers. Sprint seeks monetary damages. Sprint’s Kansas cases were stayed pending resolution of Sprint’s appeal of the Delaware court’s judgment that certain Sprint patents were invalid. The Court of Appeals for the Federal Circuit overturned the Delaware court’s judgment on September 23, 2016. As a result, Sprint’s Kansas cases are set for trial on February 13 and March 6, 2017 against Time Warner Cable and Comcast respectively, and its Delaware case was reset for trial on November 6, 2017 against Cox Communications.

[0000858877-16-000123:notes:79]
The Company believes that the service providers have strong defenses and arguments that the Company's products do not infringe the patents and/or that Sprint's patents are invalid.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should Sprint prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products. At this time, the Company does not anticipate that the outcome of the matters would be material.

[0000858877-16-000123:notes:80]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-16-000123:notes:81]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-16-000123:notes:82]
| (h) | Legal Proceedings |

[0000858877-16-000123:notes:83]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-16-000123:notes:84]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $253 million for the alleged evasion of import and other taxes, $1.3 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of October 29, 2016. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

[0000858877-16-000123:notes:85]
Backflip Software     Backflip Software, Inc. brought claims against the Company as disclosed in the Company’s Form 10-K filed on September 8, 2016. Prior to the commencement of trial set for September 12, 2016, the parties executed a Settlement and Release Agreement resolving all aspects of the case and the Court dismissed the case in its entirety on October 17, 2016. The settlement did not have a material impact on the Company's results of operations.

[0000858877-16-000123:notes:86]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against the Company in the U.S. District Court for the District of Delaware, accusing Cisco products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. On May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million, and the Court will decide whether to award enhanced damages and attorneys’ fees and whether an ongoing royalty should be awarded through the expiration of the patents in 2018. In June 2016, the Company filed post-trial motions. The Company also intends to pursue an appeal to the United States Court of Appeals for the Federal Circuit on various grounds. The Company believes it has strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, the Company does not expect it to be material.

[0000858877-16-000123:notes:87]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, Cisco petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art. On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that Cisco would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. The PTAB held a hearing to review the Company's petition on November 15, 2016 and we are awaiting a decision. The district court issued an order on June 28, 2016 staying the district court case pending the final written decision from the PTAB. The Company believes it has strong arguments that the Company's products do not infringe and the patent is invalid. If the Company does not prevail and a jury were to find that the Company's AnyConnect products infringe, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding patent litigation processes, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

[0000858877-16-000123:notes:88]
Kangtega     Cisco Systems GmbH (“Cisco GmbH”) is subject to patent claims by Kangtega GmbH (“Kangtega”), instituted on June 6, 2013, alleging that Cisco GmbH infringes in Germany a European Patent by marketing in Germany network intrusion-detection (or firewall) products known as the “ASA” firewall offering. On April 29, 2014, the Mannheim Regional Court dismissed the infringement action, finding no infringement by Cisco GmbH of the asserted patent. On November 23, 2016, a court of appeal in Germany (Oberlandesgericht Karlsruhe) will hear an appeal of that judgment. The matter had been set for July 13, 2016, but that hearing was postponed until November 23, 2016. In addition, on July 25, 2016 the German Federal Patent Court issued its grounds for a decision denying Cisco’s nullity request with respect to the Kangtega patent. The nullity decision, which is open to appeal, regards patent validity and was issued in a separate proceeding from the infringement action in which Cisco has previously prevailed. In the infringement action, Kangtega seeks an injunction which would prohibit Cisco GmbH’s activities in Germany with respect to the ASA firewall offering unless Cisco GmbH takes a license from Kangtega or the Company redesigns the products.  The Company believes that the lower court ruling in Cisco's favor in the infringement action was correct and should be affirmed.  The Company does not anticipate that the outcome of the case would be material. However, due to uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the outcome of the appeal and any subsequent appeals to a higher court at this time.

[0000858877-16-000123:notes:89]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-16-000123:notes:90]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.

[0000858877-16-000123:notes:91]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-16-000123:notes:92]
Comprehensive Income

[0000858877-16-000123:notes:93]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, for the three months ended October 29, 2016 and October 24, 2015 are summarized as follows (in millions):

[0000858877-16-000123:notes:94]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains and Losses |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 30, 2016 | $ | 413 |  |  | $ | (59 | ) |  | $ | (680 | ) |  | $ | (326 | ) |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (210 | ) |  | (46 | ) |  | (26 | ) |  | (282 | ) |
| (Gains) losses reclassified out of AOCI | (15 | ) |  | 12 |  |  | — |  |  | (3 | ) |
| Tax benefit (expense) | 86 |  |  | 2 |  |  | (1 | ) |  | 87 |  |
| BALANCE AT OCTOBER 29, 2016 | $ | 274 |  |  | $ | (91 | ) |  | $ | (707 | ) |  | $ | (524 | ) |

[0000858877-16-000123:notes:95]
|  | Net Unrealized Gains on Available-for-Sale Investments |  | Net Unrealized Losses Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains and Losses |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 25, 2015 | $ | 310 |  |  | $ | (16 | ) |  | $ | (233 | ) |  | $ | 61 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (155 | ) |  | (4 | ) |  | (178 | ) |  | (337 | ) |
| (Gains) losses reclassified out of AOCI | 1 |  |  | 3 |  |  | 1 |  |  | 5 |  |
| Tax benefit (expense) | 56 |  |  | 2 |  |  | (39 | ) |  | 19 |  |
| BALANCE AT OCTOBER 24, 2015 | $ | 212 |  |  | $ | (15 | ) |  | $ | (449 | ) |  | $ | (252 | ) |

[0000858877-16-000123:notes:96]
[same as prior period, unchanged from 0000858877-16-000109:notes:110]

[0000858877-16-000123:notes:97]
|  |  | Three Months Ended |  |  |  |
|  |  | October 29, 2016 |  | October 24, 2015 |  |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  |  | Line Item in Statements of Operations |
| Net unrealized gains and losses on available-for-sale investments |  |  |  |  |  |  |  |
|  |  | $ | 15 |  |  | $ | (1 | ) |  |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | (9 | ) |  | (2 | ) |  |  | Operating expenses |
| Foreign currency derivatives |  | (3 | ) |  | (1 | ) |  |  | Cost of sales—service |
|  |  | (12 | ) |  | (3 | ) |  |  |  |
| Cumulative translation adjustment and actuarial gains and losses |  |  |  |  |  |  |  |
|  |  | — |  |  | (1 | ) |  |  | Operating expenses |
| Total amounts reclassified out of AOCI |  | $ | 3 |  |  | $ | (5 | ) |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-16-000123:notes:98]
Borrowings

[0000858877-16-000123:notes:99]
| (a) | Short-Term Debt |

[0000858877-16-000123:notes:100]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-16-000123:notes:101]
|  | October 29, 2016 |  | July 30, 2016 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,155 |  |  | 1.08 | % |  | $ | 4,159 |  |  | 0.97 | % |
| Other notes and borrowings | — |  |  | — |  |  | 1 |  |  | 2.08 | % |
| Total short-term debt | $ | 4,155 |  |  |  |  | $ | 4,160 |  |  |  |

[0000858877-16-000123:notes:102]
The effective interest rate on the current portion of long-term debt includes the impact of interest rate swaps, as discussed further in "

[0000858877-16-000123:notes:103]
| (b) | Long-Term Debt |

[0000858877-16-000123:notes:104]
." Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements. These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.

[0000858877-16-000123:notes:105]
The Company has established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company did not have any commercial paper notes outstanding as of each of October 29, 2016 and July 30, 2016.

[0000858877-16-000123:notes:106]
(b)

[0000858877-16-000123:notes:107]
Long-Term Debt

[0000858877-16-000123:notes:108]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-16-000123:notes:109]
|  |  |  | October 29, 2016 |  | July 30, 2016 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | $ | 1,000 |  |  | 1.18% |  | $ | 1,000 |  |  | 1.03% |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1.48% |  | 1,000 |  |  | 1.32% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.23% |  | 900 |  |  | 1.03% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.40% |  | 500 |  |  | 1.23% |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (1) | 500 |  |  | 1.24% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.93% |  | 2,400 |  |  | 0.87% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.42% |  | 750 |  |  | 1.22% |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.78% |  | 2,000 |  |  | 4.76% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.14% |  | 1,750 |  |  | 1.08% |
| 1.40% | September 20, 2019 | (1) | 1,500 |  |  | 1.48% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.29% |  | 2,500 |  |  | 3.25% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.31% |  | 500 |  |  | 1.24% |
| 1.85% | September 20, 2021 | (1) | 2,000 |  |  | 1.90% |  | — |  |  | — |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.56% |  | 500 |  |  | 1.51% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 | (1) | 750 |  |  | 2.27% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.42% |  | 1,000 |  |  | 1.36% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.72% |  | 500 |  |  | 1.67% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 | (1) | 1,500 |  |  | 2.55% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 34,650 |  |  |  |  | 28,400 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (150 | ) |  |  |  | (137 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 289 |  |  |  |  | 379 |  |  |  |
| Total |  |  | $ | 34,789 |  |  |  |  | $ | 28,642 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,155 |  |  |  |  | $ | 4,159 |  |  |  |
| Long-term debt |  |  | 30,634 |  |  |  |  | 24,483 |  |  |  |
| Total |  |  | $ | 34,789 |  |  |  |  | $ | 28,642 |  |  |  |

[0000858877-16-000123:notes:110]
(1) In September 2016, the Company issued senior notes for an aggregate principal amount of $6.25 billion.

[0000858877-16-000123:notes:111]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps in prior periods with an aggregate notional amount of $9.9 billion designated as fair value hedges of certain of its fixed-rate senior notes.  In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate ("LIBOR"). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.  For additional information, see Note 11.

[0000858877-16-000123:notes:112]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount, and, if applicable, adjustments related to hedging. Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

[0000858877-16-000123:notes:113]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 29, 2016, the Company was in compliance with all debt covenants.

[0000858877-16-000123:notes:114]
As of October 29, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-16-000123:notes:115]
| Fiscal Year | Amount |
| 2017 (remaining nine months) | $ | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| Thereafter | 11,500 |  |
| Total | $ | 34,650 |  |

[0000858877-16-000123:notes:116]
| (c) | Credit Facility |

[0000858877-16-000123:notes:117]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero.  The credit agreement requires the Company to comply with certain covenants, including that it maintains an interest coverage ratio as defined in the agreement.

[0000858877-16-000123:notes:118]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. As of October 29, 2016, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-16-000123:notes:119]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 10,424 |  |  | $ | 10,621 |  |
| Product: |  |  |  |  |
| Deferred revenue related to recurring software and subscription businesses |  | 3,801 |  |  | 3,308 |  |
| Deferred revenue related to two-tier distributors |  | 439 |  |  | 377 |  |
| Other product deferred revenue |  | 2,287 |  |  | 2,166 |  |
| Total product deferred revenue |  | 6,527 |  |  | 5,851 |  |
| Total |  | $ | 16,951 |  |  | $ | 16,472 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 10,215 |  |  | $ | 10,155 |  |
| Noncurrent |  | 6,736 |  |  | 6,317 |  |
| Total |  | $ | 16,951 |  |  | $ | 16,472 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-16-000123:notes:120]
Derivative Instruments

[0000858877-16-000123:notes:121]
[same as prior period, unchanged from 0000858877-16-000109:notes:136]

[0000858877-16-000123:notes:122]
[same as prior period, unchanged from 0000858877-16-000109:notes:137]

[0000858877-16-000123:notes:123]
[same as prior period, unchanged from 0000858877-16-000109:notes:138]

[0000858877-16-000123:notes:124]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | October 29, 2016 |  | July 30, 2016 |  | Balance Sheet Line Item |  | October 29, 2016 |  | July 30, 2016 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 5 |  |  | $ | 7 |  |  | Other current liabilities |  | $ | 83 |  |  | $ | 53 |  |
| Interest rate derivatives | Other current assets |  | 6 |  |  | 11 |  |  | Other current liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other assets |  | 280 |  |  | 366 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 291 |  |  | 384 |  |  |  |  | 83 |  |  | 53 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 1 |  |  | — |  |  | Other current liabilities |  | 2 |  |  | 1 |  |
| Equity derivatives/warrants | Other assets |  | — |  |  | 1 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 1 |  |  | 1 |  |  |  |  | 2 |  |  | 1 |  |
| Total |  |  | $ | 292 |  |  | $ | 385 |  |  |  |  | $ | 85 |  |  | $ | 54 |  |

[0000858877-16-000123:notes:125]
[same as prior period, unchanged from 0000858877-16-000109:notes:140]

[0000858877-16-000123:notes:126]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE THREE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THETHREE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | October 29, 2016 |  | October 24, 2015 |  | Line Item in Statements of Operations |  | October 29, 2016 |  | October 24, 2015 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (46 | ) |  | $ | (4 | ) |  | Operating expenses |  | $ | (9 | ) |  | $ | (2 | ) |
|  |  |  |  |  |  | Cost of sales—service |  | (3 | ) |  | (1 | ) |
| Total |  | $ | (46 | ) |  | $ | (4 | ) |  |  |  | $ | (12 | ) |  | $ | (3 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 9 |  |  | $ | — |  |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-16-000123:notes:127]
As of October 29, 2016, the Company estimates that approximately $78 million of net derivative losses related to its cash flow hedges included in accumulated other comprehensive income ("AOCI") will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-16-000123:notes:128]
[same as prior period, unchanged from 0000858877-16-000109:notes:144]

[0000858877-16-000123:notes:129]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | October 29, 2016 |  | October 24, 2015 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (16 | ) |  | $ | 4 |  |
| Total return swaps—deferred compensation |  | Operating expenses |  | (3 | ) |  | (16 | ) |
| Equity derivatives |  | Other income (loss), net |  | 1 |  |  | 10 |  |
| Total |  |  |  | $ | (18 | ) |  | $ | (2 | ) |

[0000858877-16-000123:notes:130]
[same as prior period, unchanged from 0000858877-16-000109:notes:146]

[0000858877-16-000123:notes:131]
|  | October 29, 2016 |  | July 30, 2016 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 2,385 |  |  | $ | 2,683 |  |
| Interest rate derivatives | 9,900 |  |  | 9,900 |  |
| Net investment hedging instruments | 290 |  |  | 298 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,107 |  |  | 2,057 |  |
| Total return swaps—deferred compensation | 497 |  |  | 476 |  |
| Total | $ | 15,179 |  |  | $ | 15,414 |  |

[0000858877-16-000123:notes:132]
[same as prior period, unchanged from 0000858877-16-000109:notes:148]

[0000858877-16-000123:notes:133]
[same as prior period, unchanged from 0000858877-16-000109:notes:149]

[0000858877-16-000123:notes:134]
|  | October 29, 2016 |
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEETS |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETSBUT WITH LEGAL RIGHTS TO OFFSET |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 292 |  |  | $ | — |  |  | $ | 292 |  |  | $ | (30 | ) |  | $ | (242 | ) |  | $ | 20 |  |
| Derivatives liabilities | $ | 85 |  |  | $ | — |  |  | $ | 85 |  |  | $ | (30 | ) |  | $ | — |  |  | $ | 55 |  |

[0000858877-16-000123:notes:135]
|  | July 30, 2016 |
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEETS |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETSBUT WITH LEGAL RIGHTS TO OFFSET |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 385 |  |  | $ | — |  |  | $ | 385 |  |  | $ | (23 | ) |  | $ | (305 | ) |  | $ | 57 |  |
| Derivatives liabilities | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |  | $ | (23 | ) |  | $ | — |  |  | $ | 31 |  |

[0000858877-16-000123:notes:136]
[same as prior period, unchanged from 0000858877-16-000109:notes:152]

[0000858877-16-000123:notes:137]
The Company conducts business globally in numerous currencies. Therefore, it is exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, the Company enters into foreign currency contracts. The Company does not enter into such contracts for speculative purposes.

[0000858877-16-000123:notes:138]
The Company hedges forecasted foreign currency transactions related to certain operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The Company assesses effectiveness based on changes in total fair value of the derivatives.  The effective portion of the derivative instrument’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion, if any, of the gain or loss is reported in earnings immediately. During the periods presented, the Company did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-16-000123:notes:139]
[same as prior period, unchanged from 0000858877-16-000109:notes:155]

[0000858877-16-000123:notes:140]
The Company hedges certain net investments in its foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on the Company’s net investment in those foreign subsidiaries.

[0000858877-16-000123:notes:141]
[same as prior period, unchanged from 0000858877-16-000109:notes:157]

[0000858877-16-000123:notes:142]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of October 29, 2016 and July 30, 2016, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-16-000123:notes:143]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt  In the three months ended October 29, 2016, the Company did not enter into any interest rate swaps. In prior fiscal years, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2017 through 2025. Under these interest rate swaps, the Company receives fixed-rate interest payments and makes interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps was reflected in other current assets and other assets.

[0000858877-16-000123:notes:144]
[same as prior period, unchanged from 0000858877-16-000109:notes:160]

[0000858877-16-000123:notes:145]
The Company may hold equity securities for strategic purposes or to diversify its overall investment portfolio. The publicly traded equity securities in the Company’s portfolio are subject to price risk. To manage its exposure to changes in the fair value of certain equity securities, the Company has periodically entered into equity derivatives that are designated as fair value hedges. The changes in the value of the hedging instruments are included in other income (loss), net, and offset the change in the fair value of the underlying hedged investment. In addition, the Company periodically enters into equity derivatives that are not designated as accounting hedges. The changes in the fair value of these derivatives are also included in other income (loss), net.

[0000858877-16-000123:notes:146]
[same as prior period, unchanged from 0000858877-16-000109:notes:162]

[0000858877-16-000123:notes:147]
[same as prior period, unchanged from 0000858877-16-000109:notes:163]

[0000858877-16-000123:notes:148]
[same as prior period, unchanged from 0000858877-16-000109:notes:164]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-16-000123:notes:149]
Employee Benefit Plans

[0000858877-16-000123:notes:150]
[same as prior period, unchanged from 0000858877-16-000109:notes:166]

[0000858877-16-000123:notes:151]
Stock Incentive Plan Program Description    As of October 29, 2016, the Company had three stock incentive plans: the 2005 Stock Incentive Plan (the “2005 Plan”); the Cisco Systems, Inc. SA Acquisition Long-Term Incentive Plan (the “SA Acquisition Plan”); and the Cisco Systems, Inc. WebEx Acquisition Long-Term Incentive Plan (the “WebEx Acquisition Plan”). In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company.  The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors. The Company’s primary stock incentive plans are summarized as follows:

[0000858877-16-000123:notes:152]
2005 Plan    As of October 29, 2016, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus shares from the 1996 Stock Incentive Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that are forfeited or are terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan. Starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-16-000123:notes:153]
[same as prior period, unchanged from 0000858877-16-000109:notes:169]

[0000858877-16-000123:notes:154]
[same as prior period, unchanged from 0000858877-16-000109:notes:170]

[0000858877-16-000123:notes:155]
[same as prior period, unchanged from 0000858877-16-000109:notes:171]

[0000858877-16-000123:notes:156]
[same as prior period, unchanged from 0000858877-16-000109:notes:172]

[0000858877-16-000123:notes:157]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 621 million shares of the Company’s common stock have been reserved for issuance as of October 29, 2016. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period.  The Purchase Plan is scheduled to terminate on January 3, 2020. No shares were issued under the Purchase Plan during each of the three months ended October 29, 2016 and October 24, 2015. As of October 29, 2016, 123 million shares were available for issuance under the Purchase Plan.

[0000858877-16-000123:notes:158]
[same as prior period, unchanged from 0000858877-16-000109:notes:174]

[0000858877-16-000123:notes:159]
Share-based compensation expense consists primarily of expenses for stock options, stock purchase rights, restricted stock, and RSUs granted to employees. The following table summarizes share-based compensation expense (in millions):

[0000858877-16-000123:notes:160]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Cost of sales—product | $ | 21 |  |  | $ | 13 |  |
| Cost of sales—service | 33 |  |  | 38 |  |
| Share-based compensation expense in cost of sales | 54 |  |  | 51 |  |
| Research and development | 126 |  |  | 114 |  |
| Sales and marketing | 140 |  |  | 139 |  |
| General and administrative | 49 |  |  | 57 |  |
| Restructuring and other charges | 3 |  |  | 15 |  |
| Share-based compensation expense in operating expenses | 318 |  |  | 325 |  |
| Total share-based compensation expense | $ | 372 |  |  | $ | 376 |  |
| Income tax benefit for share-based compensation | $ | 105 |  |  | $ | 95 |  |

[0000858877-16-000123:notes:161]
As of October 29, 2016, the total compensation cost related to unvested share-based awards not yet recognized was $2.7 billion, which is expected to be recognized over approximately 2.5 years on a weighted-average basis.

[0000858877-16-000123:notes:162]
[same as prior period, unchanged from 0000858877-16-000109:notes:178]

[0000858877-16-000123:notes:163]
[same as prior period, unchanged from 0000858877-16-000109:notes:179]

[0000858877-16-000123:notes:164]
|  | Share-Based Awards Available for Grant |
| BALANCE AT JULY 25, 2015 | 276 |  |
| Restricted stock, stock units, and other share-based awards granted | (96 | ) |
| Share-based awards canceled/forfeited/expired | 30 |  |
| Shares withheld for taxes and not issued | 30 |  |
| Other | 2 |  |
| BALANCE AT JULY 30, 2016 | 242 |  |
| Restricted stock, stock units, and other share-based awards granted | (16 | ) |
| Share-based awards canceled/forfeited/expired | 66 |  |
| Shares withheld for taxes and not issued | 19 |  |
| BALANCE AT OCTOBER 29, 2016 | 311 |  |

[0000858877-16-000123:notes:165]
[same as prior period, unchanged from 0000858877-16-000109:notes:181]

[0000858877-16-000123:notes:166]
[same as prior period, unchanged from 0000858877-16-000109:notes:182]

[0000858877-16-000123:notes:167]
A summary of the restricted stock and stock unit activity, which includes time-based and performance-based or market-based RSUs, is as follows (in millions, except per-share amounts):

[0000858877-16-000123:notes:168]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 25, 2015 | 143 |  |  | $ | 22.08 |  |  |  |
| Granted and assumed | 70 |  |  | 25.69 |  |  |  |
| Vested | (54 | ) |  | 20.68 |  |  | $ | 1,428 |  |
| Canceled/forfeited | (14 | ) |  | 22.86 |  |  |  |
| UNVESTED BALANCE AT JULY 30, 2016 | 145 |  |  | 24.26 |  |  |  |
| Granted and assumed | 11 |  |  | 28.85 |  |  |  |
| Vested | (36 | ) |  | 22.16 |  |  | $ | 1,120 |  |
| Canceled/forfeited | (7 | ) |  | 24.62 |  |  |  |
| UNVESTED BALANCE AT OCTOBER 29, 2016 | 113 |  |  | $ | 25.36 |  |  |  |

[0000858877-16-000123:notes:169]
[same as prior period, unchanged from 0000858877-16-000109:notes:185]

[0000858877-16-000123:notes:170]
[same as prior period, unchanged from 0000858877-16-000109:notes:186]

[0000858877-16-000123:notes:171]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 25, 2015 | 103 |  |  | $ | 28.68 |  |
| Assumed from acquisitions | 18 |  |  | 5.17 |  |
| Exercised | (32 | ) |  | 19.22 |  |
| Canceled/forfeited/expired | (16 | ) |  | 30.01 |  |
| BALANCE AT JULY 30, 2016 | 73 |  |  | 26.78 |  |
| Assumed from acquisitions | 1 |  |  | 1.59 |  |
| Exercised | (4 | ) |  | 19.92 |  |
| Canceled/forfeited/expired | (55 | ) |  | 32.02 |  |
| BALANCE AT OCTOBER 29, 2016 | 15 |  |  | $ | 9.10 |  |

[0000858877-16-000123:notes:172]
The following table summarizes significant ranges of outstanding and exercisable stock options as of October 29, 2016 (in millions, except years and share prices):

[0000858877-16-000123:notes:173]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 20.00 |  | 12 |  |  | 6.6 |  | $ | 5.60 |  |  | $ | 316 |  |  | 5 |  |  | $ | 5.35 |  |  | $ | 127 |  |
| $ 20.01 – 25.00 |  | 1 |  |  | 0.3 |  | 23.37 |  |  | 3 |  |  | 1 |  |  | 23.37 |  |  | 3 |  |
| $ 25.01 – 30.00 |  | 2 |  |  | 0.4 |  | 26.64 |  |  | 8 |  |  | 2 |  |  | 26.64 |  |  | 8 |  |
| Total |  | 15 |  |  | 5.6 |  | $ | 9.10 |  |  | $ | 327 |  |  | 8 |  |  | $ | 12.43 |  |  | $ | 138 |  |

[0000858877-16-000123:notes:174]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on the Company’s closing stock price of $30.59 as of October 28, 2016, that would have been received by the option holders had those option holders exercised their stock options as of that date. The total number of in-the-money stock options exercisable as of October 29, 2016 was 8 million. As of July 30, 2016, 64 million outstanding stock options were exercisable and the weighted-average exercise price was $29.66.

[0000858877-16-000123:notes:175]
[same as prior period, unchanged from 0000858877-16-000109:notes:191]

[0000858877-16-000123:notes:176]
Time-based restricted stock units and performance-based restricted stock units ("PRSUs") that are based on the Company’s financial performance metrics or non-financial operating goals are valued using the market value of the Company’s common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, the Company estimated the fair value of the total shareholder return ("TSR") component of the PRSUs using a Monte Carlo simulation model. The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-16-000123:notes:177]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE BASEDRESTRICTED STOCK UNITS |
| Three Months Ended | October 29, 2016 |  | October 24, 2015 |  | October 29, 2016 |  | October 24, 2015 |
| Number of shares granted (in millions) | 7 |  |  | 9 |  |  | 3 |  |  | 4 |  |
| Grant date fair value per share | $ | 28.55 |  |  | $ | 24.02 |  |  | $ | 29.62 |  |  | $ | 24.61 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.3 | % |  | 3.2 | % |  | 3.3 | % |  | 3.2 | % |
| Range of risk-free interest rates | 0.0% – 1.2% |  |  | 0.0% – 1.1% |  |  | 0.1% – 0.9% |  |  | 0.0% – 1.1% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 16.7% – 46.8% |  |  | 15.3% – 54.3% |  |

[0000858877-16-000123:notes:178]
[same as prior period, unchanged from 0000858877-16-000109:notes:195]


## us-gaap:EarningsPerSharePolicyTextBlock

[0000858877-16-000123:notes:179]
Employee equity share options, unvested shares, and similar equity instruments granted by the Company are treated as potential common shares outstanding in computing diluted earnings per share. Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options, the amount of compensation cost for future service that the Company has not yet recognized, and the amount of tax benefits that would be recorded in additional paid-in capital when the award becomes deductible are collectively assumed to be used to repurchase shares.


## us-gaap:EarningsPerShareTextBlock

[0000858877-16-000123:notes:180]
Net Income per Share

[0000858877-16-000123:notes:181]
[same as prior period, unchanged from 0000858877-16-000109:notes:197]

[0000858877-16-000123:notes:182]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Net income | $ | 2,322 |  |  | $ | 2,430 |  |
| Weighted-average shares—basic | 5,027 |  |  | 5,080 |  |
| Effect of dilutive potential common shares | 39 |  |  | 33 |  |
| Weighted-average shares—diluted | 5,066 |  |  | 5,113 |  |
| Net income per share—basic | $ | 0.46 |  |  | $ | 0.48 |  |
| Net income per share—diluted | $ | 0.46 |  |  | $ | 0.48 |  |
| Antidilutive employee share-based awards, excluded | 67 |  |  | 86 |  |


## us-gaap:EquityMethodInvestmentsTextBlock

[0000858877-16-000123:notes:183]
For such investments that were accounted for under the equity and cost method as of October 29, 2016 and July 30, 2016, the amounts are summarized in the following table (in millions):

[0000858877-16-000123:notes:184]
|  | October 29, 2016 |  | July 30, 2016 |
| Equity method investments | $ | 162 |  |  | $ | 174 |  |
| Cost method investments | 829 |  |  | 829 |  |
| Total | $ | 991 |  |  | $ | 1,003 |  |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-16-000123:notes:185]
The following table presents the Company’s assets that were measured at fair value on a nonrecurring basis during the indicated periods and the related recognized gains and losses for the periods indicated (in millions):

[0000858877-16-000123:notes:186]
|  | TOTAL GAINS (LOSSES) FOR THETHREE MONTHS ENDED |
|  | October 29, 2016 |  | October 24, 2015 |
| Investments in privately held companies (impaired) | $ | (47 | ) |  | $ | (17 | ) |
| Purchased intangible assets (impaired) | (42 | ) |  | — |  |
| Total gains (losses) for nonrecurring measurements | $ | (89 | ) |  | $ | (17 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-16-000123:notes:187]
Fair Value

[0000858877-16-000123:notes:188]
[same as prior period, unchanged from 0000858877-16-000109:notes:205]

[0000858877-16-000123:notes:189]
[same as prior period, unchanged from 0000858877-16-000109:notes:206]

[0000858877-16-000123:notes:190]
[same as prior period, unchanged from 0000858877-16-000109:notes:207]

[0000858877-16-000123:notes:191]
[same as prior period, unchanged from 0000858877-16-000109:notes:208]

[0000858877-16-000123:notes:192]
[same as prior period, unchanged from 0000858877-16-000109:notes:209]

[0000858877-16-000123:notes:193]
[same as prior period, unchanged from 0000858877-16-000109:notes:210]

[0000858877-16-000123:notes:194]
[same as prior period, unchanged from 0000858877-16-000109:notes:211]

[0000858877-16-000123:notes:195]
Assets and liabilities measured at fair value on a recurring basis as of October 29, 2016 and July 30, 2016 were as follows (in millions):

[0000858877-16-000123:notes:196]
|  | OCTOBER 29, 2016FAIR VALUE MEASUREMENTS |  | JULY 30, 2016FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 6,749 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,749 |  |  | $ | 6,049 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,049 |  |
| Corporate debt securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 25,896 |  |  | — |  |  | 25,896 |  |  | — |  |  | 26,544 |  |  | — |  |  | 26,544 |  |
| U.S. government agency securities | — |  |  | 2,622 |  |  | — |  |  | 2,622 |  |  | — |  |  | 2,817 |  |  | — |  |  | 2,817 |  |
| Non-U.S. government and agency securities | — |  |  | 1,104 |  |  | — |  |  | 1,104 |  |  | — |  |  | 1,100 |  |  | — |  |  | 1,100 |  |
| Corporate debt securities | — |  |  | 29,163 |  |  | — |  |  | 29,163 |  |  | — |  |  | 24,292 |  |  | — |  |  | 24,292 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,083 |  |  | — |  |  | 2,083 |  |  | — |  |  | 1,868 |  |  | — |  |  | 1,868 |  |
| Publicly traded equity securities | 1,517 |  |  | — |  |  | — |  |  | 1,517 |  |  | 1,504 |  |  | — |  |  | — |  |  | 1,504 |  |
| Derivative assets | — |  |  | 292 |  |  | — |  |  | 292 |  |  | — |  |  | 384 |  |  | 1 |  |  | 385 |  |
| Total | $ | 8,266 |  |  | $ | 61,160 |  |  | $ | — |  |  | $ | 69,426 |  |  | $ | 7,553 |  |  | $ | 57,048 |  |  | $ | 1 |  |  | $ | 64,602 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 85 |  |  | $ | — |  |  | $ | 85 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |
| Total | $ | — |  |  | $ | 85 |  |  | $ | — |  |  | $ | 85 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |

[0000858877-16-000123:notes:197]
[same as prior period, unchanged from 0000858877-16-000109:notes:214]

[0000858877-16-000123:notes:198]
[same as prior period, unchanged from 0000858877-16-000109:notes:215]

[0000858877-16-000123:notes:199]
[same as prior period, unchanged from 0000858877-16-000109:notes:216]

[0000858877-16-000123:notes:200]
[same as prior period, unchanged from 0000858877-16-000109:notes:217]

[0000858877-16-000123:notes:201]
The fair value measurement of the impaired investments was classified as Level 3 because significant unobservable inputs were used in the valuation due to the absence of quoted market prices and inherent lack of liquidity. Significant unobservable inputs, which included financial metrics of comparable private and public companies, financial condition and near-term prospects of the investees, recent financing activities of the investees, and the investees’ capital structure as well as other economic variables, reflected the assumptions market participants would use in pricing these assets. The impairment charges, representing the difference between the net book value and the fair value as a result of the evaluation, were recorded to other income (loss), net. The remaining carrying value of the investments that were impaired was $46 million and $6 million as of October 29, 2016 and October 24, 2015, respectively.

[0000858877-16-000123:notes:202]
The fair value for purchased intangible assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation.  Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable. See Note 4. The remaining carrying value of the specific purchased intangible assets that were impaired was $11 million and zero as of October 29, 2016 and October 24, 2015.

[0000858877-16-000123:notes:203]
(d)  Other Fair Value Disclosures

[0000858877-16-000123:notes:204]
The carrying value of the Company’s investments in privately held companies that were accounted for under the cost method was $829 million as of each of October 29, 2016 and July 30, 2016. It was not practicable to estimate the fair value of this portfolio.

[0000858877-16-000123:notes:205]
The fair value of the Company’s short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of the Company’s long-term loan receivables and financed service contracts and other as of October 29, 2016 and July 30, 2016 was $3.3 billion and $2.6 billion, respectively. The estimated fair value of the Company’s long-term loan receivables and financed service contracts and other approximates their carrying value. The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-16-000123:notes:206]
As of October 29, 2016, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.  As of October 29, 2016, the fair value of the Company’s senior notes and other long-term debt was $36.5 billion with a carrying amount of $34.8 billion. This compares to a fair value of $30.9 billion and a carrying amount of $28.6 billion as of July 30, 2016. The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-16-000123:notes:207]
Gross receivables, excluding residual value, less unearned income categorized by the Company’s internal credit risk rating as of October 29, 2016 and July 30, 2016 are summarized as follows (in millions):

[0000858877-16-000123:notes:208]
|  | INTERNAL CREDIT RISK RATING |
| October 29, 2016 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,652 |  |  | $ | 1,293 |  |  | $ | 94 |  |  | $ | 3,039 |  |
| Loan receivables | 1,081 |  |  | 976 |  |  | 179 |  |  | 2,236 |  |
| Financed service contracts and other | 2,898 |  |  | 1,313 |  |  | 28 |  |  | 4,239 |  |
| Total | $ | 5,631 |  |  | $ | 3,582 |  |  | $ | 301 |  |  | $ | 9,514 |  |

[0000858877-16-000123:notes:209]
|  | INTERNAL CREDIT RISK RATING |
| July 30, 2016 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,703 |  |  | $ | 1,294 |  |  | $ | 101 |  |  | $ | 3,098 |  |
| Loan receivables | 986 |  |  | 967 |  |  | 182 |  |  | 2,135 |  |
| Financed service contracts and other | 2,077 |  |  | 1,271 |  |  | 22 |  |  | 3,370 |  |
| Total | $ | 4,766 |  |  | $ | 3,532 |  |  | $ | 305 |  |  | $ | 8,603 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-16-000123:notes:210]
Financing Receivables and Operating Leases

[0000858877-16-000123:notes:211]
[same as prior period, unchanged from 0000858877-16-000109:notes:229]

[0000858877-16-000123:notes:212]
Financing receivables primarily consist of lease receivables, loan receivables, and financed service contracts and other. Lease receivables represent sales-type and direct-financing leases resulting from the sale of the Company’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Loan receivables represent financing arrangements related to the sale of the Company’s products and services, which may include additional funding for other costs associated with network installation and integration of the Company’s products and services. Lease receivables consist of arrangements with terms of four years on average, while loan receivables generally have terms of up to three years. The financed service contracts and other category includes financing receivables related to technical support and advanced services, software, and receivables related to financing of certain indirect costs associated with leases. Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one to three years.

[0000858877-16-000123:notes:213]
[same as prior period, unchanged from 0000858877-16-000109:notes:231]

[0000858877-16-000123:notes:214]
| October 29, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Gross | $ | 3,202 |  |  | $ | 2,236 |  |  | $ | 4,239 |  |  | $ | 9,677 |  |
| Residual value | 197 |  |  | — |  |  | — |  |  | 197 |  |
| Unearned income | (163 | ) |  | — |  |  | — |  |  | (163 | ) |
| Allowance for credit loss | (227 | ) |  | (111 | ) |  | (48 | ) |  | (386 | ) |
| Total, net | $ | 3,009 |  |  | $ | 2,125 |  |  | $ | 4,191 |  |  | $ | 9,325 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,504 |  |  | $ | 1,021 |  |  | $ | 2,016 |  |  | $ | 4,541 |  |
| Noncurrent | 1,505 |  |  | 1,104 |  |  | 2,175 |  |  | 4,784 |  |
| Total, net | $ | 3,009 |  |  | $ | 2,125 |  |  | $ | 4,191 |  |  | $ | 9,325 |  |

[0000858877-16-000123:notes:215]
| July 30, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Gross | $ | 3,272 |  |  | $ | 2,135 |  |  | $ | 3,370 |  |  | $ | 8,777 |  |
| Residual value | 202 |  |  | — |  |  | — |  |  | 202 |  |
| Unearned income | (174 | ) |  | — |  |  | — |  |  | (174 | ) |
| Allowance for credit loss | (230 | ) |  | (97 | ) |  | (48 | ) |  | (375 | ) |
| Total, net | $ | 3,070 |  |  | $ | 2,038 |  |  | $ | 3,322 |  |  | $ | 8,430 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,490 |  |  | $ | 988 |  |  | $ | 1,794 |  |  | $ | 4,272 |  |
| Noncurrent | 1,580 |  |  | 1,050 |  |  | 1,528 |  |  | 4,158 |  |
| Total, net | $ | 3,070 |  |  | $ | 2,038 |  |  | $ | 3,322 |  |  | $ | 8,430 |  |

[0000858877-16-000123:notes:216]
As of October 29, 2016 and July 30, 2016, the deferred service revenue related to "Financed Service Contracts and Other" was $2,371 million and $1,716 million, respectively.

[0000858877-16-000123:notes:217]
Future minimum lease payments to the Company on lease receivables as of October 29, 2016 are summarized as follows (in millions):

[0000858877-16-000123:notes:218]
| Fiscal Year | Amount |
| 2017 (remaining nine months) | $ | 1,222 |  |
| 2018 | 1,066 |  |
| 2019 | 587 |  |
| 2020 | 260 |  |
| 2021 | 65 |  |
| Thereafter | 2 |  |
| Total | $ | 3,202 |  |

[0000858877-16-000123:notes:219]
[same as prior period, unchanged from 0000858877-16-000109:notes:237]

[0000858877-16-000123:notes:220]
[same as prior period, unchanged from 0000858877-16-000109:notes:238]

[0000858877-16-000123:notes:221]
[same as prior period, unchanged from 0000858877-16-000109:notes:239]

[0000858877-16-000123:notes:222]
[same as prior period, unchanged from 0000858877-16-000109:notes:240]

[0000858877-16-000123:notes:223]
In circumstances when collectibility is not deemed reasonably assured, the associated revenue is deferred in accordance with the Company’s revenue recognition policies, and the related allowance for credit loss, if any, is included in deferred revenue. The Company also records deferred revenue associated with financing receivables when there are remaining performance obligations, as it does for financed service contracts. Total allowances for credit loss and deferred revenue as of October 29, 2016 and July 30, 2016 were $2,779 million and $2,112 million, respectively, and they were associated with total financing receivables before allowance for credit loss of $9,711 million and $8,805 million as of their respective period ends.

[0000858877-16-000123:notes:224]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of October 29, 2016 and July 30, 2016 (in millions):

[0000858877-16-000123:notes:225]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| October 29, 2016 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 86 |  |  | $ | 70 |  |  | $ | 249 |  |  | $ | 405 |  |  | $ | 2,634 |  |  | $ | 3,039 |  |  | $ | 55 |  |  | $ | 55 |  |
| Loan receivables | 25 |  |  | 23 |  |  | 95 |  |  | 143 |  |  | 2,093 |  |  | 2,236 |  |  | 42 |  |  | 42 |  |
| Financed service contracts and other | 317 |  |  | 338 |  |  | 367 |  |  | 1,022 |  |  | 3,217 |  |  | 4,239 |  |  | 29 |  |  | 9 |  |
| Total | $ | 428 |  |  | $ | 431 |  |  | $ | 711 |  |  | $ | 1,570 |  |  | $ | 7,944 |  |  | $ | 9,514 |  |  | $ | 126 |  |  | $ | 106 |  |

[0000858877-16-000123:notes:226]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 30, 2016 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 111 |  |  | $ | 25 |  |  | $ | 251 |  |  | $ | 387 |  |  | $ | 2,711 |  |  | $ | 3,098 |  |  | $ | 60 |  |  | $ | 60 |  |
| Loan receivables | 30 |  |  | 9 |  |  | 37 |  |  | 76 |  |  | 2,059 |  |  | 2,135 |  |  | 42 |  |  | 42 |  |
| Financed service contracts and other | 213 |  |  | 152 |  |  | 565 |  |  | 930 |  |  | 2,440 |  |  | 3,370 |  |  | 30 |  |  | 10 |  |
| Total | $ | 354 |  |  | $ | 186 |  |  | $ | 853 |  |  | $ | 1,393 |  |  | $ | 7,210 |  |  | $ | 8,603 |  |  | $ | 132 |  |  | $ | 112 |  |

[0000858877-16-000123:notes:227]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms.  The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract.  The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $436 million and $670 million as of October 29, 2016 and July 30, 2016, respectively.

[0000858877-16-000123:notes:228]
As of October 29, 2016, the Company had financing receivables of $236 million, net of unbilled or current receivables, that were in the category of 91 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $144 million as of July 30, 2016.

[0000858877-16-000123:notes:229]
[same as prior period, unchanged from 0000858877-16-000109:notes:247]

[0000858877-16-000123:notes:230]
[same as prior period, unchanged from 0000858877-16-000109:notes:248]

[0000858877-16-000123:notes:231]
Typically, the Company also considers receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. These balances, as of October 29, 2016 and July 30, 2016, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-16-000123:notes:232]
[same as prior period, unchanged from 0000858877-16-000109:notes:250]

[0000858877-16-000123:notes:233]
[same as prior period, unchanged from 0000858877-16-000109:notes:251]

[0000858877-16-000123:notes:234]
[same as prior period, unchanged from 0000858877-16-000109:notes:252]

[0000858877-16-000123:notes:235]
|  | October 29, 2016 |  | July 30, 2016 |
| Operating lease assets | $ | 301 |  |  | $ | 296 |  |
| Accumulated depreciation | (168 | ) |  | (161 | ) |
| Operating lease assets, net | $ | 133 |  |  | $ | 135 |  |

[0000858877-16-000123:notes:236]
Minimum future rentals on noncancelable operating leases as of October 29, 2016 are summarized as follows (in millions):

[0000858877-16-000123:notes:237]
| Fiscal Year | Amount |
| 2017 (remaining nine months) | $ | 179 |  |
| 2018 | 142 |  |
| 2019 | 53 |  |
| 2020 | 8 |  |
| 2021 | 4 |  |
| Thereafter | 1 |  |
| Total | $ | 387 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-16-000123:notes:238]
Goodwill and Purchased Intangible Assets

[0000858877-16-000123:notes:239]
[same as prior period, unchanged from 0000858877-16-000109:notes:257]

[0000858877-16-000123:notes:240]
The following table presents the goodwill allocated to the Company’s reportable segments as of and during the three months ended October 29, 2016 (in millions):

[0000858877-16-000123:notes:241]
|  | Balance at |  |  |  |  |  | Balance at |
|  | July 30, 2016 |  | Acquisitions |  | Other |  | October 29, 2016 |
| Americas | $ | 16,529 |  |  | $ | 132 |  |  | $ | (13 | ) |  | $ | 16,648 |  |
| EMEA | 6,269 |  |  | 62 |  |  | (4 | ) |  | 6,327 |  |
| APJC | 3,827 |  |  | 23 |  |  | (2 | ) |  | 3,848 |  |
| Total | $ | 26,625 |  |  | $ | 217 |  |  | $ | (19 | ) |  | $ | 26,823 |  |

[0000858877-16-000123:notes:242]
[same as prior period, unchanged from 0000858877-16-000109:notes:260]

[0000858877-16-000123:notes:243]
[same as prior period, unchanged from 0000858877-16-000109:notes:261]

[0000858877-16-000123:notes:244]
Purchased intangible assets include intangible assets acquired through acquisitions as well as through direct purchases or licenses.

[0000858877-16-000123:notes:245]
Impairment charges related to purchased intangible assets for the three months ended October 29, 2016 were $42 million. Impairment charges were primarily as a result of declines in estimated fair values of certain purchased intangible assets resulting from the reduction or elimination of expected future cash flows associated with certain of the Company’s technology and IPR&D intangible assets. Of these impairment charges, $38 million was recorded to restructuring and other charges upon the Company's decision to exit certain product lines, and the corresponding elimination of future associated cash flows. There were no impairment charges related to purchased intangible assets for the corresponding period in fiscal 2016.

[0000858877-16-000123:notes:246]
The estimated future amortization expense of purchased intangible assets with finite lives as of October 29, 2016 is as follows (in millions):

[0000858877-16-000123:notes:247]
| Fiscal Year | Amount |
| 2017 (remaining nine months) | $ | 524 |  |
| 2018 | 579 |  |
| 2019 | 493 |  |
| 2020 | 281 |  |
| 2021 | 137 |  |
| Thereafter | 67 |  |
| Total | $ | 2,081 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-16-000123:notes:248]
Income Taxes

[0000858877-16-000123:notes:249]
As of October 29, 2016, the Company had $1.7 billion of unrecognized tax benefit, of which $1.3 billion, if recognized, would favorably impact the effective tax rate. The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. The Company believes it is reasonably possible that certain federal, foreign and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.  The Company estimates that the unrecognized tax benefits at October 29, 2016 could be reduced by approximately $150 million in the next 12 months.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-16-000123:notes:250]
The following table summarizes the maturities of the Company’s fixed income securities as of October 29, 2016 (in millions):

[0000858877-16-000123:notes:251]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 12,967 |  |  | $ | 12,977 |  |
| Due in 1 to 2 years | 17,042 |  |  | 17,071 |  |
| Due in 2 to 5 years | 25,125 |  |  | 25,230 |  |
| Due after 5 years | 3,540 |  |  | 3,507 |  |
| Mortgage-backed securities with no single maturity | 2,069 |  |  | 2,083 |  |
| Total | $ | 60,743 |  |  | $ | 60,868 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-16-000123:notes:252]
Investments

[0000858877-16-000123:notes:253]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-16-000123:notes:254]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-16-000123:notes:255]
| October 29, 2016 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 25,905 |  |  | $ | 24 |  |  | $ | (33 | ) |  | $ | 25,896 |  |
| U.S. government agency securities | 2,619 |  |  | 4 |  |  | (1 | ) |  | 2,622 |  |
| Non-U.S. government and agency securities | 1,104 |  |  | 1 |  |  | (1 | ) |  | 1,104 |  |
| Corporate debt securities | 29,046 |  |  | 177 |  |  | (60 | ) |  | 29,163 |  |
| U.S. agency mortgage-backed securities | 2,069 |  |  | 16 |  |  | (2 | ) |  | 2,083 |  |
| Total fixed income securities | 60,743 |  |  | 222 |  |  | (97 | ) |  | 60,868 |  |
| Publicly traded equity securities | 1,225 |  |  | 346 |  |  | (54 | ) |  | 1,517 |  |
| Total (1) | $ | 61,968 |  |  | $ | 568 |  |  | $ | (151 | ) |  | $ | 62,385 |  |

[0000858877-16-000123:notes:256]
| July 30, 2016 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 26,473 |  |  | $ | 73 |  |  | $ | (2 | ) |  | $ | 26,544 |  |
| U.S. government agency securities | 2,809 |  |  | 8 |  |  | — |  |  | 2,817 |  |
| Non-U.S. government and agency securities | 1,096 |  |  | 4 |  |  | — |  |  | 1,100 |  |
| Corporate debt securities | 24,044 |  |  | 263 |  |  | (15 | ) |  | 24,292 |  |
| U.S. agency mortgage-backed securities | 1,846 |  |  | 22 |  |  | — |  |  | 1,868 |  |
| Total fixed income securities | 56,268 |  |  | 370 |  |  | (17 | ) |  | 56,621 |  |
| Publicly traded equity securities | 1,211 |  |  | 333 |  |  | (40 | ) |  | 1,504 |  |
| Total (1) | $ | 57,479 |  |  | $ | 703 |  |  | $ | (57 | ) |  | $ | 58,125 |  |

[0000858877-16-000123:notes:257]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases were $328 million and $654 million as of October 29, 2016 and July 30, 2016, respectively.

[0000858877-16-000123:notes:258]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-16-000123:notes:259]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-16-000123:notes:260]
The following table presents the gross realized gains and gross realized losses related to the Company’s available-for-sale investments (in millions):

[0000858877-16-000123:notes:261]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Gross realized gains | $ | 30 |  |  | $ | 35 |  |
| Gross realized losses | (15 | ) |  | (36 | ) |
| Total | $ | 15 |  |  | $ | (1 | ) |

[0000858877-16-000123:notes:262]
The following table presents the realized net gains (losses) related to the Company’s available-for-sale investments by security type (in millions):

[0000858877-16-000123:notes:263]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Net gains/(losses) on investments in publicly traded equity securities | $ | 5 |  |  | $ | (9 | ) |
| Net gains/(losses) on investments in fixed income securities | 10 |  |  | 8 |  |
| Total | $ | 15 |  |  | $ | (1 | ) |

[0000858877-16-000123:notes:264]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at October 29, 2016 and July 30, 2016 (in millions):

[0000858877-16-000123:notes:265]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 29, 2016 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 11,766 |  |  | $ | (33 | ) |  | $ | 100 |  |  | $ | — |  |  | $ | 11,866 |  |  | $ | (33 | ) |
| U.S. government agency securities | 596 |  |  | (1 | ) |  | — |  |  | — |  |  | 596 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 498 |  |  | (1 | ) |  | — |  |  | — |  |  | 498 |  |  | (1 | ) |
| Corporate debt securities | 9,013 |  |  | (57 | ) |  | 572 |  |  | (3 | ) |  | 9,585 |  |  | (60 | ) |
| U.S. agency mortgage-backed securities | 594 |  |  | (2 | ) |  | — |  |  | — |  |  | 594 |  |  | (2 | ) |
| Total fixed income securities | 22,467 |  |  | (94 | ) |  | 672 |  |  | (3 | ) |  | 23,139 |  |  | (97 | ) |
| Publicly traded equity securities | 291 |  |  | (53 | ) |  | 3 |  |  | (1 | ) |  | 294 |  |  | (54 | ) |
| Total | $ | 22,758 |  |  | $ | (147 | ) |  | $ | 675 |  |  | $ | (4 | ) |  | $ | 23,433 |  |  | $ | (151 | ) |

[0000858877-16-000123:notes:266]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 30, 2016 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 2,414 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |  | $ | 2,414 |  |  | $ | (2 | ) |
| U.S. government agency securities | 144 |  |  | — |  |  | — |  |  | — |  |  | 144 |  |  | — |  |
| Non-U.S. government and agency securities | 61 |  |  | — |  |  | — |  |  | — |  |  | 61 |  |  | — |  |
| Corporate debt securities | 2,499 |  |  | (7 | ) |  | 1,208 |  |  | (8 | ) |  | 3,707 |  |  | (15 | ) |
| U.S. agency mortgage-backed securities | 174 |  |  | — |  |  | — |  |  | — |  |  | 174 |  |  | — |  |
| Total fixed income securities | 5,292 |  |  | (9 | ) |  | 1,208 |  |  | (8 | ) |  | 6,500 |  |  | (17 | ) |
| Publicly traded equity securities | 188 |  |  | (40 | ) |  | — |  |  | — |  |  | 188 |  |  | (40 | ) |
| Total | $ | 5,480 |  |  | $ | (49 | ) |  | $ | 1,208 |  |  | $ | (8 | ) |  | $ | 6,688 |  |  | $ | (57 | ) |

[0000858877-16-000123:notes:267]
As of October 29, 2016, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of October 29, 2016, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the three months ended October 29, 2016.

[0000858877-16-000123:notes:268]
The Company has evaluated its publicly traded equity securities as of October 29, 2016 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-16-000123:notes:269]
| (c) | Maturities of Fixed Income Securities |

[0000858877-16-000123:notes:270]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations. The remaining contractual principal maturities for mortgage-backed securities were allocated assuming no prepayments.

[0000858877-16-000123:notes:271]
| (d) | Securities Lending |

[0000858877-16-000123:notes:272]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the three months ended October 29, 2016 and October 24, 2015 was $1.5 billion and $0.5 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 29, 2016 and July 30, 2016, the Company had no outstanding securities lending transactions.

[0000858877-16-000123:notes:273]
| (e) | Investments in Privately Held Companies |

[0000858877-16-000123:notes:274]
The carrying value of the Company’s investments in privately held companies was included in other assets.  For such investments that were accounted for under the equity and cost method as of October 29, 2016 and July 30, 2016, the amounts are summarized in the following table (in millions):

[0000858877-16-000123:notes:275]
For additional information on impairment charges related to investments in privately held companies, see Note 9.

[0000858877-16-000123:notes:276]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of October 29, 2016, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

[0000858877-16-000123:notes:277]
As discussed in Note 2, during the first quarter of fiscal 2017, the Company adopted a new accounting standard update related to the consolidation of certain types of legal entities. As of October 29, 2016, the carrying value of the Company's investments in privately held companies was $991 million, of which $609 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $189 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000858877-16-000123:notes:278]
(a) New Accounting Updates Recently Adopted

[0000858877-16-000123:notes:279]
Consolidation of Certain Types of Legal Entities  In February 2015, the FASB issued an accounting standard update that changes the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. The accounting standard update became effective for the Company beginning in the first quarter of fiscal 2017. The application of this accounting standard update did not have any impact on the Company's Consolidated Balance Sheet or Statement of Operations upon adoption, but the Company has provided additional disclosures in Note 8 pursuant to this accounting standard update.

[0000858877-16-000123:notes:280]
(b) Recent Accounting Standards or Updates Not Yet Effective

[0000858877-16-000123:notes:281]
Revenue Recognition  In May 2014, the Financial Accounting Standards Board ("FASB") issued an accounting standard update related to revenue from contracts with customers, which, along with amendments issued in 2015 and 2016, will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance. The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. This accounting standard update, as amended, will be effective for the Company beginning in the first quarter of fiscal 2019. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective basis"). Early adoption is permitted, but no earlier than fiscal 2018. The Company expects to adopt this accounting standard update on a modified retrospective basis in the first quarter of fiscal 2019, and it is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-16-000123:notes:282]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-16-000123:notes:283]
Leases  In February 2016, the FASB issued an accounting standard update related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2020 on a modified retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-16-000123:notes:284]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. The accounting standard will be effective for the Company beginning the first quarter of fiscal 2018, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-16-000123:notes:285]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2021 on a modified retrospective basis, and early adoption in fiscal 2020 is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-16-000123:notes:286]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Statements of Cash Flows.

[0000858877-16-000123:notes:287]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-16-000123:notes:288]
Basis of Presentation

[0000858877-16-000123:notes:289]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2017 is a 52-week fiscal year, and fiscal 2016 was a 53-week fiscal year. The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated. The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-16-000123:notes:290]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-16-000123:notes:291]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,819 |  |  | $ | 4,778 |  |
| Computer equipment and related software |  | 1,292 |  |  | 1,288 |  |
| Production, engineering, and other equipment |  | 5,708 |  |  | 5,658 |  |
| Operating lease assets |  | 301 |  |  | 296 |  |
| Furniture and fixtures |  | 548 |  |  | 543 |  |
| Total gross property and equipment |  | 12,668 |  |  | 12,563 |  |
| Less: accumulated depreciation and amortization |  | (9,169 | ) |  | (9,057 | ) |
| Total |  | $ | 3,499 |  |  | $ | 3,506 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-16-000123:notes:292]
Restructuring and Other Charges

[0000858877-16-000123:notes:293]
In August 2016, the Company announced a restructuring plan (the "Fiscal 2017 Plan") that will impact up to 5,500 employees, representing approximately 7% of its global workforce. The Company's aggregate pretax estimated charges pursuant to the restructuring plan are expected to be up to $700 million, consisting primarily of severance and other one-time termination benefits, and other associated costs. These charges are primarily cash-based, and the Company expects the Fiscal 2017 Plan to be substantially completed by the end of fiscal 2017.

[0000858877-16-000123:notes:294]
In connection with a restructuring action announced in August 2014 (the “Fiscal 2015 Plan”), the Company incurred cumulative charges of approximately $756 million. The Company completed the Fiscal 2015 Plan in fiscal 2016.

[0000858877-16-000123:notes:295]
The following tables summarize the activities related to the restructuring and other charges (in millions):

[0000858877-16-000123:notes:296]
|  |  | FISCAL 2015 AND PRIOR PLANS |  | FISCAL 2017 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 30, 2016 |  | $ | 21 |  |  | $ | 24 |  |  | $ | — |  |  | $ | — |  |  | $ | 45 |  |
| Charges |  | — |  |  | — |  |  | 369 |  |  | 42 |  |  | 411 |  |
| Cash payments |  | (12 | ) |  | — |  |  | (257 | ) |  | (1 | ) |  | (270 | ) |
| Non-cash items |  | (4 | ) |  | (2 | ) |  | — |  |  | (41 | ) |  | (47 | ) |
| Liability as of October 29, 2016 |  | $ | 5 |  |  | $ | 22 |  |  | $ | 112 |  |  | $ | — |  |  | $ | 139 |  |

[0000858877-16-000123:notes:297]
|  |  | FISCAL 2015 AND PRIOR PLANS |  |  |
|  |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 25, 2015 |  | $ | 60 |  |  | $ | 29 |  |  | $ | 89 |  |
| Charges |  | 125 |  |  | 17 |  |  | 142 |  |
| Cash payments |  | (123 | ) |  | (6 | ) |  | (129 | ) |
| Non-cash items |  | — |  |  | (16 | ) |  | (16 | ) |
| Liability as of October 24, 2015 |  | $ | 62 |  |  | $ | 24 |  |  | $ | 86 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000858877-16-000123:notes:298]
The following tables provide details of selected balance sheet items (in millions):

[0000858877-16-000123:notes:299]
|  |  | October 29, 2016 |  | July 30, 2016 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 111 |  |  | $ | 91 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 481 |  |  | 457 |  |
| Manufactured finished goods |  | 328 |  |  | 415 |  |
| Total finished goods |  | 809 |  |  | 872 |  |
| Service-related spares |  | 237 |  |  | 236 |  |
| Demonstration systems |  | 19 |  |  | 18 |  |
| Total |  | $ | 1,176 |  |  | $ | 1,217 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-16-000123:notes:300]
Recent Accounting Pronouncements


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-16-000123:notes:301]
Shareholders’ Equity

[0000858877-16-000123:notes:302]
[same as prior period, unchanged from 0000858877-16-000109:notes:315]

[0000858877-16-000123:notes:303]
During the three months ended October 29, 2016, the Company declared and paid cash dividends of $0.26 per common share, or $1.3 billion, on the Company’s outstanding common stock. During the three months ended October 24, 2015, the Company declared and paid cash dividends of $0.21 per common share, or $1.1 billion, on the Company’s outstanding common stock.

[0000858877-16-000123:notes:304]
[same as prior period, unchanged from 0000858877-16-000109:notes:317]

[0000858877-16-000123:notes:305]
[same as prior period, unchanged from 0000858877-16-000109:notes:318]

[0000858877-16-000123:notes:306]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of October 29, 2016, the Company’s Board of Directors had authorized an aggregate repurchase of up to $112 billion of common stock under this program, and the remaining authorized repurchase amount was $14.4 billion, with no termination date. A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-16-000123:notes:307]
The purchase price for the shares of the Company’s stock repurchased is reflected as a reduction to shareholders’ equity. The Company is required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings and (ii) a reduction of common stock and additional paid-in capital.

[0000858877-16-000123:notes:308]
[same as prior period, unchanged from 0000858877-16-000109:notes:321]

[0000858877-16-000123:notes:309]
For the three months ended October 29, 2016 and October 24, 2015, the Company repurchased approximately 13 million and 15 million shares, or $401 million and $382 million, of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.

[0000858877-16-000123:notes:310]
(d)   Preferred Stock

[0000858877-16-000123:notes:311]
Under the terms of the Company’s Articles of Incorporation, the Board of Directors may determine the rights, preferences, and terms of the Company’s authorized but unissued shares of preferred stock.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-16-000123:notes:312]
Balance Sheet Details


## us-gaap:TreasuryStockTextBlock

[0000858877-16-000123:notes:313]
[same as prior period, unchanged from 0000858877-16-000109:notes:324]

[0000858877-16-000123:notes:314]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of October 29, 2016, the Company’s Board of Directors had authorized an aggregate repurchase of up to $112 billion of common stock under this program with no termination date. For additional information regarding stock repurchase, see Note 13 to the Consolidated Financial Statements. The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):
