# CSCO MD&A — 0000858877-16-000123


## mdna

[0000858877-16-000123:mdna:1]
[same as prior period, unchanged from 0000858877-16-000109:mdna:1]

[0000858877-16-000123:mdna:2]
[same as prior period, unchanged from 0000858877-16-000109:mdna:2]

[0000858877-16-000123:mdna:3]
[same as prior period, unchanged from 0000858877-16-000109:mdna:3]

[0000858877-16-000123:mdna:4]
Cisco designs and sells broad lines of products, provides services and delivers integrated solutions to develop and connect networks around the world. For over 30 years, we have helped our customers build networks and automate, orchestrate, integrate, and digitize information technology (IT)–based products and services. In an increasingly connected world, Cisco is helping to transform businesses, governments and cities worldwide. Over time, we have expanded to new markets that are a natural extension of our core networking business, as the network has become the platform for delivering an ever-increasing portfolio of IT–based products and services.

[0000858877-16-000123:mdna:5]
A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-16-000123:mdna:6]
|  | Three Months Ended |  |
|  | October 29, 2016 |  | October 24, 2015 |  | Variance |  |
| Revenue (1) | $ | 12,352 |  |  | $ | 12,682 |  |  | (2.6 | )% |  |
| Gross margin percentage | 63.8 | % |  | 61.8 | % |  | 2.0 |  | pts |
| Research and development | $ | 1,545 |  |  | $ | 1,560 |  |  | (1.0 | )% |  |
| Sales and marketing | $ | 2,418 |  |  | $ | 2,443 |  |  | (1.0 | )% |  |
| General and administrative | $ | 555 |  |  | $ | 539 |  |  | 3.0 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,518 |  |  | $ | 4,542 |  |  | (0.5 | )% |  |
| Total as a percentage of revenue | 36.6 | % |  | 35.8 | % |  | 0.8 |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 78 |  |  | $ | 69 |  |  | 13.0 | % |  |
| Restructuring and other charges included in operating expenses | $ | 411 |  |  | $ | 142 |  |  | 189.4 | % |  |
| Operating income as a percentage of revenue | 23.3 | % |  | 24.3 | % |  | (1.0 | ) | pts |
| Income tax percentage | 21.4 | % |  | 22.5 | % |  | (1.1 | ) | pts |
| Net income | $ | 2,322 |  |  | $ | 2,430 |  |  | (4.4 | )% |  |
| Net income as a percentage of revenue | 18.8 | % |  | 19.2 | % |  | (0.4 | ) | pts |
| Earnings per share—diluted | $ | 0.46 |  |  | $ | 0.48 |  |  | (4.2 | )% |  |

[0000858877-16-000123:mdna:7]
(1) During the second quarter of fiscal 2016, we completed the sale of the Customer Premises Equipment portion of our Service Provider Video Connected Devices business (“SP Video CPE Business”). As a result, revenue from this portion of the Service Provider Video product category will not recur in future periods. Includes SP Video CPE Business revenue of $411 million for the first quarter of fiscal 2016.

[0000858877-16-000123:mdna:8]
[same as prior period, unchanged from 0000858877-16-000109:mdna:9]

[0000858877-16-000123:mdna:9]
[same as prior period, unchanged from 0000858877-16-000109:mdna:10]

[0000858877-16-000123:mdna:10]
Three Months Ended October 29, 2016 Compared with Three Months Ended October 24, 2015

[0000858877-16-000123:mdna:11]
In the first quarter of fiscal 2017, our revenue decreased by 3% (increased 1% not including revenue from the divested SP Video CPE products which had been included in the prior year period) as compared with the first quarter of fiscal 2016. Within total revenue, product revenue decreased 6% while service revenue increased 7%.  Total gross margin increased by 2.0 percentage points, driven by productivity improvements and the sale of the lower margin SP Video CPE Business, partially offset by the negative impacts of pricing and product mix.  As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 0.8 percentage points. Operating income as a percentage of revenue decreased by 1.0 percentage points, driven by the increase in restructuring and other charges related to the restructuring action announced in August 2016 and the factors discussed above. Diluted earnings per share decreased by 4% from the prior year, driven by a 4% decrease in net income.

[0000858877-16-000123:mdna:12]
Revenue from the Americas decreased by $0.3 billion, driven by the sale of the SP Video CPE Business which led to lower product revenue in the United States. EMEA revenue decreased by $0.1 billion, led by product revenue declines in the United Kingdom. Revenue in our APJC segment increased $0.1 billion, led by product revenue growth in Australia and Japan. We experienced revenue declines from many emerging countries, and in particular we experienced product revenue declines in the emerging countries of Mexico, Brazil and China of 31%, 10% and 2%, respectively. In the aggregate, the “BRICM” countries experienced product revenue decline of 8% despite increased product revenue in Russia and India of 10% and 2%, respectively.

[0000858877-16-000123:mdna:13]
From a customer market standpoint, in the first quarter of fiscal 2017 we experienced product revenue declines in the service provider, public sector and commercial markets, while the enterprise market experienced growth. The decline in the service provider market was driven by the sale of the SP Video CPE Business.

[0000858877-16-000123:mdna:14]
From a product category perspective, total company product revenue, not including SP Video CPE products in the prior year period, decreased 1% year over year. This decrease was led by product revenue decrease in Switching products of 7%. Product revenue from Collaboration and Data Center each decreased by a 3% and product revenue from Service Provider Video (excluding the CPE Business from the prior year period) and Wireless products each decreased by 2%.  Partially offsetting these decreases was product revenue growth in Security and NGN Routing, which grew by 11% and 6%, respectively. The decline in sales of our Switching products was primarily due to lower sales of switches used in campus environments, which comprise the majority of our Switching portfolio. We believe the decline in sales of Switching products used in campus environments was driven by uncertainty in the macro environment, which led to a slowdown in customer spending, as well as by a highly competitive landscape.

[0000858877-16-000123:mdna:15]
In summary, during the first quarter of fiscal 2017, we experienced solid revenue growth in our Security, NGN Routing and our Services categories. In addition, we continued to make progress in the transition of our business model to increased software and subscriptions. During the first quarter of fiscal 2017, we experienced increased weakness in our business momentum with respect to the service provider customer market and continuing weakness in emerging countries in the aggregate.  We continue to operate in a challenging environment with significant volatility and a highly competitive landscape. We remain focused on accelerating innovation across our portfolio, and we believe that we have made solid progress over the past year in our priority areas. While the overall macro environment remains uncertain, we believe we are well positioned.  At the same time, we are aggressively investing in priority areas to drive growth over the long term regardless of the environment.

[0000858877-16-000123:mdna:16]
[same as prior period, unchanged from 0000858877-16-000109:mdna:20]

[0000858877-16-000123:mdna:17]
[same as prior period, unchanged from 0000858877-16-000109:mdna:21]

[0000858877-16-000123:mdna:18]
[same as prior period, unchanged from 0000858877-16-000109:mdna:22]

[0000858877-16-000123:mdna:19]
We see our customers increasingly using technology and, specifically, networks to grow their businesses, drive efficiencies, and try to gain a competitive advantage. In this increasingly digital world, we believe data is the most strategic asset and is increasingly distributed across every organization and ecosystem, on customer premises, at the edge of the network, and in the cloud. The network also plays an increasingly important role in enabling our customers to aggregate, automate, and draw insights from this highly distributed data, where there is a premium on security and speed. We believe this is driving them to adopt entirely new IT architectures and organizational structures. We understand how technology can deliver the outcomes our customers want to achieve, and our strategy is to lead our customers in their digital transition with solutions including pervasive, industry-leading security that intelligently connects nearly everything that can be digitally connected.

[0000858877-16-000123:mdna:20]
To deliver on our strategy, we are focused on providing highly secure, automated and intelligent solutions built on infrastructure that connects highly distributed data that is globally dispersed across organizations. Together with our ecosystem of partners and developers, we will provide technology, services, and solutions we believe will enable our customers to gain insight and advantage from this distributed data with scale, security and agility.

[0000858877-16-000123:mdna:21]
For a full discussion of our strategy and focus areas, see Item 1. Business in our Annual Report on Form 10-K for the year ended July 30, 2016.

[0000858877-16-000123:mdna:22]
[same as prior period, unchanged from 0000858877-16-000109:mdna:26]

[0000858877-16-000123:mdna:23]
The following is a summary of our other key financial measures for the first quarter of fiscal 2017 (in millions, except annualized inventory turns):

[0000858877-16-000123:mdna:24]
|  |  | October 29, 2016 |  | July 30, 2016 |
| Cash and cash equivalents and investments |  | $ | 70,968 |  |  | $ | 65,756 |  |
| Deferred revenue |  | $ | 16,951 |  |  | $ | 16,472 |  |
| Inventories |  | $ | 1,176 |  |  | $ | 1,217 |  |
| Annualized inventory turns |  | 14.9 |  |  | 14.6 |  |

[0000858877-16-000123:mdna:25]
|  |  | Three Months Ended |
|  |  | October 29, 2016 |  | October 24, 2015 |
| Cash provided by operating activities |  | $ | 2,730 |  |  | $ | 2,766 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 1,001 |  |  | $ | 1,207 |  |
| Dividends |  | $ | 1,308 |  |  | $ | 1,068 |  |

[0000858877-16-000123:mdna:26]
[same as prior period, unchanged from 0000858877-16-000109:mdna:31]

[0000858877-16-000123:mdna:27]
[same as prior period, unchanged from 0000858877-16-000109:mdna:32]

[0000858877-16-000123:mdna:28]
[same as prior period, unchanged from 0000858877-16-000109:mdna:33]

[0000858877-16-000123:mdna:29]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements in our Annual Report on Form 10-K for the year ended July 30, 2016, as updated as applicable in Note 2 to the Consolidated Financial Statements herein, describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-16-000123:mdna:30]
[same as prior period, unchanged from 0000858877-16-000109:mdna:35]

[0000858877-16-000123:mdna:31]
[same as prior period, unchanged from 0000858877-16-000109:mdna:36]

[0000858877-16-000123:mdna:32]
[same as prior period, unchanged from 0000858877-16-000109:mdna:37]

[0000858877-16-000123:mdna:33]
| • | Delivery has occurred. Shipping documents and customer acceptance, when applicable, are used to verify delivery. For software, delivery is considered to have occurred upon unrestricted license access and license term commencement, when applicable. |

[0000858877-16-000123:mdna:34]
[same as prior period, unchanged from 0000858877-16-000109:mdna:39]

[0000858877-16-000123:mdna:35]
[same as prior period, unchanged from 0000858877-16-000109:mdna:40]

[0000858877-16-000123:mdna:36]
[same as prior period, unchanged from 0000858877-16-000109:mdna:41]

[0000858877-16-000123:mdna:37]
The amount of revenue recognized in a given period is affected by our judgment as to whether an arrangement includes multiple deliverables and, if so, our valuation of the units of accounting.  Our multiple element arrangements may contain only deliverables within the scope of Accounting Standards Codification (ASC) 605, Revenue Recognition, deliverables within the scope of ASC 985-605, Software-Revenue Recognition, or a combination of both. According to the accounting guidance prescribed in ASC 605, we use vendor-specific objective evidence of selling price (VSOE) for each of those units, when available. We determine VSOE based on our normal pricing and discounting practices for the specific product or service when sold separately. In determining VSOE, we require that a substantial majority of the historical standalone transactions have the selling prices for a product or service fall within a reasonably narrow pricing range, generally evidenced by approximately 80% of such historical standalone transactions falling within plus or minus 15% of the median rates. When VSOE does not exist, we apply the selling price hierarchy to applicable multiple-deliverable arrangements. Under the selling price hierarchy, third-party evidence of selling price (TPE) will be considered if VSOE does not exist, and estimated selling price (ESP) will be used if neither VSOE nor TPE is available. Generally, we are not able to determine TPE because our go-to-market strategy differs from that of others in our markets, and the extent of our proprietary technology varies among comparable products or services from those of our peers. In determining ESP, we apply significant judgment as we weigh a variety of factors, based on the characteristics of the deliverable. We typically arrive at an ESP for a product or service that is not sold separately by considering company-specific factors such as geographies, competitive landscape, internal costs, profitability objectives, pricing practices used to establish bundled pricing, and existing portfolio pricing and discounting.

[0000858877-16-000123:mdna:38]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during the first quarter of fiscal 2017, nor do we currently expect a material impact in the next 12 months on our revenue recognition due to any changes in our VSOE, TPE, or ESP.

[0000858877-16-000123:mdna:39]
[same as prior period, unchanged from 0000858877-16-000109:mdna:46]

[0000858877-16-000123:mdna:40]
[same as prior period, unchanged from 0000858877-16-000109:mdna:47]

[0000858877-16-000123:mdna:41]
We make sales to distributors which we refer to as two-tier sales to the end customer. Revenue from two-tier distributors is recognized based on a sell-through method using point-of-sale information provided by these distributors. Distributors participate in various cooperative marketing and other incentive programs, and we maintain estimated accruals and allowances for these programs. If actual credits received by distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-16-000123:mdna:42]
[same as prior period, unchanged from 0000858877-16-000109:mdna:50]

[0000858877-16-000123:mdna:43]
[same as prior period, unchanged from 0000858877-16-000109:mdna:51]

[0000858877-16-000123:mdna:44]
|  |  | October 29, 2016 |  | July 30, 2016 |
| Allowance for doubtful accounts |  | $ | 247 |  |  | $ | 249 |  |
| Percentage of gross accounts receivable |  | 4.9 | % |  | 4.1 | % |
| Allowance for credit loss—lease receivables |  | $ | 227 |  |  | $ | 230 |  |
| Percentage of gross lease receivables(1) |  | 6.7 | % |  | 6.6 | % |
| Allowance for credit loss—loan receivables |  | $ | 111 |  |  | $ | 97 |  |
| Percentage of gross loan receivables |  | 5.0 | % |  | 4.5 | % |

[0000858877-16-000123:mdna:45]
[same as prior period, unchanged from 0000858877-16-000109:mdna:53]

[0000858877-16-000123:mdna:46]
The allowance for doubtful accounts is based on our assessment of the collectibility of customer accounts. We regularly review the adequacy of these allowances by considering internal factors such as historical experience, credit quality and age of the receivable balances as well as external factors such as economic conditions that may affect a customer’s ability to pay as well as historical and expected default frequency rates, which are published by major third-party credit-rating agencies and are updated on a quarterly basis. We also consider the concentration of receivables outstanding with a particular customer in assessing the adequacy of our allowances for doubtful accounts. If a major customer’s creditworthiness deteriorates, if actual defaults are higher than our historical experience, or if other circumstances arise, our estimates of the recoverability of amounts due to us could be overstated, and additional allowances could be required, which could have an adverse impact on our operating results.

[0000858877-16-000123:mdna:47]
[same as prior period, unchanged from 0000858877-16-000109:mdna:55]

[0000858877-16-000123:mdna:48]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of October 29, 2016 and July 30, 2016 was $124 million and $126 million, respectively, and was recorded as a reduction of our accounts receivable and revenue. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-16-000123:mdna:49]
[same as prior period, unchanged from 0000858877-16-000109:mdna:59]

[0000858877-16-000123:mdna:50]
Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and market, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-16-000123:mdna:51]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 29, 2016, the liability for these purchase commitments was $161 million, compared with $159 million as of July 30, 2016, and was included in other current liabilities.

[0000858877-16-000123:mdna:52]
[same as prior period, unchanged from 0000858877-16-000109:mdna:8]

[0000858877-16-000123:mdna:53]
[same as prior period, unchanged from 0000858877-16-000109:mdna:57]

[0000858877-16-000123:mdna:54]
[same as prior period, unchanged from 0000858877-16-000109:mdna:58]

[0000858877-16-000123:mdna:55]
Our provision for inventory was $12 million and $27 million for the first quarter of fiscal 2017 and 2016, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $30 million and $41 million for the first quarter of fiscal 2017 and 2016, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence, particularly in light of current macroeconomic uncertainties and conditions and the resulting potential for changes in future demand forecast.

[0000858877-16-000123:mdna:56]
Loss Contingencies and Product Warranties

[0000858877-16-000123:mdna:57]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-16-000123:mdna:58]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-16-000123:mdna:59]
We have recorded a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. In February 2014, on the basis of the growing number of failures as described in Note 12 (f) to the Consolidated Financial Statements, we decided to expand our approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014. During fiscal 2016 and 2015, we recorded adjustments to product cost of sales of $74 million and $164 million, respectively to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products. Estimating this liability is complex and subjective, and if we experience changes in a number of underlying assumptions and estimates such as a change in claims compared with our expectations, or if the cost of servicing these claims is different than expected, our estimated liability may be impacted.

[0000858877-16-000123:mdna:60]
Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty. We accrue for warranty costs as part of our cost of sales based on associated material costs, technical support labor costs, and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends in the rate of customer cases and the cost to support the customer cases within the warranty period. Overhead cost is applied based on estimated time to support warranty activities.

[0000858877-16-000123:mdna:61]
If we experience an increase in warranty claims compared with our historical experience, or if the cost of servicing warranty claims is greater than expected, our profitability could be adversely affected.

[0000858877-16-000123:mdna:62]
[same as prior period, unchanged from 0000858877-16-000109:mdna:72]

[0000858877-16-000123:mdna:63]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $62.4 billion as of October 29, 2016, compared with $58.1 billion as of July 30, 2016. Our fixed income investment portfolio as of October 29, 2016 consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-16-000123:mdna:64]
[same as prior period, unchanged from 0000858877-16-000109:mdna:74]

[0000858877-16-000123:mdna:65]
[same as prior period, unchanged from 0000858877-16-000109:mdna:70]

[0000858877-16-000123:mdna:66]
[same as prior period, unchanged from 0000858877-16-000109:mdna:71]

[0000858877-16-000123:mdna:67]
[same as prior period, unchanged from 0000858877-16-000109:mdna:75]

[0000858877-16-000123:mdna:68]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of October 29, 2016. Level 3 assets do not represent a significant portion of our total assets measured at fair value on a recurring basis as of October 29, 2016 and July 30, 2016.

[0000858877-16-000123:mdna:69]
[same as prior period, unchanged from 0000858877-16-000109:mdna:77]

[0000858877-16-000123:mdna:70]
[same as prior period, unchanged from 0000858877-16-000109:mdna:78]

[0000858877-16-000123:mdna:71]
[same as prior period, unchanged from 0000858877-16-000109:mdna:79]

[0000858877-16-000123:mdna:72]
[same as prior period, unchanged from 0000858877-16-000109:mdna:80]

[0000858877-16-000123:mdna:73]
We also have investments in privately held companies, some of which are in the startup or development stages. As of October 29, 2016, our investments in privately held companies were $991 million, compared with $1,003 million as of July 30, 2016, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize. Our impairment charges on investments in privately held companies were $47 million and $17 million for the first quarter of fiscal 2017 and 2016, respectively.

[0000858877-16-000123:mdna:74]
[same as prior period, unchanged from 0000858877-16-000109:mdna:86]

[0000858877-16-000123:mdna:75]
[same as prior period, unchanged from 0000858877-16-000109:mdna:87]

[0000858877-16-000123:mdna:76]
The goodwill recorded in the Consolidated Balance Sheets as of October 29, 2016 and July 30, 2016 was $26.8 billion and $26.6 billion, respectively. In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first quarters of fiscal 2017 and 2016.

[0000858877-16-000123:mdna:77]
[same as prior period, unchanged from 0000858877-16-000109:mdna:83]

[0000858877-16-000123:mdna:78]
[same as prior period, unchanged from 0000858877-16-000109:mdna:84]

[0000858877-16-000123:mdna:79]
[same as prior period, unchanged from 0000858877-16-000109:mdna:271]

[0000858877-16-000123:mdna:80]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts.  Our impairment charges related to purchased intangible assets were $42 million for the first quarter of fiscal 2017, and there were no such impairment charges for the first quarter of fiscal 2016. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-16-000123:mdna:81]
[same as prior period, unchanged from 0000858877-16-000109:mdna:90]

[0000858877-16-000123:mdna:82]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 21.4% and 22.5% in the first quarter of fiscal 2017 and 2016, respectively.

[0000858877-16-000123:mdna:83]
[same as prior period, unchanged from 0000858877-16-000109:mdna:92]

[0000858877-16-000123:mdna:84]
[same as prior period, unchanged from 0000858877-16-000109:mdna:93]

[0000858877-16-000123:mdna:85]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to domestic manufacturing deduction laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our intercompany R&D cost-sharing arrangement and legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including possible changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, or the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 35 countries, including the United States, has recently made changes to numerous long-standing tax principles. There can be no assurance that these changes, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-16-000123:mdna:86]
[same as prior period, unchanged from 0000858877-16-000109:mdna:45]

[0000858877-16-000123:mdna:87]
[same as prior period, unchanged from 0000858877-16-000109:mdna:95]

[0000858877-16-000123:mdna:88]
[same as prior period, unchanged from 0000858877-16-000109:mdna:96]

[0000858877-16-000123:mdna:89]
[same as prior period, unchanged from 0000858877-16-000109:mdna:101]

[0000858877-16-000123:mdna:90]
[same as prior period, unchanged from 0000858877-16-000109:mdna:102]

[0000858877-16-000123:mdna:91]
[same as prior period, unchanged from 0000858877-16-000109:mdna:103]

[0000858877-16-000123:mdna:92]
|  |  | Three Months Ended |
|  |  | October 29, 2016 |  | October 24, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,302 |  |  | $ | 9,844 |  |  | $ | (542 | ) |  | (5.5 | )% |
| Percentage of revenue |  | 75.3 | % |  | 77.6 | % |  |  |  |  |  |  |
| Service |  | 3,050 |  |  | 2,838 |  |  | 212 |  |  | 7.5 | % |
| Percentage of revenue |  | 24.7 | % |  | 22.4 | % |  |  |  |  |  |  |
| Total |  | $ | 12,352 |  |  | $ | 12,682 |  |  | $ | (330 | ) |  | (2.6 | )% |

[0000858877-16-000123:mdna:93]
[same as prior period, unchanged from 0000858877-16-000109:mdna:105]

[0000858877-16-000123:mdna:94]
|  |  | Three Months Ended |
|  |  | October 29, 2016 |  | October 24, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,443 |  |  | $ | 7,792 |  |  | $ | (349 | ) |  | (4.5 | )% |
| Percentage of revenue |  | 60.3 | % |  | 61.4 | % |  |  |  |  |
| EMEA |  | 3,013 |  |  | 3,094 |  |  | (81 | ) |  | (2.6 | )% |
| Percentage of revenue |  | 24.4 | % |  | 24.4 | % |  |  |  |  |
| APJC |  | 1,896 |  |  | 1,796 |  |  | 100 |  |  | 5.6 | % |
| Percentage of revenue |  | 15.3 | % |  | 14.2 | % |  |  |  |  |
| Total |  | $ | 12,352 |  |  | $ | 12,682 |  |  | $ | (330 | ) |  | (2.6 | )% |

[0000858877-16-000123:mdna:95]
Three Months Ended October 29, 2016 Compared with Three Months Ended October 24, 2015

[0000858877-16-000123:mdna:96]
For the first quarter of fiscal 2017, as compared with the first quarter of fiscal 2016, total revenue decreased by 3%. Total company revenue not including SP Video CPE products increased 1%. Product revenue decreased by 6% in total, and decreased by 1% not including revenue from SP Video CPE products in the prior year period. Service revenue increased by 7%.  Our total revenue increased in our APJC geographic segment, while revenue decreased in the Americas and EMEA geographic segments.  The emerging countries of BRICM, in the aggregate, experienced an 8% product revenue decline, with declines in Mexico, Brazil and China, partially offset by increases in the other two BRICM countries.

[0000858877-16-000123:mdna:97]
We conduct business globally in numerous currencies. The direct effect of foreign currency fluctuations on revenue has not been material because our revenue is primarily denominated in U.S. dollars. However, if the U.S. dollar strengthens relative to other currencies, such strengthening could have an indirect effect on our revenue to the extent it raises the cost of our products to non-U.S. customers and thereby reduces demand. A weaker U.S. dollar could have the opposite effect. However, the precise indirect effect of currency fluctuations is difficult to measure or predict because our revenue is influenced by many factors in addition to the impact of such currency fluctuations. Our revenue in the first quarter of fiscal 2017 was adversely affected by the depreciation of certain currencies relative to the U.S. dollar and especially currencies in certain emerging countries, although the indirect effects are difficult to measure.

[0000858877-16-000123:mdna:98]
In addition to the impact of macroeconomic factors, including a reduced IT spending environment and reductions in spending by government entities, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple-element arrangements; the mix of financing arrangements provided to channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment. As has been the case in certain emerging countries from time to time, customers require greater levels of financing arrangements, service, and support, and these activities may occur in future periods, which may also impact the timing of the recognition of revenue.

[0000858877-16-000123:mdna:99]
49

[0000858877-16-000123:mdna:100]
[same as prior period, unchanged from 0000858877-16-000109:mdna:99]

[0000858877-16-000123:mdna:101]
[same as prior period, unchanged from 0000858877-16-000109:mdna:100]

[0000858877-16-000123:mdna:102]
[same as prior period, unchanged from 0000858877-16-000109:mdna:115]

[0000858877-16-000123:mdna:103]
[same as prior period, unchanged from 0000858877-16-000109:mdna:116]

[0000858877-16-000123:mdna:104]
|  |  | Three Months Ended |
|  |  | October 29, 2016 |  | October 24, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,480 |  |  | $ | 5,948 |  |  | $ | (468 | ) |  | (7.9 | )% |
| Percentage of product revenue |  | 58.9 | % |  | 60.4 | % |  |  |  |  |
| EMEA |  | 2,364 |  |  | 2,483 |  |  | (119 | ) |  | (4.8 | )% |
| Percentage of product revenue |  | 25.4 | % |  | 25.2 | % |  |  |  |  |
| APJC |  | 1,458 |  |  | 1,413 |  |  | 45 |  |  | 3.2 | % |
| Percentage of product revenue |  | 15.7 | % |  | 14.4 | % |  |  |  |  |
| Total |  | $ | 9,302 |  |  | $ | 9,844 |  |  | $ | (542 | ) |  | (5.5 | )% |

[0000858877-16-000123:mdna:105]
During the second quarter of fiscal 2016, we completed the sale of our SP Video CPE Business.  As a result, revenue from this portion of the Service Provider Video product category will not recur in future periods.  SP Video CPE Business revenue for the first quarter of fiscal 2016 was $411 million.

[0000858877-16-000123:mdna:106]
Three Months Ended October 29, 2016 Compared with Three Months Ended October 24, 2015

[0000858877-16-000123:mdna:107]
[same as prior period, unchanged from 0000858877-16-000109:mdna:119]

[0000858877-16-000123:mdna:108]
The 8% decrease in product revenue for the Americas segment was driven primarily by the absence of product sales related to our SP Video CPE Business in the first quarter of fiscal 2017. We had $312 million in product sales related to our SP Video CPE Business in the first quarter of fiscal 2016 in this segment. The decrease in product revenue in the Americas segment reflected declines across all customer markets. In particular, the product revenue decrease in the service provider market was due to the sale of the SP Video CPE Business. The product revenue decrease in the public sector market was due primarily to lower sales to state and local governments, partially offset by higher sales to the U.S. federal government. From a country perspective, product revenue decreased by 7% in the United States, 31% in Mexico, 10% in Brazil and 2% in Canada.

[0000858877-16-000123:mdna:109]
[same as prior period, unchanged from 0000858877-16-000109:mdna:127]

[0000858877-16-000123:mdna:110]
The decrease in product revenue for the EMEA segment was driven primarily by the absence of product sales related to our SP Video CPE Business in the first quarter of fiscal 2017.  We had $85 million in product sales related to our SP Video CPE Business in the first quarter of fiscal 2016. Product revenue in the EMEA segment decreased by 5%, led by significant decline in the service provider market and, to a lesser extent, declines in the public sector and commercial markets. We experienced product revenue growth in the enterprise market. The decline in sales to the service provider market was due primarily to the sale of the SP Video CPE Business. Product revenue from emerging countries within EMEA decreased by 7% and product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, decreased by 4%.

[0000858877-16-000123:mdna:111]
[same as prior period, unchanged from 0000858877-16-000109:mdna:132]

[0000858877-16-000123:mdna:112]
Product revenue in the APJC segment increased by 3%, led by solid growth in the commercial and enterprise markets. These increases were partially offset by declines in the public sector and service provider markets. From a country perspective, product revenue increased by 20% in Australia, 11% in Japan and 2% in India, partially offset by a product revenue decrease of 2% in China. Product sales for this geographic segment were adversely impacted by a $14 million decrease in product sales related to the absence of our SP Video CPE Business.

[0000858877-16-000123:mdna:113]
[same as prior period, unchanged from 0000858877-16-000109:mdna:110]

[0000858877-16-000123:mdna:114]
[same as prior period, unchanged from 0000858877-16-000109:mdna:111]

[0000858877-16-000123:mdna:115]
[same as prior period, unchanged from 0000858877-16-000109:mdna:140]

[0000858877-16-000123:mdna:116]
In addition to the primary view on a geographic basis, we also prepare financial information related to groups of similar products and customer markets for various purposes. Our product categories consist of the following categories (with subcategories in parentheses): Switching (fixed switching, modular switching, and storage); NGN Routing (high-end routers, mid-range and low-end routers, and other NGN Routing products); Collaboration (unified communications, Cisco TelePresence, and conferencing); Data Center; Wireless; Security; Service Provider Video (infrastructure and software and solutions); and Other Products. The Other Products category consists primarily of emerging technology products and other networking products.

[0000858877-16-000123:mdna:117]
[same as prior period, unchanged from 0000858877-16-000109:mdna:142]

[0000858877-16-000123:mdna:118]
|  |  | Three Months Ended |
|  |  | October 29, 2016 |  | October 24, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,716 |  |  | $ | 4,009 |  |  | $ | (293 | ) |  | (7.3 | )% |
| Percentage of product revenue |  | 39.9 | % |  | 40.7 | % |  |  |  |  |  |  |
| NGN Routing |  | 2,089 |  |  | 1,969 |  |  | 120 |  |  | 6.1 | % |
| Percentage of product revenue |  | 22.5 | % |  | 20.0 | % |  |  |  |  |  |  |
| Collaboration |  | 1,081 |  |  | 1,115 |  |  | (34 | ) |  | (3.0 | )% |
| Percentage of product revenue |  | 11.6 | % |  | 11.3 | % |  |  |  |  |  |  |
| Data Center |  | 834 |  |  | 859 |  |  | (25 | ) |  | (2.9 | )% |
| Percentage of product revenue |  | 9.0 | % |  | 8.7 | % |  |  |  |  |  |  |
| Wireless |  | 632 |  |  | 646 |  |  | (14 | ) |  | (2.2 | )% |
| Percentage of product revenue |  | 6.8 | % |  | 6.6 | % |  |  |  |  |
| Security |  | 540 |  |  | 485 |  |  | 55 |  |  | 11.3 | % |
| Percentage of product revenue |  | 5.8 | % |  | 4.9 | % |  |  |  |  |  |  |
| Service Provider Video (1) |  | 271 |  |  | 687 |  |  | (416 | ) |  | (60.6 | )% |
| Percentage of product revenue |  | 2.9 | % |  | 7.0 | % |  |  |  |  |
| Other |  | 139 |  |  | 74 |  |  | 65 |  |  | 87.8 | % |
| Percentage of product revenue |  | 1.5 | % |  | 0.8 | % |  |  |  |  |  |  |
| Total |  | $ | 9,302 |  |  | $ | 9,844 |  |  | $ | (542 | ) |  | (5.5 | )% |

[0000858877-16-000123:mdna:119]
(1) Includes SP Video CPE Business revenue of $411 million for the first quarter of fiscal 2016.

[0000858877-16-000123:mdna:120]
[same as prior period, unchanged from 0000858877-16-000109:mdna:145]

[0000858877-16-000123:mdna:121]
Three Months Ended October 29, 2016 Compared with Three Months Ended October 24, 2015

[0000858877-16-000123:mdna:122]
[same as prior period, unchanged from 0000858877-16-000109:mdna:148]

[0000858877-16-000123:mdna:123]
The decrease in revenue in our Switching product category of 7%, or $293 million, was driven primarily by a decrease in sales of Switching products used in campus environments, which comprise the majority of our Switching portfolio.  We believe this was driven by the uncertainty in the macro environment which led to a slowdown in customer spending, as well as by a highly competitive landscape.

[0000858877-16-000123:mdna:124]
In terms of subcategories, the decrease was driven by a 21%, or $256 million, decrease in revenue from our modular switches due primarily to lower sales of most of our Cisco Catalyst Series Switches and also due to lower sales of our Cisco Nexus 7000 Series Switches, partially offset by sales growth in Cisco Nexus 9500 Series Switches.  We experienced a slight decrease in revenue from LAN fixed-configuration switches of 1%, or $26 million, and a decrease of a 12%, or $11 million, in sales of storage products. Revenue from our LAN-fixed configuration switches decreased due primarily to lower sales of most of the Cisco Catalyst Series switches in this product category, partially offset by higher sales of the Cisco Nexus 9300 Series Switches and certain other products in this portfolio.

[0000858877-16-000123:mdna:125]
[same as prior period, unchanged from 0000858877-16-000109:mdna:82]

[0000858877-16-000123:mdna:126]
[same as prior period, unchanged from 0000858877-16-000109:mdna:123]

[0000858877-16-000123:mdna:127]
[same as prior period, unchanged from 0000858877-16-000109:mdna:124]

[0000858877-16-000123:mdna:128]
[same as prior period, unchanged from 0000858877-16-000109:mdna:154]

[0000858877-16-000123:mdna:129]
Revenue in our NGN Routing product category increased by 6%, or $120 million, driven by a 9%, or $88 million, increase in revenue from our high-end router products, an 8%, or $25 million increase in revenue from what we categorize as other NGN Routing products and a 1%, or $7 million, increase in revenue from our midrange and low-end router products. The increase in revenue from our high-end router products was driven by an increase in revenue from our Cisco Aggregation Services Router (ASR) products, our Cisco Carrier Routing System (CRS) products and our legacy high-end router products.  The increase in revenue from other NGN Routing products was due to increased revenue from cable access products.  Revenue from our midrange and low-end router products increased slightly, driven by higher sales of our Cisco Integrated Services Router (ISR) products partially offset by lower sales of certain of our access router products.

[0000858877-16-000123:mdna:130]
[same as prior period, unchanged from 0000858877-16-000109:mdna:159]

[0000858877-16-000123:mdna:131]
Revenue from our Collaboration product category decreased by 3%, or $34 million, driven by decreases in sales from Cisco TelePresence and Unified Communications products partially offset by continued growth in Conferencing revenue. The decrease in Unified Communications revenue was driven by decreased revenue from phones partially offset by higher software revenue. Revenue from Cisco TelePresence products declined due to lower revenue from endpoint products. The growth in Conferencing revenue resulted from higher usage and recurring revenue from WebEx, which we include as product revenue within this category. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Collaboration product category.

[0000858877-16-000123:mdna:132]
[same as prior period, unchanged from 0000858877-16-000109:mdna:167]

[0000858877-16-000123:mdna:133]
The decrease in revenue in our Data Center product category of 3%, or $25 million, was primarily driven by a decrease in sales of our Cisco Unified Computing System products, with declines in the service provider, public sector and commercial markets partially offset by growth in the enterprise market.  We believe the uncertainty in the macro environment led to a slowdown of customer spending.  Additionally, we are seeing a market transition with computing workloads shifting from blade server systems to rack-based systems.  Both of these factors we believe adversely impacted the sales of this product category.

[0000858877-16-000123:mdna:134]
[same as prior period, unchanged from 0000858877-16-000109:mdna:177]

[0000858877-16-000123:mdna:135]
Revenue in our Wireless product category decreased by 2%, or $14 million, driven by a decrease in sales of our controller products, partially offset by the continued growth in sales of Meraki products within this product category and increased sales of our access point products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Wireless product category.

[0000858877-16-000123:mdna:136]
[same as prior period, unchanged from 0000858877-16-000109:mdna:182]

[0000858877-16-000123:mdna:137]
Revenue in our Security product category increased 11%, or $55 million, driven by higher sales of advanced threat security, web security and unified threat management products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Security product category.

[0000858877-16-000123:mdna:138]
[same as prior period, unchanged from 0000858877-16-000109:mdna:172]

[0000858877-16-000123:mdna:139]
The decrease in revenue from our Service Provider Video product category of 61%, or $416 million, was driven by a decrease in product sales of $411 million related to our SP Video CPE Business which we sold during the second quarter of fiscal 2016.

[0000858877-16-000123:mdna:140]
Other Products

[0000858877-16-000123:mdna:141]
The increase in revenue in our Other Products category was due to increased revenue from our Internet of Things (“IoT”) products, driven by our Jasper acquisition and increased revenue from our cloud-related offerings.

[0000858877-16-000123:mdna:142]
[same as prior period, unchanged from 0000858877-16-000109:mdna:138]

[0000858877-16-000123:mdna:143]
[same as prior period, unchanged from 0000858877-16-000109:mdna:139]

[0000858877-16-000123:mdna:144]
[same as prior period, unchanged from 0000858877-16-000109:mdna:190]

[0000858877-16-000123:mdna:145]
[same as prior period, unchanged from 0000858877-16-000109:mdna:191]

[0000858877-16-000123:mdna:146]
|  |  | Three Months Ended |
|  |  | October 29, 2016 |  | October 24, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,963 |  |  | $ | 1,844 |  |  | $ | 119 |  |  | 6.5 | % |
| Percentage of service revenue |  | 64.4 | % |  | 65.0 | % |  |  |  |  |
| EMEA |  | 649 |  |  | 611 |  |  | 38 |  |  | 6.2 | % |
| Percentage of service revenue |  | 21.3 | % |  | 21.5 | % |  |  |  |  |
| APJC |  | 438 |  |  | 383 |  |  | 55 |  |  | 14.4 | % |
| Percentage of service revenue |  | 14.3 | % |  | 13.5 | % |  |  |  |  |
| Total |  | $ | 3,050 |  |  | $ | 2,838 |  |  | $ | 212 |  |  | 7.5 | % |

[0000858877-16-000123:mdna:147]
Three Months Ended October 29, 2016 Compared with Three Months Ended October 24, 2015

[0000858877-16-000123:mdna:148]
Service revenue grew 7%, with solid growth across all of our geographic segments. Worldwide technical support services revenue increased 10% and worldwide advanced services revenue was flat. Technical support services revenue experienced solid growth across all geographic segments. Renewals and technical support service contract initiations associated with product sales provided an installed base of equipment being serviced which, in concert with new service offerings, were the primary factors driving the revenue increases. Advanced services revenue, which relates to professional services for specific customer network needs, decreased slightly in Americas and EMEA geographic segments and was flat in the APJC segment.

[0000858877-16-000123:mdna:149]
[same as prior period, unchanged from 0000858877-16-000109:mdna:200]

[0000858877-16-000123:mdna:150]
[same as prior period, unchanged from 0000858877-16-000109:mdna:201]

[0000858877-16-000123:mdna:151]
|  |  | Three Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |
|  |  | October 29, 2016 |  | October 24, 2015 |  | October 29, 2016 |  | October 24, 2015 |
| Gross margin: |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,899 |  |  | $ | 5,991 |  |  | 63.4 | % |  | 60.9 | % |
| Service |  | 1,985 |  |  | 1,841 |  |  | 65.1 | % |  | 64.9 | % |
| Total |  | $ | 7,884 |  |  | $ | 7,832 |  |  | 63.8 | % |  | 61.8 | % |

[0000858877-16-000123:mdna:152]
[same as prior period, unchanged from 0000858877-16-000109:mdna:146]

[0000858877-16-000123:mdna:153]
[same as prior period, unchanged from 0000858877-16-000109:mdna:147]

[0000858877-16-000123:mdna:154]
[same as prior period, unchanged from 0000858877-16-000109:mdna:203]

[0000858877-16-000123:mdna:155]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the first quarter of fiscal 2017 as compared with the corresponding prior year period:

[0000858877-16-000123:mdna:156]
|  |  | Product Gross Margin Percentage |
| Fiscal 2016 |  | 60.9 | % |
| Productivity (1) |  | 2.2 | % |
| SP Video CPE Business impact |  | 2.2 | % |
| Amortization of purchased intangible assets |  | 0.1 | % |
| Product pricing |  | (1.4 | )% |
| Mix of products sold |  | (0.5 | )% |
| Other |  | (0.1 | )% |
| Fiscal 2017 |  | 63.4 | % |

[0000858877-16-000123:mdna:157]
(1) Productivity includes overall manufacturing-related costs, such as component costs, warranty expense, provision for inventory, freight, logistics, shipment volume, and other items not categorized elsewhere.

[0000858877-16-000123:mdna:158]
Three Months Ended October 29, 2016 Compared with Three Months Ended October 24, 2015

[0000858877-16-000123:mdna:159]
Product gross margin increased by 2.5 percentage points as compared with the first quarter of fiscal 2016. The increase in product gross margin was due to productivity improvements and the sale during the second quarter of fiscal 2016 of our lower margin SP Video CPE Business. Productivity improvements were driven by value engineering efforts; favorable component pricing; and continued operational efficiency in manufacturing operations. Value engineering is the process by which production costs are reduced through component redesign, board configuration, test processes, and transformation processes. The various factors contributing to the product gross margin increase were partially offset by unfavorable impacts from product pricing, which were driven by typical market factors and impacted each of our geographic segments and customer markets. Product gross margin was also impacted to a lesser extent by an unfavorable mix of products sold. The mix impact was driven by negative mix impact within Cisco Unified Computing System products and an unfavorable mix within our NGN routing products.

[0000858877-16-000123:mdna:160]
[same as prior period, unchanged from 0000858877-16-000109:mdna:214]

[0000858877-16-000123:mdna:161]
Three Months Ended October 29, 2016 Compared with Three Months Ended October 24, 2015

[0000858877-16-000123:mdna:162]
Our service gross margin percentage increased by 0.2 percentage points as compared with the first quarter of fiscal 2016 due to higher sales volume, favorable mix and, to a lesser extent, lower share-based compensation expense. These benefits to service gross margin were partially offset by increased headcount-related costs and increased outside services costs.

[0000858877-16-000123:mdna:163]
[same as prior period, unchanged from 0000858877-16-000109:mdna:217]

[0000858877-16-000123:mdna:164]
54

[0000858877-16-000123:mdna:165]
[same as prior period, unchanged from 0000858877-16-000109:mdna:163]

[0000858877-16-000123:mdna:166]
[same as prior period, unchanged from 0000858877-16-000109:mdna:164]

[0000858877-16-000123:mdna:167]
[same as prior period, unchanged from 0000858877-16-000109:mdna:222]

[0000858877-16-000123:mdna:168]
[same as prior period, unchanged from 0000858877-16-000109:mdna:223]

[0000858877-16-000123:mdna:169]
|  |  | Three Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |
|  |  | October 29, 2016 |  | October 24, 2015 |  | October 29, 2016 |  | October 24, 2015 |
| Gross margin: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 4,833 |  |  | $ | 4,943 |  |  | 64.9 | % |  | 63.4 | % |
| EMEA |  | 2,013 |  |  | 1,989 |  |  | 66.8 | % |  | 64.3 | % |
| APJC |  | 1,204 |  |  | 1,078 |  |  | 63.5 | % |  | 60.0 | % |
| Segment total |  | 8,050 |  |  | 8,010 |  |  | 65.2 | % |  | 63.2 | % |
| Unallocated corporate items (1) |  | (166 | ) |  | (178 | ) |  |  |  |  |
| Total |  | $ | 7,884 |  |  | $ | 7,832 |  |  | 63.8 | % |  | 61.8 | % |

[0000858877-16-000123:mdna:170]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-16-000123:mdna:171]
Three Months Ended October 29, 2016 Compared with Three Months Ended October 24, 2015

[0000858877-16-000123:mdna:172]
The Americas segment experienced a gross margin percentage increase due primarily to the sale of the lower margin SP Video CPE Business and, to a lesser extent, productivity improvements.  Partially offsetting these favorable impacts to gross margin were negative impacts from pricing and an unfavorable product mix. The unfavorable mix of products sold was driven by an unfavorable mix within our NGN routing products, decreased revenue from our higher margin Switching products, and a negative mix impact within Cisco Unified Computing System products.

[0000858877-16-000123:mdna:173]
The gross margin percentage increase in our EMEA segment was due primarily to the impact of productivity improvements in this geographic segment and the sale of the SP Video CPE Business, partially offset by negative impacts from pricing.

[0000858877-16-000123:mdna:174]
Our APJC segment gross margin percentage increased primarily due to productivity improvements and, to a lesser extent, favorable impacts from pricing, partially offset by unfavorable mix. The mix impact was driven primarily by an increase in revenue from our relatively lower margin Cisco Unified Computing System products in this geographic segment. Higher service gross margin also contributed to the increase in the overall gross margin in this geographic segment.

[0000858877-16-000123:mdna:175]
The gross margin percentage for a particular segment may fluctuate, and period-to-period changes in such percentages may or may not be indicative of a trend for that segment.

[0000858877-16-000123:mdna:176]
[same as prior period, unchanged from 0000858877-16-000109:mdna:122]

[0000858877-16-000123:mdna:177]
[same as prior period, unchanged from 0000858877-16-000109:mdna:188]

[0000858877-16-000123:mdna:178]
[same as prior period, unchanged from 0000858877-16-000109:mdna:189]

[0000858877-16-000123:mdna:179]
[same as prior period, unchanged from 0000858877-16-000109:mdna:244]

[0000858877-16-000123:mdna:180]
[same as prior period, unchanged from 0000858877-16-000109:mdna:245]

[0000858877-16-000123:mdna:181]
|  |  | Three Months Ended |
|  |  | October 29, 2016 |  | October 24, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Research and development |  | $ | 1,545 |  |  | $ | 1,560 |  |  | $ | (15 | ) |  | (1.0 | )% |
| Percentage of revenue |  | 12.5 | % |  | 12.3 | % |  |  |  |  |
| Sales and marketing |  | 2,418 |  |  | 2,443 |  |  | (25 | ) |  | (1.0 | )% |
| Percentage of revenue |  | 19.6 | % |  | 19.3 | % |  |  |  |  |
| General and administrative |  | 555 |  |  | 539 |  |  | 16 |  |  | 3.0 | % |
| Percentage of revenue |  | 4.5 | % |  | 4.3 | % |  |  |  |  |
| Total |  | $ | 4,518 |  |  | $ | 4,542 |  |  | $ | (24 | ) |  | (0.5 | )% |
| Percentage of revenue |  | 36.6 | % |  | 35.8 | % |  |  |  |  |

[0000858877-16-000123:mdna:182]
[same as prior period, unchanged from 0000858877-16-000109:mdna:248]

[0000858877-16-000123:mdna:183]
R&D expenses decreased for the first quarter of fiscal 2017, as compared with the first quarter of fiscal 2016, primarily due to lower discretionary spending, lower acquisition-related costs and lower contracted services, partially offset by higher headcount-related expenses and higher share-based compensation expense.

[0000858877-16-000123:mdna:184]
[same as prior period, unchanged from 0000858877-16-000109:mdna:250]

[0000858877-16-000123:mdna:185]
[same as prior period, unchanged from 0000858877-16-000109:mdna:251]

[0000858877-16-000123:mdna:186]
Sales and marketing expenses decreased for the first quarter of fiscal 2017, compared with the first quarter of fiscal 2016, due to lower headcount-related expenses, lower contracted services and lower acquisition-related costs. Lower headcount related expenses were due to efficiencies related to our restructuring actions.

[0000858877-16-000123:mdna:187]
[same as prior period, unchanged from 0000858877-16-000109:mdna:253]

[0000858877-16-000123:mdna:188]
G&A expenses increased in the first quarter of fiscal 2017, as compared with the first quarter of fiscal 2016, due to higher headcount-related expenses, higher discretionary spending and higher contracted services, partially offset by lower share-based compensation expense and lower acquisition-related costs.

[0000858877-16-000123:mdna:189]
[same as prior period, unchanged from 0000858877-16-000109:mdna:256]

[0000858877-16-000123:mdna:190]
In the first quarter of fiscal 2017, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $33 million, or approximately 0.7%, compared with the first quarter of fiscal 2016.

[0000858877-16-000123:mdna:191]
[same as prior period, unchanged from 0000858877-16-000109:mdna:261]

[0000858877-16-000123:mdna:192]
Our headcount as of October 29, 2016 was 72,385, which represents a decrease of 1,326 employees in the first quarter of fiscal 2017 as compared with the total headcount at the end of fiscal 2016. The decrease was  driven by our fiscal 2017 restructuring actions that began in the first quarter, partially offset by additional headcount primarily from our investments in key growth areas.

[0000858877-16-000123:mdna:193]
[same as prior period, unchanged from 0000858877-16-000109:mdna:198]

[0000858877-16-000123:mdna:194]
[same as prior period, unchanged from 0000858877-16-000109:mdna:199]

[0000858877-16-000123:mdna:195]
[same as prior period, unchanged from 0000858877-16-000109:mdna:263]

[0000858877-16-000123:mdna:196]
[same as prior period, unchanged from 0000858877-16-000109:mdna:264]

[0000858877-16-000123:mdna:197]
|  |  | Three Months Ended |
|  |  | October 29, 2016 |  | October 24, 2015 |
| Cost of sales—product |  | $ | 21 |  |  | $ | 13 |  |
| Cost of sales—service |  | 33 |  |  | 38 |  |
| Share-based compensation expense in cost of sales |  | 54 |  |  | 51 |  |
| Research and development |  | 126 |  |  | 114 |  |
| Sales and marketing |  | 140 |  |  | 139 |  |
| General and administrative |  | 49 |  |  | 57 |  |
| Restructuring and other charges |  | 3 |  |  | 15 |  |
| Share-based compensation expense in operating expenses |  | 318 |  |  | 325 |  |
| Total share-based compensation expense |  | $ | 372 |  |  | $ | 376 |  |

[0000858877-16-000123:mdna:198]
The decrease in share-based compensation expense in the first quarter of fiscal 2017, as compared with the first quarter of fiscal 2016, was due primarily to lower expense associated with accelerated and modified awards, partially offset by higher expense related to equity awards assumed with respect to our recent acquisitions.

[0000858877-16-000123:mdna:199]
[same as prior period, unchanged from 0000858877-16-000109:mdna:267]

[0000858877-16-000123:mdna:200]
The following table presents the amortization of purchased intangible assets including impairment charges related to purchased intangible assets (in millions):

[0000858877-16-000123:mdna:201]
|  |  | Three Months Ended |
|  |  | October 29, 2016 |  | October 24, 2015 |
| Amortization of purchased intangible assets: |  |  |  |  |
| Cost of sales |  | $ | 129 |  |  | $ | 146 |  |
| Operating expenses: |  |  |  |  |
| Amortization of purchased intangible assets |  | 78 |  |  | 69 |  |
| Restructuring and other charges |  | 38 |  |  | — |  |
| Total |  | $ | 245 |  |  | $ | 215 |  |

[0000858877-16-000123:mdna:202]
Amortization of purchased intangible assets increased for the first quarter of fiscal 2017, as compared with the first quarter of fiscal 2016, due to higher impairment charges and amortization of purchased intangible assets from our recent acquisitions, partially offset by certain purchased intangible assets having become fully amortized or impaired.

[0000858877-16-000123:mdna:203]
[same as prior period, unchanged from 0000858877-16-000109:mdna:274]

[0000858877-16-000123:mdna:204]
In the first quarter of fiscal 2017, we incurred restructuring and other charges of approximately $411 million which were related primarily to employee severance charges for employees impacted by the restructuring action announced in August 2016. Our aggregate pretax estimated charges pursuant to the restructuring action are expected to be approximately $700 million, and we expect the restructuring action to be substantially completed by the end of fiscal 2017. We expect to reinvest substantially all of the cost savings from the restructuring action in our key priority areas such as security, IoT, collaboration, next generation data center and cloud.  As a result, the overall cost savings from the restructuring action are not expected to be material for future periods.

[0000858877-16-000123:mdna:205]
In the first quarter of fiscal 2016, we incurred restructuring and other charges of approximately $141 million, net of $1 million credit to cost of sales, which were related primarily to employee severance charges for employees impacted by the restructuring action announced in August 2014. We completed this restructuring action in fiscal 2016.

[0000858877-16-000123:mdna:206]
57

[0000858877-16-000123:mdna:207]
[same as prior period, unchanged from 0000858877-16-000109:mdna:209]

[0000858877-16-000123:mdna:208]
[same as prior period, unchanged from 0000858877-16-000109:mdna:210]

[0000858877-16-000123:mdna:209]
[same as prior period, unchanged from 0000858877-16-000109:mdna:277]

[0000858877-16-000123:mdna:210]
[same as prior period, unchanged from 0000858877-16-000109:mdna:278]

[0000858877-16-000123:mdna:211]
|  |  | Three Months Ended |
|  |  | October 29, 2016 |  | October 24, 2015 |
| Operating income |  | $ | 2,877 |  |  | $ | 3,079 |  |
| Operating income as a percentage of revenue |  | 23.3 | % |  | 24.3 | % |

[0000858877-16-000123:mdna:212]
For the first quarter of fiscal 2017, as compared with the first quarter of fiscal 2016, operating income decreased by 7%, and as a percentage of revenue operating income decreased by 1.0 percentage points. These decreases were primarily due to the increase in restructuring and other charges related to the restructuring action announced in August 2016.

[0000858877-16-000123:mdna:213]
[same as prior period, unchanged from 0000858877-16-000109:mdna:282]

[0000858877-16-000123:mdna:214]
[same as prior period, unchanged from 0000858877-16-000109:mdna:283]

[0000858877-16-000123:mdna:215]
|  |  | Three Months Ended |
|  |  | October 29, 2016 |  | October 24, 2015 |  | Variancein Dollars |
| Interest income |  | $ | 295 |  |  | $ | 225 |  |  | $ | 70 |  |
| Interest expense |  | (198 | ) |  | (159 | ) |  | (39 | ) |
| Interest income (expense), net |  | $ | 97 |  |  | $ | 66 |  |  | $ | 31 |  |

[0000858877-16-000123:mdna:216]
For the first quarter of fiscal 2017, interest income increased compared with the first quarter of fiscal 2016, driven by an increase in our portfolio of cash, cash equivalents, and fixed income investments as well as higher yields on our portfolio.  Interest expense in the first quarter of fiscal 2017, as compared with the first quarter of fiscal 2016, was higher driven by higher average debt balances and the impact of higher effective interest rates on floating-rate senior notes and on interest rate swaps associated with fixed-rate senior notes.

[0000858877-16-000123:mdna:217]
[same as prior period, unchanged from 0000858877-16-000109:mdna:288]

[0000858877-16-000123:mdna:218]
|  |  | Three Months Ended |
|  |  | October 29, 2016 |  | October 24, 2015 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |
| Publicly traded equity securities |  | $ | 5 |  |  | $ | (9 | ) |  | $ | 14 |  |
| Fixed income securities |  | 10 |  |  | 8 |  |  | 2 |  |
| Total available-for-sale investments |  | 15 |  |  | (1 | ) |  | 16 |  |
| Privately held companies |  | (50 | ) |  | (11 | ) |  | (39 | ) |
| Net gains (losses) on investments |  | (35 | ) |  | (12 | ) |  | (23 | ) |
| Other gains (losses), net |  | 14 |  |  | 4 |  |  | 10 |  |
| Other income (loss), net |  | $ | (21 | ) |  | $ | (8 | ) |  | $ | (13 | ) |

[0000858877-16-000123:mdna:219]
The change in total net gains (losses) on available-for-sale investments in the first quarter of fiscal 2017, as compared with the first quarter of fiscal 2016, was primarily attributable to higher realized gains on publicly traded equity securities in the current periods as a result of market conditions and the timing of sales of these securities.

[0000858877-16-000123:mdna:220]
The change in net gains (losses) on investments in privately held companies for the first quarter of fiscal 2017, as compared with the first quarter of fiscal 2016, was primarily due to higher impairment charges on investments in privately held companies.

[0000858877-16-000123:mdna:221]
The change in other gains (losses), net in the first quarter of fiscal 2017, as compared with the first quarter of fiscal 2016, was driven by net favorable foreign exchange impacts and lower donation expenses, partially offset by impacts from equity derivatives.

[0000858877-16-000123:mdna:222]
[same as prior period, unchanged from 0000858877-16-000109:mdna:220]

[0000858877-16-000123:mdna:223]
[same as prior period, unchanged from 0000858877-16-000109:mdna:221]

[0000858877-16-000123:mdna:224]
[same as prior period, unchanged from 0000858877-16-000109:mdna:293]

[0000858877-16-000123:mdna:225]
[same as prior period, unchanged from 0000858877-16-000109:mdna:294]

[0000858877-16-000123:mdna:226]
The provision for income taxes resulted in an effective tax rate of 21.4% for the first quarter of fiscal 2017 compared with 22.5% for the first quarter of fiscal 2016, a net 1.1 percentage point decrease in the effective tax rate for the first quarter of fiscal 2017 as compared with the first quarter of fiscal 2016. The decrease in the effective tax rates was primarily due to reinstatement of the U.S. federal research and development (“R&D”) tax credit on December 18, 2015 and increase in foreign income taxed at other than U.S. tax rates.

[0000858877-16-000123:mdna:227]
[same as prior period, unchanged from 0000858877-16-000109:mdna:187]

[0000858877-16-000123:mdna:228]
[same as prior period, unchanged from 0000858877-16-000109:mdna:235]

[0000858877-16-000123:mdna:229]
[same as prior period, unchanged from 0000858877-16-000109:mdna:236]

[0000858877-16-000123:mdna:230]
[same as prior period, unchanged from 0000858877-16-000109:mdna:299]

[0000858877-16-000123:mdna:231]
[same as prior period, unchanged from 0000858877-16-000109:mdna:300]

[0000858877-16-000123:mdna:232]
[same as prior period, unchanged from 0000858877-16-000109:mdna:301]

[0000858877-16-000123:mdna:233]
[same as prior period, unchanged from 0000858877-16-000109:mdna:302]

[0000858877-16-000123:mdna:234]
|  | October 29, 2016 |  | July 30, 2016 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 8,583 |  |  | $ | 7,631 |  |  | $ | 952 |  |
| Fixed income securities | 60,868 |  |  | 56,621 |  |  | 4,247 |  |
| Publicly traded equity securities | 1,517 |  |  | 1,504 |  |  | 13 |  |
| Total | $ | 70,968 |  |  | $ | 65,756 |  |  | $ | 5,212 |  |

[0000858877-16-000123:mdna:235]
The net increase in cash and cash equivalents and investments in the first quarter of fiscal 2017 was primarily driven by an increase in debt of $6.2 billion and cash provided by operating activities of $2.7 billion. These sources of cash were partially offset by cash returned to shareholders in the form of cash dividends of $1.3 billion and repurchase of common stock of $1.0 billion under the stock repurchase program, the timing of settlements and change in fair value of investments of $0.6 billion, capital expenditures of $0.3 billion and net cash paid for acquisitions of $0.3 billion.

[0000858877-16-000123:mdna:236]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $60.6 billion and $59.8 billion as of October 29, 2016 and July 30, 2016, respectively. Under current tax laws and regulations, if these assets were to be distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. The balance of cash and cash equivalents and investments available in the United States as of October 29, 2016 and July 30, 2016 was $10.4 billion and $5.9 billion, respectively.

[0000858877-16-000123:mdna:237]
[same as prior period, unchanged from 0000858877-16-000109:mdna:306]

[0000858877-16-000123:mdna:238]
[same as prior period, unchanged from 0000858877-16-000109:mdna:307]

[0000858877-16-000123:mdna:239]
[same as prior period, unchanged from 0000858877-16-000109:mdna:308]

[0000858877-16-000123:mdna:240]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Net cash provided by operating activities | $ | 2,730 |  |  | $ | 2,766 |  |
| Acquisition of property and equipment | (275 | ) |  | (262 | ) |
| Free cash flow | $ | 2,455 |  |  | $ | 2,504 |  |

[0000858877-16-000123:mdna:241]
[same as prior period, unchanged from 0000858877-16-000109:mdna:310]

[0000858877-16-000123:mdna:242]
[same as prior period, unchanged from 0000858877-16-000109:mdna:197]

[0000858877-16-000123:mdna:243]
[same as prior period, unchanged from 0000858877-16-000109:mdna:242]

[0000858877-16-000123:mdna:244]
[same as prior period, unchanged from 0000858877-16-000109:mdna:243]

[0000858877-16-000123:mdna:245]
[same as prior period, unchanged from 0000858877-16-000109:mdna:313]

[0000858877-16-000123:mdna:246]
[same as prior period, unchanged from 0000858877-16-000109:mdna:314]

[0000858877-16-000123:mdna:247]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2017 |  |  |  |  |  |  |  |  |  |  |  |  |
| October 29, 2016 |  | $ | 0.26 |  |  | $ | 1,308 |  |  | 32 |  |  | $ | 31.12 |  |  | $ | 1,001 |  |  | $ | 2,309 |  |
| Fiscal 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 30, 2016 |  | $ | 0.26 |  |  | $ | 1,309 |  |  | 28 |  |  | $ | 28.70 |  |  | $ | 800 |  |  | $ | 2,109 |  |
| April 30, 2016 |  | $ | 0.26 |  |  | $ | 1,308 |  |  | 27 |  |  | $ | 24.08 |  |  | $ | 649 |  |  | $ | 1,957 |  |
| January 23, 2016 |  | $ | 0.21 |  |  | $ | 1,065 |  |  | 48 |  |  | $ | 26.12 |  |  | $ | 1,262 |  |  | $ | 2,327 |  |
| October 24, 2015 |  | $ | 0.21 |  |  | $ | 1,068 |  |  | 45 |  |  | $ | 26.83 |  |  | $ | 1,207 |  |  | $ | 2,275 |  |

[0000858877-16-000123:mdna:248]
Any future dividends are subject to the approval of our Board of Directors.

[0000858877-16-000123:mdna:249]
Accounts Receivable, Net The following table summarizes our accounts receivable, net (in millions):

[0000858877-16-000123:mdna:250]
|  | October 29, 2016 |  | July 30, 2016 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,805 |  |  | $ | 5,847 |  |  | $ | (1,042 | ) |

[0000858877-16-000123:mdna:251]
Our accounts receivable net, as of October 29, 2016 decreased by approximately 18%, as compared with the end of fiscal 2016, primarily due to the timing of service billings.

[0000858877-16-000123:mdna:252]
[same as prior period, unchanged from 0000858877-16-000109:mdna:320]

[0000858877-16-000123:mdna:253]
|  | October 29, 2016 |  | July 30, 2016 |  | Increase (Decrease) |
| Inventories | $ | 1,176 |  |  | $ | 1,217 |  |  | $ | (41 | ) |
| Annualized inventory turns | 14.9 |  |  | 14.6 |  |  | 0.3 |  |
| Purchase commitments with contract manufacturers and suppliers | $ | 3,920 |  |  | $ | 3,896 |  |  | $ | 24 |  |

[0000858877-16-000123:mdna:254]
Inventory as of October 29, 2016 decreased by 3% from our inventory balance at the end of fiscal 2016, and for the same period purchase commitments with contract manufacturers and suppliers increased by approximately 1%.  On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers were flat compared with the end of fiscal 2016. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-16-000123:mdna:255]
[same as prior period, unchanged from 0000858877-16-000109:mdna:326]

[0000858877-16-000123:mdna:256]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing

[0000858877-16-000123:mdna:257]
[same as prior period, unchanged from 0000858877-16-000109:mdna:259]

[0000858877-16-000123:mdna:258]
[same as prior period, unchanged from 0000858877-16-000109:mdna:260]

[0000858877-16-000123:mdna:259]
manufacturing capacity. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity.

[0000858877-16-000123:mdna:260]
[same as prior period, unchanged from 0000858877-16-000109:mdna:328]

[0000858877-16-000123:mdna:261]
[same as prior period, unchanged from 0000858877-16-000109:mdna:329]

[0000858877-16-000123:mdna:262]
Financing Receivables and Guarantees We measure our net balance sheet exposure position related to our financing receivables and financing guarantees by reducing the total of gross financing receivables and financing guarantees by the associated allowances for credit loss and deferred revenue. As of October 29, 2016, our net balance sheet exposure position related to financing receivables and financing guarantees was as follows (in millions):

[0000858877-16-000123:mdna:263]
|  | FINANCING RECEIVABLES |  | FINANCING GUARANTEES |  |  |
| October 29, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |  | Channel Partner |  | End-User Customers |  | Total |  | TOTAL |
| Financing receivables and guarantees | $ | 3,399 |  |  | $ | 2,236 |  |  | $ | 4,239 |  |  | $ | 9,874 |  |  | $ | 248 |  |  | $ | 88 |  |  | $ | 336 |  |  | $ | 10,210 |  |
| Unearned income | (163 | ) |  | — |  |  | — |  |  | (163 | ) |  | — |  |  | — |  |  | — |  |  | (163 | ) |
| Allowance for credit loss | (227 | ) |  | (111 | ) |  | (48 | ) |  | (386 | ) |  | — |  |  | — |  |  | — |  |  | (386 | ) |
| Deferred revenue | (7 | ) |  | (15 | ) |  | (2,371 | ) |  | (2,393 | ) |  | (77 | ) |  | (70 | ) |  | (147 | ) |  | (2,540 | ) |
| Net balance sheet exposure | $ | 3,002 |  |  | $ | 2,110 |  |  | $ | 1,820 |  |  | $ | 6,932 |  |  | $ | 171 |  |  | $ | 18 |  |  | $ | 189 |  |  | $ | 7,121 |  |

[0000858877-16-000123:mdna:264]
Financing Receivables  Financing receivables less unearned income increased by 10% compared with the end of fiscal 2016. The change was due to a 26% increase in financed service contracts and other and a 5% increase in loan receivables partially offset by a 2% decrease in lease receivables. We provide financing to certain end-user customers and channel partners to enable sales of our products, services, and networking solutions. These financing arrangements include leases, financed service contracts, and loans. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Lease receivables include sales-type and direct-financing leases. We also provide certain qualified customers financing for long-term service contracts, which primarily relate to technical support services. Our loan financing arrangements may include not only financing the acquisition of our products and services but also providing additional funds for other costs associated with network installation and integration of our products and services. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-16-000123:mdna:265]
[same as prior period, unchanged from 0000858877-16-000109:mdna:333]

[0000858877-16-000123:mdna:266]
The volume of channel partner financing was $6.9 billion for each of the first quarters of fiscal 2017 and 2016. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.0 billion and $1.1 billion as of October 29, 2016 and July 30, 2016, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed.

[0000858877-16-000123:mdna:267]
62

[0000858877-16-000123:mdna:268]
[same as prior period, unchanged from 0000858877-16-000109:mdna:272]

[0000858877-16-000123:mdna:269]
[same as prior period, unchanged from 0000858877-16-000109:mdna:273]

[0000858877-16-000123:mdna:270]
[same as prior period, unchanged from 0000858877-16-000109:mdna:338]

[0000858877-16-000123:mdna:271]
[same as prior period, unchanged from 0000858877-16-000109:mdna:339]

[0000858877-16-000123:mdna:272]
[same as prior period, unchanged from 0000858877-16-000109:mdna:340]

[0000858877-16-000123:mdna:273]
|  | Maturity Date |  | October 29, 2016 |  | July 30, 2016 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | $ | 1,000 |  |  | $ | 1,000 |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1,000 |  |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 900 |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 500 |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (1) | 500 |  |  | — |  |
| Fixed-rate notes: |  |  |  |  |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 2,400 |  |
| 3.15% | March 14, 2017 |  | 750 |  |  | 750 |  |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1,250 |  |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1,600 |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1,000 |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |
| 1.40% | September 20, 2019 | (1) | 1,500 |  |  | — |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 1.85% | September 20, 2021 | (1) | 2,000 |  |  | — |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 | (1) | 750 |  |  | — |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 | (1) | 1,500 |  |  | — |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 34,650 |  |  | $ | 28,400 |  |

[0000858877-16-000123:mdna:274]
(1) In September 2016, we issued senior notes with an aggregate principal amount of $6.25 billion

[0000858877-16-000123:mdna:275]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of October 29, 2016.

[0000858877-16-000123:mdna:276]
Other Debt  Other debt  as of July 30, 2016 included secured borrowings associated with customer financing arrangements. The amount of borrowings outstanding under these arrangements was $1 million as of July 30, 2016.

[0000858877-16-000123:mdna:277]
[same as prior period, unchanged from 0000858877-16-000109:mdna:286]

[0000858877-16-000123:mdna:278]
[same as prior period, unchanged from 0000858877-16-000109:mdna:287]

[0000858877-16-000123:mdna:279]
Commercial Paper  We established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of each of October 29, 2016 and July 30, 2016.

[0000858877-16-000123:mdna:280]
Credit Facility On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. The credit agreement requires that we comply with certain covenants, including that it maintains an interest coverage ratio as defined in the agreement.

[0000858877-16-000123:mdna:281]
We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. We were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-16-000123:mdna:282]
[same as prior period, unchanged from 0000858877-16-000109:mdna:352]

[0000858877-16-000123:mdna:283]
|  | October 29, 2016 |  | July 30, 2016 |  | Increase (Decrease) |
| Service | $ | 10,424 |  |  | $ | 10,621 |  |  | $ | (197 | ) |
| Product: |  |  |  |  |  |  |
| Deferred revenue related to recurring software and subscription businesses | 3,801 |  |  | 3,308 |  |  | 493 |  |
| Deferred revenue related to two-tier distributors | 439 |  |  | 377 |  |  | 62 |  |
| Other product deferred revenue | 2,287 |  |  | 2,166 |  |  | 121 |  |
| Total product deferred revenue | 6,527 |  |  | 5,851 |  |  | 676 |  |
| Total | $ | 16,951 |  |  | $ | 16,472 |  |  | $ | 479 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 10,215 |  |  | $ | 10,155 |  |  | $ | 60 |  |
| Noncurrent | 6,736 |  |  | 6,317 |  |  | 419 |  |
| Total | $ | 16,951 |  |  | $ | 16,472 |  |  | $ | 479 |  |

[0000858877-16-000123:mdna:284]
Deferred product revenue increased 12% primarily due to increased deferrals related to recurring software and subscription businesses and, to a lesser extent, higher deferred revenue related to two-tier distributors. The portion of product deferred revenue related to recurring software and subscription businesses grew 48% on a year over year to $3.8 billion as of October 29, 2016. Collaboration, Security, and Wireless are the key product category contributors of this product deferred revenue growth. The 2% decrease in deferred service revenue at the end of the first quarter of fiscal 2017, as compared with the end of fiscal 2016, reflected a typical seasonal decline as we tend to experience higher service initiations as well as renewals in our fiscal fourth quarter.

[0000858877-16-000123:mdna:285]
[same as prior period, unchanged from 0000858877-16-000109:mdna:355]

[0000858877-16-000123:mdna:286]
[same as prior period, unchanged from 0000858877-16-000109:mdna:356]

[0000858877-16-000123:mdna:287]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Australia, Belgium, Canada, China, Germany, India, Israel, Japan, the Netherlands and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of October 29, 2016 were $1.1 billion.

[0000858877-16-000123:mdna:288]
[same as prior period, unchanged from 0000858877-16-000109:mdna:358]

[0000858877-16-000123:mdna:289]
[same as prior period, unchanged from 0000858877-16-000109:mdna:359]

[0000858877-16-000123:mdna:290]
[same as prior period, unchanged from 0000858877-16-000109:mdna:297]

[0000858877-16-000123:mdna:291]
[same as prior period, unchanged from 0000858877-16-000109:mdna:298]

[0000858877-16-000123:mdna:292]
Insieme Networks, Inc.  In the third quarter of fiscal 2012, we made an investment in Insieme, an early stage company focused on research and development in the data center market. As set forth in the agreement between Cisco and Insieme, this investment included $100 million of funding and a license to certain of our technology. Immediately prior to the call option exercise and acquisition described below, we owned approximately 83% of Insieme as a result of these investments and have consolidated the results of Insieme in our Consolidated Financial Statements. In connection with this investment, we entered into a put/call option agreement that provided us with the right to purchase the remaining interests in Insieme. In addition, the noncontrolling interest holders could require us to purchase their shares upon the occurrence of certain events.

[0000858877-16-000123:mdna:293]
During the first quarter of fiscal 2014, we exercised our call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. During the three months ended October 29, 2016 and October 24, 2015, we recorded compensation expense of $20 million and $51 million, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting will result in additional compensation expense in future periods. Based on the terms of the agreement, we have determined that the maximum amount that could be recorded as compensation expense by us is approximately $834 million (which includes the $803 million that has been expensed to date), net of forfeitures. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $323 million and $291 million during the first quarters of fiscal 2017 and fiscal 2016, respectively.  As of October 29, 2016, we paid a total of approximately $712 million pursuant to these two milestone payments.

[0000858877-16-000123:mdna:294]
[same as prior period, unchanged from 0000858877-16-000109:mdna:367]

[0000858877-16-000123:mdna:295]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have investments in privately held companies including venture funds and provide financing to certain customers. Certain of these investments are considered to be variable interest entities.

[0000858877-16-000123:mdna:296]
We also have certain funding commitments primarily related to these variable interest entities, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $189 million as of October 29, 2016.

[0000858877-16-000123:mdna:297]
[same as prior period, unchanged from 0000858877-16-000109:mdna:369]

[0000858877-16-000123:mdna:298]
[same as prior period, unchanged from 0000858877-16-000109:mdna:370]

[0000858877-16-000123:mdna:299]
[same as prior period, unchanged from 0000858877-16-000109:mdna:371]

[0000858877-16-000123:mdna:300]
We periodically engage in securities lending activities with certain of our available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the three months ended October 29, 2016 and October 24, 2015 was $1.5 billion and $0.5 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of October 29, 2016 and July 30, 2016, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-16-000123:mdna:301]
[same as prior period, unchanged from 0000858877-16-000109:mdna:373]

[0000858877-16-000123:mdna:302]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.

[0000858877-16-000123:mdna:303]
65
