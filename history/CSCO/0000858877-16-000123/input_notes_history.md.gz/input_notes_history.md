# CSCO note change history — 0000858877-16-000109 → 0000858877-16-000123


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-11-22):
[0000858877-16-000123:note_history:1]
Commitments and Contingencies
  (was, 2016-05-24, similarity 0.8788):
[0000858877-16-000109:note_history:1]
| 12. | Commitments and Contingencies |

- changed (2016-11-22):
[0000858877-16-000123:note_history:2]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Australia, Belgium, Canada, China, Germany, India, Israel, Japan, the Netherlands and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of October 29, 2016 are as follows (in millions):
  (was, 2016-05-24, similarity 0.9393):
[0000858877-16-000109:note_history:2]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 30, 2016 are as follows (in millions):

- changed (2016-11-22):
[0000858877-16-000123:note_history:3]
| Fiscal Year | Amount |
| 2017 (remaining nine months) | $ | 280 |  |
| 2018 | 292 |  |
| 2019 | 178 |  |
| 2020 | 128 |  |
| 2021 | 76 |  |
| Thereafter | 162 |  |
| Total | $ | 1,116 |  |
  (was, 2016-05-24, similarity 0.9772):
[0000858877-16-000109:note_history:3]
| Fiscal Year | Amount |
| 2016 (remaining three months) | $ | 95 |  |
| 2017 | 288 |  |
| 2018 | 220 |  |
| 2019 | 130 |  |
| 2020 | 106 |  |
| Thereafter | 229 |  |
| Total | $ | 1,068 |  |

- changed (2016-11-22):
[0000858877-16-000123:note_history:4]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of October 29, 2016 and July 30, 2016, the Company had total purchase commitments for inventory of $3,920 million and $3,896 million, respectively.
  (was, 2016-05-24, similarity 0.994):
[0000858877-16-000109:note_history:4]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of April 30, 2016 and July 25, 2015, the Company had total purchase commitments for inventory of $3,794 million and $4,078 million, respectively.

- changed (2016-11-22):
[0000858877-16-000123:note_history:5]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of October 29, 2016 and July 30, 2016, the liability for these purchase commitments was $161 million and $159 million, respectively, and was included in other current liabilities.
  (was, 2016-05-24, similarity 0.9848):
[0000858877-16-000109:note_history:5]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of April 30, 2016 and July 25, 2015, the liability for these purchase commitments was $160 million and $156 million, respectively, and was included in other current liabilities.

- changed (2016-11-22):
[0000858877-16-000123:note_history:6]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Compensation expense related to acquisitions | $ | 64 |  |  | $ | 73 |  |
  (was, 2016-05-24, similarity 0.7134):
[0000858877-16-000109:note_history:6]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Compensation expense related to acquisitions | $ | 68 |  |  | $ | 72 |  |  | $ | 212 |  |  | $ | 264 |  |

- changed (2016-11-22):
[0000858877-16-000123:note_history:7]
As of October 29, 2016, the Company estimated that future cash compensation expense of up to $299 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.
  (was, 2016-05-24, similarity 0.9823):
[0000858877-16-000109:note_history:7]
As of April 30, 2016, the Company estimated that future cash compensation expense of up to $400 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.

- changed (2016-11-22):
[0000858877-16-000123:note_history:8]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology. Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and has consolidated the results of Insieme in its Consolidated Financial Statements. In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.
  (was, 2016-05-24, similarity 0.9978):
[0000858877-16-000109:note_history:8]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology. Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements. In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

- changed (2016-11-22):
[0000858877-16-000123:note_history:9]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $20 million and $51 million during the three months ended October 29, 2016 and October 24, 2015, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting will result in additional compensation expense in future periods. Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $834 million (which includes the $803 million that has been expensed to date), net of forfeitures. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $323 million and $291 million during the first quarters of fiscal 2017 and fiscal 2016, respectively.  As of October 29, 2016, the Company paid a total of approximately $712 million pursuant to these two milestone payments.
  (was, 2016-05-24, similarity 0.7822):
[0000858877-16-000109:note_history:9]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $35 million and $51 million during the three months ended April 30, 2016 and April 25, 2015, respectively, and $136 million and $155 million during the nine months ended April 30, 2016 and April 25, 2015, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $839 million (which includes the $759 million that has been expensed to date), net of forfeitures.

- added (2016-11-22):
[0000858877-16-000123:note_history:10]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Balance at beginning of period | $ | 414 |  |  | $ | 449 |  |
| Provisions for warranty issued | 176 |  |  | 160 |  |
| Adjustments for pre-existing warranties | — |  |  | (10 | ) |
| Settlements | (177 | ) |  | (166 | ) |
| Balance at end of period | $ | 413 |  |  | $ | 433 |  |

- changed (2016-11-22):
[0000858877-16-000123:note_history:11]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.9 billion for each of the three months ended October 29, 2016 and October 24, 2015. The balance of the channel partner financing subject to guarantees was $1.0 billion and $1.1 billion as of October 29, 2016 and July 30, 2016, respectively.
  (was, 2016-05-24, similarity 0.8286):
[0000858877-16-000109:note_history:11]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.4 billion and $6.3 billion for the three months ended April 30, 2016 and April 25, 2015, respectively, and was $19.8 billion and $19.0 billion for the nine months ended April 30, 2016 and April 25, 2015, respectively. The balance of the channel partner financing subject to guarantees was $1.0 billion and $1.2 billion as of April 30, 2016 and July 25, 2015, respectively.

- changed (2016-11-22):
[0000858877-16-000123:note_history:12]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $6 million and $23 million for the three months ended October 29, 2016 and October 24, 2015, respectively.
  (was, 2016-05-24, similarity 0.8569):
[0000858877-16-000109:note_history:12]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $18 million and $22 million for the three months ended April 30, 2016 and April 25, 2015, respectively, and was $57 million and $87 million for the nine months ended April 30, 2016 and April 25, 2015, respectively.

- changed (2016-11-22):
[0000858877-16-000123:note_history:13]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 29, 2016 and July 30, 2016, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2016-05-24, similarity 0.9807):
[0000858877-16-000109:note_history:13]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 30, 2016 and July 25, 2015, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2016-11-22):
[0000858877-16-000123:note_history:14]
|  | October 29, 2016 |  | July 30, 2016 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 248 |  |  | $ | 281 |  |
| End user | 88 |  |  | 96 |  |
| Total | $ | 336 |  |  | $ | 377 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (77 | ) |  | $ | (85 | ) |
| End user | (70 | ) |  | (76 | ) |
| Total | $ | (147 | ) |  | $ | (161 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 189 |  |  | $ | 216 |  |
  (was, 2016-05-24, similarity 0.9885):
[0000858877-16-000109:note_history:14]
|  | April 30, 2016 |  | July 25, 2015 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 228 |  |  | $ | 288 |  |
| End user | 104 |  |  | 129 |  |
| Total | $ | 332 |  |  | $ | 417 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (98 | ) |  | $ | (127 | ) |
| End user | (82 | ) |  | (107 | ) |
| Total | $ | (180 | ) |  | $ | (234 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 152 |  |  | $ | 183 |  |

- changed (2016-11-22):
[0000858877-16-000123:note_history:15]
Other Guarantees   The Company’s other guarantee arrangements as of October 29, 2016 and July 30, 2016 that were subject to recognition and disclosure requirements were not material.
  (was, 2016-05-24, similarity 0.9704):
[0000858877-16-000109:note_history:15]
Other Guarantees   The Company’s other guarantee arrangements as of April 30, 2016 and July 25, 2015 that were subject to recognition and disclosure requirements were not material.

- changed (2016-11-22):
[0000858877-16-000123:note_history:16]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components were widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products were beyond the Company's warranty terms, the Company has been proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014. During fiscal 2016 and 2015, adjustments to product cost of sales of $74 million and $164 million, respectively, were recorded to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products. The supplier component remediation liability as of October 29, 2016 and July 30, 2016 was $265 million and $276 million, respectively.
  (was, 2016-05-24, similarity 0.9878):
[0000858877-16-000109:note_history:16]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components were widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event. Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products was beyond the Company's warranty terms, the Company has been proactively working with customers on mitigation. Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014. During the third quarters of fiscal 2016 and 2015, adjustments to product cost of sales of $74 million and $164 million, respectively, were recorded to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products. The supplier component remediation liability as of April 30, 2016 and July 25, 2015 was $286 million and $408 million, respectively.

- added (2016-11-22):
[0000858877-16-000123:note_history:17]
The Company has been asked to provide indemnification in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. in Kansas and Delaware. Sprint alleges that the service provider customers infringe Sprint’s patents by offering VoIP telephone services utilizing products provided by the Company and other manufacturers. Sprint seeks monetary damages. Sprint’s Kansas cases were stayed pending resolution of Sprint’s appeal of the Delaware court’s judgment that certain Sprint patents were invalid. The Court of Appeals for the Federal Circuit overturned the Delaware court’s judgment on September 23, 2016. As a result, Sprint’s Kansas cases are set for trial on February 13 and March 6, 2017 against Time Warner Cable and Comcast respectively, and its Delaware case was reset for trial on November 6, 2017 against Cox Communications.

- added (2016-11-22):
[0000858877-16-000123:note_history:18]
The Company believes that the service providers have strong defenses and arguments that the Company's products do not infringe the patents and/or that Sprint's patents are invalid.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should Sprint prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products. At this time, the Company does not anticipate that the outcome of the matters would be material.

- changed (2016-11-22):
[0000858877-16-000123:note_history:19]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.
  (was, 2016-05-24, similarity 0.8019):
[0000858877-16-000109:note_history:19]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. In the first quarter of fiscal 2013, the Brazilian federal tax authorities asserted an additional claim against the Company’s Brazilian subsidiary based on a theory of joint liability with respect to an alleged underpayment of income taxes, social taxes, interest, and penalties by a Brazilian distributor.  This claim was dismissed on its merits during the third quarter of fiscal 2016.

- changed (2016-11-22):
[0000858877-16-000123:note_history:20]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $253 million for the alleged evasion of import and other taxes, $1.3 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of October 29, 2016. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.
  (was, 2016-05-24, similarity 0.991):
[0000858877-16-000109:note_history:20]
The asserted claims by Brazilian federal tax authorities which remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $233 million for the alleged evasion of import and other taxes, $1.2 billion for interest, and $1.1 billion for various penalties, all determined using an exchange rate as of April 30, 2016. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

- added (2016-11-22):
[0000858877-16-000123:note_history:21]
Backflip Software     Backflip Software, Inc. brought claims against the Company as disclosed in the Company’s Form 10-K filed on September 8, 2016. Prior to the commencement of trial set for September 12, 2016, the parties executed a Settlement and Release Agreement resolving all aspects of the case and the Court dismissed the case in its entirety on October 17, 2016. The settlement did not have a material impact on the Company's results of operations.

- added (2016-11-22):
[0000858877-16-000123:note_history:22]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against the Company in the U.S. District Court for the District of Delaware, accusing Cisco products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. On May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million, and the Court will decide whether to award enhanced damages and attorneys’ fees and whether an ongoing royalty should be awarded through the expiration of the patents in 2018. In June 2016, the Company filed post-trial motions. The Company also intends to pursue an appeal to the United States Court of Appeals for the Federal Circuit on various grounds. The Company believes it has strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, the Company does not expect it to be material.

- added (2016-11-22):
[0000858877-16-000123:note_history:23]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, Cisco petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art. On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that Cisco would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. The PTAB held a hearing to review the Company's petition on November 15, 2016 and we are awaiting a decision. The district court issued an order on June 28, 2016 staying the district court case pending the final written decision from the PTAB. The Company believes it has strong arguments that the Company's products do not infringe and the patent is invalid. If the Company does not prevail and a jury were to find that the Company's AnyConnect products infringe, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding patent litigation processes, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

- added (2016-11-22):
[0000858877-16-000123:note_history:24]
Kangtega     Cisco Systems GmbH (“Cisco GmbH”) is subject to patent claims by Kangtega GmbH (“Kangtega”), instituted on June 6, 2013, alleging that Cisco GmbH infringes in Germany a European Patent by marketing in Germany network intrusion-detection (or firewall) products known as the “ASA” firewall offering. On April 29, 2014, the Mannheim Regional Court dismissed the infringement action, finding no infringement by Cisco GmbH of the asserted patent. On November 23, 2016, a court of appeal in Germany (Oberlandesgericht Karlsruhe) will hear an appeal of that judgment. The matter had been set for July 13, 2016, but that hearing was postponed until November 23, 2016. In addition, on July 25, 2016 the German Federal Patent Court issued its grounds for a decision denying Cisco’s nullity request with respect to the Kangtega patent. The nullity decision, which is open to appeal, regards patent validity and was issued in a separate proceeding from the infringement action in which Cisco has previously prevailed. In the infringement action, Kangtega seeks an injunction which would prohibit Cisco GmbH’s activities in Germany with respect to the ASA firewall offering unless Cisco GmbH takes a license from Kangtega or the Company redesigns the products.  The Company believes that the lower court ruling in Cisco's favor in the infringement action was correct and should be affirmed.  The Company does not anticipate that the outcome of the case would be material. However, due to uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the outcome of the appeal and any subsequent appeals to a higher court at this time.

- changed (2016-11-22):
[0000858877-16-000123:note_history:25]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.
  (was, 2016-05-24, similarity 0.9434):
[0000858877-16-000109:note_history:25]
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows.

- removed (2016-11-22):
[0000858877-16-000109:note_history:26]
The former noncontrolling interest holders earned the maximum amount related to the first milestone payment and were paid   approximately $375 million for a portion of this amount during the nine months ended April 30, 2016. The balance of the first milestone payment is expected to be paid primarily through the end of fiscal 2016. The second milestone payment, to the extent earned, is expected to be paid primarily during the first half of fiscal 2017.

- removed (2016-11-22):
[0000858877-16-000109:note_history:27]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $199 million and $205 million as of April 30, 2016 and July 25, 2015, respectively.

- removed (2016-11-22):
[0000858877-16-000109:note_history:28]
|  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |
| Balance at beginning of period | $ | 449 |  |  | $ | 446 |  |
| Provision for warranties issued | 512 |  |  | 517 |  |
| Payments | (524 | ) |  | (512 | ) |
| Divestitures | (28 | ) |  | — |  |
| Balance at end of period | $ | 409 |  |  | $ | 451 |  |

- removed (2016-11-22):
[0000858877-16-000109:note_history:29]
The Company is providing such indemnifications, among other cases, in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) now pending in Kansas and Delaware. Sprint alleges that the service provider customers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers. Sprint seeks monetary damages. Sprint’s cases in Kansas include claims against Comcast and Time Warner Cable, and the case in Delaware for which the Company is providing indemnification involves Cox Communications. On May 15, 2015, the judge in Sprint's Delaware action against Cox ruled invalid six of the asserted patents and a final judgment was entered on August 27, 2015, of invalidity, which Sprint appealed on October 1, 2015. In light of the invalidity rulings against Sprint in Delaware, the judge in Sprint’s Kansas actions stayed the Kansas actions until resolution of Sprint's appeal from the Delaware action. On March 21, 2016, the judge in Sprint's Delaware action also granted a partial summary judgment for Cox, finding that Cox does not literally infringe five of the remaining patents Sprint has asserted against Cox.  Additionally, Comcast has also won a judgment of non-infringement, now being appealed by Sprint, in a separate case brought against it by Sprint in Delaware.

- removed (2016-11-22):
[0000858877-16-000109:note_history:30]
The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims and/or that Sprint's patents are invalid. Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. Should the plaintiff prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

- removed (2016-11-22):
[0000858877-16-000109:note_history:31]
Russia and the Commonwealth of Independent States    At the request of the U.S. Securities and Exchange Commission ("SEC") and the U.S. Department of Justice, the Company is conducting an investigation into allegations which the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries. The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the SEC and the Department of Justice. While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows. The countries that are the subject of the investigation collectively comprise less than 2% of the Company’s revenues.

- removed (2016-11-22):
[0000858877-16-000109:note_history:32]
Backflip Software     Backflip Software, Inc. (“Backflip”) has asserted contract, tort, and fraud claims against the Company in Santa Clara County, California Superior Court. The proceeding was instituted on March 5, 2013. Backflip alleges that Cisco conspired with Backflip's then-CEO to allow the Company to access and use Backflip's source code via a pre-existing source code escrow agreement, and that, subsequently, the Company used that source code in violation of trade secret law and the parties' software license agreement. Backflip has also sued the escrow company, NCC Group, Inc., for breach of contract based on the same allegations. Backflip seeks compensatory and punitive damages. Trial is set for September 12, 2016. The Company believes that it has strong arguments that it was entitled to the source code under the parties’ software license agreement. In addition, if the jury were to find for Backflip on some or all of its claims, the Company believes that damages would not be material given the minimal value of Backflip and its intellectual property that the Company is alleged to have misappropriated. However, due to the uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

- removed (2016-11-22):
[0000858877-16-000109:note_history:33]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against the Company in the U.S. District Court for the District of Delaware, accusing Cisco products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and on May 12, 2016 the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million and the Court will decide whether to award enhanced damages and attorneys’ fees and whether an ongoing royalty should be awarded through the expiration of the patents in 2018. In June 2016, the Company plans to file post-trial motions and the Company also intends to pursue an appeal to the United States Court of Appeals for the Federal Circuit on various grounds. The Company believes it has strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, the Company does not expect it to be material.

- removed (2016-11-22):
[0000858877-16-000109:note_history:34]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas.  The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. A trial is set for September 6, 2016. The Company believes it has strong arguments that its products do not infringe and the patent is invalid. If a jury were to find that the Company's AnyConnect products infringe and the patent is not invalid, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding the litigation process, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. The Company also notes that on February 23, 2016, a multi-judge panel of the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office instituted proceedings to review whether the patent SSL has asserted against the Company is valid over prior art. The PTAB found a reasonable likelihood that the Company would prevail in showing that the patent claims are unpatentable. The PTAB has scheduled the hearing on the Company's review petition for November 16, 2016.

- removed (2016-11-22):
[0000858877-16-000109:note_history:35]
Kangtega     Cisco Systems GmbH (“Cisco GmbH”) is subject to patent claims by Kangtega GmbH (“Kangtega”), instituted on June 6, 2013, alleging that Cisco GmbH infringes in Germany a European Patent by marketing, in Germany, network intrusion-detection, or firewall, products known as the “ASA” firewall offering. On April 29, 2014, the Mannheim Regional Court dismissed the infringement action finding no infringement by Cisco GmbH of the asserted patent. On July 13, 2016, a court of appeal in Germany (Oberlandesgericht Karlsruhe) will hear an appeal of that judgment.  Kangtega seeks an injunction which would prohibit Cisco GmbH’s activities in Germany with respect to the ASA firewall offering unless Cisco GmbH takes a license from Kangtega or the Company redesigns the products.  The Company believes that the lower court ruling was correct and should be affirmed.  The Company does not anticipate that the outcome of the case would be material. However, due to uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the outcome of the appeal and any subsequent appeals to a higher court at this time.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2016-11-22):
[0000858877-16-000123:note_history:36]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.

- added (2016-11-22):
[0000858877-16-000123:note_history:37]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-11-22):
[0000858877-16-000123:note_history:38]
Basis of Presentation
  (was, 2016-05-24, similarity 0.84):
[0000858877-16-000109:note_history:38]
| 1. | Basis of Presentation |

- changed (2016-11-22):
[0000858877-16-000123:note_history:39]
The accompanying financial data as of October 29, 2016 and for the three months ended October 29, 2016 and October 24, 2015 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 30, 2016 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 30, 2016.
  (was, 2016-05-24, similarity 0.9103):
[0000858877-16-000109:note_history:39]
The accompanying financial data as of April 30, 2016 and for the three and nine months ended April 30, 2016 and April 25, 2015 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations.  The July 25, 2015 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 25, 2015.

- added (2016-11-22):
[0000858877-16-000123:note_history:40]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 29, 2016; the results of operations, the statements of comprehensive income, the statements of cash flows and equity for the three months ended October 29, 2016 and October 24, 2015 as applicable, have been made. The results of operations for the three months ended October 29, 2016 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2016-11-22):
[0000858877-16-000109:note_history:41]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of April 30, 2016; the results of operations and the statements of comprehensive income for the three and nine months ended April 30, 2016 and April 25, 2015; and the statements of cash flows and equity for the nine months ended April 30, 2016 and April 25, 2015, as applicable, have been made. The results of operations for the three and nine months ended April 30, 2016 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-11-22):
[0000858877-16-000123:note_history:42]
Recent Accounting Pronouncements
  (was, 2016-05-24, similarity 0.8889):
[0000858877-16-000109:note_history:42]
| 2. | Recent Accounting Pronouncements |

- added (2016-11-22):
[0000858877-16-000123:note_history:43]
(a) New Accounting Updates Recently Adopted

- changed (2016-11-22):
[0000858877-16-000123:note_history:44]
Consolidation of Certain Types of Legal Entities  In February 2015, the FASB issued an accounting standard update that changes the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. The accounting standard update became effective for the Company beginning in the first quarter of fiscal 2017. The application of this accounting standard update did not have any impact on the Company's Consolidated Balance Sheet or Statement of Operations upon adoption, but the Company has provided additional disclosures in Note 8 pursuant to this accounting standard update.
  (was, 2016-05-24, similarity 0.6874):
[0000858877-16-000109:note_history:44]
Consolidation of Certain Types of Legal Entities  In February 2015, the FASB issued an accounting standard update that changes the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2017, and early adoption is permitted. The application of this accounting standard update is not expected to have a material impact on the Company's Consolidated Financial Statements.

- changed (2016-11-22):
[0000858877-16-000123:note_history:45]
(b) Recent Accounting Standards or Updates Not Yet Effective
  (was, 2016-05-24, similarity 0.9655):
[0000858877-16-000109:note_history:45]
Recent Accounting Standards or Updates Not Yet Effective

- changed (2016-11-22):
[0000858877-16-000123:note_history:46]
Revenue Recognition  In May 2014, the Financial Accounting Standards Board ("FASB") issued an accounting standard update related to revenue from contracts with customers, which, along with amendments issued in 2015 and 2016, will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance. The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. This accounting standard update, as amended, will be effective for the Company beginning in the first quarter of fiscal 2019. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective basis"). Early adoption is permitted, but no earlier than fiscal 2018. The Company expects to adopt this accounting standard update on a modified retrospective basis in the first quarter of fiscal 2019, and it is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.
  (was, 2016-05-24, similarity 0.6794):
[0000858877-16-000109:note_history:46]
Revenue Recognition  In May 2014, the Financial Accounting Standards Board (FASB) issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance. The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. This accounting standard update, as amended, will be effective for the Company beginning in the first quarter of fiscal 2019. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. Early adoption is permitted, but no earlier than fiscal 2018. The Company expects to adopt this accounting standard update in the first quarter of fiscal 2019, and it is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- added (2016-11-22):
[0000858877-16-000123:note_history:47]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2021 on a modified retrospective basis, and early adoption in fiscal 2020 is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- added (2016-11-22):
[0000858877-16-000123:note_history:48]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Statements of Cash Flows.

- added (2016-11-22):
[0000858877-16-000123:note_history:49]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- removed (2016-11-22):
[0000858877-16-000109:note_history:50]
Classification of Deferred Taxes  In November 2015, the FASB issued an accounting standard update that requires that all deferred tax assets and liabilities, along with any related valuation allowance, be classified as noncurrent on the balance sheet. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2018, and early adoption is permitted. The accounting standard update is a change in balance sheet presentation only.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-22):
[0000858877-16-000123:note_history:51]
Borrowings
  (was, 2016-05-24, similarity 0.7143):
[0000858877-16-000109:note_history:51]
| 10. | Borrowings |

- changed (2016-11-22):
[0000858877-16-000123:note_history:52]
|  | October 29, 2016 |  | July 30, 2016 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,155 |  |  | 1.08 | % |  | $ | 4,159 |  |  | 0.97 | % |
| Other notes and borrowings | — |  |  | — |  |  | 1 |  |  | 2.08 | % |
| Total short-term debt | $ | 4,155 |  |  |  |  | $ | 4,160 |  |  |  |
  (was, 2016-05-24, similarity 0.6845):
[0000858877-16-000109:note_history:52]
|  | April 30, 2016 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,163 |  |  | 0.94 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other short-term debt | 1 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total | $ | 4,164 |  |  |  |  | $ | 3,897 |  |  |  |

- changed (2016-11-22):
[0000858877-16-000123:note_history:53]
The Company has established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company did not have any commercial paper notes outstanding as of each of October 29, 2016 and July 30, 2016.
  (was, 2016-05-24, similarity 0.7545):
[0000858877-16-000109:note_history:53]
The Company has established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had no commercial paper notes outstanding as of each of April 30, 2016 and July 25, 2015.

- changed (2016-11-22):
[0000858877-16-000123:note_history:54]
|  |  |  | October 29, 2016 |  | July 30, 2016 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | $ | 1,000 |  |  | 1.18% |  | $ | 1,000 |  |  | 1.03% |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1.48% |  | 1,000 |  |  | 1.32% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.23% |  | 900 |  |  | 1.03% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.40% |  | 500 |  |  | 1.23% |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (1) | 500 |  |  | 1.24% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.93% |  | 2,400 |  |  | 0.87% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.42% |  | 750 |  |  | 1.22% |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.78% |  | 2,000 |  |  | 4.76% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.14% |  | 1,750 |  |  | 1.08% |
| 1.40% | September 20, 2019 | (1) | 1,500 |  |  | 1.48% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.29% |  | 2,500 |  |  | 3.25% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.31% |  | 500 |  |  | 1.24% |
| 1.85% | September 20, 2021 | (1) | 2,000 |  |  | 1.90% |  | — |  |  | — |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.56% |  | 500 |  |  | 1.51% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 | (1) | 750 |  |  | 2.27% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.42% |  | 1,000 |  |  | 1.36% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.72% |  | 500 |  |  | 1.67% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 | (1) | 1,500 |  |  | 2.55% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 34,650 |  |  |  |  | 28,400 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (150 | ) |  |  |  | (137 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 289 |  |  |  |  | 379 |  |  |  |
| Total |  |  | $ | 34,789 |  |  |  |  | $ | 28,642 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,155 |  |  |  |  | $ | 4,159 |  |  |  |
| Long-term debt |  |  | 30,634 |  |  |  |  | 24,483 |  |  |  |
| Total |  |  | $ | 34,789 |  |  |  |  | $ | 28,642 |  |  |  |
  (was, 2016-05-24, similarity 0.7179):
[0000858877-16-000109:note_history:54]
|  |  |  | April 30, 2016 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.98% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.60% | February 21, 2018 | (1) | 1,000 |  |  | 1.30% |  | — |  |  | — |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.01% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.20% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | — |  |  | — |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.84% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.20% |  | 750 |  |  | 0.85% |
| 1.40% | February 28, 2018 | (1) | 1,250 |  |  | 1.47% |  | — |  |  | — |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.76% |  | 2,000 |  |  | 4.70% |
| 1.60% | February 28, 2019 | (1) | 1,000 |  |  | 1.67% |  | — |  |  | — |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.05% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.21% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 | (1) | 2,500 |  |  | 2.30% |  | — |  |  | — |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.21% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.46% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 | (1) | 500 |  |  | 2.68% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.33% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.62% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 | (1) | 750 |  |  | 3.01% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  |  |  | 1 |  |  | 2.08% |
| Total |  |  | 28,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (141 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 335 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 28,594 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,163 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 24,431 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 28,594 |  |  |  |  | $ | 25,351 |  |  |  |

- changed (2016-11-22):
[0000858877-16-000123:note_history:55]
(1) In September 2016, the Company issued senior notes for an aggregate principal amount of $6.25 billion.
  (was, 2016-05-24, similarity 0.9442):
[0000858877-16-000109:note_history:55]
(1) In February 2016, the Company issued senior notes for an aggregate principal amount of $7.0 billion.

- changed (2016-11-22):
[0000858877-16-000123:note_history:56]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps in prior periods with an aggregate notional amount of $9.9 billion designated as fair value hedges of certain of its fixed-rate senior notes.  In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate ("LIBOR"). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.  For additional information, see Note 11.
  (was, 2016-05-24, similarity 0.9912):
[0000858877-16-000109:note_history:56]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps in prior periods with an aggregate notional amount of $9.9 billion designated as fair value hedges of certain of its fixed-rate senior notes.  In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.  For additional information, see Note 11.

- changed (2016-11-22):
[0000858877-16-000123:note_history:57]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount, and, if applicable, adjustments related to hedging. Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.
  (was, 2016-05-24, similarity 0.9768):
[0000858877-16-000109:note_history:57]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount and issuance costs, and, if applicable, adjustments related to hedging. Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

- changed (2016-11-22):
[0000858877-16-000123:note_history:58]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 29, 2016, the Company was in compliance with all debt covenants.
  (was, 2016-05-24, similarity 0.9781):
[0000858877-16-000109:note_history:58]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 30, 2016, the Company was in compliance with all debt covenants.

- changed (2016-11-22):
[0000858877-16-000123:note_history:59]
As of October 29, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2016-05-24, similarity 0.9627):
[0000858877-16-000109:note_history:59]
As of April 30, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2016-11-22):
[0000858877-16-000123:note_history:60]
| Fiscal Year | Amount |
| 2017 (remaining nine months) | $ | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| Thereafter | 11,500 |  |
| Total | $ | 34,650 |  |
  (was, 2016-05-24, similarity 0.9707):
[0000858877-16-000109:note_history:60]
| Fiscal Year | Amount |
| 2016 (remaining three months) | $ | — |  |
| 2017 | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 10,250 |  |
| Total | $ | 28,400 |  |

- changed (2016-11-22):
[0000858877-16-000123:note_history:61]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero.  The credit agreement requires the Company to comply with certain covenants, including that it maintains an interest coverage ratio as defined in the agreement.
  (was, 2016-05-24, similarity 0.9995):
[0000858877-16-000109:note_history:61]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero.  The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement.

- changed (2016-11-22):
[0000858877-16-000123:note_history:62]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. As of October 29, 2016, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.
  (was, 2016-05-24, similarity 0.7149):
[0000858877-16-000109:note_history:62]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.  The Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.

- removed (2016-11-22):
[0000858877-16-000109:note_history:63]
On September 3, 2015, the Company repaid an aggregate principal amount of $850 million upon the maturity of its 2015 Floating-Rate Notes.  On February 22, 2016, the Company repaid an aggregate principal amount of $3.0 billion upon the maturity of its 2016 Fixed Rate Notes.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-22):
[0000858877-16-000123:note_history:64]
Investments
  (was, 2016-05-24, similarity 0.7333):
[0000858877-16-000109:note_history:64]
| 8. | Investments |

- changed (2016-11-22):
[0000858877-16-000123:note_history:65]
| October 29, 2016 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 25,905 |  |  | $ | 24 |  |  | $ | (33 | ) |  | $ | 25,896 |  |
| U.S. government agency securities | 2,619 |  |  | 4 |  |  | (1 | ) |  | 2,622 |  |
| Non-U.S. government and agency securities | 1,104 |  |  | 1 |  |  | (1 | ) |  | 1,104 |  |
| Corporate debt securities | 29,046 |  |  | 177 |  |  | (60 | ) |  | 29,163 |  |
| U.S. agency mortgage-backed securities | 2,069 |  |  | 16 |  |  | (2 | ) |  | 2,083 |  |
| Total fixed income securities | 60,743 |  |  | 222 |  |  | (97 | ) |  | 60,868 |  |
| Publicly traded equity securities | 1,225 |  |  | 346 |  |  | (54 | ) |  | 1,517 |  |
| Total (1) | $ | 61,968 |  |  | $ | 568 |  |  | $ | (151 | ) |  | $ | 62,385 |  |
  (was, 2016-05-24, similarity 0.9398):
[0000858877-16-000109:note_history:65]
| July 25, 2015 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 29,904 |  |  | $ | 41 |  |  | $ | (6 | ) |  | $ | 29,939 |  |
| U.S. government agency securities | 3,662 |  |  | 2 |  |  | (1 | ) |  | 3,663 |  |
| Non-U.S. government and agency securities | 1,128 |  |  | 1 |  |  | (1 | ) |  | 1,128 |  |
| Corporate debt securities | 15,802 |  |  | 34 |  |  | (53 | ) |  | 15,783 |  |
| U.S. agency mortgage-backed securities | 1,456 |  |  | 8 |  |  | (3 | ) |  | 1,461 |  |
| Total fixed income securities | 51,952 |  |  | 86 |  |  | (64 | ) |  | 51,974 |  |
| Publicly traded equity securities | 1,092 |  |  | 480 |  |  | (7 | ) |  | 1,565 |  |
| Total | $ | 53,044 |  |  | $ | 566 |  |  | $ | (71 | ) |  | $ | 53,539 |  |

- changed (2016-11-22):
[0000858877-16-000123:note_history:66]
| July 30, 2016 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 26,473 |  |  | $ | 73 |  |  | $ | (2 | ) |  | $ | 26,544 |  |
| U.S. government agency securities | 2,809 |  |  | 8 |  |  | — |  |  | 2,817 |  |
| Non-U.S. government and agency securities | 1,096 |  |  | 4 |  |  | — |  |  | 1,100 |  |
| Corporate debt securities | 24,044 |  |  | 263 |  |  | (15 | ) |  | 24,292 |  |
| U.S. agency mortgage-backed securities | 1,846 |  |  | 22 |  |  | — |  |  | 1,868 |  |
| Total fixed income securities | 56,268 |  |  | 370 |  |  | (17 | ) |  | 56,621 |  |
| Publicly traded equity securities | 1,211 |  |  | 333 |  |  | (40 | ) |  | 1,504 |  |
| Total (1) | $ | 57,479 |  |  | $ | 703 |  |  | $ | (57 | ) |  | $ | 58,125 |  |
  (was, 2016-05-24, similarity 0.9274):
[0000858877-16-000109:note_history:66]
| April 30, 2016 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 24,003 |  |  | $ | 44 |  |  | $ | (3 | ) |  | $ | 24,044 |  |
| U.S. government agency securities | 2,883 |  |  | 5 |  |  | — |  |  | 2,888 |  |
| Non-U.S. government and agency securities | 1,063 |  |  | 2 |  |  | — |  |  | 1,065 |  |
| Corporate debt securities | 23,193 |  |  | 160 |  |  | (37 | ) |  | 23,316 |  |
| U.S. agency mortgage-backed securities | 1,746 |  |  | 16 |  |  | — |  |  | 1,762 |  |
| Total fixed income securities | 52,888 |  |  | 227 |  |  | (40 | ) |  | 53,075 |  |
| Publicly traded equity securities | 1,354 |  |  | 218 |  |  | (30 | ) |  | 1,542 |  |
| Total | $ | 54,242 |  |  | $ | 445 |  |  | $ | (70 | ) |  | $ | 54,617 |  |

- added (2016-11-22):
[0000858877-16-000123:note_history:67]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases were $328 million and $654 million as of October 29, 2016 and July 30, 2016, respectively.

- changed (2016-11-22):
[0000858877-16-000123:note_history:68]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Gross realized gains | $ | 30 |  |  | $ | 35 |  |
| Gross realized losses | (15 | ) |  | (36 | ) |
| Total | $ | 15 |  |  | $ | (1 | ) |
  (was, 2016-05-24, similarity 0.6529):
[0000858877-16-000109:note_history:68]
|  | April 30, 2016 |  | July 25, 2015 |
| Equity method investments | $ | 609 |  |  | $ | 578 |  |
| Cost method investments | 367 |  |  | 319 |  |
| Total | $ | 976 |  |  | $ | 897 |  |

- added (2016-11-22):
[0000858877-16-000123:note_history:69]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Net gains/(losses) on investments in publicly traded equity securities | $ | 5 |  |  | $ | (9 | ) |
| Net gains/(losses) on investments in fixed income securities | 10 |  |  | 8 |  |
| Total | $ | 15 |  |  | $ | (1 | ) |

- changed (2016-11-22):
[0000858877-16-000123:note_history:70]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at October 29, 2016 and July 30, 2016 (in millions):
  (was, 2016-05-24, similarity 0.9709):
[0000858877-16-000109:note_history:70]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at April 30, 2016 and July 25, 2015 (in millions):

- changed (2016-11-22):
[0000858877-16-000123:note_history:71]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 29, 2016 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 11,766 |  |  | $ | (33 | ) |  | $ | 100 |  |  | $ | — |  |  | $ | 11,866 |  |  | $ | (33 | ) |
| U.S. government agency securities | 596 |  |  | (1 | ) |  | — |  |  | — |  |  | 596 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 498 |  |  | (1 | ) |  | — |  |  | — |  |  | 498 |  |  | (1 | ) |
| Corporate debt securities | 9,013 |  |  | (57 | ) |  | 572 |  |  | (3 | ) |  | 9,585 |  |  | (60 | ) |
| U.S. agency mortgage-backed securities | 594 |  |  | (2 | ) |  | — |  |  | — |  |  | 594 |  |  | (2 | ) |
| Total fixed income securities | 22,467 |  |  | (94 | ) |  | 672 |  |  | (3 | ) |  | 23,139 |  |  | (97 | ) |
| Publicly traded equity securities | 291 |  |  | (53 | ) |  | 3 |  |  | (1 | ) |  | 294 |  |  | (54 | ) |
| Total | $ | 22,758 |  |  | $ | (147 | ) |  | $ | 675 |  |  | $ | (4 | ) |  | $ | 23,433 |  |  | $ | (151 | ) |
  (was, 2016-05-24, similarity 0.8702):
[0000858877-16-000109:note_history:71]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 25, 2015 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 6,412 |  |  | $ | (6 | ) |  | $ | — |  |  | $ | — |  |  | $ | 6,412 |  |  | $ | (6 | ) |
| U.S. government agency securities | 1,433 |  |  | (1 | ) |  | — |  |  | — |  |  | 1,433 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 515 |  |  | (1 | ) |  | 4 |  |  | — |  |  | 519 |  |  | (1 | ) |
| Corporate debt securities | 9,552 |  |  | (49 | ) |  | 312 |  |  | (4 | ) |  | 9,864 |  |  | (53 | ) |
| U.S. agency mortgage-backed securities | 579 |  |  | (3 | ) |  | — |  |  | — |  |  | 579 |  |  | (3 | ) |
| Total fixed income securities | 18,491 |  |  | (60 | ) |  | 316 |  |  | (4 | ) |  | 18,807 |  |  | (64 | ) |
| Publicly traded equity securities | 108 |  |  | (7 | ) |  | 2 |  |  | — |  |  | 110 |  |  | (7 | ) |
| Total | $ | 18,599 |  |  | $ | (67 | ) |  | $ | 318 |  |  | $ | (4 | ) |  | $ | 18,917 |  |  | $ | (71 | ) |

- changed (2016-11-22):
[0000858877-16-000123:note_history:72]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 30, 2016 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 2,414 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |  | $ | 2,414 |  |  | $ | (2 | ) |
| U.S. government agency securities | 144 |  |  | — |  |  | — |  |  | — |  |  | 144 |  |  | — |  |
| Non-U.S. government and agency securities | 61 |  |  | — |  |  | — |  |  | — |  |  | 61 |  |  | — |  |
| Corporate debt securities | 2,499 |  |  | (7 | ) |  | 1,208 |  |  | (8 | ) |  | 3,707 |  |  | (15 | ) |
| U.S. agency mortgage-backed securities | 174 |  |  | — |  |  | — |  |  | — |  |  | 174 |  |  | — |  |
| Total fixed income securities | 5,292 |  |  | (9 | ) |  | 1,208 |  |  | (8 | ) |  | 6,500 |  |  | (17 | ) |
| Publicly traded equity securities | 188 |  |  | (40 | ) |  | — |  |  | — |  |  | 188 |  |  | (40 | ) |
| Total | $ | 5,480 |  |  | $ | (49 | ) |  | $ | 1,208 |  |  | $ | (8 | ) |  | $ | 6,688 |  |  | $ | (57 | ) |
  (was, 2016-05-24, similarity 0.9945):
[0000858877-16-000109:note_history:72]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 30, 2016 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 4,315 |  |  | $ | (3 | ) |  | $ | — |  |  | $ | — |  |  | $ | 4,315 |  |  | $ | (3 | ) |
| U.S. government agency securities | 287 |  |  | — |  |  | — |  |  | — |  |  | 287 |  |  | — |  |
| Non-U.S. government and agency securities | 192 |  |  | — |  |  | — |  |  | — |  |  | 192 |  |  | — |  |
| Corporate debt securities | 5,145 |  |  | (27 | ) |  | 1,089 |  |  | (10 | ) |  | 6,234 |  |  | (37 | ) |
| U.S. agency mortgage-backed securities | 137 |  |  | — |  |  | 18 |  |  | — |  |  | 155 |  |  | — |  |
| Total fixed income securities | 10,076 |  |  | (30 | ) |  | 1,107 |  |  | (10 | ) |  | 11,183 |  |  | (40 | ) |
| Publicly traded equity securities | 320 |  |  | (30 | ) |  | — |  |  | — |  |  | 320 |  |  | (30 | ) |
| Total | $ | 10,396 |  |  | $ | (60 | ) |  | $ | 1,107 |  |  | $ | (10 | ) |  | $ | 11,503 |  |  | $ | (70 | ) |

- changed (2016-11-22):
[0000858877-16-000123:note_history:73]
As of October 29, 2016, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of October 29, 2016, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the three months ended October 29, 2016.
  (was, 2016-05-24, similarity 0.9422):
[0000858877-16-000109:note_history:73]
As of April 30, 2016, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of April 30, 2016, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the nine months ended April 30, 2016.

- added (2016-11-22):
[0000858877-16-000123:note_history:74]
The Company has evaluated its publicly traded equity securities as of October 29, 2016 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

- changed (2016-11-22):
[0000858877-16-000123:note_history:75]
The following table summarizes the maturities of the Company’s fixed income securities as of October 29, 2016 (in millions):
  (was, 2016-05-24, similarity 0.9576):
[0000858877-16-000109:note_history:75]
The following table summarizes the maturities of the Company’s fixed income securities as of April 30, 2016 (in millions):

- changed (2016-11-22):
[0000858877-16-000123:note_history:76]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 12,967 |  |  | $ | 12,977 |  |
| Due in 1 to 2 years | 17,042 |  |  | 17,071 |  |
| Due in 2 to 5 years | 25,125 |  |  | 25,230 |  |
| Due after 5 years | 3,540 |  |  | 3,507 |  |
| Mortgage-backed securities with no single maturity | 2,069 |  |  | 2,083 |  |
| Total | $ | 60,743 |  |  | $ | 60,868 |  |
  (was, 2016-05-24, similarity 0.7563):
[0000858877-16-000109:note_history:76]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 13,883 |  |  | $ | 13,890 |  |
| Due in 1 to 2 years | 17,460 |  |  | 17,487 |  |
| Due in 2 to 5 years | 19,610 |  |  | 19,745 |  |
| Due after 5 years | 1,935 |  |  | 1,953 |  |
| Total | $ | 52,888 |  |  | $ | 53,075 |  |

- changed (2016-11-22):
[0000858877-16-000123:note_history:77]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the three months ended October 29, 2016 and October 24, 2015 was $1.5 billion and $0.5 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 29, 2016 and July 30, 2016, the Company had no outstanding securities lending transactions.
  (was, 2016-05-24, similarity 0.9788):
[0000858877-16-000109:note_history:77]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 30, 2016 and April 25, 2015 was $0.9 billion and $0.5 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of April 30, 2016 and July 25, 2015, the Company had no outstanding securities lending transactions.

- changed (2016-11-22):
[0000858877-16-000123:note_history:78]
The carrying value of the Company’s investments in privately held companies was included in other assets.  For such investments that were accounted for under the equity and cost method as of October 29, 2016 and July 30, 2016, the amounts are summarized in the following table (in millions):
  (was, 2016-05-24, similarity 0.9784):
[0000858877-16-000109:note_history:78]
The carrying value of the Company’s investments in privately held companies was included in other assets.  For such investments that were accounted for under the equity and cost method as of April 30, 2016 and July 25, 2015, the amounts are summarized in the following table (in millions):

- added (2016-11-22):
[0000858877-16-000123:note_history:79]
|  | October 29, 2016 |  | July 30, 2016 |
| Equity method investments | $ | 162 |  |  | $ | 174 |  |
| Cost method investments | 829 |  |  | 829 |  |
| Total | $ | 991 |  |  | $ | 1,003 |  |

- changed (2016-11-22):
[0000858877-16-000123:note_history:80]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of October 29, 2016, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.
  (was, 2016-05-24, similarity 0.6978):
[0000858877-16-000109:note_history:80]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings and has determined that as of April 30, 2016, except as disclosed herein, there were no variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

- added (2016-11-22):
[0000858877-16-000123:note_history:81]
As discussed in Note 2, during the first quarter of fiscal 2017, the Company adopted a new accounting standard update related to the consolidation of certain types of legal entities. As of October 29, 2016, the carrying value of the Company's investments in privately held companies was $991 million, of which $609 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $189 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.

- removed (2016-11-22):
[0000858877-16-000109:note_history:82]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Gross realized gains | $ | 68 |  |  | $ | 55 |  |  | $ | 119 |  |  | $ | 168 |  |
| Gross realized losses | (74 | ) |  | (11 | ) |  | (145 | ) |  | (48 | ) |
| Total | $ | (6 | ) |  | $ | 44 |  |  | $ | (26 | ) |  | $ | 120 |  |

- removed (2016-11-22):
[0000858877-16-000109:note_history:83]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Net gains/(losses) on investments in publicly traded equity securities | $ | 25 |  |  | $ | 38 |  |  | $ | 18 |  |  | $ | 94 |  |
| Net gains/(losses) on investments in fixed income securities | (31 | ) |  | 6 |  |  | (44 | ) |  | 26 |  |
| Total | $ | (6 | ) |  | $ | 44 |  |  | $ | (26 | ) |  | $ | 120 |  |

- removed (2016-11-22):
[0000858877-16-000109:note_history:84]
For the three and nine months ended April 30, 2016, the realized net losses related to the Company's available-for-sale investments included impairment charges of zero and $3 million, respectively, for fixed income securities. The impairment charges were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the corresponding periods in fiscal 2015.

- removed (2016-11-22):
[0000858877-16-000109:note_history:85]
The Company has evaluated its publicly traded equity securities as of April 30, 2016 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-22):
[0000858877-16-000123:note_history:86]
|  |  |  | October 29, 2016 |  | July 30, 2016 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | $ | 1,000 |  |  | 1.18% |  | $ | 1,000 |  |  | 1.03% |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1.48% |  | 1,000 |  |  | 1.32% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.23% |  | 900 |  |  | 1.03% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.40% |  | 500 |  |  | 1.23% |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (1) | 500 |  |  | 1.24% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.93% |  | 2,400 |  |  | 0.87% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.42% |  | 750 |  |  | 1.22% |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.78% |  | 2,000 |  |  | 4.76% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.14% |  | 1,750 |  |  | 1.08% |
| 1.40% | September 20, 2019 | (1) | 1,500 |  |  | 1.48% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.29% |  | 2,500 |  |  | 3.25% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.31% |  | 500 |  |  | 1.24% |
| 1.85% | September 20, 2021 | (1) | 2,000 |  |  | 1.90% |  | — |  |  | — |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.56% |  | 500 |  |  | 1.51% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 | (1) | 750 |  |  | 2.27% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.42% |  | 1,000 |  |  | 1.36% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.72% |  | 500 |  |  | 1.67% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 | (1) | 1,500 |  |  | 2.55% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 34,650 |  |  |  |  | 28,400 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (150 | ) |  |  |  | (137 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 289 |  |  |  |  | 379 |  |  |  |
| Total |  |  | $ | 34,789 |  |  |  |  | $ | 28,642 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,155 |  |  |  |  | $ | 4,159 |  |  |  |
| Long-term debt |  |  | 30,634 |  |  |  |  | 24,483 |  |  |  |
| Total |  |  | $ | 34,789 |  |  |  |  | $ | 28,642 |  |  |  |
  (was, 2016-05-24, similarity 0.7179):
[0000858877-16-000109:note_history:86]
|  |  |  | April 30, 2016 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.98% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.60% | February 21, 2018 | (1) | 1,000 |  |  | 1.30% |  | — |  |  | — |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.01% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.20% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | — |  |  | — |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.84% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.20% |  | 750 |  |  | 0.85% |
| 1.40% | February 28, 2018 | (1) | 1,250 |  |  | 1.47% |  | — |  |  | — |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.76% |  | 2,000 |  |  | 4.70% |
| 1.60% | February 28, 2019 | (1) | 1,000 |  |  | 1.67% |  | — |  |  | — |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.05% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.21% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 | (1) | 2,500 |  |  | 2.30% |  | — |  |  | — |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.21% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.46% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 | (1) | 500 |  |  | 2.68% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.33% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.62% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 | (1) | 750 |  |  | 3.01% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  |  |  | 1 |  |  | 2.08% |
| Total |  |  | 28,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (141 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 335 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 28,594 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,163 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 24,431 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 28,594 |  |  |  |  | $ | 25,351 |  |  |  |

- added (2016-11-22):
[0000858877-16-000123:note_history:87]
(1) In September 2016, the Company issued senior notes for an aggregate principal amount of $6.25 billion.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-22):
[0000858877-16-000123:note_history:88]
As of October 29, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2016-05-24, similarity 0.9627):
[0000858877-16-000109:note_history:88]
As of April 30, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2016-11-22):
[0000858877-16-000123:note_history:89]
| Fiscal Year | Amount |
| 2017 (remaining nine months) | $ | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| Thereafter | 11,500 |  |
| Total | $ | 34,650 |  |
  (was, 2016-05-24, similarity 0.9707):
[0000858877-16-000109:note_history:89]
| Fiscal Year | Amount |
| 2016 (remaining three months) | $ | — |  |
| 2017 | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 10,250 |  |
| Total | $ | 28,400 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-22):
[0000858877-16-000123:note_history:90]
|  | October 29, 2016 |  | July 30, 2016 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,155 |  |  | 1.08 | % |  | $ | 4,159 |  |  | 0.97 | % |
| Other notes and borrowings | — |  |  | — |  |  | 1 |  |  | 2.08 | % |
| Total short-term debt | $ | 4,155 |  |  |  |  | $ | 4,160 |  |  |  |
  (was, 2016-05-24, similarity 0.6845):
[0000858877-16-000109:note_history:90]
|  | April 30, 2016 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,163 |  |  | 0.94 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other short-term debt | 1 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total | $ | 4,164 |  |  |  |  | $ | 3,897 |  |  |  |
