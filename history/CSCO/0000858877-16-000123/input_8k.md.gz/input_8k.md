# CSCO 8-K — 0001193125-16-769785 filed 2016-11-16

## item codes, every 8-K on or before 2016-11-22

- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2016-11-22

- none on or before 2016-11-22

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-769785:8k_2_02:1]
EX-99.1
2
d292891dex991.htm
EX-99.1

[0001193125-16-769785:8k_2_02:2]
EX-99.1

[0001193125-16-769785:8k_2_02:3]
Exhibit 99.1

[0001193125-16-769785:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Andrea Duffy |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (646) 295-5241 |  |  |  | 1 (408) 527-7452 |
| anduffy@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-16-769785:8k_2_02:5]
CISCO REPORTS FIRST QUARTER EARNINGS

[0001193125-16-769785:8k_2_02:6]
|  | • |  | Q1 Revenue: $12.4 billion |

[0001193125-16-769785:8k_2_02:7]
|  | • |  | Growth of 1% year over year — Q1 guidance was -1% to 1% growth year over year (normalized to exclude the SP Video CPE Business for Q1 FY2016) |

[0001193125-16-769785:8k_2_02:8]
|  | • |  | Q1 Earnings per Share: $0.46 GAAP; $0.61 non-GAAP |

[0001193125-16-769785:8k_2_02:9]
|  | • |  | Q2 FY 2017 Outlook: |

[0001193125-16-769785:8k_2_02:10]
|  | • |  | Revenue: (2)% to (4)% decline year over year (normalized to exclude the SP Video CPE Business for Q2 FY2016) |

[0001193125-16-769785:8k_2_02:11]
|  | • |  | Earnings per Share: GAAP $0.42 - $0.47; Non-GAAP: $0.55 to $0.57 |

[0001193125-16-769785:8k_2_02:12]
SAN JOSE, Calif. —
November 16, 2016 — Cisco today reported first quarter results for the period ended October 29, 2016. Cisco reported first quarter revenue of $12.4 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.3
billion or $0.46 per share, and non-GAAP net income of $3.1 billion or $0.61 per share.

[0001193125-16-769785:8k_2_02:13]
“We had a good quarter despite a challenging global business
environment and we performed well in our priority areas,” said Chuck Robbins, CEO, Cisco. “We are leading our customers in their digital transition by providing them with highly secure, automated, and intelligent solutions in the ways they
want to consume them. Our innovation pipeline is robust and we are well positioned for the future.”

[0001193125-16-769785:8k_2_02:14]
GAAP Results

[0001193125-16-769785:8k_2_02:15]
|  |  | Q1 FY2017 |  |  | Q1 FY2016 |  |  | Vs. Q1 FY2016 |  |
| Revenue (excluding SP Video CPE Business for all periods) |  | $ | 12.4 billion |  |  | $ | 12.3 billion |  |  |  | 1 | % |
| Revenue (including SP Video CPE Business for all periods) |  | $ | 12.4 billion |  |  | $ | 12.7 billion |  |  |  | (3 | )% |
| Net Income |  | $ | 2.3 billion |  |  | $ | 2.4 billion |  |  |  | (4 | )% |
| Diluted Earnings per Share (EPS) |  | $ | 0.46 |  |  | $ | 0.48 |  |  |  | (4 | )% |

[0001193125-16-769785:8k_2_02:16]
Non-GAAP Results

[0001193125-16-769785:8k_2_02:17]
|  |  | Q1 FY2017 |  |  | Q1 FY2016 |  |  | Vs. Q1 FY2016 |  |
| Net Income (excluding SP Video CPE Business for all periods) |  | $ | 3.1 billion |  |  | $ | 3.0 billion |  |  |  | 3 | % |
| EPS (excluding SP Video CPE Business for all periods) |  | $ | 0.61 |  |  | $ | 0.59 |  |  |  | 3 | % |

[0001193125-16-769785:8k_2_02:18]
Reconciliations between net income, EPS and other measures on a GAAP and non-GAAP basis are provided in the tables located in
the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-16-769785:8k_2_02:19]
“We executed well in Q1 delivering profitable growth, and saw strong
adoption of our subscription-based and software offerings as we transition our business to a more recurring revenue model,” said Kelly Kramer, CFO, Cisco. “We will invest in key growth areas and continue to focus on delivering shareholder
value.”

[0001193125-16-769785:8k_2_02:20]
Financial Summary

[0001193125-16-769785:8k_2_02:21]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-16-769785:8k_2_02:22]
All revenue, non-GAAP, and geographic financial information in the “Q1 FY 2017 Highlights” section is presented excluding the SP Video CPE
Business for prior periods as it was divested during the second quarter of fiscal 2016 on November 20, 2015.

[0001193125-16-769785:8k_2_02:23]
Q1 FY 2017 Highlights

[0001193125-16-769785:8k_2_02:24]
Revenue — Total revenue was $12.4 billion, up 1%, with product revenue down 1% and service revenue up 7%. Revenue by geographic segment was:
Americas down 1%, EMEA flat, and APJC up 6%. Product revenue performance was led by Security and NGN Routing which increased 11% and 6%, respectively. Switching decreased 7%, Collaboration and Data Center each decreased 3%, and Wireless and
Service Provider Video each decreased 2%.

[0001193125-16-769785:8k_2_02:25]
Gross Margin — On a GAAP basis, total gross margin and product gross margin were 63.8% and
63.4%, respectively. The increase in the product gross margin compared with 60.9% in the first quarter of fiscal 2016 was primarily due to continued productivity improvements and the divestiture of the SP Video CPE Business, partially offset by
pricing and to a lesser extent product mix.

[0001193125-16-769785:8k_2_02:26]
Non-GAAP total gross margin and product gross margin were 65.2% and 64.8%, respectively. The increase in
non-GAAP product gross margin compared with 64.5% in the first quarter of fiscal 2016 was primarily due to continued productivity improvements, partially offset by pricing and to a lesser extent product mix.

[0001193125-16-769785:8k_2_02:27]
GAAP service margin was 65.1% and non-GAAP service gross margin was 66.2%.

[0001193125-16-769785:8k_2_02:28]
Total gross margins by geographic segment were: 64.9% for the Americas, 66.8% for EMEA and 63.5% for APJC.

[0001193125-16-769785:8k_2_02:29]
Operating Expenses — On a GAAP basis, operating expenses were $5.0 billion, up 5%, driven in large part by higher restructuring charges in
the first quarter of fiscal 2017. Non-GAAP operating expenses were $4.2 billion, up 1%, and were 33.6% of revenue. Headcount compared with the end of the fourth quarter of fiscal 2016 decreased by 1,326 to 72,385, driven by our fiscal 2017
restructuring actions that began in the first quarter, offset by additional headcount primarily from our investments in key growth areas.

[0001193125-16-769785:8k_2_02:30]
Operating
Income — GAAP operating income was $2.9 billion, down 7%, with GAAP operating margin of 23.3%. Non-GAAP operating income was $3.9 billion, up 1%, with non-GAAP operating margin at 31.6%.

[0001193125-16-769785:8k_2_02:31]
Provision for Income Taxes — The GAAP tax provision rate was 21.4%. The non-GAAP tax provision rate was 22.0%.

[0001193125-16-769785:8k_2_02:32]
Net Income and EPS — On a GAAP basis, net income was $2.3 billion and EPS was $0.46. On a non-GAAP basis, net income was $3.1 billion, an
increase of 3%, and EPS was $0.61, an increase of 3%.

[0001193125-16-769785:8k_2_02:33]
Cash Flow from Operating Activities — was $2.7 billion, a decrease of 1%
compared with $2.8 billion for the first quarter of fiscal 2016.

[0001193125-16-769785:8k_2_02:34]
Balance Sheet and Other Financial Highlights

[0001193125-16-769785:8k_2_02:35]
Cash and Cash Equivalents and Investments — were $71.0 billion at the end of the first quarter of fiscal 2017, compared with $65.8 billion
at the end of fiscal 2016. The total cash and cash equivalents and investments available in the United States at the end of the first quarter of fiscal 2017 were $10.4 billion.

[0001193125-16-769785:8k_2_02:36]
Deferred Revenue — was $17.0 billion, up 12% in total, with deferred product revenue up 19%, driven largely by subscription-based and
software offerings. Deferred service revenue was up 8%. The portion of product deferred revenue related to recurring and subscription businesses grew 48%.

[0001193125-16-769785:8k_2_02:37]
Capital Allocation — In the first quarter of fiscal 2017, Cisco declared and paid a cash dividend of $0.26 per common share, or $1.3
billion. For the first quarter of fiscal 2017, Cisco repurchased approximately 32 million shares of common stock under its stock repurchase program at an average price of $31.12 per share for an aggregate purchase price of $1.0 billion.

[0001193125-16-769785:8k_2_02:38]
As of October 29, 2016, Cisco had repurchased and retired 4.6 billion shares of Cisco common stock at an average price of $21.11 per share for an aggregate
purchase price of approximately $97.6 billion since the inception of the stock repurchase program. The remaining authorized amount for stock repurchases under this program is approximately $14.4 billion with no termination date.

[0001193125-16-769785:8k_2_02:39]
2

[0001193125-16-769785:8k_2_02:40]
Acquisitions

[0001193125-16-769785:8k_2_02:41]
During the first quarter of fiscal 2017, Cisco completed the following acquisitions:

[0001193125-16-769785:8k_2_02:42]
CloudLock, Inc. — a privately held company, to further enhance Cisco’s security portfolio and build on Cisco’s Security
Everywhere strategy, designed to provide protection from the cloud to the network to the endpoint and also aligns with our strategy to deliver more cloud-based subscription services.

[0001193125-16-769785:8k_2_02:43]
ContainerX, Inc. — an early stage company which was focused on developing enterprise-class container
management technology that works across a range of platforms.

[0001193125-16-769785:8k_2_02:44]
Heroik Labs, Inc. — doing business as Worklife. Worklife, a
privately held company, provides software to improve meeting productivity.

[0001193125-16-769785:8k_2_02:45]
Business Outlook for Q2 FY 2017

[0001193125-16-769785:8k_2_02:46]
On November 20, 2015, during the second quarter of fiscal 2016, Cisco completed its divestiture of the SP Video CPE Business. In order to provide a clear view
of Cisco’s continuing expected financial performance, the revenue outlook for the second quarter of fiscal 2017 is normalized to exclude the SP Video CPE Business for the second quarter of fiscal 2016. The corresponding revenue in the
second quarter of fiscal 2016 for the SP Video CPE Business was $93 million.

[0001193125-16-769785:8k_2_02:47]
Cisco expects to achieve the following results for the second quarter of
fiscal 2017:

[0001193125-16-769785:8k_2_02:48]
| Q2 FY 2017 |  |  |
| Revenue (normalized to exclude SP Video CPE Business for Q2 FY2016) |  | (2)% to (4)% decline Y/Y |
| Non-GAAP gross margin rate |  | 63% - 64% |
| Non-GAAP operating margin rate |  | 29% - 30% |
| Non-GAAP tax provision rate |  | 22% |
| Non-GAAP EPS |  | $0.55 - $0.57 |

[0001193125-16-769785:8k_2_02:49]
Cisco estimates that GAAP EPS will be $0.42 to $0.47 which is lower than non-GAAP EPS by $0.10 to $0.13 per share in the
second quarter of fiscal 2017.

[0001193125-16-769785:8k_2_02:50]
A reconciliation between the Business Outlook for Q2 FY 2017 on a GAAP and non-GAAP basis is provided in the table
entitled “GAAP to non-GAAP Business Outlook for Q2 FY 2017” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-16-769785:8k_2_02:51]
Editor’s Notes:

[0001193125-16-769785:8k_2_02:52]
|  | • |  | Q1 fiscal year 2017 conference call to discuss Cisco’s results along with its business outlook will be held on Wednesday, November 16, 2016 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-16-769785:8k_2_02:53]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, November 16, 2016 to 4:00 p.m. Pacific Time, November 23, 2016 at 1-866-439-3743 (United States) or 1-203-369-1047 (international). The replay will also be available via webcast on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-16-769785:8k_2_02:54]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, November 16, 2016. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-16-769785:8k_2_02:55]
3

[0001193125-16-769785:8k_2_02:56]
CISCO SYSTEMS, INC.

[0001193125-16-769785:8k_2_02:57]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-16-769785:8k_2_02:58]
(In millions, except per-share amounts)

[0001193125-16-769785:8k_2_02:59]
(Unaudited)

[0001193125-16-769785:8k_2_02:60]
|  |  | Three Months Ended |  |
|  |  | October 29,2016 |  |  | October 24,2015 |  |
| REVENUE: |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,302 |  |  | $ | 9,844 |  |
| Service |  |  | 3,050 |  |  |  | 2,838 |  |
| Total revenue |  |  | 12,352 |  |  |  | 12,682 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |
| Product |  |  | 3,403 |  |  |  | 3,853 |  |
| Service |  |  | 1,065 |  |  |  | 997 |  |
| Total cost of sales |  |  | 4,468 |  |  |  | 4,850 |  |
| GROSS MARGIN |  |  | 7,884 |  |  |  | 7,832 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,545 |  |  |  | 1,560 |  |
| Sales and marketing |  |  | 2,418 |  |  |  | 2,443 |  |
| General and administrative |  |  | 555 |  |  |  | 539 |  |
| Amortization of purchased intangible assets |  |  | 78 |  |  |  | 69 |  |
| Restructuring and other charges |  |  | 411 |  |  |  | 142 |  |
| Total operating expenses |  |  | 5,007 |  |  |  | 4,753 |  |
| OPERATING INCOME |  |  | 2,877 |  |  |  | 3,079 |  |
| Interest income |  |  | 295 |  |  |  | 225 |  |
| Interest expense |  |  | (198 | ) |  |  | (159 | ) |
| Other income (loss), net |  |  | (21 | ) |  |  | (8 | ) |
| Interest and other income (loss), net |  |  | 76 |  |  |  | 58 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 2,953 |  |  |  | 3,137 |  |
| Provision for income taxes |  |  | 631 |  |  |  | 707 |  |
| NET INCOME |  | $ | 2,322 |  |  | $ | 2,430 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.46 |  |  | $ | 0.48 |  |
| Diluted |  | $ | 0.46 |  |  | $ | 0.48 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,027 |  |  |  | 5,080 |  |
| Diluted |  |  | 5,066 |  |  |  | 5,113 |  |
| Cash dividends declared per common share |  | $ | 0.26 |  |  | $ | 0.21 |  |

[0001193125-16-769785:8k_2_02:61]
The Consolidated Statements of Operations include the results of the SP Video CPE Business prior to its divestiture during the
second quarter of fiscal 2016 on November 20, 2015.

[0001193125-16-769785:8k_2_02:62]
4

[0001193125-16-769785:8k_2_02:63]
CISCO SYSTEMS, INC.

[0001193125-16-769785:8k_2_02:64]
REVENUE BY SEGMENT

[0001193125-16-769785:8k_2_02:65]
(In
millions, except percentages)

[0001193125-16-769785:8k_2_02:66]
|  |  | Three Months Ended October 29, 2016 |  |
|  |  |  |  |  | Excluding SPVideo CPEBusiness |  |  | Including SPVideo CPEBusiness |  |
|  |  | Amount |  |  | Y/Y % |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,443 |  |  |  | (1)% |  |  |  | (4)% |  |
| EMEA |  |  | 3,013 |  |  |  | — % |  |  |  | (3)% |  |
| APJC |  |  | 1,896 |  |  |  | 6% |  |  |  | 6% |  |
| Total |  | $ | 12,352 |  |  |  | 1% |  |  |  | (3)% |  |

[0001193125-16-769785:8k_2_02:67]
During the second quarter of fiscal 2016 on November 20, 2015, Cisco completed its divestiture of the SP Video CPE Business.
SP Video CPE Business revenue for the three months ended October 24, 2015 was $411 million.

[0001193125-16-769785:8k_2_02:68]
CISCO SYSTEMS, INC.

[0001193125-16-769785:8k_2_02:69]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-16-769785:8k_2_02:70]
(In percentages)

[0001193125-16-769785:8k_2_02:71]
|  |  | Three Months EndedOctober 29, 2016 |  |
| Gross Margin Percentage: |  |  |  |  |
| Americas |  |  | 64.9% |  |
| EMEA |  |  | 66.8% |  |
| APJC |  |  | 63.5% |  |

[0001193125-16-769785:8k_2_02:72]
CISCO SYSTEMS, INC.

[0001193125-16-769785:8k_2_02:73]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-16-769785:8k_2_02:74]
(In millions, except percentages)

[0001193125-16-769785:8k_2_02:75]
|  |  | Three Months EndedOctober 29, 2016 |  |
|  |  | Amount |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,716 |  |  |  | (7)% |  |
| NGN Routing |  |  | 2,089 |  |  |  | 6% |  |
| Collaboration |  |  | 1,081 |  |  |  | (3)% |  |
| Data Center |  |  | 834 |  |  |  | (3)% |  |
| Wireless |  |  | 632 |  |  |  | (2)% |  |
| Security |  |  | 540 |  |  |  | 11% |  |
| Service Provider Video(1) |  |  | 271 |  |  |  | (2)% |  |
| Other |  |  | 139 |  |  |  | 88% |  |
| Product - excluding SP Video CPE Business (1) |  |  | 9,302 |  |  |  | (1)% |  |
| Service |  |  | 3,050 |  |  |  | 7% |  |
| Total - excluding SP Video CPE Business (1) |  | $ | 12,352 |  |  |  | 1% |  |

[0001193125-16-769785:8k_2_02:76]
(1) Excludes SP Video CPE Business revenue for all periods presented as
it was divested during the second quarter of fiscal 2016 on November 20, 2015. SP Video CPE Business revenue for the three months ended October 24, 2015 was $411 million.

[0001193125-16-769785:8k_2_02:77]
6

[0001193125-16-769785:8k_2_02:78]
CISCO SYSTEMS, INC.

[0001193125-16-769785:8k_2_02:79]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-16-769785:8k_2_02:80]
(In millions)

[0001193125-16-769785:8k_2_02:81]
(Unaudited)

[0001193125-16-769785:8k_2_02:82]
|  |  | October 29,2016 |  |  | July 30,2016 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 8,583 |  |  | $ | 7,631 |  |
| Investments |  |  | 62,385 |  |  |  | 58,125 |  |
| Accounts receivable, net of allowance for doubtful accounts of $247 at October 29, 2016 and $249 at July 30, 2016 |  |  | 4,805 |  |  |  | 5,847 |  |
| Inventories |  |  | 1,176 |  |  |  | 1,217 |  |
| Financing receivables, net |  |  | 4,541 |  |  |  | 4,272 |  |
| Other current assets |  |  | 1,651 |  |  |  | 1,627 |  |
| Total current assets |  |  | 83,141 |  |  |  | 78,719 |  |
| Property and equipment, net |  |  | 3,499 |  |  |  | 3,506 |  |
| Financing receivables, net |  |  | 4,784 |  |  |  | 4,158 |  |
| Goodwill |  |  | 26,823 |  |  |  | 26,625 |  |
| Purchased intangible assets, net |  |  | 2,297 |  |  |  | 2,501 |  |
| Deferred tax assets |  |  | 4,057 |  |  |  | 4,299 |  |
| Other assets |  |  | 1,686 |  |  |  | 1,844 |  |
| TOTAL ASSETS |  | $ | 126,287 |  |  | $ | 121,652 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 4,155 |  |  | $ | 4,160 |  |
| Accounts payable |  |  | 996 |  |  |  | 1,056 |  |
| Income taxes payable |  |  | 32 |  |  |  | 517 |  |
| Accrued compensation |  |  | 2,619 |  |  |  | 2,951 |  |
| Deferred revenue |  |  | 10,215 |  |  |  | 10,155 |  |
| Other current liabilities |  |  | 5,200 |  |  |  | 6,072 |  |
| Total current liabilities |  |  | 23,217 |  |  |  | 24,911 |  |
| Long-term debt |  |  | 30,634 |  |  |  | 24,483 |  |
| Income taxes payable |  |  | 883 |  |  |  | 925 |  |
| Deferred revenue |  |  | 6,736 |  |  |  | 6,317 |  |
| Other long-term liabilities |  |  | 1,404 |  |  |  | 1,431 |  |
| Total liabilities |  |  | 62,874 |  |  |  | 58,067 |  |
| Total equity |  |  | 63,413 |  |  |  | 63,585 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 126,287 |  |  | $ | 121,652 |  |

[0001193125-16-769785:8k_2_02:83]
7

[0001193125-16-769785:8k_2_02:84]
CISCO SYSTEMS, INC.

[0001193125-16-769785:8k_2_02:85]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-16-769785:8k_2_02:86]
(In millions)

[0001193125-16-769785:8k_2_02:87]
(Unaudited)

[0001193125-16-769785:8k_2_02:88]
|  |  | Three Months Ended |  |
|  |  | October 29,2016 |  |  | October 24,2015 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 2,322 |  |  | $ | 2,430 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 599 |  |  |  | 507 |  |
| Share-based compensation expense |  |  | 372 |  |  |  | 376 |  |
| Provision for receivables |  |  | 15 |  |  |  | 7 |  |
| Deferred income taxes |  |  | 158 |  |  |  | 193 |  |
| Excess tax benefits from share-based compensation |  |  | (91 | ) |  |  | (73 | ) |
| (Gains) losses on investments and other, net |  |  | 32 |  |  |  | (4 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,049 |  |  |  | 631 |  |
| Inventories |  |  | 44 |  |  |  | 130 |  |
| Financing receivables |  |  | (900 | ) |  |  | (206 | ) |
| Other assets |  |  | 191 |  |  |  | 129 |  |
| Accounts payable |  |  | (63 | ) |  |  | 4 |  |
| Income taxes, net |  |  | (440 | ) |  |  | (315 | ) |
| Accrued compensation |  |  | (333 | ) |  |  | (434 | ) |
| Deferred revenue |  |  | 462 |  |  |  | (19 | ) |
| Other liabilities |  |  | (687 | ) |  |  | (590 | ) |
| Net cash provided by operating activities |  |  | 2,730 |  |  |  | 2,766 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (18,667 | ) |  |  | (10,823 | ) |
| Proceeds from sales of investments |  |  | 11,337 |  |  |  | 6,675 |  |
| Proceeds from maturities of investments |  |  | 2,449 |  |  |  | 4,133 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (251 | ) |  |  | (614 | ) |
| Purchases of investments in privately held companies |  |  | (38 | ) |  |  | (78 | ) |
| Return of investments in privately held companies |  |  | 24 |  |  |  | 24 |  |
| Acquisition of property and equipment |  |  | (275 | ) |  |  | (262 | ) |
| Proceeds from sales of property and equipment |  |  | 2 |  |  |  | 6 |  |
| Other |  |  | 23 |  |  |  | (11 | ) |
| Net cash used in investing activities |  |  | (5,396 | ) |  |  | (950 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 88 |  |  |  | 385 |  |
| Repurchases of common stock—repurchase program |  |  | (1,023 | ) |  |  | (1,210 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (401 | ) |  |  | (382 | ) |
| Short-term borrowings, original maturities less than 90 days, net |  |  | — |  |  |  | (4 | ) |
| Issuances of debt |  |  | 6,232 |  |  |  | — |  |
| Repayments of debt |  |  | (1 | ) |  |  | (852 | ) |
| Excess tax benefits from share-based compensation |  |  | 91 |  |  |  | 73 |  |
| Dividends paid |  |  | (1,308 | ) |  |  | (1,068 | ) |
| Other |  |  | (60 | ) |  |  | 123 |  |
| Net cash provided by (used in) financing activities |  |  | 3,618 |  |  |  | (2,935 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 952 |  |  |  | (1,119 | ) |
| Cash and cash equivalents, beginning of period |  |  | 7,631 |  |  |  | 6,877 |  |
| Cash and cash equivalents, end of period |  | $ | 8,583 |  |  | $ | 5,758 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 248 |  |  | $ | 264 |  |
| Cash paid for income taxes, net |  | $ | 913 |  |  | $ | 828 |  |

[0001193125-16-769785:8k_2_02:89]
8

[0001193125-16-769785:8k_2_02:90]
CISCO SYSTEMS, INC.

[0001193125-16-769785:8k_2_02:91]
DEFERRED REVENUE

[0001193125-16-769785:8k_2_02:92]
(In
millions)

[0001193125-16-769785:8k_2_02:93]
|  |  | October 29,2016 |  |  | July 30, 2016 |  |  | October 24,2015 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 10,424 |  |  | $ | 10,621 |  |  | $ | 9,689 |  |
| Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred revenue related to recurring and subscription businesses |  |  | 3,801 |  |  |  | 3,308 |  |  |  | 2,571 |  |
| Deferred revenue related to two-tier distributors |  |  | 439 |  |  |  | 377 |  |  |  | 585 |  |
| Other product deferred revenue |  |  | 2,287 |  |  |  | 2,166 |  |  |  | 2,317 |  |
| Total product deferred revenue |  |  | 6,527 |  |  |  | 5,851 |  |  |  | 5,473 |  |
| Total |  | $ | 16,951 |  |  | $ | 16,472 |  |  | $ | 15,162 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 10,215 |  |  | $ | 10,155 |  |  | $ | 9,821 |  |
| Noncurrent |  |  | 6,736 |  |  |  | 6,317 |  |  |  | 5,341 |  |
| Total |  | $ | 16,951 |  |  | $ | 16,472 |  |  | $ | 15,162 |  |

[0001193125-16-769785:8k_2_02:94]
CISCO SYSTEMS, INC.

[0001193125-16-769785:8k_2_02:95]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-16-769785:8k_2_02:96]
(In millions, except per-share amounts)

[0001193125-16-769785:8k_2_02:97]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| October 29, 2016 |  | $ | 0.26 |  |  | $ | 1,308 |  |  |  | 32 |  |  | $ | 31.12 |  |  | $ | 1,001 |  |  | $ | 2,309 |  |
| Fiscal 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 30, 2016 |  | $ | 0.26 |  |  | $ | 1,309 |  |  |  | 28 |  |  | $ | 28.70 |  |  | $ | 800 |  |  | $ | 2,109 |  |
| April 30, 2016 |  |  | 0.26 |  |  |  | 1,308 |  |  |  | 27 |  |  |  | 24.08 |  |  |  | 649 |  |  |  | 1,957 |  |
| January 23, 2016 |  |  | 0.21 |  |  |  | 1,065 |  |  |  | 48 |  |  |  | 26.12 |  |  |  | 1,262 |  |  |  | 2,327 |  |
| October 24, 2015 |  |  | 0.21 |  |  |  | 1,068 |  |  |  | 45 |  |  |  | 26.83 |  |  |  | 1,207 |  |  |  | 2,275 |  |
| Total |  | $ | 0.94 |  |  | $ | 4,750 |  |  |  | 148 |  |  | $ | 26.45 |  |  | $ | 3,918 |  |  | $ | 8,668 |  |

[0001193125-16-769785:8k_2_02:98]
CISCO SYSTEMS, INC.

[0001193125-16-769785:8k_2_02:99]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-16-769785:8k_2_02:100]
GAAP TO NON-GAAP NET INCOME

[0001193125-16-769785:8k_2_02:101]
(In millions, except per-share amounts)

[0001193125-16-769785:8k_2_02:102]
|  |  | Three Months Ended |  |
|  |  | October 29,2016 |  |  | October 24,2015 |  |
| GAAP net income |  | $ | 2,322 |  |  | $ | 2,430 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 54 |  |  |  | 51 |  |
| Amortization of acquisition-related intangible assets |  |  | 112 |  |  |  | 128 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | (1 | ) |
| Total adjustments to GAAP cost of sales |  |  | 166 |  |  |  | 178 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 315 |  |  |  | 310 |  |
| Amortization of acquisition-related intangible assets |  |  | 78 |  |  |  | 69 |  |
| Acquisition-related/divestiture costs |  |  | 53 |  |  |  | 91 |  |
| Significant asset impairments and restructurings |  |  | 411 |  |  |  | 142 |  |
| Total adjustments to GAAP operating expenses |  |  | 857 |  |  |  | 612 |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 1,023 |  |  |  | 790 |  |
| Income tax effect of non-GAAP adjustments |  |  | (244 | ) |  |  | (196 | ) |
| Non-GAAP net income |  | $ | 3,101 |  |  | $ | 3,024 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.46 |  |  | $ | 0.48 |  |
| Non-GAAP |  | $ | 0.61 |  |  | $ | 0.59 |  |

[0001193125-16-769785:8k_2_02:103]
10

[0001193125-16-769785:8k_2_02:104]
CISCO SYSTEMS, INC.

[0001193125-16-769785:8k_2_02:105]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-16-769785:8k_2_02:106]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, AND NET INCOME

[0001193125-16-769785:8k_2_02:107]
(In millions, except percentages)

[0001193125-16-769785:8k_2_02:108]
|  |  | Three Months Ended October 29, 2016 |  |
|  |  |  | ProductGross Margin |  |  |  | ServiceGross Margin |  |  |  | TotalGross Margin |  |  |  | Operating Expenses |  |  |  | Y/Y |  |  |  | Operating Income |  |  |  | Y/Y |  |  |  | Net Income |  |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,899 |  |  | $ | 1,985 |  |  | $ | 7,884 |  |  | $ | 5,007 |  |  |  | 5% |  |  | $ | 2,877 |  |  |  | (7)% |  |  | $ | 2,322 |  |  |  | (4)% |  |
| % of revenue |  |  | 63.4% |  |  |  | 65.1% |  |  |  | 63.8% |  |  |  | 40.5% |  |  |  |  |  |  |  | 23.3% |  |  |  |  |  |  |  | 18.8% |  |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 21 |  |  |  | 33 |  |  |  | 54 |  |  |  | 315 |  |  |  |  |  |  |  | 369 |  |  |  |  |  |  |  | 369 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 112 |  |  |  | — |  |  |  | 112 |  |  |  | 78 |  |  |  |  |  |  |  | 190 |  |  |  |  |  |  |  | 190 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 53 |  |  |  |  |  |  |  | 53 |  |  |  |  |  |  |  | 53 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 411 |  |  |  |  |  |  |  | 411 |  |  |  |  |  |  |  | 411 |  |  |  |  |  |
| Income tax effect |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (244) |  |  |  |  |  |
| Non-GAAP amount |  | $ | 6,032 |  |  | $ | 2,018 |  |  | $ | 8,050 |  |  | $ | 4,150 |  |  |  | 1% |  |  | $ | 3,900 |  |  |  | 1% |  |  | $ | 3,101 |  |  |  | 3% |  |
| % of revenue |  |  | 64.8% |  |  |  | 66.2% |  |  |  | 65.2% |  |  |  | 33.6% |  |  |  |  |  |  |  | 31.6% |  |  |  |  |  |  |  | 25.1% |  |  |  |  |  |

[0001193125-16-769785:8k_2_02:109]
During the second quarter of fiscal 2016 on November 20, 2015, Cisco completed its divestiture of the SP Video CPE Business.
Accordingly, the non-GAAP growth rates above are normalized to exclude the SP Video CPE Business for the first quarter of fiscal 2016 as detailed in the table below.

[0001193125-16-769785:8k_2_02:110]
|  |  | Three Months EndedOctober 24, 2015 |  |
|  |  | ProductGross Margin |  |  | ServiceGross Margin |  |  | Total Gross Margin |  |  | Operating Expenses |  |  | Operating Income |  |  | Net Income |  |
| GAAP amount |  | $ | 5,991 |  |  | $ | 1,841 |  |  | $ | 7,832 |  |  | $ | 4,753 |  |  | $ | 3,079 |  |  | $ | 2,430 |  |
| % of revenue |  |  | 60.9% |  |  |  | 64.9% |  |  |  | 61.8% |  |  |  | 37.5% |  |  |  | 24.3% |  |  |  | 19.2% |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 13 |  |  |  | 38 |  |  |  | 51 |  |  |  | 310 |  |  |  | 361 |  |  |  | 361 |  |
| Amortization of acquisition-related intangible assets |  |  | 128 |  |  |  | — |  |  |  | 128 |  |  |  | 69 |  |  |  | 197 |  |  |  | 197 |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 91 |  |  |  | 91 |  |  |  | 91 |  |
| Significant asset impairments and restructurings |  |  | (1) |  |  |  | — |  |  |  | (1) |  |  |  | 142 |  |  |  | 141 |  |  |  | 141 |  |
| Income tax effect |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (196) |  |
| Non-GAAP amount |  | $ | 6,131 |  |  | $ | 1,879 |  |  | $ | 8,010 |  |  | $ | 4,141 |  |  | $ | 3,869 |  |  | $ | 3,024 |  |
| Less: SP Video CPE Business |  |  | (43) |  |  |  | — |  |  |  | (43) |  |  |  | (32) |  |  |  | (11) |  |  |  | (8) |  |
| Non-GAAP amount (excluding SP Video CPE Business) |  | $ | 6,088 |  |  | $ | 1,879 |  |  | $ | 7,967 |  |  | $ | 4,109 |  |  | $ | 3,858 |  |  | $ | 3,016 |  |
| % of revenue |  |  | 64.5% |  |  |  | 66.2% |  |  |  | 64.9% |  |  |  | 33.5% |  |  |  | 31.4% |  |  |  | 24.6% |  |

[0001193125-16-769785:8k_2_02:111]
CISCO SYSTEMS, INC.

[0001193125-16-769785:8k_2_02:112]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-16-769785:8k_2_02:113]
EFFECTIVE TAX RATE

[0001193125-16-769785:8k_2_02:114]
(In
percentages)

[0001193125-16-769785:8k_2_02:115]
|  |  | Three Months Ended |  |
|  |  | October 29,2016 |  |  | October 24,2015 |  |
| GAAP effective tax rate |  |  | 21.4 | % |  |  | 22.5 | % |
| Total adjustments to GAAP provision for income taxes |  |  | 0.6 | % |  |  | 0.5 | % |
| Non-GAAP effective tax rate |  |  | 22.0 | % |  |  | 23.0 | % |

[0001193125-16-769785:8k_2_02:116]
FREE CASH FLOW

[0001193125-16-769785:8k_2_02:117]
(In millions)

[0001193125-16-769785:8k_2_02:118]
|  |  | Three Months Ended |  |
|  |  | October 29, 2016 |  |  | July 30, 2016 |  |  | October 24, 2015 |  |
| Net cash provided by operating activities |  | $ | 2,730 |  |  | $ | 3,818 |  |  | $ | 2,766 |  |
| Acquisition of property and equipment |  |  | (275 | ) |  |  | (266 | ) |  |  | (262 | ) |
| Free cash flow |  | $ | 2,455 |  |  | $ | 3,552 |  |  | $ | 2,504 |  |

[0001193125-16-769785:8k_2_02:119]
GAAP TO NON-GAAP BUSINESS OUTLOOK FOR Q2 FY 2017

[0001193125-16-769785:8k_2_02:120]
| Q2 FY 2017 |  | Gross MarginRate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (2) |
| GAAP |  | 61.5% - 62.5% |  | 22.5% - 23.5% |  | 21% |  | $0.42 to $0.47 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3% |  | — |  | $0.05 - $0.06 |
| Amortization of purchased intangible assets and other acquisition-related/divestiture costs |  | 1.0% |  | 2% |  | — |  | $0.03 - $0.04 |
| Restructuring and other charges (1) |  | — |  | 1.5% |  | — |  | $0.02 - $0.03 |
| Income tax effect of non-GAAP adjustments |  | — |  | — |  | 1% |  |  |
| Non-GAAP |  | 63% - 64% |  | 29% - 30% |  | 22% |  | $0.55 - $0.57 |

[0001193125-16-769785:8k_2_02:121]
(1) During the first quarter of fiscal 2017, Cisco recognized pretax
charges of $411 million to the GAAP financial results in relation to the restructuring plan. Cisco currently estimates that it will recognize pretax charges to its GAAP financial results of up to $700 million consisting of severance and other
one-time termination benefits, and other associated costs. These charges are primarily cash-based. Cisco expects that approximately $125 million to $175 million of these charges will be recognized during the second quarter of fiscal 2017
with the remaining amount to be recognized during the rest of the fiscal year.

[0001193125-16-769785:8k_2_02:122]
(2) Estimated
adjustments to GAAP earnings per share are shown after income tax effects.

[0001193125-16-769785:8k_2_02:123]
Except as noted above, this business outlook does not include the effects of
any future acquisitions/divestitures, asset impairments, restructurings and significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-16-769785:8k_2_02:124]
Forward Looking Statements, Non-GAAP Information and Additional Information

[0001193125-16-769785:8k_2_02:125]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP
operating income and margin, non-GAAP effective tax rates, non-GAAP net income per share data, and free cash flow for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a
non-GAAP basis.

[0001193125-16-769785:8k_2_02:126]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted
accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have
limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in
conjunction with the corresponding GAAP measures.

[0001193125-16-769785:8k_2_02:127]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the
corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations. Cisco believes that the
presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because of its
intent to return a stated

[0001193125-16-769785:8k_2_02:128]
13

[0001193125-16-769785:8k_2_02:129]
percentage of free cash flow to shareholders in the form of dividends and stock repurchases. Cisco further regards free cash flow as a useful measure because it reflects cash that can be used to,
among other things, invest in its business, make strategic acquisitions, repurchase common stock and pay dividends on its common stock, after deducting capital investments.

[0001193125-16-769785:8k_2_02:130]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation and other contingencies, significant gains and losses on investments, the income
tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has
excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its
financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-16-769785:8k_2_02:131]
Cisco divested the Customer Premises Equipment portion of the Service Provider Video Connected Devices business (“SP Video CPE Business”) during the
second quarter of fiscal 2016 on November 20, 2015. This release includes, where indicated, financial measures that exclude the SP Video CPE Business. Cisco believes that the presentation of these measures provides useful information to
investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations because the SP Video CPE Business is no longer part of Cisco and will not be part of Cisco on
a go forward basis. Cisco’s management also uses the financial measures excluding the SP Video CPE Business in reviewing the financial results of Cisco.

[0001193125-16-769785:8k_2_02:132]
About Cisco

[0001193125-16-769785:8k_2_02:133]
Cisco (NASDAQ: CSCO) is the worldwide
technology leader that has been making the Internet work since 1984. Our people, products and partners help society securely connect and seize tomorrow’s digital opportunity today. Discover more at thenetwork.cisco.com and follow us on Twitter
at @Cisco.

[0001193125-16-769785:8k_2_02:134]
Copyright © 2016 Cisco and/or its affiliates. All rights reserved. Cisco and the
Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the
property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.
