# CSCO note change history — 0000858877-18-000015 → 0000858877-19-000003


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-02-19):
[0000858877-19-000003:note_history:1]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Australia, Belgium, Canada, China, Germany, India, Japan, Mexico, Poland and the United Kingdom. We also lease equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of January 26, 2019 are as follows (in millions):
  (was, 2018-11-20, similarity 0.9592):
[0000858877-18-000015:note_history:1]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, Germany, India, Israel, Japan, Mexico, Poland and the United Kingdom. We also lease equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of October 27, 2018 are as follows (in millions):

- changed (2019-02-19):
[0000858877-19-000003:note_history:2]
| Fiscal Year | Amount |
| 2019 (remaining six months) | $ | 214 |  |
| 2020 | 331 |  |
| 2021 | 233 |  |
| 2022 | 163 |  |
| 2023 | 106 |  |
| Thereafter | 117 |  |
| Total | $ | 1,164 |  |
  (was, 2018-11-20, similarity 0.9836):
[0000858877-18-000015:note_history:2]
| Fiscal Year | Amount |
| 2019 (remaining nine months) | $ | 312 |  |
| 2020 | 323 |  |
| 2021 | 220 |  |
| 2022 | 152 |  |
| 2023 | 102 |  |
| Thereafter | 116 |  |
| Total | $ | 1,225 |  |

- changed (2019-02-19):
[0000858877-19-000003:note_history:3]
| Commitments by Period | January 26, 2019 |  | July 28, 2018 |
| Less than 1 year | $ | 5,366 |  |  | $ | 5,407 |  |
| 1 to 3 years | 731 |  |  | 710 |  |
| 3 to 5 years | 180 |  |  | 360 |  |
| Total | $ | 6,277 |  |  | $ | 6,477 |  |
  (was, 2018-11-20, similarity 0.9683):
[0000858877-18-000015:note_history:3]
| Commitments by Period | October 27, 2018 |  | July 28, 2018 |
| Less than 1 year | $ | 5,500 |  |  | $ | 5,407 |  |
| 1 to 3 years | 704 |  |  | 710 |  |
| 3 to 5 years | 270 |  |  | 360 |  |
| Total | $ | 6,474 |  |  | $ | 6,477 |  |

- changed (2019-02-19):
[0000858877-19-000003:note_history:4]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 26, 2019 and July 28, 2018, the liability for these purchase commitments was $148 million and $159 million, respectively, and was included in other current liabilities.
  (was, 2018-11-20, similarity 0.9576):
[0000858877-18-000015:note_history:4]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 27, 2018 and July 28, 2018, the liability for these purchase commitments was $150 million and $159 million, respectively, and was included in other current liabilities.

- changed (2019-02-19):
[0000858877-19-000003:note_history:5]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Compensation expense related to acquisitions | $ | 66 |  |  | $ | 46 |  |  | $ | 175 |  |  | $ | 88 |  |
  (was, 2018-11-20, similarity 0.6985):
[0000858877-18-000015:note_history:5]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Compensation expense related to acquisitions | $ | 109 |  |  | $ | 42 |  |

- changed (2019-02-19):
[0000858877-19-000003:note_history:6]
As of January 26, 2019, we estimated that future cash compensation expense of up to $528 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2018-11-20, similarity 0.9669):
[0000858877-18-000015:note_history:6]
As of October 27, 2018, we estimated that future cash compensation expense of up to $585 million may be required to be recognized pursuant to the applicable business combination agreements.

- changed (2019-02-19):
[0000858877-19-000003:note_history:7]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $357 million and $223 million as of January 26, 2019 and July 28, 2018, respectively.
  (was, 2018-11-20, similarity 0.9797):
[0000858877-18-000015:note_history:7]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $378 million and $223 million as of October 27, 2018 and July 28, 2018, respectively.

- changed (2019-02-19):
[0000858877-19-000003:note_history:8]
|  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |
| Balance at beginning of period | $ | 359 |  |  | $ | 407 |  |
| Provisions for warranties issued | 297 |  |  | 287 |  |
| Adjustments for pre-existing warranties | (5 | ) |  | (21 | ) |
| Settlements | (300 | ) |  | (292 | ) |
| Acquisitions and divestitures | (2 | ) |  | — |  |
| Balance at end of period | $ | 349 |  |  | $ | 381 |  |
  (was, 2018-11-20, similarity 0.8316):
[0000858877-18-000015:note_history:8]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Balance at beginning of period | $ | 359 |  |  | $ | 407 |  |
| Provisions for warranties issued | 156 |  |  | 148 |  |
| Adjustments for pre-existing warranties | (3 | ) |  | (12 | ) |
| Settlements | (145 | ) |  | (149 | ) |
| Balance at end of period | $ | 367 |  |  | $ | 394 |  |

- changed (2019-02-19):
[0000858877-19-000003:note_history:9]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.3 billion and $6.9 billion for the second quarter of fiscal 2019 and fiscal 2018, respectively, and was $14.5 billion and $13.6 billion for the first six months of fiscal 2019 and fiscal 2018, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.0 billion as of January 26, 2019 and July 28, 2018, respectively.
  (was, 2018-11-20, similarity 0.8733):
[0000858877-18-000015:note_history:9]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.2 billion and $6.7 billion for the first quarter of fiscal 2019 and fiscal 2018, respectively. The balance of the channel partner financing subject to guarantees was $931 million and $953 million as of October 27, 2018 and July 28, 2018, respectively.

- changed (2019-02-19):
[0000858877-19-000003:note_history:10]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $6 million and $12 million for the second quarter of fiscal 2019 and fiscal 2018, respectively, and was $9 million and $26 million for the first six months of fiscal 2019 and fiscal 2018, respectively.
  (was, 2018-11-20, similarity 0.8827):
[0000858877-18-000015:note_history:10]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $3 million and $14 million for the first quarter of fiscal 2019 and fiscal 2018, respectively.

- changed (2019-02-19):
[0000858877-19-000003:note_history:11]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 26, 2019 and July 28, 2018, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2018-11-20, similarity 0.9776):
[0000858877-18-000015:note_history:11]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 27, 2018 and July 28, 2018, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- added (2019-02-19):
[0000858877-19-000003:note_history:12]
|  | January 26, 2019 |  | July 28, 2018 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 338 |  |  | $ | 277 |  |
| End user | 25 |  |  | 31 |  |
| Total | $ | 363 |  |  | $ | 308 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (67 | ) |  | $ | (94 | ) |
| End user | (19 | ) |  | (28 | ) |
| Total | $ | (86 | ) |  | $ | (122 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 277 |  |  | $ | 186 |  |

- changed (2019-02-19):
[0000858877-19-000003:note_history:13]
Other Guarantees   Our other guarantee arrangements as of January 26, 2019 and July 28, 2018 that were subject to recognition and disclosure requirements were not material.
  (was, 2018-11-20, similarity 0.9625):
[0000858877-18-000015:note_history:13]
Other Guarantees   Our other guarantee arrangements as of October 27, 2018 and July 28, 2018 that were subject to recognition and disclosure requirements were not material.

- changed (2019-02-19):
[0000858877-19-000003:note_history:14]
We have been asked to indemnify Time Warner Cable (“TWC”) for patent infringement claims asserted against it by Sprint Communications Company, L.P. (“Sprint”) in federal court in Kansas. Sprint alleges that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied TWC's post-trial motions. TWC appealed to the U.S. Court of Appeals for the Federal Circuit, and, on November 30, 2018, a panel of the court affirmed the judgment. TWC filed a petition for rehearing en banc on January 29, 2019. Due to the uncertainty surrounding the litigation process, we are unable to reasonably estimate the ultimate outcome of the TWC litigation at this time. Should Sprint prevail in litigation, or TWC agree to a settlement, we, in accordance with our agreements, may have an obligation to indemnify TWC. At this time, we do not anticipate that our obligations regarding the final outcome would be material.
  (was, 2018-11-20, similarity 0.6065):
[0000858877-18-000015:note_history:14]
We have been asked to indemnify Time Warner Cable (“TWC”) for patent infringement claims asserted against it by Sprint Communications Company, L.P. (“Sprint”) in federal court in Kansas. Sprint alleges that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied TWC's post-trial motions. TWC has appealed to the U.S. Court of Appeals for the Federal Circuit. We believe that TWC continues to have strong non-infringement and invalidity defenses and arguments and/or that Sprint’s damages claims are inconsistent with prevailing law. Due to the uncertainty surrounding the litigation process, we are unable to reasonably estimate the ultimate outcome of the TWC litigation at this time. Should Sprint prevail in litigation, or TWC agree to a settlement, we, in accordance with our agreements, may have an obligation to indemnify TWC for damages, mediation awards, or settlement amounts arising from its use of our products. At this time, we do not anticipate that our obligations regarding the final outcome would be material.

- changed (2019-02-19):
[0000858877-19-000003:note_history:15]
During the first six months of fiscal 2018, we recorded legal and indemnification settlement charges of $127 million to product cost of sales related to prior indemnification matters resolved in fiscal 2018.
  (was, 2018-11-20, similarity 0.8219):
[0000858877-18-000015:note_history:15]
During the first quarter of fiscal 2018, we recorded legal and indemnification settlement charges of $122 million to product cost of sales related to these and other matters.

- changed (2019-02-19):
[0000858877-19-000003:note_history:16]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $215 million for the alleged evasion of import and other taxes, $1.4 billion for interest, and $1.0 billion for various penalties, all determined using an exchange rate as of January 26, 2019. We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.
  (was, 2018-11-20, similarity 0.9937):
[0000858877-18-000015:note_history:16]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $221 million for the alleged evasion of import and other taxes, $1.4 billion for interest, and $1.0 billion for various penalties, all determined using an exchange rate as of October 27, 2018. We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

- changed (2019-02-19):
[0000858877-19-000003:note_history:17]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against us and cancelling a trial which had been set for March 12, 2018. Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit, and, on January 23, 2019, the court summarily affirmed the finding of non-infringement.
  (was, 2018-11-20, similarity 0.9402):
[0000858877-18-000015:note_history:17]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against us and cancelling a trial which had been set for March 12, 2018. On January 16, 2018, Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit.

- removed (2019-02-19):
[0000858877-18-000015:note_history:18]
|  | October 27, 2018 |  | July 28, 2018 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 307 |  |  | $ | 277 |  |
| End user | 28 |  |  | 31 |  |
| Total | $ | 335 |  |  | $ | 308 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (72 | ) |  | $ | (94 | ) |
| End user | (26 | ) |  | (28 | ) |
| Total | $ | (98 | ) |  | $ | (122 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 237 |  |  | $ | 186 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-02-19):
[0000858877-19-000003:note_history:19]
We have prepared the accompanying financial data as of January 26, 2019 and for the second quarter and first six months of fiscal 2019 and fiscal 2018, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 28, 2018 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 28, 2018.
  (was, 2018-11-20, similarity 0.9457):
[0000858877-18-000015:note_history:19]
We have prepared the accompanying financial data as of October 27, 2018 and for the three months ended October 27, 2018 and October 28, 2017, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 28, 2018 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 28, 2018.

- added (2019-02-19):
[0000858877-19-000003:note_history:20]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 26, 2019; the results of operations and the statements of comprehensive income (loss) for the second quarter and first six months of fiscal 2019 and fiscal 2018; the statements of cash flows for the first six months of fiscal 2019 and fiscal 2018; and the statements of equity for the second quarter and first six months of fiscal 2019 and fiscal 2018, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2019 and fiscal 2018 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2019-02-19):
[0000858877-18-000015:note_history:21]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 27, 2018; the results of operations and the statements of comprehensive income (loss) for the three months ended October 27, 2018 and October 28, 2017; the statements of cash flows and equity for the three months ended October 27, 2018 and October 28, 2017, as applicable, have been made. The results of operations for the three months ended October 27, 2018 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-02-19):
[0000858877-19-000003:note_history:22]
Restricted Cash in Statement of Cash Flows  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented. The application of this accounting standard update did not have a material impact on our Consolidated Statements of Cash Flows. Prior period information has been retrospectively adjusted due to the adoption of ASU 2016-18, Statement of Cash Flows, Restricted Cash at the beginning of the first quarter of fiscal 2019.
  (was, 2018-11-20, similarity 0.9972):
[0000858877-18-000015:note_history:22]
Restricted Cash in Statement of Cash Flows  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented. The application of this accounting standard update did not have a material impact on our Consolidated Statements of Cash Flows. Prior period information has been retrospectively adjusted due to the adoption of ASU 2016-18, Statement of Cash Flows, Restricted Cash in the beginning of the first quarter of fiscal 2019.

- changed (2019-02-19):
[0000858877-19-000003:note_history:23]
2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. We early adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a prospective basis. The application of this accounting standard update did not have any impact on our Consolidated Financial Statements.
  (was, 2018-11-20, similarity 0.9893):
[0000858877-18-000015:note_history:23]
2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. We early adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a prospective basis. The application of this accounting standard update did not have a material impact on our Consolidated Financial Statements.

- added (2019-02-19):
[0000858877-19-000003:note_history:24]
The application of ASC 606 increased our total revenue by $267 million and $516 million in the second quarter and first six months of fiscal 2019, respectively. The application of ASC 606 did not have a material impact to either our cost of sales or our operating expenses in the second quarter and first six months of fiscal 2019. We recognized a $152 million benefit to our provision for income taxes relating to indirect effects from the adoption of ASC 606 in the first quarter of fiscal 2019. For additional information regarding ASC 606, see Note 3 to the Consolidated Financial Statements.

- added (2019-02-19):
[0000858877-19-000003:note_history:25]
In connection with the adoption of ASC 606, we recorded a transition adjustment to increase retained earnings by $2.3 billion. See above for the transition impact of ASC 606 by balance sheet line item. As of January 26, 2019, the balance sheet changes attributable to ASC 606 related to accounts receivable, inventories, and deferred revenue were not materially different than the impacts upon adoption. In connection with the adoption of ASC 606, we established contract assets for unbilled receivables. As of January 26, 2019, we had total contract assets of $557 million, of which $241 million was recorded in other current assets and $316 million was recorded in other assets. As of January 26, 2019, we had total capitalized contract acquisition costs of $686 million, of which $380 million was recorded in other current assets and $306 million was recorded in other assets. The adoption of ASC 606 did not have any impact on net cash provided by operating activities.

- removed (2019-02-19):
[0000858877-18-000015:note_history:26]
The application of ASC 606 increased our total revenue by $276 million in the first quarter of fiscal 2019. The application of ASC 606 did not have a material impact to either our cost of sales or our operating expenses in the first quarter of fiscal 2019. We recognized a $152 million benefit to our provision for income taxes relating to indirect effects from the adoption of ASC 606 in the first quarter of fiscal 2019. For additional information regarding ASC 606, see Note 3 to the Consolidated Financial Statements.

- removed (2019-02-19):
[0000858877-18-000015:note_history:27]
In connection with the adoption of ASC 606, we recorded a transition adjustment to increase retained earnings by $2.3 billion. See above for the transition impact of ASC 606 by balance sheet line item. As of October 27, 2018, the balance sheet changes attributable to ASC 606 related to accounts receivable, inventories, and deferred revenue were not materially different than the impacts upon adoption. In connection with the adoption of ASC 606, we established contract assets for unbilled receivables. As of October 27, 2018, we had total contract assets of $447 million of which, $270 million was recorded in other current assets and $177 million was recorded in other assets. As of October 27, 2018, we had total capitalized contract acquisition costs of $673 million, of which $380 million was recorded in other current assets and $293 million was recorded in other assets. The adoption of ASC 606 did not have any impact on net cash provided by operating activities.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-19):
[0000858877-19-000003:note_history:28]
|  | January 26, 2019 |  | July 28, 2018 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 9,737 |  |  | 3.62 | % |  | $ | 5,238 |  |  | 3.46 | % |
  (was, 2018-11-20, similarity 0.9651):
[0000858877-18-000015:note_history:28]
|  | October 27, 2018 |  | July 28, 2018 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 7,241 |  |  | 3.06 | % |  | $ | 5,238 |  |  | 3.46 | % |

- added (2019-02-19):
[0000858877-19-000003:note_history:29]
We repaid our senior notes due on February 15, 2019 for an aggregate principal amount of $2.0 billion upon maturity.

- changed (2019-02-19):
[0000858877-19-000003:note_history:30]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of January 26, 2019 and July 28, 2018.  As of February 18, 2019, we had approximately $2 billion of commercial paper notes outstanding.
  (was, 2018-11-20, similarity 0.8079):
[0000858877-18-000015:note_history:30]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of October 27, 2018 and July 28, 2018.

- changed (2019-02-19):
[0000858877-19-000003:note_history:31]
|  |  |  | January 26, 2019 |  | July 28, 2018 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | $ | 500 |  |  | 3.30% |  | $ | 500 |  |  | 2.86% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 3.17% |  | 500 |  |  | 2.71% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.17% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 3.13% |  | 1,750 |  |  | 2.71% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.87% |  | 2,500 |  |  | 4.52% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 3.28% |  | 500 |  |  | 2.86% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 3.55% |  | 500 |  |  | 3.11% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 3.40% |  | 1,000 |  |  | 2.98% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.71% |  | 500 |  |  | 3.27% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 25,750 |  |  |  |  | 25,750 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (107 | ) |  |  |  | (116 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (13 | ) |  |  |  | (65 | ) |  |  |
| Total |  |  | $ | 25,630 |  |  |  |  | $ | 25,569 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 9,737 |  |  |  |  | $ | 5,238 |  |  |  |
| Long-term debt |  |  | 15,893 |  |  |  |  | 20,331 |  |  |  |
| Total |  |  | $ | 25,630 |  |  |  |  | $ | 25,569 |  |  |  |
  (was, 2018-11-20, similarity 0.996):
[0000858877-18-000015:note_history:31]
|  |  |  | October 27, 2018 |  | July 28, 2018 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | $ | 500 |  |  | 2.88% |  | $ | 500 |  |  | 2.86% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.72% |  | 500 |  |  | 2.71% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.22% |  | 2,000 |  |  | 5.17% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.87% |  | 1,750 |  |  | 2.71% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.68% |  | 2,500 |  |  | 4.52% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 3.05% |  | 500 |  |  | 2.86% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 3.32% |  | 500 |  |  | 3.11% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 3.17% |  | 1,000 |  |  | 2.98% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.48% |  | 500 |  |  | 3.27% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 25,750 |  |  |  |  | 25,750 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (112 | ) |  |  |  | (116 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (74 | ) |  |  |  | (65 | ) |  |  |
| Total |  |  | $ | 25,564 |  |  |  |  | $ | 25,569 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 7,241 |  |  |  |  | $ | 5,238 |  |  |  |
| Long-term debt |  |  | 18,323 |  |  |  |  | 20,331 |  |  |  |
| Total |  |  | $ | 25,564 |  |  |  |  | $ | 25,569 |  |  |  |

- changed (2019-02-19):
[0000858877-19-000003:note_history:32]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 26, 2019, we were in compliance with all debt covenants.
  (was, 2018-11-20, similarity 0.9856):
[0000858877-18-000015:note_history:32]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 27, 2018, we were in compliance with all debt covenants.

- changed (2019-02-19):
[0000858877-19-000003:note_history:33]
As of January 26, 2019, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2018-11-20, similarity 0.9556):
[0000858877-18-000015:note_history:33]
As of October 27, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2019-02-19):
[0000858877-19-000003:note_history:34]
| Fiscal Year | Amount |
| 2019 (remaining six months) | $ | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| Thereafter | 8,500 |  |
| Total | $ | 25,750 |  |
  (was, 2018-11-20, similarity 0.9836):
[0000858877-18-000015:note_history:34]
| Fiscal Year | Amount |
| 2019 (remaining nine months) | $ | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| Thereafter | 8,500 |  |
| Total | $ | 25,750 |  |

- changed (2019-02-19):
[0000858877-19-000003:note_history:35]
This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of January 26, 2019, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under this credit facility.
  (was, 2018-11-20, similarity 0.9782):
[0000858877-18-000015:note_history:35]
This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of October 27, 2018, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under this credit facility.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-19):
[0000858877-19-000003:note_history:36]
|  | January 26, 2019 |  | July 28, 2018 |
| Available-for-sale debt investments | $ | 30,486 |  |  | $ | 37,009 |  |
| Marketable equity securities | 62 |  |  | 605 |  |
| Total investments | 30,548 |  |  | 37,614 |  |
| Non-marketable equity securities included in other assets (1) | 1,133 |  |  | 978 |  |
| Equity method investments included in other assets | 115 |  |  | 118 |  |
| Total | $ | 31,796 |  |  | $ | 38,710 |  |
  (was, 2018-11-20, similarity 0.9718):
[0000858877-18-000015:note_history:36]
|  | October 27, 2018 |  | July 28, 2018 |
| Available-for-sale debt investments | $ | 34,183 |  |  | $ | 37,009 |  |
| Marketable equity securities | — |  |  | 605 |  |
| Total investments | 34,183 |  |  | 37,614 |  |
| Non-marketable equity securities included in other assets | 1,125 |  |  | 978 |  |
| Equity method investments included in other assets | 115 |  |  | 118 |  |
| Total | $ | 35,423 |  |  | $ | 38,710 |  |

- added (2019-02-19):
[0000858877-19-000003:note_history:37]
(1) We held equity interests in certain private equity funds of $0.6 billion as of January 26, 2019 which are accounted for under the NAV practical expedient following the adoption of ASU 2016-01, Financial Instruments, in the first quarter of fiscal 2019.

- changed (2019-02-19):
[0000858877-19-000003:note_history:38]
| January 26, 2019 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 3,486 |  |  | $ | — |  |  | $ | (14 | ) |  | $ | 3,472 |  |
| U.S. government agency securities | 356 |  |  | — |  |  | (2 | ) |  | 354 |  |
| Non-U.S. government and agency securities | 115 |  |  | — |  |  | — |  |  | 115 |  |
| Corporate debt securities | 25,103 |  |  | 16 |  |  | (366 | ) |  | 24,753 |  |
| U.S. agency mortgage-backed securities | 1,475 |  |  | 1 |  |  | (42 | ) |  | 1,434 |  |
| Commercial paper | 243 |  |  | — |  |  | — |  |  | 243 |  |
| Certificates of deposit | 115 |  |  | — |  |  | — |  |  | 115 |  |
| Total (1) | $ | 30,893 |  |  | $ | 17 |  |  | $ | (424 | ) |  | $ | 30,486 |  |
  (was, 2018-11-20, similarity 0.9874):
[0000858877-18-000015:note_history:38]
| October 27, 2018 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 5,783 |  |  | $ | — |  |  | $ | (29 | ) |  | $ | 5,754 |  |
| U.S. government agency securities | 434 |  |  | — |  |  | (4 | ) |  | 430 |  |
| Non-U.S. government and agency securities | 153 |  |  | — |  |  | — |  |  | 153 |  |
| Corporate debt securities | 26,444 |  |  | 33 |  |  | (446 | ) |  | 26,031 |  |
| U.S. agency mortgage-backed securities | 1,481 |  |  | — |  |  | (60 | ) |  | 1,421 |  |
| Commercial paper | 309 |  |  | — |  |  | — |  |  | 309 |  |
| Certificates of deposit | 85 |  |  | — |  |  | — |  |  | 85 |  |
| Total (1) | $ | 34,689 |  |  | $ | 33 |  |  | $ | (539 | ) |  | $ | 34,183 |  |

- changed (2019-02-19):
[0000858877-19-000003:note_history:39]
(1) Net unsettled investment purchases were $4 million and net unsettled investment sales were $1.5 billion as of January 26, 2019 and July 28, 2018, respectively and were included in other current assets and other current liabilities.
  (was, 2018-11-20, similarity 0.8739):
[0000858877-18-000015:note_history:39]
(1) Net unsettled investment purchases were $1 million and net unsettled investment sales were $1.5 billion as of October 27, 2018 and July 28, 2018, respectively and were included in other current assets and other current liabilities.

- changed (2019-02-19):
[0000858877-19-000003:note_history:40]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Gross realized gains | $ | 1 |  |  | $ | 6 |  |  | $ | 3 |  |  | $ | 14 |  |
| Gross realized losses | (6 | ) |  | (102 | ) |  | (14 | ) |  | (106 | ) |
| Total | $ | (5 | ) |  | $ | (96 | ) |  | $ | (11 | ) |  | $ | (92 | ) |
  (was, 2018-11-20, similarity 0.6905):
[0000858877-18-000015:note_history:40]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Gross realized gains | $ | 2 |  |  | $ | 8 |  |
| Gross realized losses | (8 | ) |  | (4 | ) |
| Total | $ | (6 | ) |  | $ | 4 |  |

- changed (2019-02-19):
[0000858877-19-000003:note_history:41]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 26, 2019 and July 28, 2018 (in millions):
  (was, 2018-11-20, similarity 0.967):
[0000858877-18-000015:note_history:41]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 27, 2018 and July 28, 2018 (in millions):

- added (2019-02-19):
[0000858877-19-000003:note_history:42]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 26, 2019 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 6 |  |  | $ | — |  |  | $ | 3,437 |  |  | $ | (14 | ) |  | $ | 3,443 |  |  | $ | (14 | ) |
| U.S. government agency securities | — |  |  | — |  |  | 344 |  |  | (2 | ) |  | 344 |  |  | (2 | ) |
| Non-U.S. government and agency securities | — |  |  | — |  |  | 115 |  |  | — |  |  | 115 |  |  | — |  |
| Corporate debt securities | 5,849 |  |  | (61 | ) |  | 15,108 |  |  | (305 | ) |  | 20,957 |  |  | (366 | ) |
| U.S. agency mortgage-backed securities | 47 |  |  | — |  |  | 1,216 |  |  | (42 | ) |  | 1,263 |  |  | (42 | ) |
| Total | $ | 5,902 |  |  | $ | (61 | ) |  | $ | 20,220 |  |  | $ | (363 | ) |  | $ | 26,122 |  |  | $ | (424 | ) |

- added (2019-02-19):
[0000858877-19-000003:note_history:43]
There were no impairment charges related to our available-for-sale debt investments for the second quarter and first six months of fiscal 2019, and for the corresponding periods of fiscal 2018, respectively. For available-for-sale debt investments that were in an unrealized loss position as of January 26, 2019, we have determined that no other-than-temporary impairments were required to be recognized.

- changed (2019-02-19):
[0000858877-19-000003:note_history:44]
The following table summarizes the maturities of our available-for-sale debt investments as of January 26, 2019 (in millions):
  (was, 2018-11-20, similarity 0.9504):
[0000858877-18-000015:note_history:44]
The following table summarizes the maturities of our available-for-sale debt investments as of October 27, 2018 (in millions):

- changed (2019-02-19):
[0000858877-19-000003:note_history:45]
We recorded adjustments to the carrying value of our non-marketable equity securities measured using the measurement alternative during the second quarter and first six months of fiscal 2019 as follows (in millions):
  (was, 2018-11-20, similarity 0.915):
[0000858877-18-000015:note_history:45]
We recorded adjustments to the carrying value of our non-marketable equity securities measured using the measurement alternative in the first quarter of fiscal 2019 as follows (in millions):

- changed (2019-02-19):
[0000858877-19-000003:note_history:46]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 26, 2019 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |  |  |
| Upward adjustments | $ | 14 |  |  | $ | 24 |  |
| Downward adjustments, including impairments | (2 | ) |  | (18 | ) |
| Net upward adjustments | $ | 12 |  |  | $ | 6 |  |
  (was, 2018-11-20, similarity 0.7545):
[0000858877-18-000015:note_history:46]
|  | Three Months Ended |
|  | October 27, 2018 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |
| Upward adjustments | $ | 10 |  |
| Downward adjustments, including impairments | (16 | ) |
| Net downward adjustments | $ | (6 | ) |

- changed (2019-02-19):
[0000858877-19-000003:note_history:47]
Gains and losses recognized on our marketable and non-marketable equity securities for the second quarter and first six months of fiscal 2019 are summarized below (in millions):
  (was, 2018-11-20, similarity 0.908):
[0000858877-18-000015:note_history:47]
Gains and losses recognized on our marketable and non-marketable equity securities for the first quarter of fiscal 2019 are summarized below (in millions):

- added (2019-02-19):
[0000858877-19-000003:note_history:48]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 26, 2019 |
| Net gains and losses recognized during the period on equity investments | $ | 67 |  |  | $ | 75 |  |
| Less: Net gains and losses recognized on equity investments sold | 5 |  |  | (7 | ) |
| Unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | 72 |  |  | $ | 68 |  |

- changed (2019-02-19):
[0000858877-19-000003:note_history:49]
We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending was $1.2 billion and $0.4 billion for the first six months of fiscal 2019 and fiscal 2018, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 26, 2019 and July 28, 2018, we had no outstanding securities lending transactions.
  (was, 2018-11-20, similarity 0.946):
[0000858877-18-000015:note_history:49]
We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending was $0.5 billion as of each of the first quarters of fiscal 2019 and fiscal 2018, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 27, 2018 and July 28, 2018, we had no outstanding securities lending transactions.

- changed (2019-02-19):
[0000858877-19-000003:note_history:50]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 26, 2019, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2018-11-20, similarity 0.9868):
[0000858877-18-000015:note_history:50]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 27, 2018, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in our Consolidated Financial Statements.

- changed (2019-02-19):
[0000858877-19-000003:note_history:51]
As of January 26, 2019, the carrying value of investments in privately held companies was $1.25 billion, of which $670 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, we have additional funding commitments of $192 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these variable interest entities.
  (was, 2018-11-20, similarity 0.8922):
[0000858877-18-000015:note_history:51]
As of October 27, 2018, the carrying value of our non-marketable equity securities was $1.2 billion, of which $670 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, we have additional funding commitments of $204 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these variable interest entities.

- removed (2019-02-19):
[0000858877-18-000015:note_history:52]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 27, 2018 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 516 |  |  | $ | (3 | ) |  | $ | 5,231 |  |  | $ | (26 | ) |  | $ | 5,747 |  |  | $ | (29 | ) |
| U.S. government agency securities | 4 |  |  | — |  |  | 427 |  |  | (4 | ) |  | 431 |  |  | (4 | ) |
| Non-U.S. government and agency securities | — |  |  | — |  |  | 153 |  |  | — |  |  | 153 |  |  | — |  |
| Corporate debt securities | 13,483 |  |  | (257 | ) |  | 6,738 |  |  | (189 | ) |  | 20,221 |  |  | (446 | ) |
| U.S. agency mortgage-backed securities | 456 |  |  | (12 | ) |  | 947 |  |  | (48 | ) |  | 1,403 |  |  | (60 | ) |
| Total | $ | 14,459 |  |  | $ | (272 | ) |  | $ | 13,496 |  |  | $ | (267 | ) |  | $ | 27,955 |  |  | $ | (539 | ) |

- removed (2019-02-19):
[0000858877-18-000015:note_history:53]
During the first quarter of fiscal 2019 and fiscal 2018, respectively, we did not recognize any impairment charges on our available-for-sale debt investments. For available-for-sale debt investments that were in an unrealized loss position as of October 27, 2018, we have determined that no other-than-temporary impairments were required to be recognized.

- removed (2019-02-19):
[0000858877-18-000015:note_history:54]
|  | Three Months Ended |
|  | October 27, 2018 |
| Net gains and losses recognized during the period on equity investments | $ | 8 |  |
| Less: Net gains and losses recognized on equity investments sold | (12 | ) |
| Unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | (4 | ) |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-19):
[0000858877-19-000003:note_history:55]
|  |  |  | January 26, 2019 |  | July 28, 2018 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | $ | 500 |  |  | 3.30% |  | $ | 500 |  |  | 2.86% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 3.17% |  | 500 |  |  | 2.71% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.17% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 3.13% |  | 1,750 |  |  | 2.71% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.87% |  | 2,500 |  |  | 4.52% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 3.28% |  | 500 |  |  | 2.86% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 3.55% |  | 500 |  |  | 3.11% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 3.40% |  | 1,000 |  |  | 2.98% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.71% |  | 500 |  |  | 3.27% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 25,750 |  |  |  |  | 25,750 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (107 | ) |  |  |  | (116 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (13 | ) |  |  |  | (65 | ) |  |  |
| Total |  |  | $ | 25,630 |  |  |  |  | $ | 25,569 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 9,737 |  |  |  |  | $ | 5,238 |  |  |  |
| Long-term debt |  |  | 15,893 |  |  |  |  | 20,331 |  |  |  |
| Total |  |  | $ | 25,630 |  |  |  |  | $ | 25,569 |  |  |  |
  (was, 2018-11-20, similarity 0.996):
[0000858877-18-000015:note_history:55]
|  |  |  | October 27, 2018 |  | July 28, 2018 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | $ | 500 |  |  | 2.88% |  | $ | 500 |  |  | 2.86% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.72% |  | 500 |  |  | 2.71% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.22% |  | 2,000 |  |  | 5.17% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.87% |  | 1,750 |  |  | 2.71% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.68% |  | 2,500 |  |  | 4.52% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 3.05% |  | 500 |  |  | 2.86% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 3.32% |  | 500 |  |  | 3.11% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 3.17% |  | 1,000 |  |  | 2.98% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.48% |  | 500 |  |  | 3.27% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 25,750 |  |  |  |  | 25,750 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (112 | ) |  |  |  | (116 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (74 | ) |  |  |  | (65 | ) |  |  |
| Total |  |  | $ | 25,564 |  |  |  |  | $ | 25,569 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 7,241 |  |  |  |  | $ | 5,238 |  |  |  |
| Long-term debt |  |  | 18,323 |  |  |  |  | 20,331 |  |  |  |
| Total |  |  | $ | 25,564 |  |  |  |  | $ | 25,569 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-19):
[0000858877-19-000003:note_history:56]
As of January 26, 2019, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2018-11-20, similarity 0.9556):
[0000858877-18-000015:note_history:56]
As of October 27, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2019-02-19):
[0000858877-19-000003:note_history:57]
| Fiscal Year | Amount |
| 2019 (remaining six months) | $ | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| Thereafter | 8,500 |  |
| Total | $ | 25,750 |  |
  (was, 2018-11-20, similarity 0.9836):
[0000858877-18-000015:note_history:57]
| Fiscal Year | Amount |
| 2019 (remaining nine months) | $ | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| Thereafter | 8,500 |  |
| Total | $ | 25,750 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-19):
[0000858877-19-000003:note_history:58]
|  | January 26, 2019 |  | July 28, 2018 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 9,737 |  |  | 3.62 | % |  | $ | 5,238 |  |  | 3.46 | % |
  (was, 2018-11-20, similarity 0.9651):
[0000858877-18-000015:note_history:58]
|  | October 27, 2018 |  | July 28, 2018 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 7,241 |  |  | 3.06 | % |  | $ | 5,238 |  |  | 3.46 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-02-19):
[0000858877-19-000003:note_history:59]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 7,128 |  |  | $ | 6,710 |  |  | $ | 14,770 |  |  | $ | 13,690 |  |
| Applications | 1,465 |  |  | 1,184 |  |  | 2,884 |  |  | 2,387 |  |
| Security | 658 |  |  | 557 |  |  | 1,308 |  |  | 1,142 |  |
| Other Products | 22 |  |  | 258 |  |  | 200 |  |  | 544 |  |
| Total Product | 9,273 |  |  | 8,709 |  |  | 19,163 |  |  | 17,763 |  |
| Services | 3,173 |  |  | 3,178 |  |  | 6,355 |  |  | 6,260 |  |
| Total (1) | $ | 12,446 |  |  | $ | 11,887 |  |  | $ | 25,518 |  |  | $ | 24,023 |  |

- added (2019-02-19):
[0000858877-19-000003:note_history:60]
Amounts may not sum due to rounding.

- added (2019-02-19):
[0000858877-19-000003:note_history:61]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions ("SPVSS") business. Total revenue includes SPVSS business revenue of $0 and $230 million for the second quarter of fiscal 2019 and 2018, respectively, and $168 million and $478 million for the first six months of fiscal 2019 and 2018, respectively.

- removed (2019-02-19):
[0000858877-18-000015:note_history:62]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 7,642 |  |  | $ | 6,980 |  |
| Applications | 1,419 |  |  | 1,203 |  |
| Security | 651 |  |  | 585 |  |
| Other Products | 178 |  |  | 286 |  |
| Total Product | 9,890 |  |  | 9,054 |  |
| Services | 3,182 |  |  | 3,082 |  |
| Total | $ | 13,072 |  |  | $ | 12,136 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-02-19):
[0000858877-19-000003:note_history:63]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 7,128 |  |  | $ | 6,710 |  |  | $ | 14,770 |  |  | $ | 13,690 |  |
| Applications | 1,465 |  |  | 1,184 |  |  | 2,884 |  |  | 2,387 |  |
| Security | 658 |  |  | 557 |  |  | 1,308 |  |  | 1,142 |  |
| Other Products | 22 |  |  | 258 |  |  | 200 |  |  | 544 |  |
| Total Product | 9,273 |  |  | 8,709 |  |  | 19,163 |  |  | 17,763 |  |
| Services | 3,173 |  |  | 3,178 |  |  | 6,355 |  |  | 6,260 |  |
| Total (1) | $ | 12,446 |  |  | $ | 11,887 |  |  | $ | 25,518 |  |  | $ | 24,023 |  |

- added (2019-02-19):
[0000858877-19-000003:note_history:64]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions ("SPVSS") business. Total revenue includes SPVSS business revenue of $0 and $230 million for the second quarter of fiscal 2019 and 2018, respectively, and $168 million and $478 million for the first six months of fiscal 2019 and 2018, respectively.

- changed (2019-02-19):
[0000858877-19-000003:note_history:65]
Other Products primarily include our Service Provider Video Software Solutions and cloud and system management products. On May 1, 2018, we announced a definitive agreement to sell the SPVSS business. The sale closed on October 28, 2018. These products include both hardware and software licenses. Our offerings in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control.
  (was, 2018-11-20, similarity 0.9892):
[0000858877-18-000015:note_history:65]
Other Products primarily include our Service Provider Video Software Solutions, cloud and system management products. On May 1, 2018, we announced a definitive agreement to sell the SPVSS business. The sale was closed on October 28, 2018. These products include both hardware and software licenses. Our offerings in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control.

- changed (2019-02-19):
[0000858877-19-000003:note_history:66]
Accounts receivable, net was $3.7 billion as of January 26, 2019 compared to $5.6 billion as of July 28, 2018, as reported on the Consolidated Balance Sheet.
  (was, 2018-11-20, similarity 0.9577):
[0000858877-18-000015:note_history:66]
Accounts receivable, net was $4.5 billion as of October 27, 2018 compared to $5.6 billion as of July 28, 2018, as reported on the Consolidated Balance Sheet.

- changed (2019-02-19):
[0000858877-19-000003:note_history:67]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of January 26, 2019 and July 29, 2018, our contract assets for these unbilled receivables were $557 million and $122 million, respectively, and were included in other current assets and other assets.
  (was, 2018-11-20, similarity 0.9852):
[0000858877-18-000015:note_history:67]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of October 27, 2018 and July 29, 2018, our contract assets for these unbilled receivables were $447 million and $122 million, respectively, and were included in other current assets and other assets.

- changed (2019-02-19):
[0000858877-19-000003:note_history:68]
Contract liabilities consist of deferred revenue. Deferred revenue was $17.3 billion as of January 26, 2019 compared to $19.7 billion as of July 28, 2018. In connection with the adoption of ASC 606, we recorded an adjustment to retained earnings to reduce deferred revenue by $2.8 billion. We recognized approximately $2.6 billion and $6.0 billion of revenue during the second quarter and first six months of fiscal 2019, respectively, that was included in the deferred revenue balance at July 29, 2018.
  (was, 2018-11-20, similarity 0.7633):
[0000858877-18-000015:note_history:68]
Contract liabilities consist of deferred revenue. Deferred revenue was $16.8 billion as of October 27, 2018 compared to $19.7 billion as of July 28, 2018. In connection with the adoption of ASC 606, we recorded an adjustment to retained earnings to reduce deferred revenue by $2.8 billion. We recognized approximately $3.4 billion of revenue during the first quarter of fiscal 2019 that was included in the deferred revenue balance at July 29, 2018.

- changed (2019-02-19):
[0000858877-19-000003:note_history:69]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of January 26, 2019, the aggregate amount of RPO was $22.5 billion, comprised of $17.3 billion of deferred revenue and $5.2 billion of unbilled contract revenue. We expect approximately 56% of this amount to be recognized as revenue over the next year. Unbilled contract revenue represents non-cancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.
  (was, 2018-11-20, similarity 0.987):
[0000858877-18-000015:note_history:69]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of October 27, 2018, the aggregate amount of RPO was $22.3 billion, comprised of $16.8 billion of deferred revenue and $5.5 billion of unbilled contract revenue. We expect approximately 55% of this amount to be recognized as revenue over the next year. Unbilled contract revenue represents non-cancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

- changed (2019-02-19):
[0000858877-19-000003:note_history:70]
In connection with the adoption of ASC 606, we began to capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $686 million and $644 million as of January 26, 2019 and July 29, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $100 million and $212 million for the second quarter and first six months of fiscal 2019, respectively, and was included in sales and marketing expenses.
  (was, 2018-11-20, similarity 0.8757):
[0000858877-18-000015:note_history:70]
In connection with the adoption of ASC 606, we began to capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $673 million and $644 million as of October 27, 2018 and July 29, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $112 million for the first quarter of fiscal 2019 and was included in sales and marketing expenses.

- removed (2019-02-19):
[0000858877-18-000015:note_history:71]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 7,642 |  |  | $ | 6,980 |  |
| Applications | 1,419 |  |  | 1,203 |  |
| Security | 651 |  |  | 585 |  |
| Other Products | 178 |  |  | 286 |  |
| Total Product | 9,890 |  |  | 9,054 |  |
| Services | 3,182 |  |  | 3,082 |  |
| Total | $ | 13,072 |  |  | $ | 12,136 |  |
