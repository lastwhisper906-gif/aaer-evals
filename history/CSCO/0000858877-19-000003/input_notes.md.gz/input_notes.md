# CSCO notes — 0000858877-19-000003


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-19-000003:notes:1]
[same as prior period, unchanged from 0000858877-18-000015:notes:1]

[0000858877-19-000003:notes:2]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Compensation expense related to acquisitions | $ | 66 |  |  | $ | 46 |  |  | $ | 175 |  |  | $ | 88 |  |


## csco:IncometaxprovisionTableTextBlock

[0000858877-19-000003:notes:3]
[same as prior period, unchanged from 0000858877-18-000015:notes:3]

[0000858877-19-000003:notes:4]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Income before provision for income taxes | $ | 3,343 |  |  | $ | 3,232 |  |  | $ | 7,252 |  |  | $ | 6,194 |  |
| Provision for income taxes | $ | 521 |  |  | $ | 12,010 |  |  | $ | 881 |  |  | $ | 12,578 |  |
| Effective tax rate | 15.6 | % |  | 371.6 | % |  | 12.1 | % |  | 203.1 | % |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-19-000003:notes:5]
[same as prior period, unchanged from 0000858877-18-000015:notes:5]

[0000858877-19-000003:notes:6]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 7,128 |  |  | $ | 6,710 |  |  | $ | 14,770 |  |  | $ | 13,690 |  |
| Applications | 1,465 |  |  | 1,184 |  |  | 2,884 |  |  | 2,387 |  |
| Security | 658 |  |  | 557 |  |  | 1,308 |  |  | 1,142 |  |
| Other Products | 22 |  |  | 258 |  |  | 200 |  |  | 544 |  |
| Total Product | 9,273 |  |  | 8,709 |  |  | 19,163 |  |  | 17,763 |  |
| Services | 3,173 |  |  | 3,178 |  |  | 6,355 |  |  | 6,260 |  |
| Total (1) | $ | 12,446 |  |  | $ | 11,887 |  |  | $ | 25,518 |  |  | $ | 24,023 |  |

[0000858877-19-000003:notes:7]
(1) Includes SPVSS business revenue of $0 and $230 million for the second quarter of fiscal 2019 and 2018, respectively, and $168 million and $478 million for the first six months of fiscal 2019 and fiscal 2018, respectively.


## csco:ScheduleOfCommonStockRepurchasedTextBlock

[0000858877-19-000003:notes:8]
A summary of the stock repurchase activity for fiscal 2019 and 2018 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-19-000003:notes:9]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2019 |  |  |  |  |  |  |
| January 26, 2019 |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |
| October 27, 2018 |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |
| Fiscal 2018 |  |  |  |  |  |  |
| July 28, 2018 |  | 138 |  |  | $ | 43.58 |  |  | $ | 6,015 |  |
| April 28, 2018 |  | 140 |  |  | $ | 42.83 |  |  | $ | 6,015 |  |
| January 27, 2018 |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |
| October 28, 2017 |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-19-000003:notes:10]
[same as prior period, unchanged from 0000858877-18-000015:notes:9]

[0000858877-19-000003:notes:11]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE THREE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Interest rate derivatives |  | Interest expense |  | $ | 64 |  |  | $ | (63 | ) |  | $ | (61 | ) |  | $ | 63 |  |
| Equity derivatives |  | Other income (loss), net |  | — |  |  | (35 | ) |  | — |  |  | 35 |  |
| Total |  |  |  | $ | 64 |  |  | $ | (98 | ) |  | $ | (61 | ) |  | $ | 98 |  |

[0000858877-19-000003:notes:12]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THESIX MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE SIX MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Interest rate derivatives |  | Interest expense |  | $ | 55 |  |  | $ | (109 | ) |  | $ | (52 | ) |  | $ | 109 |  |
| Equity derivatives |  | Other income (loss), net |  | — |  |  | (49 | ) |  | — |  |  | 49 |  |
| Total |  |  |  | $ | 55 |  |  | $ | (158 | ) |  | $ | (52 | ) |  | $ | 158 |  |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-19-000003:notes:13]
[same as prior period, unchanged from 0000858877-18-000015:notes:11]

[0000858877-19-000003:notes:14]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 156 |  |  | $ | 160 |  |  | $ | 307 |  |  | $ | 314 |  |
| Operating expenses | 39 |  |  | 60 |  |  | 73 |  |  | 121 |  |
| Total | $ | 195 |  |  | $ | 220 |  |  | $ | 380 |  |  | $ | 435 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-19-000003:notes:15]
The following table presents details of our intangible assets acquired through acquisitions completed during the first six months of fiscal 2019 (in millions, except years):

[0000858877-19-000003:notes:16]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Duo | 5.0 |  | $ | 153 |  |  | 5.0 |  |  | $ | 94 |  |  | 2.5 |  |  | $ | 18 |  |  | $ | 77 |  |  | $ | 342 |  |
| Others (two in total) | 5.0 |  | 8 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| Total |  |  | $ | 161 |  |  |  |  | $ | 94 |  |  |  |  | $ | 18 |  |  | $ | 77 |  |  | $ | 350 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-19-000003:notes:17]
[same as prior period, unchanged from 0000858877-18-000015:notes:15]

[0000858877-19-000003:notes:18]
| January 26, 2019 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,165 |  |  | $ | (1,620 | ) |  | $ | 1,545 |  |
| Customer relationships |  | 812 |  |  | (292 | ) |  | 520 |  |
| Other |  | 55 |  |  | (30 | ) |  | 25 |  |
| Total purchased intangible assets with finite lives |  | 4,032 |  |  | (1,942 | ) |  | 2,090 |  |
| In-process research and development, with indefinite lives |  | 180 |  |  | — |  |  | 180 |  |
| Total |  | $ | 4,212 |  |  | $ | (1,942 | ) |  | $ | 2,270 |  |

[0000858877-19-000003:notes:19]
[same as prior period, unchanged from 0000858877-18-000015:notes:17]


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-19-000003:notes:20]
[same as prior period, unchanged from 0000858877-18-000015:notes:18]

[0000858877-19-000003:notes:21]
[same as prior period, unchanged from 0000858877-18-000015:notes:19]

[0000858877-19-000003:notes:22]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-19-000003:notes:23]
Summarized financial information by segment for the second quarter and the first six months of fiscal 2019 and fiscal 2018, based on our internal management system and as utilized by our Chief Operating Decision Maker ("CODM"), is as follows (in millions):

[0000858877-19-000003:notes:24]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 7,352 |  |  | $ | 7,004 |  |  | $ | 15,103 |  |  | $ | 14,354 |  |
| EMEA | 3,223 |  |  | 3,062 |  |  | 6,447 |  |  | 5,971 |  |
| APJC | 1,872 |  |  | 1,820 |  |  | 3,968 |  |  | 3,698 |  |
| Total | $ | 12,446 |  |  | $ | 11,887 |  |  | $ | 25,518 |  |  | $ | 24,023 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,796 |  |  | $ | 4,614 |  |  | $ | 9,866 |  |  | $ | 9,336 |  |
| EMEA | 2,070 |  |  | 1,977 |  |  | 4,141 |  |  | 3,816 |  |
| APJC | 1,109 |  |  | 1,094 |  |  | 2,309 |  |  | 2,259 |  |
| Segment total | 7,975 |  |  | 7,685 |  |  | 16,316 |  |  | 15,411 |  |
| Unallocated corporate items | (202 | ) |  | (187 | ) |  | (397 | ) |  | (486 | ) |
| Total | $ | 7,773 |  |  | $ | 7,498 |  |  | $ | 15,919 |  |  | $ | 14,925 |  |

[0000858877-19-000003:notes:25]
[same as prior period, unchanged from 0000858877-18-000015:notes:23]

[0000858877-19-000003:notes:26]
Revenue in the United States was $6.4 billion and $6.1 billion for the second quarter of fiscal 2019 and fiscal 2018, respectively, and $13.3 billion and $12.6 billion for the first six months of fiscal 2019 and fiscal 2018, respectively.

[0000858877-19-000003:notes:27]
[same as prior period, unchanged from 0000858877-18-000015:notes:25]

[0000858877-19-000003:notes:28]
[same as prior period, unchanged from 0000858877-18-000015:notes:26]

[0000858877-19-000003:notes:29]
[same as prior period, unchanged from 0000858877-18-000015:notes:27]

[0000858877-19-000003:notes:30]
The majority of our assets was attributable to our U.S. operations as of each of January 26, 2019 and July 28, 2018.

[0000858877-19-000003:notes:31]
[same as prior period, unchanged from 0000858877-18-000015:notes:29]

[0000858877-19-000003:notes:32]
|  | January 26, 2019 |  | July 28, 2018 |
| Property and equipment, net: |  |  |  |
| United States | $ | 2,394 |  |  | $ | 2,487 |  |
| International | 537 |  |  | 519 |  |
| Total | $ | 2,931 |  |  | $ | 3,006 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-19-000003:notes:33]
[same as prior period, unchanged from 0000858877-18-000015:notes:31]

[0000858877-19-000003:notes:34]
| Three months ended January 26, 2019 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of October 27, 2018 | $ | 131 |  |  | $ | 60 |  |  | $ | 8 |  |  | $ | 199 |  |
| Provisions (benefits) | (4 | ) |  | 4 |  |  | 1 |  |  | 1 |  |
| Allowance for credit loss as of January 26, 2019 | $ | 127 |  |  | $ | 64 |  |  | $ | 9 |  |  | $ | 200 |  |

[0000858877-19-000003:notes:35]
| Six months ended January 26, 2019 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 28, 2018 | $ | 135 |  |  | $ | 60 |  |  | $ | 10 |  |  | $ | 205 |  |
| Provisions (benefits) | (7 | ) |  | 4 |  |  | (1 | ) |  | (4 | ) |
| Foreign exchange and other | (1 | ) |  | — |  |  | — |  |  | (1 | ) |
| Allowance for credit loss as of January 26, 2019 | $ | 127 |  |  | $ | 64 |  |  | $ | 9 |  |  | $ | 200 |  |

[0000858877-19-000003:notes:36]
| Three months ended January 27, 2018 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of October 28, 2017 | $ | 160 |  |  | $ | 106 |  |  | $ | 23 |  |  | $ | 289 |  |
| Provisions (benefits) | 3 |  |  | (13 | ) |  | (10 | ) |  | (20 | ) |
| Foreign exchange and other | 2 |  |  | 1 |  |  | — |  |  | 3 |  |
| Allowance for credit loss as of January 27, 2018 | $ | 165 |  |  | $ | 94 |  |  | $ | 13 |  |  | $ | 272 |  |

[0000858877-19-000003:notes:37]
| Six months ended January 27, 2018 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 29, 2017 | $ | 162 |  |  | $ | 103 |  |  | $ | 30 |  |  | $ | 295 |  |
| Provisions (benefits) | 1 |  |  | (11 | ) |  | (16 | ) |  | (26 | ) |
| Foreign exchange and other | 2 |  |  | 2 |  |  | (1 | ) |  | 3 |  |
| Allowance for credit loss as of January 27, 2018 | $ | 165 |  |  | $ | 94 |  |  | $ | 13 |  |  | $ | 272 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000858877-19-000003:notes:38]
[same as prior period, unchanged from 0000858877-18-000015:notes:34]

[0000858877-19-000003:notes:39]
We have prepared the accompanying financial data as of January 26, 2019 and for the second quarter and first six months of fiscal 2019 and fiscal 2018, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 28, 2018 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 28, 2018.

[0000858877-19-000003:notes:40]
We consolidate our investments in certain variable interest entities (VIEs) where we are the  primary beneficiary. The noncontrolling interests attributed to these investments, if any, are presented as a separate component from our equity in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-19-000003:notes:41]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 26, 2019; the results of operations and the statements of comprehensive income (loss) for the second quarter and first six months of fiscal 2019 and fiscal 2018; the statements of cash flows for the first six months of fiscal 2019 and fiscal 2018; and the statements of equity for the second quarter and first six months of fiscal 2019 and fiscal 2018, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2019 and fiscal 2018 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-19-000003:notes:42]
[same as prior period, unchanged from 0000858877-18-000015:notes:38]

[0000858877-19-000003:notes:43]
We completed three acquisitions during the first six months of fiscal 2019. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-19-000003:notes:44]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Duo | $ | 2,025 |  |  | $ | (57 | ) |  | $ | 342 |  |  | $ | 1,740 |  |
| Others (two in total) | 60 |  |  | 3 |  |  | 8 |  |  | 49 |  |
| Total | $ | 2,085 |  |  | $ | (54 | ) |  | $ | 350 |  |  | $ | 1,789 |  |

[0000858877-19-000003:notes:45]
[same as prior period, unchanged from 0000858877-18-000015:notes:41]

[0000858877-19-000003:notes:46]
The total purchase consideration related to acquisitions completed during the first six months of fiscal 2019 consisted of cash consideration. The total cash and cash equivalents acquired from these acquisitions was approximately $85 million. Total transaction costs related to acquisition and divestiture activities were $11 million and $14 million for the first six months of fiscal 2019 and fiscal 2018, respectively. These transaction costs were expensed as incurred in general and administrative expenses ("G&A") in the Consolidated Statements of Operations.

[0000858877-19-000003:notes:47]
The goodwill generated from acquisitions completed during the first six months of fiscal 2019 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-19-000003:notes:48]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first six months of fiscal 2019 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.

[0000858877-19-000003:notes:49]
Divestiture of Service Provider Video Software Solutions     On October 28, 2018, we completed the sale of the Service Provider Video Software Solutions business. This business had tangible assets of approximately $160 million (primarily comprised of accounts receivables, inventories and various other current and long-term assets) and net intangible assets and goodwill (based on relative fair value) of $340 million. In addition, the business had total liabilities of approximately $200 million (primarily comprised of deferred revenue and various other current and long-term liabilities). We recognized an immaterial gain from this transaction in the second quarter of fiscal 2019.

[0000858877-19-000003:notes:50]
We completed two divestitures during the second quarter of fiscal 2018. The financial statement impact of these divestitures was not material for the second quarter and first six months of fiscal 2018.

[0000858877-19-000003:notes:51]
Acquisition of Luxtera     On February 6, 2019, we completed our acquisition of Luxtera, Inc. ("Luxtera"), a semiconductor company, for total consideration of approximately $660 million in cash and assumed equity awards. Revenue from the Luxtera acquisition will be included in our Infrastructure Platforms product category. We expect that most of the purchase price will be allocated to goodwill and purchased intangible assets.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-19-000003:notes:52]
Commitments and Contingencies

[0000858877-19-000003:notes:53]
| (a) | Operating Leases |

[0000858877-19-000003:notes:54]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Australia, Belgium, Canada, China, Germany, India, Japan, Mexico, Poland and the United Kingdom. We also lease equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of January 26, 2019 are as follows (in millions):

[0000858877-19-000003:notes:55]
| Fiscal Year | Amount |
| 2019 (remaining six months) | $ | 214 |  |
| 2020 | 331 |  |
| 2021 | 233 |  |
| 2022 | 163 |  |
| 2023 | 106 |  |
| Thereafter | 117 |  |
| Total | $ | 1,164 |  |

[0000858877-19-000003:notes:56]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-19-000003:notes:57]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-19-000003:notes:58]
The following table summarizes our purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-19-000003:notes:59]
| Commitments by Period | January 26, 2019 |  | July 28, 2018 |
| Less than 1 year | $ | 5,366 |  |  | $ | 5,407 |  |
| 1 to 3 years | 731 |  |  | 710 |  |
| 3 to 5 years | 180 |  |  | 360 |  |
| Total | $ | 6,277 |  |  | $ | 6,477 |  |

[0000858877-19-000003:notes:60]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 26, 2019 and July 28, 2018, the liability for these purchase commitments was $148 million and $159 million, respectively, and was included in other current liabilities.

[0000858877-19-000003:notes:61]
| (c) | Other Commitments |

[0000858877-19-000003:notes:62]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-19-000003:notes:63]
As of January 26, 2019, we estimated that future cash compensation expense of up to $528 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-19-000003:notes:64]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $357 million and $223 million as of January 26, 2019 and July 28, 2018, respectively.

[0000858877-19-000003:notes:65]
| (d) | Product Warranties |

[0000858877-19-000003:notes:66]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-19-000003:notes:67]
|  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |
| Balance at beginning of period | $ | 359 |  |  | $ | 407 |  |
| Provisions for warranties issued | 297 |  |  | 287 |  |
| Adjustments for pre-existing warranties | (5 | ) |  | (21 | ) |
| Settlements | (300 | ) |  | (292 | ) |
| Acquisitions and divestitures | (2 | ) |  | — |  |
| Balance at end of period | $ | 349 |  |  | $ | 381 |  |

[0000858877-19-000003:notes:68]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-19-000003:notes:69]
| (e) | Financing and Other Guarantees |

[0000858877-19-000003:notes:70]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-19-000003:notes:71]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.3 billion and $6.9 billion for the second quarter of fiscal 2019 and fiscal 2018, respectively, and was $14.5 billion and $13.6 billion for the first six months of fiscal 2019 and fiscal 2018, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.0 billion as of January 26, 2019 and July 28, 2018, respectively.

[0000858877-19-000003:notes:72]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $6 million and $12 million for the second quarter of fiscal 2019 and fiscal 2018, respectively, and was $9 million and $26 million for the first six months of fiscal 2019 and fiscal 2018, respectively.

[0000858877-19-000003:notes:73]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 26, 2019 and July 28, 2018, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-19-000003:notes:74]
|  | January 26, 2019 |  | July 28, 2018 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 338 |  |  | $ | 277 |  |
| End user | 25 |  |  | 31 |  |
| Total | $ | 363 |  |  | $ | 308 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (67 | ) |  | $ | (94 | ) |
| End user | (19 | ) |  | (28 | ) |
| Total | $ | (86 | ) |  | $ | (122 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 277 |  |  | $ | 186 |  |

[0000858877-19-000003:notes:75]
Other Guarantees   Our other guarantee arrangements as of January 26, 2019 and July 28, 2018 that were subject to recognition and disclosure requirements were not material.

[0000858877-19-000003:notes:76]
| (f) | Indemnifications |

[0000858877-19-000003:notes:77]
In the normal course of business, we indemnify other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-19-000003:notes:78]
We have been asked to indemnify Time Warner Cable (“TWC”) for patent infringement claims asserted against it by Sprint Communications Company, L.P. (“Sprint”) in federal court in Kansas. Sprint alleges that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied TWC's post-trial motions. TWC appealed to the U.S. Court of Appeals for the Federal Circuit, and, on November 30, 2018, a panel of the court affirmed the judgment. TWC filed a petition for rehearing en banc on January 29, 2019. Due to the uncertainty surrounding the litigation process, we are unable to reasonably estimate the ultimate outcome of the TWC litigation at this time. Should Sprint prevail in litigation, or TWC agree to a settlement, we, in accordance with our agreements, may have an obligation to indemnify TWC. At this time, we do not anticipate that our obligations regarding the final outcome would be material.

[0000858877-19-000003:notes:79]
During the first six months of fiscal 2018, we recorded legal and indemnification settlement charges of $127 million to product cost of sales related to prior indemnification matters resolved in fiscal 2018.

[0000858877-19-000003:notes:80]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-19-000003:notes:81]
It is not possible to determine the maximum potential amount under these indemnification agreements due to our limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by us under these agreements have not had a material effect on our operating results, financial position, or cash flows.

[0000858877-19-000003:notes:82]
| (g) | Legal Proceedings |

[0000858877-19-000003:notes:83]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of our former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-19-000003:notes:84]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $215 million for the alleged evasion of import and other taxes, $1.4 billion for interest, and $1.0 billion for various penalties, all determined using an exchange rate as of January 26, 2019. We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-19-000003:notes:85]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and, on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We have appealed to the United States Court of Appeals for the Federal Circuit on various grounds. We believe we have strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, we do not expect it to be material.

[0000858877-19-000003:notes:86]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against us and cancelling a trial which had been set for March 12, 2018. Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit, and, on January 23, 2019, the court summarily affirmed the finding of non-infringement.

[0000858877-19-000003:notes:87]
Arista Networks, Inc.     As reported in our Form 10-K for the fiscal year ended July 28, 2018 we received a payment of $400 million from Arista Networks, Inc. ("Arista") in connection with the settlement of litigation. The payment was recognized in general and administrative expenses in our first quarter of fiscal 2019.

[0000858877-19-000003:notes:88]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the court consolidated the cases alleging infringement of the ‘327 Patent. Oyster's cases against some of the defendants were resolved. The court vacated the November 4, 2018 trial date set for Oyster's claims against Cisco and one other remaining defendant, pending resolution of Oyster's appeal of the court's summary judgment ruling dismissing certain of Oyster's claims. While we believe that we have strong non-infringement arguments and that the patent is invalid, if we do not prevail in the District Court, we believe damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, we are unable to reasonably estimate the ultimate outcome of this litigation at this time. However, we do not anticipate that any final outcome of the dispute would be material.

[0000858877-19-000003:notes:89]
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-19-000003:notes:90]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-19-000003:notes:91]
[same as prior period, unchanged from 0000858877-18-000015:notes:86]

[0000858877-19-000003:notes:92]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, for the first six months of fiscal 2019 and fiscal 2018 are summarized as follows (in millions):

[0000858877-19-000003:notes:93]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 28, 2018 | $ | (310 | ) |  | $ | (11 | ) |  | $ | (528 | ) |  | $ | (849 | ) |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 86 |  |  | (9 | ) |  | (184 | ) |  | (107 | ) |
| (Gains) losses reclassified out of AOCI | 11 |  |  | (1 | ) |  | 3 |  |  | 13 |  |
| Tax benefit (expense) | — |  |  | 2 |  |  | (1 | ) |  | 1 |  |
| Total change for the period | 97 |  |  | (8 | ) |  | (182 | ) |  | (93 | ) |
| Effect of adoption of accounting standards | (168 | ) |  | — |  |  | — |  |  | (168 | ) |
| BALANCE AT JANUARY 26, 2019 | $ | (381 | ) |  | $ | (19 | ) |  | $ | (710 | ) |  | $ | (1,110 | ) |

[0000858877-19-000003:notes:94]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 29, 2017 | $ | 373 |  |  | $ | 32 |  |  | $ | (359 | ) |  | $ | 46 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (174 | ) |  | 38 |  |  | 292 |  |  | 156 |  |
| (Gains) losses reclassified out of AOCI | (91 | ) |  | (31 | ) |  | 5 |  |  | (117 | ) |
| Tax benefit (expense) | 3 |  |  | 1 |  |  | (6 | ) |  | (2 | ) |
| Total change for the period | (262 | ) |  | 8 |  |  | 291 |  |  | 37 |  |
| BALANCE AT JANUARY 27, 2018 | $ | 111 |  |  | $ | 40 |  |  | $ | (68 | ) |  | $ | 83 |  |

[0000858877-19-000003:notes:95]
[same as prior period, unchanged from 0000858877-18-000015:notes:90]

[0000858877-19-000003:notes:96]
|  |  | Three Months Ended |  | Six Months Ended |  |  |
|  |  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains and losses on available-for-sale investments |  | $ | (5 | ) |  | $ | 58 |  |  | $ | (11 | ) |  | $ | 91 |  |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | Revenue—product |
| Foreign currency derivatives |  | 1 |  |  | — |  |  | 2 |  |  | — |  |  | Revenue—service |
| Foreign currency derivatives |  | (1 | ) |  | 4 |  |  | (1 | ) |  | 7 |  |  | Cost of sales—service |
| Foreign currency derivatives |  | — |  |  | 14 |  |  | (1 | ) |  | 24 |  |  | Operating expenses |
|  |  | 1 |  |  | 18 |  |  | 1 |  |  | 31 |  |  |  |
| Cumulative translation adjustment and actuarial gains and losses |  | — |  |  | (4 | ) |  | — |  |  | (5 | ) |  | Operating expenses |
| Cumulative translation adjustment and actuarial gains and losses |  | (4 | ) |  | — |  |  | (3 | ) |  | — |  |  | Other income (loss), net |
| Total amounts reclassified out of AOCI |  | $ | (8 | ) |  | $ | 72 |  |  | $ | (13 | ) |  | $ | 117 |  |  |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000858877-19-000003:notes:97]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 11,246 |  |  | $ | 11,431 |  |
| Product |  | 6,015 |  |  | 8,254 |  |
| Total |  | $ | 17,261 |  |  | $ | 19,685 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,976 |  |  | $ | 11,490 |  |
| Noncurrent |  | 7,285 |  |  | 8,195 |  |
| Total |  | $ | 17,261 |  |  | $ | 19,685 |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-19-000003:notes:98]
Borrowings

[0000858877-19-000003:notes:99]
| (a) | Short-Term Debt |

[0000858877-19-000003:notes:100]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-19-000003:notes:101]
|  | January 26, 2019 |  | July 28, 2018 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 9,737 |  |  | 3.62 | % |  | $ | 5,238 |  |  | 3.46 | % |

[0000858877-19-000003:notes:102]
We repaid our senior notes due on February 15, 2019 for an aggregate principal amount of $2.0 billion upon maturity.

[0000858877-19-000003:notes:103]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of January 26, 2019 and July 28, 2018.  As of February 18, 2019, we had approximately $2 billion of commercial paper notes outstanding.

[0000858877-19-000003:notes:104]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-19-000003:notes:105]
| (b) | Long-Term Debt |

[0000858877-19-000003:notes:106]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-19-000003:notes:107]
|  |  |  | January 26, 2019 |  | July 28, 2018 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | $ | 500 |  |  | 3.30% |  | $ | 500 |  |  | 2.86% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 3.17% |  | 500 |  |  | 2.71% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.17% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 3.13% |  | 1,750 |  |  | 2.71% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.87% |  | 2,500 |  |  | 4.52% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 3.28% |  | 500 |  |  | 2.86% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 3.55% |  | 500 |  |  | 3.11% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 3.40% |  | 1,000 |  |  | 2.98% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.71% |  | 500 |  |  | 3.27% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 25,750 |  |  |  |  | 25,750 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (107 | ) |  |  |  | (116 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (13 | ) |  |  |  | (65 | ) |  |  |
| Total |  |  | $ | 25,630 |  |  |  |  | $ | 25,569 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 9,737 |  |  |  |  | $ | 5,238 |  |  |  |
| Long-term debt |  |  | 15,893 |  |  |  |  | 20,331 |  |  |  |
| Total |  |  | $ | 25,630 |  |  |  |  | $ | 25,569 |  |  |  |

[0000858877-19-000003:notes:108]
We entered into interest rate swaps in prior periods with an aggregate notional amount of $6.75 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate ("LIBOR"). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 12.

[0000858877-19-000003:notes:109]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 26, 2019, we were in compliance with all debt covenants.

[0000858877-19-000003:notes:110]
As of January 26, 2019, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-19-000003:notes:111]
| Fiscal Year | Amount |
| 2019 (remaining six months) | $ | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| Thereafter | 8,500 |  |
| Total | $ | 25,750 |  |

[0000858877-19-000003:notes:112]
| (c) | Credit Facility |

[0000858877-19-000003:notes:113]
On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.

[0000858877-19-000003:notes:114]
This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of January 26, 2019, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under this credit facility.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-19-000003:notes:115]
[same as prior period, unchanged from 0000858877-18-000015:notes:109]

[0000858877-19-000003:notes:116]
[same as prior period, unchanged from 0000858877-18-000015:notes:110]

[0000858877-19-000003:notes:117]
[same as prior period, unchanged from 0000858877-18-000015:notes:111]

[0000858877-19-000003:notes:118]
[same as prior period, unchanged from 0000858877-18-000015:notes:112]

[0000858877-19-000003:notes:119]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | January 26, 2019 |  | July 28, 2018 |  | Balance Sheet Line Item |  | January 26, 2019 |  | July 28, 2018 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 1 |  |  | $ | 1 |  |  | Other current liabilities |  | $ | 8 |  |  | $ | — |  |
| Interest rate derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 13 |  |  | 10 |  |
| Interest rate derivatives | Other assets |  | 12 |  |  | — |  |  | Other long-term liabilities |  | 15 |  |  | 62 |  |
| Total |  |  | 13 |  |  | 1 |  |  |  |  | 36 |  |  | 72 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 10 |  |  | 1 |  |  | Other current liabilities |  | 4 |  |  | 2 |  |
| Total |  |  | 10 |  |  | 1 |  |  |  |  | 4 |  |  | 2 |  |
| Total |  |  | $ | 23 |  |  | $ | 2 |  |  |  |  | $ | 40 |  |  | $ | 74 |  |

[0000858877-19-000003:notes:120]
[same as prior period, unchanged from 0000858877-18-000015:notes:114]

[0000858877-19-000003:notes:121]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE THREE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THETHREE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | January 26, 2019 |  | January 27, 2018 |  | Line Item in Statements of Operations |  | January 26, 2019 |  | January 27, 2018 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (6 | ) |  | $ | 30 |  |  | Revenue — product |  | $ | 1 |  |  | $ | — |  |
|  |  |  |  |  |  | Revenue — service |  | 1 |  |  | — |  |
|  |  |  |  |  |  | Cost of sales — service |  | (1 | ) |  | 4 |  |
|  |  |  |  |  |  | Operating expenses |  | — |  |  | 14 |  |
| Total |  | $ | (6 | ) |  | $ | 30 |  |  |  |  | $ | 1 |  |  | $ | 18 |  |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (1 | ) |  | $ | (12 | ) |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-19-000003:notes:122]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE SIX MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THESIX MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | January 26, 2019 |  | January 27, 2018 |  | Line Item in Statements of Operations |  | January 26, 2019 |  | January 27, 2018 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (10 | ) |  | $ | 38 |  |  | Revenue — product |  | $ | 1 |  |  | $ | — |  |
|  |  |  |  |  |  | Revenue — service |  | 2 |  |  | — |  |
|  |  |  |  |  |  | Cost of sales — service |  | (1 | ) |  | 7 |  |
|  |  |  |  |  |  | Operating expenses |  | (1 | ) |  | 24 |  |
| Total |  | $ | (10 | ) |  | $ | 38 |  |  |  |  | $ | 1 |  |  | $ | 31 |  |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 3 |  |  | $ | (17 | ) |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-19-000003:notes:123]
As of January 26, 2019, we estimate that approximately $9 million of net derivative losses related to our cash flow hedges included in accumulated other comprehensive income (AOCI) will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-19-000003:notes:124]
[same as prior period, unchanged from 0000858877-18-000015:notes:117]

[0000858877-19-000003:notes:125]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES) FOR THESIX MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (1 | ) |  | $ | 66 |  |  | $ | (28 | ) |  | $ | 73 |  |
| Total return swaps—deferred compensation |  | Operating expenses |  | (9 | ) |  | 39 |  |  | (33 | ) |  | 54 |  |
|  |  | Cost of sales — product |  | — |  |  | 1 |  |  | (1 | ) |  | 1 |  |
|  |  | Cost of sales — service |  | (1 | ) |  | 1 |  |  | (2 | ) |  | 2 |  |
|  |  | Other income (loss), net |  | (4 | ) |  | (3 | ) |  | (8 | ) |  | (5 | ) |
| Equity derivatives |  | Other income (loss), net |  | — |  |  | 2 |  |  | 1 |  |  | 3 |  |
| Total |  |  |  | $ | (15 | ) |  | $ | 106 |  |  | $ | (71 | ) |  | $ | 128 |  |

[0000858877-19-000003:notes:126]
[same as prior period, unchanged from 0000858877-18-000015:notes:119]

[0000858877-19-000003:notes:127]
|  | January 26, 2019 |  | July 28, 2018 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 890 |  |  | $ | 147 |  |
| Interest rate derivatives | 6,750 |  |  | 6,750 |  |
| Net investment hedging instruments | 299 |  |  | 250 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,643 |  |  | 2,298 |  |
| Total return swaps—deferred compensation | 536 |  |  | 566 |  |
| Total | $ | 11,118 |  |  | $ | 10,011 |  |

[0000858877-19-000003:notes:128]
[same as prior period, unchanged from 0000858877-18-000015:notes:121]

[0000858877-19-000003:notes:129]
[same as prior period, unchanged from 0000858877-18-000015:notes:122]

[0000858877-19-000003:notes:130]
|  | January 26, 2019 |
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEETS |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETSBUT WITH LEGAL RIGHTS TO OFFSET |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |  | $ | (12 | ) |  | $ | (11 | ) |  | $ | — |  |
| Derivatives liabilities | $ | 40 |  |  | $ | — |  |  | $ | 40 |  |  | $ | (12 | ) |  | $ | (19 | ) |  | $ | 9 |  |

[0000858877-19-000003:notes:131]
[same as prior period, unchanged from 0000858877-18-000015:notes:124]

[0000858877-19-000003:notes:132]
[same as prior period, unchanged from 0000858877-18-000015:notes:125]

[0000858877-19-000003:notes:133]
[same as prior period, unchanged from 0000858877-18-000015:notes:126]

[0000858877-19-000003:notes:134]
[same as prior period, unchanged from 0000858877-18-000015:notes:127]

[0000858877-19-000003:notes:135]
[same as prior period, unchanged from 0000858877-18-000015:notes:128]

[0000858877-19-000003:notes:136]
[same as prior period, unchanged from 0000858877-18-000015:notes:129]

[0000858877-19-000003:notes:137]
[same as prior period, unchanged from 0000858877-18-000015:notes:130]

[0000858877-19-000003:notes:138]
Interest Rate Derivatives, Investments   Our primary objective for holding available-for-sale debt investments is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, we may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of January 26, 2019 and July 28, 2018, we did not have any outstanding interest rate derivatives related to our available-for-sale debt investments.

[0000858877-19-000003:notes:139]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt  In the first six months of fiscal 2019, we did not enter into any interest rate swaps. In prior fiscal years, we entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2019 through 2025. Under these interest rate swaps, we receive fixed-rate interest payments and make interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps was reflected in other assets and other current and long-term liabilities.

[0000858877-19-000003:notes:140]
[same as prior period, unchanged from 0000858877-18-000015:notes:133]

[0000858877-19-000003:notes:141]
[same as prior period, unchanged from 0000858877-18-000015:notes:134]

[0000858877-19-000003:notes:142]
[same as prior period, unchanged from 0000858877-18-000015:notes:135]

[0000858877-19-000003:notes:143]
[same as prior period, unchanged from 0000858877-18-000015:notes:136]

[0000858877-19-000003:notes:144]
[same as prior period, unchanged from 0000858877-18-000015:notes:137]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-19-000003:notes:145]
[same as prior period, unchanged from 0000858877-18-000015:notes:138]

[0000858877-19-000003:notes:146]
Amounts may not sum due to rounding.

[0000858877-19-000003:notes:147]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions ("SPVSS") business. Total revenue includes SPVSS business revenue of $0 and $230 million for the second quarter of fiscal 2019 and 2018, respectively, and $168 million and $478 million for the first six months of fiscal 2019 and 2018, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-19-000003:notes:148]
[same as prior period, unchanged from 0000858877-18-000015:notes:139]

[0000858877-19-000003:notes:149]
[same as prior period, unchanged from 0000858877-18-000015:notes:140]

[0000858877-19-000003:notes:150]
Stock Incentive Plan Program Description    As of January 26, 2019, we had one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with Cisco. The number and frequency of share-based awards are based on competitive practices, operating results of Cisco, government regulations, and other factors. Our primary stock incentive plan is summarized as follows:

[0000858877-19-000003:notes:151]
2005 Plan    As of January 26, 2019, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus shares from certain previous plans that are forfeited or are terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan. In addition, starting November 19, 2013, shares withheld by Cisco from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-19-000003:notes:152]
Pursuant to an amendment approved by our shareholders on November 12, 2009, the number of shares available for issuance under the 2005 Plan is reduced by 1.5 shares for each share awarded as a stock grant or a stock unit, and any shares underlying awards outstanding from certain previous plans that expire unexercised at the end of their maximum terms become available for reissuance under the 2005 Plan. The 2005 Plan permits the granting of stock options, restricted stock, and restricted stock units ("RSUs"), the vesting of which may be performance-based or market-based along with the requisite service requirement, and stock appreciation rights to employees (including employee directors and officers), consultants of Cisco and its subsidiaries and affiliates, and non-employee directors of Cisco. Stock options and stock appreciation rights granted under the 2005 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date. The expiration date for stock options and stock appreciation rights shall be no later than 10 years from the grant date.

[0000858877-19-000003:notes:153]
[same as prior period, unchanged from 0000858877-18-000015:notes:144]

[0000858877-19-000003:notes:154]
[same as prior period, unchanged from 0000858877-18-000015:notes:145]

[0000858877-19-000003:notes:155]
We have an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 721 million shares of our common stock have been reserved for issuance as of January 26, 2019. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of our stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. The Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Purchase Plan are sold pursuant to exercised purchase rights. Under the Purchase Plan, we issued 9 million shares during the second quarter and first six months of fiscal 2019 and 12 million shares during the second quarter and first six months of fiscal 2018.  As of January 26, 2019, 169 million shares were available for issuance under the Purchase Plan.

[0000858877-19-000003:notes:156]
[same as prior period, unchanged from 0000858877-18-000015:notes:147]

[0000858877-19-000003:notes:157]
[same as prior period, unchanged from 0000858877-18-000015:notes:148]

[0000858877-19-000003:notes:158]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Cost of sales—product | $ | 22 |  |  | $ | 23 |  |  | $ | 45 |  |  | $ | 46 |  |
| Cost of sales—service | 31 |  |  | 31 |  |  | 64 |  |  | 65 |  |
| Share-based compensation expense in cost of sales | 53 |  |  | 54 |  |  | 109 |  |  | 111 |  |
| Research and development | 133 |  |  | 134 |  |  | 263 |  |  | 270 |  |
| Sales and marketing | 125 |  |  | 135 |  |  | 262 |  |  | 270 |  |
| General and administrative | 65 |  |  | 64 |  |  | 127 |  |  | 128 |  |
| Restructuring and other charges | 19 |  |  | 12 |  |  | 42 |  |  | 18 |  |
| Share-based compensation expense in operating expenses | 342 |  |  | 345 |  |  | 694 |  |  | 686 |  |
| Total share-based compensation expense | $ | 395 |  |  | $ | 399 |  |  | $ | 803 |  |  | $ | 797 |  |
| Income tax benefit for share-based compensation | $ | 126 |  |  | $ | 96 |  |  | $ | 291 |  |  | $ | 271 |  |

[0000858877-19-000003:notes:159]
As of January 26, 2019, the total compensation cost related to unvested share-based awards not yet recognized was $3.2 billion which is expected to be recognized over approximately 2.7 years on a weighted-average basis.

[0000858877-19-000003:notes:160]
[same as prior period, unchanged from 0000858877-18-000015:notes:151]

[0000858877-19-000003:notes:161]
[same as prior period, unchanged from 0000858877-18-000015:notes:152]

[0000858877-19-000003:notes:162]
|  | Share-Based Awards Available for Grant |
| BALANCE AT JULY 29, 2017 | 272 |  |
| Restricted stock, stock units, and other share-based awards granted | (70 | ) |
| Share-based awards canceled/forfeited/expired | 18 |  |
| Shares withheld for taxes and not issued | 25 |  |
| BALANCE AT JULY 28, 2018 | 245 |  |
| Restricted stock, stock units, and other share-based awards granted | (37 | ) |
| Share-based awards canceled/forfeited/expired | 12 |  |
| Shares withheld for taxes and not issued | 15 |  |
| Other | 1 |  |
| BALANCE AT JANUARY 26, 2019 | 236 |  |

[0000858877-19-000003:notes:163]
[same as prior period, unchanged from 0000858877-18-000015:notes:154]

[0000858877-19-000003:notes:164]
[same as prior period, unchanged from 0000858877-18-000015:notes:155]

[0000858877-19-000003:notes:165]
[same as prior period, unchanged from 0000858877-18-000015:notes:156]

[0000858877-19-000003:notes:166]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 29, 2017 | 141 |  |  | $ | 26.94 |  |  |  |
| Granted | 46 |  |  | 35.62 |  |  |  |
| Assumed from acquisitions | 1 |  |  | 28.26 |  |  |  |
| Vested | (53 | ) |  | 26.02 |  |  | $ | 1,909 |  |
| Canceled/forfeited/other | (16 | ) |  | 28.37 |  |  |  |
| UNVESTED BALANCE AT JULY 28, 2018 | 119 |  |  | 30.56 |  |  |  |
| Granted | 25 |  |  | 44.69 |  |  |  |
| Vested | (31 | ) |  | 27.99 |  |  | $ | 1,453 |  |
| Canceled/forfeited/other | (10 | ) |  | 31.20 |  |  |  |
| UNVESTED BALANCE AT JANUARY 26, 2019 | 103 |  |  | $ | 34.66 |  |  |  |

[0000858877-19-000003:notes:167]
[same as prior period, unchanged from 0000858877-18-000015:notes:158]

[0000858877-19-000003:notes:168]
[same as prior period, unchanged from 0000858877-18-000015:notes:159]

[0000858877-19-000003:notes:169]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 29, 2017 | 12 |  |  | $ | 6.15 |  |
| Assumed from acquisitions | 3 |  |  | 8.20 |  |
| Exercised | (8 | ) |  | 5.77 |  |
| Canceled/forfeited/expired | (1 | ) |  | 8.75 |  |
| BALANCE AT JULY 28, 2018 | 6 |  |  | 7.18 |  |
| Exercised | (2 | ) |  | 6.79 |  |
| BALANCE AT JANUARY 26, 2019 | 4 |  |  | $ | 7.27 |  |

[0000858877-19-000003:notes:170]
The following table summarizes significant ranges of outstanding and exercisable stock options as of January 26, 2019 (in millions, except years and share prices):

[0000858877-19-000003:notes:171]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 35.00 |  | 4 |  |  | 5.3 |  | $ | 7.27 |  |  | $ | 167 |  |  | 3 |  |  | $ | 7.11 |  |  | $ | 130 |  |

[0000858877-19-000003:notes:172]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on our closing stock price of $46.13 as of January 25, 2019. The total number of in-the-money stock options exercisable as of January 26, 2019 was 3 million. As of July 28, 2018, 4 million outstanding stock options were exercisable and the weighted-average exercise price was $6.84.

[0000858877-19-000003:notes:173]
[same as prior period, unchanged from 0000858877-18-000015:notes:164]

[0000858877-19-000003:notes:174]
[same as prior period, unchanged from 0000858877-18-000015:notes:165]

[0000858877-19-000003:notes:175]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE BASEDRESTRICTED STOCK UNITS |
| Three Months Ended | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Number of shares granted (in millions) | 17 |  |  | 21 |  |  | — |  |  | — |  |
| Grant date fair value per share | $ | 44.53 |  |  | $ | 34.89 |  |  | N/A |  |  | $ | 32.47 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 2.8 | % |  | 3.1 | % |  | N/A |  |  | 3.2 | % |
| Range of risk-free interest rates | 0.0% – 2.8% |  |  | 0.0% – 2.1% |  |  | N/A |  |  | 1.0%-1.8% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | N/A |  |  | 13.2%-81.0% |  |

[0000858877-19-000003:notes:176]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE BASEDRESTRICTED STOCK UNITS |
| Six Months Ended | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Number of shares granted (in millions) | 23 |  |  | 28 |  |  | 2 |  |  | 3 |  |
| Grant date fair value per share | $ | 44.48 |  |  | $ | 33.50 |  |  | $ | 47.00 |  |  | $ | 31.31 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 2.8 | % |  | 3.2 | % |  | 2.8 | % |  | 3.6 | % |
| Range of risk-free interest rates | 0.0% – 2.9% |  |  | 0.0% – 2.1% |  |  | 2.1% – 3.0% |  |  | 1.0%-1.8% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 13.0% – 65.2% |  |  | 13.2%-81.0% |  |

[0000858877-19-000003:notes:177]
[same as prior period, unchanged from 0000858877-18-000015:notes:167]


## us-gaap:EarningsPerSharePolicyTextBlock

[0000858877-19-000003:notes:178]
[same as prior period, unchanged from 0000858877-18-000015:notes:168]


## us-gaap:EarningsPerShareTextBlock

[0000858877-19-000003:notes:179]
Net Income (Loss) per Share

[0000858877-19-000003:notes:180]
The following table presents the calculation of basic and diluted net income (loss) per share (in millions, except per-share amounts):

[0000858877-19-000003:notes:181]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Net income (loss) | $ | 2,822 |  |  | $ | (8,778 | ) |  | $ | 6,371 |  |  | $ | (6,384 | ) |
| Weighted-average shares—basic | 4,470 |  |  | 4,924 |  |  | 4,517 |  |  | 4,942 |  |
| Effect of dilutive potential common shares | 35 |  |  | — |  |  | 40 |  |  | — |  |
| Weighted-average shares—diluted | 4,505 |  |  | 4,924 |  |  | 4,557 |  |  | 4,942 |  |
| Net income (loss) per share—basic | $ | 0.63 |  |  | $ | (1.78 | ) |  | $ | 1.41 |  |  | $ | (1.29 | ) |
| Net income (loss) per share—diluted | $ | 0.63 |  |  | $ | (1.78 | ) |  | $ | 1.40 |  |  | $ | (1.29 | ) |

[0000858877-19-000003:notes:182]
We excluded antidilutive employee-share based awards of 27 million and 28 million for the second quarter and first six months of fiscal 2019, respectively. For the second quarter and first six months of fiscal 2018, we excluded the impact of potentially dilutive common shares from the calculation of net income (loss) per share as the inclusion would have an antidilutive effect.


## us-gaap:EquitySecuritiesWithoutReadilyDeterminableFairValueTableTextBlock

[0000858877-19-000003:notes:183]
We recorded adjustments to the carrying value of our non-marketable equity securities measured using the measurement alternative during the second quarter and first six months of fiscal 2019 as follows (in millions):

[0000858877-19-000003:notes:184]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 26, 2019 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |  |  |
| Upward adjustments | $ | 14 |  |  | $ | 24 |  |
| Downward adjustments, including impairments | (2 | ) |  | (18 | ) |
| Net upward adjustments | $ | 12 |  |  | $ | 6 |  |

[0000858877-19-000003:notes:185]
Gains and losses recognized on our marketable and non-marketable equity securities for the second quarter and first six months of fiscal 2019 are summarized below (in millions):

[0000858877-19-000003:notes:186]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 26, 2019 |
| Net gains and losses recognized during the period on equity investments | $ | 67 |  |  | $ | 75 |  |
| Less: Net gains and losses recognized on equity investments sold | 5 |  |  | (7 | ) |
| Unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | 72 |  |  | $ | 68 |  |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-19-000003:notes:187]
[same as prior period, unchanged from 0000858877-18-000015:notes:176]

[0000858877-19-000003:notes:188]
|  | TOTAL GAINS (LOSSES) FOR THE THREE MONTHS ENDED |  | TOTAL GAINS (LOSSES) FOR THE SIX MONTHS ENDED |
|  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Non-marketable equity securities | $ | 12 |  |  | $ | (18 | ) |  | $ | 6 |  |  | $ | (39 | ) |
| Property held for sale—land and buildings | — |  |  | 20 |  |  | — |  |  | 20 |  |
| Total gains (losses) for nonrecurring measurements | $ | 12 |  |  | $ | 2 |  |  | $ | 6 |  |  | $ | (19 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-19-000003:notes:189]
[same as prior period, unchanged from 0000858877-18-000015:notes:178]

[0000858877-19-000003:notes:190]
[same as prior period, unchanged from 0000858877-18-000015:notes:179]

[0000858877-19-000003:notes:191]
[same as prior period, unchanged from 0000858877-18-000015:notes:180]

[0000858877-19-000003:notes:192]
[same as prior period, unchanged from 0000858877-18-000015:notes:181]

[0000858877-19-000003:notes:193]
[same as prior period, unchanged from 0000858877-18-000015:notes:182]

[0000858877-19-000003:notes:194]
[same as prior period, unchanged from 0000858877-18-000015:notes:183]

[0000858877-19-000003:notes:195]
[same as prior period, unchanged from 0000858877-18-000015:notes:184]

[0000858877-19-000003:notes:196]
[same as prior period, unchanged from 0000858877-18-000015:notes:185]

[0000858877-19-000003:notes:197]
[same as prior period, unchanged from 0000858877-18-000015:notes:186]

[0000858877-19-000003:notes:198]
|  | JANUARY 26, 2019FAIR VALUE MEASUREMENTS |  | JULY 28, 2018FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 7,888 |  |  | $ | — |  |  | $ | 7,888 |  |  | $ | 6,890 |  |  | $ | — |  |  | $ | 6,890 |  |
| Commercial paper | — |  |  | 99 |  |  | 99 |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposit | — |  |  | 25 |  |  | 25 |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 3,472 |  |  | 3,472 |  |  | — |  |  | 7,275 |  |  | 7,275 |  |
| U.S. government agency securities | — |  |  | 354 |  |  | 354 |  |  | — |  |  | 727 |  |  | 727 |  |
| Non-U.S. government and agency securities | — |  |  | 115 |  |  | 115 |  |  | — |  |  | 208 |  |  | 208 |  |
| Corporate debt securities | — |  |  | 24,753 |  |  | 24,753 |  |  | — |  |  | 27,364 |  |  | 27,364 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,434 |  |  | 1,434 |  |  | — |  |  | 1,435 |  |  | 1,435 |  |
| Commercial paper | — |  |  | 243 |  |  | 243 |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposit | — |  |  | 115 |  |  | 115 |  |  | — |  |  | — |  |  | — |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 62 |  |  | — |  |  | 62 |  |  | 605 |  |  | — |  |  | 605 |  |
| Derivative assets | — |  |  | 23 |  |  | 23 |  |  | — |  |  | 2 |  |  | 2 |  |
| Total | $ | 7,950 |  |  | $ | 30,633 |  |  | $ | 38,583 |  |  | $ | 7,495 |  |  | $ | 37,011 |  |  | $ | 44,506 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 40 |  |  | $ | 40 |  |  | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |
| Total | $ | — |  |  | $ | 40 |  |  | $ | 40 |  |  | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |

[0000858877-19-000003:notes:199]
[same as prior period, unchanged from 0000858877-18-000015:notes:188]

[0000858877-19-000003:notes:200]
[same as prior period, unchanged from 0000858877-18-000015:notes:189]

[0000858877-19-000003:notes:201]
[same as prior period, unchanged from 0000858877-18-000015:notes:190]

[0000858877-19-000003:notes:202]
The fair value of property held for sale was measured with the assistance of third-party valuation models, which used discounted cash flow techniques as part of their analysis. The fair value measurement was categorized as Level 3, as significant unobservable inputs were used in the valuation report. The impairment charge as a result of the valuations, which represented the difference between the fair value less cost to sell and the carrying amount of the assets held for sale, was included in restructuring and other charges. The remaining carrying value of property held for sale that was impaired was zero as of January 27, 2018.

[0000858877-19-000003:notes:203]
[same as prior period, unchanged from 0000858877-18-000015:notes:191]

[0000858877-19-000003:notes:204]
The fair value of short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of long-term loan receivables and financed service contracts as of January 26, 2019 and July 28, 2018 was $3.3 billion and $3.6 billion, respectively. The estimated fair value of long-term loan receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-19-000003:notes:205]
As of January 26, 2019, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of January 26, 2019, the fair value of our senior notes and other long-term debt was $26.5 billion with a carrying amount of $25.6 billion. This compares to a fair value of $26.4 billion and a carrying amount of $25.6 billion as of July 28, 2018. The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-19-000003:notes:206]
Gross receivables, excluding residual value, less unearned income categorized by our internal credit risk rating as of January 26, 2019 and July 28, 2018 are summarized as follows (in millions):

[0000858877-19-000003:notes:207]
|  | INTERNAL CREDIT RISK RATING |
| January 26, 2019 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,233 |  |  | $ | 1,066 |  |  | $ | 46 |  |  | $ | 2,345 |  |
| Loan receivables | 3,000 |  |  | 1,875 |  |  | 51 |  |  | 4,926 |  |
| Financed service contracts | 1,390 |  |  | 995 |  |  | 13 |  |  | 2,398 |  |
| Total | $ | 5,623 |  |  | $ | 3,936 |  |  | $ | 110 |  |  | $ | 9,669 |  |

[0000858877-19-000003:notes:208]
[same as prior period, unchanged from 0000858877-18-000015:notes:196]


## us-gaap:FinancingReceivablesTextBlock

[0000858877-19-000003:notes:209]
[same as prior period, unchanged from 0000858877-18-000015:notes:197]

[0000858877-19-000003:notes:210]
[same as prior period, unchanged from 0000858877-18-000015:notes:198]

[0000858877-19-000003:notes:211]
[same as prior period, unchanged from 0000858877-18-000015:notes:199]

[0000858877-19-000003:notes:212]
[same as prior period, unchanged from 0000858877-18-000015:notes:200]

[0000858877-19-000003:notes:213]
| January 26, 2019 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,483 |  |  | $ | 4,926 |  |  | $ | 2,398 |  |  | $ | 9,807 |  |
| Residual value | 153 |  |  | — |  |  | — |  |  | 153 |  |
| Unearned income | (138 | ) |  | — |  |  | — |  |  | (138 | ) |
| Allowance for credit loss | (127 | ) |  | (64 | ) |  | (9 | ) |  | (200 | ) |
| Total, net | $ | 2,371 |  |  | $ | 4,862 |  |  | $ | 2,389 |  |  | $ | 9,622 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,121 |  |  | $ | 2,502 |  |  | $ | 1,434 |  |  | $ | 5,057 |  |
| Noncurrent | 1,250 |  |  | 2,360 |  |  | 955 |  |  | 4,565 |  |
| Total, net | $ | 2,371 |  |  | $ | 4,862 |  |  | $ | 2,389 |  |  | $ | 9,622 |  |

[0000858877-19-000003:notes:214]
[same as prior period, unchanged from 0000858877-18-000015:notes:202]

[0000858877-19-000003:notes:215]
Future minimum lease payments to Cisco on lease receivables as of January 26, 2019 are summarized as follows (in millions):

[0000858877-19-000003:notes:216]
| Fiscal Year | Amount |
| 2019 (remaining six months) | $ | 637 |  |
| 2020 | 855 |  |
| 2021 | 532 |  |
| 2022 | 309 |  |
| 2023 | 126 |  |
| Thereafter | 24 |  |
| Total | $ | 2,483 |  |

[0000858877-19-000003:notes:217]
[same as prior period, unchanged from 0000858877-18-000015:notes:205]

[0000858877-19-000003:notes:218]
[same as prior period, unchanged from 0000858877-18-000015:notes:206]

[0000858877-19-000003:notes:219]
[same as prior period, unchanged from 0000858877-18-000015:notes:207]

[0000858877-19-000003:notes:220]
[same as prior period, unchanged from 0000858877-18-000015:notes:208]

[0000858877-19-000003:notes:221]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of January 26, 2019 and July 28, 2018 (in millions):

[0000858877-19-000003:notes:222]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| January 26, 2019 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 79 |  |  | $ | 34 |  |  | $ | 152 |  |  | $ | 265 |  |  | $ | 2,080 |  |  | $ | 2,345 |  |  | $ | 3 |  |  | $ | 3 |  |
| Loan receivables | 73 |  |  | 39 |  |  | 235 |  |  | 347 |  |  | 4,579 |  |  | 4,926 |  |  | 28 |  |  | 28 |  |
| Financed service contracts | 74 |  |  | 38 |  |  | 280 |  |  | 392 |  |  | 2,006 |  |  | 2,398 |  |  | 2 |  |  | 2 |  |
| Total | $ | 226 |  |  | $ | 111 |  |  | $ | 667 |  |  | $ | 1,004 |  |  | $ | 8,665 |  |  | $ | 9,669 |  |  | $ | 33 |  |  | $ | 33 |  |

[0000858877-19-000003:notes:223]
[same as prior period, unchanged from 0000858877-18-000015:notes:211]

[0000858877-19-000003:notes:224]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract. The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $396 million and $503 million as of January 26, 2019 and July 28, 2018, respectively.

[0000858877-19-000003:notes:225]
As of January 26, 2019, we had financing receivables of $247 million, net of unbilled or current receivables, that were in the category of 91 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $182 million as of July 28, 2018.

[0000858877-19-000003:notes:226]
[same as prior period, unchanged from 0000858877-18-000015:notes:214]

[0000858877-19-000003:notes:227]
[same as prior period, unchanged from 0000858877-18-000015:notes:215]

[0000858877-19-000003:notes:228]
Typically, we also consider receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. These balances, as of January 26, 2019 and July 28, 2018, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-19-000003:notes:229]
[same as prior period, unchanged from 0000858877-18-000015:notes:217]

[0000858877-19-000003:notes:230]
[same as prior period, unchanged from 0000858877-18-000015:notes:218]

[0000858877-19-000003:notes:231]
[same as prior period, unchanged from 0000858877-18-000015:notes:219]

[0000858877-19-000003:notes:232]
|  | January 26, 2019 |  | July 28, 2018 |
| Operating lease assets | $ | 529 |  |  | $ | 356 |  |
| Accumulated depreciation | (370 | ) |  | (238 | ) |
| Operating lease assets, net | $ | 159 |  |  | $ | 118 |  |

[0000858877-19-000003:notes:233]
Minimum future rentals on noncancelable operating leases as of January 26, 2019 are summarized as follows (in millions):

[0000858877-19-000003:notes:234]
| Fiscal Year | Amount |
| 2019 (remaining six months) | $ | 81 |  |
| 2020 | 111 |  |
| 2021 | 48 |  |
| 2022 | 5 |  |
| Total | $ | 245 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-19-000003:notes:235]
[same as prior period, unchanged from 0000858877-18-000015:notes:223]

[0000858877-19-000003:notes:236]
[same as prior period, unchanged from 0000858877-18-000015:notes:224]

[0000858877-19-000003:notes:237]
The following table presents the goodwill allocated to our reportable segments as of January 26, 2019 and during the first six months of fiscal 2019 (in millions):

[0000858877-19-000003:notes:238]
|  | Balance at July 28, 2018 |  | Acquisitions & Divestitures |  | Other |  | Balance at January 26, 2019 |
| Americas | $ | 19,998 |  |  | $ | 1,082 |  |  | $ | (79 | ) |  | $ | 21,001 |  |
| EMEA | 7,529 |  |  | 429 |  |  | (22 | ) |  | 7,936 |  |
| APJC | 4,179 |  |  | 190 |  |  | (13 | ) |  | 4,356 |  |
| Total | $ | 31,706 |  |  | $ | 1,701 |  |  | $ | (114 | ) |  | $ | 33,293 |  |

[0000858877-19-000003:notes:239]
[same as prior period, unchanged from 0000858877-18-000015:notes:227]

[0000858877-19-000003:notes:240]
[same as prior period, unchanged from 0000858877-18-000015:notes:228]

[0000858877-19-000003:notes:241]
[same as prior period, unchanged from 0000858877-18-000015:notes:229]

[0000858877-19-000003:notes:242]
There were no impairment charges related to purchased intangible assets for the second quarter and first six months of fiscal 2019 and for the corresponding periods of fiscal 2018. Impairment charges are primarily a result of declines in estimated fair values of certain purchased intangible assets resulting from the reduction or elimination of expected future cash flows associated with certain of our technology and in-process research and development (IPR&D) intangible assets.

[0000858877-19-000003:notes:243]
The estimated future amortization expense of purchased intangible assets with finite lives as of January 26, 2019 is as follows (in millions):

[0000858877-19-000003:notes:244]
| Fiscal Year | Amount |
| 2019 (remaining six months) | $ | 382 |  |
| 2020 | $ | 726 |  |
| 2021 | $ | 530 |  |
| 2022 | $ | 274 |  |
| 2023 | $ | 133 |  |
| Thereafter | $ | 45 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-19-000003:notes:245]
[same as prior period, unchanged from 0000858877-18-000015:notes:233]

[0000858877-19-000003:notes:246]
The effective tax rate for the first six months of fiscal 2019 includes a $152 million tax benefit relating to indirect effects from adoption of ASC 606 at the beginning of fiscal 2019.

[0000858877-19-000003:notes:247]
On December 22, 2017, the Tax Cuts and Jobs Act (the "Tax Act") was enacted. The Tax Act significantly revises the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (“federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries. The enactment of the Tax Act resulted in us recording a provisional tax expense of $10.4 billion in fiscal 2018. In the second quarter of fiscal 2019, we completed our accounting relating to the Tax Act and recorded an additional $58 million of tax expense. The total tax charge as a result of the Tax Act was $10.5 billion, consisting of $8.2 billion of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries, $1.2 billion of foreign withholding tax and $1.1 billion of tax expense for DTA re-measurement. The tax expense related to the U.S. transition tax on accumulated earnings in foreign subsidiaries is net of a $0.9 billion benefit related to U.S. taxation of deemed foreign dividends in the transition fiscal year. This benefit may be reduced or eliminated in future legislation. If such legislation is enacted, we will record the impact of the legislation in the quarter of enactment.

[0000858877-19-000003:notes:248]
[same as prior period, unchanged from 0000858877-18-000015:notes:237]

[0000858877-19-000003:notes:249]
As of January 26, 2019, we had $1.8 billion of unrecognized tax benefit, of which $1.6 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters. We estimate that the unrecognized tax benefits at January 26, 2019 could be reduced by approximately $50 million in the next 12 months.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-19-000003:notes:250]
The following table summarizes the maturities of our available-for-sale debt investments as of January 26, 2019 (in millions):

[0000858877-19-000003:notes:251]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 10,131 |  |  | $ | 10,104 |  |
| After 1 year through 5 years | 17,704 |  |  | 17,426 |  |
| After 5 years through 10 years | 1,568 |  |  | 1,507 |  |
| After 10 years | 15 |  |  | 15 |  |
| Mortgage-backed securities with no single maturity | 1,475 |  |  | 1,434 |  |
| Total | $ | 30,893 |  |  | $ | 30,486 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-19-000003:notes:252]
Available-for-Sale Debt Investments and Equity Investments

[0000858877-19-000003:notes:253]
The following table summarizes our available-for-sale debt investments and equity investments (in millions):

[0000858877-19-000003:notes:254]
|  | January 26, 2019 |  | July 28, 2018 |
| Available-for-sale debt investments | $ | 30,486 |  |  | $ | 37,009 |  |
| Marketable equity securities | 62 |  |  | 605 |  |
| Total investments | 30,548 |  |  | 37,614 |  |
| Non-marketable equity securities included in other assets (1) | 1,133 |  |  | 978 |  |
| Equity method investments included in other assets | 115 |  |  | 118 |  |
| Total | $ | 31,796 |  |  | $ | 38,710 |  |

[0000858877-19-000003:notes:255]
(1) We held equity interests in certain private equity funds of $0.6 billion as of January 26, 2019 which are accounted for under the NAV practical expedient following the adoption of ASU 2016-01, Financial Instruments, in the first quarter of fiscal 2019.

[0000858877-19-000003:notes:256]
| (a) | Summary of Available-for-Sale Debt Investments |

[0000858877-19-000003:notes:257]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-19-000003:notes:258]
| January 26, 2019 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 3,486 |  |  | $ | — |  |  | $ | (14 | ) |  | $ | 3,472 |  |
| U.S. government agency securities | 356 |  |  | — |  |  | (2 | ) |  | 354 |  |
| Non-U.S. government and agency securities | 115 |  |  | — |  |  | — |  |  | 115 |  |
| Corporate debt securities | 25,103 |  |  | 16 |  |  | (366 | ) |  | 24,753 |  |
| U.S. agency mortgage-backed securities | 1,475 |  |  | 1 |  |  | (42 | ) |  | 1,434 |  |
| Commercial paper | 243 |  |  | — |  |  | — |  |  | 243 |  |
| Certificates of deposit | 115 |  |  | — |  |  | — |  |  | 115 |  |
| Total (1) | $ | 30,893 |  |  | $ | 17 |  |  | $ | (424 | ) |  | $ | 30,486 |  |

[0000858877-19-000003:notes:259]
| July 28, 2018 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 7,318 |  |  | $ | — |  |  | $ | (43 | ) |  | $ | 7,275 |  |
| U.S. government agency securities | 732 |  |  | — |  |  | (5 | ) |  | 727 |  |
| Non-U.S. government and agency securities | 209 |  |  | — |  |  | (1 | ) |  | 208 |  |
| Corporate debt securities | 27,765 |  |  | 44 |  |  | (445 | ) |  | 27,364 |  |
| U.S. agency mortgage-backed securities | 1,488 |  |  | — |  |  | (53 | ) |  | 1,435 |  |
| Total (1) | $ | 37,512 |  |  | $ | 44 |  |  | $ | (547 | ) |  | $ | 37,009 |  |

[0000858877-19-000003:notes:260]
(1) Net unsettled investment purchases were $4 million and net unsettled investment sales were $1.5 billion as of January 26, 2019 and July 28, 2018, respectively and were included in other current assets and other current liabilities.

[0000858877-19-000003:notes:261]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-19-000003:notes:262]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-19-000003:notes:263]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Gross realized gains | $ | 1 |  |  | $ | 6 |  |  | $ | 3 |  |  | $ | 14 |  |
| Gross realized losses | (6 | ) |  | (102 | ) |  | (14 | ) |  | (106 | ) |
| Total | $ | (5 | ) |  | $ | (96 | ) |  | $ | (11 | ) |  | $ | (92 | ) |

[0000858877-19-000003:notes:264]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 26, 2019 and July 28, 2018 (in millions):

[0000858877-19-000003:notes:265]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 26, 2019 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 6 |  |  | $ | — |  |  | $ | 3,437 |  |  | $ | (14 | ) |  | $ | 3,443 |  |  | $ | (14 | ) |
| U.S. government agency securities | — |  |  | — |  |  | 344 |  |  | (2 | ) |  | 344 |  |  | (2 | ) |
| Non-U.S. government and agency securities | — |  |  | — |  |  | 115 |  |  | — |  |  | 115 |  |  | — |  |
| Corporate debt securities | 5,849 |  |  | (61 | ) |  | 15,108 |  |  | (305 | ) |  | 20,957 |  |  | (366 | ) |
| U.S. agency mortgage-backed securities | 47 |  |  | — |  |  | 1,216 |  |  | (42 | ) |  | 1,263 |  |  | (42 | ) |
| Total | $ | 5,902 |  |  | $ | (61 | ) |  | $ | 20,220 |  |  | $ | (363 | ) |  | $ | 26,122 |  |  | $ | (424 | ) |

[0000858877-19-000003:notes:266]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 28, 2018 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 2,966 |  |  | $ | (20 | ) |  | $ | 4,303 |  |  | $ | (23 | ) |  | $ | 7,269 |  |  | $ | (43 | ) |
| U.S. government agency securities | 206 |  |  | (2 | ) |  | 521 |  |  | (3 | ) |  | 727 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 105 |  |  | (1 | ) |  | 103 |  |  | — |  |  | 208 |  |  | (1 | ) |
| Corporate debt securities | 16,990 |  |  | (344 | ) |  | 3,511 |  |  | (101 | ) |  | 20,501 |  |  | (445 | ) |
| U.S. agency mortgage-backed securities | 826 |  |  | (24 | ) |  | 581 |  |  | (29 | ) |  | 1,407 |  |  | (53 | ) |
| Total | $ | 21,093 |  |  | $ | (391 | ) |  | $ | 9,019 |  |  | $ | (156 | ) |  | $ | 30,112 |  |  | $ | (547 | ) |

[0000858877-19-000003:notes:267]
There were no impairment charges related to our available-for-sale debt investments for the second quarter and first six months of fiscal 2019, and for the corresponding periods of fiscal 2018, respectively. For available-for-sale debt investments that were in an unrealized loss position as of January 26, 2019, we have determined that no other-than-temporary impairments were required to be recognized.

[0000858877-19-000003:notes:268]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-19-000003:notes:269]
| (b) | Summary of Equity Investments |

[0000858877-19-000003:notes:270]
| (c) | Securities Lending |

[0000858877-19-000003:notes:271]
We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending was $1.2 billion and $0.4 billion for the first six months of fiscal 2019 and fiscal 2018, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 26, 2019 and July 28, 2018, we had no outstanding securities lending transactions.

[0000858877-19-000003:notes:272]
| (d) | Variable Interest Entities |

[0000858877-19-000003:notes:273]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 26, 2019, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-19-000003:notes:274]
As of January 26, 2019, the carrying value of investments in privately held companies was $1.25 billion, of which $670 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, we have additional funding commitments of $192 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these variable interest entities.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000858877-19-000003:notes:275]
New Accounting Updates Recently Adopted

[0000858877-19-000003:notes:276]
Revenue Recognition  In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers, a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP on revenue recognition and eliminated industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. It also requires increased disclosures including the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

[0000858877-19-000003:notes:277]
ASC 606 allows two methods of adoption: i) retrospectively to each prior period presented (“full retrospective method”), or ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective method"). At the beginning of the first quarter of fiscal 2019, we adopted ASC 606 using the modified retrospective method to those contracts that were not completed as of July 28, 2018. Refer to Opening Balance Adjustments below for the impact of adoption on our Consolidated Financial Statements.

[0000858877-19-000003:notes:278]
We have implemented new accounting policies, systems, processes, and internal controls necessary to support the requirements of ASC 606.

[0000858877-19-000003:notes:279]
ASC 606 primarily impacts our revenue recognition for software arrangements and sales to two-tier distributors. In both areas, the new standard accelerates the recognition of revenue.

[0000858877-19-000003:notes:280]
The table below details the timing of when revenue was typically recognized under the prior revenue standard compared to the timing of when revenue is typically recognized under ASC 606 for these major areas:

[0000858877-19-000003:notes:281]
|  |  | Prior Revenue Standard |  | ASC 606 |
| Software arrangements: |  |  |  |  |
| Perpetual software licenses |  | Upfront |  | Upfront |
| Term software licenses |  | Ratable |  | Upfront |
| Security software licenses |  | Ratable |  | Ratable |
| Enterprise license agreements (software licenses) |  | Ratable |  | Upfront |
| Software support (maintenance) |  | Ratable |  | Ratable |
| Software-as-a-service |  | Ratable |  | Ratable |
| Two-tier distribution |  | Sell-Through |  | Sell-In |

[0000858877-19-000003:notes:282]
In addition to the above revenue recognition timing impacts, ASC 606 requires incremental contract acquisition costs (such as sales commissions) for customer contracts to be capitalized and amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the assets relates.

[0000858877-19-000003:notes:283]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

[0000858877-19-000003:notes:284]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or once delivery and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-19-000003:notes:285]
Significant Judgments

[0000858877-19-000003:notes:286]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-19-000003:notes:287]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes various rebate, cooperative marketing, and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

[0000858877-19-000003:notes:288]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license's utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a distinct performance obligation satisfied over the contract term.

[0000858877-19-000003:notes:289]
For the additional disclosures required as part of ASC 606 see Note 3.

[0000858877-19-000003:notes:290]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The most significant impact of this accounting standard update is that it requires the remeasurement of investments not accounted for under the equity method to be recorded at fair value through the Consolidated Statement of Operations at the end of each reporting period. The application of this accounting standard update increases the variability of other income (loss), net.

[0000858877-19-000003:notes:291]
Our equity investments are accounted for as follows:

[0000858877-19-000003:notes:292]
| • | Marketable equity securities have readily determinable fair value (RDFV) that are measured and recorded at fair value. |

[0000858877-19-000003:notes:293]
| • | Non-marketable equity securities do not have RDFV and are measured using a measurement alternative recorded at cost less any impairment, plus or minus changes resulting from qualifying observable price changes. For certain of these securities, we have elected to apply the net asset value (NAV) practical expedient. The NAV is the estimated fair value of these investments. |

[0000858877-19-000003:notes:294]
| • | Equity method investments are securities we do not control, but are able to exert significant influence over the investee. These investments are measured at cost less any impairment, plus or minus our share of equity method investee income or loss. |

[0000858877-19-000003:notes:295]
We adopted this accounting standard update beginning the first quarter of fiscal 2019. The standard was adopted using the modified retrospective method for our marketable equity securities and non-marketable equity securities measured using the NAV practical expedient. For our non-marketable equity securities measured using the measurement alternative, we applied the prospective method. Refer to Opening Balance Adjustments below for the impact of adoption on our Consolidated Balance Sheet.

[0000858877-19-000003:notes:296]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a modified retrospective basis. The ongoing impact of this standard will be facts and circumstances dependent on any transactions within its scope. Refer to Opening Balance Adjustments below for the impact of adoption on our Consolidated Balance Sheet.

[0000858877-19-000003:notes:297]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a retrospective basis. The application of this accounting standard update did not have an impact on our Consolidated Statements of Cash Flows.

[0000858877-19-000003:notes:298]
Restricted Cash in Statement of Cash Flows  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented. The application of this accounting standard update did not have a material impact on our Consolidated Statements of Cash Flows. Prior period information has been retrospectively adjusted due to the adoption of ASU 2016-18, Statement of Cash Flows, Restricted Cash at the beginning of the first quarter of fiscal 2019.

[0000858877-19-000003:notes:299]
Simplifying the Test for Goodwill Impairment  In January 2017, the FASB issued an accounting standard update that removes Step

[0000858877-19-000003:notes:300]
2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. We early adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a prospective basis. The application of this accounting standard update did not have any impact on our Consolidated Financial Statements.

[0000858877-19-000003:notes:301]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be fact dependent, but we expect that some transactions that were previously accounted for as business combinations or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.

[0000858877-19-000003:notes:302]
Opening Balance Adjustments

[0000858877-19-000003:notes:303]
The following table summarizes the cumulative effect of the changes made to the Consolidated Balance Sheet for the adoption of ASC 606, ASU 2016-01, Financial Instruments, and ASU 2016-16, Intra-Entity Transfers of Assets Other than Inventory (in millions):

[0000858877-19-000003:notes:304]
| Line Item in Consolidated Balance Sheet: |  | Balance at July 28, 2018 |  | New Revenue Recognition Standard |  | New Financial Instruments Standard |  | New Intra-Entity Transfers Standard |  | Adjusted Balance at July 29, 2018 |
| ASSETS |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 5,554 |  |  | $ | (104 | ) | (1) | $ | — |  |  | $ | — |  |  | $ | 5,450 |  |
| Inventories |  | $ | 1,846 |  |  | $ | (302 | ) | (2) | $ | — |  |  | $ | — |  |  | $ | 1,544 |  |
| Other current assets (includes capitalized contract acquisition costs) |  | $ | 2,940 |  |  | $ | 371 |  | (3), (4) | $ | — |  |  | $ | (25 | ) | (3) | $ | 3,286 |  |
| Deferred tax assets |  | $ | 3,219 |  |  | $ | (624 | ) | (3) | $ | (15 | ) | (3) | $ | 1,415 |  | (8) | $ | 3,995 |  |
| Other assets (includes capitalized contract acquisition costs) |  | $ | 1,582 |  |  | $ | 327 |  | (4) | $ | 136 |  | (7) | $ | (91 | ) | (3) | $ | 1,954 |  |
| TOTAL ASSETS |  | $ | 108,784 |  |  | $ | (332 | ) |  | $ | 121 |  |  | $ | 1,299 |  |  | $ | 109,872 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |  |  |
| Income taxes payable |  | $ | 1,004 |  |  | $ | — |  |  | $ | — |  |  | $ | 11 |  | (3) | $ | 1,015 |  |
| Deferred revenue — current |  | $ | 11,490 |  |  | $ | (1,702 | ) | (5) | $ | — |  |  | $ | — |  |  | $ | 9,788 |  |
| Other current liabilities |  | $ | 4,413 |  |  | $ | 33 |  | (6) | $ | — |  |  | $ | — |  |  | $ | 4,446 |  |
| Deferred revenue — non-current |  | $ | 8,195 |  |  | $ | (1,081 | ) | (5) | $ | — |  |  | $ | — |  |  | $ | 7,114 |  |
| Other long-term liabilities |  | $ | 1,434 |  |  | $ | 85 |  | (3) | $ | 13 |  | (3) | $ | — |  |  | $ | 1,532 |  |
| Retained earnings |  | $ | 1,233 |  |  | $ | 2,333 |  | (10) | $ | 283 |  | (10) | $ | 1,281 |  | (10) | $ | 5,130 |  |
| Accumulated other comprehensive income (loss) |  | $ | (849 | ) |  | $ | — |  |  | $ | (175 | ) | (9) | $ | 7 |  | (3) | $ | (1,017 | ) |
| TOTAL LIABILITIES AND EQUITY |  | $ | 108,784 |  |  | $ | (332 | ) |  | $ | 121 |  |  | $ | 1,299 |  |  | $ | 109,872 |  |

[0000858877-19-000003:notes:305]
(1) Primarily represents the decrease to accounts receivable related to the change in recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis

[0000858877-19-000003:notes:306]
(2) Primarily represents the reduction of inventory for the change from recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis

[0000858877-19-000003:notes:307]
(3) Includes the impacts to deferred tax assets, liabilities and other income tax balances

[0000858877-19-000003:notes:308]
(4) Primarily represents capitalized contract acquisition costs (e.g. commissions)

[0000858877-19-000003:notes:309]
(5) Primarily represents deferred revenue adjusted to retained earnings primarily due to the change in revenue recognition for certain software arrangements from ratable to upfront, recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis. Of this total $2.8 billion adjustment, $2.6 billion related to product deferred revenue, of which $1.3 billion relates to our recurring software and subscription offers, $0.6 billion relates to two-tier distribution, and the remainder relates to non-recurring software and other adjustments.

[0000858877-19-000003:notes:310]
(6) Primarily represents the reclassification of accounts receivable contra balances to other current liabilities, adjustments to rebate liabilities for the change from recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis, and reclassifications from other current liabilities for amounts that are not contract liabilities under ASC 606

[0000858877-19-000003:notes:311]
(7) Represents the adjustment due to the remeasurement of non-marketable equity investments at fair value

[0000858877-19-000003:notes:312]
(8) Primarily represents the change in net deferred tax assets related to unrecognized income tax effects of intra-entity asset transfers

[0000858877-19-000003:notes:313]
(9) Represents the reclassification of net unrealized gains from accumulated other comprehensive income (loss) to retained earnings

[0000858877-19-000003:notes:314]
(10) Retained earnings impact from the adjustments noted above

[0000858877-19-000003:notes:315]
Impact of ASC 606 Adoption

[0000858877-19-000003:notes:316]
The application of ASC 606 increased our total revenue by $267 million and $516 million in the second quarter and first six months of fiscal 2019, respectively. The application of ASC 606 did not have a material impact to either our cost of sales or our operating expenses in the second quarter and first six months of fiscal 2019. We recognized a $152 million benefit to our provision for income taxes relating to indirect effects from the adoption of ASC 606 in the first quarter of fiscal 2019. For additional information regarding ASC 606, see Note 3 to the Consolidated Financial Statements.

[0000858877-19-000003:notes:317]
In connection with the adoption of ASC 606, we recorded a transition adjustment to increase retained earnings by $2.3 billion. See above for the transition impact of ASC 606 by balance sheet line item. As of January 26, 2019, the balance sheet changes attributable to ASC 606 related to accounts receivable, inventories, and deferred revenue were not materially different than the impacts upon adoption. In connection with the adoption of ASC 606, we established contract assets for unbilled receivables. As of January 26, 2019, we had total contract assets of $557 million, of which $241 million was recorded in other current assets and $316 million was recorded in other assets. As of January 26, 2019, we had total capitalized contract acquisition costs of $686 million, of which $380 million was recorded in other current assets and $306 million was recorded in other assets. The adoption of ASC 606 did not have any impact on net cash provided by operating activities.

[0000858877-19-000003:notes:318]
| (b) | Recent Accounting Standards or Updates Not Yet Effective |

[0000858877-19-000003:notes:319]
Leases  In February 2016, the FASB issued an accounting standard update and subsequent amendments related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2020 and early adoption is permitted. We expect to adopt this accounting standard update on a modified retrospective basis in the first quarter of fiscal 2020, and we are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.

[0000858877-19-000003:notes:320]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2021 and early adoption in fiscal 2020 is permitted. We expect to adopt this accounting standard update on a modified retrospective basis in the first quarter of fiscal 2021, and we are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-19-000003:notes:321]
[same as prior period, unchanged from 0000858877-18-000015:notes:309]

[0000858877-19-000003:notes:322]
[same as prior period, unchanged from 0000858877-18-000015:notes:310]

[0000858877-19-000003:notes:323]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-19-000003:notes:324]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,731 |  |  | $ | 4,710 |  |
| Computer equipment and related software |  | 965 |  |  | 1,085 |  |
| Production, engineering, and other equipment |  | 5,616 |  |  | 5,734 |  |
| Operating lease assets |  | 529 |  |  | 356 |  |
| Furniture and fixtures |  | 369 |  |  | 358 |  |
| Total gross property and equipment |  | 12,210 |  |  | 12,243 |  |
| Less: accumulated depreciation and amortization |  | (9,279 | ) |  | (9,237 | ) |
| Total |  | $ | 2,931 |  |  | $ | 3,006 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-19-000003:notes:325]
[same as prior period, unchanged from 0000858877-18-000015:notes:313]

[0000858877-19-000003:notes:326]
We initiated a restructuring plan during fiscal 2018 (the "Fiscal 2018 Plan") in order to realign the organization and enable further investment in key priority areas with estimated pretax charges of approximately $600 million. These aggregate pretax charges are primarily cash-based and consist of employee severance and other one-time termination benefits, and other associated costs. In connection with the Fiscal 2018 Plan, we have incurred charges of $186 million and $264 million for the second quarter and first six months of fiscal 2019, respectively, and have incurred cumulative charges of $372 million. We expect the Fiscal 2018 Plan to be substantially completed in fiscal 2019.

[0000858877-19-000003:notes:327]
[same as prior period, unchanged from 0000858877-18-000015:notes:315]

[0000858877-19-000003:notes:328]
[same as prior period, unchanged from 0000858877-18-000015:notes:316]

[0000858877-19-000003:notes:329]
|  |  | FISCAL 2017 AND PRIOR PLANS |  | FISCAL 2018 PLAN |  |  |
|  |  | Employee Severance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 28, 2018 |  | $ | 41 |  |  | $ | 13 |  |  | $ | 19 |  |  | $ | — |  |  | $ | 73 |  |
| Charges |  | — |  |  | (1 | ) |  | 222 |  |  | 43 |  |  | 264 |  |
| Cash payments |  | (31 | ) |  | (3 | ) |  | (202 | ) |  | (1 | ) |  | (237 | ) |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (42 | ) |  | (42 | ) |
| Liability as of January 26, 2019 |  | $ | 10 |  |  | $ | 9 |  |  | $ | 39 |  |  | $ | — |  |  | $ | 58 |  |

[0000858877-19-000003:notes:330]
|  |  | FISCAL 2017 AND PRIOR PLANS |  |  |
|  |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 29, 2017 |  | $ | 74 |  |  | $ | 43 |  |  | $ | 117 |  |
| Charges |  | 223 |  |  | 27 |  |  | 250 |  |
| Cash payments |  | (213 | ) |  | (27 | ) |  | (240 | ) |
| Non-cash items |  | 3 |  |  | (18 | ) |  | (15 | ) |
| Liability as of January 27, 2018 |  | $ | 87 |  |  | $ | 25 |  |  | $ | 112 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-19-000003:notes:331]
[same as prior period, unchanged from 0000858877-18-000015:notes:319]

[0000858877-19-000003:notes:332]
[same as prior period, unchanged from 0000858877-18-000015:notes:320]

[0000858877-19-000003:notes:333]
[same as prior period, unchanged from 0000858877-18-000015:notes:321]

[0000858877-19-000003:notes:334]
[same as prior period, unchanged from 0000858877-18-000015:notes:323]

[0000858877-19-000003:notes:335]
[same as prior period, unchanged from 0000858877-18-000015:notes:324]

[0000858877-19-000003:notes:336]
[same as prior period, unchanged from 0000858877-18-000015:notes:325]

[0000858877-19-000003:notes:337]
Other Products primarily include our Service Provider Video Software Solutions and cloud and system management products. On May 1, 2018, we announced a definitive agreement to sell the SPVSS business. The sale closed on October 28, 2018. These products include both hardware and software licenses. Our offerings in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control.

[0000858877-19-000003:notes:338]
[same as prior period, unchanged from 0000858877-18-000015:notes:327]

[0000858877-19-000003:notes:339]
[same as prior period, unchanged from 0000858877-18-000015:notes:328]

[0000858877-19-000003:notes:340]
[same as prior period, unchanged from 0000858877-18-000015:notes:329]

[0000858877-19-000003:notes:341]
Accounts receivable, net was $3.7 billion as of January 26, 2019 compared to $5.6 billion as of July 28, 2018, as reported on the Consolidated Balance Sheet.

[0000858877-19-000003:notes:342]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of January 26, 2019 and July 29, 2018, our contract assets for these unbilled receivables were $557 million and $122 million, respectively, and were included in other current assets and other assets.

[0000858877-19-000003:notes:343]
Contract liabilities consist of deferred revenue. Deferred revenue was $17.3 billion as of January 26, 2019 compared to $19.7 billion as of July 28, 2018. In connection with the adoption of ASC 606, we recorded an adjustment to retained earnings to reduce deferred revenue by $2.8 billion. We recognized approximately $2.6 billion and $6.0 billion of revenue during the second quarter and first six months of fiscal 2019, respectively, that was included in the deferred revenue balance at July 29, 2018.

[0000858877-19-000003:notes:344]
[same as prior period, unchanged from 0000858877-18-000015:notes:333]

[0000858877-19-000003:notes:345]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of January 26, 2019, the aggregate amount of RPO was $22.5 billion, comprised of $17.3 billion of deferred revenue and $5.2 billion of unbilled contract revenue. We expect approximately 56% of this amount to be recognized as revenue over the next year. Unbilled contract revenue represents non-cancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

[0000858877-19-000003:notes:346]
[same as prior period, unchanged from 0000858877-18-000015:notes:335]

[0000858877-19-000003:notes:347]
In connection with the adoption of ASC 606, we began to capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $686 million and $644 million as of January 26, 2019 and July 29, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $100 million and $212 million for the second quarter and first six months of fiscal 2019, respectively, and was included in sales and marketing expenses.


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0000858877-19-000003:notes:348]
[same as prior period, unchanged from 0000858877-18-000015:notes:337]

[0000858877-19-000003:notes:349]
|  |  | January 26, 2019 |  | July 28, 2018 |
| Cash and cash equivalents |  | $ | 9,835 |  |  | $ | 8,934 |  |
| Restricted cash included in other current assets |  | 23 |  |  | 32 |  |
| Restricted cash included in other assets |  | 21 |  |  | 27 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 9,879 |  |  | $ | 8,993 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000858877-19-000003:notes:350]
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 468 |  |  | $ | 423 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales and distributor inventory |  | 74 |  |  | 443 |  |
| Manufactured finished goods |  | 908 |  |  | 689 |  |
| Total finished goods |  | 982 |  |  | 1,132 |  |
| Service-related spares |  | 228 |  |  | 258 |  |
| Demonstration systems |  | 23 |  |  | 33 |  |
| Total |  | $ | 1,701 |  |  | $ | 1,846 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-19-000003:notes:351]
[same as prior period, unchanged from 0000858877-18-000015:notes:340]

[0000858877-19-000003:notes:352]
[same as prior period, unchanged from 0000858877-18-000015:notes:341]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-19-000003:notes:353]
[same as prior period, unchanged from 0000858877-18-000015:notes:342]

[0000858877-19-000003:notes:354]
[same as prior period, unchanged from 0000858877-18-000015:notes:343]

[0000858877-19-000003:notes:355]
We declared and paid cash dividends of $0.33 and $0.29 per common share, or $1.5 billion and $1.4 billion, on our outstanding common stock for the second quarter of fiscal 2019 and fiscal 2018, respectively. We declared and paid cash dividends of $0.66 and $0.58 per common share, or $3.0 billion and $2.9 billion, on our outstanding common stock for the first six months of fiscal 2019 and fiscal 2018, respectively.

[0000858877-19-000003:notes:356]
On February 13, 2019, our Board of Directors declared a quarterly dividend of $0.35 per common share to be paid on April 24, 2019 to all shareholders of record as of the close of business on April 5, 2019. Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-19-000003:notes:357]
[same as prior period, unchanged from 0000858877-18-000015:notes:346]

[0000858877-19-000003:notes:358]
In September 2001, our Board of Directors authorized a stock repurchase program. On February 13, 2019, our Board of Directors authorized a $15 billion increase to the stock repurchase program. The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $24 billion with no termination date. A summary of the stock repurchase activity for fiscal 2019 and 2018 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-19-000003:notes:359]
There were $160 million and $180 million of stock repurchases that were pending settlement as of January 26, 2019 and July 28, 2018, respectively.

[0000858877-19-000003:notes:360]
[same as prior period, unchanged from 0000858877-18-000015:notes:349]

[0000858877-19-000003:notes:361]
(c)   Preferred Stock

[0000858877-19-000003:notes:362]
[same as prior period, unchanged from 0000858877-18-000015:notes:353]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-19-000003:notes:363]
[same as prior period, unchanged from 0000858877-18-000015:notes:354]
