# CSCO 8-K — 0001193125-19-037964 filed 2019-02-13

## item codes, every 8-K on or before 2019-02-19

- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2019-02-19

- none on or before 2019-02-19

## item 2.02 — earnings release, exhibit 99.1

[0001193125-19-037964:8k_2_02:1]
EX-99.1
2
d680163dex991.htm
EX-99.1

[0001193125-19-037964:8k_2_02:2]
EX-99.1

[0001193125-19-037964:8k_2_02:3]
Exhibit 99.1

[0001193125-19-037964:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-19-037964:8k_2_02:5]
CISCO REPORTS SECOND QUARTER EARNINGS

[0001193125-19-037964:8k_2_02:6]
Dividend Increased 6 Percent, Additional $15 Billion Authorized for Stock Repurchase

[0001193125-19-037964:8k_2_02:7]
|  | • |  | Q2 Results: |

[0001193125-19-037964:8k_2_02:8]
|  | • |  | Revenue: $12.4 billion |

[0001193125-19-037964:8k_2_02:9]
|  | • |  | Growth of 7% year over year (normalized to exclude the divested SPVSS business for Q2 FY 2018) |

[0001193125-19-037964:8k_2_02:10]
|  | • |  | Earnings per Share: GAAP: $0.63; Non-GAAP: $0.73 |

[0001193125-19-037964:8k_2_02:11]
|  | • |  | Non-GAAP EPS increased 16% year over year |

[0001193125-19-037964:8k_2_02:12]
|  | • |  | Q3 Guidance (normalized to exclude the divested SPVSS business for Q3 FY 2018): |

[0001193125-19-037964:8k_2_02:13]
|  | • |  | Revenue: 4% to 6% growth year over year |

[0001193125-19-037964:8k_2_02:14]
|  | • |  | Earnings per Share: GAAP: $0.63 to $0.68; Non-GAAP: $0.76 to $0.78 |

[0001193125-19-037964:8k_2_02:15]
SAN JOSE, Calif. — February 13, 2019 — Cisco today reported second quarter results for the period ended January 26,
2019. Cisco reported second quarter revenue of $12.4 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.8 billion or $0.63 per share, and non-GAAP net income of
$3.3 billion or $0.73 per share.

[0001193125-19-037964:8k_2_02:16]
As previously disclosed, Cisco completed the divestiture of the Service Provider Video Software Solutions (SPVSS)
business in the second quarter of fiscal 2019 on October 28, 2018. Revenue, non-GAAP financial information, and Q3 FY 2019 guidance have been normalized to exclude the SPVSS business from prior periods
for comparative purposes.

[0001193125-19-037964:8k_2_02:17]
“We are very pleased with our strong performance in the quarter,” said Chuck Robbins, chairman and CEO of Cisco.
“Our teams are executing incredibly well, aggressively transitioning to a software model and accelerating our pace of innovation. We are redefining and connecting every domain of the networking infrastructure to deliver the agility, operational
efficiency and security our customers require to embrace multicloud, edge computing and digital transformation.”

[0001193125-19-037964:8k_2_02:18]
GAAP Results

[0001193125-19-037964:8k_2_02:19]
|  |  | Q2 FY 2019 |  |  | Q2 FY 2018 |  |  | Vs. Q2 FY 2018 |  |
| Revenue (including SPVSS business for all periods) |  | $ | 12.4 billion |  |  | $ | 11.9 billion |  |  |  | 5 | % |
| Revenue (excluding SPVSS business for all periods) |  | $ | 12.4 billion |  |  | $ | 11.7 billion |  |  |  | 7 | % |
| Net Income (Loss) |  | $ | 2.8 billion |  |  | $ | (8.8) billion |  |  |  | NM |  |
| Earnings (Loss) per Share |  | $ | 0.63 |  |  | $ | (1.78 | ) |  |  | NM |  |

[0001193125-19-037964:8k_2_02:20]
NM — Not meaningful

[0001193125-19-037964:8k_2_02:21]
GAAP
results for the second quarter of fiscal 2018 include a $11.1 billion charge related to the enactment of the Tax Cuts and Jobs Act.

[0001193125-19-037964:8k_2_02:22]
Non-GAAP Results

[0001193125-19-037964:8k_2_02:23]
|  |  | Q2 FY 2019 |  |  | Q2 FY 2018 |  |  | Vs. Q2 FY 2018 |  |
| Net Income (excluding SPVSS business for all periods) |  | $ | 3.3 billion |  |  | $ | 3.1 billion |  |  |  | 6 | % |
| Diluted Earnings per Share (EPS) (excluding SPVSS business for all periods) |  | $ | 0.73 |  |  | $ | 0.63 |  |  |  | 16 | % |

[0001193125-19-037964:8k_2_02:24]
Reconciliations between net income (loss), earnings (loss) per share, and other measures on a GAAP and non-GAAP basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-19-037964:8k_2_02:25]
1

[0001193125-19-037964:8k_2_02:26]
Cisco Increases Quarterly Cash Dividend; Stock Repurchase Program Authorization Increased

[0001193125-19-037964:8k_2_02:27]
Cisco has declared a quarterly dividend of $0.35 per common share, a 2-cent increase or up 6% over the previous quarter’s dividend, to be paid on
April 24, 2019 to all shareholders of record as of the close of business on April 5, 2019. Future dividends will be subject to Board approval.

[0001193125-19-037964:8k_2_02:28]
Cisco’s board of directors has also approved a $15 billion increase to the authorization of the stock repurchase program. There is no fixed termination
date for the repurchase program. The remaining authorized amount for stock repurchases including the additional authorization is approximately $24 billion.

[0001193125-19-037964:8k_2_02:29]
“Q2 was a solid quarter with continued momentum across the business delivering revenue growth of 7% and non-GAAP EPS growth of 16%. I’m also very
pleased with our revenue from software subscriptions which is now 65% of total software revenue,” said Kelly Kramer, CFO of Cisco. “Our increased dividend and share repurchase authorization show confidence in the strength of our ongoing
cash flows and reinforce our commitment to returning capital to our shareholders.”

[0001193125-19-037964:8k_2_02:30]
Financial Summary

[0001193125-19-037964:8k_2_02:31]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-19-037964:8k_2_02:32]
All revenue, non-GAAP, and geographic financial information in the “Q2 FY 2019 Highlights” section are
presented excluding the SPVSS business for all periods as it was divested during the second quarter on October 28, 2018.

[0001193125-19-037964:8k_2_02:33]
Q2 FY 2019
Highlights

[0001193125-19-037964:8k_2_02:34]
Revenue — Total revenue was $12.4 billion, up 7%, with product revenue up 9% and service revenue up 1%. Revenue by
geographic segment was: Americas up 7%, EMEA up 8%, and APJC up 5%. Product revenue performance was broad based with growth in Applications, up 24%, Security, up 18%, and Infrastructure Platforms, up 6%.

[0001193125-19-037964:8k_2_02:35]
Gross Margin — On a GAAP basis, total gross margin, product gross margin, and service gross margin were 62.5%, 61.0%, and 66.6%,
respectively, as compared with 63.1%, 61.5%, and 67.4%, respectively, in the second quarter of fiscal 2018.

[0001193125-19-037964:8k_2_02:36]
On a
non-GAAP basis, total gross margin, product gross margin, and service gross margin were 64.1%, 62.8%, and 67.7%, respectively, as compared with 65.1%, 63.8%, and 68.7%, respectively, in the second quarter of
fiscal 2018.

[0001193125-19-037964:8k_2_02:37]
Total gross margins by geographic segment were: 65.2% for the Americas, 64.2% for EMEA and 59.2% for APJC.

[0001193125-19-037964:8k_2_02:38]
Operating Expenses — On a GAAP basis, operating expenses were $4.6 billion, up 3%.
Non-GAAP operating expenses were $4.0 billion, up 3%, and were 31.9% of revenue.

[0001193125-19-037964:8k_2_02:39]
Operating Income
— GAAP operating income was $3.2 billion, up 4%, with GAAP operating margin of 25.8%. Non-GAAP operating income was $4.0 billion, up 7%, with
non-GAAP operating margin flat at 32.1%.

[0001193125-19-037964:8k_2_02:40]
Provision for Income Taxes — The GAAP tax provision
rate was 15.6%. The non-GAAP tax provision rate was 19.0%.

[0001193125-19-037964:8k_2_02:41]
Net Income and EPS — On a GAAP
basis, net income was $2.8 billion and EPS was $0.63. On a non-GAAP basis, net income was $3.3 billion, an increase of 6%, and EPS was $0.73, an increase of 16%.

[0001193125-19-037964:8k_2_02:42]
Cash Flow from Operating Activities — $3.8 billion for the second quarter of fiscal 2019, a decrease of 7% compared with
$4.1 billion for the second quarter of fiscal 2018. Operating cash flow includes the payment of $0.8 billion in relation to a transition tax payment as a result of the Tax Cuts and Jobs Act. Operating cash flow increased 12%, normalized
for this payment.

[0001193125-19-037964:8k_2_02:43]
Balance Sheet and Other Financial Highlights

[0001193125-19-037964:8k_2_02:44]
Cash and Cash Equivalents and Investments — $40.4 billion at the end of the second quarter of fiscal 2019, compared with
$42.6 billion at the end of the first quarter of fiscal 2019, and compared with $46.5 billion at the end of fiscal 2018.

[0001193125-19-037964:8k_2_02:45]
Deferred Revenue
— $17.3 billion, down 8% in total, with deferred product revenue down 23%. Deferred service revenue was up 3%.

[0001193125-19-037964:8k_2_02:46]
Capital Allocation
— For the second quarter of fiscal 2019, we returned $6.5 billion to shareholders through share buybacks and dividends. We declared and paid a cash dividend of $0.33 per common share, or $1.5 billion, and repurchased
approximately 111 million shares of common stock under our stock repurchase program at an average price of $45.09 per share for an aggregate purchase price of $5.0 billion.

[0001193125-19-037964:8k_2_02:47]
Acquisitions

[0001193125-19-037964:8k_2_02:48]
On December 18, 2018, we announced our
intent to acquire Luxtera, Inc., a privately held semiconductor company. On January 30, 2019, we announced our intent to acquire Singularity Networks, a privately held network infrastructure analytics company. Both acquisitions closed in the
third quarter of fiscal 2019.

[0001193125-19-037964:8k_2_02:49]
2

[0001193125-19-037964:8k_2_02:50]
Guidance for Q3 FY 2019

[0001193125-19-037964:8k_2_02:51]
Cisco expects to achieve the following results for the third quarter of fiscal 2019 (normalized to exclude the divested SPVSS business):

[0001193125-19-037964:8k_2_02:52]
| Q3 FY 2019 |  |  |
| Revenue |  | 4% - 6% growth Y/Y |
| Non-GAAP gross margin rate |  | 64% - 65% |
| Non-GAAP operating margin rate |  | 31% - 32% |
| Non-GAAP tax provision rate |  | 19% |
| Non-GAAP EPS |  | $0.76 - $0.78 |

[0001193125-19-037964:8k_2_02:53]
Revenue for the divested SPVSS business for the third quarter of fiscal 2018 was $219 million.

[0001193125-19-037964:8k_2_02:54]
Cisco estimates that GAAP EPS will be $0.63 to $0.68 in the third quarter of fiscal 2019.

[0001193125-19-037964:8k_2_02:55]
A reconciliation between the Guidance for Q3 FY 2019 on a GAAP and non-GAAP basis is provided in the table entitled
“GAAP to non-GAAP Guidance for Q3 FY 2019” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-19-037964:8k_2_02:56]
Editor’s Notes:

[0001193125-19-037964:8k_2_02:57]
|  | • |  | Q2 fiscal year 2019 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, February 13, 2019 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-19-037964:8k_2_02:58]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, February 13, 2019 to 4:00 p.m. Pacific Time, February 20, 2019 at 1-800-391-9851 (United States) or 1-203-369-3268 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-19-037964:8k_2_02:59]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, February 13, 2019. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-19-037964:8k_2_02:60]
3

[0001193125-19-037964:8k_2_02:61]
CISCO SYSTEMS, INC.

[0001193125-19-037964:8k_2_02:62]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-19-037964:8k_2_02:63]
(In millions, except per-share amounts)

[0001193125-19-037964:8k_2_02:64]
(Unaudited)

[0001193125-19-037964:8k_2_02:65]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 26,2019 |  |  | January 27,2018 |  |  | January 26,2019 |  |  | January 27,2018 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,273 |  |  | $ | 8,709 |  |  | $ | 19,163 |  |  | $ | 17,763 |  |
| Service |  |  | 3,173 |  |  |  | 3,178 |  |  |  | 6,355 |  |  |  | 6,260 |  |
| Total revenue |  |  | 12,446 |  |  |  | 11,887 |  |  |  | 25,518 |  |  |  | 24,023 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,614 |  |  |  | 3,354 |  |  |  | 7,413 |  |  |  | 6,969 |  |
| Service |  |  | 1,059 |  |  |  | 1,035 |  |  |  | 2,186 |  |  |  | 2,129 |  |
| Total cost of sales |  |  | 4,673 |  |  |  | 4,389 |  |  |  | 9,599 |  |  |  | 9,098 |  |
| GROSS MARGIN |  |  | 7,773 |  |  |  | 7,498 |  |  |  | 15,919 |  |  |  | 14,925 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,557 |  |  |  | 1,549 |  |  |  | 3,165 |  |  |  | 3,116 |  |
| Sales and marketing |  |  | 2,271 |  |  |  | 2,235 |  |  |  | 4,681 |  |  |  | 4,569 |  |
| General and administrative |  |  | 509 |  |  |  | 483 |  |  |  | 720 |  |  |  | 1,040 |  |
| Amortization of purchased intangible assets |  |  | 39 |  |  |  | 60 |  |  |  | 73 |  |  |  | 121 |  |
| Restructuring and other charges |  |  | 186 |  |  |  | 98 |  |  |  | 264 |  |  |  | 250 |  |
| Total operating expenses |  |  | 4,562 |  |  |  | 4,425 |  |  |  | 8,903 |  |  |  | 9,096 |  |
| OPERATING INCOME |  |  | 3,211 |  |  |  | 3,073 |  |  |  | 7,016 |  |  |  | 5,829 |  |
| Interest income |  |  | 328 |  |  |  | 396 |  |  |  | 672 |  |  |  | 775 |  |
| Interest expense |  |  | (223 | ) |  |  | (247 | ) |  |  | (444 | ) |  |  | (482 | ) |
| Other income (loss), net |  |  | 27 |  |  |  | 10 |  |  |  | 8 |  |  |  | 72 |  |
| Interest and other income (loss), net |  |  | 132 |  |  |  | 159 |  |  |  | 236 |  |  |  | 365 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,343 |  |  |  | 3,232 |  |  |  | 7,252 |  |  |  | 6,194 |  |
| Provision for income taxes (1) |  |  | 521 |  |  |  | 12,010 |  |  |  | 881 |  |  |  | 12,578 |  |
| NET INCOME (LOSS) |  | $ | 2,822 |  |  | $ | (8,778 | ) |  | $ | 6,371 |  |  | $ | (6,384 | ) |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.63 |  |  | $ | (1.78 | ) |  | $ | 1.41 |  |  | $ | (1.29 | ) |
| Diluted |  | $ | 0.63 |  |  | $ | (1.78 | ) |  | $ | 1.40 |  |  | $ | (1.29 | ) |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,470 |  |  |  | 4,924 |  |  |  | 4,517 |  |  |  | 4,942 |  |
| Diluted |  |  | 4,505 |  |  |  | 4,924 |  |  |  | 4,557 |  |  |  | 4,942 |  |

[0001193125-19-037964:8k_2_02:66]
The Consolidated Statements of Operations include the results of the SPVSS business prior to its divestiture during the second
quarter of fiscal 2019 on October 28, 2018. Accordingly, the six months ended January 26, 2019 includes three months of financial results for this business.

[0001193125-19-037964:8k_2_02:67]
| (1) | The provision for income taxes for the three and six months ended January 27, 2018 includes an $11.1 billion charge related to the enactment of the Tax Cuts and Jobs Act. |

[0001193125-19-037964:8k_2_02:68]
4

[0001193125-19-037964:8k_2_02:69]
CISCO SYSTEMS, INC.

[0001193125-19-037964:8k_2_02:70]
REVENUE BY SEGMENT

[0001193125-19-037964:8k_2_02:71]
(In
millions, except percentages)

[0001193125-19-037964:8k_2_02:72]
|  |  | January 26, 2019 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Including SPVSS business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,352 |  |  |  | 5 | % |  | $ | 15,103 |  |  |  | 5 | % |
| EMEA |  |  | 3,223 |  |  |  | 5 | % |  |  | 6,447 |  |  |  | 8 | % |
| APJC |  |  | 1,872 |  |  |  | 3 | % |  |  | 3,968 |  |  |  | 7 | % |
| Total |  | $ | 12,446 |  |  |  | 5 | % |  | $ | 25,518 |  |  |  | 6 | % |
| Excluding SPVSS business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,352 |  |  |  | 7 | % |  | $ | 15,027 |  |  |  | 6 | % |
| EMEA |  |  | 3,223 |  |  |  | 8 | % |  |  | 6,381 |  |  |  | 10 | % |
| APJC |  |  | 1,872 |  |  |  | 5 | % |  |  | 3,944 |  |  |  | 10 | % |
| Total |  | $ | 12,446 |  |  |  | 7 | % |  | $ | 25,351 |  |  |  | 8 | % |

[0001193125-19-037964:8k_2_02:73]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-037964:8k_2_02:74]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. SPVSS business revenue for the three
months ended January 27, 2018 was $230 million and for the six months ended January 26, 2019 and January 27, 2018 was $168 million and $478 million, respectively.

[0001193125-19-037964:8k_2_02:75]
CISCO SYSTEMS, INC.

[0001193125-19-037964:8k_2_02:76]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-19-037964:8k_2_02:77]
(In percentages)

[0001193125-19-037964:8k_2_02:78]
|  |  | January 26, 2019 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Including SPVSS business for all periods: |  |  |  |  |  |  |  |  |
| Americas |  |  | 65.2 | % |  |  | 65.3 | % |
| EMEA |  |  | 64.2 | % |  |  | 64.2 | % |
| APJC |  |  | 59.2 | % |  |  | 58.2 | % |
| Excluding SPVSS business for all periods (1): |  |  |  |  |  |  |  |  |
| Americas |  |  | 65.2 | % |  |  | 65.6 | % |
| EMEA |  |  | 64.2 | % |  |  | 64.3 | % |
| APJC |  |  | 59.2 | % |  |  | 58.4 | % |

[0001193125-19-037964:8k_2_02:79]
| (1) | During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. |

[0001193125-19-037964:8k_2_02:80]
5

[0001193125-19-037964:8k_2_02:81]
CISCO SYSTEMS, INC.

[0001193125-19-037964:8k_2_02:82]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-19-037964:8k_2_02:83]
(In millions, except percentages)

[0001193125-19-037964:8k_2_02:84]
|  |  | January 26, 2019 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Including SPVSS business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,128 |  |  |  | 6 | % |  | $ | 14,770 |  |  |  | 8 | % |
| Applications |  |  | 1,465 |  |  |  | 24 | % |  |  | 2,884 |  |  |  | 21 | % |
| Security |  |  | 658 |  |  |  | 18 | % |  |  | 1,308 |  |  |  | 15 | % |
| Other Products |  |  | 22 |  |  |  | (91 | )% |  |  | 200 |  |  |  | (63 | )% |
| Total Product |  |  | 9,273 |  |  |  | 6 | % |  |  | 19,163 |  |  |  | 8 | % |
| Services |  |  | 3,173 |  |  |  | — | % |  |  | 6,355 |  |  |  | 2 | % |
| Total |  | $ | 12,446 |  |  |  | 5 | % |  | $ | 25,518 |  |  |  | 6 | % |
| Excluding SPVSS business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,128 |  |  |  | 6 | % |  | $ | 14,770 |  |  |  | 8 | % |
| Applications |  |  | 1,465 |  |  |  | 24 | % |  |  | 2,884 |  |  |  | 21 | % |
| Security |  |  | 658 |  |  |  | 18 | % |  |  | 1,308 |  |  |  | 15 | % |
| Other Products |  |  | 22 |  |  |  | (59 | )% |  |  | 54 |  |  |  | (53 | )% |
| Total Product |  |  | 9,273 |  |  |  | 9 | % |  |  | 19,017 |  |  |  | 10 | % |
| Services |  |  | 3,173 |  |  |  | 1 | % |  |  | 6,334 |  |  |  | 2 | % |
| Total |  | $ | 12,446 |  |  |  | 7 | % |  | $ | 25,351 |  |  |  | 8 | % |

[0001193125-19-037964:8k_2_02:85]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-037964:8k_2_02:86]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. SPVSS business revenue for the three
months ended January 27, 2018 was $230 million and for the six months ended January 26, 2019 and January 27, 2018 was $168 million and $478 million, respectively.

[0001193125-19-037964:8k_2_02:87]
6

[0001193125-19-037964:8k_2_02:88]
CISCO SYSTEMS, INC.

[0001193125-19-037964:8k_2_02:89]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-19-037964:8k_2_02:90]
(In millions)

[0001193125-19-037964:8k_2_02:91]
(Unaudited)

[0001193125-19-037964:8k_2_02:92]
|  |  | January 26,2019 |  |  | July 28,2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,835 |  |  | $ | 8,934 |  |
| Investments |  |  | 30,548 |  |  |  | 37,614 |  |
| Accounts receivable, net of allowance for doubtful accounts of $135 at January 26, 2019 and $129 at July 28, 2018 |  |  | 3,745 |  |  |  | 5,554 |  |
| Inventories |  |  | 1,701 |  |  |  | 1,846 |  |
| Financing receivables, net |  |  | 5,057 |  |  |  | 4,949 |  |
| Other current assets |  |  | 2,231 |  |  |  | 2,940 |  |
| Total current assets |  |  | 53,117 |  |  |  | 61,837 |  |
| Property and equipment, net |  |  | 2,931 |  |  |  | 3,006 |  |
| Financing receivables, net |  |  | 4,565 |  |  |  | 4,882 |  |
| Goodwill |  |  | 33,293 |  |  |  | 31,706 |  |
| Purchased intangible assets, net |  |  | 2,270 |  |  |  | 2,552 |  |
| Deferred tax assets |  |  | 4,081 |  |  |  | 3,219 |  |
| Other assets |  |  | 2,205 |  |  |  | 1,582 |  |
| TOTAL ASSETS |  | $ | 102,462 |  |  | $ | 108,784 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 9,737 |  |  | $ | 5,238 |  |
| Accounts payable |  |  | 1,655 |  |  |  | 1,904 |  |
| Income taxes payable |  |  | 1,110 |  |  |  | 1,004 |  |
| Accrued compensation |  |  | 2,599 |  |  |  | 2,986 |  |
| Deferred revenue |  |  | 9,976 |  |  |  | 11,490 |  |
| Other current liabilities |  |  | 4,402 |  |  |  | 4,413 |  |
| Total current liabilities |  |  | 29,479 |  |  |  | 27,035 |  |
| Long-term debt |  |  | 15,893 |  |  |  | 20,331 |  |
| Income taxes payable |  |  | 7,760 |  |  |  | 8,585 |  |
| Deferred revenue |  |  | 7,285 |  |  |  | 8,195 |  |
| Other long-term liabilities |  |  | 1,256 |  |  |  | 1,434 |  |
| Total liabilities |  |  | 61,673 |  |  |  | 65,580 |  |
| Total equity |  |  | 40,789 |  |  |  | 43,204 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 102,462 |  |  | $ | 108,784 |  |

[0001193125-19-037964:8k_2_02:93]
7

[0001193125-19-037964:8k_2_02:94]
CISCO SYSTEMS, INC.

[0001193125-19-037964:8k_2_02:95]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-19-037964:8k_2_02:96]
(In millions)

[0001193125-19-037964:8k_2_02:97]
(Unaudited)

[0001193125-19-037964:8k_2_02:98]
|  |  | Six Months Ended |  |
|  |  | January 26,2019 |  |  | January 27,2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 6,371 |  |  | $ | (6,384 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 952 |  |  |  | 1,112 |  |
| Share-based compensation expense |  |  | 792 |  |  |  | 785 |  |
| Provision (benefit) for receivables |  |  | 30 |  |  |  | (43 | ) |
| Deferred income taxes |  |  | (257 | ) |  |  | 1,021 |  |
| (Gains) losses on divestitures, investments and other, net |  |  | (77 | ) |  |  | (174 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,613 |  |  |  | 1,236 |  |
| Inventories |  |  | (203 | ) |  |  | (276 | ) |
| Financing receivables |  |  | 161 |  |  |  | (156 | ) |
| Other assets |  |  | (652 | ) |  |  | (15 | ) |
| Accounts payable |  |  | (296 | ) |  |  | (338 | ) |
| Income taxes, net |  |  | (830 | ) |  |  | 10,246 |  |
| Accrued compensation |  |  | (339 | ) |  |  | (189 | ) |
| Deferred revenue |  |  | 207 |  |  |  | 237 |  |
| Other liabilities |  |  | 88 |  |  |  | 88 |  |
| Net cash provided by operating activities |  |  | 7,560 |  |  |  | 7,150 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (677 | ) |  |  | (13,954 | ) |
| Proceeds from sales of investments |  |  | 3,055 |  |  |  | 9,111 |  |
| Proceeds from maturities of investments |  |  | 6,263 |  |  |  | 7,365 |  |
| Acquisitions and divestitures |  |  | (1,599 | ) |  |  | (727 | ) |
| Purchases of investments in privately held companies |  |  | (68 | ) |  |  | (89 | ) |
| Return of investments in privately held companies |  |  | 43 |  |  |  | 124 |  |
| Acquisition of property and equipment |  |  | (473 | ) |  |  | (379 | ) |
| Proceeds from sales of property and equipment |  |  | 10 |  |  |  | 51 |  |
| Other |  |  | (12 | ) |  |  | (17 | ) |
| Net cash provided by investing activities |  |  | 6,542 |  |  |  | 1,485 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 312 |  |  |  | 302 |  |
| Repurchases of common stock—repurchase program |  |  | (10,062 | ) |  |  | (5,457 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (514 | ) |  |  | (433 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | — |  |  |  | 5,095 |  |
| Issuances of debt |  |  | — |  |  |  | 6,877 |  |
| Repayments of debt |  |  | — |  |  |  | (6,230 | ) |
| Dividends paid |  |  | (2,970 | ) |  |  | (2,861 | ) |
| Other |  |  | 18 |  |  |  | (22 | ) |
| Net cash used in financing activities |  |  | (13,216 | ) |  |  | (2,729 | ) |
| Net increase in cash, cash equivalents, and restricted cash |  |  | 886 |  |  |  | 5,906 |  |
| Cash, cash equivalents, and restricted cash, beginning of period |  |  | 8,993 |  |  |  | 11,773 |  |
| Cash, cash equivalents, and restricted cash, end of period |  | $ | 9,879 |  |  | $ | 17,679 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 421 |  |  | $ | 454 |  |
| Cash paid for income taxes, net |  | $ | 1,968 |  |  | $ | 1,311 |  |

[0001193125-19-037964:8k_2_02:99]
Prior period information has been retrospectively adjusted due to the adoption of ASU
2016-18, Statement of Cash Flows, Restricted Cash at the beginning of the first quarter of fiscal 2019.

[0001193125-19-037964:8k_2_02:100]
8

[0001193125-19-037964:8k_2_02:101]
CISCO SYSTEMS, INC.

[0001193125-19-037964:8k_2_02:102]
DEFERRED REVENUE

[0001193125-19-037964:8k_2_02:103]
(In
millions)

[0001193125-19-037964:8k_2_02:104]
|  |  | January 26,2019 |  |  | October 27,2018 |  |  | January 27,2018 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 11,246 |  |  | $ | 11,062 |  |  | $ | 10,963 |  |
| Product |  |  | 6,015 |  |  |  | 5,752 |  |  |  | 7,825 |  |
| Total |  | $ | 17,261 |  |  | $ | 16,814 |  |  | $ | 18,788 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 9,976 |  |  | $ | 9,637 |  |  | $ | 11,102 |  |
| Noncurrent |  |  | 7,285 |  |  |  | 7,177 |  |  |  | 7,686 |  |
| Total |  | $ | 17,261 |  |  | $ | 16,814 |  |  | $ | 18,788 |  |

[0001193125-19-037964:8k_2_02:105]
CISCO SYSTEMS, INC.

[0001193125-19-037964:8k_2_02:106]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-19-037964:8k_2_02:107]
(In millions, except per-share amounts)

[0001193125-19-037964:8k_2_02:108]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| January 26, 2019 |  | $ | 0.33 |  |  | $ | 1,470 |  |  |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |  | $ | 6,486 |  |
| October 27, 2018 |  | $ | 0.33 |  |  | $ | 1,500 |  |  |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |  | $ | 6,526 |  |
| Fiscal 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 28, 2018 |  | $ | 0.33 |  |  | $ | 1,535 |  |  |  | 138 |  |  | $ | 43.58 |  |  | $ | 6,015 |  |  | $ | 7,550 |  |
| April 28, 2018 |  | $ | 0.33 |  |  | $ | 1,572 |  |  |  | 140 |  |  | $ | 42.83 |  |  | $ | 6,015 |  |  | $ | 7,587 |  |
| January 27, 2018 |  | $ | 0.29 |  |  | $ | 1,425 |  |  |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |  | $ | 5,436 |  |
| October 28, 2017 |  | $ | 0.29 |  |  | $ | 1,436 |  |  |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |  | $ | 3,056 |  |

[0001193125-19-037964:8k_2_02:109]
9

[0001193125-19-037964:8k_2_02:110]
CISCO SYSTEMS, INC.

[0001193125-19-037964:8k_2_02:111]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-19-037964:8k_2_02:112]
GAAP NET INCOME (LOSS) TO NON-GAAP NET INCOME

[0001193125-19-037964:8k_2_02:113]
(In millions, except per-share amounts)

[0001193125-19-037964:8k_2_02:114]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 26,2019 |  |  | January 27,2018 |  |  | January 26,2019 |  |  | January 27,2018 |  |
| GAAP net income (loss) |  | $ | 2,822 |  |  | $ | (8,778 | ) |  | $ | 6,371 |  |  | $ | (6,384 | ) |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 53 |  |  |  | 54 |  |  |  | 109 |  |  |  | 111 |  |
| Amortization of acquisition-related intangible assets |  |  | 141 |  |  |  | 144 |  |  |  | 277 |  |  |  | 283 |  |
| Supplier component remediation charge (adjustment), net |  |  | — |  |  |  | (13 | ) |  |  | (1 | ) |  |  | (32 | ) |
| Acquisition-related/divestiture costs |  |  | 3 |  |  |  | 2 |  |  |  | 7 |  |  |  | 2 |  |
| Legal and indemnification settlements |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | 122 |  |
| Total adjustments to GAAP cost of sales |  |  | 202 |  |  |  | 187 |  |  |  | 397 |  |  |  | 486 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 323 |  |  |  | 333 |  |  |  | 652 |  |  |  | 668 |  |
| Amortization of acquisition-related intangible assets |  |  | 39 |  |  |  | 60 |  |  |  | 73 |  |  |  | 121 |  |
| Acquisition-related/divestiture costs |  |  | 39 |  |  |  | 23 |  |  |  | 160 |  |  |  | 106 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | (395 | ) |  |  | — |  |
| Significant asset impairments and restructurings |  |  | 186 |  |  |  | 98 |  |  |  | 264 |  |  |  | 250 |  |
| Total adjustments to GAAP operating expenses |  |  | 587 |  |  |  | 514 |  |  |  | 754 |  |  |  | 1,145 |  |
| Adjustments to GAAP interest and other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | (64 | ) |  |  | — |  |  |  | (73 | ) |  |  | — |  |
| Total adjustments to GAAP income (loss) before provision for income taxes |  |  | 725 |  |  |  | 701 |  |  |  | 1,078 |  |  |  | 1,631 |  |
| Income tax effect of non-GAAP adjustments |  |  | (209 | ) |  |  | (157 | ) |  |  | (394 | ) |  |  | (445 | ) |
| Significant tax matters (1) |  |  | (43 | ) |  |  | 11,380 |  |  |  | (308 | ) |  |  | 11,380 |  |
| Total adjustments to GAAP provision for income taxes |  |  | (252 | ) |  |  | 11,223 |  |  |  | (702 | ) |  |  | 10,935 |  |
| Non-GAAP net income |  | $ | 3,295 |  |  | $ | 3,146 |  |  | $ | 6,747 |  |  | $ | 6,182 |  |
| Net income (loss) per share (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.63 |  |  | $ | (1.78 | ) |  | $ | 1.40 |  |  | $ | (1.29 | ) |
| Non-GAAP |  | $ | 0.73 |  |  | $ | 0.63 |  |  | $ | 1.48 |  |  | $ | 1.24 |  |

[0001193125-19-037964:8k_2_02:115]
| (1) | During the second quarter of fiscal 2018, we recorded charges relating to significant tax matters that were excluded from non-GAAP net income for the second quarter and first six months of fiscal 2018. $11.1 billion of these charges were provisional amounts related to the enactment of the Tax Cuts and Jobs Act comprised of $9.0 billion related to the U.S. transition tax, $1.2 billion related to foreign withholding tax and $0.9 billion related to the re-measurement of net deferred tax assets. The amounts were provisional based on Securities and Exchange Commission Staff Accounting Bulletin No. 118. The remaining $0.3 billion was related to other significant tax matters. |

[0001193125-19-037964:8k_2_02:116]
| (2) | GAAP net loss per share for the three and six months ended January 27, 2018 was calculated using basic shares of 4,924 million and 4,942 million respectively, due to the net loss resulting from the tax charge as discussed in footnote (1). Non-GAAP net income per share for the respective periods was calculated using diluted shares of 4,966 million and 4,982 million, as we had non-GAAP net income for these periods. |

[0001193125-19-037964:8k_2_02:117]
10

[0001193125-19-037964:8k_2_02:118]
CISCO SYSTEMS, INC.

[0001193125-19-037964:8k_2_02:119]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-19-037964:8k_2_02:120]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME (LOSS)

[0001193125-19-037964:8k_2_02:121]
(In millions, except percentages)

[0001193125-19-037964:8k_2_02:122]
|  |  | Three Months Ended |  |
|  |  | January 26, 2019 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestand otherincome(loss),net |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,659 |  |  | $ | 2,114 |  |  | $ | 7,773 |  |  | $ | 4,562 |  |  |  | 3 | % |  | $ | 3,211 |  |  |  | 4 | % |  | $ | 132 |  |  |  | (17 | )% |  | $ | 2,822 |  |  |  | NM |  |
| % of revenue |  |  | 61.0 | % |  |  | 66.6 | % |  |  | 62.5 | % |  |  | 36.7 | % |  |  |  |  |  |  | 25.8 | % |  |  |  |  |  |  | 1.1 | % |  |  |  |  |  |  | 22.7 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 22 |  |  |  | 31 |  |  |  | 53 |  |  |  | 323 |  |  |  |  |  |  |  | 376 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 376 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 141 |  |  |  | — |  |  |  | 141 |  |  |  | 39 |  |  |  |  |  |  |  | 180 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 180 |  |  |  |  |  |
| Legal and indemnification settlements |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | — |  |  |  |  |  |  |  | 5 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 5 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | 2 |  |  |  | 3 |  |  |  | 39 |  |  |  |  |  |  |  | 42 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 42 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 186 |  |  |  |  |  |  |  | 186 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 186 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (64 | ) |  |  |  |  |  |  | (64 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (252 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 5,828 |  |  | $ | 2,147 |  |  | $ | 7,975 |  |  | $ | 3,975 |  |  |  | 3 | % |  | $ | 4,000 |  |  |  | 7 | % |  | $ | 68 |  |  |  | (57 | )% |  | $ | 3,295 |  |  |  | 6 | % |
| % of revenue |  |  | 62.8 | % |  |  | 67.7 | % |  |  | 64.1 | % |  |  | 31.9 | % |  |  |  |  |  |  | 32.1 | % |  |  |  |  |  |  | 0.5 | % |  |  |  |  |  |  | 26.5 | % |  |  |  |  |

[0001193125-19-037964:8k_2_02:123]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-037964:8k_2_02:124]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. Accordingly, the non-GAAP growth rates are normalized to exclude the SPVSS business for the second quarter of fiscal 2018.

[0001193125-19-037964:8k_2_02:125]
|  |  | Three Months Ended |  |
|  |  | January 27, 2018 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | NetIncome(Loss) |  |
| GAAP amount |  | $ | 5,355 |  |  | $ | 2,143 |  |  | $ | 7,498 |  |  | $ | 4,425 |  |  | $ | 3,073 |  |  | $ | (8,778 | ) |
| % of revenue |  |  | 61.5 | % |  |  | 67.4 | % |  |  | 63.1 | % |  |  | 37.2 | % |  |  | 25.9 | % |  |  | (73.8 | )% |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 23 |  |  |  | 31 |  |  |  | 54 |  |  |  | 333 |  |  |  | 387 |  |  |  | 387 |  |
| Amortization of acquisition-related intangible assets |  |  | 144 |  |  |  | — |  |  |  | 144 |  |  |  | 60 |  |  |  | 204 |  |  |  | 204 |  |
| Supplier component remediation charge (adjustment), net |  |  | (13 | ) |  |  | — |  |  |  | (13 | ) |  |  | — |  |  |  | (13 | ) |  |  | (13 | ) |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 2 |  |  |  | 2 |  |  |  | 23 |  |  |  | 25 |  |  |  | 25 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 98 |  |  |  | 98 |  |  |  | 98 |  |
| Income tax effect/significant tax matters (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 11,223 |  |
| Non-GAAP amount |  | $ | 5,509 |  |  | $ | 2,176 |  |  | $ | 7,685 |  |  | $ | 3,911 |  |  | $ | 3,774 |  |  | $ | 3,146 |  |
| Less: SPVSS business (2) |  |  | (82 | ) |  |  | (10 | ) |  |  | (92 | ) |  |  | (64 | ) |  |  | (28 | ) |  |  | (22 | ) |
| Non-GAAP amount (excluding SPVSS business) |  | $ | 5,427 |  |  | $ | 2,166 |  |  | $ | 7,593 |  |  | $ | 3,847 |  |  | $ | 3,746 |  |  | $ | 3,123 |  |
| % of revenue |  |  | 63.8 | % |  |  | 68.7 | % |  |  | 65.1 | % |  |  | 33.0 | % |  |  | 32.1 | % |  |  | 26.8 | % |

[0001193125-19-037964:8k_2_02:126]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-037964:8k_2_02:127]
| (1) | Includes an $11.1 billion charge related to the enactment of the Tax Cuts and Jobs Act. |

[0001193125-19-037964:8k_2_02:128]
| (2) | Reflects three months of operations for the SPVSS business. For the SPVSS business, EPS was $0.00 for the second quarter of fiscal 2018. |

[0001193125-19-037964:8k_2_02:129]
12

[0001193125-19-037964:8k_2_02:130]
CISCO SYSTEMS, INC.

[0001193125-19-037964:8k_2_02:131]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-19-037964:8k_2_02:132]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME (LOSS)

[0001193125-19-037964:8k_2_02:133]
(In millions, except percentages)

[0001193125-19-037964:8k_2_02:134]
|  |  | Six Months Ended |  |
|  |  | January 26, 2019 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestand otherincome(loss),net |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 11,750 |  |  | $ | 4,169 |  |  | $ | 15,919 |  |  | $ | 8,903 |  |  |  | (2 | )% |  | $ | 7,016 |  |  |  | 20 | % |  | $ | 236 |  |  |  | (35 | )% |  | $ | 6,371 |  |  |  | NM |  |
| % of revenue |  |  | 61.3 | % |  |  | 65.6 | % |  |  | 62.4 | % |  |  | 34.9 | % |  |  |  |  |  |  | 27.5 | % |  |  |  |  |  |  | 0.9 | % |  |  |  |  |  |  | 25.0 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 45 |  |  |  | 64 |  |  |  | 109 |  |  |  | 652 |  |  |  |  |  |  |  | 761 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 761 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 277 |  |  |  | — |  |  |  | 277 |  |  |  | 73 |  |  |  |  |  |  |  | 350 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 350 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |
| Legal and indemnification settlements |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | (395 | ) |  |  |  |  |  |  | (390 | ) |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (390 | ) |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 3 |  |  |  | 4 |  |  |  | 7 |  |  |  | 160 |  |  |  |  |  |  |  | 167 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 167 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 264 |  |  |  |  |  |  |  | 264 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 264 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (73 | ) |  |  |  |  |  |  | (73 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (702 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 12,079 |  |  | $ | 4,237 |  |  | $ | 16,316 |  |  | $ | 8,149 |  |  |  |  |  |  | $ | 8,167 |  |  |  |  |  |  | $ | 163 |  |  |  |  |  |  | $ | 6,747 |  |  |  |  |  |
| % of revenue |  |  | 63.0 | % |  |  | 66.7 | % |  |  | 63.9 | % |  |  | 31.9 | % |  |  |  |  |  |  | 32.0 | % |  |  |  |  |  |  | 0.6 | % |  |  |  |  |  |  | 26.4 | % |  |  |  |  |
| Less: SPVSS business (1) |  |  | (52 | ) |  |  | (9 | ) |  |  | (61 | ) |  |  | (59 | ) |  |  |  |  |  |  | (1 | ) |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |
| Non-GAAP amount (excluding SPVSS business) |  | $ | 12,028 |  |  | $ | 4,228 |  |  | $ | 16,255 |  |  | $ | 8,090 |  |  |  | 3 | % |  | $ | 8,166 |  |  |  | 10 | % |  | $ | 163 |  |  |  | (55 | )% |  | $ | 6,747 |  |  |  | 10 | % |
| % of revenue |  |  | 63.2 | % |  |  | 66.7 | % |  |  | 64.1 | % |  |  | 31.9 | % |  |  |  |  |  |  | 32.2 | % |  |  |  |  |  |  | 0.6 | % |  |  |  |  |  |  | 26.6 | % |  |  |  |  |

[0001193125-19-037964:8k_2_02:135]
| (1) | Reflects three months of operations for the SPVSS business. |

[0001193125-19-037964:8k_2_02:136]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-037964:8k_2_02:137]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. Accordingly, the non-GAAP growth rates are normalized to exclude the SPVSS business for the first six months of fiscal 2018.

[0001193125-19-037964:8k_2_02:138]
|  |  | Six Months Ended |  |
|  |  | January 27, 2018 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | NetIncome(Loss) |  |
| GAAP amount |  | $ | 10,794 |  |  | $ | 4,131 |  |  | $ | 14,925 |  |  | $ | 9,096 |  |  | $ | 5,829 |  |  | $ | (6,384 | ) |
| % of revenue |  |  | 60.8 | % |  |  | 66.0 | % |  |  | 62.1 | % |  |  | 37.9 | % |  |  | 24.3 | % |  |  | (26.6 | )% |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 46 |  |  |  | 65 |  |  |  | 111 |  |  |  | 668 |  |  |  | 779 |  |  |  | 779 |  |
| Amortization of acquisition-related intangible assets |  |  | 283 |  |  |  | — |  |  |  | 283 |  |  |  | 121 |  |  |  | 404 |  |  |  | 404 |  |
| Supplier component remediation charge (adjustment), net |  |  | (32 | ) |  |  | — |  |  |  | (32 | ) |  |  | — |  |  |  | (32 | ) |  |  | (32 | ) |
| Legal and indemnification settlements |  |  | 122 |  |  |  | — |  |  |  | 122 |  |  |  | — |  |  |  | 122 |  |  |  | 122 |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 2 |  |  |  | 2 |  |  |  | 106 |  |  |  | 108 |  |  |  | 108 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 250 |  |  |  | 250 |  |  |  | 250 |  |
| Income tax effect/significant tax matters (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 10,935 |  |
| Non-GAAP amount |  | $ | 11,213 |  |  | $ | 4,198 |  |  | $ | 15,411 |  |  | $ | 7,951 |  |  | $ | 7,460 |  |  | $ | 6,182 |  |
| Less: SPVSS business (2) |  |  | (144 | ) |  |  | (16 | ) |  |  | (160 | ) |  |  | (131 | ) |  |  | (29 | ) |  |  | (23 | ) |
| Non-GAAP amount (excluding SPVSS business) |  | $ | 11,070 |  |  | $ | 4,181 |  |  | $ | 15,251 |  |  | $ | 7,821 |  |  | $ | 7,430 |  |  | $ | 6,158 |  |
| % of revenue |  |  | 63.9 | % |  |  | 67.3 | % |  |  | 64.8 | % |  |  | 33.2 | % |  |  | 31.6 | % |  |  | 26.2 | % |

[0001193125-19-037964:8k_2_02:139]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-037964:8k_2_02:140]
| (1) | Includes an $11.1 billion charge related to the enactment of the Tax Cuts and Jobs Act. |

[0001193125-19-037964:8k_2_02:141]
| (2) | Reflects six months of operations for the SPVSS business. |

[0001193125-19-037964:8k_2_02:142]
14

[0001193125-19-037964:8k_2_02:143]
CISCO SYSTEMS, INC.

[0001193125-19-037964:8k_2_02:144]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-19-037964:8k_2_02:145]
EFFECTIVE TAX RATE

[0001193125-19-037964:8k_2_02:146]
(In
percentages)

[0001193125-19-037964:8k_2_02:147]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 26, 2019 |  |  | January 27, 2018 |  |  | January 26, 2019 |  |  | January 27, 2018 |  |
| GAAP effective tax rate (1) |  |  | 15.6 | % |  |  | 371.6 | % |  |  | 12.1 | % |  |  | 203.1 | % |
| Total adjustments to GAAP provision for income taxes |  |  | 3.4 | % |  |  | (351.6 | )% |  |  | 6.9 | % |  |  | (182.1 | )% |
| Non-GAAP effective tax rate |  |  | 19.0 | % |  |  | 20.0 | % |  |  | 19.0 | % |  |  | 21.0 | % |

[0001193125-19-037964:8k_2_02:148]
| (1) | Includes an $11.1 billion charge related to the enactment of the Tax Cuts and Jobs Act for the three and six months ended January 27, 2018. |

[0001193125-19-037964:8k_2_02:149]
GAAP TO NON-GAAP GUIDANCE FOR Q3 FY
2019

[0001193125-19-037964:8k_2_02:150]
| Q3 FY 2019 |  | Gross MarginRate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (2) |
| GAAP |  | 62.5% - 63.5% |  | 25.5% - 26.5% |  | 18% |  | $0.63 - $0.68 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.0% |  | — |  | $0.06 - $0.07 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 1.0% |  | 2.0% |  | — |  | $0.04 - $0.05 |
| Significant asset impairments and restructurings (1) |  | — |  | 0.5% |  | — |  | $0.00 - $0.01 |
| Income tax effect of non-GAAP adjustments |  |  |  |  |  | 1% |  |  |
| Non-GAAP |  | 64% - 65% |  | 31% - 32% |  | 19% |  | $0.76 - $0.78 |

[0001193125-19-037964:8k_2_02:151]
| (1) | In the third quarter of fiscal 2018, we initiated a restructuring plan in order to realign the organization and enable further investment in key priority areas with estimated pretax charges of approximately $600 million. We have recognized pretax charges of $372 million to our GAAP financial results in relation to this restructuring plan since its inception. We expect to recognize approximately $50 million of pretax charges under this plan in the third quarter of fiscal 2019. |

[0001193125-19-037964:8k_2_02:152]
| (2) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-19-037964:8k_2_02:153]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and significant
tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-19-037964:8k_2_02:154]
15

[0001193125-19-037964:8k_2_02:155]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-19-037964:8k_2_02:156]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax rates,
non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross
margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-19-037964:8k_2_02:157]
These
non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles and may be different from
non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes
that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should
only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-19-037964:8k_2_02:158]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition
and its historical and projected results of operations.

[0001193125-19-037964:8k_2_02:159]
For its internal budgeting process, Cisco’s management uses financial statements that do not
include, when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other
contingencies, gains and losses on equity investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the
corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time
to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-19-037964:8k_2_02:160]
16

[0001193125-19-037964:8k_2_02:161]
Cisco divested its Service Provider Video Software Solutions business (SPVSS) during the second quarter of
fiscal 2019 on October 28, 2018. This release includes, where indicated, financial measures that exclude the SPVSS business. Cisco believes that the presentation of these measures provides useful information to investors and management
regarding financial and business trends relating to its financial condition and its historical and projected results of operations because the SPVSS business will not be part of Cisco on a go forward basis. Cisco’s management also uses the
financial measures excluding the SPVSS business in reviewing the financial results of Cisco.

[0001193125-19-037964:8k_2_02:162]
About Cisco

[0001193125-19-037964:8k_2_02:163]
Cisco (Nasdaq: CSCO) is the worldwide technology leader that has been making the Internet work since 1984. Our people, products and partners help society
securely connect and seize tomorrow’s digital opportunity today. Discover more at thenetwork.cisco.com and follow us on Twitter at @Cisco.

[0001193125-19-037964:8k_2_02:164]
Copyright
© 2019 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To
view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco
and any other company. This document is Cisco Public Information.
