# CSCO MD&A — 0000858877-19-000003


## mdna

[0000858877-19-000003:mdna:1]
[same as prior period, unchanged from 0000858877-18-000015:mdna:1]

[0000858877-19-000003:mdna:2]
[same as prior period, unchanged from 0000858877-18-000015:mdna:2]

[0000858877-19-000003:mdna:3]
[same as prior period, unchanged from 0000858877-18-000015:mdna:3]

[0000858877-19-000003:mdna:4]
Cisco designs and sells a broad range of technologies that have been powering the Internet since 1984. Across networking, security, collaboration, applications and the cloud, our evolving intent-based technologies are constantly learning and adapting to provide customers with a highly secure, intelligent platform for their digital business. A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-19-000003:mdna:5]
|  | Three Months Ended |  | Six Months Ended |  |
|  | January 26, 2019 |  | January 27, 2018 |  | % Variance |  | January 26, 2019 |  | January 27, 2018 |  | % Variance |  |
| Revenue (1) | $ | 12,446 |  |  | $ | 11,887 |  |  | 5 | % |  | $ | 25,518 |  |  | $ | 24,023 |  |  | 6 | % |  |
| Gross margin percentage | 62.5 | % |  | 63.1 | % |  | (0.6 | ) | pts | 62.4 | % |  | 62.1 | % |  | 0.3 |  | pts |
| Research and development | $ | 1,557 |  |  | $ | 1,549 |  |  | 1 | % |  | $ | 3,165 |  |  | $ | 3,116 |  |  | 2 | % |  |
| Sales and marketing | $ | 2,271 |  |  | $ | 2,235 |  |  | 2 | % |  | $ | 4,681 |  |  | $ | 4,569 |  |  | 2 | % |  |
| General and administrative | $ | 509 |  |  | $ | 483 |  |  | 5 | % |  | $ | 720 |  |  | $ | 1,040 |  |  | (31 | )% |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,337 |  |  | $ | 4,267 |  |  | 2 | % |  | $ | 8,566 |  |  | $ | 8,725 |  |  | (2 | )% |  |
| Total as a percentage of revenue | 34.8 | % |  | 35.9 | % |  | (1.1 | ) | pts | 33.6 | % |  | 36.3 | % |  | (2.7 | ) | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 39 |  |  | $ | 60 |  |  | (35 | )% |  | $ | 73 |  |  | $ | 121 |  |  | (40 | )% |  |
| Restructuring and other charges included in operating expenses | $ | 186 |  |  | $ | 98 |  |  | 90 | % |  | $ | 264 |  |  | $ | 250 |  |  | 6 | % |  |
| Interest and other income (loss), net | $ | 132 |  |  | $ | 159 |  |  | (17 | )% |  | $ | 236 |  |  | $ | 365 |  |  | (35 | )% |  |
| Operating income as a percentage of revenue | 25.8 | % |  | 25.9 | % |  | (0.1 | ) | pts | 27.5 | % |  | 24.3 | % |  | 3.2 |  | pts |
| Income tax percentage | 15.6 | % |  | 371.6 | % |  | NM |  |  | 12.1 | % |  | 203.1 | % |  | NM |  |  |
| Net income (loss) (2) | $ | 2,822 |  |  | $ | (8,778 | ) |  | NM |  |  | $ | 6,371 |  |  | $ | (6,384 | ) |  | NM |  |  |
| Net income (loss) as a percentage of revenue (2) | 22.7 | % |  | (73.8 | )% |  | NM |  |  | 25.0 | % |  | (26.6 | )% |  | NM |  |  |
| Earnings (loss) per share—diluted (2) | $ | 0.63 |  |  | $ | (1.78 | ) |  | NM |  |  | $ | 1.40 |  |  | $ | (1.29 | ) |  | NM |  |  |

[0000858877-19-000003:mdna:6]
NM - Not meaningful; we recognized a net loss for the second quarter and first six months of fiscal 2018 related to the enactment of the Tax Cuts and Jobs Act.

[0000858877-19-000003:mdna:7]
We adopted ASC 606 in the first quarter of fiscal 2019 using the modified retrospective method. See Note 2 to the Consolidated Financial Statements for impact of this adoption on our operating results for the second quarter and first six months of fiscal 2019.

[0000858877-19-000003:mdna:8]
(1) During the second quarter of fiscal 2019, we completed the sale of our Service Provider Video Software Solutions (“SPVSS”) business. As a result, revenue from this business will not recur in future periods. Includes SPVSS business revenue of $0 and $230 million for the second quarter of fiscal 2019 and 2018, respectively, and $168 million and $478 million for the first six months of fiscal 2019 and 2018, respectively.

[0000858877-19-000003:mdna:9]
(2) Second quarter and first six months of fiscal 2018 results include an $11.1 billion charge related to the enactment of the Tax Cuts and Jobs Act.

[0000858877-19-000003:mdna:10]
[same as prior period, unchanged from 0000858877-18-000015:mdna:9]

[0000858877-19-000003:mdna:11]
[same as prior period, unchanged from 0000858877-18-000015:mdna:10]

[0000858877-19-000003:mdna:12]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:13]
In the second quarter of fiscal 2019, we delivered revenue growth across all geographies and product areas, solid margins and operating cash flow. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. Our product revenue reflected growth in Infrastructure Platforms, Applications and Security, and we continued to make progress in the transition of our business model to increased software and subscriptions. Notwithstanding the second quarter fiscal 2019 results, we continue to operate in a challenging and highly competitive environment. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-19-000003:mdna:14]
Total revenue increased by 5% compared with the second quarter of fiscal 2018. Within total revenue, product revenue increased by 6% and service revenue was flat. In the second quarter of fiscal 2019, on October 28, 2018, we completed the sale of our SPVSS business. Total revenue for the second quarter of fiscal 2019 increased 7% not including revenue from SPVSS business in the prior year period. Total gross margin decreased by 0.6 percentage points, driven by unfavorable impacts from pricing and productivity. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 1.1 percentage points. Operating income as a percentage of revenue decreased by 0.1 percentage points. The net loss and net loss per share in the prior year period were driven by the one-time transition tax on accumulated earnings of foreign subsidiaries, foreign withholding taxes, and re-measurement of net deferred tax assets and liabilities recorded during the second quarter of fiscal 2018.

[0000858877-19-000003:mdna:15]
In terms of our geographic segments, revenue from the Americas increased $348 million, EMEA revenue increased by $161 million, and revenue in our APJC segment increased by $52 million. These increases reflect broad strength across several countries within these segments. The “BRICM” countries experienced product revenue growth of 5% in the aggregate, driven by increased product revenue in the emerging countries of Mexico, India, Brazil and Russia of 35%, 18%, 14% and 4%, respectively, partially offset by a product revenue decrease of 16% in China.

[0000858877-19-000003:mdna:16]
From a customer market standpoint, we experienced product revenue growth in the public sector, enterprise and commercial markets, partially offset by a product revenue decline in the service provider market.

[0000858877-19-000003:mdna:17]
From a product category perspective, total product revenue, not including SPVSS products in the prior year period, increased 9% year over year. The increase was driven by a 6% product revenue increase in Infrastructure Platforms and solid product revenue growth in Applications and Security, which grew by 24% and 18% respectively.

[0000858877-19-000003:mdna:18]
[same as prior period, unchanged from 0000858877-18-000015:mdna:39]

[0000858877-19-000003:mdna:19]
[same as prior period, unchanged from 0000858877-18-000015:mdna:17]

[0000858877-19-000003:mdna:20]
[same as prior period, unchanged from 0000858877-18-000015:mdna:18]

[0000858877-19-000003:mdna:21]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:22]
Total revenue increased 6%, with product revenue increasing 8% and service revenue increasing 2%. Total gross margin increased by 0.3 percentage points due to productivity benefits and a $127 million legal and indemnification settlement charge recorded in the first six months of fiscal 2018, partially offset by unfavorable impacts from pricing. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively decreased by 2.7 percentage points due to lower general and administrative expenses. General and administrative expenses decreased due to a benefit from the $400 million litigation settlement with Arista in the first quarter of fiscal 2019. Operating income as a percentage of revenue increased by 3.2 percentage points. The net loss and net loss per share in the prior year period were driven by similar factors as discussed in the three-month period immediately above.

[0000858877-19-000003:mdna:23]
[same as prior period, unchanged from 0000858877-18-000015:mdna:19]

[0000858877-19-000003:mdna:24]
[same as prior period, unchanged from 0000858877-18-000015:mdna:20]

[0000858877-19-000003:mdna:25]
[same as prior period, unchanged from 0000858877-18-000015:mdna:21]

[0000858877-19-000003:mdna:26]
[same as prior period, unchanged from 0000858877-18-000015:mdna:22]

[0000858877-19-000003:mdna:27]
The following is a summary of our other key financial measures for the second quarter and first six months of fiscal 2019 (in millions):

[0000858877-19-000003:mdna:28]
|  |  | January 26, 2019 |  | July 28, 2018 |
| Cash and cash equivalents and investments |  | $ | 40,383 |  |  | $ | 46,548 |  |
| Deferred revenue |  | $ | 17,261 |  |  | $ | 19,685 |  |
| Inventories |  | $ | 1,701 |  |  | $ | 1,846 |  |

[0000858877-19-000003:mdna:29]
|  |  | Six Months Ended |
|  |  | January 26, 2019 |  | January 27, 2018 |
| Cash provided by operating activities |  | $ | 7,560 |  |  | $ | 7,150 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 10,042 |  |  | $ | 5,631 |  |
| Dividends |  | $ | 2,970 |  |  | $ | 2,861 |  |

[0000858877-19-000003:mdna:30]
52

[0000858877-19-000003:mdna:31]
[same as prior period, unchanged from 0000858877-18-000015:mdna:26]

[0000858877-19-000003:mdna:32]
[same as prior period, unchanged from 0000858877-18-000015:mdna:27]

[0000858877-19-000003:mdna:33]
[same as prior period, unchanged from 0000858877-18-000015:mdna:28]

[0000858877-19-000003:mdna:34]
[same as prior period, unchanged from 0000858877-18-000015:mdna:29]

[0000858877-19-000003:mdna:35]
[same as prior period, unchanged from 0000858877-18-000015:mdna:30]

[0000858877-19-000003:mdna:36]
[same as prior period, unchanged from 0000858877-18-000015:mdna:31]

[0000858877-19-000003:mdna:37]
[same as prior period, unchanged from 0000858877-18-000015:mdna:32]

[0000858877-19-000003:mdna:38]
[same as prior period, unchanged from 0000858877-18-000015:mdna:33]

[0000858877-19-000003:mdna:39]
[same as prior period, unchanged from 0000858877-18-000015:mdna:34]

[0000858877-19-000003:mdna:40]
[same as prior period, unchanged from 0000858877-18-000015:mdna:35]

[0000858877-19-000003:mdna:41]
[same as prior period, unchanged from 0000858877-18-000015:mdna:36]

[0000858877-19-000003:mdna:42]
[same as prior period, unchanged from 0000858877-18-000015:mdna:37]

[0000858877-19-000003:mdna:43]
[same as prior period, unchanged from 0000858877-18-000015:mdna:38]

[0000858877-19-000003:mdna:44]
53

[0000858877-19-000003:mdna:45]
[same as prior period, unchanged from 0000858877-18-000015:mdna:40]

[0000858877-19-000003:mdna:46]
[same as prior period, unchanged from 0000858877-18-000015:mdna:41]

[0000858877-19-000003:mdna:47]
[same as prior period, unchanged from 0000858877-18-000015:mdna:42]

[0000858877-19-000003:mdna:48]
[same as prior period, unchanged from 0000858877-18-000015:mdna:43]

[0000858877-19-000003:mdna:49]
|  |  | January 26, 2019 |  | July 28, 2018 |
| Allowance for doubtful accounts |  | $ | 135 |  |  | $ | 129 |  |
| Percentage of gross accounts receivable |  | 3.5 | % |  | 2.3 | % |
| Allowance for credit loss—lease receivables |  | $ | 127 |  |  | $ | 135 |  |
| Percentage of gross lease receivables(1) |  | 4.8 | % |  | 4.7 | % |
| Allowance for credit loss—loan receivables |  | $ | 64 |  |  | $ | 60 |  |
| Percentage of gross loan receivables |  | 1.3 | % |  | 1.2 | % |

[0000858877-19-000003:mdna:50]
[same as prior period, unchanged from 0000858877-18-000015:mdna:45]

[0000858877-19-000003:mdna:51]
[same as prior period, unchanged from 0000858877-18-000015:mdna:46]

[0000858877-19-000003:mdna:52]
The allowance for credit loss on financing receivables is also based on the assessment of collectibility of customer accounts. We regularly review the adequacy of the credit allowances determined either on an individual or a collective basis. When evaluating the financing receivables on an individual basis, we consider historical experience, credit quality and age of receivable balances, and economic conditions that may affect a customer’s ability to pay. When evaluating financing receivables on a collective basis, we use expected default frequency rates published by a major third-party credit-rating agency as well as our own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk and correlation. Determining expected default frequency rates and loss factors associated with internal credit risk ratings, as well as assessing factors such as economic conditions, concentration of risk, and correlation, are complex and subjective. Our ongoing consideration of all these factors could result in an increase in our allowance for credit loss in the future, which could adversely affect our operating results. Both accounts receivable and financing receivables are charged off at the point when they are considered uncollectible.

[0000858877-19-000003:mdna:53]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of January 26, 2019 and July 28, 2018 was $92 million and $123 million, respectively, and was recorded as a reduction of our accounts receivable and revenue. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-19-000003:mdna:54]
[same as prior period, unchanged from 0000858877-18-000015:mdna:49]

[0000858877-19-000003:mdna:55]
[same as prior period, unchanged from 0000858877-18-000015:mdna:50]

[0000858877-19-000003:mdna:56]
[same as prior period, unchanged from 0000858877-18-000015:mdna:51]

[0000858877-19-000003:mdna:57]
Our provision for inventory was $23 million and $31 million for the first six months of fiscal 2019 and 2018, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $48 million and $44 million for the first six months of fiscal 2019 and 2018, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments.

[0000858877-19-000003:mdna:58]
54

[0000858877-19-000003:mdna:59]
[same as prior period, unchanged from 0000858877-18-000015:mdna:53]

[0000858877-19-000003:mdna:60]
[same as prior period, unchanged from 0000858877-18-000015:mdna:54]

[0000858877-19-000003:mdna:61]
Loss Contingencies and Product Warranties

[0000858877-19-000003:mdna:62]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-19-000003:mdna:63]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-19-000003:mdna:64]
[same as prior period, unchanged from 0000858877-18-000015:mdna:58]

[0000858877-19-000003:mdna:65]
[same as prior period, unchanged from 0000858877-18-000015:mdna:59]

[0000858877-19-000003:mdna:66]
[same as prior period, unchanged from 0000858877-18-000015:mdna:60]

[0000858877-19-000003:mdna:67]
[same as prior period, unchanged from 0000858877-18-000015:mdna:61]

[0000858877-19-000003:mdna:68]
[same as prior period, unchanged from 0000858877-18-000015:mdna:62]

[0000858877-19-000003:mdna:69]
We hold non-marketable equity and other investments, some of which are in the startup or development stages. As of January 26, 2019, our non-marketable equity and other investments were $1.3 billion, compared with $1.1 billion as of July 28, 2018, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize.

[0000858877-19-000003:mdna:70]
[same as prior period, unchanged from 0000858877-18-000015:mdna:64]

[0000858877-19-000003:mdna:71]
[same as prior period, unchanged from 0000858877-18-000015:mdna:65]

[0000858877-19-000003:mdna:72]
[same as prior period, unchanged from 0000858877-18-000015:mdna:66]

[0000858877-19-000003:mdna:73]
[same as prior period, unchanged from 0000858877-18-000015:mdna:67]

[0000858877-19-000003:mdna:74]
The goodwill recorded in the Consolidated Balance Sheets as of January 26, 2019 and July 28, 2018 was $33.3 billion and $31.7 billion, respectively. In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first six months of fiscal 2019 and 2018.

[0000858877-19-000003:mdna:75]
[same as prior period, unchanged from 0000858877-18-000015:mdna:69]

[0000858877-19-000003:mdna:76]
[same as prior period, unchanged from 0000858877-18-000015:mdna:70]

[0000858877-19-000003:mdna:77]
There were no impairment charges related to purchased intangible assets for the first six months of fiscal 2019 and 2018. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-19-000003:mdna:78]
[same as prior period, unchanged from 0000858877-18-000015:mdna:72]

[0000858877-19-000003:mdna:79]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 15.6% and 371.6% in the second quarter of fiscal 2019 and 2018, respectively. Our effective tax rate was 12.1% and 203.1% in the first six months of fiscal 2019 and 2018, respectively.

[0000858877-19-000003:mdna:80]
On December 22, 2017, the Tax Cuts and Jobs Act (the "Tax Act") was enacted. The Tax Act significantly revises the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (“federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries. As a result of the Tax Act enactment, we recorded a provisional tax expense of $10.4 billion in fiscal 2018. In the second quarter of fiscal 2019, we completed our accounting relating to the Tax Act and recorded an additional $58 million tax expense. The total tax charge as the result of the Tax Act is $10.5 billion, consisting of $8.2 billion of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries, $1.2 billion of foreign withholding tax, and $1.1 billion of tax expense for DTA re-measurement. The tax expense related to the U.S. transition tax on accumulated earnings in foreign subsidiaries is net of a $0.9 billion benefit related to U.S. taxation of deemed foreign dividends in the transition fiscal year. This benefit may be reduced or eliminated in future legislation. If such legislation is enacted, we will record the impact of the legislation in the quarter of enactment.

[0000858877-19-000003:mdna:81]
[same as prior period, unchanged from 0000858877-18-000015:mdna:78]

[0000858877-19-000003:mdna:82]
[same as prior period, unchanged from 0000858877-18-000015:mdna:79]

[0000858877-19-000003:mdna:83]
[same as prior period, unchanged from 0000858877-18-000015:mdna:76]

[0000858877-19-000003:mdna:84]
[same as prior period, unchanged from 0000858877-18-000015:mdna:77]

[0000858877-19-000003:mdna:85]
[same as prior period, unchanged from 0000858877-18-000015:mdna:80]

[0000858877-19-000003:mdna:86]
[same as prior period, unchanged from 0000858877-18-000015:mdna:108]

[0000858877-19-000003:mdna:87]
[same as prior period, unchanged from 0000858877-18-000015:mdna:82]

[0000858877-19-000003:mdna:88]
[same as prior period, unchanged from 0000858877-18-000015:mdna:83]

[0000858877-19-000003:mdna:89]
[same as prior period, unchanged from 0000858877-18-000015:mdna:84]

[0000858877-19-000003:mdna:90]
[same as prior period, unchanged from 0000858877-18-000015:mdna:85]

[0000858877-19-000003:mdna:91]
[same as prior period, unchanged from 0000858877-18-000015:mdna:86]

[0000858877-19-000003:mdna:92]
|  |  | Three Months Ended (1) |  | Six Months Ended |
|  |  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |  | Variance in Percent |  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,273 |  |  | $ | 8,709 |  |  | $ | 564 |  |  | 6 | % |  | $ | 19,163 |  |  | $ | 17,763 |  |  | $ | 1,400 |  |  | 8 | % |
| Percentage of revenue |  | 74.5 | % |  | 73.3 | % |  |  |  |  |  |  |  | 75.1 | % |  | 73.9 | % |  |  |  |  |  |  |
| Service |  | 3,173 |  |  | 3,178 |  |  | (5 | ) |  | — | % |  | 6,355 |  |  | 6,260 |  |  | 95 |  |  | 2 | % |
| Percentage of revenue |  | 25.5 | % |  | 26.7 | % |  |  |  |  |  |  |  | 24.9 | % |  | 26.1 | % |  |  |  |  |  |  |
| Total |  | $ | 12,446 |  |  | $ | 11,887 |  |  | $ | 559 |  |  | 5 | % |  | $ | 25,518 |  |  | $ | 24,023 |  |  | $ | 1,495 |  |  | 6 | % |

[0000858877-19-000003:mdna:93]
(1) Total revenue, product revenue and service revenue not including the SPVSS business in the prior year period increased 7%, 9% and 1%, respectively.

[0000858877-19-000003:mdna:94]
[same as prior period, unchanged from 0000858877-18-000015:mdna:88]

[0000858877-19-000003:mdna:95]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |  | Variance in Percent |  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,352 |  |  | $ | 7,004 |  |  | $ | 348 |  |  | 5 | % |  | $ | 15,103 |  |  | $ | 14,354 |  |  | $ | 749 |  |  | 5 | % |
| Percentage of revenue |  | 59.1 | % |  | 58.9 | % |  |  |  |  |  | 59.2 | % |  | 59.7 | % |  |  |  |  |
| EMEA |  | 3,223 |  |  | 3,062 |  |  | 161 |  |  | 5 | % |  | 6,447 |  |  | 5,971 |  |  | 476 |  |  | 8 | % |
| Percentage of revenue |  | 25.9 | % |  | 25.8 | % |  |  |  |  |  | 25.3 | % |  | 24.9 | % |  |  |  |  |
| APJC |  | 1,872 |  |  | 1,820 |  |  | 52 |  |  | 3 | % |  | 3,968 |  |  | 3,698 |  |  | 270 |  |  | 7 | % |
| Percentage of revenue |  | 15.0 | % |  | 15.3 | % |  |  |  |  |  | 15.5 | % |  | 15.4 | % |  |  |  |  |
| Total |  | $ | 12,446 |  |  | $ | 11,887 |  |  | $ | 559 |  |  | 5 | % |  | $ | 25,518 |  |  | $ | 24,023 |  |  | $ | 1,495 |  |  | 6 | % |

[0000858877-19-000003:mdna:96]
[same as prior period, unchanged from 0000858877-18-000015:mdna:90]

[0000858877-19-000003:mdna:97]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:98]
Total revenue increased by 5%. Product revenue increased by 6% while service revenue was flat. Our total revenue reflected growth across each of our geographic segments. Product revenue for the emerging countries of BRICM, in the aggregate, experienced 5% product revenue growth, with increases in Mexico, India, Brazil and Russia partially offset by a decrease in China.

[0000858877-19-000003:mdna:99]
In addition to the impact of macroeconomic factors, including a reduced IT spending environment and reductions in spending by government entities, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple performance obligations; the mix of financing arrangements provided to channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment. As has been the case in certain emerging countries from time to time, certain customers require greater levels of financing arrangements, service, and support, and these activities may occur in future periods, which may also impact the timing of the recognition of revenue.

[0000858877-19-000003:mdna:100]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:101]
Total revenue increased by 6%. Product revenue increased by 8% and service revenue increased by 2%. Our total revenue reflected growth across each of our geographic segments. Product revenue for the emerging countries of BRICM, in the aggregate, experienced 14% product revenue growth, with increases in Mexico, India, Russia and Brazil, partially offset by decrease in China.

[0000858877-19-000003:mdna:102]
[same as prior period, unchanged from 0000858877-18-000015:mdna:95]

[0000858877-19-000003:mdna:103]
[same as prior period, unchanged from 0000858877-18-000015:mdna:96]

[0000858877-19-000003:mdna:104]
[same as prior period, unchanged from 0000858877-18-000015:mdna:97]

[0000858877-19-000003:mdna:105]
[same as prior period, unchanged from 0000858877-18-000015:mdna:98]

[0000858877-19-000003:mdna:106]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |  | Variance in Percent |  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,349 |  |  | $ | 4,988 |  |  | $ | 361 |  |  | 7 | % |  | $ | 11,060 |  |  | $ | 10,380 |  |  | $ | 680 |  |  | 7 | % |
| Percentage of product revenue |  | 57.7 | % |  | 57.3 | % |  |  |  |  |  | 57.7 | % |  | 58.4 | % |  |  |  |  |
| EMEA |  | 2,512 |  |  | 2,375 |  |  | 137 |  |  | 6 | % |  | 5,039 |  |  | 4,614 |  |  | 425 |  |  | 9 | % |
| Percentage of product revenue |  | 27.1 | % |  | 27.3 | % |  |  |  |  |  | 26.3 | % |  | 26.0 | % |  |  |  |  |
| APJC |  | 1,413 |  |  | 1,346 |  |  | 67 |  |  | 5 | % |  | 3,064 |  |  | 2,769 |  |  | 295 |  |  | 11 | % |
| Percentage of product revenue |  | 15.2 | % |  | 15.4 | % |  |  |  |  |  | 16.0 | % |  | 15.6 | % |  |  |  |  |
| Total |  | $ | 9,273 |  |  | $ | 8,709 |  |  | $ | 564 |  |  | 6 | % |  | $ | 19,163 |  |  | $ | 17,763 |  |  | $ | 1,400 |  |  | 8 | % |

[0000858877-19-000003:mdna:107]
[same as prior period, unchanged from 0000858877-18-000015:mdna:100]

[0000858877-19-000003:mdna:108]
[same as prior period, unchanged from 0000858877-18-000015:mdna:102]

[0000858877-19-000003:mdna:109]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:110]
Product revenue in the Americas segment increased by 7%, led by solid growth in the public sector, enterprise and commercial markets, partially offset by a decline in the service provider market. From a country perspective, product revenue increased by 7% in the United States, 35% in Mexico, 11% in Canada and 14% in Brazil.

[0000858877-19-000003:mdna:111]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:112]
The increase in product revenue in the Americas segment was led by growth in the enterprise, public sector and commercial markets. These increases were partially offset by a product revenue decline in the service provider market. From a country perspective, product revenue increased by 7% in the United States, 48% in Mexico, 16% in Canada and 7% in Brazil.

[0000858877-19-000003:mdna:113]
[same as prior period, unchanged from 0000858877-18-000015:mdna:104]

[0000858877-19-000003:mdna:114]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:115]
Product revenue in the EMEA segment increased by 6%, with growth in the public sector, enterprise and commercial markets partially offset by a decline in the service provider market. Product revenue from emerging countries within EMEA was flat and product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, increased by 8%.

[0000858877-19-000003:mdna:116]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:117]
Product revenue in the EMEA segment increased by 9%, with growth across each of the customer markets in this geographic segment. Product revenue from emerging countries within EMEA increased by 5% and product revenue for the remainder of the EMEA segment increased by 11%.

[0000858877-19-000003:mdna:118]
[same as prior period, unchanged from 0000858877-18-000015:mdna:109]

[0000858877-19-000003:mdna:119]
[same as prior period, unchanged from 0000858877-18-000015:mdna:110]

[0000858877-19-000003:mdna:120]
[same as prior period, unchanged from 0000858877-18-000015:mdna:106]

[0000858877-19-000003:mdna:121]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:122]
Product revenue in the APJC segment increased by 5%, led by solid growth in the public sector and enterprise markets and, to a lesser extent, growth in the commercial market. These increases were partially offset by a product revenue decline in the service provider market. From a country perspective, product revenue in India and in Japan each increased by 18% while product revenue in China decreased by 16%.

[0000858877-19-000003:mdna:123]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:124]
Product revenue in the APJC segment increased 11%, with growth across each of the customer markets in this geographic segment. From a country perspective, product revenue increased by 36% in India and 13% in Japan while product revenue in China decreased by 8%.

[0000858877-19-000003:mdna:125]
[same as prior period, unchanged from 0000858877-18-000015:mdna:111]

[0000858877-19-000003:mdna:126]
[same as prior period, unchanged from 0000858877-18-000015:mdna:112]

[0000858877-19-000003:mdna:127]
[same as prior period, unchanged from 0000858877-18-000015:mdna:113]

[0000858877-19-000003:mdna:128]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |  | Variance in Percent |  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,128 |  |  | $ | 6,710 |  |  | $ | 418 |  |  | 6 | % |  | $ | 14,770 |  |  | $ | 13,690 |  |  | $ | 1,080 |  |  | 8 | % |
| Applications |  | 1,465 |  |  | 1,184 |  |  | 281 |  |  | 24 | % |  | 2,884 |  |  | 2,387 |  |  | 497 |  |  | 21 | % |
| Security |  | 658 |  |  | 557 |  |  | 101 |  |  | 18 | % |  | 1,308 |  |  | 1,142 |  |  | 166 |  |  | 15 | % |
| Other Products |  | 22 |  |  | 258 |  |  | (236 | ) |  | (91 | )% |  | 200 |  |  | 544 |  |  | (344 | ) |  | (63 | )% |
| Total |  | $ | 9,273 |  |  | $ | 8,709 |  |  | $ | 564 |  |  | 6 | % |  | $ | 19,163 |  |  | $ | 17,763 |  |  | $ | 1,400 |  |  | 8 | % |

[0000858877-19-000003:mdna:129]
[same as prior period, unchanged from 0000858877-18-000015:mdna:115]

[0000858877-19-000003:mdna:130]
[same as prior period, unchanged from 0000858877-18-000015:mdna:117]

[0000858877-19-000003:mdna:131]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:132]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center. Infrastructure Platforms revenue increased by 6%, or $418 million. Switching had solid growth, with double digit revenue growth in campus switching driven by an increase in sales of our intent-based networking Catalyst 9000 Series. We also had double digit revenue growth from wireless products driven by our Wave 2 offerings as well as Meraki. Revenue from our routing products decreased due to weakness in the service provider market. Revenue from data center also decreased driven by lower sales of server products partially offset by revenue growth in our hyperconverged data center offering, HyperFlex.

[0000858877-19-000003:mdna:133]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:134]
Revenue from the Infrastructure Platforms product category increased 8% or $1,080 million, with strength across the portfolio. Switching had solid growth, with solid revenue growth in campus switching driven by an increase in sales of our intent-based networking Catalyst 9000 Series, and with revenue growth in data center switching driven by increased revenue from our Nexus 9000 Series. Routing experienced revenue growth driven by growth in the service provider market. We experienced double digit revenue growth from wireless products driven by our Wave 2 offerings and Meraki. Revenue from data center increased driven by higher sales of our hyperconverged data center offering, HyperFlex, and our server products.

[0000858877-19-000003:mdna:135]
[same as prior period, unchanged from 0000858877-18-000015:mdna:149]

[0000858877-19-000003:mdna:136]
[same as prior period, unchanged from 0000858877-18-000015:mdna:125]

[0000858877-19-000003:mdna:137]
[same as prior period, unchanged from 0000858877-18-000015:mdna:126]

[0000858877-19-000003:mdna:138]
[same as prior period, unchanged from 0000858877-18-000015:mdna:119]

[0000858877-19-000003:mdna:139]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:140]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as the Internet of Things (IoT) and analytics software offerings from Jasper and AppDynamics, respectively. Revenue in our Applications product category increased by 24%, or $281 million, with growth across all of the business. We had strong revenue growth in unified communications, Telepresence and analytics from AppDynamics.

[0000858877-19-000003:mdna:141]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:142]
Revenue in our Applications product category increased by 21%, or $497 million, with solid revenue growth in unified communications, TelePresence and analytics from AppDynamics.

[0000858877-19-000003:mdna:143]
[same as prior period, unchanged from 0000858877-18-000015:mdna:121]

[0000858877-19-000003:mdna:144]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:145]
Revenue in our Security product category increased 18%, or $101 million, driven by higher sales of identity and access, advance threat security and unified threat management products. The acquisition of Duo Security in the first quarter of fiscal 2019 also contributed to the revenue increase in this product category.

[0000858877-19-000003:mdna:146]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:147]
Revenue in our Security product category increased 15%, or $166 million, driven by higher sales of identity and access, advance threat security, unified threat management and web security products. The acquisition of Duo Security in the first quarter of fiscal 2019 also contributed to the revenue increase in this product category.

[0000858877-19-000003:mdna:148]
[same as prior period, unchanged from 0000858877-18-000015:mdna:123]

[0000858877-19-000003:mdna:149]
The decrease in revenue from our Other Products category for the second quarter and first six months of fiscal 2019, compared to corresponding periods of fiscal 2018, was primarily driven by a decrease in revenue from the SPVSS business which we divested on October 28, 2018.

[0000858877-19-000003:mdna:150]
[same as prior period, unchanged from 0000858877-18-000015:mdna:127]

[0000858877-19-000003:mdna:151]
[same as prior period, unchanged from 0000858877-18-000015:mdna:128]

[0000858877-19-000003:mdna:152]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |  | Variance in Percent |  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,003 |  |  | $ | 2,016 |  |  | $ | (13 | ) |  | (1 | )% |  | $ | 4,043 |  |  | $ | 3,974 |  |  | $ | 69 |  |  | 2 | % |
| Percentage of service revenue |  | 63.1 | % |  | 63.4 | % |  |  |  |  |  | 63.6 | % |  | 63.5 | % |  |  |  |  |
| EMEA |  | 711 |  |  | 687 |  |  | 24 |  |  | 3 | % |  | 1,408 |  |  | 1,357 |  |  | 51 |  |  | 4 | % |
| Percentage of service revenue |  | 22.4 | % |  | 21.6 | % |  |  |  |  |  | 22.2 | % |  | 21.7 | % |  |  |  |  |
| APJC |  | 459 |  |  | 475 |  |  | (16 | ) |  | (3 | )% |  | 904 |  |  | 929 |  |  | (25 | ) |  | (3 | )% |
| Percentage of service revenue |  | 14.5 | % |  | 15.0 | % |  |  |  |  |  | 14.2 | % |  | 14.8 | % |  |  |  |  |
| Total |  | $ | 3,173 |  |  | $ | 3,178 |  |  | $ | (5 | ) |  | — | % |  | $ | 6,355 |  |  | $ | 6,260 |  |  | $ | 95 |  |  | 2 | % |

[0000858877-19-000003:mdna:153]
[same as prior period, unchanged from 0000858877-18-000015:mdna:130]

[0000858877-19-000003:mdna:154]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:155]
Service revenue was flat. Service revenue not including the SPVSS business in the prior year period increased by 1% . The service revenue increase in the EMEA segment offset the decreases in service revenue in our APJC and Americas segments.

[0000858877-19-000003:mdna:156]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:157]
Service revenue increased 2%, driven by an increase in software and solution support offerings. Service revenue increased in the Americas and EMEA segments, partially offset by decreased revenue in our APJC segment.

[0000858877-19-000003:mdna:158]
[same as prior period, unchanged from 0000858877-18-000015:mdna:162]

[0000858877-19-000003:mdna:159]
[same as prior period, unchanged from 0000858877-18-000015:mdna:136]

[0000858877-19-000003:mdna:160]
[same as prior period, unchanged from 0000858877-18-000015:mdna:137]

[0000858877-19-000003:mdna:161]
[same as prior period, unchanged from 0000858877-18-000015:mdna:133]

[0000858877-19-000003:mdna:162]
[same as prior period, unchanged from 0000858877-18-000015:mdna:134]

[0000858877-19-000003:mdna:163]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,659 |  |  | $ | 5,355 |  |  | 61.0 | % |  | 61.5 | % |  | $ | 11,750 |  |  | $ | 10,794 |  |  | 61.3 | % |  | 60.8 | % |
| Service |  | 2,114 |  |  | 2,143 |  |  | 66.6 | % |  | 67.4 | % |  | 4,169 |  |  | 4,131 |  |  | 65.6 | % |  | 66.0 | % |
| Total |  | $ | 7,773 |  |  | $ | 7,498 |  |  | 62.5 | % |  | 63.1 | % |  | $ | 15,919 |  |  | $ | 14,925 |  |  | 62.4 | % |  | 62.1 | % |

[0000858877-19-000003:mdna:164]
[same as prior period, unchanged from 0000858877-18-000015:mdna:138]

[0000858877-19-000003:mdna:165]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the second quarter and first six months of fiscal 2019, as compared with the corresponding prior year periods:

[0000858877-19-000003:mdna:166]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Six Months Ended |
| Fiscal 2018 |  | 61.5 | % |  | 60.8 | % |
| Product pricing |  | (1.0 | )% |  | (1.5 | )% |
| Mix of products sold |  | 0.3 | % |  | (0.2 | )% |
| Productivity (1) |  | (0.2 | )% |  | 1.1 | % |
| Legal and indemnification settlements |  | (0.1 | )% |  | 0.7 | % |
| Impact from divestiture of SPVSS business |  | 0.5 | % |  | 0.5 | % |
| Other |  | — | % |  | (0.1 | )% |
| Fiscal 2019 |  | 61.0 | % |  | 61.3 | % |

[0000858877-19-000003:mdna:167]
[same as prior period, unchanged from 0000858877-18-000015:mdna:141]

[0000858877-19-000003:mdna:168]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:169]
Product gross margin decreased by 0.5 percentage points driven by unfavorable impacts from product pricing and productivity, partially offset by favorable product mix. Our product gross margin also benefited from the sale of our lower margin SPVSS business during the second quarter of fiscal 2019.

[0000858877-19-000003:mdna:170]
The negative pricing impact, which was lower than the year-over-year impact we experienced in the second quarter of fiscal 2018, was driven by typical market factors and impacted each of our geographic segments and customer markets. Our productivity was negatively impacted by higher costs of memory and other components, partially offset by cost reductions including value engineering efforts (e.g. component redesign, board configuration, test processes and transformation processes) and continued operational efficiency in manufacturing operations.

[0000858877-19-000003:mdna:171]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:172]
Product gross margin increased by 0.5 percentage points driven by productivity improvements, partially offset by unfavorable impacts from product pricing and product mix. A charge of $127 million to product cost of sales recorded in the first six months of fiscal 2018 related to legal and indemnification settlements also contributed to the increase. Our product gross margin also benefited from the sale of our lower margin SPVSS business during the second quarter of fiscal 2019.

[0000858877-19-000003:mdna:173]
Productivity improvements were driven by cost reductions including value engineering efforts (e.g. component redesign, board configuration, test processes, and transformation processes) and continued operational efficiency in manufacturing operations.

[0000858877-19-000003:mdna:174]
[same as prior period, unchanged from 0000858877-18-000015:mdna:178]

[0000858877-19-000003:mdna:175]
[same as prior period, unchanged from 0000858877-18-000015:mdna:150]

[0000858877-19-000003:mdna:176]
[same as prior period, unchanged from 0000858877-18-000015:mdna:151]

[0000858877-19-000003:mdna:177]
[same as prior period, unchanged from 0000858877-18-000015:mdna:145]

[0000858877-19-000003:mdna:178]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:179]
Our service gross margin percentage decreased by 0.8 percentage points due to increased headcount-related costs and increased delivery costs, partially offset by favorable mix.

[0000858877-19-000003:mdna:180]
[same as prior period, unchanged from 0000858877-18-000015:mdna:148]

[0000858877-19-000003:mdna:181]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:182]
Service gross margin percentage decreased by 0.4 percentage points due to increased headcount-related costs and increased delivery costs. These cost impacts were partially offset by the resulting benefit to gross margin of higher sales volume.

[0000858877-19-000003:mdna:183]
[same as prior period, unchanged from 0000858877-18-000015:mdna:152]

[0000858877-19-000003:mdna:184]
[same as prior period, unchanged from 0000858877-18-000015:mdna:153]

[0000858877-19-000003:mdna:185]
|  | Three Months Ended |  | Six Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,796 |  |  | $ | 4,614 |  |  | 65.2 | % |  | 65.9 | % |  | $ | 9,866 |  |  | $ | 9,336 |  |  | 65.3 | % |  | 65.0 | % |
| EMEA | 2,070 |  |  | 1,977 |  |  | 64.2 | % |  | 64.6 | % |  | 4,141 |  |  | 3,816 |  |  | 64.2 | % |  | 63.9 | % |
| APJC | 1,109 |  |  | 1,094 |  |  | 59.2 | % |  | 60.1 | % |  | 2,309 |  |  | 2,259 |  |  | 58.2 | % |  | 61.1 | % |
| Segment total | 7,975 |  |  | 7,685 |  |  | 64.1 | % |  | 64.7 | % |  | 16,316 |  |  | 15,411 |  |  | 63.9 | % |  | 64.2 | % |
| Unallocated corporate items (1) | (202 | ) |  | (187 | ) |  |  |  |  |  | (397 | ) |  | (486 | ) |  |  |  |  |
| Total | $ | 7,773 |  |  | $ | 7,498 |  |  | 62.5 | % |  | 63.1 | % |  | $ | 15,919 |  |  | $ | 14,925 |  |  | 62.4 | % |  | 62.1 | % |

[0000858877-19-000003:mdna:186]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-19-000003:mdna:187]
[same as prior period, unchanged from 0000858877-18-000015:mdna:156]

[0000858877-19-000003:mdna:188]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:189]
We experienced a gross margin percentage decrease in our Americas segment due to unfavorable impacts from pricing and mix, partially offset by productivity improvements.

[0000858877-19-000003:mdna:190]
The gross margin percentage decrease in our EMEA segment was due primarily to lower service gross margin. Product gross margin in this segment increased due to favorable product mix partially offset by negative impacts from productivity and pricing.

[0000858877-19-000003:mdna:191]
The APJC segment gross margin percentage decrease was due primarily to lower service gross margin. Product gross margin in this segment increased slightly due to favorable product mix and productivity improvements, partially offset by negative impacts from pricing.

[0000858877-19-000003:mdna:192]
[same as prior period, unchanged from 0000858877-18-000015:mdna:161]

[0000858877-19-000003:mdna:193]
[same as prior period, unchanged from 0000858877-18-000015:mdna:163]

[0000858877-19-000003:mdna:194]
[same as prior period, unchanged from 0000858877-18-000015:mdna:164]

[0000858877-19-000003:mdna:195]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:196]
The Americas segment had a gross margin percentage increase driven by productivity improvements, partially offset by unfavorable impacts from pricing and mix.

[0000858877-19-000003:mdna:197]
The gross margin percentage increase in our EMEA segment was due to productivity improvements and favorable mix, partially offset by negative impacts from pricing.

[0000858877-19-000003:mdna:198]
The APJC segment gross margin percentage decrease was due to negative impacts from pricing partially offset by favorable mix and productivity improvements.

[0000858877-19-000003:mdna:199]
[same as prior period, unchanged from 0000858877-18-000015:mdna:165]

[0000858877-19-000003:mdna:200]
[same as prior period, unchanged from 0000858877-18-000015:mdna:166]

[0000858877-19-000003:mdna:201]
|  | Three Months Ended |  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |  | Variance in Percent |  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,557 |  |  | $ | 1,549 |  |  | $ | 8 |  |  | 1 | % |  | $ | 3,165 |  |  | $ | 3,116 |  |  | $ | 49 |  |  | 2 | % |
| Percentage of revenue | 12.5 | % |  | 13.0 | % |  |  |  |  |  | 12.4 | % |  | 13.0 | % |  |  |  |  |
| Sales and marketing | 2,271 |  |  | 2,235 |  |  | 36 |  |  | 2 | % |  | 4,681 |  |  | 4,569 |  |  | 112 |  |  | 2 | % |
| Percentage of revenue | 18.2 | % |  | 18.8 | % |  |  |  |  |  | 18.3 | % |  | 19.0 | % |  |  |  |  |
| General and administrative | 509 |  |  | 483 |  |  | 26 |  |  | 5 | % |  | 720 |  |  | 1,040 |  |  | (320 | ) |  | (31 | )% |
| Percentage of revenue | 4.1 | % |  | 4.1 | % |  |  |  |  |  | 2.8 | % |  | 4.3 | % |  |  |  |  |
| Total | $ | 4,337 |  |  | $ | 4,267 |  |  | $ | 70 |  |  | 2 | % |  | $ | 8,566 |  |  | $ | 8,725 |  |  | $ | (159 | ) |  | (2 | )% |
| Percentage of revenue | 34.8 | % |  | 35.9 | % |  |  |  |  |  | 33.6 | % |  | 36.3 | % |  |  |  |  |

[0000858877-19-000003:mdna:202]
[same as prior period, unchanged from 0000858877-18-000015:mdna:169]

[0000858877-19-000003:mdna:203]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:204]
R&D expenses increased slightly as increases in headcount-related expenses and acquisition-related/divestiture costs significantly offset the decrease in discretionary spending.

[0000858877-19-000003:mdna:205]
[same as prior period, unchanged from 0000858877-18-000015:mdna:171]

[0000858877-19-000003:mdna:206]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:207]
R&D expenses increased primarily due to higher headcount-related expenses and, to a lesser extent, higher contracted services and higher acquisition-related/divestiture costs. These increases were partially offset by lower discretionary spending and share-based compensation expense.

[0000858877-19-000003:mdna:208]
[same as prior period, unchanged from 0000858877-18-000015:mdna:172]

[0000858877-19-000003:mdna:209]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:210]
Sales and marketing expenses increased due to higher discretionary spending, headcount-related expenses, contracted services and acquisition-related/divestiture costs, partially offset by lower share-based compensation expense.

[0000858877-19-000003:mdna:211]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:212]
Sales and marketing expenses increased due to higher discretionary spending, higher headcount-related expenses and, to a lesser extent, higher contracted services and higher acquisition-related/divestiture costs, partially offset by lower share-based compensation expense.

[0000858877-19-000003:mdna:213]
[same as prior period, unchanged from 0000858877-18-000015:mdna:213]

[0000858877-19-000003:mdna:214]
[same as prior period, unchanged from 0000858877-18-000015:mdna:179]

[0000858877-19-000003:mdna:215]
[same as prior period, unchanged from 0000858877-18-000015:mdna:180]

[0000858877-19-000003:mdna:216]
[same as prior period, unchanged from 0000858877-18-000015:mdna:174]

[0000858877-19-000003:mdna:217]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:218]
G&A expenses increased due to higher discretionary spending and headcount-related expenses, partially offset by lower contracted services.

[0000858877-19-000003:mdna:219]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:220]
G&A expenses decreased due to a benefit from the $400 million litigation settlement with Arista, partially offset by higher discretionary spending, higher acquisition-related/divestiture costs and higher headcount-related expenses.

[0000858877-19-000003:mdna:221]
[same as prior period, unchanged from 0000858877-18-000015:mdna:176]

[0000858877-19-000003:mdna:222]
In the second quarter of fiscal 2019, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $52 million, or 1.2%, compared with the second quarter of fiscal 2018.

[0000858877-19-000003:mdna:223]
In the first six months of fiscal 2019, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $102 million, or 1.2%, compared with the first six months of fiscal 2018.

[0000858877-19-000003:mdna:224]
[same as prior period, unchanged from 0000858877-18-000015:mdna:181]

[0000858877-19-000003:mdna:225]
[same as prior period, unchanged from 0000858877-18-000015:mdna:182]

[0000858877-19-000003:mdna:226]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Cost of sales—product |  | $ | 22 |  |  | $ | 23 |  |  | $ | 45 |  |  | $ | 46 |  |
| Cost of sales—service |  | 31 |  |  | 31 |  |  | 64 |  |  | 65 |  |
| Share-based compensation expense in cost of sales |  | 53 |  |  | 54 |  |  | 109 |  |  | 111 |  |
| Research and development |  | 133 |  |  | 134 |  |  | 263 |  |  | 270 |  |
| Sales and marketing |  | 125 |  |  | 135 |  |  | 262 |  |  | 270 |  |
| General and administrative |  | 65 |  |  | 64 |  |  | 127 |  |  | 128 |  |
| Restructuring and other charges |  | 19 |  |  | 12 |  |  | 42 |  |  | 18 |  |
| Share-based compensation expense in operating expenses |  | 342 |  |  | 345 |  |  | 694 |  |  | 686 |  |
| Total share-based compensation expense |  | $ | 395 |  |  | $ | 399 |  |  | $ | 803 |  |  | $ | 797 |  |

[0000858877-19-000003:mdna:227]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:228]
The decrease in share-based compensation expense was due primarily to higher forfeitures partially offset by higher restructuring charges.

[0000858877-19-000003:mdna:229]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:230]
[same as prior period, unchanged from 0000858877-18-000015:mdna:185]

[0000858877-19-000003:mdna:231]
[same as prior period, unchanged from 0000858877-18-000015:mdna:186]

[0000858877-19-000003:mdna:232]
[same as prior period, unchanged from 0000858877-18-000015:mdna:187]

[0000858877-19-000003:mdna:233]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 156 |  |  | $ | 160 |  |  | $ | 307 |  |  | $ | 314 |  |
| Operating expenses |  | 39 |  |  | 60 |  |  | 73 |  |  | 121 |  |
| Total |  | $ | 195 |  |  | $ | 220 |  |  | $ | 380 |  |  | $ | 435 |  |

[0000858877-19-000003:mdna:234]
65

[0000858877-19-000003:mdna:235]
[same as prior period, unchanged from 0000858877-18-000015:mdna:195]

[0000858877-19-000003:mdna:236]
[same as prior period, unchanged from 0000858877-18-000015:mdna:196]

[0000858877-19-000003:mdna:237]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:238]
Amortization of purchased intangible assets decreased due largely to the purchased intangible assets related to the divestiture of SPVSS business on October 28, 2018, partially offset by amortization from our recent acquisitions.

[0000858877-19-000003:mdna:239]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:240]
Amortization of purchased intangible assets decreased due largely to the purchased intangible assets related to the divestiture of SPVSS business on October 28, 2018, partially offset by amortization from our recent acquisitions.

[0000858877-19-000003:mdna:241]
[same as prior period, unchanged from 0000858877-18-000015:mdna:191]

[0000858877-19-000003:mdna:242]
We initiated a restructuring plan during fiscal 2018 in order to realign our organization and enable further investment in key priority areas, with estimated pretax charges of approximately $600 million. In connection with this restructuring plan, we incurred charges of $186 million and $264 million for the second quarter and first six months of fiscal 2019, respectively, and have incurred cumulative charges of $372 million since inception. We expect this restructuring plan to be substantially completed in fiscal 2019.

[0000858877-19-000003:mdna:243]
We incurred restructuring and other charges of $98 million and $250 million for the second quarter and first six months of fiscal 2018 in connection with the restructuring plan announced in August 2016.

[0000858877-19-000003:mdna:244]
[same as prior period, unchanged from 0000858877-18-000015:mdna:194]

[0000858877-19-000003:mdna:245]
[same as prior period, unchanged from 0000858877-18-000015:mdna:197]

[0000858877-19-000003:mdna:246]
[same as prior period, unchanged from 0000858877-18-000015:mdna:198]

[0000858877-19-000003:mdna:247]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 26, 2019 |  | January 27, 2018 |  | January 26, 2019 |  | January 27, 2018 |
| Operating income |  | $ | 3,211 |  |  | $ | 3,073 |  |  | $ | 7,016 |  |  | $ | 5,829 |  |
| Operating income as a percentage of revenue |  | 25.8 | % |  | 25.9 | % |  | 27.5 | % |  | 24.3 | % |

[0000858877-19-000003:mdna:248]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:249]
Operating income increased by 4% and as a percentage of revenue operating income decreased by 0.1 percentage points. These changes resulted primarily from: a revenue increase, a gross margin percentage decrease (driven primarily by unfavorable impacts from pricing and productivity), and higher restructuring and other charges.

[0000858877-19-000003:mdna:250]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:251]
Operating income increased by 20% and as a percentage of revenue operating income increased by 3.2 percentage points. These increases resulted primarily from: a revenue increase, a gross margin percentage increase (driven primarily by productivity improvements and a charge of $127 million to product cost of sales recorded in the first six months of fiscal 2018 related to legal and indemnification settlements) and a benefit from the $400 million litigation settlement with Arista in the first quarter of fiscal 2019.

[0000858877-19-000003:mdna:252]
[same as prior period, unchanged from 0000858877-18-000015:mdna:202]

[0000858877-19-000003:mdna:253]
[same as prior period, unchanged from 0000858877-18-000015:mdna:203]

[0000858877-19-000003:mdna:254]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |
| Interest income |  | $ | 328 |  |  | $ | 396 |  |  | $ | (68 | ) |  | $ | 672 |  |  | $ | 775 |  |  | $ | (103 | ) |
| Interest expense |  | (223 | ) |  | (247 | ) |  | 24 |  |  | (444 | ) |  | (482 | ) |  | 38 |  |
| Interest income (expense), net |  | $ | 105 |  |  | $ | 149 |  |  | $ | (44 | ) |  | $ | 228 |  |  | $ | 293 |  |  | $ | (65 | ) |

[0000858877-19-000003:mdna:255]
Interest income decreased, driven by a decrease in the average balance of cash and available-for-sale debt investments. The decrease in interest expense was driven by a lower average debt balance, partially offset by the impact of higher effective interest rates.

[0000858877-19-000003:mdna:256]
[same as prior period, unchanged from 0000858877-18-000015:mdna:214]

[0000858877-19-000003:mdna:257]
[same as prior period, unchanged from 0000858877-18-000015:mdna:215]

[0000858877-19-000003:mdna:258]
[same as prior period, unchanged from 0000858877-18-000015:mdna:207]

[0000858877-19-000003:mdna:259]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |  | January 26, 2019 |  | January 27, 2018 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | (5 | ) |  | $ | (96 | ) |  | $ | 91 |  |  | $ | (11 | ) |  | $ | (92 | ) |  | $ | 81 |  |
| Marketable equity investments |  | 61 |  |  | 154 |  |  | (93 | ) |  | 57 |  |  | 183 |  |  | (126 | ) |
| Non-marketable equity and other investments |  | (3 | ) |  | 2 |  |  | (5 | ) |  | 1 |  |  | 37 |  |  | (36 | ) |
| Net gains (losses) on investments |  | 53 |  |  | 60 |  |  | (7 | ) |  | 47 |  |  | 128 |  |  | (81 | ) |
| Other gains (losses), net |  | (26 | ) |  | (50 | ) |  | 24 |  |  | (39 | ) |  | (56 | ) |  | 17 |  |
| Other income (loss), net |  | $ | 27 |  |  | $ | 10 |  |  | $ | 17 |  |  | $ | 8 |  |  | $ | 72 |  |  | $ | (64 | ) |

[0000858877-19-000003:mdna:260]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:261]
The total change in net gains (losses) on available-for-sale debt investments was primarily attributable to lower realized losses as a result of market conditions, and the timing of sales of these investments.

[0000858877-19-000003:mdna:262]
The total change in net gains (losses) on marketable equity investments was attributable to market value fluctuations and the timing of recognition of gains and losses.

[0000858877-19-000003:mdna:263]
The change in net gains (losses) on non-marketable equity and other investments was primarily due to higher realized net losses, partially offset by higher unrealized gains and lower impairment charges.

[0000858877-19-000003:mdna:264]
The change in other gains (losses), net was primarily driven by net favorable foreign exchange impacts.

[0000858877-19-000003:mdna:265]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:266]
The total change in net gains (losses) on available-for-sale debt investments was primarily attributable to lower realized losses as a result of market conditions, and the timing of sales of these investments.

[0000858877-19-000003:mdna:267]
The total change in net gains (losses) on marketable equity investments was attributable to market value fluctuations and the timing of recognition of gains and losses.

[0000858877-19-000003:mdna:268]
The change in net gains (losses) on non-marketable equity and other investments was primarily due to higher realized net losses, partially offset by higher unrealized gains and lower impairment charges.

[0000858877-19-000003:mdna:269]
The change in other gains (losses), net was driven by net favorable foreign exchange impacts partially offset by lower gains from customer lease terminations.

[0000858877-19-000003:mdna:270]
[same as prior period, unchanged from 0000858877-18-000015:mdna:216]

[0000858877-19-000003:mdna:271]
Three Months Ended January 26, 2019 Compared with Three Months Ended January 27, 2018

[0000858877-19-000003:mdna:272]
The provision for income taxes resulted in an effective tax rate of 15.6% for the second quarter of fiscal 2019 compared with 371.6% for the second quarter of fiscal 2018. The decrease in the effective tax rate was primarily due to the one-time transition tax on accumulated earnings of foreign subsidiaries, foreign withholding tax, and DTA re-measurement recorded during the second quarter of fiscal 2018.

[0000858877-19-000003:mdna:273]
[same as prior period, unchanged from 0000858877-18-000015:mdna:218]

[0000858877-19-000003:mdna:274]
67

[0000858877-19-000003:mdna:275]
[same as prior period, unchanged from 0000858877-18-000015:mdna:229]

[0000858877-19-000003:mdna:276]
[same as prior period, unchanged from 0000858877-18-000015:mdna:230]

[0000858877-19-000003:mdna:277]
Six Months Ended January 26, 2019 Compared with Six Months Ended January 27, 2018

[0000858877-19-000003:mdna:278]
The provision for income taxes resulted in an effective tax rate of 12.1% for the first six months of fiscal 2019 compared with 203.1% for the first six months of fiscal 2018. The decrease in the effective tax rate was primarily due to the one-time transition tax on accumulated earnings of foreign subsidiaries, foreign withholding tax, and DTA re-measurement recorded during the first six months of fiscal 2018.

[0000858877-19-000003:mdna:279]
[same as prior period, unchanged from 0000858877-18-000015:mdna:219]

[0000858877-19-000003:mdna:280]
[same as prior period, unchanged from 0000858877-18-000015:mdna:220]

[0000858877-19-000003:mdna:281]
[same as prior period, unchanged from 0000858877-18-000015:mdna:221]

[0000858877-19-000003:mdna:282]
[same as prior period, unchanged from 0000858877-18-000015:mdna:222]

[0000858877-19-000003:mdna:283]
|  | January 26, 2019 |  | July 28, 2018 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 9,835 |  |  | $ | 8,934 |  |  | $ | 901 |  |
| Available-for-sale debt investments | 30,486 |  |  | 37,009 |  |  | (6,523 | ) |
| Marketable equity securities | 62 |  |  | 605 |  |  | (543 | ) |
| Total | $ | 40,383 |  |  | $ | 46,548 |  |  | $ | (6,165 | ) |

[0000858877-19-000003:mdna:284]
The decrease in cash and cash equivalents and investments in the first six months of fiscal 2019 was primarily driven by cash returned to shareholders in the form of repurchases of common stock of $10.1 billion under the stock repurchase program and cash dividends of $3.0 billion; net cash paid for acquisitions and divestitures of $1.6 billion; and capital expenditures of $0.5 billion. These uses of cash were partially offset by cash provided by operating activities of $7.6 billion and timing of settlements of investments and other of $1.6 billion.

[0000858877-19-000003:mdna:285]
In addition to cash requirements in the normal course of business, in the third quarter of fiscal 2019 on February 6, 2019, we closed the acquisition of Luxtera for a purchase price of approximately $0.7 billion in cash and assumed equity awards. Also approximately $0.7 billion of the U.S. transition tax on accumulated earnings for foreign subsidiaries is payable in less than one year. Additionally, $9.7 billion of long term debt which was outstanding at January 26, 2019 (of which $2.0 billion was repaid on February 15, 2019) and approximately $2 billion of commercial paper notes (issued in February 2019) will mature within the next 12 months from the balance sheet date. See further discussion of liquidity under “Liquidity and Capital Resource Requirements” below.

[0000858877-19-000003:mdna:286]
[same as prior period, unchanged from 0000858877-18-000015:mdna:225]

[0000858877-19-000003:mdna:287]
[same as prior period, unchanged from 0000858877-18-000015:mdna:226]

[0000858877-19-000003:mdna:288]
[same as prior period, unchanged from 0000858877-18-000015:mdna:227]

[0000858877-19-000003:mdna:289]
|  | Six Months Ended |
|  | January 26, 2019 |  | January 27, 2018 |
| Net cash provided by operating activities | $ | 7,560 |  |  | $ | 7,150 |  |
| Acquisition of property and equipment | (473 | ) |  | (379 | ) |
| Free cash flow | $ | 7,087 |  |  | $ | 6,771 |  |

[0000858877-19-000003:mdna:290]
[same as prior period, unchanged from 0000858877-18-000015:mdna:242]

[0000858877-19-000003:mdna:291]
[same as prior period, unchanged from 0000858877-18-000015:mdna:243]

[0000858877-19-000003:mdna:292]
[same as prior period, unchanged from 0000858877-18-000015:mdna:231]

[0000858877-19-000003:mdna:293]
[same as prior period, unchanged from 0000858877-18-000015:mdna:232]

[0000858877-19-000003:mdna:294]
[same as prior period, unchanged from 0000858877-18-000015:mdna:233]

[0000858877-19-000003:mdna:295]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2019 |  |  |  |  |  |  |  |  |  |  |  |  |
| January 26, 2019 |  | $ | 0.33 |  |  | $ | 1,470 |  |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |  | $ | 6,486 |  |
| October 27, 2018 |  | $ | 0.33 |  |  | $ | 1,500 |  |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |  | $ | 6,526 |  |
| Fiscal 2018 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 28, 2018 |  | $ | 0.33 |  |  | $ | 1,535 |  |  | 138 |  |  | $ | 43.58 |  |  | $ | 6,015 |  |  | $ | 7,550 |  |
| April 28, 2018 |  | $ | 0.33 |  |  | $ | 1,572 |  |  | 140 |  |  | $ | 42.83 |  |  | $ | 6,015 |  |  | $ | 7,587 |  |
| January 27, 2018 |  | $ | 0.29 |  |  | $ | 1,425 |  |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |  | $ | 5,436 |  |
| October 28, 2017 |  | $ | 0.29 |  |  | $ | 1,436 |  |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |  | $ | 3,056 |  |

[0000858877-19-000003:mdna:296]
On February 13, 2019, our Board of Directors declared a quarterly dividend of $0.35 per common share to be paid on April 24, 2019 to all shareholders of record as of the close of business on April 5, 2019. Any future dividends are subject to the approval of our Board of Directors.

[0000858877-19-000003:mdna:297]
On February 13, 2019, our Board of Directors authorized a $15 billion increase to the stock repurchase program. The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $24 billion, with no termination date.

[0000858877-19-000003:mdna:298]
[same as prior period, unchanged from 0000858877-18-000015:mdna:237]

[0000858877-19-000003:mdna:299]
[same as prior period, unchanged from 0000858877-18-000015:mdna:238]

[0000858877-19-000003:mdna:300]
|  | January 26, 2019 |  | July 28, 2018 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 3,745 |  |  | $ | 5,554 |  |  | $ | (1,809 | ) |

[0000858877-19-000003:mdna:301]
Our accounts receivable net, as of January 26, 2019 decreased by approximately 33%, as compared with the end of fiscal 2018, primarily due to product and service billings being more linear in the second quarter of fiscal 2019 compared with the fourth quarter of fiscal 2018.

[0000858877-19-000003:mdna:302]
69

[0000858877-19-000003:mdna:303]
[same as prior period, unchanged from 0000858877-18-000015:mdna:255]

[0000858877-19-000003:mdna:304]
[same as prior period, unchanged from 0000858877-18-000015:mdna:256]

[0000858877-19-000003:mdna:305]
[same as prior period, unchanged from 0000858877-18-000015:mdna:244]

[0000858877-19-000003:mdna:306]
|  | January 26, 2019 |  | July 28, 2018 |  | Increase (Decrease) |
| Inventories | $ | 1,701 |  |  | $ | 1,846 |  |  | $ | (145 | ) |

[0000858877-19-000003:mdna:307]
Inventory as of January 26, 2019 decreased by 8% from our inventory balance at the end of fiscal 2018. The decrease in inventory was due primarily to lower deferred cost of sales related to the adoption of ASC 606 in the beginning of our first quarter of fiscal 2019.

[0000858877-19-000003:mdna:308]
[same as prior period, unchanged from 0000858877-18-000015:mdna:247]

[0000858877-19-000003:mdna:309]
[same as prior period, unchanged from 0000858877-18-000015:mdna:248]

[0000858877-19-000003:mdna:310]
| Commitments by Period | January 26, 2019 |  | July 28, 2018 |
| Less than 1 year | $ | 5,366 |  |  | $ | 5,407 |  |
| 1 to 3 years | 731 |  |  | 710 |  |
| 3 to 5 years | 180 |  |  | 360 |  |
| Total | $ | 6,277 |  |  | $ | 6,477 |  |

[0000858877-19-000003:mdna:311]
Purchase commitments with contract manufacturers and suppliers decreased 3% compared to the end of fiscal 2018.  On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers decreased by 4% compared with the end of fiscal 2018.

[0000858877-19-000003:mdna:312]
[same as prior period, unchanged from 0000858877-18-000015:mdna:251]

[0000858877-19-000003:mdna:313]
[same as prior period, unchanged from 0000858877-18-000015:mdna:252]

[0000858877-19-000003:mdna:314]
|  | January 26, 2019 |  | July 28, 2018 |  | Increase (Decrease) |
| Lease receivables, net | $ | 2,371 |  |  | $ | 2,576 |  |  | $ | (205 | ) |
| Loan receivables, net | 4,862 |  |  | 4,939 |  |  | (77 | ) |
| Financed service contracts, net | 2,389 |  |  | 2,316 |  |  | 73 |  |
| Total, net | $ | 9,622 |  |  | $ | 9,831 |  |  | $ | (209 | ) |

[0000858877-19-000003:mdna:315]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type and direct-financing leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services.  The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed.  Financing receivables decreased by 2%. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-19-000003:mdna:316]
70

[0000858877-19-000003:mdna:317]
[same as prior period, unchanged from 0000858877-18-000015:mdna:264]

[0000858877-19-000003:mdna:318]
[same as prior period, unchanged from 0000858877-18-000015:mdna:265]

[0000858877-19-000003:mdna:319]
[same as prior period, unchanged from 0000858877-18-000015:mdna:257]

[0000858877-19-000003:mdna:320]
The volume of channel partner financing was $14.5 billion and $13.6 billion for the first six months of fiscal 2019 and 2018, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.0 billion as of January 26, 2019 and July 28, 2018, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of January 26, 2019, the total maximum potential future payments related to these guarantees was approximately $363 million, of which approximately $86 million was recorded as deferred revenue.

[0000858877-19-000003:mdna:321]
[same as prior period, unchanged from 0000858877-18-000015:mdna:259]

[0000858877-19-000003:mdna:322]
[same as prior period, unchanged from 0000858877-18-000015:mdna:260]

[0000858877-19-000003:mdna:323]
|  | Maturity Date |  | January 26, 2019 |  | July 28, 2018 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | $ | 500 |  |  | $ | 500 |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1,000 |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1,500 |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 25,750 |  |  | $ | 25,750 |  |

[0000858877-19-000003:mdna:324]
We repaid our senior notes due on February 15, 2019 for an aggregate principal amount of $2.0 billion upon maturity.

[0000858877-19-000003:mdna:325]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of January 26, 2019.

[0000858877-19-000003:mdna:326]
[same as prior period, unchanged from 0000858877-18-000015:mdna:276]

[0000858877-19-000003:mdna:327]
[same as prior period, unchanged from 0000858877-18-000015:mdna:277]

[0000858877-19-000003:mdna:328]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.  We had no commercial paper notes outstanding as of January 26, 2019 and July 28, 2018. As of February 18, 2019, we had approximately $2 billion of commercial paper notes outstanding.

[0000858877-19-000003:mdna:329]
Credit Facility On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.  As of January 26, 2019, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-19-000003:mdna:330]
[same as prior period, unchanged from 0000858877-18-000015:mdna:268]

[0000858877-19-000003:mdna:331]
|  | January 26, 2019 |  | July 28, 2018 |  | Increase (Decrease) |
| Service | $ | 11,246 |  |  | $ | 11,431 |  |  | $ | (185 | ) |
| Product | 6,015 |  |  | 8,254 |  |  | (2,239 | ) |
| Total | $ | 17,261 |  |  | $ | 19,685 |  |  | $ | (2,424 | ) |
| Reported as: |  |  |  |  |  |
| Current | $ | 9,976 |  |  | $ | 11,490 |  |  | $ | (1,514 | ) |
| Noncurrent | 7,285 |  |  | 8,195 |  |  | (910 | ) |
| Total | $ | 17,261 |  |  | $ | 19,685 |  |  | $ | (2,424 | ) |

[0000858877-19-000003:mdna:332]
[same as prior period, unchanged from 0000858877-18-000015:mdna:270]

[0000858877-19-000003:mdna:333]
[same as prior period, unchanged from 0000858877-18-000015:mdna:271]

[0000858877-19-000003:mdna:334]
[same as prior period, unchanged from 0000858877-18-000015:mdna:272]

[0000858877-19-000003:mdna:335]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Australia, Belgium, Canada, China, Germany, India, Japan, Mexico, Poland and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of January 26, 2019 were $1.2 billion.

[0000858877-19-000003:mdna:336]
[same as prior period, unchanged from 0000858877-18-000015:mdna:274]

[0000858877-19-000003:mdna:337]
The income tax payable outstanding as of January 26, 2019 for the U.S. transition tax on accumulated earnings for foreign subsidiaries is $7.4 billion. Approximately $0.7 billion is payable in less than one year; $1.3 billion is payable between 1 to 3 years; $1.9 billion is payable between 3 to 5 years; and the remaining $3.5 billion is payable in more than 5 years. See Note 17 to the Consolidated Financial Statements.

[0000858877-19-000003:mdna:338]
72

[0000858877-19-000003:mdna:339]
CISCO SYSTEMS, INC.

[0000858877-19-000003:mdna:340]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-19-000003:mdna:341]
[same as prior period, unchanged from 0000858877-18-000015:mdna:278]

[0000858877-19-000003:mdna:342]
[same as prior period, unchanged from 0000858877-18-000015:mdna:279]

[0000858877-19-000003:mdna:343]
Other Funding Commitments  We also have certain funding commitments primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $357 million as of January 26, 2019, compared with $223 million as of July 28, 2018.

[0000858877-19-000003:mdna:344]
[same as prior period, unchanged from 0000858877-18-000015:mdna:281]

[0000858877-19-000003:mdna:345]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have non-marketable equity and other investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our non-marketable equity and other investments and customer financings, and we have determined that as of January 26, 2019 there were no material unconsolidated variable interest entities.

[0000858877-19-000003:mdna:346]
[same as prior period, unchanged from 0000858877-18-000015:mdna:283]

[0000858877-19-000003:mdna:347]
[same as prior period, unchanged from 0000858877-18-000015:mdna:284]

[0000858877-19-000003:mdna:348]
[same as prior period, unchanged from 0000858877-18-000015:mdna:285]

[0000858877-19-000003:mdna:349]
[same as prior period, unchanged from 0000858877-18-000015:mdna:286]

[0000858877-19-000003:mdna:350]
73
