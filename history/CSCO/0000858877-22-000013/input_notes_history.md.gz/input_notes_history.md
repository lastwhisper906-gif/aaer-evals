# CSCO note change history — 0000858877-22-000004 → 0000858877-22-000009


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-25):
[0000858877-22-000009:note_history:1]
|  | April 30,2022 |  | July 31,2021 |
| Less than 1 year | $ | 10,698 |  |  | $ | 6,903 |  |
| 1 to 3 years | 2,401 |  |  | 1,806 |  |
| 3 to 5 years | — |  |  | 1,545 |  |
| Total | $ | 13,099 |  |  | $ | 10,254 |  |
  (was, 2022-02-22, similarity 0.9691):
[0000858877-22-000004:note_history:1]
|  | January 29,2022 |  | July 31,2021 |
| Less than 1 year | $ | 9,224 |  |  | $ | 6,903 |  |
| 1 to 3 years | 1,879 |  |  | 1,806 |  |
| 3 to 5 years | 1,159 |  |  | 1,545 |  |
| Total | $ | 12,262 |  |  | $ | 10,254 |  |

- changed (2022-05-25):
[0000858877-22-000009:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 30, 2022 and July 31, 2021, the liability for these purchase commitments was $236 million and $151 million, respectively, and was included in other current liabilities. For further discussion around the Supply Constraints Impacts and Risks, see Result of Operations—Product Gross Margin and Liquidity and Capital Resources—Inventory Supply Chain.
  (was, 2022-02-22, similarity 0.9892):
[0000858877-22-000004:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 29, 2022 and July 31, 2021, the liability for these purchase commitments was $199 million and $151 million, respectively, and was included in other current liabilities. For further discussion around the Supply Constraints Impacts and Risks, see Result of Operations—Product Gross Margin and Liquidity and Capital Resources—Inventory Supply Chain.

- changed (2022-05-25):
[0000858877-22-000009:note_history:3]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2022 |  | May 1, 2021 |  | April 30, 2022 |  | May 1, 2021 |
| Compensation expense related to acquisitions | $ | 56 |  |  | $ | 66 |  |  | $ | 220 |  |  | $ | 182 |  |
  (was, 2022-02-22, similarity 0.7431):
[0000858877-22-000004:note_history:3]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29, 2022 |  | January 23, 2021 |  | January 29, 2022 |  | January 23, 2021 |
| Compensation expense related to acquisitions | $ | 75 |  |  | $ | 59 |  |  | $ | 164 |  |  | $ | 116 |  |

- changed (2022-05-25):
[0000858877-22-000009:note_history:4]
As of April 30, 2022, we estimated that future cash compensation expense of up to $534 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2022-02-22, similarity 0.9778):
[0000858877-22-000004:note_history:4]
As of January 29, 2022, we estimated that future cash compensation expense of up to $600 million may be required to be recognized pursuant to the applicable business combination agreements.

- changed (2022-05-25):
[0000858877-22-000009:note_history:5]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.4 billion and $0.2 billion as of April 30, 2022 and July 31, 2021, respectively.
  (was, 2022-02-22, similarity 0.9129):
[0000858877-22-000004:note_history:5]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.4 billion and $0.2 billion as of January 29, 2022 and July 31, 2021, respectively.

- changed (2022-05-25):
[0000858877-22-000009:note_history:6]
|  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |
| Balance at beginning of period | $ | 336 |  |  | $ | 331 |  |
| Provisions for warranties issued | 320 |  |  | 382 |  |
| Adjustments for pre-existing warranties | 1 |  |  | 1 |  |
| Settlements | (322) |  |  | (373) |  |
| Balance at end of period | $ | 335 |  |  | $ | 341 |  |
  (was, 2022-02-22, similarity 0.9318):
[0000858877-22-000004:note_history:6]
|  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |
| Balance at beginning of period | $ | 336 |  |  | $ | 331 |  |
| Provisions for warranties issued | 218 |  |  | 247 |  |
| Adjustments for pre-existing warranties | 2 |  |  | 4 |  |
| Settlements | (222) |  |  | (249) |  |
| Balance at end of period | $ | 334 |  |  | $ | 333 |  |

- changed (2022-05-25):
[0000858877-22-000009:note_history:7]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.9 billion and $6.6 billion for the third quarter of fiscal 2022 and 2021, respectively, and was $20.3 billion and $19.5 billion for the first nine months of fiscal 2022 and 2021, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion as of each of April 30, 2022 and July 31, 2021.
  (was, 2022-02-22, similarity 0.9281):
[0000858877-22-000004:note_history:7]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.8 billion and $6.7 billion for the second quarter of fiscal 2022 and 2021, respectively, and was $13.4 billion and $12.8 billion for the first six months of fiscal 2022 and 2021, respectively. The balance of the channel partner financing subject to guarantees was $1.4 billion and $1.3 billion as of January 29, 2022 and July 31, 2021, respectively.

- changed (2022-05-25):
[0000858877-22-000009:note_history:8]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $3 million and $1 million for the third quarter of fiscal 2022 and 2021, respectively, and was $9 million and $8 million for the first nine months of fiscal 2022 and 2021, respectively.
  (was, 2022-02-22, similarity 0.984):
[0000858877-22-000004:note_history:8]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $4 million and $3 million for the second quarter of fiscal 2022 and 2021, respectively, and was $6 million and $8 million for the first six months of fiscal 2022 and 2021, respectively.

- changed (2022-05-25):
[0000858877-22-000009:note_history:9]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 30, 2022 and July 31, 2021, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2022-02-22, similarity 0.9807):
[0000858877-22-000004:note_history:9]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 29, 2022 and July 31, 2021, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2022-05-25):
[0000858877-22-000009:note_history:10]
|  | April 30,2022 |  | July 31,2021 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 144 |  |  | $ | 155 |  |
| End user | 4 |  |  | 5 |  |
| Total | $ | 148 |  |  | $ | 160 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (15) |  |  | $ | (16) |  |
| End user | (4) |  |  | (5) |  |
| Total | $ | (19) |  |  | $ | (21) |  |
| Total | $ | 129 |  |  | $ | 139 |  |
  (was, 2022-02-22, similarity 0.9855):
[0000858877-22-000004:note_history:10]
|  | January 29,2022 |  | July 31,2021 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 162 |  |  | $ | 155 |  |
| End user | 4 |  |  | 5 |  |
| Total | $ | 166 |  |  | $ | 160 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (5) |  |  | $ | (16) |  |
| End user | (4) |  |  | (5) |  |
| Total | $ | (9) |  |  | $ | (21) |  |
| Total | $ | 157 |  |  | $ | 139 |  |

- changed (2022-05-25):
[0000858877-22-000009:note_history:11]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $163 million for the alleged evasion of import and other taxes, $840 million for interest, and $402 million for various penalties, all determined using an exchange rate as of April 30, 2022.
  (was, 2022-02-22, similarity 0.995):
[0000858877-22-000004:note_history:11]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $151 million for the alleged evasion of import and other taxes, $764 million for interest, and $373 million for various penalties, all determined using an exchange rate as of January 29, 2022.

- changed (2022-05-25):
[0000858877-22-000009:note_history:12]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted claims against us in the U.S. District Court for the District of Delaware (“D. Del.”), accusing our products and services related to network intrusion detection of infringing two patents. After a trial, SRI obtained a verdict against us, and we appealed to the United States Court of Appeals for the Federal Circuit (“Federal Circuit”) which was ultimately unsuccessful. In resolution of this matter, we have paid the SRI judgments, including attorneys’ fees and post-judgment royalties and interest, in the aggregate amount of approximately $60 million. On May 17, 2022, the District Court entered a final order in the case requiring us to pay SRI additional post-judgment interest of approximately $1 million. We made the payment and the case is now concluded.
  (was, 2022-02-22, similarity 0.7249):
[0000858877-22-000004:note_history:12]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted claims against us in the U.S. District Court for the District of Delaware (“D. Del.”), accusing our products and services related to network intrusion detection of infringing two patents. After a trial, SRI obtained a verdict against us, and we appealed to the United States Court of Appeals for the Federal Circuit (“Federal Circuit”) which was ultimately unsuccessful. In resolution of this matter, we have paid SRI judgments, including attorneys’ fees and post-judgment royalties and interest, in the aggregate amount of approximately $60 million. The only remaining potential liability for this matter involves a small portion of post-judgment interest. The amounts that we paid to date and any potential additional interest we may have to pay involve amounts, individually or in the aggregate, that did not or will not, as applicable, have a material effect on our Consolidated Financial Statements.

- changed (2022-05-25):
[0000858877-22-000009:note_history:13]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services (including our Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal U.S. patents. We thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office (“PTO”) to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. The PTAB’s findings of unpatentability have been affirmed on appeal.
  (was, 2022-02-22, similarity 0.8121):
[0000858877-22-000004:note_history:13]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services (including our Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal U.S. patents. We thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office (“PTO”) to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal appealed the PTAB’s findings of unpatentability to the Federal Circuit. The Federal Circuit affirmed the PTAB’s findings of unpatentability as to three of the patents on March 10, 2021, and affirmed the PTAB’s findings of unpatentability as to the remaining four patents on May 11, 2021. On August 9, 2021, Centripetal filed a writ of certiorari seeking review of the Federal Circuit’s affirmance of several of the PTAB’s unpatentability findings, which the U.S. Supreme Court denied on October 4, 2021.

- changed (2022-05-25):
[0000858877-22-000009:note_history:14]
Centripetal has submitted complaints in the District Court of Dusseldorf in Germany (“German Court”) against Cisco Systems GmbH and Cisco Systems, Inc., asserting a total of six patents. On April 29, 2020 and April 30, 2020, Centripetal asserted three European patents, seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. district court proceedings, one of which has been invalidated by the PTAB.
  (was, 2022-02-22, similarity 0.6387):
[0000858877-22-000004:note_history:14]
On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. district court proceedings, one of which has been invalidated by the PTAB. On June 22, 2021, Centripetal amended one of its complaints to assert one additional European patent and one additional German Utility Model patent. Centripetal seeks both injunctive relief and damages on these newly added patents.

- added (2022-05-25):
[0000858877-22-000009:note_history:15]
On June 22, 2021, Centripetal amended one of its complaints to assert one additional European patent and one additional German Utility Model patent. On December 10, 2021, the German Court rejected Centripetal’s complaints on two patents. Centripetal has appealed. On December 21, 2021, the German Court stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. On May 17, 2022, Centripetal withdrew its complaint for infringement of the German Utility Model patent. The proceedings on Centripetal’s European patent filed on June 22, 2021 remains pending.

- added (2022-05-25):
[0000858877-22-000009:note_history:16]
On February 14, 2022, Centripetal filed an additional complaint asserting infringement of a sixth patent issued by the European Patent Office. Centripetal seeks both injunctive relief and damages on these patents. We are assessing the complaint and are preparing our defense.

- changed (2022-05-25):
[0000858877-22-000009:note_history:17]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of either litigation at this time. If we do not prevail in either litigation, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.
  (was, 2022-02-22, similarity 0.987):
[0000858877-22-000004:note_history:17]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of either litigation at this time. If we do not prevail in either litigation, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

- added (2022-05-25):
[0000858877-22-000009:note_history:18]
Viasat     On January 21, 2016, Viasat, Inc. (“Viasat”) filed suit against Acacia (which we subsequently acquired) in the California Superior Court for San Diego County (“SDSC”) seeking unpaid royalties for breach of contract and the implied covenant of good faith and fair dealing, and damages for trade secret misappropriation for certain products (“Viasat 1”). Acacia counterclaimed for patent and trade secret misappropriation, contract, and unfair competition claims. On July 17, 2019, the jury found for Viasat on its contract claims, and awarded Viasat approximately $49 million for unpaid royalties through 2018. The jury further found that Acacia willfully misappropriated Viasat’s trade secrets and awarded Viasat $1. On Acacia’s counterclaims, the jury found for Acacia on its contract and trade secret claims and awarded Acacia $1. Both Acacia and Viasat appealed to the California Court of Appeal, Fourth Appellate District (“CCA”). On May 23, 2022, the CCA affirmed the judgment of approximately $49 million, plus post-judgment interest and costs, for Viasat on its breach of contract claim for unpaid royalties, but reversed the judgments for Viasat for breach of the implied covenant of good faith and fair dealing, and for trade secret misappropriation. We are currently reviewing the decision of the CCA and assessing whether to seek additional appellate review.

- added (2022-05-25):
[0000858877-22-000009:note_history:19]
On November 6, 2019, Viasat filed a second suit in SDSC, alleging contract and trade secret claims for Acacia products sold from January 1, 2019 forward (“Viasat 2”). On February 28, 2020, the court stayed Viasat 2 pending the appeal in Viasat 1. On June 9, 2020, Viasat filed a third suit in SDSC (“Viasat 3”). In Viasat 3, Viasat alleges contract and trade secrets claims for sales of additional Acacia products. On August 11, 2020, the court stayed Viasat 3 pending the appeal in Viasat 1.

- changed (2022-05-25):
[0000858877-22-000009:note_history:20]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court - Business Litigation Session against ViaSat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation. On April 5, 2018, ViaSat counterclaimed with contract, trade secret, and unfair competition claims (collectively, with Viasat 2 and Viasat 3, the “Viasat Cases”). On December 13, 2018, the Massachusetts court entered an order staying the Massachusetts litigation, which has been extended to June 30, 2022.
  (was, 2022-02-22, similarity 0.9918):
[0000858877-22-000004:note_history:20]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court - Business Litigation Session against ViaSat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation. On April 5, 2018, ViaSat counterclaimed with contract, trade secret, and unfair competition claims (collectively, with Viasat 1, Viasat 2 and Viasat 3, the “Viasat Cases”). On December 13, 2018, the Massachusetts court entered an order staying the Massachusetts litigation, which has been extended to June 30, 2022.

- changed (2022-05-25):
[0000858877-22-000009:note_history:21]
While we believe Acacia has strong defenses in each of the Viasat Cases, we are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If Acacia does not prevail, we
  (was, 2022-02-22, similarity 0.7747):
[0000858877-22-000004:note_history:21]
While we believe Acacia has strong defenses in each of the Viasat Cases, we are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If Acacia does not prevail, we believe that any relief ultimately assessed in any of the Viasat Cases would not have a material effect on our Consolidated Financial Statements.

- added (2022-05-25):
[0000858877-22-000009:note_history:22]
believe that any relief ultimately assessed in any of the Viasat Cases would not have a material effect on our Consolidated Financial Statements.

- added (2022-05-25):
[0000858877-22-000009:note_history:23]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager product infringes three U.S. patents. Egenera seeks damages, including enhanced damages for allegations of willful infringement, and an injunction. Two of the asserted patents have been dismissed, leaving Egenera’s infringement claim based on one asserted patent. The court has scheduled a jury trial on the remaining patent to commence on August 2, 2022. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. While we believe that we have strong non-infringement and invalidity arguments, and that Egenera’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation process. If we do not prevail in court, we believe at this time that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.
In addition, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.

- removed (2022-05-25):
[0000858877-22-000004:note_history:24]
On December 10, 2021, the District Court of Dusseldorf issued its findings on two of the patents, rejecting Centripetal’s patent complaints. Centripetal has appealed. On December 21, 2021, the District Court of Dusseldorf stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. The proceedings on Centripetal’s amended complaint remain pending.

- removed (2022-05-25):
[0000858877-22-000004:note_history:25]
Viasat     On January 21, 2016, Viasat, Inc. (“Viasat”) filed suit against Acacia (which we subsequently acquired) in the California Superior Court for San Diego County (“SDSC”) seeking unpaid royalties for breach of contract and the implied covenant of good faith and fair dealing, and damages for trade secret misappropriation for certain products (“Viasat 1”). Acacia counterclaimed for patent and trade secret misappropriation, contract, and unfair competition claims. On July 17, 2019, the jury found for Viasat on its contract claims, and awarded Viasat $49 million for unpaid royalties through 2018. The jury further found that Acacia willfully misappropriated Viasat’s trade secrets and awarded Viasat $1. On Acacia’s counterclaims, the jury found for Acacia on its contract and trade secret claims and awarded Acacia $1. Both Acacia and Viasat have pending appeals to the California Court of Appeal. On November 6, 2019, Viasat filed a second suit in SDSC, alleging contract and trade secret claims for Acacia products sold from January 1, 2019 forward (“Viasat 2”). On February 28, 2020, the court stayed Viasat 2 pending the appeal in Viasat 1. On June 9, 2020, Viasat filed a third suit in SDSC (“Viasat 3”). In Viasat 3, Viasat alleges contract and trade secrets claims for sales of additional Acacia products. On August 11, 2020, the court stayed Viasat 3 pending the appeal in Viasat 1.

- removed (2022-05-25):
[0000858877-22-000004:note_history:26]
In addition, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the 
ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-25):
[0000858877-22-000009:note_history:27]
We have prepared the accompanying financial data as of April 30, 2022 and for the third quarter and first nine months of fiscal 2022 and 2021, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 31, 2021 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021.
  (was, 2022-02-22, similarity 0.9861):
[0000858877-22-000004:note_history:27]
We have prepared the accompanying financial data as of January 29, 2022 and for the second quarter and first six months of fiscal 2022 and 2021, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 31, 2021 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021.

- added (2022-05-25):
[0000858877-22-000009:note_history:28]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic, including the associated impact of supply constraints, on our critical and significant accounting estimates. The actual results that we experience may differ materially from our estimates. As these events continue, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

- changed (2022-05-25):
[0000858877-22-000009:note_history:29]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of April 30, 2022, the results of operations, the statements of comprehensive income and the statements of equity for the third quarter and first nine months of fiscal 2022 and 2021, and the statements of cash flows for the first nine months of fiscal 2022 and 2021, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2022 are not necessarily indicative of the operating results for the full fiscal year or any future periods.
  (was, 2022-02-22, similarity 0.9565):
[0000858877-22-000004:note_history:29]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of January 29, 2022, the results of operations, the statements of comprehensive income and the statements of equity for the second quarter and first six months of fiscal 2022 and 2021, and the statements of cash flows for the first six months of fiscal 2022 and 2021, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2022 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2022-05-25):
[0000858877-22-000004:note_history:30]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-25):
[0000858877-22-000009:note_history:31]
|  | April 30, 2022 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,000 |  |  | 2.13 | % |  | $ | 2,508 |  |  | 1.75 | % |
  (was, 2022-02-22, similarity 0.7317):
[0000858877-22-000004:note_history:31]
|  | January 29, 2022 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 502 |  |  | 1.14 | % |  | $ | 2,508 |  |  | 1.75 | % |
| Commercial paper | 2,000 |  |  | 0.15 | % |  | — |  |  | — |  |
| Total short-term debt | $ | 2,502 |  |  |  |  | $ | 2,508 |  |  |  |

- changed (2022-05-25):
[0000858877-22-000009:note_history:32]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of April 30, 2022 and July 31, 2021.
  (was, 2022-02-22, similarity 0.8589):
[0000858877-22-000004:note_history:32]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

- changed (2022-05-25):
[0000858877-22-000009:note_history:33]
|  |  |  | April 30, 2022 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.59% |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.35% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.75% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,500 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (76) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (6) |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 9,418 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,000 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,418 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 9,418 |  |  |  |  | $ | 11,526 |  |  |  |
  (was, 2022-02-22, similarity 0.9929):
[0000858877-22-000004:note_history:33]
|  |  |  | January 29, 2022 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.14% |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.00% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.31% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,500 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (77) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 48 |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 9,471 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 502 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,969 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 9,471 |  |  |  |  | $ | 11,526 |  |  |  |

- changed (2022-05-25):
[0000858877-22-000009:note_history:34]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 30, 2022, we were in compliance with all debt covenants.
  (was, 2022-02-22, similarity 0.9863):
[0000858877-22-000004:note_history:34]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 29, 2022, we were in compliance with all debt covenants.

- changed (2022-05-25):
[0000858877-22-000009:note_history:35]
As of April 30, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2022-02-22, similarity 0.9701):
[0000858877-22-000004:note_history:35]
As of January 29, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2022-05-25):
[0000858877-22-000009:note_history:36]
| Fiscal Year | Amount |
| 2022 (remaining three months) | $ | 500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 9,500 |  |
  (was, 2022-02-22, similarity 0.9739):
[0000858877-22-000004:note_history:36]
| Fiscal Year | Amount |
| 2022 (remaining six months) | $ | 500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 9,500 |  |

- changed (2022-05-25):
[0000858877-22-000009:note_history:37]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of April 30, 2022, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.
  (was, 2022-02-22, similarity 0.7776):
[0000858877-22-000004:note_history:37]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. The credit agreement is structured as an amendment and restatement of our 364-day credit agreement, which would have terminated on May 14, 2021. As of January 29, 2022, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-05-25):
[0000858877-22-000009:note_history:38]
| April 30, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,346 |  |  | $ | — |  |  | $ | (46) |  |  | $ | 1,300 |  |
| U.S. government agency securities | 150 |  |  | — |  |  | (4) |  |  | 146 |  |
| Non-U.S. government and agency securities | 171 |  |  | — |  |  | — |  |  | 171 |  |
| Corporate debt securities | 8,770 |  |  | 5 |  |  | (296) |  |  | 8,479 |  |
| U.S. agency mortgage-backed securities | 2,234 |  |  | — |  |  | (176) |  |  | 2,058 |  |
| Commercial paper | 548 |  |  | — |  |  | — |  |  | 548 |  |
| Certificates of deposit | 212 |  |  | — |  |  | — |  |  | 212 |  |
| Total | $ | 13,431 |  |  | $ | 5 |  |  | $ | (522) |  |  | $ | 12,914 |  |

- added (2022-05-25):
[0000858877-22-000009:note_history:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2022 |  | May 1, 2021 |  | April 30, 2022 |  | May 1, 2021 |
| Gross realized gains | $ | 8 |  |  | $ | 24 |  |  | $ | 27 |  |  | $ | 48 |  |
| Gross realized losses | (6) |  |  | (2) |  |  | (9) |  |  | (2) |  |
| Total | $ | 2 |  |  | $ | 22 |  |  | $ | 18 |  |  | $ | 46 |  |

- changed (2022-05-25):
[0000858877-22-000009:note_history:40]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 30, 2022 and July 31, 2021 (in millions):
  (was, 2022-02-22, similarity 0.9716):
[0000858877-22-000004:note_history:40]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 29, 2022 and July 31, 2021 (in millions):

- changed (2022-05-25):
[0000858877-22-000009:note_history:41]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 30, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,185 |  |  | $ | (43) |  |  | $ | 96 |  |  | $ | (3) |  |  | $ | 1,281 |  |  | $ | (46) |  |
| U.S. government agency securities | 121 |  |  | (2) |  |  | 24 |  |  | (2) |  |  | 145 |  |  | (4) |  |
| Non-U.S. government and agency securities | 171 |  |  | — |  |  | — |  |  | — |  |  | 171 |  |  | — |  |
| Corporate debt securities | 6,185 |  |  | (225) |  |  | 367 |  |  | (35) |  |  | 6,552 |  |  | (260) |  |
| U.S. agency mortgage-backed securities | 1,505 |  |  | (118) |  |  | 547 |  |  | (58) |  |  | 2,052 |  |  | (176) |  |
| Total | $ | 9,167 |  |  | $ | (388) |  |  | $ | 1,034 |  |  | $ | (98) |  |  | $ | 10,201 |  |  | $ | (486) |  |
  (was, 2022-02-22, similarity 0.9265):
[0000858877-22-000004:note_history:41]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 29, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,124 |  |  | $ | (19) |  |  | $ | 2 |  |  | $ | — |  |  | $ | 1,126 |  |  | $ | (19) |  |
| U.S. government agency securities | 125 |  |  | (1) |  |  | 15 |  |  | (1) |  |  | 140 |  |  | (2) |  |
| Corporate debt securities | 4,230 |  |  | (69) |  |  | 182 |  |  | (8) |  |  | 4,412 |  |  | (77) |  |
| U.S. agency mortgage-backed securities | 1,881 |  |  | (52) |  |  | 91 |  |  | (4) |  |  | 1,972 |  |  | (56) |  |
| Total | $ | 7,360 |  |  | $ | (141) |  |  | $ | 290 |  |  | $ | (13) |  |  | $ | 7,650 |  |  | $ | (154) |  |

- changed (2022-05-25):
[0000858877-22-000009:note_history:42]
The following table summarizes the maturities of our available-for-sale debt investments as of April 30, 2022 (in millions):
  (was, 2022-02-22, similarity 0.9667):
[0000858877-22-000004:note_history:42]
The following table summarizes the maturities of our available-for-sale debt investments as of January 29, 2022 (in millions):

- added (2022-05-25):
[0000858877-22-000009:note_history:43]
We held marketable equity securities of $242 million and $137 million as of April 30, 2022 and July 31, 2021, respectively. We recognized a net unrealized loss of $19 million and $32 million during the third quarter and first nine months of fiscal 2022, respectively, and net unrealized gains of $3 million for each of the third quarter and first nine months of fiscal 2021, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $11 million and $28 million for the third quarter and first nine months of fiscal 2022, respectively. These adjustments were a net loss of $3 million and a net gain of $1 million for the corresponding periods of fiscal 2021, respectively. We held equity interests in certain private equity funds of $1.2 billion and $0.9 billion as of April 30, 2022 and July 31, 2021, respectively, which are accounted for under the NAV practical expedient.

- changed (2022-05-25):
[0000858877-22-000009:note_history:44]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest
  (was, 2022-02-22, similarity 0.6175):
[0000858877-22-000004:note_history:44]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 29, 2022, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- added (2022-05-25):
[0000858877-22-000009:note_history:45]
entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 30, 2022, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- changed (2022-05-25):
[0000858877-22-000009:note_history:46]
The carrying value of our investments in privately held companies was $1.9 billion and $1.5 billion as of April 30, 2022 and July 31, 2021, respectively. Of the total carrying value of our investments in privately held companies as of April 30, 2022, $1.2 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of April 30, 2022, we have total funding commitments of $0.4 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.
  (was, 2022-02-22, similarity 0.9629):
[0000858877-22-000004:note_history:46]
The carrying value of our investments in privately held companies was $1.8 billion and $1.5 billion as of January 29, 2022 and July 31, 2021, respectively. Of the total carrying value of our investments in privately held companies as of January 29, 2022, $1.1 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of January 29, 2022, we have total funding commitments of $0.4 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.

- removed (2022-05-25):
[0000858877-22-000004:note_history:47]
| January 29, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,702 |  |  | $ | 4 |  |  | $ | (19) |  |  | $ | 1,687 |  |
| U.S. government agency securities | 142 |  |  | — |  |  | (2) |  |  | 140 |  |
| Corporate debt securities | 9,008 |  |  | 82 |  |  | (102) |  |  | 8,988 |  |
| U.S. agency mortgage-backed securities | 2,569 |  |  | 10 |  |  | (56) |  |  | 2,523 |  |
| Commercial paper | 614 |  |  | — |  |  | — |  |  | 614 |  |
| Certificates of deposit | 209 |  |  | — |  |  | — |  |  | 209 |  |
| Total | $ | 14,244 |  |  | $ | 96 |  |  | $ | (179) |  |  | $ | 14,161 |  |

- removed (2022-05-25):
[0000858877-22-000004:note_history:48]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29, 2022 |  | January 23, 2021 |  | January 29, 2022 |  | January 23, 2021 |
| Gross realized gains | $ | 13 |  |  | $ | 9 |  |  | $ | 19 |  |  | $ | 24 |  |
| Gross realized losses | (3) |  |  | — |  |  | (3) |  |  | — |  |
| Total | $ | 10 |  |  | $ | 9 |  |  | $ | 16 |  |  | $ | 24 |  |

- removed (2022-05-25):
[0000858877-22-000004:note_history:49]
We recognized a net unrealized loss of $18 million and $13 million during the second quarter and first six months of fiscal 2022, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $14 million and $16 million for the second quarter and first six months of fiscal 2022, respectively. We held equity interests in certain private equity funds of $1.1 billion and $0.9 billion as of January 29, 2022 and July 31, 2021, respectively, which are accounted for under the NAV practical expedient.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-25):
[0000858877-22-000009:note_history:50]
|  |  |  | April 30, 2022 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.59% |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.35% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.75% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,500 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (76) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (6) |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 9,418 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,000 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,418 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 9,418 |  |  |  |  | $ | 11,526 |  |  |  |
  (was, 2022-02-22, similarity 0.9929):
[0000858877-22-000004:note_history:50]
|  |  |  | January 29, 2022 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.14% |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.00% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.31% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,500 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (77) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 48 |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 9,471 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 502 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,969 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 9,471 |  |  |  |  | $ | 11,526 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-25):
[0000858877-22-000009:note_history:51]
As of April 30, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2022-02-22, similarity 0.9701):
[0000858877-22-000004:note_history:51]
As of January 29, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2022-05-25):
[0000858877-22-000009:note_history:52]
| Fiscal Year | Amount |
| 2022 (remaining three months) | $ | 500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 9,500 |  |
  (was, 2022-02-22, similarity 0.9739):
[0000858877-22-000004:note_history:52]
| Fiscal Year | Amount |
| 2022 (remaining six months) | $ | 500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 9,500 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-25):
[0000858877-22-000009:note_history:53]
|  | April 30, 2022 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,000 |  |  | 2.13 | % |  | $ | 2,508 |  |  | 1.75 | % |
  (was, 2022-02-22, similarity 0.7317):
[0000858877-22-000004:note_history:53]
|  | January 29, 2022 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 502 |  |  | 1.14 | % |  | $ | 2,508 |  |  | 1.75 | % |
| Commercial paper | 2,000 |  |  | 0.15 | % |  | — |  |  | — |  |
| Total short-term debt | $ | 2,502 |  |  |  |  | $ | 2,508 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-25):
[0000858877-22-000009:note_history:54]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,869 |  |  | $ | 5,620 |  |  | $ | 17,735 |  |  | $ | 16,543 |  |
| Internet for the Future | 1,324 |  |  | 1,249 |  |  | 4,021 |  |  | 3,121 |  |
| Collaboration | 1,132 |  |  | 1,220 |  |  | 3,308 |  |  | 3,580 |  |
| End-to-End Security | 938 |  |  | 876 |  |  | 2,716 |  |  | 2,559 |  |
| Optimized Application Experiences | 183 |  |  | 170 |  |  | 544 |  |  | 483 |  |
| Other Products | 2 |  |  | 5 |  |  | 7 |  |  | 11 |  |
| Total Product | 9,448 |  |  | 9,139 |  |  | 28,330 |  |  | 26,298 |  |
| Services | 3,387 |  |  | 3,664 |  |  | 10,125 |  |  | 10,394 |  |
| Total | $ | 12,835 |  |  | $ | 12,803 |  |  | $ | 38,455 |  |  | $ | 36,692 |  |
  (was, 2022-02-22, similarity 0.6117):
[0000858877-22-000004:note_history:54]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,898 |  |  | $ | 5,489 |  |  | $ | 11,866 |  |  | $ | 10,923 |  |
| Hybrid Work | 1,067 |  |  | 1,167 |  |  | 2,176 |  |  | 2,360 |  |
| End-to-End Security | 883 |  |  | 822 |  |  | 1,778 |  |  | 1,684 |  |
| Internet for the Future | 1,322 |  |  | 931 |  |  | 2,697 |  |  | 1,872 |  |
| Optimized Application Experiences | 180 |  |  | 161 |  |  | 361 |  |  | 314 |  |
| Other Products | 2 |  |  | 3 |  |  | 5 |  |  | 6 |  |
| Total Product | 9,353 |  |  | 8,572 |  |  | 18,882 |  |  | 17,159 |  |
| Services | 3,367 |  |  | 3,388 |  |  | 6,738 |  |  | 6,730 |  |
| Total | $ | 12,720 |  |  | $ | 11,960 |  |  | $ | 25,620 |  |  | $ | 23,889 |  |

- changed (2022-05-25):
[0000858877-22-000009:note_history:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,869 |  |  | $ | 5,620 |  |  | $ | 17,735 |  |  | $ | 16,543 |  |
| Internet for the Future | 1,324 |  |  | 1,249 |  |  | 4,021 |  |  | 3,121 |  |
| Collaboration | 1,132 |  |  | 1,220 |  |  | 3,308 |  |  | 3,580 |  |
| End-to-End Security | 938 |  |  | 876 |  |  | 2,716 |  |  | 2,559 |  |
| Optimized Application Experiences | 183 |  |  | 170 |  |  | 544 |  |  | 483 |  |
| Other Products | 2 |  |  | 5 |  |  | 7 |  |  | 11 |  |
| Total Product | 9,448 |  |  | 9,139 |  |  | 28,330 |  |  | 26,298 |  |
| Services | 3,387 |  |  | 3,664 |  |  | 10,125 |  |  | 10,394 |  |
| Total | $ | 12,835 |  |  | $ | 12,803 |  |  | $ | 38,455 |  |  | $ | 36,692 |  |
  (was, 2022-02-22, similarity 0.6149):
[0000858877-22-000004:note_history:55]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,898 |  |  | $ | 5,489 |  |  | $ | 11,866 |  |  | $ | 10,923 |  |
| Hybrid Work | 1,067 |  |  | 1,167 |  |  | 2,176 |  |  | 2,360 |  |
| End-to-End Security | 883 |  |  | 822 |  |  | 1,778 |  |  | 1,684 |  |
| Internet for the Future | 1,322 |  |  | 931 |  |  | 2,697 |  |  | 1,872 |  |
| Optimized Application Experiences | 180 |  |  | 161 |  |  | 361 |  |  | 314 |  |
| Other Products | 2 |  |  | 3 |  |  | 5 |  |  | 6 |  |
| Total Product | 9,353 |  |  | 8,572 |  |  | 18,882 |  |  | 17,159 |  |
| Services | 3,367 |  |  | 3,388 |  |  | 6,738 |  |  | 6,730 |  |
| Total | $ | 12,720 |  |  | $ | 11,960 |  |  | $ | 25,620 |  |  | $ | 23,889 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-25):
[0000858877-22-000009:note_history:56]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 30, 2022 and July 31, 2021 was $42 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2022-02-22, similarity 0.9793):
[0000858877-22-000004:note_history:56]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 29, 2022 and July 31, 2021 was $46 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-25):
[0000858877-22-000009:note_history:57]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 30, 2022 and July 31, 2021 was $42 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2022-02-22, similarity 0.9793):
[0000858877-22-000004:note_history:57]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 29, 2022 and July 31, 2021 was $46 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2022-05-25):
[0000858877-22-000009:note_history:58]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. Effective fiscal 2022, we began reporting our product and service revenue in the following categories: Secure, Agile Networks; Internet for the Future; Collaboration; End-to-End Security; Optimized Application Experiences; Other Products; and Services. This change will better align our product categories with our strategic priorities. The following table presents this disaggregation of revenue (in millions):
  (was, 2022-02-22, similarity 0.9391):
[0000858877-22-000004:note_history:58]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. Effective in the first quarter of fiscal 2022, we began reporting our product and service revenue in the following categories: Secure, Agile Networks; Hybrid Work; End-to-End Security; Internet for the Future; Optimized Application Experiences; Other Products; and Services. This change will better align our product categories with our strategic priorities. The following table presents this disaggregation of revenue (in millions):

- changed (2022-05-25):
[0000858877-22-000009:note_history:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,869 |  |  | $ | 5,620 |  |  | $ | 17,735 |  |  | $ | 16,543 |  |
| Internet for the Future | 1,324 |  |  | 1,249 |  |  | 4,021 |  |  | 3,121 |  |
| Collaboration | 1,132 |  |  | 1,220 |  |  | 3,308 |  |  | 3,580 |  |
| End-to-End Security | 938 |  |  | 876 |  |  | 2,716 |  |  | 2,559 |  |
| Optimized Application Experiences | 183 |  |  | 170 |  |  | 544 |  |  | 483 |  |
| Other Products | 2 |  |  | 5 |  |  | 7 |  |  | 11 |  |
| Total Product | 9,448 |  |  | 9,139 |  |  | 28,330 |  |  | 26,298 |  |
| Services | 3,387 |  |  | 3,664 |  |  | 10,125 |  |  | 10,394 |  |
| Total | $ | 12,835 |  |  | $ | 12,803 |  |  | $ | 38,455 |  |  | $ | 36,692 |  |
  (was, 2022-02-22, similarity 0.611):
[0000858877-22-000004:note_history:59]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,898 |  |  | $ | 5,489 |  |  | $ | 11,866 |  |  | $ | 10,923 |  |
| Hybrid Work | 1,067 |  |  | 1,167 |  |  | 2,176 |  |  | 2,360 |  |
| End-to-End Security | 883 |  |  | 822 |  |  | 1,778 |  |  | 1,684 |  |
| Internet for the Future | 1,322 |  |  | 931 |  |  | 2,697 |  |  | 1,872 |  |
| Optimized Application Experiences | 180 |  |  | 161 |  |  | 361 |  |  | 314 |  |
| Other Products | 2 |  |  | 3 |  |  | 5 |  |  | 6 |  |
| Total Product | 9,353 |  |  | 8,572 |  |  | 18,882 |  |  | 17,159 |  |
| Services | 3,367 |  |  | 3,388 |  |  | 6,738 |  |  | 6,730 |  |
| Total | $ | 12,720 |  |  | $ | 11,960 |  |  | $ | 25,620 |  |  | $ | 23,889 |  |

- added (2022-05-25):
[0000858877-22-000009:note_history:60]
Collaboration consists of our Collaboration Devices, Meetings, Calling and contact center offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- changed (2022-05-25):
[0000858877-22-000009:note_history:61]
End-to-End Security consists of our overall security offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements
  (was, 2022-02-22, similarity 0.9123):
[0000858877-22-000004:note_history:61]
End-to-End Security consists of our overall security offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2022-05-25):
[0000858877-22-000009:note_history:62]
in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- changed (2022-05-25):
[0000858877-22-000009:note_history:63]
Accounts receivable, net was $5.8 billion as of each of April 30, 2022 and July 31, 2021, as reported on the Consolidated Balance Sheets.
  (was, 2022-02-22, similarity 0.8464):
[0000858877-22-000004:note_history:63]
Accounts receivable, net was $6.0 billion as of January 29, 2022 compared to $5.8 billion as of July 31, 2021, as reported on the Consolidated Balance Sheets.

- changed (2022-05-25):
[0000858877-22-000009:note_history:64]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2022 |  | May 1, 2021 |  | April 30, 2022 |  | May 1, 2021 |
| Allowance for credit loss at beginning of period | $ | 70 |  |  | $ | 102 |  |  | $ | 109 |  |  | $ | 143 |  |
| Provisions (benefits) | 17 |  |  | 16 |  |  | 53 |  |  | 15 |  |
| Recoveries (write-offs), net | (9) |  |  | (8) |  |  | (75) |  |  | (22) |  |
| Foreign exchange and other | — |  |  | — |  |  | (9) |  |  | (26) |  |
| Allowance for credit loss at end of period | $ | 78 |  |  | $ | 110 |  |  | $ | 78 |  |  | $ | 110 |  |
  (was, 2022-02-22, similarity 0.8731):
[0000858877-22-000004:note_history:64]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29, 2022 |  | January 23, 2021 |  | January 29, 2022 |  | January 23, 2021 |
| Allowance for credit loss at beginning of period | $ | 114 |  |  | $ | 125 |  |  | $ | 109 |  |  | $ | 143 |  |
| Provisions (benefits) | 17 |  |  | (15) |  |  | 36 |  |  | (1) |  |
| Recoveries (write-offs), net | (52) |  |  | (8) |  |  | (66) |  |  | (14) |  |
| Foreign exchange and other | (9) |  |  | — |  |  | (9) |  |  | (26) |  |
| Allowance for credit loss at end of period | $ | 70 |  |  | $ | 102 |  |  | $ | 70 |  |  | $ | 102 |  |

- changed (2022-05-25):
[0000858877-22-000009:note_history:65]
|  | April 30,2022 |  | July 31,2021 |
| 1 to 4 | $ | 422 |  |  | $ | 521 |  |
| 5 to 6 | 807 |  |  | 770 |  |
| 7 and Higher | 169 |  |  | 166 |  |
| Total | $ | 1,398 |  |  | $ | 1,457 |  |
  (was, 2022-02-22, similarity 0.9726):
[0000858877-22-000004:note_history:65]
|  | January 29,2022 |  | July 31,2021 |
| 1 to 4 | $ | 464 |  |  | $ | 521 |  |
| 5 to 6 | 825 |  |  | 770 |  |
| 7 and Higher | 164 |  |  | 166 |  |
| Total | $ | 1,453 |  |  | $ | 1,457 |  |

- changed (2022-05-25):
[0000858877-22-000009:note_history:66]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, was $1.3 billion and $1.4 billion as of April 30, 2022 and July 31, 2021, respectively, and were included in other current assets and other assets.
  (was, 2022-02-22, similarity 0.9203):
[0000858877-22-000004:note_history:66]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, was $1.4 billion as of both January 29, 2022 and July 31, 2021, and were included in other current assets and other assets.

- added (2022-05-25):
[0000858877-22-000009:note_history:67]
Contract liabilities consist of deferred revenue. Deferred revenue was $22.3 billion as of April 30, 2022 compared to $22.2 billion as of July 31, 2021. We recognized approximately $2.5 billion and $9.9 billion of revenue during the third quarter and first nine months of fiscal 2022, respectively, that was included in the deferred revenue balance at July 31, 2021. 
(c)Capitalized Contract Acquisition CostsWe capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $1.0 billion and $967 million as of April 30, 2022 and July 31, 2021, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $175 million and $492 million for the third quarter and first nine months of fiscal 2022, respectively, and $134 million and $386 million for the corresponding periods of fiscal 2021, respectively, and was included in sales and marketing expenses.

- removed (2022-05-25):
[0000858877-22-000004:note_history:68]
Hybrid Work consists of our collaboration offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2022-05-25):
[0000858877-22-000004:note_history:69]
Contract liabilities consist of deferred revenue. Deferred revenue was $22.3 billion as of January 29, 2022 compared to $22.2 billion as of July 31, 2021. We recognized approximately $3.3 billion and $7.4 billion of revenue during the second quarter and first six months of fiscal 2022, respectively, that was included in the deferred revenue balance at July 31, 2021.

- removed (2022-05-25):
[0000858877-22-000004:note_history:70]
(c)Capitalized Contract Acquisition Costs

- removed (2022-05-25):
[0000858877-22-000004:note_history:71]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $999 million and $967 million as of January 29, 2022 and July 31, 
2021, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $147 million and $317 million for the second quarter and first six months of fiscal 2022, respectively, and $129 million and $252 million for the corresponding periods of fiscal 2021, respectively, and was included in sales and marketing expenses.
