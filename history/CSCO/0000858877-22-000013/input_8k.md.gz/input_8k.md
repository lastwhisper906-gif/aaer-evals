# CSCO 8-K — 0001193125-22-223250 filed 2022-08-17

## item codes, every 8-K on or before 2022-09-08

- 2022-08-24 0001193125-22-228572 — 5.02
- 2022-08-17 0001193125-22-223250 — 2.02, 9.01
- 2022-06-17 0001193125-22-176552 — 8.01
- 2022-05-18 0001193125-22-154039 — 2.02, 9.01
- 2022-03-28 0001193125-22-086807 — 8.01
- 2022-02-16 0001193125-22-044372 — 2.02, 9.01
- 2022-02-11 0001193125-22-037227 — 5.02
- 2022-01-31 0001193125-22-023458 — 5.02
- 2021-12-17 0001193125-21-361182 — 8.01
- 2021-12-14 0001193125-21-356837 — 5.07, 8.01
- 2021-11-17 0001193125-21-332467 — 2.02, 9.01
- 2021-09-27 0001193125-21-284199 — 8.01
- 2021-08-18 0001193125-21-250360 — 2.02, 9.01
- 2021-06-29 0001193125-21-203324 — 8.01
- 2021-05-19 0001193125-21-166614 — 2.02, 9.01
- 2021-05-14 0001193125-21-162081 — 1.01, 2.03, 9.01
- 2021-03-08 0001193125-21-073328 — 5.02
- 2021-02-25 0001193125-21-056977 — 5.02
- 2021-02-09 0001193125-21-034339 — 2.02, 9.01
- 2021-01-07 0001193125-21-004250 — 5.02
- 2020-12-17 0001193125-20-320092 — 5.02, 8.01
- 2020-12-11 0001193125-20-315999 — 5.02, 5.07, 9.01
- 2020-11-30 0001193125-20-305352 — 5.02
- 2020-11-13 0001193125-20-293020 — 5.02, 9.01
- 2020-11-12 0001193125-20-291658 — 2.02, 9.01
- 2020-10-09 0001193125-20-267248 — 5.03, 9.01
- 2020-09-23 0001193125-20-252356 — 8.01
- 2020-08-12 0001193125-20-217756 — 5.02
- 2020-08-12 0001193125-20-217658 — 2.02, 2.05, 9.01
- 2020-06-22 0001193125-20-175641 — 8.01
- 2020-05-13 0001193125-20-141598 — 2.02, 9.01
- 2020-03-13 0001193125-20-072960 — 5.02
- 2020-03-06 0001193125-20-065138 — 5.02
- 2020-02-12 0001193125-20-033208 — 2.02, 9.01
- 2020-01-27 0001193125-20-015453 — 5.02
- 2019-12-23 0001193125-19-322662 — 8.01
- 2019-12-12 0001193125-19-312796 — 8.01
- 2019-12-11 0001193125-19-311525 — 5.07
- 2019-12-04 0001193125-19-306229 — 8.01
- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2022-09-08

- none on or before 2022-09-08

## item 2.02 — earnings release, exhibit 99.1

[0001193125-22-223250:8k_2_02:1]
EX-99.1
2
d391322dex991.htm
EX-99.1

[0001193125-22-223250:8k_2_02:2]
EX-99.1

[0001193125-22-223250:8k_2_02:3]
Exhibit 99.1

[0001193125-22-223250:8k_2_02:4]
| Press Contact: |  | Investor Relations Contact: |
| Robyn Blum |  | Marilyn Mora |
| Cisco |  | Cisco |
| 1 (408) 930-8548 |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  | marilmor@cisco.com |

[0001193125-22-223250:8k_2_02:5]
CISCO REPORTS FOURTH QUARTER AND FISCAL YEAR 2022 EARNINGS

[0001193125-22-223250:8k_2_02:6]
News Summary:

[0001193125-22-223250:8k_2_02:7]
|  | • |  | Cisco ended fiscal 2022 with Q4 revenue at $13.1 billion, flat year over year and fiscal year revenue of $51.6 billion, up 3% year over year |

[0001193125-22-223250:8k_2_02:8]
|  | • |  | Strong demand with record full year product orders and backlog |

[0001193125-22-223250:8k_2_02:9]
|  | • |  | Progress on business model transformation with total Annualized Recurring Revenue (ARR) at $22.9 billion in the fourth quarter of fiscal 2022, up 8% year over year |

[0001193125-22-223250:8k_2_02:10]
| • |  | Q4 FY 2022 Results: |

[0001193125-22-223250:8k_2_02:11]
|  | • |  | Revenue: $13.1 billion |

[0001193125-22-223250:8k_2_02:12]
|  | • |  | Flat year over year |

[0001193125-22-223250:8k_2_02:13]
|  | • |  | Earnings per Share: GAAP: $0.68; Non-GAAP: $0.83 |

[0001193125-22-223250:8k_2_02:14]
|  | • |  | GAAP EPS decreased (4)% year over year |

[0001193125-22-223250:8k_2_02:15]
|  | • |  | Non-GAAP EPS decreased (1)% year over year |

[0001193125-22-223250:8k_2_02:16]
| • |  | FY 2022 Results: |

[0001193125-22-223250:8k_2_02:17]
|  | • |  | Revenue: $51.6 billion |

[0001193125-22-223250:8k_2_02:18]
|  | • |  | Increase of 3% year over year |

[0001193125-22-223250:8k_2_02:19]
|  | • |  | Earnings per Share: GAAP: $2.82; Non-GAAP: $3.36 |

[0001193125-22-223250:8k_2_02:20]
|  | • |  | GAAP EPS increased 13% year over year |

[0001193125-22-223250:8k_2_02:21]
|  | • |  | Non-GAAP EPS increased 4% year over year |

[0001193125-22-223250:8k_2_02:22]
| • |  | Q1 FY 2023 Guidance: |

[0001193125-22-223250:8k_2_02:23]
|  | • |  | Revenue: 2% to 4% growth year over year |

[0001193125-22-223250:8k_2_02:24]
|  | • |  | Earnings per Share: GAAP: $0.64 to $0.68; Non-GAAP: $0.82 to $0.84 |

[0001193125-22-223250:8k_2_02:25]
| • |  | FY 2023 Guidance: |

[0001193125-22-223250:8k_2_02:26]
|  | • |  | Revenue: 4% to 6% growth year over year |

[0001193125-22-223250:8k_2_02:27]
|  | • |  | Earnings per Share: GAAP: $2.77 to $2.88; Non-GAAP: $3.49 to $3.56 |

[0001193125-22-223250:8k_2_02:28]
SAN JOSE, Calif. — August 17, 2022 — Cisco today reported fourth quarter and fiscal year results for the period ended
July 30, 2022. Cisco reported fourth quarter revenue of $13.1 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.8 billion or $0.68 per share, and non-GAAP net
income of $3.4 billion or $0.83 per share.

[0001193125-22-223250:8k_2_02:29]
“We had a strong end to our fiscal year thanks to our Q4 performance. Our teams executed well in the
midst of an incredibly dynamic environment, resulting in the highest full year non-GAAP earnings per share in the history of the company,” said Chuck Robbins, chair and CEO of Cisco. “Full year
product orders and backlog are both at record highs and reflect the strong demand we continue to see for our innovation and the overall value we bring to our customers as they accelerate their digital transformation.”

[0001193125-22-223250:8k_2_02:30]
“Total revenue exceeded our expectations in Q4, as a result of our strong execution and the numerous initiatives we have taken to reduce the impact of
the global supply situation,” said Scott Herren, CFO of Cisco. “Our operational discipline is reflected in our healthy operating margin and strong cash flow generation, enabling us to return nearly $4 billion to our shareholders in
Q4. And we continue to make good progress in our business model transformation with RPO of over $31 billion, which, coupled with our record backlog, provide us with substantial visibility and confidence in our future revenue.”

[0001193125-22-223250:8k_2_02:31]
1

[0001193125-22-223250:8k_2_02:32]
Q4 GAAP Results

[0001193125-22-223250:8k_2_02:33]
|  |  | Q4 FY 2022 |  |  | Q4 FY 2021 |  |  | Vs. Q4 FY 2021 |  |
| Revenue |  | $ | 13.1 billion |  |  | $ | 13.1 billion |  |  |  | — | % |
| Net Income |  | $ | 2.8 billion |  |  | $ | 3.0 billion |  |  |  | (6 | )% |
| Diluted Earnings per Share (EPS) |  | $ | 0.68 |  |  | $ | 0.71 |  |  |  | (4 | )% |

[0001193125-22-223250:8k_2_02:34]
Q4 Non-GAAP Results

[0001193125-22-223250:8k_2_02:35]
|  |  | Q4 FY 2022 |  |  | Q4 FY 2021 |  |  | Vs. Q4 FY 2021 |  |
| Net Income |  | $ | 3.4 billion |  |  | $ | 3.6 billion |  |  |  | (3 | )% |
| EPS |  | $ | 0.83 |  |  | $ | 0.84 |  |  |  | (1 | )% |

[0001193125-22-223250:8k_2_02:36]
Fiscal Year GAAP Results

[0001193125-22-223250:8k_2_02:37]
|  |  | FY 2022 |  |  | FY 2021 |  |  | Vs. FY 2021 |  |
| Revenue |  | $ | 51.6 billion |  |  | $ | 49.8 billion |  |  |  | 3 | % |
| Net Income |  | $ | 11.8 billion |  |  | $ | 10.6 billion |  |  |  | 12 | % |
| EPS |  | $ | 2.82 |  |  | $ | 2.50 |  |  |  | 13 | % |

[0001193125-22-223250:8k_2_02:38]
Fiscal Year Non-GAAP Results

[0001193125-22-223250:8k_2_02:39]
|  |  | FY 2022 |  |  | FY 2021 |  |  | Vs. FY 2021 |  |
| Net Income |  | $ | 14.1 billion |  |  | $ | 13.6 billion |  |  |  | 3 | % |
| EPS |  | $ | 3.36 |  |  | $ | 3.22 |  |  |  | 4 | % |

[0001193125-22-223250:8k_2_02:40]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-22-223250:8k_2_02:41]
2

[0001193125-22-223250:8k_2_02:42]
Financial Summary

[0001193125-22-223250:8k_2_02:43]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-22-223250:8k_2_02:44]
Q4 FY 2022 Highlights

[0001193125-22-223250:8k_2_02:45]
Revenue —
Total revenue was flat at $13.1 billion, with both product revenue and service revenue flat year over year. Revenue by geographic segment was: Americas down 3%, EMEA up 8%, and APJC down 2%. Product revenue performance was led by growth
in End-to-End Security up 20%, Optimized Application Experiences up 8%, and Collaboration up 2%. Secure, Agile Networks was down 1% and Internet for the Future was down
10%.

[0001193125-22-223250:8k_2_02:46]
Gross Margin — On a GAAP basis, total gross margin, product gross margin, and service gross margin were 61.3%, 59.1%, and
67.5%, respectively, as compared with 63.6%, 62.7%, and 66.2%, respectively, in the fourth quarter of fiscal 2021.

[0001193125-22-223250:8k_2_02:47]
On a
non-GAAP basis, total gross margin, product gross margin, and service gross margin were 63.3%, 61.3%, and 69.0%, respectively, as compared with 65.6%, 65.0%, and 67.4%, respectively, in the fourth quarter of
fiscal 2021.

[0001193125-22-223250:8k_2_02:48]
Total gross margins by geographic segment were: 62.6% for the Americas, 64.4% for EMEA and 63.6% for APJC.

[0001193125-22-223250:8k_2_02:49]
Operating Expenses — On a GAAP basis, operating expenses were $4.6 billion, down 4%, and were 35.0% of revenue. Non-GAAP operating expenses were $4.1 billion, down 4%, and were 30.9% of revenue.

[0001193125-22-223250:8k_2_02:50]
Operating Income
— GAAP operating income was $3.4 billion, down 4%, with GAAP operating margin of 26.2%. Non-GAAP operating income was $4.2 billion, down 4%, with
non-GAAP operating margin at 32.4%.

[0001193125-22-223250:8k_2_02:51]
Provision for Income Taxes — The GAAP tax provision rate
was 17.6%. The non-GAAP tax provision rate was 18.5%.

[0001193125-22-223250:8k_2_02:52]
Net Income and EPS — On a GAAP basis,
net income was $2.8 billion, a decrease of 6%, and EPS was $0.68, a decrease of 4%. On a non-GAAP basis, net income was $3.4 billion, a decrease of 3%, and EPS was $0.83, a decrease of 1%.

[0001193125-22-223250:8k_2_02:53]
Cash Flow from Operating Activities — $3.7 billion for the fourth quarter of fiscal 2022, a decrease of 18% compared with
$4.5 billion for the fourth quarter of fiscal 2021.

[0001193125-22-223250:8k_2_02:54]
FY 2022 Highlights

[0001193125-22-223250:8k_2_02:55]
Revenue — Total revenue was $51.6 billion, an increase of 3%.

[0001193125-22-223250:8k_2_02:56]
Net Income and EPS — On a GAAP basis, net income was $11.8 billion, an increase of 12%, and EPS was $2.82, an increase of 13%. On a non-GAAP basis, net income was $14.1 billion, an increase of 3% compared to fiscal 2021, and EPS was $3.36, an increase of 4%.

[0001193125-22-223250:8k_2_02:57]
Cash Flow from Operating Activities — $13.2 billion for fiscal 2022, a decrease of 14% compared with fiscal 2021.

[0001193125-22-223250:8k_2_02:58]
Balance Sheet and Other Financial Highlights

[0001193125-22-223250:8k_2_02:59]
Cash and Cash Equivalents and Investments — $19.3 billion at the end of the fourth quarter of fiscal 2022, compared with
$20.1 billion at the end of the third quarter of fiscal 2022, and compared with $24.5 billion at the end of fiscal 2021.

[0001193125-22-223250:8k_2_02:60]
Remaining
Performance Obligations (RPO) — $31.5 billion, up 2% in total, with 54% of this amount to be recognized as revenue over the next 12 months. Product RPO were up 6% and service RPO were down 1%.

[0001193125-22-223250:8k_2_02:61]
Deferred Revenue — $23.3 billion, up 5% in total, with deferred product revenue up 11%. Deferred service revenue was up 1%.

[0001193125-22-223250:8k_2_02:62]
Capital Allocation — In the fourth quarter of fiscal 2022, we returned $4.0 billion to stockholders through share buybacks and
dividends. We declared and paid a cash dividend of $0.38 per common share, or $1.6 billion, and repurchased approximately 54 million shares of common stock under our stock repurchase program at an average price of $44.02 per share for an
aggregate purchase price of $2.4 billion. The remaining authorized amount for stock repurchases under the program is $15.2 billion with no termination date.

[0001193125-22-223250:8k_2_02:63]
3

[0001193125-22-223250:8k_2_02:64]
Guidance

[0001193125-22-223250:8k_2_02:65]
Cisco expects to achieve the following results for the first quarter of fiscal 2023:

[0001193125-22-223250:8k_2_02:66]
| Q1 FY 2023 |  |  |
| Revenue |  | 2% - 4% growth Y/Y |
| Non-GAAP gross margin rate |  | 63% - 64% |
| Non-GAAP operating margin rate |  | 31.5% - 32.5% |
| Non-GAAP EPS |  | $0.82 - $0.84 |

[0001193125-22-223250:8k_2_02:67]
Cisco estimates that GAAP EPS will be $0.64 to $0.68 for the first quarter of fiscal 2023.

[0001193125-22-223250:8k_2_02:68]
Cisco expects to achieve the following results for fiscal 2023:

[0001193125-22-223250:8k_2_02:69]
| FY 2023 |  |  |
| Revenue |  | 4% - 6% growth Y/Y |
| Non-GAAP EPS |  | $3.49 - $3.56 |

[0001193125-22-223250:8k_2_02:70]
Cisco estimates that GAAP EPS will be $2.77 to $2.88 for fiscal 2023.

[0001193125-22-223250:8k_2_02:71]
Our Q1 FY 2023 and FY 2023 guidance assumes an effective tax provision rate of 19% for GAAP and non-GAAP results.

[0001193125-22-223250:8k_2_02:72]
A reconciliation between the Guidance on a GAAP and non-GAAP basis is provided in the tables entitled “GAAP to non-GAAP Guidance” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-22-223250:8k_2_02:73]
Editor’s Notes:

[0001193125-22-223250:8k_2_02:74]
|  | • |  | Q4 fiscal year 2022 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, August 17, 2022 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-22-223250:8k_2_02:75]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, August 17, 2022 to 4:00 p.m. Pacific Time, August 24, 2022 at 1-866-517-3736 (United States) or 1-203-369-2047 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-22-223250:8k_2_02:76]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, August 17, 2022. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-22-223250:8k_2_02:77]
4

[0001193125-22-223250:8k_2_02:78]
CISCO SYSTEMS, INC.

[0001193125-22-223250:8k_2_02:79]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-22-223250:8k_2_02:80]
(In millions, except per-share amounts)

[0001193125-22-223250:8k_2_02:81]
(Unaudited)

[0001193125-22-223250:8k_2_02:82]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 30,2022 |  |  | July 31,2021 |  |  | July 30,2022 |  |  | July 31,2021 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,688 |  |  | $ | 9,716 |  |  | $ | 38,018 |  |  | $ | 36,014 |  |
| Service |  |  | 3,414 |  |  |  | 3,410 |  |  |  | 13,539 |  |  |  | 13,804 |  |
| Total revenue |  |  | 13,102 |  |  |  | 13,126 |  |  |  | 51,557 |  |  |  | 49,818 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,966 |  |  |  | 3,628 |  |  |  | 14,814 |  |  |  | 13,300 |  |
| Service |  |  | 1,111 |  |  |  | 1,154 |  |  |  | 4,495 |  |  |  | 4,624 |  |
| Total cost of sales |  |  | 5,077 |  |  |  | 4,782 |  |  |  | 19,309 |  |  |  | 17,924 |  |
| GROSS MARGIN |  |  | 8,025 |  |  |  | 8,344 |  |  |  | 32,248 |  |  |  | 31,894 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,682 |  |  |  | 1,713 |  |  |  | 6,774 |  |  |  | 6,549 |  |
| Sales and marketing |  |  | 2,349 |  |  |  | 2,448 |  |  |  | 9,085 |  |  |  | 9,259 |  |
| General and administrative |  |  | 489 |  |  |  | 521 |  |  |  | 2,101 |  |  |  | 2,152 |  |
| Amortization of purchased intangible assets |  |  | 73 |  |  |  | 79 |  |  |  | 313 |  |  |  | 215 |  |
| Restructuring and other charges |  |  | (2 | ) |  |  | 8 |  |  |  | 6 |  |  |  | 886 |  |
| Total operating expenses |  |  | 4,591 |  |  |  | 4,769 |  |  |  | 18,279 |  |  |  | 19,061 |  |
| OPERATING INCOME |  |  | 3,434 |  |  |  | 3,575 |  |  |  | 13,969 |  |  |  | 12,833 |  |
| Interest income |  |  | 129 |  |  |  | 130 |  |  |  | 476 |  |  |  | 618 |  |
| Interest expense |  |  | (93 | ) |  |  | (98 | ) |  |  | (360 | ) |  |  | (434 | ) |
| Other income (loss), net |  |  | (54 | ) |  |  | 128 |  |  |  | 392 |  |  |  | 245 |  |
| Interest and other income (loss), net |  |  | (18 | ) |  |  | 160 |  |  |  | 508 |  |  |  | 429 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,416 |  |  |  | 3,735 |  |  |  | 14,477 |  |  |  | 13,262 |  |
| Provision for income taxes |  |  | 601 |  |  |  | 726 |  |  |  | 2,665 |  |  |  | 2,671 |  |
| NET INCOME |  | $ | 2,815 |  |  | $ | 3,009 |  |  | $ | 11,812 |  |  | $ | 10,591 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.68 |  |  | $ | 0.71 |  |  | $ | 2.83 |  |  | $ | 2.51 |  |
| Diluted |  | $ | 0.68 |  |  | $ | 0.71 |  |  | $ | 2.82 |  |  | $ | 2.50 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,128 |  |  |  | 4,216 |  |  |  | 4,170 |  |  |  | 4,222 |  |
| Diluted |  |  | 4,137 |  |  |  | 4,238 |  |  |  | 4,192 |  |  |  | 4,236 |  |

[0001193125-22-223250:8k_2_02:83]
5

[0001193125-22-223250:8k_2_02:84]
CISCO SYSTEMS, INC.

[0001193125-22-223250:8k_2_02:85]
REVENUE BY SEGMENT

[0001193125-22-223250:8k_2_02:86]
(In
millions, except percentages)

[0001193125-22-223250:8k_2_02:87]
|  |  | July 30, 2022 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,470 |  |  |  | (3 | )% |  | $ | 29,814 |  |  |  | 2 | % |
| EMEA |  |  | 3,577 |  |  |  | 8 | % |  |  | 13,715 |  |  |  | 6 | % |
| APJC |  |  | 2,055 |  |  |  | (2 | )% |  |  | 8,027 |  |  |  | 4 | % |
| Total |  | $ | 13,102 |  |  |  | — | % |  | $ | 51,557 |  |  |  | 3 | % |

[0001193125-22-223250:8k_2_02:88]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-22-223250:8k_2_02:89]
CISCO SYSTEMS, INC.

[0001193125-22-223250:8k_2_02:90]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-22-223250:8k_2_02:91]
(In percentages)

[0001193125-22-223250:8k_2_02:92]
|  |  | July 30, 2022 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 62.6% |  |  |  | 64.1% |  |
| EMEA |  |  | 64.4% |  |  |  | 65.4% |  |
| APJC |  |  | 63.6% |  |  |  | 65.3% |  |

[0001193125-22-223250:8k_2_02:93]
CISCO SYSTEMS, INC.

[0001193125-22-223250:8k_2_02:94]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-22-223250:8k_2_02:95]
(In millions, except percentages)

[0001193125-22-223250:8k_2_02:96]
|  |  | July 30, 2022 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Secure, Agile Networks |  | $ | 6,094 |  |  |  | (1 | )% |  | $ | 23,829 |  |  |  | 5 | % |
| Internet for the Future |  |  | 1,257 |  |  |  | (10 | )% |  |  | 5,278 |  |  |  | 17 | % |
| Collaboration |  |  | 1,164 |  |  |  | 2 | % |  |  | 4,472 |  |  |  | (5 | )% |
| End-to-End Security |  |  | 984 |  |  |  | 20 | % |  |  | 3,699 |  |  |  | 9 | % |
| Optimized Application Experiences |  |  | 185 |  |  |  | 8 | % |  |  | 729 |  |  |  | 11 | % |
| Other Products |  |  | 3 |  |  |  | (22 | )% |  |  | 11 |  |  |  | (29 | )% |
| Total Product |  |  | 9,688 |  |  |  | — | % |  |  | 38,018 |  |  |  | 6 | % |
| Services |  |  | 3,414 |  |  |  | — | % |  |  | 13,539 |  |  |  | (2 | )% |
| Total |  | $ | 13,102 |  |  |  | — | % |  | $ | 51,557 |  |  |  | 3 | % |

[0001193125-22-223250:8k_2_02:97]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-22-223250:8k_2_02:98]
6

[0001193125-22-223250:8k_2_02:99]
CISCO SYSTEMS, INC.

[0001193125-22-223250:8k_2_02:100]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-22-223250:8k_2_02:101]
(In millions)

[0001193125-22-223250:8k_2_02:102]
(Unaudited)

[0001193125-22-223250:8k_2_02:103]
|  |  | July 30,2022 |  |  | July 31,2021 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 7,079 |  |  | $ | 9,175 |  |
| Investments |  |  | 12,188 |  |  |  | 15,343 |  |
| Accounts receivable, net of allowance of $83 at July 30, 2022 and $109 at July 31, 2021 |  |  | 6,622 |  |  |  | 5,766 |  |
| Inventories |  |  | 2,568 |  |  |  | 1,559 |  |
| Financing receivables, net |  |  | 3,905 |  |  |  | 4,380 |  |
| Other current assets |  |  | 4,355 |  |  |  | 2,889 |  |
| Total current assets |  |  | 36,717 |  |  |  | 39,112 |  |
| Property and equipment, net |  |  | 1,997 |  |  |  | 2,338 |  |
| Financing receivables, net |  |  | 4,009 |  |  |  | 4,884 |  |
| Goodwill |  |  | 38,304 |  |  |  | 38,168 |  |
| Purchased intangible assets, net |  |  | 2,569 |  |  |  | 3,619 |  |
| Deferred tax assets |  |  | 4,449 |  |  |  | 4,360 |  |
| Other assets |  |  | 5,957 |  |  |  | 5,016 |  |
| TOTAL ASSETS |  | $ | 94,002 |  |  | $ | 97,497 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 1,099 |  |  | $ | 2,508 |  |
| Accounts payable |  |  | 2,281 |  |  |  | 2,362 |  |
| Income taxes payable |  |  | 961 |  |  |  | 801 |  |
| Accrued compensation |  |  | 3,316 |  |  |  | 3,818 |  |
| Deferred revenue |  |  | 12,784 |  |  |  | 12,148 |  |
| Other current liabilities |  |  | 5,199 |  |  |  | 4,620 |  |
| Total current liabilities |  |  | 25,640 |  |  |  | 26,257 |  |
| Long-term debt |  |  | 8,416 |  |  |  | 9,018 |  |
| Income taxes payable |  |  | 7,725 |  |  |  | 8,538 |  |
| Deferred revenue |  |  | 10,480 |  |  |  | 10,016 |  |
| Other long-term liabilities |  |  | 1,968 |  |  |  | 2,393 |  |
| Total liabilities |  |  | 54,229 |  |  |  | 56,222 |  |
| Total equity |  |  | 39,773 |  |  |  | 41,275 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 94,002 |  |  | $ | 97,497 |  |

[0001193125-22-223250:8k_2_02:104]
7

[0001193125-22-223250:8k_2_02:105]
CISCO SYSTEMS, INC.

[0001193125-22-223250:8k_2_02:106]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-22-223250:8k_2_02:107]
(In millions)

[0001193125-22-223250:8k_2_02:108]
(Unaudited)

[0001193125-22-223250:8k_2_02:109]
|  |  | Fiscal Year Ended |  |
|  |  | July 30,2022 |  |  | July 31,2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 11,812 |  |  | $ | 10,591 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,957 |  |  |  | 1,862 |  |
| Share-based compensation expense |  |  | 1,886 |  |  |  | 1,761 |  |
| Provision (benefit) for receivables |  |  | 55 |  |  |  | (6 | ) |
| Deferred income taxes |  |  | (309 | ) |  |  | (384 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (453 | ) |  |  | (354 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (1,009 | ) |  |  | (107 | ) |
| Inventories |  |  | (1,030 | ) |  |  | (244 | ) |
| Financing receivables |  |  | 1,241 |  |  |  | 1,577 |  |
| Other assets |  |  | (1,615 | ) |  |  | (797 | ) |
| Accounts payable |  |  | (55 | ) |  |  | (53 | ) |
| Income taxes, net |  |  | (690 | ) |  |  | (549 | ) |
| Accrued compensation |  |  | (427 | ) |  |  | 643 |  |
| Deferred revenue |  |  | 1,328 |  |  |  | 1,560 |  |
| Other liabilities |  |  | 535 |  |  |  | (46 | ) |
| Net cash provided by operating activities |  |  | 13,226 |  |  |  | 15,454 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (6,070 | ) |  |  | (9,328 | ) |
| Proceeds from sales of investments |  |  | 2,660 |  |  |  | 3,373 |  |
| Proceeds from maturities of investments |  |  | 5,686 |  |  |  | 8,409 |  |
| Acquisitions, net of cash and cash equivalents acquired and divestitures |  |  | (373 | ) |  |  | (7,038 | ) |
| Purchases of investments in privately held companies |  |  | (186 | ) |  |  | (175 | ) |
| Return of investments in privately held companies |  |  | 237 |  |  |  | 194 |  |
| Acquisition of property and equipment |  |  | (477 | ) |  |  | (692 | ) |
| Proceeds from sales of property and equipment |  |  | 91 |  |  |  | 28 |  |
| Other |  |  | (15 | ) |  |  | (56 | ) |
| Net cash provided by (used in) investing activities |  |  | 1,553 |  |  |  | (5,285 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 660 |  |  |  | 643 |  |
| Repurchases of common stock - repurchase program |  |  | (7,689 | ) |  |  | (2,877 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (692 | ) |  |  | (636 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | 606 |  |  |  | (5 | ) |
| Issuances of debt |  |  | 1,049 |  |  |  | — |  |
| Repayments of debt |  |  | (3,550 | ) |  |  | (3,000 | ) |
| Dividends paid |  |  | (6,224 | ) |  |  | (6,163 | ) |
| Other |  |  | (302 | ) |  |  | (1 | ) |
| Net cash used in financing activities |  |  | (16,142 | ) |  |  | (12,039 | ) |
| Net decrease in cash, cash equivalents, restricted cash and restricted cash equivalents |  |  | (1,363 | ) |  |  | (1,870 | ) |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, beginning of fiscal year |  |  | 9,942 |  |  |  | 11,812 |  |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, end of fiscal year |  | $ | 8,579 |  |  | $ | 9,942 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 355 |  |  | $ | 438 |  |
| Cash paid for income taxes, net |  | $ | 3,663 |  |  | $ | 3,604 |  |

[0001193125-22-223250:8k_2_02:110]
8

[0001193125-22-223250:8k_2_02:111]
CISCO SYSTEMS, INC.

[0001193125-22-223250:8k_2_02:112]
REMAINING PERFORMANCE OBLIGATIONS

[0001193125-22-223250:8k_2_02:113]
(In millions, except percentages)

[0001193125-22-223250:8k_2_02:114]
|  |  | July 30, 2022 |  |  | April 30, 2022 |  |  | July 31, 2021 |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Product |  | $ | 14,090 |  |  |  | 6 | % |  | $ | 13,416 |  |  |  | 13 | % |  | $ | 13,270 |  |  |  | 18 | % |
| Service |  |  | 17,449 |  |  |  | (1 | )% |  |  | 16,789 |  |  |  | 3 | % |  |  | 17,623 |  |  |  | 3 | % |
| Total |  | $ | 31,539 |  |  |  | 2 | % |  | $ | 30,205 |  |  |  | 7 | % |  | $ | 30,893 |  |  |  | 9 | % |

[0001193125-22-223250:8k_2_02:115]
We expect 54% of total RPO at July 30, 2022 will be recognized as revenue over the next 12 months.

[0001193125-22-223250:8k_2_02:116]
CISCO SYSTEMS, INC.

[0001193125-22-223250:8k_2_02:117]
DEFERRED REVENUE

[0001193125-22-223250:8k_2_02:118]
(In
millions)

[0001193125-22-223250:8k_2_02:119]
|  |  | July 30,2022 |  |  | April 30,2022 |  |  | July 31,2021 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 10,427 |  |  | $ | 9,835 |  |  | $ | 9,416 |  |
| Service |  |  | 12,837 |  |  |  | 12,458 |  |  |  | 12,748 |  |
| Total |  | $ | 23,264 |  |  | $ | 22,293 |  |  | $ | 22,164 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 12,784 |  |  | $ | 12,249 |  |  | $ | 12,148 |  |
| Noncurrent |  |  | 10,480 |  |  |  | 10,044 |  |  |  | 10,016 |  |
| Total |  | $ | 23,264 |  |  | $ | 22,293 |  |  | $ | 22,164 |  |

[0001193125-22-223250:8k_2_02:120]
CISCO SYSTEMS, INC.

[0001193125-22-223250:8k_2_02:121]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-22-223250:8k_2_02:122]
(In millions, except per-share amounts)

[0001193125-22-223250:8k_2_02:123]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 30, 2022 |  | $ | 0.38 |  |  | $ | 1,567 |  |  |  | 54 |  |  | $ | 44.02 |  |  | $ | 2,402 |  |  | $ | 3,969 |  |
| April 30, 2022 |  | $ | 0.38 |  |  | $ | 1,555 |  |  |  | 5 |  |  | $ | 54.20 |  |  | $ | 252 |  |  | $ | 1,807 |  |
| January 29, 2022 |  | $ | 0.37 |  |  | $ | 1,541 |  |  |  | 82 |  |  | $ | 58.36 |  |  | $ | 4,824 |  |  | $ | 6,365 |  |
| October 30, 2021 |  | $ | 0.37 |  |  | $ | 1,561 |  |  |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |  | $ | 1,817 |  |
| Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 31, 2021 |  | $ | 0.37 |  |  | $ | 1,562 |  |  |  | 15 |  |  | $ | 53.30 |  |  | $ | 791 |  |  | $ | 2,353 |  |
| May 1, 2021 |  | $ | 0.37 |  |  | $ | 1,560 |  |  |  | 10 |  |  | $ | 48.71 |  |  | $ | 510 |  |  | $ | 2,070 |  |
| January 23, 2021 |  | $ | 0.36 |  |  | $ | 1,521 |  |  |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |  | $ | 2,322 |  |
| October 24, 2020 |  | $ | 0.36 |  |  | $ | 1,520 |  |  |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |  | $ | 2,320 |  |

[0001193125-22-223250:8k_2_02:124]
9

[0001193125-22-223250:8k_2_02:125]
CISCO SYSTEMS, INC.

[0001193125-22-223250:8k_2_02:126]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-22-223250:8k_2_02:127]
GAAP TO NON-GAAP NET INCOME

[0001193125-22-223250:8k_2_02:128]
(In millions)

[0001193125-22-223250:8k_2_02:129]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 30,2022 |  |  | July 31,2021 |  |  | July 30,2022 |  |  | July 31,2021 |  |
| GAAP net income |  | $ | 2,815 |  |  | $ | 3,009 |  |  | $ | 11,812 |  |  | $ | 10,591 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 78 |  |  |  | 67 |  |  |  | 311 |  |  |  | 275 |  |
| Amortization of acquisition-related intangible assets |  |  | 162 |  |  |  | 199 |  |  |  | 733 |  |  |  | 698 |  |
| Acquisition-related/divestiture costs |  |  | 24 |  |  |  | 1 |  |  |  | 27 |  |  |  | 4 |  |
| Russia-Ukraine war costs |  |  | 2 |  |  |  | — |  |  |  | 7 |  |  |  | — |  |
| Legal and indemnification settlements/charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 43 |  |
| Total adjustments to GAAP cost of sales |  |  | 266 |  |  |  | 267 |  |  |  | 1,078 |  |  |  | 1,020 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 401 |  |  |  | 357 |  |  |  | 1,574 |  |  |  | 1,460 |  |
| Amortization of acquisition-related intangible assets |  |  | 73 |  |  |  | 79 |  |  |  | 328 |  |  |  | 215 |  |
| Acquisition-related/divestiture costs |  |  | 45 |  |  |  | 109 |  |  |  | 306 |  |  |  | 288 |  |
| Russia-Ukraine war costs |  |  | 22 |  |  |  | — |  |  |  | 84 |  |  |  | — |  |
| Significant asset impairments and restructurings |  |  | (2 | ) |  |  | 8 |  |  |  | 6 |  |  |  | 886 |  |
| Total adjustments to GAAP operating expenses |  |  | 539 |  |  |  | 553 |  |  |  | 2,298 |  |  |  | 2,849 |  |
| Adjustments to interest and other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 4 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | (154 | ) |  |  | (478 | ) |  |  | (285 | ) |
| Total adjustments to GAAP interest and other income (loss), net |  |  | — |  |  |  | (154 | ) |  |  | (478 | ) |  |  | (281 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 805 |  |  |  | 666 |  |  |  | 2,898 |  |  |  | 3,588 |  |
| Income tax effect of non-GAAP adjustments |  |  | (181 | ) |  |  | (199 | ) |  |  | (616 | ) |  |  | (702 | ) |
| Significant tax matters |  |  | — |  |  |  | 76 |  |  |  | — |  |  |  | 159 |  |
| Total adjustments to GAAP provision for income taxes |  |  | (181 | ) |  |  | (123 | ) |  |  | (616 | ) |  |  | (543 | ) |
| Non-GAAP net income |  | $ | 3,439 |  |  | $ | 3,552 |  |  | $ | 14,094 |  |  | $ | 13,636 |  |

[0001193125-22-223250:8k_2_02:130]
10

[0001193125-22-223250:8k_2_02:131]
CISCO SYSTEMS, INC.

[0001193125-22-223250:8k_2_02:132]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-22-223250:8k_2_02:133]
GAAP TO NON-GAAP EPS

[0001193125-22-223250:8k_2_02:134]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 30,2022 |  |  | July 31,2021 |  |  | July 30,2022 |  |  | July 31,2021 |  |
| GAAP EPS |  | $ | 0.68 |  |  | $ | 0.71 |  |  | $ | 2.82 |  |  | $ | 2.50 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.12 |  |  |  | 0.10 |  |  |  | 0.45 |  |  |  | 0.41 |  |
| Amortization of acquisition-related intangible assets |  |  | 0.06 |  |  |  | 0.07 |  |  |  | 0.25 |  |  |  | 0.22 |  |
| Acquisition-related/divestiture costs |  |  | 0.02 |  |  |  | 0.03 |  |  |  | 0.08 |  |  |  | 0.07 |  |
| Russia-Ukraine war costs |  |  | 0.01 |  |  |  | — |  |  |  | 0.02 |  |  |  | — |  |
| Legal and indemnification settlements/charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.01 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.21 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | (0.04 | ) |  |  | (0.11 | ) |  |  | (0.07 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.04 | ) |  |  | (0.05 | ) |  |  | (0.15 | ) |  |  | (0.17 | ) |
| Significant tax matters |  |  | — |  |  |  | 0.02 |  |  |  | — |  |  |  | 0.04 |  |
| Non-GAAP EPS |  | $ | 0.83 |  |  | $ | 0.84 |  |  | $ | 3.36 |  |  | $ | 3.22 |  |

[0001193125-22-223250:8k_2_02:135]
Amounts may not sum due to rounding.

[0001193125-22-223250:8k_2_02:136]
11

[0001193125-22-223250:8k_2_02:137]
CISCO SYSTEMS, INC.

[0001193125-22-223250:8k_2_02:138]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-22-223250:8k_2_02:139]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET,

[0001193125-22-223250:8k_2_02:140]
AND NET INCOME

[0001193125-22-223250:8k_2_02:141]
(In
millions, except percentages)

[0001193125-22-223250:8k_2_02:142]
|  |  | Three Months Ended |  |
|  |  | July 30, 2022 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,722 |  |  | $ | 2,303 |  |  | $ | 8,025 |  |  | $ | 4,591 |  |  |  | (4 | )% |  | $ | 3,434 |  |  |  | (4 | )% |  | $ | (18 | ) |  | $ | 2,815 |  |  |  | (6 | )% |
| % of revenue |  |  | 59.1 | % |  |  | 67.5 | % |  |  | 61.3 | % |  |  | 35.0 | % |  |  |  |  |  |  | 26.2 | % |  |  |  |  |  |  | (0.1 | )% |  |  | 21.5 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 28 |  |  |  | 50 |  |  |  | 78 |  |  |  | 401 |  |  |  |  |  |  |  | 479 |  |  |  |  |  |  |  | — |  |  |  | 479 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 162 |  |  |  | — |  |  |  | 162 |  |  |  | 73 |  |  |  |  |  |  |  | 235 |  |  |  |  |  |  |  | — |  |  |  | 235 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 24 |  |  |  | — |  |  |  | 24 |  |  |  | 45 |  |  |  |  |  |  |  | 69 |  |  |  |  |  |  |  | — |  |  |  | 69 |  |  |  |  |  |
| Russia-Ukraine war costs |  |  | — |  |  |  | 2 |  |  |  | 2 |  |  |  | 22 |  |  |  |  |  |  |  | 24 |  |  |  |  |  |  |  | — |  |  |  | 24 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  |  |  |  |  | (2 | ) |  |  |  |  |  |  | — |  |  |  | (2 | ) |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (181 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 5,936 |  |  | $ | 2,355 |  |  | $ | 8,291 |  |  | $ | 4,052 |  |  |  | (4 | )% |  | $ | 4,239 |  |  |  | (4 | )% |  | $ | (18 | ) |  | $ | 3,439 |  |  |  | (3 | )% |
| % of revenue |  |  | 61.3 | % |  |  | 69.0 | % |  |  | 63.3 | % |  |  | 30.9 | % |  |  |  |  |  |  | 32.4 | % |  |  |  |  |  |  | (0.1 | )% |  |  | 26.2 | % |  |  |  |  |

[0001193125-22-223250:8k_2_02:143]
|  |  | Three Months Ended |  |
|  |  | July 31, 2021 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 6,088 |  |  | $ | 2,256 |  |  | $ | 8,344 |  |  | $ | 4,769 |  |  | $ | 3,575 |  |  | $ | 160 |  |  | $ | 3,009 |  |
| % of revenue |  |  | 62.7 | % |  |  | 66.2 | % |  |  | 63.6 | % |  |  | 36.3 | % |  |  | 27.2 | % |  |  | 1.2 | % |  |  | 22.9 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 24 |  |  |  | 43 |  |  |  | 67 |  |  |  | 357 |  |  |  | 424 |  |  |  | — |  |  |  | 424 |  |
| Amortization of acquisition-related intangible assets |  |  | 199 |  |  |  | — |  |  |  | 199 |  |  |  | 79 |  |  |  | 278 |  |  |  | — |  |  |  | 278 |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 109 |  |  |  | 110 |  |  |  | — |  |  |  | 110 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 8 |  |  |  | 8 |  |  |  | — |  |  |  | 8 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (154 | ) |  |  | (154 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (123 | ) |
| Non-GAAP amount |  | $ | 6,312 |  |  | $ | 2,299 |  |  | $ | 8,611 |  |  | $ | 4,216 |  |  | $ | 4,395 |  |  | $ | 6 |  |  | $ | 3,552 |  |
| % of revenue |  |  | 65.0 | % |  |  | 67.4 | % |  |  | 65.6 | % |  |  | 32.1 | % |  |  | 33.5 | % |  |  | — | % |  |  | 27.1 | % |

[0001193125-22-223250:8k_2_02:144]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-22-223250:8k_2_02:145]
12

[0001193125-22-223250:8k_2_02:146]
CISCO SYSTEMS, INC.

[0001193125-22-223250:8k_2_02:147]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-22-223250:8k_2_02:148]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET,

[0001193125-22-223250:8k_2_02:149]
AND NET INCOME

[0001193125-22-223250:8k_2_02:150]
(In
millions, except percentages)

[0001193125-22-223250:8k_2_02:151]
|  |  | Fiscal Year Ended |  |
|  |  | July 30, 2022 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 23,204 |  |  | $ | 9,044 |  |  | $ | 32,248 |  |  | $ | 18,279 |  |  |  | (4 | )% |  | $ | 13,969 |  |  |  | 9 | % |  | $ | 508 |  |  | $ | 11,812 |  |  |  | 12 | % |
| % of revenue |  |  | 61.0 | % |  |  | 66.8 | % |  |  | 62.5 | % |  |  | 35.5 | % |  |  |  |  |  |  | 27.1 | % |  |  |  |  |  |  | 1.0 | % |  |  | 22.9 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 112 |  |  |  | 199 |  |  |  | 311 |  |  |  | 1,574 |  |  |  |  |  |  |  | 1,885 |  |  |  |  |  |  |  | — |  |  |  | 1,885 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 733 |  |  |  | — |  |  |  | 733 |  |  |  | 328 |  |  |  |  |  |  |  | 1,061 |  |  |  |  |  |  |  | — |  |  |  | 1,061 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 27 |  |  |  | — |  |  |  | 27 |  |  |  | 306 |  |  |  |  |  |  |  | 333 |  |  |  |  |  |  |  | — |  |  |  | 333 |  |  |  |  |  |
| Russia-Ukraine war costs |  |  | 4 |  |  |  | 3 |  |  |  | 7 |  |  |  | 84 |  |  |  |  |  |  |  | 91 |  |  |  |  |  |  |  | — |  |  |  | 91 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 6 |  |  |  |  |  |  |  | 6 |  |  |  |  |  |  |  | — |  |  |  | 6 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (478 | ) |  |  | (478 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (616 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 24,080 |  |  | $ | 9,246 |  |  | $ | 33,326 |  |  | $ | 15,981 |  |  |  | (1 | )% |  | $ | 17,345 |  |  |  | 4 | % |  | $ | 30 |  |  | $ | 14,094 |  |  |  | 3 | % |
| % of revenue |  |  | 63.3 | % |  |  | 68.3 | % |  |  | 64.6 | % |  |  | 31.0 | % |  |  |  |  |  |  | 33.6 | % |  |  |  |  |  |  | 0.1 | % |  |  | 27.3 | % |  |  |  |  |

[0001193125-22-223250:8k_2_02:152]
|  |  | Fiscal Year Ended |  |
|  |  | July 31, 2021 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 22,714 |  |  | $ | 9,180 |  |  | $ | 31,894 |  |  | $ | 19,061 |  |  | $ | 12,833 |  |  | $ | 429 |  |  | $ | 10,591 |  |
| % of revenue |  |  | 63.1 | % |  |  | 66.5 | % |  |  | 64.0 | % |  |  | 38.3 | % |  |  | 25.8 | % |  |  | 0.9 | % |  |  | 21.3 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 99 |  |  |  | 176 |  |  |  | 275 |  |  |  | 1,460 |  |  |  | 1,735 |  |  |  | — |  |  |  | 1,735 |  |
| Amortization of acquisition-related intangible assets |  |  | 698 |  |  |  | — |  |  |  | 698 |  |  |  | 215 |  |  |  | 913 |  |  |  | — |  |  |  | 913 |  |
| Acquisition/divestiture-related costs |  |  | 3 |  |  |  | 1 |  |  |  | 4 |  |  |  | 288 |  |  |  | 292 |  |  |  | 4 |  |  |  | 296 |  |
| Legal and indemnification settlements/charges |  |  | 43 |  |  |  | — |  |  |  | 43 |  |  |  | — |  |  |  | 43 |  |  |  | — |  |  |  | 43 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 886 |  |  |  | 886 |  |  |  | — |  |  |  | 886 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (285 | ) |  |  | (285 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (543 | ) |
| Non-GAAP amount |  | $ | 23,557 |  |  | $ | 9,357 |  |  | $ | 32,914 |  |  | $ | 16,212 |  |  | $ | 16,702 |  |  | $ | 148 |  |  | $ | 13,636 |  |
| % of revenue |  |  | 65.4 | % |  |  | 67.8 | % |  |  | 66.1 | % |  |  | 32.5 | % |  |  | 33.5 | % |  |  | 0.3 | % |  |  | 27.4 | % |

[0001193125-22-223250:8k_2_02:153]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-22-223250:8k_2_02:154]
13

[0001193125-22-223250:8k_2_02:155]
CISCO SYSTEMS, INC.

[0001193125-22-223250:8k_2_02:156]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-22-223250:8k_2_02:157]
EFFECTIVE TAX RATE

[0001193125-22-223250:8k_2_02:158]
(In
percentages)

[0001193125-22-223250:8k_2_02:159]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 30,2022 |  |  | July 31,2021 |  |  | July 30,2022 |  |  | July 31,2021 |  |
| GAAP effective tax rate |  |  | 17.6 | % |  |  | 19.4 | % |  |  | 18.4 | % |  |  | 20.1 | % |
| Total adjustments to GAAP provision for income taxes |  |  | 0.9 | % |  |  | (0.1 | )% |  |  | 0.5 | % |  |  | (1.0 | )% |
| Non-GAAP effective tax rate |  |  | 18.5 | % |  |  | 19.3 | % |  |  | 18.9 | % |  |  | 19.1 | % |

[0001193125-22-223250:8k_2_02:160]
GAAP TO NON-GAAP GUIDANCE

[0001193125-22-223250:8k_2_02:161]
| Q1 FY 2023 |  | Gross MarginRate |  | Operating MarginRate |  | Earnings perShare (1) |
| GAAP |  | 61% - 62% |  | 25.5% - 26.5% |  | $0.64 - $0.68 |
| Estimated adjustments for: |  |  |  |  |  |  |
| Share-based compensation expense |  | 1.0% |  | 4.0% |  | $0.10 - $0.11 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 1.0% |  | 2.0% |  | $0.06 - $0.07 |
| Non-GAAP |  | 63% - 64% |  | 31.5% - 32.5% |  | $0.82 - $0.84 |

[0001193125-22-223250:8k_2_02:162]
| FY 2023 |  | Earnings perShare (1) |
| GAAP |  | $2.77 - $2.88 |
| Estimated adjustments for: |  |  |
| Share-based compensation expense |  | $0.46 - $0.48 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | $0.22 - $0.24 |
| Non-GAAP |  | $3.49 - $3.56 |

[0001193125-22-223250:8k_2_02:163]
| (1) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-22-223250:8k_2_02:164]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, Russia-Ukraine war costs,
restructurings, (gains) and losses on equity investments and significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-22-223250:8k_2_02:165]
14

[0001193125-22-223250:8k_2_02:166]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-22-223250:8k_2_02:167]
This release includes non-GAAP net income,
non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin,
non-GAAP effective tax rates, non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the
periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-22-223250:8k_2_02:168]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with
generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any
comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as
determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-22-223250:8k_2_02:169]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP
measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-22-223250:8k_2_02:170]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other contingencies, Russia-Ukraine war costs, gains and losses on
equity investments, the income tax effects of the foregoing and significant tax matters.

[0001193125-22-223250:8k_2_02:171]
15

[0001193125-22-223250:8k_2_02:172]
Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial results of
Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be other items that Cisco may
exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures,
refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-22-223250:8k_2_02:173]
Annualized Recurring Revenue represents the annualized revenue run-rate of active subscriptions, term licenses, and
maintenance contracts at the end of a reporting period, net of rebates to customers and partners as well as certain other revenue adjustments. Includes both revenue recognized ratably as well as upfront on an annualized basis.

[0001193125-22-223250:8k_2_02:174]
About Cisco

[0001193125-22-223250:8k_2_02:175]
Cisco (Nasdaq: CSCO) is the worldwide
leader in technology that powers the Internet. Cisco inspires new possibilities by reimagining your applications, securing your data, transforming your infrastructure, and empowering your teams for a global and inclusive future.
Discover more at newsroom.cisco.com and follow us on Twitter at @Cisco.

[0001193125-22-223250:8k_2_02:176]
Copyright © 2022 Cisco
and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks.
Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-22-223250:8k_2_02:177]
RSS Feed for Cisco: https://newsroom.cisco.com/rss-feeds

[0001193125-22-223250:8k_2_02:178]
16
