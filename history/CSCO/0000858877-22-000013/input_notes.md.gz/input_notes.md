# CSCO notes — 0000858877-22-000013


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000858877-22-000013:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to the 2022 Annual Meeting of Stockholders, to be held on December 8, 2022, are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-22-000013:notes:2]
Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2022 and fiscal 2020 were each 52-week fiscal years, and fiscal 2021 was a 53-week fiscal year. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-22-000013:notes:3]
Our consolidated financial statements include our accounts and investments consolidated under the variable interest and voting models. The noncontrolling interests attributed to these investments are not presented as a separate component in the equity section of the Consolidated Balance Sheets as these amounts are not material for any of the fiscal periods presented. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-22-000013:notes:4]
Certain reclassifications have been made to the amounts for prior years in order to conform to the current year’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-22-000013:notes:5]
Summary of Significant Accounting Policies
(a) Cash and Cash Equivalents   We consider all highly liquid investments purchased with an original or remaining maturity of three months or less at the date of purchase to be cash equivalents. Cash and cash equivalents are maintained with various financial institutions.

[0000858877-22-000013:notes:6]
(b) Available-for-Sale Debt Investments   We classify our investments in fixed income securities as available-for-sale debt investments. Our available-for-sale debt investments primarily consist of U.S. government, U.S. government agency, non-U.S. government and agency, corporate debt, and U.S. agency mortgage-backed securities. These available-for-sale debt investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of available-for-sale debt investments sold. These investments are recorded in the Consolidated Balance Sheets at fair value. Unrealized gains and losses on these investments are included as a separate component of accumulated other comprehensive income (AOCI), net of tax. We classify our investments as current based on the nature of the investments and their availability for use in current operations.

[0000858877-22-000013:notes:7]
(c) Equity Instruments   Our equity investments are accounted for as follows:

[0000858877-22-000013:notes:8]
•Marketable equity securities have readily determinable fair value (RDFV) that are measured and recorded at fair value through income.

[0000858877-22-000013:notes:9]
•Non-marketable equity securities do not have RDFV and are measured using a measurement alternative recorded at cost less any impairment, plus or minus changes resulting from qualifying observable price changes. For certain of these securities, we have elected to apply the net asset value (NAV) practical expedient. The NAV is the estimated fair value of these investments.

[0000858877-22-000013:notes:10]
•Equity method investments are securities we do not control, but are able to exert significant influence over the investee. These investments are measured at cost less any impairment, plus or minus our share of equity method investee income or loss.

[0000858877-22-000013:notes:11]
(d) Impairments of Investments   For our available-for-sale debt securities in an unrealized loss position, we determine whether a credit loss exists. In this assessment, among other factors, we consider the extent to which the fair value is less than the amortized cost, any changes to the rating of the security by a rating agency, and adverse conditions specifically related to the security. If factors indicate a credit loss exists, an allowance for credit loss is recorded to other income (loss), net, limited by the amount that the fair value is less than the amortized cost basis. The amount of fair value change relating to all other factors will be recognized in other comprehensive income (OCI).

[0000858877-22-000013:notes:12]
We hold non-marketable equity and other investments (“privately held investments”) which are included in other assets in the Consolidated Balance Sheets. We monitor these investments for impairments and make reductions in carrying values if we determine that an impairment charge is required based primarily on the financial condition and near-term prospects of these companies.

[0000858877-22-000013:notes:13]
(e) Inventories   Inventories are stated at the lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. We provide inventory write-downs based on excess and obsolete inventories determined primarily by future demand forecasts. The write-down is measured as the difference between the cost of the inventory and net realizable value based upon assumptions about future demand and charged to the provision for inventory, which is a component of cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In addition, we record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0000858877-22-000013:notes:14]
(f) Allowance for Accounts Receivable, Contract Assets and Financing Receivables   We estimate our allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, we determine collectibility by pooling our assets with similar characteristics.

[0000858877-22-000013:notes:15]
The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. Our internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality. Assets that do not share risk characteristics are evaluated on an individual basis. The allowances for credit losses are each measured by multiplying the exposure probability of default, the probability the asset will default within a given time frame, by the loss given default rate, the percentage of the asset not expected to be collected due to default, based on the pool of assets.

[0000858877-22-000013:notes:16]
Probability of default rates are published quarterly by third-party credit agencies. Adjustments to our internal credit risk ratings may take into account including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000858877-22-000013:notes:17]
(g) Financing Receivables and Guarantees   We provide financing arrangements, including leases and loans and financed service contracts, for certain qualified end-user customers to build, maintain, and upgrade their networks. Lease receivables primarily represent sales-type and direct-financing leases. Leases have on average a four-year term and are usually collateralized by a security interest in the underlying assets. Loan receivables and financed service contracts include customers financing purchases of our hardware, software and services, and also may include additional funds for other costs associated with network installation and integration of our products and services. Loan receivables and financed service contracts have terms of one year to three years on average.

[0000858877-22-000013:notes:18]
Outstanding financing receivables that are aged 31 days or more from the contractual payment date are considered past due. We do not accrue interest on financing receivables that are considered impaired and more than 120 days past due unless either the receivable has not been collected due to administrative reasons or the receivable is well secured and in the process of collection. Financing receivables may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain. After a financing receivable has been categorized as nonaccrual, interest will be recognized when cash is received. A financing receivable may be returned to accrual status after all of the customer’s delinquent balances of principal and interest have been settled, and the customer remains current for an appropriate period.

[0000858877-22-000013:notes:19]
We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive a payment for the receivables from the third party based on our standard payment terms. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Deferred revenue relating to these financing arrangements is recorded in accordance with revenue recognition policies or for the fair value of the financing guarantees.

[0000858877-22-000013:notes:20]
(h) Leases   We lease real estate, information technology (IT) and other equipment and vehicles. We also have arrangements with certain suppliers and contract manufacturers which includes the leasing of dedicated space and equipment costs. Our leases have the option to extend or terminate the lease when it is reasonably certain that we will exercise that option.

[0000858877-22-000013:notes:21]
As a lessee, we determine if an arrangement is a lease at commencement. Our ROU lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments related to the lease. Operating lease ROU assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. We use incremental borrowing rates based on information available at the commencement date to determine the present value of our lease payments. Certain of our lease agreements contain variable lease payments. Our variable lease payments can fluctuate depending on the level of activity or the cost of certain services where we have elected to combine lease and non-lease components. While these payments are not included as part of our lease liabilities, they are recognized as variable lease expense in the period they are incurred.

[0000858877-22-000013:notes:22]
We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. As a lessor, we determine if an arrangement is a lease at inception. We provide leasing arrangements for our equipment to certain qualified customers. Our lease portfolio primarily consists of sales-type leases. We allocate the consideration in a bundled contract with our customers based on relative standalone selling prices of our lease and non-lease components. The residual value on our leased equipment is determined at the inception of the lease based on an analysis of estimates of the value of equipment, market factors and historical customer behavior. Residual value estimates are reviewed on a periodic basis and other-than-temporary declines are expensed in the period they occur. Our leases generally provide an end-of-term option for the customer to extend the lease under mutually-agreed terms, return the leased equipment, or purchase the equipment for either the then-market value of the equipment or a pre-determined purchase price. If a customer chooses to terminate their lease prior to the original end of term date, the customer is required to pay all remaining lease payments in full.

[0000858877-22-000013:notes:23]
(i) Depreciation and Amortization   Property and equipment are stated at cost, less accumulated depreciation or amortization, whenever applicable. Depreciation and amortization expenses for property and equipment were approximately $0.8 billion, $0.8 billion, and $0.9 billion for fiscal 2022, 2021, and 2020, respectively. Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-22-000013:notes:24]
| Asset Category |  | Period |
| Buildings |  | 25 years |
| Building improvements |  | 10 years |
| Leasehold improvements |  | Shorter of remaining lease term or up to 10 years |
| Computer equipment and related software |  | 30 to 36 months |
| Production, engineering, and other equipment |  | Up to 5 years |
| Operating lease assets |  | Based on lease term |
| Furniture and fixtures |  | 5 years |

[0000858877-22-000013:notes:25]
(j) Business Combinations We allocate the fair value of the purchase consideration of our acquisitions to the tangible assets, liabilities, and intangible assets acquired, including in-process research and development (IPR&D), based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life. Acquisition-related expenses and related restructuring costs are recognized separately from the business combination and are expensed as incurred.

[0000858877-22-000013:notes:26]
(k) Goodwill and Purchased Intangible Assets   Goodwill is tested for impairment on an annual basis in the fourth fiscal quarter and, when specific circumstances dictate, between annual tests. When impaired, the carrying value of goodwill is written down to fair value. Identifying a potential impairment consists of comparing the fair value of a reporting unit with its carrying amount, including goodwill. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. See “Long-Lived Assets” for our policy regarding impairment testing of purchased intangible assets with finite lives. Purchased intangible assets with indefinite lives are assessed for potential impairment annually or when events or circumstances indicate that their carrying amounts might be impaired.

[0000858877-22-000013:notes:27]
(l) Long-Lived Assets   Long-lived assets that are held and used by us are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability of long-lived assets is based on an estimate of the undiscounted future cash flows resulting from the use of the asset and its eventual disposition. Measurement of an impairment loss for long-lived assets that management expects to hold and use is based on the difference between the fair value of the asset and its carrying value. Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0000858877-22-000013:notes:28]
(m) Fair Value   Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, we consider the principal or most advantageous market in which we would transact, and we also consider assumptions that market participants would use when pricing the asset or liability.

[0000858877-22-000013:notes:29]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. The standard establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement.

[0000858877-22-000013:notes:30]
The fair value hierarchy is as follows:

[0000858877-22-000013:notes:31]
Level 1 applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000858877-22-000013:notes:32]
Level 2 applies to assets or liabilities for which there are inputs other than quoted prices that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets); or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of assets or liabilities.

[0000858877-22-000013:notes:33]
Level 3 applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities. The fair values are determined based on model-based techniques such as discounted cash flow models using inputs that we could not corroborate with market data.

[0000858877-22-000013:notes:34]
(n) Derivative Instruments   We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.

[0000858877-22-000013:notes:35]
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.

[0000858877-22-000013:notes:36]
(o) Foreign Currency Translation   Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated to U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of AOCI. Income and expense accounts are translated at average exchange rates during the year. Remeasurement adjustments are recorded in other income (loss), net.

[0000858877-22-000013:notes:37]
(p) Concentrations of Risk   Cash and cash equivalents are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. We seek to mitigate our credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties.

[0000858877-22-000013:notes:38]
We perform ongoing credit evaluations of our customers and, with the exception of certain financing transactions, do not require collateral from our customers. We receive certain of our components from sole suppliers. Additionally, we rely on a limited number of contract manufacturers and suppliers to provide manufacturing services for our products. The inability of a contract manufacturer or supplier to fulfill our supply requirements could materially impact future operating results.

[0000858877-22-000013:notes:39]
(q) Revenue Recognition   We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

[0000858877-22-000013:notes:40]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-22-000013:notes:41]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of July 30, 2022 and July 31, 2021 was $43 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-22-000013:notes:42]
Significant Judgments

[0000858877-22-000013:notes:43]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-22-000013:notes:44]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.

[0000858877-22-000013:notes:45]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license’s utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

[0000858877-22-000013:notes:46]
(r) Advertising Costs   We expense all advertising costs as incurred. Advertising costs included within sales and marketing expenses were approximately $219 million, $268 million, and $187 million for fiscal 2022, 2021, and 2020, respectively.

[0000858877-22-000013:notes:47]
(s) Share-Based Compensation Expense   We measure and recognize the compensation expense for all share-based awards made to employees and directors, including employee stock options, restricted stock units (RSUs), performance-based restricted stock units (PRSUs), and employee stock purchases related to the Employee Stock Purchase Plan (Employee Stock Purchase Rights) based on estimated fair values. The fair value of employee stock options is estimated on the date of grant using a lattice-binomial option-pricing model (Lattice-Binomial Model) or the Black-Scholes model, and for employee stock purchase rights we estimate the fair value using the Black-Scholes model. The fair value for time-based stock awards and stock awards that are contingent upon the achievement of financial performance metrics is based on the grant date share price reduced by the present

[0000858877-22-000013:notes:48]
value of the expected dividend yield prior to vesting. The fair value of market-based stock awards is estimated using an option-pricing model on the date of grant. Share-based compensation expense is reduced for forfeitures.

[0000858877-22-000013:notes:49]
(t) Software Development Costs   Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.

[0000858877-22-000013:notes:50]
(u) Income Taxes   Income tax expense is based on pretax financial accounting income. Deferred tax assets and liabilities are recognized for the expected tax consequences of temporary differences between the tax bases of assets and liabilities and their reported amounts. Valuation allowances are recorded to reduce deferred tax assets to the amount that will more likely than not be realized.

[0000858877-22-000013:notes:51]
We account for uncertainty in income taxes using a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. We classify the liability for unrecognized tax benefits as current to the extent that we anticipate payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.

[0000858877-22-000013:notes:52]
(v) Computation of Net Income per Share   Basic net income per share is computed using the weighted-average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted-average number of common shares and dilutive potential common shares outstanding during the period. Diluted shares outstanding includes the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares.

[0000858877-22-000013:notes:53]
(w) Consolidation of Variable Interest Entities  Our approach in assessing the consolidation requirement for variable interest entities focuses on identifying which enterprise has the power to direct the activities that most significantly impact the variable interest entity’s economic performance and which enterprise has the obligation to absorb losses or the right to receive benefits from the variable interest entity. Should we conclude that we are the primary beneficiary of a variable interest entity, the assets, liabilities, and results of operations of the variable interest entity will be included in our Consolidated Financial Statements.

[0000858877-22-000013:notes:54]
(x) Use of Estimates   The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Estimates are used for the following, among others:

[0000858877-22-000013:notes:55]
▪Revenue recognition

[0000858877-22-000013:notes:56]
▪Allowances for accounts receivable, sales returns, and financing receivables

[0000858877-22-000013:notes:57]
▪Inventory valuation and liability for purchase commitments with contract manufacturers and suppliers

[0000858877-22-000013:notes:58]
▪Loss contingencies and product warranties

[0000858877-22-000013:notes:59]
▪Fair value measurements

[0000858877-22-000013:notes:60]
▪Goodwill and purchased intangible asset impairments

[0000858877-22-000013:notes:61]
▪Income taxes

[0000858877-22-000013:notes:62]
The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic, including the associated impact of supply constraints, on our critical and significant accounting estimates. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-22-000013:notes:63]
(y) New Accounting Updates Recently Adopted

[0000858877-22-000013:notes:64]
Acquired Revenue Contracts with Customers in Business Combinations  In October 2021, the Financial Accounting Standards Board (FASB) issued an accounting standard update that requires companies to apply ASC 606 to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination. We early adopted this accounting standard update beginning in the first quarter of fiscal 2022 and it did not have a material impact on our

[0000858877-22-000013:notes:65]
Consolidated Financial Statements. The ongoing impact of this standard will be fact dependent on the transactions within its scope.

[0000858877-22-000013:notes:66]
(z) Recent Accounting Standards or Updates Not Yet Effective as of Fiscal Year End

[0000858877-22-000013:notes:67]
Reference Rate Reform  In March 2020, the FASB issued an accounting standard update and subsequent amendments that provide optional expedients and exceptions to the current guidance on contract modification and hedging relationships to ease the financial reporting burden of the expected market transition from the London InterBank Offered Rate (LIBOR) and other interbank offered rates to alternative reference rates. This accounting standard update was effective upon issuance and may be applied prospectively through December 31, 2022. We do not expect this accounting standard update will have a material impact on our Consolidated Financial Statements.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-22-000013:notes:68]
Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-22-000013:notes:69]
Property and Equipment, Net

[0000858877-22-000013:notes:70]
|  |  | July 30, 2022 |  | July 31, 2021 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,219 |  |  | $ | 4,304 |  |
| Computer equipment and related software |  | 779 |  |  | 858 |  |
| Production, engineering, and other equipment |  | 4,647 |  |  | 5,106 |  |
| Operating lease assets |  | 185 |  |  | 273 |  |
| Furniture, fixtures and other |  | 335 |  |  | 377 |  |
| Total gross property and equipment |  | 10,165 |  |  | 10,918 |  |
| Less: accumulated depreciation and amortization |  | (8,168) |  |  | (8,580) |  |
| Total |  | $ | 1,997 |  |  | $ | 2,338 |  |


## us-gaap:DerivativesPolicyTextBlock

[0000858877-22-000013:notes:71]
(n) Derivative Instruments   We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We do, however, seek to mitigate such risks by limiting our counterparties to major financial institutions and requiring collateral in certain cases. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-22-000013:notes:72]
Revenue
(a)Disaggregation of Revenue

[0000858877-22-000013:notes:73]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. Effective fiscal 2022, we began reporting our product and service revenue in the following categories: Secure, Agile Networks; Internet for the Future; Collaboration; End-to-End Security; Optimized Application Experiences; Other Products; and Services. This change will better align our product categories with our strategic priorities.

[0000858877-22-000013:notes:74]
The following table presents this disaggregation of revenue (in millions):

[0000858877-22-000013:notes:75]
| Years Ended | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Product revenue: |  |  |  |  |  |
| Secure, Agile Networks | $ | 23,829 |  |  | $ | 22,722 |  |  | $ | 23,265 |  |
| Internet for the Future | 5,278 |  |  | 4,514 |  |  | 4,180 |  |
| Collaboration | 4,472 |  |  | 4,727 |  |  | 4,823 |  |
| End-to-End Security | 3,699 |  |  | 3,382 |  |  | 3,158 |  |
| Optimized Application Experiences | 729 |  |  | 654 |  |  | 524 |  |
| Other Products | 11 |  |  | 15 |  |  | 28 |  |
| Total Product | 38,018 |  |  | 36,014 |  |  | 35,978 |  |
| Services | 13,539 |  |  | 13,804 |  |  | 13,323 |  |
| Total | $ | 51,557 |  |  | $ | 49,818 |  |  | $ | 49,301 |  |

[0000858877-22-000013:notes:76]
Amounts may not sum due to rounding.

[0000858877-22-000013:notes:77]
Secure, Agile Networks consists of our core networking technologies of switching, enterprise routing, wireless, and compute products. These technologies consist of both hardware and software offerings, including software licenses and SaaS, that help our customers build networks, automate, orchestrate, integrate, and digitize data. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-22-000013:notes:78]
Internet for the Future consists of our routed optical networking, 5G, silicon, and optics solutions. These products consist primarily of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-22-000013:notes:79]
Collaboration consists of our Meetings, Collaboration Devices, Calling, Contact Center and CPaaS offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this

[0000858877-22-000013:notes:80]
category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-22-000013:notes:81]
End-to-End Security product category consists of our Network Security, Cloud Security, Security Endpoints, Unified Threat Management and Zero Trust offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-22-000013:notes:82]
Optimized Application Experiences consists of our full stack observability and cloud-native platform offerings. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-22-000013:notes:83]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and advanced services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Advanced services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

[0000858877-22-000013:notes:84]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for all of our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.

[0000858877-22-000013:notes:85]
(b)Contract Balances

[0000858877-22-000013:notes:86]
Accounts Receivable

[0000858877-22-000013:notes:87]
Accounts receivable, net was $6.6 billion as of July 30, 2022 compared to $5.8 billion as of July 31, 2021, as reported on the Consolidated Balance Sheets.

[0000858877-22-000013:notes:88]
The allowances for credit loss for our accounts receivable are summarized as follows (in millions):

[0000858877-22-000013:notes:89]
|  |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Allowance for credit loss at beginning of fiscal year |  | $ | 109 |  |  | $ | 143 |  |  | $ | 136 |  |
| Provisions (benefits) |  | 64 |  |  | 21 |  |  | 55 |  |
| Recoveries (write-offs), net |  | (81) |  |  | (29) |  |  | (48) |  |
| Foreign exchange and other |  | (9) |  |  | (26) |  |  | — |  |
| Allowance for credit loss at end of fiscal year |  | $ | 83 |  |  | $ | 109 |  |  | $ | 143 |  |

[0000858877-22-000013:notes:90]
Contract Assets and Liabilities

[0000858877-22-000013:notes:91]
Gross contract assets by our internal risk ratings are summarized as follows (in millions):

[0000858877-22-000013:notes:92]
|  | July 30, 2022 |  | July 31, 2021 |
| 1 to 4 | $ | 414 |  |  | $ | 521 |  |
| 5 to 6 | 814 |  |  | 770 |  |
| 7 and Higher | 158 |  |  | 166 |  |
| Total | $ | 1,386 |  |  | $ | 1,457 |  |

[0000858877-22-000013:notes:93]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of July 30, 2022 and July 31, 2021, our contract assets for these unbilled receivables, net of allowances, were $1.3 billion and $1.4 billion, respectively, and were included in other current assets and other assets.

[0000858877-22-000013:notes:94]
Contract liabilities consist of deferred revenue. Deferred revenue was $23.3 billion as of July 30, 2022 compared to $22.2 billion as of July 31, 2021. We recognized approximately $12.0 billion of revenue during fiscal 2022 that was included in the deferred revenue balance at July 31, 2021.

[0000858877-22-000013:notes:95]
(c)Capitalized Contract Acquisition Costs

[0000858877-22-000013:notes:96]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $1.0 billion as of each of July 30, 2022 and July 31, 2021, and were included in other current assets and other assets. The amortization expense associated with these costs was $679 million and $532 million for fiscal 2022 and 2021, respectively, and was included in sales and marketing expenses.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-22-000013:notes:97]
The following table presents revenue for groups of similar products and services (in millions):

[0000858877-22-000013:notes:98]
| Years Ended | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Revenue: |  |  |  |  |  |
| Secure, Agile Networks | $ | 23,829 |  |  | $ | 22,722 |  |  | $ | 23,265 |  |
| Internet for the Future | 5,278 |  |  | 4,514 |  |  | 4,180 |  |
| Collaboration | 4,472 |  |  | 4,727 |  |  | 4,823 |  |
| End-to-End Security | 3,699 |  |  | 3,382 |  |  | 3,158 |  |
| Optimized Application Experiences | 729 |  |  | 654 |  |  | 524 |  |
| Other Products | 11 |  |  | 15 |  |  | 28 |  |
| Total Product | 38,018 |  |  | 36,014 |  |  | 35,978 |  |
| Services | 13,539 |  |  | 13,804 |  |  | 13,323 |  |
| Total | $ | 51,557 |  |  | $ | 49,818 |  |  | $ | 49,301 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-22-000013:notes:99]
Acquisitions and Divestitures 
(a)Acquisition Summary

[0000858877-22-000013:notes:100]
We completed three acquisitions during fiscal 2022. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-22-000013:notes:101]
| Fiscal 2022 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions (three in total) | $ | 364 |  |  | $ | 12 |  |  | $ | 20 |  |  | $ | 332 |  |

[0000858877-22-000013:notes:102]
The total purchase consideration related to our acquisitions completed during fiscal 2022 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $7 million.

[0000858877-22-000013:notes:103]
Fiscal 2021 Acquisitions

[0000858877-22-000013:notes:104]
Allocation of the purchase consideration for acquisitions completed in fiscal 2021 is summarized as follows (in millions):

[0000858877-22-000013:notes:105]
| Fiscal 2021 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Acacia | $ | 4,983 |  |  | $ | 442 |  |  | $ | 2,160 |  |  | $ | 2,381 |  |
| Others (12 in total) | 2,472 |  |  | (130) |  |  | 754 |  |  | 1,848 |  |
| Total | $ | 7,455 |  |  | $ | 312 |  |  | $ | 2,914 |  |  | $ | 4,229 |  |

[0000858877-22-000013:notes:106]
On March 1, 2021, we completed our acquisition of Acacia Communications, Inc. (“Acacia”), a public fabless semiconductor company that develops, manufactures and sells high-speed coherent optical interconnect products that are designed to transform communications networks through improvements in performance, capacity and cost. Revenue from the Acacia acquisition has been included in our Internet for the Future product category.

[0000858877-22-000013:notes:107]
The total purchase consideration related to our acquisitions completed during fiscal 2021 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $338 million.

[0000858877-22-000013:notes:108]
Fiscal 2020 Acquisitions

[0000858877-22-000013:notes:109]
In fiscal 2020, we completed six acquisitions for total purchase consideration of $359 million.

[0000858877-22-000013:notes:110]
(b)   Other Acquisition and Divestiture Information

[0000858877-22-000013:notes:111]
Total transaction costs related to acquisition and divestiture activities during fiscal 2022, 2021, and 2020 were $50 million, $46 million, and $21 million, respectively. These transaction costs were expensed as incurred in G&A expenses in the Consolidated Statements of Operations.

[0000858877-22-000013:notes:112]
The goodwill generated from acquisitions completed during fiscal 2022 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during fiscal 2022, 2021, and 2020 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0000858877-22-000013:notes:113]
A summary of the allocation of the total purchase consideration is presented as follows (in millions):


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-22-000013:notes:114]
Goodwill and Purchased Intangible Assets 
(a)Goodwill

[0000858877-22-000013:notes:115]
The following tables present the goodwill allocated to our reportable segments as of July 30, 2022 and July 31, 2021, as well as the changes to goodwill during fiscal 2022 and 2021 (in millions):

[0000858877-22-000013:notes:116]
|  | Balance at July 31, 2021 |  | Acquisitions & Divestitures |  | Other |  | Balance at July 30, 2022 |
| Americas | $ | 23,673 |  |  | $ | 222 |  |  | $ | (13) |  |  | $ | 23,882 |  |
| EMEA | 9,094 |  |  | 83 |  |  | (115) |  |  | 9,062 |  |
| APJC | 5,401 |  |  | 27 |  |  | (68) |  |  | 5,360 |  |
| Total | $ | 38,168 |  |  | $ | 332 |  |  | $ | (196) |  |  | $ | 38,304 |  |

[0000858877-22-000013:notes:117]
|  | Balance at July 25, 2020 |  | Acquisitions & Divestitures |  | Other |  | Balance at July 31, 2021 |
| Americas | $ | 21,304 |  |  | $ | 2,275 |  |  | $ | 94 |  |  | $ | 23,673 |  |
| EMEA | 8,040 |  |  | 1,019 |  |  | 35 |  |  | 9,094 |  |
| APJC | 4,462 |  |  | 920 |  |  | 19 |  |  | 5,401 |  |
| Total | $ | 33,806 |  |  | $ | 4,214 |  |  | $ | 148 |  |  | $ | 38,168 |  |

[0000858877-22-000013:notes:118]
“Other” in the tables above consists of foreign currency translation as well as purchase accounting adjustments.

[0000858877-22-000013:notes:119]
(b)Purchased Intangible Assets

[0000858877-22-000013:notes:120]
The following tables present details of our intangible assets acquired through acquisitions completed during fiscal 2022 and 2021 (in millions, except years):

[0000858877-22-000013:notes:121]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2022 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions (three in total) | 2.7 |  | $ | 16 |  |  | 2.0 |  | $ | 4 |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 20 |  |

[0000858877-22-000013:notes:122]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2021 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Acacia | 4.0 |  | $ | 1,290 |  |  | 4.0 |  | $ | 490 |  |  | 3.1 |  | $ | 35 |  |  | $ | 345 |  |  | $ | 2,160 |  |
| Others | 4.3 |  | 545 |  |  | 4.6 |  | 174 |  |  | 2.9 |  | 35 |  |  | — |  |  | 754 |  |
| Total |  |  | $ | 1,835 |  |  |  |  | $ | 664 |  |  |  |  | $ | 70 |  |  | $ | 345 |  |  | $ | 2,914 |  |

[0000858877-22-000013:notes:123]
The following tables present details of our purchased intangible assets (in millions):

[0000858877-22-000013:notes:124]
| July 30, 2022 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 2,631 |  |  | $ | (1,102) |  |  | $ | 1,529 |  |
| Customer relationships |  | 1,354 |  |  | (769) |  |  | 585 |  |
| Other |  | 41 |  |  | (16) |  |  | 25 |  |
| Total purchased intangible assets with finite lives |  | 4,026 |  |  | (1,887) |  |  | 2,139 |  |
| In-process research and development, with indefinite lives |  | 430 |  |  | — |  |  | 430 |  |
| Total |  | $ | 4,456 |  |  | $ | (1,887) |  |  | $ | 2,569 |  |

[0000858877-22-000013:notes:125]
| July 31, 2021 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,629 |  |  | $ | (1,437) |  |  | $ | 2,192 |  |
| Customer relationships |  | 1,387 |  |  | (523) |  |  | 864 |  |
| Other |  | 71 |  |  | (13) |  |  | 58 |  |
| Total purchased intangible assets with finite lives |  | 5,087 |  |  | (1,973) |  |  | 3,114 |  |
| In-process research and development, with indefinite lives |  | 505 |  |  | — |  |  | 505 |  |
| Total |  | $ | 5,592 |  |  | $ | (1,973) |  |  | $ | 3,619 |  |

[0000858877-22-000013:notes:126]
Purchased intangible assets include intangible assets acquired through acquisitions as well as through direct purchases or licenses.

[0000858877-22-000013:notes:127]
Impairment charges related to purchased intangible assets were $15 million for fiscal 2022, and were included in research and development expenses. Impairment charges are primarily a result of declines in estimated fair values of certain purchased intangible assets resulting from the reduction or elimination of expected future cash flows associated with certain of our technology and IPR&D intangible assets.

[0000858877-22-000013:notes:128]
The following table presents the amortization of purchased intangible assets, including impairment charges (in millions):

[0000858877-22-000013:notes:129]
| Years Ended |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 749 |  |  | $ | 716 |  |  | $ | 659 |  |
| Operating expenses |  | 328 |  |  | 215 |  |  | 141 |  |
| Total |  | $ | 1,077 |  |  | $ | 931 |  |  | $ | 800 |  |

[0000858877-22-000013:notes:130]
The estimated future amortization expense of purchased intangible assets with finite lives as of July 30, 2022 is as follows (in millions):

[0000858877-22-000013:notes:131]
| Fiscal Year | Amount |
| 2023 | $ | 900 |  |
| 2024 | $ | 773 |  |
| 2025 | $ | 403 |  |
| 2026 | $ | 61 |  |
| 2027 | $ | 2 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-22-000013:notes:132]
Restructuring and Other Charges
We initiated a restructuring plan in fiscal 2021 (the “Fiscal 2021 Plan”), which included a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas. The total pretax charges were estimated to be approximately $900 million. In connection with the Fiscal 2021 Plan, we incurred cumulative charges of $892 million and completed the Fiscal 2021 Plan in fiscal 2022.

[0000858877-22-000013:notes:133]
We initiated a restructuring plan in fiscal 2020 (the “Fiscal 2020 Plan”) in order to realign the organization and enable further investment in key priority areas. In connection with the Fiscal 2020 Plan, we incurred cumulative charges of $254 million. We completed the Fiscal 2020 Plan in fiscal 2021.

[0000858877-22-000013:notes:134]
The aggregate pretax charges related to these plans are primarily cash-based and consist of severance and other one-time termination benefits, and other costs.

[0000858877-22-000013:notes:135]
The following table summarizes the activities related to the restructuring and other charges, as discussed above (in millions):

[0000858877-22-000013:notes:136]
|  |  | FISCAL 2020 AND PRIOR PLANS |  | FISCAL 2021 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 27, 2019 |  | $ | 22 |  |  | $ | 11 |  |  | $ | — |  |  | $ | — |  |  | $ | 33 |  |
| Charges |  | 353 |  |  | 128 |  |  | — |  |  | — |  |  | 481 |  |
| Cash payments |  | (317) |  |  | (10) |  |  | — |  |  | — |  |  | (327) |  |
| Non-cash items |  | — |  |  | (115) |  |  | — |  |  | — |  |  | (115) |  |
| Liability as of July 25, 2020 |  | 58 |  |  | 14 |  |  | — |  |  | — |  |  | 72 |  |
| Charges |  | — |  |  | 5 |  |  | 836 |  |  | 45 |  |  | 886 |  |
| Cash payments |  | (58) |  |  | (6) |  |  | (821) |  |  | (5) |  |  | (890) |  |
| Non-cash items |  | — |  |  | (3) |  |  | 1 |  |  | (32) |  |  | (34) |  |
| Liability as of July 31, 2021 |  | — |  |  | 10 |  |  | 16 |  |  | 8 |  |  | 34 |  |
| Charges |  | — |  |  | (6) |  |  | 9 |  |  | 3 |  |  | 6 |  |
| Cash payments |  | — |  |  | (1) |  |  | (23) |  |  | (1) |  |  | (25) |  |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (6) |  |  | (6) |  |
| Liability as of July 30, 2022 |  | $ | — |  |  | $ | 3 |  |  | $ | 2 |  |  | $ | 4 |  |  | $ | 9 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-22-000013:notes:137]
Balance Sheet and Other Details 
The following tables provide details of selected balance sheet and other items (in millions):

[0000858877-22-000013:notes:138]
Cash, Cash Equivalents, Restricted Cash and Restricted Cash Equivalents

[0000858877-22-000013:notes:139]
|  |  | July 30, 2022 |  | July 31, 2021 |
| Cash and cash equivalents |  | $ | 7,079 |  |  | $ | 9,175 |  |
| Restricted cash and restricted cash equivalents included in other current assets |  | — |  |  | 14 |  |
| Restricted cash and restricted cash equivalents included in other assets |  | 1,500 |  |  | 753 |  |
| Total |  | $ | 8,579 |  |  | $ | 9,942 |  |

[0000858877-22-000013:notes:140]
Our restricted cash equivalents are funds primarily related to contractual obligations with suppliers.

[0000858877-22-000013:notes:141]
Inventories

[0000858877-22-000013:notes:142]
|  |  | July 30, 2022 |  | July 31, 2021 |
| Raw materials |  | $ | 1,601 |  |  | $ | 801 |  |
| Work in process |  | 150 |  |  | 54 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales |  | 86 |  |  | 97 |  |
| Manufactured finished goods |  | 631 |  |  | 422 |  |
| Total finished goods |  | 717 |  |  | 519 |  |
| Service-related spares |  | 90 |  |  | 174 |  |
| Demonstration systems |  | 10 |  |  | 11 |  |
| Total |  | $ | 2,568 |  |  | $ | 1,559 |  |

[0000858877-22-000013:notes:143]
Remaining Performance Obligations (RPO)

[0000858877-22-000013:notes:144]
|  |  | July 30, 2022 |  | July 31, 2021 |
| Product |  | $ | 14,090 |  |  | $ | 13,270 |  |
| Service |  | 17,449 |  |  | 17,623 |  |
| Total |  | $ | 31,539 |  |  | $ | 30,893 |  |
| Short-term RPO |  | $ | 16,936 |  |  | $ | 16,289 |  |
| Long-term RPO |  | 14,603 |  |  | 14,604 |  |
| Total |  | $ | 31,539 |  |  | $ | 30,893 |  |
| Amount to be recognized as revenue over the next 12 months |  | 54 | % |  | 53 | % |
| Deferred revenue |  | $ | 23,264 |  |  | $ | 22,164 |  |
| Unbilled contract revenue |  | 8,275 |  |  | 8,729 |  |
| Total |  | $ | 31,539 |  |  | $ | 30,893 |  |

[0000858877-22-000013:notes:145]
Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

[0000858877-22-000013:notes:146]
Deferred Revenue

[0000858877-22-000013:notes:147]
|  |  | July 30, 2022 |  | July 31, 2021 |
| Product |  | $ | 10,427 |  |  | $ | 9,416 |  |
| Service |  | 12,837 |  |  | 12,748 |  |
| Total |  | $ | 23,264 |  |  | $ | 22,164 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 12,784 |  |  | $ | 12,148 |  |
| Noncurrent |  | 10,480 |  |  | 10,016 |  |
| Total |  | $ | 23,264 |  |  | $ | 22,164 |  |

[0000858877-22-000013:notes:148]
Transition Tax Payable

[0000858877-22-000013:notes:149]
Our income tax payable associated with the one-time U.S. transition tax on accumulated earnings for foreign subsidiaries as a result of the Tax Act is as follows (in millions):

[0000858877-22-000013:notes:150]
|  |  | July 30, 2022 |  | July 31, 2021 |
| Current |  | $ | 727 |  |  | $ | 727 |  |
| Noncurrent |  | 5,456 |  |  | 6,183 |  |
| Total |  | $ | 6,183 |  |  | $ | 6,910 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000858877-22-000013:notes:151]
Leases
(a)Lessee Arrangements

[0000858877-22-000013:notes:152]
The following table presents our operating lease balances (in millions):

[0000858877-22-000013:notes:153]
|  | Balance Sheet Line Item |  | July 30, 2022 |  | July 31, 2021 |
| Operating lease right-of-use assets | Other assets |  | $ | 1,003 |  |  | $ | 1,095 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 322 |  |  | $ | 337 |  |
| Operating lease liabilities | Other long-term liabilities |  | 724 |  |  | 831 |  |
| Total operating lease liabilities |  |  | $ | 1,046 |  |  | $ | 1,168 |  |

[0000858877-22-000013:notes:154]
The components of our lease expenses were as follows (in millions):

[0000858877-22-000013:notes:155]
| Years Ended |  | July 30, 2022 |  | July 31, 2021 |
| Operating lease expense |  | $ | 390 |  |  | $ | 399 |  |
| Short-term lease expense |  | 66 |  |  | 65 |  |
| Variable lease expense |  | 173 |  |  | 173 |  |
| Total lease expense |  | $ | 629 |  |  | $ | 637 |  |

[0000858877-22-000013:notes:156]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-22-000013:notes:157]
| Years Ended |  | July 30, 2022 |  | July 31, 2021 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows |  | $ | 408 |  |  | $ | 407 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities |  | $ | 331 |  |  | $ | 536 |  |

[0000858877-22-000013:notes:158]
The weighted-average lease term was 4.7 years and 5.2 years as of July 30, 2022 and July 31, 2021, respectively. The weighted-average discount rate was 2.2% and 1.7% as of July 30, 2022 and July 31, 2021, respectively.

[0000858877-22-000013:notes:159]
The maturities of our operating leases (undiscounted) as of July 30, 2022 are as follows (in millions):

[0000858877-22-000013:notes:160]
| Fiscal Year | Amount |
| 2023 | $ | 343 |  |
| 2024 | 255 |  |
| 2025 | 176 |  |
| 2026 | 104 |  |
| 2027 | 64 |  |
| Thereafter | 185 |  |
| Total lease payments | 1,127 |  |
| Less interest | (81) |  |
| Total | $ | 1,046 |  |

[0000858877-22-000013:notes:161]
(b)Lessor Arrangements

[0000858877-22-000013:notes:162]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income for fiscal 2022 and 2021 was $54 million and $75 million, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-22-000013:notes:163]
Future minimum lease payments on our lease receivables as of July 30, 2022 are summarized as follows (in millions):

[0000858877-22-000013:notes:164]
| Fiscal Year | Amount |
| 2023 | $ | 582 |  |
| 2024 | 314 |  |
| 2025 | 171 |  |
| 2026 | 80 |  |
| 2027 | 28 |  |
| Thereafter | 1 |  |
| Total | 1,176 |  |
| Less: Present value of lease payments | 1,122 |  |
| Unearned income | $ | 54 |  |

[0000858877-22-000013:notes:165]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-22-000013:notes:166]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-22-000013:notes:167]
|  | July 30, 2022 |  | July 31, 2021 |
| Operating lease assets | $ | 185 |  |  | $ | 273 |  |
| Accumulated depreciation | (111) |  |  | (165) |  |
| Operating lease assets, net | $ | 74 |  |  | $ | 108 |  |

[0000858877-22-000013:notes:168]
Our operating lease income for fiscal 2022 and 2021 was $107 million and $151 million, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-22-000013:notes:169]
Minimum future rentals on noncancelable operating leases as of July 30, 2022 are summarized as follows (in millions):

[0000858877-22-000013:notes:170]
| Fiscal Year | Amount |
| 2023 | $ | 33 |  |
| 2024 | 16 |  |
| 2025 | 4 |  |
| 2026 | — |  |
| Total | $ | 53 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-22-000013:notes:171]
Financing Receivables  
(a)Financing Receivables

[0000858877-22-000013:notes:172]
Financing receivables primarily consist of lease receivables, loans receivables, and financed service contracts. Lease receivables represent sales-type leases resulting from the sale of Cisco’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services, which may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables have terms of three years on average. Financed service contracts include financing receivables related to technical support and advanced services. Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one year to three years.

[0000858877-22-000013:notes:173]
A summary of our financing receivables is presented as follows (in millions):

[0000858877-22-000013:notes:174]
| July 30, 2022 | LeaseReceivables |  | Loan Receivables |  | Financed Service Contracts |  | Total |
| Gross | $ | 1,176 |  |  | $ | 4,656 |  |  | $ | 2,186 |  |  | $ | 8,018 |  |
| Residual value | 76 |  |  | — |  |  | — |  |  | 76 |  |
| Unearned income | (54) |  |  | — |  |  | — |  |  | (54) |  |
| Allowance for credit loss | (23) |  |  | (100) |  |  | (3) |  |  | (126) |  |
| Total, net | $ | 1,175 |  |  | $ | 4,556 |  |  | $ | 2,183 |  |  | $ | 7,914 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 578 |  |  | $ | 2,176 |  |  | $ | 1,151 |  |  | $ | 3,905 |  |
| Noncurrent | 597 |  |  | 2,380 |  |  | 1,032 |  |  | 4,009 |  |
| Total, net | $ | 1,175 |  |  | $ | 4,556 |  |  | $ | 2,183 |  |  | $ | 7,914 |  |

[0000858877-22-000013:notes:175]
| July 31, 2021 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 1,710 |  |  | $ | 5,203 |  |  | $ | 2,453 |  |  | $ | 9,366 |  |
| Residual value | 103 |  |  | — |  |  | — |  |  | 103 |  |
| Unearned income | (78) |  |  | — |  |  | — |  |  | (78) |  |
| Allowance for credit loss | (38) |  |  | (86) |  |  | (3) |  |  | (127) |  |
| Total, net | $ | 1,697 |  |  | $ | 5,117 |  |  | $ | 2,450 |  |  | $ | 9,264 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 780 |  |  | $ | 2,372 |  |  | $ | 1,228 |  |  | $ | 4,380 |  |
| Noncurrent | 917 |  |  | 2,745 |  |  | 1,222 |  |  | 4,884 |  |
| Total, net | $ | 1,697 |  |  | $ | 5,117 |  |  | $ | 2,450 |  |  | $ | 9,264 |  |

[0000858877-22-000013:notes:176]
(b)Credit Quality of Financing Receivables

[0000858877-22-000013:notes:177]
The tables below present our gross financing receivables, excluding residual value, less unearned income, categorized by our internal credit risk rating by period of origination (in millions):

[0000858877-22-000013:notes:178]
| July 30, 2022 |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 28, 2018 |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | July 30, 2022 |  | Total |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 25 |  |  | $ | 74 |  |  | $ | 124 |  |  | $ | 176 |  |  | $ | 152 |  |  | $ | 553 |  |
| 5 to 6 | 1 |  |  | 10 |  |  | 67 |  |  | 146 |  |  | 165 |  |  | 151 |  |  | 540 |  |
| 7 and Higher | — |  |  | 1 |  |  | 4 |  |  | 12 |  |  | 2 |  |  | 10 |  |  | 29 |  |
| Total Lease Receivables | $ | 3 |  |  | $ | 36 |  |  | $ | 145 |  |  | $ | 282 |  |  | $ | 343 |  |  | $ | 313 |  |  | $ | 1,122 |  |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 1 |  |  | $ | 46 |  |  | $ | 136 |  |  | $ | 458 |  |  | $ | 896 |  |  | $ | 1,488 |  |  | $ | 3,025 |  |
| 5 to 6 | 1 |  |  | 10 |  |  | 71 |  |  | 242 |  |  | 465 |  |  | 733 |  |  | 1,522 |  |
| 7 and Higher | 1 |  |  | 1 |  |  | 20 |  |  | 38 |  |  | 37 |  |  | 12 |  |  | 109 |  |
| Total Loan Receivables | $ | 3 |  |  | $ | 57 |  |  | $ | 227 |  |  | $ | 738 |  |  | $ | 1,398 |  |  | $ | 2,233 |  |  | $ | 4,656 |  |
| Financed Service Contracts: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 1 |  |  | $ | 3 |  |  | $ | 37 |  |  | $ | 78 |  |  | $ | 562 |  |  | $ | 799 |  |  | $ | 1,480 |  |
| 5 to 6 | — |  |  | 7 |  |  | 44 |  |  | 103 |  |  | 244 |  |  | 297 |  |  | 695 |  |
| 7 and Higher | — |  |  | — |  |  | 2 |  |  | 7 |  |  | 2 |  |  | — |  |  | 11 |  |
| Total Financed Service Contracts | $ | 1 |  |  | $ | 10 |  |  | $ | 83 |  |  | $ | 188 |  |  | $ | 808 |  |  | $ | 1,096 |  |  | $ | 2,186 |  |
| Total | $ | 7 |  |  | $ | 103 |  |  | $ | 455 |  |  | $ | 1,208 |  |  | $ | 2,549 |  |  | $ | 3,642 |  |  | $ | 7,964 |  |

[0000858877-22-000013:notes:179]
| July 31, 2021 |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 29, 2017 |  | July 28, 2018 |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | Total |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 20 |  |  | $ | 100 |  |  | $ | 168 |  |  | $ | 282 |  |  | $ | 227 |  |  | $ | 799 |  |
| 5 to 6 | 1 |  |  | 17 |  |  | 65 |  |  | 187 |  |  | 285 |  |  | 231 |  |  | 786 |  |
| 7 and Higher | — |  |  | 2 |  |  | 6 |  |  | 12 |  |  | 23 |  |  | 4 |  |  | 47 |  |
| Total Lease Receivables | $ | 3 |  |  | $ | 39 |  |  | $ | 171 |  |  | $ | 367 |  |  | $ | 590 |  |  | $ | 462 |  |  | $ | 1,632 |  |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 4 |  |  | $ | 86 |  |  | $ | 134 |  |  | $ | 577 |  |  | $ | 990 |  |  | $ | 1,552 |  |  | $ | 3,343 |  |
| 5 to 6 | — |  |  | 19 |  |  | 75 |  |  | 202 |  |  | 505 |  |  | 925 |  |  | 1,726 |  |
| 7 and Higher | 1 |  |  | 2 |  |  | 4 |  |  | 50 |  |  | 43 |  |  | 34 |  |  | 134 |  |
| Total Loan Receivables | $ | 5 |  |  | $ | 107 |  |  | $ | 213 |  |  | $ | 829 |  |  | $ | 1,538 |  |  | $ | 2,511 |  |  | $ | 5,203 |  |
| Financed Service Contracts: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | — |  |  | $ | 38 |  |  | $ | 26 |  |  | $ | 106 |  |  | $ | 252 |  |  | $ | 1,053 |  |  | $ | 1,475 |  |
| 5 to 6 | — |  |  | 6 |  |  | 26 |  |  | 105 |  |  | 302 |  |  | 520 |  |  | 959 |  |
| 7 and Higher | — |  |  | — |  |  | 1 |  |  | 6 |  |  | 7 |  |  | 5 |  |  | 19 |  |
| Total Financed Service Contracts | $ | — |  |  | $ | 44 |  |  | $ | 53 |  |  | $ | 217 |  |  | $ | 561 |  |  | $ | 1,578 |  |  | $ | 2,453 |  |
| Total | $ | 8 |  |  | $ | 190 |  |  | $ | 437 |  |  | $ | 1,413 |  |  | $ | 2,689 |  |  | $ | 4,551 |  |  | $ | 9,288 |  |

[0000858877-22-000013:notes:180]
The following tables present the aging analysis of gross receivables as of July 30, 2022 and July 31, 2021 (in millions):

[0000858877-22-000013:notes:181]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| July 30, 2022 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 8 |  |  | $ | 6 |  |  | $ | 26 |  |  | $ | 40 |  |  | $ | 1,082 |  |  | $ | 1,122 |  |  | $ | 7 |  |  | $ | 11 |  |  | $ | 11 |  |
| Loan receivables | 72 |  |  | 36 |  |  | 48 |  |  | 156 |  |  | 4,500 |  |  | 4,656 |  |  | 8 |  |  | 58 |  |  | 58 |  |
| Financed service contracts | 26 |  |  | 26 |  |  | 81 |  |  | 133 |  |  | 2,053 |  |  | 2,186 |  |  | 6 |  |  | 2 |  |  | 2 |  |
| Total | $ | 106 |  |  | $ | 68 |  |  | $ | 155 |  |  | $ | 329 |  |  | $ | 7,635 |  |  | $ | 7,964 |  |  | $ | 21 |  |  | $ | 71 |  |  | $ | 71 |  |

[0000858877-22-000013:notes:182]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| July 31, 2021 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 21 |  |  | $ | 17 |  |  | $ | 29 |  |  | $ | 67 |  |  | $ | 1,565 |  |  | $ | 1,632 |  |  | $ | 1 |  |  | $ | 33 |  |  | $ | 26 |  |
| Loan receivables | 71 |  |  | 17 |  |  | 35 |  |  | 123 |  |  | 5,080 |  |  | 5,203 |  |  | 4 |  |  | 33 |  |  | 33 |  |
| Financed service contracts | 18 |  |  | 13 |  |  | 18 |  |  | 49 |  |  | 2,404 |  |  | 2,453 |  |  | 3 |  |  | 3 |  |  | 3 |  |
| Total | $ | 110 |  |  | $ | 47 |  |  | $ | 82 |  |  | $ | 239 |  |  | $ | 9,049 |  |  | $ | 9,288 |  |  | $ | 8 |  |  | $ | 69 |  |  | $ | 62 |  |

[0000858877-22-000013:notes:183]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract.

[0000858877-22-000013:notes:184]
(c)Allowance for Credit Loss Rollforward

[0000858877-22-000013:notes:185]
The allowances for credit loss and the related financing receivables are summarized as follows (in millions):

[0000858877-22-000013:notes:186]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 31, 2021 | $ | 38 |  |  | $ | 86 |  |  | $ | 3 |  |  | $ | 127 |  |
| Provisions (benefits) | (13) |  |  | 4 |  |  | — |  |  | (9) |  |
| Recoveries (write-offs), net | (2) |  |  | — |  |  | — |  |  | (2) |  |
| Foreign exchange and other | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Allowance for credit loss as of July 30, 2022 | $ | 23 |  |  | $ | 100 |  |  | $ | 3 |  |  | $ | 126 |  |

[0000858877-22-000013:notes:187]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 25, 2020 | $ | 48 |  |  | $ | 81 |  |  | $ | 9 |  |  | $ | 138 |  |
| Provisions (benefits) | (10) |  |  | (12) |  |  | (5) |  |  | (27) |  |
| Recoveries (write-offs), net | (1) |  |  | (1) |  |  | — |  |  | (2) |  |
| Foreign exchange and other | 1 |  |  | 18 |  |  | (1) |  |  | 18 |  |
| Allowance for credit loss as of July 31, 2021 | $ | 38 |  |  | $ | 86 |  |  | $ | 3 |  |  | $ | 127 |  |

[0000858877-22-000013:notes:188]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 27, 2019 | $ | 46 |  |  | $ | 71 |  |  | $ | 9 |  |  | $ | 126 |  |
| Provisions (benefits) | 5 |  |  | 32 |  |  | 1 |  |  | 38 |  |
| Recoveries (write-offs), net | (3) |  |  | (19) |  |  | — |  |  | (22) |  |
| Foreign exchange and other | — |  |  | (3) |  |  | (1) |  |  | (4) |  |
| Allowance for credit loss as of July 25, 2020 | $ | 48 |  |  | $ | 81 |  |  | $ | 9 |  |  | $ | 138 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-22-000013:notes:189]
Available-for-Sale Debt and Equity Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-22-000013:notes:190]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-22-000013:notes:191]
| July 30, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,287 |  |  | $ | — |  |  | $ | (49) |  |  | $ | 1,238 |  |
| U.S. government agency securities | 142 |  |  | — |  |  | (4) |  |  | 138 |  |
| Non-U.S. government and agency securities | 272 |  |  | — |  |  | — |  |  | 272 |  |
| Corporate debt securities | 8,127 |  |  | 2 |  |  | (311) |  |  | 7,818 |  |
| U.S. agency mortgage-backed securities | 2,134 |  |  | — |  |  | (158) |  |  | 1,976 |  |
| Commercial paper | 255 |  |  | — |  |  | — |  |  | 255 |  |
| Certificates of deposit | 250 |  |  | — |  |  | — |  |  | 250 |  |
| Total | $ | 12,467 |  |  | $ | 2 |  |  | $ | (522) |  |  | $ | 11,947 |  |

[0000858877-22-000013:notes:192]
| July 31, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,773 |  |  | $ | 21 |  |  | $ | — |  |  | $ | 1,794 |  |
| U.S. government agency securities | 152 |  |  | — |  |  | — |  |  | 152 |  |
| Non-U.S. government and agency securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Corporate debt securities | 8,727 |  |  | 213 |  |  | (30) |  |  | 8,910 |  |
| U.S. agency mortgage-backed securities | 2,838 |  |  | 34 |  |  | (10) |  |  | 2,862 |  |
| Commercial paper | 1,190 |  |  | — |  |  | — |  |  | 1,190 |  |
| Certificates of deposit | 295 |  |  | — |  |  | — |  |  | 295 |  |
| Total | $ | 14,978 |  |  | $ | 268 |  |  | $ | (40) |  |  | $ | 15,206 |  |

[0000858877-22-000013:notes:193]
Net unsettled investment sales as of July 30, 2022 were $70 million and were included in other current assets.

[0000858877-22-000013:notes:194]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-22-000013:notes:195]
| Years Ended | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Gross realized gains | $ | 27 |  |  | $ | 55 |  |  | $ | 70 |  |
| Gross realized losses | (18) |  |  | (2) |  |  | (28) |  |
| Total | $ | 9 |  |  | $ | 53 |  |  | $ | 42 |  |

[0000858877-22-000013:notes:196]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at July 30, 2022 and July 31, 2021 (in millions):

[0000858877-22-000013:notes:197]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 30, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,110 |  |  | $ | (44) |  |  | $ | 120 |  |  | $ | (5) |  |  | $ | 1,230 |  |  | $ | (49) |  |
| U.S. government agency securities | 114 |  |  | (2) |  |  | 24 |  |  | (2) |  |  | 138 |  |  | (4) |  |
| Non-U.S. government and agency securities | 264 |  |  | — |  |  | — |  |  | — |  |  | 264 |  |  | — |  |
| Corporate debt securities | 6,920 |  |  | (240) |  |  | 422 |  |  | (37) |  |  | 7,342 |  |  | (277) |  |
| U.S. agency mortgage-backed securities | 1,305 |  |  | (96) |  |  | 615 |  |  | (62) |  |  | 1,920 |  |  | (158) |  |
| Total | $ | 9,713 |  |  | $ | (382) |  |  | $ | 1,181 |  |  | $ | (106) |  |  | $ | 10,894 |  |  | $ | (488) |  |

[0000858877-22-000013:notes:198]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 31, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 468 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 468 |  |  | $ | — |  |
| U.S. government agency securities | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |
| Corporate debt securities | 1,086 |  |  | (5) |  |  | 6 |  |  | — |  |  | 1,092 |  |  | (5) |  |
| U.S. agency mortgage-backed securities | 1,293 |  |  | (10) |  |  | 13 |  |  | — |  |  | 1,306 |  |  | (10) |  |
| Commercial paper | 37 |  |  | — |  |  | — |  |  | — |  |  | 37 |  |  | — |  |
| Total | $ | 2,910 |  |  | $ | (15) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 2,929 |  |  | $ | (15) |  |

[0000858877-22-000013:notes:199]
The following table summarizes the maturities of our available-for-sale debt investments as of July 30, 2022 (in millions):

[0000858877-22-000013:notes:200]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 3,273 |  |  | $ | 3,219 |  |
| After 1 year through 5 years | 6,946 |  |  | 6,646 |  |
| After 5 years through 10 years | 111 |  |  | 103 |  |
| After 10 years | 3 |  |  | 3 |  |
| Mortgage-backed securities with no single maturity | 2,134 |  |  | 1,976 |  |
| Total | $ | 12,467 |  |  | $ | 11,947 |  |

[0000858877-22-000013:notes:201]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-22-000013:notes:202]
(b)Summary of Equity Investments

[0000858877-22-000013:notes:203]
We held marketable equity securities of $241 million and $137 million as of July 30, 2022 and July 31, 2021, respectively. We recognized a net unrealized loss of $38 million during fiscal 2022 and a net unrealized gain of $8 million during fiscal 2021 on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $32 million and $39 million for fiscal 2022 and 2021, respectively. We held equity interests in certain private equity funds of $1.1 billion and $0.9 billion as of July 30, 2022 and July 31, 2021, respectively, which are accounted for under the NAV practical expedient.

[0000858877-22-000013:notes:204]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of July 30, 2022, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
As of July 30, 2022, the carrying value of our investments in privately held companies was $1.9 billion. Of the total carrying value of our investments in privately held companies as of July 30, 2022, $1.1 billion of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $0.4 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-22-000013:notes:205]
Fair Value 
(a)Assets and Liabilities Measured at Fair Value on a Recurring Basis

[0000858877-22-000013:notes:206]
Assets and liabilities measured at fair value on a recurring basis were as follows (in millions):

[0000858877-22-000013:notes:207]
|  | JULY 30, 2022 |  | JULY 31, 2021 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 3,930 |  |  | $ | — |  |  | $ | 3,930 |  |  | $ | 5,694 |  |  | $ | — |  |  | $ | 5,694 |  |
| Commercial paper | — |  |  | 72 |  |  | 72 |  |  | — |  |  | 114 |  |  | 114 |  |
| Certificates of deposit | — |  |  | 32 |  |  | 32 |  |  | — |  |  | — |  |  | — |  |
| U.S. government securities | — |  |  | 12 |  |  | 12 |  |  | — |  |  | 300 |  |  | 300 |  |
| Corporate debt securities | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 1,238 |  |  | 1,238 |  |  | — |  |  | 1,794 |  |  | 1,794 |  |
| U.S. government agency securities | — |  |  | 138 |  |  | 138 |  |  | — |  |  | 152 |  |  | 152 |  |
| Non-U.S. government and agency securities | — |  |  | 272 |  |  | 272 |  |  | — |  |  | 3 |  |  | 3 |  |
| Corporate debt securities | — |  |  | 7,818 |  |  | 7,818 |  |  | — |  |  | 8,910 |  |  | 8,910 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,976 |  |  | 1,976 |  |  | — |  |  | 2,862 |  |  | 2,862 |  |
| Commercial paper | — |  |  | 255 |  |  | 255 |  |  | — |  |  | 1,190 |  |  | 1,190 |  |
| Certificates of deposit | — |  |  | 250 |  |  | 250 |  |  | — |  |  | 295 |  |  | 295 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 241 |  |  | — |  |  | 241 |  |  | 137 |  |  | — |  |  | 137 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 1,500 |  |  | — |  |  | 1,500 |  |  | 750 |  |  | — |  |  | 750 |  |
| Derivative assets | — |  |  | 78 |  |  | 78 |  |  | — |  |  | 126 |  |  | 126 |  |
| Total | $ | 5,671 |  |  | $ | 12,142 |  |  | $ | 17,813 |  |  | $ | 6,581 |  |  | $ | 15,746 |  |  | $ | 22,327 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 89 |  |  | $ | 89 |  |  | $ | — |  |  | $ | 20 |  |  | $ | 20 |  |
| Total | $ | — |  |  | $ | 89 |  |  | $ | 89 |  |  | $ | — |  |  | $ | 20 |  |  | $ | 20 |  |

[0000858877-22-000013:notes:208]
(b)Assets Measured at Fair Value on a Nonrecurring Basis

[0000858877-22-000013:notes:209]
Our non-marketable equity securities using the measurement alternative are adjusted to fair value on a non-recurring basis. Adjustments are made when observable transactions for identical or similar investments of the same issuer occur, or due to impairment. These securities are classified as Level 3 in the fair value hierarchy because we estimate the value based on valuation methods using the observable transaction price at the transaction date and other unobservable inputs such as volatility, rights, and obligations of the securities we hold.

[0000858877-22-000013:notes:210]
The fair value for purchased intangibles assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation. Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable. See Note 5.

[0000858877-22-000013:notes:211]
(c)Other Fair Value Disclosures

[0000858877-22-000013:notes:212]
The fair value of our short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables and financed service contracts as of July 30, 2022 and July 31, 2021 was $3.4 billion and $4.0 billion, respectively. The estimated fair value of our long-term loan receivables and financed service contracts approximates their carrying value. We use unobservable inputs in determining 
discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.As of July 30, 2022 and July 31, 2021, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of July 30, 2022, the fair value of our senior notes was $9.7 billion, with a carrying amount of $8.9 billion. This compares to a fair value of $13.7 billion and a carrying amount of $11.5 billion as of July 31, 2021. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:DebtDisclosureTextBlock

[0000858877-22-000013:notes:213]
Borrowings 
(a)Short-Term Debt

[0000858877-22-000013:notes:214]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-22-000013:notes:215]
|  | July 30, 2022 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 499 |  |  | 2.68 | % |  | $ | 2,508 |  |  | 1.75 | % |
| Commercial paper | 600 |  |  | 2.05 | % |  | — |  |  | — |  |
| Total | $ | 1,099 |  |  |  |  | $ | 2,508 |  |  |  |

[0000858877-22-000013:notes:216]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-22-000013:notes:217]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-22-000013:notes:218]
(b)Long-Term Debt

[0000858877-22-000013:notes:219]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-22-000013:notes:220]
|  |  |  | July 30, 2022 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | — |  |  | — |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.69% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.20% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,000 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (75) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (10) |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 8,915 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 499 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,416 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 8,915 |  |  |  |  | $ | 11,526 |  |  |  |

[0000858877-22-000013:notes:221]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $1.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-22-000013:notes:222]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of July 30, 2022, we were in compliance with all debt covenants.

[0000858877-22-000013:notes:223]
As of July 30, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-22-000013:notes:224]
| Fiscal Year | Amount |
| 2023 | $ | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 9,000 |  |

[0000858877-22-000013:notes:225]
(c)Credit Facility

[0000858877-22-000013:notes:226]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of July 30, 2022, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.

[0000858877-22-000013:notes:227]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-22-000013:notes:228]
Derivative Instruments 
(a)Summary of Derivative Instruments

[0000858877-22-000013:notes:229]
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We do, however, seek to mitigate such risks by limiting our counterparties to major financial institutions and requiring collateral in certain cases. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-22-000013:notes:230]
The fair values of our derivative instruments and the line items on the Consolidated Balance Sheets to which they were recorded are summarized as follows (in millions):

[0000858877-22-000013:notes:231]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | July 30, 2022 |  | July 31, 2021 |  | Balance Sheet Line Item |  | July 30, 2022 |  | July 31, 2021 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 55 |  |  | $ | 14 |  |  | Other current liabilities |  | $ | — |  |  | $ | 3 |  |
| Foreign currency derivatives | Other assets |  | 9 |  |  | 1 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other current assets |  | — |  |  | 9 |  |  | Other current liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other assets |  | — |  |  | 99 |  |  | Other long-term liabilities |  | 10 |  |  | — |  |
| Total |  |  | 64 |  |  | 123 |  |  |  |  | 10 |  |  | 3 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 14 |  |  | 3 |  |  | Other current liabilities |  | 69 |  |  | 16 |  |
| Foreign currency derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 9 |  |  | 1 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 1 |  |  | — |  |
| Total |  |  | 14 |  |  | 3 |  |  |  |  | 79 |  |  | 17 |  |
| Total |  |  | $ | 78 |  |  | $ | 126 |  |  |  |  | $ | 89 |  |  | $ | 20 |  |

[0000858877-22-000013:notes:232]
The following amounts were recorded on the Consolidated Balance Sheets related to cumulative basis adjustments for our fair value hedges (in millions):

[0000858877-22-000013:notes:233]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | July 30,2022 |  | July 31,2021 |  | July 30,2022 |  | July 31,2021 |
| Short-term debt |  | $ | — |  |  | $ | (508) |  |  | $ | — |  |  | $ | (9) |  |
| Long-term debt |  | $ | (1,487) |  |  | $ | (1,594) |  |  | $ | 10 |  |  | $ | (97) |  |

[0000858877-22-000013:notes:234]
The effect of derivative instruments designated as fair value hedges, recognized in interest and other income (loss), net is summarized as follows (in millions):

[0000858877-22-000013:notes:235]
|  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
|  |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Interest rate derivatives: |  |  |  |  |  |  |
| Hedged items |  | $ | 116 |  |  | $ | 65 |  |  | $ | (98) |  |
| Derivatives designated as hedging instruments |  | (118) |  |  | (67) |  |  | 101 |  |
| Total |  | $ | (2) |  |  | $ | (2) |  |  | $ | 3 |  |

[0000858877-22-000013:notes:236]
The effect on the Consolidated Statements of Operations of derivative instruments not designated as hedges is summarized as follows (in millions):

[0000858877-22-000013:notes:237]
|  |  |  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (237) |  |  | $ | 2 |  |  | $ | (5) |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | (92) |  |  | 157 |  |  | 15 |  |
| Equity derivatives |  | Other income (loss), net |  | 9 |  |  | 20 |  |  | 9 |  |
| Total |  |  |  | $ | (320) |  |  | $ | 179 |  |  | $ | 19 |  |

[0000858877-22-000013:notes:238]
The notional amounts of our outstanding derivatives are summarized as follows (in millions):

[0000858877-22-000013:notes:239]
|  | July 30, 2022 |  | July 31, 2021 |
| Foreign currency derivatives | $ | 4,521 |  |  | $ | 4,139 |  |
| Interest rate derivatives | 1,500 |  |  | 2,000 |  |
| Total return swaps—deferred compensation | 651 |  |  | 730 |  |
| Total | $ | 6,672 |  |  | $ | 6,869 |  |

[0000858877-22-000013:notes:240]
(b)Offsetting of Derivative Instruments

[0000858877-22-000013:notes:241]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty.

[0000858877-22-000013:notes:242]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral provided for was $14 million as of July 30, 2022 and the net cash collateral received was $109 million as of July 31, 2021. Including the effects of collateral, this results in a net derivative asset of $3 million and a net derivative liability of $3 million as of July 30, 2022 and July 31, 2021, respectively.

[0000858877-22-000013:notes:243]
(c)Foreign Currency Exchange Risk

[0000858877-22-000013:notes:244]
We conduct business globally in numerous currencies. Therefore, we are exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, we enter into foreign currency contracts. We do not enter into such contracts for speculative purposes.

[0000858877-22-000013:notes:245]
We hedge forecasted foreign currency transactions related to certain revenues, operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The derivative instrument’s gain or loss is initially reported as a component of accumulated other comprehensive income (AOCI) and subsequently reclassified into earnings when the hedged exposure affects earnings.

[0000858877-22-000013:notes:246]
We enter into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, long-term customer financings and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of intercompany balances, other current assets, or liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-22-000013:notes:247]
We hedge certain net investments in our foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on our net investment in those foreign subsidiaries. These derivative instruments generally have maturities of up to six months.

[0000858877-22-000013:notes:248]
(d)Interest Rate Risk

[0000858877-22-000013:notes:249]
We hold interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2024 through 2025. Under these interest rate swaps, we receive fixed-rate interest payments and make interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.

[0000858877-22-000013:notes:250]
(e)Equity Price Risk

[0000858877-22-000013:notes:251]
We hold marketable equity securities in our portfolio that are subject to price risk. To diversify our overall portfolio, we also hold equity derivatives that are not designated as accounting hedges. The change in the fair value of each of these investment types are included in other income (loss), net. 
We are also exposed to variability in compensation charges related to certain deferred compensation obligations to employees. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure and offset the related compensation expense.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-22-000013:notes:252]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-22-000013:notes:253]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-22-000013:notes:254]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-22-000013:notes:255]
| Commitments by Period | July 30,2022 |  | July 31,2021 |
| Less than 1 year | $ | 9,954 |  |  | $ | 6,903 |  |
| 1 to 3 years | 2,240 |  |  | 1,806 |  |
| 3 to 5 years | 770 |  |  | 1,545 |  |
| Total | $ | 12,964 |  |  | $ | 10,254 |  |

[0000858877-22-000013:notes:256]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 30, 2022 and July 31, 2021, the liability for these purchase commitments was $313 million and $151 million, respectively, and was included in other current liabilities.

[0000858877-22-000013:notes:257]
(b)Other Commitments

[0000858877-22-000013:notes:258]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-22-000013:notes:259]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-22-000013:notes:260]
|  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Compensation expense related to acquisitions | $ | 271 |  |  | $ | 262 |  |  | $ | 214 |  |

[0000858877-22-000013:notes:261]
As of July 30, 2022, we estimated that future cash compensation expense of up to $468 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-22-000013:notes:262]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.4 billion and $0.2 billion as of July 30, 2022 and July 31, 2021, respectively.

[0000858877-22-000013:notes:263]
(c)Product Warranties

[0000858877-22-000013:notes:264]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-22-000013:notes:265]
|  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Balance at beginning of fiscal year | $ | 336 |  |  | $ | 331 |  |  | $ | 342 |  |
| Provisions for warranties issued | 415 |  |  | 496 |  |  | 561 |  |
| Adjustments for pre-existing warranties | 3 |  |  | — |  |  | (8) |  |
| Settlements | (421) |  |  | (491) |  |  | (564) |  |
| Balance at end of fiscal year | $ | 333 |  |  | $ | 336 |  |  | $ | 331 |  |

[0000858877-22-000013:notes:266]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-22-000013:notes:267]
(d)Financing and Other Guarantees

[0000858877-22-000013:notes:268]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-22-000013:notes:269]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $27.9 billion, $26.7 billion, and $26.9 billion in fiscal 2022, 2021, and 2020, respectively. The balance of the channel partner financing subject to guarantees was $1.4 billion and $1.3 billion as of July 30, 2022 and July 31, 2021, respectively.

[0000858877-22-000013:notes:270]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at July 30, 2022 and July 31, 2021, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-22-000013:notes:271]
|  | July 30, 2022 |  | July 31, 2021 |
| Maximum potential future payments | $ | 188 |  |  | $ | 155 |  |
| Deferred revenue | (9) |  |  | (16) |  |
| Total | $ | 179 |  |  | $ | 139 |  |

[0000858877-22-000013:notes:272]
(e)Indemnifications

[0000858877-22-000013:notes:273]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-22-000013:notes:274]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-22-000013:notes:275]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-22-000013:notes:276]
(f)Legal Proceedings

[0000858877-22-000013:notes:277]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-22-000013:notes:278]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state

[0000858877-22-000013:notes:279]
and federal tax authorities aggregate to $156 million for the alleged evasion of import and other taxes, $822 million for interest, and $387 million for various penalties, all determined using an exchange rate as of July 30, 2022.

[0000858877-22-000013:notes:280]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-22-000013:notes:281]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted claims against us in the U.S. District Court for the District of Delaware (“D. Del.”), accusing our products and services related to network intrusion detection of infringing two patents. After a trial, SRI obtained a verdict against us, and we appealed to the United States Court of Appeals for the Federal Circuit (“Federal Circuit”) which was ultimately unsuccessful. In resolution of this matter, we have paid the SRI judgments, including attorneys’ fees and post-judgment royalties and interest, in the aggregate amount of approximately $60 million. On May 17, 2022, the District Court entered a final order in the case requiring us to pay SRI additional post-judgment interest of approximately $1 million. We made the payment and the case is now concluded.

[0000858877-22-000013:notes:282]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services (including our Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal U.S. patents. Following a number of successful petitions filed with the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office (“PTO”) that were sustained on appeal, the district court case moved forward on five asserted U.S. patents not subject to the IPR Proceedings. The district court conducted a bench trial by videoconference from May 6, 2020 to June 25, 2020. On October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The district court awarded Centripetal $1.9 billion, comprised of $756 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $14 million. The district court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $168 million and a maximum annual royalty of $300 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $84 million and a maximum annual royalty of $150 million. We appealed the district court’s judgment as to the four patents found valid and infringed to the Federal Circuit. On June 23, 2022, the Federal Circuit vacated the district court’s final judgment, remanded the case back to the district court to be assigned to a new judge and ordered the district court to conduct additional proceedings.

[0000858877-22-000013:notes:283]
Centripetal filed complaints in the District Court of Dusseldorf in Germany (“German Court”) against Cisco Systems GmbH and Cisco Systems, Inc., asserting a total of six patents. On April 29, 2020 and April 30, 2020, Centripetal asserted three European patents, seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. district court proceedings, one of which has been invalidated by the PTAB. On June 22, 2021, Centripetal amended one of its complaints to assert one additional European patent and one additional German Utility Model patent. On December 10, 2021, the German Court rejected Centripetal’s complaints on two patents, and Centripetal has appealed. A hearing for a Cisco nullity action in the Federal Patent Court in Germany on one of those two patents occurred on August 1, 2022, and we are waiting for the Court’s opinion. On December 21, 2021, the German Court stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. On May 17, 2022, Centripetal withdrew its complaint for infringement of the German Utility Model patent. The proceedings on Centripetal’s European patent filed on June 22, 2021 remains pending.

[0000858877-22-000013:notes:284]
On February 14, 2022, Centripetal filed an additional complaint asserting infringement of another patent issued by the European Patent Office. Centripetal seeks both injunctive relief and damages on these patents. We are assessing the complaint and are preparing our defense.

[0000858877-22-000013:notes:285]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of either litigation at this time. If we do not prevail in either litigation, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-22-000013:notes:286]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in E.D. Tex., seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. As of November 27, 2020, the PTO preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings. On January 13, 2021, the court entered an order staying the case pending the conclusion of the ex parte reexamination proceedings (“Reexamination Proceedings”). While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of

[0000858877-22-000013:notes:287]
this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in court, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-22-000013:notes:288]
On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) (which we subsequently acquired) in D. Del, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot has asserted in its E.D. Tex. case. On September 3, 2021, the court stayed the case pending the ultimate resolution of the Reexamination Proceedings. Due to the early stage of the litigation as well as uncertainties in the litigation processes, we are unable, at this time, to reasonably estimate a potential range of loss, if any, or the ultimate outcome of this litigation.

[0000858877-22-000013:notes:289]
On September 28, 2021, Cisco and Acacia filed a declaratory judgment action of noninfringement against Ramot in D. Del on another patent in the same family as those Ramot asserted in the previous litigations. Ramot counterclaimed for patent infringement seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Due to the early stage of the litigation as well as uncertainties in the litigation processes, we are unable, at this time, to reasonably estimate a potential range of loss, if any, or the ultimate outcome of this litigation.

[0000858877-22-000013:notes:290]
On May 24, 2022, Cisco and Acacia filed a declaratory judgment action of noninfringement against Ramot in D. Del on another patent in the same family as those Ramot asserted in the previous litigations. Ramot filed suit against Cisco in E.D. Tex. alleging infringement of the same patent. Ramot seeks damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Due to the early stage of these litigations as well as uncertainties in the litigation processes, we are unable, at this time, to reasonably estimate a potential range of loss, if any, or the ultimate outcome of these litigations.

[0000858877-22-000013:notes:291]
Viasat     On January 21, 2016, Viasat, Inc. (“Viasat”) filed suit against Acacia (which we subsequently acquired) in the California Superior Court for San Diego County (“SDSC”) seeking unpaid royalties for breach of contract and the implied covenant of good faith and fair dealing, and damages for trade secret misappropriation for certain products (“Viasat 1”). Acacia counterclaimed for patent and trade secret misappropriation, contract, and unfair competition claims. On July 17, 2019, the jury found for Viasat on its contract claims, and awarded Viasat approximately $49 million for unpaid royalties through 2018. The jury further found that Acacia willfully misappropriated Viasat’s trade secrets and awarded Viasat $1. On Acacia’s counterclaims, the jury found for Acacia on its contract and trade secret claims and awarded Acacia $1. Both Acacia and Viasat appealed to the California Court of Appeal, Fourth Appellate District (“CCA”). On May 23, 2022, the CCA affirmed the judgment of approximately $49 million, plus post-judgment interest and costs, for Viasat on its breach of contract claim for unpaid royalties, but reversed the judgments for Viasat for breach of the implied covenant of good faith and fair dealing, and for trade secret misappropriation. On July 8, 2022, a satisfaction of judgment was entered as to Acacia, resolving all claims and disputes as related to Viasat 1.

[0000858877-22-000013:notes:292]
On November 6, 2019, Viasat filed a second suit in SDSC, alleging contract and trade secret claims for Acacia products sold from January 1, 2019 forward (“Viasat 2”). On February 28, 2020, the court stayed Viasat 2 pending the appeal in Viasat 1. On June 9, 2020, Viasat filed a third suit in SDSC (“Viasat 3”). In Viasat 3, Viasat alleges contract and trade secrets claims for sales of additional Acacia products. On August 11, 2020, the court stayed Viasat 3 pending the appeal in Viasat 1.

[0000858877-22-000013:notes:293]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court - Business Litigation Session against ViaSat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation. On April 5, 2018, ViaSat counterclaimed with contract, trade secret, and unfair competition claims (collectively, with Viasat 2 and Viasat 3, the “Viasat Cases”). On December 13, 2018, the Massachusetts court entered an order staying the Massachusetts litigation, which has been extended to October 21, 2022.

[0000858877-22-000013:notes:294]
We are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If Acacia does not prevail, we believe that any relief ultimately assessed in any of the Viasat Cases would not have a material effect on our Consolidated Financial Statements.

[0000858877-22-000013:notes:295]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager product infringes three U.S. patents. Egenera seeks damages, including enhanced damages for allegations of willful infringement, and an injunction. Two of the asserted patents have been dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. The court began a jury trial on the remaining patent on August 2, 2022. On August 15, 2022, the jury returned a verdict finding that Cisco does not infringe Egenera’s patent. The parties will file post-trial motions prior to the entry of final judgment in the case.
In addition, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part I, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-22-000013:notes:296]
Stockholders’ Equity 
(a)Cash Dividends on Shares of Common Stock

[0000858877-22-000013:notes:297]
We declared and paid cash dividends of $1.50, $1.46 and $1.42 per common share, or $6.2 billion during each of fiscal 2022 and 2021 and $6.0 billion during fiscal 2020, on our outstanding common stock.

[0000858877-22-000013:notes:298]
On August 23, 2022, our Board of Directors declared a quarterly dividend of $0.38 per common share to be paid on October 26, 2022, to all stockholders of record as of the close of business on October 5, 2022. Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-22-000013:notes:299]
(b)Stock Repurchase Program

[0000858877-22-000013:notes:300]
In September 2001, our Board of Directors authorized a stock repurchase program. As of July 30, 2022, the remaining authorized amount for stock repurchases under this program was approximately $15.2 billion with no termination date.

[0000858877-22-000013:notes:301]
A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-22-000013:notes:302]
| Years Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| July 30, 2022 |  | 146 |  |  | $ | 52.82 |  |  | $ | 7,734 |  |
| July 31, 2021 |  | 64 |  |  | $ | 45.48 |  |  | $ | 2,902 |  |
| July 25, 2020 |  | 59 |  |  | $ | 44.36 |  |  | $ | 2,619 |  |

[0000858877-22-000013:notes:303]
There were $70 million and $25 million in stock repurchases that were pending settlement as of July 30, 2022 and July 31, 2021, respectively. There was no stock repurchases that were pending settlement as of July 25, 2020.

[0000858877-22-000013:notes:304]
The purchase price for the shares of our stock repurchased is reflected as a reduction to stockholders’ equity.

[0000858877-22-000013:notes:305]
We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings or an increase to accumulated deficit and (ii) a reduction of common stock and additional paid-in capital.

[0000858877-22-000013:notes:306]
(c)Preferred Stock

[0000858877-22-000013:notes:307]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock in one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights, if any, of such series, and any qualifications, limitations or restrictions thereof, of the shares of such series. As of July 30, 2022, we had not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-22-000013:notes:308]
Employee Benefit Plans  
(a)Employee Stock Incentive Plans

[0000858877-22-000013:notes:309]
We have one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with us. The number and frequency of share-based awards are based on competitive practices, our operating results, government regulations, and other factors. Our primary stock incentive plan is summarized as follows:

[0000858877-22-000013:notes:310]
The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions. Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. The 2005 Plan may be terminated by our Board of Directors at any time and for any reason, and is currently set to terminate at the 2030 Annual Meeting unless re-adopted or extended by our stockholders prior to or on such date.

[0000858877-22-000013:notes:311]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of July 30, 2022, 205 million shares were authorized for future grant under the 2005 Plan.

[0000858877-22-000013:notes:312]
(b)Employee Stock Purchase Plan

[0000858877-22-000013:notes:313]
We have an Employee Stock Purchase Plan under which eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. We issued 18 million, 17 million, and 18 million shares under the Employee Stock Purchase Plan in fiscal 2022, 2021, and 2020, respectively. As of July 30, 2022, 107 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-22-000013:notes:314]
(c)Summary of Share-Based Compensation Expense

[0000858877-22-000013:notes:315]
Share-based compensation expense consists primarily of expenses for RSUs, stock purchase rights, and stock options, granted to employees or assumed from acquisitions. The following table summarizes share-based compensation expense (in millions):

[0000858877-22-000013:notes:316]
| Years Ended | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Cost of sales—product | $ | 112 |  |  | $ | 99 |  |  | $ | 93 |  |
| Cost of sales—service | 199 |  |  | 176 |  |  | 144 |  |
| Share-based compensation expense in cost of sales | 311 |  |  | 275 |  |  | 237 |  |
| Research and development | 790 |  |  | 694 |  |  | 592 |  |
| Sales and marketing | 572 |  |  | 540 |  |  | 500 |  |
| General and administrative | 212 |  |  | 226 |  |  | 215 |  |
| Restructuring and other charges | 1 |  |  | 26 |  |  | 25 |  |
| Share-based compensation expense in operating expenses | 1,575 |  |  | 1,486 |  |  | 1,332 |  |
| Total share-based compensation expense | $ | 1,886 |  |  | $ | 1,761 |  |  | $ | 1,569 |  |
| Income tax benefit for share-based compensation | $ | 457 |  |  | $ | 387 |  |  | $ | 452 |  |

[0000858877-22-000013:notes:317]
As of July 30, 2022, the total compensation cost related to unvested share-based awards not yet recognized was $4.3 billion, which is expected to be recognized over approximately 2.6 years on a weighted-average basis.

[0000858877-22-000013:notes:318]
(d)Restricted Stock Unit Awards

[0000858877-22-000013:notes:319]
A summary of the restricted stock and stock unit activity, which includes time-based and performance-based or market-based RSUs, is as follows (in millions, except per-share amounts):

[0000858877-22-000013:notes:320]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 27, 2019 | 100 |  |  | $ | 38.66 |  |  |  |
| Granted and assumed | 49 |  |  | 42.61 |  |  |  |
| Vested | (44) |  |  | 35.20 |  |  | $ | 2,045 |  |
| Canceled/forfeited/other | (9) |  |  | 40.45 |  |  |  |
| UNVESTED BALANCE AT JULY 25, 2020 | 96 |  |  | 42.03 |  |  |  |
| Granted and assumed | 51 |  |  | 41.89 |  |  |  |
| Vested | (39) |  |  | 39.63 |  |  | $ | 1,813 |  |
| Canceled/forfeited/other | (14) |  |  | 42.13 |  |  |  |
| UNVESTED BALANCE AT JULY 31, 2021 | 94 |  |  | 42.93 |  |  |  |
| Granted and assumed | 52 |  |  | 50.06 |  |  |  |
| Vested | (37) |  |  | 42.27 |  |  | $ | 1,979 |  |
| Canceled/forfeited/other | (12) |  |  | 45.63 |  |  |  |
| UNVESTED BALANCE AT JULY 30, 2022 | 97 |  |  | $ | 46.67 |  |  |  |

[0000858877-22-000013:notes:321]
(e)Valuation of Employee Share-Based Awards

[0000858877-22-000013:notes:322]
Time-based restricted stock units and PRSUs that are based on our financial performance metrics or non-financial operating goals are valued using the market value of our common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, we estimated the fair value of the total shareholder return (TSR) component of the PRSUs using a Monte Carlo simulation model. The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-22-000013:notes:323]
|  | RESTRICTED STOCK UNITS |
| Years Ended | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Number of shares granted (in millions) | 50 |  |  | 48 |  |  | 47 |  |
| Grant date fair value per share | $ | 49.68 |  |  | $ | 42.04 |  |  | $ | 42.68 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 2.9 | % |  | 3.3 | % |  | 3.1 | % |
| Range of risk-free interest rates | 0.0% – 3.0% |  | 0.0% – 0.9% |  | 0.0% – 2.0% |

[0000858877-22-000013:notes:324]
|  | PERFORMANCE BASED RESTRICTED STOCK UNITS |
| Years Ended | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Number of shares granted (in millions) | 2 |  |  | 2 |  |  | 2 |  |
| Grant date fair value per share | $ | 59.64 |  |  | $ | 37.91 |  |  | $ | 41.91 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 0.4 | % |  | 3.6 | % |  | 2.8 | % |
| Range of risk-free interest rates | 0.0% – 0.7% |  | 0.1% – 0.4% |  | 1.7% – 2.0% |

[0000858877-22-000013:notes:325]
The PRSUs granted during the fiscal years presented are contingent on the achievement of our financial performance metrics, our comparative market-based returns, or the achievement of financial and non-financial operating goals. For the awards based on financial performance metrics or comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period. Generally, the remaining 50% of the PRSUs are earned based on our TSR measured against the benchmark TSR of a peer group over the same period. Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of our financial performance metrics or our comparative market-based returns, and 0% to 100% of the target shares granted contingent on the achievement of non-financial operating goals.

[0000858877-22-000013:notes:326]
The assumptions for the valuation of employee stock purchase rights are summarized as follows:

[0000858877-22-000013:notes:327]
|  | EMPLOYEE STOCK PURCHASE RIGHTS |
| Years Ended | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Weighted-average assumptions: |  |  |  |  |  |
| Expected volatility | 27.9 | % |  | 29.2 | % |  | 22.2 | % |
| Risk-free interest rate | 0.1 | % |  | 0.3 | % |  | 1.8 | % |
| Expected dividend | 3.2 | % |  | 3.2 | % |  | 3.0 | % |
| Expected life (in years) | 1.2 |  | 1.3 |  | 1.3 |
| Weighted-average estimated grant date fair value per share | $ | 12.90 |  |  | $ | 12.46 |  |  | $ | 10.20 |  |

[0000858877-22-000013:notes:328]
The valuation of employee stock purchase rights and the related assumptions are for the employee stock purchases made during the respective fiscal years.

[0000858877-22-000013:notes:329]
We used third-party analyses to assist in developing the assumptions used in our Black-Scholes model. We are responsible for determining the assumptions used in estimating the fair value of our share-based payment awards.

[0000858877-22-000013:notes:330]
We used the implied volatility for traded options (with contract terms corresponding to the expected life of the employee stock purchase rights) on our stock as the expected volatility assumption required in the Black-Scholes model. The implied volatility is more representative of future stock price trends than historical volatility. The risk-free interest rate assumption is based upon observed interest rates appropriate for the term of our employee stock purchase rights. The dividend yield assumption is based on the history and expectation of dividend payouts at the grant date.

[0000858877-22-000013:notes:331]
(f)Employee 401(k) Plans

[0000858877-22-000013:notes:332]
We sponsor the Cisco Systems, Inc. 401(k) Plan (the “Plan”) to provide retirement benefits for our employees. As allowed under Section 401(k) of the Internal Revenue Code, the Plan provides for tax-deferred salary contributions and after-tax contributions for eligible employees. The Plan allows employees to contribute up to 75% of their annual eligible earnings to the Plan on a pretax and after-tax basis, including Roth contributions. Employee contributions are limited to a maximum annual amount as set periodically by the Internal Revenue Code. We match pretax and Roth employee contributions up to 100% of the first 4.5% of eligible earnings that are contributed by employees. Therefore, the maximum matching contribution that we may allocate to each participant’s account will not exceed $13,725 for the 2022 calendar year due to the $305,000 annual limit on eligible earnings imposed by the Internal Revenue Code. All matching contributions vest immediately. Our matching contributions to the Plan totaled $306 million, $290 million, and $295 million in fiscal 2022, 2021, and 2020, respectively.

[0000858877-22-000013:notes:333]
The Plan allows employees who meet the age requirements and reach the Plan contribution limits to make catch-up contributions (pretax or Roth) not to exceed the lesser of 75% of their annual eligible earnings or the limit set forth in the Internal Revenue Code. Catch-up contributions are not eligible for matching contributions. In addition, the Plan provides for discretionary profit-sharing contributions as determined by the Board of Directors. Such contributions to the Plan are allocated among eligible participants in the proportion of their salaries to the total salaries of all participants. There were no discretionary profit-sharing contributions made in fiscal 2022, 2021, and 2020.

[0000858877-22-000013:notes:334]
We also sponsor other 401(k) plans as a result of acquisitions of other companies. Our contributions to these plans were not material to Cisco on either an individual or aggregate basis for any of the fiscal years presented.

[0000858877-22-000013:notes:335]
(g)Deferred Compensation Plans
The Cisco Systems, Inc. Deferred Compensation Plan (the “Deferred Compensation Plan”), a nonqualified deferred compensation plan, became effective in 2007. As required by applicable law, participation in the Deferred Compensation Plan is limited to a select group of our management employees. Under the Deferred Compensation Plan, which is an unfunded and unsecured deferred compensation arrangement, a participant may elect to defer base salary, bonus, and/or commissions, pursuant to such rules as may be established by Cisco, up to the maximum percentages for each deferral election as described in the plan. We may also, at our discretion, make a matching contribution to the employee under the Deferred Compensation Plan. A matching contribution equal to 4.5% of eligible compensation in excess of the Internal Revenue Code limit for qualified plans for calendar year 2022 that is deferred by participants under the Deferred Compensation Plan (with a $1.5 million cap on eligible compensation) will be made to eligible participants’ accounts at the end of calendar year 2022. The total deferred compensation liability under the Deferred Compensation Plan, together with deferred compensation plans assumed from acquired companies, was approximately $760 million and $845 million as of July 30, 2022 and July 31, 2021, respectively, and was recorded primarily in other long-term liabilities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-22-000013:notes:336]
Comprehensive Income (Loss)  
The components of AOCI, net of tax, and the other comprehensive income (loss) are summarized as follows (in millions):

[0000858877-22-000013:notes:337]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 27, 2019 | $ | — |  |  | $ | (14) |  |  | $ | (778) |  |  | $ | (792) |  |
| Other comprehensive income (loss) before reclassifications | 420 |  |  | 7 |  |  | (51) |  |  | 376 |  |
| (Gains) losses reclassified out of AOCI | (42) |  |  | 1 |  |  | 6 |  |  | (35) |  |
| Tax benefit (expense) | (63) |  |  | — |  |  | (5) |  |  | (68) |  |
| BALANCE AT JULY 25, 2020 | 315 |  |  | (6) |  |  | (828) |  |  | (519) |  |
| Other comprehensive income (loss) before reclassifications | (141) |  |  | 20 |  |  | 229 |  |  | 108 |  |
| (Gains) losses reclassified out of AOCI | (53) |  |  | (14) |  |  | 3 |  |  | (64) |  |
| Tax benefit (expense) | 61 |  |  | (1) |  |  | (2) |  |  | 58 |  |
| BALANCE AT JULY 31, 2021 | 182 |  |  | (1) |  |  | (598) |  |  | (417) |  |
| Other comprehensive income (loss) before reclassifications | (731) |  |  | 87 |  |  | (647) |  |  | (1,291) |  |
| (Gains) losses reclassified out of AOCI | (9) |  |  | (29) |  |  | 2 |  |  | (36) |  |
| Tax benefit (expense) | 179 |  |  | (13) |  |  | (44) |  |  | 122 |  |
| BALANCE AT JULY 30, 2022 | $ | (379) |  |  | $ | 44 |  |  | $ | (1,287) |  |  | $ | (1,622) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-22-000013:notes:338]
Income Taxes
(a)Provision for Income Taxes

[0000858877-22-000013:notes:339]
The provision for income taxes consists of the following (in millions):

[0000858877-22-000013:notes:340]
| Years Ended | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Federal: |  |  |  |  |  |
| Current | $ | 2,203 |  |  | $ | 1,959 |  |  | $ | 1,101 |  |
| Deferred | (176) |  |  | (203) |  |  | (374) |  |
|  | 2,027 |  |  | 1,756 |  |  | 727 |  |
| State: |  |  |  |  |  |
| Current | 458 |  |  | 513 |  |  | 264 |  |
| Deferred | (156) |  |  | (46) |  |  | 287 |  |
|  | 302 |  |  | 467 |  |  | 551 |  |
| Foreign: |  |  |  |  |  |
| Current | 313 |  |  | 583 |  |  | 1,429 |  |
| Deferred | 23 |  |  | (135) |  |  | 49 |  |
|  | 336 |  |  | 448 |  |  | 1,478 |  |
| Total | $ | 2,665 |  |  | $ | 2,671 |  |  | $ | 2,756 |  |

[0000858877-22-000013:notes:341]
Income before provision for income taxes consists of the following (in millions):

[0000858877-22-000013:notes:342]
| Years Ended | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| United States | $ | 13,550 |  |  | $ | 12,335 |  |  | $ | 7,534 |  |
| International | 927 |  |  | 927 |  |  | 6,436 |  |
| Total | $ | 14,477 |  |  | $ | 13,262 |  |  | $ | 13,970 |  |

[0000858877-22-000013:notes:343]
The items accounting for the difference between income taxes computed at the federal statutory rate and the provision for income taxes consist of the following:

[0000858877-22-000013:notes:344]
| Years Ended | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Federal statutory rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 1.7 |  |  | 2.7 |  |  | 3.5 |  |
| Foreign income at other than U.S. rates | 0.8 |  |  | 1.5 |  |  | (1.5) |  |
| Tax credits | (1.6) |  |  | (1.4) |  |  | (0.9) |  |
| Foreign-derived intangible income deduction | (3.9) |  |  | (4.2) |  |  | (2.6) |  |
| Stock-based compensation | 0.3 |  |  | 0.6 |  |  | (0.1) |  |
| Other, net | 0.1 |  |  | (0.1) |  |  | 0.3 |  |
| Total | 18.4 | % |  | 20.1 | % |  | 19.7 | % |

[0000858877-22-000013:notes:345]
During fiscal 2020, the IRS and Cisco settled all outstanding items related to the audit of our federal income tax returns for the fiscal year ended July 30, 2011 through July 27, 2013. As a result of the settlement, we recognized a net benefit to the provision for income taxes of $102 million, net of a reduction in interest expense of $4 million.

[0000858877-22-000013:notes:346]
Foreign taxes associated with the repatriation of earnings of foreign subsidiaries were not provided on a cumulative total of $6.5 billion of undistributed earnings for certain foreign subsidiaries as of the end of fiscal 2022. We intend to reinvest these earnings indefinitely in such foreign subsidiaries. If these earnings were distributed in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, we could be subject to additional income and withholding taxes. The amount of potential unrecognized deferred income tax liability related to these earnings is approximately $681 million.

[0000858877-22-000013:notes:347]
Unrecognized Tax Benefits

[0000858877-22-000013:notes:348]
The aggregate changes in the balance of gross unrecognized tax benefits were as follows (in millions):

[0000858877-22-000013:notes:349]
| Years Ended | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Beginning balance | $ | 3,106 |  |  | $ | 2,518 |  |  | $ | 1,925 |  |
| Additions based on tax positions related to the current year | 157 |  |  | 224 |  |  | 188 |  |
| Additions for tax positions of prior years | 74 |  |  | 618 |  |  | 554 |  |
| Reductions for tax positions of prior years | (81) |  |  | (122) |  |  | (136) |  |
| Settlements | (69) |  |  | (93) |  |  | (4) |  |
| Lapse of statute of limitations | (86) |  |  | (39) |  |  | (9) |  |
| Ending balance | $ | 3,101 |  |  | $ | 3,106 |  |  | $ | 2,518 |  |

[0000858877-22-000013:notes:350]
As of July 30, 2022, $2.2 billion of the unrecognized tax benefits would affect the effective tax rate if realized. We recognized net interest expense of $33 million, $74 million and $104 million during fiscal 2022, 2021, and 2020, respectively. Our net penalty expense for fiscal 2022, 2021, and 2020 was not material. Our total accrual for interest and penalties was $486 million, $444 million, and $340 million as of the end of fiscal 2022, 2021, and 2020, respectively. We are no longer subject to U.S. federal income tax audit for returns covering tax years through fiscal 2013. We are no longer subject to foreign or state income tax audits for returns covering tax years through fiscal 2003 and fiscal 2008, respectively.

[0000858877-22-000013:notes:351]
We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters. We estimate that the unrecognized tax benefits at July 30, 2022 could be reduced by $1 billion in the next 12 months.

[0000858877-22-000013:notes:352]
(b)Deferred Tax Assets and Liabilities

[0000858877-22-000013:notes:353]
The following table presents the breakdown for net deferred tax assets (in millions):

[0000858877-22-000013:notes:354]
|  | July 30, 2022 |  | July 31, 2021 |
| Deferred tax assets | $ | 4,449 |  |  | $ | 4,360 |  |
| Deferred tax liabilities | (55) |  |  | (134) |  |
| Total net deferred tax assets | $ | 4,394 |  |  | $ | 4,226 |  |

[0000858877-22-000013:notes:355]
The following table presents the components of the deferred tax assets and liabilities (in millions):

[0000858877-22-000013:notes:356]
|  | July 30, 2022 |  | July 31, 2021 |
| ASSETS |  |  |  |
| Allowance for accounts receivable and returns | $ | 90 |  |  | $ | 68 |  |
| Sales-type and direct-financing leases | 29 |  |  | 39 |  |
| Inventory write-downs and capitalization | 430 |  |  | 392 |  |
| Deferred foreign income | 210 |  |  | 164 |  |
| IPR&D and purchased intangible assets | 1,184 |  |  | 1,195 |  |
| Depreciation | 10 |  |  | — |  |
| Deferred revenue | 1,744 |  |  | 1,526 |  |
| Credits and net operating loss carryforwards | 1,336 |  |  | 1,264 |  |
| Share-based compensation expense | 138 |  |  | 123 |  |
| Accrued compensation | 333 |  |  | 333 |  |
| Lease liabilities | 248 |  |  | 277 |  |
| Capitalized research expenditures | 149 |  |  | 303 |  |
| Other | 439 |  |  | 454 |  |
| Gross deferred tax assets | 6,340 |  |  | 6,138 |  |
| Valuation allowance | (834) |  |  | (771) |  |
| Total deferred tax assets | 5,506 |  |  | 5,367 |  |
| LIABILITIES |  |  |  |
| Goodwill and purchased intangible assets | (767) |  |  | (686) |  |
| Depreciation | — |  |  | (46) |  |
| Unrealized gains on investments | (26) |  |  | (112) |  |
| ROU lease assets | (237) |  |  | (260) |  |
| Other | (82) |  |  | (37) |  |
| Total deferred tax liabilities | (1,112) |  |  | (1,141) |  |
| Total net deferred tax assets | $ | 4,394 |  |  | $ | 4,226 |  |

[0000858877-22-000013:notes:357]
The changes in the valuation allowance for deferred tax assets are summarized as follows (in millions):

[0000858877-22-000013:notes:358]
|  |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Balance at beginning of fiscal year |  | $ | 771 |  |  | $ | 700 |  |  | $ | 457 |  |
| Additions |  | 84 |  |  | 91 |  |  | 279 |  |
| Deductions |  | (10) |  |  | (5) |  |  | (29) |  |
| Write-offs |  | (12) |  |  | (16) |  |  | (7) |  |
| Foreign exchange and other |  | 1 |  |  | 1 |  |  | — |  |
| Balance at end of fiscal year |  | $ | 834 |  |  | $ | 771 |  |  | $ | 700 |  |

[0000858877-22-000013:notes:359]
As of July 30, 2022, our federal, state, and foreign net operating loss carryforwards before valuation allowance for income tax purposes were $302 million, $1.1 billion, and $580 million, respectively. A significant amount of the net operating loss carryforwards relates to acquisitions and, as a result, is limited in the amount that can be recognized in any one year. If not utilized, the federal, state, and foreign net operating loss carryforwards will begin to expire in fiscal 2023. We have provided a valuation allowance of $98 million and $10 million for deferred tax assets related to foreign and state net operating losses respectively that are not expected to be realized.
As of July 30, 2022, our federal, state, and foreign tax credit carryforwards for income tax purposes before valuation allowance were approximately $6 million, $1.6 billion, and $4 million, respectively. The federal tax credit carryforwards will begin to expire in fiscal 2024. The majority of state and foreign tax credits can be carried forward indefinitely. We have provided a valuation allowance of $648 million for deferred tax assets related to state and foreign tax credits carryforwards that are not expected to be realized.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-22-000013:notes:360]
Segment Information and Major Customers 
(a)Revenue and Gross Margin by Segment

[0000858877-22-000013:notes:361]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-22-000013:notes:362]
Summarized financial information by segment for fiscal 2022, 2021, and 2020, based on our internal management system and as utilized by our Chief Operating Decision Maker (CODM), is as follows (in millions):

[0000858877-22-000013:notes:363]
| Years Ended | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Revenue: |  |  |  |  |  |
| Americas | $ | 29,814 |  |  | $ | 29,161 |  |  | $ | 29,291 |  |
| EMEA | 13,715 |  |  | 12,951 |  |  | 12,659 |  |
| APJC | 8,027 |  |  | 7,706 |  |  | 7,352 |  |
| Total | $ | 51,557 |  |  | $ | 49,818 |  |  | $ | 49,301 |  |
| Gross margin: |  |  |  |  |  |
| Americas | $ | 19,117 |  |  | $ | 19,499 |  |  | $ | 19,547 |  |
| EMEA | 8,969 |  |  | 8,466 |  |  | 8,304 |  |
| APJC | 5,241 |  |  | 4,949 |  |  | 4,688 |  |
| Segment total | 33,326 |  |  | 32,914 |  |  | 32,538 |  |
| Unallocated corporate items | (1,078) |  |  | (1,020) |  |  | (855) |  |
| Total | $ | 32,248 |  |  | $ | 31,894 |  |  | $ | 31,683 |  |

[0000858877-22-000013:notes:364]
Revenue in the United States was $26.7 billion, $26.1 billion, and $26.1 billion for fiscal 2022, 2021, and 2020, respectively.

[0000858877-22-000013:notes:365]
(b)Revenue for Groups of Similar Products and Services

[0000858877-22-000013:notes:366]
We design and sell IP-based networking and other products related to the communications and IT industry and provide services associated with these products and their use. Effective fiscal 2022, we began reporting our product and service revenue in the following categories: Secure, Agile Networks; Internet for the Future; Collaboration; End-to-End Security; Optimized Application Experiences; Other Products; and Services. This change will better align our product categories with our strategic priorities.

[0000858877-22-000013:notes:367]
(c)Additional Segment Information

[0000858877-22-000013:notes:368]
No single customer accounted for 10% or more of revenue in fiscal 2022, 2021, and 2020.

[0000858877-22-000013:notes:369]
The majority of our assets as of July 30, 2022 and July 31, 2021 were attributable to our U.S. operations. Our long-lived assets are based on the physical location of the assets. The following table presents our long-lived assets, which consists of property and equipment, net and operating lease right-of-use assets information for geographic areas (in millions):

[0000858877-22-000013:notes:370]
|  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Long-lived assets: |  |  |  |  |  |
| United States | $ | 2,004 |  |  | $ | 2,189 |  |  | $ | 2,328 |  |
| International | 997 |  |  | 1,244 |  |  | 1,046 |  |
| Total | $ | 3,001 |  |  | $ | 3,433 |  |  | $ | 3,374 |  |


## us-gaap:EarningsPerShareTextBlock

[0000858877-22-000013:notes:371]
Net Income per Share 
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-22-000013:notes:372]
| Years Ended | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Net income | $ | 11,812 |  |  | $ | 10,591 |  |  | $ | 11,214 |  |
| Weighted-average shares—basic | 4,170 |  |  | 4,222 |  |  | 4,236 |  |
| Effect of dilutive potential common shares | 22 |  |  | 14 |  |  | 18 |  |
| Weighted-average shares—diluted | 4,192 |  |  | 4,236 |  |  | 4,254 |  |
| Net income per share—basic | $ | 2.83 |  |  | $ | 2.51 |  |  | $ | 2.65 |  |
| Net income per share—diluted | $ | 2.82 |  |  | $ | 2.50 |  |  | $ | 2.64 |  |
| Antidilutive employee share-based awards, excluded | 70 |  |  | 69 |  |  | 76 |  |
