# CSCO MD&A — 0000858877-22-000013


## mdna

[0000858877-22-000013:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000858877-22-000013:mdna:2]
Forward-Looking Statements

[0000858877-22-000013:mdna:3]
OVERVIEW

[0000858877-22-000013:mdna:4]
Cisco designs and sells a broad range of technologies that power the Internet. We are integrating our platforms across networking, security, collaboration, applications and the cloud. These platforms are designed to help our customers manage more users, devices and things connecting to their networks. This will enable us to provide customers with a highly secure, intelligent platform for their digital business.

[0000858877-22-000013:mdna:5]
A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-22-000013:mdna:6]
|  | Three Months Ended |  | Years Ended |  |
|  | July 30, 2022 |  | July 31, 2021 |  | Variance |  | July 30, 2022 |  | July 31, 2021 |  | Variance |  |
| Revenue | $ | 13,102 |  |  | $ | 13,126 |  |  | — | % |  | $ | 51,557 |  |  | $ | 49,818 |  |  | 3 | % |  |
| Gross margin percentage | 61.3 | % |  | 63.6 | % |  | (2.3) |  | pts | 62.5 | % |  | 64.0 | % |  | (1.5) |  | pts |
| Research and development | $ | 1,682 |  |  | $ | 1,713 |  |  | (2) | % |  | $ | 6,774 |  |  | $ | 6,549 |  |  | 3 | % |  |
| Sales and marketing | $ | 2,349 |  |  | $ | 2,448 |  |  | (4) | % |  | $ | 9,085 |  |  | $ | 9,259 |  |  | (2) | % |  |
| General and administrative | $ | 489 |  |  | $ | 521 |  |  | (6) | % |  | $ | 2,101 |  |  | $ | 2,152 |  |  | (2) | % |  |
| Total R&D, sales and marketing, general and administrative | $ | 4,520 |  |  | $ | 4,682 |  |  | (3) | % |  | $ | 17,960 |  |  | $ | 17,960 |  |  | — | % |  |
| Total as a percentage of revenue | 34.5 | % |  | 35.7 | % |  | (1.2) |  | pts | 34.8 | % |  | 36.1 | % |  | (1.3) |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 73 |  |  | $ | 79 |  |  | (8) | % |  | $ | 313 |  |  | $ | 215 |  |  | 46 | % |  |
| Restructuring and other charges included in operating expenses | $ | (2) |  |  | $ | 8 |  |  | (133) | % |  | $ | 6 |  |  | $ | 886 |  |  | (99) | % |  |
| Operating income as a percentage of revenue | 26.2 | % |  | 27.2 | % |  | (1.0) |  | pts | 27.1 | % |  | 25.8 | % |  | 1.3 |  | pts |
| Interest and other income (loss), net | $ | (18) |  |  | $ | 160 |  |  | (111) | % |  | $ | 508 |  |  | $ | 429 |  |  | 18 | % |  |
| Income tax percentage | 17.6 | % |  | 19.4 | % |  | (1.8) |  | pts | 18.4 | % |  | 20.1 | % |  | (1.7) |  | pts |
| Net income | $ | 2,815 |  |  | $ | 3,009 |  |  | (6) | % |  | $ | 11,812 |  |  | $ | 10,591 |  |  | 12 | % |  |
| Net income as a percentage of revenue | 21.5 | % |  | 22.9 | % |  | (1.4) |  | pts | 22.9 | % |  | 21.3 | % |  | 1.6 |  | pts |
| Earnings per share—diluted | $ | 0.68 |  |  | $ | 0.71 |  |  | (4) | % |  | $ | 2.82 |  |  | $ | 2.50 |  |  | 13 | % |  |

[0000858877-22-000013:mdna:7]
Percentages may not recalculate due to rounding.

[0000858877-22-000013:mdna:8]
Fiscal 2022 Compared with Fiscal 2021

[0000858877-22-000013:mdna:9]
In fiscal 2022, we delivered growth in total revenue and strong profitability in a challenging environment impacted by significant supply constraints, rising component and related costs, and the Russia and Ukraine war. We remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformations. We continue to be negatively impacted by supply constraints seen industry-wide due to component shortages. While we did see some easing of the supply constraints towards the end of the fourth quarter of fiscal 2022, we expect the constraints to continue and the duration is uncertain. We have, and continue to take, multiple steps in order to mitigate the component shortages and deliver products to our customers. We continued to make progress in the transition of our business model delivering increased software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-22-000013:mdna:10]
Total revenue increased by 3% compared with fiscal 2021. Within total revenue, product revenue increased by 6% and service revenue decreased by 2%. Fiscal 2022 had 52 weeks, compared with 53 weeks in fiscal 2021, thus our results for fiscal 2022 reflect one less week compared with fiscal 2021. In fiscal 2022, total software revenue was flat at $15.1 billion across all product areas and service. Within total software revenue, subscription revenue increased 3%. Total gross margin decreased by 1.5 percentage points. Product gross margin decreased by 2.1 percentage points, largely driven by increased costs related to supply constraints and to a lesser extent, product mix, partially offset by favorable pricing. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 1.3 percentage points. Operating income as a percentage of revenue increased by 1.3 percentage points. Diluted earnings per share increased 13%, driven by an increase of 12% in net income and a decrease in diluted share count of 44 million shares.

[0000858877-22-000013:mdna:11]
In terms of our geographic segments, revenue from the Americas increased by $0.7 billion, EMEA revenue increased by $0.8 billion and revenue in our APJC segment increased by $0.3 billion.

[0000858877-22-000013:mdna:12]
From a customer market standpoint, we experienced product revenue growth in the commercial, enterprise and service provider markets partially offset by a decline in the public sector market.

[0000858877-22-000013:mdna:13]
From a product category perspective, total product revenue increased 6% year over year, driven by growth in revenue in Secure, Agile Networks of 5%; Internet for the Future of 17%; End-to-End Security of 9% and Optimized Application Experiences of 11%; partially offset by a product revenue decline in Collaboration of 5%.

[0000858877-22-000013:mdna:14]
Russia and Ukraine War

[0000858877-22-000013:mdna:15]
In March 2022, in connection with the Russian invasion of Ukraine, Cisco announced its intention to stop business operations in Russia and Belarus for the foreseeable future. Those operations in Russia and Belarus included sales, services and related support functions. Further, on June 23, 2022, we announced that we will begin an orderly wind-down and exit of our business in Russia and Belarus.

[0000858877-22-000013:mdna:16]
Our business operations in Russia, Belarus and Ukraine, collectively, comprised approximately 1% of our total revenue for the year ended July 31, 2021. Russia and Belarus, collectively, represented less than 0.1% of our total assets at the end of fiscal 2022. As a result of the war and the resulting events, we have not recognized revenue in these countries effective March 2022. The negative impact to total revenue was approximately $200 million for fiscal 2022, which includes committed revenue we would have otherwise recognized, charges for uncollectible receivables, and other items. Further, we also assessed the risk to the recoverability of our assets and other potential financial exposures in these countries. We have reserved for the non-recoverability of substantially all of our assets in Russia and Belarus. As a result, we have recognized certain non-recurring charges of $91 million in cost of sales and operating expenses in fiscal 2022 related to non-recoverability of certain assets, special personnel-related charges in order to support impacted employees, and severance and other exit related costs.

[0000858877-22-000013:mdna:17]
The ongoing effect of the Russia and Ukraine war are difficult to predict due to the other uncertainties identified in Part I, Item 1A. Risk Factors herein.

[0000858877-22-000013:mdna:18]
Fourth Quarter Snapshot

[0000858877-22-000013:mdna:19]
For the fourth quarter of fiscal 2022, total revenue, product revenue and service revenue were each flat as compared with the fourth quarter of fiscal 2021. With regard to our geographic segment performance, on a year-over-year basis, revenue in EMEA increased by 8% offset by declines in Americas and APJC by 3% and 2%, respectively. From a product category perspective, we experienced product revenue growth in Collaboration; End-to-End Security and Optimized Application Experiences; partially offset by declines in Secure, Agile Networks and Internet for the Future. Total gross margin decreased by 2.3 percentage points, driven by higher component and commodity costs, in addition to higher freight and logistics costs related to supply constraints, partially offset by favorable pricing and product mix. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively decreased by 1.2 percentage points. Operating income as a percentage of revenue decreased by 1.0 percentage points. Diluted earnings per share decreased by 4%, driven by a decrease in net income of 6% and a decrease in diluted share count of 101 million shares.

[0000858877-22-000013:mdna:20]
Strategy and Priorities

[0000858877-22-000013:mdna:21]
As our customers add billions of new connections to their enterprises, and as more applications move to a multicloud environment, the network becomes even more critical. Our customers are navigating change at an unprecedented pace. In this dynamic environment, we believe their priorities are to reimagine applications, power hybrid work, transform infrastructure, and secure the enterprise.

[0000858877-22-000013:mdna:22]
Our strategy is to help our customers connect, secure, and automate to accelerate their digital agility in a cloud-first world. We are committed to driving a trusted customer experience, through our innovation, choice, and people.

[0000858877-22-000013:mdna:23]
For a full discussion of our strategy and priorities, see “Item 1. Business.”

[0000858877-22-000013:mdna:24]
Other Key Financial Measures

[0000858877-22-000013:mdna:25]
The following is a summary of our other key financial measures for fiscal 2022 compared with fiscal 2021 (in millions):

[0000858877-22-000013:mdna:26]
|  |  | Fiscal 2022 |  | Fiscal 2021 |
| Cash and cash equivalents and investments |  | $19,267 |  | $24,518 |
| Cash provided by operating activities |  | $13,226 |  | $15,454 |
| Remaining performance obligations |  | $31,539 |  | $30,893 |
| Repurchases of common stock—stock repurchase program |  | $7,734 |  | $2,902 |
| Dividends paid |  | $6,224 |  | $6,163 |
| Inventories |  | $2,568 |  | $1,559 |

[0000858877-22-000013:mdna:27]
CRITICAL ACCOUNTING ESTIMATES

[0000858877-22-000013:mdna:28]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-22-000013:mdna:29]
The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic, including the associated impact of supply constraints, on our critical and significant accounting estimates. The COVID-19 pandemic did not have a material impact on our significant judgments, assumptions and estimates that are reflected in our results for fiscal 2022. These estimates include: goodwill and identified purchased intangible assets and income taxes, among other items. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-22-000013:mdna:30]
Revenue Recognition

[0000858877-22-000013:mdna:31]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis.

[0000858877-22-000013:mdna:32]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-22-000013:mdna:33]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-22-000013:mdna:34]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable. If actual credits received by distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-22-000013:mdna:35]
See Note 3 to the Consolidated Financial Statements for more details.

[0000858877-22-000013:mdna:36]
Inventory Valuation and Liability for Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-22-000013:mdna:37]
Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and net realizable value, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-22-000013:mdna:38]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.

[0000858877-22-000013:mdna:39]
Our provision for inventory was $102 million, $116 million, and $74 million in fiscal 2022, 2021, and 2020, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $227 million, $76 million, and $139 million in fiscal 2022, 2021, and 2020, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, or if supply constraints were to continue, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs, and the adequacy of our liability for purchase commitments. We continue to manage through significant supply constraints seen industry-wide due to component shortages caused, in part, by the COVID-19 pandemic. For further discussion around the Supply Constraints Impacts and Risks, see “—Results of Operations—Gross Margin—Supply Constraints Impacts and Risks” and “—Liquidity and Capital Resources—Inventory Supply Chain.”

[0000858877-22-000013:mdna:40]
Loss Contingencies

[0000858877-22-000013:mdna:41]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-22-000013:mdna:42]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-22-000013:mdna:43]
Goodwill and Purchased Intangible Asset Impairments

[0000858877-22-000013:mdna:44]
Our methodology for allocating the purchase price relating to purchase acquisitions is determined through established valuation techniques. Goodwill represents a residual value as of the acquisition date, which in most cases results in measuring goodwill as an excess of the purchase consideration transferred plus the fair value of any noncontrolling interest in the acquired company over the fair value of net assets acquired, including contingent consideration. We perform goodwill impairment tests on an annual basis in the fourth fiscal quarter and between annual tests in certain circumstances for each reporting unit. The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the new accounting guidance for the fair value measurement of nonfinancial assets.

[0000858877-22-000013:mdna:45]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in fiscal 2022, 2021, and 2020. For the annual impairment testing in fiscal 2022, the excess of the fair value over the carrying value for each of our reporting units was $64.7 billion for the Americas, $55.2 billion for EMEA, and $21.0 billion for APJC.

[0000858877-22-000013:mdna:46]
During the fourth quarter of fiscal 2022, we performed a sensitivity analysis for goodwill impairment with respect to each of our respective reporting units and determined that a hypothetical 10% decline in the fair value of each reporting unit would not result in an impairment of goodwill for any reporting unit.

[0000858877-22-000013:mdna:47]
The fair value of acquired technology and patents, as well as acquired technology under development, is determined at acquisition date primarily using the income approach, which discounts expected future cash flows to present value. The discount rates used in the present value calculations are typically derived from a weighted-average cost of capital analysis and

[0000858877-22-000013:mdna:48]
36

[0000858877-22-000013:mdna:49]
then adjusted to reflect risks inherent in the development lifecycle as appropriate. We consider the pricing model for products related to these acquisitions to be standard within the high-technology communications industry, and the applicable discount rates represent the rates that market participants would use for valuation of such intangible assets.

[0000858877-22-000013:mdna:50]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. Our impairment charges related to purchased intangible assets were $15 million for fiscal 2022. Our ongoing consideration of all the factors described previously could result in impairment charges in the future, which could adversely affect our net income.

[0000858877-22-000013:mdna:51]
Income Taxes

[0000858877-22-000013:mdna:52]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was 18.4%, 20.1%, and 19.7% in fiscal 2022, 2021, and 2020, respectively.

[0000858877-22-000013:mdna:53]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.

[0000858877-22-000013:mdna:54]
Significant judgment is also required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000858877-22-000013:mdna:55]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to foreign-derived intangible income deduction, global intangible low-tax income and base erosion and anti-abuse tax laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The OECD, an international association comprised of 38 countries, including the United States, has made changes and is contemplating additional changes to numerous long-standing tax principles. There can be no assurance that these changes and any contemplated changes if finalized, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries was subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the IRS and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-22-000013:mdna:56]
RESULTS OF OPERATIONS

[0000858877-22-000013:mdna:57]
A discussion regarding our financial condition and results of operations for fiscal 2022 compared to fiscal 2021 is presented below. A discussion regarding our financial condition and results of operations for fiscal 2021 compared to fiscal 2020, with the exception of Product Revenue by Category, for which is discussed herein, can be found under Item 7 in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021, filed with the SEC on September 9, 2021.

[0000858877-22-000013:mdna:58]
Revenue

[0000858877-22-000013:mdna:59]
The following table presents the breakdown of revenue between product and service (in millions, except percentages):

[0000858877-22-000013:mdna:60]
|  |  | Years Ended |  | 2022 vs. 2021 |
|  |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 38,018 |  |  | $ | 36,014 |  |  | $ | 35,978 |  |  | $ | 2,004 |  |  | 6 | % |
| Percentage of revenue |  | 73.7 | % |  | 72.3 | % |  | 73.0 | % |  |  |  |  |
| Service |  | 13,539 |  |  | 13,804 |  |  | 13,323 |  |  | (265) |  |  | (2) | % |
| Percentage of revenue |  | 26.3 | % |  | 27.7 | % |  | 27.0 | % |  |  |  |  |
| Total |  | $ | 51,557 |  |  | $ | 49,818 |  |  | $ | 49,301 |  |  | $ | 1,739 |  |  | 3 | % |

[0000858877-22-000013:mdna:61]
We manage our business primarily on a geographic basis, organized into three geographic segments. Our revenue, which includes product and service for each segment, is summarized in the following table (in millions, except percentages):

[0000858877-22-000013:mdna:62]
|  |  | Years Ended |  | 2022 vs. 2021 |
|  |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 29,814 |  |  | $ | 29,161 |  |  | $ | 29,291 |  |  | $ | 653 |  |  | 2 | % |
| Percentage of revenue |  | 57.8 | % |  | 58.5 | % |  | 59.4 | % |  |  |  |  |
| EMEA |  | 13,715 |  |  | 12,951 |  |  | 12,659 |  |  | 764 |  |  | 6 | % |
| Percentage of revenue |  | 26.6 | % |  | 26.0 | % |  | 25.7 | % |  |  |  |  |
| APJC |  | 8,027 |  |  | 7,706 |  |  | 7,352 |  |  | 321 |  |  | 4 | % |
| Percentage of revenue |  | 15.6 | % |  | 15.5 | % |  | 14.9 | % |  |  |  |  |
| Total |  | $ | 51,557 |  |  | $ | 49,818 |  |  | $ | 49,301 |  |  | $ | 1,739 |  |  | 3 | % |

[0000858877-22-000013:mdna:63]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-22-000013:mdna:64]
Total revenue in fiscal 2022 increased by 3% compared with fiscal 2021. Product revenue increased by 6% and service revenue decreased by 2%. Our total revenue reflected growth across each of our geographic segments.

[0000858877-22-000013:mdna:65]
In addition to the impact of macroeconomic factors, including the IT spending environment and the level of spending by government entities, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple performance obligations; the mix of financing arrangements provided to channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment.

[0000858877-22-000013:mdna:66]
Product Revenue by Segment

[0000858877-22-000013:mdna:67]
The following table presents the breakdown of product revenue by segment (in millions, except percentages):

[0000858877-22-000013:mdna:68]
|  |  | Years Ended |  | 2022 vs. 2021 |
|  |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 21,620 |  |  | $ | 20,688 |  |  | $ | 21,006 |  |  | $ | 932 |  |  | 5 | % |
| Percentage of product revenue |  | 56.9 | % |  | 57.5 | % |  | 58.4 | % |  |  |  |  |
| EMEA |  | 10,545 |  |  | 9,805 |  |  | 9,647 |  |  | 740 |  |  | 8 | % |
| Percentage of product revenue |  | 27.7 | % |  | 27.2 | % |  | 26.8 | % |  |  |  |  |
| APJC |  | 5,854 |  |  | 5,521 |  |  | 5,326 |  |  | 333 |  |  | 6 | % |
| Percentage of product revenue |  | 15.4 | % |  | 15.3 | % |  | 14.8 | % |  |  |  |  |
| Total |  | $ | 38,018 |  |  | $ | 36,014 |  |  | $ | 35,978 |  |  | $ | 2,004 |  |  | 6 | % |

[0000858877-22-000013:mdna:69]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-22-000013:mdna:70]
Americas

[0000858877-22-000013:mdna:71]
Product revenue in the Americas segment increased by 5%. The product revenue increase was driven by growth in the service provider, commercial and enterprise markets, partially offset by a decline in the public sector market. From a country perspective, product revenue increased by 5% in the United States, 5% in Canada and 7% in Mexico, partially offset by a product revenue decrease of 1% in Brazil.

[0000858877-22-000013:mdna:72]
EMEA

[0000858877-22-000013:mdna:73]
The increase in product revenue in the EMEA segment of 8% was driven by growth in the commercial, enterprise and service provider markets The public sector market was flat. From a country perspective, product revenue increased by 14% in the United Kingdom and 9% in Germany, partially offset by a decline of 3% in France.

[0000858877-22-000013:mdna:74]
APJC

[0000858877-22-000013:mdna:75]
Product revenue in the APJC segment increased by 6%, driven by growth in the commercial and enterprise markets, partially offset by declines in the service provider and public sector markets. From a country perspective, product revenue increased by 18% in China and 10% in Australia, partially offset by declines of 9% in Japan and 1% in India.

[0000858877-22-000013:mdna:76]
Product Revenue by Category

[0000858877-22-000013:mdna:77]
In addition to the primary view on a geographic basis, we also prepare financial information related to product categories and customer markets for various purposes. Effective fiscal 2022, we began reporting our product revenue in the following categories: Secure, Agile Networks; Internet for the Future; Collaboration; End-to-End Security; Optimized Application Experiences; and Other Products. This change will better align our product categories with our strategic priorities.

[0000858877-22-000013:mdna:78]
The following table presents product revenue by category (in millions, except percentages):

[0000858877-22-000013:mdna:79]
|  |  | Years Ended |  | 2022 vs. 2021 |  | 2021 vs. 2020 |
|  |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Secure, Agile Networks |  | $ | 23,829 |  |  | $ | 22,722 |  |  | $ | 23,265 |  |  | $ | 1,107 |  |  | 5 | % |  | $ | (543) |  |  | (2) | % |
| Internet for the Future |  | 5,278 |  |  | 4,514 |  |  | 4,180 |  |  | 764 |  |  | 17 | % |  | 334 |  |  | 8 | % |
| Collaboration |  | 4,472 |  |  | 4,727 |  |  | 4,823 |  |  | (255) |  |  | (5) | % |  | (96) |  |  | (2) | % |
| End-to-End Security |  | 3,699 |  |  | 3,382 |  |  | 3,158 |  |  | 317 |  |  | 9 | % |  | 224 |  |  | 7 | % |
| Optimized Application Experiences |  | 729 |  |  | 654 |  |  | 524 |  |  | 75 |  |  | 11 | % |  | 130 |  |  | 25 | % |
| Other Products |  | 11 |  |  | 15 |  |  | 28 |  |  | (4) |  |  | (29) | % |  | (13) |  |  | (47) | % |
| Total |  | $ | 38,018 |  |  | $ | 36,014 |  |  | $ | 35,978 |  |  | $ | 2,004 |  |  | 6 | % |  | $ | 36 |  |  | — | % |

[0000858877-22-000013:mdna:80]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-22-000013:mdna:81]
Secure, Agile Networks

[0000858877-22-000013:mdna:82]
Fiscal 2022 Compared with Fiscal 2021

[0000858877-22-000013:mdna:83]
The Secure, Agile Networks product category represents our core networking offerings related to switching, enterprise routing, wireless, and compute. Secure, Agile Networks revenue increased by 5%, or $1.1 billion, with growth across the portfolio except enterprise routing. Revenue grew in both campus switching and data center switching, primarily driven by growth in our Catalyst 9000 series, Nexus 9000 series and Meraki switching offerings. The decrease in enterprise routing was primarily driven by declines in our Access and Edge offerings. Wireless had double-digit growth driven by our WiFi-6 products and Meraki offerings. Revenue from compute grew primarily driven by our servers.

[0000858877-22-000013:mdna:84]
Fiscal 2021 Compared with Fiscal 2020

[0000858877-22-000013:mdna:85]
Revenue from the Secure, Agile Networks product category decreased by 2%, or $543 million, driven by declines across the portfolio with the exception of Wireless. Switching revenue declined in both campus switching and data center switching, although we had double-digit growth in our Catalyst 9000 series and Meraki switching offerings and growth in our Nexus 9000 series. The decrease in enterprise routing was primarily driven by declines in our Access offerings, partially offset by growth in our SD-WAN and Edge offerings. Wireless had solid growth driven by our Meraki offerings and the ramp of our WiFi-6 products. Revenue from compute declined primarily driven by our servers.

[0000858877-22-000013:mdna:86]
Internet for the Future

[0000858877-22-000013:mdna:87]
Fiscal 2022 Compared with Fiscal 2021

[0000858877-22-000013:mdna:88]
The Internet for the Future product category includes our routed optical networking, 5G, silicon and optics solutions. Revenue in our Internet for the Future product category increased by 17%, or $764 million, driven by growth in the webscale provider market. We saw growth in our Cisco 8000, NCS 5500 and ASR 9000 series offerings, and also saw a benefit from our acquisition of Acacia in the third quarter of fiscal 2021.

[0000858877-22-000013:mdna:89]
Fiscal 2021 Compared with Fiscal 2020

[0000858877-22-000013:mdna:90]
Revenue in our Internet for the Future product category increased 8%, or $334 million, driven by growth in our NCS 5500 series offerings and the ramp of our Cisco 8000 series offerings.

[0000858877-22-000013:mdna:91]
Collaboration

[0000858877-22-000013:mdna:92]
Fiscal 2022 Compared with Fiscal 2021

[0000858877-22-000013:mdna:93]
The Collaboration product category consists of our Meetings, Collaboration Devices, Calling, Contact Center and CPaaS offerings. Revenue in our Collaboration product category decreased 5%, or $255 million, with declines in our Meetings, Calling and Contact Center offerings, partially offset by the ramp in our CPaaS offerings.

[0000858877-22-000013:mdna:94]
Fiscal 2021 Compared with Fiscal 2020

[0000858877-22-000013:mdna:95]
Revenue in our Collaboration product category decreased by 2%, or $96 million, with declines in our Collaboration Devices, partially offset by growth in our Meetings, Calling and Contact Center offerings.

[0000858877-22-000013:mdna:96]
End-to-End Security

[0000858877-22-000013:mdna:97]
Fiscal 2022 Compared with Fiscal 2021

[0000858877-22-000013:mdna:98]
The End-to-End Security product category consists of our Network Security, Cloud Security, Security Endpoints, Unified Threat Management and Zero Trust offerings. Revenue in our End-to-End Security product category increased by 9%, or $317 million, primarily driven by growth in our Zero Trust portfolio, Network Security, Unified Threat Management and Security Endpoint offerings. Our Zero Trust portfolio reflected double-digit growth driven by continued momentum with our Duo offerings.

[0000858877-22-000013:mdna:99]
Fiscal 2021 Compared with Fiscal 2020

[0000858877-22-000013:mdna:100]
Revenue in our End-to-End Security product category increased by 7%, or $224 million, primarily driven by growth in our cloud-based solutions and Unified Threat Management offerings, partially offset by declines in our Network Security offerings. Our Zero Trust portfolio reflected growth driven by our Duo offerings.

[0000858877-22-000013:mdna:101]
Optimized Application Experiences

[0000858877-22-000013:mdna:102]
Fiscal 2022 Compared with Fiscal 2021

[0000858877-22-000013:mdna:103]
The Optimized Application Experiences product category includes our full stack observability and cloud-native platforms offerings. Revenue in our Optimized Application Experiences product category increased 11%, or $75 million, driven by growth in our ThousandEyes and Intersight offerings, partially offset by a decline in our AppDynamics offerings.

[0000858877-22-000013:mdna:104]
Fiscal 2021 Compared with Fiscal 2020

[0000858877-22-000013:mdna:105]
Revenue in our Optimized Application Experiences product category increased by 25%, or $130 million, driven by growth in our Intersight offerings. We also had a benefit from our acquisition of ThousandEyes.

[0000858877-22-000013:mdna:106]
Service Revenue by Segment

[0000858877-22-000013:mdna:107]
The following table presents the breakdown of service revenue by segment (in millions, except percentages):

[0000858877-22-000013:mdna:108]
|  | Years Ended |  | 2022 vs. 2021 |
|  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |  | Variance in Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 8,194 |  |  | $ | 8,472 |  |  | $ | 8,285 |  |  | $ | (278) |  |  | (3) | % |
| Percentage of service revenue | 60.5 | % |  | 61.4 | % |  | 62.2 | % |  |  |  |  |
| EMEA | 3,171 |  |  | 3,146 |  |  | 3,012 |  |  | 25 |  |  | 1 | % |
| Percentage of service revenue | 23.4 | % |  | 22.8 | % |  | 22.6 | % |  |  |  |  |
| APJC | 2,173 |  |  | 2,186 |  |  | 2,026 |  |  | (13) |  |  | (1) | % |
| Percentage of service revenue | 16.0 | % |  | 15.8 | % |  | 15.2 | % |  |  |  |  |
| Total | $ | 13,539 |  |  | $ | 13,804 |  |  | $ | 13,323 |  |  | $ | (265) |  |  | (2) | % |

[0000858877-22-000013:mdna:109]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-22-000013:mdna:110]
Service revenue decreased 2%, driven by declines in our maintenance business, advisory services and software support offerings, partially offset by growth in our solution support and network support offerings. The extra week in fiscal 2021 also contributed to the decrease in service revenue in fiscal 2022. Service revenue decreased in the Americas and APJC segments, partially offset by growth in the EMEA segment.

[0000858877-22-000013:mdna:111]
Gross Margin

[0000858877-22-000013:mdna:112]
The following table presents the gross margin for products and services (in millions, except percentages):

[0000858877-22-000013:mdna:113]
|  | AMOUNT |  | PERCENTAGE |
| Years Ended | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 23,204 |  |  | $ | 22,714 |  |  | $ | 22,779 |  |  | 61.0 | % |  | 63.1 | % |  | 63.3 | % |
| Service | 9,044 |  |  | 9,180 |  |  | 8,904 |  |  | 66.8 | % |  | 66.5 | % |  | 66.8 | % |
| Total | $ | 32,248 |  |  | $ | 31,894 |  |  | $ | 31,683 |  |  | 62.5 | % |  | 64.0 | % |  | 64.3 | % |

[0000858877-22-000013:mdna:114]
Product Gross Margin

[0000858877-22-000013:mdna:115]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2021 to fiscal 2022:

[0000858877-22-000013:mdna:116]
|  |  | Product Gross Margin Percentage |
| Fiscal 2021 |  | 63.1 | % |
| Productivity (1) |  | (2.8) | % |
| Product pricing |  | 1.0 | % |
| Mix of products sold |  | (0.3) | % |
| Others |  | — | % |
| Fiscal 2022 |  | 61.0 | % |

[0000858877-22-000013:mdna:117]
(1) Productivity includes overall manufacturing-related costs, such as component costs, warranty expense, provision for inventory, freight, logistics, shipment volume, and other items not categorized elsewhere.

[0000858877-22-000013:mdna:118]
Product gross margin decreased by 2.1 percentage points primarily driven by negative impacts from productivity, largely driven by increased costs related to supply constraints from freight, expedites, and higher component and commodity costs. These impacts were partially offset by favorable pricing. The benefit we saw from favorable pricing was primarily driven by price increases implemented during fiscal 2022, to partially offset increases in components and commodity costs, freight and logistics costs, driven by supply constraints.

[0000858877-22-000013:mdna:119]
Supply Constraints Impacts and Risks

[0000858877-22-000013:mdna:120]
We continue to manage through significant supply constraints seen industry-wide due to component shortages caused, in part, by the COVID-19 pandemic, and for which the duration of such constraints is uncertain. These shortages have resulted in increased costs (i.e., component and other commodity costs, freight, expedite fees, etc.) which have had a negative impact on our product gross margin and have resulted in extended lead times for us and our customers. We have taken a number of steps in order to mitigate the supply constraint related impacts including: partnering with several of our key suppliers utilizing our volume purchasing ability and extending supply coverage, including, in certain cases, revising supplier arrangements; paying significantly higher component and logistics costs to secure supply; modifying our product designs in order to leverage alternate suppliers, where possible; and continually optimizing our inventory build and customer delivery plans, among others. We believe these actions are helping us to optimize our access to critical components and meet customer demand for our products. We continue to see solid demand across the majority of our portfolio. As a result, in order to secure supply to meet customer demand, we have increased our inventory balances, inventory purchase commitments, and inventory deposits and prepayments (see “—Liquidity and Capital Resources—Inventory Supply Chain”), which, in turn, has increased our supply chain exposure. Additionally, in certain situations, we have prepaid or made deposits with suppliers to secure future supply. These actions significantly increase the risk of future material excess and obsolete inventory and related losses if customer demand were to suddenly and significantly decrease in future periods. While we believe we are taking the right strategic and operational actions to address the supply situation, we recognize the increased risks.

[0000858877-22-000013:mdna:121]
Service Gross Margin

[0000858877-22-000013:mdna:122]
Our service gross margin percentage increased by 0.3 percentage points primarily due to lower headcount-related and delivery costs and favorable mix of service offerings, partially offset by lower sales volume.

[0000858877-22-000013:mdna:123]
Our service gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service

[0000858877-22-000013:mdna:124]
42

[0000858877-22-000013:mdna:125]
business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-22-000013:mdna:126]
Gross Margin by Segment

[0000858877-22-000013:mdna:127]
The following table presents the total gross margin for each segment (in millions, except percentages):

[0000858877-22-000013:mdna:128]
|  |  | AMOUNT |  | PERCENTAGE |
| Years Ended |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 19,117 |  |  | $ | 19,499 |  |  | $ | 19,547 |  |  | 64.1 | % |  | 66.9 | % |  | 66.7 | % |
| EMEA |  | 8,969 |  |  | 8,466 |  |  | 8,304 |  |  | 65.4 | % |  | 65.4 | % |  | 65.6 | % |
| APJC |  | 5,241 |  |  | 4,949 |  |  | 4,688 |  |  | 65.3 | % |  | 64.2 | % |  | 63.8 | % |
| Segment total |  | 33,326 |  |  | 32,914 |  |  | 32,538 |  |  | 64.6 | % |  | 66.1 | % |  | 66.0 | % |
| Unallocated corporate items (1) |  | (1,078) |  |  | (1,020) |  |  | (855) |  |  |  |  |  |  |  |
| Total |  | $ | 32,248 |  |  | $ | 31,894 |  |  | $ | 31,683 |  |  | 62.5 | % |  | 64.0 | % |  | 64.3 | % |

[0000858877-22-000013:mdna:129]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-22-000013:mdna:130]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-22-000013:mdna:131]
We experienced a gross margin percentage decrease in our Americas segment due to negative impacts from productivity and unfavorable product mix, partially offset by favorable pricing.

[0000858877-22-000013:mdna:132]
Gross margin in our EMEA segment was flat due to higher service gross margin, favorable product mix and favorable pricing  offset by negative impacts from productivity.

[0000858877-22-000013:mdna:133]
The APJC segment gross margin percentage increase was due to favorable product mix and favorable pricing, partially offset by negative impacts from productivity.

[0000858877-22-000013:mdna:134]
The gross margin percentage for a particular segment may fluctuate, and period-to-period changes in such percentages may or may not be indicative of a trend for that segment.

[0000858877-22-000013:mdna:135]
Research and Development (“R&D”), Sales and Marketing, and General and Administrative (“G&A”) Expenses

[0000858877-22-000013:mdna:136]
R&D, sales and marketing, and G&A expenses are summarized in the following table (in millions, except percentages):

[0000858877-22-000013:mdna:137]
|  |  | Years Ended |  | 2022 vs. 2021 |
|  |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |  | Variance in Dollars |  | Variance in Percent |
| Research and development |  | $ | 6,774 |  |  | $ | 6,549 |  |  | $ | 6,347 |  |  | $ | 225 |  |  | 3 | % |
| Percentage of revenue |  | 13.1 | % |  | 13.1 | % |  | 12.9 | % |  |  |  |  |
| Sales and marketing |  | 9,085 |  |  | 9,259 |  |  | 9,169 |  |  | (174) |  |  | (2) | % |
| Percentage of revenue |  | 17.6 | % |  | 18.6 | % |  | 18.6 | % |  |  |  |  |
| General and administrative |  | 2,101 |  |  | 2,152 |  |  | 1,925 |  |  | (51) |  |  | (2) | % |
| Percentage of revenue |  | 4.1 | % |  | 4.3 | % |  | 3.9 | % |  |  |  |  |
| Total |  | $ | 17,960 |  |  | $ | 17,960 |  |  | $ | 17,441 |  |  | $ | — |  |  | — | % |
| Percentage of revenue |  | 34.8 | % |  | 36.1 | % |  | 35.4 | % |  |  |  |  |

[0000858877-22-000013:mdna:138]
Our fiscal 2022 had one less week compared with fiscal 2021, which had an extra week.

[0000858877-22-000013:mdna:139]
R&D Expenses

[0000858877-22-000013:mdna:140]
R&D expenses increased due to higher headcount-related expenses, higher share-based compensation expense, higher acquisition-related costs and higher contracted services spending, partially offset by lower discretionary spending.

[0000858877-22-000013:mdna:141]
We continue to invest in R&D in order to bring a broad range of products to market in a timely fashion. If we believe that we are unable to enter a particular market in a timely manner with internally developed products, we may purchase or license technology from other businesses, or we may partner with or acquire businesses as an alternative to internal R&D.

[0000858877-22-000013:mdna:142]
Sales and Marketing Expenses

[0000858877-22-000013:mdna:143]
Sales and marketing expenses decreased primarily due to lower headcount-related expenses and lower contracted services spending, partially offset by higher discretionary spending, certain non-recurring charges recognized due to the Russia and Ukraine war and higher share-based compensation expense. The extra week in fiscal 2021 contributed to the decrease in headcount-related expenses.

[0000858877-22-000013:mdna:144]
G&A Expenses

[0000858877-22-000013:mdna:145]
G&A expenses decreased due to lower contracted services spending, partially offset by certain non-recurring charges recognized due to the Russia and Ukraine war.

[0000858877-22-000013:mdna:146]
Effect of Foreign Currency

[0000858877-22-000013:mdna:147]
In fiscal 2022, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $154 million, or 0.9%, compared with fiscal 2021.

[0000858877-22-000013:mdna:148]
Amortization of Purchased Intangible Assets

[0000858877-22-000013:mdna:149]
The following table presents the amortization of purchased intangible assets including impairment charges (in millions):

[0000858877-22-000013:mdna:150]
| Years Ended |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 749 |  |  | $ | 716 |  |  | $ | 659 |  |
| Operating expenses |  | 328 |  |  | 215 |  |  | 141 |  |
| Total |  | $ | 1,077 |  |  | $ | 931 |  |  | $ | 800 |  |

[0000858877-22-000013:mdna:151]
The increase in amortization of purchased intangible assets was due largely to the amortization of purchased intangibles from our recent acquisitions and impairment charges of $15 million. The impairment charges were primarily due to declines in estimated fair value resulting from reductions in or the elimination of expected future cash flows associated with certain of our technology and in-process research and development (IPR&D) intangible assets.

[0000858877-22-000013:mdna:152]
Restructuring and Other Charges

[0000858877-22-000013:mdna:153]
The following table presents restructuring and other charges (in millions):

[0000858877-22-000013:mdna:154]
| Years Ended |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Restructuring and other charges included in operating expenses |  | $ | 6 |  |  | $ | 886 |  |  | $ | 481 |  |

[0000858877-22-000013:mdna:155]
We initiated a restructuring plan in fiscal 2021, which included a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas. The total pretax charges were estimated to be approximately $900 million. We incurred cumulative charges of $892 million and completed this plan in fiscal 2022.

[0000858877-22-000013:mdna:156]
Operating Income

[0000858877-22-000013:mdna:157]
The following table presents our operating income and our operating income as a percentage of revenue (in millions, except percentages):

[0000858877-22-000013:mdna:158]
| Years Ended |  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Operating income |  | $ | 13,969 |  |  | $ | 12,833 |  |  | $ | 13,620 |  |
| Operating income as a percentage of revenue |  | 27.1 | % |  | 25.8 | % |  | 27.6 | % |

[0000858877-22-000013:mdna:159]
Operating income increased by 9%, and as a percentage of revenue operating income increased by 1.3 percentage points. These changes resulted primarily from a revenue increase and lower restructuring and other charges partially offset by a gross margin percentage decrease (driven by negative impacts from productivity partially offset by favorable pricing).

[0000858877-22-000013:mdna:160]
Interest and Other Income (Loss), Net

[0000858877-22-000013:mdna:161]
Interest Income (Expense), Net   The following table summarizes interest income and interest expense (in millions):

[0000858877-22-000013:mdna:162]
|  | Years Ended |  | 2022 vs. 2021 |
|  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |  | Variance in Dollars |
| Interest income | $ | 476 |  |  | $ | 618 |  |  | $ | 920 |  |  | $ | (142) |  |
| Interest expense | (360) |  |  | (434) |  |  | (585) |  |  | 74 |  |
| Interest income (expense), net | $ | 116 |  |  | $ | 184 |  |  | $ | 335 |  |  | $ | (68) |  |

[0000858877-22-000013:mdna:163]
Interest income decreased driven by lower average book yields and lower average balances of cash and available-for-sale debt investments. The decrease in interest expense was driven by a lower average debt balance.

[0000858877-22-000013:mdna:164]
Other Income (Loss), Net   The components of other income (loss), net, are summarized as follows (in millions):

[0000858877-22-000013:mdna:165]
|  | Years Ended |  | 2022 vs. 2021 |
|  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |
| Available-for-sale debt investments | $ | 9 |  |  | $ | 53 |  |  | $ | 42 |  |  | $ | (44) |  |
| Marketable equity investments | (38) |  |  | 6 |  |  | (5) |  |  | (44) |  |
| Privately held investments | 486 |  |  | 266 |  |  | 95 |  |  | 220 |  |
| Net gains (losses) on investments | 457 |  |  | 325 |  |  | 132 |  |  | 132 |  |
| Other gains (losses), net | (65) |  |  | (80) |  |  | (117) |  |  | 15 |  |
| Other income (loss), net | $ | 392 |  |  | $ | 245 |  |  | $ | 15 |  |  | $ | 147 |  |

[0000858877-22-000013:mdna:166]
The increase in our other income (loss), net was primarily driven by higher realized and unrealized gains on our privately held investments, and to a lesser extent, favorable impacts from foreign exchange. The increase was partially offset by changes in net gains (losses) on available-for-sale debt investments and marketable equity investments.

[0000858877-22-000013:mdna:167]
Provision for Income Taxes

[0000858877-22-000013:mdna:168]
The provision for income taxes resulted in an effective tax rate of 18.4% for fiscal 2022, compared with 20.1% for fiscal 2021. The net 1.7 percentage points decrease in the effective tax rate was primarily due to a decrease in prior year discrete tax expenses and state taxes.

[0000858877-22-000013:mdna:169]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 21% and for further explanation of our provision for income taxes, see Note 18 to the Consolidated Financial Statements.

[0000858877-22-000013:mdna:170]
LIQUIDITY AND CAPITAL RESOURCES

[0000858877-22-000013:mdna:171]
The following sections discuss the effects of changes in our balance sheet, our capital allocation strategy including stock repurchase program and dividends, our contractual obligations, and certain other commitments and activities on our liquidity and capital resources.

[0000858877-22-000013:mdna:172]
Balance Sheet and Cash Flows

[0000858877-22-000013:mdna:173]
Cash and Cash Equivalents and Investments  The following table summarizes our cash and cash equivalents and investments (in millions):

[0000858877-22-000013:mdna:174]
|  | July 30, 2022 |  | July 31, 2021 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 7,079 |  |  | $ | 9,175 |  |  | $ | (2,096) |  |
| Available-for-sale debt investments | 11,947 |  |  | 15,206 |  |  | (3,259) |  |
| Marketable equity securities | 241 |  |  | 137 |  |  | 104 |  |
| Total | $ | 19,267 |  |  | $ | 24,518 |  |  | $ | (5,251) |  |

[0000858877-22-000013:mdna:175]
The net decrease in cash and cash equivalents and investments from fiscal 2021 to fiscal 2022 was primarily driven by cash returned to stockholders in the form of repurchases of common stock of $7.7 billion under the stock repurchase program and cash dividends of $6.2 billion, net decrease in debt of $2.5 billion, changes in unrealized losses of our investments and other of $0.9 billion, net increase in restricted cash equivalents of $0.8 billion, capital expenditures of $0.5 billion and net cash paid for acquisitions and divestitures of $0.4 billion. These uses of cash were partially offset by cash provided by operating activities of $13.2 billion and issuance of commercial paper of $0.6 billion.

[0000858877-22-000013:mdna:176]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our available-for-sale debt investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-22-000013:mdna:177]
Securities Lending  We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of July 30, 2022 and July 31, 2021, we had no outstanding securities lending transactions.

[0000858877-22-000013:mdna:178]
Free Cash Flow and Capital Allocation  As part of our capital allocation strategy, we target to return a minimum of 50% of our free cash flow annually to our stockholders through cash dividends and repurchases of common stock.

[0000858877-22-000013:mdna:179]
We define free cash flow as net cash provided by operating activities less cash used to acquire property and equipment. The following table reconciles our net cash provided by operating activities to free cash flow (in millions):

[0000858877-22-000013:mdna:180]
| Years Ended | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |
| Net cash provided by operating activities | $ | 13,226 |  |  | $ | 15,454 |  |  | $ | 15,426 |  |
| Acquisition of property and equipment | (477) |  |  | (692) |  |  | (770) |  |
| Free cash flow | $ | 12,749 |  |  | $ | 14,762 |  |  | $ | 14,656 |  |

[0000858877-22-000013:mdna:181]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue and the timing and amount of tax and other payments. For additional discussion, see “Part I, Item 1A. Risk Factors” in this report.

[0000858877-22-000013:mdna:182]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to stockholders in the form of dividends and stock repurchases. We

[0000858877-22-000013:mdna:183]
46

[0000858877-22-000013:mdna:184]
further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness. Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net cash provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-22-000013:mdna:185]
The following table summarizes the dividends paid and stock repurchases (in millions, except per-share amounts):

[0000858877-22-000013:mdna:186]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  | TOTAL |
| Years Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | Amount |
| July 30, 2022 |  | $ | 1.50 |  |  | $ | 6,224 |  |  | 146 |  |  | $ | 52.82 |  |  | $ | 7,734 |  |  | $ | 13,958 |  |
| July 31, 2021 |  | $ | 1.46 |  |  | $ | 6,163 |  |  | 64 |  |  | $ | 45.48 |  |  | $ | 2,902 |  |  | $ | 9,065 |  |
| July 25, 2020 |  | $ | 1.42 |  |  | $ | 6,016 |  |  | 59 |  |  | $ | 44.36 |  |  | $ | 2,619 |  |  | $ | 8,635 |  |

[0000858877-22-000013:mdna:187]
On August 23, 2022, our Board of Directors declared a quarterly dividend of $0.38 per common share to be paid on October 26, 2022, to all stockholders of record as of the close of business on October 5, 2022. Any future dividends are subject to the approval of our Board of Directors.

[0000858877-22-000013:mdna:188]
The remaining authorized amount for stock repurchases under this program is approximately $15.2 billion, with no termination date.

[0000858877-22-000013:mdna:189]
Accounts Receivable, Net  The following table summarizes our accounts receivable, net (in millions):

[0000858877-22-000013:mdna:190]
|  | July 30, 2022 |  | July 31, 2021 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 6,622 |  |  | $ | 5,766 |  |  | $ | 856 |  |

[0000858877-22-000013:mdna:191]
Our accounts receivable net, as of July 30, 2022 increased by approximately 15% compared with the end of fiscal 2021, primarily due to timing and amount of product and service billings at the end of fiscal 2022 compared with the end of fiscal 2021.

[0000858877-22-000013:mdna:192]
Inventory Supply Chain  The following table summarizes our inventories and inventory purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-22-000013:mdna:193]
|  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |  | Variance vs. July 31, 2021 |  | Variance vs. July 25, 2020 |
| Inventories | $ | 2,568 |  |  | $ | 1,559 |  |  | $ | 1,282 |  |  | $ | 1,009 |  |  | $ | 1,286 |  |
| Inventory purchase commitments | $ | 12,964 |  |  | $ | 10,254 |  |  | $ | 4,406 |  |  | $ | 2,710 |  |  | $ | 8,558 |  |
| Inventory deposits and prepayments | $ | 1,484 |  |  | $ | 162 |  |  | $ | 117 |  |  | $ | 1,322 |  |  | $ | 1,367 |  |

[0000858877-22-000013:mdna:194]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-22-000013:mdna:195]
|  | July 30, 2022 |  | July 31, 2021 |  | July 25, 2020 |  | Variance vs. July 31, 2021 |  | Variance vs. July 25, 2020 |
| Less than 1 year | $ | 9,954 |  |  | $ | 6,903 |  |  | $ | 3,994 |  |  | $ | 3,051 |  |  | $ | 5,960 |  |
| 1 to 3 years | 2,240 |  |  | 1,806 |  |  | 412 |  |  | 434 |  |  | 1,828 |  |
| 3 to 5 years | 770 |  |  | 1,545 |  |  | — |  |  | (775) |  |  | 770 |  |
| Total | $ | 12,964 |  |  | $ | 10,254 |  |  | $ | 4,406 |  |  | $ | 2,710 |  |  | $ | 8,558 |  |

[0000858877-22-000013:mdna:196]
Inventory as of July 30, 2022 increased by 65% and 100% from our inventory balances at the end of fiscal 2021 and fiscal 2020, respectively. Inventory purchase commitments with contract manufacturers and suppliers increased by 26% and 194% from our balances at the end of fiscal 2021 and fiscal 2020, respectively. We increased our balances in inventories, inventory purchase commitments, and inventory deposits and prepayments as compared to prior fiscal years in order to address significant supply constraints seen industry-wide. The increases were primarily due to arrangements to secure supply and pricing for certain product components and commitments with contract manufacturers to meet customer demand and to address extended

[0000858877-22-000013:mdna:197]
lead times, as well as advance payments with suppliers to secure future supply, as a result of the supply constraints. We have partnered with several of our key suppliers utilizing our volume purchasing and extending supply coverage, including revising supplier arrangements. As discussed, our risks of future material excess and obsolete inventory and related losses are further outlined in the Result of Operations—Product Gross Margin section.

[0000858877-22-000013:mdna:198]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity.

[0000858877-22-000013:mdna:199]
Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-22-000013:mdna:200]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of supply constraints, rapidly changing technology and customer requirements. We believe the amount of our inventory and inventory purchase commitments is appropriate for our current and expected customer demand and revenue levels.

[0000858877-22-000013:mdna:201]
Financing Receivables and Guarantees  The following table summarizes our financing receivables (in millions):

[0000858877-22-000013:mdna:202]
|  | July 30, 2022 |  | July 31, 2021 |  | Increase (Decrease) |
| Lease receivables, net | $ | 1,175 |  |  | $ | 1,697 |  |  | $ | (522) |  |
| Loan receivables, net | 4,556 |  |  | 5,117 |  |  | (561) |  |
| Financed service contracts, net | 2,183 |  |  | 2,450 |  |  | (267) |  |
| Total, net | $ | 7,914 |  |  | $ | 9,264 |  |  | $ | (1,350) |  |

[0000858877-22-000013:mdna:203]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services. The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed. Financing receivables decreased by 15%.

[0000858877-22-000013:mdna:204]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, with payment terms generally ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-22-000013:mdna:205]
The volume of channel partner financing was $27.9 billion, $26.7 billion, and $26.9 billion in fiscal 2022, 2021, and 2020, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.4 billion and $1.3 billion as of July 30, 2022 and July 31, 2021, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of July 30, 2022, the total maximum potential future payments related to these guarantees was approximately $179 million, of which approximately $9 million was recorded as deferred revenue.

[0000858877-22-000013:mdna:206]
Borrowings

[0000858877-22-000013:mdna:207]
Senior Notes  The following table summarizes the principal amount of our senior notes (in millions):

[0000858877-22-000013:mdna:208]
|  | Maturity Date |  | July 30, 2022 |  | July 31, 2021 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | $ | 2,000 |  |
| 3.00% | June 15, 2022 |  | — |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 9,000 |  |  | $ | 11,500 |  |

[0000858877-22-000013:mdna:209]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of July 30, 2022.

[0000858877-22-000013:mdna:210]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had $0.6 billion in commercial paper notes outstanding as of July 30, 2022, and no commercial paper outstanding as of July 31, 2021.

[0000858877-22-000013:mdna:211]
Credit Facility  On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of July 30, 2022, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement. Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

[0000858877-22-000013:mdna:212]
49

[0000858877-22-000013:mdna:213]
Remaining Performance Obligations   The following table presents the breakdown of remaining performance obligations (in millions):

[0000858877-22-000013:mdna:214]
|  | July 30, 2022 |  | July 31, 2021 |  | Increase (Decrease) |
| Product | $ | 14,090 |  |  | $ | 13,270 |  |  | $ | 820 |  |
| Service | 17,449 |  |  | 17,623 |  |  | (174) |  |
| Total | $ | 31,539 |  |  | $ | 30,893 |  |  | $ | 646 |  |
| Short-term RPO | $ | 16,936 |  |  | $ | 16,289 |  |  | $ | 647 |  |
| Long-term RPO | 14,603 |  |  | 14,604 |  |  | (1) |  |
| Total | $ | 31,539 |  |  | $ | 30,893 |  |  | $ | 646 |  |

[0000858877-22-000013:mdna:215]
Total remaining performance obligations increased 2% in fiscal 2022. Remaining performance obligations for product increased 6% and remaining product obligations for service decreased 1%, compared to fiscal 2021. We expect approximately 54% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-22-000013:mdna:216]
Deferred Revenue   The following table presents the breakdown of deferred revenue (in millions):

[0000858877-22-000013:mdna:217]
|  | July 30, 2022 |  | July 31, 2021 |  | Increase (Decrease) |
| Product | $ | 10,427 |  |  | $ | 9,416 |  |  | $ | 1,011 |  |
| Service | 12,837 |  |  | 12,748 |  |  | 89 |  |
| Total | $ | 23,264 |  |  | $ | 22,164 |  |  | $ | 1,100 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 12,784 |  |  | $ | 12,148 |  |  | $ | 636 |  |
| Noncurrent | 10,480 |  |  | 10,016 |  |  | 464 |  |
| Total | $ | 23,264 |  |  | $ | 22,164 |  |  | $ | 1,100 |  |

[0000858877-22-000013:mdna:218]
Total deferred revenue increased 5% in fiscal 2022. The increase in deferred product revenue of 11% was primarily due to increased deferrals related to our recurring software offerings. The slight increase in deferred service revenue was driven by the impact of contract renewals, partially offset by amortization of deferred service revenue.

[0000858877-22-000013:mdna:219]
Contractual Obligations

[0000858877-22-000013:mdna:220]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. In addition, we plan for and measure our liquidity and capital resources through an annual budgeting process. The following table summarizes our contractual obligations at July 30, 2022 (in millions):

[0000858877-22-000013:mdna:221]
|  | PAYMENTS DUE BY PERIOD |
| July 30, 2022 | Total |  | Less than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than 5 Years |
| Operating leases | $ | 1,127 |  |  | $ | 343 |  |  | $ | 431 |  |  | $ | 168 |  |  | $ | 185 |  |
| Purchase commitments with contract manufacturers and suppliers | 12,964 |  |  | 9,954 |  |  | 2,240 |  |  | 770 |  |  | — |  |
| Other purchase obligations | 2,601 |  |  | 1,030 |  |  | 879 |  |  | 662 |  |  | 30 |  |
| Senior notes | 9,000 |  |  | 500 |  |  | 2,250 |  |  | 2,250 |  |  | 4,000 |  |
| Transition tax payable | 6,183 |  |  | 727 |  |  | 3,183 |  |  | 2,273 |  |  | — |  |
| Other long-term liabilities | 1,189 |  |  | — |  |  | 187 |  |  | 135 |  |  | 867 |  |
| Total by period | $ | 33,064 |  |  | $ | 12,554 |  |  | $ | 9,170 |  |  | $ | 6,258 |  |  | $ | 5,082 |  |
| Other long-term liabilities (uncertainty in the timing of future payments) | 2,324 |  |  |  |  |  |  |  |  |  |
| Total | $ | 35,388 |  |  |  |  |  |  |  |  |  |

[0000858877-22-000013:mdna:222]
Operating Leases  For more information on our operating leases, see Note 8 to the Consolidated Financial Statements.

[0000858877-22-000013:mdna:223]
Purchase Commitments with Contract Manufacturers and Suppliers  We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. See further discussion in “Inventory Supply Chain.”

[0000858877-22-000013:mdna:224]
Other Purchase Obligations  Other purchase obligations represent an estimate of all contractual obligations in the ordinary course of business, other than operating leases and commitments with contract manufacturers and suppliers, for which we have not received the goods or services. Purchase orders are not included in the preceding table as they typically represent our authorization to purchase rather than binding contractual purchase obligations.

[0000858877-22-000013:mdna:225]
Long-Term Debt  The amount of long-term debt in the preceding table represents the principal amount of the respective debt instruments. See Note 12 to the Consolidated Financial Statements.

[0000858877-22-000013:mdna:226]
Transition Tax Payable  Transition tax payable represents future cash tax payments associated with the one-time U.S. transition tax on accumulated earnings for foreign subsidiaries as a result of the Tax Cuts and Jobs Act (“the Tax Act”).

[0000858877-22-000013:mdna:227]
Other Long-Term Liabilities  Other long-term liabilities primarily include noncurrent income taxes payable, accrued liabilities for deferred compensation, deferred tax liabilities, and certain other long-term liabilities. Due to the uncertainty in the timing of future payments, our noncurrent income taxes payable of approximately $2.3 billion and deferred tax liabilities of $55 million were presented as one aggregated amount in the total column on a separate line in the preceding table. Noncurrent income taxes payable include uncertain tax positions. See Note 18 to the Consolidated Financial Statements.

[0000858877-22-000013:mdna:228]
Other Commitments

[0000858877-22-000013:mdna:229]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or the continued employment with us of certain employees of the acquired entities. See Note 14 to the Consolidated Financial Statements.

[0000858877-22-000013:mdna:230]
We also have certain funding commitments primarily related to our privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.4 billion and $0.2 billion as of July 30, 2022 and July 31, 2021, respectively.

[0000858877-22-000013:mdna:231]
In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of July 30, 2022 there were no material unconsolidated variable interest entities.

[0000858877-22-000013:mdna:232]
On an ongoing basis, we reassess our privately held investments and customer financings to determine if they are variable interest entities and if we would be regarded as the primary beneficiary pursuant to the applicable accounting guidance. As a result of this ongoing assessment, we may be required to make additional disclosures or consolidate these entities. Because we may not control these entities, we may not have the ability to influence these events.

[0000858877-22-000013:mdna:233]
We provide financing guarantees, which are generally for various third-party financing arrangements extended to our channel partners. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. See the previous discussion of these financing guarantees under “Financing Receivables and Guarantees.”

[0000858877-22-000013:mdna:234]
Liquidity and Capital Resource Requirements

[0000858877-22-000013:mdna:235]
While the COVID-19 pandemic and the Russia and Ukraine war have not materially impacted our liquidity and capital resources to date, it has led to increased disruption and volatility in capital markets and credit markets. These events and resulting economic uncertainty could adversely affect our liquidity and capital resources in the future. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs (including inventory and other supply related payments), capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. We expect increased payments related to inventory and other supply related payments through at least the next 12 months. There are no other transactions, arrangements, or relationships with

[0000858877-22-000013:mdna:236]
unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.

[0000858877-22-000013:mdna:237]
52
