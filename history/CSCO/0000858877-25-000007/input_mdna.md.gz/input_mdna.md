# CSCO MD&A — 0000858877-25-000007


## mdna

[0000858877-25-000007:mdna:1]
[same as prior period, unchanged from 0000858877-24-000030:mdna:1]

[0000858877-25-000007:mdna:2]
[same as prior period, unchanged from 0000858877-24-000030:mdna:2]

[0000858877-25-000007:mdna:3]
[same as prior period, unchanged from 0000858877-24-000030:mdna:3]

[0000858877-25-000007:mdna:4]
[same as prior period, unchanged from 0000858877-24-000030:mdna:4]

[0000858877-25-000007:mdna:5]
[same as prior period, unchanged from 0000858877-24-000030:mdna:5]

[0000858877-25-000007:mdna:6]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | January 25,2025 |  | January 27,2024 |  | % Variance |  |  | January 25, 2025 |  | January 27, 2024 |  | % Variance |  |
| Revenue | $ | 13,991 |  |  | $ | 12,791 |  |  | 9 | % |  |  | $ | 27,832 |  |  | $ | 27,459 |  |  | 1 | % |  |
| Gross margin percentage | 65.1 | % |  | 64.2 | % |  | 0.9 |  | pts |  | 65.5 | % |  | 64.7 | % |  | 0.8 |  | pts |
| Research and development | $ | 2,299 |  |  | $ | 1,943 |  |  | 18 | % |  |  | $ | 4,585 |  |  | $ | 3,856 |  |  | 19 | % |  |
| Sales and marketing | $ | 2,672 |  |  | $ | 2,458 |  |  | 9 | % |  |  | $ | 5,424 |  |  | $ | 4,964 |  |  | 9 | % |  |
| General and administrative | $ | 752 |  |  | $ | 642 |  |  | 17 | % |  |  | $ | 1,547 |  |  | $ | 1,314 |  |  | 18 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 5,723 |  |  | $ | 5,043 |  |  | 13 | % |  |  | $ | 11,556 |  |  | $ | 10,134 |  |  | 14 | % |  |
| Total as a percentage of revenue | 40.9 | % |  | 39.4 | % |  | 1.5 |  | pts |  | 41.5 | % |  | 36.9 | % |  | 4.6 |  | pts |
| Restructuring and other charges included in operating expenses | $ | 10 |  |  | $ | 12 |  |  | (19) | % |  |  | $ | 675 |  |  | $ | 135 |  |  | NM |  |
| Operating income as a percentage of revenue | 22.3 | % |  | 24.2 | % |  | (1.9) |  | pts |  | 19.7 | % |  | 26.8 | % |  | (7.1) |  | pts |
| Interest and other income (loss), net | $ | (226) |  |  | $ | 65 |  |  | NM |  |  | $ | (317) |  |  | $ | 231 |  |  | NM |  |
| Income tax percentage | 15.9 | % |  | 16.7 | % |  | (0.8) |  | pts |  | 0.3 | % |  | 17.5 | % |  | (17.2) |  | pts |
| Net income | $ | 2,428 |  |  | $ | 2,634 |  |  | (8) | % |  |  | $ | 5,139 |  |  | $ | 6,272 |  |  | (18) | % |  |
| Net income as a percentage of revenue | 17.4 | % |  | 20.6 | % |  | (3.2) |  | pts |  | 18.5 | % |  | 22.8 | % |  | (4.3) |  | pts |
| Earnings per share—diluted | $ | 0.61 |  |  | $ | 0.65 |  |  | (6) | % |  |  | $ | 1.28 |  |  | $ | 1.54 |  |  | (17) | % |  |

[0000858877-25-000007:mdna:7]
[same as prior period, unchanged from 0000858877-24-000030:mdna:7]

[0000858877-25-000007:mdna:8]
[same as prior period, unchanged from 0000858877-24-000030:mdna:8]

[0000858877-25-000007:mdna:9]
[same as prior period, unchanged from 0000858877-24-000030:mdna:9]

[0000858877-25-000007:mdna:10]
[same as prior period, unchanged from 0000858877-24-000030:mdna:10]

[0000858877-25-000007:mdna:11]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:12]
In the second quarter of fiscal 2025, we delivered strong revenue growth across all geographies and solid margins as we saw a positive demand environment. Total revenue increased by 9% compared with the second quarter of fiscal 2024. Excluding Splunk, total revenue decreased 1% compared with the second quarter of fiscal 2024. Within total revenue, product revenue increased by 11% and services revenue increased by 6%. In the second quarter of fiscal 2025, total software revenue was $5.5 billion across all product areas and services, an increase of 33%, primarily driven by the contribution of Splunk. Total subscription revenue increased 23%, primarily driven by the contribution of Splunk.

[0000858877-25-000007:mdna:13]
Total gross margin increased by 0.9 percentage points. Product gross margin increased by 1.0 percentage points, largely driven by benefits from Splunk and productivity improvements, partially offset by pricing erosion. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 1.5 percentage points. Operating income as a percentage of revenue decreased by 1.9 percentage points primarily driven by incremental operating expenses from Splunk and higher amortization of purchased intangible assets in the second quarter of fiscal 2025. Diluted earnings per share decreased 6%, driven by a decrease of 8% in net income, partially offset by a decrease in diluted share count of 68 million shares.

[0000858877-25-000007:mdna:14]
In terms of our geographic segments, revenue from the Americas increased by $692 million, EMEA revenue increased by $371 million and APJC revenue increased by $136 million. From a customer market standpoint, we experienced product revenue growth across all of our customer markets. From a product category perspective, the product revenue increase of 11% was driven by a growth in Security of 117%, Observability of 47% and Collaboration of 1%. This growth was partially offset by a product revenue decline in Networking of 3%. The product revenue growth in Security and Observability were each driven in large part by the contribution of Splunk.

[0000858877-25-000007:mdna:15]
[same as prior period, unchanged from 0000858877-24-000030:mdna:15]

[0000858877-25-000007:mdna:16]
[same as prior period, unchanged from 0000858877-24-000030:mdna:25]

[0000858877-25-000007:mdna:17]
[same as prior period, unchanged from 0000858877-24-000030:mdna:16]

[0000858877-25-000007:mdna:18]
[same as prior period, unchanged from 0000858877-24-000030:mdna:17]

[0000858877-25-000007:mdna:19]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:20]
Total revenue increased 1%, with product revenue flat and service revenue increasing 6%. Total gross margin increased 0.8 percentage points due to benefits from Splunk, productivity improvements and favorable product mix, partially offset by pricing erosion. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 4.6 percentage points. Operating income as a percentage of revenue decreased by 7.1 percentage points primarily due to incremental operating expenses from Splunk, restructuring and other charges of $675 million and higher amortization of purchased intangibles in the first six months of fiscal 2025. Diluted earnings per share decreased 17%, driven by a decrease of 18% in net income, partially offset by a decrease in diluted share count of 71 million shares.

[0000858877-25-000007:mdna:21]
[same as prior period, unchanged from 0000858877-24-000030:mdna:18]

[0000858877-25-000007:mdna:22]
[same as prior period, unchanged from 0000858877-24-000030:mdna:19]

[0000858877-25-000007:mdna:23]
[same as prior period, unchanged from 0000858877-24-000030:mdna:20]

[0000858877-25-000007:mdna:24]
[same as prior period, unchanged from 0000858877-24-000030:mdna:21]

[0000858877-25-000007:mdna:25]
The following is a summary of our other key financial measures for the second quarter of fiscal 2025 (in millions):

[0000858877-25-000007:mdna:26]
|  |  | January 25,2025 |  | July 27,2024 |
| Cash and cash equivalents and investments |  | $ | 16,853 |  |  | $ | 17,854 |  |
| Remaining performance obligations |  | $ | 41,268 |  |  | $ | 41,048 |  |
| Inventories |  | $ | 2,927 |  |  | $ | 3,373 |  |
| Total debt |  | $ | 31,038 |  |  | $ | 30,962 |  |

[0000858877-25-000007:mdna:27]
|  |  | Six Months Ended |
|  |  | January 25,2025 |  | January 27,2024 |
| Cash provided by operating activities |  | $ | 5,902 |  |  | $ | 3,179 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 3,239 |  |  | $ | 2,506 |  |
| Dividends paid |  | $ | 3,185 |  |  | $ | 3,163 |  |

[0000858877-25-000007:mdna:28]
[same as prior period, unchanged from 0000858877-24-000030:mdna:26]

[0000858877-25-000007:mdna:29]
[same as prior period, unchanged from 0000858877-24-000030:mdna:27]

[0000858877-25-000007:mdna:30]
[same as prior period, unchanged from 0000858877-24-000030:mdna:28]

[0000858877-25-000007:mdna:31]
[same as prior period, unchanged from 0000858877-24-000030:mdna:29]

[0000858877-25-000007:mdna:32]
[same as prior period, unchanged from 0000858877-24-000030:mdna:30]

[0000858877-25-000007:mdna:33]
[same as prior period, unchanged from 0000858877-24-000030:mdna:31]

[0000858877-25-000007:mdna:34]
[same as prior period, unchanged from 0000858877-24-000030:mdna:32]

[0000858877-25-000007:mdna:35]
[same as prior period, unchanged from 0000858877-24-000030:mdna:33]

[0000858877-25-000007:mdna:36]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and end customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable. If actual credits received by distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-25-000007:mdna:37]
[same as prior period, unchanged from 0000858877-24-000030:mdna:35]

[0000858877-25-000007:mdna:38]
[same as prior period, unchanged from 0000858877-24-000030:mdna:36]

[0000858877-25-000007:mdna:39]
[same as prior period, unchanged from 0000858877-24-000030:mdna:37]

[0000858877-25-000007:mdna:40]
42

[0000858877-25-000007:mdna:41]
[same as prior period, unchanged from 0000858877-24-000030:mdna:39]

[0000858877-25-000007:mdna:42]
[same as prior period, unchanged from 0000858877-24-000030:mdna:40]

[0000858877-25-000007:mdna:43]
[same as prior period, unchanged from 0000858877-24-000030:mdna:41]

[0000858877-25-000007:mdna:44]
Our provision for inventory was $381 million and $258 million for the first six months of fiscal 2025 and 2024, respectively. The provision (benefit) from the liability related to purchase commitments with contract manufacturers and suppliers was a benefit of $24 million and a provision of $128 million for the first six months of fiscal 2025 and 2024, respectively. If there were to be a sudden and significant decrease in demand for our products, if there were a higher incidence of inventory obsolescence because of rapidly changing technology or customer requirements, or if supply constraints were to continue, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. For further discussion around the supply chain impacts and risks, see “—Results of Operations—Gross Margin—Supply Chain Impacts and Risks” and “—Liquidity and Capital Resources—Inventory Supply Chain.”

[0000858877-25-000007:mdna:45]
Loss Contingencies

[0000858877-25-000007:mdna:46]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-25-000007:mdna:47]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-25-000007:mdna:48]
[same as prior period, unchanged from 0000858877-24-000030:mdna:46]

[0000858877-25-000007:mdna:49]
[same as prior period, unchanged from 0000858877-24-000030:mdna:47]

[0000858877-25-000007:mdna:50]
[same as prior period, unchanged from 0000858877-24-000030:mdna:48]

[0000858877-25-000007:mdna:51]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first six months of fiscal 2025 and 2024.

[0000858877-25-000007:mdna:52]
[same as prior period, unchanged from 0000858877-24-000030:mdna:50]

[0000858877-25-000007:mdna:53]
[same as prior period, unchanged from 0000858877-24-000030:mdna:51]

[0000858877-25-000007:mdna:54]
[same as prior period, unchanged from 0000858877-24-000030:mdna:52]

[0000858877-25-000007:mdna:55]
[same as prior period, unchanged from 0000858877-24-000030:mdna:61]

[0000858877-25-000007:mdna:56]
[same as prior period, unchanged from 0000858877-24-000030:mdna:53]

[0000858877-25-000007:mdna:57]
[same as prior period, unchanged from 0000858877-24-000030:mdna:54]

[0000858877-25-000007:mdna:58]
[same as prior period, unchanged from 0000858877-24-000030:mdna:55]

[0000858877-25-000007:mdna:59]
[same as prior period, unchanged from 0000858877-24-000030:mdna:56]

[0000858877-25-000007:mdna:60]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was 15.9% and 16.7% in the second quarter of fiscal 2025 and 2024, respectively and 0.3% and 17.5% in the first six months of fiscal 2025 and 2024, respectively.

[0000858877-25-000007:mdna:61]
[same as prior period, unchanged from 0000858877-24-000030:mdna:58]

[0000858877-25-000007:mdna:62]
[same as prior period, unchanged from 0000858877-24-000030:mdna:59]

[0000858877-25-000007:mdna:63]
[same as prior period, unchanged from 0000858877-24-000030:mdna:60]

[0000858877-25-000007:mdna:64]
[same as prior period, unchanged from 0000858877-24-000030:mdna:62]

[0000858877-25-000007:mdna:65]
[same as prior period, unchanged from 0000858877-24-000030:mdna:63]

[0000858877-25-000007:mdna:66]
[same as prior period, unchanged from 0000858877-24-000030:mdna:64]

[0000858877-25-000007:mdna:67]
[same as prior period, unchanged from 0000858877-24-000030:mdna:65]

[0000858877-25-000007:mdna:68]
[same as prior period, unchanged from 0000858877-24-000030:mdna:66]

[0000858877-25-000007:mdna:69]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25,2025 |  | January 27,2024 |  | Variancein Dollars |  | Variance in Percent |  | January 25, 2025 |  | January 27, 2024 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 10,234 |  |  | $ | 9,232 |  |  | $ | 1,002 |  |  | 11 | % |  | $ | 20,348 |  |  | $ | 20,371 |  |  | $ | (23) |  |  | — | % |
| Percentage of revenue |  | 73.1 | % |  | 72.2 | % |  |  |  |  |  | 73.1 | % |  | 74.2 | % |  |  |  |  |
| Services |  | 3,757 |  |  | 3,559 |  |  | 198 |  |  | 6 | % |  | 7,484 |  |  | 7,088 |  |  | 396 |  |  | 6 | % |
| Percentage of revenue |  | 26.9 | % |  | 27.8 | % |  |  |  |  |  | 26.9 | % |  | 25.8 | % |  |  |  |  |
| Total |  | $ | 13,991 |  |  | $ | 12,791 |  |  | $ | 1,200 |  |  | 9 | % |  | $ | 27,832 |  |  | $ | 27,459 |  |  | $ | 373 |  |  | 1 | % |

[0000858877-25-000007:mdna:70]
[same as prior period, unchanged from 0000858877-24-000030:mdna:68]

[0000858877-25-000007:mdna:71]
Excluding Splunk, total revenue for the second quarter and first six months of fiscal 2025 decreased by 1% and 8%, respectively, as compared with the corresponding periods of fiscal 2024.

[0000858877-25-000007:mdna:72]
[same as prior period, unchanged from 0000858877-24-000030:mdna:70]

[0000858877-25-000007:mdna:73]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25,2025 |  | January 27,2024 |  | Variancein Dollars |  | Variance in Percent |  | January 25,2025 |  | January 27,2024 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 8,202 |  |  | $ | 7,510 |  |  | $ | 692 |  |  | 9 | % |  | $ | 16,454 |  |  | $ | 16,532 |  |  | $ | (78) |  |  | — | % |
| Percentage of revenue |  | 58.6 | % |  | 58.7 | % |  |  |  |  |  | 59.2 | % |  | 60.2 | % |  |  |  |  |
| EMEA |  | 3,855 |  |  | 3,484 |  |  | 371 |  |  | 11 | % |  | 7,444 |  |  | 7,148 |  |  | 296 |  |  | 4 | % |
| Percentage of revenue |  | 27.6 | % |  | 27.2 | % |  |  |  |  |  | 26.7 | % |  | 26.0 | % |  |  |  |  |
| APJC |  | 1,934 |  |  | 1,798 |  |  | 136 |  |  | 8 | % |  | 3,934 |  |  | 3,779 |  |  | 155 |  |  | 4 | % |
| Percentage of revenue |  | 13.8 | % |  | 14.1 | % |  |  |  |  |  | 14.1 | % |  | 13.8 | % |  |  |  |  |
| Total |  | $ | 13,991 |  |  | $ | 12,791 |  |  | $ | 1,200 |  |  | 9 | % |  | $ | 27,832 |  |  | $ | 27,459 |  |  | $ | 373 |  |  | 1 | % |

[0000858877-25-000007:mdna:74]
[same as prior period, unchanged from 0000858877-24-000030:mdna:72]

[0000858877-25-000007:mdna:75]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:76]
Total revenue increased by 9%. Product revenue increased by 11% and services revenue increased by 6%. Our total revenue reflected growth across each of our geographic segments.

[0000858877-25-000007:mdna:77]
[same as prior period, unchanged from 0000858877-24-000030:mdna:75]

[0000858877-25-000007:mdna:78]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:79]
Total revenue increased by 1%. Product revenue was flat and services revenue increased by 6%. Our total revenue reflected growth in the EMEA and APJC segments. Total revenue was flat in the Americas segment.

[0000858877-25-000007:mdna:80]
45

[0000858877-25-000007:mdna:81]
[same as prior period, unchanged from 0000858877-24-000030:mdna:76]

[0000858877-25-000007:mdna:82]
[same as prior period, unchanged from 0000858877-24-000030:mdna:77]

[0000858877-25-000007:mdna:83]
[same as prior period, unchanged from 0000858877-24-000030:mdna:78]

[0000858877-25-000007:mdna:84]
[same as prior period, unchanged from 0000858877-24-000030:mdna:79]

[0000858877-25-000007:mdna:85]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25,2025 |  | January 27,2024 |  | Variancein Dollars |  | Variance in Percent |  | January 25,2025 |  | January 27,2024 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,947 |  |  | $ | 5,346 |  |  | $ | 601 |  |  | 11 | % |  | $ | 11,950 |  |  | $ | 12,197 |  |  | $ | (247) |  |  | (2) | % |
| Percentage of product revenue |  | 58.1 | % |  | 57.9 | % |  |  |  |  |  | 58.7 | % |  | 59.9 | % |  |  |  |  |
| EMEA |  | 2,926 |  |  | 2,638 |  |  | 288 |  |  | 11 | % |  | 5,612 |  |  | 5,478 |  |  | 134 |  |  | 2 | % |
| Percentage of product revenue |  | 28.6 | % |  | 28.6 | % |  |  |  |  |  | 27.6 | % |  | 26.9 | % |  |  |  |  |
| APJC |  | 1,360 |  |  | 1,248 |  |  | 112 |  |  | 9 | % |  | 2,786 |  |  | 2,696 |  |  | 90 |  |  | 3 | % |
| Percentage of product revenue |  | 13.3 | % |  | 13.5 | % |  |  |  |  |  | 13.7 | % |  | 13.2 | % |  |  |  |  |
| Total |  | $ | 10,234 |  |  | $ | 9,232 |  |  | $ | 1,002 |  |  | 11 | % |  | $ | 20,348 |  |  | $ | 20,371 |  |  | $ | (23) |  |  | — | % |

[0000858877-25-000007:mdna:86]
[same as prior period, unchanged from 0000858877-24-000030:mdna:81]

[0000858877-25-000007:mdna:87]
[same as prior period, unchanged from 0000858877-24-000030:mdna:83]

[0000858877-25-000007:mdna:88]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:89]
Product revenue in the Americas segment increased by 11%, with growth in the enterprise and service provider and cloud markets, partially offset by a decline in the public sector market. From a country perspective, product revenue increased in the United States and Canada by 12% and 9%, respectively, partially offset by declines in Brazil and Mexico of 3% and 19%, respectively.

[0000858877-25-000007:mdna:90]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:91]
Product revenue in the Americas segment decreased by 2%, with declines in the public sector and service provider and cloud markets, partially offset by growth in the enterprise market. From a country perspective, product revenue decreased in the United States and Mexico by 2% and 21%, respectively, partially offset by growth in product revenue in Canada and Brazil of 6% and 7%, respectively.

[0000858877-25-000007:mdna:92]
[same as prior period, unchanged from 0000858877-24-000030:mdna:85]

[0000858877-25-000007:mdna:93]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:94]
Product revenue in the EMEA segment increased by 11%, with growth in the public sector and enterprise markets, partially offset by a decline in the service provider and cloud market. From a country perspective, product revenue increased in Germany, the United Kingdom and France by 11%, 8% and 14%, respectively.

[0000858877-25-000007:mdna:95]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:96]
Product revenue in the EMEA segment increased by 2%, driven by growth in the public sector and enterprise markets, partially offset by a decline in the service provider and cloud market. From a country perspective, product revenue increased in Germany by 5%, and by 10% in each of the United Kingdom and France.

[0000858877-25-000007:mdna:97]
[same as prior period, unchanged from 0000858877-24-000030:mdna:87]

[0000858877-25-000007:mdna:98]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:99]
Product revenue in the APJC segment increased by 9%, with growth across each of our customer markets. From a country perspective, product revenue increased in Japan, Australia, India and China by 10%, 16%, 23% and 23%, respectively.

[0000858877-25-000007:mdna:100]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:101]
Product revenue in the APJC segment increased by 3%, with growth in the public sector and service provider and cloud markets. Product revenue in the enterprise market was flat. From a country perspective, product revenue increased in Japan, Australia, India and China by 14%, 17%, 5% and 8%, respectively.

[0000858877-25-000007:mdna:102]
[same as prior period, unchanged from 0000858877-24-000030:mdna:89]

[0000858877-25-000007:mdna:103]
[same as prior period, unchanged from 0000858877-24-000030:mdna:90]

[0000858877-25-000007:mdna:104]
[same as prior period, unchanged from 0000858877-24-000030:mdna:91]

[0000858877-25-000007:mdna:105]
[same as prior period, unchanged from 0000858877-24-000030:mdna:92]

[0000858877-25-000007:mdna:106]
[same as prior period, unchanged from 0000858877-24-000030:mdna:93]

[0000858877-25-000007:mdna:107]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25,2025 |  | January 27,2024 |  | Variancein Dollars |  | Variance in Percent |  | January 25,2025 |  | January 27,2024 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking |  | $ | 6,850 |  |  | $ | 7,081 |  |  | $ | (231) |  |  | (3) | % |  | $ | 13,603 |  |  | $ | 15,904 |  |  | $ | (2,301) |  |  | (14) | % |
| Security |  | 2,111 |  |  | 973 |  |  | 1,138 |  |  | 117 | % |  | 4,129 |  |  | 1,984 |  |  | 2,145 |  |  | 108 | % |
| Collaboration |  | 996 |  |  | 989 |  |  | 7 |  |  | 1 | % |  | 2,081 |  |  | 2,106 |  |  | (25) |  |  | (1) | % |
| Observability |  | 277 |  |  | 188 |  |  | 89 |  |  | 47 | % |  | 535 |  |  | 378 |  |  | 157 |  |  | 42 | % |
| Total |  | $ | 10,234 |  |  | $ | 9,232 |  |  | $ | 1,002 |  |  | 11 | % |  | $ | 20,348 |  |  | $ | 20,371 |  |  | $ | (23) |  |  | — | % |

[0000858877-25-000007:mdna:108]
[same as prior period, unchanged from 0000858877-24-000030:mdna:95]

[0000858877-25-000007:mdna:109]
[same as prior period, unchanged from 0000858877-24-000030:mdna:97]

[0000858877-25-000007:mdna:110]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:111]
The Networking product category consists of our core networking technologies of switching, routing, wireless, and servers. Revenue from the Networking product category decreased by 3%, or $231 million, as the second quarter of fiscal 2024 included the remaining elevated levels of product shipments. We experienced a revenue decline in Servers, partially offset by growth in Wireless and Switching.

[0000858877-25-000007:mdna:112]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:113]
Revenue from the Networking product category decreased by 14%, or $2.3 billion. Revenue declined in both campus switching and data center switching, primarily driven by declines in our Catalyst 9000 series and Nexus 9000 series offerings. We experienced a revenue decline in Enterprise Routing, although we saw revenue growth in our SD-WAN offerings. The decrease in Wireless was primarily driven by our WiFi-6 products. We also saw a decline in Internet Infrastructure and Servers.

[0000858877-25-000007:mdna:114]
[same as prior period, unchanged from 0000858877-24-000030:mdna:99]

[0000858877-25-000007:mdna:115]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:116]
The Security product category consists of our Network Security, Identity and Access Management, SASE and Threat Intelligence, Detection, and Response offerings. Revenue in our Security product category increased by 117%, or $1.1 billion, primarily driven by Threat Intelligence, Detection, and Response offerings, which includes the offerings from Splunk, and growth in our SASE and Network Security offerings. Excluding Splunk, product revenue in the Security product category increased 4%.

[0000858877-25-000007:mdna:117]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:118]
Revenue from the Security product category increased by 108%, or $2.1 billion, primarily driven by Threat Intelligence, Detection, and Response offerings, which includes the offerings from Splunk, and to a lesser extent, growth in our SASE and Network Security offerings. Excluding Splunk, product revenue in the Security product category increased 3%.

[0000858877-25-000007:mdna:119]
[same as prior period, unchanged from 0000858877-24-000030:mdna:101]

[0000858877-25-000007:mdna:120]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:121]
The Collaboration product category consists of our Webex Suite, Collaboration Devices, Contact Center and CPaaS offerings. Revenue in our Collaboration product category increased by 1%, or $7 million, primarily driven by growth in our Contact Center, CPaaS and Collaboration Devices offerings, partially offset by declines in our On-Prem Webex Suite offerings.

[0000858877-25-000007:mdna:122]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:123]
Revenue from our Collaboration product category decreased by 1%, or $25 million, primarily driven by declines in our On-Prem Webex Suite offerings, partially offset by growth in our Contact Center and CPaaS offerings.

[0000858877-25-000007:mdna:124]
47

[0000858877-25-000007:mdna:125]
[same as prior period, unchanged from 0000858877-24-000030:mdna:105]

[0000858877-25-000007:mdna:126]
[same as prior period, unchanged from 0000858877-24-000030:mdna:106]

[0000858877-25-000007:mdna:127]
[same as prior period, unchanged from 0000858877-24-000030:mdna:103]

[0000858877-25-000007:mdna:128]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:129]
The Observability product category consists of our network assurance, monitoring and analytics and observability suite offerings. Revenue in our Observability product category increased 47%, or $89 million, primarily driven by our Observability Suite offerings. Excluding Splunk, revenue in the Observability product category increased 3%.

[0000858877-25-000007:mdna:130]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:131]
Revenue from the Observability product category increased by 42%, or $157 million, driven by primarily by our Observability Suite offerings. Excluding Splunk, revenue in the Observability product category increased 2%.

[0000858877-25-000007:mdna:132]
[same as prior period, unchanged from 0000858877-24-000030:mdna:107]

[0000858877-25-000007:mdna:133]
[same as prior period, unchanged from 0000858877-24-000030:mdna:108]

[0000858877-25-000007:mdna:134]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25,2025 |  | January 27,2024 |  | Variancein Dollars |  | Variance in Percent |  | January 25,2025 |  | January 27,2024 |  | Variance in Dollars |  | Variance in Percent |
| Services revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,255 |  |  | $ | 2,164 |  |  | $ | 91 |  |  | 4 | % |  | $ | 4,505 |  |  | $ | 4,335 |  |  | $ | 170 |  |  | 4 | % |
| Percentage of service revenue |  | 60.0 | % |  | 60.8 | % |  |  |  |  |  | 60.2 | % |  | 61.2 | % |  |  |  |  |
| EMEA |  | 929 |  |  | 846 |  |  | 83 |  |  | 10 | % |  | 1,832 |  |  | 1,670 |  |  | 162 |  |  | 10 | % |
| Percentage of service revenue |  | 24.7 | % |  | 23.8 | % |  |  |  |  |  | 24.5 | % |  | 23.6 | % |  |  |  |  |
| APJC |  | 573 |  |  | 550 |  |  | 23 |  |  | 4 | % |  | 1,148 |  |  | 1,084 |  |  | 64 |  |  | 6 | % |
| Percentage of service revenue |  | 15.3 | % |  | 15.4 | % |  |  |  |  |  | 15.3 | % |  | 15.2 | % |  |  |  |  |
| Total |  | $ | 3,757 |  |  | $ | 3,559 |  |  | $ | 198 |  |  | 6 | % |  | $ | 7,484 |  |  | $ | 7,088 |  |  | $ | 396 |  |  | 6 | % |

[0000858877-25-000007:mdna:135]
[same as prior period, unchanged from 0000858877-24-000030:mdna:110]

[0000858877-25-000007:mdna:136]
Services revenue increased 6% in the second quarter of fiscal 2025 compared with the second quarter of fiscal 2024, primarily driven by Splunk and advisory services. Services revenue increased across all of our geographic segments for the second quarter of fiscal 2025.

[0000858877-25-000007:mdna:137]
Services revenue increased 6% in the first six months of fiscal 2025 compared to the first six months of fiscal 2024, primarily driven by Splunk and revenue growth in our solution support offerings, network support offerings and advisory services. Services revenue increased across each of our geographic segments.

[0000858877-25-000007:mdna:138]
[same as prior period, unchanged from 0000858877-24-000030:mdna:112]

[0000858877-25-000007:mdna:139]
[same as prior period, unchanged from 0000858877-24-000030:mdna:113]

[0000858877-25-000007:mdna:140]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | January 25,2025 |  | January 27,2024 |  | January 25,2025 |  | January 27,2024 |  | January 25,2025 |  | January 27,2024 |  | January 25,2025 |  | January 27,2024 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 6,521 |  |  | $ | 5,789 |  |  | 63.7 | % |  | 62.7 | % |  | $ | 13,109 |  |  | $ | 12,971 |  |  | 64.4 | % |  | 63.7 | % |
| Services |  | 2,590 |  |  | 2,428 |  |  | 68.9 | % |  | 68.2 | % |  | 5,123 |  |  | 4,803 |  |  | 68.5 | % |  | 67.8 | % |
| Total |  | $ | 9,111 |  |  | $ | 8,217 |  |  | 65.1 | % |  | 64.2 | % |  | $ | 18,232 |  |  | $ | 17,774 |  |  | 65.5 | % |  | 64.7 | % |

[0000858877-25-000007:mdna:141]
[same as prior period, unchanged from 0000858877-24-000030:mdna:119]

[0000858877-25-000007:mdna:142]
[same as prior period, unchanged from 0000858877-24-000030:mdna:120]

[0000858877-25-000007:mdna:143]
[same as prior period, unchanged from 0000858877-24-000030:mdna:115]

[0000858877-25-000007:mdna:144]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the second quarter and first six months of fiscal 2025, as compared with the corresponding prior year periods:

[0000858877-25-000007:mdna:145]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Six Months Ended |
| Fiscal 2024 |  | 62.7 | % |  | 63.7 | % |
| Productivity (1) |  | 1.5 | % |  | 0.8 | % |
| Product pricing |  | (1.5) | % |  | (1.7) | % |
| Mix of products sold |  | 2.5 | % |  | 3.2 | % |
| Amortization of purchased intangible assets |  | (1.4) | % |  | (1.5) | % |
| Others |  | (0.1) | % |  | (0.1) | % |
| Fiscal 2025 |  | 63.7 | % |  | 64.4 | % |

[0000858877-25-000007:mdna:146]
[same as prior period, unchanged from 0000858877-24-000030:mdna:118]

[0000858877-25-000007:mdna:147]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:148]
Product gross margin increased by 1.0 percentage points primarily driven by favorable product mix largely due to benefits from Splunk and productivity benefits, partially offset by negative impacts from pricing and the amortization of purchased intangible assets primarily related to Splunk.

[0000858877-25-000007:mdna:149]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:150]
Product gross margin increased by 0.7 percentage points primarily driven by benefits from Splunk, favorable product mix, and productivity benefits, driven by an import duty benefit, partially offset by negative impacts from pricing and the amortization of purchased intangible assets primarily related to Splunk.

[0000858877-25-000007:mdna:151]
[same as prior period, unchanged from 0000858877-24-000030:mdna:123]

[0000858877-25-000007:mdna:152]
[same as prior period, unchanged from 0000858877-24-000030:mdna:124]

[0000858877-25-000007:mdna:153]
[same as prior period, unchanged from 0000858877-24-000030:mdna:125]

[0000858877-25-000007:mdna:154]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:155]
Our services gross margin percentage increased by 0.7 percentage points primarily due to higher sales volume and lower delivery costs, partially offset by higher headcount-related costs and an unfavorable mix of service offerings.

[0000858877-25-000007:mdna:156]
[same as prior period, unchanged from 0000858877-24-000030:mdna:128]

[0000858877-25-000007:mdna:157]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:158]
Services gross margin percentage increased by 0.7 percentage points primarily due to higher sales volume and lower delivery costs, partially offset by higher headcount-related costs and an unfavorable mix of service offerings.

[0000858877-25-000007:mdna:159]
[same as prior period, unchanged from 0000858877-24-000030:mdna:138]

[0000858877-25-000007:mdna:160]
[same as prior period, unchanged from 0000858877-24-000030:mdna:139]

[0000858877-25-000007:mdna:161]
[same as prior period, unchanged from 0000858877-24-000030:mdna:129]

[0000858877-25-000007:mdna:162]
[same as prior period, unchanged from 0000858877-24-000030:mdna:130]

[0000858877-25-000007:mdna:163]
|  | Three Months Ended |  | Six Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | January 25,2025 |  | January 27,2024 |  | January 25,2025 |  | January 27,2024 |  | January 25,2025 |  | January 27,2024 |  | January 25,2025 |  | January 27,2024 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 5,545 |  |  | $ | 4,932 |  |  | 67.6 | % |  | 65.7 | % |  | $ | 11,285 |  |  | $ | 10,901 |  |  | 68.6 | % |  | 65.9 | % |
| EMEA | 2,750 |  |  | 2,373 |  |  | 71.3 | % |  | 68.1 | % |  | 5,272 |  |  | 4,919 |  |  | 70.8 | % |  | 68.8 | % |
| APJC | 1,320 |  |  | 1,226 |  |  | 68.3 | % |  | 68.2 | % |  | 2,648 |  |  | 2,554 |  |  | 67.3 | % |  | 67.6 | % |
| Segment total | 9,614 |  |  | 8,532 |  |  | 68.7 | % |  | 66.7 | % |  | 19,204 |  |  | 18,373 |  |  | 69.0 | % |  | 66.9 | % |
| Unallocated corporate items (1) | (503) |  |  | (315) |  |  |  |  |  |  | (972) |  |  | (599) |  |  |  |  |  |
| Total | $ | 9,111 |  |  | $ | 8,217 |  |  | 65.1 | % |  | 64.2 | % |  | $ | 18,232 |  |  | $ | 17,774 |  |  | 65.5 | % |  | 64.7 | % |

[0000858877-25-000007:mdna:164]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-25-000007:mdna:165]
[same as prior period, unchanged from 0000858877-24-000030:mdna:133]

[0000858877-25-000007:mdna:166]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:167]
[same as prior period, unchanged from 0000858877-24-000030:mdna:135]

[0000858877-25-000007:mdna:168]
Gross margin percentage in our EMEA segment increased primarily due to favorable product mix, productivity improvements and higher services gross margin, partially offset by pricing erosion.

[0000858877-25-000007:mdna:169]
The slight increase in the APJC segment gross margin percentage was primarily due to favorable product mix and positive impacts from productivity improvements, partially offset by pricing erosion.

[0000858877-25-000007:mdna:170]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:171]
The Americas segment had a gross margin percentage increase driven by favorable product mix, and to a lesser extent, positive impacts from productivity improvements, partially offset by pricing erosion.

[0000858877-25-000007:mdna:172]
The gross margin percentage increase in our EMEA segment was primarily due to favorable product mix and positive impacts from productivity improvements, partially offset by pricing erosion.

[0000858877-25-000007:mdna:173]
The APJC segment gross margin percentage decrease was primarily driven by pricing erosion, partially offset by favorable product mix.

[0000858877-25-000007:mdna:174]
[same as prior period, unchanged from 0000858877-24-000030:mdna:140]

[0000858877-25-000007:mdna:175]
[same as prior period, unchanged from 0000858877-24-000030:mdna:141]

[0000858877-25-000007:mdna:176]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25,2025 |  | January 27,2024 |  | Variancein Dollars |  | Variance in Percent |  | January 25,2025 |  | January 27,2024 |  | Variance in Dollars |  | Variance in Percent |
| Research and development | $ | 2,299 |  |  | $ | 1,943 |  |  | $ | 356 |  |  | 18 | % |  | $ | 4,585 |  |  | $ | 3,856 |  |  | $ | 729 |  |  | 19 | % |
| Percentage of revenue | 16.4 | % |  | 15.2 | % |  |  |  |  |  | 16.5 | % |  | 14.0 | % |  |  |  |  |
| Sales and marketing | 2,672 |  |  | 2,458 |  |  | 214 |  |  | 9 | % |  | 5,424 |  |  | 4,964 |  |  | 460 |  |  | 9 | % |
| Percentage of revenue | 19.1 | % |  | 19.2 | % |  |  |  |  |  | 19.5 | % |  | 18.1 | % |  |  |  |  |
| General and administrative | 752 |  |  | 642 |  |  | 110 |  |  | 17 | % |  | 1,547 |  |  | 1,314 |  |  | 233 |  |  | 18 | % |
| Percentage of revenue | 5.4 | % |  | 5.0 | % |  |  |  |  |  | 5.6 | % |  | 4.8 | % |  |  |  |  |
| Total | $ | 5,723 |  |  | $ | 5,043 |  |  | $ | 680 |  |  | 13 | % |  | $ | 11,556 |  |  | $ | 10,134 |  |  | $ | 1,422 |  |  | 14 | % |
| Percentage of revenue | 40.9 | % |  | 39.4 | % |  |  |  |  |  | 41.5 | % |  | 36.9 | % |  |  |  |  |

[0000858877-25-000007:mdna:177]
[same as prior period, unchanged from 0000858877-24-000030:mdna:157]

[0000858877-25-000007:mdna:178]
[same as prior period, unchanged from 0000858877-24-000030:mdna:158]

[0000858877-25-000007:mdna:179]
[same as prior period, unchanged from 0000858877-24-000030:mdna:144]

[0000858877-25-000007:mdna:180]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:181]
[same as prior period, unchanged from 0000858877-24-000030:mdna:145]

[0000858877-25-000007:mdna:182]
[same as prior period, unchanged from 0000858877-24-000030:mdna:146]

[0000858877-25-000007:mdna:183]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:184]
R&D expenses increased due to incremental expenses from Splunk, higher headcount-related expenses, higher cash compensation from acquisitions, higher share-based compensation expense and higher discretionary spending.

[0000858877-25-000007:mdna:185]
[same as prior period, unchanged from 0000858877-24-000030:mdna:147]

[0000858877-25-000007:mdna:186]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:187]
[same as prior period, unchanged from 0000858877-24-000030:mdna:148]

[0000858877-25-000007:mdna:188]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:189]
Sales and marketing expenses increased primarily due to incremental expenses from Splunk, higher headcount-related expenses, higher cash compensation from acquisitions, higher discretionary spending and higher share-based compensation expense, partially offset by lower contracted services spending.

[0000858877-25-000007:mdna:190]
[same as prior period, unchanged from 0000858877-24-000030:mdna:149]

[0000858877-25-000007:mdna:191]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:192]
G&A expenses increased primarily due to incremental expenses from Splunk, higher headcount-related expenses and higher share-based compensation expense.

[0000858877-25-000007:mdna:193]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:194]
G&A expenses increased due to incremental expenses from Splunk, higher headcount-related expenses, higher share-based compensation expense and higher acquisition and divestitures related costs, partially offset by lower contracted services spending.

[0000858877-25-000007:mdna:195]
[same as prior period, unchanged from 0000858877-24-000030:mdna:151]

[0000858877-25-000007:mdna:196]
In the second quarter of fiscal 2025, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $20 million, or 0.4%, compared with the second quarter of fiscal 2024.

[0000858877-25-000007:mdna:197]
In the first six months of fiscal 2025, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $11 million, or 0.1%, compared with the first six months of fiscal 2024.

[0000858877-25-000007:mdna:198]
[same as prior period, unchanged from 0000858877-24-000030:mdna:153]

[0000858877-25-000007:mdna:199]
[same as prior period, unchanged from 0000858877-24-000030:mdna:154]

[0000858877-25-000007:mdna:200]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25,2025 |  | January 27,2024 |  | January 25,2025 |  | January 27,2024 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 340 |  |  | $ | 180 |  |  | $ | 665 |  |  | $ | 366 |  |
| Operating expenses |  | 265 |  |  | 66 |  |  | 530 |  |  | 133 |  |
| Total |  | $ | 605 |  |  | $ | 246 |  |  | $ | 1,195 |  |  | $ | 499 |  |

[0000858877-25-000007:mdna:201]
For each of the second quarter and first six months of fiscal 2025, the increase in amortization of purchased intangible assets was primarily due to amortization of purchased intangibles from our recent acquisitions, including the acquisition of Splunk, and impairment charges of $19 million. The increase was partially offset by certain purchased intangible assets that became

[0000858877-25-000007:mdna:202]
[same as prior period, unchanged from 0000858877-24-000030:mdna:174]

[0000858877-25-000007:mdna:203]
[same as prior period, unchanged from 0000858877-24-000030:mdna:175]

[0000858877-25-000007:mdna:204]
fully amortized. The impairment charges were as a result of declines in estimated fair value resulting from the reductions in or the elimination of expected future cash flows associated with certain technology intangible assets.

[0000858877-25-000007:mdna:205]
[same as prior period, unchanged from 0000858877-24-000030:mdna:159]

[0000858877-25-000007:mdna:206]
In the first quarter of fiscal 2025, we announced a restructuring plan in order to allow us to invest in key growth opportunities and drive more efficiencies in our business. This restructuring plan is expected to impact approximately 7% of our global workforce with estimated pre-tax charges of approximately $1 billion. In connection with this restructuring plan, we incurred charges of $10 million and $675 million in the second quarter and first six months of fiscal 2025. We expect this plan to be substantially completed by the end of fiscal 2025.

[0000858877-25-000007:mdna:207]
[same as prior period, unchanged from 0000858877-24-000030:mdna:161]

[0000858877-25-000007:mdna:208]
[same as prior period, unchanged from 0000858877-24-000030:mdna:162]

[0000858877-25-000007:mdna:209]
[same as prior period, unchanged from 0000858877-24-000030:mdna:163]

[0000858877-25-000007:mdna:210]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25,2025 |  | January 27,2024 |  | January 25,2025 |  | January 27,2024 |
| Operating income |  | $ | 3,113 |  |  | $ | 3,096 |  |  | $ | 5,471 |  |  | $ | 7,372 |  |
| Operating income as a percentage of revenue |  | 22.3 | % |  | 24.2 | % |  | 19.7 | % |  | 26.8 | % |

[0000858877-25-000007:mdna:211]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:212]
Operating income increased by 1%, and operating income as a percentage of revenue decreased by 1.9 percentage points. The increase in operating income was primarily due to a revenue increase partially offset by higher operating expenses, including incremental expenses from Splunk, and higher amortization of purchased intangible assets. The decrease in operating income as a percentage of revenue was primarily due to an operating expenses percentage increase.

[0000858877-25-000007:mdna:213]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:214]
Operating income decreased by 26%, and operating income as a percentage of revenue decreased by 7.1 percentage points. These changes resulted primarily from incremental expenses from Splunk, higher restructuring and other charges and higher amortization of purchased intangible assets, partially offset by a revenue increase and gross margin percentage increase (driven by favorable product mix and productivity improvements, partially offset by pricing erosion).

[0000858877-25-000007:mdna:215]
[same as prior period, unchanged from 0000858877-24-000030:mdna:167]

[0000858877-25-000007:mdna:216]
[same as prior period, unchanged from 0000858877-24-000030:mdna:168]

[0000858877-25-000007:mdna:217]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25,2025 |  | January 27,2024 |  | Variancein Dollars |  | January 25,2025 |  | January 27,2024 |  | Variance in Dollars |
| Interest income |  | $ | 238 |  |  | $ | 324 |  |  | $ | (86) |  |  | $ | 524 |  |  | $ | 684 |  |  | $ | (160) |  |
| Interest expense |  | (404) |  |  | (120) |  |  | (284) |  |  | (822) |  |  | (231) |  |  | (591) |  |
| Interest income (expense), net |  | $ | (166) |  |  | $ | 204 |  |  | $ | (370) |  |  | $ | (298) |  |  | $ | 453 |  |  | $ | (751) |  |

[0000858877-25-000007:mdna:218]
For each of the second quarter and first six months of fiscal 2025, the decrease in interest income was driven by a lower average balance of cash and available-for-sale debt investments and lower interest rates. The increase in interest expense was primarily driven by the issuances of senior notes and commercial paper.

[0000858877-25-000007:mdna:219]
[same as prior period, unchanged from 0000858877-24-000030:mdna:181]

[0000858877-25-000007:mdna:220]
[same as prior period, unchanged from 0000858877-24-000030:mdna:182]

[0000858877-25-000007:mdna:221]
[same as prior period, unchanged from 0000858877-24-000030:mdna:172]

[0000858877-25-000007:mdna:222]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 25,2025 |  | January 27,2024 |  | Variancein Dollars |  | January 25,2025 |  | January 27,2024 |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | (20) |  |  | $ | (23) |  |  | $ | 3 |  |  | $ | (45) |  |  | $ | (43) |  |  | $ | (2) |  |
| Marketable equity investments |  | 21 |  |  | 62 |  |  | (41) |  |  | 45 |  |  | 16 |  |  | 29 |  |
| Privately held investments |  | (27) |  |  | (150) |  |  | 123 |  |  | 47 |  |  | (155) |  |  | 202 |  |
| Net gains (losses) on investments |  | (26) |  |  | (111) |  |  | 85 |  |  | 47 |  |  | (182) |  |  | 229 |  |
| Other gains (losses), net |  | (34) |  |  | (28) |  |  | (6) |  |  | (66) |  |  | (40) |  |  | (26) |  |
| Other income (loss), net |  | $ | (60) |  |  | $ | (139) |  |  | $ | 79 |  |  | $ | (19) |  |  | $ | (222) |  |  | $ | 203 |  |

[0000858877-25-000007:mdna:223]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:224]
The change in our other income (loss), net was primarily driven by lower impairment charges on our privately held investments partially offset by lower gains on our marketable equity investments.

[0000858877-25-000007:mdna:225]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:226]
The change in our other income (loss), net was primarily driven by lower impairment charges on our privately held investments, and higher unrealized gains on our privately held investments and marketable equity investments.

[0000858877-25-000007:mdna:227]
Provision for Income Taxes

[0000858877-25-000007:mdna:228]
Three Months Ended January 25, 2025 Compared with Three Months Ended January 27, 2024

[0000858877-25-000007:mdna:229]
The provision for income taxes resulted in an effective tax rate of 15.9% for the second quarter of fiscal 2025 compared with an effective tax rate of 16.7% for the second quarter of fiscal 2024. The decrease in the effective tax rate was primarily due to an increase in the U.S. federal research tax credit benefit.

[0000858877-25-000007:mdna:230]
Six Months Ended January 25, 2025 Compared with Six Months Ended January 27, 2024

[0000858877-25-000007:mdna:231]
The provision for income taxes resulted in an effective tax rate of 0.3% for the first six months of fiscal 2025 compared with 17.5% for the first six months of fiscal 2024. The decrease in the effective tax rate was primarily due to a $720 million benefit related to a U.S. Tax Court opinion issued during the first quarter of fiscal 2025 regarding the U.S. taxation of deemed foreign dividends in the transition year of the Tax Cuts and Jobs Act (our fiscal 2018) and an increase in the U.S. federal research tax credit benefit.

[0000858877-25-000007:mdna:232]
[same as prior period, unchanged from 0000858877-24-000030:mdna:195]

[0000858877-25-000007:mdna:233]
[same as prior period, unchanged from 0000858877-24-000030:mdna:196]

[0000858877-25-000007:mdna:234]
[same as prior period, unchanged from 0000858877-24-000030:mdna:183]

[0000858877-25-000007:mdna:235]
[same as prior period, unchanged from 0000858877-24-000030:mdna:184]

[0000858877-25-000007:mdna:236]
[same as prior period, unchanged from 0000858877-24-000030:mdna:185]

[0000858877-25-000007:mdna:237]
[same as prior period, unchanged from 0000858877-24-000030:mdna:186]

[0000858877-25-000007:mdna:238]
|  | January 25,2025 |  | July 27,2024 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 8,556 |  |  | $ | 7,508 |  |  | $ | 1,048 |  |
| Available-for-sale debt investments | 7,958 |  |  | 9,865 |  |  | (1,907) |  |
| Marketable equity securities | 339 |  |  | 481 |  |  | (142) |  |
| Total | $ | 16,853 |  |  | $ | 17,854 |  |  | $ | (1,001) |  |

[0000858877-25-000007:mdna:239]
The net decrease in cash and cash equivalents and investments in the first six months of fiscal 2025 was primarily driven by cash returned to stockholders in the form of repurchases of common stock of $3.2 billion and cash dividends of $3.2 billion, capital expenditures of $0.4 billion and net cash paid for acquisitions and divestitures of $0.3 billion. These uses of cash were partially offset by net cash provided by operating activities of $5.9 billion.

[0000858877-25-000007:mdna:240]
[same as prior period, unchanged from 0000858877-24-000030:mdna:189]

[0000858877-25-000007:mdna:241]
Securities Lending   We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 25, 2025 and July 27, 2024, we had no outstanding securities lending transactions.

[0000858877-25-000007:mdna:242]
[same as prior period, unchanged from 0000858877-24-000030:mdna:191]

[0000858877-25-000007:mdna:243]
[same as prior period, unchanged from 0000858877-24-000030:mdna:192]

[0000858877-25-000007:mdna:244]
|  | Six Months Ended |
|  | January 25,2025 |  | January 27,2024 |
| Net cash provided by operating activities | $ | 5,902 |  |  | $ | 3,179 |  |
| Acquisition of property and equipment | (427) |  |  | (304) |  |
| Free cash flow | $ | 5,475 |  |  | $ | 2,875 |  |

[0000858877-25-000007:mdna:245]
[same as prior period, unchanged from 0000858877-24-000030:mdna:194]

[0000858877-25-000007:mdna:246]
[same as prior period, unchanged from 0000858877-24-000030:mdna:205]

[0000858877-25-000007:mdna:247]
[same as prior period, unchanged from 0000858877-24-000030:mdna:206]

[0000858877-25-000007:mdna:248]
[same as prior period, unchanged from 0000858877-24-000030:mdna:197]

[0000858877-25-000007:mdna:249]
[same as prior period, unchanged from 0000858877-24-000030:mdna:198]

[0000858877-25-000007:mdna:250]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2025 |  |  |  |  |  |  |  |  |  |  |  |  |
| January 25, 2025 |  | $ | 0.40 |  |  | $ | 1,593 |  |  | 21 |  |  | $ | 58.58 |  |  | $ | 1,236 |  |  | $ | 2,829 |  |
| October 26, 2024 |  | $ | 0.40 |  |  | $ | 1,592 |  |  | 40 |  |  | $ | 49.56 |  |  | $ | 2,003 |  |  | $ | 3,595 |  |
| Fiscal 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 27, 2024 |  | $ | 0.40 |  |  | $ | 1,606 |  |  | 43 |  |  | $ | 46.80 |  |  | $ | 2,002 |  |  | $ | 3,608 |  |
| April 27, 2024 |  | $ | 0.40 |  |  | $ | 1,615 |  |  | 26 |  |  | $ | 49.22 |  |  | $ | 1,256 |  |  | $ | 2,871 |  |
| January 27, 2024 |  | $ | 0.39 |  |  | $ | 1,583 |  |  | 25 |  |  | $ | 49.54 |  |  | $ | 1,254 |  |  | $ | 2,837 |  |
| October 28, 2023 |  | $ | 0.39 |  |  | $ | 1,580 |  |  | 23 |  |  | $ | 54.53 |  |  | $ | 1,252 |  |  | $ | 2,832 |  |

[0000858877-25-000007:mdna:251]
On February 12, 2025, our Board of Directors declared a quarterly dividend of $0.41 per common share to be paid on April 23, 2025, to all stockholders of record as of the close of business on April 3, 2025. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-25-000007:mdna:252]
On February 12, 2025, our Board of Directors authorized a $15 billion increase to the stock repurchase program. The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $17 billion, with no termination date.

[0000858877-25-000007:mdna:253]
[same as prior period, unchanged from 0000858877-24-000030:mdna:202]

[0000858877-25-000007:mdna:254]
|  | January 25,2025 |  | July 27,2024 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,669 |  |  | $ | 6,685 |  |  | $ | (1,016) |  |

[0000858877-25-000007:mdna:255]
Our accounts receivable net, as of January 25, 2025 decreased by approximately 15%, as compared with the end of fiscal 2024, primarily due to timing and amount of product and service billings in the second quarter of fiscal 2025 compared with the fourth quarter of fiscal 2024.

[0000858877-25-000007:mdna:256]
[same as prior period, unchanged from 0000858877-24-000030:mdna:219]

[0000858877-25-000007:mdna:257]
[same as prior period, unchanged from 0000858877-24-000030:mdna:220]

[0000858877-25-000007:mdna:258]
[same as prior period, unchanged from 0000858877-24-000030:mdna:207]

[0000858877-25-000007:mdna:259]
|  | January 25,2025 |  | July 27,2024 |  | July 29,2023 |  | Variance vs. July 27, 2024 |  | Variance vs. July 29, 2023 |
| Inventories | $ | 2,927 |  |  | $ | 3,373 |  |  | $ | 3,644 |  |  | $ | (446) |  |  | $ | (717) |  |
| Inventory purchase commitments | $ | 5,824 |  |  | $ | 5,158 |  |  | $ | 7,253 |  |  | $ | 666 |  |  | $ | (1,429) |  |
| Inventory deposits and prepayments | $ | 1,003 |  |  | $ | 973 |  |  | $ | 1,109 |  |  | $ | 30 |  |  | $ | (106) |  |

[0000858877-25-000007:mdna:260]
[same as prior period, unchanged from 0000858877-24-000030:mdna:209]

[0000858877-25-000007:mdna:261]
|  | January 25,2025 |  | July 27,2024 |  | July 29,2023 |  | Variance vs. July 27, 2024 |  | Variance vs.July 29, 2023 |
| Less than 1 year | $ | 5,054 |  |  | $ | 3,952 |  |  | $ | 5,270 |  |  | $ | 1,102 |  |  | $ | (216) |  |
| 1 to 3 years | 681 |  |  | 1,085 |  |  | 1,783 |  |  | (404) |  |  | (1,102) |  |
| 3 to 5 years | 89 |  |  | 121 |  |  | 200 |  |  | (32) |  |  | (111) |  |
| Total | $ | 5,824 |  |  | $ | 5,158 |  |  | $ | 7,253 |  |  | $ | 666 |  |  | $ | (1,429) |  |

[0000858877-25-000007:mdna:262]
Inventory as of January 25, 2025 decreased by 13% and inventory purchase commitments with contract manufacturers and suppliers increased by 13% from our balances at the end of fiscal 2024. The combined increase in our inventory and inventory purchase commitments was 3% as compared with the end of fiscal 2024.

[0000858877-25-000007:mdna:263]
[same as prior period, unchanged from 0000858877-24-000030:mdna:212]

[0000858877-25-000007:mdna:264]
[same as prior period, unchanged from 0000858877-24-000030:mdna:213]

[0000858877-25-000007:mdna:265]
[same as prior period, unchanged from 0000858877-24-000030:mdna:214]

[0000858877-25-000007:mdna:266]
[same as prior period, unchanged from 0000858877-24-000030:mdna:215]

[0000858877-25-000007:mdna:267]
|  | January 25,2025 |  | July 27,2024 |  | Increase (Decrease) |
| Loan receivables, net | $ | 5,378 |  |  | $ | 5,808 |  |  | $ | (430) |  |
| Lease receivables, net | 936 |  |  | 906 |  |  | 30 |  |
| Total, net | $ | 6,314 |  |  | $ | 6,714 |  |  | $ | (400) |  |

[0000858877-25-000007:mdna:268]
Financing Receivables  Our financing arrangements include loans and leases. Our loan receivables include customer financing for purchases of our hardware, software and services (including technical support and advanced services), and also may include additional funds for other costs associated with network installation and integration of our products and services. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Financing receivables decreased by 6% as compared with the end of fiscal 2024.

[0000858877-25-000007:mdna:269]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third

[0000858877-25-000007:mdna:270]
[same as prior period, unchanged from 0000858877-24-000030:mdna:229]

[0000858877-25-000007:mdna:271]
[same as prior period, unchanged from 0000858877-24-000030:mdna:230]

[0000858877-25-000007:mdna:272]
parties, with payment terms generally ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-25-000007:mdna:273]
The volume of channel partner financing was $12.2 billion and $14.8 billion for the first six months of fiscal 2025 and 2024, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.2 billion as of January 25, 2025 and July 27, 2024, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of January 25, 2025, the total maximum potential future payments related to these guarantees was approximately $125 million, of which approximately $13 million was recorded as deferred revenue.

[0000858877-25-000007:mdna:274]
[same as prior period, unchanged from 0000858877-24-000030:mdna:223]

[0000858877-25-000007:mdna:275]
[same as prior period, unchanged from 0000858877-24-000030:mdna:224]

[0000858877-25-000007:mdna:276]
|  | Maturity Date |  | January 25,2025 |  | July 27,2024 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | $ | 500 |  |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 1,000 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 2,000 |  |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 2,500 |  |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 2,500 |  |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 2,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 2,000 |  |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 1,000 |  |
| Total |  |  | $ | 20,250 |  |  | $ | 20,250 |  |

[0000858877-25-000007:mdna:277]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of January 25, 2025.

[0000858877-25-000007:mdna:278]
Commercial Paper  We have a short-term debt financing program in which up to $15.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had $10.9 billion in commercial paper notes outstanding as of each of January 25, 2025 and July 27, 2024.

[0000858877-25-000007:mdna:279]
Credit Facility  On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of January 25, 2025, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.

[0000858877-25-000007:mdna:280]
[same as prior period, unchanged from 0000858877-24-000030:mdna:241]

[0000858877-25-000007:mdna:281]
[same as prior period, unchanged from 0000858877-24-000030:mdna:242]

[0000858877-25-000007:mdna:282]
[same as prior period, unchanged from 0000858877-24-000030:mdna:231]

[0000858877-25-000007:mdna:283]
|  | January 25,2025 |  | July 27,2024 |  | Increase (Decrease) |
| Product | $ | 20,321 |  |  | $ | 20,055 |  |  | $ | 266 |  |
| Services | 20,947 |  |  | 20,993 |  |  | (46) |  |
| Total | $ | 41,268 |  |  | $ | 41,048 |  |  | $ | 220 |  |
| Short-term RPO | $ | 21,017 |  |  | $ | 20,882 |  |  | $ | 135 |  |
| Long-term RPO | 20,251 |  |  | 20,166 |  |  | 85 |  |
| Total | $ | 41,268 |  |  | $ | 41,048 |  |  | $ | 220 |  |

[0000858877-25-000007:mdna:284]
Total remaining performance obligations as of January 25, 2025 increased 1% compared to the end of fiscal 2024. Remaining performance obligations for product increased by 1% compared to the end of fiscal 2024. Remaining performance obligations for services were flat. We expect approximately 51% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-25-000007:mdna:285]
[same as prior period, unchanged from 0000858877-24-000030:mdna:234]

[0000858877-25-000007:mdna:286]
|  | January 25,2025 |  | July 27,2024 |  | Increase (Decrease) |
| Product | $ | 13,033 |  |  | $ | 13,219 |  |  | $ | (186) |  |
| Services | 14,762 |  |  | 15,256 |  |  | (494) |  |
| Total | $ | 27,795 |  |  | $ | 28,475 |  |  | $ | (680) |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 15,999 |  |  | $ | 16,249 |  |  | $ | (250) |  |
| Noncurrent | 11,796 |  |  | 12,226 |  |  | (430) |  |
| Total | $ | 27,795 |  |  | $ | 28,475 |  |  | $ | (680) |  |

[0000858877-25-000007:mdna:287]
Total deferred revenue decreased 2% compared to the end of fiscal 2024. The decrease in deferred product revenue of 1% was primarily due to lower business volume. The decrease in deferred services revenue of 3% was driven by lower business volume and ongoing amortization of deferred services revenue.

[0000858877-25-000007:mdna:288]
[same as prior period, unchanged from 0000858877-24-000030:mdna:237]

[0000858877-25-000007:mdna:289]
[same as prior period, unchanged from 0000858877-24-000030:mdna:238]

[0000858877-25-000007:mdna:290]
The income tax payable outstanding as of January 25, 2025 for the U.S. transition tax on accumulated earnings for foreign subsidiaries was $1.6 billion, which is payable in the second quarter of fiscal 2026.

[0000858877-25-000007:mdna:291]
[same as prior period, unchanged from 0000858877-24-000030:mdna:240]

[0000858877-25-000007:mdna:292]
CISCO SYSTEMS, INC.

[0000858877-25-000007:mdna:293]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-25-000007:mdna:294]
[same as prior period, unchanged from 0000858877-24-000030:mdna:243]

[0000858877-25-000007:mdna:295]
[same as prior period, unchanged from 0000858877-24-000030:mdna:244]

[0000858877-25-000007:mdna:296]
We also have certain funding commitments primarily related to our privately held investments. The funding commitments were $0.2 billion as of each of January 25, 2025 and July 27, 2024.

[0000858877-25-000007:mdna:297]
In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of January 25, 2025 there were no material unconsolidated variable interest entities.

[0000858877-25-000007:mdna:298]
[same as prior period, unchanged from 0000858877-24-000030:mdna:247]

[0000858877-25-000007:mdna:299]
[same as prior period, unchanged from 0000858877-24-000030:mdna:248]

[0000858877-25-000007:mdna:300]
[same as prior period, unchanged from 0000858877-24-000030:mdna:249]

[0000858877-25-000007:mdna:301]
[same as prior period, unchanged from 0000858877-24-000030:mdna:250]
