# CSCO note change history — 0000858877-24-000030 → 0000858877-25-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-02-18):
[0000858877-25-000007:note_history:1]
|  | January 25,2025 |  | July 27,2024 |
| Less than 1 year | $ | 5,054 |  |  | $ | 3,952 |  |
| 1 to 3 years | 681 |  |  | 1,085 |  |
| 3 to 5 years | 89 |  |  | 121 |  |
| Total | $ | 5,824 |  |  | $ | 5,158 |  |
  (was, 2024-11-19, similarity 0.9632):
[0000858877-24-000030:note_history:1]
|  | October 26,2024 |  | July 27,2024 |
| Less than 1 year | $ | 4,309 |  |  | $ | 3,952 |  |
| 1 to 3 years | 886 |  |  | 1,085 |  |
| 3 to 5 years | 126 |  |  | 121 |  |
| Total | $ | 5,321 |  |  | $ | 5,158 |  |

- changed (2025-02-18):
[0000858877-25-000007:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 25, 2025 and July 27, 2024, the liability for these purchase commitments was $383 million and $498 million, respectively, and was included in other current liabilities.
  (was, 2024-11-19, similarity 0.9576):
[0000858877-24-000030:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 26, 2024 and July 27, 2024, the liability for these purchase commitments was $439 million and $498 million, respectively, and was included in other current liabilities.

- changed (2025-02-18):
[0000858877-25-000007:note_history:3]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.2 billion as of each of January 25, 2025 and July 27, 2024.
  (was, 2024-11-19, similarity 0.8683):
[0000858877-24-000030:note_history:3]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.3 billion and $0.2 billion as of October 26, 2024 and July 27, 2024, respectively.

- changed (2025-02-18):
[0000858877-25-000007:note_history:4]
|  | Six Months Ended |
|  | January 25,2025 |  | January 27,2024 |
| Balance at beginning of period | $ | 362 |  |  | $ | 329 |  |
| Provisions for warranties issued | 198 |  |  | 198 |  |
| Adjustments for pre-existing warranties | 37 |  |  | 5 |  |
| Settlements | (203) |  |  | (205) |  |
| Balance at end of period | $ | 394 |  |  | $ | 327 |  |
  (was, 2024-11-19, similarity 0.9178):
[0000858877-24-000030:note_history:4]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |
| Balance at beginning of period | $ | 362 |  |  | $ | 329 |  |
| Provisions for warranties issued | 105 |  |  | 98 |  |
| Adjustments for pre-existing warranties | 1 |  |  | 3 |  |
| Settlements | (111) |  |  | (100) |  |
| Balance at end of period | $ | 357 |  |  | $ | 330 |  |

- changed (2025-02-18):
[0000858877-25-000007:note_history:5]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.2 billion and $6.6 billion for the second quarter of fiscal 2025 and 2024, respectively, and $12.2 billion and $14.8 billion for the first six months of fiscal 2025 and 2024, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.2 billion as of January 25, 2025 and July 27, 2024, respectively.
  (was, 2024-11-19, similarity 0.9193):
[0000858877-24-000030:note_history:5]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.0 billion and $8.2 billion for the first quarter of fiscal 2025 and 2024, respectively. The balance of the channel partner financing subject to guarantees was $1.1 billion and $1.2 billion as of October 26, 2024 and July 27, 2024, respectively.

- changed (2025-02-18):
[0000858877-25-000007:note_history:6]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at January 25, 2025 and July 27, 2024, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2024-11-19, similarity 0.9787):
[0000858877-24-000030:note_history:6]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at October 26, 2024 and July 27, 2024, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2025-02-18):
[0000858877-25-000007:note_history:7]
|  | January 25,2025 |  | July 27,2024 |
| Maximum potential future payments | $ | 125 |  |  | $ | 127 |  |
| Deferred revenue | (13) |  |  | (13) |  |
| Total | $ | 112 |  |  | $ | 114 |  |
  (was, 2024-11-19, similarity 0.9618):
[0000858877-24-000030:note_history:7]
|  | October 26,2024 |  | July 27,2024 |
| Maximum potential future payments | $ | 123 |  |  | $ | 127 |  |
| Deferred revenue | (12) |  |  | (13) |  |
| Total | $ | 111 |  |  | $ | 114 |  |

- changed (2025-02-18):
[0000858877-25-000007:note_history:8]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $137 million for the alleged evasion of import and other taxes, $768 million for interest, and $276 million for various penalties, all determined using an exchange rate as of January 25, 2025.
  (was, 2024-11-19, similarity 0.9941):
[0000858877-24-000030:note_history:8]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $142 million for the alleged evasion of import and other taxes, $839 million for interest, and $323 million for various penalties, all determined using an exchange rate as of October 26, 2024.

- changed (2025-02-18):
[0000858877-25-000007:note_history:9]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. After two bench trials and various administrative actions and appeals, we have been found either to not have infringed any of the patents or the patents have been invalidated. Centripetal appealed one of the invalidity decisions and we are awaiting the decision following the Federal Circuit hearing on that appeal on February 6, 2025. Centripetal’s appeal of the non-infringement judgment of the District Court is ongoing.
  (was, 2024-11-19, similarity 0.7834):
[0000858877-24-000030:note_history:9]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. After two bench trials and various administrative actions and appeals, we have been found either to not have infringed any of the patents or the patents have been invalidated. Centripetal has appealed one of the invalidity decisions and the non-infringement judgment of the District Court, and both of those proceedings are ongoing.

- added (2025-02-18):
[0000858877-25-000007:note_history:10]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringed three patents, one patent was invalidated, and the utility model was invalidated. The infringement action on the final patent is stayed due to an invalidity action heard on June 6, 2024 in the Federal Patent Court, in which all claims, aside from one auxiliary claim, were found invalid, and for which we are awaiting the entry of judgment from the Federal Patent Court. Centripetal’s appeals of two of the non-infringement findings remain pending and, on March 27, 2024, the Court of Appeals rejected Centripetal’s appeal of the third non-infringement finding.

- changed (2025-02-18):
[0000858877-25-000007:note_history:11]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement. We have filed our response and defenses to the complaint and the case briefing is ongoing. While the Court has not set a final hearing date, we anticipate that it will occur in the third calendar quarter of 2025.
  (was, 2024-11-19, similarity 0.7754):
[0000858877-24-000030:note_history:11]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement. We have filed our response and defenses to the complaint and we anticipate that on December 5, 2024, the Court will set a schedule for the remainder of the proceedings.

- removed (2025-02-18):
[0000858877-24-000030:note_history:12]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringed three patents, one patent was invalidated, the utility model was invalidated, and the infringement action on the final patent is stayed due to an invalidity action heard on June 6, 2024 in the Federal Patent Court, in which all claims, aside from one auxiliary claim, were found invalid, for which we are awaiting the entry of judgment from the Federal Patent Court. Centripetal’s appeals of two of the non-infringement findings remain pending and, on March 27, 2024, the Court of Appeals rejected Centripetal’s appeal of the third non-infringement finding.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-02-18):
[0000858877-25-000007:note_history:13]
We have prepared the accompanying financial data as of January 25, 2025 and for the second quarter and first six months of fiscal 2025 and 2024, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2024 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2024.
  (was, 2024-11-19, similarity 0.977):
[0000858877-24-000030:note_history:13]
We have prepared the accompanying financial data as of October 26, 2024 and for the first quarter of fiscal 2025 and 2024, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2024 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2024.

- added (2025-02-18):
[0000858877-25-000007:note_history:14]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of January 25, 2025, the results of operations, the statements of comprehensive income and the statements of equity for the second quarter and first six months of fiscal 2025 and 2024, and the statements of cash flows for the first six months of fiscal 2025 and 2024, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2025 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- added (2025-02-18):
[0000858877-25-000007:note_history:15]
We have evaluated subsequent events through the date that the financial statements were issued.

- removed (2025-02-18):
[0000858877-24-000030:note_history:16]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of October 26, 2024, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2025 and 2024, as applicable, have been made. The results of operations for the first quarter of fiscal 2025 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2025-02-18):
[0000858877-24-000030:note_history:17]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-18):
[0000858877-25-000007:note_history:18]
|  | January 25, 2025 |  | July 27, 2024 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 496 |  |  | 5.66 | % |  | $ | 488 |  |  | 6.66 | % |
| Commercial paper | 10,916 |  |  | 4.75 | % |  | 10,853 |  |  | 5.43 | % |
| Current portion of other debt | 1 |  |  | 1.13 | % |  | — |  |  | — |  |
| Total | $ | 11,413 |  |  |  |  | $ | 11,341 |  |  |  |
  (was, 2024-11-19, similarity 0.9789):
[0000858877-24-000030:note_history:18]
|  | October 26, 2024 |  | July 27, 2024 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 493 |  |  | 6.17 | % |  | $ | 488 |  |  | 6.66 | % |
| Commercial paper | 11,870 |  |  | 5.19 | % |  | 10,853 |  |  | 5.43 | % |
| Current portion of other debt | 1 |  |  | 1.13 | % |  | — |  |  | — |  |
| Total | $ | 12,364 |  |  |  |  | $ | 11,341 |  |  |  |

- changed (2025-02-18):
[0000858877-25-000007:note_history:19]
|  |  |  | January 25, 2025 |  | July 27, 2024 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | 5.66% |  | $ | 500 |  |  | 6.66% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 3 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 20,253 |  |  |  |  | 20,253 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (127) |  |  |  |  | (133) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (4) |  |  |  |  | (11) |  |  |  |
| Total |  |  | $ | 20,122 |  |  |  |  | $ | 20,109 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 497 |  |  |  |  | $ | 488 |  |  |  |
| Long-term debt |  |  | 19,625 |  |  |  |  | 19,621 |  |  |  |
| Total |  |  | $ | 20,122 |  |  |  |  | $ | 20,109 |  |  |  |
  (was, 2024-11-19, similarity 0.9945):
[0000858877-24-000030:note_history:19]
|  |  |  | October 26, 2024 |  | July 27, 2024 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | 6.17% |  | $ | 500 |  |  | 6.66% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 3 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 20,253 |  |  |  |  | 20,253 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (129) |  |  |  |  | (133) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (7) |  |  |  |  | (11) |  |  |  |
| Total |  |  | $ | 20,117 |  |  |  |  | $ | 20,109 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 494 |  |  |  |  | $ | 488 |  |  |  |
| Long-term debt |  |  | 19,623 |  |  |  |  | 19,621 |  |  |  |
| Total |  |  | $ | 20,117 |  |  |  |  | $ | 20,109 |  |  |  |

- changed (2025-02-18):
[0000858877-25-000007:note_history:20]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 25, 2025, we were in compliance with all debt covenants.
  (was, 2024-11-19, similarity 0.9836):
[0000858877-24-000030:note_history:20]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 26, 2024, we were in compliance with all debt covenants.

- changed (2025-02-18):
[0000858877-25-000007:note_history:21]
As of January 25, 2025, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2024-11-19, similarity 0.9556):
[0000858877-24-000030:note_history:21]
As of October 26, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2025-02-18):
[0000858877-25-000007:note_history:22]
| Fiscal Year | Amount |
| 2025 (remaining six months) | $ | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | — |  |
| 2029 | 2,500 |  |
| Thereafter | 12,000 |  |
| Total | $ | 20,253 |  |
  (was, 2024-11-19, similarity 0.9836):
[0000858877-24-000030:note_history:22]
| Fiscal Year | Amount |
| 2025 (remaining nine months) | $ | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | — |  |
| 2029 | 2,500 |  |
| Thereafter | 12,000 |  |
| Total | $ | 20,253 |  |

- changed (2025-02-18):
[0000858877-25-000007:note_history:23]
On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of January 25, 2025, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.
  (was, 2024-11-19, similarity 0.8475):
[0000858877-24-000030:note_history:23]
On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of October 26, 2024, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-18):
[0000858877-25-000007:note_history:24]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 25, 2025 and July 27, 2024 (in millions):
  (was, 2024-11-19, similarity 0.967):
[0000858877-24-000030:note_history:24]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 26, 2024 and July 27, 2024 (in millions):

- added (2025-02-18):
[0000858877-25-000007:note_history:25]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 25, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,431 |  |  | $ | (17) |  |  | $ | 387 |  |  | $ | (12) |  |  | $ | 1,818 |  |  | $ | (29) |  |
| U.S. government agency securities | 30 |  |  | — |  |  | 48 |  |  | (1) |  |  | 78 |  |  | (1) |  |
| Corporate debt securities | 281 |  |  | (2) |  |  | 2,193 |  |  | (63) |  |  | 2,474 |  |  | (65) |  |
| U.S. agency mortgage-backed securities | 8 |  |  | — |  |  | 728 |  |  | (111) |  |  | 736 |  |  | (111) |  |
| Total | $ | 1,750 |  |  | $ | (19) |  |  | $ | 3,356 |  |  | $ | (187) |  |  | $ | 5,106 |  |  | $ | (206) |  |

- removed (2025-02-18):
[0000858877-24-000030:note_history:26]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 26, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,134 |  |  | $ | (11) |  |  | $ | 634 |  |  | $ | (13) |  |  | $ | 1,768 |  |  | $ | (24) |  |
| U.S. government agency securities | 37 |  |  | — |  |  | 60 |  |  | (1) |  |  | 97 |  |  | (1) |  |
| Non-U.S. government and agency securities | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |
| Corporate debt securities | 221 |  |  | (1) |  |  | 2,402 |  |  | (76) |  |  | 2,623 |  |  | (77) |  |
| U.S. agency mortgage-backed securities | 7 |  |  | — |  |  | 896 |  |  | (133) |  |  | 903 |  |  | (133) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 1,435 |  |  | $ | (12) |  |  | $ | 3,992 |  |  | $ | (223) |  |  | $ | 5,427 |  |  | $ | (235) |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-18):
[0000858877-25-000007:note_history:27]
| January 25, 2025 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,177 |  |  | $ | — |  |  | $ | (29) |  |  | $ | 2,148 |  |
| U.S. government agency securities | 112 |  |  | — |  |  | (1) |  |  | 111 |  |
| Non-U.S. government and agency securities | 363 |  |  | 1 |  |  | — |  |  | 364 |  |
| Corporate debt securities | 3,292 |  |  | 6 |  |  | (94) |  |  | 3,204 |  |
| U.S. agency mortgage-backed securities | 847 |  |  | — |  |  | (111) |  |  | 736 |  |
| Commercial paper | 732 |  |  | — |  |  | — |  |  | 732 |  |
| Certificates of deposit | 663 |  |  | — |  |  | — |  |  | 663 |  |
| Total | $ | 8,186 |  |  | $ | 7 |  |  | $ | (235) |  |  | $ | 7,958 |  |
  (was, 2024-11-19, similarity 0.9874):
[0000858877-24-000030:note_history:27]
| October 26, 2024 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,390 |  |  | $ | 2 |  |  | $ | (24) |  |  | $ | 2,368 |  |
| U.S. government agency securities | 154 |  |  | — |  |  | (1) |  |  | 153 |  |
| Non-U.S. government and agency securities | 388 |  |  | 1 |  |  | — |  |  | 389 |  |
| Corporate debt securities | 3,610 |  |  | 9 |  |  | (107) |  |  | 3,512 |  |
| U.S. agency mortgage-backed securities | 1,038 |  |  | — |  |  | (133) |  |  | 905 |  |
| Commercial paper | 1,193 |  |  | — |  |  | — |  |  | 1,193 |  |
| Certificates of deposit | 674 |  |  | — |  |  | — |  |  | 674 |  |
| Total | $ | 9,447 |  |  | $ | 12 |  |  | $ | (265) |  |  | $ | 9,194 |  |

- changed (2025-02-18):
[0000858877-25-000007:note_history:28]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2025 |  | January 27, 2024 |  | January 25, 2025 |  | January 27, 2024 |
| Gross realized gains | $ | — |  |  | $ | 5 |  |  | $ | 8 |  |  | $ | 5 |  |
| Gross realized losses | (20) |  |  | (28) |  |  | (53) |  |  | $ | (48) |  |
| Total | $ | (20) |  |  | $ | (23) |  |  | $ | (45) |  |  | $ | (43) |  |
  (was, 2024-11-19, similarity 0.6894):
[0000858877-24-000030:note_history:28]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Gross realized gains | $ | 8 |  |  | $ | — |  |
| Gross realized losses | (33) |  |  | (20) |  |
| Total | $ | (25) |  |  | $ | (20) |  |

- changed (2025-02-18):
[0000858877-25-000007:note_history:29]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 25, 2025 and July 27, 2024 (in millions):
  (was, 2024-11-19, similarity 0.967):
[0000858877-24-000030:note_history:29]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 26, 2024 and July 27, 2024 (in millions):

- added (2025-02-18):
[0000858877-25-000007:note_history:30]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 25, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,431 |  |  | $ | (17) |  |  | $ | 387 |  |  | $ | (12) |  |  | $ | 1,818 |  |  | $ | (29) |  |
| U.S. government agency securities | 30 |  |  | — |  |  | 48 |  |  | (1) |  |  | 78 |  |  | (1) |  |
| Corporate debt securities | 281 |  |  | (2) |  |  | 2,193 |  |  | (63) |  |  | 2,474 |  |  | (65) |  |
| U.S. agency mortgage-backed securities | 8 |  |  | — |  |  | 728 |  |  | (111) |  |  | 736 |  |  | (111) |  |
| Total | $ | 1,750 |  |  | $ | (19) |  |  | $ | 3,356 |  |  | $ | (187) |  |  | $ | 5,106 |  |  | $ | (206) |  |

- changed (2025-02-18):
[0000858877-25-000007:note_history:31]
The following table summarizes the maturities of our available-for-sale debt investments as of January 25, 2025 (in millions):
  (was, 2024-11-19, similarity 0.9504):
[0000858877-24-000030:note_history:31]
The following table summarizes the maturities of our available-for-sale debt investments as of October 26, 2024 (in millions):

- added (2025-02-18):
[0000858877-25-000007:note_history:32]
We held marketable equity securities of $339 million and $481 million as of January 25, 2025 and July 27, 2024, respectively. We recognized a net unrealized gain of $16 million and $36 million during the second quarter and first six months of fiscal 2025, respectively, and a net unrealized gain of $55 million and $17 million during the corresponding periods of fiscal 2024, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $8 million and $16 million for the second quarter and first six months of fiscal 2025, respectively, and a net loss of $134 million for each of the corresponding periods of fiscal 2024. We held equity interests in certain private equity funds of $0.7 billion and $0.8 billion as of January 25, 2025 and July 27, 2024, respectively, which are accounted for under the NAV practical expedient.

- changed (2025-02-18):
[0000858877-25-000007:note_history:33]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 25, 2025, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2024-11-19, similarity 0.9878):
[0000858877-24-000030:note_history:33]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 26, 2024, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- added (2025-02-18):
[0000858877-25-000007:note_history:34]
The carrying value of our investments in privately held companies was $1.9 billion and $1.8 billion as of January 25, 2025 and July 27, 2024, respectively. Of the total carrying value of our investments in privately held companies as of January 25, 2025, $0.8 billion of such investments are considered to be in variable interest entities which are not required to be consolidated. As of January 25, 2025, we have total funding commitments of $0.2 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.

- removed (2025-02-18):
[0000858877-24-000030:note_history:35]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 26, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,134 |  |  | $ | (11) |  |  | $ | 634 |  |  | $ | (13) |  |  | $ | 1,768 |  |  | $ | (24) |  |
| U.S. government agency securities | 37 |  |  | — |  |  | 60 |  |  | (1) |  |  | 97 |  |  | (1) |  |
| Non-U.S. government and agency securities | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |
| Corporate debt securities | 221 |  |  | (1) |  |  | 2,402 |  |  | (76) |  |  | 2,623 |  |  | (77) |  |
| U.S. agency mortgage-backed securities | 7 |  |  | — |  |  | 896 |  |  | (133) |  |  | 903 |  |  | (133) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 1,435 |  |  | $ | (12) |  |  | $ | 3,992 |  |  | $ | (223) |  |  | $ | 5,427 |  |  | $ | (235) |  |

- removed (2025-02-18):
[0000858877-24-000030:note_history:36]
We held marketable equity securities of $412 million and $481 million as of October 26, 2024 and July 27, 2024, respectively. We recognized a net unrealized gain of $25 million and a net unrealized loss of $42 million during the first quarter of fiscal 2025 and 2024, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $8 million for the first quarter of fiscal 2025. These adjustments were not material for the first quarter of 2024. We held equity interests in certain private equity funds of $0.8 billion as of each of October 26, 2024 and July 27, 2024, which are accounted for under the NAV practical expedient.

- removed (2025-02-18):
[0000858877-24-000030:note_history:37]
The carrying value of our investments in privately held companies was $1.8 billion as of each of October 26, 2024 and July 27, 2024. Of the total carrying value of our investments in privately held companies as of October 26, 2024, $0.8 billion of such investments are considered to be in variable interest entities which are not required to be consolidated. As of October 26, 2024, we have total funding commitments of $0.3 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-18):
[0000858877-25-000007:note_history:38]
|  |  |  | January 25, 2025 |  | July 27, 2024 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | 5.66% |  | $ | 500 |  |  | 6.66% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 3 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 20,253 |  |  |  |  | 20,253 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (127) |  |  |  |  | (133) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (4) |  |  |  |  | (11) |  |  |  |
| Total |  |  | $ | 20,122 |  |  |  |  | $ | 20,109 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 497 |  |  |  |  | $ | 488 |  |  |  |
| Long-term debt |  |  | 19,625 |  |  |  |  | 19,621 |  |  |  |
| Total |  |  | $ | 20,122 |  |  |  |  | $ | 20,109 |  |  |  |
  (was, 2024-11-19, similarity 0.9945):
[0000858877-24-000030:note_history:38]
|  |  |  | October 26, 2024 |  | July 27, 2024 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | 6.17% |  | $ | 500 |  |  | 6.66% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 3 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 20,253 |  |  |  |  | 20,253 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (129) |  |  |  |  | (133) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (7) |  |  |  |  | (11) |  |  |  |
| Total |  |  | $ | 20,117 |  |  |  |  | $ | 20,109 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 494 |  |  |  |  | $ | 488 |  |  |  |
| Long-term debt |  |  | 19,623 |  |  |  |  | 19,621 |  |  |  |
| Total |  |  | $ | 20,117 |  |  |  |  | $ | 20,109 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-18):
[0000858877-25-000007:note_history:39]
As of January 25, 2025, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2024-11-19, similarity 0.9556):
[0000858877-24-000030:note_history:39]
As of October 26, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2025-02-18):
[0000858877-25-000007:note_history:40]
| Fiscal Year | Amount |
| 2025 (remaining six months) | $ | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | — |  |
| 2029 | 2,500 |  |
| Thereafter | 12,000 |  |
| Total | $ | 20,253 |  |
  (was, 2024-11-19, similarity 0.9836):
[0000858877-24-000030:note_history:40]
| Fiscal Year | Amount |
| 2025 (remaining nine months) | $ | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | — |  |
| 2029 | 2,500 |  |
| Thereafter | 12,000 |  |
| Total | $ | 20,253 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-18):
[0000858877-25-000007:note_history:41]
|  | January 25, 2025 |  | July 27, 2024 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 496 |  |  | 5.66 | % |  | $ | 488 |  |  | 6.66 | % |
| Commercial paper | 10,916 |  |  | 4.75 | % |  | 10,853 |  |  | 5.43 | % |
| Current portion of other debt | 1 |  |  | 1.13 | % |  | — |  |  | — |  |
| Total | $ | 11,413 |  |  |  |  | $ | 11,341 |  |  |  |
  (was, 2024-11-19, similarity 0.9789):
[0000858877-24-000030:note_history:41]
|  | October 26, 2024 |  | July 27, 2024 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 493 |  |  | 6.17 | % |  | $ | 488 |  |  | 6.66 | % |
| Commercial paper | 11,870 |  |  | 5.19 | % |  | 10,853 |  |  | 5.43 | % |
| Current portion of other debt | 1 |  |  | 1.13 | % |  | — |  |  | — |  |
| Total | $ | 12,364 |  |  |  |  | $ | 11,341 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-02-18):
[0000858877-25-000007:note_history:42]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25,2025 |  | January 27,2024 |  | January 25,2025 |  | January 27,2024 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 6,850 |  |  | $ | 7,081 |  |  | $ | 13,603 |  |  | $ | 15,904 |  |
| Security | 2,111 |  |  | 973 |  |  | 4,129 |  |  | 1,984 |  |
| Collaboration | 996 |  |  | 989 |  |  | 2,081 |  |  | 2,106 |  |
| Observability | 277 |  |  | 188 |  |  | 535 |  |  | 378 |  |
| Total Product | 10,234 |  |  | 9,232 |  |  | 20,348 |  |  | 20,371 |  |
| Services | 3,757 |  |  | 3,559 |  |  | 7,484 |  |  | 7,088 |  |
| Total | $ | 13,991 |  |  | $ | 12,791 |  |  | $ | 27,832 |  |  | $ | 27,459 |  |
  (was, 2024-11-19, similarity 0.6726):
[0000858877-24-000030:note_history:42]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |
| Product revenue: |  |  |  |
| Networking | $ | 6,753 |  |  | $ | 8,822 |  |
| Security | 2,017 |  |  | 1,010 |  |
| Collaboration | 1,085 |  |  | 1,117 |  |
| Observability | 258 |  |  | 190 |  |
| Total Product | 10,114 |  |  | 11,139 |  |
| Services | 3,727 |  |  | 3,529 |  |
| Total | $ | 13,841 |  |  | $ | 14,668 |  |

- changed (2025-02-18):
[0000858877-25-000007:note_history:43]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2025 |  | January 27, 2024 |  | January 25, 2025 |  | January 27, 2024 |
| Product | $ | 4,432 |  |  | $ | 3,110 |  |  | $ | 8,851 |  |  | $ | 6,317 |  |
| Services | 3,430 |  |  | 3,280 |  |  | 6,855 |  |  | 6,534 |  |
| Total | $ | 7,862 |  |  | $ | 6,390 |  |  | $ | 15,706 |  |  | $ | 12,851 |  |
  (was, 2024-11-19, similarity 0.6635):
[0000858877-24-000030:note_history:43]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Product | $ | 4,419 |  |  | $ | 3,207 |  |
| Services | 3,425 |  |  | 3,254 |  |
| Total | $ | 7,844 |  |  | $ | 6,461 |  |

- added (2025-02-18):
[0000858877-25-000007:note_history:44]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25,2025 |  | January 27,2024 |  | January 25,2025 |  | January 27,2024 |
| Revenue: |  |  |  |  |  |  |  |
| Networking | $ | 6,850 |  |  | $ | 7,081 |  |  | $ | 13,603 |  |  | $ | 15,904 |  |
| Security | 2,111 |  |  | 973 |  |  | 4,129 |  |  | 1,984 |  |
| Collaboration | 996 |  |  | 989 |  |  | 2,081 |  |  | 2,106 |  |
| Observability | 277 |  |  | 188 |  |  | 535 |  |  | 378 |  |
| Total Product | 10,234 |  |  | 9,232 |  |  | 20,348 |  |  | 20,371 |  |
| Services | 3,757 |  |  | 3,559 |  |  | 7,484 |  |  | 7,088 |  |
| Total | $ | 13,991 |  |  | $ | 12,791 |  |  | $ | 27,832 |  |  | $ | 27,459 |  |

- removed (2025-02-18):
[0000858877-24-000030:note_history:45]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |
| Revenue: |  |  |  |
| Networking | $ | 6,753 |  |  | $ | 8,822 |  |
| Security | 2,017 |  |  | 1,010 |  |
| Collaboration | 1,085 |  |  | 1,117 |  |
| Observability | 258 |  |  | 190 |  |
| Total Product | 10,114 |  |  | 11,139 |  |
| Services | 3,727 |  |  | 3,529 |  |
| Total | $ | 13,841 |  |  | $ | 14,668 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-02-18):
[0000858877-25-000007:note_history:46]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 25, 2025 and July 27, 2024 was $42 million and $37 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2024-11-19, similarity 0.9759):
[0000858877-24-000030:note_history:46]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 26, 2024 and July 27, 2024 was $42 million and $37 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2025-02-18):
[0000858877-25-000007:note_history:47]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and end customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.
  (was, 2024-11-19, similarity 0.9976):
[0000858877-24-000030:note_history:47]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-02-18):
[0000858877-25-000007:note_history:48]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 25, 2025 and July 27, 2024 was $42 million and $37 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2024-11-19, similarity 0.9759):
[0000858877-24-000030:note_history:48]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 26, 2024 and July 27, 2024 was $42 million and $37 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2025-02-18):
[0000858877-25-000007:note_history:49]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and end customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.
  (was, 2024-11-19, similarity 0.9976):
[0000858877-24-000030:note_history:49]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.

- changed (2025-02-18):
[0000858877-25-000007:note_history:50]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25,2025 |  | January 27,2024 |  | January 25,2025 |  | January 27,2024 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 6,850 |  |  | $ | 7,081 |  |  | $ | 13,603 |  |  | $ | 15,904 |  |
| Security | 2,111 |  |  | 973 |  |  | 4,129 |  |  | 1,984 |  |
| Collaboration | 996 |  |  | 989 |  |  | 2,081 |  |  | 2,106 |  |
| Observability | 277 |  |  | 188 |  |  | 535 |  |  | 378 |  |
| Total Product | 10,234 |  |  | 9,232 |  |  | 20,348 |  |  | 20,371 |  |
| Services | 3,757 |  |  | 3,559 |  |  | 7,484 |  |  | 7,088 |  |
| Total | $ | 13,991 |  |  | $ | 12,791 |  |  | $ | 27,832 |  |  | $ | 27,459 |  |
  (was, 2024-11-19, similarity 0.6726):
[0000858877-24-000030:note_history:50]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |
| Product revenue: |  |  |  |
| Networking | $ | 6,753 |  |  | $ | 8,822 |  |
| Security | 2,017 |  |  | 1,010 |  |
| Collaboration | 1,085 |  |  | 1,117 |  |
| Observability | 258 |  |  | 190 |  |
| Total Product | 10,114 |  |  | 11,139 |  |
| Services | 3,727 |  |  | 3,529 |  |
| Total | $ | 13,841 |  |  | $ | 14,668 |  |

- changed (2025-02-18):
[0000858877-25-000007:note_history:51]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2025 |  | January 27, 2024 |  | January 25, 2025 |  | January 27, 2024 |
| Product | $ | 4,432 |  |  | $ | 3,110 |  |  | $ | 8,851 |  |  | $ | 6,317 |  |
| Services | 3,430 |  |  | 3,280 |  |  | 6,855 |  |  | 6,534 |  |
| Total | $ | 7,862 |  |  | $ | 6,390 |  |  | $ | 15,706 |  |  | $ | 12,851 |  |
  (was, 2024-11-19, similarity 0.6635):
[0000858877-24-000030:note_history:51]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Product | $ | 4,419 |  |  | $ | 3,207 |  |
| Services | 3,425 |  |  | 3,254 |  |
| Total | $ | 7,844 |  |  | $ | 6,461 |  |

- changed (2025-02-18):
[0000858877-25-000007:note_history:52]
Accounts receivable, net was $5.7 billion as of January 25, 2025 compared to $6.7 billion as of July 27, 2024, as reported on the Consolidated Balance Sheets.
  (was, 2024-11-19, similarity 0.958):
[0000858877-24-000030:note_history:52]
Accounts receivable, net was $4.5 billion as of October 26, 2024 compared to $6.7 billion as of July 27, 2024, as reported on the Consolidated Balance Sheets.

- changed (2025-02-18):
[0000858877-25-000007:note_history:53]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2025 |  | January 27, 2024 |  | January 25, 2025 |  | January 27, 2024 |
| Allowance for credit loss at beginning of period | $ | 78 |  |  | $ | 82 |  |  | $ | 87 |  |  | $ | 85 |  |
| Provisions (benefits) | 12 |  |  | 9 |  |  | 12 |  |  | 11 |  |
| Recoveries (write-offs), net | (10) |  |  | (12) |  |  | (19) |  |  | (17) |  |
| Allowance for credit loss at end of period | $ | 80 |  |  | $ | 79 |  |  | $ | 80 |  |  | $ | 79 |  |
  (was, 2024-11-19, similarity 0.7386):
[0000858877-24-000030:note_history:53]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Allowance for credit loss at beginning of period | $ | 87 |  |  | $ | 85 |  |
| Provisions (benefits) | — |  |  | 2 |  |
| Recoveries (write-offs), net | (9) |  |  | (5) |  |
| Allowance for credit loss at end of period | $ | 78 |  |  | $ | 82 |  |

- changed (2025-02-18):
[0000858877-25-000007:note_history:54]
|  | January 25,2025 |  | July 27,2024 |
| 1 to 4 | $ | 1,223 |  |  | $ | 1,266 |  |
| 5 to 6 | 1,659 |  |  | 1,456 |  |
| 7 and Higher | 82 |  |  | 72 |  |
| Total | $ | 2,964 |  |  | $ | 2,794 |  |
  (was, 2024-11-19, similarity 0.9592):
[0000858877-24-000030:note_history:54]
|  | October 26,2024 |  | July 27,2024 |
| 1 to 4 | $ | 1,244 |  |  | $ | 1,266 |  |
| 5 to 6 | 1,599 |  |  | 1,456 |  |
| 7 and Higher | 71 |  |  | 72 |  |
| Total | $ | 2,914 |  |  | $ | 2,794 |  |

- changed (2025-02-18):
[0000858877-25-000007:note_history:55]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $2.9 billion as of January 25, 2025 and $2.7 billion as of July 27, 2024, and were included in other current assets and other assets.
  (was, 2024-11-19, similarity 0.9269):
[0000858877-24-000030:note_history:55]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $2.9 billion as of October 26, 2024 and $2.7 billion as of July 27, 2024, and were included in other current assets and other assets.

- changed (2025-02-18):
[0000858877-25-000007:note_history:56]
Contract liabilities consist of deferred revenue. Deferred revenue was $27.8 billion as of January 25, 2025 compared to $28.5 billion as of July 27, 2024. We recognized approximately $4.4 billion and $9.7 billion of revenue during the second quarter and first six months of fiscal 2025 that was included in the deferred revenue balance at July 27, 2024.
  (was, 2024-11-19, similarity 0.8013):
[0000858877-24-000030:note_history:56]
Contract liabilities consist of deferred revenue. Deferred revenue was $27.5 billion as of October 26, 2024 compared to $28.5 billion as of July 27, 2024. We recognized approximately $5.3 billion of revenue during the first quarter of fiscal 2025 that was included in the deferred revenue balance at July 27, 2024.

- changed (2025-02-18):
[0000858877-25-000007:note_history:57]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to 
the period of benefit. Capitalized contract acquisition costs were $1.5 billion and $1.3 billion as of January 25, 2025 and July 27, 2024, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $238 million and $446 million for the second quarter and first six months of fiscal 2025, respectively, and $166 million and $324 million for the corresponding periods of fiscal 2024, respectively, and was included in sales and marketing expenses.
  (was, 2024-11-19, similarity 0.8699):
[0000858877-24-000030:note_history:57]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to 
the period of benefit. Capitalized contract acquisition costs were $1.4 billion and $1.3 billion as of October 26, 2024 and July 27, 2024, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $208 million and $158 million for the first quarter of fiscal 2025 and fiscal 2024, respectively, and was included in sales and marketing expenses.
