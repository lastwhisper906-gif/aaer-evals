# CSCO MD&A — 0000858877-15-000051


## mdna

[0000858877-15-000051:mdna:1]
[same as prior period, unchanged from 0000858877-15-000013:mdna:1]

[0000858877-15-000051:mdna:2]
[same as prior period, unchanged from 0000858877-15-000013:mdna:2]

[0000858877-15-000051:mdna:3]
[same as prior period, unchanged from 0000858877-15-000013:mdna:3]

[0000858877-15-000051:mdna:4]
[same as prior period, unchanged from 0000858877-15-000013:mdna:4]

[0000858877-15-000051:mdna:5]
[same as prior period, unchanged from 0000858877-15-000013:mdna:5]

[0000858877-15-000051:mdna:6]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | April 25, 2015 |  | April 26, 2014 |  | Variance |  |  | April 25, 2015 |  | April 26, 2014 |  | Variance |  |
| Revenue | $ | 12,137 |  |  | $ | 11,545 |  |  | 5.1 | % |  |  | $ | 36,318 |  |  | $ | 34,785 |  |  | 4.4 | % |  |
| Gross margin percentage | 62.0 | % |  | 60.7 | % |  | 1.3 |  | pts |  | 60.4 | % |  | 58.5 | % |  | 1.9 |  | pts |
| Research and development | $ | 1,547 |  |  | $ | 1,565 |  |  | (1.2 | )% |  |  | $ | 4,659 |  |  | $ | 4,701 |  |  | (0.9 | )% |  |
| Sales and marketing | $ | 2,449 |  |  | $ | 2,342 |  |  | 4.6 | % |  |  | $ | 7,272 |  |  | $ | 7,030 |  |  | 3.4 | % |  |
| General and administrative | $ | 510 |  |  | $ | 460 |  |  | 10.9 | % |  |  | $ | 1,504 |  |  | $ | 1,426 |  |  | 5.5 | % |  |
| Total R&D, sales and marketing, general and administrative | $ | 4,506 |  |  | $ | 4,367 |  |  | 3.2 | % |  |  | $ | 13,435 |  |  | $ | 13,157 |  |  | 2.1 | % |  |
| Total as a percentage of revenue | 37.1 | % |  | 37.8 | % |  | (0.7 | ) | pts |  | 37.0 | % |  | 37.8 | % |  | (0.8 | ) | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 70 |  |  | $ | 71 |  |  | (1.4 | )% |  |  | $ | 213 |  |  | $ | 207 |  |  | 2.9 | % |  |
| Restructuring and other charges | $ | 24 |  |  | $ | 26 |  |  | (7.7 | )% |  |  | $ | 411 |  |  | $ | 336 |  |  | 22.3 | % |  |
| Operating income as a percentage of revenue | 24.1 | % |  | 22.0 | % |  | 2.1 |  | pts |  | 21.7 | % |  | 19.2 | % |  | 2.5 |  | pts |
| Income tax percentage | 19.7 | % |  | 17.4 | % |  | 2.3 |  | pts |  | 19.4 | % |  | 19.2 | % |  | 0.2 |  | pts |
| Net income | $ | 2,437 |  |  | $ | 2,181 |  |  | 11.7 | % |  |  | $ | 6,662 |  |  | $ | 5,606 |  |  | 18.8 | % |  |
| Net income as a percentage of revenue | 20.1 | % |  | 18.9 | % |  | 1.2 |  | pts |  | 18.3 | % |  | 16.1 | % |  | 2.2 |  | pts |
| Earnings per share—diluted | $ | 0.47 |  |  | $ | 0.42 |  |  | 11.9 | % |  |  | $ | 1.29 |  |  | $ | 1.06 |  |  | 21.7 | % |  |

[0000858877-15-000051:mdna:7]
[same as prior period, unchanged from 0000858877-15-000013:mdna:8]

[0000858877-15-000051:mdna:8]
[same as prior period, unchanged from 0000858877-15-000013:mdna:9]

[0000858877-15-000051:mdna:9]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:10]
In the third quarter of fiscal 2015, revenue increased by 5% as compared with the third quarter of fiscal 2014. Within the total revenue change, product revenue increased 6% while service revenue increased 3%. Total gross margin increased by 1.3 percentage points, as we experienced stable gross margins and a favorable impact from the supplier component remediation adjustment of $164 million, or 1.4 percentage points.  As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 0.7 percentage points. Operating income as a percentage of revenue increased by 2.1 percentage points. Diluted earnings per share increased by 12% from the prior year, driven by a 12% increase in net income.

[0000858877-15-000051:mdna:11]
In the third quarter of fiscal 2015, total revenue increased by $0.6 billion as compared with the third quarter of fiscal 2014. Revenue for the Americas increased by $0.6 billion, driven in large part by higher product revenue in the United States. EMEA revenue increased by $0.1 billion, led by higher product revenue in the United Kingdom. Revenue in our APJC segment decreased slightly, led by a product revenue decline in China. We experienced decreased product revenue in the emerging countries of China, Brazil and Russia and increased revenue in Mexico and India, as the “BRICM” countries experienced, in the aggregate, product revenue decline of 6%.  We believe that the product revenue declines we experienced in various emerging countries reflected the impact of economic and geopolitical challenges in these countries.

[0000858877-15-000051:mdna:12]
From a customer market standpoint, in the third quarter of fiscal 2015 we experienced solid product revenue growth in the commercial and enterprise markets, while the public sector and service provider markets were relatively flat.

[0000858877-15-000051:mdna:13]
From a product category perspective, the product revenue increase of 6% year-over-year was driven by product revenue growth in our core Switching and NGN Routing products which grew 6% and 4%, respectively. We also experienced 21% revenue growth from Data Center products due to continued strong customer demand. Our other major product categories experienced revenue changes ranging from a 14% increase in Security to a 5% decrease in Service Provider Video. Service revenue increased by 3% year over year.

[0000858877-15-000051:mdna:14]
In summary, during the third quarter of fiscal 2015, we achieved solid and profitable revenue growth despite encountering similar challenges that we have experienced in recent quarters in service provider and certain emerging countries. While we expect that these challenges may continue for a few more quarters, we believe we are well positioned for an upturn in these areas.

[0000858877-15-000051:mdna:15]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:16]
Diluted earnings per share increased by 22% from the prior year, a result of both a 19% increase in net income and a decrease in diluted share count by 157 million shares. Revenue increased 4%, with product revenue increasing 5% and service revenue increasing 4%. Total gross margin increased by 1.9 percentage points driven in part by the $655 million (or 1.9 percentage points)  supplier component remediation charge recorded in the second quarter of fiscal 2014. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively decreased by 0.8 percentage points, driven by higher compensation expense recorded in the first nine months of fiscal 2014 in connection with our acquisition of the remaining interest in Insieme. Operating income as a percentage of revenue increased by 2.5 percentage points.

[0000858877-15-000051:mdna:17]
[same as prior period, unchanged from 0000858877-15-000013:mdna:30]

[0000858877-15-000051:mdna:18]
[same as prior period, unchanged from 0000858877-15-000013:mdna:19]

[0000858877-15-000051:mdna:19]
[same as prior period, unchanged from 0000858877-15-000013:mdna:20]

[0000858877-15-000051:mdna:20]
[same as prior period, unchanged from 0000858877-15-000013:mdna:21]

[0000858877-15-000051:mdna:21]
[same as prior period, unchanged from 0000858877-15-000013:mdna:22]

[0000858877-15-000051:mdna:22]
[same as prior period, unchanged from 0000858877-15-000013:mdna:23]

[0000858877-15-000051:mdna:23]
[same as prior period, unchanged from 0000858877-15-000013:mdna:24]

[0000858877-15-000051:mdna:24]
[same as prior period, unchanged from 0000858877-15-000013:mdna:25]

[0000858877-15-000051:mdna:25]
[same as prior period, unchanged from 0000858877-15-000013:mdna:26]

[0000858877-15-000051:mdna:26]
The following is a summary of our other key financial measures for the third quarter and first nine months of fiscal 2015 (in millions, except days sales outstanding in accounts receivable (DSO) and annualized inventory turns):

[0000858877-15-000051:mdna:27]
|  |  | April 25, 2015 |  | July 26, 2014 |
| Cash and cash equivalents and investments |  | $ | 54,419 |  |  | $ | 52,074 |  |
| Deferred revenue |  | $ | 14,181 |  |  | $ | 14,142 |  |
| DSO |  | 37 days |  |  | 38 days |  |
| Inventories |  | $ | 1,760 |  |  | $ | 1,591 |  |
| Annualized inventory turns |  | 10.1 |  |  | 12.7 |  |

[0000858877-15-000051:mdna:28]
|  |  | Nine Months Ended |
|  |  | April 25, 2015 |  | April 26, 2014 |
| Cash provided by operating activities |  | $ | 8,414 |  |  | $ | 8,720 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 3,229 |  |  | $ | 8,025 |  |
| Dividends |  | $ | 3,017 |  |  | $ | 2,784 |  |

[0000858877-15-000051:mdna:29]
[same as prior period, unchanged from 0000858877-15-000013:mdna:31]

[0000858877-15-000051:mdna:30]
[same as prior period, unchanged from 0000858877-15-000013:mdna:32]

[0000858877-15-000051:mdna:31]
[same as prior period, unchanged from 0000858877-15-000013:mdna:33]

[0000858877-15-000051:mdna:32]
[same as prior period, unchanged from 0000858877-15-000013:mdna:34]

[0000858877-15-000051:mdna:33]
[same as prior period, unchanged from 0000858877-15-000013:mdna:35]

[0000858877-15-000051:mdna:34]
[same as prior period, unchanged from 0000858877-15-000013:mdna:36]

[0000858877-15-000051:mdna:35]
[same as prior period, unchanged from 0000858877-15-000013:mdna:37]

[0000858877-15-000051:mdna:36]
[same as prior period, unchanged from 0000858877-15-000013:mdna:38]

[0000858877-15-000051:mdna:37]
[same as prior period, unchanged from 0000858877-15-000013:mdna:39]

[0000858877-15-000051:mdna:38]
[same as prior period, unchanged from 0000858877-15-000013:mdna:40]

[0000858877-15-000051:mdna:39]
[same as prior period, unchanged from 0000858877-15-000013:mdna:41]

[0000858877-15-000051:mdna:40]
[same as prior period, unchanged from 0000858877-15-000013:mdna:42]

[0000858877-15-000051:mdna:41]
[same as prior period, unchanged from 0000858877-15-000013:mdna:43]

[0000858877-15-000051:mdna:42]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during the first nine months of fiscal 2015, nor do we currently expect a material impact in the next 12 months on our revenue recognition due to any changes in our VSOE, TPE, or ESP.

[0000858877-15-000051:mdna:43]
[same as prior period, unchanged from 0000858877-15-000013:mdna:46]

[0000858877-15-000051:mdna:44]
[same as prior period, unchanged from 0000858877-15-000013:mdna:47]

[0000858877-15-000051:mdna:45]
Revenue deferrals relate to the timing of revenue recognition for specific transactions based on financing arrangements, service, support, and other factors. Financing arrangements may include sales-type, direct-financing, and operating leases, loans, and guarantees of third-party financing. Our deferred revenue for products was $4.9 billion and $4.5 billion as of April 25, 2015 and July 26, 2014, respectively. Technical support services revenue is deferred and recognized ratably over the period during which the services are to be performed, which typically is from one to three years. Advanced services revenue is recognized upon delivery or completion of performance. Our deferred revenue for services was $9.2 billion and $9.6 billion as of April 25, 2015 and July 26, 2014, respectively.

[0000858877-15-000051:mdna:46]
[same as prior period, unchanged from 0000858877-15-000013:mdna:49]

[0000858877-15-000051:mdna:47]
[same as prior period, unchanged from 0000858877-15-000013:mdna:50]

[0000858877-15-000051:mdna:48]
[same as prior period, unchanged from 0000858877-15-000013:mdna:51]

[0000858877-15-000051:mdna:49]
|  |  | April 25, 2015 |  | July 26, 2014 |
| Allowance for doubtful accounts |  | $ | 290 |  |  | $ | 265 |  |
| Percentage of gross accounts receivable |  | 5.6 | % |  | 4.9 | % |
| Allowance for credit loss—lease receivables |  | $ | 242 |  |  | $ | 233 |  |
| Percentage of gross lease receivables(1) |  | 6.9 | % |  | 6.2 | % |
| Allowance for credit loss—loan receivables |  | $ | 80 |  |  | $ | 98 |  |
| Percentage of gross loan receivables |  | 4.7 | % |  | 5.8 | % |

[0000858877-15-000051:mdna:50]
[same as prior period, unchanged from 0000858877-15-000013:mdna:53]

[0000858877-15-000051:mdna:51]
[same as prior period, unchanged from 0000858877-15-000013:mdna:54]

[0000858877-15-000051:mdna:52]
[same as prior period, unchanged from 0000858877-15-000013:mdna:55]

[0000858877-15-000051:mdna:53]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of April 25, 2015 and July 26, 2014 was $130 million and $135 million, respectively, and was recorded as a reduction of our accounts receivable.  If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-15-000051:mdna:54]
[same as prior period, unchanged from 0000858877-15-000013:mdna:69]

[0000858877-15-000051:mdna:55]
[same as prior period, unchanged from 0000858877-15-000013:mdna:57]

[0000858877-15-000051:mdna:56]
[same as prior period, unchanged from 0000858877-15-000013:mdna:58]

[0000858877-15-000051:mdna:57]
[same as prior period, unchanged from 0000858877-15-000013:mdna:59]

[0000858877-15-000051:mdna:58]
Our inventory balance was $1.8 billion and $1.6 billion as of April 25, 2015 and July 26, 2014, respectively. Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and market, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-15-000051:mdna:59]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 25, 2015, the liability for these purchase commitments was $153 million, compared with $162 million as of July 26, 2014, and was included in other current liabilities.

[0000858877-15-000051:mdna:60]
Our provision for inventory was $42 million and $53 million for the first nine months of fiscal 2015 and 2014, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $79 million and $94 million for the first nine months of fiscal 2015 and 2014, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence, particularly in light of current macroeconomic uncertainties and conditions and the resulting potential for changes in future demand forecast.

[0000858877-15-000051:mdna:61]
Loss Contingencies and Product Warranties

[0000858877-15-000051:mdna:62]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-15-000051:mdna:63]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-15-000051:mdna:64]
We have recorded a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. In February 2014, on the basis of the growing number of failures as described in Note 12 (f) to the Consolidated Financial Statements, we decided to expand our approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  During the third quarter of fiscal 2015, we recorded an adjustment of $164 million, which was a reduction to the liability, to reflect net lower than estimated future costs to remediate the impacted customer products. Estimating this liability is complex and subjective, and if we experience changes in a number of underlying assumptions and estimates such as a change in claims compared with our expectations, or if the cost of servicing these claims is different than expected, our estimated liability may be impacted.

[0000858877-15-000051:mdna:65]
Our liability for product warranties, included in other current liabilities, was $451 million as of April 25, 2015, compared with $446 million as of July 26, 2014. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty. We accrue for warranty costs as part of our cost of sales based on associated material costs, technical support labor costs, and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends in the rate of customer cases and the cost to support the customer cases within the warranty period. Overhead cost is applied based on estimated time to support warranty activities.

[0000858877-15-000051:mdna:66]
The provision for product warranties during the first nine months of fiscal 2015 and 2014 was $517 million and $532 million, respectively. If we experience an increase in warranty claims compared with our historical experience, or if the cost of servicing warranty claims is greater than expected, our profitability could be adversely affected.

[0000858877-15-000051:mdna:67]
[same as prior period, unchanged from 0000858877-15-000013:mdna:70]

[0000858877-15-000051:mdna:68]
[same as prior period, unchanged from 0000858877-15-000013:mdna:71]

[0000858877-15-000051:mdna:69]
[same as prior period, unchanged from 0000858877-15-000013:mdna:72]

[0000858877-15-000051:mdna:70]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $50.5 billion as of April 25, 2015, compared with $45.3 billion as of July 26, 2014. Our fixed income investment portfolio as of April 25, 2015 consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-15-000051:mdna:71]
[same as prior period, unchanged from 0000858877-15-000013:mdna:74]

[0000858877-15-000051:mdna:72]
[same as prior period, unchanged from 0000858877-15-000013:mdna:75]

[0000858877-15-000051:mdna:73]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of April 25, 2015. Level 3 assets do not represent a significant portion of our total assets measured at fair value on a recurring basis as of April 25, 2015 and July 26, 2014.

[0000858877-15-000051:mdna:74]
[same as prior period, unchanged from 0000858877-15-000013:mdna:77]

[0000858877-15-000051:mdna:75]
[same as prior period, unchanged from 0000858877-15-000013:mdna:78]

[0000858877-15-000051:mdna:76]
[same as prior period, unchanged from 0000858877-15-000013:mdna:79]

[0000858877-15-000051:mdna:77]
[same as prior period, unchanged from 0000858877-15-000013:mdna:80]

[0000858877-15-000051:mdna:78]
There were no impairment charges on our investments in publicly traded equity securities in the first nine months of fiscal 2015, while $11 million of such impairment charges were recognized in earnings for the first nine months of fiscal 2014.  There were no impairment charges on our investments in fixed income securities in the first nine months of fiscal 2015 and 2014. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-15-000051:mdna:79]
[same as prior period, unchanged from 0000858877-15-000013:mdna:82]

[0000858877-15-000051:mdna:80]
[same as prior period, unchanged from 0000858877-15-000013:mdna:83]

[0000858877-15-000051:mdna:81]
We also have investments in privately held companies, some of which are in the startup or development stages. Our investments in privately held companies as of April 25, 2015 were $873 million, compared with $899 million as of July 26, 2014, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize. Our impairment charges on investments in privately held companies were $20 million and $10 million for the first nine months of fiscal 2015 and 2014, respectively.

[0000858877-15-000051:mdna:82]
[same as prior period, unchanged from 0000858877-15-000013:mdna:85]

[0000858877-15-000051:mdna:83]
[same as prior period, unchanged from 0000858877-15-000013:mdna:86]

[0000858877-15-000051:mdna:84]
The goodwill recorded in the Consolidated Balance Sheets as of April 25, 2015 and July 26, 2014 was $24.4 billion and $24.2 billion, respectively.  In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in the first nine months of fiscal 2015 and 2014.

[0000858877-15-000051:mdna:85]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. For the first nine months of fiscal 2015, impairment charges of $57 million on purchased intangible assets were recognized in earnings, while there were no such impairment charges in the first nine months of fiscal 2014. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-15-000051:mdna:86]
[same as prior period, unchanged from 0000858877-15-000013:mdna:89]

[0000858877-15-000051:mdna:87]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 19.7% and 17.4% in the third quarter of fiscal 2015 and 2014, respectively.  Our effective tax rate was 19.4% and 19.2% in the first nine months of fiscal 2015 and 2014, respectively.

[0000858877-15-000051:mdna:88]
[same as prior period, unchanged from 0000858877-15-000013:mdna:91]

[0000858877-15-000051:mdna:89]
[same as prior period, unchanged from 0000858877-15-000013:mdna:92]

[0000858877-15-000051:mdna:90]
[same as prior period, unchanged from 0000858877-15-000013:mdna:96]

[0000858877-15-000051:mdna:91]
[same as prior period, unchanged from 0000858877-15-000013:mdna:93]

[0000858877-15-000051:mdna:92]
[same as prior period, unchanged from 0000858877-15-000013:mdna:94]

[0000858877-15-000051:mdna:93]
[same as prior period, unchanged from 0000858877-15-000013:mdna:95]

[0000858877-15-000051:mdna:94]
51

[0000858877-15-000051:mdna:95]
[same as prior period, unchanged from 0000858877-15-000013:mdna:97]

[0000858877-15-000051:mdna:96]
[same as prior period, unchanged from 0000858877-15-000013:mdna:98]

[0000858877-15-000051:mdna:97]
[same as prior period, unchanged from 0000858877-15-000013:mdna:99]

[0000858877-15-000051:mdna:98]
[same as prior period, unchanged from 0000858877-15-000013:mdna:100]

[0000858877-15-000051:mdna:99]
[same as prior period, unchanged from 0000858877-15-000013:mdna:101]

[0000858877-15-000051:mdna:100]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |  | Variance in Percent |  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,326 |  |  | $ | 8,820 |  |  | $ | 506 |  |  | 5.7 | % |  | $ | 27,839 |  |  | $ | 26,640 |  |  | $ | 1,199 |  |  | 4.5 | % |
| Percentage of revenue |  | 76.8 | % |  | 76.4 | % |  |  |  |  |  |  |  | 76.7 | % |  | 76.6 | % |  |  |  |  |  |  |
| Service |  | 2,811 |  |  | 2,725 |  |  | 86 |  |  | 3.2 | % |  | 8,479 |  |  | 8,145 |  |  | 334 |  |  | 4.1 | % |
| Percentage of revenue |  | 23.2 | % |  | 23.6 | % |  |  |  |  |  |  |  | 23.3 | % |  | 23.4 | % |  |  |  |  |  |  |
| Total |  | $ | 12,137 |  |  | $ | 11,545 |  |  | $ | 592 |  |  | 5.1 | % |  | $ | 36,318 |  |  | $ | 34,785 |  |  | $ | 1,533 |  |  | 4.4 | % |

[0000858877-15-000051:mdna:101]
[same as prior period, unchanged from 0000858877-15-000013:mdna:103]

[0000858877-15-000051:mdna:102]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |  | Variance in Percent |  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,252 |  |  | $ | 6,689 |  |  | $ | 563 |  |  | 8.4 | % |  | $ | 21,854 |  |  | $ | 20,465 |  |  | $ | 1,389 |  |  | 6.8 | % |
| Percentage of revenue |  | 59.7 | % |  | 57.9 | % |  |  |  |  |  | 60.2 | % |  | 58.8 | % |  |  |  |  |
| EMEA |  | 3,119 |  |  | 3,068 |  |  | 51 |  |  | 1.7 | % |  | 9,212 |  |  | 8,897 |  |  | 315 |  |  | 3.5 | % |
| Percentage of revenue |  | 25.7 | % |  | 26.6 | % |  |  |  |  |  | 25.4 | % |  | 25.6 | % |  |  |  |  |
| APJC |  | 1,766 |  |  | 1,788 |  |  | (22 | ) |  | (1.2 | )% |  | 5,252 |  |  | 5,423 |  |  | (171 | ) |  | (3.2 | )% |
| Percentage of revenue |  | 14.6 | % |  | 15.5 | % |  |  |  |  |  | 14.4 | % |  | 15.6 | % |  |  |  |  |
| Total |  | $ | 12,137 |  |  | $ | 11,545 |  |  | $ | 592 |  |  | 5.1 | % |  | $ | 36,318 |  |  | $ | 34,785 |  |  | $ | 1,533 |  |  | 4.4 | % |

[0000858877-15-000051:mdna:103]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:104]
For the third quarter of fiscal 2015, as compared with the third quarter of fiscal 2014, total revenue increased by 5%.  Product revenue increased by 6%, while service revenue increased by 3%.  Our total revenue reflected growth in our Americas and EMEA geographic segments, while revenue declined in the APJC segment. The emerging countries of BRICM, in the aggregate, experienced a 6% product revenue decline, with declines in China, Russia and Brazil partially offset by increases in the other two BRICM countries.

[0000858877-15-000051:mdna:105]
We conduct business globally in numerous currencies. The direct effect of foreign currency fluctuations on revenue has not been material because our revenue is primarily denominated in U.S. dollars. However, if the U.S. dollar strengthens relative to other currencies, such strengthening could have an indirect effect on our revenue to the extent it raises the cost of our products to non-U.S. customers and thereby reduces demand. A weaker U.S. dollar could have the opposite effect. However, the precise indirect effect of currency fluctuations is difficult to measure or predict because our revenue is influenced by many factors in addition to the impact of such currency fluctuations. It is possible that our revenue in the third quarter of fiscal 2015 may have been adversely affected by the depreciation of the local currency relative to the U.S. dollar, although as noted above, such indirect effects are difficult to measure.

[0000858877-15-000051:mdna:106]
[same as prior period, unchanged from 0000858877-15-000013:mdna:108]

[0000858877-15-000051:mdna:107]
[same as prior period, unchanged from 0000858877-15-000013:mdna:126]

[0000858877-15-000051:mdna:108]
[same as prior period, unchanged from 0000858877-15-000013:mdna:109]

[0000858877-15-000051:mdna:109]
[same as prior period, unchanged from 0000858877-15-000013:mdna:110]

[0000858877-15-000051:mdna:110]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:111]
For the first nine months of fiscal 2015, as compared with the first nine months of fiscal 2014, total revenue increased by 4%.  Product revenue increased 5%, while service revenue increased by 4%.  Our total revenue increase reflected revenue growth in our Americas and EMEA geographic segments, while revenue declined in the APJC segment. The emerging countries of BRICM, in the aggregate, experienced a 4% product revenue decline, with declines in China and Russia partially offset by increases in the other three BRICM countries.

[0000858877-15-000051:mdna:112]
[same as prior period, unchanged from 0000858877-15-000013:mdna:113]

[0000858877-15-000051:mdna:113]
[same as prior period, unchanged from 0000858877-15-000013:mdna:114]

[0000858877-15-000051:mdna:114]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |  | Variance in Percent |  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,429 |  |  | $ | 4,925 |  |  | $ | 504 |  |  | 10.2 | % |  | $ | 16,356 |  |  | $ | 15,134 |  |  | $ | 1,222 |  |  | 8.1 | % |
| Percentage of product revenue |  | 58.2 | % |  | 55.9 | % |  |  |  |  |  | 58.8 | % |  | 56.8 | % |  |  |  |  |
| EMEA |  | 2,512 |  |  | 2,472 |  |  | 40 |  |  | 1.6 | % |  | 7,388 |  |  | 7,181 |  |  | 207 |  |  | 2.9 | % |
| Percentage of product revenue |  | 26.9 | % |  | 28.0 | % |  |  |  |  |  | 26.5 | % |  | 27.0 | % |  |  |  |  |
| APJC |  | 1,385 |  |  | 1,423 |  |  | (38 | ) |  | (2.7 | )% |  | 4,095 |  |  | 4,325 |  |  | (230 | ) |  | (5.3 | )% |
| Percentage of product revenue |  | 14.9 | % |  | 16.1 | % |  |  |  |  |  | 14.7 | % |  | 16.2 | % |  |  |  |  |
| Total |  | $ | 9,326 |  |  | $ | 8,820 |  |  | $ | 506 |  |  | 5.7 | % |  | $ | 27,839 |  |  | $ | 26,640 |  |  | $ | 1,199 |  |  | 4.5 | % |

[0000858877-15-000051:mdna:115]
[same as prior period, unchanged from 0000858877-15-000013:mdna:116]

[0000858877-15-000051:mdna:116]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:117]
Product revenue in the Americas segment increased by 10%, led by strong growth in the commercial and enterprise markets, and to a lesser extent, growth in the service provider and public sector markets. The product revenue increase in the enterprise market was driven by strength in the U.S. enterprise. Product revenue increased in the U.S. public sector market, led by higher sales to the U.S. federal government. From a country perspective, product revenue increases of 10% in the United States and 48% in Mexico were partially offset by product revenue declines of 14% in Brazil and 3% in Canada.

[0000858877-15-000051:mdna:118]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:119]
The increase in product revenue in the Americas segment of 8% was led by solid growth in the public sector, commercial and enterprise markets. The product revenue growth in the public sector market was due primarily to higher sales to the U.S. federal government and, to a lesser extent, higher sales to state and local governments. We experienced a product revenue decline in the service provider market. From a country perspective, product revenue increased by 8% in the United States, 28% in Mexico, and 10% in Brazil.

[0000858877-15-000051:mdna:120]
[same as prior period, unchanged from 0000858877-15-000013:mdna:121]

[0000858877-15-000051:mdna:121]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:122]
Product revenue in the EMEA segment increased by 2%, led by growth in the commercial and enterprise markets. We experienced product revenue declines in the service provider and public sector markets. Product revenue from emerging countries within EMEA increased by 9%, despite a product revenue decline of 14% in Russia, while product revenue for the remainder of EMEA, which primarily consists of countries in Western Europe, decreased slightly.

[0000858877-15-000051:mdna:123]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:124]
Product revenue in the EMEA segment increased by 3%, driven by growth in the commercial and enterprise markets and, to a lesser extent, in the service provider market. We experienced a slight product revenue decline in the public sector market. Product revenue from emerging countries within EMEA increased by 2% and product revenue for the remainder of EMEA grew by 3%.

[0000858877-15-000051:mdna:125]
53

[0000858877-15-000051:mdna:126]
[same as prior period, unchanged from 0000858877-15-000013:mdna:127]

[0000858877-15-000051:mdna:127]
[same as prior period, unchanged from 0000858877-15-000013:mdna:128]

[0000858877-15-000051:mdna:128]
[same as prior period, unchanged from 0000858877-15-000013:mdna:129]

[0000858877-15-000051:mdna:129]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:130]
The decrease in product revenue in the APJC segment of 3% was led by declines in the service provider and public sector markets and, to a lesser extent, in the enterprise market.  These decreases were partially offset by solid growth in the commercial market. From a country perspective, we experienced year-over-year product revenue declines of 30% in China and 2% in Japan. These decreases were partially offset by product revenue growth of 55% in Australia, with the growth attributable in large part to the timing of pricing changes, and 24% in India.

[0000858877-15-000051:mdna:131]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:132]
Product revenue in the APJC segment decreased by 5%.  The product revenue decline was led by a significant decline in the service provider market and, to a lesser degree, in the public sector market.  These decreases were partially offset by growth in the commercial and enterprise markets. From a country perspective, product revenue decreased by 25% in China and 6% in Japan. We experienced product revenue growth of 24% in India and 10% in Australia.

[0000858877-15-000051:mdna:133]
[same as prior period, unchanged from 0000858877-15-000013:mdna:134]

[0000858877-15-000051:mdna:134]
[same as prior period, unchanged from 0000858877-15-000013:mdna:135]

[0000858877-15-000051:mdna:135]
[same as prior period, unchanged from 0000858877-15-000013:mdna:136]

[0000858877-15-000051:mdna:136]
[same as prior period, unchanged from 0000858877-15-000013:mdna:137]

[0000858877-15-000051:mdna:137]
[same as prior period, unchanged from 0000858877-15-000013:mdna:138]

[0000858877-15-000051:mdna:138]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |  | Variance in Percent |  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,560 |  |  | $ | 3,368 |  |  | $ | 192 |  |  | 5.7 | % |  | $ | 11,022 |  |  | $ | 10,366 |  |  | $ | 656 |  |  | 6.3 | % |
| Percentage of product revenue |  | 38.2 | % |  | 38.2 | % |  |  |  |  |  |  |  | 39.6 | % |  | 38.9 | % |  |  |  |  |  |  |
| NGN Routing |  | 1,999 |  |  | 1,925 |  |  | 74 |  |  | 3.8 | % |  | 5,712 |  |  | 5,681 |  |  | 31 |  |  | 0.5 | % |
| Percentage of product revenue |  | 21.4 | % |  | 21.8 | % |  |  |  |  |  |  |  | 20.5 | % |  | 21.3 | % |  |  |  |  |  |  |
| Collaboration |  | 973 |  |  | 909 |  |  | 64 |  |  | 7.0 | % |  | 2,912 |  |  | 2,859 |  |  | 53 |  |  | 1.9 | % |
| Percentage of product revenue |  | 10.4 | % |  | 10.3 | % |  |  |  |  |  |  |  | 10.5 | % |  | 10.7 | % |  |  |  |  |  |  |
| Service Provider Video |  | 914 |  |  | 961 |  |  | (47 | ) |  | (4.9 | )% |  | 2,561 |  |  | 2,905 |  |  | (344 | ) |  | (11.8 | )% |
| Percentage of product revenue |  | 9.8 | % |  | 10.9 | % |  |  |  |  |  |  |  | 9.2 | % |  | 10.9 | % |  |  |  |  |  |  |
| Data Center |  | 801 |  |  | 662 |  |  | 139 |  |  | 21.0 | % |  | 2,340 |  |  | 1,868 |  |  | 472 |  |  | 25.3 | % |
| Percentage of product revenue |  | 8.6 | % |  | 7.5 | % |  |  |  |  |  | 8.4 | % |  | 7.0 | % |  |  |  |  |
| Wireless |  | 611 |  |  | 560 |  |  | 51 |  |  | 9.1 | % |  | 1,827 |  |  | 1,624 |  |  | 203 |  |  | 12.5 | % |
| Percentage of product revenue |  | 6.6 | % |  | 6.3 | % |  |  |  |  |  |  |  | 6.6 | % |  | 6.1 | % |  |  |  |  |  |  |
| Security |  | 412 |  |  | 361 |  |  | 51 |  |  | 14.1 | % |  | 1,283 |  |  | 1,119 |  |  | 164 |  |  | 14.7 | % |
| Percentage of product revenue |  | 4.4 | % |  | 4.1 | % |  |  |  |  |  |  |  | 4.6 | % |  | 4.2 | % |  |  |  |  |  |  |
| Other |  | 56 |  |  | 74 |  |  | (18 | ) |  | (24.3 | )% |  | 182 |  |  | 218 |  |  | (36 | ) |  | (16.5 | )% |
| Percentage of product revenue |  | 0.6 | % |  | 0.9 | % |  |  |  |  |  |  |  | 0.6 | % |  | 0.9 | % |  |  |  |  |  |  |
| Total |  | $ | 9,326 |  |  | $ | 8,820 |  |  | $ | 506 |  |  | 5.7 | % |  | $ | 27,839 |  |  | $ | 26,640 |  |  | $ | 1,199 |  |  | 4.5 | % |

[0000858877-15-000051:mdna:139]
[same as prior period, unchanged from 0000858877-15-000013:mdna:140]

[0000858877-15-000051:mdna:140]
[same as prior period, unchanged from 0000858877-15-000013:mdna:141]

[0000858877-15-000051:mdna:141]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:142]
Revenue in our Switching product category increased by 6%, or $192 million, driven by a 10%, or $211 million, increase in revenue from our LAN fixed-configuration switches. Revenue from our LAN fixed-configuration switches increased due to the continued adoption of Cisco Catalyst 3850 Series Switches and Cisco Catalyst 3650 Series Switches.  Higher revenue from fixed-configuration Cisco Nexus Series Switches also contributed to the increase. Partially offsetting these increase was a decrease in revenue from our modular switches of 2%, or $18 million, driven by lower sales of Cisco Nexus 7000 Series Switches and Cisco Catalyst 6500-E Series Switches.  We also experienced a slight decrease in sales of storage products within this category.

[0000858877-15-000051:mdna:143]
[same as prior period, unchanged from 0000858877-15-000013:mdna:163]

[0000858877-15-000051:mdna:144]
[same as prior period, unchanged from 0000858877-15-000013:mdna:144]

[0000858877-15-000051:mdna:145]
[same as prior period, unchanged from 0000858877-15-000013:mdna:145]

[0000858877-15-000051:mdna:146]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:147]
The increase in revenue in our Switching product category of 6%, or $656 million, was driven by an 11%, or $718 million, increase in revenue from our LAN fixed-configuration switches and, to a lesser extent, a 31%, or $95 million, increase in sales of storage products. Revenue from LAN fixed-configuration switches increased due to higher sales of most of our Cisco Nexus Series Switches and Cisco Catalyst Series Switches within this category. We experienced a decrease in revenue from our modular switches of 4%, or $157 million, driven by lower sales of Cisco Catalyst 6500-E Series Switches and Cisco Nexus 7000 Series Switches.

[0000858877-15-000051:mdna:148]
[same as prior period, unchanged from 0000858877-15-000013:mdna:148]

[0000858877-15-000051:mdna:149]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:150]
The increase in revenue in our NGN Routing product category of 4%, or $74 million, was driven by a 5%, or $62 million, increase in revenue from our high-end router products and a 4%, or $26 million, increase in revenue from our midrange and low-end router products. These increases were partially offset by a 9%, or $14 million, decrease in revenue from what we categorize as other NGN Routing products. Within the high-end router product category, we experienced increased sales of most of our products within our Cisco Aggregation Services Routers category and the adoption of our Cisco Network Convergence System platform and CRS-X, partially offset by lower sales of our legacy high-end router products. The increase in revenue from our midrange and low-end router products was due to higher sales of our Cisco Integrated Services Routers products. Revenue from other NGN Routing products decreased due to lower sales of certain optical networking products.

[0000858877-15-000051:mdna:151]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:152]
Revenue in our NGN Routing product category increased by 1%, or $31 million, driven by a 5%, or $158 million, increase in revenue from our high-end router products, partially offset by 27%, or $122 million, decrease in revenue from other NGN Routing products and a slight decrease in revenue from our midrange and low-end router products.  Revenue from high-end router product increased due to an increase in revenue from most products within our Cisco Aggregation Services Routers category and the adoption of our Cisco Network Convergence System platform, partially offset by lower sales of Cisco Carrier Routing System products and our legacy high-end router products. Revenue from other NGN Routing products decreased due to lower sales of certain optical networking products. The slight decrease in revenue from our midrange and low-end router products was due to lower sales of certain of our access products, partially offset by higher sales of our Cisco Integrated Services Routers products.

[0000858877-15-000051:mdna:153]
[same as prior period, unchanged from 0000858877-15-000013:mdna:153]

[0000858877-15-000051:mdna:154]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:155]
Overall, revenue in our Collaboration product category increased by 7%, or $64 million, due to increased revenue from our Conferencing, Cisco TelePresence and Unified Communications products. Revenue from Cisco TelePresence products increased due to higher revenue in endpoint products as a result of new product introductions. The increase in Conferencing revenue was a result of higher recurring revenue and one-time usage fees. The increase in Unified Communications revenue was a result of higher software revenue partially offset by a decrease in revenue from phones. We continue to increase the amount of deferred revenue related to our Collaboration product category.

[0000858877-15-000051:mdna:156]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:157]
Revenue in our Collaboration product category increased by 2%, or $53 million, primarily due to increased revenue from our Unified Communications and conferencing products, partially offset by a slight decrease in revenue from our Cisco TelePresence products. Revenue from Unified Communication products increased as a result of higher software revenue partially offset by slightly lower revenue from phones. The increase in Conferencing revenue was a result of higher recurring revenue. Cisco TelePresence revenue was slightly lower due to lower software revenue partially offset by higher revenue from endpoints.

[0000858877-15-000051:mdna:158]
[same as prior period, unchanged from 0000858877-15-000013:mdna:158]

[0000858877-15-000051:mdna:159]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:160]
Revenue in our Service Provider Video product category decreased by 5%, or $47 million, due to decreased revenue from Service Provider Video software and solutions, cable access products and Service Provider Video infrastructure products, the latter due primarily to lower sales of set-top boxes.

[0000858877-15-000051:mdna:161]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:162]
The decrease in revenue from our Service Provider Video product category of 12%, or $344 million, was driven by a 17%, or $271 million, decrease in sales of our Service Provider Video infrastructure products, due primarily to lower sales of set-top boxes. We also experienced a decrease in revenue from cable access products within this product category.

[0000858877-15-000051:mdna:163]
[same as prior period, unchanged from 0000858877-15-000013:mdna:183]

[0000858877-15-000051:mdna:164]
[same as prior period, unchanged from 0000858877-15-000013:mdna:164]

[0000858877-15-000051:mdna:165]
[same as prior period, unchanged from 0000858877-15-000013:mdna:165]

[0000858877-15-000051:mdna:166]
[same as prior period, unchanged from 0000858877-15-000013:mdna:166]

[0000858877-15-000051:mdna:167]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:168]
We continued to experience solid growth in our Data Center product category, which grew by 21%, or $139 million, with sales growth of our Cisco Unified Computing System products occurring across all geographic segments and within most of our customer markets. The increase was due in large part to the continued momentum we are experiencing in both data center and cloud environments, as current customers increase their data center build-outs and as new customers deploy these offerings.

[0000858877-15-000051:mdna:169]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:170]
We experienced solid growth in our Data Center product category, which grew by 25%, or $472 million, with sales growth of our Cisco Unified Computing System products occurring across all geographic segments and customer markets. The increase in this product category was driven by similar factors as discussed in the three month period immediately above.

[0000858877-15-000051:mdna:171]
[same as prior period, unchanged from 0000858877-15-000013:mdna:171]

[0000858877-15-000051:mdna:172]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:173]
Revenue in our Wireless product category increased by 9%, or $51 million, driven by continued growth in Meraki combined with continued strength in our 802.11ac portfolio. We continue to increase the proportion of recurring revenue in our Wireless product category.

[0000858877-15-000051:mdna:174]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:175]
Revenue in our Wireless product category increased by 13%, or $203 million, due primarily to higher sales of Meraki products and 802.11ac products.

[0000858877-15-000051:mdna:176]
[same as prior period, unchanged from 0000858877-15-000013:mdna:176]

[0000858877-15-000051:mdna:177]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:178]
Revenue in our Security product category experienced growth of 14%, or $51 million, driven by higher Network Security sales as a result of product integration with Sourcefire, which we acquired in the first quarter of fiscal 2014.  This increase was partially offset by a slight decrease in revenue from our Content Security products due to lower sales of Web and E-mail security products. Our software and subscription sales continue to drive an increase in the proportion of recurring revenue in our Security product category.

[0000858877-15-000051:mdna:179]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:180]
Revenue in our Security product category was up 15%, or $164 million, driven primarily by sales of Sourcefire products and, to a lesser extent, by higher sales of our high-end Firewall products within our Network Security product portfolio. This increase was partially offset by slight decrease in revenue from our Content Security products due to lower sales of Web and E-mail security products.

[0000858877-15-000051:mdna:181]
[same as prior period, unchanged from 0000858877-15-000013:mdna:181]

[0000858877-15-000051:mdna:182]
We experienced a year-over-year decrease in revenue in our Other Products category for the third quarter and first nine months of fiscal 2015 due in large part to the decrease in sales of our other networking products.

[0000858877-15-000051:mdna:183]
[same as prior period, unchanged from 0000858877-15-000013:mdna:184]

[0000858877-15-000051:mdna:184]
[same as prior period, unchanged from 0000858877-15-000013:mdna:185]

[0000858877-15-000051:mdna:185]
[same as prior period, unchanged from 0000858877-15-000013:mdna:186]

[0000858877-15-000051:mdna:186]
[same as prior period, unchanged from 0000858877-15-000013:mdna:187]

[0000858877-15-000051:mdna:187]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |  | Variance in Percent |  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,823 |  |  | $ | 1,764 |  |  | $ | 59 |  |  | 3.3 | % |  | $ | 5,498 |  |  | $ | 5,331 |  |  | $ | 167 |  |  | 3.1 | % |
| Percentage of service revenue | 64.8 | % |  | 64.7 | % |  |  |  |  |  | 64.9 | % |  | 65.4 | % |  |  |  |  |
| EMEA | 607 |  |  | 596 |  |  | 11 |  |  | 1.8 | % |  | 1,824 |  |  | 1,716 |  |  | 108 |  |  | 6.3 | % |
| Percentage of service revenue | 21.6 | % |  | 21.9 | % |  |  |  |  |  | 21.5 | % |  | 21.1 | % |  |  |  |  |
| APJC | 381 |  |  | 365 |  |  | 16 |  |  | 4.4 | % |  | 1,157 |  |  | 1,098 |  |  | 59 |  |  | 5.4 | % |
| Percentage of service revenue | 13.6 | % |  | 13.4 | % |  |  |  |  |  | 13.6 | % |  | 13.5 | % |  |  |  |  |
| Total | $ | 2,811 |  |  | $ | 2,725 |  |  | $ | 86 |  |  | 3.2 | % |  | $ | 8,479 |  |  | $ | 8,145 |  |  | $ | 334 |  |  | 4.1 | % |

[0000858877-15-000051:mdna:188]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:189]
Service revenue increased across all of our geographic segments. Worldwide technical support services revenue increased by 3% and worldwide advanced services revenue increased by 5%, driven by growth in subscription revenues. Technical support service revenue experienced growth across all geographic segments, led by growth in our Americas and APJC segments. Renewals and technical support service contract initiations associated with product sales provided an installed base of equipment being serviced which, in concert with new service offerings, were the primary factors driving the revenue increases. Advanced services revenue, which relates to consulting support services for specific customer network needs, grew across all geographic segments, led by solid growth in our APJC segment.

[0000858877-15-000051:mdna:190]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:191]
Service revenue grew by 4%, with growth across all of our geographic segments. Worldwide technical support services revenue and worldwide advanced services each experienced 4% revenue growth. Technical support services revenue grew across all geographic segments, led by growth in our APJC and EMEA segments. Advanced services revenue also grew across all geographic segments, led by solid growth in our EMEA segment.

[0000858877-15-000051:mdna:192]
[same as prior period, unchanged from 0000858877-15-000013:mdna:193]

[0000858877-15-000051:mdna:193]
[same as prior period, unchanged from 0000858877-15-000013:mdna:194]

[0000858877-15-000051:mdna:194]
[same as prior period, unchanged from 0000858877-15-000013:mdna:195]

[0000858877-15-000051:mdna:195]
[same as prior period, unchanged from 0000858877-15-000013:mdna:196]

[0000858877-15-000051:mdna:196]
|  | Three Months Ended |  | Nine Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 5,742 |  |  | $ | 5,225 |  |  | 61.6 | % |  | 59.2 | % |  | $ | 16,530 |  |  | $ | 14,975 |  |  | 59.4 | % |  | 56.2 | % |
| Service | 1,783 |  |  | 1,781 |  |  | 63.4 | % |  | 65.4 | % |  | 5,418 |  |  | 5,389 |  |  | 63.9 | % |  | 66.2 | % |
| Total | $ | 7,525 |  |  | $ | 7,006 |  |  | 62.0 | % |  | 60.7 | % |  | $ | 21,948 |  |  | $ | 20,364 |  |  | 60.4 | % |  | 58.5 | % |

[0000858877-15-000051:mdna:197]
[same as prior period, unchanged from 0000858877-15-000013:mdna:198]

[0000858877-15-000051:mdna:198]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the third quarter and first nine months of fiscal 2015 as compared with the corresponding prior year periods:

[0000858877-15-000051:mdna:199]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Nine Months Ended |
| Fiscal 2014 |  | 59.2 | % |  | 56.2 | % |
| Productivity (1) |  | 2.8 | % |  | 2.8 | % |
| Supplier component remediation charge/adjustment |  | 1.8 | % |  | 3.1 | % |
| Amortization of purchased intangible assets |  | 0.3 | % |  | (0.1 | )% |
| Product pricing |  | (1.9 | )% |  | (2.4 | )% |
| Mix of products sold |  | (0.6 | )% |  | 0.5 | % |
| Rockstar patent portfolio charge |  | — | % |  | (0.7 | )% |
| Fiscal 2015 |  | 61.6 | % |  | 59.4 | % |

[0000858877-15-000051:mdna:200]
[same as prior period, unchanged from 0000858877-15-000013:mdna:201]

[0000858877-15-000051:mdna:201]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:202]
Product gross margin increased by 2.4 percentage points as compared with the third quarter of fiscal 2014.

[0000858877-15-000051:mdna:203]
The increase in product gross margin was due to productivity improvements, which were driven by value engineering efforts; favorable component pricing; continued operational efficiency in manufacturing operations and lower warranty expense. Value engineering is the process by which production costs are reduced through component redesign, board configuration, test processes, and transformation processes. The increase was also due to the supplier component remediation adjustment.  See Note 12 (f) to the Consolidated Financial Statements. Our product gross margin for the third quarter of fiscal 2015 also benefited from lower amortization expense of purchased intangible assets.

[0000858877-15-000051:mdna:204]
The various factors contributing to the product gross margin increase were partially offset by unfavorable impacts from product pricing, which were driven by typical market factors and impacted each of our geographic segments and customer markets, as well as the unfavorable impact of product mix. The mix of products sold was unfavorable primarily as a result of a revenue increase from our relatively lower margin Cisco Unified Computing System products and the mix impact within our core products, partially offset by a revenue decrease from our relatively lower margin Service Provider Video products.

[0000858877-15-000051:mdna:205]
[same as prior period, unchanged from 0000858877-15-000013:mdna:206]

[0000858877-15-000051:mdna:206]
[same as prior period, unchanged from 0000858877-15-000013:mdna:217]

[0000858877-15-000051:mdna:207]
[same as prior period, unchanged from 0000858877-15-000013:mdna:207]

[0000858877-15-000051:mdna:208]
[same as prior period, unchanged from 0000858877-15-000013:mdna:208]

[0000858877-15-000051:mdna:209]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:210]
Product gross margin increased by 3.2 percentage points as compared with the first nine months of fiscal 2014. The increase was driven by the $655 million charge to product cost of sales for the second quarter of fiscal 2014 related to the expected cost to remediate issues with a supplier component in certain products sold in prior fiscal years. As discussed in the three-month period immediately above, the $164 million adjustment recorded in the third quarter of fiscal 2015 also contributed to the increase in product gross margin.

[0000858877-15-000051:mdna:211]
Additionally, gross margin increased due to benefits from productivity improvements driven by similar factors as discussed in the three-month period immediately above, and also due to the mix of products sold. The favorable product mix impact was due to revenue decreases from our relatively lower margin Service Provider Video products and a revenue increase from certain of our higher margin core products, partially offset by increased  revenue from our relatively lower margin Cisco Unified Computing System products.  These factors were partially offset by unfavorable impacts from product pricing, the unfavorable impact of the $188 million charge to product cost of sales recorded in the first quarter fiscal 2015 related to the Rockstar patent portfolio, and impairment charges related to acquisition-related intangible assets.

[0000858877-15-000051:mdna:212]
[same as prior period, unchanged from 0000858877-15-000013:mdna:211]

[0000858877-15-000051:mdna:213]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:214]
Our service gross margin percentage decreased by 2.0 percentage points compared with the third quarter of fiscal 2014 due to increased costs such as  partner delivery cost, outside services and continued investments in security and cloud managed services. These cost impacts were partially offset by the resulting benefit to gross margin of higher sales volume in both advanced services and technical support services and, to a lesser extent efficiencies related to our restructuring actions.

[0000858877-15-000051:mdna:215]
[same as prior period, unchanged from 0000858877-15-000013:mdna:214]

[0000858877-15-000051:mdna:216]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:217]
Service gross margin percentage decreased by 2.3 percentage points as compared with the first nine months of fiscal 2014, driven by increased cost impacts such as partner delivery costs, headcount-related costs and outside services. Headcount-related costs increased due to continued investments in security and cloud managed services and higher variable compensation expense. These cost impacts were partially offset by the resulting benefit to gross margin of higher sales volume in both advanced services and technical support services.

[0000858877-15-000051:mdna:218]
[same as prior period, unchanged from 0000858877-15-000013:mdna:218]

[0000858877-15-000051:mdna:219]
[same as prior period, unchanged from 0000858877-15-000013:mdna:219]

[0000858877-15-000051:mdna:220]
[same as prior period, unchanged from 0000858877-15-000013:mdna:220]

[0000858877-15-000051:mdna:221]
[same as prior period, unchanged from 0000858877-15-000013:mdna:221]

[0000858877-15-000051:mdna:222]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 4,560 |  |  | $ | 4,196 |  |  | 62.9 | % |  | 62.7 | % |  | $ | 13,776 |  |  | $ | 12,823 |  |  | 63.0 | % |  | 62.7 | % |
| EMEA |  | 1,949 |  |  | 1,967 |  |  | 62.5 | % |  | 64.1 | % |  | 5,774 |  |  | 5,725 |  |  | 62.7 | % |  | 64.3 | % |
| APJC |  | 1,080 |  |  | 1,076 |  |  | 61.2 | % |  | 60.2 | % |  | 3,157 |  |  | 3,148 |  |  | 60.1 | % |  | 58.0 | % |
| Segment total |  | 7,589 |  |  | 7,239 |  |  | 62.5 | % |  | 62.7 | % |  | 22,707 |  |  | 21,696 |  |  | 62.5 | % |  | 62.4 | % |
| Unallocated corporate items (1) |  | (64 | ) |  | (233 | ) |  |  |  |  |  | (759 | ) |  | (1,332 | ) |  |  |  |  |
| Total |  | $ | 7,525 |  |  | $ | 7,006 |  |  | 62.0 | % |  | 60.7 | % |  | $ | 21,948 |  |  | $ | 20,364 |  |  | 60.4 | % |  | 58.5 | % |

[0000858877-15-000051:mdna:223]
(1) The unallocated corporate items for the periods presented include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-15-000051:mdna:224]
Three Months Ended April 25, 2015 Compared with Three Months Ended April 26, 2014

[0000858877-15-000051:mdna:225]
The Americas segment experienced a gross margin percentage increase due to productivity improvements from lower overall manufacturing costs, partially offset by unfavorable impacts from pricing and mix. The unfavorable mix impact in this geographic segment was driven by the mix within our core products and an increase in revenue from our relatively lower margin Cisco Unified Computing System products.

[0000858877-15-000051:mdna:226]
The gross margin percentage decrease in our EMEA segment was due primarily to unfavorable impacts from pricing and mix. The unfavorable mix impact was driven by an increase in revenue from our relatively lower margin Cisco Unified Computing System products. Lower service gross margin also contributed to the decrease in the overall gross margin in this segment.

[0000858877-15-000051:mdna:227]
Our APJC segment gross margin percentage increased due to productivity improvements and favorable mix impact, partially offset by unfavorable impacts from pricing. The favorable mix impact was driven by a decrease in revenue from our relatively lower margin Service Provider Video products.

[0000858877-15-000051:mdna:228]
[same as prior period, unchanged from 0000858877-15-000013:mdna:228]

[0000858877-15-000051:mdna:229]
Nine Months Ended April 25, 2015 Compared with Nine Months Ended April 26, 2014

[0000858877-15-000051:mdna:230]
We experienced a gross margin percentage increase in our Americas segment due to productivity improvements and, to a lesser extent, a favorable mix impact, partially offset by unfavorable impacts from pricing. The favorable mix impact in this geographic segment was driven by lower sales of our relatively lower margin Service Provider Video products, partially offset by an increase in revenue from our relatively lower margin Cisco Unified Computing System products.

[0000858877-15-000051:mdna:231]
The gross margin percentage decrease in our EMEA segment was primarily due to negative impacts from pricing. Lower service gross margin also contributed to the decrease in the overall gross margin in this segment.

[0000858877-15-000051:mdna:232]
The APJC segment gross margin percentage increased due to productivity improvements and a favorable mix impact, partially offset by unfavorable impacts from pricing. The favorable mix impact was driven by a decrease in revenue from our relatively lower margin Service Provider Video products and an increase in revenue from certain of our higher margin core products. Lower service gross margin also contributed to the decrease in the overall gross margin in this segment.

[0000858877-15-000051:mdna:233]
[same as prior period, unchanged from 0000858877-15-000013:mdna:241]

[0000858877-15-000051:mdna:234]
[same as prior period, unchanged from 0000858877-15-000013:mdna:234]

[0000858877-15-000051:mdna:235]
[same as prior period, unchanged from 0000858877-15-000013:mdna:235]

[0000858877-15-000051:mdna:236]
[same as prior period, unchanged from 0000858877-15-000013:mdna:236]

[0000858877-15-000051:mdna:237]
[same as prior period, unchanged from 0000858877-15-000013:mdna:237]

[0000858877-15-000051:mdna:238]
[same as prior period, unchanged from 0000858877-15-000013:mdna:238]

[0000858877-15-000051:mdna:239]
[same as prior period, unchanged from 0000858877-15-000013:mdna:239]

[0000858877-15-000051:mdna:240]
[same as prior period, unchanged from 0000858877-15-000013:mdna:240]

[0000858877-15-000051:mdna:241]
[same as prior period, unchanged from 0000858877-15-000013:mdna:242]

[0000858877-15-000051:mdna:242]
[same as prior period, unchanged from 0000858877-15-000013:mdna:243]

[0000858877-15-000051:mdna:243]
[same as prior period, unchanged from 0000858877-15-000013:mdna:244]

[0000858877-15-000051:mdna:244]
[same as prior period, unchanged from 0000858877-15-000013:mdna:245]

[0000858877-15-000051:mdna:245]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |  | Variance in Percent |  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Research and development |  | $ | 1,547 |  |  | $ | 1,565 |  |  | $ | (18 | ) |  | (1.2 | )% |  | $ | 4,659 |  |  | $ | 4,701 |  |  | $ | (42 | ) |  | (0.9 | )% |
| Percentage of revenue |  | 12.7 | % |  | 13.6 | % |  |  |  |  |  | 12.8 | % |  | 13.5 | % |  |  |  |  |
| Sales and marketing |  | 2,449 |  |  | 2,342 |  |  | 107 |  |  | 4.6 | % |  | 7,272 |  |  | 7,030 |  |  | 242 |  |  | 3.4 | % |
| Percentage of revenue |  | 20.2 | % |  | 20.3 | % |  |  |  |  |  | 20.0 | % |  | 20.2 | % |  |  |  |  |
| General and administrative |  | 510 |  |  | 460 |  |  | 50 |  |  | 10.9 | % |  | 1,504 |  |  | 1,426 |  |  | 78 |  |  | 5.5 | % |
| Percentage of revenue |  | 4.2 | % |  | 4.0 | % |  |  |  |  |  | 4.1 | % |  | 4.1 | % |  |  |  |  |
| Total |  | $ | 4,506 |  |  | $ | 4,367 |  |  | $ | 139 |  |  | 3.2 | % |  | $ | 13,435 |  |  | $ | 13,157 |  |  | $ | 278 |  |  | 2.1 | % |
| Percentage of revenue |  | 37.1 | % |  | 37.8 | % |  |  |  |  |  | 37.0 | % |  | 37.8 | % |  |  |  |  |

[0000858877-15-000051:mdna:246]
[same as prior period, unchanged from 0000858877-15-000013:mdna:247]

[0000858877-15-000051:mdna:247]
R&D expenses decreased for the third quarter of fiscal 2015, as compared with the third quarter of fiscal 2014, primarily due to lower headcount-related expenses driven by our restructuring actions. Lower acquisition related costs also contributed to the decrease.

[0000858877-15-000051:mdna:248]
The decrease in R&D expenses for the first nine months of fiscal 2015, as compared with the first nine months of fiscal 2014, was primarily due to higher compensation expense recorded in the first nine months of fiscal 2014 in connection with our acquisition of the remaining interest in Insieme, partially offset by higher contracted services and higher headcount-related expenses. The higher headcount-related expenses were due to increased variable compensation expense, partially offset by efficiencies related to our restructuring actions.

[0000858877-15-000051:mdna:249]
[same as prior period, unchanged from 0000858877-15-000013:mdna:250]

[0000858877-15-000051:mdna:250]
[same as prior period, unchanged from 0000858877-15-000013:mdna:251]

[0000858877-15-000051:mdna:251]
Sales and marketing expenses increased for the third quarter of fiscal 2015, as compared with the third quarter of fiscal 2014, due to higher headcount-related expenses and, to a lesser extent, higher contracted services. Higher headcount-related expenses were due primarily to increased variable compensation expense as a result of our financial performance.

[0000858877-15-000051:mdna:252]
Sales and marketing expenses increased for the first nine months of fiscal 2015, as compared with the first nine months of fiscal 2014, due to higher headcount-related expenses, driven by increased variable compensation expense, and higher discretionary spending, partially offset by higher compensation expense recorded in the first nine months of fiscal 2014 in connection with our acquisition of the remaining interest in Insieme.

[0000858877-15-000051:mdna:253]
[same as prior period, unchanged from 0000858877-15-000013:mdna:254]

[0000858877-15-000051:mdna:254]
G&A expenses increased in the third quarter of fiscal 2015, as compared with the third quarter of fiscal 2014, primarily due to the timing of corporate-level expenses, which tend to vary from period to period, and higher acquisition-related costs.

[0000858877-15-000051:mdna:255]
G&A expenses increased in the first nine months of fiscal 2015, as compared with the corresponding period in fiscal 2014, primarily due to increased variable compensation expense as a result of our financial performance and timing of corporate-level expenses, which tend to vary from period to period, partially offset by higher compensation expense recorded in the first nine months of fiscal 2014 in connection with our acquisition of the remaining interest in Insieme.

[0000858877-15-000051:mdna:256]
[same as prior period, unchanged from 0000858877-15-000013:mdna:257]

[0000858877-15-000051:mdna:257]
In the third quarter of fiscal 2015, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $112 million, or approximately 2.6%, compared with the third quarter of fiscal 2014.

[0000858877-15-000051:mdna:258]
In the first nine months of fiscal 2015, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $168 million, or approximately 1.3%, compared with the first nine months of fiscal 2014.

[0000858877-15-000051:mdna:259]
[same as prior period, unchanged from 0000858877-15-000013:mdna:261]

[0000858877-15-000051:mdna:260]
[same as prior period, unchanged from 0000858877-15-000013:mdna:262]

[0000858877-15-000051:mdna:261]
[same as prior period, unchanged from 0000858877-15-000013:mdna:263]

[0000858877-15-000051:mdna:262]
Our headcount increased by approximately 800 employees in the third quarter of fiscal 2015 and decreased by approximately 3,100 employees in the first nine months of fiscal 2015, as compared with the total headcount at the end of fiscal 2014. The increase in headcount for the third quarter of fiscal 2015 was due to targeted hiring in key growth areas in engineering, services and sales.

[0000858877-15-000051:mdna:263]
The decrease in headcount for the first nine months of fiscal 2015 was due to headcount reductions from our workforce reduction under the Fiscal 2015 Plan. These headcount reductions were partially offset by headcount additions from targeted hiring in engineering, services and sales, and also by headcount additions from our recent acquisitions.

[0000858877-15-000051:mdna:264]
[same as prior period, unchanged from 0000858877-15-000013:mdna:265]

[0000858877-15-000051:mdna:265]
[same as prior period, unchanged from 0000858877-15-000013:mdna:266]

[0000858877-15-000051:mdna:266]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Cost of sales—product |  | $ | 12 |  |  | $ | 12 |  |  | $ | 34 |  |  | $ | 34 |  |
| Cost of sales—service |  | 44 |  |  | 39 |  |  | 115 |  |  | 112 |  |
| Share-based compensation expense in cost of sales |  | 56 |  |  | 51 |  |  | 149 |  |  | 146 |  |
| Research and development |  | 114 |  |  | 106 |  |  | 338 |  |  | 306 |  |
| Sales and marketing |  | 147 |  |  | 144 |  |  | 408 |  |  | 408 |  |
| General and administrative |  | 50 |  |  | 52 |  |  | 151 |  |  | 153 |  |
| Restructuring and other charges |  | — |  |  | — |  |  | (2 | ) |  | (4 | ) |
| Share-based compensation expense in operating expenses |  | 311 |  |  | 302 |  |  | 895 |  |  | 863 |  |
| Total share-based compensation expense |  | $ | 367 |  |  | $ | 353 |  |  | $ | 1,044 |  |  | $ | 1,009 |  |

[0000858877-15-000051:mdna:267]
The change in share-based compensation expense in the third quarter and first nine months of fiscal 2015, as compared with the corresponding periods in fiscal 2014, was due primarily to the timing of annual RSU grants, higher expense associated with PRSUs, and lower expense related to equity awards assumed with respect to our recent acquisitions.

[0000858877-15-000051:mdna:268]
[same as prior period, unchanged from 0000858877-15-000013:mdna:270]

[0000858877-15-000051:mdna:269]
[same as prior period, unchanged from 0000858877-15-000013:mdna:271]

[0000858877-15-000051:mdna:270]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 187 |  |  | $ | 190 |  |  | $ | 618 |  |  | $ | 553 |  |
| Operating expenses |  | 70 |  |  | 71 |  |  | 213 |  |  | 207 |  |
| Total |  | $ | 257 |  |  | $ | 261 |  |  | $ | 831 |  |  | $ | 760 |  |

[0000858877-15-000051:mdna:271]
Amortization of purchased intangible assets decreased slightly for the third quarter of fiscal 2015, as compared with the third quarter of fiscal 2014, due to certain purchased intangible assets having become fully amortized, partially offset by amortization of purchased intangible assets from our recent acquisitions.

[0000858877-15-000051:mdna:272]
Amortization of purchased intangible assets increased for the first nine months of fiscal 2015, as compared with the corresponding period of fiscal 2014, primarily due to the impairment charges of approximately $57 million recorded in the first nine months of fiscal 2015. The impairment charges were primarily due to reductions in expected future cash flows related to certain of our technology intangible assets.

[0000858877-15-000051:mdna:273]
[same as prior period, unchanged from 0000858877-15-000013:mdna:274]

[0000858877-15-000051:mdna:274]
[same as prior period, unchanged from 0000858877-15-000013:mdna:289]

[0000858877-15-000051:mdna:275]
[same as prior period, unchanged from 0000858877-15-000013:mdna:275]

[0000858877-15-000051:mdna:276]
[same as prior period, unchanged from 0000858877-15-000013:mdna:276]

[0000858877-15-000051:mdna:277]
[same as prior period, unchanged from 0000858877-15-000013:mdna:277]

[0000858877-15-000051:mdna:278]
In the third quarter and first nine months of fiscal 2015, we incurred within operating expenses restructuring and other charges of approximately $24 million and $411 million, respectively, which were related primarily to employee severance charges for employees impacted by our workforce reduction under the Fiscal 2015 Plan.  We expect the remaining charges under this plan to be incurred during the remainder of fiscal 2015. We plan to reinvest substantially all of the cost savings from the restructuring actions in key growth areas of our business such as data center, software, security, and cloud. The overall cost savings from these restructuring actions were not material for the periods presented and are not expected to be material for future periods.

[0000858877-15-000051:mdna:279]
In the third quarter and first nine months of fiscal 2014, we incurred within operating expenses net restructuring and other charges of $26 million and $336 million, respectively, which were related primarily to employee severance charges for employees impacted by our workforce reduction under the Fiscal 2014 Plan. See Note 5 to the Consolidated Financial Statements.

[0000858877-15-000051:mdna:280]
[same as prior period, unchanged from 0000858877-15-000013:mdna:280]

[0000858877-15-000051:mdna:281]
[same as prior period, unchanged from 0000858877-15-000013:mdna:281]

[0000858877-15-000051:mdna:282]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Operating income |  | $ | 2,925 |  |  | $ | 2,542 |  |  | $ | 7,889 |  |  | $ | 6,664 |  |
| Operating income as a percentage of revenue |  | 24.1 | % |  | 22.0 | % |  | 21.7 | % |  | 19.2 | % |

[0000858877-15-000051:mdna:283]
For the third quarter of fiscal 2015, as compared with the third quarter of fiscal 2014, operating income increased by 15%, and as a percentage of revenue operating income increased by 2.1 percentage points. The increase resulted from an increase in revenue and a gross margin percentage increase, with the gross margin percentage positively affected by the supplier component remediation adjustment of $164 million (or 1.4 percentage points) recorded in the third quarter of fiscal 2015.

[0000858877-15-000051:mdna:284]
In the first nine months of fiscal 2015, as compared with the first nine months of fiscal 2014, operating income increased by 18%, and as a percentage of revenue operating income increased by 2.5 percentage points. The increase resulted from the following: an increase in revenue; a gross margin percentage increase, driven in part by the $655 million (or 1.9 percentage points) supplier component remediation charge recorded in the second quarter of fiscal 2014; and higher compensation expense recorded in the first nine months of fiscal 2014 in connection with our acquisition of the remaining interest in Insieme.

[0000858877-15-000051:mdna:285]
[same as prior period, unchanged from 0000858877-15-000013:mdna:285]

[0000858877-15-000051:mdna:286]
[same as prior period, unchanged from 0000858877-15-000013:mdna:286]

[0000858877-15-000051:mdna:287]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |
| Interest income | $ | 190 |  |  | $ | 170 |  |  | $ | 20 |  |  | $ | 558 |  |  | $ | 508 |  |  | $ | 50 |  |
| Interest expense | (139 | ) |  | (146 | ) |  | 7 |  |  | (417 | ) |  | (422 | ) |  | 5 |  |
| Interest income (expense), net | $ | 51 |  |  | $ | 24 |  |  | $ | 27 |  |  | $ | 141 |  |  | $ | 86 |  |  | $ | 55 |  |

[0000858877-15-000051:mdna:288]
For the third quarter and first nine months of fiscal 2015, interest income increased by 12% and 10%, respectively, compared with the corresponding periods in fiscal 2014, driven by an increase in our portfolio of cash, cash equivalents, and fixed income investments. Interest expense in the third quarter and first nine months of fiscal 2015, compared with the corresponding periods in fiscal 2014, decreased by 5% and 1%, respectively.

[0000858877-15-000051:mdna:289]
[same as prior period, unchanged from 0000858877-15-000013:mdna:290]

[0000858877-15-000051:mdna:290]
[same as prior period, unchanged from 0000858877-15-000013:mdna:291]

[0000858877-15-000051:mdna:291]
[same as prior period, unchanged from 0000858877-15-000013:mdna:292]

[0000858877-15-000051:mdna:292]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |  | April 25, 2015 |  | April 26, 2014 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |
| Publicly traded equity securities | $ | 38 |  |  | $ | 55 |  |  | $ | (17 | ) |  | $ | 94 |  |  | $ | 199 |  |  | $ | (105 | ) |
| Fixed income securities | 6 |  |  | 14 |  |  | (8 | ) |  | 26 |  |  | 35 |  |  | (9 | ) |
| Total available-for-sale investments | 44 |  |  | 69 |  |  | (25 | ) |  | 120 |  |  | 234 |  |  | (114 | ) |
| Privately held companies | 3 |  |  | (10 | ) |  | 13 |  |  | 104 |  |  | (76 | ) |  | 180 |  |
| Net gains (losses) on investments | 47 |  |  | 59 |  |  | (12 | ) |  | 224 |  |  | 158 |  |  | 66 |  |
| Other gains (losses), net | 12 |  |  | 17 |  |  | (5 | ) |  | 14 |  |  | 29 |  |  | (15 | ) |
| Other income (loss), net | $ | 59 |  |  | $ | 76 |  |  | $ | (17 | ) |  | $ | 238 |  |  | $ | 187 |  |  | $ | 51 |  |

[0000858877-15-000051:mdna:293]
The decrease in total net gains on available-for-sale investments in the third quarter and first nine months of fiscal 2015, as compared with the corresponding periods in fiscal 2014, was primarily attributable to lower gains on publicly traded equity securities in the current periods as a result of market conditions and the timing of sales of these securities.

[0000858877-15-000051:mdna:294]
The change in net gains (losses) on investments in privately held companies for the third quarter of fiscal 2015, as compared with the third quarter of fiscal 2014, was primarily due to the absence of losses from VCE for the third quarter of fiscal 2015, partially offset by impairment charges on certain investments in privately held companies and lower realized gains from  sales of various investments in privately held companies. The change in net gains (losses) on investments in privately held companies for the first nine months of fiscal 2015 as compared with the first nine months of fiscal 2014, was primarily due to a gain of $126 million related to the reorganization of our investments in VCE and lower losses related to this investment under the equity method. We ceased accounting for VCE under the equity method in October 2014.

[0000858877-15-000051:mdna:295]
The change in other gains (losses), net in the third quarter and first nine months of fiscal 2015, as compared with the corresponding periods in fiscal 2014, was driven by equity derivative impacts and higher donation expenses, partially offset by net favorable foreign exchange impacts.

[0000858877-15-000051:mdna:296]
[same as prior period, unchanged from 0000858877-15-000013:mdna:297]

[0000858877-15-000051:mdna:297]
[same as prior period, unchanged from 0000858877-15-000013:mdna:298]

[0000858877-15-000051:mdna:298]
The provision for income taxes resulted in an effective tax rate of 19.7% for the third quarter of fiscal 2015, compared with 17.4% for the third quarter of fiscal 2014, which resulted in a net 2.3 percentage point increase in the effective tax rate for the third quarter of fiscal 2015 as compared with the third quarter of fiscal 2014. The increase in the effective tax rates was primarily due to a decrease in foreign income taxed at lower than U.S. rates.

[0000858877-15-000051:mdna:299]
The provision for income taxes resulted in an effective tax rate of 19.4% for the first nine months of fiscal 2015, as compared with an effective tax rate of 19.2% for the first nine months of fiscal 2014, which resulted in a net 0.2 percentage point increase in the effective tax rate for the first nine months of fiscal 2015 as compared with the first nine months of fiscal 2014. The increase in the effective tax rates was primarily due to a decrease in foreign income taxed at lower than U.S. rates, partially offset by a decrease in non-deductible compensation.

[0000858877-15-000051:mdna:300]
66

[0000858877-15-000051:mdna:301]
[same as prior period, unchanged from 0000858877-15-000013:mdna:300]

[0000858877-15-000051:mdna:302]
[same as prior period, unchanged from 0000858877-15-000013:mdna:301]

[0000858877-15-000051:mdna:303]
[same as prior period, unchanged from 0000858877-15-000013:mdna:302]

[0000858877-15-000051:mdna:304]
[same as prior period, unchanged from 0000858877-15-000013:mdna:303]

[0000858877-15-000051:mdna:305]
[same as prior period, unchanged from 0000858877-15-000013:mdna:304]

[0000858877-15-000051:mdna:306]
[same as prior period, unchanged from 0000858877-15-000013:mdna:305]

[0000858877-15-000051:mdna:307]
|  | April 25, 2015 |  | July 26, 2014 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 3,870 |  |  | $ | 6,726 |  |  | $ | (2,856 | ) |
| Fixed income securities | 48,626 |  |  | 43,396 |  |  | 5,230 |  |
| Publicly traded equity securities | 1,923 |  |  | 1,952 |  |  | (29 | ) |
| Total | $ | 54,419 |  |  | $ | 52,074 |  |  | $ | 2,345 |  |

[0000858877-15-000051:mdna:308]
The net increase in cash and cash equivalents and investments in the first nine months of fiscal 2015 was primarily the result of cash provided by operating activities of $8.4 billion and proceeds from the issuance of common stock of $1.6 billion pursuant to employee stock incentive plans. These sources of cash were partially offset by the repurchase of common stock of $3.3 billion under the stock repurchase program, cash dividends paid of $3.0 billion, capital expenditures of $0.9 billion and net cash paid for acquisitions of $0.2 billion.

[0000858877-15-000051:mdna:309]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $51.8 billion and $47.4 billion as of April 25, 2015 and July 26, 2014, respectively. Under current tax laws and regulations, if these assets were to be distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. The balance of cash and cash equivalents and investments available in the United States as of April 25, 2015 and July 26, 2014 was $2.6 billion and $4.7 billion, respectively.

[0000858877-15-000051:mdna:310]
[same as prior period, unchanged from 0000858877-15-000013:mdna:309]

[0000858877-15-000051:mdna:311]
[same as prior period, unchanged from 0000858877-15-000013:mdna:310]

[0000858877-15-000051:mdna:312]
[same as prior period, unchanged from 0000858877-15-000013:mdna:311]

[0000858877-15-000051:mdna:313]
|  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |
| Net cash provided by operating activities | $ | 8,414 |  |  | $ | 8,720 |  |
| Acquisition of property and equipment | (907 | ) |  | (950 | ) |
| Free cash flow | $ | 7,507 |  |  | $ | 7,770 |  |

[0000858877-15-000051:mdna:314]
[same as prior period, unchanged from 0000858877-15-000013:mdna:313]

[0000858877-15-000051:mdna:315]
[same as prior period, unchanged from 0000858877-15-000013:mdna:314]

[0000858877-15-000051:mdna:316]
[same as prior period, unchanged from 0000858877-15-000013:mdna:315]

[0000858877-15-000051:mdna:317]
[same as prior period, unchanged from 0000858877-15-000013:mdna:316]

[0000858877-15-000051:mdna:318]
[same as prior period, unchanged from 0000858877-15-000013:mdna:317]

[0000858877-15-000051:mdna:319]
[same as prior period, unchanged from 0000858877-15-000013:mdna:318]

[0000858877-15-000051:mdna:320]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2015 |  |  |  |  |  |  |  |  |  |  |  |  |
| April 25, 2015 |  | $ | 0.21 |  |  | $ | 1,070 |  |  | 35 |  |  | $ | 28.39 |  |  | $ | 1,008 |  |  | $ | 2,078 |  |
| January 24, 2015 |  | $ | 0.19 |  |  | $ | 974 |  |  | 44 |  |  | $ | 27.63 |  |  | $ | 1,208 |  |  | $ | 2,182 |  |
| October 25, 2014 |  | $ | 0.19 |  |  | $ | 973 |  |  | 41 |  |  | $ | 24.58 |  |  | $ | 1,013 |  |  | $ | 1,986 |  |
| Fiscal 2014 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 26, 2014 |  | $ | 0.19 |  |  | $ | 974 |  |  | 61 |  |  | $ | 25.11 |  |  | $ | 1,514 |  |  | $ | 2,488 |  |
| April 26, 2014 |  | $ | 0.19 |  |  | $ | 974 |  |  | 90 |  |  | $ | 22.24 |  |  | $ | 2,005 |  |  | $ | 2,979 |  |
| January 25, 2014 |  | $ | 0.17 |  |  | $ | 896 |  |  | 185 |  |  | $ | 21.73 |  |  | $ | 4,020 |  |  | $ | 4,916 |  |
| October 26, 2013 |  | $ | 0.17 |  |  | $ | 914 |  |  | 84 |  |  | $ | 23.65 |  |  | $ | 2,000 |  |  | $ | 2,914 |  |

[0000858877-15-000051:mdna:321]
Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-15-000051:mdna:322]
[same as prior period, unchanged from 0000858877-15-000013:mdna:321]

[0000858877-15-000051:mdna:323]
|  | April 25, 2015 |  | July 26, 2014 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,889 |  |  | $ | 5,157 |  |  | $ | (268 | ) |
| DSO | 37 |  |  | 38 |  |  | (1 | ) |

[0000858877-15-000051:mdna:324]
Our accounts receivable net, as of April 25, 2015 decreased by approximately 5% compared with the end of fiscal 2014. Our DSO as of April 25, 2015 was lower by one day compared with the end of fiscal 2014, primarily due to product and service billings being more linear in the third quarter of fiscal 2015 compared with the fourth quarter of fiscal 2014.

[0000858877-15-000051:mdna:325]
[same as prior period, unchanged from 0000858877-15-000013:mdna:324]

[0000858877-15-000051:mdna:326]
|  | April 25, 2015 |  | July 26, 2014 |  | Increase (Decrease) |
| Inventories | $ | 1,760 |  |  | $ | 1,591 |  |  | $ | 169 |  |
| Annualized inventory turns | 10.1 |  |  | 12.7 |  |  | (2.6 | ) |
| Purchase commitments with contract manufacturers and suppliers | $ | 4,495 |  |  | $ | 4,169 |  |  | $ | 326 |  |

[0000858877-15-000051:mdna:327]
Inventory as of April 25, 2015 increased by 11% from our inventory balance at the end of fiscal 2014, and for the same period purchase commitments with contract manufacturers and suppliers increased by approximately 8%.  On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers increased by 9% compared with the end of fiscal 2014.

[0000858877-15-000051:mdna:328]
[same as prior period, unchanged from 0000858877-15-000013:mdna:327]

[0000858877-15-000051:mdna:329]
[same as prior period, unchanged from 0000858877-15-000013:mdna:328]

[0000858877-15-000051:mdna:330]
[same as prior period, unchanged from 0000858877-15-000013:mdna:329]

[0000858877-15-000051:mdna:331]
[same as prior period, unchanged from 0000858877-15-000013:mdna:330]

[0000858877-15-000051:mdna:332]
[same as prior period, unchanged from 0000858877-15-000013:mdna:331]

[0000858877-15-000051:mdna:333]
[same as prior period, unchanged from 0000858877-15-000013:mdna:332]

[0000858877-15-000051:mdna:334]
[same as prior period, unchanged from 0000858877-15-000013:mdna:333]

[0000858877-15-000051:mdna:335]
Financing Receivables and Guarantees We measure our net balance sheet exposure position related to our financing receivables and financing guarantees by reducing the total of gross financing receivables and financing guarantees by the associated allowances for credit loss and deferred revenue. As of April 25, 2015, our net balance sheet exposure position related to financing receivables and financing guarantees was as follows (in millions):

[0000858877-15-000051:mdna:336]
|  | FINANCING RECEIVABLES |  | FINANCING GUARANTEES |  |  |
| April 25, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |  | Channel Partner |  | End-User Customers |  | Total |  | TOTAL |
| Financing receivables less unearned income | $ | 3,312 |  |  | $ | 1,720 |  |  | $ | 3,081 |  |  | $ | 8,113 |  |  | $ | 299 |  |  | $ | 138 |  |  | $ | 437 |  |  | $ | 8,550 |  |
| Allowance for credit loss | (242 | ) |  | (80 | ) |  | (37 | ) |  | (359 | ) |  | — |  |  | — |  |  | — |  |  | (359 | ) |
| Deferred revenue | (7 | ) |  | (14 | ) |  | (1,520 | ) |  | (1,541 | ) |  | (122 | ) |  | (113 | ) |  | (235 | ) |  | (1,776 | ) |
| Net balance sheet exposure | $ | 3,063 |  |  | $ | 1,626 |  |  | $ | 1,524 |  |  | $ | 6,213 |  |  | $ | 177 |  |  | $ | 25 |  |  | $ | 202 |  |  | $ | 6,415 |  |

[0000858877-15-000051:mdna:337]
Financing Receivables  Financing receivables less unearned income decreased by 4% compared with the end of fiscal 2014. The change was due to a 6% decrease in lease receivables and a 4% decrease in financed service contracts and other, partially offset by a 2% increase in loan receivables. We provide financing to certain end-user customers and channel partners to enable sales of our products, services, and networking solutions. These financing arrangements include leases, financed service contracts, and loans. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Lease receivables include sales-type and direct-financing leases. We also provide certain qualified customers financing for long-term service contracts, which primarily relate to technical support services and advanced services. Our loan financing arrangements may include not only financing the acquisition of our products and services but also providing additional funds for other costs associated with network installation and integration of our products and services. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-15-000051:mdna:338]
[same as prior period, unchanged from 0000858877-15-000013:mdna:337]

[0000858877-15-000051:mdna:339]
[same as prior period, unchanged from 0000858877-15-000013:mdna:350]

[0000858877-15-000051:mdna:340]
[same as prior period, unchanged from 0000858877-15-000013:mdna:339]

[0000858877-15-000051:mdna:341]
[same as prior period, unchanged from 0000858877-15-000013:mdna:340]

[0000858877-15-000051:mdna:342]
[same as prior period, unchanged from 0000858877-15-000013:mdna:341]

[0000858877-15-000051:mdna:343]
[same as prior period, unchanged from 0000858877-15-000013:mdna:342]

[0000858877-15-000051:mdna:344]
[same as prior period, unchanged from 0000858877-15-000013:mdna:343]

[0000858877-15-000051:mdna:345]
|  | Maturity Date |  | April 25, 2015 |  | July 26, 2014 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | $ | 850 |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 1,000 |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | — |  |  | 500 |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3,000 |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 2,400 |  |
| 3.15% | March 14, 2017 |  | 750 |  |  | 750 |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 20,250 |  |  | $ | 20,750 |  |

[0000858877-15-000051:mdna:346]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of April 25, 2015.

[0000858877-15-000051:mdna:347]
[same as prior period, unchanged from 0000858877-15-000013:mdna:346]

[0000858877-15-000051:mdna:348]
Other Debt  Other debt as of April 25, 2015 and July 26, 2014 included secured borrowings associated with customer financing arrangements.  The amount of borrowings outstanding under these arrangements was $5 million and $12 million as of April 25, 2015 and July 26, 2014, respectively.

[0000858877-15-000051:mdna:349]
Commercial Paper  In fiscal 2011, we established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. As of April 25, 2015, we had commercial paper notes of $500 million outstanding under this program, with original maturity dates of three months or less. We had no commercial paper notes outstanding as of July 26, 2014.

[0000858877-15-000051:mdna:350]
Credit Facility On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR or a comparable or successor rate which rate is approved by the Administrative Agent (“Eurocurrency Rate”) for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. The credit agreement requires that we comply with certain covenants, including that it maintains an interest coverage ratio as defined in the agreement.

[0000858877-15-000051:mdna:351]
70

[0000858877-15-000051:mdna:352]
[same as prior period, unchanged from 0000858877-15-000013:mdna:351]

[0000858877-15-000051:mdna:353]
[same as prior period, unchanged from 0000858877-15-000013:mdna:352]

[0000858877-15-000051:mdna:354]
We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.  We were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-15-000051:mdna:355]
This credit facility replaces our prior credit facility that was entered into on February 17, 2012, which was terminated in connection with its entering into the new credit facility.

[0000858877-15-000051:mdna:356]
[same as prior period, unchanged from 0000858877-15-000013:mdna:354]

[0000858877-15-000051:mdna:357]
|  | April 25, 2015 |  | July 26, 2014 |  | Increase (Decrease) |
| Service | $ | 9,236 |  |  | $ | 9,640 |  |  | $ | (404 | ) |
| Product | 4,945 |  |  | 4,502 |  |  | 443 |  |
| Total | $ | 14,181 |  |  | $ | 14,142 |  |  | $ | 39 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 9,371 |  |  | $ | 9,478 |  |  | $ | (107 | ) |
| Noncurrent | 4,810 |  |  | 4,664 |  |  | 146 |  |
| Total | $ | 14,181 |  |  | $ | 14,142 |  |  | $ | 39 |  |

[0000858877-15-000051:mdna:358]
The 4% decrease in deferred service revenue was driven by the timing of multiyear arrangements, an increase in customers paying technical support service contracts over time and the impact of ongoing amortization of deferred service revenue. The 10% increase in deferred product revenue was primarily due to increased deferrals related to subscription revenue arrangements and also was due, to a lesser extent, to an increase in shipments not having met revenue recognition criteria as of April 25, 2015.

[0000858877-15-000051:mdna:359]
[same as prior period, unchanged from 0000858877-15-000013:mdna:357]

[0000858877-15-000051:mdna:360]
[same as prior period, unchanged from 0000858877-15-000013:mdna:358]

[0000858877-15-000051:mdna:361]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Norway, and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of April 25, 2015 were $1.1 billion.

[0000858877-15-000051:mdna:362]
[same as prior period, unchanged from 0000858877-15-000013:mdna:360]

[0000858877-15-000051:mdna:363]
[same as prior period, unchanged from 0000858877-15-000013:mdna:361]

[0000858877-15-000051:mdna:364]
[same as prior period, unchanged from 0000858877-15-000013:mdna:362]

[0000858877-15-000051:mdna:365]
During the first quarter of fiscal 2014, we exercised our call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  During the nine months ended April 25, 2015 and April 26, 2014, we recorded compensation expense of $155 million and $363 million, respectively, related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders. Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods. Based on the terms of the agreement, we have determined that the maximum amount that could be recorded as compensation expense by us is approximately $843 million (which includes the $571 million that has been expensed to date), net of forfeitures.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.

[0000858877-15-000051:mdna:366]
[same as prior period, unchanged from 0000858877-15-000013:mdna:375]

[0000858877-15-000051:mdna:367]
[same as prior period, unchanged from 0000858877-15-000013:mdna:365]

[0000858877-15-000051:mdna:368]
[same as prior period, unchanged from 0000858877-15-000013:mdna:366]

[0000858877-15-000051:mdna:369]
Other Funding Commitments  We also have certain funding commitments primarily related to our investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $247 million as of April 25, 2015, compared with $255 million as of July 26, 2014.

[0000858877-15-000051:mdna:370]
[same as prior period, unchanged from 0000858877-15-000013:mdna:367]

[0000858877-15-000051:mdna:371]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and customer financings, and we have determined that as of April 25, 2015 there were no material unconsolidated variable interest entities.

[0000858877-15-000051:mdna:372]
[same as prior period, unchanged from 0000858877-15-000013:mdna:369]

[0000858877-15-000051:mdna:373]
[same as prior period, unchanged from 0000858877-15-000013:mdna:370]

[0000858877-15-000051:mdna:374]
[same as prior period, unchanged from 0000858877-15-000013:mdna:371]

[0000858877-15-000051:mdna:375]
We periodically engage in securities lending activities with certain of our investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 25, 2015 and April 26, 2014 was $0.5 billion and $1.4 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of April 25, 2015 and July 26, 2014, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-15-000051:mdna:376]
[same as prior period, unchanged from 0000858877-15-000013:mdna:373]

[0000858877-15-000051:mdna:377]
[same as prior period, unchanged from 0000858877-15-000013:mdna:374]
