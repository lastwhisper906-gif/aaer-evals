# CSCO notes — 0000858877-15-000051


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-15-000051:notes:1]
[same as prior period, unchanged from 0000858877-15-000013:notes:1]

[0000858877-15-000051:notes:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Compensation expense related to acquisitions | $ | 72 |  |  | $ | 95 |  |  | $ | 264 |  |  | $ | 505 |  |


## csco:DescriptionOfNewAccountingPronouncementsNotYetAdoptedPolicyTextBlock

[0000858877-15-000051:notes:3]
Recent Accounting Standards or Updates Not Yet Effective

[0000858877-15-000051:notes:4]
In May 2014, the FASB issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance.  The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services.  This accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2018.  The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption.  Early adoption is not permitted.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-15-000051:notes:5]
In February 2015, the FASB issued an accounting standard update that changes the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2017 and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-15-000051:notes:6]
In April 2015, the FASB issued an accounting standard update requiring debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying amount of that debt, consistent with debt discounts.  The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2017 on a retrospective basis, with early adoption permitted.  The accounting standard update is a change in balance sheet presentation only and is not expected to have a material impact on the Company's Consolidated Financial Statements.


## csco:EntityWideDisclosureOnGeographicAreasLongLivedAssetsTableTextBlock

[0000858877-15-000051:notes:7]
[same as prior period, unchanged from 0000858877-15-000013:notes:5]

[0000858877-15-000051:notes:8]
|  | April 25, 2015 |  | July 26, 2014 |
| Property and equipment, net: |  |  |  |
| United States | $ | 2,709 |  |  | $ | 2,697 |  |
| International | 567 |  |  | 555 |  |
| Total | $ | 3,276 |  |  | $ | 3,252 |  |


## csco:IncometaxprovisionTableTextBlock

[0000858877-15-000051:notes:9]
[same as prior period, unchanged from 0000858877-15-000013:notes:7]

[0000858877-15-000051:notes:10]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Income before provision for income taxes | $ | 3,035 |  |  | $ | 2,642 |  |  | $ | 8,268 |  |  | $ | 6,937 |  |
| Provision for income taxes | $ | 598 |  |  | $ | 461 |  |  | $ | 1,606 |  |  | $ | 1,331 |  |
| Effective tax rate | 19.7 | % |  | 17.4 | % |  | 19.4 | % |  | 19.2 | % |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-15-000051:notes:11]
[same as prior period, unchanged from 0000858877-15-000013:notes:9]

[0000858877-15-000051:notes:12]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Revenue: |  |  |  |  |  |  |  |
| Switching | $ | 3,560 |  |  | $ | 3,368 |  |  | $ | 11,022 |  |  | $ | 10,366 |  |
| NGN Routing | 1,999 |  |  | 1,925 |  |  | 5,712 |  |  | 5,681 |  |
| Collaboration | 973 |  |  | 909 |  |  | 2,912 |  |  | 2,859 |  |
| Service Provider Video | 914 |  |  | 961 |  |  | 2,561 |  |  | 2,905 |  |
| Data Center | 801 |  |  | 662 |  |  | 2,340 |  |  | 1,868 |  |
| Wireless | 611 |  |  | 560 |  |  | 1,827 |  |  | 1,624 |  |
| Security | 412 |  |  | 361 |  |  | 1,283 |  |  | 1,119 |  |
| Other | 56 |  |  | 74 |  |  | 182 |  |  | 218 |  |
| Product | 9,326 |  |  | 8,820 |  |  | 27,839 |  |  | 26,640 |  |
| Service | 2,811 |  |  | 2,725 |  |  | 8,479 |  |  | 8,145 |  |
| Total | $ | 12,137 |  |  | $ | 11,545 |  |  | $ | 36,318 |  |  | $ | 34,785 |  |


## csco:ScheduleOfCommonStockRepurchasedTextBlock

[0000858877-15-000051:notes:13]
[same as prior period, unchanged from 0000858877-15-000013:notes:11]

[0000858877-15-000051:notes:14]
|  | SharesRepurchased |  | Weighted-Average Priceper Share |  | AmountRepurchased |
| Cumulative balance at July 26, 2014 | 4,288 |  |  | $ | 20.63 |  |  | $ | 88,445 |  |
| Repurchase of common stock under the stock repurchase program (1) | 120 |  |  | 26.81 |  |  | 3,229 |  |
| Cumulative balance at April 25, 2015 | 4,408 |  |  | $ | 20.80 |  |  | $ | 91,674 |  |

[0000858877-15-000051:notes:15]
(1) Includes stock repurchases of $30 million, which were pending settlement as of April 25, 2015. There were $126 million of stock repurchases that were pending settlement as of July 26, 2014.


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-15-000051:notes:16]
[same as prior period, unchanged from 0000858877-15-000013:notes:14]

[0000858877-15-000051:notes:17]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE THREE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Equity derivatives |  | Other income (loss), net |  | $ | (8 | ) |  | $ | (8 | ) |  | $ | 8 |  |  | $ | 8 |  |
| Interest rate derivatives |  | Interest expense |  | (9 | ) |  | 8 |  |  | 9 |  |  | (8 | ) |
| Total |  |  |  | $ | (17 | ) |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |

[0000858877-15-000051:notes:18]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THENINE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE NINE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Equity derivatives |  | Other income (loss), net |  | $ | (20 | ) |  | $ | (55 | ) |  | $ | 20 |  |  | $ | 55 |  |
| Interest rate derivatives |  | Interest expense |  | 122 |  |  | (27 | ) |  | (125 | ) |  | 26 |  |
| Total |  |  |  | $ | 102 |  |  | $ | (82 | ) |  | $ | (105 | ) |  | $ | 81 |  |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-15-000051:notes:19]
[same as prior period, unchanged from 0000858877-15-000013:notes:17]

[0000858877-15-000051:notes:20]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 187 |  |  | $ | 190 |  |  | $ | 618 |  |  | $ | 553 |  |
| Operating expenses | 70 |  |  | 71 |  |  | 213 |  |  | 207 |  |
| Total | $ | 257 |  |  | $ | 261 |  |  | $ | 831 |  |  | $ | 760 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-15-000051:notes:21]
Purchased Intangible Assets

[0000858877-15-000051:notes:22]
The following table presents details of the Company’s intangible assets acquired through business combinations completed during the nine months ended April 25, 2015 (in millions, except years):

[0000858877-15-000051:notes:23]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Metacloud, Inc. | 3.0 |  | $ | 24 |  |  | 5.0 |  | $ | 3 |  |  | $ | 2 |  |  | $ | 29 |  |
| All others (three in total) | 4.7 |  | 31 |  |  | 8.1 |  | 11 |  |  | 4 |  |  | 46 |  |
| Total |  |  | $ | 55 |  |  |  |  | $ | 14 |  |  | $ | 6 |  |  | $ | 75 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-15-000051:notes:24]
[same as prior period, unchanged from 0000858877-15-000013:notes:21]

[0000858877-15-000051:notes:25]
| April 25, 2015 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,456 |  |  | $ | (1,742 | ) |  | $ | 1,714 |  |
| Customer relationships |  | 1,709 |  |  | (915 | ) |  | 794 |  |
| Other |  | 51 |  |  | (22 | ) |  | 29 |  |
| Total purchased intangible assets with finite lives |  | 5,216 |  |  | (2,679 | ) |  | 2,537 |  |
| In-process research and development, with indefinite lives |  | 89 |  |  | — |  |  | 89 |  |
| Total |  | $ | 5,305 |  |  | $ | (2,679 | ) |  | $ | 2,626 |  |

[0000858877-15-000051:notes:26]
| July 26, 2014 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 4,100 |  |  | $ | (1,976 | ) |  | $ | 2,124 |  |
| Customer relationships |  | 1,706 |  |  | (720 | ) |  | 986 |  |
| Other |  | 51 |  |  | (13 | ) |  | 38 |  |
| Total purchased intangible assets with finite lives |  | 5,857 |  |  | (2,709 | ) |  | 3,148 |  |
| In-process research and development, with indefinite lives |  | 132 |  |  | — |  |  | 132 |  |
| Total |  | $ | 5,989 |  |  | $ | (2,709 | ) |  | $ | 3,280 |  |


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-15-000051:notes:27]
[same as prior period, unchanged from 0000858877-15-000013:notes:24]

[0000858877-15-000051:notes:28]
[same as prior period, unchanged from 0000858877-15-000013:notes:25]

[0000858877-15-000051:notes:29]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC.  The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system.  Sales are attributed to a segment based on the ordering location of the customer.  The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments.  In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, impacts to cost of sales from purchase accounting adjustments to inventory, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-15-000051:notes:30]
Summarized financial information by segment for the three and nine months ended April 25, 2015 and April 26, 2014, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker ("CODM"), is as follows (in millions):

[0000858877-15-000051:notes:31]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 7,252 |  |  | $ | 6,689 |  |  | $ | 21,854 |  |  | $ | 20,465 |  |
| EMEA | 3,119 |  |  | 3,068 |  |  | 9,212 |  |  | 8,897 |  |
| APJC | 1,766 |  |  | 1,788 |  |  | 5,252 |  |  | 5,423 |  |
| Total | $ | 12,137 |  |  | $ | 11,545 |  |  | $ | 36,318 |  |  | $ | 34,785 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,560 |  |  | $ | 4,196 |  |  | $ | 13,776 |  |  | $ | 12,823 |  |
| EMEA | 1,949 |  |  | 1,967 |  |  | 5,774 |  |  | 5,725 |  |
| APJC | 1,080 |  |  | 1,076 |  |  | 3,157 |  |  | 3,148 |  |
| Segment total | 7,589 |  |  | 7,239 |  |  | 22,707 |  |  | 21,696 |  |
| Unallocated corporate items | (64 | ) |  | (233 | ) |  | (759 | ) |  | (1,332 | ) |
| Total | $ | 7,525 |  |  | $ | 7,006 |  |  | $ | 21,948 |  |  | $ | 20,364 |  |

[0000858877-15-000051:notes:32]
Revenue in the United States was $6.4 billion and $5.9 billion for the three months ended April 25, 2015 and April 26, 2014, respectively, and was $19.1 billion and $17.9 billion for the nine months ended April 25, 2015 and April 26, 2014, respectively.

[0000858877-15-000051:notes:33]
[same as prior period, unchanged from 0000858877-15-000013:notes:30]

[0000858877-15-000051:notes:34]
The Company designs, manufactures, and sells Internet Protocol (IP)-based networking and other products related to the communications and IT industry and provides services associated with these products and their use.  The Company groups its products and technologies into the following categories: Switching, NGN Routing, Collaboration, Service Provider Video, Data Center, Wireless, Security, and Other Products.  These products, primarily integrated by Cisco IOS Software, link geographically dispersed local-area networks (LANs), metropolitan-area networks (MANs), and wide-area networks (WANs).

[0000858877-15-000051:notes:35]
[same as prior period, unchanged from 0000858877-15-000013:notes:32]

[0000858877-15-000051:notes:36]
[same as prior period, unchanged from 0000858877-15-000013:notes:33]

[0000858877-15-000051:notes:37]
The majority of the Company’s assets, excluding cash and cash equivalents and investments, as of April 25, 2015 and July 26, 2014 were attributable to its U.S. operations.  The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $51.8 billion and $47.4 billion as of April 25, 2015 and July 26, 2014, respectively, and the remaining $2.6 billion and $4.7 billion at the respective period ends were available in the United States.


## csco:StockRepurchasesSinceInceptionOfProgramTableTextBlock

[0000858877-15-000051:notes:38]
[same as prior period, unchanged from 0000858877-15-000013:notes:35]

[0000858877-15-000051:notes:39]
|  | Shares ofCommonStock |  | Common Stockand AdditionalPaid-In Capital |  | RetainedEarnings |  | Total CiscoShareholders’Equity |
| Repurchases of common stock under the repurchase program | 4,408 |  |  | $ | 22,318 |  |  | $ | 69,356 |  |  | $ | 91,674 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-15-000051:notes:40]
[same as prior period, unchanged from 0000858877-15-000013:notes:37]

[0000858877-15-000051:notes:41]
|  | CREDIT LOSS ALLOWANCES |
| Three Months Ended April 25, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of January 24, 2015 | $ | 250 |  |  | $ | 85 |  |  | $ | 40 |  |  | $ | 375 |  |
| Provisions | (4 | ) |  | (5 | ) |  | (2 | ) |  | (11 | ) |
| Recoveries (write-offs), net | (1 | ) |  | — |  |  | — |  |  | (1 | ) |
| Foreign exchange and other | (3 | ) |  | — |  |  | (1 | ) |  | (4 | ) |
| Allowance for credit loss as of April 25, 2015 | $ | 242 |  |  | $ | 80 |  |  | $ | 37 |  |  | $ | 359 |  |
| Financing receivables as of April 25, 2015 (1) | $ | 3,312 |  |  | $ | 1,720 |  |  | $ | 3,081 |  |  | $ | 8,113 |  |

[0000858877-15-000051:notes:42]
|  | CREDIT LOSS ALLOWANCES |
| Nine Months Ended April 25, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 26, 2014 | $ | 233 |  |  | $ | 98 |  |  | $ | 18 |  |  | $ | 349 |  |
| Provisions | 25 |  |  | (15 | ) |  | 21 |  |  | 31 |  |
| Recoveries (write-offs), net | (6 | ) |  | 1 |  |  | — |  |  | (5 | ) |
| Foreign exchange and other | (10 | ) |  | (4 | ) |  | (2 | ) |  | (16 | ) |
| Allowance for credit loss as of April 25, 2015 | $ | 242 |  |  | $ | 80 |  |  | $ | 37 |  |  | $ | 359 |  |

[0000858877-15-000051:notes:43]
|  | CREDIT LOSS ALLOWANCES |
| Three Months Ended April 26, 2014 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of January 25, 2014 | $ | 254 |  |  | $ | 98 |  |  | $ | 22 |  |  | $ | 374 |  |
| Provisions | (6 | ) |  | (10 | ) |  | (2 | ) |  | (18 | ) |
| Recoveries (write-offs), net | (1 | ) |  | 4 |  |  | (1 | ) |  | 2 |  |
| Foreign exchange and other | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Allowance for credit loss as of April 26, 2014 | $ | 249 |  |  | $ | 92 |  |  | $ | 19 |  |  | $ | 360 |  |
| Financing receivables as of April 26, 2014 (1) | $ | 3,537 |  |  | $ | 1,621 |  |  | $ | 2,810 |  |  | $ | 7,968 |  |

[0000858877-15-000051:notes:44]
|  | CREDIT LOSS ALLOWANCES |
| Nine Months Ended April 26, 2014 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 27, 2013 | $ | 238 |  |  | $ | 86 |  |  | $ | 20 |  |  | $ | 344 |  |
| Provisions | 9 |  |  | 5 |  |  | — |  |  | 14 |  |
| Recoveries (write-offs), net | — |  |  | 4 |  |  | (1 | ) |  | 3 |  |
| Foreign exchange and other | 2 |  |  | (3 | ) |  | — |  |  | (1 | ) |
| Allowance for credit loss as of April 26, 2014 | $ | 249 |  |  | $ | 92 |  |  | $ | 19 |  |  | $ | 360 |  |

[0000858877-15-000051:notes:45]
[same as prior period, unchanged from 0000858877-15-000013:notes:42]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-15-000051:notes:46]
[same as prior period, unchanged from 0000858877-15-000013:notes:43]

[0000858877-15-000051:notes:47]
The Company completed four business combinations during the nine months ended April 25, 2015.  A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-15-000051:notes:48]
|  | Purchase Consideration |  | Net Liabilities Assumed |  | Purchased Intangible Assets |  | Goodwill |
| Metacloud, Inc. | $ | 149 |  |  | $ | (7 | ) |  | $ | 29 |  |  | $ | 127 |  |
| All others (three in total) | 93 |  |  | (10 | ) |  | 46 |  |  | 57 |  |
| Total | $ | 242 |  |  | $ | (17 | ) |  | $ | 75 |  |  | $ | 184 |  |

[0000858877-15-000051:notes:49]
On September 29, 2014, the Company completed its acquisition of Metacloud, Inc. ("Metacloud"), a provider of private clouds for global organizations.  With its acquisition of Metacloud, the Company aims to advance its Intercloud strategy to deliver a globally distributed, highly secure cloud platform capable of meeting customer demands.  Revenue from the Metacloud acquisition has been included in the Company's Service category.

[0000858877-15-000051:notes:50]
The total purchase consideration related to the Company’s business combinations completed during the nine months ended April 25, 2015 consisted of cash consideration and vested share-based awards assumed.  The total cash and cash equivalents acquired from these business combinations was approximately $5 million.  Total transaction costs related to the Company’s business combination activities were $5 million and $7 million for the nine months ended April 25, 2015 and April 26, 2014, respectively.  These transaction costs were expensed as incurred in general and administrative expenses ("G&A") in the Consolidated Statements of Operations.

[0000858877-15-000051:notes:51]
The Company’s purchase price allocation for business combinations completed during recent periods is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available.  Additional information, that existed as of the acquisition date but at that time was unknown to the Company may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date.  Adjustments in the purchase price allocation may require a recasting of the amounts allocated to goodwill retroactive to the period in which the acquisition occurred.

[0000858877-15-000051:notes:52]
The goodwill generated from the Company’s business combinations completed during the nine months ended April 25, 2015 is primarily related to expected synergies.  The goodwill is generally not deductible for income tax purposes.

[0000858877-15-000051:notes:53]
The Consolidated Financial Statements include the operating results of each business combination from the date of acquisition.  Pro forma results of operations for the acquisitions completed during the nine months ended April 25, 2015 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-15-000051:notes:54]
| 12. | Commitments and Contingencies |

[0000858877-15-000051:notes:55]
| (a) | Operating Leases |

[0000858877-15-000051:notes:56]
The Company leases office space in many U.S. locations.  Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Norway, and the United Kingdom.  The Company also leases equipment and vehicles.  Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 25, 2015 are as follows (in millions):

[0000858877-15-000051:notes:57]
| Fiscal Year | Amount |
| 2015 (remaining three months) | $ | 97 |  |
| 2016 | 304 |  |
| 2017 | 210 |  |
| 2018 | 153 |  |
| 2019 | 85 |  |
| Thereafter | 228 |  |
| Total | $ | 1,077 |  |

[0000858877-15-000051:notes:58]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-15-000051:notes:59]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products.  During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that allow them to either procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments.  In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of April 25, 2015 and July 26, 2014, the Company had total purchase commitments for inventory of $4,495 million and $4,169 million, respectively.

[0000858877-15-000051:notes:60]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory.  As of April 25, 2015 and July 26, 2014, the liability for these purchase commitments was $153 million and $162 million, respectively, and was included in other current liabilities.

[0000858877-15-000051:notes:61]
| (c) | Other Commitments |

[0000858877-15-000051:notes:62]
In connection with the Company’s business combinations, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-15-000051:notes:63]
As of April 25, 2015, the Company estimated that future cash compensation expense of up to $366 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc., as more fully discussed immediately below.

[0000858877-15-000051:notes:64]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme Networks, Inc. ("Insieme"), an early stage company focused on research and development in the data center market.  As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology.  Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements.  In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

[0000858877-15-000051:notes:65]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  The Company recorded compensation expense of $51 million and $52 million during the three months ended April 25, 2015 and April 26, 2014, respectively, and $155 million and $363 million during the nine months ended April 25, 2015 and April 26, 2014, respectively, related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $843 million (which includes the $571 million that has been expensed to date), net of forfeitures.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.

[0000858877-15-000051:notes:66]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand.  The funding commitments were $247 million and $255 million as of April 25, 2015 and July 26, 2014, respectively.

[0000858877-15-000051:notes:67]
| (d) | Product Warranties |

[0000858877-15-000051:notes:68]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-15-000051:notes:69]
|  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |
| Balance at beginning of period | $ | 446 |  |  | $ | 402 |  |
| Provision for warranties issued | 517 |  |  | 532 |  |
| Payments | (512 | ) |  | (504 | ) |
| Balance at end of period | $ | 451 |  |  | $ | 430 |  |

[0000858877-15-000051:notes:70]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead.  The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-15-000051:notes:71]
| (e) | Financing and Other Guarantees |

[0000858877-15-000051:notes:72]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers.  Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-15-000051:notes:73]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days.  These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements.  The volume of channel partner financing was $6.3 billion and $5.8 billion for the three months ended April 25, 2015 and April 26, 2014, respectively.  The volume of channel partner financing was $19.0 billion and $17.9 billion for the nine months ended April 25, 2015 and April 26, 2014, respectively.  The balance of the channel partner financing subject to guarantees was $1.2 billion as of each April 25, 2015 and July 26, 2014.

[0000858877-15-000051:notes:74]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years.  The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $22 million and $44 million for the three months ended April 25, 2015 and April 26, 2014, respectively, and was $87 million and $89 million for the nine months ended April 25, 2015 and April 26, 2014, respectively.

[0000858877-15-000051:notes:75]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 25, 2015 and July 26, 2014, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-15-000051:notes:76]
|  | April 25, 2015 |  | July 26, 2014 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 299 |  |  | $ | 263 |  |
| End user | 138 |  |  | 202 |  |
| Total | $ | 437 |  |  | $ | 465 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (122 | ) |  | $ | (127 | ) |
| End user | (113 | ) |  | (166 | ) |
| Total | $ | (235 | ) |  | $ | (293 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 202 |  |  | $ | 172 |  |

[0000858877-15-000051:notes:77]
Other Guarantees   The Company’s other guarantee arrangements as of April 25, 2015 and July 26, 2014 that were subject to recognition and disclosure requirements were not material.

[0000858877-15-000051:notes:78]
| (f) | Supplier Component Remediation Liability |

[0000858877-15-000051:notes:79]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010.  These components are widely used across the industry and are included in a number of the Company's products.  Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low.  However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem.  Although the majority of these products are beyond the Company's warranty terms, the Company is proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  During the third quarter of fiscal 2015, an adjustment of $164 million  was recorded, which was a reduction to the liability to reflect net lower than estimated future costs to remediate the impacted customer products.  The supplier component remediation liability as of April 25, 2015 and July 26, 2014 was $426 million and $670 million, respectively.

[0000858877-15-000051:notes:80]
| (g) | Indemnifications |

[0000858877-15-000051:notes:81]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters.  The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties.  These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-15-000051:notes:82]
The Company has an obligation to indemnify certain expenses pursuant to such an agreement in, among other cases, a case involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) in the U.S. District Court for the District of Kansas filed on December 19, 2011 (including one case that was later transferred to the District of Delaware).  Sprint alleges that the service providers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers.  Sprint is seeking monetary damages.  Trial dates have been set for the first half of calendar year 2016 in the case proceeding in the District of Kansas.  The trial in Delaware is scheduled for February 2017.  The parties conducted mediations, and the Company participated through a mediation involving a service provider customer.  Those particular mediations did not resolve the parties’ disputes, but the parties plan to engage in additional dispute resolution efforts, including participation by the Company.  The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims and/or that the patents are invalid.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should the plaintiff prevail in litigation, mediation, or settlement, the Company, in accordance with its agreement, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

[0000858877-15-000051:notes:83]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-15-000051:notes:84]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement.  Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-15-000051:notes:85]
| (h) | Legal Proceedings |

[0000858877-15-000051:notes:86]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer.  Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties.  In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.  In the first quarter of fiscal 2013, the Brazilian federal tax authorities asserted an additional claim against the Company’s Brazilian subsidiary based on a theory of joint liability with respect to an alleged underpayment of income taxes, social taxes, interest, and penalties by a Brazilian distributor.

[0000858877-15-000051:notes:87]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007.  The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $291 million for the alleged evasion of import and other taxes, approximately $1.1 billion for interest, and approximately $1.3 billion for various penalties, all determined using an exchange rate as of April 25, 2015.  The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously.  While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any.  The Company does not expect a final judicial determination for several years.

[0000858877-15-000051:notes:88]
Russia and the Commonwealth of Independent States    At the request of the U.S. Securities and Exchange Commission (SEC) and the U.S. Department of Justice, the Company is conducting an investigation into allegations which the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries.  The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the SEC and the Department of Justice.  While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.  The countries that are the subject of the investigation collectively comprise less than 2% of the Company’s revenues.

[0000858877-15-000051:notes:89]
Rockstar    The Company and some of its service provider customers were subject to patent claims asserted in December 2013 in the Eastern District of Texas and the District of Delaware by subsidiaries of the Rockstar Consortium (“Rockstar”).  Rockstar, whose members include Apple, Microsoft, LM Ericsson, Sony, and Blackberry, had purchased a portfolio of patents out of the Nortel Networks’ bankruptcy proceedings (the “Nortel Portfolio”).  In connection with this matter, during the first quarter of fiscal 2015 the Company recorded a charge to product cost of sales of $188 million.

[0000858877-15-000051:notes:90]
In December 2014, RPX Corporation (“RPX”) and Rockstar entered into an agreement, which closed on January 28, 2015, resulting in over 30 technology companies, including the Company and the various service provider customers described above, obtaining a license to the patents owned by Rockstar.  The Company paid approximately $300 million in connection with this transaction, with the payment recorded against the amount previously reserved and as an intangible asset to be amortized over its estimated useful life.  In connection with the closing of the transaction, Rockstar dismissed all litigation it had brought against the participating companies.

[0000858877-15-000051:notes:91]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation.  While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-15-000051:notes:92]
[same as prior period, unchanged from 0000858877-15-000013:notes:89]

[0000858877-15-000051:notes:93]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, for the nine months ended April 25, 2015 and April 26, 2014 are summarized as follows (in millions):

[0000858877-15-000051:notes:94]
|  | Net Unrealized Gains on Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income |
| BALANCE AT JULY 26, 2014 | $ | 424 |  |  | $ | (12 | ) |  | $ | 265 |  |  | $ | 677 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 111 |  |  | (163 | ) |  | (473 | ) |  | (525 | ) |
| (Gains) losses reclassified out of AOCI | (120 | ) |  | 94 |  |  | — |  |  | (26 | ) |
| Tax benefit (expense) | 8 |  |  | 3 |  |  | 50 |  |  | 61 |  |
| BALANCE AT APRIL 25, 2015 | $ | 423 |  |  | $ | (78 | ) |  | $ | (158 | ) |  | $ | 187 |  |

[0000858877-15-000051:notes:95]
|  | Net Unrealized Gains on Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income |
| BALANCE AT JULY 27, 2013 | $ | 379 |  |  | $ | 8 |  |  | $ | 221 |  |  | $ | 608 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 339 |  |  | 46 |  |  | 32 |  |  | 417 |  |
| (Gains) losses reclassified out of AOCI | (234 | ) |  | (44 | ) |  | — |  |  | (278 | ) |
| Tax benefit (expense) | (43 | ) |  | (2 | ) |  | (5 | ) |  | (50 | ) |
| BALANCE AT APRIL 26, 2014 | $ | 441 |  |  | $ | 8 |  |  | $ | 248 |  |  | $ | 697 |  |

[0000858877-15-000051:notes:96]
[same as prior period, unchanged from 0000858877-15-000013:notes:93]

[0000858877-15-000051:notes:97]
|  |  | Three Months Ended |  | Nine Months Ended |  |  |
|  |  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains on available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |
|  |  | $ | 44 |  |  | $ | 69 |  |  | $ | 120 |  |  | $ | 234 |  |  | Other income (loss), net |
| Net unrealized gains and (losses) on cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | (50 | ) |  | 13 |  |  | (74 | ) |  | 36 |  |  | Operating expenses |
| Foreign currency derivatives |  | (14 | ) |  | 3 |  |  | (20 | ) |  | 8 |  |  | Cost of sales—service |
|  |  | (64 | ) |  | 16 |  |  | (94 | ) |  | 44 |  |  |  |
| Total amounts reclassified out of AOCI |  | $ | (20 | ) |  | $ | 85 |  |  | $ | 26 |  |  | $ | 278 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-15-000051:notes:98]
| 10. | Borrowings |

[0000858877-15-000051:notes:99]
| (a) | Short-Term Debt |

[0000858877-15-000051:notes:100]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-15-000051:notes:101]
|  | April 25, 2015 |  | July 26, 2014 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 3,914 |  |  | 2.47 | % |  | $ | 500 |  |  | 3.11 | % |
| Commercial paper | 500 |  |  | 0.16 | % |  | — |  |  | — |  |
| Other short-term debt | 4 |  |  | 2.62 | % |  | 8 |  |  | 2.67 | % |
| Total | $ | 4,418 |  |  |  |  | $ | 508 |  |  |  |

[0000858877-15-000051:notes:102]
The effective interest rate on the current portion of long-term debt includes the impact of interest rate swaps, as discussed further in "

[0000858877-15-000051:notes:103]
| (b) | Long-Term Debt |

[0000858877-15-000051:notes:104]
."  Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements.  These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.

[0000858877-15-000051:notes:105]
On November 17, 2014, upon the maturity of the Company’s 2014 Fixed-Rate Notes (2.90%), the Company repaid an aggregate principal amount of $500 million.

[0000858877-15-000051:notes:106]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes.  The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes.  The outstanding commercial paper notes as of April 25, 2015 had original maturity dates of three months or less.

[0000858877-15-000051:notes:107]
(b)

[0000858877-15-000051:notes:108]
Long-Term Debt

[0000858877-15-000051:notes:109]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-15-000051:notes:110]
|  |  |  | April 25, 2015 |  | July 26, 2014 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | 0.41% |  | $ | 850 |  |  | 0.35% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.61% |  | 1,000 |  |  | 0.56% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.82% |  | 500 |  |  | 0.78% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | — |  |  | — |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.06% |  | 3,000 |  |  | 3.04% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.58% |  | 2,400 |  |  | 0.56% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.83% |  | 750 |  |  | 0.79% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.69% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.79% |  | 1,750 |  |  | 0.77% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.00% |  | 2,500 |  |  | 2.98% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.95% |  | 500 |  |  | 0.93% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.07% |  | 1,000 |  |  | 1.05% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 1 |  |  | 2.08% |  | 4 |  |  | 2.39% |
| Total |  |  | 20,251 |  |  |  |  | 20,754 |  |  |  |
| Unaccreted discount |  |  | (59 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 308 |  |  |  |  | 210 |  |  |  |
| Total |  |  | $ | 20,500 |  |  |  |  | $ | 20,901 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,914 |  |  |  |  | $ | 500 |  |  |  |
| Long-term debt |  |  | 16,586 |  |  |  |  | 20,401 |  |  |  |
| Total |  |  | $ | 20,500 |  |  |  |  | $ | 20,901 |  |  |  |

[0000858877-15-000051:notes:111]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps in prior periods with an aggregate notional amount of $10.4 billion designated as fair value hedges of certain of its fixed-rate senior notes.  In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR).  The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.  For additional information, see Note 11.

[0000858877-15-000051:notes:112]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount, and, if applicable, adjustments related to hedging.  Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes.  Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

[0000858877-15-000051:notes:113]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.”  As of April 25, 2015, the Company was in compliance with all debt covenants.

[0000858877-15-000051:notes:114]
As of April 25, 2015, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-15-000051:notes:115]
| Fiscal Year | Amount |
| 2015 (remaining three months) | $ | — |  |
| 2016 | 3,850 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| 2019 | 4,250 |  |
| Thereafter | 8,000 |  |
| Total | $ | 20,251 |  |

[0000858877-15-000051:notes:116]
| (c) | Credit Facility |

[0000858877-15-000051:notes:117]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020.  Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR or a comparable or successor rate which rate is approved by the Administrative Agent (“Eurocurrency Rate”) for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero.  The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement.

[0000858877-15-000051:notes:118]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.  The Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.

[0000858877-15-000051:notes:119]
This credit facility replaces the Company’s prior credit facility that was entered into on February 17, 2012, which was terminated in connection with its entering into the new credit facility.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-15-000051:notes:120]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 9,236 |  |  | $ | 9,640 |  |
| Product: |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  | 4,258 |  |  | 3,924 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  | 687 |  |  | 578 |  |
| Total product deferred revenue |  | 4,945 |  |  | 4,502 |  |
| Total |  | $ | 14,181 |  |  | $ | 14,142 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,371 |  |  | $ | 9,478 |  |
| Noncurrent |  | 4,810 |  |  | 4,664 |  |
| Total |  | $ | 14,181 |  |  | $ | 14,142 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-15-000051:notes:121]
[same as prior period, unchanged from 0000858877-15-000013:notes:117]

[0000858877-15-000051:notes:122]
[same as prior period, unchanged from 0000858877-15-000013:notes:118]

[0000858877-15-000051:notes:123]
The Company uses derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks.  The Company’s primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices.  The Company’s derivatives expose it to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement.  The Company does, however, seek to mitigate such risks by limiting its counterparties to major financial institutions.  In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored.  Management does not expect material losses as a result of defaults by counterparties.

[0000858877-15-000051:notes:124]
[same as prior period, unchanged from 0000858877-15-000013:notes:120]

[0000858877-15-000051:notes:125]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | April 25, 2015 |  | July 26, 2014 |  | Balance Sheet Line Item |  | April 25, 2015 |  | July 26, 2014 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 1 |  |  | $ | 7 |  |  | Other current liabilities |  | $ | 48 |  |  | $ | 6 |  |
| Interest rate derivatives | Other assets |  | 270 |  |  | 148 |  |  | Other long-term liabilities |  | — |  |  | 3 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 76 |  |  | 56 |  |
| Total |  |  | 271 |  |  | 155 |  |  |  |  | 124 |  |  | 65 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 4 |  |  | 3 |  |  | Other current liabilities |  | 7 |  |  | 2 |  |
| Equity derivatives | Other assets |  | 1 |  |  | 2 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 5 |  |  | 5 |  |  |  |  | 7 |  |  | 2 |  |
| Total |  |  | $ | 276 |  |  | $ | 160 |  |  |  |  | $ | 131 |  |  | $ | 67 |  |

[0000858877-15-000051:notes:126]
[same as prior period, unchanged from 0000858877-15-000013:notes:122]

[0000858877-15-000051:notes:127]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE THREE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THETHREE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | April 25, 2015 |  | April 26, 2014 |  | Line Item in Statements of Operations |  | April 25, 2015 |  | April 26, 2014 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (32 | ) |  | $ | 13 |  |  | Operating expenses |  | $ | (50 | ) |  | $ | 13 |  |
|  |  |  |  |  |  | Cost of sales—service |  | (14 | ) |  | 3 |  |
| Total |  | $ | (32 | ) |  | $ | 13 |  |  |  |  | $ | (64 | ) |  | $ | 16 |  |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 2 |  |  | $ | (10 | ) |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-15-000051:notes:128]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE NINE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THENINE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | April 25, 2015 |  | April 26, 2014 |  | Line Item in Statements of Operations |  | April 25, 2015 |  | April 26, 2014 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (163 | ) |  | $ | 47 |  |  | Operating expenses |  | $ | (74 | ) |  | $ | 36 |  |
|  |  |  |  |  |  | Cost of sales—service |  | (20 | ) |  | 8 |  |
| Total |  | $ | (163 | ) |  | $ | 47 |  |  |  |  | $ | (94 | ) |  | $ | 44 |  |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 46 |  |  | $ | (13 | ) |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-15-000051:notes:129]
As of April 25, 2015, the Company estimates that approximately $69 million of net derivative losses related to its cash flow hedges included in accumulated other comprehensive income (AOCI) will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-15-000051:notes:130]
[same as prior period, unchanged from 0000858877-15-000013:notes:126]

[0000858877-15-000051:notes:131]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES) FOR THENINE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (56 | ) |  | $ | 36 |  |  | $ | (165 | ) |  | $ | 16 |  |
| Total return swaps—deferred compensation |  | Operating expenses |  | 23 |  |  | 4 |  |  | 23 |  |  | 33 |  |
| Equity derivatives |  | Other income (loss), net |  | 6 |  |  | 9 |  |  | 10 |  |  | 33 |  |
| Total |  |  |  | $ | (27 | ) |  | $ | 49 |  |  | $ | (132 | ) |  | $ | 82 |  |

[0000858877-15-000051:notes:132]
[same as prior period, unchanged from 0000858877-15-000013:notes:128]

[0000858877-15-000051:notes:133]
|  | April 25, 2015 |  | July 26, 2014 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 654 |  |  | $ | 1,618 |  |
| Interest rate derivatives | 10,400 |  |  | 10,400 |  |
| Net investment hedging instruments | 188 |  |  | 345 |  |
| Equity derivatives | 238 |  |  | 238 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,187 |  |  | 2,528 |  |
| Total return swaps—deferred compensation | 473 |  |  | 428 |  |
| Total | $ | 14,140 |  |  | $ | 15,557 |  |

[0000858877-15-000051:notes:134]
[same as prior period, unchanged from 0000858877-15-000013:notes:130]

[0000858877-15-000051:notes:135]
The Company presents its derivative instruments at gross fair values in the Consolidated Balance Sheets.  However, the Company’s master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty.  To further limit credit risk, the Company also enters into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument.  Information related to these offsetting arrangements is summarized as follows (in millions):

[0000858877-15-000051:notes:136]
|  | April 25, 2015 |
|  | Gross Amounts Offset in the Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 276 |  |  | $ | — |  |  | $ | 276 |  |  | $ | (59 | ) |  | $ | (159 | ) |  | $ | 58 |  |
| Derivatives liabilities | $ | 131 |  |  | $ | — |  |  | $ | 131 |  |  | $ | (59 | ) |  | $ | — |  |  | $ | 72 |  |

[0000858877-15-000051:notes:137]
|  | July 26, 2014 |
|  | Gross Amounts Offset in the Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 160 |  |  | $ | — |  |  | $ | 160 |  |  | $ | (39 | ) |  | $ | (60 | ) |  | $ | 61 |  |
| Derivatives liabilities | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |  | $ | (39 | ) |  | $ | (1 | ) |  | $ | 27 |  |

[0000858877-15-000051:notes:138]
[same as prior period, unchanged from 0000858877-15-000013:notes:136]

[0000858877-15-000051:notes:139]
The Company conducts business globally in numerous currencies.  Therefore, it is exposed to adverse movements in foreign currency exchange rates.  To limit the exposure related to foreign currency changes, the Company enters into foreign currency contracts.  The Company does not enter into such contracts for trading purposes.

[0000858877-15-000051:notes:140]
The Company hedges forecasted foreign currency transactions related to certain operating expenses and service cost of sales with currency options and forward contracts.  These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 18 months.  The Company assesses effectiveness based on changes in total fair value of the derivatives.  The effective portion of the derivative instrument’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings.  The ineffective portion, if any, of the gain or loss is reported in earnings immediately.  During the periods presented, the Company did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-15-000051:notes:141]
The Company enters into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, including long-term customer financings, investments, and payables.  These derivatives are not designated as hedging instruments.  Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of intercompany balances or other current assets, investments, or liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-15-000051:notes:142]
The Company hedges certain net investments in its foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on the Company’s net investment in those foreign subsidiaries.  These derivative instruments generally have maturities of up to six months.

[0000858877-15-000051:notes:143]
[same as prior period, unchanged from 0000858877-15-000013:notes:141]

[0000858877-15-000051:notes:144]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk.  To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges.  As of April 25, 2015 and July 26, 2014, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-15-000051:notes:145]
Interest Rate Derivatives Designated as Fair Value Hedge, Long-Term Debt   In fiscal 2014 and 2013, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due on various dates from 2017 through 2024.  In the periods prior to fiscal 2013, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in 2016 and 2017.  Under these interest rate swaps, the Company receives fixed-rate interest payments and makes interest payments based on LIBOR plus a fixed number of basis points.  The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR.  The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.  The fair value of the interest rate swaps was reflected in other assets and other long-term liabilities.

[0000858877-15-000051:notes:146]
[same as prior period, unchanged from 0000858877-15-000013:notes:144]

[0000858877-15-000051:notes:147]
The Company may hold equity securities for strategic purposes or to diversify its overall investment portfolio.  The publicly traded equity securities in the Company’s portfolio are subject to price risk.  To manage its exposure to changes in the fair value of certain equity securities, the Company has entered into equity derivatives that are designated as fair value hedges.  The changes in the value of the hedging instruments are included in other income (loss), net, and offset the change in the fair value of the underlying hedged investment.  In addition, the Company periodically enters into equity derivatives that are not designated as accounting hedges.  The changes in the fair value of these derivatives are also included in other income (loss), net.

[0000858877-15-000051:notes:148]
The Company is also exposed to variability in compensation charges related to certain deferred compensation obligations to employees.  Although not designated as accounting hedges, the Company utilizes derivatives such as total return swaps to economically hedge this exposure.

[0000858877-15-000051:notes:149]
[same as prior period, unchanged from 0000858877-15-000013:notes:147]

[0000858877-15-000051:notes:150]
For the periods presented, amounts excluded from the assessment of hedge effectiveness were not material for fair value, cash flow, and net investment hedges.  In addition, hedge ineffectiveness for fair value, cash flow, and net investment hedges was not material for any of the periods presented.

[0000858877-15-000051:notes:151]
[same as prior period, unchanged from 0000858877-15-000013:notes:149]

[0000858877-15-000051:notes:152]
[same as prior period, unchanged from 0000858877-15-000013:notes:150]

[0000858877-15-000051:notes:153]
In addition, certain derivative instruments are executed under agreements that have provisions requiring the Company and the counterparty to maintain a specified credit rating from certain credit-rating agencies.  Under such agreements, if the Company’s or the counterparty’s credit rating falls below a specified credit rating, either party has the right to request collateral on the derivatives’ net liability position.  No such derivatives were in a net liability position as of April 25, 2015.  The fair market value of such derivatives was $3 million as of July 26, 2014.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-15-000051:notes:154]
[same as prior period, unchanged from 0000858877-15-000013:notes:152]

[0000858877-15-000051:notes:155]
[same as prior period, unchanged from 0000858877-15-000013:notes:153]

[0000858877-15-000051:notes:156]
Stock Incentive Plan Program Description    As of April 25, 2015, the Company had four stock incentive plans: the 2005 Stock Incentive Plan (the “2005 Plan”); the 1996 Stock Incentive Plan (the “1996 Plan”); the Cisco Systems, Inc. SA Acquisition Long-Term Incentive Plan (the “SA Acquisition Plan”); and the Cisco Systems, Inc. WebEx Acquisition Long-Term Incentive Plan (the “WebEx Acquisition Plan”).  In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof.  Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company.  The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors.  Since the inception of the stock incentive plans, the Company has granted share-based awards to a significant percentage of its employees, and the majority has been granted to employees below the vice president level.  The Company’s primary stock incentive plans are summarized as follows:

[0000858877-15-000051:notes:157]
2005 Plan    As of April 25, 2015, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus the number of any shares underlying awards outstanding on November 15, 2007 under the 1996 Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that are forfeited or are terminated for any other reason before being exercised or settled.  If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan.  Starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-15-000051:notes:158]
Pursuant to an amendment approved by the Company’s shareholders on November 12, 2009, the number of shares available for issuance under the 2005 Plan is reduced by 1.5 shares for each share awarded as a stock grant or a stock unit, and any shares underlying awards outstanding under the 1996 Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that expire unexercised at the end of their maximum terms become available for reissuance under the 2005 Plan.  The 2005 Plan permits the granting of stock options, restricted stock, and restricted stock units (RSUs), the vesting of which may be performance-based or market-based along with the requisite service requirement, and stock appreciation rights to employees (including employee directors and officers), consultants of the Company and its subsidiaries and affiliates, and non-employee directors of the Company. Stock options and stock appreciation rights granted under the 2005 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date and prior to November 12, 2009 have an expiration date no later than nine years from the grant date.  The expiration date for stock options and stock appreciation rights granted subsequent to the amendment approved on November 12, 2009 shall be no later than 10 years from the grant date.

[0000858877-15-000051:notes:159]
The stock options will generally become exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively.  Time-based stock grants and time-based RSUs will generally vest with respect to 20% or 25% of the shares or share units covered by the grant on each of the first through fifth or fourth anniversaries of the date of the grant, respectively.  The majority of the performance-based and market-based RSUs vest at the end of the three-year requisite service period or earlier if the award recipient meets certain retirement eligibility conditions.  Other  performance-based RSUs, that are based on the achievement of financial and/or non-financial operating goals, typically vest upon the achievement of milestones (and may require subsequent service periods), with overall vesting ranging from six months to three years.  The Compensation and Management Development Committee of the Board of Directors has the discretion to use different vesting schedules.  Stock appreciation rights may be awarded in combination with stock options or stock grants, and such awards shall provide that the stock appreciation rights will not be exercisable unless the related stock options or stock grants are forfeited.  Stock grants may be awarded in combination with non-statutory stock options, and such awards may provide that the stock grants will be forfeited in the event that the related non-statutory stock options are exercised.

[0000858877-15-000051:notes:160]
1996 Plan   The 1996 Plan expired on December 31, 2006, and the Company can no longer make equity awards under the 1996 Plan.  The maximum number of shares issuable over the term of the 1996 Plan was 2.5 billion shares.  Stock options granted under the 1996 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date and expire no later than nine years from the grant date.  The stock options generally became exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively.  Certain other grants utilized a 60-month ratable vesting schedule. In addition, the Board of Directors, or other committees administering the 1996 Plan, had the discretion to use a different vesting schedule and did so from time to time.

[0000858877-15-000051:notes:161]
Acquisition Plans In connection with the Company’s acquisitions of Scientific-Atlanta, Inc. (“Scientific-Atlanta”) and WebEx Communications, Inc. (“WebEx”), the Company adopted the SA Acquisition Plan and the WebEx Acquisition Plan, respectively, each effective upon completion of the applicable acquisition.  These plans constitute assumptions, amendments, restatements, and renamings of the 2003 Long-Term Incentive Plan of Scientific-Atlanta and the WebEx Communications, Inc. Amended and Restated 2000 Stock Incentive Plan, respectively.  The plans permit the grant of stock options, stock, stock units, and stock appreciation rights to certain employees of the Company and its subsidiaries and affiliates who had been employed by Scientific-Atlanta or its subsidiaries or WebEx or its subsidiaries, as applicable.  As a result of the shareholder approval of the amendment and extension of the 2005 Plan, as of November 15, 2007, the Company will no longer make stock option grants or direct share issuances under either the SA Acquisition Plan or the WebEx Acquisition Plan.

[0000858877-15-000051:notes:162]
[same as prior period, unchanged from 0000858877-15-000013:notes:160]

[0000858877-15-000051:notes:163]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 621 million shares of the Company’s common stock have been reserved for issuance as of April 25, 2015.  Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods.  Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period.  The Purchase Plan is scheduled to terminate on January 3, 2020.  The Company issued 14 million shares under the Purchase Plan during each of the nine months ended April 25, 2015 and April 26, 2014.  As of April 25, 2015, 161 million shares were available for issuance under the Purchase Plan.

[0000858877-15-000051:notes:164]
[same as prior period, unchanged from 0000858877-15-000013:notes:162]

[0000858877-15-000051:notes:165]
[same as prior period, unchanged from 0000858877-15-000013:notes:163]

[0000858877-15-000051:notes:166]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Cost of sales—product | $ | 12 |  |  | $ | 12 |  |  | $ | 34 |  |  | $ | 34 |  |
| Cost of sales—service | 44 |  |  | 39 |  |  | 115 |  |  | 112 |  |
| Share-based compensation expense in cost of sales | 56 |  |  | 51 |  |  | 149 |  |  | 146 |  |
| Research and development | 114 |  |  | 106 |  |  | 338 |  |  | 306 |  |
| Sales and marketing | 147 |  |  | 144 |  |  | 408 |  |  | 408 |  |
| General and administrative | 50 |  |  | 52 |  |  | 151 |  |  | 153 |  |
| Restructuring and other charges | — |  |  | — |  |  | (2 | ) |  | (4 | ) |
| Share-based compensation expense in operating expenses | 311 |  |  | 302 |  |  | 895 |  |  | 863 |  |
| Total share-based compensation expense | $ | 367 |  |  | $ | 353 |  |  | $ | 1,044 |  |  | $ | 1,009 |  |
| Income tax benefit for share-based compensation | $ | 88 |  |  | $ | 86 |  |  | $ | 267 |  |  | $ | 246 |  |

[0000858877-15-000051:notes:167]
As of April 25, 2015, the total compensation cost related to unvested share-based awards not yet recognized was $2.4 billion, which is expected to be recognized over approximately 2.5 years on a weighted-average basis.

[0000858877-15-000051:notes:168]
[same as prior period, unchanged from 0000858877-15-000013:notes:166]

[0000858877-15-000051:notes:169]
[same as prior period, unchanged from 0000858877-15-000013:notes:167]

[0000858877-15-000051:notes:170]
|  | Share-BasedAwards Availablefor Grant |
| BALANCE AT JULY 27, 2013 | 228 |  |
| Restricted stock, stock units, and other share-based awards granted | (98 | ) |
| Share-based awards canceled/forfeited/expired | 36 |  |
| Additional shares reserved | 135 |  |
| Shares withheld for taxes and not issued | 6 |  |
| Other | 3 |  |
| BALANCE AT JULY 26, 2014 | 310 |  |
| Restricted stock, stock units, and other share-based awards granted | (79 | ) |
| Share-based awards canceled/forfeited/expired | 33 |  |
| Shares withheld for taxes and not issued | 23 |  |
| Other | (2 | ) |
| BALANCE AT APRIL 25, 2015 | 285 |  |

[0000858877-15-000051:notes:171]
As reflected in the preceding table, for each share awarded as restricted stock or subject to a restricted stock unit award under the 2005 Plan, an equivalent of 1.5 shares was deducted from the available share-based award balance.  For restricted stock units that were awarded with vesting contingent upon the achievement of future financial performance or market-based metrics, the maximum awards that can be achieved upon full vesting of such awards were reflected in the preceding table.

[0000858877-15-000051:notes:172]
[same as prior period, unchanged from 0000858877-15-000013:notes:170]

[0000858877-15-000051:notes:173]
[same as prior period, unchanged from 0000858877-15-000013:notes:171]

[0000858877-15-000051:notes:174]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregated FairMarket Value |
| UNVESTED BALANCE AT JULY 27, 2013 | 143 |  |  | $ | 18.80 |  |  |  |
| Granted and assumed | 72 |  |  | 20.85 |  |  |  |
| Vested | (53 | ) |  | 19.55 |  |  | $ | 1,229 |  |
| Canceled/forfeited | (13 | ) |  | 18.61 |  |  |  |
| UNVESTED BALANCE AT JULY 26, 2014 | 149 |  |  | 19.54 |  |  |  |
| Granted and assumed | 52 |  |  | 24.68 |  |  |  |
| Vested | (46 | ) |  | 19.57 |  |  | $ | 1,191 |  |
| Canceled/forfeited | (14 | ) |  | 19.91 |  |  |  |
| UNVESTED BALANCE AT APRIL 25, 2015 | 141 |  |  | $ | 21.40 |  |  |  |

[0000858877-15-000051:notes:175]
[same as prior period, unchanged from 0000858877-15-000013:notes:173]

[0000858877-15-000051:notes:176]
[same as prior period, unchanged from 0000858877-15-000013:notes:174]

[0000858877-15-000051:notes:177]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 27, 2013 | 276 |  |  | $ | 24.44 |  |
| Assumed from acquisitions | 6 |  |  | 3.60 |  |
| Exercised | (78 | ) |  | 18.30 |  |
| Canceled/forfeited/expired | (17 | ) |  | 27.53 |  |
| BALANCE AT JULY 26, 2014 | 187 |  |  | 26.03 |  |
| Assumed from acquisitions | 1 |  |  | 2.72 |  |
| Exercised | (64 | ) |  | 21.05 |  |
| Canceled/forfeited/expired | (12 | ) |  | 29.55 |  |
| BALANCE AT APRIL 25, 2015 | 112 |  |  | $ | 28.26 |  |

[0000858877-15-000051:notes:178]
The following table summarizes significant ranges of outstanding and exercisable stock options as of April 25, 2015 (in millions, except years and share prices):

[0000858877-15-000051:notes:179]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 20.00 |  | 5 |  |  | 4.6 |  | $ | 6.46 |  |  | $ | 116 |  |  | 4 |  |  | $ | 8.51 |  |  | $ | 69 |  |
| $ 20.01 – 25.00 |  | 24 |  |  | 0.6 |  | 22.99 |  |  | 140 |  |  | 24 |  |  | 22.99 |  |  | 140 |  |
| $ 25.01 – 30.00 |  | 15 |  |  | 1.3 |  | 26.79 |  |  | 33 |  |  | 15 |  |  | 26.79 |  |  | 33 |  |
| $ 30.01 – 35.00 |  | 68 |  |  | 1.3 |  | 32.16 |  |  | — |  |  | 68 |  |  | 32.16 |  |  | — |  |
| Total |  | 112 |  |  | 1.3 |  | $ | 28.26 |  |  | $ | 289 |  |  | 111 |  |  | $ | 28.68 |  |  | $ | 242 |  |

[0000858877-15-000051:notes:180]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on the Company’s closing stock price of $28.82 as of April 24, 2015, that would have been received by the option holders had those option holders exercised their stock options as of that date.  The total number of in-the-money stock options exercisable as of April 25, 2015 was 41 million. As of July 26, 2014, 183 million outstanding stock options were exercisable, and the weighted-average exercise price was $26.50.

[0000858877-15-000051:notes:181]
[same as prior period, unchanged from 0000858877-15-000013:notes:179]

[0000858877-15-000051:notes:182]
Time-based restricted stock units and performance-based restricted stock units (PRSUs) that are based on the Company’s financial performance metrics or non-financial operating goals are valued using the market value of the Company’s common stock on the date of grant, discounted for the present value of expected dividends.  On the date of grant, the Company estimated the fair value of the total shareholder return (TSR) component of the PRSUs using a Monte Carlo simulation model.  The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-15-000051:notes:183]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE RESTRICTED STOCK UNITS |
| Three Months Ended | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Number of shares granted (in millions) | 33 |  |  | 6 |  |  | 1 |  |  | 2 |  |
| Grant date fair value per share | $ | 25.31 |  |  | $ | 19.95 |  |  | $ | 25.87 |  |  | $ | 19.85 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 2.8 | % |  | 3.1 | % |  | 3.0 | % |  | 3.5 | % |
| Range of risk-free interest rates | 0.0% – 1.4% |  |  | 0.0% – 1.7% |  |  | 0.0% – 1.4% |  |  | 0.1% – 1.7% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | N/A |  |  | N/A |  |

[0000858877-15-000051:notes:184]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE RESTRICTED STOCK UNITS |
| Nine Months Ended | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Number of shares granted (in millions) | 44 |  |  | 53 |  |  | 8 |  |  | 6 |  |
| Grant date fair value per share | $ | 24.83 |  |  | $ | 20.50 |  |  | $ | 23.97 |  |  | $ | 21.73 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 2.9 | % |  | 3.1 | % |  | 3.0 | % |  | 2.7 | % |
| Range of risk-free interest rates | 0.0% – 1.8% |  |  | 0.0% – 1.7% |  |  | 0.0% – 1.8% |  |  | 0.0% – 1.7% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 14.4% – 70.0% |  |  | 17.4% – 70.5% |  |

[0000858877-15-000051:notes:185]
The PRSUs granted during the periods presented are contingent on the achievement of the Company’s financial performance metrics, its comparative market-based returns, or the achievement of financial and non-financial operating goals.  For the awards based on financial performance metrics or comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period.  Generally, the remaining 50% of the PRSUs are earned based on the Company’s TSR measured against the benchmark TSR of a peer group over the same period.  Each PRSU recipient could vest in 0% to 150% of the target shares  granted contingent on the achievement of the Company's financial performance metrics or its comparative market-based returns and 0% to 100% of the target shares granted contingent on the achievement of non-financial operating goals.


## us-gaap:EarningsPerShareTextBlock

[0000858877-15-000051:notes:186]
[same as prior period, unchanged from 0000858877-15-000013:notes:184]

[0000858877-15-000051:notes:187]
[same as prior period, unchanged from 0000858877-15-000013:notes:185]

[0000858877-15-000051:notes:188]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Net income | $ | 2,437 |  |  | $ | 2,181 |  |  | $ | 6,662 |  |  | $ | 5,606 |  |
| Weighted-average shares—basic | 5,102 |  |  | 5,143 |  |  | 5,110 |  |  | 5,271 |  |
| Effect of dilutive potential common shares | 46 |  |  | 37 |  |  | 44 |  |  | 40 |  |
| Weighted-average shares—diluted | 5,148 |  |  | 5,180 |  |  | 5,154 |  |  | 5,311 |  |
| Net income per share—basic | $ | 0.48 |  |  | $ | 0.42 |  |  | $ | 1.30 |  |  | $ | 1.06 |  |
| Net income per share—diluted | $ | 0.47 |  |  | $ | 0.42 |  |  | $ | 1.29 |  |  | $ | 1.06 |  |
| Antidilutive employee share-based awards, excluded | 75 |  |  | 240 |  |  | 156 |  |  | 331 |  |

[0000858877-15-000051:notes:189]
Employee equity share options, unvested shares, and similar equity instruments granted by the Company are treated as potential common shares outstanding in computing diluted earnings per share.  Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units.  The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method.  Under the treasury stock method, the amount the employee must pay for exercising stock options, the amount of compensation cost for future service that the Company has not yet recognized, and the amount of tax benefits that would be recorded in additional paid-in capital when the award becomes deductible are collectively assumed to be used to repurchase shares.


## us-gaap:EquityMethodInvestmentsTextBlock

[0000858877-15-000051:notes:190]
For such investments that were accounted for under the equity and cost method as of April 25, 2015 and July 26, 2014, the amounts are summarized in the following table (in millions):

[0000858877-15-000051:notes:191]
|  | April 25, 2015 |  | July 26, 2014 |
| Equity method investments | $ | 561 |  |  | $ | 630 |  |
| Cost method investments | 312 |  |  | 269 |  |
| Total | $ | 873 |  |  | $ | 899 |  |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-15-000051:notes:192]
The following table presents the Company's assets that were measured at fair value on a nonrecurring basis during the indicated periods and the related recognized gains and losses for the periods indicated (in millions):

[0000858877-15-000051:notes:193]
|  | LOSSES FOR THETHREE MONTHS ENDED |  | LOSSES FOR THENINE MONTHS ENDED |
|  | April 25,2015 |  | April 26,2014 |  | April 25,2015 |  | April 26,2014 |
| Investments in privately held companies (impaired) | $ | (17 | ) |  | $ | — |  |  | $ | (20 | ) |  | $ | (10 | ) |
| Purchased intangible assets (impaired) | (1 | ) |  | — |  |  | (57 | ) |  | — |  |
| Property held for sale—land and buildings | (5 | ) |  | — |  |  | (5 | ) |  | — |  |
| Total | $ | (23 | ) |  | $ | — |  |  | $ | (82 | ) |  | $ | (10 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-15-000051:notes:194]
[same as prior period, unchanged from 0000858877-15-000013:notes:190]

[0000858877-15-000051:notes:195]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date.  When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, the Company considers the principal or most advantageous market in which it would transact, and it also considers assumptions that market participants would use when pricing the asset or liability.

[0000858877-15-000051:notes:196]
[same as prior period, unchanged from 0000858877-15-000013:notes:192]

[0000858877-15-000051:notes:197]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value.  The standard establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value.  A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement.  The fair value hierarchy is as follows:

[0000858877-15-000051:notes:198]
[same as prior period, unchanged from 0000858877-15-000013:notes:194]

[0000858877-15-000051:notes:199]
[same as prior period, unchanged from 0000858877-15-000013:notes:195]

[0000858877-15-000051:notes:200]
[same as prior period, unchanged from 0000858877-15-000013:notes:196]

[0000858877-15-000051:notes:201]
[same as prior period, unchanged from 0000858877-15-000013:notes:197]

[0000858877-15-000051:notes:202]
Assets and liabilities measured at fair value on a recurring basis as of April 25, 2015 and July 26, 2014 were as follows (in millions):

[0000858877-15-000051:notes:203]
|  | APRIL 25, 2015FAIR VALUE MEASUREMENTS |  | JULY 26, 2014FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 2,307 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,307 |  |  | $ | 4,935 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,935 |  |
| Corporate debt securities | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 29,422 |  |  | — |  |  | 29,422 |  |  | — |  |  | 31,734 |  |  | — |  |  | 31,734 |  |
| U.S. government agency securities | — |  |  | 3,262 |  |  | — |  |  | 3,262 |  |  | — |  |  | 1,063 |  |  | — |  |  | 1,063 |  |
| Non-U.S. government and agency securities | — |  |  | 1,186 |  |  | — |  |  | 1,186 |  |  | — |  |  | 861 |  |  | — |  |  | 861 |  |
| Corporate debt securities | — |  |  | 13,394 |  |  | — |  |  | 13,394 |  |  | — |  |  | 9,159 |  |  | — |  |  | 9,159 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,362 |  |  | — |  |  | 1,362 |  |  | — |  |  | 579 |  |  | — |  |  | 579 |  |
| Publicly traded equity securities | 1,923 |  |  | — |  |  | — |  |  | 1,923 |  |  | 1,952 |  |  | — |  |  | — |  |  | 1,952 |  |
| Derivative assets | — |  |  | 275 |  |  | 1 |  |  | 276 |  |  | — |  |  | 158 |  |  | 2 |  |  | 160 |  |
| Total | $ | 4,230 |  |  | $ | 48,902 |  |  | $ | 1 |  |  | $ | 53,133 |  |  | $ | 6,887 |  |  | $ | 43,554 |  |  | $ | 2 |  |  | $ | 50,443 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 131 |  |  | $ | — |  |  | $ | 131 |  |  | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |
| Total | $ | — |  |  | $ | 131 |  |  | $ | — |  |  | $ | 131 |  |  | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |

[0000858877-15-000051:notes:204]
Level 1 publicly traded equity securities are determined by using quoted prices in active markets for identical assets.  Level 2 fixed income securities are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data.  The Company uses inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of these assets and liabilities.  The Company uses such pricing data as the primary input to make its assessments and determinations as to the ultimate valuation of its investment portfolio and has not made, during the periods presented, any material adjustments to such inputs.  The Company is ultimately responsible for the financial statements and underlying estimates.  The Company’s derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs.  The Company did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.

[0000858877-15-000051:notes:205]
[same as prior period, unchanged from 0000858877-15-000013:notes:201]

[0000858877-15-000051:notes:206]
[same as prior period, unchanged from 0000858877-15-000013:notes:202]

[0000858877-15-000051:notes:207]
These assets were measured at fair value due to events or circumstances the Company identified as having significant impact on their fair value during the respective periods.  To arrive at the valuation of these assets, the Company considers any significant changes in the financial metrics and economic variables and also uses third-party valuation reports to assist in the valuation as necessary.

[0000858877-15-000051:notes:208]
The fair value measurement of the impaired investments was classified as Level 3 because significant unobservable inputs were used in the valuation due to the absence of quoted market prices and inherent lack of liquidity.  Significant unobservable inputs, which included financial metrics of comparable private and public companies, financial condition and near-term prospects of the investees, recent  financing activities of the investees, and the investees’ capital structure as well as other economic variables, reflected the assumptions market participants would use in pricing these assets.  The impairment charges, representing the difference between the net book value and the fair value as a result of the evaluation, were recorded to other income (loss), net.  The remaining carrying value of the investments that were impaired was $4 million as of April 25, 2015.

[0000858877-15-000051:notes:209]
The fair value for purchased intangibles for which the carrying amount was not deemed to be recoverable was determined using the future discounted cash flows that the assets are expected to generate.  The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable.  See Note 4.  The remaining carrying value of the specific purchased intangible assets that were impaired was zero as of April 25, 2015.

[0000858877-15-000051:notes:210]
The fair value of property held for sale was measured with the assistance of third-party valuation models which used discounted cash flow techniques as part of their analysis.  The fair value measurement was categorized as Level 3, as significant unobservable inputs were used in the valuation report.  The impairment charges as a result of the valuations, which represented the difference between the fair value less cost to sell and the carrying amount of the assets held for sale, were included in G&A expenses.  The remaining carrying value of property held for sale was $11 million as of April 25, 2015.

[0000858877-15-000051:notes:211]
[same as prior period, unchanged from 0000858877-15-000013:notes:206]

[0000858877-15-000051:notes:212]
The carrying value of the Company’s investments in privately held companies that were accounted for under the cost method was $312 million and $269 million as of April 25, 2015 and July 26, 2014, respectively.  It was not practicable to estimate the fair value of this portfolio.

[0000858877-15-000051:notes:213]
The fair value of the Company’s short-term loan receivables and financed service contracts approximates their carrying value due to their short duration.  The aggregate carrying value of the Company’s long-term loan receivables and financed service contracts and other as of April 25, 2015 and July 26, 2014 was $1.9 billion and $2.1 billion, respectively.  The estimated fair value of the Company’s long-term loan receivables and financed service contracts and other approximates their carrying value.  The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-15-000051:notes:214]
As of April 25, 2015, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.  As of April 25, 2015, the fair value of the Company’s senior notes and other long-term debt was $22.2 billion with a carrying amount of $20.5 billion.  This compares to a fair value of $22.4 billion and a carrying amount of $20.9 billion as of July 26, 2014.  The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-15-000051:notes:215]
Gross receivables less unearned income categorized by the Company’s internal credit risk rating as of April 25, 2015 and July 26, 2014 are summarized as follows (in millions):

[0000858877-15-000051:notes:216]
|  | INTERNAL CREDIT RISK RATING |
| April 25, 2015 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,590 |  |  | $ | 1,371 |  |  | $ | 125 |  |  | $ | 3,086 |  |
| Loan receivables | 755 |  |  | 816 |  |  | 149 |  |  | 1,720 |  |
| Financed service contracts and other | 1,650 |  |  | 1,371 |  |  | 60 |  |  | 3,081 |  |
| Total | $ | 3,995 |  |  | $ | 3,558 |  |  | $ | 334 |  |  | $ | 7,887 |  |

[0000858877-15-000051:notes:217]
[same as prior period, unchanged from 0000858877-15-000013:notes:212]


## us-gaap:FinancingReceivablesTextBlock

[0000858877-15-000051:notes:218]
[same as prior period, unchanged from 0000858877-15-000013:notes:213]

[0000858877-15-000051:notes:219]
[same as prior period, unchanged from 0000858877-15-000013:notes:214]

[0000858877-15-000051:notes:220]
Financing receivables primarily consist of lease receivables, loan receivables, and financed service contracts and other.  Lease receivables represent sales-type and direct-financing leases resulting from the sale of the Company’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets.  Loan receivables represent financing arrangements related to the sale of the Company’s products and services, which may include additional funding for other costs associated with network installation and integration of the Company’s products and services.  Lease receivables consist of arrangements with terms of four years on average, while loan receivables generally have terms of up to three years.  The financed service contracts and other category includes financing receivables related to technical support and advanced services, as well as receivables related to financing of certain indirect costs associated with leases.  Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one to three years.

[0000858877-15-000051:notes:221]
[same as prior period, unchanged from 0000858877-15-000013:notes:216]

[0000858877-15-000051:notes:222]
| April 25, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Gross | $ | 3,276 |  |  | $ | 1,720 |  |  | $ | 3,081 |  |  | $ | 8,077 |  |
| Residual value | 226 |  |  | — |  |  | — |  |  | 226 |  |
| Unearned income | (190 | ) |  | — |  |  | — |  |  | (190 | ) |
| Allowance for credit loss | (242 | ) |  | (80 | ) |  | (37 | ) |  | (359 | ) |
| Total, net | $ | 3,070 |  |  | $ | 1,640 |  |  | $ | 3,044 |  |  | $ | 7,754 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,424 |  |  | $ | 820 |  |  | $ | 2,004 |  |  | $ | 4,248 |  |
| Noncurrent | 1,646 |  |  | 820 |  |  | 1,040 |  |  | 3,506 |  |
| Total, net | $ | 3,070 |  |  | $ | 1,640 |  |  | $ | 3,044 |  |  | $ | 7,754 |  |

[0000858877-15-000051:notes:223]
| July 26, 2014 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Gross | $ | 3,532 |  |  | $ | 1,683 |  |  | $ | 3,210 |  |  | $ | 8,425 |  |
| Residual value | 233 |  |  | — |  |  | — |  |  | 233 |  |
| Unearned income | (238 | ) |  | — |  |  | — |  |  | (238 | ) |
| Allowance for credit loss | (233 | ) |  | (98 | ) |  | (18 | ) |  | (349 | ) |
| Total, net | $ | 3,294 |  |  | $ | 1,585 |  |  | $ | 3,192 |  |  | $ | 8,071 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,476 |  |  | $ | 728 |  |  | $ | 1,949 |  |  | $ | 4,153 |  |
| Noncurrent | 1,818 |  |  | 857 |  |  | 1,243 |  |  | 3,918 |  |
| Total, net | $ | 3,294 |  |  | $ | 1,585 |  |  | $ | 3,192 |  |  | $ | 8,071 |  |

[0000858877-15-000051:notes:224]
As of April 25, 2015 and July 26, 2014, the deferred service revenue related to "Financed Service Contracts and Other" was $1,520 million and $1,843 million, respectively.

[0000858877-15-000051:notes:225]
Future minimum lease payments at April 25, 2015 are summarized as follows (in millions):

[0000858877-15-000051:notes:226]
| Fiscal Year | Amount |
| 2015 (remaining three months) | $ | 498 |  |
| 2016 | 1,349 |  |
| 2017 | 857 |  |
| 2018 | 406 |  |
| 2019 | 146 |  |
| Thereafter | 20 |  |
| Total | $ | 3,276 |  |

[0000858877-15-000051:notes:227]
[same as prior period, unchanged from 0000858877-15-000013:notes:222]

[0000858877-15-000051:notes:228]
[same as prior period, unchanged from 0000858877-15-000013:notes:223]

[0000858877-15-000051:notes:229]
The Company determines the adequacy of its allowance for credit loss by assessing the risks and losses inherent in its financing receivables by portfolio segment.  The portfolio segment is based on the types of financing offered by the Company to its customers, which consist of the following: lease receivables, loan receivables, and financed service contracts and other.

[0000858877-15-000051:notes:230]
The Company’s internal credit risk ratings of 1 through 4 correspond to investment-grade ratings, while credit risk ratings of 5 and 6 correspond to non-investment grade ratings.  Credit risk ratings of 7 and higher correspond to substandard ratings.

[0000858877-15-000051:notes:231]
In circumstances when collectibility is not deemed reasonably assured, the associated revenue is deferred in accordance with the Company’s revenue recognition policies, and the related allowance for credit loss, if any, is included in deferred revenue.  The Company also records deferred revenue associated with financing receivables when there are remaining performance obligations, as it does for financed service contracts.  Total allowances for credit loss and deferred revenue as of April 25, 2015 and July 26, 2014 were $1,900 million and $2,220 million, respectively, and they were associated with total financing receivables before allowance for credit loss of $8,113 million and $8,420 million as of their respective period ends.

[0000858877-15-000051:notes:232]
The following tables present the aging analysis of gross receivables less unearned income as of April 25, 2015 and July 26, 2014 (in millions):

[0000858877-15-000051:notes:233]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| April 25, 2015 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 102 |  |  | $ | 48 |  |  | $ | 138 |  |  | $ | 288 |  |  | $ | 2,798 |  |  | $ | 3,086 |  |  | $ | 38 |  |  | $ | 38 |  |
| Loan receivables | 12 |  |  | 15 |  |  | 56 |  |  | 83 |  |  | 1,637 |  |  | 1,720 |  |  | 29 |  |  | 29 |  |
| Financed service contracts and other | 99 |  |  | 88 |  |  | 309 |  |  | 496 |  |  | 2,585 |  |  | 3,081 |  |  | 32 |  |  | 12 |  |
| Total | $ | 213 |  |  | $ | 151 |  |  | $ | 503 |  |  | $ | 867 |  |  | $ | 7,020 |  |  | $ | 7,887 |  |  | $ | 99 |  |  | $ | 79 |  |

[0000858877-15-000051:notes:234]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 26, 2014 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 63 |  |  | $ | 46 |  |  | $ | 202 |  |  | $ | 311 |  |  | $ | 2,983 |  |  | $ | 3,294 |  |  | $ | 48 |  |  | $ | 41 |  |
| Loan receivables | 3 |  |  | 21 |  |  | 27 |  |  | 51 |  |  | 1,632 |  |  | 1,683 |  |  | 19 |  |  | 19 |  |
| Financed service contracts and other | 268 |  |  | 230 |  |  | 220 |  |  | 718 |  |  | 2,492 |  |  | 3,210 |  |  | 12 |  |  | 9 |  |
| Total | $ | 334 |  |  | $ | 297 |  |  | $ | 449 |  |  | $ | 1,080 |  |  | $ | 7,107 |  |  | $ | 8,187 |  |  | $ | 79 |  |  | $ | 69 |  |

[0000858877-15-000051:notes:235]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms.  The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract.  The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $361 million and $334 million as of April 25, 2015 and July 26, 2014, respectively.

[0000858877-15-000051:notes:236]
As of April 25, 2015, the Company had financing receivables of $75 million, net of unbilled or current receivables from the same contract, that were in the category of 91 days plus past due but remained on accrual status.  Such balance was $78 million as of July 26, 2014.  A financing receivable may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain.

[0000858877-15-000051:notes:237]
[same as prior period, unchanged from 0000858877-15-000013:notes:232]

[0000858877-15-000051:notes:238]
The Company assesses the allowance for credit loss related to financing receivables on either an individual or a collective basis.  The Company considers various factors in evaluating lease and loan receivables and the earned portion of financed service contracts for possible impairment on an individual basis.  These factors include the Company’s historical experience, credit quality and age of the receivable balances, and economic conditions that may affect a customer’s ability to pay.  When the evaluation indicates that it is probable that all amounts due pursuant to the contractual terms of the financing agreement, including scheduled interest payments, are unable to be collected, the financing receivable is considered impaired.  All such outstanding amounts, including any accrued interest, will be assessed and fully reserved at the customer level.  The Company’s internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality financing receivables.

[0000858877-15-000051:notes:239]
Typically, the Company also considers receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance.  These balances, as of April 25, 2015 and July 26, 2014, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-15-000051:notes:240]
[same as prior period, unchanged from 0000858877-15-000013:notes:235]

[0000858877-15-000051:notes:241]
[same as prior period, unchanged from 0000858877-15-000013:notes:236]

[0000858877-15-000051:notes:242]
[same as prior period, unchanged from 0000858877-15-000013:notes:237]

[0000858877-15-000051:notes:243]
|  | April 25, 2015 |  | July 26, 2014 |
| Operating lease assets | $ | 359 |  |  | $ | 362 |  |
| Accumulated depreciation | (195 | ) |  | (202 | ) |
| Operating lease assets, net | $ | 164 |  |  | $ | 160 |  |

[0000858877-15-000051:notes:244]
Minimum future rentals on noncancelable operating leases at April 25, 2015 were approximately $0.1 billion for the remaining three months of fiscal 2015, $0.2 billion for fiscal 2016, and less than $0.1 billion per year for each of fiscal 2017 through fiscal 2019.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-15-000051:notes:245]
[same as prior period, unchanged from 0000858877-15-000013:notes:240]

[0000858877-15-000051:notes:246]
[same as prior period, unchanged from 0000858877-15-000013:notes:241]

[0000858877-15-000051:notes:247]
The following table presents the goodwill allocated to the Company’s reportable segments as of and during the nine months ended April 25, 2015 (in millions):

[0000858877-15-000051:notes:248]
|  | Balance at July 26, 2014 |  | Acquisitions |  | Other |  | Balance at April 25, 2015 |
| Americas | $ | 15,080 |  |  | $ | 99 |  |  | $ | (13 | ) |  | $ | 15,166 |  |
| EMEA | 5,715 |  |  | 67 |  |  | (7 | ) |  | 5,775 |  |
| APJC | 3,444 |  |  | 18 |  |  | (5 | ) |  | 3,457 |  |
| Total | $ | 24,239 |  |  | $ | 184 |  |  | $ | (25 | ) |  | $ | 24,398 |  |

[0000858877-15-000051:notes:249]
[same as prior period, unchanged from 0000858877-15-000013:notes:244]

[0000858877-15-000051:notes:250]
[same as prior period, unchanged from 0000858877-15-000013:notes:245]

[0000858877-15-000051:notes:251]
[same as prior period, unchanged from 0000858877-15-000013:notes:246]

[0000858877-15-000051:notes:252]
Amortization of purchased intangible assets for the three and nine months ended April 25, 2015 included impairment charges of approximately $1 million and $57 million, respectively.  The impairment was primarily due to reductions in expected future cash flows related to certain of the Company's technology intangible assets and was recorded as amortization of purchased intangible assets.  There were no impairment charges related to purchased intangible assets during the three and nine months ended April 26, 2014.

[0000858877-15-000051:notes:253]
The estimated future amortization expense of purchased intangible assets with finite lives as of April 25, 2015 is as follows (in millions):

[0000858877-15-000051:notes:254]
| Fiscal Year | Amount |
| 2015 (remaining three months) | $ | 223 |  |
| 2016 | 763 |  |
| 2017 | 590 |  |
| 2018 | 448 |  |
| 2019 | 345 |  |
| Thereafter | 168 |  |
| Total | $ | 2,537 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-15-000051:notes:255]
[same as prior period, unchanged from 0000858877-15-000013:notes:250]

[0000858877-15-000051:notes:256]
During the nine months ended April 25, 2015, the Tax Increase Prevention Act of 2014 reinstated the U.S. federal R&D tax credit for calendar year 2014 R&D expenses.  As a result, the effective tax rate for the nine months ended April 25, 2015 reflected tax benefits related to fiscal 2015 R&D expenses and a tax benefit of $91 million related to fiscal 2014 R&D expenses.

[0000858877-15-000051:notes:257]
As of April 25, 2015, the Company had $2.0 billion of unrecognized tax benefits, of which $1.8 billion, if recognized, would favorably impact the effective tax rate.  The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions.  The Company believes it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months.  Specific positions that may be resolved include issues involving transfer pricing and various other matters.  Accordingly, the Company estimates that it is reasonably possible that the unrecognized tax benefits at April 25, 2015 could be reduced in the next 12 months by approximately $900 million, a portion of which could increase earnings.


## us-gaap:InventoryDisclosureTextBlock

[0000858877-15-000051:notes:258]
[same as prior period, unchanged from 0000858877-15-000013:notes:253]

[0000858877-15-000051:notes:259]
|  |  | April 25, 2015 |  | July 26, 2014 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 264 |  |  | $ | 77 |  |
| Work in process |  | 2 |  |  | 5 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 635 |  |  | 595 |  |
| Manufactured finished goods |  | 547 |  |  | 606 |  |
| Total finished goods |  | 1,182 |  |  | 1,201 |  |
| Service-related spares |  | 268 |  |  | 273 |  |
| Demonstration systems |  | 44 |  |  | 35 |  |
| Total |  | $ | 1,760 |  |  | $ | 1,591 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-15-000051:notes:260]
The following table summarizes the maturities of the Company’s fixed income securities at April 25, 2015 (in millions):

[0000858877-15-000051:notes:261]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 16,322 |  |  | $ | 16,332 |  |
| Due in 1 to 2 years | 14,969 |  |  | 15,006 |  |
| Due in 2 to 5 years | 15,610 |  |  | 15,697 |  |
| Due after 5 years | 1,571 |  |  | 1,591 |  |
| Total | $ | 48,472 |  |  | $ | 48,626 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-15-000051:notes:262]
| 8. | Investments |

[0000858877-15-000051:notes:263]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-15-000051:notes:264]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-15-000051:notes:265]
| April 25, 2015 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 29,364 |  |  | $ | 59 |  |  | $ | (1 | ) |  | $ | 29,422 |  |
| U.S. government agency securities | 3,257 |  |  | 6 |  |  | (1 | ) |  | 3,262 |  |
| Non-U.S. government and agency securities | 1,184 |  |  | 2 |  |  | — |  |  | 1,186 |  |
| Corporate debt securities | 13,321 |  |  | 86 |  |  | (13 | ) |  | 13,394 |  |
| U.S. agency mortgage-backed securities | 1,346 |  |  | 16 |  |  | — |  |  | 1,362 |  |
| Total fixed income securities | 48,472 |  |  | 169 |  |  | (15 | ) |  | 48,626 |  |
| Publicly traded equity securities | 1,328 |  |  | 598 |  |  | (3 | ) |  | 1,923 |  |
| Total | $ | 49,800 |  |  | $ | 767 |  |  | $ | (18 | ) |  | $ | 50,549 |  |

[0000858877-15-000051:notes:266]
| July 26, 2014 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 31,717 |  |  | $ | 29 |  |  | $ | (12 | ) |  | $ | 31,734 |  |
| U.S. government agency securities | 1,062 |  |  | 1 |  |  | — |  |  | 1,063 |  |
| Non-U.S. government and agency securities | 860 |  |  | 2 |  |  | (1 | ) |  | 861 |  |
| Corporate debt securities | 9,092 |  |  | 74 |  |  | (7 | ) |  | 9,159 |  |
| U.S. agency mortgage-backed securities | 574 |  |  | 5 |  |  | — |  |  | 579 |  |
| Total fixed income securities | 43,305 |  |  | 111 |  |  | (20 | ) |  | 43,396 |  |
| Publicly traded equity securities | 1,314 |  |  | 648 |  |  | (10 | ) |  | 1,952 |  |
| Total | $ | 44,619 |  |  | $ | 759 |  |  | $ | (30 | ) |  | $ | 45,348 |  |

[0000858877-15-000051:notes:267]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-15-000051:notes:268]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-15-000051:notes:269]
The following table presents the gross realized gains and gross realized losses related to the Company’s available-for-sale investments (in millions):

[0000858877-15-000051:notes:270]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Gross realized gains | $ | 55 |  |  | $ | 75 |  |  | $ | 168 |  |  | $ | 267 |  |
| Gross realized losses | (11 | ) |  | (6 | ) |  | (48 | ) |  | (33 | ) |
| Total | $ | 44 |  |  | $ | 69 |  |  | $ | 120 |  |  | $ | 234 |  |

[0000858877-15-000051:notes:271]
The following table presents the realized net gains (losses) related to the Company’s available-for-sale investments by security type (in millions):

[0000858877-15-000051:notes:272]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2015 |  | April 26, 2014 |  | April 25, 2015 |  | April 26, 2014 |
| Net gains on investments in publicly traded equity securities | $ | 38 |  |  | $ | 55 |  |  | $ | 94 |  |  | $ | 199 |  |
| Net gains on investments in fixed income securities | 6 |  |  | 14 |  |  | 26 |  |  | 35 |  |
| Total | $ | 44 |  |  | $ | 69 |  |  | $ | 120 |  |  | $ | 234 |  |

[0000858877-15-000051:notes:273]
There were no impairment charges on available-for-sale investments for the nine months ended April 25, 2015.  For the three months ended April 26, 2014, there were no impairment charges on available-for-sale investments.  For the nine months ended April 26, 2014, the Company had impairment charges of $11 million for publicly traded equity securities, which were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary.

[0000858877-15-000051:notes:274]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at April 25, 2015 and July 26, 2014 (in millions):

[0000858877-15-000051:notes:275]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 25, 2015 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 4,096 |  |  | $ | (1 | ) |  | $ | — |  |  | $ | — |  |  | $ | 4,096 |  |  | $ | (1 | ) |
| U.S. government agency securities | 702 |  |  | (1 | ) |  | — |  |  | — |  |  | 702 |  |  | (1 | ) |
| Corporate debt securities | 3,587 |  |  | (12 | ) |  | 157 |  |  | (1 | ) |  | 3,744 |  |  | (13 | ) |
| Total fixed income securities | 8,385 |  |  | (14 | ) |  | 157 |  |  | (1 | ) |  | 8,542 |  |  | (15 | ) |
| Publicly traded equity securities | 42 |  |  | (3 | ) |  | 1 |  |  | — |  |  | 43 |  |  | (3 | ) |
| Total | $ | 8,427 |  |  | $ | (17 | ) |  | $ | 158 |  |  | $ | (1 | ) |  | $ | 8,585 |  |  | $ | (18 | ) |

[0000858877-15-000051:notes:276]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 26, 2014 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 7,676 |  |  | $ | (12 | ) |  | $ | 45 |  |  | $ | — |  |  | $ | 7,721 |  |  | $ | (12 | ) |
| Non-U.S. government and agency securities | 361 |  |  | (1 | ) |  | 22 |  |  | — |  |  | 383 |  |  | (1 | ) |
| Corporate debt securities | 1,875 |  |  | (3 | ) |  | 491 |  |  | (4 | ) |  | 2,366 |  |  | (7 | ) |
| Total fixed income securities | 9,912 |  |  | (16 | ) |  | 558 |  |  | (4 | ) |  | 10,470 |  |  | (20 | ) |
| Publicly traded equity securities | 132 |  |  | (10 | ) |  | — |  |  | — |  |  | 132 |  |  | (10 | ) |
| Total | $ | 10,044 |  |  | $ | (26 | ) |  | $ | 558 |  |  | $ | (4 | ) |  | $ | 10,602 |  |  | $ | (30 | ) |

[0000858877-15-000051:notes:277]
As of April 25, 2015, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis.  In addition, as of April 25, 2015, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the nine months ended April 25, 2015.

[0000858877-15-000051:notes:278]
The Company has evaluated its publicly traded equity securities as of April 25, 2015 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses.  This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-15-000051:notes:279]
| (c) | Maturities of Fixed Income Securities |

[0000858877-15-000051:notes:280]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.  The remaining contractual principal maturities for mortgage-backed securities were allocated assuming no prepayments.

[0000858877-15-000051:notes:281]
| (d) | Securities Lending |

[0000858877-15-000051:notes:282]
The Company periodically engages in securities lending activities with certain of its investments.  These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis.  The average daily balance of securities lending for the nine months ended April 25, 2015 and April 26, 2014 was $0.5 billion and $1.4 billion, respectively.  The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets.  The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses.  The Company did not experience any losses in connection with the secured lending of securities during the periods presented.  As of April 25, 2015 and July 26, 2014, the Company had no outstanding securities lending transactions.

[0000858877-15-000051:notes:283]
| (e) | Investments in Privately Held Companies |

[0000858877-15-000051:notes:284]
The carrying value of the Company’s investments in privately held companies was included in other assets.  For such investments that were accounted for under the equity and cost method as of April 25, 2015 and July 26, 2014, the amounts are summarized in the following table (in millions):

[0000858877-15-000051:notes:285]
Variable Interest Entities

[0000858877-15-000051:notes:286]
VCE Joint Venture  VCE is a joint venture formed in fiscal 2010 between the Company and EMC Corporation (“EMC”), with investments from VMware, Inc. (“VMware”) and Intel Capital Corporation ("Intel").  In October 2014, the Company, EMC, VMware, and Intel agreed to restructure VCE, and this transaction was completed in the second quarter of fiscal 2015.  Prior to the restructuring, the Company’s cumulative gross investment in VCE was approximately $716 million inclusive of convertible notes and accrued interest on convertible notes.  The Company recorded cumulative losses from VCE under the equity method of $691 million since inception.  The Company ceased accounting for the VCE investment under the equity method in October 2014 and recorded no losses during the three months ended April 25, 2015, compared with losses of $52 million recorded for the three months ended April 26, 2014, and losses of $47 million and $163 million were recorded for the nine months ended April 25, 2015 and April 26, 2014, respectively.  Under the terms of the restructuring, VCE paid $152 million to the Company for a portion of the outstanding principal balance of the convertible notes held by it and accrued interest on such notes, and the remaining principal balance of other such notes, and the accrued interest thereon, was cancelled.  Pursuant to the restructuring, VCE also redeemed a portion of the Company’s equity interest in VCE, reducing the Company’s ownership interest in VCE from 35% prior to the restructuring to 10%.  In connection with this transaction, the Company has written this investment down to a book value of zero and has recognized a gain of $126 million for the nine months ended April 25, 2015.

[0000858877-15-000051:notes:287]
Other Variable Interest Entities    In the ordinary course of business, the Company has investments in other privately held companies and provides financing to certain customers.  These other privately held companies and customers may be considered to be variable interest entities.  The Company evaluates on an ongoing basis its investments in these other privately held companies and its customer financings and has determined that as of April 25, 2015 there were no other variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-15-000051:notes:288]
[same as prior period, unchanged from 0000858877-15-000013:notes:283]

[0000858877-15-000051:notes:289]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2015 and fiscal 2014 are each 52-week fiscal years.  The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries.  All intercompany accounts and transactions have been eliminated.  The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-15-000051:notes:290]
The accompanying financial data as of April 25, 2015 and for the three and nine months ended April 25, 2015 and April 26, 2014 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations.  The July 26, 2014 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States.  However, the Company believes that the disclosures are adequate to make the information presented not misleading.  These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 26, 2014.

[0000858877-15-000051:notes:291]
[same as prior period, unchanged from 0000858877-15-000013:notes:286]

[0000858877-15-000051:notes:292]
In the opinion of management, all adjustments (which include normal recurring adjustments, except as disclosed herein) necessary to present fairly the consolidated balance sheet as of April 25, 2015; the results of operations and statements of comprehensive income for the three and nine months ended April 25, 2015 and April 26, 2014; and the statements of cash flows and equity for the nine months ended April 25, 2015 and April 26, 2014, as applicable, have been made.  The results of operations for the three and nine months ended April 25, 2015 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-15-000051:notes:293]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000858877-15-000051:notes:294]
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 1,437 |  |  | $ | 1,700 |  |
| Investments in privately held companies |  | 873 |  |  | 899 |  |
| Other |  | 765 |  |  | 732 |  |
| Total |  | $ | 3,075 |  |  | $ | 3,331 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-15-000051:notes:295]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,465 |  |  | $ | 4,468 |  |
| Computer equipment and related software |  | 1,344 |  |  | 1,425 |  |
| Production, engineering, and other equipment |  | 5,795 |  |  | 5,756 |  |
| Operating lease assets |  | 359 |  |  | 362 |  |
| Furniture and fixtures |  | 498 |  |  | 509 |  |
| Total gross property and equipment |  | 12,461 |  |  | 12,520 |  |
| Less: accumulated depreciation and amortization |  | (9,185 | ) |  | (9,268 | ) |
| Total |  | $ | 3,276 |  |  | $ | 3,252 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-15-000051:notes:296]
[same as prior period, unchanged from 0000858877-15-000013:notes:291]

[0000858877-15-000051:notes:297]
[same as prior period, unchanged from 0000858877-15-000013:notes:292]

[0000858877-15-000051:notes:298]
In connection with a restructuring action announced in August 2014 ("Fiscal 2015 Plan"), the Company incurred charges of $24 million and $411 million for the three and nine months ended April 25, 2015, respectively.  The Company estimates that it will recognize aggregate pre-tax charges pursuant to the restructuring action in an amount not expected to exceed $600 million, consisting of severance and other one-time termination benefits and other associated costs.  These charges are primarily cash-based and the Company expects the remaining amount to be recognized during the remainder of fiscal 2015.

[0000858877-15-000051:notes:299]
[same as prior period, unchanged from 0000858877-15-000013:notes:294]

[0000858877-15-000051:notes:300]
In connection with a restructuring action announced in August 2013 ("Fiscal 2014 Plan"), the Company incurred cumulative charges of approximately $418 million, of which $26 million and $336 million were incurred during the three and nine months ended April 26, 2014, respectively.  The Company completed the Fiscal 2014 Plan at the end of fiscal 2014.

[0000858877-15-000051:notes:301]
[same as prior period, unchanged from 0000858877-15-000013:notes:296]

[0000858877-15-000051:notes:302]
|  |  | Fiscal 2014 and Prior Plans |  | Fiscal 2015 Plan |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 26, 2014 |  | $ | 40 |  |  | $ | 29 |  |  | $ | — |  |  | $ | — |  |  | $ | 69 |  |
| Gross charges in fiscal 2015 |  | — |  |  | — |  |  | 405 |  |  | 6 |  |  | 411 |  |
| Cash payments |  | (26 | ) |  | (10 | ) |  | (381 | ) |  | (3 | ) |  | (420 | ) |
| Non-cash items |  | — |  |  | — |  |  | (2 | ) |  | 4 |  |  | 2 |  |
| Liability as of April 25, 2015 |  | $ | 14 |  |  | $ | 19 |  |  | $ | 22 |  |  | $ | 7 |  |  | $ | 62 |  |


## us-gaap:ScheduleOfNewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000858877-15-000051:notes:303]
New Accounting Updates Recently Adopted

[0000858877-15-000051:notes:304]
In March 2013, the Financial Accounting Standards Board (FASB) issued an accounting standard update requiring an entity to release into net income the entire amount of a cumulative translation adjustment related to its investment in a foreign entity when as a parent it sells either a part or all of its investment in the foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within the foreign entity.  This accounting standard update became effective for the Company beginning in the first quarter of fiscal 2015.  The application of this accounting standard update did not have any impact to the Company's Consolidated Financial Statements.

[0000858877-15-000051:notes:305]
In July 2013, the FASB issued an accounting standard update that provides explicit guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists.  Under the new standard update, an unrecognized tax benefit, or a portion of an unrecognized tax benefit, is to be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward or a tax credit carryforward.  This accounting standard update became effective for the Company beginning in the first quarter of fiscal 2015 and applied prospectively.  The application of this accounting standard update did not have a material impact to the Company's Consolidated Financial Statements.

[0000858877-15-000051:notes:306]
In April 2014, the FASB issued an accounting standard update that changes the criteria for reporting discontinued operations.  This accounting standard update raises the threshold for a disposal transaction to qualify as a discontinued operation and requires additional disclosures about discontinued operations and disposals of individually significant components that do not qualify as discontinued operations.  The Company adopted this accounting standard update in the second quarter of fiscal 2015, and it did not have any impact upon adoption.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-15-000051:notes:307]
[same as prior period, unchanged from 0000858877-15-000013:notes:302]

[0000858877-15-000051:notes:308]
[same as prior period, unchanged from 0000858877-15-000013:notes:303]

[0000858877-15-000051:notes:309]
[same as prior period, unchanged from 0000858877-15-000013:notes:304]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-15-000051:notes:310]
[same as prior period, unchanged from 0000858877-15-000013:notes:305]

[0000858877-15-000051:notes:311]
[same as prior period, unchanged from 0000858877-15-000013:notes:306]

[0000858877-15-000051:notes:312]
During the nine months ended April 25, 2015, the Company declared and paid cash dividends of $0.59 per common share, or $3.0 billion, on the Company’s outstanding common stock.  During the nine months ended April 26, 2014, the Company declared and paid cash dividends of $0.53 per common share, or $2.8 billion, on the Company’s outstanding common stock.

[0000858877-15-000051:notes:313]
Any future dividends will be subject to the approval of the Company's Board of Directors.

[0000858877-15-000051:notes:314]
[same as prior period, unchanged from 0000858877-15-000013:notes:309]

[0000858877-15-000051:notes:315]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program.  As of April 25, 2015, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program, and the remaining authorized repurchase amount was $5.3 billion, with no termination date.  A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-15-000051:notes:316]
The purchase price for the shares of the Company’s stock repurchased is reflected as a reduction to shareholders’ equity.  The Company is required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings and (ii) a reduction of common stock and additional paid-in capital.  Issuance of common stock and the tax benefit related to employee stock incentive plans are recorded as an increase to common stock and additional paid-in capital.

[0000858877-15-000051:notes:317]
[same as prior period, unchanged from 0000858877-15-000013:notes:312]

[0000858877-15-000051:notes:318]
For the nine months ended April 25, 2015 and April 26, 2014, the Company repurchased approximately 17 million and 14 million shares, or $415 million and $345 million, of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-15-000051:notes:319]
[same as prior period, unchanged from 0000858877-15-000013:notes:314]


## us-gaap:TreasuryStockTextBlock

[0000858877-15-000051:notes:320]
[same as prior period, unchanged from 0000858877-15-000013:notes:315]

[0000858877-15-000051:notes:321]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of April 25, 2015, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program with no termination date. The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):
