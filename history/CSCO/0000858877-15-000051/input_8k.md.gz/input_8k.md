# CSCO 8-K — 0001193125-15-185905 filed 2015-05-13

## item codes, every 8-K on or before 2015-05-20

- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2015-05-20

- none on or before 2015-05-20

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-185905:8k_2_02:1]
EX-99.1
2
d925318dex991.htm
EX-99.1

[0001193125-15-185905:8k_2_02:2]
EX-99.1

[0001193125-15-185905:8k_2_02:3]
Exhibit 99.1

[0001193125-15-185905:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Jenkins-Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 853-9848 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-15-185905:8k_2_02:5]
CISCO REPORTS THIRD QUARTER EARNINGS

[0001193125-15-185905:8k_2_02:6]
Strong Execution Drives Business Momentum and Return for Shareholders

[0001193125-15-185905:8k_2_02:7]
|  | • |  | Q3 Revenue: $12.1 billion (increase of 5% year over year) |

[0001193125-15-185905:8k_2_02:8]
|  | • |  | Q3 Earnings per Share: $0.47 GAAP; $0.54 non-GAAP |

[0001193125-15-185905:8k_2_02:9]
SAN JOSE, Calif. — May 13, 2015 —
Cisco, the worldwide leader in networking that transforms how people connect, communicate and collaborate, today reported its third quarter results for the period ended April 25, 2015. Cisco reported third quarter revenue of $12.1 billion, net
income on a generally accepted accounting principles (GAAP) basis of $2.4 billion or $0.47 per share, and non-GAAP net income of $2.8 billion or $0.54 per share.

[0001193125-15-185905:8k_2_02:10]
“Cisco is in a very strong position and we delivered another solid quarter. Our vision and strategy are working and we are executing very well in a tough
environment, as evidenced in our revenue growth, profitability, strong gross margins and cash generation. Our customers feel the pace of change and disruption in every industry and market, and know their success depends on digitizing their business.
Whether they are the disruptor or the incumbent, they are coming to Cisco as their strategic partner. We believe we are pulling away from our competition using the same formula we’ve always used: integrating our industry-leading products in
every category into architectures and solutions that deliver real outcomes. We’ve created this opportunity and it is ours to execute,” stated John Chambers, Cisco chairman and CEO.

[0001193125-15-185905:8k_2_02:11]
“I am extremely honored and proud to have led Cisco for the last 20 years and to get us to this positive inflection point. We have a tremendous
opportunity to extend our lead in the industry, and with Chuck Robbins as the CEO for Cisco’s next chapter, we have exactly the right leader to capture that opportunity. I could not be more confident in our future.”

[0001193125-15-185905:8k_2_02:12]
GAAP Results

[0001193125-15-185905:8k_2_02:13]
|  |  | Q3 2015 |  |  | Q3 2014 |  |  | Vs. Q3 2014 |  |
| Revenue |  | $ | 12.1 billion |  |  | $ | 11.5 billion |  |  |  | 5.1 | % |
| Net Income |  | $ | 2.4 billion |  |  | $ | 2.2 billion |  |  |  | 11.7 | % |
| Earnings per Share |  | $ | 0.47 |  |  | $ | 0.42 |  |  |  | 11.9 | % |

[0001193125-15-185905:8k_2_02:14]
Non-GAAP Results

[0001193125-15-185905:8k_2_02:15]
|  |  | Q3 2015 |  |  | Q3 2014 |  |  | Vs. Q3 2014 |  |
| Net Income |  | $ | 2.8 billion |  |  | $ | 2.6 billion |  |  |  | 5.9 | % |
| Earnings per Share |  | $ | 0.54 |  |  | $ | 0.51 |  |  |  | 5.9 | % |

[0001193125-15-185905:8k_2_02:16]
Revenue for the first nine months of fiscal 2015 was $36.3 billion, compared with $34.8 billion for the first nine months of
fiscal 2014. Net income for the first nine months of fiscal 2015, on a GAAP basis, was $6.7 billion or $1.29 per share, compared with $5.6 billion or $1.06 per share for the first nine months of fiscal 2014. Non-GAAP net income for the first nine
months of fiscal 2015 was $8.3 billion or $1.62 per share, compared with $8.0 billion or $1.51 per share for the first nine months of fiscal 2014.

[0001193125-15-185905:8k_2_02:17]
A
reconciliation between net income on a GAAP basis and non-GAAP net income is provided in the table following the Consolidated Statements of Operations.

[0001193125-15-185905:8k_2_02:18]
Cisco will discuss third quarter results and business outlook on a conference call and webcast at 1:30 p.m. Pacific Time today. Call information and related
charts are available at http://investor.cisco.com.

[0001193125-15-185905:8k_2_02:19]
Cash and Cash Equivalents and Investments

[0001193125-15-185905:8k_2_02:20]
|  | • |  | Cash flow from operations were $3.0 billion for the third quarter of fiscal 2015, compared with $2.9 billion for the second quarter of fiscal 2015, and compared with $3.2 billion for the third quarter of fiscal 2014. |

[0001193125-15-185905:8k_2_02:21]
|  | • |  | Cash and cash equivalents and investments were $54.4 billion at the end of the third quarter of fiscal 2015, compared with $53.0 billion at the end of the second quarter of fiscal 2015, and compared with $52.1 billion at the end of the fourth quarter of fiscal 2014. |

[0001193125-15-185905:8k_2_02:22]
1

[0001193125-15-185905:8k_2_02:23]
Dividends and Stock Repurchase Program

[0001193125-15-185905:8k_2_02:24]
|  | • |  | During the third quarter of fiscal 2015, Cisco paid a cash dividend of $0.21 per common share, or $1.1 billion. |

[0001193125-15-185905:8k_2_02:25]
|  | • |  | Cisco repurchased approximately 35 million shares of common stock under the stock repurchase program at an average price of $28.39 per share for an aggregate purchase price of $1.0 billion during the third quarter of fiscal 2015. As of April 25, 2015, Cisco had repurchased and retired 4.4 billion shares of Cisco common stock at an average price of $20.80 per share for an aggregate purchase price of approximately $91.7 billion since the inception of the stock repurchase program. The remaining authorized amount for stock repurchases under this program is approximately $5.3 billion with no termination date. |

[0001193125-15-185905:8k_2_02:26]
“I feel great about the quarter. We executed well and the strategy is working,” said Kelly Kramer, Cisco executive vice president and
CFO. “We saw good balance again across our portfolio and delivered revenues of $12.1 billion up 5%, and grew earnings per share faster than revenue. We continued our strong cash generation and returned another $2.1 billion to our
shareholders. We’re well positioned in the market, managing the company well, and focused on delivering value for our customers and shareholders. It’s an exciting time.”

[0001193125-15-185905:8k_2_02:27]
Internet of Everything

[0001193125-15-185905:8k_2_02:28]
|  | • |  | Cisco released a study highlighting how the adoption of Internet of Everything (IoE) strategies by the oil and gas industry could fuel a U.S. gross domestic product (GDP) increase by up to 0.8 percent, or $816 billion, over 10 years. |

[0001193125-15-185905:8k_2_02:29]
|  | • |  | Cisco opened an IoE Innovation Center in Berlin that unveiled a new asset management solution less than six months after opening its doors. |

[0001193125-15-185905:8k_2_02:30]
|  | • |  | Cisco announced the investment in a Cisco IoE Innovation Center in Australia, one of eight such centers globally. |

[0001193125-15-185905:8k_2_02:31]
|  | • |  | Cisco launched Connected Roadways, a suite of validated solutions using the IoE that connect disparate transportation systems to increase safety, reduce roadside incidents, improve traffic flow and provide a centralized view of highway systems in a highly secure manner. |

[0001193125-15-185905:8k_2_02:32]
Next Generation of IT

[0001193125-15-185905:8k_2_02:33]
|  | • |  | Cisco introduced Cisco Collaborative Knowledge, a software-as-a-service (SaaS) solution designed to help its customers invigorate their organizations and empower employees with the digital tools and technology needed to access experts, learning and knowledge in real time. |

[0001193125-15-185905:8k_2_02:34]
|  | • |  | Cisco unveiled a host of new capabilities and services for security professionals that provide extensive intelligence and analysis on potential threats, and solutions to protect against, respond to and recover from attacks. |

[0001193125-15-185905:8k_2_02:35]
|  | • |  | Cisco announced three significant enhancements to the Cisco Evolved Programmable Network (EPN) portfolio, an open, elastic, and application-centric network infrastructure framework that helps enable service providers to accelerate time-to-revenue while reducing the costs of deploying new services. |

[0001193125-15-185905:8k_2_02:36]
|  | • |  | To make it easier for customers to achieve business outcomes, Cisco announced it has established software resale agreements with Cloudera, Hortonworks and MapR for their industry leading Apache Hadoop data management capabilities and innovation. |

[0001193125-15-185905:8k_2_02:37]
|  | • |  | Cisco completed the acquisition of Embrane, a provider of a lifecycle-management platform for application-centric network services. |

[0001193125-15-185905:8k_2_02:38]
Innovation

[0001193125-15-185905:8k_2_02:39]
|  | • |  | One of the Brazil’s largest retail groups, CSD, selected Cisco technology to unify its communications infrastructure. |

[0001193125-15-185905:8k_2_02:40]
|  | • |  | Cisco and Globo, a leading broadcaster in Brazil and one of the largest content producers worldwide, are working together on a large-scale project to provide Globo with greater business agility by virtualizing and orchestrating the network functions and workflows required to manage, deliver and share produced content within its new media content partners. |

[0001193125-15-185905:8k_2_02:41]
|  | • |  | Employees across many industries are now using Cisco Spark to collaborate simply and in a highly secure way inside and outside their organizations in ways not previously possible. |

[0001193125-15-185905:8k_2_02:42]
|  | • |  | Cisco announced an extension of its cloud and data center relationship with Microsoft to include a new technology platform designed to accelerate service delivery and streamline the journey to the Cisco Intercloud™ for cloud providers. |

[0001193125-15-185905:8k_2_02:43]
|  | • |  | Cisco announced that EE, the United Kingdom’s largest mobile network operator, is deploying Cisco small cells to support its growing base of enterprise customers. Cisco’s end-to-end small cell solutions can scale to be suitable for small, medium and large enterprise buildings. |

[0001193125-15-185905:8k_2_02:44]
|  | • |  | Cisco announced that AT&T will use its virtualized mobile Internet solution to help support AT&T’s auto-maker customers in providing advanced connected car services. |

[0001193125-15-185905:8k_2_02:45]
|  | • |  | The Sao Paulo International Airport adopted Cisco technology to integrate and update its technology and telecommunications infrastructure. |

[0001193125-15-185905:8k_2_02:46]
|  | • |  | Telstra and Cisco announced their intention to extend their strategic collaboration by giving Telstra’s domestic and global business customers a unified, on-demand suite of cloud and managed network services. |

[0001193125-15-185905:8k_2_02:47]
2

[0001193125-15-185905:8k_2_02:48]
|  | • |  | Cisco introduced Mobility IQ, a mobility SaaS analytics solution hosted on Cisco Cloud Services that provides advanced insights and a high-level overview across Wi-Fi, 3G and LTE network activity in real-time. |

[0001193125-15-185905:8k_2_02:49]
Editor’s Notes:

[0001193125-15-185905:8k_2_02:50]
|  | • |  | Q3 fiscal year 2015 conference call to discuss Cisco’s results along with its business outlook will be held on Wednesday, May 13, 2015 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-15-185905:8k_2_02:51]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, May 13, 2015 to 4:00 p.m. Pacific Time, May 20, 2015 at 1-800-839-1170 (United States) or 1-402-998-0559 (international). The replay will also be available via webcast from May 13, 2015 through July 17, 2015 on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-15-185905:8k_2_02:52]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, May 13, 2015. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-15-185905:8k_2_02:53]
About Cisco

[0001193125-15-185905:8k_2_02:54]
Cisco (NASDAQ: CSCO) is the worldwide leader
in IT that helps companies seize the opportunities of tomorrow by proving that amazing things can happen when you connect the previously unconnected. For ongoing news, please go to http://thenetwork.cisco.com.

[0001193125-15-185905:8k_2_02:55]
###

[0001193125-15-185905:8k_2_02:56]
This release includes non-GAAP net income, non-GAAP effective tax rates, non-GAAP net income per share data, non-GAAP inventory turns and free cash flow.

[0001193125-15-185905:8k_2_02:57]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles and
may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do
not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding
GAAP measures.

[0001193125-15-185905:8k_2_02:58]
Cisco believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP net income per share data, when
shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. In addition, Cisco believes
that the presentation of non-GAAP inventory turns provides useful information to investors and management regarding financial and business trends relating to inventory management based on the operating activities of the periods presented. Cisco
believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management

[0001193125-15-185905:8k_2_02:59]
and investors because of its intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases. Cisco further regards free cash flow as a
useful measure because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock, after deducting capital investments.

[0001193125-15-185905:8k_2_02:60]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, impact to cost of sales from purchase accounting adjustments to inventory, acquisition-related/divestiture costs (which includes a gain recognized in the second quarter of fiscal 2015 with
respect to the reorganization and divestiture of a portion of Cisco’s investment in VCE), significant asset impairments and restructurings, significant litigation and other contingencies, the income tax effects of the foregoing, and significant
tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes
for purposes of its non-GAAP financial measures. From time to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the
items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-15-185905:8k_2_02:61]
Copyright © 2015 Cisco and/or its affiliates. All rights reserved. Cisco, the Cisco logo and Cisco
Intercloud are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the
property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-15-185905:8k_2_02:62]
4

[0001193125-15-185905:8k_2_02:63]
CISCO SYSTEMS, INC.

[0001193125-15-185905:8k_2_02:64]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-15-185905:8k_2_02:65]
(In millions, except per-share amounts)

[0001193125-15-185905:8k_2_02:66]
(Unaudited)

[0001193125-15-185905:8k_2_02:67]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 25,2015 |  |  | April 26,2014 |  |  | April 25,2015 |  |  | April 26,2014 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,326 |  |  | $ | 8,820 |  |  | $ | 27,839 |  |  | $ | 26,640 |  |
| Service |  |  | 2,811 |  |  |  | 2,725 |  |  |  | 8,479 |  |  |  | 8,145 |  |
| Total revenue |  |  | 12,137 |  |  |  | 11,545 |  |  |  | 36,318 |  |  |  | 34,785 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,584 |  |  |  | 3,595 |  |  |  | 11,309 |  |  |  | 11,665 |  |
| Service |  |  | 1,028 |  |  |  | 944 |  |  |  | 3,061 |  |  |  | 2,756 |  |
| Total cost of sales |  |  | 4,612 |  |  |  | 4,539 |  |  |  | 14,370 |  |  |  | 14,421 |  |
| GROSS MARGIN |  |  | 7,525 |  |  |  | 7,006 |  |  |  | 21,948 |  |  |  | 20,364 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,547 |  |  |  | 1,565 |  |  |  | 4,659 |  |  |  | 4,701 |  |
| Sales and marketing |  |  | 2,449 |  |  |  | 2,342 |  |  |  | 7,272 |  |  |  | 7,030 |  |
| General and administrative |  |  | 510 |  |  |  | 460 |  |  |  | 1,504 |  |  |  | 1,426 |  |
| Amortization of purchased intangible assets |  |  | 70 |  |  |  | 71 |  |  |  | 213 |  |  |  | 207 |  |
| Restructuring and other charges |  |  | 24 |  |  |  | 26 |  |  |  | 411 |  |  |  | 336 |  |
| Total operating expenses |  |  | 4,600 |  |  |  | 4,464 |  |  |  | 14,059 |  |  |  | 13,700 |  |
| OPERATING INCOME |  |  | 2,925 |  |  |  | 2,542 |  |  |  | 7,889 |  |  |  | 6,664 |  |
| Interest income |  |  | 190 |  |  |  | 170 |  |  |  | 558 |  |  |  | 508 |  |
| Interest expense |  |  | (139 | ) |  |  | (146 | ) |  |  | (417 | ) |  |  | (422 | ) |
| Other income (loss), net |  |  | 59 |  |  |  | 76 |  |  |  | 238 |  |  |  | 187 |  |
| Interest and other income (loss), net |  |  | 110 |  |  |  | 100 |  |  |  | 379 |  |  |  | 273 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,035 |  |  |  | 2,642 |  |  |  | 8,268 |  |  |  | 6,937 |  |
| Provision for income taxes |  |  | 598 |  |  |  | 461 |  |  |  | 1,606 |  |  |  | 1,331 |  |
| NET INCOME |  | $ | 2,437 |  |  | $ | 2,181 |  |  | $ | 6,662 |  |  | $ | 5,606 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.48 |  |  | $ | 0.42 |  |  | $ | 1.30 |  |  | $ | 1.06 |  |
| Diluted |  | $ | 0.47 |  |  | $ | 0.42 |  |  | $ | 1.29 |  |  | $ | 1.06 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,102 |  |  |  | 5,143 |  |  |  | 5,110 |  |  |  | 5,271 |  |
| Diluted |  |  | 5,148 |  |  |  | 5,180 |  |  |  | 5,154 |  |  |  | 5,311 |  |
| Cash dividends declared per common share |  | $ | 0.21 |  |  | $ | 0.19 |  |  | $ | 0.59 |  |  | $ | 0.53 |  |

[0001193125-15-185905:8k_2_02:68]
5

[0001193125-15-185905:8k_2_02:69]
RECONCILIATION OF GAAP TO NON-GAAP NET INCOME

[0001193125-15-185905:8k_2_02:70]
(In millions, except per-share amounts)

[0001193125-15-185905:8k_2_02:71]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 25,2015 |  |  | April 26,2014 |  |  | April 25,2015 |  |  | April 26,2014 |  |
| GAAP net income |  | $ | 2,437 |  |  | $ | 2,181 |  |  | $ | 6,662 |  |  | $ | 5,606 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 56 |  |  |  | 51 |  |  |  | 149 |  |  |  | 146 |  |
| Amortization of acquisition-related intangible assets |  |  | 172 |  |  |  | 181 |  |  |  | 586 |  |  |  | 530 |  |
| Supplier component remediation charge (adjustment) |  |  | (164 | ) |  |  | — |  |  |  | (164 | ) |  |  | 655 |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | 1 |  |
| Rockstar patent portfolio charge |  |  | — |  |  |  | — |  |  |  | 188 |  |  |  | — |  |
| Total adjustments to GAAP cost of sales |  |  | 64 |  |  |  | 233 |  |  |  | 759 |  |  |  | 1,332 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 311 |  |  |  | 302 |  |  |  | 897 |  |  |  | 867 |  |
| Amortization of acquisition-related intangible assets |  |  | 70 |  |  |  | 71 |  |  |  | 213 |  |  |  | 207 |  |
| Acquisition-related/divestiture costs |  |  | 79 |  |  |  | 68 |  |  |  | 272 |  |  |  | 483 |  |
| Significant asset impairments and restructurings |  |  | 24 |  |  |  | 26 |  |  |  | 411 |  |  |  | 336 |  |
| Total adjustments to GAAP operating expenses |  |  | 484 |  |  |  | 467 |  |  |  | 1,793 |  |  |  | 1,893 |  |
| Adjustments to other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on VCE reorganization |  |  | — |  |  |  | — |  |  |  | (126 | ) |  |  | — |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 548 |  |  |  | 700 |  |  |  | 2,426 |  |  |  | 3,225 |  |
| Income tax effect of non-GAAP adjustments |  |  | (124 | ) |  |  | (156 | ) |  |  | (546 | ) |  |  | (649 | ) |
| Significant tax matters |  |  | (66 | ) |  |  | (85 | ) |  |  | (200 | ) |  |  | (154 | ) |
| Total adjustments to GAAP provision for income taxes |  |  | (190 | ) |  |  | (241 | ) |  |  | (746 | ) |  |  | (803 | ) |
| Non-GAAP net income |  | $ | 2,795 |  |  | $ | 2,640 |  |  | $ | 8,342 |  |  | $ | 8,028 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.47 |  |  | $ | 0.42 |  |  | $ | 1.29 |  |  | $ | 1.06 |  |
| Non-GAAP |  | $ | 0.54 |  |  | $ | 0.51 |  |  | $ | 1.62 |  |  | $ | 1.51 |  |

[0001193125-15-185905:8k_2_02:72]
RECONCILIATION OF GAAP TO NON-GAAP EFFECTIVE TAX RATE

[0001193125-15-185905:8k_2_02:73]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 25,2015 |  |  | April 26,2014 |  |  | April 25,2015 |  |  | April 26,2014 |  |
| GAAP effective tax rate |  |  | 19.7 | % |  |  | 17.4 | % |  |  | 19.4 | % |  |  | 19.2 | % |
| Tax effect of non-GAAP adjustments to net income |  |  | 2.3 | % |  |  | 3.6 | % |  |  | 2.6 | % |  |  | 1.8 | % |
| Non-GAAP effective tax rate |  |  | 22.0 | % |  |  | 21.0 | % |  |  | 22.0 | % |  |  | 21.0 | % |

[0001193125-15-185905:8k_2_02:74]
6

[0001193125-15-185905:8k_2_02:75]
CISCO SYSTEMS, INC.

[0001193125-15-185905:8k_2_02:76]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-15-185905:8k_2_02:77]
(In millions)

[0001193125-15-185905:8k_2_02:78]
(Unaudited)

[0001193125-15-185905:8k_2_02:79]
|  |  | April 25,2015 |  |  | July 26,2014 |  |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,870 |  |  | $ | 6,726 |  |
| Investments |  |  | 50,549 |  |  |  | 45,348 |  |
| Accounts receivable, net of allowance for doubtful accounts of $290 at April 25, 2015 and $265 at July 26, 2014 |  |  | 4,889 |  |  |  | 5,157 |  |
| Inventories |  |  | 1,760 |  |  |  | 1,591 |  |
| Financing receivables, net |  |  | 4,248 |  |  |  | 4,153 |  |
| Deferred tax assets |  |  | 2,539 |  |  |  | 2,808 |  |
| Other current assets |  |  | 1,476 |  |  |  | 1,331 |  |
| Total current assets |  |  | 69,331 |  |  |  | 67,114 |  |
| Property and equipment, net |  |  | 3,276 |  |  |  | 3,252 |  |
| Financing receivables, net |  |  | 3,506 |  |  |  | 3,918 |  |
| Goodwill |  |  | 24,398 |  |  |  | 24,239 |  |
| Purchased intangible assets, net |  |  | 2,626 |  |  |  | 3,280 |  |
| Other assets |  |  | 3,075 |  |  |  | 3,331 |  |
| TOTAL ASSETS |  | $ | 106,212 |  |  | $ | 105,134 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Short-term debt |  | $ | 4,418 |  |  | $ | 508 |  |
| Accounts payable |  |  | 1,118 |  |  |  | 1,032 |  |
| Income taxes payable |  |  | 80 |  |  |  | 159 |  |
| Accrued compensation |  |  | 2,726 |  |  |  | 3,181 |  |
| Deferred revenue |  |  | 9,371 |  |  |  | 9,478 |  |
| Other current liabilities |  |  | 5,532 |  |  |  | 5,451 |  |
| Total current liabilities |  |  | 23,245 |  |  |  | 19,809 |  |
| Long-term debt |  |  | 16,586 |  |  |  | 20,401 |  |
| Income taxes payable |  |  | 1,294 |  |  |  | 1,851 |  |
| Deferred revenue |  |  | 4,810 |  |  |  | 4,664 |  |
| Other long-term liabilities |  |  | 1,444 |  |  |  | 1,748 |  |
| Total liabilities |  |  | 47,379 |  |  |  | 48,473 |  |
| Total equity |  |  | 58,833 |  |  |  | 56,661 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 106,212 |  |  | $ | 105,134 |  |

[0001193125-15-185905:8k_2_02:80]
CISCO SYSTEMS, INC.

[0001193125-15-185905:8k_2_02:81]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-15-185905:8k_2_02:82]
(In millions)

[0001193125-15-185905:8k_2_02:83]
(Unaudited)

[0001193125-15-185905:8k_2_02:84]
|  |  | Nine Months Ended |  |
|  |  | April 25,2015 |  |  | April 26,2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 6,662 |  |  | $ | 5,606 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,791 |  |  |  | 1,811 |  |
| Share-based compensation expense |  |  | 1,044 |  |  |  | 1,009 |  |
| Provision for receivables |  |  | 82 |  |  |  | 48 |  |
| Deferred income taxes |  |  | 438 |  |  |  | (181 | ) |
| Excess tax benefits from share-based compensation |  |  | (102 | ) |  |  | (84 | ) |
| (Gains) losses on investments and other, net |  |  | (231 | ) |  |  | (228 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 97 |  |  |  | 1,064 |  |
| Inventories |  |  | (235 | ) |  |  | (50 | ) |
| Financing receivables |  |  | 36 |  |  |  | 332 |  |
| Other assets |  |  | (341 | ) |  |  | 180 |  |
| Accounts payable |  |  | 101 |  |  |  | (2 | ) |
| Income taxes, net |  |  | (511 | ) |  |  | (356 | ) |
| Accrued compensation |  |  | (324 | ) |  |  | (411 | ) |
| Deferred revenue |  |  | 217 |  |  |  | (309 | ) |
| Other liabilities |  |  | (310 | ) |  |  | 291 |  |
| Net cash provided by operating activities |  |  | 8,414 |  |  |  | 8,720 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (30,617 | ) |  |  | (27,884 | ) |
| Proceeds from sales of investments |  |  | 13,890 |  |  |  | 14,490 |  |
| Proceeds from maturities of investments |  |  | 11,632 |  |  |  | 12,048 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (238 | ) |  |  | (2,784 | ) |
| Purchases of investments in privately held companies |  |  | (155 | ) |  |  | (315 | ) |
| Return of investments in privately held companies |  |  | 274 |  |  |  | 119 |  |
| Acquisition of property and equipment |  |  | (907 | ) |  |  | (950 | ) |
| Proceeds from sales of property and equipment |  |  | 8 |  |  |  | 168 |  |
| Other |  |  | (115 | ) |  |  | (30 | ) |
| Net cash used in investing activities |  |  | (6,228 | ) |  |  | (5,138 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 1,584 |  |  |  | 1,053 |  |
| Repurchases of common stock—repurchase program |  |  | (3,325 | ) |  |  | (7,965 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (415 | ) |  |  | (345 | ) |
| Short-term borrowings, original maturities less than 90 days, net |  |  | 496 |  |  |  | (2 | ) |
| Issuances of debt |  |  | — |  |  |  | 8,001 |  |
| Repayments of debt |  |  | (507 | ) |  |  | (3,274 | ) |
| Excess tax benefits from share-based compensation |  |  | 102 |  |  |  | 84 |  |
| Dividends paid |  |  | (3,017 | ) |  |  | (2,784 | ) |
| Other |  |  | 40 |  |  |  | (34 | ) |
| Net cash used in financing activities |  |  | (5,042 | ) |  |  | (5,266 | ) |
| Net decrease in cash and cash equivalents |  |  | (2,856 | ) |  |  | (1,684 | ) |
| Cash and cash equivalents, beginning of period |  |  | 6,726 |  |  |  | 7,925 |  |
| Cash and cash equivalents, end of period |  | $ | 3,870 |  |  | $ | 6,241 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 646 |  |  | $ | 561 |  |
| Cash paid for income taxes, net |  | $ | 1,680 |  |  | $ | 1,868 |  |

[0001193125-15-185905:8k_2_02:85]
8

[0001193125-15-185905:8k_2_02:86]
CASH AND CASH EQUIVALENTS AND INVESTMENTS

[0001193125-15-185905:8k_2_02:87]
(In millions)

[0001193125-15-185905:8k_2_02:88]
|  |  | April 25,2015 |  |  | July 26,2014 |  |
| Cash and cash equivalents and investments: |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,870 |  |  | $ | 6,726 |  |
| Fixed income securities |  |  | 48,626 |  |  |  | 43,396 |  |
| Publicly traded equity securities |  |  | 1,923 |  |  |  | 1,952 |  |
| Total |  | $ | 54,419 |  |  | $ | 52,074 |  |

[0001193125-15-185905:8k_2_02:89]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES

[0001193125-15-185905:8k_2_02:90]
TO FREE CASH FLOW (NON-GAAP)

[0001193125-15-185905:8k_2_02:91]
(In millions)

[0001193125-15-185905:8k_2_02:92]
|  |  | Three Months Ended |  |
|  |  | April 25,2015 |  |  | January 24,2015 |  |  | April 26,2014 |  |
| Net cash provided by operating activities |  | $ | 3,040 |  |  | $ | 2,883 |  |  | $ | 3,198 |  |
| Acquisition of property and equipment |  |  | (357 | ) |  |  | (265 | ) |  |  | (373 | ) |
| Free cash flow |  | $ | 2,683 |  |  | $ | 2,618 |  |  | $ | 2,825 |  |

[0001193125-15-185905:8k_2_02:93]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-15-185905:8k_2_02:94]
(In millions, except per-share amounts)

[0001193125-15-185905:8k_2_02:95]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2015 |  |  |  |  |  |  |  |  |
| April 25, 2015 |  | $ | 0.21 |  |  | $ | 1,070 |  |  |  | 35 |  |  | $ | 28.39 |  |  | $ | 1,008 |  |  | $ | 2,078 |  |
| January 24, 2015 |  | $ | 0.19 |  |  | $ | 974 |  |  |  | 44 |  |  | $ | 27.63 |  |  | $ | 1,208 |  |  | $ | 2,182 |  |
| October 25, 2014 |  | $ | 0.19 |  |  | $ | 973 |  |  |  | 41 |  |  | $ | 24.58 |  |  | $ | 1,013 |  |  | $ | 1,986 |  |
| Fiscal 2014 |  |  |  |  |  |  |  |  |
| July 26, 2014 |  | $ | 0.19 |  |  | $ | 974 |  |  |  | 61 |  |  | $ | 25.11 |  |  | $ | 1,514 |  |  | $ | 2,488 |  |
| April 26, 2014 |  |  | 0.19 |  |  |  | 974 |  |  |  | 90 |  |  | $ | 22.24 |  |  |  | 2,005 |  |  |  | 2,979 |  |
| January 25, 2014 |  |  | 0.17 |  |  |  | 896 |  |  |  | 185 |  |  | $ | 21.73 |  |  |  | 4,020 |  |  |  | 4,916 |  |
| October 26, 2013 |  |  | 0.17 |  |  |  | 914 |  |  |  | 84 |  |  | $ | 23.65 |  |  |  | 2,000 |  |  |  | 2,914 |  |
| Total |  | $ | 0.72 |  |  | $ | 3,758 |  |  |  | 420 |  |  | $ | 22.71 |  |  | $ | 9,539 |  |  | $ | 13,297 |  |

[0001193125-15-185905:8k_2_02:96]
ACCOUNTS RECEIVABLE AND DSO

[0001193125-15-185905:8k_2_02:97]
(In millions, except DSO)

[0001193125-15-185905:8k_2_02:98]
|  |  | April 25,2015 |  |  | January 24,2015 |  |  | April 26,2014 |  |
| Accounts receivable, net |  | $ | 4,889 |  |  | $ | 4,541 |  |  | $ | 4,443 |  |
| Days sales outstanding in accounts receivable (DSO) |  |  | 37 |  |  |  | 35 |  |  |  | 35 |  |

[0001193125-15-185905:8k_2_02:99]
INVENTORIES

[0001193125-15-185905:8k_2_02:100]
(In millions)

[0001193125-15-185905:8k_2_02:101]
|  |  | April 25,2015 |  |  | January 24,2015 |  |  | April 26,2014 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 264 |  |  | $ | 265 |  |  | $ | 57 |  |
| Work in process |  |  | 2 |  |  |  | 2 |  |  |  | 5 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  |  | 635 |  |  |  | 733 |  |  |  | 623 |  |
| Manufactured finished goods |  |  | 547 |  |  |  | 577 |  |  |  | 550 |  |
| Total finished goods |  |  | 1,182 |  |  |  | 1,310 |  |  |  | 1,173 |  |
| Service-related spares |  |  | 268 |  |  |  | 274 |  |  |  | 255 |  |
| Demonstration systems |  |  | 44 |  |  |  | 39 |  |  |  | 38 |  |
| Total |  | $ | 1,760 |  |  | $ | 1,890 |  |  | $ | 1,528 |  |

[0001193125-15-185905:8k_2_02:102]
INVENTORY TURNS AND RECONCILIATION OF GAAP TO NON-GAAP

[0001193125-15-185905:8k_2_02:103]
COST OF SALES USED IN INVENTORY TURNS

[0001193125-15-185905:8k_2_02:104]
(In millions, except annualized inventory turns)

[0001193125-15-185905:8k_2_02:105]
|  |  | Three Months Ended |  |
|  |  | April 25,2015 |  |  | January 24,2015 |  |  | April 26,2014 |  |
| Annualized inventory turns - GAAP |  |  | 10.1 |  |  |  | 10.9 |  |  |  | 11.8 |  |
| Cost of sales adjustments |  |  | (0.1 | ) |  |  | (0.7 | ) |  |  | (0.6 | ) |
| Annualized inventory turns - non-GAAP |  |  | 10.0 |  |  |  | 10.2 |  |  |  | 11.2 |  |
| GAAP cost of sales |  | $ | 4,612 |  |  | $ | 4,846 |  |  | $ | 4,539 |  |
| Cost of sales adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | (56 | ) |  |  | (45 | ) |  |  | (51 | ) |
| Amortization of acquisition-related intangible assets |  |  | (172 | ) |  |  | (233 | ) |  |  | (181 | ) |
| Supplier component remediation adjustment |  |  | 164 |  |  |  | — |  |  |  | — |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | — |  |  |  | (1 | ) |
| Non-GAAP cost of sales |  | $ | 4,548 |  |  | $ | 4,568 |  |  | $ | 4,306 |  |

[0001193125-15-185905:8k_2_02:106]
DEFERRED REVENUE

[0001193125-15-185905:8k_2_02:107]
(In millions)

[0001193125-15-185905:8k_2_02:108]
|  |  | April 25,2015 |  |  | January 24,2015 |  |  | April 26,2014 |  |
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 9,236 |  |  | $ | 9,020 |  |  | $ | 8,746 |  |
| Product: |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  |  | 4,258 |  |  |  | 4,276 |  |  |  | 3,669 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  |  | 687 |  |  |  | 725 |  |  |  | 736 |  |
| Total product deferred revenue |  |  | 4,945 |  |  |  | 5,001 |  |  |  | 4,405 |  |
| Total |  | $ | 14,181 |  |  | $ | 14,021 |  |  | $ | 13,151 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,371 |  |  | $ | 9,369 |  |  | $ | 9,198 |  |
| Noncurrent |  |  | 4,810 |  |  |  | 4,652 |  |  |  | 3,953 |  |
| Total |  | $ | 14,181 |  |  | $ | 14,021 |  |  | $ | 13,151 |  |

[0001193125-15-185905:8k_2_02:109]
SUMMARY OF SHARE-BASED COMPENSATION EXPENSE

[0001193125-15-185905:8k_2_02:110]
(In millions)

[0001193125-15-185905:8k_2_02:111]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 25,2015 |  |  | April 26,2014 |  |  | April 25,2015 |  |  | April 26,2014 |  |
| Cost of sales - product |  | $ | 12 |  |  | $ | 12 |  |  | $ | 34 |  |  | $ | 34 |  |
| Cost of sales - service |  |  | 44 |  |  |  | 39 |  |  |  | 115 |  |  |  | 112 |  |
| Share-based compensation expense in cost of sales |  |  | 56 |  |  |  | 51 |  |  |  | 149 |  |  |  | 146 |  |
| Research and development |  |  | 114 |  |  |  | 106 |  |  |  | 338 |  |  |  | 306 |  |
| Sales and marketing |  |  | 147 |  |  |  | 144 |  |  |  | 408 |  |  |  | 408 |  |
| General and administrative |  |  | 50 |  |  |  | 52 |  |  |  | 151 |  |  |  | 153 |  |
| Restructuring and other charges |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  | (4 | ) |
| Share-based compensation expense in operating expenses |  |  | 311 |  |  |  | 302 |  |  |  | 895 |  |  |  | 863 |  |
| Total share-based compensation expense |  | $ | 367 |  |  | $ | 353 |  |  | $ | 1,044 |  |  | $ | 1,009 |  |
| Income tax benefit for share-based compensation |  | $ | 88 |  |  | $ | 86 |  |  | $ | 267 |  |  | $ | 246 |  |

[0001193125-15-185905:8k_2_02:112]
11
