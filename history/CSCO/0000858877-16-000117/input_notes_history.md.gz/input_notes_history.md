# CSCO note change history — 0000858877-16-000090 → 0000858877-16-000109


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-05-24):
[0000858877-16-000109:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 30, 2016 are as follows (in millions):
  (was, 2016-02-18, similarity 0.9858):
[0000858877-16-000090:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of January 23, 2016 are as follows (in millions):

- changed (2016-05-24):
[0000858877-16-000109:note_history:2]
| Fiscal Year | Amount |
| 2016 (remaining three months) | $ | 95 |  |
| 2017 | 288 |  |
| 2018 | 220 |  |
| 2019 | 130 |  |
| 2020 | 106 |  |
| Thereafter | 229 |  |
| Total | $ | 1,068 |  |
  (was, 2016-02-18, similarity 0.9739):
[0000858877-16-000090:note_history:2]
| Fiscal Year | Amount |
| 2016 (remaining six months) | $ | 184 |  |
| 2017 | 268 |  |
| 2018 | 204 |  |
| 2019 | 117 |  |
| 2020 | 96 |  |
| Thereafter | 222 |  |
| Total | $ | 1,091 |  |

- changed (2016-05-24):
[0000858877-16-000109:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of April 30, 2016 and July 25, 2015, the Company had total purchase commitments for inventory of $3,794 million and $4,078 million, respectively.
  (was, 2016-02-18, similarity 0.994):
[0000858877-16-000090:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of January 23, 2016 and July 25, 2015, the Company had total purchase commitments for inventory of $3,435 million and $4,078 million, respectively.

- changed (2016-05-24):
[0000858877-16-000109:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of April 30, 2016 and July 25, 2015, the liability for these purchase commitments was $160 million and $156 million, respectively, and was included in other current liabilities.
  (was, 2016-02-18, similarity 0.9621):
[0000858877-16-000090:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of January 23, 2016 and July 25, 2015, the liability for these purchase commitments was $180 million and $156 million, respectively, and was included in other current liabilities.

- changed (2016-05-24):
[0000858877-16-000109:note_history:5]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Compensation expense related to acquisitions | $ | 68 |  |  | $ | 72 |  |  | $ | 212 |  |  | $ | 264 |  |
  (was, 2016-02-18, similarity 0.7309):
[0000858877-16-000090:note_history:5]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Compensation expense related to acquisitions | $ | 71 |  |  | $ | 94 |  |  | $ | 144 |  |  | $ | 192 |  |

- changed (2016-05-24):
[0000858877-16-000109:note_history:6]
As of April 30, 2016, the Company estimated that future cash compensation expense of up to $400 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.
  (was, 2016-02-18, similarity 0.9823):
[0000858877-16-000090:note_history:6]
As of January 23, 2016, the Company estimated that future cash compensation expense of up to $230 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.

- changed (2016-05-24):
[0000858877-16-000109:note_history:7]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $35 million and $51 million during the three months ended April 30, 2016 and April 25, 2015, respectively, and $136 million and $155 million during the nine months ended April 30, 2016 and April 25, 2015, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $839 million (which includes the $759 million that has been expensed to date), net of forfeitures.
  (was, 2016-02-18, similarity 0.9528):
[0000858877-16-000090:note_history:7]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $50 million and $51 million during the three months ended January 23, 2016 and January 24, 2015, respectively, and $101 million and $104 million during the six months ended January 23, 2016 and January 24, 2015, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $839 million (which includes the $724 million that has been expensed to date), net of forfeitures.

- changed (2016-05-24):
[0000858877-16-000109:note_history:8]
The former noncontrolling interest holders earned the maximum amount related to the first milestone payment and were paid   approximately $375 million for a portion of this amount during the nine months ended April 30, 2016. The balance of the first milestone payment is expected to be paid primarily through the end of fiscal 2016. The second milestone payment, to the extent earned, is expected to be paid primarily during the first half of fiscal 2017.
  (was, 2016-02-18, similarity 0.9463):
[0000858877-16-000090:note_history:8]
The former noncontrolling interest holders earned the maximum amount related to the first milestone payment and were paid   approximately $354 million for a portion of this amount during the six months ended January 23, 2016. The balance of the first milestone payment is expected to be paid primarily through the end of fiscal 2016. The second milestone payment, to the extent earned, is expected to be paid primarily during the first half of fiscal 2017.

- changed (2016-05-24):
[0000858877-16-000109:note_history:9]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $199 million and $205 million as of April 30, 2016 and July 25, 2015, respectively.
  (was, 2016-02-18, similarity 0.9589):
[0000858877-16-000090:note_history:9]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $188 million and $205 million as of January 23, 2016 and July 25, 2015, respectively.

- changed (2016-05-24):
[0000858877-16-000109:note_history:10]
|  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |
| Balance at beginning of period | $ | 449 |  |  | $ | 446 |  |
| Provision for warranties issued | 512 |  |  | 517 |  |
| Payments | (524 | ) |  | (512 | ) |
| Divestitures | (28 | ) |  | — |  |
| Balance at end of period | $ | 409 |  |  | $ | 451 |  |
  (was, 2016-02-18, similarity 0.8932):
[0000858877-16-000090:note_history:10]
|  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |
| Balance at beginning of period | $ | 449 |  |  | $ | 446 |  |
| Provision for warranties issued | 322 |  |  | 355 |  |
| Payments | (340 | ) |  | (327 | ) |
| Acquisition/divestitures | (28 | ) |  | — |  |
| Balance at end of period | $ | 403 |  |  | $ | 474 |  |

- changed (2016-05-24):
[0000858877-16-000109:note_history:11]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.4 billion and $6.3 billion for the three months ended April 30, 2016 and April 25, 2015, respectively, and was $19.8 billion and $19.0 billion for the nine months ended April 30, 2016 and April 25, 2015, respectively. The balance of the channel partner financing subject to guarantees was $1.0 billion and $1.2 billion as of April 30, 2016 and July 25, 2015, respectively.
  (was, 2016-02-18, similarity 0.8836):
[0000858877-16-000090:note_history:11]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.5 billion and $6.2 billion for the three months ended January 23, 2016 and January 24, 2015, respectively and was $13.4 billion and $12.5 billion for the six months ended January 23, 2016 and January 24, 2015, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion as of each of January 23, 2016 and July 25, 2015, respectively.

- changed (2016-05-24):
[0000858877-16-000109:note_history:12]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $18 million and $22 million for the three months ended April 30, 2016 and April 25, 2015, respectively, and was $57 million and $87 million for the nine months ended April 30, 2016 and April 25, 2015, respectively.
  (was, 2016-02-18, similarity 0.8897):
[0000858877-16-000090:note_history:12]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $16 million and $39 million for the three months ended January 23, 2016 and January 24, 2015, respectively, and was $39 million and $65 million for the six months ended January 23, 2016 and January 24, 2015, respectively.

- changed (2016-05-24):
[0000858877-16-000109:note_history:13]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 30, 2016 and July 25, 2015, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2016-02-18, similarity 0.9807):
[0000858877-16-000090:note_history:13]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 23, 2016 and July 25, 2015, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- added (2016-05-24):
[0000858877-16-000109:note_history:14]
|  | April 30, 2016 |  | July 25, 2015 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 228 |  |  | $ | 288 |  |
| End user | 104 |  |  | 129 |  |
| Total | $ | 332 |  |  | $ | 417 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (98 | ) |  | $ | (127 | ) |
| End user | (82 | ) |  | (107 | ) |
| Total | $ | (180 | ) |  | $ | (234 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 152 |  |  | $ | 183 |  |

- changed (2016-05-24):
[0000858877-16-000109:note_history:15]
Other Guarantees   The Company’s other guarantee arrangements as of April 30, 2016 and July 25, 2015 that were subject to recognition and disclosure requirements were not material.
  (was, 2016-02-18, similarity 0.9763):
[0000858877-16-000090:note_history:15]
Other Guarantees   The Company’s other guarantee arrangements as of January 23, 2016 and July 25, 2015 that were subject to recognition and disclosure requirements were not material.

- changed (2016-05-24):
[0000858877-16-000109:note_history:16]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components were widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event. Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products was beyond the Company's warranty terms, the Company has been proactively working with customers on mitigation. Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014. During the third quarters of fiscal 2016 and 2015, adjustments to product cost of sales of $74 million and $164 million, respectively, were recorded to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products. The supplier component remediation liability as of April 30, 2016 and July 25, 2015 was $286 million and $408 million, respectively.
  (was, 2016-02-18, similarity 0.8478):
[0000858877-16-000090:note_history:16]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components were widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event. Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products was beyond the Company's warranty terms, the Company has been proactively working with customers on mitigation. Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014. During the third quarter of fiscal 2015, an adjustment to product cost of sales of $164 million was recorded to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products. The supplier component remediation liability as of January 23, 2016 and July 25, 2015 was $375 million and $408 million, respectively.

- added (2016-05-24):
[0000858877-16-000109:note_history:17]
The Company is providing such indemnifications, among other cases, in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) now pending in Kansas and Delaware. Sprint alleges that the service provider customers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers. Sprint seeks monetary damages. Sprint’s cases in Kansas include claims against Comcast and Time Warner Cable, and the case in Delaware for which the Company is providing indemnification involves Cox Communications. On May 15, 2015, the judge in Sprint's Delaware action against Cox ruled invalid six of the asserted patents and a final judgment was entered on August 27, 2015, of invalidity, which Sprint appealed on October 1, 2015. In light of the invalidity rulings against Sprint in Delaware, the judge in Sprint’s Kansas actions stayed the Kansas actions until resolution of Sprint's appeal from the Delaware action. On March 21, 2016, the judge in Sprint's Delaware action also granted a partial summary judgment for Cox, finding that Cox does not literally infringe five of the remaining patents Sprint has asserted against Cox.  Additionally, Comcast has also won a judgment of non-infringement, now being appealed by Sprint, in a separate case brought against it by Sprint in Delaware.

- changed (2016-05-24):
[0000858877-16-000109:note_history:18]
The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims and/or that Sprint's patents are invalid. Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. Should the plaintiff prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.
  (was, 2016-02-18, similarity 0.9992):
[0000858877-16-000090:note_history:18]
The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims and/or that Sprint's patents are invalid. Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. Should the plaintiff prevail in litigation, mediation, or settlement, the Company, in accordance with its agreement, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

- changed (2016-05-24):
[0000858877-16-000109:note_history:19]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. In the first quarter of fiscal 2013, the Brazilian federal tax authorities asserted an additional claim against the Company’s Brazilian subsidiary based on a theory of joint liability with respect to an alleged underpayment of income taxes, social taxes, interest, and penalties by a Brazilian distributor.  This claim was dismissed on its merits during the third quarter of fiscal 2016.
  (was, 2016-02-18, similarity 0.9657):
[0000858877-16-000090:note_history:19]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. In the first quarter of fiscal 2013, the Brazilian federal tax authorities asserted an additional claim against the Company’s Brazilian subsidiary based on a theory of joint liability with respect to an alleged underpayment of income taxes, social taxes, interest, and penalties by a Brazilian distributor.

- changed (2016-05-24):
[0000858877-16-000109:note_history:20]
The asserted claims by Brazilian federal tax authorities which remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $233 million for the alleged evasion of import and other taxes, $1.2 billion for interest, and $1.1 billion for various penalties, all determined using an exchange rate as of April 30, 2016. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.
  (was, 2016-02-18, similarity 0.9875):
[0000858877-16-000090:note_history:20]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $209 million for the alleged evasion of import and other taxes, $942 million for interest, and $929 million for various penalties, all determined using an exchange rate as of January 23, 2016. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

- changed (2016-05-24):
[0000858877-16-000109:note_history:21]
Russia and the Commonwealth of Independent States    At the request of the U.S. Securities and Exchange Commission ("SEC") and the U.S. Department of Justice, the Company is conducting an investigation into allegations which the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries. The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the SEC and the Department of Justice. While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows. The countries that are the subject of the investigation collectively comprise less than 2% of the Company’s revenues.
  (was, 2016-02-18, similarity 0.9919):
[0000858877-16-000090:note_history:21]
Russia and the Commonwealth of Independent States    At the request of the U.S. Securities and Exchange Commission (SEC) and the U.S. Department of Justice, the Company is conducting an investigation into allegations that the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries. The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the SEC and the Department of Justice. While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows. The countries that are the subject of the investigation collectively comprise less than 2% of the Company’s revenues.

- added (2016-05-24):
[0000858877-16-000109:note_history:22]
Backflip Software     Backflip Software, Inc. (“Backflip”) has asserted contract, tort, and fraud claims against the Company in Santa Clara County, California Superior Court. The proceeding was instituted on March 5, 2013. Backflip alleges that Cisco conspired with Backflip's then-CEO to allow the Company to access and use Backflip's source code via a pre-existing source code escrow agreement, and that, subsequently, the Company used that source code in violation of trade secret law and the parties' software license agreement. Backflip has also sued the escrow company, NCC Group, Inc., for breach of contract based on the same allegations. Backflip seeks compensatory and punitive damages. Trial is set for September 12, 2016. The Company believes that it has strong arguments that it was entitled to the source code under the parties’ software license agreement. In addition, if the jury were to find for Backflip on some or all of its claims, the Company believes that damages would not be material given the minimal value of Backflip and its intellectual property that the Company is alleged to have misappropriated. However, due to the uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

- added (2016-05-24):
[0000858877-16-000109:note_history:23]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against the Company in the U.S. District Court for the District of Delaware, accusing Cisco products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and on May 12, 2016 the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million and the Court will decide whether to award enhanced damages and attorneys’ fees and whether an ongoing royalty should be awarded through the expiration of the patents in 2018. In June 2016, the Company plans to file post-trial motions and the Company also intends to pursue an appeal to the United States Court of Appeals for the Federal Circuit on various grounds. The Company believes it has strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, the Company does not expect it to be material.

- added (2016-05-24):
[0000858877-16-000109:note_history:24]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas.  The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. A trial is set for September 6, 2016. The Company believes it has strong arguments that its products do not infringe and the patent is invalid. If a jury were to find that the Company's AnyConnect products infringe and the patent is not invalid, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding the litigation process, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. The Company also notes that on February 23, 2016, a multi-judge panel of the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office instituted proceedings to review whether the patent SSL has asserted against the Company is valid over prior art. The PTAB found a reasonable likelihood that the Company would prevail in showing that the patent claims are unpatentable. The PTAB has scheduled the hearing on the Company's review petition for November 16, 2016.

- added (2016-05-24):
[0000858877-16-000109:note_history:25]
Kangtega     Cisco Systems GmbH (“Cisco GmbH”) is subject to patent claims by Kangtega GmbH (“Kangtega”), instituted on June 6, 2013, alleging that Cisco GmbH infringes in Germany a European Patent by marketing, in Germany, network intrusion-detection, or firewall, products known as the “ASA” firewall offering. On April 29, 2014, the Mannheim Regional Court dismissed the infringement action finding no infringement by Cisco GmbH of the asserted patent. On July 13, 2016, a court of appeal in Germany (Oberlandesgericht Karlsruhe) will hear an appeal of that judgment.  Kangtega seeks an injunction which would prohibit Cisco GmbH’s activities in Germany with respect to the ASA firewall offering unless Cisco GmbH takes a license from Kangtega or the Company redesigns the products.  The Company believes that the lower court ruling was correct and should be affirmed.  The Company does not anticipate that the outcome of the case would be material. However, due to uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the outcome of the appeal and any subsequent appeals to a higher court at this time.

- added (2016-05-24):
[0000858877-16-000109:note_history:26]
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows.

- removed (2016-05-24):
[0000858877-16-000090:note_history:27]
|  | January 23, 2016 |  | July 25, 2015 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 244 |  |  | $ | 288 |  |
| End user | 113 |  |  | 129 |  |
| Total | $ | 357 |  |  | $ | 417 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (100 | ) |  | $ | (127 | ) |
| End user | (90 | ) |  | (107 | ) |
| Total | $ | (190 | ) |  | $ | (234 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 167 |  |  | $ | 183 |  |

- removed (2016-05-24):
[0000858877-16-000090:note_history:28]
The Company is providing such indemnifications, among other cases, in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) now pending in Kansas and Delaware. Sprint alleges that the service provider customers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers. Sprint seeks monetary damages. Sprint’s cases in Kansas include claims against Comcast and Time Warner Cable, and the case in Delaware for which the Company is providing indemnification involves Cox Communications. At the request of Sprint and Comcast, on August 5, 2015, the judge in Sprint’s Kansas action ordered a six-month stay of the patent litigation between those parties for them to pursue a resolution of their dispute. In addition, on May 15, 2015, the judge in Sprint's Delaware action against Cox ruled invalid six of the patents that Sprint asserted Cox had infringed and a final judgment was entered on August 27, 2015, of invalidity, which Sprint appealed on October 1, 2015. In May 2015 the Company filed two declaratory judgment actions against Sprint seeking declarations that the patents Sprint asserted against the Company’s customers are invalid and/or not infringed. Cox has filed a motion for summary judgment of non-infringement for the five remaining Sprint patents that are actively being litigated against Cox in Delaware, and Comcast has also won a judgment of non-infringement, now being appealed by Sprint, in a separate case brought against it by Sprint in Delaware. In light of the invalidity rulings against Sprint in Delaware, on October 8, 2015, the judge in Sprint’s Kansas actions ordered an additional stay of Sprint’s Kansas actions including the case against Time Warner Cable, pending resolution of Sprint’s appeal of the Delaware Judge’s judgment of invalidity in the Cox case.

- removed (2016-05-24):
[0000858877-16-000090:note_history:29]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-05-24):
[0000858877-16-000109:note_history:30]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2016 is a 53-week fiscal year, and fiscal 2015 was a 52-week fiscal year. The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated. The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).
  (was, 2016-02-18, similarity 0.9991):
[0000858877-16-000090:note_history:30]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2016 is a 53-week fiscal year and fiscal 2015 was a 52-week fiscal year. The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated. The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

- changed (2016-05-24):
[0000858877-16-000109:note_history:31]
The accompanying financial data as of April 30, 2016 and for the three and nine months ended April 30, 2016 and April 25, 2015 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations.  The July 25, 2015 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 25, 2015.
  (was, 2016-02-18, similarity 0.966):
[0000858877-16-000090:note_history:31]
The accompanying financial data as of January 23, 2016 and for the three and six months ended January 23, 2016 and January 24, 2015 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations.  The July 25, 2015 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 25, 2015.

- changed (2016-05-24):
[0000858877-16-000109:note_history:32]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of April 30, 2016; the results of operations and the statements of comprehensive income for the three and nine months ended April 30, 2016 and April 25, 2015; and the statements of cash flows and equity for the nine months ended April 30, 2016 and April 25, 2015, as applicable, have been made. The results of operations for the three and nine months ended April 30, 2016 are not necessarily indicative of the operating results for the full fiscal year or any future periods.
  (was, 2016-02-18, similarity 0.8143):
[0000858877-16-000090:note_history:32]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 23, 2016; the results of operations and the statements of comprehensive income for the three and six months ended January 23, 2016 and January 24, 2015; and the statements of cash flows and equity for the six months ended January 23, 2016 and January 24, 2015, as applicable, have been made. The results of operations for the three and six months ended January 23, 2016 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-05-24):
[0000858877-16-000109:note_history:33]
Recent Accounting Standards or Updates Not Yet Effective

- changed (2016-05-24):
[0000858877-16-000109:note_history:34]
Revenue Recognition  In May 2014, the Financial Accounting Standards Board (FASB) issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance. The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. This accounting standard update, as amended, will be effective for the Company beginning in the first quarter of fiscal 2019. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. Early adoption is permitted, but no earlier than fiscal 2018. The Company expects to adopt this accounting standard update in the first quarter of fiscal 2019, and it is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.
  (was, 2016-02-18, similarity 0.8849):
[0000858877-16-000090:note_history:34]
Recent Accounting Standards or Updates Not Yet Effective  In May 2014, the Financial Accounting Standards Board (FASB) issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance. The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. This accounting standard update, as amended, will be effective for the Company beginning in the first quarter of fiscal 2019. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. Early adoption is permitted, but no earlier than fiscal 2018. The Company is currently evaluating the timing of its adoption and impact of this accounting standard update on its Consolidated Financial Statements.

- changed (2016-05-24):
[0000858877-16-000109:note_history:35]
Consolidation of Certain Types of Legal Entities  In February 2015, the FASB issued an accounting standard update that changes the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2017, and early adoption is permitted. The application of this accounting standard update is not expected to have a material impact on the Company's Consolidated Financial Statements.
  (was, 2016-02-18, similarity 0.7651):
[0000858877-16-000090:note_history:35]
In February 2015, the FASB issued an accounting standard update that changes the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2017, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- changed (2016-05-24):
[0000858877-16-000109:note_history:36]
Classification of Deferred Taxes  In November 2015, the FASB issued an accounting standard update that requires that all deferred tax assets and liabilities, along with any related valuation allowance, be classified as noncurrent on the balance sheet. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2018, and early adoption is permitted. The accounting standard update is a change in balance sheet presentation only.
  (was, 2016-02-18, similarity 0.9633):
[0000858877-16-000090:note_history:36]
In November 2015, the FASB issued an accounting standard update that requires that all deferred tax assets and liabilities, along with any related valuation allowance, be classified as noncurrent on the balance sheet. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2018, and early adoption is permitted. The accounting standard update is a change in balance sheet presentation only.

- changed (2016-05-24):
[0000858877-16-000109:note_history:37]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments.  The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.
  (was, 2016-02-18, similarity 0.9786):
[0000858877-16-000090:note_history:37]
In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments.  The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- added (2016-05-24):
[0000858877-16-000109:note_history:38]
Leases  In February 2016, the FASB issued an accounting standard update related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets.  The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2020 on a modified retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- added (2016-05-24):
[0000858877-16-000109:note_history:39]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows.  The accounting standard will be effective for the Company beginning the first quarter of fiscal 2018, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-24):
[0000858877-16-000109:note_history:40]
|  | April 30, 2016 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,163 |  |  | 0.94 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other short-term debt | 1 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total | $ | 4,164 |  |  |  |  | $ | 3,897 |  |  |  |
  (was, 2016-02-18, similarity 0.9779):
[0000858877-16-000090:note_history:40]
|  | January 23, 2016 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 3,006 |  |  | 3.12 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other short-term debt | 2 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total | $ | 3,008 |  |  |  |  | $ | 3,897 |  |  |  |

- changed (2016-05-24):
[0000858877-16-000109:note_history:41]
On September 3, 2015, the Company repaid an aggregate principal amount of $850 million upon the maturity of its 2015 Floating-Rate Notes.  On February 22, 2016, the Company repaid an aggregate principal amount of $3.0 billion upon the maturity of its 2016 Fixed Rate Notes.
  (was, 2016-02-18, similarity 0.672):
[0000858877-16-000090:note_history:41]
On September 3, 2015, the Company repaid an aggregate principal amount of $850 million upon the maturity of its 2015 Floating-Rate Notes.

- changed (2016-05-24):
[0000858877-16-000109:note_history:42]
The Company has established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had no commercial paper notes outstanding as of each of April 30, 2016 and July 25, 2015.
  (was, 2016-02-18, similarity 0.8769):
[0000858877-16-000090:note_history:42]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had no commercial paper notes outstanding as of each of January 23, 2016 and July 25, 2015.

- changed (2016-05-24):
[0000858877-16-000109:note_history:43]
|  |  |  | April 30, 2016 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.98% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.60% | February 21, 2018 | (1) | 1,000 |  |  | 1.30% |  | — |  |  | — |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.01% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.20% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | — |  |  | — |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.84% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.20% |  | 750 |  |  | 0.85% |
| 1.40% | February 28, 2018 | (1) | 1,250 |  |  | 1.47% |  | — |  |  | — |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.76% |  | 2,000 |  |  | 4.70% |
| 1.60% | February 28, 2019 | (1) | 1,000 |  |  | 1.67% |  | — |  |  | — |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.05% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.21% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 | (1) | 2,500 |  |  | 2.30% |  | — |  |  | — |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.21% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.46% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 | (1) | 500 |  |  | 2.68% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.33% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.62% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 | (1) | 750 |  |  | 3.01% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  |  |  | 1 |  |  | 2.08% |
| Total |  |  | 28,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (141 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 335 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 28,594 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,163 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 24,431 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 28,594 |  |  |  |  | $ | 25,351 |  |  |  |
  (was, 2016-02-18, similarity 0.8371):
[0000858877-16-000090:note_history:43]
|  |  |  | January 23, 2016 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.77% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 0.89% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.97% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.12% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.83% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.07% |  | 750 |  |  | 0.85% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.76% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.04% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.20% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.20% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.45% |  | 500 |  |  | 1.21% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.32% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.61% |  | 500 |  |  | 1.37% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  |  |  | 1 |  |  | 2.08% |
| Total |  |  | 24,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (123 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 320 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 24,597 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,006 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 21,591 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 24,597 |  |  |  |  | $ | 25,351 |  |  |  |

- added (2016-05-24):
[0000858877-16-000109:note_history:44]
(1) In February 2016, the Company issued senior notes for an aggregate principal amount of $7.0 billion.

- changed (2016-05-24):
[0000858877-16-000109:note_history:45]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 30, 2016, the Company was in compliance with all debt covenants.
  (was, 2016-02-18, similarity 0.9781):
[0000858877-16-000090:note_history:45]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 23, 2016, the Company was in compliance with all debt covenants.

- changed (2016-05-24):
[0000858877-16-000109:note_history:46]
As of April 30, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2016-02-18, similarity 0.9701):
[0000858877-16-000090:note_history:46]
As of January 23, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2016-05-24):
[0000858877-16-000109:note_history:47]
| Fiscal Year | Amount |
| 2016 (remaining three months) | $ | — |  |
| 2017 | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 10,250 |  |
| Total | $ | 28,400 |  |
  (was, 2016-02-18, similarity 0.9673):
[0000858877-16-000090:note_history:47]
| Fiscal Year | Amount |
| 2016 (remaining six months) | $ | 3,000 |  |
| 2017 | 4,150 |  |
| 2018 | 2,500 |  |
| 2019 | 4,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 6,500 |  |
| Total | $ | 24,400 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-24):
[0000858877-16-000109:note_history:48]
| April 30, 2016 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 24,003 |  |  | $ | 44 |  |  | $ | (3 | ) |  | $ | 24,044 |  |
| U.S. government agency securities | 2,883 |  |  | 5 |  |  | — |  |  | 2,888 |  |
| Non-U.S. government and agency securities | 1,063 |  |  | 2 |  |  | — |  |  | 1,065 |  |
| Corporate debt securities | 23,193 |  |  | 160 |  |  | (37 | ) |  | 23,316 |  |
| U.S. agency mortgage-backed securities | 1,746 |  |  | 16 |  |  | — |  |  | 1,762 |  |
| Total fixed income securities | 52,888 |  |  | 227 |  |  | (40 | ) |  | 53,075 |  |
| Publicly traded equity securities | 1,354 |  |  | 218 |  |  | (30 | ) |  | 1,542 |  |
| Total | $ | 54,242 |  |  | $ | 445 |  |  | $ | (70 | ) |  | $ | 54,617 |  |
  (was, 2016-02-18, similarity 0.6233):
[0000858877-16-000090:note_history:48]
| January 23, 2016 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 28,242 |  |  | $ | 18 |  |  | $ | (16 | ) |  | $ | 28,244 |  |
| U.S. government agency securities | 3,492 |  |  | 3 |  |  | (2 | ) |  | 3,493 |  |
| Non-U.S. government and agency securities | 1,152 |  |  | 1 |  |  | (1 | ) |  | 1,152 |  |
| Corporate debt securities | 18,410 |  |  | 29 |  |  | (158 | ) |  | 18,281 |  |
| U.S. agency mortgage-backed securities | 1,452 |  |  | 9 |  |  | (1 | ) |  | 1,460 |  |
| Total fixed income securities | 52,748 |  |  | 60 |  |  | (178 | ) |  | 52,630 |  |
| Publicly traded equity securities | 1,318 |  |  | 176 |  |  | (63 | ) |  | 1,431 |  |
| Total | $ | 54,066 |  |  | $ | 236 |  |  | $ | (241 | ) |  | $ | 54,061 |  |

- changed (2016-05-24):
[0000858877-16-000109:note_history:49]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Gross realized gains | $ | 68 |  |  | $ | 55 |  |  | $ | 119 |  |  | $ | 168 |  |
| Gross realized losses | (74 | ) |  | (11 | ) |  | (145 | ) |  | (48 | ) |
| Total | $ | (6 | ) |  | $ | 44 |  |  | $ | (26 | ) |  | $ | 120 |  |
  (was, 2016-02-18, similarity 0.8266):
[0000858877-16-000090:note_history:49]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Gross realized gains | $ | 16 |  |  | $ | 92 |  |  | $ | 51 |  |  | $ | 113 |  |
| Gross realized losses | (35 | ) |  | (23 | ) |  | (71 | ) |  | (37 | ) |
| Total | $ | (19 | ) |  | $ | 69 |  |  | $ | (20 | ) |  | $ | 76 |  |

- added (2016-05-24):
[0000858877-16-000109:note_history:50]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Net gains/(losses) on investments in publicly traded equity securities | $ | 25 |  |  | $ | 38 |  |  | $ | 18 |  |  | $ | 94 |  |
| Net gains/(losses) on investments in fixed income securities | (31 | ) |  | 6 |  |  | (44 | ) |  | 26 |  |
| Total | $ | (6 | ) |  | $ | 44 |  |  | $ | (26 | ) |  | $ | 120 |  |

- changed (2016-05-24):
[0000858877-16-000109:note_history:51]
For the three and nine months ended April 30, 2016, the realized net losses related to the Company's available-for-sale investments included impairment charges of zero and $3 million, respectively, for fixed income securities. The impairment charges were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the corresponding periods in fiscal 2015.
  (was, 2016-02-18, similarity 0.831):
[0000858877-16-000090:note_history:51]
For the three and six months ended January 23, 2016, the realized net losses related to the Company's available-for-sale investments included impairment charges of $3 million for fixed income securities, due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the corresponding periods in fiscal 2015.

- changed (2016-05-24):
[0000858877-16-000109:note_history:52]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at April 30, 2016 and July 25, 2015 (in millions):
  (was, 2016-02-18, similarity 0.9709):
[0000858877-16-000090:note_history:52]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at January 23, 2016 and July 25, 2015 (in millions):

- changed (2016-05-24):
[0000858877-16-000109:note_history:53]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 30, 2016 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 4,315 |  |  | $ | (3 | ) |  | $ | — |  |  | $ | — |  |  | $ | 4,315 |  |  | $ | (3 | ) |
| U.S. government agency securities | 287 |  |  | — |  |  | — |  |  | — |  |  | 287 |  |  | — |  |
| Non-U.S. government and agency securities | 192 |  |  | — |  |  | — |  |  | — |  |  | 192 |  |  | — |  |
| Corporate debt securities | 5,145 |  |  | (27 | ) |  | 1,089 |  |  | (10 | ) |  | 6,234 |  |  | (37 | ) |
| U.S. agency mortgage-backed securities | 137 |  |  | — |  |  | 18 |  |  | — |  |  | 155 |  |  | — |  |
| Total fixed income securities | 10,076 |  |  | (30 | ) |  | 1,107 |  |  | (10 | ) |  | 11,183 |  |  | (40 | ) |
| Publicly traded equity securities | 320 |  |  | (30 | ) |  | — |  |  | — |  |  | 320 |  |  | (30 | ) |
| Total | $ | 10,396 |  |  | $ | (60 | ) |  | $ | 1,107 |  |  | $ | (10 | ) |  | $ | 11,503 |  |  | $ | (70 | ) |
  (was, 2016-02-18, similarity 0.7103):
[0000858877-16-000090:note_history:53]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 23, 2016 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 15,432 |  |  | $ | (16 | ) |  | $ | 3 |  |  | $ | — |  |  | $ | 15,435 |  |  | $ | (16 | ) |
| U.S. government agency securities | 1,793 |  |  | (2 | ) |  | — |  |  | — |  |  | 1,793 |  |  | (2 | ) |
| Non-U.S. government and agency securities | 645 |  |  | (1 | ) |  | 17 |  |  | — |  |  | 662 |  |  | (1 | ) |
| Corporate debt securities | 11,565 |  |  | (136 | ) |  | 1,252 |  |  | (22 | ) |  | 12,817 |  |  | (158 | ) |
| U.S. agency mortgage-backed securities | 387 |  |  | (1 | ) |  | — |  |  | — |  |  | 387 |  |  | (1 | ) |
| Total fixed income securities | 29,822 |  |  | (156 | ) |  | 1,272 |  |  | (22 | ) |  | 31,094 |  |  | (178 | ) |
| Publicly traded equity securities | 694 |  |  | (62 | ) |  | 2 |  |  | (1 | ) |  | 696 |  |  | (63 | ) |
| Total | $ | 30,516 |  |  | $ | (218 | ) |  | $ | 1,274 |  |  | $ | (23 | ) |  | $ | 31,790 |  |  | $ | (241 | ) |

- added (2016-05-24):
[0000858877-16-000109:note_history:54]
As of April 30, 2016, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of April 30, 2016, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the nine months ended April 30, 2016.

- changed (2016-05-24):
[0000858877-16-000109:note_history:55]
The Company has evaluated its publicly traded equity securities as of April 30, 2016 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.
  (was, 2016-02-18, similarity 0.9899):
[0000858877-16-000090:note_history:55]
The Company has evaluated its publicly traded equity securities as of January 23, 2016 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

- changed (2016-05-24):
[0000858877-16-000109:note_history:56]
The following table summarizes the maturities of the Company’s fixed income securities as of April 30, 2016 (in millions):
  (was, 2016-02-18, similarity 0.9442):
[0000858877-16-000090:note_history:56]
The following table summarizes the maturities of the Company’s fixed income securities at January 23, 2016 (in millions):

- changed (2016-05-24):
[0000858877-16-000109:note_history:57]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 30, 2016 and April 25, 2015 was $0.9 billion and $0.5 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of April 30, 2016 and July 25, 2015, the Company had no outstanding securities lending transactions.
  (was, 2016-02-18, similarity 0.9421):
[0000858877-16-000090:note_history:57]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for each of the six months ended January 23, 2016 and January 24, 2015 was $0.6 billion. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 23, 2016 and July 25, 2015, the Company had no outstanding securities lending transactions.

- changed (2016-05-24):
[0000858877-16-000109:note_history:58]
The carrying value of the Company’s investments in privately held companies was included in other assets.  For such investments that were accounted for under the equity and cost method as of April 30, 2016 and July 25, 2015, the amounts are summarized in the following table (in millions):
  (was, 2016-02-18, similarity 0.9784):
[0000858877-16-000090:note_history:58]
The carrying value of the Company’s investments in privately held companies was included in other assets.  For such investments that were accounted for under the equity and cost method as of January 23, 2016 and July 25, 2015, the amounts are summarized in the following table (in millions):

- changed (2016-05-24):
[0000858877-16-000109:note_history:59]
|  | April 30, 2016 |  | July 25, 2015 |
| Equity method investments | $ | 609 |  |  | $ | 578 |  |
| Cost method investments | 367 |  |  | 319 |  |
| Total | $ | 976 |  |  | $ | 897 |  |
  (was, 2016-02-18, similarity 0.9742):
[0000858877-16-000090:note_history:59]
|  | January 23, 2016 |  | July 25, 2015 |
| Equity method investments | $ | 605 |  |  | $ | 578 |  |
| Cost method investments | 359 |  |  | 319 |  |
| Total | $ | 964 |  |  | $ | 897 |  |

- changed (2016-05-24):
[0000858877-16-000109:note_history:60]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings and has determined that as of April 30, 2016, except as disclosed herein, there were no variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.
  (was, 2016-02-18, similarity 0.9895):
[0000858877-16-000090:note_history:60]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings and has determined that as of January 23, 2016, except as disclosed herein, there were no variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

- removed (2016-05-24):
[0000858877-16-000090:note_history:61]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Net gains/(losses) on investments in publicly traded equity securities | $ | 2 |  |  | $ | 60 |  |  | $ | (7 | ) |  | $ | 56 |  |
| Net gains/(losses) on investments in fixed income securities | (21 | ) |  | 9 |  |  | (13 | ) |  | 20 |  |
| Total | $ | (19 | ) |  | $ | 69 |  |  | $ | (20 | ) |  | $ | 76 |  |

- removed (2016-05-24):
[0000858877-16-000090:note_history:62]
As of January 23, 2016, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of January 23, 2016, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the six months ended January 23, 2016.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-24):
[0000858877-16-000109:note_history:63]
|  |  |  | April 30, 2016 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.98% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.60% | February 21, 2018 | (1) | 1,000 |  |  | 1.30% |  | — |  |  | — |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.01% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.20% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | — |  |  | — |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.84% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.20% |  | 750 |  |  | 0.85% |
| 1.40% | February 28, 2018 | (1) | 1,250 |  |  | 1.47% |  | — |  |  | — |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.76% |  | 2,000 |  |  | 4.70% |
| 1.60% | February 28, 2019 | (1) | 1,000 |  |  | 1.67% |  | — |  |  | — |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.05% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.21% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 | (1) | 2,500 |  |  | 2.30% |  | — |  |  | — |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.21% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.46% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 | (1) | 500 |  |  | 2.68% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.33% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.62% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 | (1) | 750 |  |  | 3.01% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  |  |  | 1 |  |  | 2.08% |
| Total |  |  | 28,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (141 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 335 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 28,594 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,163 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 24,431 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 28,594 |  |  |  |  | $ | 25,351 |  |  |  |
  (was, 2016-02-18, similarity 0.8371):
[0000858877-16-000090:note_history:63]
|  |  |  | January 23, 2016 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.77% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 0.89% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.97% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.12% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.83% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.07% |  | 750 |  |  | 0.85% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.76% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.04% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.20% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.20% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.45% |  | 500 |  |  | 1.21% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.32% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.61% |  | 500 |  |  | 1.37% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  |  |  | 1 |  |  | 2.08% |
| Total |  |  | 24,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (123 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 320 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 24,597 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,006 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 21,591 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 24,597 |  |  |  |  | $ | 25,351 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-24):
[0000858877-16-000109:note_history:64]
As of April 30, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2016-02-18, similarity 0.9701):
[0000858877-16-000090:note_history:64]
As of January 23, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2016-05-24):
[0000858877-16-000109:note_history:65]
| Fiscal Year | Amount |
| 2016 (remaining three months) | $ | — |  |
| 2017 | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 10,250 |  |
| Total | $ | 28,400 |  |
  (was, 2016-02-18, similarity 0.9673):
[0000858877-16-000090:note_history:65]
| Fiscal Year | Amount |
| 2016 (remaining six months) | $ | 3,000 |  |
| 2017 | 4,150 |  |
| 2018 | 2,500 |  |
| 2019 | 4,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 6,500 |  |
| Total | $ | 24,400 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-24):
[0000858877-16-000109:note_history:66]
|  | April 30, 2016 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,163 |  |  | 0.94 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other short-term debt | 1 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total | $ | 4,164 |  |  |  |  | $ | 3,897 |  |  |  |
  (was, 2016-02-18, similarity 0.9779):
[0000858877-16-000090:note_history:66]
|  | January 23, 2016 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 3,006 |  |  | 3.12 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other short-term debt | 2 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total | $ | 3,008 |  |  |  |  | $ | 3,897 |  |  |  |
