# CSCO 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0000858877-16-000117:item_9a:1]
| Item 9A. | Controls and Procedures |

[0000858877-16-000117:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000858877-16-000117:item_9a:3]
Based on our management’s evaluation (with the participation of our principal executive officer and principal financial officer), as of the end of the period covered by this report, our principal executive officer and principal financial officer have concluded that our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended, (the “Exchange Act”)) are effective to ensure that information required to be disclosed by us in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in Securities and Exchange Commission rules and forms and is accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000858877-16-000117:item_9a:4]
Internal Control over Financial Reporting

[0000858877-16-000117:item_9a:5]
Management’s report on our internal control over financial reporting and the report of our independent registered public accounting firm on our internal control over financial reporting are set forth, respectively, on page 69 under the caption “Management’s Report on Internal Control Over Financial Reporting” and on page 68 of this report.

[0000858877-16-000117:item_9a:6]
There was no change in our internal control over financial reporting during our fourth quarter of fiscal 2016 that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.
