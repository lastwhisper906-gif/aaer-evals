# CSCO MD&A — 0000858877-16-000117


## mdna

[0000858877-16-000117:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000858877-16-000117:mdna:2]
Forward-Looking Statements

[0000858877-16-000117:mdna:3]
OVERVIEW

[0000858877-16-000117:mdna:4]
Cisco designs and sells broad lines of products, provides services and delivers integrated solutions to develop and connect networks around the world. For over 30 years, we have helped our customers build networks and automate, orchestrate, integrate, and digitize information technology (IT)–based products and services. In an increasingly connected world, Cisco is helping to transform businesses, governments and cities worldwide. Over time, we have expanded to new markets that are a natural extension of our core networking business, as the network has become the platform for delivering an ever-increasing portfolio of IT–based products and services.

[0000858877-16-000117:mdna:5]
A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-16-000117:mdna:6]
|  | Three Months Ended |  | Years Ended |  |
|  | July 30, 2016 |  | July 25, 2015 |  | Variance |  | July 30, 2016 |  | July 25, 2015 |  | Variance |  |
| Revenue (1) | $ | 12,638 |  |  | $ | 12,843 |  |  | (1.6 | )% |  | $ | 49,247 |  |  | $ | 49,161 |  |  | 0.2 | % |  |
| Gross margin percentage | 63.1 | % |  | 60.2 | % |  | 2.9 |  | pts | 62.9 | % |  | 60.4 | % |  | 2.5 |  | pts |
| Research and development | $ | 1,601 |  |  | $ | 1,548 |  |  | 3.4 | % |  | $ | 6,296 |  |  | $ | 6,207 |  |  | 1.4 | % |  |
| Sales and marketing | $ | 2,443 |  |  | $ | 2,549 |  |  | (4.2 | )% |  | $ | 9,619 |  |  | $ | 9,821 |  |  | (2.1 | )% |  |
| General and administrative | $ | 533 |  |  | $ | 536 |  |  | (0.6 | )% |  | $ | 1,814 |  |  | $ | 2,040 |  |  | (11.1 | )% |  |
| Total R&D, sales and marketing, general and administrative | $ | 4,577 |  |  | $ | 4,633 |  |  | (1.2 | )% |  | $ | 17,729 |  |  | $ | 18,068 |  |  | (1.9 | )% |  |
| Total as a percentage of revenue | 36.2 | % |  | 36.1 | % |  | 0.1 |  | pts | 36.0 | % |  | 36.8 | % |  | (0.8 | ) | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 82 |  |  | $ | 146 |  |  | (43.8 | )% |  | $ | 303 |  |  | $ | 359 |  |  | (15.6 | )% |  |
| Restructuring and other charges included in operating expenses | $ | 13 |  |  | $ | 73 |  |  | (82.2 | )% |  | $ | 268 |  |  | $ | 484 |  |  | (44.6 | )% |  |
| Operating income as a percentage of revenue | 26.1 | % |  | 22.4 | % |  | 3.7 |  | pts | 25.7 | % |  | 21.9 | % |  | 3.8 |  | pts |
| Income tax percentage | 17.1 | % |  | 20.9 | % |  | (3.8 | ) | pts | 16.9 | % |  | 19.8 | % |  | (2.9 | ) | pts |
| Net income | $ | 2,813 |  |  | $ | 2,319 |  |  | 21.3 | % |  | $ | 10,739 |  |  | $ | 8,981 |  |  | 19.6 | % |  |
| Net income as a percentage of revenue | 22.3 | % |  | 18.1 | % |  | 4.2 |  | pts | 21.8 | % |  | 18.3 | % |  | 3.5 |  | pts |
| Earnings per share—diluted | $ | 0.56 |  |  | $ | 0.45 |  |  | 24.4 | % |  | $ | 2.11 |  |  | $ | 1.75 |  |  | 20.6 | % |  |

[0000858877-16-000117:mdna:7]
(1) During the second quarter of fiscal 2016, we completed the sale of the SP Video CPE Business. As a result, revenue from this portion of the Service Provider Video product category will not recur in future periods. The three months ended July 25, 2015 includes SP Video CPE Business revenue of $487 million. The years ended July 30, 2016 and July 25, 2015 include SP Video CPE Business revenue of $504 million and $1,846 million, respectively.

[0000858877-16-000117:mdna:8]
Fiscal 2016 Compared with Fiscal 2015—Financial Performance

[0000858877-16-000117:mdna:9]
For fiscal 2016, our total revenue was flat compared with fiscal 2015, as the service revenue increase of 5% was substantially offset by the product revenue decrease of 1%. In the second quarter of fiscal 2016, we completed the sale of our SP Video CPE Business. Total company revenue for fiscal 2016 increased 3% not including revenue from SP Video CPE products for all periods. Additionally, fiscal 2016 had 53 weeks, compared with 52 weeks in fiscal 2015, thus our results for fiscal 2016 reflect an extra week compared with fiscal 2015. We estimate that the additional revenue associated with the extra week was approximately $265 million, $200 million of which was from our services subscriptions, and $65 million from our software-as-a-service (SaaS) offerings such as WebEx, and a small amount from product distribution. Total gross margin increased by 2.5 percentage points, driven by productivity improvements, the sale of the lower margin SP Video CPE Business, and higher service gross margin. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 0.8 percentage points, driven in part by the $253 million pre-tax gain from the sale of the SP Video CPE Business. Operating income as a percentage of revenue increased by 3.8 percentage points, driven by the factors discussed above as well as a decrease in restructuring and other charges related to the restructuring action announced in August 2014. Diluted earnings per share increased by 21% from the prior year, as a result of both a 20% increase in net income and a decrease in diluted share count of 58 million shares.

[0000858877-16-000117:mdna:10]
Revenue from the Americas decreased by $244 million, driven by the sale of the SP Video CPE Business. Revenue for the Americas segment increased not including SP Video CPE products. EMEA revenue decreased by $41 million, led by a product revenue decline in Russia. Revenue in our APJC segment increased $371 million, led by product revenue growth in China. We saw improvements in our revenue from many emerging countries, and in particular we experienced product revenue growth in the emerging countries of China, India and Mexico of 22%, 18% and 3%, respectively. The “BRICM” countries experienced, in the aggregate, product revenue growth of 3%, despite decreased product revenue in Brazil and Russia of 34% and 31%, respectively.

[0000858877-16-000117:mdna:11]
From a customer market standpoint, in fiscal 2016 we experienced solid product revenue growth in the commercial market and, to a lesser extent, in the public sector and enterprise markets, while the service provider market declined. The decline in the service provider market was driven by the sale of the SP Video CPE Business.

[0000858877-16-000117:mdna:12]
From a product category perspective, total company product revenue, not including SP Video CPE products, increased 2% year over year. This increase was led by product revenue growth in Security and Collaboration which grew 13% and 9%, respectively. We also experienced a 12% increase in revenue from Service Provider Video products (not including the CPE Business for all periods), as well as Data Center and Wireless products which grew 5% and 3%, respectively.  Offsetting these increases was a 4% product revenue decrease in our NGN Routing category, driven primarily by a decrease in sales of our high-end router products. In addition, we believe a cautious service provider capital expenditure spending environment negatively impacted sales in this product category. Sales of our Switching products were flat due to higher sales of data center switches, flat sales of switches used in campus environments (which comprises the majority of this product category), and lower sales of storage products. We believe the flat sales of switches used in campus environments was largely driven by uncertainty in the macro environment, which led to a slowdown in customer spending.

[0000858877-16-000117:mdna:13]
Over this past fiscal year, we experienced a challenging environment with significant volatility and a highly competitive landscape. After three consecutive quarters of positive business momentum in both the service provider customer market and emerging countries in the aggregate, these areas experienced a decline in business momentum during the fourth quarter of fiscal 2016, while the remainder of the business performed well with positive business momentum.

[0000858877-16-000117:mdna:14]
In summary, for fiscal 2016 we experienced solid revenue growth in Security, Switching products used in data centers, Collaboration, and our Services categories. In addition, we continued to make progress in the transition of our business model to software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we have made solid progress over the past year in these priority areas. While the overall macro environment remains uncertain, we believe we are well positioned.  At the same time, we are aggressively investing in priority areas to drive growth over the long term regardless of the environment.

[0000858877-16-000117:mdna:15]
Fourth Quarter Snapshot

[0000858877-16-000117:mdna:16]
For the fourth quarter of fiscal 2016, as compared with the corresponding period in fiscal 2015, total revenue decreased by 2%. Within the total revenue, product revenue decreased 4% while service revenue increased by 5%. Total company revenue for the fourth quarter of fiscal 2016 increased 2% not including revenue from SP Video CPE products (which was sold on November 20, 2015) in the prior year period. With regard to our geographic segment performance, on a year-over-year basis, revenue in the Americas and APJC each decreased by 2%, while EMEA was flat. From a product category perspective, total company product revenue, not including SP Video CPE products in the prior year period, increased 1% year over year. This increase was driven by growth from Security products which grew 16% year over year. Total gross margin increased by 2.9 percentage points, as results for the fourth quarter of fiscal 2016 did not include the lower margin SP Video CPE Business. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively increased by 0.1 percentage points. Operating income as a percentage of revenue increased by 3.7 percentage points. Diluted earnings per share increased by 24% from the prior year, primarily as a result of both a 21% increase in net income and a decrease in our diluted share count by 64 million shares.

[0000858877-16-000117:mdna:17]
Strategy and Focus Areas

[0000858877-16-000117:mdna:18]
We see our customers increasingly using technology and, specifically, networks to grow their businesses, drive efficiencies, and try to gain a competitive advantage. In this increasingly digital world, we believe data is the most strategic asset and is increasingly distributed across every organization and ecosystem, on customer premises, at the edge of the network, and in the cloud. The network also plays an increasingly important role enabling our customers to aggregate, automate, and draw insights from this highly distributed data, where there is a premium on security and speed. We believe this is driving them to adopt entirely new IT architectures and organizational structures. We understand how technology can deliver the outcomes our customers want to achieve, and our strategy is to lead our customers in their digital transition with solutions including pervasive, industry-leading security that intelligently connects nearly everything that can be digitally connected.

[0000858877-16-000117:mdna:19]
To deliver on our strategy, we are focused on providing highly secure, automated and intelligent solutions built on infrastructure that connects highly distributed data that is globally dispersed across organizations. Together with our ecosystem of partners and developers, we will provide technology, services, and solutions we believe will enable our customers to gain insight and advantage from this distributed data with scale, security and agility.

[0000858877-16-000117:mdna:20]
For a full discussion of our strategy and focus areas, see Item 1. Business.

[0000858877-16-000117:mdna:21]
Other Key Financial Measures

[0000858877-16-000117:mdna:22]
The following is a summary of our other key financial measures for fiscal 2016 compared with fiscal 2015 (in millions, except days sales outstanding in accounts receivable (DSO) and annualized inventory turns):

[0000858877-16-000117:mdna:23]
|  |  | Fiscal 2016 |  | Fiscal 2015 |
| Cash and cash equivalents and investments |  | $65,756 |  | $60,416 |
| Cash provided by operating activities |  | $13,570 |  | $12,552 |
| Deferred revenue |  | $16,472 |  | $15,183 |
| Repurchases of common stock—stock repurchase program |  | $3,918 |  | $4,234 |
| Dividends |  | $4,750 |  | $4,086 |
| DSO |  | 42 days |  | 38 days |
| Inventories |  | $1,217 |  | $1,627 |
| Annualized inventory turns |  | 14.6 |  | 12.1 |

[0000858877-16-000117:mdna:24]
38

[0000858877-16-000117:mdna:25]
CRITICAL ACCOUNTING ESTIMATES

[0000858877-16-000117:mdna:26]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-16-000117:mdna:27]
Revenue Recognition

[0000858877-16-000117:mdna:28]
Revenue is recognized when all of the following criteria have been met:

[0000858877-16-000117:mdna:29]
| • | Persuasive evidence of an arrangement exists. Contracts, Internet commerce agreements, and customer purchase orders are generally used to determine the existence of an arrangement. |

[0000858877-16-000117:mdna:30]
| • | Delivery has occurred. Shipping documents and customer acceptance, when applicable, are used to verify delivery. For software, delivery is considered to have occurred upon unrestricted license access and license term commencement, when applicable. |

[0000858877-16-000117:mdna:31]
| • | The fee is fixed or determinable. We assess whether the fee is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. |

[0000858877-16-000117:mdna:32]
| • | Collectibility is reasonably assured. We assess collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer’s payment history. |

[0000858877-16-000117:mdna:33]
In instances where final acceptance of the product, system, or solution is specified by the customer, revenue is deferred until all acceptance criteria have been met. When a sale involves multiple deliverables, such as sales of products that include services, the multiple deliverables are evaluated to determine the unit of accounting, and the entire fee from the arrangement is allocated to each unit of accounting based on the relative selling price. Revenue is recognized when the revenue recognition criteria for each unit of accounting are met. For hosting arrangements, we recognize subscription revenue ratably over the subscription period, while usage revenue is recognized based on utilization. Software subscription revenue is deferred and recognized ratably over the subscription term upon delivery of the first product and commencement of the term.

[0000858877-16-000117:mdna:34]
The amount of revenue recognized in a given period is affected by our judgment as to whether an arrangement includes multiple deliverables and, if so, our valuation of the units of accounting.  Our multiple element arrangements may contain only deliverables within the scope of Accounting Standards Codification (ASC) 605, Revenue Recognition, deliverables within the scope of ASC 985-605, Software-Revenue Recognition, or a combination of both. According to the accounting guidance prescribed in ASC 605, we use vendor-specific objective evidence of selling price (VSOE) for each of those units, when available. We determine VSOE based on our normal pricing and discounting practices for the specific product or service when sold separately. In determining VSOE, we require that a substantial majority of the historical standalone transactions have the selling prices for a product or service fall within a reasonably narrow pricing range, generally evidenced by approximately 80% of such historical standalone transactions falling within plus or minus 15% of the median rates. When VSOE does not exist, we apply the selling price hierarchy to applicable multiple-deliverable arrangements. Under the selling price hierarchy, third-party evidence of selling price (TPE) will be considered if VSOE does not exist, and estimated selling price (ESP) will be used if neither VSOE nor TPE is available. Generally, we are not able to determine TPE because our go-to-market strategy differs from that of others in our markets, and the extent of our proprietary technology varies among comparable products or services from those of our peers. In determining ESP, we apply significant judgment as we weigh a variety of factors, based on the characteristics of the deliverable. We typically arrive at an ESP for a product or service that is not sold separately by considering company-specific factors such as geographies, competitive landscape, internal costs, profitability objectives, pricing practices used to establish bundled pricing, and existing portfolio pricing and discounting.

[0000858877-16-000117:mdna:35]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during fiscal 2016, nor do we currently expect a material impact in the next 12 months on our revenue recognition due to any changes in our VSOE, TPE, or ESP.

[0000858877-16-000117:mdna:36]
We make sales to distributors which we refer to as two-tier sales to the end customer. Revenue from two-tier distributors is recognized based on a sell-through method using point-of-sale information provided by these distributors. Distributors participate in various cooperative marketing and other incentive programs, and we maintain estimated accruals and allowances for these programs. If actual credits received by distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-16-000117:mdna:37]
Allowances for Receivables and Sales Returns

[0000858877-16-000117:mdna:38]
The allowances for receivables were as follows (in millions, except percentages):

[0000858877-16-000117:mdna:39]
|  |  | July 30, 2016 |  |  | July 25, 2015 |  |
| Allowance for doubtful accounts |  | $ | 249 |  |  | $ | 302 |  |
| Percentage of gross accounts receivable |  | 4.1 | % |  | 5.4 | % |
| Allowance for credit loss—lease receivables |  | $ | 230 |  |  | $ | 259 |  |
| Percentage of gross lease receivables (1) |  | 6.6 | % |  | 7.2 | % |
| Allowance for credit loss—loan receivables |  | $ | 97 |  |  | $ | 87 |  |
| Percentage of gross loan receivables |  | 4.5 | % |  | 4.9 | % |

[0000858877-16-000117:mdna:40]
(1) Calculated as allowance for credit loss on lease receivables as a percentage of gross lease receivables and residual value before unearned income.

[0000858877-16-000117:mdna:41]
The allowance for doubtful accounts is based on our assessment of the collectibility of customer accounts. We regularly review the adequacy of these allowances by considering internal factors such as historical experience, credit quality and age of the receivable balances as well as external factors such as economic conditions that may affect a customer’s ability to pay as well as historical and expected default frequency rates, which are published by major third-party credit-rating agencies and are updated on a quarterly basis. We also consider the concentration of receivables outstanding with a particular customer in assessing the adequacy of our allowances for doubtful accounts. If a major customer’s creditworthiness deteriorates, if actual defaults are higher than our historical experience, or if other circumstances arise, our estimates of the recoverability of amounts due to us could be overstated, and additional allowances could be required, which could have an adverse impact on our operating results.

[0000858877-16-000117:mdna:42]
The allowance for credit loss on financing receivables is also based on the assessment of collectibility of customer accounts. We regularly review the adequacy of the credit allowances determined either on an individual or a collective basis. When evaluating the financing receivables on an individual basis, we consider historical experience, credit quality and age of receivable balances, and economic conditions that may affect a customer’s ability to pay. When evaluating financing receivables on a collective basis, we use expected default frequency rates published by a major third-party credit-rating agency as well as our own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk and correlation.  Determining expected default frequency rates and loss factors associated with internal credit risk ratings, as well as assessing factors such as economic conditions, concentration of risk, and correlation, are complex and subjective. Our ongoing consideration of all these factors could result in an increase in our allowance for credit loss in the future, which could adversely affect our operating results. Both accounts receivable and financing receivables are charged off at the point when they are considered uncollectible.

[0000858877-16-000117:mdna:43]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of July 30, 2016 and July 25, 2015 was $126 million and $129 million, respectively, and was recorded as a reduction of our accounts receivable and revenue. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-16-000117:mdna:44]
Inventory Valuation and Liability for Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-16-000117:mdna:45]
Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and market, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-16-000117:mdna:46]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 30, 2016, the liability for these purchase commitments was $159 million, compared with $156 million as of July 25, 2015, and was included in other current liabilities.

[0000858877-16-000117:mdna:47]
Our provision for inventory was $65 million, $54 million, and $67 million in fiscal 2016, 2015, and 2014, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $134 million, $102 million, and $124 million in fiscal 2016, 2015, and 2014, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence, particularly in light of current macroeconomic uncertainties and conditions and the resulting potential for changes in future demand forecast.

[0000858877-16-000117:mdna:48]
Loss Contingencies and Product Warranties

[0000858877-16-000117:mdna:49]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-16-000117:mdna:50]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-16-000117:mdna:51]
We have recorded a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. In February 2014, on the basis of the growing number of failures as described in Note 12 (f) to the Consolidated Financial Statements, we decided to expand our approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014. During fiscal 2016 and 2015, we recorded adjustments to product cost of sales of $74 million and $164 million, respectively to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products. Estimating this liability is complex and subjective, and if we experience changes in a number of underlying assumptions and estimates such as a change in claims compared with our expectations, or if the cost of servicing these claims is different than expected, our estimated liability may be impacted.

[0000858877-16-000117:mdna:52]
Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty. We accrue for warranty costs as part of our cost of sales based on associated material costs, technical support labor costs, and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends in the rate of customer cases and the cost to support the customer cases within the warranty period. Overhead cost is applied based on estimated time to support warranty activities.

[0000858877-16-000117:mdna:53]
If we experience an increase in warranty claims compared with our historical experience, or if the cost of servicing warranty claims is greater than expected, our profitability could be adversely affected.

[0000858877-16-000117:mdna:54]
Fair Value Measurements

[0000858877-16-000117:mdna:55]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $58.1 billion as of July 30, 2016, compared with $53.5 billion as of July 25, 2015. Our fixed income investment portfolio, as of July 30, 2016, consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-16-000117:mdna:56]
As described more fully in Note 2 to the Consolidated Financial Statements, a valuation hierarchy is based on the level of independent, objective evidence available regarding the value of the investments. It encompasses three classes of investments: Level 1 consists of securities for which there are quoted prices in active markets for identical securities; Level 2 consists of securities for which observable inputs other than Level 1 inputs are used, such as quoted prices for similar securities in active markets or quoted prices for identical securities in less active markets and model-derived valuations for which the variables are derived from, or corroborated by, observable market data; and Level 3 consists of securities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value.

[0000858877-16-000117:mdna:57]
41

[0000858877-16-000117:mdna:58]
Our Level 2 securities are valued using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from independent pricing vendors, quoted market prices, or other sources to determine the ultimate fair value of our assets and liabilities. We use such pricing data as the primary input, to which we have not made any material adjustments during fiscal 2016 and 2015, to make our assessments and determinations as to the ultimate valuation of our investment portfolio. We are ultimately responsible for the financial statements and underlying estimates.

[0000858877-16-000117:mdna:59]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of July 30, 2016. Level 3 assets do not represent a significant portion of our total assets measured at fair value on a recurring basis as of July 30, 2016 and July 25, 2015.

[0000858877-16-000117:mdna:60]
Other-than-Temporary Impairments

[0000858877-16-000117:mdna:61]
We recognize an impairment charge when the declines in the fair values of our fixed income or publicly traded equity securities below their cost basis are judged to be other than temporary. The ultimate value realized on these securities, to the extent unhedged, is subject to market price volatility until they are sold.

[0000858877-16-000117:mdna:62]
If the fair value of a debt security is less than its amortized cost, we assess whether the impairment is other than temporary. An impairment is considered other than temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of its entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost of the security. If an impairment is considered other than temporary based on (i) or (ii) described in the prior sentence, the entire difference between the amortized cost and the fair value of the security is recognized in earnings. If an impairment is considered other than temporary based on condition (iii), the amount representing credit loss, defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security, will be recognized in earnings, and the amount relating to all other factors will be recognized in other comprehensive income (OCI). In estimating the amount and timing of cash flows expected to be collected, we consider all available information, including past events, current conditions, the remaining payment terms of the security, the financial condition of the issuer, expected defaults, and the value of underlying collateral.

[0000858877-16-000117:mdna:63]
For publicly traded equity securities, we consider various factors in determining whether we should recognize an impairment charge, including the length of time and extent to which the fair value has been less than our cost basis, the financial condition and near-term prospects of the issuer, and our intent and ability to hold the investment for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-16-000117:mdna:64]
We also have investments in privately held companies, some of which are in the startup or development stages. As of July 30, 2016, our investments in privately held companies were $1,003 million, compared with $897 million as of July 25, 2015, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize. Our impairment charges on investments in privately held companies were $67 million, $41 million, and $23 million in fiscal 2016, 2015, and 2014, respectively.

[0000858877-16-000117:mdna:65]
42

[0000858877-16-000117:mdna:66]
Goodwill and Purchased Intangible Asset Impairments

[0000858877-16-000117:mdna:67]
Our methodology for allocating the purchase price relating to purchase acquisitions is determined through established valuation techniques. Goodwill represents a residual value as of the acquisition date, which in most cases results in measuring goodwill as an excess of the purchase consideration transferred plus the fair value of any noncontrolling interest in the acquired company over the fair value of net assets acquired, including contingent consideration. We perform goodwill impairment tests on an annual basis in the fourth fiscal quarter and between annual tests in certain circumstances for each reporting unit. The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the new accounting guidance for the fair value measurement of nonfinancial assets.

[0000858877-16-000117:mdna:68]
The goodwill recorded in the Consolidated Balance Sheets as of July 30, 2016 and July 25, 2015 was $26.6 billion and $24.5 billion, respectively. In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in fiscal 2016, 2015, and 2014. For the annual impairment testing in fiscal 2016, the excess of the fair value over the carrying value for each of our reporting units was $40.8 billion for the Americas, $29.4 billion for EMEA, and $13.1 billion for APJC. During the fourth quarter of fiscal 2016, we performed a sensitivity analysis for goodwill impairment with respect to each of our respective reporting units and determined that a hypothetical 10% decline in the fair value of each reporting unit would not result in an impairment of goodwill for any reporting unit.

[0000858877-16-000117:mdna:69]
The fair value of acquired technology and patents, as well as acquired technology under development, is determined at acquisition date primarily using the income approach, which discounts expected future cash flows to present value. The discount rates used in the present value calculations are typically derived from a weighted-average cost of capital analysis and then adjusted to reflect risks inherent in the development lifecycle as appropriate. We consider the pricing model for products related to these acquisitions to be standard within the high-technology communications industry, and the applicable discount rates represent the rates that market participants would use for valuation of such intangible assets.

[0000858877-16-000117:mdna:70]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. Our impairment charges related to purchased intangible assets were $74 million and $175 million during fiscal 2016 and 2015, respectively. There were no impairment charges related to purchased intangible assets during fiscal 2014. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-16-000117:mdna:71]
Income Taxes

[0000858877-16-000117:mdna:72]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 16.9%, 19.8%, and 19.2% in fiscal 2016, 2015, and 2014, respectively.

[0000858877-16-000117:mdna:73]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.

[0000858877-16-000117:mdna:74]
Significant judgment is also required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000858877-16-000117:mdna:75]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to domestic manufacturing deduction laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our intercompany R&D cost-sharing arrangement and legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including possible changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, or the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 34 countries, including the United States, has recently made changes to numerous long-standing tax principles. There can be no assurance that these changes, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-16-000117:mdna:76]
RESULTS OF OPERATIONS

[0000858877-16-000117:mdna:77]
Revenue

[0000858877-16-000117:mdna:78]
The following table presents the breakdown of revenue between product and service (in millions, except percentages):

[0000858877-16-000117:mdna:79]
|  |  | Years Ended |  | 2016 vs. 2015 |  | 2015 vs. 2014 |
|  |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 37,254 |  |  | $ | 37,750 |  |  | $ | 36,172 |  |  | $ | (496 | ) |  | (1.3 | )% |  | $ | 1,578 |  |  | 4.4 | % |
| Percentage of revenue |  | 75.6 | % |  | 76.8 | % |  | 76.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | 11,993 |  |  | 11,411 |  |  | 10,970 |  |  | 582 |  |  | 5.1 | % |  | 441 |  |  | 4.0 | % |
| Percentage of revenue |  | 24.4 | % |  | 23.2 | % |  | 23.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 49,247 |  |  | $ | 49,161 |  |  | $ | 47,142 |  |  | $ | 86 |  |  | 0.2 | % |  | $ | 2,019 |  |  | 4.3 | % |

[0000858877-16-000117:mdna:80]
We manage our business primarily on a geographic basis, organized into three geographic segments. Our revenue, which includes product and service for each segment, is summarized in the following table (in millions, except percentages):

[0000858877-16-000117:mdna:81]
|  |  | Years Ended |  | 2016 vs. 2015 |  | 2015 vs. 2014 |
|  |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 29,411 |  |  | $ | 29,655 |  |  | $ | 27,781 |  |  | $ | (244 | ) |  | (0.8 | )% |  | $ | 1,874 |  |  | 6.7 | % |
| Percentage of revenue |  | 59.7 | % |  | 60.3 | % |  | 58.9 | % |  |  |  |  |  |  |  |  |
| EMEA |  | 12,281 |  |  | 12,322 |  |  | 12,006 |  |  | (41 | ) |  | (0.3 | )% |  | 316 |  |  | 2.6 | % |
| Percentage of revenue |  | 24.9 | % |  | 25.1 | % |  | 25.5 | % |  |  |  |  |  |  |  |  |
| APJC |  | 7,555 |  |  | 7,184 |  |  | 7,355 |  |  | 371 |  |  | 5.2 | % |  | (171 | ) |  | (2.3 | )% |
| Percentage of revenue |  | 15.4 | % |  | 14.6 | % |  | 15.6 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 49,247 |  |  | $ | 49,161 |  |  | $ | 47,142 |  |  | $ | 86 |  |  | 0.2 | % |  | $ | 2,019 |  |  | 4.3 | % |

[0000858877-16-000117:mdna:82]
44

[0000858877-16-000117:mdna:83]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:84]
For fiscal 2016, as compared with fiscal 2015, total revenue was flat. Total company revenue not including SP Video CPE products increased 3%. Product revenue decreased by1% in total, but increased by 2% for product revenue not including SP Video CPE products. Service revenue increased by 5%. Fiscal 2016 had 53 weeks, compared with 52 weeks in fiscal 2015, thus our results for fiscal 2016 reflect an extra week. We estimate that the additional revenue associated with the extra week was approximately $265 million, $200 million of which was from our services subscriptions, and $65 million from our SaaS offerings such as WebEx, and a small amount from product distribution. Our total revenue grew in our APJC geographic segment, while revenue declined in the Americas and EMEA geographic segments. The emerging countries of BRICM, in the aggregate, experienced 3% product revenue growth, with growth in China, India and Mexico, partially offset by decreases in the other two BRICM countries.

[0000858877-16-000117:mdna:85]
We conduct business globally in numerous currencies. The direct effect of foreign currency fluctuations on revenue has not been material because our revenue is primarily denominated in U.S. dollars. However, if the U.S. dollar strengthens relative to other currencies, as was the case during fiscal 2016, such strengthening could have an indirect effect on our revenue to the extent it raises the cost of our products to non-U.S. customers and thereby reduces demand. A weaker U.S. dollar could have the opposite effect. However, the precise indirect effect of currency fluctuations is difficult to measure or predict because our revenue is influenced by many factors in addition to the impact of such currency fluctuations. Our revenue in fiscal 2016 was adversely affected by the depreciation of certain currencies relative to the U.S. dollar and especially currencies in certain emerging countries, although the indirect effects are difficult to measure.

[0000858877-16-000117:mdna:86]
In addition to the impact of macroeconomic factors, including a reduced IT spending environment and reductions in spending by government entities, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple-element arrangements; the mix of financing arrangements provided to channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment. As has been the case in certain emerging countries from time to time, customers require greater levels of financing arrangements, service, and support, and these activities may occur in future periods, which may also impact the timing of the recognition of revenue.

[0000858877-16-000117:mdna:87]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:88]
For fiscal 2015, as compared with fiscal 2014, total revenue increased by 4%, as product and service revenue each increased by 4%. Our total revenue grew in our Americas and EMEA geographic segments, while revenue declined in the APJC segment. The emerging countries of BRICM, in the aggregate, experienced a 4% product revenue decline, with declines in China and Russia partially offset by increases in the other three BRICM countries.

[0000858877-16-000117:mdna:89]
Product Revenue by Segment

[0000858877-16-000117:mdna:90]
The following table presents the breakdown of product revenue by segment (in millions, except percentages):

[0000858877-16-000117:mdna:91]
|  |  | Years Ended |  | 2016 vs. 2015 |  | 2015 vs. 2014 |
|  |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 21,679 |  |  | $ | 22,261 |  |  | $ | 20,631 |  |  | $ | (582 | ) |  | (2.6 | )% |  | $ | 1,630 |  |  | 7.9 | % |
| Percentage of product revenue |  | 58.2 | % |  | 59.0 | % |  | 57.0 | % |  |  |  |  |  |  |  |  |
| EMEA |  | 9,658 |  |  | 9,856 |  |  | 9,655 |  |  | (198 | ) |  | (2.0 | )% |  | 201 |  |  | 2.1 | % |
| Percentage of product revenue |  | 25.9 | % |  | 26.1 | % |  | 26.7 | % |  |  |  |  |  |  |  |  |
| APJC |  | 5,917 |  |  | 5,633 |  |  | 5,886 |  |  | 284 |  |  | 5.0 | % |  | (253 | ) |  | (4.3 | )% |
| Percentage of product revenue |  | 15.9 | % |  | 14.9 | % |  | 16.3 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 37,254 |  |  | $ | 37,750 |  |  | $ | 36,172 |  |  | $ | (496 | ) |  | (1.3 | )% |  | $ | 1,578 |  |  | 4.4 | % |

[0000858877-16-000117:mdna:92]
During the second quarter of fiscal 2016, we completed the sale of our SP Video CPE Business. As a result, fiscal 2016 includes only four months of product revenue from our SP Video CPE Business. Revenue from this portion of the Service Provider Video product category will not recur in future periods. SP Video CPE Business revenue was $504 million, $1,846 million and $2,240 million for fiscal 2016, 2015 and 2014, respectively.

[0000858877-16-000117:mdna:93]
45

[0000858877-16-000117:mdna:94]
Americas

[0000858877-16-000117:mdna:95]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:96]
The decrease in product revenue for the Americas segment was driven by a decline of $1,146 million in product sales related to our SP Video CPE Business. Product revenue not including SP Video CPE products increased for the Americas segment. From a customer markets perspective, the decrease in product revenue in the Americas segment of 3% was led by a significant decline in the service provider market driven by the sale of the SP Video CPE Business. We experienced product revenue growth in the commercial, public sector and enterprise markets. The product revenue growth in the public sector market was due primarily to higher sales to state and local governments, partially offset by lower sales to the U.S. federal government. From a country perspective, product revenue decreased by 34% in Brazil and 24% in Canada partially offset by a slight increase in the United States and an increase of 3% in Mexico.

[0000858877-16-000117:mdna:97]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:98]
The increase in product revenue in the Americas segment of 8% was led by solid growth in the public sector, commercial and enterprise markets. The product revenue growth in the public sector market was due primarily to higher sales to the U.S. federal government and, to a lesser extent, higher sales to state and local governments. The product revenue growth in the enterprise and commercial markets was driven by strength in the United States. We experienced a product revenue decline in the service provider market in this segment. From a country perspective, product revenue increased by 8% in the United States, 34% in Mexico, and 2% in Brazil.

[0000858877-16-000117:mdna:99]
EMEA

[0000858877-16-000117:mdna:100]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:101]
The decrease in product revenue of 2%, or $198 million, for the EMEA segment was driven by a decline of $164 million in product sales related to our SP Video CPE Business. From a customer market perspective, the decrease was driven by product revenue declines in the service provider, public sector and enterprise markets, partially offset by product revenue growth in the commercial market. The decline in sales to the service provider market was due primarily to the sale of the SP Video CPE Business. Product revenue from emerging countries within EMEA decreased by 11%, led by a decline in Russia of 31%. Product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, increased by 1%.

[0000858877-16-000117:mdna:102]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:103]
Product revenue in the EMEA segment increased by 2%, driven by growth in the commercial, public sector and enterprise markets. Product revenue in the service provider market was flat. Product revenue from emerging countries within EMEA increased by 1% and product revenue for the remainder of EMEA grew by 2%.

[0000858877-16-000117:mdna:104]
APJC

[0000858877-16-000117:mdna:105]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:106]
The increase in product revenue in the APJC segment of 5% was led by solid growth in the service provider market and, to a lesser extent, growth in the enterprise, public sector and commercial markets. From a country perspective, product revenue increased by 22% in China, driven by an increase in sales of Service Provider Video software and solutions products, and 18% in India, partially offset by product revenue decreases of 7% in Japan and 5% in Australia. Product revenue for this geographic segment was adversely impacted by a $32 million decrease in product revenue related to the sale of our SP Video CPE Business.

[0000858877-16-000117:mdna:107]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:108]
The decrease in product revenue in the APJC segment of 4% was led by a significant decline in the service provider market and, to a lesser degree, in the public sector and enterprise markets. These decreases were partially offset by growth in the commercial market. From a country perspective, product revenue decreased by 21% in China and 5% in Japan. We experienced product revenue growth of 15% in India and 8% in Australia.

[0000858877-16-000117:mdna:109]
Product Revenue by Groups of Similar Products

[0000858877-16-000117:mdna:110]
In addition to the primary view on a geographic basis, we also prepare financial information related to groups of similar products and customer markets for various purposes. Our product categories consist of the following categories (with subcategories in parentheses): Switching (fixed switching, modular switching, and storage); NGN Routing (high-end routers, mid-range and low-end routers, and other NGN Routing products); Collaboration (unified communications, Cisco TelePresence, and conferencing); Data Center; Wireless; Service Provider Video (video software and solutions, and cable access); Security; and Other Products. The Other Products category consists primarily of emerging technology products and other networking products.

[0000858877-16-000117:mdna:111]
The following table presents revenue for groups of similar products (in millions, except percentages):

[0000858877-16-000117:mdna:112]
|  |  | Years Ended |  | 2016 vs. 2015 |  | 2015 vs. 2014 |
|  |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 14,746 |  |  | $ | 14,740 |  |  | $ | 14,001 |  |  | $ | 6 |  |  | — | % |  | $ | 739 |  |  | 5.3 | % |
| Percentage of product revenue |  | 39.6 | % |  | 39.1 | % |  | 38.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| NGN Routing |  | 7,408 |  |  | 7,704 |  |  | 7,606 |  |  | (296 | ) |  | (3.8 | )% |  | 98 |  |  | 1.3 | % |
| Percentage of product revenue |  | 19.9 | % |  | 20.4 | % |  | 21.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Collaboration |  | 4,352 |  |  | 4,004 |  |  | 3,817 |  |  | 348 |  |  | 8.7 | % |  | 187 |  |  | 4.9 | % |
| Percentage of product revenue |  | 11.7 | % |  | 10.6 | % |  | 10.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Data Center |  | 3,365 |  |  | 3,219 |  |  | 2,640 |  |  | 146 |  |  | 4.5 | % |  | 579 |  |  | 21.9 | % |
| Percentage of product revenue |  | 9.0 | % |  | 8.5 | % |  | 7.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Wireless |  | 2,625 |  |  | 2,542 |  |  | 2,293 |  |  | 83 |  |  | 3.3 | % |  | 249 |  |  | 10.9 | % |
| Percentage of product revenue |  | 7.0 | % |  | 6.7 | % |  | 6.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Service Provider Video (1) |  | 2,424 |  |  | 3,555 |  |  | 3,969 |  |  | (1,131 | ) |  | (31.8 | )% |  | (414 | ) |  | (10.4 | )% |
| Percentage of product revenue |  | 6.5 | % |  | 9.4 | % |  | 11.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Security |  | 1,969 |  |  | 1,747 |  |  | 1,566 |  |  | 222 |  |  | 12.7 | % |  | 181 |  |  | 11.6 | % |
| Percentage of product revenue |  | 5.3 | % |  | 4.6 | % |  | 4.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Other |  | 365 |  |  | 239 |  |  | 280 |  |  | 126 |  |  | 52.7 | % |  | (41 | ) |  | (14.6 | )% |
| Percentage of product revenue |  | 1.0 | % |  | 0.7 | % |  | 0.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | $ | 37,254 |  |  | $ | 37,750 |  |  | $ | 36,172 |  |  | $ | (496 | ) |  | (1.3 | )% |  | $ | 1,578 |  |  | 4.4 | % |

[0000858877-16-000117:mdna:113]
(1) During the second quarter of fiscal 2016, we completed the sale of the SP Video CPE Business.  As a result, fiscal 2016 includes only four months of product revenue from SP Video CPE Business. Includes SP Video CPE Business revenue of $504 million, $1,846 million and $2,240 million for fiscal 2016, 2015, and 2014, respectively.

[0000858877-16-000117:mdna:114]
Certain reclassifications have been made to the prior period amounts to conform to the current period’s presentation.

[0000858877-16-000117:mdna:115]
Switching

[0000858877-16-000117:mdna:116]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:117]
We believe the flat revenue growth in our Switching product category was driven in large part by the uncertainty in the macro environment which led to a slowdown in customer spending. This led to flat growth in our Switching products used in campus environments which comprise the majority of revenue within this product category.  We also experienced decreased revenue from storage products. These impacts were offset by an increase in sales of our Switching products used in data centers, reflecting strength in our Application Centric Infrastructure portfolio.

[0000858877-16-000117:mdna:118]
In terms of subcategories, the increase in revenue from LAN fixed-configuration switches of 5%, or $469 million was substantially offset by decreased revenue from our modular switches of 8%, or $375 million, and the decreased revenue from storage products of 17%, or $88 million. Revenue from our LAN-fixed configuration switches increased due primarily to higher sales of our Cisco Catalyst 3850 Series Switches, Cisco Catalyst 3650 Series Switches, Cisco Nexus 9300 Series Switches and Cisco Nexus 3000 Series Switches, partially offset by a decrease in sales of certain other products in this portfolio. Decreased revenue from our modular switches was due primarily to lower sales of most of our Cisco Catalyst Series Switches and also due to lower sales of our Cisco Nexus 7000 Series Switches, partially offset by sales growth in Cisco Nexus 9500 Series Switches within this product category.

[0000858877-16-000117:mdna:119]
47

[0000858877-16-000117:mdna:120]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:121]
The increase in revenue in our Switching product category of 5%, or $739 million, was driven by a 9%, or $826 million, increase in revenue from our LAN fixed-configuration switches and, to a lesser extent, a 24%, or $101 million, increase in sales of storage products. Revenue from LAN fixed-configuration switches increased due to higher sales of most of our Cisco Nexus Series Switches and Cisco Catalyst Series Switches within this category. We experienced a decrease in revenue from our modular switches of 4%, or $188 million, driven by lower sales of Cisco Catalyst 6500-E Series Switches and Cisco Nexus 7000 Series Switches.

[0000858877-16-000117:mdna:122]
NGN Routing

[0000858877-16-000117:mdna:123]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:124]
We believe a cautious service provider capital expenditure spending environment negatively impacted sales in NGN Routing. Revenue in this product category decreased by 4%, or $296 million, driven by an 8%, or $378 million, decrease in revenue from our high-end router products partially offset by an 11%, or $48 million, increase in revenue from what we categorize as other NGN Routing products and a 1%, or $34 million, increase in revenue from our mid-range and low-end router products. Revenue from high-end router products decreased due to a decrease in revenue from most of our high-end router products, partially offset by higher sales of our CRS-X products. Revenue from other NGN Routing products increased due to higher sales of optical networking products. The revenue increase in the mid-range and low-end routers was primarily driven by higher sales of Cisco ISR products.

[0000858877-16-000117:mdna:125]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:126]
Revenue in our NGN Routing product category increased by 1%, or $98 million, driven by a 6%, or $248 million, increase in revenue from our high-end router products and a slight increase in revenue from our midrange and low-end router products, partially offset by 28%, or $171 million, decrease in revenue from other NGN Routing products. Revenue from high-end router products increased due to an increase in revenue from most products within our Cisco ASR category and the adoption of our Cisco NCS platform and CRS-X, partially offset by lower sales of our legacy high-end router products. The slight increase in revenue from our midrange and low-end router products was due to higher sales of our Cisco ISR products, partially offset by lower sales of certain of our access products. Revenue from other NGN Routing products decreased primarily due to lower sales of certain optical networking products.

[0000858877-16-000117:mdna:127]
Collaboration

[0000858877-16-000117:mdna:128]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:129]
Revenue from our Collaboration product category increased by 9%, or $348 million, driven by growth across the various subcategories within this product category. The growth in Conferencing revenue resulted from higher usage and recurring revenue from WebEx, which we include as product revenue in this category.  Revenue from Cisco TelePresence products grew due to higher revenue in infrastructure and endpoint products as a result of new product introductions. The increase in Unified Communications revenue was driven by higher software revenue. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Collaboration product category.

[0000858877-16-000117:mdna:130]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:131]
Revenue in our Collaboration product category increased by 5%, or $187 million, due to increased revenue from our Unified Communications products as a result of higher software revenue and a slight increase in revenue from phones. Higher revenue from our Cisco TelePresence and conferencing products also contributed to the increase. Revenue from Cisco TelePresence products increased due to higher revenue in endpoint products as a result of new product introductions. The increase in conferencing revenue was a result of higher recurring revenue. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Collaboration product category.

[0000858877-16-000117:mdna:132]
Data Center

[0000858877-16-000117:mdna:133]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:134]
The increase in revenue in our Data Center product category of 5%, or $146 million, was primarily driven by an increase in sales of our Cisco Unified Computing System products, with growth across all geographic segments and most of the customer markets.  We believe the uncertainty in the macro environment led to a slowdown of customer spending for products in this category. Additionally, we are seeing a market transition with computing workloads shifting from blade server systems to rack-based systems.  We believe both of these factors adversely impacted the sales of this product category.

[0000858877-16-000117:mdna:135]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:136]
Revenue in our Data Center product category grew by 22%, or $579 million, with sales growth of our Cisco Unified Computing System products across all geographic segments and customer markets. The increase was due in large part to the continued momentum we are experiencing in both data center and cloud environments, as current customers increase their data center build-outs and as new customers deploy these offerings.

[0000858877-16-000117:mdna:137]
Wireless

[0000858877-16-000117:mdna:138]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:139]
Revenue in our Wireless product category increased by 3%, or $83 million, due primarily to continued growth in sales of Meraki products within this category, partially offset by a decrease in sales of our controllers products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Wireless product category.

[0000858877-16-000117:mdna:140]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:141]
Revenue in our Wireless product category increased by 11%, or $249 million, driven by continued growth in sales of Meraki products combined with continued strength in our 802.11ac portfolio. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Wireless product category.

[0000858877-16-000117:mdna:142]
Service Provider Video

[0000858877-16-000117:mdna:143]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:144]
The decrease in revenue from our Service Provider Video product category of 32%, or $1,131 million, was driven by a decrease in product sales of $1,342 million related to our SP Video CPE Business which we sold during the second quarter of fiscal 2016. This decrease was partially offset by an increase in revenue from certain cable access products and an increase in revenue from our video software and solutions products, particularly in China.

[0000858877-16-000117:mdna:145]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:146]
The decrease in revenue from our Service Provider Video product category of 10%, or $414 million, was driven by a 16%, or $332 million, decrease in sales of our Service Provider Video infrastructure products, due primarily to lower sales of set-top boxes. We also experienced a decrease in revenue from cable access products within this product category.

[0000858877-16-000117:mdna:147]
Security

[0000858877-16-000117:mdna:148]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:149]
Revenue in our Security product category increased 13%, or $222 million, driven by higher sales of advanced threat security, web security and unified threat management products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Security product category.

[0000858877-16-000117:mdna:150]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:151]
Revenue in our Security product category was up 12%, or $181 million, driven primarily by sales of Sourcefire products and, to a lesser extent, by higher sales of our high-end firewall products within our network security product portfolio. This increase was partially offset by a slight decrease in revenue from our content security products due to lower sales of web and e-mail security products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Security product category.

[0000858877-16-000117:mdna:152]
Other Products

[0000858877-16-000117:mdna:153]
The year-over-year increase in revenue in our Other Products category for fiscal 2016 was due to increased revenue from data and analytics offerings, from our cloud-related offerings and from our IoT products, driven by our Jasper acquisition. We experienced a year-over-year decrease in revenue in our Other Products category for fiscal 2015 due in large part to the decrease in sales of our other networking products.

[0000858877-16-000117:mdna:154]
49

[0000858877-16-000117:mdna:155]
Service Revenue by Segment

[0000858877-16-000117:mdna:156]
The following table presents the breakdown of service revenue by segment (in millions, except percentages):

[0000858877-16-000117:mdna:157]
|  | Years Ended |  | 2016 vs. 2015 |  | 2015 vs. 2014 |
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 7,732 |  |  | $ | 7,394 |  |  | $ | 7,150 |  |  | $ | 338 |  |  | 4.6 | % |  | $ | 244 |  |  | 3.4 | % |
| Percentage of service revenue | 64.4 | % |  | 64.8 | % |  | 65.2 | % |  |  |  |  |  |  |  |  |
| EMEA | 2,623 |  |  | 2,466 |  |  | 2,351 |  |  | 157 |  |  | 6.4 | % |  | 115 |  |  | 4.9 | % |
| Percentage of service revenue | 21.9 | % |  | 21.6 | % |  | 21.4 | % |  |  |  |  |  |  |  |  |
| APJC | 1,638 |  |  | 1,551 |  |  | 1,469 |  |  | 87 |  |  | 5.6 | % |  | 82 |  |  | 5.6 | % |
| Percentage of service revenue | 13.7 | % |  | 13.6 | % |  | 13.4 | % |  |  |  |  |  |  |  |  |
| Total | $ | 11,993 |  |  | $ | 11,411 |  |  | $ | 10,970 |  |  | $ | 582 |  |  | 5.1 | % |  | $ | 441 |  |  | 4.0 | % |

[0000858877-16-000117:mdna:158]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:159]
Service revenue grew 5%, which includes a $200 million, or 2%, year-over-year increase as a result of the impact of the extra week in fiscal 2016. Service revenue had solid growth across all of our geographic segments. Worldwide technical support services revenue increased by 5% and worldwide advanced services revenue increased by 7%. Technical support services revenue increased across all geographic segments. Renewals and technical support service contract initiations associated with product sales provided an installed base of equipment being serviced which, in concert with new service offerings, were the primary factors driving the revenue increases. Advanced services revenue, which relates to professional services for specific customer network needs, grew across all geographic segments.

[0000858877-16-000117:mdna:160]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:161]
Service revenue increased across all of our geographic segments. Worldwide technical support services revenue increased by 3% and worldwide advanced services revenue increased by 6%, driven by growth in subscription revenues. Technical support services revenue experienced relatively balanced growth across all geographic segments. Renewals and technical support service contract initiations associated with product sales provided an installed base of equipment being serviced which, in concert with new service offerings, were the primary factors driving the revenue increases. Advanced services revenue grew across all geographic segments.

[0000858877-16-000117:mdna:162]
Gross Margin

[0000858877-16-000117:mdna:163]
The following table presents the gross margin for products and services (in millions, except percentages):

[0000858877-16-000117:mdna:164]
|  | AMOUNT |  | PERCENTAGE |
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 23,093 |  |  | $ | 22,373 |  |  | $ | 20,531 |  |  | 62.0 | % |  | 59.3 | % |  | 56.8 | % |
| Service | 7,867 |  |  | 7,308 |  |  | 7,238 |  |  | 65.6 | % |  | 64.0 | % |  | 66.0 | % |
| Total | $ | 30,960 |  |  | $ | 29,681 |  |  | $ | 27,769 |  |  | 62.9 | % |  | 60.4 | % |  | 58.9 | % |

[0000858877-16-000117:mdna:165]
50

[0000858877-16-000117:mdna:166]
Product Gross Margin

[0000858877-16-000117:mdna:167]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:168]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2015 to fiscal 2016:

[0000858877-16-000117:mdna:169]
|  |  | Product Gross Margin Percentage |
| Fiscal 2015 |  | 59.3 | % |
| Productivity (1) |  | 3.3 | % |
| SP Video CPE Business impact |  | 1.5 | % |
| Amortization of purchased intangible assets |  | 0.6 | % |
| Rockstar patent portfolio charge |  | 0.5 | % |
| Product pricing |  | (2.2 | )% |
| Mix of products sold |  | (0.8 | )% |
| Supplier component remediation adjustment |  | (0.2 | )% |
| Fiscal 2016 |  | 62.0 | % |

[0000858877-16-000117:mdna:170]
(1) Productivity includes overall manufacturing-related costs, such as component costs, warranty expense, provision for inventory, freight, logistics, shipment volume, and other items not categorized elsewhere.

[0000858877-16-000117:mdna:171]
Product gross margin increased by 2.7 percentage points as compared with fiscal 2015. The increase in product gross margin was due in large part to productivity improvements, which were driven primarily by value engineering efforts; favorable component pricing; and continued operational efficiency in manufacturing operations. Value engineering is the process by which production costs are reduced through component redesign, board configuration, test processes, and transformation processes. Our product gross margin also benefited from the sale during the second quarter of fiscal 2016 of our lower margin SP Video CPE Business, lower amortization expense and impairment charges related to acquisition-related intangible assets, and a $188 million charge to product cost of sales recorded in the first quarter of fiscal 2015 related to the Rockstar patent portfolio. The various factors contributing to the product gross margin increase were partially offset by unfavorable impacts from product pricing, which were driven by typical market factors and impacted each of our geographic segments and customer markets, an unfavorable mix of products sold and the lower supplier component remediation adjustment. The unfavorable mix of products sold was due to a negative mix impact from our Cisco Unified Computing System products, higher sales of Service Provider Video products (not including the CPE Business) and an unfavorable mix within Switching products.

[0000858877-16-000117:mdna:172]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:173]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2014 to fiscal 2015:

[0000858877-16-000117:mdna:174]
|  |  | Product Gross Margin Percentage |
| Fiscal 2014 |  | 56.8 | % |
| Productivity (1) |  | 2.8 | % |
| Supplier component remediation charge/adjustment |  | 2.2 | % |
| Mix of products sold |  | 0.3 | % |
| Product pricing |  | (2.3 | )% |
| Rockstar patent portfolio charge |  | (0.5 | )% |
| Fiscal 2015 |  | 59.3 | % |

[0000858877-16-000117:mdna:175]
Product gross margin increased by 2.5 percentage points compared with fiscal 2014. The increase in product gross margin was due to productivity improvements, which were driven by value engineering efforts; favorable component pricing; continued operational efficiency in manufacturing operations and lower warranty expense. The increase was also due to the $655 million charge to product cost of sales in fiscal 2014 related to the expected cost to remediate issues with a supplier component in certain products sold in prior fiscal years and an associated $164 million favorable adjustment recorded in fiscal 2015.

[0000858877-16-000117:mdna:176]
Additionally, gross margin increased due to the mix of products sold. The favorable product mix impact was due to revenue decreases from our relatively lower margin Service Provider Video products and a revenue increase from certain of our higher margin core products, partially offset by increased revenue from our relatively lower margin Cisco Unified Computing System products. The various factors contributing to the product gross margin increase were partially offset by unfavorable impacts from product pricing, which were driven by typical market factors and impacted each of our geographic segments and customer markets, as well as the unfavorable impact of a $188 million charge to product cost of sales recorded in fiscal 2015 related to the Rockstar patent portfolio, see Note 4(b) to the Consolidated Financial Statements.

[0000858877-16-000117:mdna:177]
Service Gross Margin

[0000858877-16-000117:mdna:178]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:179]
Service gross margin percentage increased by 1.6 percentage points, as compared with fiscal 2015, due to higher sales volume and decreased headcount-related costs. These benefits to gross margin were partially offset by increased partner delivery costs and increased outside services costs.

[0000858877-16-000117:mdna:180]
Our service gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-16-000117:mdna:181]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:182]
Service gross margin percentage decreased by 2.0 percentage points for fiscal 2015, as compared with fiscal 2014, driven by increased cost impacts such as partner delivery costs, headcount-related costs and outside services. Headcount-related costs increased due to continued investments in security and cloud managed services and higher variable compensation expense. These cost impacts were partially offset by the resulting benefit to gross margin of higher sales volume in both advanced services and technical support services.

[0000858877-16-000117:mdna:183]
Gross Margin by Segment

[0000858877-16-000117:mdna:184]
The following table presents the total gross margin for each segment (in millions, except percentages):

[0000858877-16-000117:mdna:185]
|  |  | AMOUNT |  | PERCENTAGE |
| Years Ended |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 19,006 |  |  | $ | 18,670 |  |  | $ | 17,379 |  |  | 64.6 | % |  | 63.0 | % |  | 62.6 | % |
| EMEA |  | 7,976 |  |  | 7,705 |  |  | 7,700 |  |  | 64.9 | % |  | 62.5 | % |  | 64.1 | % |
| APJC |  | 4,622 |  |  | 4,307 |  |  | 4,252 |  |  | 61.2 | % |  | 60.0 | % |  | 57.8 | % |
| Segment total |  | 31,604 |  |  | 30,682 |  |  | 29,331 |  |  | 64.2 | % |  | 62.4 | % |  | 62.2 | % |
| Unallocated corporate items (1) |  | (644 | ) |  | (1,001 | ) |  | (1,562 | ) |  |  |  |  |  |  |
| Total |  | $ | 30,960 |  |  | $ | 29,681 |  |  | $ | 27,769 |  |  | 62.9 | % |  | 60.4 | % |  | 58.9 | % |

[0000858877-16-000117:mdna:186]
(1) The unallocated corporate items for the years presented include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-16-000117:mdna:187]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:188]
The Americas segment experienced a gross margin percentage increase due primarily to the sale of the lower margin SP Video CPE Business. In this geographic segment, productivity improvements were substantially offset by unfavorable impacts from pricing and product mix. The unfavorable mix of products sold was due to increased revenue from our lower margin Cisco Unified Computing System products and an unfavorable mix within our NGN Routing products.

[0000858877-16-000117:mdna:189]
The gross margin percentage increase in our EMEA segment was due primarily to the impact of productivity improvements in this geographic segment and the sale of the SP Video CPE Business. Partially offsetting these favorable impacts to gross margin were negative impacts from pricing and an unfavorable product mix. The unfavorable mix of products sold was due primarily to increased revenue from our lower margin Cisco Unified Computing System products. Higher service gross margin also contributed to the increase in the overall gross margin in this geographic segment.

[0000858877-16-000117:mdna:190]
Our APJC segment gross margin percentage increased due to productivity improvements, partially offset by unfavorable impacts from pricing and mix. The mix impact was driven primarily by higher sales from our Service Provider Video products (not including the SP Video CPE Business) and unfavorable mix within our NGN Routing products.

[0000858877-16-000117:mdna:191]
The gross margin percentage for a particular segment may fluctuate, and period-to-period changes in such percentages may or may not be indicative of a trend for that segment.

[0000858877-16-000117:mdna:192]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:193]
We experienced a gross margin percentage increase in our Americas segment due to productivity improvements partially offset by unfavorable impacts from pricing. The product mix was flat in this geographic segment as the impact of decreased revenue from our relatively lower margin Service Provider Video products offset the increase in revenue from our relatively lower margin Cisco Unified Computing System products.

[0000858877-16-000117:mdna:194]
The gross margin percentage decrease in our EMEA segment was due primarily to unfavorable impacts from pricing and mix. The unfavorable mix impact was driven by an increase in revenue from our relatively lower margin Cisco Unified Computing System products. Lower service gross margin also contributed to the decrease in the overall gross margin in this segment.

[0000858877-16-000117:mdna:195]
The APJC segment gross margin percentage increased due to productivity improvements and a favorable mix impact, partially offset by unfavorable impacts from pricing. The favorable mix impact was driven by a decrease in revenue from our relatively lower margin Service Provider Video products and an increase in revenue from certain of our higher margin core products.

[0000858877-16-000117:mdna:196]
Research and Development (“R&D”), Sales and Marketing, and General and Administrative (“G&A”) Expenses

[0000858877-16-000117:mdna:197]
R&D, sales and marketing, and G&A expenses are summarized in the following table (in millions, except percentages):

[0000858877-16-000117:mdna:198]
|  |  | Years Ended |  | 2016 vs. 2015 |  | 2015 vs. 2014 |
|  |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Research and development |  | $ | 6,296 |  |  | $ | 6,207 |  |  | $ | 6,294 |  |  | $ | 89 |  |  | 1.4 | % |  | $ | (87 | ) |  | (1.4 | )% |
| Percentage of revenue |  | 12.8 | % |  | 12.6 | % |  | 13.4 | % |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 9,619 |  |  | 9,821 |  |  | 9,503 |  |  | (202 | ) |  | (2.1 | )% |  | 318 |  |  | 3.3 | % |
| Percentage of revenue |  | 19.5 | % |  | 20.0 | % |  | 20.2 | % |  |  |  |  |  |  |  |  |
| General and administrative |  | 1,814 |  |  | 2,040 |  |  | 1,934 |  |  | (226 | ) |  | (11.1 | )% |  | 106 |  |  | 5.5 | % |
| Percentage of revenue |  | 3.7 | % |  | 4.1 | % |  | 4.1 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 17,729 |  |  | $ | 18,068 |  |  | $ | 17,731 |  |  | $ | (339 | ) |  | (1.9 | )% |  | $ | 337 |  |  | 1.9 | % |
| Percentage of revenue |  | 36.0 | % |  | 36.8 | % |  | 37.6 | % |  |  |  |  |  |  |  |  |

[0000858877-16-000117:mdna:199]
Fiscal 2016 had an extra week compared with fiscal 2015. We estimate that the extra week contributed approximately $116 million in total operating expenses (not including share-based compensation expense discussed below).

[0000858877-16-000117:mdna:200]
R&D Expenses

[0000858877-16-000117:mdna:201]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:202]
R&D expenses increased for fiscal 2016, as compared with fiscal 2015, primarily due to higher headcount-related expenses attributable in part to the impact of the extra week in fiscal 2016 and, to a lesser extent, higher share-based compensation expense. These increases were partially offset by lower acquisition-related costs and lower discretionary spending.

[0000858877-16-000117:mdna:203]
We continue to invest in R&D in order to bring a broad range of products to market in a timely fashion. If we believe that we are unable to enter a particular market in a timely manner with internally developed products, we may purchase or license technology from other businesses, or we may partner with or acquire businesses as an alternative to internal R&D.

[0000858877-16-000117:mdna:204]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:205]
The decrease in R&D expenses for fiscal 2015, as compared with fiscal 2014, was primarily due to higher compensation expense recorded in fiscal 2014 in connection with our acquisition of the remaining interest in Insieme Networks, Inc. (“Insieme”). See Note 12 to the Consolidated Financial Statements. Efficiencies arising from our restructuring action announced in August 2014 also contributed to the decrease. These decreases were partially offset by higher contracted services and higher share-based compensation expense.

[0000858877-16-000117:mdna:206]
Sales and Marketing Expenses

[0000858877-16-000117:mdna:207]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:208]
Sales and marketing expenses decreased for fiscal 2016, as compared with fiscal 2015, due to lower discretionary spending and lower headcount-related expenses. The aforementioned items benefited from foreign exchange rates during fiscal 2016. Lower share-based compensation expense also contributed to the decrease.

[0000858877-16-000117:mdna:209]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:210]
Sales and marketing expenses increased for fiscal 2015, as compared with fiscal 2014, due to higher headcount-related expenses, driven by increased variable compensation expense and higher discretionary spending, partially offset by lower compensation expense from acquisitions.

[0000858877-16-000117:mdna:211]
G&A Expenses

[0000858877-16-000117:mdna:212]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:213]
G&A expenses decreased in fiscal 2016, as compared with fiscal 2015, primarily due to the $253 million pre-tax gain from the sale of our SP Video CPE Business and, to a lesser extent, lower contracted services and lower share-based compensation expense, partially offset by higher headcount-related expenses. The extra week in fiscal 2016 contributed to the increased headcount-related expenses.

[0000858877-16-000117:mdna:214]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:215]
G&A expenses increased in fiscal 2015, as compared with fiscal 2014, primarily due to increased variable compensation expense as a result of our financial performance, higher share-based compensation expense and the timing of corporate-level expenses. Corporate-level expenses, which tend to vary from period to period, included operational infrastructure activities such as IT project implementations, which included investments in our global data center infrastructure, and investments related to operational and financial systems.

[0000858877-16-000117:mdna:216]
Effect of Foreign Currency

[0000858877-16-000117:mdna:217]
In fiscal 2016, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $567 million, or 3.1%, compared with fiscal 2015. In fiscal 2015, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $278 million, or 1.6%, compared with fiscal 2014.

[0000858877-16-000117:mdna:218]
Headcount

[0000858877-16-000117:mdna:219]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:220]
Our headcount increased by approximately 1,800 employees in fiscal 2016 due to headcount additions from targeted hiring in key growth areas in engineering and services, and due also to headcount additions from our recent acquisitions. These headcount additions were partially offset by headcount reductions from our restructuring plan announced in August 2014 and from the sale of the SP Video CPE Business.

[0000858877-16-000117:mdna:221]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:222]
The decrease in headcount of approximately 2,200 employees in fiscal 2015 was due to headcount reductions from attrition and from our restructuring plan announced in August 2014. These headcount reductions were partially offset by headcount additions from targeted hiring in engineering and services, and also by headcount additions from our recent acquisitions.

[0000858877-16-000117:mdna:223]
Share-Based Compensation Expense

[0000858877-16-000117:mdna:224]
The following table presents share-based compensation expense (in millions):

[0000858877-16-000117:mdna:225]
| Years Ended |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Cost of sales—product |  | $ | 70 |  |  | $ | 50 |  |  | $ | 45 |  |
| Cost of sales—service |  | 142 |  |  | 157 |  |  | 150 |  |
| Share-based compensation expense in cost of sales |  | 212 |  |  | 207 |  |  | 195 |  |
| Research and development |  | 470 |  |  | 448 |  |  | 411 |  |
| Sales and marketing |  | 545 |  |  | 559 |  |  | 549 |  |
| General and administrative |  | 205 |  |  | 228 |  |  | 198 |  |
| Restructuring and other charges |  | 26 |  |  | (2 | ) |  | (5 | ) |
| Share-based compensation expense in operating expenses |  | 1,246 |  |  | 1,233 |  |  | 1,153 |  |
| Total share-based compensation expense |  | $ | 1,458 |  |  | $ | 1,440 |  |  | $ | 1,348 |  |

[0000858877-16-000117:mdna:226]
The increase in share-based compensation expense for fiscal 2016, as compared with fiscal 2015, was due primarily to the timing of RSU grants and the impact of the extra week in fiscal 2016, partially offset by lower net expense associated with accelerated and modified awards.

[0000858877-16-000117:mdna:227]
The increase in share-based compensation expense for fiscal 2015, as compared with fiscal 2014, was due primarily to higher expense associated with performance-based restricted stock units and charges associated with severance arrangements with certain executives, partially offset by lower expense related to equity awards assumed with respect to our recent acquisitions.

[0000858877-16-000117:mdna:228]
Amortization of Purchased Intangible Assets

[0000858877-16-000117:mdna:229]
The following table presents the amortization of purchased intangible assets (in millions):

[0000858877-16-000117:mdna:230]
| Years Ended |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 577 |  |  | $ | 814 |  |  | $ | 742 |  |
| Operating expenses |  | 303 |  |  | 359 |  |  | 275 |  |
| Total |  | $ | 880 |  |  | $ | 1,173 |  |  | $ | 1,017 |  |

[0000858877-16-000117:mdna:231]
Amortization of purchased intangible assets decreased in fiscal 2016, as compared with fiscal 2015, due to certain purchased intangible assets having become fully amortized or impaired, partially offset by amortization of purchased intangible assets from our recent acquisitions. Lower impairment charges in fiscal 2016 also contributed to the decrease.

[0000858877-16-000117:mdna:232]
Amortization of purchased intangible assets increased in fiscal 2015 as compared with fiscal 2014, primarily due to the impairment charges of approximately $175 million recorded in fiscal 2015. The impairment charges were primarily due to declines in estimated fair value resulting from reductions in or the elimination of expected future cash flows associated with certain of our technology and IPR&D intangible assets.

[0000858877-16-000117:mdna:233]
Restructuring and Other Charges

[0000858877-16-000117:mdna:234]
In connection with a restructuring action announced in August 2014, we incurred restructuring and other charges of $267 million and $489 million during fiscal 2016 and 2015, respectively. These charges were related primarily to severance and other one-time termination benefits and other associated costs. We completed this plan at the end of fiscal 2016.

[0000858877-16-000117:mdna:235]
In connection with a restructuring action announced in August 2013, we incurred restructuring and other charges of approximately $418 million during fiscal 2014, which were related primarily to employee severance charges for employees impacted by our workforce reduction under this plan. We completed this plan at the end of fiscal 2014.

[0000858877-16-000117:mdna:236]
In August 2016, we announced a restructuring plan that will impact up to 5,500 employees, representing approximately 7% of our global workforce. We began taking action under this plan in the first quarter of fiscal 2017. We currently estimate that we will recognize pre-tax charges in an amount of up to $700 million consisting of severance and other one-time termination benefits, and other associated costs.  We expect that approximately $325 million to $400 million of these charges will be recognized during the first quarter of fiscal 2017, with the remaining amount to be recognized during the rest of the fiscal 2017. We expect to reinvest substantially all of the cost savings from the restructuring actions in our key priority areas such as security, IoT, collaboration, next generation data center and cloud.  As a result, the overall cost savings from these restructuring actions are not expected to be material for future periods.

[0000858877-16-000117:mdna:237]
Operating Income

[0000858877-16-000117:mdna:238]
The following table presents our operating income and our operating income as a percentage of revenue (in millions, except percentages):

[0000858877-16-000117:mdna:239]
| Years Ended |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Operating income |  | $ | 12,660 |  |  | $ | 10,770 |  |  | $ | 9,345 |  |
| Operating income as a percentage of revenue |  | 25.7 | % |  | 21.9 | % |  | 19.8 | % |

[0000858877-16-000117:mdna:240]
For fiscal 2016, as compared with fiscal 2015, operating income increased by 18%, and as a percentage of revenue operating income increased by 3.8 percentage points. The increase resulted from the following: a gross margin percentage increase, driven in part by the sale of the lower margin SP Video CPE Business during fiscal 2016; the $253 million pre-tax gain from the sale of our SP Video CPE Business; and a decrease in restructuring and other charges related to the restructuring action announced in August 2014.

[0000858877-16-000117:mdna:241]
For fiscal 2015, as compared with fiscal 2014, operating income increased by 15%, and as a percentage of revenue operating income increased by 2.1 percentage points. The increase resulted from the following: an increase in revenue; a gross margin percentage increase, driven in part by the $655 million supplier component remediation charge (or 1.4 percentage points of fiscal 2014 revenue) recorded in fiscal 2014; and higher compensation expense recorded in fiscal 2014 in connection with our acquisition of the remaining interest in Insieme.

[0000858877-16-000117:mdna:242]
Interest and Other Income (Loss), Net

[0000858877-16-000117:mdna:243]
Interest Income (Expense), Net   The following table summarizes interest income and interest expense (in millions):

[0000858877-16-000117:mdna:244]
|  | Years Ended |  | 2016 vs. 2015 |  | 2015 vs. 2014 |
|  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |  | Variance in Dollars |  | Variance in Dollars |
| Interest income | $ | 1,005 |  |  | $ | 769 |  |  | $ | 691 |  |  | $ | 236 |  |  | $ | 78 |  |
| Interest expense | (676 | ) |  | (566 | ) |  | (564 | ) |  | (110 | ) |  | (2 | ) |
| Interest income (expense), net | $ | 329 |  |  | $ | 203 |  |  | $ | 127 |  |  | $ | 126 |  |  | $ | 76 |  |

[0000858877-16-000117:mdna:245]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:246]
Interest income increased in fiscal 2016 as compared with fiscal 2015, driven by an increase in our portfolio of cash, cash equivalents, and fixed income investments as well as higher yields on our portfolio of cash and investments. The increase in interest expense in fiscal 2016 compared with fiscal 2015 was driven by higher average debt balances and the impact of higher effective interest rates on floating-rate senior notes and interest rate swaps associated with fixed-rate senior notes.

[0000858877-16-000117:mdna:247]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:248]
Interest income increased in fiscal 2015 as compared with fiscal 2014, driven by an increase in our portfolio of cash, cash equivalents, and fixed income investments. Interest expense in fiscal 2015 as compared with the prior fiscal year increased slightly, driven by additional interest expense due to the net increase in long-term debt in fiscal 2015.

[0000858877-16-000117:mdna:249]
Other Income (Loss), Net   The components of other income (loss), net, are summarized as follows (in millions):

[0000858877-16-000117:mdna:250]
|  | Years Ended |  | 2016 vs. 2015 |  | 2015 vs. 2014 |
|  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |  | Variance in Dollars |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |
| Publicly traded equity securities | $ | 33 |  |  | $ | 116 |  |  | $ | 253 |  |  | $ | (83 | ) |  | $ | (137 | ) |
| Fixed income securities | (34 | ) |  | 41 |  |  | 47 |  |  | (75 | ) |  | (6 | ) |
| Total available-for-sale investments | (1 | ) |  | 157 |  |  | 300 |  |  | (158 | ) |  | (143 | ) |
| Privately held companies | (35 | ) |  | 82 |  |  | (60 | ) |  | (117 | ) |  | 142 |  |
| Net gains (losses) on investments | (36 | ) |  | 239 |  |  | 240 |  |  | (275 | ) |  | (1 | ) |
| Other gains (losses), net | (33 | ) |  | (11 | ) |  | 3 |  |  | (22 | ) |  | (14 | ) |
| Other income (loss), net | $ | (69 | ) |  | $ | 228 |  |  | $ | 243 |  |  | $ | (297 | ) |  | $ | (15 | ) |

[0000858877-16-000117:mdna:251]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:252]
The change in total net gains (losses) on available-for-sale investments in fiscal 2016, as compared with fiscal 2015, was primarily attributable to lower realized gains on publicly traded equity securities and net losses on fixed income securities in fiscal 2016 compared to net gains in fiscal 2015 as a result of market conditions and the timing of sales of these securities.

[0000858877-16-000117:mdna:253]
The change in net gains (losses) on investments in privately held companies in fiscal 2016, as compared with fiscal 2015, was primarily due to a gain of $126 million related to the reorganization of our investment in VCE, which was recorded in fiscal 2015.

[0000858877-16-000117:mdna:254]
The change in other gains (losses), net in fiscal 2016, as compared with fiscal 2015, was driven by higher donation expenses and net unfavorable foreign exchange impacts, partially offset by higher gains from customer lease terminations.

[0000858877-16-000117:mdna:255]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:256]
The decrease in total net gains on available-for-sale investments in fiscal 2015 compared with fiscal 2014 was primarily attributable to lower gains on publicly traded equity securities in the current period as a result of market conditions and the timing of sales of these securities.

[0000858877-16-000117:mdna:257]
The change in net gains (losses) on investments in privately held companies for the fiscal 2015 as compared with fiscal 2014 was primarily due to a $126 million gain recorded in fiscal 2015 related to the reorganization of our investments in VCE and lower losses related to this investment under the equity method. We ceased accounting for VCE under the equity method in October 2014. These favorable items were partially offset by higher impairment charges and lower realized gains from sales of various investments in privately held companies.

[0000858877-16-000117:mdna:258]
The change in other gains (losses), net in fiscal 2015 as compared with fiscal 2014 was driven by equity derivative impacts and higher donation expenses, partially offset by net favorable foreign exchange impacts in fiscal 2015.

[0000858877-16-000117:mdna:259]
Provision for Income Taxes

[0000858877-16-000117:mdna:260]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates, higher than anticipated in countries that have higher tax rates, and expiration of or lapses in tax incentives. Our provision for income taxes does not include provisions for U.S. income taxes and foreign withholding taxes associated with the repatriation of undistributed earnings of certain foreign subsidiaries that we intend to reinvest indefinitely in our foreign subsidiaries. If these earnings were distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. Further, as a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes.

[0000858877-16-000117:mdna:261]
Fiscal 2016 Compared with Fiscal 2015

[0000858877-16-000117:mdna:262]
The provision for income taxes resulted in an effective tax rate of 16.9% for fiscal 2016, compared with 19.8% for fiscal 2015. The net 2.9 percentage point decrease in the effective tax rates between fiscal years was primarily due to a non-recurring net tax benefit of $367 million, or 2.8 percentage points, related to a tax settlement with the IRS in fiscal 2016.

[0000858877-16-000117:mdna:263]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 35% and for further explanation of our provision for income taxes, see Note 16 to the Consolidated Financial Statements.

[0000858877-16-000117:mdna:264]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-16-000117:mdna:265]
The provision for income taxes resulted in an effective tax rate of 19.8% for fiscal 2015, compared with 19.2% for fiscal 2014. The net 0.6 percentage point increase in the effective tax rate between fiscal years was primarily due to a decrease in foreign income taxed at lower than U.S. rates, partially offset by an increase in U.S. federal R&D tax credit.

[0000858877-16-000117:mdna:266]
LIQUIDITY AND CAPITAL RESOURCES

[0000858877-16-000117:mdna:267]
The following sections discuss the effects of changes in our balance sheet, our capital allocation strategy including stock repurchase program and dividends, our contractual obligations, and certain other commitments and activities on our liquidity and capital resources.

[0000858877-16-000117:mdna:268]
Balance Sheet and Cash Flows

[0000858877-16-000117:mdna:269]
Cash and Cash Equivalents and Investments  The following table summarizes our cash and cash equivalents and investments (in millions):

[0000858877-16-000117:mdna:270]
|  | July 30, 2016 |  | July 25, 2015 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 7,631 |  |  | $ | 6,877 |  |  | $ | 754 |  |
| Fixed income securities | 56,621 |  |  | 51,974 |  |  | 4,647 |  |
| Publicly traded equity securities | 1,504 |  |  | 1,565 |  |  | (61 | ) |
| Total | $ | 65,756 |  |  | $ | 60,416 |  |  | $ | 5,340 |  |

[0000858877-16-000117:mdna:271]
The net increase in cash and cash equivalents and investments from fiscal 2015 to fiscal 2016 was primarily the result of cash provided by operating activities of $13.6 billion, a net increase in debt of $3.1 billion, proceeds from issuance of common stock of $1.1 billion pursuant to employee stock incentive and purchase plans, and net proceeds from the sale of our SP Video CPE Business of $0.4 billion. These sources of cash were partially offset by cash returned to shareholders in the form of cash dividends of $4.8 billion and repurchase of common stock of $3.9 billion under the stock repurchase program, net cash paid for acquisitions of $3.2 billion and capital expenditures of $1.1 billion.

[0000858877-16-000117:mdna:272]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $59.8 billion and $53.4 billion as of July 30, 2016 and July 25, 2015, respectively. Under current tax laws and regulations, if these assets were to be distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. The balance of cash and cash equivalents and investments available in the United States as of July 30, 2016 and July 25, 2015 was $5.9 billion and $7.0 billion, respectively.

[0000858877-16-000117:mdna:273]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our fixed income investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-16-000117:mdna:274]
Free Cash Flow and Capital Allocation   As part of our capital allocation strategy, we intend to return a minimum of 50% of our free cash flow annually to our shareholders through cash dividends and repurchases of common stock.

[0000858877-16-000117:mdna:275]
We define free cash flow as net cash provided by operating activities less cash used to acquire property and equipment. The following table reconciles our net cash provided by operating activities to free cash flow (in millions):

[0000858877-16-000117:mdna:276]
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Net cash provided by operating activities | $ | 13,570 |  |  | $ | 12,552 |  |  | $ | 12,332 |  |
| Acquisition of property and equipment | (1,146 | ) |  | (1,227 | ) |  | (1,275 | ) |
| Free cash flow | $ | 12,424 |  |  | $ | 11,325 |  |  | $ | 11,057 |  |

[0000858877-16-000117:mdna:277]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue, excess tax benefits resulting from share-based compensation, and the timing and amount of tax and other payments. For additional discussion, see “Part I, Item 1A. Risk Factors” in this report.

[0000858877-16-000117:mdna:278]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases. We further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period.  In addition, we have other required uses of cash, including

[0000858877-16-000117:mdna:279]
repaying the principal of our outstanding indebtedness. Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net income provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-16-000117:mdna:280]
The following table summarizes the dividends paid and stock repurchases (in millions, except per-share amounts):

[0000858877-16-000117:mdna:281]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  | TOTAL |
| Years Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | Amount |
| July 30, 2016 |  | $ | 0.94 |  |  | $ | 4,750 |  |  | 148 |  |  | $ | 26.45 |  |  | $ | 3,918 |  |  | $ | 8,668 |  |
| July 25, 2015 |  | $ | 0.80 |  |  | $ | 4,086 |  |  | 155 |  |  | $ | 27.22 |  |  | $ | 4,234 |  |  | $ | 8,320 |  |
| July 26, 2014 |  | $ | 0.72 |  |  | $ | 3,758 |  |  | 420 |  |  | $ | 22.71 |  |  | $ | 9,539 |  |  | $ | 13,297 |  |

[0000858877-16-000117:mdna:282]
Any future dividends are subject to the approval of our Board of Directors.

[0000858877-16-000117:mdna:283]
Accounts Receivable, Net The following table summarizes our accounts receivable, net (in millions), and DSO:

[0000858877-16-000117:mdna:284]
|  | July 30, 2016 |  | July 25, 2015 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,847 |  |  | $ | 5,344 |  |  | $ | 503 |  |
| DSO | 42 |  |  | 38 |  |  | 4 |  |

[0000858877-16-000117:mdna:285]
Our accounts receivable net, as of July 30, 2016 increased by approximately 9% compared with the end of fiscal 2015. Our DSO as of July 30, 2016 was higher by four days as compared with the end of fiscal 2015, as there was a relatively higher proportion of service billings in the latter part of the fourth quarter in fiscal 2016.

[0000858877-16-000117:mdna:286]
Inventory Supply Chain  The following table summarizes our inventories and purchase commitments with contract manufacturers and suppliers (in millions, except annualized inventory turns):

[0000858877-16-000117:mdna:287]
|  | July 30, 2016 |  | July 25, 2015 |  | Increase (Decrease) |
| Inventories | $ | 1,217 |  |  | $ | 1,627 |  |  | $ | (410 | ) |
| Annualized inventory turns | 14.6 |  |  | 12.1 |  |  | 2.5 |  |
| Purchase commitments with contract manufacturers and suppliers | $ | 3,896 |  |  | $ | 4,078 |  |  | $ | (182 | ) |

[0000858877-16-000117:mdna:288]
Inventory as of July 30, 2016 decreased by 25% from our inventory balance at the end of fiscal 2015, and for the same period purchase commitments with contract manufacturers and suppliers decreased by approximately 4%. On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers decreased by 10% compared with the end of fiscal 2015. The decrease in inventory and purchase commitments with contract manufacturers and suppliers was due in part to the sale of the SP Video CPE Business. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-16-000117:mdna:289]
Our finished goods consist of distributor inventory and deferred cost of sales and manufactured finished goods. Distributor inventory and deferred cost of sales are related to unrecognized revenue on shipments to distributors and retail partners as well as shipments to customers. Manufactured finished goods consist primarily of build-to-order and build-to-stock products.

[0000858877-16-000117:mdna:290]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity.

[0000858877-16-000117:mdna:291]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of rapidly changing technology and customer requirements. We believe the amount of our inventory and purchase commitments is appropriate for our revenue levels.

[0000858877-16-000117:mdna:292]
Financing Receivables and Guarantees We measure our net balance sheet exposure position related to our financing receivables and financing guarantees by reducing the total of gross financing receivables and financing guarantees by the associated allowances for credit loss and deferred revenue. As of July 30, 2016, our net balance sheet exposure position related to financing receivables and financing guarantees was as follows (in millions):

[0000858877-16-000117:mdna:293]
|  | FINANCING RECEIVABLES |  | FINANCING GUARANTEES |  |  |
| July 30, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |  | Channel Partner |  | End-User Customers |  | Total |  | TOTAL |
| Financing receivables and guarantees | $ | 3,474 |  |  | $ | 2,135 |  |  | $ | 3,370 |  |  | $ | 8,979 |  |  | $ | 281 |  |  | $ | 96 |  |  | $ | 377 |  |  | $ | 9,356 |  |
| Unearned income | (174 | ) |  | — |  |  | — |  |  | (174 | ) |  | — |  |  | — |  |  | — |  |  | (174 | ) |
| Allowance for credit loss | (230 | ) |  | (97 | ) |  | (48 | ) |  | (375 | ) |  | — |  |  | — |  |  | — |  |  | (375 | ) |
| Deferred revenue | (6 | ) |  | (15 | ) |  | (1,716 | ) |  | (1,737 | ) |  | (85 | ) |  | (76 | ) |  | (161 | ) |  | (1,898 | ) |
| Net balance sheet exposure | $ | 3,064 |  |  | $ | 2,023 |  |  | $ | 1,606 |  |  | $ | 6,693 |  |  | $ | 196 |  |  | $ | 20 |  |  | $ | 216 |  |  | $ | 6,909 |  |

[0000858877-16-000117:mdna:294]
Financing Receivables  Financing receivables less unearned income increased by 1% compared with the end of fiscal 2015. The change was primarily due to a 21% increase in loan receivables partially offset by a 6% decrease in financed service contracts and other and a 3% decrease in lease receivables. We provide financing to certain end-user customers and channel partners to enable sales of our products, services, and networking solutions. These financing arrangements include leases, financed service contracts, and loans. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Lease receivables include sales-type and direct-financing leases. We also provide certain qualified customers financing for long-term service contracts, which primarily relate to technical support services. Our loan financing arrangements may include not only financing the acquisition of our products and services but also providing additional funds for other costs associated with network installation and integration of our products and services. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-16-000117:mdna:295]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements to customers provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms. The volume of channel partner financing was $26.9 billion, $25.9 billion, and $24.6 billion in fiscal 2016, 2015, and 2014, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.1 billion and $1.2 billion as of July 30, 2016 and July 25, 2015, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed.

[0000858877-16-000117:mdna:296]
Deferred Revenue Related to Financing Receivables and Guarantees The majority of the deferred revenue in the preceding table is related to financed service contracts. The majority of the revenue related to financed service contracts, which primarily relates to technical support services, is deferred as the revenue related to financed service contracts is recognized ratably over the period during which the related services are to be performed. A portion of the revenue related to lease and loan receivables is also deferred and included in deferred product revenue based on revenue recognition criteria not currently having been met.

[0000858877-16-000117:mdna:297]
60

[0000858877-16-000117:mdna:298]
Borrowings

[0000858877-16-000117:mdna:299]
Senior Notes  The following table summarizes the principal amount of our senior notes (in millions):

[0000858877-16-000117:mdna:300]
|  | Maturity Date |  | July 30, 2016 |  | July 25, 2015 |  |
| Senior notes: |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | $ | 850 |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 1,000 |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 | (1) | 1,000 |  |  | — |  |  |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 900 |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 500 |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | — |  |  | 3,000 |  |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 2,400 |  |  |
| 3.15% | March 14, 2017 |  | 750 |  |  | 750 |  |  |
| 1.40% | February 28, 2018 | (1) | 1,250 |  |  | — |  |  |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1,600 |  |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |  |
| 1.60% | February 28, 2019 | (1) | 1,000 |  |  | — |  |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |  |
| 2.20% | February 28, 2021 | (1) | 2,500 |  |  | — |  |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |  |
| 2.60% | February 28, 2023 | (1) | 500 |  |  | — |  |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |  |
| 2.95% | February 28, 2026 | (1) | 750 |  |  | — |  |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |  |
| Total |  |  | $ | 28,400 |  |  | $ | 25,250 |  |  |

[0000858877-16-000117:mdna:301]
(1) In February 2016, we issued senior notes with an aggregate principal amount of $7.0 billion.

[0000858877-16-000117:mdna:302]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of July 30, 2016.

[0000858877-16-000117:mdna:303]
We repaid the fixed-rate notes (5.50%) due on February 22, 2016 for an aggregate principal amount of $3.0 billion upon maturity.

[0000858877-16-000117:mdna:304]
We repaid the floating-rate notes due on September 3, 2015 for an aggregate principal amount of $850 million upon maturity.

[0000858877-16-000117:mdna:305]
Other Debt  Other debt as of July 30, 2016 and July 25, 2015 includes secured borrowings associated with customer financing arrangements. The amount of borrowings outstanding under these arrangements was $1 million and $4 million as of July 30, 2016 and July 25, 2015, respectively.

[0000858877-16-000117:mdna:306]
Commercial Paper  We established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of each of July 30, 2016 and July 25, 2015.

[0000858877-16-000117:mdna:307]
Credit Facility  On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial

[0000858877-16-000117:mdna:308]
Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. The credit agreement requires that we comply with certain covenants, including that it maintains an interest coverage ratio as defined in the agreement.

[0000858877-16-000117:mdna:309]
We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. We were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-16-000117:mdna:310]
Deferred Revenue   The following table presents the breakdown of deferred revenue (in millions):

[0000858877-16-000117:mdna:311]
|  | July 30, 2016 |  | July 25, 2015 |  | Increase (Decrease) |
| Service | $ | 10,621 |  |  | $ | 9,757 |  |  | $ | 864 |  |
| Product | 5,851 |  |  | 5,426 |  |  | 425 |  |
| Total | $ | 16,472 |  |  | $ | 15,183 |  |  | $ | 1,289 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 10,155 |  |  | $ | 9,824 |  |  | $ | 331 |  |
| Noncurrent | 6,317 |  |  | 5,359 |  |  | 958 |  |
| Total | $ | 16,472 |  |  | $ | 15,183 |  |  | $ | 1,289 |  |

[0000858877-16-000117:mdna:312]
Total deferred revenue increased 8% in fiscal 2016. Deferred service revenue increased 9% driven by the timing of multiyear arrangements, an increase in customers paying technical support service contracts over time and the impact of ongoing amortization of deferred service revenue. Deferred product revenue increased 8% primarily due to increased deferrals related to subscription and software revenue arrangements, partially offset by lower deferred revenue related to two-tier distributors. The product categories of Collaboration, Security, and Wireless were the key contributors to the increase in deferred product revenue. The portion of deferred product revenue related to recurring software and subscriptions increased 33% including the portion related to our Security products which increased 29% and our Collaboration products which increased 13%.

[0000858877-16-000117:mdna:313]
Contractual Obligations

[0000858877-16-000117:mdna:314]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. In addition, we plan for and measure our liquidity and capital resources through an annual budgeting process. The following table summarizes our contractual obligations at July 30, 2016 (in millions):

[0000858877-16-000117:mdna:315]
|  | PAYMENTS DUE BY PERIOD |
| July 30, 2016 | Total |  | Less than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than 5 Years |
| Operating leases | $ | 1,159 |  |  | $ | 363 |  |  | $ | 446 |  |  | $ | 190 |  |  | $ | 160 |  |
| Purchase commitments with contract manufacturers and suppliers | 3,896 |  |  | 3,896 |  |  | — |  |  | — |  |  | — |  |
| Other purchase obligations | 2,010 |  |  | 726 |  |  | 712 |  |  | 523 |  |  | 49 |  |
| Senior notes | 28,400 |  |  | 4,150 |  |  | 10,000 |  |  | 7,000 |  |  | 7,250 |  |
| Other long-term liabilities | 1,153 |  |  | — |  |  | 182 |  |  | 127 |  |  | 844 |  |
| Total by period | $ | 36,618 |  |  | $ | 9,135 |  |  | $ | 11,340 |  |  | $ | 7,840 |  |  | $ | 8,303 |  |
| Other long-term liabilities (uncertainty in the timing of future payments) | 1,203 |  |  |  |  |  |  |  |  |  |
| Total | $ | 37,821 |  |  |  |  |  |  |  |  |  |

[0000858877-16-000117:mdna:316]
Operating Leases   For more information on our operating leases, see Note 12 to the Consolidated Financial Statements.

[0000858877-16-000117:mdna:317]
Purchase Commitments with Contract Manufacturers and Suppliers   We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. A significant portion of our reported estimated purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. See further discussion in “Inventory Supply Chain.” As of July 30, 2016, the liability for these purchase commitments was $159 million and is recorded in other current liabilities and is not included in the preceding table.

[0000858877-16-000117:mdna:318]
Other Purchase Obligations   Other purchase obligations represent an estimate of all contractual obligations in the ordinary course of business, other than operating leases and commitments with contract manufacturers and suppliers, for which we have not received the goods or services. Purchase orders are not included in the preceding table as they typically represent our authorization to purchase rather than binding contractual purchase obligations.

[0000858877-16-000117:mdna:319]
Long-Term Debt   The amount of long-term debt in the preceding table represents the principal amount of the respective debt instruments. See Note 10 to the Consolidated Financial Statements.

[0000858877-16-000117:mdna:320]
Other Long-Term Liabilities   Other long-term liabilities primarily include noncurrent income taxes payable, accrued liabilities for deferred compensation, noncurrent deferred tax liabilities, and certain other long-term liabilities. Due to the uncertainty in the timing of future payments, our noncurrent income taxes payable of approximately $925 million and noncurrent deferred tax liabilities of $278 million were presented as one aggregated amount in the total column on a separate line in the preceding table. Noncurrent income taxes payable include uncertain tax positions (see Note 16 to the Consolidated Financial Statements).

[0000858877-16-000117:mdna:321]
Other Commitments

[0000858877-16-000117:mdna:322]
In connection with our business combinations and asset purchases, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or the continued employment with us of certain employees of the acquired entities. See Note 12 to the Consolidated Financial Statements.

[0000858877-16-000117:mdna:323]
Insieme Networks, Inc.  In the third quarter of fiscal 2012, we made an investment in Insieme, an early stage company focused on research and development in the data center market. As set forth in the agreement between Cisco and Insieme, this investment included $100 million of funding and a license to certain of our technology. Immediately prior to the call option exercise and acquisition described below, we owned approximately 83% of Insieme as a result of these investments and have consolidated the results of Insieme in our Consolidated Financial Statements. In connection with this investment, we entered into a put/call option agreement that provided us with the right to purchase the remaining interests in Insieme. In addition, the noncontrolling interest holders could require us to purchase their shares upon the occurrence of certain events.

[0000858877-16-000117:mdna:324]
During the first quarter of fiscal 2014, we exercised our call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. During fiscal 2016, 2015, and 2014, we recorded compensation expense of $160 million, $207 million and $416 million, respectively, related to the fair value of the vested portion of amounts that were earned or expected to be earned by the former noncontrolling interest holders. Continued vesting will result in additional compensation expense in future periods.  Based on the terms of the agreement, we have determined that the maximum amount that could be recorded as compensation expense by us is approximately $836 million (which includes the $783 million that has been expensed to date), net of forfeitures.

[0000858877-16-000117:mdna:325]
The former noncontrolling interest holders earned the maximum amount related to the first milestone payment and were paid   approximately $389 million for a portion of this amount during fiscal 2016. During the first quarter of fiscal 2017, we expect to pay approximately $325 million pursuant to the second milestone payment and continued vesting of the first milestone payment.

[0000858877-16-000117:mdna:326]
Other Funding Commitments  We also have certain funding commitments primarily related to our investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $222 million as of July 30, 2016, compared with $205 million as of July 25, 2015.

[0000858877-16-000117:mdna:327]
Off-Balance Sheet Arrangements

[0000858877-16-000117:mdna:328]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and customer financings, and we have determined that as of July 30, 2016 there were no material unconsolidated variable interest entities.

[0000858877-16-000117:mdna:329]
On an ongoing basis, we reassess our investments in privately held companies and customer financings to determine if they are variable interest entities and if we would be regarded as the primary beneficiary pursuant to the applicable accounting guidance. As a result of this ongoing assessment, we may be required to make additional disclosures or consolidate these entities. Because we may not control these entities, we may not have the ability to influence these events.

[0000858877-16-000117:mdna:330]
We provide financing guarantees, which are generally for various third-party financing arrangements extended to our channel partners and end-user customers. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. See the previous discussion of these financing guarantees under “Financing Receivables and Guarantees.”

[0000858877-16-000117:mdna:331]
Securities Lending

[0000858877-16-000117:mdna:332]
We periodically engage in securities lending activities with certain of our available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for fiscal 2016 and 2015 was $1.0 billion and $0.4 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of July 30, 2016 and July 25, 2015, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-16-000117:mdna:333]
Liquidity and Capital Resource Requirements

[0000858877-16-000117:mdna:334]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.
