# CSCO notes — 0000858877-16-000117


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-16-000117:notes:1]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-16-000117:notes:2]
|  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Compensation expense related to acquisitions | $ | 282 |  |  | $ | 334 |  |  | $ | 607 |  |


## csco:ConcentrationOfCreditRiskPolicyTextBlock

[0000858877-16-000117:notes:3]
(n) Concentrations of Risk   Cash and cash equivalents are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties.

[0000858877-16-000117:notes:4]
The Company performs ongoing credit evaluations of its customers and, with the exception of certain financing transactions, does not require collateral from its customers. The Company receives certain of its components from sole suppliers. Additionally, the Company relies on a limited number of contract manufacturers and suppliers to provide manufacturing services for its products. The inability of a contract manufacturer or supplier to fulfill supply requirements of the Company could materially impact future operating results.


## csco:DepreciationAndAmortizationPeriodByTypeOfAssetTextBlock

[0000858877-16-000117:notes:5]
Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-16-000117:notes:6]
| Asset Category |  | Period |
| Buildings |  | 25 years |
| Building improvements |  | 10 years |
| Leasehold improvements |  | Shorter of remaining lease term or up to 10 years |
| Computer equipment and related software |  | 30 to 36 months |
| Production, engineering, and other equipment |  | Up to 5 years |
| Operating lease assets |  | Based on lease term |
| Furniture and fixtures |  | 5 years |


## csco:DescriptionOfNewAccountingPronouncementsNotYetAdoptedPolicyTextBlock

[0000858877-16-000117:notes:7]
(x) Recent Accounting Standards or Updates Not Yet Effective as of Fiscal Year End

[0000858877-16-000117:notes:8]
Revenue Recognition  In May 2014, the FASB issued an accounting standard update related to revenue from contracts with customers, which, along with amendments issued in 2015 and 2016, will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance. The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. This accounting standard update, as amended, will be effective for the Company beginning in the first quarter of fiscal 2019. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. Early adoption is permitted, but no earlier than fiscal 2018. The Company expects to adopt this accounting standard update on a modified retrospective basis in the first quarter of fiscal 2019, and it is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-16-000117:notes:9]
Consolidation of Certain Types of Legal Entities  In February 2015, the FASB issued an accounting standard update that changes the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. The accounting standard update was effective for the Company beginning in the first quarter of fiscal 2017. The application of this accounting standard update did not have any impact on the Company's Consolidated Balance Sheet or Statement of Operations upon adoption.

[0000858877-16-000117:notes:10]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-16-000117:notes:11]
Leases  In February 2016, the FASB issued an accounting standard update related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2020 on a modified retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-16-000117:notes:12]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. The accounting standard will be effective for the Company beginning the first quarter of fiscal 2018, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-16-000117:notes:13]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2021 on a modified retrospective basis, and early adoption in fiscal 2020 is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-16-000117:notes:14]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Statements of Cash Flows.


## csco:EntityWideDisclosureOnGeographicAreasLongLivedAssetsTableTextBlock

[0000858877-16-000117:notes:15]
Property and equipment information is based on the physical location of the assets. The following table presents property and equipment information for geographic areas (in millions):

[0000858877-16-000117:notes:16]
|  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Property and equipment, net: |  |  |  |  |  |
| United States | $ | 2,822 |  |  | $ | 2,733 |  |  | $ | 2,697 |  |
| International | 684 |  |  | 599 |  |  | 555 |  |
| Total | $ | 3,506 |  |  | $ | 3,332 |  |  | $ | 3,252 |  |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-16-000117:notes:17]
The following table presents revenue for groups of similar products and services (in millions):

[0000858877-16-000117:notes:18]
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Revenue: |  |  |  |  |  |
| Switching | $ | 14,746 |  |  | $ | 14,740 |  |  | $ | 14,001 |  |
| NGN Routing | 7,408 |  |  | 7,704 |  |  | 7,606 |  |
| Collaboration | 4,352 |  |  | 4,004 |  |  | 3,817 |  |
| Data Center | 3,365 |  |  | 3,219 |  |  | 2,640 |  |
| Wireless | 2,625 |  |  | 2,542 |  |  | 2,293 |  |
| Service Provider Video (1) | 2,424 |  |  | 3,555 |  |  | 3,969 |  |
| Security | 1,969 |  |  | 1,747 |  |  | 1,566 |  |
| Other | 365 |  |  | 239 |  |  | 280 |  |
| Product | 37,254 |  |  | 37,750 |  |  | 36,172 |  |
| Service | 11,993 |  |  | 11,411 |  |  | 10,970 |  |
| Total | $ | 49,247 |  |  | $ | 49,161 |  |  | $ | 47,142 |  |

[0000858877-16-000117:notes:19]
(1) During the second quarter of fiscal 2016, the Company completed the sale of our SP Video CPE Business. As a result, revenue from this portion of the Service Provider Video product category will not recur in future periods. SP Video CPE Business revenue was $504 million, $1,846 million, and $2,240 million for fiscal 2016, 2015 and 2014, respectively.


## csco:OtherThanTemporaryImpairmentLossesOnInvestmentsPolicyTextBlock

[0000858877-16-000117:notes:20]
(c) Other-than-Temporary Impairments on Investments   When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and the Company will assess whether the impairment is other than temporary. An impairment is considered other than temporary if (i) the Company has the intent to sell the security, (ii) it is more likely than not that the Company will be required to sell the security before recovery of the entire amortized cost basis, or (iii) the Company does not expect to recover the entire amortized cost basis of the security. If impairment is considered other than temporary based on condition (i) or (ii) described earlier, the entire difference between the amortized cost and the fair value of the debt security is recognized in earnings. If an impairment is considered other than temporary based on condition (iii), the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) will be recognized in earnings, and the amount relating to all other factors will be recognized in other comprehensive income (OCI).

[0000858877-16-000117:notes:21]
The Company recognizes an impairment charge on publicly traded equity securities when a decline in the fair value of a security below the respective cost basis is judged to be other than temporary. The Company considers various factors in determining whether a decline in the fair value of these investments is other than temporary, including the length of time and extent to which the fair value of the security has been less than the Company’s cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the investment for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-16-000117:notes:22]
Investments in privately held companies are included in other assets in the Consolidated Balance Sheets and are primarily accounted for using either the cost or equity method. The Company monitors these investments for impairments and makes reductions in carrying values if the Company determines that an impairment charge is required based primarily on the financial condition and near-term prospects of these companies.


## csco:RecentlyAdoptedAccountingStandardsPolicyTextBlock

[0000858877-16-000117:notes:23]
(w) New Accounting Updates Recently Adopted

[0000858877-16-000117:notes:24]
Classification of Deferred Taxes  In the fourth quarter of fiscal 2016, the Company elected to early adopt an accounting standard update requiring all deferred tax assets and liabilities to be classified as non-current on the  balance sheet instead of separating deferred taxes into current and non-current. The amended standard was adopted on a retrospective basis. As a result of the adoption, the Company made the following adjustments to the Consolidated Balance Sheet for fiscal 2015: a $2.9 billion decrease to current deferred tax assets, a $2.8 billion increase to non-current deferred tax assets, a $211 million decrease to current deferred tax liabilities, and an increase of $103 million to non-current deferred tax liabilities.


## csco:ScheduleOfCommonStockRepurchasedTextBlock

[0000858877-16-000117:notes:25]
A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-16-000117:notes:26]
|  | SharesRepurchased |  | Weighted-Average Priceper Share |  | AmountRepurchased |
| Cumulative balance at July 26, 2014 | 4,288 |  |  | $ | 20.63 |  |  | $ | 88,445 |  |
| Repurchase of common stock under the stock repurchase program (1) | 155 |  |  | 27.22 |  |  | 4,234 |  |
| Cumulative balance at July 25, 2015 | 4,443 |  |  | 20.86 |  |  | 92,679 |  |
| Repurchase of common stock under the stock repurchase program (2) | 148 |  |  | 26.45 |  |  | 3,918 |  |
| Cumulative balance at July 30, 2016 | 4,591 |  |  | $ | 21.04 |  |  | $ | 96,597 |  |

[0000858877-16-000117:notes:27]
(1) Includes stock repurchases of $36 million, which were pending settlement as of July 25, 2015.

[0000858877-16-000117:notes:28]
(2) Includes stock repurchases of $45 million, which were pending settlement as of July 30, 2016.


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-16-000117:notes:29]
The effect on the Consolidated Statements of Operations of derivative instruments designated as fair value hedges and the underlying hedged items is summarized as follows (in millions):

[0000858877-16-000117:notes:30]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVE INSTRUMENTS FOR THE YEARS ENDED |  | GAINS (LOSSES) RELATED TO HEDGED ITEMS FOR THE YEARS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Equity derivatives |  | Other income (loss), net |  | $ | — |  |  | $ | 56 |  |  | $ | (72 | ) |  | $ | — |  |  | $ | (56 | ) |  | $ | 72 |  |
| Interest rate derivatives |  | Interest expense |  | 175 |  |  | 54 |  |  | (2 | ) |  | (169 | ) |  | (57 | ) |  | — |  |
| Total |  |  |  | $ | 175 |  |  | $ | 110 |  |  | $ | (74 | ) |  | $ | (169 | ) |  | $ | (113 | ) |  | $ | 72 |  |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-16-000117:notes:31]
The following table presents the amortization of purchased intangible assets (in millions):

[0000858877-16-000117:notes:32]
| Years Ended |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 577 |  |  | $ | 814 |  |  | $ | 742 |  |
| Operating expenses |  | 303 |  |  | 359 |  |  | 275 |  |
| Total |  | $ | 880 |  |  | $ | 1,173 |  |  | $ | 1,017 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-16-000117:notes:33]
The following tables present details of the Company’s intangible assets acquired through acquisitions completed during fiscal 2016 and 2015 (in millions, except years):

[0000858877-16-000117:notes:34]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2016 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| MaintenanceNet | 5.0 |  | $ | 50 |  |  | 5.0 |  | $ | 2 |  |  | 2.0 |  | $ | 2 |  |  | $ | 11 |  |  | $ | 65 |  |
| OpenDNS | 5.0 |  | 43 |  |  | 7.0 |  | 15 |  |  | 1.0 |  | 2 |  |  | 1 |  |  | 61 |  |
| Lancope | 5.0 |  | 79 |  |  | 6.0 |  | 29 |  |  | 3.0 |  | 3 |  |  | 10 |  |  | 121 |  |
| Acano | 5.0 |  | 9 |  |  | 5.0 |  | 12 |  |  | 0.0 |  | — |  |  | 82 |  |  | 103 |  |
| Leaba | 0.0 |  | — |  |  | 0.0 |  | — |  |  | 0.0 |  | — |  |  | 96 |  |  | 96 |  |
| Jasper | 6.0 |  | 240 |  |  | 7.0 |  | 75 |  |  | 2.0 |  | 23 |  |  | 23 |  |  | 361 |  |
| CliQr | 6.0 |  | 65 |  |  | 6.0 |  | 3 |  |  | 2.0 |  | 1 |  |  | — |  |  | 69 |  |
| Others (five in total) | 4.1 |  | 58 |  |  | 6.3 |  | 6 |  |  | 0.0 |  | — |  |  | — |  |  | 64 |  |
| Total |  |  | $ | 544 |  |  |  |  | $ | 142 |  |  |  |  | $ | 31 |  |  | $ | 223 |  |  | $ | 940 |  |

[0000858877-16-000117:notes:35]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2015 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Metacloud | 3.0 |  | $ | 24 |  |  | 5.0 |  | $ | 3 |  |  | 0.0 |  | $ | — |  |  | $ | 2 |  |  | $ | 29 |  |
| Others (five in total) | 4.7 |  | 48 |  |  | 7.8 |  | 12 |  |  | 5.8 |  | 6 |  |  | 4 |  |  | 70 |  |
| Total |  |  | $ | 72 |  |  |  |  | $ | 15 |  |  |  |  | $ | 6 |  |  | $ | 6 |  |  | $ | 99 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-16-000117:notes:36]
The following tables present details of the Company’s purchased intangible assets (in millions):

[0000858877-16-000117:notes:37]
| July 30, 2016 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,038 |  |  | $ | (1,391 | ) |  | $ | 1,647 |  |
| Customer relationships |  | 1,793 |  |  | (1,203 | ) |  | 590 |  |
| Other |  | 85 |  |  | (43 | ) |  | 42 |  |
| Total purchased intangible assets with finite lives |  | 4,916 |  |  | (2,637 | ) |  | 2,279 |  |
| In-process research and development, with indefinite lives |  | 222 |  |  | — |  |  | 222 |  |
| Total |  | $ | 5,138 |  |  | $ | (2,637 | ) |  | $ | 2,501 |  |

[0000858877-16-000117:notes:38]
| July 25, 2015 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,418 |  |  | $ | (1,818 | ) |  | $ | 1,600 |  |
| Customer relationships |  | 1,699 |  |  | (971 | ) |  | 728 |  |
| Other |  | 55 |  |  | (24 | ) |  | 31 |  |
| Total purchased intangible assets with finite lives |  | 5,172 |  |  | (2,813 | ) |  | 2,359 |  |
| In-process research and development, with indefinite lives |  | 17 |  |  | — |  |  | 17 |  |
| Total |  | $ | 5,189 |  |  | $ | (2,813 | ) |  | $ | 2,376 |  |


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-16-000117:notes:39]
| 17. | Segment Information and Major Customers |

[0000858877-16-000117:notes:40]
| (a) | Revenue and Gross Margin by Segment |

[0000858877-16-000117:notes:41]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system. Sales are attributed to a segment based on the ordering location of the customer. The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments. In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, impacts to cost of sales from purchase accounting adjustments to inventory, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-16-000117:notes:42]
Summarized financial information by segment for fiscal 2016, 2015, and 2014, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-16-000117:notes:43]
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Revenue: |  |  |  |  |  |
| Americas | $ | 29,411 |  |  | $ | 29,655 |  |  | $ | 27,781 |  |
| EMEA | 12,281 |  |  | 12,322 |  |  | 12,006 |  |
| APJC | 7,555 |  |  | 7,184 |  |  | 7,355 |  |
| Total | $ | 49,247 |  |  | $ | 49,161 |  |  | $ | 47,142 |  |
| Gross margin: |  |  |  |  |  |
| Americas | $ | 19,006 |  |  | $ | 18,670 |  |  | $ | 17,379 |  |
| EMEA | 7,976 |  |  | 7,705 |  |  | 7,700 |  |
| APJC | 4,622 |  |  | 4,307 |  |  | 4,252 |  |
| Segment total | 31,604 |  |  | 30,682 |  |  | 29,331 |  |
| Unallocated corporate items | (644 | ) |  | (1,001 | ) |  | (1,562 | ) |
| Total | $ | 30,960 |  |  | $ | 29,681 |  |  | $ | 27,769 |  |

[0000858877-16-000117:notes:44]
Revenue in the United States was $26.2 billion, $26.2 billion, and $24.4 billion for fiscal 2016, 2015, and 2014, respectively.

[0000858877-16-000117:notes:45]
| (b) | Revenue for Groups of Similar Products and Services |

[0000858877-16-000117:notes:46]
The Company designs, manufactures, and sells Internet Protocol (IP)-based networking and other products related to the communications and IT industry and provides services associated with these products and their use. The Company groups its products and technologies into the following categories: Switching, NGN Routing, Collaboration, Service Provider Video, Data Center, Wireless, Security, and Other Products. These products, primarily integrated by Cisco IOS Software, link geographically dispersed local-area networks (LANs), metropolitan-area networks (MANs), and wide-area networks (WANs).

[0000858877-16-000117:notes:47]
The Company has made certain reclassifications to the product revenue amounts for prior years to conform to the current year’s presentation.

[0000858877-16-000117:notes:48]
| (c) | Additional Segment Information |

[0000858877-16-000117:notes:49]
The majority of the Company’s assets, excluding cash and cash equivalents and investments, as of July 30, 2016 and July 25, 2015 was attributable to its U.S. operations. The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $59.8 billion and $53.4 billion as of July 30, 2016 and July 25, 2015, respectively, and the remaining $5.9 billion and $7.0 billion at the respective fiscal year ends were available in the United States. In fiscal 2016, 2015, and 2014, no single customer accounted for 10% or more of revenue.


## csco:StockRepurchasesSinceInceptionOfProgramTableTextBlock

[0000858877-16-000117:notes:50]
he stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):

[0000858877-16-000117:notes:51]
|  | Shares ofCommonStock |  | Common Stockand AdditionalPaid-In Capital |  | RetainedEarnings |  | Total CiscoShareholders’Equity |
| Repurchases of common stock under the repurchase program | 4,591 |  |  | $ | 23,895 |  |  | $ | 72,702 |  |  | $ | 96,597 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000858877-16-000117:notes:52]
(p) Advertising Costs   The Company expenses all advertising costs as incurred. Advertising costs included within sales and marketing expenses were approximately $186 million, $202 million, and $196 million for fiscal 2016, 2015, and 2014, respectively.


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-16-000117:notes:53]
The allowances for credit loss and the related financing receivables are summarized as follows (in millions):

[0000858877-16-000117:notes:54]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 25, 2015 | $ | 259 |  |  | $ | 87 |  |  | $ | 36 |  |  | $ | 382 |  |
| Provisions | (13 | ) |  | 13 |  |  | 17 |  |  | 17 |  |
| Recoveries (write-offs), net | (10 | ) |  | — |  |  | (5 | ) |  | (15 | ) |
| Foreign exchange and other | (6 | ) |  | (3 | ) |  | — |  |  | (9 | ) |
| Allowance for credit loss as of July 30, 2016 | $ | 230 |  |  | $ | 97 |  |  | $ | 48 |  |  | $ | 375 |  |

[0000858877-16-000117:notes:55]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 26, 2014 | $ | 233 |  |  | $ | 98 |  |  | $ | 18 |  |  | $ | 349 |  |
| Provisions | 45 |  |  | (8 | ) |  | 20 |  |  | 57 |  |
| Recoveries (write-offs), net | (7 | ) |  | 1 |  |  | (1 | ) |  | (7 | ) |
| Foreign exchange and other | (12 | ) |  | (4 | ) |  | (1 | ) |  | (17 | ) |
| Allowance for credit loss as of July 25, 2015 | $ | 259 |  |  | $ | 87 |  |  | $ | 36 |  |  | $ | 382 |  |

[0000858877-16-000117:notes:56]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 27, 2013 | $ | 238 |  |  | $ | 86 |  |  | $ | 20 |  |  | $ | 344 |  |
| Provisions | 4 |  |  | 9 |  |  | 1 |  |  | 14 |  |
| Recoveries (write-offs), net | (11 | ) |  | 5 |  |  | (3 | ) |  | (9 | ) |
| Foreign exchange and other | 2 |  |  | (2 | ) |  | — |  |  | — |  |
| Allowance for credit loss as of July 26, 2014 | $ | 233 |  |  | $ | 98 |  |  | $ | 18 |  |  | $ | 349 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-16-000117:notes:57]
| 3. | Acquisitions and Divestitures |

[0000858877-16-000117:notes:58]
| (a) | Acquisition Summary |

[0000858877-16-000117:notes:59]
The Company completed 12 acquisitions during fiscal 2016. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-16-000117:notes:60]
| Fiscal 2016 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| MaintenanceNet | $ | 105 |  |  | $ | (21 | ) |  | $ | 65 |  |  | $ | 61 |  |
| OpenDNS | 545 |  |  | (9 | ) |  | 61 |  |  | 493 |  |
| Lancope | 410 |  |  | (34 | ) |  | 121 |  |  | 323 |  |
| Acano | 528 |  |  | (27 | ) |  | 103 |  |  | 452 |  |
| Leaba | 219 |  |  | (18 | ) |  | 96 |  |  | 141 |  |
| Jasper | 1,234 |  |  | 5 |  |  | 361 |  |  | 868 |  |
| CliQr | 225 |  |  | (3 | ) |  | 69 |  |  | 159 |  |
| Others (five in total) | 112 |  |  | (17 | ) |  | 64 |  |  | 65 |  |
| Total | $ | 3,378 |  |  | $ | (124 | ) |  | $ | 940 |  |  | $ | 2,562 |  |

[0000858877-16-000117:notes:61]
On August 6, 2015, the Company completed its acquisition of privately held MaintenanceNet, Inc. ("MaintenanceNet"), a provider  of a cloud-based software platform that uses data analytics and automation to manage renewals of recurring customer contracts.  This acquisition is a component of the Company's strategy for its Services organization to simplify and digitize its business processes.

[0000858877-16-000117:notes:62]
On August 26, 2015, the Company completed its acquisition of privately held OpenDNS, Inc. ("OpenDNS"), a provider of advanced threat protection for endpoint devices. With the OpenDNS acquisition, the Company aims to strengthen its security offerings by adding broad visibility and threat intelligence delivered through a software-as-a-service platform. Revenue from the OpenDNS acquisition has been included in the Company's Security product category.

[0000858877-16-000117:notes:63]
On December 21, 2015, the Company completed its acquisition of privately held Lancope, Inc. ("Lancope"), a provider of network behavior analytics, threat visibility, and security intelligence. With the Lancope acquisition, the Company aims to advance its "security everywhere" strategy with an additional capability of network behavior analytics that extend protection further into the network. Revenue from the Lancope acquisition has been included in the Company's Security product category.

[0000858877-16-000117:notes:64]
On January 29, 2016, the Company completed its acquisition of privately held, London-based Acano (UK) Limited ("Acano"), a collaboration infrastructure and conferencing software provider. With the Acano acquisition, the Company aims to enhance its collaboration strategy to deliver video across both cloud and hybrid environments. Revenue from the Acano acquisition has been included in the Company's Collaboration product category.

[0000858877-16-000117:notes:65]
On March 3, 2016, the Company completed its acquisition of privately held Leaba Semiconductor, Ltd. ("Leaba"), an Israeli-based fabless semiconductor provider whose semiconductor expertise is expected to be leveraged to accelerate the Company's next-generation product portfolio. This acquisition is a component of the Company's strategy to enhance its product offerings in the networking chipset market.

[0000858877-16-000117:notes:66]
On March 18, 2016, the Company completed its acquisition of privately held Jasper Technologies, Inc. ("Jasper"), a provider of a cloud-based Internet of Things (IoT) software-as-a-service platform to help enterprises and service providers launch, manage, and monetize IoT services on a global scale. With the Jasper acquisition, the Company aims to offer an IoT solution that is interoperable across devices and works with IoT service providers, application developers, and an ecosystem of partners. Revenue from the Jasper acquisition has been included in the Company's Other product category.

[0000858877-16-000117:notes:67]
On April 15, 2016, the Company completed its acquisition of privately held CliQr Technologies, Inc. ("CliQr"), an application-defined cloud orchestration platform provider. With the CliQr acquisition, the Company aims to help its customers simplify and accelerate their private, public, and hybrid cloud deployments. Revenue from the CliQr acquisition has been included in the Company's Switching product category.

[0000858877-16-000117:notes:68]
The total purchase consideration related to the Company’s acquisitions completed during fiscal 2016 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $44 million.

[0000858877-16-000117:notes:69]
Fiscal 2015 and 2014 Acquisitions

[0000858877-16-000117:notes:70]
Allocation of the purchase consideration for acquisitions completed in fiscal 2015 is summarized as follows (in millions):

[0000858877-16-000117:notes:71]
| Fiscal 2015 | Purchase Consideration |  | Net Liabilities Assumed |  | Purchased Intangible Assets |  | Goodwill |
| Metacloud | $ | 149 |  |  | $ | (7 | ) |  | $ | 29 |  |  | $ | 127 |  |
| Others (five in total) | 185 |  |  | (13 | ) |  | 70 |  |  | 128 |  |
| Total | $ | 334 |  |  | $ | (20 | ) |  | $ | 99 |  |  | $ | 255 |  |

[0000858877-16-000117:notes:72]
The Company acquired privately held Metacloud, Inc. ("Metacloud") in the first quarter of fiscal 2015. Prior to its acquisition, Metacloud provided private clouds for global organizations. With its acquisition of Metacloud, the Company aims to advance its Intercloud strategy to deliver a globally distributed, highly secure cloud platform. The Company has included revenue from the Metacloud acquisition, subsequent to the acquisition date, in the Company's Service category.

[0000858877-16-000117:notes:73]
The total purchase consideration related to the Company’s acquisitions completed during fiscal 2015 consisted of cash consideration and vested share-based awards assumed.  The total cash and cash equivalents acquired from these acquisitions was approximately $5 million.

[0000858877-16-000117:notes:74]
Allocation of the purchase consideration for acquisitions completed in fiscal 2014 is summarized as follows (in millions):

[0000858877-16-000117:notes:75]
| Fiscal 2014 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Composite Software | $ | 160 |  |  | $ | (10 | ) |  | $ | 75 |  |  | $ | 95 |  |
| Sourcefire | 2,449 |  |  | 81 |  |  | 577 |  |  | 1,791 |  |
| WhipTail | 351 |  |  | (34 | ) |  | 105 |  |  | 280 |  |
| Tail-f | 167 |  |  | (7 | ) |  | 61 |  |  | 113 |  |
| Others (four in total) | 54 |  |  | (5 | ) |  | 20 |  |  | 39 |  |
| Total | $ | 3,181 |  |  | $ | 25 |  |  | $ | 838 |  |  | $ | 2,318 |  |

[0000858877-16-000117:notes:76]
The Company acquired privately held Composite Software, Inc. (“Composite Software”) in the first quarter of fiscal 2014.  Prior to its acquisition, Composite Software provided data virtualization software and services that connect many types of data from across the network and make it appear as if the data is in one place. With its acquisition of Composite Software, the Company intends to extend its next-generation services platform by connecting data and infrastructure.  The Company has included revenue from the Composite Software acquisition, subsequent to the acquisition date, in the Company's Service category.

[0000858877-16-000117:notes:77]
The Company acquired Sourcefire, Inc. (“Sourcefire”) in the first quarter of fiscal 2014.  Prior to its acquisition, Sourcefire delivered innovative, highly automated security through continuous awareness, threat detection, and protection across its portfolio, including next-generation intrusion prevention systems, next-generation firewalls, and advanced malware protection.  With its acquisition of Sourcefire, the Company aims to accelerate its security strategy of defending, discovering, and remediating advanced threats to provide continuous security solutions to the Company’s customers in more places across the network.  The Company has included revenue from the Sourcefire acquisition in its Security product category.

[0000858877-16-000117:notes:78]
The Company acquired privately held WhipTail Technologies, Inc. (“WhipTail”) in the second quarter of fiscal 2014. Prior to its acquisition, WhipTail was a provider of high-performance, scalable solid state memory systems. In the fourth quarter of fiscal 2015, the Company announced the end-of-sale and end-of-life dates for the Cisco UCS Invicta Series in connection with the decision to shut down the WhipTail unit.

[0000858877-16-000117:notes:79]
The Company acquired privately held Tail-f Systems AB ("Tail-f") in the fourth quarter of fiscal 2014. Prior to its acquisitions, Tail-f was a provider of multi-vendor network service orchestration solutions for traditional and virtualized networks. With its acquisition of Tail-f, the Company intends to advance its cloud virtualization strategy. The Company has included revenue from the Tail-f acquisition in the Company's cloud and virtualization offerings within the Other products category.

[0000858877-16-000117:notes:80]
The total purchase consideration related to the Company’s acquisitions completed during fiscal 2014 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $134 million.

[0000858877-16-000117:notes:81]
| (b) | Divestiture of SP Video CPE Business |

[0000858877-16-000117:notes:82]
During the second quarter of fiscal 2016, the Company completed the sale of the assets comprising its SP Video CPE Business to Technicolor SA. As a result of the transaction, the Company received aggregate consideration of $542 million consisting of $372 million in cash and $170 million in Technicolor stock (as of the divestiture date) and the transaction resulted in a gain of $253 million, net of certain transaction costs incurred to date.

[0000858877-16-000117:notes:83]
(c)   Other Acquisition Information

[0000858877-16-000117:notes:84]
Total transaction costs related to the Company’s acquisitions during fiscal 2016, 2015, and 2014 were $32 million, $10 million, and $7 million, respectively. These transaction costs were expensed as incurred in G&A expenses in the Consolidated Statements of Operations.

[0000858877-16-000117:notes:85]
The Company’s purchase price allocation for acquisitions completed during recent periods is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information that existed as of the acquisition date but at that time was unknown to the Company, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date. Adjustments in the purchase price allocation may require a recasting of the amounts allocated to goodwill retroactive to the period in which the acquisition occurred.

[0000858877-16-000117:notes:86]
The goodwill generated from the Company’s acquisitions completed during fiscal 2016 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-16-000117:notes:87]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations for the acquisitions completed during the fiscal years presented have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.


## us-gaap:BusinessCombinationsAndOtherPurchaseOfBusinessTransactionsPolicyTextBlock

[0000858877-16-000117:notes:88]
(h) Business Combinations The Company allocates the fair value of the purchase consideration of its acquisitions to the tangible assets, liabilities, and intangible assets acquired, including in-process research and development (IPR&D), based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life. Acquisition-related expenses and related restructuring costs are recognized separately from the business combination and are expensed as incurred.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000858877-16-000117:notes:89]
(a) Cash and Cash Equivalents   The Company considers all highly liquid investments purchased with an original or remaining maturity of three months or less at the date of purchase to be cash equivalents. Cash and cash equivalents are maintained with various financial institutions.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-16-000117:notes:90]
| 12. | Commitments and Contingencies |

[0000858877-16-000117:notes:91]
| (a) | Operating Leases |

[0000858877-16-000117:notes:92]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, Germany, India, Israel, Japan, Netherlands, Poland, and the United Kingdom.  The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of July 30, 2016 are as follows (in millions):

[0000858877-16-000117:notes:93]
| Fiscal Year | Amount |
| 2017 | $ | 363 |  |
| 2018 | 280 |  |
| 2019 | 166 |  |
| 2020 | 118 |  |
| 2021 | 72 |  |
| Thereafter | 160 |  |
| Total | $ | 1,159 |  |

[0000858877-16-000117:notes:94]
Rent expense for office space and equipment totaled $385 million, $394 million, and $413 million in fiscal 2016, 2015, and 2014, respectively.

[0000858877-16-000117:notes:95]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-16-000117:notes:96]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products.  During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments.  In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed. As of July 30, 2016 and July 25, 2015, the Company had total purchase commitments for inventory of $3,896 million and $4,078 million, respectively.

[0000858877-16-000117:notes:97]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory.  As of July 30, 2016 and July 25, 2015, the liability for these purchase commitments was $159 million and $156 million, respectively, and was included in other current liabilities.

[0000858877-16-000117:notes:98]
| (c) | Other Commitments |

[0000858877-16-000117:notes:99]
In connection with the Company’s acquisitions, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-16-000117:notes:100]
As of July 30, 2016, the Company estimated that future cash compensation expense of up to $328 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme as more fully discussed immediately below.

[0000858877-16-000117:notes:101]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market.  As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology.  Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and has consolidated the results of Insieme in its Consolidated Financial Statements.  In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

[0000858877-16-000117:notes:102]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $160 million, $207 million, and $416 million during fiscal 2016, 2015, and 2014, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders.  Continued vesting will result in additional compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $836 million (which includes the $783 million that has been expensed to date), net of forfeitures.

[0000858877-16-000117:notes:103]
The former noncontrolling interest holders earned the maximum amount related to the first milestone payment and were paid   approximately $389 million for a portion of this amount during fiscal 2016. The majority of the balance of the first milestone payment was paid during fiscal 2016. During the first quarter of fiscal 2017, the Company expects to pay approximately $325 million pursuant to the second milestone payment and continued vesting of the first milestone payment.

[0000858877-16-000117:notes:104]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $222 million and $205 million as of July 30, 2016 and July 25, 2015, respectively.

[0000858877-16-000117:notes:105]
| (d) | Product Warranties |

[0000858877-16-000117:notes:106]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-16-000117:notes:107]
|  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Balance at beginning of fiscal year | $ | 449 |  |  | $ | 446 |  |  | $ | 402 |  |
| Provisions for warranty issued | 715 |  |  | 686 |  |  | 708 |  |
| Adjustments for pre-existing warranties | (8 | ) |  | 10 |  |  | (4 | ) |
| Settlements | (714 | ) |  | (693 | ) |  | (660 | ) |
| Divestiture | (28 | ) |  | — |  |  | — |  |
| Balance at end of fiscal year | $ | 414 |  |  | $ | 449 |  |  | $ | 446 |  |

[0000858877-16-000117:notes:108]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-16-000117:notes:109]
| (e) | Financing and Other Guarantees |

[0000858877-16-000117:notes:110]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-16-000117:notes:111]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $26.9 billion, $25.9 billion, and $24.6 billion in fiscal 2016, 2015, and 2014, respectively. The balance of the channel partner financing subject to guarantees was $1.1 billion and $1.2 billion as of July 30, 2016 and July 25, 2015, respectively.

[0000858877-16-000117:notes:112]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $63 million, $107 million, and $129 million in fiscal 2016, 2015, and 2014, respectively.

[0000858877-16-000117:notes:113]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at July 30, 2016 and July 25, 2015, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-16-000117:notes:114]
|  | July 30, 2016 |  | July 25, 2015 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 281 |  |  | $ | 288 |  |
| End user | 96 |  |  | 129 |  |
| Total | $ | 377 |  |  | $ | 417 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (85 | ) |  | $ | (127 | ) |
| End user | (76 | ) |  | (107 | ) |
| Total | $ | (161 | ) |  | $ | (234 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 216 |  |  | $ | 183 |  |

[0000858877-16-000117:notes:115]
Other Guarantees   The Company’s other guarantee arrangements as of July 30, 2016 and July 25, 2015 that were subject to recognition and disclosure requirements were not material.

[0000858877-16-000117:notes:116]
| (f) | Supplier Component Remediation Liability |

[0000858877-16-000117:notes:117]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components were widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products were beyond the Company's warranty terms, the Company has been proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  During fiscal 2016 and 2015, adjustments to product cost of sales of $74 million and $164 million, respectively, were recorded to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products.  The supplier component remediation liability was $276 million and $408 million as of July 30, 2016 and July 25, 2015, respectively.

[0000858877-16-000117:notes:118]
| (g) | Indemnifications |

[0000858877-16-000117:notes:119]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-16-000117:notes:120]
The Company is providing such indemnifications, among other cases, in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) now pending in Kansas and Delaware. Sprint alleges that the service provider customers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers. Sprint seeks monetary damages. Sprint’s cases in Kansas include claims against Comcast and Time Warner Cable, and the case in Delaware for which the Company is providing indemnification involves Cox Communications ("Cox"). On May 15, 2015, the judge in Sprint's Delaware action against Cox ruled invalid six of the asserted patents and a final judgment was entered on August 27, 2015, of invalidity, which Sprint appealed on October 1, 2015. In light of the invalidity rulings against Sprint in Delaware, the judge in Sprint’s Kansas actions stayed the Kansas actions until resolution of Sprint's appeal from the Delaware action. On March 21, 2016, the judge in Sprint's Delaware action also granted a partial summary judgment for Cox, finding that Cox does not literally infringe five of the remaining patents Sprint has asserted against Cox. On August 5, 2016, Cox filed motions for summary judgment for non-infringement under the doctrine of equivalents as to five patents and lack of damages evidence as to one patent.  Sprint also dropped one patent from the case. The trial date for Sprint’s doctrine of equivalents claims on four patents is set for trial on February 13, 2017. Additionally, Comcast has also won a judgment of non-infringement, now being appealed by Sprint, in a separate case brought against it by Sprint in Delaware.

[0000858877-16-000117:notes:121]
The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims and/or that Sprint's patents are invalid.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should the plaintiff prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

[0000858877-16-000117:notes:122]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-16-000117:notes:123]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-16-000117:notes:124]
| (h) | Legal Proceedings |

[0000858877-16-000117:notes:125]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. In the first quarter of fiscal 2013, the Brazilian federal tax authorities asserted an additional claim against the Company’s Brazilian subsidiary based on a theory of joint liability with respect to an alleged underpayment of income taxes, social taxes, interest, and penalties by a Brazilian distributor. This claim was dismissed on its merits during the third quarter of fiscal 2016.

[0000858877-16-000117:notes:126]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $249 million for the alleged evasion of import and other taxes, $1.3 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of July 30, 2016. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

[0000858877-16-000117:notes:127]
Russia and the Commonwealth of Independent States    At the request of the U.S. Securities and Exchange Commission ("SEC") and the U.S. Department of Justice, the Company has conducted an investigation into allegations that the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States and by certain resellers of the Company’s products in those countries.  The Company takes any such allegations very seriously and has fully cooperated with and shared the results of its investigation with the SEC and the Department of Justice. Based on the investigation results, both the SEC and the Department of Justice have recently informed the Company that they have decided not to bring enforcement actions.

[0000858877-16-000117:notes:128]
Backflip Software     Backflip Software, Inc. (“Backflip”) asserted contract, tort, and fraud claims against the Company in Santa Clara County, California Superior Court. The proceeding was instituted on March 5, 2013. Backflip alleges that Cisco conspired with Backflip's then-CEO to allow the Company to access and use a copy of Backflip's source code via a pre-existing escrow agreement and that, subsequently, the Company used that source code in violation of trade secret law and the parties' software license agreement. Five claims brought by Backflip were dismissed by the Court in an order dated August 1, 2016; the claims remaining in the case are for breach of contract and misappropriation of trade secrets. Backflip will seek compensatory and enhanced damages during a trial currently set for September 12, 2016. The Company believes that it has strong arguments that it was entitled to access and use a copy of the source code under the parties’ software license agreement and did not violate trade secret law. In addition, if the jury were to find for Backflip on some or all of its claims, the Company believes that damages would not be material given the Company's assessment of the value of the Backflip intellectual property that the Company is alleged to have misappropriated. However, due to the uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

[0000858877-16-000117:notes:129]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against the Company in the U.S. District Court for the District of Delaware, accusing Cisco products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million, and the Court will decide whether to award enhanced damages and attorneys’ fees and whether an ongoing royalty should be awarded through the expiration of the patents in 2018. In June 2016, the Company filed post-trial motions. The Company also intends to pursue an appeal to the United States Court of Appeals for the Federal Circuit on various grounds. The Company believes it has strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, the Company does not expect it to be material.

[0000858877-16-000117:notes:130]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, Cisco petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art.  On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that Cisco would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. The PTAB scheduled a hearing to review our petition for November 16, 2016.  Although a trial of SSL’s claim in district court in Texas was set for September 6, 2016, the district court issued an order on June 28, 2016 staying the district court case pending the final written decision from the PTAB. The Company believes it has strong arguments that the Company's products do not infringe and the patent is invalid.  If the Company did not prevail and a jury were to find that the Company's AnyConnect products infringe, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding patent litigation processes, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

[0000858877-16-000117:notes:131]
Kangtega     Cisco Systems GmbH (“Cisco GmbH”) is subject to patent claims by Kangtega GmbH (“Kangtega”), instituted on June 6, 2013, alleging that Cisco GmbH infringes in Germany a European Patent by marketing in Germany network intrusion-detection (or firewall) products known as the “ASA” firewall offering. On April 29, 2014, the Mannheim Regional Court dismissed the infringement action, finding no infringement by Cisco GmbH of the asserted patent. On November 23, 2016, a court of appeal in Germany (Oberlandesgericht Karlsruhe) will hear an appeal of that judgment. The matter had been set for July 13, 2016, but that hearing was postponed until November 23, 2016. In addition, on July 25, 2016 the German Federal Patent Court issued its grounds for a decision denying Cisco’s nullity request with respect to the Kangtega patent. The nullity decision, which is open to appeal, regards patent validity and was issued in a separate proceeding from the infringement action in which Cisco has previously prevailed. In the infringement action, Kangtega seeks an injunction which would prohibit Cisco GmbH’s activities in Germany with respect to the ASA firewall offering unless Cisco GmbH takes a license from Kangtega or the Company redesigns the products.  The Company believes that the lower court ruling in Cisco's favor in the infringement action was correct and should be affirmed.  The Company does not anticipate that the outcome of the case would be material. However, due to uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the outcome of the appeal and any subsequent appeals to a higher court at this time.

[0000858877-16-000117:notes:132]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0000858877-16-000117:notes:133]
(q) Share-Based Compensation Expense   The Company measures and recognizes the compensation expense for all share-based awards made to employees and directors, including employee stock options, restricted stock units (RSUs), PRSUs, and employee stock purchases related to the Employee Stock Purchase Plan (Employee Stock Purchase Rights) based on estimated fair values. The fair value of employee stock options is estimated on the date of grant using a lattice-binomial option-pricing model (Lattice-Binomial Model) or the Black-Scholes model, and for employee stock purchase rights the Company estimates the fair value using the Black-Scholes model. The fair value for time-based stock awards and stock awards that are contingent upon the achievement of financial performance metrics is based on the grant date share price reduced by the present value of the expected dividend yield prior to vesting. The fair value of market-based stock awards is estimated using an option-pricing model on the date of grant. Share-based compensation expense is reduced for forfeitures.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-16-000117:notes:134]
| 15. | Comprehensive Income |

[0000858877-16-000117:notes:135]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, are summarized as follows (in millions):

[0000858877-16-000117:notes:136]
|  | Net Unrealized Gains on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains and Losses |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 27, 2013 | $ | 379 |  |  | $ | 8 |  |  | $ | 221 |  |  | $ | 608 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 380 |  |  | 48 |  |  | 49 |  |  | 477 |  |
| (Gains) losses reclassified out of AOCI | (300 | ) |  | (68 | ) |  | — |  |  | (368 | ) |
| Tax benefit (expense) | (35 | ) |  | — |  |  | (5 | ) |  | (40 | ) |
| BALANCE AT JULY 26, 2014 | 424 |  |  | (12 | ) |  | 265 |  |  | 677 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (28 | ) |  | (159 | ) |  | (563 | ) |  | (750 | ) |
| (Gains) losses reclassified out of AOCI | (157 | ) |  | 154 |  |  | 2 |  |  | (1 | ) |
| Tax benefit (expense) | 71 |  |  | 1 |  |  | 63 |  |  | 135 |  |
| BALANCE AT JULY 25, 2015 | 310 |  |  | (16 | ) |  | (233 | ) |  | 61 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 151 |  |  | (66 | ) |  | (399 | ) |  | (314 | ) |
| (Gains) losses reclassified out of AOCI | 1 |  |  | 20 |  |  | (6 | ) |  | 15 |  |
| Tax benefit (expense) | (49 | ) |  | 3 |  |  | (42 | ) |  | (88 | ) |
| BALANCE AT JULY 30, 2016 | $ | 413 |  |  | $ | (59 | ) |  | $ | (680 | ) |  | $ | (326 | ) |

[0000858877-16-000117:notes:137]
The net gains (losses) reclassified out of AOCI into the Consolidated Statements of Operations, with line item location, during each period were as follows (in millions):

[0000858877-16-000117:notes:138]
|  |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains on available-for-sale investments |  |  |  |  |  |  |  |  |
|  |  | $ | (1 | ) |  | $ | 157 |  |  | $ | 300 |  |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | (15 | ) |  | (121 | ) |  | 55 |  |  | Operating expenses |
| Foreign currency derivatives |  | (5 | ) |  | (33 | ) |  | 13 |  |  | Cost of sales—service |
|  |  | (20 | ) |  | (154 | ) |  | 68 |  |  |  |
| Cumulative translation adjustment and actuarial gains and losses |  |  |  |  |  |  |  |  |
|  |  | 6 |  |  | (2 | ) |  | — |  |  | Operating expenses |
| Total amounts reclassified out of AOCI |  | $ | (15 | ) |  | $ | 1 |  |  | $ | 368 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-16-000117:notes:139]
| 10. | Borrowings |

[0000858877-16-000117:notes:140]
| (a) | Short-Term Debt |

[0000858877-16-000117:notes:141]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-16-000117:notes:142]
|  | July 30, 2016 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,159 |  |  | 0.97 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other notes and borrowings | 1 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total short-term debt | $ | 4,160 |  |  |  |  | $ | 3,897 |  |  |  |

[0000858877-16-000117:notes:143]
The effective interest rate on the current portion of long-term debt includes the impact of interest rate swaps, as discussed further in "

[0000858877-16-000117:notes:144]
| (b) | Long-Term Debt |

[0000858877-16-000117:notes:145]
."  Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements.  These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.

[0000858877-16-000117:notes:146]
On September 3, 2015, the Company repaid an aggregate principal amount of $850 million upon maturity of its 2015 Floating-Rate Notes. On February 22, 2016, the Company repaid an aggregate principal amount of $3.0 billion upon the maturity of its 2016 Fixed Rate Notes.

[0000858877-16-000117:notes:147]
The Company has established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes.  The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes.  The Company did not have any commercial paper notes outstanding as of each of July 30, 2016 and July 25, 2015.

[0000858877-16-000117:notes:148]
(b)

[0000858877-16-000117:notes:149]
Long-Term Debt

[0000858877-16-000117:notes:150]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-16-000117:notes:151]
|  |  |  | July 30, 2016 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 1.03% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.60% | February 21, 2018 | (1) | 1,000 |  |  | 1.32% |  | — |  |  | — |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.03% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.23% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | — |  |  | — |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.87% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.22% |  | 750 |  |  | 0.85% |
| 1.40% | February 28, 2018 | (1) | 1,250 |  |  | 1.47% |  | — |  |  | — |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.76% |  | 2,000 |  |  | 4.70% |
| 1.60% | February 28, 2019 | (1) | 1,000 |  |  | 1.67% |  | — |  |  | — |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.08% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.25% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 | (1) | 2,500 |  |  | 2.30% |  | — |  |  | — |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.24% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.51% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 | (1) | 500 |  |  | 2.68% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.36% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.67% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 | (1) | 750 |  |  | 3.01% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  | — |  | 1 |  |  | 2.08% |
| Total |  |  | 28,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (137 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 379 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 28,642 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,159 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 24,483 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 28,642 |  |  |  |  | $ | 25,351 |  |  |  |

[0000858877-16-000117:notes:152]
(1) In February 2016, the Company issued senior notes for an aggregate principal amount of $7.0 billion.

[0000858877-16-000117:notes:153]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps in prior periods with an aggregate notional amount of $9.9 billion designated as fair value hedges of certain of its fixed-rate senior notes.  In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR).  The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.  For additional information, see Note 11.

[0000858877-16-000117:notes:154]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount, and, if applicable, adjustments related to hedging.  Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes.  Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

[0000858877-16-000117:notes:155]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.”  As of July 30, 2016, the Company was in compliance with all debt covenants.

[0000858877-16-000117:notes:156]
As of July 30, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-16-000117:notes:157]
| Fiscal Year | Amount |
| 2017 | $ | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 4,000 |  |
| 2021 | 3,000 |  |
| Thereafter | 7,250 |  |
| Total | $ | 28,400 |  |

[0000858877-16-000117:notes:158]
| (c) | Credit Facility |

[0000858877-16-000117:notes:159]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020.  Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero.  The credit agreement requires the Company to comply with certain covenants, including that it maintains an interest coverage ratio as defined in the agreement.

[0000858877-16-000117:notes:160]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.  As of July 30, 2016, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-16-000117:notes:161]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 10,621 |  |  | $ | 9,757 |  |
| Product: |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  | 5,474 |  |  | 4,766 |  |
| Deferred revenue related to two-tier distributors |  | 377 |  |  | 660 |  |
| Total product deferred revenue |  | 5,851 |  |  | 5,426 |  |
| Total |  | $ | 16,472 |  |  | $ | 15,183 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 10,155 |  |  | $ | 9,824 |  |
| Noncurrent |  | 6,317 |  |  | 5,359 |  |
| Total |  | $ | 16,472 |  |  | $ | 15,183 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-16-000117:notes:162]
| 11. | Derivative Instruments |

[0000858877-16-000117:notes:163]
| (a) | Summary of Derivative Instruments |

[0000858877-16-000117:notes:164]
The Company uses derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. The Company’s primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. The Company’s derivatives expose it to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. The Company does, however, seek to mitigate such risks by limiting its counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-16-000117:notes:165]
The fair values of the Company’s derivative instruments and the line items on the Consolidated Balance Sheets to which they were recorded are summarized as follows (in millions):

[0000858877-16-000117:notes:166]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | July 30, 2016 |  | July 25, 2015 |  | Balance Sheet Line Item |  | July 30, 2016 |  | July 25, 2015 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 7 |  |  | $ | 10 |  |  | Other current liabilities |  | $ | 53 |  |  | $ | 11 |  |
| Interest rate derivatives | Other current assets |  | 11 |  |  | 22 |  |  | Other current liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other assets |  | 366 |  |  | 180 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 384 |  |  | 212 |  |  |  |  | 53 |  |  | 11 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | — |  |  | 2 |  |  | Other current liabilities |  | 1 |  |  | 1 |  |
| Equity derivatives/warrants | Other assets |  | 1 |  |  | 4 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 1 |  |  | 6 |  |  |  |  | 1 |  |  | 1 |  |
| Total |  |  | $ | 385 |  |  | $ | 218 |  |  |  |  | $ | 54 |  |  | $ | 12 |  |

[0000858877-16-000117:notes:167]
The effects of the Company’s cash flow and net investment hedging instruments on other comprehensive income (OCI) and the Consolidated Statements of Operations are summarized as follows (in millions):

[0000858877-16-000117:notes:168]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FORTHE YEARS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FORTHE YEARS ENDED (EFFECTIVE PORTION) |
|  |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |  | Line Item in Statements of Operations |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (66 | ) |  | $ | (159 | ) |  | $ | 48 |  |  | Operating expenses |  | $ | (15 | ) |  | $ | (121 | ) |  | $ | 55 |  |
|  |  |  |  |  |  |  |  | Cost of sales—service |  | (5 | ) |  | (33 | ) |  | 13 |  |
| Total |  | $ | (66 | ) |  | $ | (159 | ) |  | $ | 48 |  |  | Total |  | $ | (20 | ) |  | $ | (154 | ) |  | $ | 68 |  |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 16 |  |  | $ | 42 |  |  | $ | (15 | ) |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000858877-16-000117:notes:169]
As of July 30, 2016, the Company estimates that approximately $54 million of net derivative losses related to its cash flow hedges included in accumulated other comprehensive income (AOCI) will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-16-000117:notes:170]
The effect on the Consolidated Statements of Operations of derivative instruments not designated as hedges is summarized as follows (in millions):

[0000858877-16-000117:notes:171]
|  |  |  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (19 | ) |  | $ | (173 | ) |  | $ | 23 |  |
| Total return swaps—deferred compensation |  | Operating expenses |  | 7 |  |  | 19 |  |  | 47 |  |
| Equity derivatives |  | Other income (loss), net |  | 13 |  |  | 27 |  |  | 34 |  |
| Total |  |  |  | $ | 1 |  |  | $ | (127 | ) |  | $ | 104 |  |

[0000858877-16-000117:notes:172]
The notional amounts of the Company’s outstanding derivatives are summarized as follows (in millions):

[0000858877-16-000117:notes:173]
|  | July 30, 2016 |  | July 25, 2015 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 2,683 |  |  | $ | 1,201 |  |
| Interest rate derivatives | 9,900 |  |  | 11,400 |  |
| Net investment hedging instruments | 298 |  |  | 192 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,057 |  |  | 2,023 |  |
| Total return swaps—deferred compensation | 476 |  |  | 462 |  |
| Total | $ | 15,414 |  |  | $ | 15,278 |  |

[0000858877-16-000117:notes:174]
| (b) | Offsetting of Derivative Instruments |

[0000858877-16-000117:notes:175]
The Company presents its derivative instruments at gross fair values in the Consolidated Balance Sheets.  However, the Company’s master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty.  To further limit credit risk, the Company also enters into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument.   Information related to these offsetting arrangements is summarized as follows (in millions):

[0000858877-16-000117:notes:176]
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEET |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETBUT WITH LEGAL RIGHTS TO OFFSET |
| July 30, 2016 | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 385 |  |  | $ | — |  |  | $ | 385 |  |  | $ | (23 | ) |  | $ | (305 | ) |  | $ | 57 |  |
| Derivatives liabilities | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |  | $ | (23 | ) |  | $ | — |  |  | $ | 31 |  |

[0000858877-16-000117:notes:177]
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEET |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETBUT WITH LEGAL RIGHTS TO OFFSET |
| July 25, 2015 | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 218 |  |  | $ | — |  |  | $ | 218 |  |  | $ | (12 | ) |  | $ | (124 | ) |  | $ | 82 |  |
| Derivatives liabilities | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |  | $ | (12 | ) |  | $ | — |  |  | $ | — |  |

[0000858877-16-000117:notes:178]
| (c) | Foreign Currency Exchange Risk |

[0000858877-16-000117:notes:179]
The Company conducts business globally in numerous currencies. Therefore, it is exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, the Company enters into foreign currency contracts. The Company does not enter into such contracts for speculative purposes.

[0000858877-16-000117:notes:180]
The Company hedges forecasted foreign currency transactions related to certain operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The Company assesses effectiveness based on changes in total fair value of the derivatives. The effective portion of the derivative instrument’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion, if any, of the gain or loss is reported in earnings immediately. During the fiscal years presented, the Company did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-16-000117:notes:181]
The Company enters into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, including long-term customer financings, investments, and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of intercompany balances or other current assets, investments, or liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-16-000117:notes:182]
The Company hedges certain net investments in its foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on the Company’s net investment in those foreign subsidiaries. These derivative instruments generally have maturities of up to six months.

[0000858877-16-000117:notes:183]
| (d) | Interest Rate Risk |

[0000858877-16-000117:notes:184]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of July 30, 2016 and July 25, 2015, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-16-000117:notes:185]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt   In fiscal 2016, the Company did not enter into any interest rate swaps. In prior fiscal years, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2017 through 2025. Under these interest rate swaps, the Company receives fixed-rate interest payments and makes interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps was reflected in other current assets and other assets.

[0000858877-16-000117:notes:186]
| (e) | Equity Price Risk |

[0000858877-16-000117:notes:187]
The Company may hold equity securities for strategic purposes or to diversify its overall investment portfolio. The publicly traded equity securities in the Company’s portfolio are subject to price risk. To manage its exposure to changes in the fair value of certain equity securities, the Company has periodically entered into equity derivatives that are designated as fair value hedges. The changes in the value of the hedging instruments are included in other income (loss), net, and offset the change in the fair value of the underlying hedged investment. In addition, the Company periodically enters into equity derivatives that are not designated as accounting hedges. The changes in the fair value of these derivatives are also included in other income (loss), net.

[0000858877-16-000117:notes:188]
The Company is also exposed to variability in compensation charges related to certain deferred compensation obligations to employees. Although not designated as accounting hedges, the Company utilizes derivatives such as total return swaps to economically hedge this exposure.

[0000858877-16-000117:notes:189]
| (f) | Hedge Effectiveness |

[0000858877-16-000117:notes:190]
For the fiscal years presented, amounts excluded from the assessment of hedge effectiveness were not material for fair value, cash flow, and net investment hedges. In addition, hedge ineffectiveness for fair value, cash flow, and net investment hedges was not material for any of the fiscal years presented.


## us-gaap:DerivativesPolicyTextBlock

[0000858877-16-000117:notes:191]
(l) Derivative Instruments   The Company recognizes derivative instruments as either assets or liabilities and measures those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the effective portion of the derivative’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion of the gain or loss is reported in earnings immediately. For a derivative instrument designated as a net investment hedge of the Company’s foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. Any ineffective portion of the net investment hedges is reported in earnings during the period of change. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. The Company records derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.

[0000858877-16-000117:notes:192]
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-16-000117:notes:193]
| 14. | Employee Benefit Plans |

[0000858877-16-000117:notes:194]
| (a) | Employee Stock Incentive Plans |

[0000858877-16-000117:notes:195]
Stock Incentive Plan Program Description    As of July 30, 2016, the Company had three stock incentive plans: the 2005 Stock Incentive Plan (the “2005 Plan”); the Cisco Systems, Inc. SA Acquisition Long-Term Incentive Plan (the “SA Acquisition Plan”); and the Cisco Systems, Inc. WebEx Acquisition Long-Term Incentive Plan (the “WebEx Acquisition Plan”). In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company. The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors. The Company’s primary stock incentive plans are summarized as follows:

[0000858877-16-000117:notes:196]
2005 Plan    As of July 30, 2016, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus shares from the 1996 Stock Incentive Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that are forfeited or are terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan.  Starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-16-000117:notes:197]
Pursuant to an amendment approved by the Company’s shareholders on November 12, 2009, the number of shares available for issuance under the 2005 Plan is reduced by 1.5 shares for each share awarded as a stock grant or a stock unit, and any shares underlying awards outstanding under the 1996 Stock Incentive Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that expire unexercised at the end of their maximum terms become available for reissuance under the 2005 Plan. The 2005 Plan permits the granting of stock options, restricted stock, and RSUs, the vesting of which may be performance-based or market-based along with the requisite service requirement, and stock appreciation rights to employees (including employee directors and officers), consultants of the Company and its subsidiaries and affiliates, and non-employee directors of the Company. Stock options and stock appreciation rights granted under the 2005 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date and prior to November 12, 2009 have an expiration date no later than nine years from the grant date. The expiration date for stock options and stock appreciation rights granted subsequent to the amendment approved on November 12, 2009 shall be no later than 10 years from the grant date.

[0000858877-16-000117:notes:198]
The stock options will generally become exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively. Time-based stock grants and time-based RSUs will generally vest with respect to 20% or 25% of the shares or share units covered by the grant annually over the vesting period.  The majority of the performance-based and market-based RSUs vests at the end of the three-year requisite service period or earlier if the award recipient meets certain retirement eligibility conditions. Certain performance-based RSUs that are based on the achievement of financial and/or non-financial operating goals typically vest upon the achievement of milestones (and may require subsequent service periods), with overall vesting of the shares underlying the award ranging from six months to three years.  The Compensation and Management Development Committee of the Board of Directors has the discretion to use different vesting schedules. Stock appreciation rights may be awarded in combination with stock options or stock grants, and such awards shall provide that the stock appreciation rights will not be exercisable unless the related stock options or stock grants are forfeited. Stock grants may be awarded in combination with non-statutory stock options, and such awards may provide that the stock grants will be forfeited in the event that the related non-statutory stock options are exercised.

[0000858877-16-000117:notes:199]
Acquisition Plans In connection with the Company’s acquisitions of Scientific-Atlanta, Inc. (“Scientific-Atlanta”) and WebEx Communications, Inc. (“WebEx”), the Company adopted the SA Acquisition Plan and the WebEx Acquisition Plan, respectively, each effective upon completion of the applicable acquisition. These plans constitute assumptions, amendments, restatements, and renamings of the 2003 Long-Term Incentive Plan of Scientific-Atlanta and the WebEx Communications, Inc. Amended and Restated 2000 Stock Incentive Plan, respectively. The plans permit the grant of stock options, stock, stock units, and stock appreciation rights to certain employees of the Company and its subsidiaries and affiliates who had been employed by Scientific-Atlanta or its subsidiaries or WebEx or its subsidiaries, as applicable. As a result of the shareholder approval of the amendment and extension of the 2005 Plan, as of November 15, 2007, the Company will no longer make stock option grants or direct share issuances under either the SA Acquisition Plan or the WebEx Acquisition Plan.

[0000858877-16-000117:notes:200]
| (b) | Employee Stock Purchase Plan |

[0000858877-16-000117:notes:201]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 621 million shares of the Company’s common stock have been reserved for issuance as of July 30, 2016. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. The Purchase Plan is scheduled to terminate on January 3, 2020. The Company issued 25 million, 27 million, and 27 million shares under the Purchase Plan in fiscal 2016, 2015, and 2014, respectively. As of July 30, 2016, 123 million shares were available for issuance under the Purchase Plan.

[0000858877-16-000117:notes:202]
| (c) | Summary of Share-Based Compensation Expense |

[0000858877-16-000117:notes:203]
Share-based compensation expense consists primarily of expenses for stock options, stock purchase rights, restricted stock, and restricted stock units granted to employees. The following table summarizes share-based compensation expense (in millions):

[0000858877-16-000117:notes:204]
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Cost of sales—product | $ | 70 |  |  | $ | 50 |  |  | $ | 45 |  |
| Cost of sales—service | 142 |  |  | 157 |  |  | 150 |  |
| Share-based compensation expense in cost of sales | 212 |  |  | 207 |  |  | 195 |  |
| Research and development | 470 |  |  | 448 |  |  | 411 |  |
| Sales and marketing | 545 |  |  | 559 |  |  | 549 |  |
| General and administrative | 205 |  |  | 228 |  |  | 198 |  |
| Restructuring and other charges | 26 |  |  | (2 | ) |  | (5 | ) |
| Share-based compensation expense in operating expenses | 1,246 |  |  | 1,233 |  |  | 1,153 |  |
| Total share-based compensation expense | $ | 1,458 |  |  | $ | 1,440 |  |  | $ | 1,348 |  |
| Income tax benefit for share-based compensation | $ | 429 |  |  | $ | 373 |  |  | $ | 324 |  |

[0000858877-16-000117:notes:205]
As of July 30, 2016, the total compensation cost related to unvested share-based awards not yet recognized was $2.9 billion, which is expected to be recognized over approximately 2.6 years on a weighted-average basis.

[0000858877-16-000117:notes:206]
| (d) | Share-Based Awards Available for Grant |

[0000858877-16-000117:notes:207]
A summary of share-based awards available for grant is as follows (in millions):

[0000858877-16-000117:notes:208]
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Balance at beginning of fiscal year | 276 |  |  | 310 |  |  | 228 |  |
| Restricted stock, stock units, and other share-based awards granted | (96 | ) |  | (101 | ) |  | (98 | ) |
| Share-based awards canceled/forfeited/expired | 30 |  |  | 40 |  |  | 36 |  |
| Additional shares reserved | — |  |  | — |  |  | 135 |  |
| Shares withheld for taxes and not issued | 30 |  |  | 27 |  |  | 6 |  |
| Other | 2 |  |  | — |  |  | 3 |  |
| Balance at end of fiscal year | 242 |  |  | 276 |  |  | 310 |  |

[0000858877-16-000117:notes:209]
As reflected in the preceding table, for each share awarded as restricted stock or subject to a restricted stock unit award under the 2005 Plan, an equivalent of 1.5 shares was deducted from the available share-based award balance. For restricted stock units that were awarded with vesting contingent upon the achievement of future financial performance or market-based metrics, the maximum awards that can be achieved upon full vesting of such awards were reflected in the preceding table.

[0000858877-16-000117:notes:210]
| (e) | Restricted Stock and Stock Unit Awards |

[0000858877-16-000117:notes:211]
A summary of the restricted stock and stock unit activity, which includes time-based and performance-based or market-based restricted stock units, is as follows (in millions, except per-share amounts):

[0000858877-16-000117:notes:212]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 27, 2013 | 143 |  |  | $ | 18.80 |  |  |  |
| Granted and assumed | 72 |  |  | 20.85 |  |  |  |
| Vested | (53 | ) |  | 19.55 |  |  | $ | 1,229 |  |
| Canceled/forfeited | (13 | ) |  | 18.61 |  |  |  |
| UNVESTED BALANCE AT JULY 26, 2014 | 149 |  |  | 19.54 |  |  |  |
| Granted and assumed | 67 |  |  | 25.29 |  |  |  |
| Vested | (57 | ) |  | 19.82 |  |  | $ | 1,517 |  |
| Canceled/forfeited | (16 | ) |  | 20.17 |  |  |  |
| UNVESTED BALANCE AT JULY 25, 2015 | 143 |  |  | 22.08 |  |  |  |
| Granted and assumed | 70 |  |  | 25.69 |  |  |  |
| Vested | (54 | ) |  | 20.68 |  |  | $ | 1,428 |  |
| Canceled/forfeited | (14 | ) |  | 22.86 |  |  |  |
| UNVESTED BALANCE AT JULY 30, 2016 | 145 |  |  | $ | 24.26 |  |  |  |

[0000858877-16-000117:notes:213]
| (f) | Stock Option Awards |

[0000858877-16-000117:notes:214]
A summary of the stock option activity is as follows (in millions, except per-share amounts):

[0000858877-16-000117:notes:215]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 27, 2013 | 276 |  |  | $ | 24.44 |  |
| Assumed from acquisitions | 6 |  |  | 3.60 |  |
| Exercised | (78 | ) |  | 18.30 |  |
| Canceled/forfeited/expired | (17 | ) |  | 27.53 |  |
| BALANCE AT JULY 26, 2014 | 187 |  |  | 26.03 |  |
| Assumed from acquisitions | 1 |  |  | 2.60 |  |
| Exercised | (71 | ) |  | 21.15 |  |
| Canceled/forfeited/expired | (14 | ) |  | 29.68 |  |
| BALANCE AT JULY 25, 2015 | 103 |  |  | 28.68 |  |
| Assumed from acquisitions | 18 |  |  | 5.17 |  |
| Exercised | (32 | ) |  | 19.22 |  |
| Canceled/forfeited/expired | (16 | ) |  | 30.01 |  |
| BALANCE AT JULY 30, 2016 | 73 |  |  | $ | 26.78 |  |

[0000858877-16-000117:notes:216]
The total pretax intrinsic value of stock options exercised during fiscal 2016, 2015, and 2014 was $266 million, $434 million, and $458 million, respectively.

[0000858877-16-000117:notes:217]
The following table summarizes significant ranges of outstanding and exercisable stock options as of July 30, 2016 (in millions, except years and share prices):

[0000858877-16-000117:notes:218]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 20.00 |  | 14 |  |  | 6.9 |  | $ | 5.68 |  |  | $ | 346 |  |  | 5 |  |  | $ | 5.28 |  |  | $ | 127 |  |
| $ 20.01 – 25.00 |  | 1 |  |  | 0.5 |  | 23.38 |  |  | 6 |  |  | 1 |  |  | 23.38 |  |  | 6 |  |
| $ 25.01 – 30.00 |  | 4 |  |  | 0.6 |  | 27.23 |  |  | 12 |  |  | 4 |  |  | 27.23 |  |  | 12 |  |
| $ 30.01 – 35.00 |  | 54 |  |  | 0.1 |  | 32.16 |  |  | — |  |  | 54 |  |  | 32.16 |  |  | — |  |
| Total |  | 73 |  |  | 1.4 |  | $ | 26.78 |  |  | $ | 364 |  |  | 64 |  |  | $ | 29.66 |  |  | $ | 145 |  |

[0000858877-16-000117:notes:219]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on the Company's closing stock price of $30.53 as of July 29, 2016, that would have been received by the option holders had those option holders exercised their stock options as of that date.  The total number of in-the-money stock options exercisable as of July 30, 2016 was 10 million.  As of July 25, 2015, 102 million outstanding stock options were exercisable, and the weighted-average exercise price was $29.02.

[0000858877-16-000117:notes:220]
| (g) | Valuation of Employee Share-Based Awards |

[0000858877-16-000117:notes:221]
Time-based restricted stock units and PRSUs that are based on the Company’s financial performance metrics or non-financial operating goals are valued using the market value of the Company’s common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, the Company estimated the fair value of the total shareholder return (TSR) component of the PRSUs using a Monte Carlo simulation model. The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-16-000117:notes:222]
|  | RESTRICTED STOCK UNITS |
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Number of shares granted (in millions) | 57 |  |  | 55 |  |  | 56 |  |
| Grant date fair value per share | $ | 26.01 |  |  | $ | 25.30 |  |  | $ | 20.61 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 3.2 | % |  | 2.9 | % |  | 3.1 | % |
| Range of risk-free interest rates | 0.0% – 1.2% |  |  | 0.0% – 1.8% |  |  | 0.0% – 1.7% |  |

[0000858877-16-000117:notes:223]
|  | PERFORMANCE BASED RESTRICTED STOCK UNITS |
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Number of shares granted (in millions) | 5 |  |  | 11 |  |  | 7 |  |
| Grant date fair value per share | $ | 24.70 |  |  | $ | 24.85 |  |  | $ | 21.90 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 3.1 | % |  | 3.0 | % |  | 3.0 | % |
| Range of risk-free interest rates | 0.0% – 1.2% |  |  | 0.0% – 1.8% |  |  | 0.0% – 1.7% |  |
| Range of expected volatilities for index | 15.3% – 54.3% |  |  | 14.3% – 70.0% |  |  | 14.2% – 70.5% |  |

[0000858877-16-000117:notes:224]
The PRSUs granted during fiscal 2016, 2015, and 2014 are contingent on the achievement of the Company’s financial performance metrics, its comparative market-based returns, or the achievement of financial and non-financial operating goals.  For the awards based on financial performance metrics or comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period. Generally, the remaining 50% of the PRSUs are earned based on the Company’s TSR measured against the benchmark TSR of a peer group over the same period. Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of the Company's financial performance metrics or its comparative market-based returns, and 0% to 100% of the target shares granted contingent on the achievement of non-financial operating goals.

[0000858877-16-000117:notes:225]
The assumptions for the valuation of employee stock purchase rights are summarized as follows:

[0000858877-16-000117:notes:226]
|  | EMPLOYEE STOCK PURCHASE RIGHTS |
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Weighted-average assumptions: |  |  |  |  |  |
| Expected volatility | 23.9 | % |  | 26.0 | % |  | 25.1 | % |
| Risk-free interest rate | 0.4 | % |  | 0.3 | % |  | 0.1 | % |
| Expected dividend | 3.1 | % |  | 2.8 | % |  | 2.8 | % |
| Expected life (in years) | 1.3 |  |  | 1.8 |  |  | 0.8 |  |
| Weighted-average estimated grant date fair value per share | $ | 5.73 |  |  | $ | 6.54 |  |  | $ | 5.54 |  |

[0000858877-16-000117:notes:227]
The valuation of employee stock purchase rights and the related assumptions are for the employee stock purchases made during the respective fiscal years.

[0000858877-16-000117:notes:228]
The Company uses third-party analyses to assist in developing the assumptions used in, as well as calibrating, its lattice-binomial and Black-Scholes models. The Company is responsible for determining the assumptions used in estimating the fair value of its share-based payment awards.

[0000858877-16-000117:notes:229]
The Company used the implied volatility for traded options (with contract terms corresponding to the expected life of the employee stock purchase rights) on the Company’s stock as the expected volatility assumption required in the Black-Scholes model. The implied volatility is more representative of future stock price trends than historical volatility. The risk-free interest rate assumption is based upon observed interest rates appropriate for the term of the Company’s employee stock purchase rights. The dividend yield assumption is based on the history and expectation of dividend payouts at the grant date.

[0000858877-16-000117:notes:230]
| (h) | Employee 401(k) Plans |

[0000858877-16-000117:notes:231]
The Company sponsors the Cisco Systems, Inc. 401(k) Plan (the “Plan”) to provide retirement benefits for its employees. As allowed under Section 401(k) of the Internal Revenue Code, the Plan provides for tax-deferred salary contributions and after-tax contributions for eligible employees. The Plan allows employees to contribute up to 75% of their annual eligible earnings to the Plan on a pretax and after-tax basis, including Roth contributions. Employee contributions are limited to a maximum annual amount as set periodically by the Internal Revenue Code. The Company matches pretax and Roth employee contributions up to 100% of the first 4.5% of eligible earnings that are contributed by employees. Therefore, the maximum matching contribution that the Company may allocate to each participant’s account will not exceed $11,925 for the 2016 calendar year due to the $265,000 annual limit on eligible earnings imposed by the Internal Revenue Code. All matching contributions vest immediately. The Company’s matching contributions to the Plan totaled $262 million, $244 million, and $236 million in fiscal 2016, 2015, and 2014, respectively.

[0000858877-16-000117:notes:232]
The Plan allows employees who meet the age requirements and reach the Plan contribution limits to make catch-up contributions (pretax or Roth) not to exceed the lesser of 75% of their annual eligible earnings or the limit set forth in the Internal Revenue Code. Catch-up contributions are not eligible for matching contributions. In addition, the Plan provides for discretionary profit-sharing contributions as determined by the Board of Directors. Such contributions to the Plan are allocated among eligible participants in the proportion of their salaries to the total salaries of all participants. There were no discretionary profit-sharing contributions made in fiscal 2016, 2015, and 2014.

[0000858877-16-000117:notes:233]
The Company also sponsors other 401(k) plans as a result of acquisitions of other companies. The Company’s contributions to these plans were not material to the Company on either an individual or aggregate basis for any of the fiscal years presented.

[0000858877-16-000117:notes:234]
| (i) | Deferred Compensation Plans |

[0000858877-16-000117:notes:235]
The Cisco Systems, Inc. Deferred Compensation Plan (the “Deferred Compensation Plan”), a nonqualified deferred compensation plan, became effective in 2007. As required by applicable law, participation in the Deferred Compensation Plan is limited to a select group of the Company’s management employees. Under the Deferred Compensation Plan, which is an unfunded and unsecured deferred compensation arrangement, a participant may elect to defer base salary, bonus, and/or commissions, pursuant to such rules as may be established by the Company, up to the maximum percentages for each deferral election as described in the plan. The Company may also, at its discretion, make a matching contribution to the employee under the Deferred Compensation Plan. A matching contribution equal to 4.5% of eligible compensation in excess of the Internal Revenue Code limit for qualified plans for calendar year 2016 that is deferred by participants under the Deferred Compensation Plan (with a $1.5 million cap on eligible compensation) will be made to eligible participants’ accounts at the end of calendar year 2016. The deferred compensation liability under the Deferred Compensation Plan, together with a deferred compensation plan assumed from Scientific-Atlanta, was approximately $569 million and $536 million as of July 30, 2016 and July 25, 2015, respectively, and was recorded primarily in other long-term liabilities.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000858877-16-000117:notes:236]
(t) Computation of Net Income per Share   Basic net income per share is computed using the weighted-average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted-average number of common shares and dilutive potential common shares outstanding during the period. Diluted shares outstanding includes the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options, the amount of compensation cost for future service that the Company has not yet recognized, and the amount of tax benefits that would be recorded in additional paid-in capital when the award becomes deductible are collectively assumed to be used to repurchase shares.


## us-gaap:EarningsPerShareTextBlock

[0000858877-16-000117:notes:237]
| 18. | Net Income per Share |

[0000858877-16-000117:notes:238]
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-16-000117:notes:239]
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Net income | $ | 10,739 |  |  | $ | 8,981 |  |  | $ | 7,853 |  |
| Weighted-average shares—basic | 5,053 |  |  | 5,104 |  |  | 5,234 |  |
| Effect of dilutive potential common shares | 35 |  |  | 42 |  |  | 47 |  |
| Weighted-average shares—diluted | 5,088 |  |  | 5,146 |  |  | 5,281 |  |
| Net income per share—basic | $ | 2.13 |  |  | $ | 1.76 |  |  | $ | 1.50 |  |
| Net income per share—diluted | $ | 2.11 |  |  | $ | 1.75 |  |  | $ | 1.49 |  |
| Antidilutive employee share-based awards, excluded | 148 |  |  | 183 |  |  | 254 |  |

[0000858877-16-000117:notes:240]
Employee equity share options, unvested shares, and similar equity instruments granted by the Company are treated as potential common shares outstanding in computing diluted earnings per share. Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options, the amount of compensation cost for future service that the Company has not yet recognized, and the amount of tax benefits that would be recorded in additional paid-in capital when the award becomes deductible are collectively assumed to be used to repurchase shares.


## us-gaap:EquityMethodInvestmentsTextBlock

[0000858877-16-000117:notes:241]
|  | July 30, 2016 |  | July 25, 2015 |
| Equity method investments | $ | 174 |  |  | $ | 170 |  |
| Cost method investments | 829 |  |  | 727 |  |
| Total | $ | 1,003 |  |  | $ | 897 |  |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-16-000117:notes:242]
The following table presents the Company’s assets that were measured at fair value on a nonrecurring basis during the indicated periods and the related recognized gains and losses for the periods indicated (in millions):

[0000858877-16-000117:notes:243]
|  | TOTAL GAINS (LOSSES) FOR THE YEARS ENDED |
|  | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Investments in privately held companies (impaired) | $ | (57 | ) |  | $ | (38 | ) |  | $ | (21 | ) |
| Purchased intangible assets (impaired) | (74 | ) |  | (175 | ) |  | — |  |
| Gains (losses) on assets no longer held at end of fiscal year | (10 | ) |  | (8 | ) |  | (2 | ) |
| Total gains (losses) for nonrecurring measurements | $ | (141 | ) |  | $ | (221 | ) |  | $ | (23 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-16-000117:notes:244]
| 9. | Fair Value |

[0000858877-16-000117:notes:245]
| (a) | Assets and Liabilities Measured at Fair Value on a Recurring Basis |

[0000858877-16-000117:notes:246]
Assets and liabilities measured at fair value on a recurring basis as of July 30, 2016 and July 25, 2015 were as follows (in millions):

[0000858877-16-000117:notes:247]
|  | JULY 30, 2016 |  | JULY 25, 2015 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 6,049 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,049 |  |  | $ | 5,336 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,336 |  |
| Corporate debt securities | — |  |  | 43 |  |  | — |  |  | 43 |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 26,544 |  |  | — |  |  | 26,544 |  |  | — |  |  | 29,939 |  |  | — |  |  | 29,939 |  |
| U.S. government agency securities | — |  |  | 2,817 |  |  | — |  |  | 2,817 |  |  | — |  |  | 3,663 |  |  | — |  |  | 3,663 |  |
| Non-U.S. government and agency securities | — |  |  | 1,100 |  |  | — |  |  | 1,100 |  |  | — |  |  | 1,128 |  |  | — |  |  | 1,128 |  |
| Corporate debt securities | — |  |  | 24,292 |  |  | — |  |  | 24,292 |  |  | — |  |  | 15,783 |  |  | — |  |  | 15,783 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,868 |  |  | — |  |  | 1,868 |  |  | — |  |  | 1,461 |  |  | — |  |  | 1,461 |  |
| Publicly traded equity securities | 1,504 |  |  | — |  |  | — |  |  | 1,504 |  |  | 1,565 |  |  | — |  |  | — |  |  | 1,565 |  |
| Derivative assets | — |  |  | 384 |  |  | 1 |  |  | 385 |  |  | — |  |  | 214 |  |  | 4 |  |  | 218 |  |
| Total | $ | 7,553 |  |  | $ | 57,048 |  |  | $ | 1 |  |  | $ | 64,602 |  |  | $ | 6,901 |  |  | $ | 52,202 |  |  | $ | 4 |  |  | $ | 59,107 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |
| Total | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |

[0000858877-16-000117:notes:248]
Level 1 publicly traded equity securities are determined by using quoted prices in active markets for identical assets.  Level 2 fixed income securities are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. The Company uses inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of these assets and liabilities. The Company uses such pricing data as the primary input to make its assessments and determinations as to the ultimate valuation of its investment portfolio and has not made, during the periods presented, any material adjustments to such inputs. The Company is ultimately responsible for the financial statements and underlying estimates. The Company’s derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs. The Company did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.

[0000858877-16-000117:notes:249]
Level 3 assets include certain derivative instruments, the values of which are determined based on discounted cash flow models using inputs that the Company could not corroborate with market data.

[0000858877-16-000117:notes:250]
| (b) | Assets Measured at Fair Value on a Nonrecurring Basis |

[0000858877-16-000117:notes:251]
These assets were measured at fair value due to events or circumstances the Company identified as having significant impact on their fair value during the respective periods.  To arrive at the valuation of these assets, the Company considers any significant changes in the financial metrics and economic variables and also uses third-party valuation reports to assist in the valuation as necessary.

[0000858877-16-000117:notes:252]
The fair value measurement of the impaired investments was classified as Level 3 because significant unobservable inputs were used in the valuation due to the absence of quoted market prices and inherent lack of liquidity.  Significant unobservable inputs, which included financial metrics of comparable private and public companies, financial condition and near-term prospects of the investees, recent financing activities of the investees, and the investees’ capital structure as well as other economic variables, reflected the assumptions market participants would use in pricing these assets.  The impairment charges, representing the difference between the net book value and the fair value as a result of the evaluation, were recorded to other income (loss), net.  The remaining carrying value of the investments that were impaired was $24 million as of July 30, 2016.

[0000858877-16-000117:notes:253]
The fair value for purchased intangibles assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation.  Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets.  The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable.  See Note 4.  The remaining carrying value of the specific purchased intangible assets that were impaired was zero as of July 30, 2016.

[0000858877-16-000117:notes:254]
The fair value of property held for sale was measured with the assistance of third-party valuation models, which used discounted cash flow techniques as part of their analysis.  The fair value measurement was categorized as Level 3, as significant unobservable inputs were used in the valuation report.  The impairment charges as a result of the valuations, which represented the difference between the fair value less cost to sell and the carrying amount of the assets held for sale, were included in G&A expenses.

[0000858877-16-000117:notes:255]
| (c) | Other Fair Value Disclosures |

[0000858877-16-000117:notes:256]
The carrying value of the Company’s investments in privately held companies that were accounted for under the cost method was $829 million and $727 million as of July 30, 2016 and July 25, 2015, respectively. It was not practicable to estimate the fair value of this portfolio.

[0000858877-16-000117:notes:257]
The fair value of the Company’s short-term loan receivables and financed service contracts approximates their carrying value due to their short duration.  The aggregate carrying value of the Company’s long-term loan receivables and financed service contracts and other as of July 30, 2016 and July 25, 2015 was $2.6 billion and $2.2 billion, respectively.  The estimated fair value of the Company’s long-term loan receivables and financed service contracts and other approximates their carrying value. The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-16-000117:notes:258]
As of July 30, 2016 and July 25, 2015, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.  As of July 30, 2016, the fair value of the Company’s senior notes and other long-term debt was $30.9 billion, with a carrying amount of $28.6 billion.  This compares to a fair value of $26.6 billion and a carrying amount of $25.4 billion as of July 25, 2015.  The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-16-000117:notes:259]
Gross receivables, excluding residual value, less unearned income categorized by the Company’s internal credit risk rating as of July 30, 2016 and July 25, 2015 are summarized as follows (in millions):

[0000858877-16-000117:notes:260]
|  | INTERNAL CREDIT RISK RATING |
| July 30, 2016 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,703 |  |  | $ | 1,294 |  |  | $ | 101 |  |  | $ | 3,098 |  |
| Loan receivables | 986 |  |  | 967 |  |  | 182 |  |  | 2,135 |  |
| Financed service contracts and other | 2,077 |  |  | 1,271 |  |  | 22 |  |  | 3,370 |  |
| Total | $ | 4,766 |  |  | $ | 3,532 |  |  | $ | 305 |  |  | $ | 8,603 |  |

[0000858877-16-000117:notes:261]
|  | INTERNAL CREDIT RISK RATING |
| July 25, 2015 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,688 |  |  | $ | 1,342 |  |  | $ | 141 |  |  | $ | 3,171 |  |
| Loan receivables | 788 |  |  | 823 |  |  | 152 |  |  | 1,763 |  |
| Financed service contracts and other | 2,133 |  |  | 1,389 |  |  | 51 |  |  | 3,573 |  |
| Total | $ | 4,609 |  |  | $ | 3,554 |  |  | $ | 344 |  |  | $ | 8,507 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-16-000117:notes:262]
| 7. | Financing Receivables and Operating Leases |

[0000858877-16-000117:notes:263]
| (a) | Financing Receivables |

[0000858877-16-000117:notes:264]
Financing receivables primarily consist of lease receivables, loan receivables, and financed service contracts and other. Lease receivables represent sales-type and direct-financing leases resulting from the sale of the Company’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Loan receivables represent financing arrangements related to the sale of the Company’s products and services, which may include additional funding for other costs associated with network installation and integration of the Company’s products and services. Lease receivables consist of arrangements with terms of four years on average, while loan receivables generally have terms of up to three years. The financed service contracts and other category includes financing receivables related to technical support and advanced services, as well as receivables related to financing of certain indirect costs associated with leases. Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one to three years.

[0000858877-16-000117:notes:265]
A summary of the Company's financing receivables is presented as follows (in millions):

[0000858877-16-000117:notes:266]
| July 30, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Gross | $ | 3,272 |  |  | $ | 2,135 |  |  | $ | 3,370 |  |  | $ | 8,777 |  |
| Residual value | 202 |  |  | — |  |  | — |  |  | 202 |  |
| Unearned income | (174 | ) |  | — |  |  | — |  |  | (174 | ) |
| Allowance for credit loss | (230 | ) |  | (97 | ) |  | (48 | ) |  | (375 | ) |
| Total, net | $ | 3,070 |  |  | $ | 2,038 |  |  | $ | 3,322 |  |  | $ | 8,430 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,490 |  |  | $ | 988 |  |  | $ | 1,794 |  |  | $ | 4,272 |  |
| Noncurrent | 1,580 |  |  | 1,050 |  |  | 1,528 |  |  | 4,158 |  |
| Total, net | $ | 3,070 |  |  | $ | 2,038 |  |  | $ | 3,322 |  |  | $ | 8,430 |  |

[0000858877-16-000117:notes:267]
| July 25, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Gross | $ | 3,361 |  |  | $ | 1,763 |  |  | $ | 3,573 |  |  | $ | 8,697 |  |
| Residual value | 224 |  |  | — |  |  | — |  |  | 224 |  |
| Unearned income | (190 | ) |  | — |  |  | — |  |  | (190 | ) |
| Allowance for credit loss | (259 | ) |  | (87 | ) |  | (36 | ) |  | (382 | ) |
| Total, net | $ | 3,136 |  |  | $ | 1,676 |  |  | $ | 3,537 |  |  | $ | 8,349 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,468 |  |  | $ | 856 |  |  | $ | 2,167 |  |  | $ | 4,491 |  |
| Noncurrent | 1,668 |  |  | 820 |  |  | 1,370 |  |  | 3,858 |  |
| Total, net | $ | 3,136 |  |  | $ | 1,676 |  |  | $ | 3,537 |  |  | $ | 8,349 |  |

[0000858877-16-000117:notes:268]
As of July 30, 2016 and July 25, 2015, the deferred service revenue related to "Financed Service Contracts and Other" was $1,716 million and $1,853 million, respectively.

[0000858877-16-000117:notes:269]
Future minimum lease payments to the Company on lease receivables as of July 30, 2016 are summarized as follows (in millions):

[0000858877-16-000117:notes:270]
| Fiscal Year | Amount |
| 2017 | $ | 1,565 |  |
| 2018 | 962 |  |
| 2019 | 500 |  |
| 2020 | 209 |  |
| 2021 | 36 |  |
| Total | $ | 3,272 |  |

[0000858877-16-000117:notes:271]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-16-000117:notes:272]
| (b) | Credit Quality of Financing Receivables |

[0000858877-16-000117:notes:273]
The Company determines the adequacy of its allowance for credit loss by assessing the risks and losses inherent in its financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by the Company to its customers, which consist of the following: lease receivables, loan receivables, and financed service contracts and other.

[0000858877-16-000117:notes:274]
The Company’s internal credit risk ratings of 1 through 4 correspond to investment-grade ratings, while credit risk ratings of 5 and 6 correspond to non-investment grade ratings. Credit risk ratings of 7 and higher correspond to substandard ratings.

[0000858877-16-000117:notes:275]
In circumstances when collectibility is not deemed reasonably assured, the associated revenue is deferred in accordance with the Company’s revenue recognition policies, and the related allowance for credit loss, if any, is included in deferred revenue. The Company also records deferred revenue associated with financing receivables when there are remaining performance obligations, as it does for financed service contracts. Total allowances for credit loss and deferred revenue as of July 30, 2016 and July 25, 2015 were $2,112 million and $2,253 million, respectively, and they were associated with total financing receivables before allowance for credit loss of $8,805 million and $8,731 million as of their respective period ends.

[0000858877-16-000117:notes:276]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of July 30, 2016 and July 25, 2015 (in millions):

[0000858877-16-000117:notes:277]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 30, 2016 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 111 |  |  | $ | 25 |  |  | $ | 251 |  |  | $ | 387 |  |  | $ | 2,711 |  |  | $ | 3,098 |  |  | $ | 60 |  |  | $ | 60 |  |
| Loan receivables | 30 |  |  | 9 |  |  | 37 |  |  | 76 |  |  | 2,059 |  |  | 2,135 |  |  | 42 |  |  | 42 |  |
| Financed service contracts and other | 213 |  |  | 152 |  |  | 565 |  |  | 930 |  |  | 2,440 |  |  | 3,370 |  |  | 30 |  |  | 10 |  |
| Total | $ | 354 |  |  | $ | 186 |  |  | $ | 853 |  |  | $ | 1,393 |  |  | $ | 7,210 |  |  | $ | 8,603 |  |  | $ | 132 |  |  | $ | 112 |  |

[0000858877-16-000117:notes:278]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 25, 2015 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 90 |  |  | $ | 27 |  |  | $ | 185 |  |  | $ | 302 |  |  | $ | 2,869 |  |  | $ | 3,171 |  |  | $ | 73 |  |  | $ | 73 |  |
| Loan receivables | 21 |  |  | 3 |  |  | 25 |  |  | 49 |  |  | 1,714 |  |  | 1,763 |  |  | 32 |  |  | 32 |  |
| Financed service contracts and other | 396 |  |  | 152 |  |  | 414 |  |  | 962 |  |  | 2,611 |  |  | 3,573 |  |  | 29 |  |  | 9 |  |
| Total | $ | 507 |  |  | $ | 182 |  |  | $ | 624 |  |  | $ | 1,313 |  |  | $ | 7,194 |  |  | $ | 8,507 |  |  | $ | 134 |  |  | $ | 114 |  |

[0000858877-16-000117:notes:279]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract. The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $670 million and $496 million as of July 30, 2016 and July 25, 2015, respectively.

[0000858877-16-000117:notes:280]
As of July 30, 2016, the Company had financing receivables of $144 million, net of unbilled or current receivables, that were in the category of 91 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $70 million as of July 25, 2015.

[0000858877-16-000117:notes:281]
| (c) | Allowance for Credit Loss Rollforward |

[0000858877-16-000117:notes:282]
| (d) | Operating Leases |

[0000858877-16-000117:notes:283]
The Company provides financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-16-000117:notes:284]
|  | July 30, 2016 |  | July 25, 2015 |
| Operating lease assets | $ | 296 |  |  | $ | 372 |  |
| Accumulated depreciation | (161 | ) |  | (205 | ) |
| Operating lease assets, net | $ | 135 |  |  | $ | 167 |  |

[0000858877-16-000117:notes:285]
Minimum future rentals on noncancelable operating leases as of July 30, 2016 are summarized as follows (in millions):

[0000858877-16-000117:notes:286]
| Fiscal Year | Amount |
| 2017 | $ | 199 |  |
| 2018 | 138 |  |
| 2019 | 47 |  |
| 2020 | 8 |  |
| 2021 | 4 |  |
| Thereafter | 2 |  |
| Total | $ | 398 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000858877-16-000117:notes:287]
(m) Foreign Currency Translation   Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated to U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of AOCI. Income and expense accounts are translated at average exchange rates during the year. Remeasurement adjustments are recorded in other income (loss), net. The effect of foreign currency exchange rates on cash and cash equivalents was not material for any of the fiscal years presented.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-16-000117:notes:288]
| 4. | Goodwill and Purchased Intangible Assets |

[0000858877-16-000117:notes:289]
| (a) | Goodwill |

[0000858877-16-000117:notes:290]
The following tables present the goodwill allocated to the Company’s reportable segments as of July 30, 2016 and July 25, 2015, as well as the changes to goodwill during fiscal 2016 and 2015 (in millions):

[0000858877-16-000117:notes:291]
|  | Balance at July 25, 2015 |  | Acquisitions |  | Divestiture |  | Other |  | Balance at July 30, 2016 |
| Americas | $ | 15,212 |  |  | $ | 1,607 |  |  | $ | (126 | ) |  | $ | (164 | ) |  | $ | 16,529 |  |
| EMEA | 5,791 |  |  | 554 |  |  | (12 | ) |  | (64 | ) |  | 6,269 |  |
| APJC | 3,466 |  |  | 401 |  |  | (3 | ) |  | (37 | ) |  | 3,827 |  |
| Total | $ | 24,469 |  |  | $ | 2,562 |  |  | $ | (141 | ) |  | $ | (265 | ) |  | $ | 26,625 |  |

[0000858877-16-000117:notes:292]
|  | Balance at July 26, 2014 |  | Acquisitions |  | Divestiture |  | Other |  | Balance at July 25, 2015 |
| Americas | $ | 15,080 |  |  | $ | 145 |  |  | $ | — |  |  | $ | (13 | ) |  | $ | 15,212 |  |
| EMEA | 5,715 |  |  | 84 |  |  | — |  |  | (8 | ) |  | 5,791 |  |
| APJC | 3,444 |  |  | 26 |  |  | — |  |  | (4 | ) |  | 3,466 |  |
| Total | $ | 24,239 |  |  | $ | 255 |  |  | $ | — |  |  | $ | (25 | ) |  | $ | 24,469 |  |

[0000858877-16-000117:notes:293]
“Other” in the tables above primarily consists of foreign currency translation, as well as immaterial purchase accounting adjustments.

[0000858877-16-000117:notes:294]
| (b) | Purchased Intangible Assets |

[0000858877-16-000117:notes:295]
Purchased intangible assets include intangible assets acquired through acquisitions as well as through direct purchases or licenses.  In fiscal 2015, the Company, along with a number of other companies, entered into an agreement to obtain a license to the patents owned by the Rockstar Consortium, and the Company paid approximately $300 million, of which $188 million was expensed to product cost of sales related to the settlement of patent infringement claims, and the remainder was capitalized as an intangible asset to be amortized over its estimated useful life.

[0000858877-16-000117:notes:296]
Impairment charges related to purchased intangible assets were approximately $74 million and $175 million for fiscal 2016 and fiscal 2015, respectively. Impairment charges were as a result of declines in estimated fair value resulting from the reduction or elimination of expected future cash flows associated with certain of the Company’s technology and IPR&D intangible assets.  There were no impairment charges related to purchased intangible assets during fiscal 2014.

[0000858877-16-000117:notes:297]
The estimated future amortization expense of purchased intangible assets with finite lives as of July 30, 2016 is as follows (in millions):

[0000858877-16-000117:notes:298]
| Fiscal Year | Amount |
| 2017 | $ | 730 |  |
| 2018 | 585 |  |
| 2019 | 495 |  |
| 2020 | 275 |  |
| 2021 | 132 |  |
| Thereafter | 62 |  |
| Total | $ | 2,279 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000858877-16-000117:notes:299]
(i) Goodwill and Purchased Intangible Assets   Goodwill is tested for impairment on an annual basis in the fourth fiscal quarter and, when specific circumstances dictate, between annual tests. When impaired, the carrying value of goodwill is written down to fair value. The goodwill impairment test involves a two-step process. The first step, identifying a potential impairment, compares the fair value of a reporting unit with its carrying amount, including goodwill. If the carrying value of the reporting unit exceeds its fair value, the second step would need to be conducted; otherwise, no further steps are necessary as no potential impairment exists. If necessary, the second step to measure the impairment loss would be to compare the implied fair value of the reporting unit goodwill with the carrying amount of that goodwill. Any excess of the reporting unit goodwill carrying value over the respective implied fair value is recognized as an impairment loss. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. See “Long-Lived Assets” for the Company’s policy regarding impairment testing of purchased intangible assets with finite lives. Purchased intangible assets with indefinite lives are assessed for potential impairment annually or when events or circumstances indicate that their carrying amounts might be impaired.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000858877-16-000117:notes:300]
(j) Long-Lived Assets   Long-lived assets that are held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability of long-lived assets is based on an estimate of the undiscounted future cash flows resulting from the use of the asset and its eventual disposition. Measurement of an impairment loss for long-lived assets that management expects to hold and use is based on the difference between the fair value of the asset and its carrying value. Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-16-000117:notes:301]
| 16. | Income Taxes |

[0000858877-16-000117:notes:302]
| (a) | Provision for Income Taxes |

[0000858877-16-000117:notes:303]
The provision for income taxes consists of the following (in millions):

[0000858877-16-000117:notes:304]
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Federal: |  |  |  |  |  |
| Current | $ | 865 |  |  | $ | 1,583 |  |  | $ | 1,672 |  |
| Deferred | (93 | ) |  | 43 |  |  | (383 | ) |
|  | 772 |  |  | 1,626 |  |  | 1,289 |  |
| State: |  |  |  |  |  |
| Current | 78 |  |  | 130 |  |  | 176 |  |
| Deferred | 13 |  |  | (20 | ) |  | (64 | ) |
|  | 91 |  |  | 110 |  |  | 112 |  |
| Foreign: |  |  |  |  |  |
| Current | 1,432 |  |  | 530 |  |  | 692 |  |
| Deferred | (114 | ) |  | (46 | ) |  | (231 | ) |
|  | 1,318 |  |  | 484 |  |  | 461 |  |
| Total | $ | 2,181 |  |  | $ | 2,220 |  |  | $ | 1,862 |  |

[0000858877-16-000117:notes:305]
Income before provision for income taxes consists of the following (in millions):

[0000858877-16-000117:notes:306]
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| United States | $ | 2,907 |  |  | $ | 3,570 |  |  | $ | 2,734 |  |
| International | 10,013 |  |  | 7,631 |  |  | 6,981 |  |
| Total | $ | 12,920 |  |  | $ | 11,201 |  |  | $ | 9,715 |  |

[0000858877-16-000117:notes:307]
The items accounting for the difference between income taxes computed at the federal statutory rate and the provision for income taxes consist of the following:

[0000858877-16-000117:notes:308]
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Federal statutory rate | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 0.5 |  |  | 0.8 |  |  | 0.5 |  |
| Foreign income at other than U.S. rates | (14.5 | ) |  | (15.2 | ) |  | (16.4 | ) |
| Tax credits | (1.7 | ) |  | (1.2 | ) |  | (0.7 | ) |
| Domestic manufacturing deduction | (0.6 | ) |  | (0.7 | ) |  | (0.9 | ) |
| Nondeductible compensation | 1.4 |  |  | 2.0 |  |  | 3.3 |  |
| Tax audit settlement | (2.8 | ) |  | — |  |  | — |  |
| Other, net | (0.4 | ) |  | (0.9 | ) |  | (1.6 | ) |
| Total | 16.9 | % |  | 19.8 | % |  | 19.2 | % |

[0000858877-16-000117:notes:309]
During fiscal 2016, the Internal Revenue Service (IRS) and the Company settled all outstanding items related to the audit of the Company's federal income tax returns for the fiscal years ended July 26, 2008 through July 31, 2010.  As a result of the settlement, the Company recognized a net benefit to the provision for income taxes of $367 million, which included a reduction of interest expense of $21 million.  In addition, the Protecting Americans from Tax Hikes Act of 2015 reinstated the U.S. federal R&D tax credit permanently.  As a result, the tax provision in fiscal 2016 included a tax benefit of $226 million related to the U.S. R&D tax credit, of which $81 million was attributable to fiscal 2015.

[0000858877-16-000117:notes:310]
During fiscal 2015, the Tax Increase Prevention Act of 2014 reinstated the U.S. federal R&D tax credit for calendar year 2014 R&D expenses.  As a result, the tax provision in fiscal 2015 included a tax benefit of $138 million related to the U.S. R&D tax credit, of which $78 million was attributable to fiscal 2014.

[0000858877-16-000117:notes:311]
U.S. income taxes and foreign withholding taxes associated with the repatriation of earnings of foreign subsidiaries were not provided for on a cumulative total of $65.6 billion of undistributed earnings for certain foreign subsidiaries as of the end of fiscal 2016. The Company intends to reinvest these earnings indefinitely in its foreign subsidiaries. If these earnings were distributed to the United States in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, the Company would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. Determination of the amount of unrecognized deferred income tax liability related to these earnings is not practicable.

[0000858877-16-000117:notes:312]
As a result of certain employment and capital investment actions, the Company’s income in certain foreign countries is subject to reduced tax rates.  A portion of these incentives expired at the end of fiscal 2015.  The majority of the remaining tax incentives will expire at the end of fiscal 2018.  The gross income tax benefit attributable to tax incentives was estimated to be $1.2 billion ($0.23 per diluted share) in fiscal 2016.  As of the end of fiscal 2015 and 2014, the gross income tax benefits attributable to tax incentives were estimated to be $1.4 billion and $1.3 billion ($0.28 and $0.25 per diluted share) for the respective years. The gross income tax benefits were partially offset by accruals of U.S. income taxes on undistributed earnings.

[0000858877-16-000117:notes:313]
Unrecognized Tax Benefits

[0000858877-16-000117:notes:314]
The aggregate changes in the balance of gross unrecognized tax benefits were as follows (in millions):

[0000858877-16-000117:notes:315]
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Beginning balance | $ | 2,029 |  |  | $ | 1,938 |  |  | $ | 1,775 |  |
| Additions based on tax positions related to the current year | 255 |  |  | 276 |  |  | 262 |  |
| Additions for tax positions of prior years | 116 |  |  | 137 |  |  | 64 |  |
| Reductions for tax positions of prior years | (457 | ) |  | (30 | ) |  | (13 | ) |
| Settlements | (241 | ) |  | (165 | ) |  | (17 | ) |
| Lapse of statute of limitations | (75 | ) |  | (127 | ) |  | (133 | ) |
| Ending balance | $ | 1,627 |  |  | $ | 2,029 |  |  | $ | 1,938 |  |

[0000858877-16-000117:notes:316]
As a result of the IRS tax settlement related to the federal income tax returns for the fiscal years ended July 26, 2008 through July 31, 2010, the amount of gross unrecognized tax benefits in fiscal 2016 was reduced by approximately $563 million.  The Company also reduced the amount of accrued interest by $63 million.

[0000858877-16-000117:notes:317]
As of July 30, 2016, $1.2 billion of the unrecognized tax benefits would affect the effective tax rate if realized. During fiscal 2016, the Company recognized a $55 million reduction in net interest expense and a $40 million reduction in penalties.  During fiscal 2015, the Company recognized a $37 million reduction in net interest expense and a $3 million reduction in penalties.  During fiscal 2014, the Company recognized $20 million of net interest expense and $8 million of penalties. The Company’s total accrual for interest and penalties was $154 million, $274 million, and $304 million as of the end of fiscal 2016, 2015, and 2014, respectively. The Company is no longer subject to U.S. federal income tax audit for returns covering tax years through fiscal 2010. The Company is no longer subject to foreign, state, or local income tax audits for returns covering tax years through fiscal 2000.

[0000858877-16-000117:notes:318]
The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. The Company believes it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months.  Specific positions that may be resolved include issues involving transfer pricing and various other matters. The Company estimates that the unrecognized tax benefits at July 30, 2016 could be reduced by approximately $150 million in the next 12 months.

[0000858877-16-000117:notes:319]
| (b) | Deferred Tax Assets and Liabilities |

[0000858877-16-000117:notes:320]
The following table presents the breakdown for net deferred tax assets (in millions):

[0000858877-16-000117:notes:321]
|  | July 30, 2016 |  | July 25, 2015 |
| Deferred tax assets | $ | 4,299 |  |  | $ | 4,454 |  |
| Deferred tax liabilities | (278 | ) |  | (349 | ) |
| Total net deferred tax assets | $ | 4,021 |  |  | $ | 4,105 |  |

[0000858877-16-000117:notes:322]
The following table presents the components of the deferred tax assets and liabilities (in millions):

[0000858877-16-000117:notes:323]
|  | July 30, 2016 |  | July 25, 2015 |
| ASSETS |  |  |  |
| Allowance for doubtful accounts and returns | $ | 524 |  |  | $ | 417 |  |
| Sales-type and direct-financing leases | 289 |  |  | 266 |  |
| Inventory write-downs and capitalization | 417 |  |  | 345 |  |
| Investment provisions | 126 |  |  | 112 |  |
| IPR&D, goodwill, and purchased intangible assets | 139 |  |  | 134 |  |
| Deferred revenue | 1,858 |  |  | 1,795 |  |
| Credits and net operating loss carryforwards | 863 |  |  | 746 |  |
| Share-based compensation expense | 438 |  |  | 520 |  |
| Accrued compensation | 572 |  |  | 467 |  |
| Other | 516 |  |  | 670 |  |
| Gross deferred tax assets | 5,742 |  |  | 5,472 |  |
| Valuation allowance | (134 | ) |  | (84 | ) |
| Total deferred tax assets | 5,608 |  |  | 5,388 |  |
| LIABILITIES |  |  |  |
| Purchased intangible assets | (995 | ) |  | (950 | ) |
| Depreciation | (289 | ) |  | (143 | ) |
| Unrealized gains on investments | (225 | ) |  | (175 | ) |
| Other | (78 | ) |  | (15 | ) |
| Total deferred tax liabilities | (1,587 | ) |  | (1,283 | ) |
| Total net deferred tax assets | $ | 4,021 |  |  | $ | 4,105 |  |

[0000858877-16-000117:notes:324]
As of July 30, 2016, the Company’s federal, state, and foreign net operating loss carryforwards for income tax purposes were $466 million, $735 million, and $809 million, respectively.  A significant amount of the federal net operating loss carryforwards relates to acquisitions and, as a result, is limited in the amount that can be recognized in any one year. If not utilized, the federal net operating loss will begin to expire in fiscal 2018, and the state and foreign net operating loss carryforwards will begin to expire in fiscal 2018 and 2017, respectively. The Company has provided a valuation allowance of $97 million for deferred tax assets related to foreign net operating losses that are not expected to be realized.

[0000858877-16-000117:notes:325]
As of July 30, 2016, the Company’s federal, state, and foreign tax credit carryforwards for income tax purposes were approximately $8 million, $734 million, and $20 million, respectively. The federal tax credit carryforwards will begin to expire in fiscal 2017.  The majority of state tax credits can be carried forward indefinitely. The foreign tax credits carryforwards will begin to expire in fiscal 2018.  The Company has provided a valuation allowance of $32 million for deferred tax assets related to state and foreign tax credits that are not expected to be realized.


## us-gaap:IncomeTaxPolicyTextBlock

[0000858877-16-000117:notes:326]
(s) Income Taxes   Income tax expense is based on pretax financial accounting income. Deferred tax assets and liabilities are recognized for the expected tax consequences of temporary differences between the tax bases of assets and liabilities and their reported amounts. Valuation allowances are recorded to reduce deferred tax assets to the amount that will more likely than not be realized.

[0000858877-16-000117:notes:327]
The Company accounts for uncertainty in income taxes using a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. The Company classifies the liability for unrecognized tax benefits as current to the extent that the Company anticipates payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.


## us-gaap:InventoryDisclosureTextBlock

[0000858877-16-000117:notes:328]
The following tables provide details of selected balance sheet items (in millions):

[0000858877-16-000117:notes:329]
|  |  | July 30, 2016 |  | July 25, 2015 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 91 |  |  | $ | 114 |  |
| Work in process |  | — |  |  | 2 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 457 |  |  | 610 |  |
| Manufactured finished goods |  | 415 |  |  | 593 |  |
| Total finished goods |  | 872 |  |  | 1,203 |  |
| Service-related spares |  | 236 |  |  | 258 |  |
| Demonstration systems |  | 18 |  |  | 50 |  |
| Total |  | $ | 1,217 |  |  | $ | 1,627 |  |


## us-gaap:InventoryPolicyTextBlock

[0000858877-16-000117:notes:330]
(d) Inventories   Inventories are stated at the lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company provides inventory write-downs based on excess and obsolete inventories determined primarily by future demand forecasts. The write-down is measured as the difference between the cost of the inventory and market based upon assumptions about future demand and charged to the provision for inventory, which is a component of cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In addition, the Company records a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of the Company’s future demand forecasts consistent with its valuation of excess and obsolete inventory.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-16-000117:notes:331]
The following table summarizes the maturities of the Company’s fixed income securities at July 30, 2016 (in millions):

[0000858877-16-000117:notes:332]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 15,473 |  |  | $ | 15,485 |  |
| Due in 1 to 2 years | 17,791 |  |  | 17,847 |  |
| Due in 2 to 5 years | 20,870 |  |  | 21,128 |  |
| Due after 5 years | 288 |  |  | 293 |  |
| Mortgage-backed securities with no single maturity | 1,846 |  |  | 1,868 |  |
| Total | $ | 56,268 |  |  | $ | 56,621 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-16-000117:notes:333]
| 8. | Investments |

[0000858877-16-000117:notes:334]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-16-000117:notes:335]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-16-000117:notes:336]
| July 30, 2016 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 26,473 |  |  | $ | 73 |  |  | $ | (2 | ) |  | $ | 26,544 |  |
| U.S. government agency securities | 2,809 |  |  | 8 |  |  | — |  |  | 2,817 |  |
| Non-U.S. government and agency securities | 1,096 |  |  | 4 |  |  | — |  |  | 1,100 |  |
| Corporate debt securities | 24,044 |  |  | 263 |  |  | (15 | ) |  | 24,292 |  |
| U.S. agency mortgage-backed securities | 1,846 |  |  | 22 |  |  | — |  |  | 1,868 |  |
| Total fixed income securities | 56,268 |  |  | 370 |  |  | (17 | ) |  | 56,621 |  |
| Publicly traded equity securities | 1,211 |  |  | 333 |  |  | (40 | ) |  | 1,504 |  |
| Total (1) | $ | 57,479 |  |  | $ | 703 |  |  | $ | (57 | ) |  | $ | 58,125 |  |
| July 25, 2015 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 29,904 |  |  | $ | 41 |  |  | $ | (6 | ) |  | $ | 29,939 |  |
| U.S. government agency securities | 3,662 |  |  | 2 |  |  | (1 | ) |  | 3,663 |  |
| Non-U.S. government and agency securities | 1,128 |  |  | 1 |  |  | (1 | ) |  | 1,128 |  |
| Corporate debt securities | 15,802 |  |  | 34 |  |  | (53 | ) |  | 15,783 |  |
| U.S. agency mortgage-backed securities | 1,456 |  |  | 8 |  |  | (3 | ) |  | 1,461 |  |
| Total fixed income securities | 51,952 |  |  | 86 |  |  | (64 | ) |  | 51,974 |  |
| Publicly traded equity securities | 1,092 |  |  | 480 |  |  | (7 | ) |  | 1,565 |  |
| Total (1) | $ | 53,044 |  |  | $ | 566 |  |  | $ | (71 | ) |  | $ | 53,539 |  |

[0000858877-16-000117:notes:337]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases were $654 million and $4 million as of July 30, 2016 and July 25, 2015, respectively.

[0000858877-16-000117:notes:338]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-16-000117:notes:339]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-16-000117:notes:340]
The following table presents the gross realized gains and gross realized losses related to the Company’s available-for-sale investments (in millions):

[0000858877-16-000117:notes:341]
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Gross realized gains | $ | 152 |  |  | $ | 221 |  |  | $ | 341 |  |
| Gross realized losses | (153 | ) |  | (64 | ) |  | (41 | ) |
| Total | $ | (1 | ) |  | $ | 157 |  |  | $ | 300 |  |

[0000858877-16-000117:notes:342]
The following table presents the realized net gains related to the Company’s available-for-sale investments by security type (in millions):

[0000858877-16-000117:notes:343]
| Years Ended | July 30, 2016 |  | July 25, 2015 |  | July 26, 2014 |
| Net gains on investments in publicly traded equity securities | $ | 33 |  |  | $ | 116 |  |  | $ | 253 |  |
| Net gains/(losses) on investments in fixed income securities | (34 | ) |  | 41 |  |  | 47 |  |
| Total | $ | (1 | ) |  | $ | 157 |  |  | $ | 300 |  |

[0000858877-16-000117:notes:344]
For fiscal 2016, the realized net losses related to the Company's available-for-sale investments included impairment charges of $3 million for fixed income securities.  There were no impairment charges on available-for-sale investments for fiscal 2015. For fiscal 2014, the realized net gains related to the Company's available-for-sale investments included impairment charges of $11 million for publicly traded equity securities. The impairment charges were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary.

[0000858877-16-000117:notes:345]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at July 30, 2016 and July 25, 2015 (in millions):

[0000858877-16-000117:notes:346]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 30, 2016 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 2,414 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |  | $ | 2,414 |  |  | $ | (2 | ) |
| U.S. government agency securities | 144 |  |  | — |  |  | — |  |  | — |  |  | 144 |  |  | — |  |
| Non-U.S. government and agency securities | 61 |  |  | — |  |  | — |  |  | — |  |  | 61 |  |  | — |  |
| Corporate debt securities | 2,499 |  |  | (7 | ) |  | 1,208 |  |  | (8 | ) |  | 3,707 |  |  | (15 | ) |
| U.S. agency mortgage-backed securities | 174 |  |  | — |  |  | — |  |  | — |  |  | 174 |  |  | — |  |
| Total fixed income securities | 5,292 |  |  | (9 | ) |  | 1,208 |  |  | (8 | ) |  | 6,500 |  |  | (17 | ) |
| Publicly traded equity securities | 188 |  |  | (40 | ) |  | — |  |  | — |  |  | 188 |  |  | (40 | ) |
| Total | $ | 5,480 |  |  | $ | (49 | ) |  | $ | 1,208 |  |  | $ | (8 | ) |  | $ | 6,688 |  |  | $ | (57 | ) |

[0000858877-16-000117:notes:347]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 25, 2015 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 6,412 |  |  | $ | (6 | ) |  | $ | — |  |  | $ | — |  |  | $ | 6,412 |  |  | $ | (6 | ) |
| U.S. government agency securities | 1,433 |  |  | (1 | ) |  | — |  |  | — |  |  | 1,433 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 515 |  |  | (1 | ) |  | 4 |  |  | — |  |  | 519 |  |  | (1 | ) |
| Corporate debt securities | 9,552 |  |  | (49 | ) |  | 312 |  |  | (4 | ) |  | 9,864 |  |  | (53 | ) |
| U.S. agency mortgage-backed securities | 579 |  |  | (3 | ) |  | — |  |  | — |  |  | 579 |  |  | (3 | ) |
| Total fixed income securities | 18,491 |  |  | (60 | ) |  | 316 |  |  | (4 | ) |  | 18,807 |  |  | (64 | ) |
| Publicly traded equity securities | 108 |  |  | (7 | ) |  | 2 |  |  | — |  |  | 110 |  |  | (7 | ) |
| Total | $ | 18,599 |  |  | $ | (67 | ) |  | $ | 318 |  |  | $ | (4 | ) |  | $ | 18,917 |  |  | $ | (71 | ) |

[0000858877-16-000117:notes:348]
As of July 30, 2016, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments, and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of July 30, 2016, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses as of July 30, 2016 were required to be recognized.

[0000858877-16-000117:notes:349]
The Company has evaluated its publicly traded equity securities as of July 30, 2016 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-16-000117:notes:350]
| (c) | Maturities of Fixed Income Securities |

[0000858877-16-000117:notes:351]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations. The remaining contractual principal maturities for mortgage-backed securities were allocated assuming no prepayments.

[0000858877-16-000117:notes:352]
| (d) | Securities Lending |

[0000858877-16-000117:notes:353]
The Company periodically engages in securities lending activities with certain of its available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for fiscal 2016 and 2015 was $1.0 billion and $0.4 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented.  As of July 30, 2016 and July 25, 2015, the Company had no outstanding securities lending transactions.

[0000858877-16-000117:notes:354]
| (e) | Investments in Privately Held Companies |

[0000858877-16-000117:notes:355]
The carrying value of the Company’s investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of July 30, 2016 and July 25, 2015, the amounts are summarized in the following table (in millions):

[0000858877-16-000117:notes:356]
For additional information on impairment charges related to investments in privately held companies, see Note 9.

[0000858877-16-000117:notes:357]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings and has determined that as of July 30, 2016, except as disclosed herein, there were no variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-16-000117:notes:358]
| 1. | Basis of Presentation |

[0000858877-16-000117:notes:359]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2016 was a 53-week fiscal year, and each of fiscal 2015 and fiscal 2014 were 52-week fiscal years. The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated.  The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-16-000117:notes:360]
The Company consolidates its investments in a venture fund managed by SOFTBANK Corp. and its affiliates (“SOFTBANK”) as this is a variable interest entity and the Company is the primary beneficiary. The noncontrolling interests attributed to SOFTBANK are presented as a separate component from the Company’s equity in the equity section of the Consolidated Balance Sheets. SOFTBANK’s share of the earnings in the venture fund are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-16-000117:notes:361]
Certain reclassifications have been made to the amounts for prior years in order to conform to the current year’s presentation. The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000858877-16-000117:notes:362]
(g) Depreciation and Amortization   Property and equipment are stated at cost, less accumulated depreciation or amortization, whenever applicable. Depreciation and amortization expenses for property and equipment were approximately $1.0 billion, $1.1 billion, and $1.2 billion for fiscal 2016, 2015, and 2014, respectively. Depreciation and amortization are computed using the straight-line method, generally over the following periods:


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-16-000117:notes:363]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,778 |  |  | $ | 4,495 |  |
| Computer equipment and related software |  | 1,288 |  |  | 1,310 |  |
| Production, engineering, and other equipment |  | 5,658 |  |  | 5,753 |  |
| Operating lease assets |  | 296 |  |  | 372 |  |
| Furniture and fixtures |  | 543 |  |  | 497 |  |
| Total gross property and equipment |  | 12,563 |  |  | 12,427 |  |
| Less: accumulated depreciation and amortization |  | (9,057 | ) |  | (9,095 | ) |
| Total |  | $ | 3,506 |  |  | $ | 3,332 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000858877-16-000117:notes:364]
(r) Software Development Costs   Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-16-000117:notes:365]
| 5. | Restructuring and Other Charges |

[0000858877-16-000117:notes:366]
The Company announced a restructuring action in August 2014 (the “Fiscal 2015 Plan”), in order to realign its workforce towards key growth areas of its business such as data center, software, security, and cloud. In connection with this plan, the Company incurred cumulative charges of approximately $756 million. The Company completed the Fiscal 2015 Plan at the end of fiscal 2016.

[0000858877-16-000117:notes:367]
In connection with a restructuring action announced in August 2013 (the “Fiscal 2014 Plan”), the Company incurred cumulative charges of approximately $417 million, of which a $1 million credit was recognized in fiscal 2016. The Company completed the Fiscal 2014 Plan at the end of fiscal 2014.

[0000858877-16-000117:notes:368]
The following table summarizes the activities related to the restructuring and other charges, as discussed above (in millions):

[0000858877-16-000117:notes:369]
|  |  | FISCAL 2014 AND PRIOR YEAR PLANS |  | FISCAL 2015 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 27, 2013 |  | $ | 21 |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  | $ | 28 |  |
| Charges |  | 366 |  |  | 52 |  |  | — |  |  | — |  |  | 418 |  |
| Cash payments |  | (345 | ) |  | (7 | ) |  | — |  |  | — |  |  | (352 | ) |
| Non-cash items |  | (2 | ) |  | (23 | ) |  | — |  |  | — |  |  | (25 | ) |
| Liability as of July 26, 2014 |  | 40 |  |  | 29 |  |  | — |  |  | — |  |  | 69 |  |
| Charges |  | — |  |  | — |  |  | 464 |  |  | 20 |  |  | 484 |  |
| Cash payments |  | (29 | ) |  | (14 | ) |  | (413 | ) |  | (3 | ) |  | (459 | ) |
| Non-cash items |  | — |  |  | (1 | ) |  | (2 | ) |  | (2 | ) |  | (5 | ) |
| Liability as of July 25, 2015 |  | 11 |  |  | 14 |  |  | 49 |  |  | 15 |  |  | 89 |  |
| Charges |  | — |  |  | (1 | ) |  | 225 |  |  | 44 |  |  | 268 |  |
| Cash payments |  | (11 | ) |  | (4 | ) |  | (253 | ) |  | (11 | ) |  | (279 | ) |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (33 | ) |  | (33 | ) |
| Liability as of July 30, 2016 |  | $ | — |  |  | $ | 9 |  |  | $ | 21 |  |  | $ | 15 |  |  | $ | 45 |  |

[0000858877-16-000117:notes:370]
In addition to the above amounts, the Company incurred $2 million credit and $5 million of restructuring and other charges within cost of sales during fiscal 2016 and fiscal 2015, respectively.

[0000858877-16-000117:notes:371]
In August 2016, the Company announced a restructuring plan that will impact up to 5,500 employees, representing approximately 7% of its global workforce. The Company began taking action under this plan in the first quarter of fiscal 2017. The Company currently estimates that it will recognize pre-tax charges of up to $700 million consisting of severance and other one-time termination benefits, and other associated costs. These charges are primarily cash based. The Company expects that approximately $325 million to $400 million of these charges will be recognized during the first quarter of fiscal 2017, with the remaining amount to be recognized during the rest of the fiscal 2017.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000858877-16-000117:notes:372]
(o) Revenue Recognition   The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is reasonably assured. In instances where final acceptance of the product, system, or solution is specified by the customer, revenue is deferred until all acceptance criteria have been met. For hosting arrangements, the Company recognizes subscription revenue ratably over the subscription period, while usage revenue is recognized based on utilization. Software subscription revenue is deferred and recognized ratably over the subscription term upon delivery of the first product and commencement of the term. Technical support and consulting services revenue is deferred and recognized ratably over the period during which the services are to be performed, which is typically from one to three years. Transactional advanced services revenue is recognized upon delivery or completion of performance milestones.

[0000858877-16-000117:notes:373]
The Company uses distributors that stock inventory and typically sell to systems integrators, service providers, and other resellers.     The Company refers to this as its two-tier sales to the end customer. Revenue from distributors is recognized based on a sell-through method using point-of-sale information provided by the distributors. Distributors and other partners participate in various rebate, cooperative marketing, and other incentive programs, and the Company maintains estimated accruals and allowances for these programs. The ending liability for these programs was included in other current liabilities, and the balance as of July 30, 2016 and July 25, 2015 was $1.1 billion and $1.3 billion, respectively. The Company accrues for warranty costs, sales returns, and other allowances based on its historical experience. Shipping and handling fees billed to customers are included in revenue, with the associated costs included in cost of sales.

[0000858877-16-000117:notes:374]
Many of the Company’s products have both software and non-software components that function together to deliver the products’ essential functionality. The Company’s product offerings fall into the following categories: Switching, Next-Generation Network (NGN) Routing, Collaboration, Service Provider Video, Data Center, Wireless, Security, and Other Products. The Company also provides technical support and advanced services. The Company has a broad customer base that encompasses virtually all types of public and private entities, including enterprise businesses, service providers, and commercial customers. The Company and its salesforce are not organized by product divisions, and the Company’s products and services can be sold standalone or together in various combinations across the Company’s geographic segments or customer markets. For example, service provider arrangements are typically larger in scale with longer deployment schedules and involve the delivery of a variety of product technologies, including high-end routing, video and network management software, and other product technologies along with technical support and advanced services. The Company’s enterprise and commercial arrangements are unique for each customer and smaller in scale and may include network infrastructure products such as routers and switches or collaboration technologies such as Unified Communications and Cisco TelePresence systems products along with technical support services.

[0000858877-16-000117:notes:375]
The Company enters into revenue arrangements that may consist of multiple deliverables of its product and service offerings due to the needs of its customers. For example, a customer may purchase routing products along with a contract for technical support services. This arrangement would consist of multiple elements, with the products delivered in one reporting period and the technical support services delivered across multiple reporting periods. Another customer may purchase networking products along with advanced service offerings, in which all the elements are delivered within the same reporting period. In addition, distributors purchase products or technical support services on a standalone basis for resale to an end user or for purposes of stocking certain products, and these transactions would not result in a multiple-element arrangement. The Company considers several factors when reviewing multiple purchases made by the same customer within a short time frame in order to identify multiple-element arrangements, including whether the deliverables are closely interrelated, whether the deliverables are essential to each other’s functionality, whether payment terms are linked, whether the customer is entitled to a refund or concession if another purchase is not completed satisfactorily, and/or whether the purchases were negotiated together as one overall arrangement.

[0000858877-16-000117:notes:376]
In many instances, products are sold separately in standalone arrangements as customers may support the products themselves or purchase support on a time-and-materials basis. Advanced services are sometimes sold in standalone engagements such as general consulting, network management, or security advisory projects, and technical support services are sold separately through renewals of annual contracts. The Company determines its vendor-specific objective evidence (VSOE) based on its normal pricing and discounting practices for products or services when sold separately. VSOE determination requires that a substantial majority of the historical standalone transactions has the selling prices for a product or service that fall within a reasonably narrow pricing range, generally evidenced by approximately 80% of such historical standalone transactions falling within plus or minus 15% of the median rates. In addition, the Company considers the geographies in which the products or services are sold, major product and service groups and customer classifications, and other environmental or marketing variables in determining VSOE.

[0000858877-16-000117:notes:377]
When the Company is not able to establish VSOE for all deliverables in an arrangement with multiple elements, which may be due to the Company infrequently selling each element separately, not pricing products within a narrow range, or only having a limited sales history, such as in the case of certain newly introduced product categories, the Company attempts to determine the selling price of each element based on third-party evidence of selling price (TPE). TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, the Company’s go-to-market strategy differs from that of its peers, and its offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, the Company is unable to reliably determine what similar competitor products’ selling prices are on a standalone basis. Therefore, the Company is typically not able to determine TPE.

[0000858877-16-000117:notes:378]
When the Company is unable to establish fair value using VSOE or TPE, the Company uses estimated selling prices (ESP) in its allocation of arrangement consideration. The objective of ESP is to determine the price at which the Company would transact a sale if the product or service were regularly sold on a standalone basis. ESP is generally used for new or highly proprietary offerings and solutions or for offerings not priced within a reasonably narrow range. The Company determines ESP for a product or service by considering multiple factors, including, but not limited to, geographies, market conditions, competitive landscape, internal costs, gross margin objectives, and pricing practices. The determination of ESP is made through consultation with and formal approval by the Company’s management, taking into consideration the go-to-market strategy.

[0000858877-16-000117:notes:379]
The Company regularly reviews VSOE, TPE, and ESP and maintains internal controls over the establishment and updates of these estimates. There were no material impacts during the fiscal year, nor does the Company currently expect a material impact in the near term from changes in VSOE, TPE, or ESP.

[0000858877-16-000117:notes:380]
The Company’s arrangements with multiple deliverables may include one or more software deliverables that are subject to the software revenue recognition guidance. In these cases, revenue for the software is generally recognized upon shipment or electronic delivery and granting of the license. The revenue for these multiple-element arrangements is allocated to the software deliverables and the non-software deliverables based on the relative selling prices of all of the deliverables in the arrangement using the hierarchy in the applicable accounting guidance. In the circumstances where the Company cannot determine VSOE or TPE of the selling price for all of the deliverables in the arrangement, including the software deliverables, ESP is used for the purposes of performing this allocation. VSOE is required to allocate the revenue between multiple software deliverables. If VSOE is available for the undelivered software elements, the Company applies the residual method; where VSOE is not available, software revenue is either recognized when all software elements have been delivered or recognized ratably when post-contract support is the only undelivered software element remaining.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0000858877-16-000117:notes:381]
A summary of the allocation of the total purchase consideration is presented as follows (in millions):


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000858877-16-000117:notes:382]
SCHEDULE II

[0000858877-16-000117:notes:383]
VALUATION AND QUALIFYING ACCOUNTS

[0000858877-16-000117:notes:384]
(in millions)

[0000858877-16-000117:notes:385]
|  | Allowances For |
|  | FinancingReceivables |  | AccountsReceivable |
| Year ended July 26, 2014 |  |  |  |
| Balance at beginning of fiscal year | $ | 344 |  |  | $ | 228 |  |
| Provisions | 14 |  |  | 65 |  |
| Recoveries (write-offs), net | (9 | ) |  | (28 | ) |
| Balance at end of fiscal year | $ | 349 |  |  | $ | 265 |  |
| Year ended July 25, 2015 |  |  |  |
| Balance at beginning of fiscal year | $ | 349 |  |  | $ | 265 |  |
| Provisions | 57 |  |  | 77 |  |
| Recoveries (write-offs), net | (7 | ) |  | (40 | ) |
| Foreign exchange and other | (17 | ) |  | — |  |
| Balance at end of fiscal year | $ | 382 |  |  | $ | 302 |  |
| Year ended July 30, 2016 |  |  |  |
| Balance at beginning of fiscal year | $ | 382 |  |  | $ | 302 |  |
| Provisions | 17 |  |  | (26 | ) |
| Recoveries (write-offs), net | (15 | ) |  | (28 | ) |
| Foreign exchange and other | (9 | ) |  | 1 |  |
| Balance at end of fiscal year | $ | 375 |  |  | $ | 249 |  |

[0000858877-16-000117:notes:386]
Foreign exchange and other includes the impact of foreign exchange and certain immaterial reclassifications.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-16-000117:notes:387]
| 2. | Summary of Significant Accounting Policies |

[0000858877-16-000117:notes:388]
(b) Available-for-Sale Investments   The Company classifies its investments in both fixed income securities and publicly traded equity securities as available-for-sale investments. Fixed income securities primarily consist of U.S. government securities, U.S. government agency securities, non-U.S. government and agency securities, corporate debt securities, and U.S. agency mortgage-backed securities. These available-for-sale investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of fixed income and public equity securities sold. These investments are recorded in the Consolidated Balance Sheets at fair value. Unrealized gains and losses on these investments, to the extent the investments are unhedged, are included as a separate component of accumulated other comprehensive income (AOCI), net of tax. The Company classifies its investments as current based on the nature of the investments and their availability for use in current operations.

[0000858877-16-000117:notes:389]
(e) Allowance for Doubtful Accounts   The allowance for doubtful accounts is based on the Company’s assessment of the collectibility of customer accounts. The Company regularly reviews the allowance by considering factors such as historical experience, credit quality, age of the accounts receivable balances, economic conditions that may affect a customer’s ability to pay, and expected default frequency rates. Trade receivables are written off at the point when they are considered uncollectible.

[0000858877-16-000117:notes:390]
(f) Financing Receivables and Guarantees   The Company provides financing arrangements, including leases, financed service contracts, and loans, for certain qualified end-user customers to build, maintain, and upgrade their networks. Lease receivables primarily represent sales-type and direct-financing leases. Leases have on average a four-year term and are usually collateralized by a security interest in the underlying assets, while loan receivables generally have terms of up to three years. Financed service contracts typically have terms of one to three years and primarily relate to technical support services.

[0000858877-16-000117:notes:391]
The Company determines the adequacy of its allowance for credit loss by assessing the risks and losses inherent in its financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by the Company to its customers: lease receivables, loan receivables, and financed service contracts and other.

[0000858877-16-000117:notes:392]
The Company assesses the allowance for credit loss related to financing receivables on either an individual or a collective basis. The Company considers various factors in evaluating lease and loan receivables and the earned portion of financed service contracts for possible impairment on an individual basis. These factors include the Company’s historical experience, credit quality and age of the receivable balances, and economic conditions that may affect a customer’s ability to pay. When the evaluation indicates that it is probable that all amounts due pursuant to the contractual terms of the financing agreement, including scheduled interest payments, are unable to be collected, the financing receivable is considered impaired. All such outstanding amounts, including any accrued interest, are assessed and fully reserved at the customer level. The Company’s internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality financing receivables. Typically, the Company also considers financing receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. The Company evaluates the remainder of its financing receivables portfolio for impairment on a collective basis and records an allowance for credit loss at the portfolio segment level. When evaluating the financing receivables on a collective basis, the Company uses historical default rates and expected default frequency rates published by major third-party credit-rating agencies as well as its own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk, and correlation.

[0000858877-16-000117:notes:393]
Expected default frequency rates and historical default rates are published quarterly by major third-party credit-rating agencies, and the internal credit risk rating is derived by taking into consideration various customer-specific factors and macroeconomic conditions. These factors, which include the strength of the customer’s business and financial performance, the quality of the customer’s banking relationships, the Company’s specific historical experience with the customer, the performance and outlook of the customer’s industry, the customer’s legal and regulatory environment, the potential sovereign risk of the geographic locations in which the customer is operating, and independent third-party evaluations, are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000858877-16-000117:notes:394]
Financing receivables are written off at the point when they are considered uncollectible, and all outstanding balances, including any previously earned but uncollected interest income, will be reversed and charged against the allowance for credit loss. The Company does not typically have any partially written-off financing receivables.

[0000858877-16-000117:notes:395]
Outstanding financing receivables that are aged 31 days or more from the contractual payment date are considered past due. The Company does not accrue interest on financing receivables that are considered impaired or more than 90 days past due unless either the receivable has not been collected due to administrative reasons or the receivable is well secured and in the process of collection. Financing receivables may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain. After a financing receivable has been categorized as nonaccrual, interest will be recognized when cash is received. A financing receivable may be returned to accrual status after all of the customer’s delinquent balances of principal and interest have been settled, and the customer remains current for an appropriate period.

[0000858877-16-000117:notes:396]
The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of the Company’s receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and the Company receives a payment for the receivables from the third party based on the Company’s standard payment terms. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The Company could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Deferred revenue relating to these financing arrangements is recorded in accordance with revenue recognition policies or for the fair value of the financing guarantees.

[0000858877-16-000117:notes:397]
(k) Fair Value   Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, the Company considers the principal or most advantageous market in which it would transact, and it also considers assumptions that market participants would use when pricing the asset or liability.

[0000858877-16-000117:notes:398]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. The standard establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000858877-16-000117:notes:399]
Level 1 applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000858877-16-000117:notes:400]
Level 2 applies to assets or liabilities for which there are inputs other than quoted prices that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets); or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000858877-16-000117:notes:401]
Level 3 applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0000858877-16-000117:notes:402]
(u) Consolidation of Variable Interest Entities  The Company uses a qualitative approach in assessing the consolidation requirement for variable interest entities. The approach focuses on identifying which enterprise has the power to direct the activities that most significantly impact the variable interest entity’s economic performance and which enterprise has the obligation to absorb losses or the right to receive benefits from the variable interest entity. In the event that the Company is the primary beneficiary of a variable interest entity, the assets, liabilities, and results of operations of the variable interest entity will be included in the Company’s Consolidated Financial Statements.

[0000858877-16-000117:notes:403]
(v) Use of Estimates   The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Estimates are used for the following, among others:

[0000858877-16-000117:notes:404]
| ▪ | Revenue recognition |

[0000858877-16-000117:notes:405]
| ▪ | Allowances for accounts receivable, sales returns, and financing receivables |

[0000858877-16-000117:notes:406]
| ▪ | Inventory valuation and liability for purchase commitments with contract manufacturers and suppliers |

[0000858877-16-000117:notes:407]
| ▪ | Loss contingencies and product warranties |

[0000858877-16-000117:notes:408]
| ▪ | Fair value measurements and other-than-temporary impairments |

[0000858877-16-000117:notes:409]
| ▪ | Goodwill and purchased intangible asset impairments |

[0000858877-16-000117:notes:410]
| ▪ | Income taxes |

[0000858877-16-000117:notes:411]
The actual results experienced by the Company may differ materially from management’s estimates.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-16-000117:notes:412]
| 13. | Shareholders’ Equity |

[0000858877-16-000117:notes:413]
| (a) | Cash Dividends on Shares of Common Stock |

[0000858877-16-000117:notes:414]
During fiscal 2016, the Company declared and paid cash dividends of $0.94 per common share, or $4.8 billion, on the Company’s outstanding common stock.  During fiscal 2015, the Company declared and paid cash dividends of $0.80 per common share, or $4.1 billion, on the Company’s outstanding common stock.

[0000858877-16-000117:notes:415]
Any future dividends will be subject to the approval of the Company's Board of Directors.

[0000858877-16-000117:notes:416]
| (b) | Stock Repurchase Program |

[0000858877-16-000117:notes:417]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of July 30, 2016, the Company’s Board of Directors had authorized an aggregate repurchase of up to $112 billion of common stock under this program, and the remaining authorized repurchase amount was $15.4 billion, with no termination date. A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-16-000117:notes:418]
The purchase price for the shares of the Company’s stock repurchased is reflected as a reduction to shareholders’ equity. The Company is required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings and (ii) a reduction of common stock and additional paid-in capital.

[0000858877-16-000117:notes:419]
| (c) | Restricted Stock Unit Withholdings |

[0000858877-16-000117:notes:420]
For the years ended July 30, 2016 and July 25, 2015, the Company repurchased approximately 21 million and 20 million shares, or $557 million and $502 million, of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.

[0000858877-16-000117:notes:421]
| (d) | Preferred Stock |

[0000858877-16-000117:notes:422]
Under the terms of the Company’s Articles of Incorporation, the Board of Directors may determine the rights, preferences, and terms of the Company’s authorized but unissued shares of preferred stock.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-16-000117:notes:423]
| 6. | Balance Sheet Details |


## us-gaap:TreasuryStockTextBlock

[0000858877-16-000117:notes:424]
Supplemental Information

[0000858877-16-000117:notes:425]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of July 30, 2016, the Company’s Board of Directors had authorized an aggregate repurchase of up to $112 billion of common stock under this program with no termination date. For additional information regarding stock repurchase, see Note 13 to the Consolidated Financial Statements. The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):
