# CSCO 8-K — 0001193125-16-684126 filed 2016-08-17

## item codes, every 8-K on or before 2016-09-08

- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2016-09-08

- none on or before 2016-09-08

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-684126:8k_2_02:1]
EX-99.1
2
d410923dex991.htm
EX-99.1

[0001193125-16-684126:8k_2_02:2]
EX-99.1

[0001193125-16-684126:8k_2_02:3]
Exhibit 99.1

[0001193125-16-684126:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Andrea Duffy |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (646) 295-5241 |  |  |  | 1 (408) 527-7452 |
| anduffy@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-16-684126:8k_2_02:5]
CISCO REPORTS FOURTH QUARTER AND FISCAL YEAR 2016 EARNINGS

[0001193125-16-684126:8k_2_02:6]
|  | • |  | Q4 Revenue: $12.6 billion |

[0001193125-16-684126:8k_2_02:7]
|  | • |  | Growth of 2% year over year — Q4 guidance was 0% to 3% growth year over year (normalized to exclude the SP Video CPE Business for Q4 FY 2015) |

[0001193125-16-684126:8k_2_02:8]
|  | • |  | Q4 Earnings per Share: $0.56 GAAP; $0.63 non-GAAP |

[0001193125-16-684126:8k_2_02:9]
|  | • |  | FY 2016 Revenue (normalized to exclude the SP Video CPE Business): |

[0001193125-16-684126:8k_2_02:10]
|  | • |  | $48.7 billion, growth of 3% year over year |

[0001193125-16-684126:8k_2_02:11]
|  | • |  | FY 2016 Earnings per Share: $2.11 GAAP; $2.36 non-GAAP |

[0001193125-16-684126:8k_2_02:12]
|  | • |  | Q1 FY 2017 Outlook: |

[0001193125-16-684126:8k_2_02:13]
|  | • |  | Revenue: -1% to 1% growth year over year (normalized to exclude the SP Video CPE Business for Q1 FY 2016) |

[0001193125-16-684126:8k_2_02:14]
|  | • |  | Earnings per Share: GAAP $0.42 - $0.47; Non-GAAP: $0.58 to $0.60 |

[0001193125-16-684126:8k_2_02:15]
SAN JOSE, Calif. —
August 17, 2016 — Cisco today reported fourth quarter and fiscal year results for the period ended July 30, 2016. Cisco reported fourth quarter revenue of $12.6 billion, net income on a generally accepted accounting principles (GAAP)
basis of $2.8 billion or $0.56 per share, and non-GAAP net income of $3.2 billion or $0.63 per share.

[0001193125-16-684126:8k_2_02:16]
“We had another strong quarter, wrapping up a
great year. I am particularly pleased with our performance in priority areas including security, data center switching, collaboration, services as well as our overall performance, with revenues up 2% in Q4 excluding the SP Video CPE business,”
said Chuck Robbins, CEO of Cisco. “We continue to execute well in a challenging macro environment. Despite slowing in our Service Provider business and Emerging Markets after three consecutive quarters of growth, the balance of the business was
healthy with 5% order growth. This growth and balance demonstrates the strength of our diverse portfolio. Our product deferred revenue from software and subscriptions grew 33% showing the continued momentum of our business model
transformation.”

[0001193125-16-684126:8k_2_02:17]
Q4 GAAP Results

[0001193125-16-684126:8k_2_02:18]
|  |  | Q4 FY 2016 |  |  | Q4 FY 2015 |  |  | Vs. Q4 FY 2015 |  |
| Revenue (including SP Video CPE Business for all periods) |  | $ | 12.6 billion |  |  | $ | 12.8 billion |  |  |  | (2 | )% |
| Revenue (excluding SP Video CPE Business for all periods) |  | $ | 12.6 billion |  |  | $ | 12.4 billion |  |  |  | 2 | % |
| Net Income |  | $ | 2.8 billion |  |  | $ | 2.3 billion |  |  |  | 21 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.56 |  |  | $ | 0.45 |  |  |  | 24 | % |

[0001193125-16-684126:8k_2_02:19]
Q4 Non-GAAP Results

[0001193125-16-684126:8k_2_02:20]
|  |  | Q4 FY 2016 |  |  | Q4 FY 2015 |  |  | Vs. Q4 FY 2015 |  |
| Net Income (excluding SP Video CPE Business for all periods) |  | $ | 3.2 billion |  |  | $ | 3.0 billion |  |  |  | 7 | % |
| EPS (excluding SP Video CPE Business for all periods) |  | $ | 0.63 |  |  | $ | 0.58 |  |  |  | 9 | % |

[0001193125-16-684126:8k_2_02:21]
1

[0001193125-16-684126:8k_2_02:22]
Fiscal Year GAAP Results

[0001193125-16-684126:8k_2_02:23]
|  |  | FY 2016 |  |  | FY 2015 |  |  | Vs. FY 2015 |  |
| Revenue (including SP Video CPE Business for all periods) |  | $ | 49.2 billion |  |  | $ | 49.2 billion |  |  |  | — | % |
| Revenue (excluding SP Video CPE Business for all periods) |  | $ | 48.7 billion |  |  | $ | 47.3 billion |  |  |  | 3 | % |
| Net Income |  | $ | 10.7 billion |  |  | $ | 9.0 billion |  |  |  | 20 | % |
| EPS |  | $ | 2.11 |  |  | $ | 1.75 |  |  |  | 21 | % |

[0001193125-16-684126:8k_2_02:24]
Fiscal Year Non-GAAP Results

[0001193125-16-684126:8k_2_02:25]
|  |  | FY 2016 |  |  | FY 2015 |  |  | Vs. FY 2015 |  |
| Net Income (excluding SP Video CPE Business for all periods) |  | $ | 12.0 billion |  |  | $ | 11.2 billion |  |  |  | 7 | % |
| EPS (excluding SP Video CPE Business for all periods) |  | $ | 2.36 |  |  | $ | 2.18 |  |  |  | 8 | % |

[0001193125-16-684126:8k_2_02:26]
Reconciliations between net income, EPS and other measures on a GAAP and non-GAAP basis are provided in the tables located in
the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-16-684126:8k_2_02:27]
“We delivered another solid quarter and a good fiscal year, expanding
both our gross margins and operating margins,” said Kelly Kramer, Cisco executive vice president and chief financial officer. “Our strong operational discipline has enabled us to drive growth and margin improvement as we continue to invest
in key priority areas such as security, IoT, collaboration, next generation data center and cloud, while also delivering shareholder value.”

[0001193125-16-684126:8k_2_02:28]
Restructuring Plan

[0001193125-16-684126:8k_2_02:29]
Today’s market requires Cisco
and our customers to be decisive, move with greater speed and drive more innovation than we’ve seen in our history. Today, we announced a restructuring enabling us to optimize our cost base in lower growth areas of our portfolio and further
invest in key priority areas such as security, IoT, collaboration, next generation data center and cloud. We expect to reinvest substantially all of the cost savings from these actions back into these businesses and will continue to
aggressively invest to focus on our areas of future growth. The restructuring will eliminate up to 5,500 positions, representing approximately 7 percent of our global workforce, and we will take action under this plan beginning in the first quarter
of fiscal 2017.

[0001193125-16-684126:8k_2_02:30]
Financial Summary

[0001193125-16-684126:8k_2_02:31]
All
comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-16-684126:8k_2_02:32]
All revenue, non-GAAP, and geographic financial information in the
“Q4 FY 2016 Highlights” and “FY 2016 Highlights” sections are presented excluding the SP Video CPE Business for prior periods as it was divested during the second quarter of fiscal 2016 on November 20, 2015.

[0001193125-16-684126:8k_2_02:33]
Q4 FY 2016 Highlights

[0001193125-16-684126:8k_2_02:34]
Revenue — Total
revenue was $12.6 billion, up 2%, with product revenue up 1% and service revenue up 5%. Revenue by geographic segment was: Americas up 3%, EMEA up 3%, and APJC down 2%. Product revenue growth was led by Security at 16%. Collaboration,
Wireless and Switching product revenue increased by 6%, 5%, and 2%, respectively. Service Provider Video, NGN Routing and Data Center product revenue decreased by 12%, 6%, and 1%, respectively.

[0001193125-16-684126:8k_2_02:35]
Gross Margin — On a GAAP basis, total gross margin and product gross margin were 63.1% and 62.2%, respectively. The increase in the product
gross margin compared with 59.0% in the fourth quarter of fiscal 2015 was primarily due to continued productivity improvements, the divestiture of the SP Video CPE Business, and to a lesser extent product mix, partially offset by pricing.

[0001193125-16-684126:8k_2_02:36]
Non-GAAP total gross margin and product gross margin were 64.6% and 63.9%, respectively. The increase in non-GAAP product gross margin compared with 63.2% in
the fourth quarter of fiscal 2015 was primarily due to continued productivity improvement and to a lesser extent product mix, partially offset by pricing.

[0001193125-16-684126:8k_2_02:37]
GAAP service margin was 66.0% and non-GAAP service gross margin was 67.0%.

[0001193125-16-684126:8k_2_02:38]
Total gross margins by geographic segment were: 64.9% for the Americas, 65.2% for EMEA and 62.5% for APJC.

[0001193125-16-684126:8k_2_02:39]
Operating Expenses — On a GAAP basis, operating expenses were $4.7 billion, down 4%. Non-GAAP operating expenses were $4.2 billion, up 1%,
and were 33.2% of revenue. Headcount compared with the end of the third quarter of fiscal 2016 increased by 607 to 73,711, driven by additional headcount from investments in key growth areas.

[0001193125-16-684126:8k_2_02:40]
Operating Income — GAAP operating income was $3.3 billion, up 15%, with GAAP operating margin of 26.1%. Non-GAAP operating income was $4.0
billion, up 7%, with non-GAAP operating margin at 31.4%.

[0001193125-16-684126:8k_2_02:41]
2

[0001193125-16-684126:8k_2_02:42]
Provision for Income Taxes — The GAAP tax provision rate was 17.1%, reflecting certain tax
benefits related to prior-year periods. The non-GAAP tax provision rate was 21.4% which excludes these tax benefits related to prior-year periods.

[0001193125-16-684126:8k_2_02:43]
Net Income and EPS — On a GAAP basis, net income was $2.8 billion and EPS was $0.56. On a non-GAAP basis, net income was $3.2 billion, an
increase of 7%, and EPS was $0.63, an increase of 9%.

[0001193125-16-684126:8k_2_02:44]
Cash Flow from Operating Activities — was $3.8 billion for the fourth quarter of
fiscal 2016, compared with $3.1 billion for the third quarter of fiscal 2016, and compared with $4.1 billion for the fourth quarter of fiscal 2015.

[0001193125-16-684126:8k_2_02:45]
FY
2016 Highlights

[0001193125-16-684126:8k_2_02:46]
Revenue — Total revenue was $48.7 billion, an increase of 3%.

[0001193125-16-684126:8k_2_02:47]
Net Income and EPS — On a GAAP basis, net income was $10.7 billion and EPS was $2.11. On a non-GAAP basis, net income was $12.0 billion, an
increase of 7%, and EPS was $2.36, an increase of 8%.

[0001193125-16-684126:8k_2_02:48]
Cash Flow from Operating Activities — was $13.6 billion for fiscal 2016,
compared with $12.6 billion for fiscal 2015.

[0001193125-16-684126:8k_2_02:49]
Balance Sheet and Other Financial Highlights

[0001193125-16-684126:8k_2_02:50]
Cash and Cash Equivalents and Investments — were $65.8 billion at the end of the fourth quarter of fiscal 2016, compared with $63.5 billion
at the end of the third quarter of fiscal 2016, and compared with $60.4 billion at the end of fiscal 2015. The total cash and cash equivalents and investments available in the United States at the end of the fourth quarter of fiscal 2016 were $5.9
billion.

[0001193125-16-684126:8k_2_02:51]
Deferred Revenue — was $16.5 billion, up 8% in total, with deferred product revenue up 8%, driven largely by
subscription-based and software offerings, and deferred service revenue was up 9%. Cisco continued to build a greater mix of recurring revenue as reflected in the increase in deferred revenue.

[0001193125-16-684126:8k_2_02:52]
Product Backlog — was approximately $4.6 billion at the end of fiscal 2016, an increase of 1% compared with the balance at the end of
fiscal 2015 (excluding the SP Video CPE Business).

[0001193125-16-684126:8k_2_02:53]
Days Sales Outstanding in Accounts Receivable (DSO) — was 42 days at the end of the
fourth quarter of fiscal 2016, compared with 38 days at the end of the fourth quarter of fiscal 2015.

[0001193125-16-684126:8k_2_02:54]
Capital Allocation — In the
fourth quarter of fiscal 2016, Cisco declared and paid a cash dividend of $0.26 per common share, or $1.3 billion. For the full fiscal year, Cisco declared and paid cash dividends of $0.94 per common share, or $4.8 billion.

[0001193125-16-684126:8k_2_02:55]
For the fourth quarter of fiscal 2016, Cisco repurchased approximately 28 million shares of common stock under its stock repurchase program at an average
price of $28.70 per share for an aggregate purchase price of $800 million. For the full fiscal year, Cisco repurchased approximately 148 million shares of common stock under its stock repurchase program at an average price of $26.45 per share for an
aggregate purchase price of $3.9 billion. As of July 30, 2016, Cisco had repurchased and retired 4.6 billion shares of Cisco common stock at an average price of $21.04 per share for an aggregate purchase price of approximately $96.6 billion
since the inception of the stock repurchase program. The remaining authorized amount for stock repurchases under this program is approximately $15.4 billion with no termination date.

[0001193125-16-684126:8k_2_02:56]
For the full fiscal year, Cisco returned $8.7 billion to shareholders through share buybacks and dividends, which represented approximately 70% of free cash
flow.

[0001193125-16-684126:8k_2_02:57]
Acquisitions — In Q4 FY 2016, we announced our intent to acquire CloudLock Inc., which closed in early Q1 FY 2017. The CloudLock
acquisition will further enhance Cisco’s security portfolio and build on Cisco’s Security Everywhere strategy, designed to provide protection from the cloud to the network to the endpoint and also aligns with our strategy to deliver more
cloud based subscription services.

[0001193125-16-684126:8k_2_02:58]
3

[0001193125-16-684126:8k_2_02:59]
Business Outlook for Q1 FY 2017

[0001193125-16-684126:8k_2_02:60]
On November 20, 2015, during the second quarter of fiscal 2016, Cisco completed its divestiture of the SP Video CPE Business. In order to provide a clear view
of Cisco’s continuing expected financial performance, the revenue outlook for the first quarter of fiscal 2017 is normalized to exclude the SP Video CPE Business for the first quarter of fiscal 2016. The corresponding revenue in the first
quarter of fiscal 2016 for the SP Video CPE Business was $411 million.

[0001193125-16-684126:8k_2_02:61]
Cisco expects to achieve the following results for the first quarter of fiscal
2017:

[0001193125-16-684126:8k_2_02:62]
| Q1 FY 2017 |  |  |
| Revenue (normalized to exclude SP Video CPE Business for Q1 FY2016) |  | -1% to 1% growth Y/Y |
| Non-GAAP gross margin rate |  | 63% - 64% |
| Non-GAAP operating margin rate |  | 29% - 30% |
| Non-GAAP tax provision rate |  | 22% |
| Non-GAAP EPS |  | $0.58 - $0.60 |

[0001193125-16-684126:8k_2_02:63]
Cisco estimates that GAAP EPS will be $0.42 to $0.47 which is lower than non-GAAP EPS by $0.13 to $0.16 per share in the first
quarter of fiscal 2017.

[0001193125-16-684126:8k_2_02:64]
A reconciliation between the Business Outlook for Q1 FY 2017 on a GAAP and non-GAAP basis is provided in the table entitled
“GAAP to non-GAAP Business Outlook for Q1 FY 2017” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-16-684126:8k_2_02:65]
Editor’s Notes:

[0001193125-16-684126:8k_2_02:66]
|  | • |  | Q4 fiscal year 2016 conference call to discuss Cisco’s results along with its business outlook will be held on Wednesday, August 17, 2016 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-16-684126:8k_2_02:67]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, August 17, 2016 to 4:00 p.m. Pacific Time, August 24, 2016 at 1-866-566-0452 (United States) or 1-203-369-3048 (international). The replay will also be available via webcast on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-16-684126:8k_2_02:68]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, August 17, 2016. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-16-684126:8k_2_02:69]
4

[0001193125-16-684126:8k_2_02:70]
CISCO SYSTEMS, INC.

[0001193125-16-684126:8k_2_02:71]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-16-684126:8k_2_02:72]
(In millions, except per-share amounts)

[0001193125-16-684126:8k_2_02:73]
(Unaudited)

[0001193125-16-684126:8k_2_02:74]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 30,2016 |  |  | July 25,2015 |  |  | July 30,2016 |  |  | July 25,2015 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,552 |  |  | $ | 9,911 |  |  | $ | 37,254 |  |  | $ | 37,750 |  |
| Service |  |  | 3,086 |  |  |  | 2,932 |  |  |  | 11,993 |  |  |  | 11,411 |  |
| Total revenue |  |  | 12,638 |  |  |  | 12,843 |  |  |  | 49,247 |  |  |  | 49,161 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,614 |  |  |  | 4,068 |  |  |  | 14,161 |  |  |  | 15,377 |  |
| Service |  |  | 1,049 |  |  |  | 1,042 |  |  |  | 4,126 |  |  |  | 4,103 |  |
| Total cost of sales |  |  | 4,663 |  |  |  | 5,110 |  |  |  | 18,287 |  |  |  | 19,480 |  |
| GROSS MARGIN |  |  | 7,975 |  |  |  | 7,733 |  |  |  | 30,960 |  |  |  | 29,681 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,601 |  |  |  | 1,548 |  |  |  | 6,296 |  |  |  | 6,207 |  |
| Sales and marketing |  |  | 2,443 |  |  |  | 2,549 |  |  |  | 9,619 |  |  |  | 9,821 |  |
| General and administrative |  |  | 533 |  |  |  | 536 |  |  |  | 1,814 |  |  |  | 2,040 |  |
| Amortization of purchased intangible assets |  |  | 82 |  |  |  | 146 |  |  |  | 303 |  |  |  | 359 |  |
| Restructuring and other charges |  |  | 13 |  |  |  | 73 |  |  |  | 268 |  |  |  | 484 |  |
| Total operating expenses |  |  | 4,672 |  |  |  | 4,852 |  |  |  | 18,300 |  |  |  | 18,911 |  |
| OPERATING INCOME |  |  | 3,303 |  |  |  | 2,881 |  |  |  | 12,660 |  |  |  | 10,770 |  |
| Interest income |  |  | 273 |  |  |  | 211 |  |  |  | 1,005 |  |  |  | 769 |  |
| Interest expense |  |  | (180 | ) |  |  | (149 | ) |  |  | (676 | ) |  |  | (566 | ) |
| Other income (loss), net |  |  | (2 | ) |  |  | (10 | ) |  |  | (69 | ) |  |  | 228 |  |
| Interest and other income (loss), net |  |  | 91 |  |  |  | 52 |  |  |  | 260 |  |  |  | 431 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,394 |  |  |  | 2,933 |  |  |  | 12,920 |  |  |  | 11,201 |  |
| Provision for income taxes |  |  | 581 |  |  |  | 614 |  |  |  | 2,181 |  |  |  | 2,220 |  |
| NET INCOME |  | $ | 2,813 |  |  | $ | 2,319 |  |  | $ | 10,739 |  |  | $ | 8,981 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.56 |  |  | $ | 0.46 |  |  | $ | 2.13 |  |  | $ | 1.76 |  |
| Diluted |  | $ | 0.56 |  |  | $ | 0.45 |  |  | $ | 2.11 |  |  | $ | 1.75 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,031 |  |  |  | 5,086 |  |  |  | 5,053 |  |  |  | 5,104 |  |
| Diluted |  |  | 5,067 |  |  |  | 5,131 |  |  |  | 5,088 |  |  |  | 5,146 |  |
| Cash dividends declared per common share |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.94 |  |  | $ | 0.80 |  |

[0001193125-16-684126:8k_2_02:75]
The Consolidated Statements of Operations include the results of the SP Video CPE Business prior to its divestiture during the
second quarter of fiscal 2016 on November 20, 2015. Accordingly, the fiscal year ended July 30, 2016 includes four months of financial results for this business.

[0001193125-16-684126:8k_2_02:76]
5

[0001193125-16-684126:8k_2_02:77]
CISCO SYSTEMS, INC.

[0001193125-16-684126:8k_2_02:78]
REVENUE BY SEGMENT

[0001193125-16-684126:8k_2_02:79]
(In
millions, except percentages)

[0001193125-16-684126:8k_2_02:80]
|  |  | July 30, 2016 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | Amount |  |  | Y/Y % |  |  | Amount |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Including SP Video CPE Business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,638 |  |  |  | (2)% |  |  | $ | 29,411 |  |  |  | (1)% |  |
| EMEA |  |  | 3,105 |  |  |  | — % |  |  |  | 12,281 |  |  |  | — % |  |
| APJC |  |  | 1,895 |  |  |  | (2)% |  |  |  | 7,555 |  |  |  | 5% |  |
| Total |  | $ | 12,638 |  |  |  | (2)% |  |  | $ | 49,247 |  |  |  | — % |  |
| Excluding SP Video CPE Business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,638 |  |  |  | 3% |  |  | $ | 29,033 |  |  |  | 3% |  |
| EMEA |  |  | 3,105 |  |  |  | 3% |  |  |  | 12,173 |  |  |  | 1% |  |
| APJC |  |  | 1,895 |  |  |  | (2)% |  |  |  | 7,537 |  |  |  | 6% |  |
| Total |  | $ | 12,638 |  |  |  | 2% |  |  | $ | 48,743 |  |  |  | 3% |  |

[0001193125-16-684126:8k_2_02:81]
During the second quarter of fiscal 2016 on November 20, 2015, Cisco completed its divestiture of the SP Video CPE Business.
SP Video CPE Business revenue for the three months ended July 25, 2015 was $487 million and for fiscal 2016 and 2015 was $504 million and $1,846 million, respectively.

[0001193125-16-684126:8k_2_02:82]
CISCO SYSTEMS, INC.

[0001193125-16-684126:8k_2_02:83]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-16-684126:8k_2_02:84]
(In percentages)

[0001193125-16-684126:8k_2_02:85]
|  |  | July 30, 2016 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Including SP Video CPE Business for all periods: |  |  |  |  |  |  |  |  |
| Americas |  |  | 64.9% |  |  |  | 64.6% |  |
| EMEA |  |  | 65.2% |  |  |  | 64.9% |  |
| APJC |  |  | 62.5% |  |  |  | 61.2% |  |
| Excluding SP Video CPE Business for all periods (1): |  |  |  |  |  |  |  |  |
| Americas |  |  | 64.9% |  |  |  | 65.3% |  |
| EMEA |  |  | 65.2% |  |  |  | 65.4% |  |
| APJC |  |  | 62.5% |  |  |  | 61.3% |  |

[0001193125-16-684126:8k_2_02:86]
(1) During the second quarter of fiscal 2016 on November 20, 2015,
Cisco completed its divestiture of the SP Video CPE Business. SP Video CPE Business gross profit for fiscal 2016 was $41 million and $15 million for the Americas and EMEA, respectively.

[0001193125-16-684126:8k_2_02:87]
CISCO SYSTEMS, INC.

[0001193125-16-684126:8k_2_02:88]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-16-684126:8k_2_02:89]
(In millions, except percentages)

[0001193125-16-684126:8k_2_02:90]
|  |  | July 30, 2016 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | Amount |  |  | Y/Y % |  |  | Amount |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,794 |  |  |  | 2% |  |  | $ | 14,746 |  |  |  | — % |  |
| NGN Routing |  |  | 1,876 |  |  |  | (6)% |  |  |  | 7,408 |  |  |  | (4)% |  |
| Collaboration |  |  | 1,149 |  |  |  | 6% |  |  |  | 4,352 |  |  |  | 9% |  |
| Data Center |  |  | 873 |  |  |  | (1)% |  |  |  | 3,365 |  |  |  | 5% |  |
| Wireless |  |  | 752 |  |  |  | 5% |  |  |  | 2,625 |  |  |  | 3% |  |
| Security |  |  | 540 |  |  |  | 16% |  |  |  | 1,969 |  |  |  | 13% |  |
| Service Provider Video(1) |  |  | 444 |  |  |  | (12)% |  |  |  | 1,920 |  |  |  | 12% |  |
| Other |  |  | 124 |  |  |  | 114% |  |  |  | 365 |  |  |  | 53% |  |
| Product - excluding SP Video CPE Business |  |  | 9,552 |  |  |  | 1% |  |  |  | 36,750 |  |  |  | 2% |  |
| Service |  |  | 3,086 |  |  |  | 5% |  |  |  | 11,993 |  |  |  | 5% |  |
| Total - excluding SP Video CPE Business |  |  | 12,638 |  |  |  | 2% |  |  |  | 48,743 |  |  |  | 3% |  |
| SP Video CPE Business (2) |  |  | — |  |  |  |  |  |  |  | 504 |  |  |  |  |  |
| Total |  | $ | 12,638 |  |  |  | (2)% |  |  | $ | 49,247 |  |  |  | — % |  |

[0001193125-16-684126:8k_2_02:91]
(1) Excludes SP Video CPE Business revenue for all periods presented as
it was divested during the second quarter of fiscal 2016 on November 20, 2015. SP Video CPE Business revenue for the three months ended July 25, 2015 was $487 million and for fiscal 2016 and fiscal 2015 was $504 million and $1,846 million,
respectively.

[0001193125-16-684126:8k_2_02:92]
(2) Includes SP Video CPE Business revenue through the date of divestiture of November
20, 2015.

[0001193125-16-684126:8k_2_02:93]
7

[0001193125-16-684126:8k_2_02:94]
CISCO SYSTEMS, INC.

[0001193125-16-684126:8k_2_02:95]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-16-684126:8k_2_02:96]
(In millions)

[0001193125-16-684126:8k_2_02:97]
(Unaudited)

[0001193125-16-684126:8k_2_02:98]
|  |  | July 30,2016 |  |  | July 25,2015 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 7,631 |  |  | $ | 6,877 |  |
| Investments |  |  | 58,125 |  |  |  | 53,539 |  |
| Accounts receivable, net of allowance for doubtful accounts of $249 at July 30, 2016 and $302 at July 25, 2015 |  |  | 5,847 |  |  |  | 5,344 |  |
| Inventories |  |  | 1,217 |  |  |  | 1,627 |  |
| Financing receivables, net |  |  | 4,272 |  |  |  | 4,491 |  |
| Other current assets |  |  | 1,627 |  |  |  | 1,490 |  |
| Total current assets |  |  | 78,719 |  |  |  | 73,368 |  |
| Property and equipment, net |  |  | 3,506 |  |  |  | 3,332 |  |
| Financing receivables, net |  |  | 4,158 |  |  |  | 3,858 |  |
| Goodwill |  |  | 26,625 |  |  |  | 24,469 |  |
| Purchased intangible assets, net |  |  | 2,501 |  |  |  | 2,376 |  |
| Deferred tax assets |  |  | 4,299 |  |  |  | 4,454 |  |
| Other assets |  |  | 1,844 |  |  |  | 1,516 |  |
| TOTAL ASSETS |  | $ | 121,652 |  |  | $ | 113,373 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 4,160 |  |  | $ | 3,897 |  |
| Accounts payable |  |  | 1,056 |  |  |  | 1,104 |  |
| Income taxes payable |  |  | 517 |  |  |  | 62 |  |
| Accrued compensation |  |  | 2,951 |  |  |  | 3,049 |  |
| Deferred revenue |  |  | 10,155 |  |  |  | 9,824 |  |
| Other current liabilities |  |  | 6,072 |  |  |  | 5,476 |  |
| Total current liabilities |  |  | 24,911 |  |  |  | 23,412 |  |
| Long-term debt |  |  | 24,483 |  |  |  | 21,457 |  |
| Income taxes payable |  |  | 925 |  |  |  | 1,876 |  |
| Deferred revenue |  |  | 6,317 |  |  |  | 5,359 |  |
| Other long-term liabilities |  |  | 1,431 |  |  |  | 1,562 |  |
| Total liabilities |  |  | 58,067 |  |  |  | 53,666 |  |
| Total equity |  |  | 63,585 |  |  |  | 59,707 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 121,652 |  |  | $ | 113,373 |  |

[0001193125-16-684126:8k_2_02:99]
Certain reclassifications have been made to prior year amounts to conform to the current year’s
presentation.

[0001193125-16-684126:8k_2_02:100]
8

[0001193125-16-684126:8k_2_02:101]
CISCO SYSTEMS, INC.

[0001193125-16-684126:8k_2_02:102]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-16-684126:8k_2_02:103]
(In millions)

[0001193125-16-684126:8k_2_02:104]
(Unaudited)

[0001193125-16-684126:8k_2_02:105]
|  |  | Fiscal Year Ended |  |
|  |  | July 30,2016 |  |  | July 25,2015 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,739 |  |  | $ | 8,981 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 2,150 |  |  |  | 2,442 |  |
| Share-based compensation expense |  |  | 1,458 |  |  |  | 1,440 |  |
| Provision for receivables |  |  | (9 | ) |  |  | 134 |  |
| Deferred income taxes |  |  | (194 | ) |  |  | (23 | ) |
| Excess tax benefits from share-based compensation |  |  | (129 | ) |  |  | (128 | ) |
| (Gains) losses on investments and other, net |  |  | (317 | ) |  |  | (258 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (404 | ) |  |  | (413 | ) |
| Inventories |  |  | 315 |  |  |  | (116 | ) |
| Financing receivables |  |  | (150 | ) |  |  | (634 | ) |
| Other assets |  |  | (37 | ) |  |  | (370 | ) |
| Accounts payable |  |  | (65 | ) |  |  | 87 |  |
| Income taxes, net |  |  | (300 | ) |  |  | 53 |  |
| Accrued compensation |  |  | (101 | ) |  |  | 7 |  |
| Deferred revenue |  |  | 1,219 |  |  |  | 1,275 |  |
| Other liabilities |  |  | (605 | ) |  |  | 75 |  |
| Net cash provided by operating activities |  |  | 13,570 |  |  |  | 12,552 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (46,760 | ) |  |  | (43,975 | ) |
| Proceeds from sales of investments |  |  | 28,778 |  |  |  | 20,237 |  |
| Proceeds from maturities of investments |  |  | 14,115 |  |  |  | 15,293 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (3,161 | ) |  |  | (326 | ) |
| Proceeds from business divestiture |  |  | 372 |  |  |  | — |  |
| Purchases of investments in privately held companies |  |  | (256 | ) |  |  | (222 | ) |
| Return of investments in privately held companies |  |  | 91 |  |  |  | 288 |  |
| Acquisition of property and equipment |  |  | (1,146 | ) |  |  | (1,227 | ) |
| Proceeds from sales of property and equipment |  |  | 41 |  |  |  | 22 |  |
| Other |  |  | (191 | ) |  |  | (178 | ) |
| Net cash used in investing activities |  |  | (8,117 | ) |  |  | (10,088 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 1,127 |  |  |  | 2,016 |  |
| Repurchases of common stock—repurchase program |  |  | (3,909 | ) |  |  | (4,324 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (557 | ) |  |  | (502 | ) |
| Short-term borrowings, original maturities less than 90 days, net |  |  | (4 | ) |  |  | (4 | ) |
| Issuances of debt |  |  | 6,978 |  |  |  | 4,981 |  |
| Repayments of debt |  |  | (3,863 | ) |  |  | (508 | ) |
| Excess tax benefits from share-based compensation |  |  | 129 |  |  |  | 128 |  |
| Dividends paid |  |  | (4,750 | ) |  |  | (4,086 | ) |
| Other |  |  | 150 |  |  |  | (14 | ) |
| Net cash used in financing activities |  |  | (4,699 | ) |  |  | (2,313 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 754 |  |  |  | 151 |  |
| Cash and cash equivalents, beginning of fiscal year |  |  | 6,877 |  |  |  | 6,726 |  |
| Cash and cash equivalents, end of fiscal year |  | $ | 7,631 |  |  | $ | 6,877 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 859 |  |  | $ | 760 |  |
| Cash paid for income taxes, net |  | $ | 2,675 |  |  | $ | 2,190 |  |

[0001193125-16-684126:8k_2_02:106]
9

[0001193125-16-684126:8k_2_02:107]
CISCO SYSTEMS, INC.

[0001193125-16-684126:8k_2_02:108]
DEFERRED REVENUE

[0001193125-16-684126:8k_2_02:109]
(In
millions)

[0001193125-16-684126:8k_2_02:110]
|  |  | July 30,2016 |  |  | April 30,2016 |  |  | July 25,2015 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 10,621 |  |  | $ | 9,866 |  |  | $ | 9,757 |  |
| Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  |  | 5,474 |  |  |  | 4,987 |  |  |  | 4,766 |  |
| Deferred revenue related to two-tier distributors |  |  | 377 |  |  |  | 419 |  |  |  | 660 |  |
| Total product deferred revenue |  |  | 5,851 |  |  |  | 5,406 |  |  |  | 5,426 |  |
| Total |  | $ | 16,472 |  |  | $ | 15,272 |  |  | $ | 15,183 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 10,155 |  |  | $ | 9,662 |  |  | $ | 9,824 |  |
| Noncurrent |  |  | 6,317 |  |  |  | 5,610 |  |  |  | 5,359 |  |
| Total |  | $ | 16,472 |  |  | $ | 15,272 |  |  | $ | 15,183 |  |

[0001193125-16-684126:8k_2_02:111]
CISCO SYSTEMS, INC.

[0001193125-16-684126:8k_2_02:112]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-16-684126:8k_2_02:113]
(In millions, except per-share amounts)

[0001193125-16-684126:8k_2_02:114]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 30, 2016 |  | $ | 0.26 |  |  | $ | 1,309 |  |  |  | 28 |  |  | $ | 28.70 |  |  | $ | 800 |  |  | $ | 2,109 |  |
| April 30, 2016 |  |  | 0.26 |  |  |  | 1,308 |  |  |  | 27 |  |  |  | 24.08 |  |  |  | 649 |  |  |  | 1,957 |  |
| January 23, 2016 |  |  | 0.21 |  |  |  | 1,065 |  |  |  | 48 |  |  |  | 26.12 |  |  |  | 1,262 |  |  |  | 2,327 |  |
| October 24, 2015 |  |  | 0.21 |  |  |  | 1,068 |  |  |  | 45 |  |  |  | 26.83 |  |  |  | 1,207 |  |  |  | 2,275 |  |
|  |  | $ | 0.94 |  |  | $ | 4,750 |  |  |  | 148 |  |  | $ | 26.45 |  |  | $ | 3,918 |  |  | $ | 8,668 |  |
| Fiscal 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 25, 2015 |  | $ | 0.21 |  |  | $ | 1,069 |  |  |  | 35 |  |  | $ | 28.62 |  |  | $ | 1,005 |  |  | $ | 2,074 |  |
| April 25, 2015 |  |  | 0.21 |  |  |  | 1,070 |  |  |  | 35 |  |  |  | 28.39 |  |  |  | 1,008 |  |  |  | 2,078 |  |
| January 24, 2015 |  |  | 0.19 |  |  |  | 974 |  |  |  | 44 |  |  |  | 27.63 |  |  |  | 1,208 |  |  |  | 2,182 |  |
| October 25, 2014 |  |  | 0.19 |  |  |  | 973 |  |  |  | 41 |  |  |  | 24.58 |  |  |  | 1,013 |  |  |  | 1,986 |  |
| Total |  | $ | 0.80 |  |  | $ | 4,086 |  |  |  | 155 |  |  | $ | 27.22 |  |  | $ | 4,234 |  |  | $ | 8,320 |  |

[0001193125-16-684126:8k_2_02:115]
CISCO SYSTEMS, INC.

[0001193125-16-684126:8k_2_02:116]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-16-684126:8k_2_02:117]
GAAP TO NON-GAAP NET INCOME

[0001193125-16-684126:8k_2_02:118]
(In millions, except per-share amounts)

[0001193125-16-684126:8k_2_02:119]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 30,2016 |  |  | July 25,2015 |  |  | July 30,2016 |  |  | July 25,2015 |  |
| GAAP net income |  | $ | 2,813 |  |  | $ | 2,319 |  |  | $ | 10,739 |  |  | $ | 8,981 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 52 |  |  |  | 58 |  |  |  | 212 |  |  |  | 207 |  |
| Amortization of acquisition-related intangible assets |  |  | 141 |  |  |  | 179 |  |  |  | 507 |  |  |  | 765 |  |
| Supplier component remediation adjustment |  |  | — |  |  |  | — |  |  |  | (74 | ) |  |  | (164 | ) |
| Rockstar patent portfolio charge |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 188 |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | — |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | 5 |  |  |  | (2 | ) |  |  | 5 |  |
| Total adjustments to GAAP cost of sales |  |  | 193 |  |  |  | 242 |  |  |  | 644 |  |  |  | 1,001 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 293 |  |  |  | 338 |  |  |  | 1,220 |  |  |  | 1,235 |  |
| Amortization of acquisition-related intangible assets |  |  | 82 |  |  |  | 146 |  |  |  | 303 |  |  |  | 359 |  |
| Acquisition-related/divestiture costs (1) |  |  | 82 |  |  |  | 79 |  |  |  | 27 |  |  |  | 351 |  |
| Significant asset impairments and restructurings |  |  | 13 |  |  |  | 73 |  |  |  | 268 |  |  |  | 484 |  |
| Total adjustments to GAAP operating expenses |  |  | 470 |  |  |  | 636 |  |  |  | 1,818 |  |  |  | 2,429 |  |
| Adjustments to other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on VCE reorganization |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (126 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 663 |  |  |  | 878 |  |  |  | 2,462 |  |  |  | 3,304 |  |
| Income tax effect of non-GAAP adjustments |  |  | (196 | ) |  |  | (185 | ) |  |  | (623 | ) |  |  | (731 | ) |
| Significant tax matters (2) |  |  | (91 | ) |  |  | — |  |  |  | (556 | ) |  |  | (200 | ) |
| Total adjustments to GAAP provision for income taxes |  |  | (287 | ) |  |  | (185 | ) |  |  | (1,179 | ) |  |  | (931 | ) |
| Non-GAAP net income |  | $ | 3,189 |  |  | $ | 3,012 |  |  | $ | 12,022 |  |  | $ | 11,354 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.56 |  |  | $ | 0.45 |  |  | $ | 2.11 |  |  | $ | 1.75 |  |
| Non-GAAP |  | $ | 0.63 |  |  | $ | 0.59 |  |  | $ | 2.36 |  |  | $ | 2.21 |  |

[0001193125-16-684126:8k_2_02:120]
(1) During the second quarter of fiscal 2016 on November 20, 2015, Cisco
completed its divestiture of the SP Video CPE Business. This sale resulted in a pre-tax gain of $253 million, net of certain transaction costs incurred to date. The gain on this transaction was excluded from non-GAAP net income for fiscal 2016.

[0001193125-16-684126:8k_2_02:121]
(2) Cisco recorded certain net tax benefits totaling $556 million related to prior-year periods that
were excluded from non-GAAP net income for fiscal 2016.

[0001193125-16-684126:8k_2_02:122]
11

[0001193125-16-684126:8k_2_02:123]
CISCO SYSTEMS, INC.

[0001193125-16-684126:8k_2_02:124]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-16-684126:8k_2_02:125]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, AND NET INCOME

[0001193125-16-684126:8k_2_02:126]
(In millions, except percentages)

[0001193125-16-684126:8k_2_02:127]
|  |  | Three Months Ended July 30, 2016 |  |
|  |  |  | ProductGross Margin |  |  |  | ServiceGross Margin |  |  |  | TotalGross Margin |  |  |  | Operating Expenses |  |  |  | Y/Y |  |  |  | Operating Income |  |  |  | Y/Y |  |  |  | Net Income |  |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,938 |  |  | $ | 2,037 |  |  | $ | 7,975 |  |  | $ | 4,672 |  |  |  | (4)% |  |  | $ | 3,303 |  |  |  | 15% |  |  | $ | 2,813 |  |  |  | 21% |  |
| % of revenue |  |  | 62.2% |  |  |  | 66.0% |  |  |  | 63.1% |  |  |  | 37.0% |  |  |  |  |  |  |  | 26.1% |  |  |  |  |  |  |  | 22.3% |  |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 20 |  |  |  | 32 |  |  |  | 52 |  |  |  | 293 |  |  |  |  |  |  |  | 345 |  |  |  |  |  |  |  | 345 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 141 |  |  |  | — |  |  |  | 141 |  |  |  | 82 |  |  |  |  |  |  |  | 223 |  |  |  |  |  |  |  | 223 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 82 |  |  |  |  |  |  |  | 82 |  |  |  |  |  |  |  | 82 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 13 |  |  |  |  |  |  |  | 13 |  |  |  |  |  |  |  | 13 |  |  |  |  |  |
| Income tax/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (287) |  |  |  |  |  |
| Non-GAAP amount |  | $ | 6,099 |  |  | $ | 2,069 |  |  | $ | 8,168 |  |  | $ | 4,202 |  |  |  | 1% |  |  | $ | 3,966 |  |  |  | 7% |  |  | $ | 3,189 |  |  |  | 7% |  |
| % of revenue |  |  | 63.9% |  |  |  | 67.0% |  |  |  | 64.6% |  |  |  | 33.2% |  |  |  |  |  |  |  | 31.4% |  |  |  |  |  |  |  | 25.2% |  |  |  |  |  |

[0001193125-16-684126:8k_2_02:128]
On November 20, 2015, during the second quarter of fiscal 2016, Cisco completed its divestiture of the SP Video CPE Business.
Accordingly, the non-GAAP growth rates above are normalized to exclude the SP Video CPE Business for the fourth quarter of fiscal 2015 as detailed in the table below.

[0001193125-16-684126:8k_2_02:129]
|  |  | Three Months EndedJuly 25, 2015 |  |
|  |  | ProductGross Margin |  |  | ServiceGross Margin |  |  | TotalGross Margin |  |  | Operating Expenses |  |  | Operating Income |  |  | Net Income |  |
| GAAP amount |  | $ | 5,843 |  |  | $ | 1,890 |  |  | $ | 7,733 |  |  | $ | 4,852 |  |  | $ | 2,881 |  |  | $ | 2,319 |  |
| % of revenue |  |  | 59.0% |  |  |  | 64.5% |  |  |  | 60.2% |  |  |  | 37.8% |  |  |  | 22.4% |  |  |  | 18.1% |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 16 |  |  |  | 42 |  |  |  | 58 |  |  |  | 338 |  |  |  | 396 |  |  |  | 396 |  |
| Amortization of acquisition-related intangible assets |  |  | 179 |  |  |  | — |  |  |  | 179 |  |  |  | 146 |  |  |  | 325 |  |  |  | 325 |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 79 |  |  |  | 79 |  |  |  | 79 |  |
| Significant asset impairments and restructurings |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | 73 |  |  |  | 78 |  |  |  | 78 |  |
| Income tax/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (185) |  |
| Non-GAAP amount |  | $ | 6,043 |  |  | $ | 1,932 |  |  | $ | 7,975 |  |  | $ | 4,216 |  |  | $ | 3,759 |  |  | $ | 3,012 |  |
| Less: SP Video CPE Business |  |  | (83) |  |  |  | — |  |  |  | (83) |  |  |  | (37) |  |  |  | (46) |  |  |  | (37) |  |
| Non-GAAP amount (excluding SP Video CPE Business) |  | $ | 5,960 |  |  | $ | 1,932 |  |  | $ | 7,892 |  |  | $ | 4,179 |  |  | $ | 3,713 |  |  | $ | 2,975 |  |
| % of revenue |  |  | 63.2% |  |  |  | 65.9% |  |  |  | 63.9% |  |  |  | 33.8% |  |  |  | 30.1% |  |  |  | 24.1% |  |

[0001193125-16-684126:8k_2_02:130]
For the SP Video CPE Business, EPS was $0.01 for the fourth quarter of fiscal 2015. Net income for the SP Video CPE Business
was $10 million and $142 million for fiscal 2016 and fiscal 2015, respectively, and EPS for fiscal 2016 and 2015 was $0.00 and $0.03, respectively.

[0001193125-16-684126:8k_2_02:131]
CISCO SYSTEMS, INC.

[0001193125-16-684126:8k_2_02:132]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-16-684126:8k_2_02:133]
EFFECTIVE TAX RATE

[0001193125-16-684126:8k_2_02:134]
(In
percentages)

[0001193125-16-684126:8k_2_02:135]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 30,2016 |  |  | July 25,2015 |  |  | July 30,2016 |  |  | July 25,2015 |  |
| GAAP effective tax rate |  |  | 17.1 | % |  |  | 20.9 | % |  |  | 16.9 | % |  |  | 19.8 | % |
| Total adjustments to GAAP provision for income taxes |  |  | 4.3 | % |  |  | 0.1 | % |  |  | 4.9 | % |  |  | 1.9 | % |
| Non-GAAP effective tax rate |  |  | 21.4 | % |  |  | 21.0 | % |  |  | 21.8 | % |  |  | 21.7 | % |

[0001193125-16-684126:8k_2_02:136]
FREE CASH FLOW

[0001193125-16-684126:8k_2_02:137]
(In millions)

[0001193125-16-684126:8k_2_02:138]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 30, 2016 |  |  | July 25, 2015 |  |  | July 30, 2016 |  |  | July 25, 2015 |  |
| Net cash provided by operating activities |  | $ | 3,818 |  |  | $ | 4,138 |  |  | $ | 13,570 |  |  | $ | 12,552 |  |
| Acquisition of property and equipment |  |  | (266 | ) |  |  | (320 | ) |  |  | (1,146 | ) |  |  | (1,227 | ) |
| Free cash flow |  | $ | 3,552 |  |  | $ | 3,818 |  |  | $ | 12,424 |  |  | $ | 11,325 |  |

[0001193125-16-684126:8k_2_02:139]
GAAP TO NON-GAAP BUSINESS OUTLOOK FOR Q1 FY 2017

[0001193125-16-684126:8k_2_02:140]
| Q1 FY 2017 |  | Gross MarginRate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (2) |
| GAAP |  | 61.5% - 62.5% |  | 21% - 22% |  | 21% |  | $0.42 to $0.47 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3% |  | — |  | $0.05 - $0.06 |
| Amortization of purchased intangible assets and other acquisition-related/divestiture costs |  | 1% |  | 2% |  | — |  | $0.03 - $0.04 |
| Restructuring and other charges (1) |  | — |  | 3% |  | — |  | $0.05 - $0.06 |
| Income tax effect of non-GAAP adjustments |  | — |  | — |  | 1% |  |  |
| Non-GAAP |  | 63% - 64% |  | 29% - 30% |  | 22% |  | $0.58 - $0.60 |

[0001193125-16-684126:8k_2_02:141]
(1) In relation to the restructuring plan, Cisco currently estimates that
it will recognize pre-tax charges to its GAAP financial results in an amount of up to $700 million consisting of severance and other one-time termination benefits, and other associated costs. These charges are primarily cash-based. Cisco expects
that approximately $325 million to $400 million of these charges will be recognized during the first quarter of fiscal 2017 with the remaining amount to be recognized during the rest of the fiscal year.

[0001193125-16-684126:8k_2_02:142]
(2) Estimated adjustments to GAAP earnings per share are shown after income tax effects.

[0001193125-16-684126:8k_2_02:143]
Except as noted above, this business outlook does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and
significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-16-684126:8k_2_02:144]
13

[0001193125-16-684126:8k_2_02:145]
Forward Looking Statements, Non-GAAP Information and Additional Information

[0001193125-16-684126:8k_2_02:146]
This release includes
non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax rates, non-GAAP net income per share data, and free cash flow for the periods presented. It also includes future
estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-16-684126:8k_2_02:147]
These non-GAAP measures are not in accordance with,
or an alternative for, measures prepared in accordance with generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of
accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures
should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-16-684126:8k_2_02:148]
Cisco believes that the
presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical
and projected results of operations. Cisco believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a

[0001193125-16-684126:8k_2_02:149]
14

[0001193125-16-684126:8k_2_02:150]
liquidity measure that provides useful information to management and investors because of its intent to return a stated percentage of free cash flow to shareholders in the form of dividends and
stock repurchases. Cisco further regards free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock and pay dividends on its
common stock, after deducting capital investments.

[0001193125-16-684126:8k_2_02:151]
For its internal budgeting process, Cisco’s management uses financial statements that do not
include, when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, impact to cost of sales from purchase accounting adjustments to inventory, acquisition-related/divestiture costs, significant asset
impairments and restructurings, significant litigation and other contingencies, significant gains and losses on investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing
non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to
time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP
financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-16-684126:8k_2_02:152]
Cisco divested the Customer
Premises Equipment portion of the Service Provider Video Connected Devices business (“SP Video CPE Business”) during the second quarter of fiscal 2016 on November 20, 2015. This release includes, where indicated, financial measures
that exclude the SP Video CPE Business. Cisco believes that the presentation of these measures provides useful information to investors and management regarding financial and business trends relating to its financial condition and its
historical and projected results of operations because the SP Video CPE Business is no longer part of Cisco and will not be part of Cisco on a go forward basis. Cisco’s management also uses the financial measures excluding the SP Video CPE
Business in reviewing the financial results of Cisco.

[0001193125-16-684126:8k_2_02:153]
About Cisco

[0001193125-16-684126:8k_2_02:154]
Cisco (NASDAQ: CSCO) is the worldwide technology leader that has been making the Internet work since 1984. Our people, products and partners help society
securely connect and seize tomorrow’s digital opportunity today. Discover more at thenetwork.cisco.com and follow us on Twitter at @Cisco.

[0001193125-16-684126:8k_2_02:155]
Copyright
© 2016 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To
view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco
and any other company. This document is Cisco Public Information.
