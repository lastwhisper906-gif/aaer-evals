# CSCO notes — 0000858877-24-000030


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-24-000030:notes:1]
Organization and Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2025 and fiscal 2024 are each 52-week fiscal years. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-24-000030:notes:2]
We have prepared the accompanying financial data as of October 26, 2024 and for the first quarter of fiscal 2025 and 2024, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2024 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2024.

[0000858877-24-000030:notes:3]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of October 26, 2024, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2025 and 2024, as applicable, have been made. The results of operations for the first quarter of fiscal 2025 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-24-000030:notes:4]
[same as prior period, unchanged from 0000858877-24-000007:notes:4]

[0000858877-24-000030:notes:5]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-24-000030:notes:6]
[same as prior period, unchanged from 0000858877-24-000007:notes:6]

[0000858877-24-000030:notes:7]
[same as prior period, unchanged from 0000858877-24-000007:notes:7]

[0000858877-24-000030:notes:8]
[same as prior period, unchanged from 0000858877-24-000007:notes:8]

[0000858877-24-000030:notes:9]
Disaggregation of Income Statement Expenses     In November 2024, the FASB issued an accounting standard update expanding the disclosure requirements about specific expense categories, primarily through disaggregated information on income statement line items. The accounting standard update will be effective for our fiscal 2028 Form 10-K, and early adoption is permitted. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-24-000030:notes:10]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers. Revenue from subscription offers includes revenue recognized over time as well as upfront.

[0000858877-24-000030:notes:11]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-24-000030:notes:12]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 26, 2024 and July 27, 2024 was $42 million and $37 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-24-000030:notes:13]
Significant Judgments

[0000858877-24-000030:notes:14]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-24-000030:notes:15]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.

[0000858877-24-000030:notes:16]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license’s utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

[0000858877-24-000030:notes:17]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and advanced services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Advanced services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

[0000858877-24-000030:notes:18]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.
Subscription revenue includes revenue recognized from our term software licenses, security software licenses, SaaS, and associated service arrangements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-24-000030:notes:19]
[same as prior period, unchanged from 0000858877-24-000007:notes:16]

[0000858877-24-000030:notes:20]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. The following table presents this disaggregation of revenue (in millions):

[0000858877-24-000030:notes:21]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |
| Product revenue: |  |  |  |
| Networking | $ | 6,753 |  |  | $ | 8,822 |  |
| Security | 2,017 |  |  | 1,010 |  |
| Collaboration | 1,085 |  |  | 1,117 |  |
| Observability | 258 |  |  | 190 |  |
| Total Product | 10,114 |  |  | 11,139 |  |
| Services | 3,727 |  |  | 3,529 |  |
| Total | $ | 13,841 |  |  | $ | 14,668 |  |

[0000858877-24-000030:notes:22]
[same as prior period, unchanged from 0000858877-24-000007:notes:19]

[0000858877-24-000030:notes:23]
Networking consists of our core networking technologies of switching, routing, wireless, and servers. These technologies consist of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-24-000030:notes:24]
Security consists of our Network Security, Identity and Access Management, Secure Access Service Edge (SASE) and Threat Intelligence, Detection, and Response offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-24-000030:notes:25]
Collaboration consists of our Webex Suite, Collaboration Devices, Contact Center and Communication Platform as a Service (CPaaS) offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-24-000030:notes:26]
Observability consists of our network assurance, monitoring and analytics and observability suite offerings. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-24-000030:notes:27]
[same as prior period, unchanged from 0000858877-24-000007:notes:25]

[0000858877-24-000030:notes:28]
Subscription revenue includes revenue recognized from our term software licenses, security software licenses, SaaS, and associated service arrangements. Our subscription revenue is recorded in product and services revenue in our Consolidated Statements of Operations as follows (in millions):

[0000858877-24-000030:notes:29]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Product | $ | 4,419 |  |  | $ | 3,207 |  |
| Services | 3,425 |  |  | 3,254 |  |
| Total | $ | 7,844 |  |  | $ | 6,461 |  |

[0000858877-24-000030:notes:30]
The majority of our product subscription revenue is recognized over time and the remainder is recognized upfront. Substantially all of our services subscription revenue is recognized over time based on the contract term.

[0000858877-24-000030:notes:31]
[same as prior period, unchanged from 0000858877-24-000007:notes:26]

[0000858877-24-000030:notes:32]
[same as prior period, unchanged from 0000858877-24-000007:notes:27]

[0000858877-24-000030:notes:33]
Accounts receivable, net was $4.5 billion as of October 26, 2024 compared to $6.7 billion as of July 27, 2024, as reported on the Consolidated Balance Sheets.

[0000858877-24-000030:notes:34]
[same as prior period, unchanged from 0000858877-24-000007:notes:29]

[0000858877-24-000030:notes:35]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Allowance for credit loss at beginning of period | $ | 87 |  |  | $ | 85 |  |
| Provisions (benefits) | — |  |  | 2 |  |
| Recoveries (write-offs), net | (9) |  |  | (5) |  |
| Allowance for credit loss at end of period | $ | 78 |  |  | $ | 82 |  |

[0000858877-24-000030:notes:36]
[same as prior period, unchanged from 0000858877-24-000007:notes:31]

[0000858877-24-000030:notes:37]
[same as prior period, unchanged from 0000858877-24-000007:notes:32]

[0000858877-24-000030:notes:38]
|  | October 26,2024 |  | July 27,2024 |
| 1 to 4 | $ | 1,244 |  |  | $ | 1,266 |  |
| 5 to 6 | 1,599 |  |  | 1,456 |  |
| 7 and Higher | 71 |  |  | 72 |  |
| Total | $ | 2,914 |  |  | $ | 2,794 |  |

[0000858877-24-000030:notes:39]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $2.9 billion as of October 26, 2024 and $2.7 billion as of July 27, 2024, and were included in other current assets and other assets.

[0000858877-24-000030:notes:40]
Contract liabilities consist of deferred revenue. Deferred revenue was $27.5 billion as of October 26, 2024 compared to $28.5 billion as of July 27, 2024. We recognized approximately $5.3 billion of revenue during the first quarter of fiscal 2025 that was included in the deferred revenue balance at July 27, 2024.

[0000858877-24-000030:notes:41]
(c)Capitalized Contract Acquisition Costs

[0000858877-24-000030:notes:42]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to 
the period of benefit. Capitalized contract acquisition costs were $1.4 billion and $1.3 billion as of October 26, 2024 and July 27, 2024, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $208 million and $158 million for the first quarter of fiscal 2025 and fiscal 2024, respectively, and was included in sales and marketing expenses.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-24-000030:notes:43]
[same as prior period, unchanged from 0000858877-24-000007:notes:37]

[0000858877-24-000030:notes:44]
Our subscription revenue is recorded in product and services revenue in our Consolidated Statements of Operations as follows (in millions):

[0000858877-24-000030:notes:45]
[same as prior period, unchanged from 0000858877-24-000007:notes:38]

[0000858877-24-000030:notes:46]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |
| Revenue: |  |  |  |
| Networking | $ | 6,753 |  |  | $ | 8,822 |  |
| Security | 2,017 |  |  | 1,010 |  |
| Collaboration | 1,085 |  |  | 1,117 |  |
| Observability | 258 |  |  | 190 |  |
| Total Product | 10,114 |  |  | 11,139 |  |
| Services | 3,727 |  |  | 3,529 |  |
| Total | $ | 13,841 |  |  | $ | 14,668 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-24-000030:notes:47]
Acquisitions
A summary of the allocation of the total purchase consideration of our completed acquisitions during the first quarter of fiscal 2025 is presented as follows (in millions):

[0000858877-24-000030:notes:48]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions | $ | 225 |  |  | $ | (14) |  |  | $ | 105 |  |  | $ | 134 |  |

[0000858877-24-000030:notes:49]
The total purchase consideration related to our acquisitions completed during the first quarter of fiscal 2025 consisted primarily of cash consideration. The total cash and cash equivalents acquired from these acquisitions was approximately $13 million. Total transaction costs related to acquisition activities were $9 million and $31 million for the first quarter of fiscal 2025 and 2024, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-24-000030:notes:50]
The purchase price allocation for acquisitions completed during recent periods is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information that existed as of the acquisition date but is currently unknown to us may become known during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date.

[0000858877-24-000030:notes:51]
The goodwill generated from these acquisitions completed during the first quarter of fiscal 2025 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-24-000030:notes:52]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first quarter of fiscal 2025 have not been presented because the effects of the acquisitions were not material to our financial results.

[0000858877-24-000030:notes:53]
Compensation Expense Related to Acquisitions

[0000858877-24-000030:notes:54]
[same as prior period, unchanged from 0000858877-24-000007:notes:71]

[0000858877-24-000030:notes:55]
[same as prior period, unchanged from 0000858877-24-000007:notes:72]

[0000858877-24-000030:notes:56]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Compensation expense related to acquisitions | $ | 297 |  |  | $ | 49 |  |

[0000858877-24-000030:notes:57]
As of October 26, 2024, we estimated that future cash compensation expense of up to $1.3 billion may be required to be recognized pursuant to applicable acquisition agreements.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-24-000030:notes:58]
[same as prior period, unchanged from 0000858877-24-000007:notes:76]

[0000858877-24-000030:notes:59]
The following table presents the goodwill allocated to our reportable segments as of October 26, 2024 and during the first quarter of fiscal 2025 (in millions):

[0000858877-24-000030:notes:60]
|  | Balance at July 27, 2024 |  | Acquisitions, net of Divestitures |  | Foreign Currency Translation and Other |  | Balance at October 26, 2024 |
| Americas | $ | 36,169 |  |  | $ | 86 |  |  | $ | (11) |  |  | $ | 36,244 |  |
| EMEA | 14,283 |  |  | 32 |  |  | (4) |  |  | 14,311 |  |
| APJC | 8,208 |  |  | 14 |  |  | (3) |  |  | 8,219 |  |
| Total | $ | 58,660 |  |  | $ | 132 |  |  | $ | (18) |  |  | $ | 58,774 |  |

[0000858877-24-000030:notes:61]
[same as prior period, unchanged from 0000858877-24-000007:notes:79]

[0000858877-24-000030:notes:62]
The following table presents details of our intangible assets acquired through acquisitions completed during the first quarter of fiscal 2025 (in millions, except years):

[0000858877-24-000030:notes:63]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATED |  | TRADE NAME |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions | 4.0 |  | $ | 93 |  |  | 4.0 |  | $ | 12 |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 105 |  |

[0000858877-24-000030:notes:64]
[same as prior period, unchanged from 0000858877-24-000007:notes:82]

[0000858877-24-000030:notes:65]
| October 26, 2024 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Customer related |  | $ | 6,856 |  |  | $ | (1,081) |  |  | $ | 5,775 |  |
| Technology |  | 6,658 |  |  | (2,206) |  |  | 4,452 |  |
| Trade name |  | 551 |  |  | (60) |  |  | 491 |  |
| Total purchased intangible assets with finite lives |  | 14,065 |  |  | (3,347) |  |  | 10,718 |  |
| In-process research and development, with indefinite lives |  | 26 |  |  | — |  |  | 26 |  |
| Total |  | $ | 14,091 |  |  | $ | (3,347) |  |  | $ | 10,744 |  |

[0000858877-24-000030:notes:66]
| July 27, 2024 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Customer related |  | $ | 6,844 |  |  | $ | (829) |  |  | $ | 6,015 |  |
| Technology |  | 6,680 |  |  | (2,006) |  |  | 4,674 |  |
| Trade name |  | 553 |  |  | (49) |  |  | 504 |  |
| Total purchased intangible assets with finite lives |  | 14,077 |  |  | (2,884) |  |  | 11,193 |  |
| In-process research and development, with indefinite lives |  | 26 |  |  | — |  |  | 26 |  |
| Total |  | $ | 14,103 |  |  | $ | (2,884) |  |  | $ | 11,219 |  |

[0000858877-24-000030:notes:67]
[same as prior period, unchanged from 0000858877-24-000007:notes:85]

[0000858877-24-000030:notes:68]
[same as prior period, unchanged from 0000858877-24-000007:notes:87]

[0000858877-24-000030:notes:69]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Amortization of purchased intangible assets: |  |  |  |
| Cost of sales | $ | 325 |  |  | $ | 186 |  |
| Operating expenses | 265 |  |  | 67 |  |
| Total | $ | 590 |  |  | $ | 253 |  |

[0000858877-24-000030:notes:70]
The estimated future amortization expense of purchased intangible assets with finite lives as of October 26, 2024 is as follows (in millions):

[0000858877-24-000030:notes:71]
| Fiscal Year | Amount |
| 2025 (remaining nine months) | $ | 1,571 |  |
| 2026 | $ | 1,818 |  |
| 2027 | $ | 1,474 |  |
| 2028 | $ | 1,393 |  |
| 2029 | $ | 1,271 |  |
| Thereafter | $ | 3,191 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-24-000030:notes:72]
Restructuring and Other Charges
In the first quarter of fiscal 2025, we announced a restructuring plan (the “Fiscal 2025 Plan”), in order to allow us to invest in key growth opportunities and drive more efficiencies in our business, of which approximately 7% of our global workforce would be impacted with estimated pre-tax charges of up to $1 billion. In connection with the Fiscal 2025 Plan, we incurred charges of $665 million in the first quarter of fiscal 2025. These aggregate pre-tax charges are primarily cash-based and consist of severance and other one-time termination benefits, and other costs. We expect the Fiscal 2025 Plan to be substantially completed by the end of fiscal 2025.

[0000858877-24-000030:notes:73]
In fiscal 2024, we initiated a restructuring plan (the “Fiscal 2024 Plan”), in order to realign the organization and enable further investment in key priority areas. We completed the Fiscal 2024 Plan and incurred cumulative charges of $654 million. These aggregate pretax charges were primarily cash-based and consisted of severance and other one-time termination benefits, real estate-related charges, and other costs.

[0000858877-24-000030:notes:74]
The following table summarizes the activities related to our restructuring liability, which were included in other current liabilities on our Consolidated Balance Sheets (in millions):

[0000858877-24-000030:notes:75]
|  |  | FISCAL 2025 PLAN |  | FISCAL 2024 PLAN |  |  |
|  |  | Employee Severance |  | Other |  | Employee Severance |  | Other |  | Total |
| Liability as of July 27, 2024 |  | $ | — |  |  | $ | — |  |  | $ | 201 |  |  | $ | 9 |  |  | $ | 210 |  |
| Charges |  | 643 |  |  | 22 |  |  | — |  |  | — |  |  | 665 |  |
| Cash payments |  | (116) |  |  | (1) |  |  | (51) |  |  | (2) |  |  | (170) |  |
| Non-cash items |  | (1) |  |  | (20) |  |  | — |  |  | — |  |  | (21) |  |
| Liability as of October 26, 2024 |  | $ | 526 |  |  | $ | 1 |  |  | $ | 150 |  |  | $ | 7 |  |  | $ | 684 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-24-000030:notes:76]
[same as prior period, unchanged from 0000858877-24-000007:notes:95]

[0000858877-24-000030:notes:77]
[same as prior period, unchanged from 0000858877-24-000007:notes:96]

[0000858877-24-000030:notes:78]
|  |  | October 26,2024 |  | July 27,2024 |
| Cash and cash equivalents |  | $ | 9,065 |  |  | $ | 7,508 |  |
| Restricted cash and restricted cash equivalents included in other current assets |  | 763 |  |  | 765 |  |
| Restricted cash and restricted cash equivalents included in other assets |  | 380 |  |  | 569 |  |
| Total |  | $ | 10,208 |  |  | $ | 8,842 |  |

[0000858877-24-000030:notes:79]
[same as prior period, unchanged from 0000858877-24-000007:notes:98]

[0000858877-24-000030:notes:80]
[same as prior period, unchanged from 0000858877-24-000007:notes:99]

[0000858877-24-000030:notes:81]
|  |  | October 26,2024 |  | July 27,2024 |
| Raw materials |  | $ | 1,885 |  |  | $ | 2,039 |  |
| Work in process |  | 100 |  |  | 83 |  |
| Finished goods |  | 945 |  |  | 1,027 |  |
| Service-related spares |  | 207 |  |  | 216 |  |
| Demonstration systems |  | 6 |  |  | 8 |  |
| Total |  | $ | 3,143 |  |  | $ | 3,373 |  |

[0000858877-24-000030:notes:82]
[same as prior period, unchanged from 0000858877-24-000007:notes:101]

[0000858877-24-000030:notes:83]
|  |  | October 26,2024 |  | July 27,2024 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,267 |  |  | $ | 4,247 |  |
| Production, engineering, computer and other equipment and related software |  | 5,135 |  |  | 5,160 |  |
| Operating lease assets |  | 88 |  |  | 115 |  |
| Furniture, fixtures and other |  | 356 |  |  | 351 |  |
| Total gross property and equipment |  | 9,846 |  |  | 9,873 |  |
| Less: accumulated depreciation and amortization |  | (7,764) |  |  | (7,783) |  |
| Total |  | $ | 2,082 |  |  | $ | 2,090 |  |

[0000858877-24-000030:notes:84]
[same as prior period, unchanged from 0000858877-24-000007:notes:103]

[0000858877-24-000030:notes:85]
|  |  | October 26,2024 |  | July 27,2024 |
| Product |  | $ | 19,882 |  |  | $ | 20,055 |  |
| Services |  | 20,108 |  |  | 20,993 |  |
| Total |  | $ | 39,990 |  |  | $ | 41,048 |  |
| Short-term RPO |  | $ | 20,310 |  |  | $ | 20,882 |  |
| Long-term RPO |  | 19,680 |  |  | 20,166 |  |
| Total |  | $ | 39,990 |  |  | $ | 41,048 |  |
| Amount to be recognized as revenue over the next 12 months |  | 51 | % |  | 51 | % |
| Deferred revenue |  | $ | 27,502 |  |  | $ | 28,475 |  |
| Unbilled contract revenue |  | 12,488 |  |  | 12,573 |  |
| Total |  | $ | 39,990 |  |  | $ | 41,048 |  |

[0000858877-24-000030:notes:86]
[same as prior period, unchanged from 0000858877-24-000007:notes:105]

[0000858877-24-000030:notes:87]
[same as prior period, unchanged from 0000858877-24-000007:notes:106]

[0000858877-24-000030:notes:88]
|  |  | October 26,2024 |  | July 27,2024 |
| Product |  | $ | 12,941 |  |  | $ | 13,219 |  |
| Services |  | 14,561 |  |  | 15,256 |  |
| Total |  | $ | 27,502 |  |  | $ | 28,475 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 15,615 |  |  | $ | 16,249 |  |
| Noncurrent |  | 11,887 |  |  | 12,226 |  |
| Total |  | $ | 27,502 |  |  | $ | 28,475 |  |

[0000858877-24-000030:notes:89]
[same as prior period, unchanged from 0000858877-24-000007:notes:108]

[0000858877-24-000030:notes:90]
[same as prior period, unchanged from 0000858877-24-000007:notes:109]

[0000858877-24-000030:notes:91]
|  |  | October 26,2024 |  | July 27,2024 |
| Current |  | $ | 1,819 |  |  | $ | 1,819 |  |
| Noncurrent |  | 1,595 |  |  | 2,273 |  |
| Total |  | $ | 3,414 |  |  | $ | 4,092 |  |

[0000858877-24-000030:notes:92]
Our noncurrent transition tax payable has been reduced to reflect the transition tax benefit of the U.S. Tax Court opinion in Varian Medical Systems, Inc. v. Commissioner. See Note 18.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000858877-24-000030:notes:93]
Leases 
(a)Lessee Arrangements

[0000858877-24-000030:notes:94]
The following table presents our operating lease balances (in millions):

[0000858877-24-000030:notes:95]
|  | Balance Sheet Line Item |  | October 26, 2024 |  | July 27, 2024 |
| Operating lease right-of-use assets | Other assets |  | $ | 1,092 |  |  | 1,066 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 357 |  |  | $ | 364 |  |
| Operating lease liabilities | Other long-term liabilities |  | 938 |  |  | 906 |  |
| Total operating lease liabilities |  |  | $ | 1,295 |  |  | $ | 1,270 |  |

[0000858877-24-000030:notes:96]
The components of our lease expenses were as follows (in millions):

[0000858877-24-000030:notes:97]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Operating lease expense | $ | 114 |  |  | $ | 100 |  |
| Short-term lease expense | 18 |  |  | 11 |  |
| Variable lease expense | 46 |  |  | 56 |  |
| Total lease expense | $ | 178 |  |  | $ | 167 |  |

[0000858877-24-000030:notes:98]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-24-000030:notes:99]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 114 |  |  | $ | 88 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 127 |  |  | $ | 126 |  |

[0000858877-24-000030:notes:100]
The weighted-average lease term was 4.9 years as of each of October 26, 2024 and July 27, 2024. The weighted-average discount rate was 4.0% as of each of October 26, 2024 and July 27, 2024.

[0000858877-24-000030:notes:101]
The maturities of our operating leases (undiscounted) as of October 26, 2024 are as follows (in millions):

[0000858877-24-000030:notes:102]
| Fiscal Year | Amount |
| 2025 (remaining nine months) | $ | 319 |  |
| 2026 | 323 |  |
| 2027 | 235 |  |
| 2028 | 161 |  |
| 2029 | 128 |  |
| Thereafter | 285 |  |
| Total lease payments | 1,451 |  |
| Less: interest | (156) |  |
| Total | $ | 1,295 |  |

[0000858877-24-000030:notes:103]
(b)Lessor Arrangements

[0000858877-24-000030:notes:104]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income was $17 million and $14 million for the first quarter of fiscal 2025 and 2024, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-24-000030:notes:105]
Future minimum lease payments on our lease receivables as of October 26, 2024 are summarized as follows (in millions):

[0000858877-24-000030:notes:106]
| Fiscal Year | Amount |
| 2025 (remaining nine months) | $ | 285 |  |
| 2026 | 409 |  |
| 2027 | 128 |  |
| 2028 | 78 |  |
| 2029 | 73 |  |
| Thereafter | 83 |  |
| Total | 1,056 |  |
| Less: Present value of lease payments | (949) |  |
| Unearned income | $ | 107 |  |

[0000858877-24-000030:notes:107]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-24-000030:notes:108]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-24-000030:notes:109]
|  | October 26, 2024 |  | July 27, 2024 |
| Operating lease assets | $ | 88 |  |  | $ | 115 |  |
| Accumulated depreciation | (48) |  |  | (61) |  |
| Operating lease assets, net | $ | 40 |  |  | $ | 54 |  |

[0000858877-24-000030:notes:110]
Our operating lease income was $11 million and $16 million for the first quarter of fiscal 2025 and 2024, respectively, and was included in product revenue in the Consolidated Statements of Operations.

[0000858877-24-000030:notes:111]
Minimum future rentals on noncancelable operating leases as of October 26, 2024 are summarized as follows (in millions):

[0000858877-24-000030:notes:112]
| Fiscal Year | Amount |
| 2025 (remaining nine months) | $ | 13 |  |
| 2026 | 12 |  |
| 2027 | 3 |  |
| Total | $ | 28 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-24-000030:notes:113]
[same as prior period, unchanged from 0000858877-24-000007:notes:131]

[0000858877-24-000030:notes:114]
[same as prior period, unchanged from 0000858877-24-000007:notes:132]

[0000858877-24-000030:notes:115]
[same as prior period, unchanged from 0000858877-24-000007:notes:133]

[0000858877-24-000030:notes:116]
| October 26, 2024 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,583 |  |  | $ | 1,056 |  |  | $ | 6,639 |  |
| Residual value | — |  |  | 66 |  |  | 66 |  |
| Unearned income | — |  |  | (107) |  |  | (107) |  |
| Allowance for credit loss | (49) |  |  | (15) |  |  | (64) |  |
| Total, net | $ | 5,534 |  |  | $ | 1,000 |  |  | $ | 6,534 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 2,785 |  |  | $ | 338 |  |  | $ | 3,123 |  |
| Noncurrent | 2,749 |  |  | 662 |  |  | 3,411 |  |
| Total, net | $ | 5,534 |  |  | $ | 1,000 |  |  | $ | 6,534 |  |

[0000858877-24-000030:notes:117]
| July 27, 2024 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,858 |  |  | $ | 965 |  |  | $ | 6,823 |  |
| Residual value | — |  |  | 67 |  |  | 67 |  |
| Unearned income | — |  |  | (111) |  |  | (111) |  |
| Allowance for credit loss | (50) |  |  | (15) |  |  | (65) |  |
| Total, net | $ | 5,808 |  |  | $ | 906 |  |  | $ | 6,714 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 3,071 |  |  | $ | 267 |  |  | $ | 3,338 |  |
| Noncurrent | 2,737 |  |  | 639 |  |  | 3,376 |  |
| Total, net | $ | 5,808 |  |  | $ | 906 |  |  | $ | 6,714 |  |

[0000858877-24-000030:notes:118]
[same as prior period, unchanged from 0000858877-24-000007:notes:136]

[0000858877-24-000030:notes:119]
[same as prior period, unchanged from 0000858877-24-000007:notes:137]

[0000858877-24-000030:notes:120]
| October 26, 2024 |  |  | Fiscal Year |  | Three Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 31, 2021 |  | July 30, 2022 |  | July 29, 2023 |  | July 27, 2024 |  | October 26, 2024 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 53 |  |  | $ | 256 |  |  | $ | 449 |  |  | $ | 736 |  |  | $ | 1,613 |  |  | $ | 504 |  |  | $ | 3,611 |  |
| 5 to 6 | 20 |  |  | 65 |  |  | 107 |  |  | 360 |  |  | 939 |  |  | 404 |  |  | 1,895 |  |
| 7 and Higher | 4 |  |  | 5 |  |  | 58 |  |  | 8 |  |  | 2 |  |  | — |  |  | 77 |  |
| Total Loan Receivables | $ | 77 |  |  | $ | 326 |  |  | $ | 614 |  |  | $ | 1,104 |  |  | $ | 2,554 |  |  | $ | 908 |  |  | $ | 5,583 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 7 |  |  | $ | 34 |  |  | $ | 50 |  |  | $ | 195 |  |  | $ | 276 |  |  | $ | 63 |  |  | $ | 625 |  |
| 5 to 6 | 6 |  |  | 16 |  |  | 36 |  |  | 99 |  |  | 126 |  |  | 28 |  |  | 311 |  |
| 7 and Higher | — |  |  | 1 |  |  | 2 |  |  | 4 |  |  | 6 |  |  | — |  |  | 13 |  |
| Total Lease Receivables | $ | 13 |  |  | $ | 51 |  |  | $ | 88 |  |  | $ | 298 |  |  | $ | 408 |  |  | $ | 91 |  |  | $ | 949 |  |
| Total | $ | 90 |  |  | $ | 377 |  |  | $ | 702 |  |  | $ | 1,402 |  |  | $ | 2,962 |  |  | $ | 999 |  |  | $ | 6,532 |  |

[0000858877-24-000030:notes:121]
| July 27, 2024 |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 25, 2020 |  | July 31, 2021 |  | July 30, 2022 |  | July 29, 2023 |  | July 27, 2024 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 78 |  |  | $ | 341 |  |  | $ | 555 |  |  | $ | 945 |  |  | $ | 1,803 |  |  | $ | 3,724 |  |
| 5 to 6 | 2 |  |  | 29 |  |  | 127 |  |  | 130 |  |  | 426 |  |  | 1,314 |  |  | 2,028 |  |
| 7 and Higher | 3 |  |  | 1 |  |  | 10 |  |  | 74 |  |  | 14 |  |  | 4 |  |  | 106 |  |
| Total Loan Receivables | $ | 7 |  |  | $ | 108 |  |  | $ | 478 |  |  | $ | 759 |  |  | $ | 1,385 |  |  | $ | 3,121 |  |  | $ | 5,858 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 1 |  |  | $ | 8 |  |  | $ | 38 |  |  | $ | 46 |  |  | $ | 176 |  |  | $ | 341 |  |  | $ | 610 |  |
| 5 to 6 | 1 |  |  | 11 |  |  | 22 |  |  | 44 |  |  | 129 |  |  | 21 |  |  | 228 |  |
| 7 and Higher | — |  |  | — |  |  | 1 |  |  | 3 |  |  | 4 |  |  | 8 |  |  | 16 |  |
| Total Lease Receivables | $ | 2 |  |  | $ | 19 |  |  | $ | 61 |  |  | $ | 93 |  |  | $ | 309 |  |  | $ | 370 |  |  | $ | 854 |  |
| Total | $ | 9 |  |  | $ | 127 |  |  | $ | 539 |  |  | $ | 852 |  |  | $ | 1,694 |  |  | $ | 3,491 |  |  | $ | 6,712 |  |

[0000858877-24-000030:notes:122]
The following tables present the aging analysis of gross receivables as of October 26, 2024 and July 27, 2024 (in millions):

[0000858877-24-000030:notes:123]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| October 26, 2024 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 21 |  |  | $ | 30 |  |  | $ | 32 |  |  | $ | 83 |  |  | $ | 5,500 |  |  | $ | 5,583 |  |  | $ | 7 |  |  | $ | 7 |  |  | $ | 7 |  |
| Lease receivables | 21 |  |  | 5 |  |  | 5 |  |  | 31 |  |  | 918 |  |  | 949 |  |  | 4 |  |  | — |  |  | — |  |
| Total | $ | 42 |  |  | $ | 35 |  |  | $ | 37 |  |  | $ | 114 |  |  | $ | 6,418 |  |  | $ | 6,532 |  |  | $ | 11 |  |  | $ | 7 |  |  | $ | 7 |  |

[0000858877-24-000030:notes:124]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| July 27, 2024 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 34 |  |  | $ | 17 |  |  | $ | 35 |  |  | $ | 86 |  |  | $ | 5,772 |  |  | $ | 5,858 |  |  | $ | 14 |  |  | $ | 7 |  |  | $ | 7 |  |
| Lease receivables | 14 |  |  | 4 |  |  | 5 |  |  | 23 |  |  | 831 |  |  | 854 |  |  | 1 |  |  | — |  |  | — |  |
| Total | $ | 48 |  |  | $ | 21 |  |  | $ | 40 |  |  | $ | 109 |  |  | $ | 6,603 |  |  | $ | 6,712 |  |  | $ | 15 |  |  | $ | 7 |  |  | $ | 7 |  |

[0000858877-24-000030:notes:125]
[same as prior period, unchanged from 0000858877-24-000007:notes:143]

[0000858877-24-000030:notes:126]
[same as prior period, unchanged from 0000858877-24-000007:notes:144]

[0000858877-24-000030:notes:127]
[same as prior period, unchanged from 0000858877-24-000007:notes:145]

[0000858877-24-000030:notes:128]
| Three Months Ended October 26, 2024 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 27, 2024 | $ | 50 |  |  | $ | 15 |  |  | $ | 65 |  |
| Provisions (benefits) | (1) |  |  | — |  |  | (1) |  |
| Allowance for credit loss as of October 26, 2024 | $ | 49 |  |  | $ | 15 |  |  | $ | 64 |  |

[0000858877-24-000030:notes:129]
| Three Months Ended October 28, 2023 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 29, 2023 | $ | 53 |  |  | $ | 19 |  |  | $ | 72 |  |
| Provisions (benefits) | 5 |  |  | (3) |  |  | 2 |  |
| Allowance for credit loss as of October 28, 2023 | $ | 58 |  |  | $ | 16 |  |  | $ | 74 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-24-000030:notes:130]
Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-24-000030:notes:131]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-24-000030:notes:132]
| October 26, 2024 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,390 |  |  | $ | 2 |  |  | $ | (24) |  |  | $ | 2,368 |  |
| U.S. government agency securities | 154 |  |  | — |  |  | (1) |  |  | 153 |  |
| Non-U.S. government and agency securities | 388 |  |  | 1 |  |  | — |  |  | 389 |  |
| Corporate debt securities | 3,610 |  |  | 9 |  |  | (107) |  |  | 3,512 |  |
| U.S. agency mortgage-backed securities | 1,038 |  |  | — |  |  | (133) |  |  | 905 |  |
| Commercial paper | 1,193 |  |  | — |  |  | — |  |  | 1,193 |  |
| Certificates of deposit | 674 |  |  | — |  |  | — |  |  | 674 |  |
| Total | $ | 9,447 |  |  | $ | 12 |  |  | $ | (265) |  |  | $ | 9,194 |  |

[0000858877-24-000030:notes:133]
| July 27, 2024 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,380 |  |  | $ | 1 |  |  | $ | (28) |  |  | $ | 2,353 |  |
| U.S. government agency securities | 223 |  |  | — |  |  | (2) |  |  | 221 |  |
| Non-U.S. government and agency securities | 370 |  |  | 1 |  |  | — |  |  | 371 |  |
| Corporate debt securities | 3,818 |  |  | 5 |  |  | (146) |  |  | 3,677 |  |
| U.S. agency mortgage-backed securities | 1,959 |  |  | — |  |  | (178) |  |  | 1,781 |  |
| Commercial paper | 1,023 |  |  | — |  |  | — |  |  | 1,023 |  |
| Certificates of deposit | 439 |  |  | — |  |  | — |  |  | 439 |  |
| Total | $ | 10,212 |  |  | $ | 7 |  |  | $ | (354) |  |  | $ | 9,865 |  |

[0000858877-24-000030:notes:134]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-24-000030:notes:135]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Gross realized gains | $ | 8 |  |  | $ | — |  |
| Gross realized losses | (33) |  |  | (20) |  |
| Total | $ | (25) |  |  | $ | (20) |  |

[0000858877-24-000030:notes:136]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 26, 2024 and July 27, 2024 (in millions):

[0000858877-24-000030:notes:137]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 26, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,134 |  |  | $ | (11) |  |  | $ | 634 |  |  | $ | (13) |  |  | $ | 1,768 |  |  | $ | (24) |  |
| U.S. government agency securities | 37 |  |  | — |  |  | 60 |  |  | (1) |  |  | 97 |  |  | (1) |  |
| Non-U.S. government and agency securities | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |
| Corporate debt securities | 221 |  |  | (1) |  |  | 2,402 |  |  | (76) |  |  | 2,623 |  |  | (77) |  |
| U.S. agency mortgage-backed securities | 7 |  |  | — |  |  | 896 |  |  | (133) |  |  | 903 |  |  | (133) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 1,435 |  |  | $ | (12) |  |  | $ | 3,992 |  |  | $ | (223) |  |  | $ | 5,427 |  |  | $ | (235) |  |

[0000858877-24-000030:notes:138]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 598 |  |  | $ | (2) |  |  | $ | 1,399 |  |  | $ | (26) |  |  | $ | 1,997 |  |  | $ | (28) |  |
| U.S. government agency securities | 89 |  |  | — |  |  | 109 |  |  | (2) |  |  | 198 |  |  | (2) |  |
| Non-U.S. government and agency securities | 17 |  |  | — |  |  | — |  |  | — |  |  | 17 |  |  | — |  |
| Corporate debt securities | 276 |  |  | (1) |  |  | 2,818 |  |  | (115) |  |  | 3,094 |  |  | (116) |  |
| U.S. agency mortgage-backed securities | 238 |  |  | (1) |  |  | 1,438 |  |  | (177) |  |  | 1,676 |  |  | (178) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 1,228 |  |  | $ | (4) |  |  | $ | 5,764 |  |  | $ | (320) |  |  | $ | 6,992 |  |  | $ | (324) |  |

[0000858877-24-000030:notes:139]
The following table summarizes the maturities of our available-for-sale debt investments as of October 26, 2024 (in millions):

[0000858877-24-000030:notes:140]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 4,045 |  |  | $ | 4,012 |  |
| After 1 year through 5 years | 4,364 |  |  | 4,277 |  |
| Mortgage-backed securities with no single maturity | 1,038 |  |  | 905 |  |
| Total | $ | 9,447 |  |  | $ | 9,194 |  |

[0000858877-24-000030:notes:141]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-24-000030:notes:142]
(b)Summary of Equity Investments

[0000858877-24-000030:notes:143]
We held marketable equity securities of $412 million and $481 million as of October 26, 2024 and July 27, 2024, respectively. We recognized a net unrealized gain of $25 million and a net unrealized loss of $42 million during the first quarter of fiscal 2025 and 2024, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $8 million for the first quarter of fiscal 2025. These adjustments were not material for the first quarter of 2024. We held equity interests in certain private equity funds of $0.8 billion as of each of October 26, 2024 and July 27, 2024, which are accounted for under the NAV practical expedient.

[0000858877-24-000030:notes:144]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 26, 2024, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-24-000030:notes:145]
The carrying value of our investments in privately held companies was $1.8 billion as of each of October 26, 2024 and July 27, 2024. Of the total carrying value of our investments in privately held companies as of October 26, 2024, $0.8 billion of such investments are considered to be in variable interest entities which are not required to be consolidated. As of October 26, 2024, we have total funding commitments of $0.3 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-24-000030:notes:146]
[same as prior period, unchanged from 0000858877-24-000007:notes:166]

[0000858877-24-000030:notes:147]
[same as prior period, unchanged from 0000858877-24-000007:notes:167]

[0000858877-24-000030:notes:148]
|  | OCTOBER 26, 2024 |  | JULY 27, 2024 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 5,871 |  |  | $ | — |  |  | $ | 5,871 |  |  | $ | 3,334 |  |  | $ | — |  |  | $ | 3,334 |  |
| Commercial paper | — |  |  | 112 |  |  | 112 |  |  | — |  |  | 468 |  |  | 468 |  |
| Corporate debt securities | — |  |  | 18 |  |  | 18 |  |  | — |  |  | 25 |  |  | 25 |  |
| Certificates of deposit | — |  |  | — |  |  | — |  |  | — |  |  | 14 |  |  | 14 |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 2,368 |  |  | 2,368 |  |  | — |  |  | 2,353 |  |  | 2,353 |  |
| U.S. government agency securities | — |  |  | 153 |  |  | 153 |  |  | — |  |  | 221 |  |  | 221 |  |
| Non-U.S. government and agency securities | — |  |  | 389 |  |  | 389 |  |  | — |  |  | 371 |  |  | 371 |  |
| Corporate debt securities | — |  |  | 3,512 |  |  | 3,512 |  |  | — |  |  | 3,677 |  |  | 3,677 |  |
| U.S. agency mortgage-backed securities | — |  |  | 905 |  |  | 905 |  |  | — |  |  | 1,781 |  |  | 1,781 |  |
| Commercial paper | — |  |  | 1,193 |  |  | 1,193 |  |  | — |  |  | 1,023 |  |  | 1,023 |  |
| Certificates of deposit | — |  |  | 674 |  |  | 674 |  |  | — |  |  | 439 |  |  | 439 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 412 |  |  | — |  |  | 412 |  |  | 481 |  |  | — |  |  | 481 |  |
| Other current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 750 |  |  | — |  |  | 750 |  |  | 750 |  |  | — |  |  | 750 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 375 |  |  | — |  |  | 375 |  |  | 563 |  |  | — |  |  | 563 |  |
| Derivative assets | — |  |  | 61 |  |  | 61 |  |  | — |  |  | 64 |  |  | 64 |  |
| Total | $ | 7,408 |  |  | $ | 9,385 |  |  | $ | 16,793 |  |  | $ | 5,128 |  |  | $ | 10,436 |  |  | $ | 15,564 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 72 |  |  | $ | 72 |  |  | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |
| Total | $ | — |  |  | $ | 72 |  |  | $ | 72 |  |  | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |

[0000858877-24-000030:notes:149]
[same as prior period, unchanged from 0000858877-24-000007:notes:169]

[0000858877-24-000030:notes:150]
[same as prior period, unchanged from 0000858877-24-000007:notes:170]

[0000858877-24-000030:notes:151]
[same as prior period, unchanged from 0000858877-24-000007:notes:171]

[0000858877-24-000030:notes:152]
[same as prior period, unchanged from 0000858877-24-000007:notes:173]

[0000858877-24-000030:notes:153]
The fair value of our short-term loan receivables approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables as of each of October 26, 2024 and July 27, 2024 was $2.7 billion. The estimated fair value of our long-term loan receivables approximates their carrying value. We use unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables, and therefore they are categorized as Level 3.
As of October 26, 2024, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of October 26, 2024, the fair value of our senior notes was $20.6 billion with a carrying amount of $20.1 billion. This compares to a fair value of $20.4 billion and a carrying amount of $20.1 billion as of July 27, 2024. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2.


## us-gaap:DebtDisclosureTextBlock

[0000858877-24-000030:notes:154]
Borrowings 
(a)Short-Term Debt

[0000858877-24-000030:notes:155]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-24-000030:notes:156]
|  | October 26, 2024 |  | July 27, 2024 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 493 |  |  | 6.17 | % |  | $ | 488 |  |  | 6.66 | % |
| Commercial paper | 11,870 |  |  | 5.19 | % |  | 10,853 |  |  | 5.43 | % |
| Current portion of other debt | 1 |  |  | 1.13 | % |  | — |  |  | — |  |
| Total | $ | 12,364 |  |  |  |  | $ | 11,341 |  |  |  |

[0000858877-24-000030:notes:157]
We have a short-term debt financing program of up to $15.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-24-000030:notes:158]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-24-000030:notes:159]
(b)Long-Term Debt

[0000858877-24-000030:notes:160]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-24-000030:notes:161]
|  |  |  | October 26, 2024 |  | July 27, 2024 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | 6.17% |  | $ | 500 |  |  | 6.66% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 3 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 20,253 |  |  |  |  | 20,253 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (129) |  |  |  |  | (133) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (7) |  |  |  |  | (11) |  |  |  |
| Total |  |  | $ | 20,117 |  |  |  |  | $ | 20,109 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 494 |  |  |  |  | $ | 488 |  |  |  |
| Long-term debt |  |  | 19,623 |  |  |  |  | 19,621 |  |  |  |
| Total |  |  | $ | 20,117 |  |  |  |  | $ | 20,109 |  |  |  |

[0000858877-24-000030:notes:162]
We entered into an interest rate swap in a prior period with an aggregate notional amount of $0.5 billion designated as a fair value hedge of certain of our fixed-rate senior notes. This swap converts the fixed interest rate of the fixed-rate note to a floating interest rate based on Secured Overnight Financing Rate (SOFR). The gain and loss related to the change in the fair value of the interest rate swap substantially offsets the change in the fair value of the hedged portion of the underlying debt that is attributable to the change in market interest rates. For additional information, see Note 13.

[0000858877-24-000030:notes:163]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 26, 2024, we were in compliance with all debt covenants.

[0000858877-24-000030:notes:164]
As of October 26, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-24-000030:notes:165]
| Fiscal Year | Amount |
| 2025 (remaining nine months) | $ | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | — |  |
| 2029 | 2,500 |  |
| Thereafter | 12,000 |  |
| Total | $ | 20,253 |  |

[0000858877-24-000030:notes:166]
(c)Credit Facility

[0000858877-24-000030:notes:167]
On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of October 26, 2024, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-24-000030:notes:168]
[same as prior period, unchanged from 0000858877-24-000007:notes:190]

[0000858877-24-000030:notes:169]
[same as prior period, unchanged from 0000858877-24-000007:notes:191]

[0000858877-24-000030:notes:170]
[same as prior period, unchanged from 0000858877-24-000007:notes:192]

[0000858877-24-000030:notes:171]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | October 26,2024 |  | July 27,2024 |  | Balance Sheet Line Item |  | October 26,2024 |  | July 27,2024 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 45 |  |  | $ | 47 |  |  | Other current liabilities |  | $ | — |  |  | $ | 1 |  |
| Foreign currency derivatives | Other assets |  | 14 |  |  | 15 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other current assets |  | 2 |  |  | — |  |  | Other current liabilities |  | 8 |  |  | 11 |  |
| Total |  |  | 61 |  |  | 62 |  |  |  |  | 8 |  |  | 12 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | — |  |  | 2 |  |  | Other current liabilities |  | 50 |  |  | 47 |  |
| Foreign currency derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 14 |  |  | 15 |  |
| Total |  |  | — |  |  | 2 |  |  |  |  | 64 |  |  | 62 |  |
| Total |  |  | $ | 61 |  |  | $ | 64 |  |  |  |  | $ | 72 |  |  | $ | 74 |  |

[0000858877-24-000030:notes:172]
[same as prior period, unchanged from 0000858877-24-000007:notes:194]

[0000858877-24-000030:notes:173]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | October 26,2024 |  | July 27,2024 |  | October 26,2024 |  | July 27,2024 |
| Short-term debt |  | $ | (493) |  |  | $ | (488) |  |  | $ | 7 |  |  | $ | 11 |  |

[0000858877-24-000030:notes:174]
[same as prior period, unchanged from 0000858877-24-000007:notes:196]

[0000858877-24-000030:notes:175]
|  |  | Three Months Ended |
|  |  | October 26, 2024 |  | October 28, 2023 |
| Interest rate derivatives: |  |  |  |  |
| Hedged items |  | $ | (4) |  |  | $ | (9) |  |
| Derivatives designated as hedging instruments |  | 4 |  |  | 9 |  |
| Total |  | $ | — |  |  | $ | — |  |

[0000858877-24-000030:notes:176]
[same as prior period, unchanged from 0000858877-24-000007:notes:198]

[0000858877-24-000030:notes:177]
|  |  |  |  | GAINS (LOSSES) FOR THE THREE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | October 26,2024 |  | October 28,2023 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (32) |  |  | $ | (130) |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | 22 |  |  | (77) |  |
| Equity derivatives |  | Other income (loss), net |  | — |  |  | 2 |  |
| Total |  |  |  | $ | (10) |  |  | $ | (205) |  |

[0000858877-24-000030:notes:178]
[same as prior period, unchanged from 0000858877-24-000007:notes:200]

[0000858877-24-000030:notes:179]
|  | October 26,2024 |  | July 27,2024 |
| Foreign currency derivatives | $ | 7,535 |  |  | $ | 7,434 |  |
| Interest rate derivatives | 950 |  |  | 500 |  |
| Total return swaps—deferred compensation | 1,032 |  |  | 985 |  |
| Total | $ | 9,517 |  |  | $ | 8,919 |  |

[0000858877-24-000030:notes:180]
[same as prior period, unchanged from 0000858877-24-000007:notes:202]

[0000858877-24-000030:notes:181]
[same as prior period, unchanged from 0000858877-24-000007:notes:203]

[0000858877-24-000030:notes:182]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral provided for was $7 million and $11 million as of October 26, 2024 and July 27, 2024, respectively.

[0000858877-24-000030:notes:183]
[same as prior period, unchanged from 0000858877-24-000007:notes:205]

[0000858877-24-000030:notes:184]
[same as prior period, unchanged from 0000858877-24-000007:notes:206]

[0000858877-24-000030:notes:185]
[same as prior period, unchanged from 0000858877-24-000007:notes:207]

[0000858877-24-000030:notes:186]
[same as prior period, unchanged from 0000858877-24-000007:notes:208]

[0000858877-24-000030:notes:187]
[same as prior period, unchanged from 0000858877-24-000007:notes:209]

[0000858877-24-000030:notes:188]
[same as prior period, unchanged from 0000858877-24-000007:notes:210]

[0000858877-24-000030:notes:189]
We hold an interest rate swap designated as a fair value hedge related to a fixed-rate senior note that is due in fiscal 2025. Under the interest rate swap, we receive fixed-rate interest payments and make interest payments based on SOFR plus a fixed number of basis points. The effect of the swap is to convert the fixed interest rate of the senior fixed-rate note to a floating interest rate based on SOFR. The gain and loss related to the change in the fair value of the interest rate swap is included in interest expense and substantially offsets the change in the fair value of the hedged portion of the underlying debt attributable to the change in market interest rates.

[0000858877-24-000030:notes:190]
We periodically enter into treasury lock agreements, designated as cash flow hedges, in order to hedge the impact of changes in the U.S. benchmark interest rate on future interest payments in anticipation of future debt offerings. Changes in the fair value of treasury lock agreements are recorded to AOCI and reclassified into earnings when the hedged exposure affects earnings.

[0000858877-24-000030:notes:191]
[same as prior period, unchanged from 0000858877-24-000007:notes:212]

[0000858877-24-000030:notes:192]
We hold marketable equity securities in our portfolio that are subject to price risk. To diversify our overall portfolio, we also hold equity derivatives that are not designated as accounting hedges. The change in the fair value of each of these investment types are included in other income (loss), net.
We are also exposed to variability in compensation charges related to certain deferred compensation obligations to employees and directors. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure and offset the related compensation expense.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-24-000030:notes:193]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-24-000030:notes:194]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments are directly with suppliers, and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-24-000030:notes:195]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-24-000030:notes:196]
|  | October 26,2024 |  | July 27,2024 |
| Less than 1 year | $ | 4,309 |  |  | $ | 3,952 |  |
| 1 to 3 years | 886 |  |  | 1,085 |  |
| 3 to 5 years | 126 |  |  | 121 |  |
| Total | $ | 5,321 |  |  | $ | 5,158 |  |

[0000858877-24-000030:notes:197]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 26, 2024 and July 27, 2024, the liability for these purchase commitments was $439 million and $498 million, respectively, and was included in other current liabilities.

[0000858877-24-000030:notes:198]
(b)Other Commitments

[0000858877-24-000030:notes:199]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.3 billion and $0.2 billion as of October 26, 2024 and July 27, 2024, respectively.

[0000858877-24-000030:notes:200]
(c)Product Warranties

[0000858877-24-000030:notes:201]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-24-000030:notes:202]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |
| Balance at beginning of period | $ | 362 |  |  | $ | 329 |  |
| Provisions for warranties issued | 105 |  |  | 98 |  |
| Adjustments for pre-existing warranties | 1 |  |  | 3 |  |
| Settlements | (111) |  |  | (100) |  |
| Balance at end of period | $ | 357 |  |  | $ | 330 |  |

[0000858877-24-000030:notes:203]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-24-000030:notes:204]
(d)Financing and Other Guarantees

[0000858877-24-000030:notes:205]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-24-000030:notes:206]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.0 billion and $8.2 billion for the first quarter of fiscal 2025 and 2024, respectively. The balance of the channel partner financing subject to guarantees was $1.1 billion and $1.2 billion as of October 26, 2024 and July 27, 2024, respectively.

[0000858877-24-000030:notes:207]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at October 26, 2024 and July 27, 2024, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-24-000030:notes:208]
|  | October 26,2024 |  | July 27,2024 |
| Maximum potential future payments | $ | 123 |  |  | $ | 127 |  |
| Deferred revenue | (12) |  |  | (13) |  |
| Total | $ | 111 |  |  | $ | 114 |  |

[0000858877-24-000030:notes:209]
(e)Indemnifications

[0000858877-24-000030:notes:210]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-24-000030:notes:211]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-24-000030:notes:212]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-24-000030:notes:213]
(f)Legal Proceedings

[0000858877-24-000030:notes:214]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $142 million for the alleged evasion of import and other taxes, $839 million for interest, and $323 million for various penalties, all determined using an exchange rate as of October 26, 2024.

[0000858877-24-000030:notes:215]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-24-000030:notes:216]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. After two bench trials and various administrative actions and appeals, we have been found either to not have infringed any of the patents or the patents have been invalidated. Centripetal has appealed one of the invalidity decisions and the non-infringement judgment of the District Court, and both of those proceedings are ongoing.

[0000858877-24-000030:notes:217]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringed three patents, one patent was invalidated, the utility model was invalidated, and the infringement action on the final patent is stayed due to an invalidity action heard on June 6, 2024 in the Federal Patent Court, in which all claims, aside from one auxiliary claim, were found invalid, for which we are awaiting the entry of judgment from the Federal Patent Court. Centripetal’s appeals of two of the non-infringement findings remain pending and, on March 27, 2024, the Court of Appeals rejected Centripetal’s appeal of the third non-infringement finding.

[0000858877-24-000030:notes:218]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement. We have filed our response and defenses to the complaint and we anticipate that on December 5, 2024, the Court will set a schedule for the remainder of the proceedings.

[0000858877-24-000030:notes:219]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of the litigations at this time. If we do not prevail in these litigations, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-24-000030:notes:220]
Ramot     On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents and those proceedings are ongoing. The Court set trial in the D. Del. cases for November 3, 2025.

[0000858877-24-000030:notes:221]
While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-24-000030:notes:222]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023. The Federal Circuit heard oral argument on October 11, 2024 and we are awaiting the decision.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-24-000030:notes:223]
Purchase Commitments with Contract Manufacturers and Suppliers We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments are directly with suppliers, and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-24-000030:notes:224]
[same as prior period, unchanged from 0000858877-24-000007:notes:247]

[0000858877-24-000030:notes:225]
In September 2001, our Board of Directors authorized a stock repurchase program. As of October 26, 2024, the remaining authorized amount for stock repurchases under this program was approximately $3.2 billion with no termination date. The stock repurchase activity for fiscal 2025 and 2024 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-24-000030:notes:226]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2025 |  |  |  |  |  |  |
| October 26, 2024 |  | 40 |  |  | $ | 49.56 |  |  | $ | 2,003 |  |
| Fiscal 2024 |  |  |  |  |  |  |
| July 27, 2024 |  | 43 |  |  | $ | 46.80 |  |  | $ | 2,002 |  |
| April 27, 2024 |  | 26 |  |  | $ | 49.22 |  |  | $ | 1,256 |  |
| January 27, 2024 |  | 25 |  |  | $ | 49.54 |  |  | $ | 1,254 |  |
| October 28, 2023 |  | 23 |  |  | $ | 54.53 |  |  | $ | 1,252 |  |

[0000858877-24-000030:notes:227]
There were stock repurchases of $25 million that were pending settlement as of each of October 26, 2024 and July 27, 2024.

[0000858877-24-000030:notes:228]
[same as prior period, unchanged from 0000858877-24-000007:notes:251]

[0000858877-24-000030:notes:229]
[same as prior period, unchanged from 0000858877-24-000007:notes:252]

[0000858877-24-000030:notes:230]
On November 13, 2024, our Board of Directors declared a quarterly dividend of $0.40 per common share to be paid on January 22, 2025, to all stockholders of record as of the close of business on January 3, 2025. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-24-000030:notes:231]
[same as prior period, unchanged from 0000858877-24-000007:notes:254]

[0000858877-24-000030:notes:232]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock in one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights, if any, of such series, and any qualifications, limitations or restrictions thereof, of the shares of such series. As of October 26, 2024, we have not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-24-000030:notes:233]
[same as prior period, unchanged from 0000858877-24-000007:notes:256]

[0000858877-24-000030:notes:234]
We have one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with us. The number and frequency of share-based awards are based on competitive practices, our operating results, government regulations, and other factors.

[0000858877-24-000030:notes:235]
The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions. Time-based and performance-based RSUs generally vest over three years with certain awards containing retirement eligible provisions. Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. The 2005 Plan may be terminated by our Board of Directors at any time and for any reason, and is currently set to terminate at the 2030 Annual Meeting unless re-adopted or extended by our stockholders prior to or on such date.

[0000858877-24-000030:notes:236]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of October 26, 2024, 158 million shares were authorized for future grant under the 2005 Plan.

[0000858877-24-000030:notes:237]
[same as prior period, unchanged from 0000858877-24-000007:notes:260]

[0000858877-24-000030:notes:238]
We have an Employee Stock Purchase Plan under which eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. No shares were issued under the Employee Stock Purchase Plan during each of the first quarter of fiscal 2025 and 2024. As of October 26, 2024, 68 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-24-000030:notes:239]
[same as prior period, unchanged from 0000858877-24-000007:notes:262]

[0000858877-24-000030:notes:240]
Share-based compensation expense consists of expenses for RSUs and stock purchase rights, granted to employees or assumed from acquisitions. The following table summarizes share-based compensation expense (in millions):

[0000858877-24-000030:notes:241]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Cost of sales—product | $ | 57 |  |  | $ | 42 |  |
| Cost of sales—services | 74 |  |  | 61 |  |
| Share-based compensation expense in cost of sales | 131 |  |  | 103 |  |
| Research and development | 354 |  |  | 274 |  |
| Sales and marketing | 210 |  |  | 186 |  |
| General and administrative | 115 |  |  | 90 |  |
| Restructuring and other charges | 17 |  |  | 8 |  |
| Share-based compensation expense in operating expenses | 696 |  |  | 558 |  |
| Total share-based compensation expense | $ | 827 |  |  | $ | 661 |  |
| Income tax benefit for share-based compensation | $ | 174 |  |  | $ | 143 |  |

[0000858877-24-000030:notes:242]
As of October 26, 2024, the total compensation cost related to unvested share-based awards not yet recognized was $4.1 billion which is expected to be recognized over approximately 1.7 years on a weighted-average basis.

[0000858877-24-000030:notes:243]
[same as prior period, unchanged from 0000858877-24-000007:notes:266]

[0000858877-24-000030:notes:244]
[same as prior period, unchanged from 0000858877-24-000007:notes:267]

[0000858877-24-000030:notes:245]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| Unvested balance at July 29, 2023 | 122 |  |  | $ | 44.04 |  |  |  |
| Granted and assumed | 63 |  |  | 48.97 |  |  |  |
| Vested | (58) |  |  | 43.46 |  |  | $ | 2,906 |  |
| Canceled/forfeited/other | (10) |  |  | 45.65 |  |  |  |
| Unvested balance at July 27, 2024 | 117 |  |  | $ | 46.86 |  |  |  |
| Granted and assumed | 7 |  |  | 50.94 |  |  |  |
| Vested | (13) |  |  | 46.03 |  |  | $ | 586 |  |
| Canceled/forfeited/other | (2) |  |  | 46.47 |  |  |  |
| Unvested balance at October 26, 2024 | 109 |  |  | $ | 47.24 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-24-000030:notes:246]
Accumulated Other Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first quarter of fiscal 2025 and 2024 are summarized as follows (in millions):

[0000858877-24-000030:notes:247]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 27, 2024 | $ | (241) |  |  | $ | 79 |  |  | $ | (1,268) |  |  | $ | (1,430) |  |
| Other comprehensive income (loss) before reclassifications | 71 |  |  | 9 |  |  | (19) |  |  | 61 |  |
| (Gains) losses reclassified out of AOCI | 25 |  |  | (9) |  |  | — |  |  | 16 |  |
| Tax benefit (expense) | (23) |  |  | — |  |  | — |  |  | (23) |  |
| Balance at October 26, 2024 | $ | (168) |  |  | $ | 79 |  |  | $ | (1,287) |  |  | $ | (1,376) |  |

[0000858877-24-000030:notes:248]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 29, 2023 | $ | (440) |  |  | $ | 18 |  |  | $ | (1,153) |  |  | $ | (1,575) |  |
| Other comprehensive income (loss) before reclassifications | (170) |  |  | 38 |  |  | (356) |  |  | (488) |  |
| (Gains) losses reclassified out of AOCI | 20 |  |  | (12) |  |  | (1) |  |  | 7 |  |
| Tax benefit (expense) | 36 |  |  | (6) |  |  | 1 |  |  | 31 |  |
| Balance at October 28, 2023 | $ | (554) |  |  | $ | 38 |  |  | $ | (1,509) |  |  | $ | (2,025) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-24-000030:notes:249]
[same as prior period, unchanged from 0000858877-24-000007:notes:272]

[0000858877-24-000030:notes:250]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |
| Income before provision for (benefit from) income taxes | $ | 2,267 |  |  | $ | 4,442 |  |
| Provision for (benefit from) income taxes | $ | (444) |  |  | $ | 804 |  |
| Effective tax rate | (19.6) | % |  | 18.1 | % |

[0000858877-24-000030:notes:251]
As of October 26, 2024, we had $2.1 billion of unrecognized tax benefits, of which $1.5 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.

[0000858877-24-000030:notes:252]
On August 26, 2024, the U.S. Tax Court issued an opinion in Varian Medical Systems, Inc. v. Commissioner. The opinion related to the U.S. taxation of deemed foreign dividends in the transition year of the Tax Cuts and Jobs Act (our fiscal 2018). While we were not a party to the case, the opinion resulted in a change to our tax position. As such, we recorded a tax benefit of $720 million as a reduction to the provision for income taxes in the first quarter of fiscal 2025 due to this recent U.S. Tax Court opinion.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-24-000030:notes:253]
[same as prior period, unchanged from 0000858877-24-000007:notes:275]

[0000858877-24-000030:notes:254]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-24-000030:notes:255]
Summarized financial information by segment for the first quarter of fiscal 2025 and 2024, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-24-000030:notes:256]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |
| Revenue: |  |  |  |
| Americas | $ | 8,252 |  |  | $ | 9,022 |  |
| EMEA | 3,588 |  |  | 3,664 |  |
| APJC | 2,001 |  |  | 1,982 |  |
| Total | $ | 13,841 |  |  | $ | 14,668 |  |
| Gross margin: |  |  |  |
| Americas | $ | 5,740 |  |  | $ | 5,968 |  |
| EMEA | 2,522 |  |  | 2,545 |  |
| APJC | 1,328 |  |  | 1,328 |  |
| Segment total | 9,590 |  |  | 9,841 |  |
| Unallocated corporate items | (469) |  |  | (284) |  |
| Total | $ | 9,121 |  |  | $ | 9,557 |  |

[0000858877-24-000030:notes:257]
Revenue in the United States was $7.4 billion and $8.1 billion for the first quarter of fiscal 2025 and 2024, respectively.

[0000858877-24-000030:notes:258]
[same as prior period, unchanged from 0000858877-24-000007:notes:280]

[0000858877-24-000030:notes:259]
We design and sell Internet Protocol (IP)-based networking and other products related to the communications and IT industry and provide services associated with these products and their use.


## us-gaap:EarningsPerShareTextBlock

[0000858877-24-000030:notes:260]
[same as prior period, unchanged from 0000858877-24-000007:notes:282]

[0000858877-24-000030:notes:261]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |
| Net income | $ | 2,711 |  |  | $ | 3,638 |  |
| Weighted-average shares—basic | 3,990 |  |  | 4,057 |  |
| Effect of dilutive potential common shares | 23 |  |  | 30 |  |
| Weighted-average shares—diluted | 4,013 |  |  | 4,087 |  |
| Net income per share—basic | $ | 0.68 |  |  | $ | 0.90 |  |
| Net income per share—diluted | $ | 0.68 |  |  | $ | 0.89 |  |
| Antidilutive employee share-based awards, excluded | 13 |  |  | 16 |  |
