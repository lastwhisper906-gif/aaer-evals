# CSCO 8-K — 0001193125-24-257224 filed 2024-11-13

## item codes, every 8-K on or before 2024-11-19

- 2024-11-13 0001193125-24-257224 — 2.02, 9.01
- 2024-10-11 0001193125-24-236734 — 5.02
- 2024-08-14 0001193125-24-200636 — 2.02, 2.05, 9.01
- 2024-07-19 0000858877-24-000012 — 5.02
- 2024-06-14 0000858877-24-000010 — 5.02
- 2024-05-15 0001193125-24-139371 — 2.02, 5.02, 9.01
- 2024-03-18 0001193125-24-070175 — 2.01, 7.01, 9.01
- 2024-02-26 0001193125-24-046231 — 1.01, 2.03, 9.01
- 2024-02-14 0001193125-24-036201 — 2.02, 2.05, 9.01
- 2024-02-08 0001193125-24-028353 — 1.01, 2.03, 8.01, 9.01
- 2023-12-08 0001193125-23-291721 — 5.02, 5.07, 9.01
- 2023-11-15 0001193125-23-277891 — 2.02, 9.01
- 2023-10-10 0000858877-23-000025 — 5.02
- 2023-09-25 0001193125-23-240975 — 7.01
- 2023-09-21 0001193125-23-239165 — 1.01, 7.01, 8.01, 9.01
- 2023-08-16 0001193125-23-214316 — 2.02, 9.01
- 2023-07-19 0000858877-23-000016 — 5.02
- 2023-05-17 0001193125-23-147021 — 2.02, 9.01
- 2023-03-10 0000858877-23-000009 — 5.03, 9.01
- 2023-02-21 0000858877-23-000006 — 5.02
- 2023-02-15 0001193125-23-040212 — 2.02, 9.01
- 2022-12-16 0000858877-22-000029 — 8.01
- 2022-12-09 0000858877-22-000027 — 5.07
- 2022-11-16 0001628280-22-030151 — 5.02
- 2022-11-16 0001193125-22-286782 — 2.02, 2.05, 9.01
- 2022-10-04 0000858877-22-000018 — 1.01, 1.02, 9.01
- 2022-09-15 0000858877-22-000015 — 8.01
- 2022-08-24 0001193125-22-228572 — 5.02
- 2022-08-17 0001193125-22-223250 — 2.02, 9.01
- 2022-06-17 0001193125-22-176552 — 8.01
- 2022-05-18 0001193125-22-154039 — 2.02, 9.01
- 2022-03-28 0001193125-22-086807 — 8.01
- 2022-02-16 0001193125-22-044372 — 2.02, 9.01
- 2022-02-11 0001193125-22-037227 — 5.02
- 2022-01-31 0001193125-22-023458 — 5.02
- 2021-12-17 0001193125-21-361182 — 8.01
- 2021-12-14 0001193125-21-356837 — 5.07, 8.01
- 2021-11-17 0001193125-21-332467 — 2.02, 9.01
- 2021-09-27 0001193125-21-284199 — 8.01
- 2021-08-18 0001193125-21-250360 — 2.02, 9.01
- 2021-06-29 0001193125-21-203324 — 8.01
- 2021-05-19 0001193125-21-166614 — 2.02, 9.01
- 2021-05-14 0001193125-21-162081 — 1.01, 2.03, 9.01
- 2021-03-08 0001193125-21-073328 — 5.02
- 2021-02-25 0001193125-21-056977 — 5.02
- 2021-02-09 0001193125-21-034339 — 2.02, 9.01
- 2021-01-07 0001193125-21-004250 — 5.02
- 2020-12-17 0001193125-20-320092 — 5.02, 8.01
- 2020-12-11 0001193125-20-315999 — 5.02, 5.07, 9.01
- 2020-11-30 0001193125-20-305352 — 5.02
- 2020-11-13 0001193125-20-293020 — 5.02, 9.01
- 2020-11-12 0001193125-20-291658 — 2.02, 9.01
- 2020-10-09 0001193125-20-267248 — 5.03, 9.01
- 2020-09-23 0001193125-20-252356 — 8.01
- 2020-08-12 0001193125-20-217756 — 5.02
- 2020-08-12 0001193125-20-217658 — 2.02, 2.05, 9.01
- 2020-06-22 0001193125-20-175641 — 8.01
- 2020-05-13 0001193125-20-141598 — 2.02, 9.01
- 2020-03-13 0001193125-20-072960 — 5.02
- 2020-03-06 0001193125-20-065138 — 5.02
- 2020-02-12 0001193125-20-033208 — 2.02, 9.01
- 2020-01-27 0001193125-20-015453 — 5.02
- 2019-12-23 0001193125-19-322662 — 8.01
- 2019-12-12 0001193125-19-312796 — 8.01
- 2019-12-11 0001193125-19-311525 — 5.07
- 2019-12-04 0001193125-19-306229 — 8.01
- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2024-11-19

- none on or before 2024-11-19

## item 2.02 — earnings release, exhibit 99.1

[0001193125-24-257224:8k_2_02:1]
EX-99.1
2
d875468dex991.htm
EX-99.1

[0001193125-24-257224:8k_2_02:2]
EX-99.1

[0001193125-24-257224:8k_2_02:3]
Exhibit 99.1

[0001193125-24-257224:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Sami Badri |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 (469) 420-4834 |
| rojenkin@cisco.com |  |  |  | sambadri@cisco.com |

[0001193125-24-257224:8k_2_02:5]
CISCO REPORTS FIRST QUARTER EARNINGS

[0001193125-24-257224:8k_2_02:6]
News Summary:

[0001193125-24-257224:8k_2_02:7]
|  | • |  | Broad-based acceleration in product orders reflecting normalizing demand |

[0001193125-24-257224:8k_2_02:8]
|  | • |  | Product orders up 20% year over year; up 9% year over year excluding Splunk |

[0001193125-24-257224:8k_2_02:9]
|  | • |  | Revenue of $13.8 billion in Q1, at the high end of our guidance range |

[0001193125-24-257224:8k_2_02:10]
|  | • |  | Strong profitability: |

[0001193125-24-257224:8k_2_02:11]
|  | • |  | GAAP gross margin of 65.9% and non-GAAP gross margin of 69.3%, above our guidance range |

[0001193125-24-257224:8k_2_02:12]
|  | • |  | GAAP EPS of $0.68 and non-GAAP EPS of $0.91, above our guidance range |

[0001193125-24-257224:8k_2_02:13]
| • |  | Q1 FY 2025 Results: |

[0001193125-24-257224:8k_2_02:14]
|  | • |  | Revenue: $13.8 billion |

[0001193125-24-257224:8k_2_02:15]
|  | • |  | Decrease of 6% year over year |

[0001193125-24-257224:8k_2_02:16]
|  | • |  | Earnings per Share: GAAP: $0.68; Non-GAAP: $0.91 |

[0001193125-24-257224:8k_2_02:17]
|  | • |  | GAAP EPS decreased 24% year over year |

[0001193125-24-257224:8k_2_02:18]
|  | • |  | Non-GAAP EPS decreased 18% year over year |

[0001193125-24-257224:8k_2_02:19]
| • |  | Q2 FY 2025 Guidance: |

[0001193125-24-257224:8k_2_02:20]
|  | • |  | Revenue: $13.75 billion to $13.95 billion |

[0001193125-24-257224:8k_2_02:21]
|  | • |  | Earnings per Share: GAAP: $0.51 to $0.56; Non-GAAP: $0.89 to $0.91 |

[0001193125-24-257224:8k_2_02:22]
| • |  | FY 2025 Guidance: |

[0001193125-24-257224:8k_2_02:23]
|  | • |  | Revenue: $55.3 billion to $56.3 billion |

[0001193125-24-257224:8k_2_02:24]
|  | • |  | Earnings per Share: GAAP: $2.26 to $2.38; Non-GAAP: $3.60 to $3.66 |

[0001193125-24-257224:8k_2_02:25]
SAN JOSE, Calif. — November 13, 2024 — Cisco today reported first quarter results for the period ended October 26,
2024. Cisco reported first quarter revenue of $13.8 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.7 billion or $0.68 per share, and non-GAAP net income of
$3.7 billion or $0.91 per share.

[0001193125-24-257224:8k_2_02:26]
“Cisco is off to a strong start to fiscal 2025” said Chuck Robbins, chair and CEO of Cisco. “Our
customers are investing in critical infrastructure to prepare for AI, and with the breadth of our portfolio, we are uniquely positioned to capitalize on this opportunity.”

[0001193125-24-257224:8k_2_02:27]
“Revenue, gross margin and EPS in Q1 were at the high end or above our guidance range, generating strong operating leverage” said Scott Herren, CFO
of Cisco. “We are focused on solid execution and operating discipline while making strategic investments to drive innovation and growth.”

[0001193125-24-257224:8k_2_02:28]
1

[0001193125-24-257224:8k_2_02:29]
GAAP Results

[0001193125-24-257224:8k_2_02:30]
|  |  | Q1 FY 2025 |  |  | Q1 FY 2024 |  |  | Vs. Q1 FY 2024 |  |
| Revenue |  | $ | 13.8 billion |  |  | $ | 14.7 billion |  |  |  | (6 | )% |
| Net Income |  | $ | 2.7 billion |  |  | $ | 3.6 billion |  |  |  | (25 | )% |
| Diluted Earnings per Share (EPS) |  | $ | 0.68 |  |  | $ | 0.89 |  |  |  | (24 | )% |

[0001193125-24-257224:8k_2_02:31]
Q1 FY 2025 GAAP results include a tax benefit of $720 million due to a recent U.S. Tax Court decision regarding the U.S.
taxation of deemed foreign dividends in the transition year of the Tax Cuts and Jobs Act.

[0001193125-24-257224:8k_2_02:32]
Non-GAAP Results

[0001193125-24-257224:8k_2_02:33]
|  |  | Q1 FY 2025 |  |  | Q1 FY 2024 |  |  | Vs. Q1 FY 2024 |  |
| Net Income |  | $ | 3.7 billion |  |  | $ | 4.5 billion |  |  |  | (19 | )% |
| EPS |  | $ | 0.91 |  |  | $ | 1.11 |  |  |  | (18 | )% |

[0001193125-24-257224:8k_2_02:34]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-24-257224:8k_2_02:35]
Cisco Declares Quarterly Dividend

[0001193125-24-257224:8k_2_02:36]
Cisco has declared a
quarterly dividend of $0.40 per common share to be paid on January 22, 2025, to all stockholders of record as of the close of business on January 3, 2025. Future dividends will be subject to Board approval.

[0001193125-24-257224:8k_2_02:37]
2

[0001193125-24-257224:8k_2_02:38]
Financial Summary

[0001193125-24-257224:8k_2_02:39]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-24-257224:8k_2_02:40]
Q1 FY 2025 Highlights

[0001193125-24-257224:8k_2_02:41]
Revenue — Total
revenue was $13.8 billion, down 6%, with product revenue down 9% and services revenue up 6%. Excluding the contribution from Splunk, total revenue was down 14%.

[0001193125-24-257224:8k_2_02:42]
Revenue by geographic segment was: Americas down 9%, EMEA down 2%, and APJC up 1%. Product revenue performance reflected growth in Security up 100% and
Observability up 36%. Networking was down 23% and Collaboration was down 3%. Excluding Splunk, Security and Observability grew 2% and 1%, respectively, in the first quarter of fiscal 2025.

[0001193125-24-257224:8k_2_02:43]
Gross Margin — On a GAAP basis, total gross margin, product gross margin, and services gross margin were 65.9%, 65.1%, and 68.0%,
respectively, as compared with 65.2%, 64.5%, and 67.3%, respectively, in the first quarter of fiscal 2024.

[0001193125-24-257224:8k_2_02:44]
On a
non-GAAP basis, total gross margin, product gross margin, and services gross margin were 69.3%, 68.9%, and 70.3%, respectively, as compared with 67.1%, 66.5%, and 69.0%, respectively, in the first quarter of
fiscal 2024.

[0001193125-24-257224:8k_2_02:45]
Total gross margins by geographic segment were: 69.6% for the Americas, 70.3% for EMEA and 66.4% for APJC.

[0001193125-24-257224:8k_2_02:46]
Operating Expenses — On a GAAP basis, operating expenses were $6.8 billion, up 28%, and were 48.9% of revenue. Non-GAAP operating expenses were $4.9 billion, up 9%, and were 35.2% of revenue.

[0001193125-24-257224:8k_2_02:47]
Operating Income
— GAAP operating income was $2.4 billion, down 45%, with GAAP operating margin of 17.0%. Non-GAAP operating income was $4.7 billion, down 12%, with
non-GAAP operating margin at 34.1%.

[0001193125-24-257224:8k_2_02:48]
Provision for (benefit from) Income Taxes — The GAAP tax
provision rate was a benefit of 19.6%, which includes the $720 million benefit on deemed foreign dividends as discussed above. The non-GAAP tax provision rate was 19.0%.

[0001193125-24-257224:8k_2_02:49]
Net Income and EPS — On a GAAP basis, net income was $2.7 billion, a decrease of 25%, and EPS was $0.68, a decrease of 24%. On a non-GAAP basis, net income was $3.7 billion, a decrease of 19%, and EPS was $0.91, a decrease of 18%.

[0001193125-24-257224:8k_2_02:50]
Cash
Flow from Operating Activities — $3.7 billion for the first quarter of fiscal 2025, an increase of 54%, compared with $2.4 billion for the first quarter of fiscal 2024.

[0001193125-24-257224:8k_2_02:51]
Balance Sheet and Other Financial Highlights

[0001193125-24-257224:8k_2_02:52]
Cash
and Cash Equivalents and Investments — $18.7 billion at the end of the first quarter of fiscal 2025, compared with $17.9 billion at the end of fiscal 2024.

[0001193125-24-257224:8k_2_02:53]
Remaining Performance Obligations (RPO) — $40.0 billion, up 15% in total, with 51% of this amount to be recognized as
revenue over the next 12 months. Product RPO were up 24% and services RPO were up 7%.

[0001193125-24-257224:8k_2_02:54]
Deferred Revenue — $27.5 billion, up 7% in
total, with deferred product revenue up 11%. Deferred services revenue was up 4%.

[0001193125-24-257224:8k_2_02:55]
Capital Allocation — In the first quarter of fiscal
2025, we returned $3.6 billion to stockholders through share buybacks and dividends. We declared and paid a cash dividend of $0.40 per common share, or $1.6 billion, and repurchased approximately 40 million shares of common stock
under our stock repurchase program at an average price of $49.56 per share for an aggregate purchase price of $2.0 billion. The remaining authorized amount for stock repurchases under the program is $3.2 billion with no termination date.

[0001193125-24-257224:8k_2_02:56]
Acquisitions

[0001193125-24-257224:8k_2_02:57]
In the first quarter of fiscal 2025,
we closed the following acquisitions:

[0001193125-24-257224:8k_2_02:58]
|  | • |  | DeepFactor, Inc., a privately held cloud-native application security company |

[0001193125-24-257224:8k_2_02:59]
|  | • |  | Robust Intelligence, Inc., a privately held AI security solutions company |

[0001193125-24-257224:8k_2_02:60]
Guidance

[0001193125-24-257224:8k_2_02:61]
Cisco estimates the following results for the second quarter of fiscal 2025:

[0001193125-24-257224:8k_2_02:62]
| Q2 FY 2025 |  |  |  |
| Revenue |  |  | $13.75 billion - $13.95 billion |  |
| Non-GAAP gross margin |  |  | 68% - 69% |  |
| Non-GAAP operating margin |  |  | 33.5% - 34.5% |  |
| Non-GAAP EPS |  |  | $0.89 - $0.91 |  |

[0001193125-24-257224:8k_2_02:63]
Cisco estimates that GAAP EPS will be $0.51 to $0.56 for the second quarter of fiscal 2025.

[0001193125-24-257224:8k_2_02:64]
Cisco estimates the following results for fiscal 2025:

[0001193125-24-257224:8k_2_02:65]
| FY 2025 |  |  |  |
| Revenue |  |  | $55.3 billion - $56.3 billion |  |
| Non-GAAP EPS |  |  | $3.60 - $3.66 |  |

[0001193125-24-257224:8k_2_02:66]
Cisco estimates that GAAP EPS will be $2.26 to $2.38 for fiscal 2025.

[0001193125-24-257224:8k_2_02:67]
Our Q2 FY 2025 guidance assumes an effective tax provision rate of approximately 17% for GAAP and approximately 19% for
non-GAAP results. Our FY 2025 guidance assumes an effective tax provision rate of approximately 9% for GAAP and approximately 19% for non-GAAP results.

[0001193125-24-257224:8k_2_02:68]
A reconciliation between the guidance on a GAAP and non-GAAP basis is provided in the tables entitled “GAAP to non-GAAP Guidance” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-24-257224:8k_2_02:69]
Editor’s Notes:

[0001193125-24-257224:8k_2_02:70]
|  | • |  | Q1 fiscal year 2025 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, November 13, 2024 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-24-257224:8k_2_02:71]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, November 13, 2024 to 4:00 p.m. Pacific Time, November 19, 2024 at 1-866-360-7722 (United States) or 1-203-369-0174 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-24-257224:8k_2_02:72]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, November 13, 2024. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-24-257224:8k_2_02:73]
4

[0001193125-24-257224:8k_2_02:74]
CISCO SYSTEMS, INC.

[0001193125-24-257224:8k_2_02:75]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-24-257224:8k_2_02:76]
(In millions, except per-share amounts)

[0001193125-24-257224:8k_2_02:77]
(Unaudited)

[0001193125-24-257224:8k_2_02:78]
|  |  | Three Months Ended |  |
|  |  | October 26,2024 |  |  | October 28,2023 |  |
| REVENUE: |  |  |  |  |  |  |  |  |
| Product |  | $ | 10,114 |  |  | $ | 11,139 |  |
| Services |  |  | 3,727 |  |  |  | 3,529 |  |
| Total revenue |  |  | 13,841 |  |  |  | 14,668 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |
| Product |  |  | 3,526 |  |  |  | 3,957 |  |
| Services |  |  | 1,194 |  |  |  | 1,154 |  |
| Total cost of sales |  |  | 4,720 |  |  |  | 5,111 |  |
| GROSS MARGIN |  |  | 9,121 |  |  |  | 9,557 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 2,286 |  |  |  | 1,913 |  |
| Sales and marketing |  |  | 2,752 |  |  |  | 2,506 |  |
| General and administrative |  |  | 795 |  |  |  | 672 |  |
| Amortization of purchased intangible assets |  |  | 265 |  |  |  | 67 |  |
| Restructuring and other charges |  |  | 665 |  |  |  | 123 |  |
| Total operating expenses |  |  | 6,763 |  |  |  | 5,281 |  |
| OPERATING INCOME |  |  | 2,358 |  |  |  | 4,276 |  |
| Interest income |  |  | 286 |  |  |  | 360 |  |
| Interest expense |  |  | (418 | ) |  |  | (111 | ) |
| Other income (loss), net |  |  | 41 |  |  |  | (83 | ) |
| Interest and other income (loss), net |  |  | (91 | ) |  |  | 166 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 2,267 |  |  |  | 4,442 |  |
| Provision for (benefit from) income taxes |  |  | (444 | ) |  |  | 804 |  |
| NET INCOME |  | $ | 2,711 |  |  | $ | 3,638 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.68 |  |  | $ | 0.90 |  |
| Diluted |  | $ | 0.68 |  |  | $ | 0.89 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |
| Basic |  |  | 3,990 |  |  |  | 4,057 |  |
| Diluted |  |  | 4,013 |  |  |  | 4,087 |  |

[0001193125-24-257224:8k_2_02:79]
5

[0001193125-24-257224:8k_2_02:80]
CISCO SYSTEMS, INC.

[0001193125-24-257224:8k_2_02:81]
REVENUE BY SEGMENT

[0001193125-24-257224:8k_2_02:82]
(In
millions, except percentages)

[0001193125-24-257224:8k_2_02:83]
|  |  | Three Months EndedOctober 26, 2024 |  |
|  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 8,252 |  |  |  | (9 | )% |
| EMEA |  |  | 3,588 |  |  |  | (2 | )% |
| APJC |  |  | 2,001 |  |  |  | 1 | % |
| Total |  | $ | 13,841 |  |  |  | (6 | )% |

[0001193125-24-257224:8k_2_02:84]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-24-257224:8k_2_02:85]
CISCO SYSTEMS, INC.

[0001193125-24-257224:8k_2_02:86]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-24-257224:8k_2_02:87]
(In percentages)

[0001193125-24-257224:8k_2_02:88]
|  |  | Three Months EndedOctober 26, 2024 |  |
| Gross Margin Percentage: |  |  |  |  |
| Americas |  |  | 69.6% |  |
| EMEA |  |  | 70.3% |  |
| APJC |  |  | 66.4% |  |

[0001193125-24-257224:8k_2_02:89]
CISCO SYSTEMS, INC.

[0001193125-24-257224:8k_2_02:90]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-24-257224:8k_2_02:91]
(In millions, except percentages)

[0001193125-24-257224:8k_2_02:92]
|  |  | Three Months EndedOctober 26, 2024 |  |
|  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Networking |  | $ | 6,753 |  |  |  | (23 | )% |
| Security |  |  | 2,017 |  |  |  | 100 | % |
| Collaboration |  |  | 1,085 |  |  |  | (3 | )% |
| Observability |  |  | 258 |  |  |  | 36 | % |
| Total Product |  |  | 10,114 |  |  |  | (9 | )% |
| Services |  |  | 3,727 |  |  |  | 6 | % |
| Total |  | $ | 13,841 |  |  |  | (6 | )% |

[0001193125-24-257224:8k_2_02:93]
Excluding Splunk, Security and Observability grew 2% and 1%, respectively, in the first quarter of fiscal 2025.

[0001193125-24-257224:8k_2_02:94]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-24-257224:8k_2_02:95]
6

[0001193125-24-257224:8k_2_02:96]
CISCO SYSTEMS, INC.

[0001193125-24-257224:8k_2_02:97]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-24-257224:8k_2_02:98]
(In millions)

[0001193125-24-257224:8k_2_02:99]
(Unaudited)

[0001193125-24-257224:8k_2_02:100]
|  |  | October 26,2024 |  |  | July 27,2024 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,065 |  |  | $ | 7,508 |  |
| Investments |  |  | 9,606 |  |  |  | 10,346 |  |
| Accounts receivable, net of allowance of $78 at October 26, 2024 and $87 at July 27, 2024 |  |  | 4,457 |  |  |  | 6,685 |  |
| Inventories |  |  | 3,143 |  |  |  | 3,373 |  |
| Financing receivables, net |  |  | 3,123 |  |  |  | 3,338 |  |
| Other current assets |  |  | 6,358 |  |  |  | 5,612 |  |
| Total current assets |  |  | 35,752 |  |  |  | 36,862 |  |
| Property and equipment, net |  |  | 2,082 |  |  |  | 2,090 |  |
| Financing receivables, net |  |  | 3,411 |  |  |  | 3,376 |  |
| Goodwill |  |  | 58,774 |  |  |  | 58,660 |  |
| Purchased intangible assets, net |  |  | 10,744 |  |  |  | 11,219 |  |
| Deferred tax assets |  |  | 6,514 |  |  |  | 6,262 |  |
| Other assets |  |  | 6,056 |  |  |  | 5,944 |  |
| TOTAL ASSETS |  | $ | 123,333 |  |  | $ | 124,413 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 12,364 |  |  | $ | 11,341 |  |
| Accounts payable |  |  | 1,996 |  |  |  | 2,304 |  |
| Income taxes payable |  |  | 2,096 |  |  |  | 1,439 |  |
| Accrued compensation |  |  | 2,861 |  |  |  | 3,608 |  |
| Deferred revenue |  |  | 15,615 |  |  |  | 16,249 |  |
| Other current liabilities |  |  | 5,610 |  |  |  | 5,643 |  |
| Total current liabilities |  |  | 40,542 |  |  |  | 40,584 |  |
| Long-term debt |  |  | 19,623 |  |  |  | 19,621 |  |
| Income taxes payable |  |  | 3,367 |  |  |  | 3,985 |  |
| Deferred revenue |  |  | 11,887 |  |  |  | 12,226 |  |
| Other long-term liabilities |  |  | 2,637 |  |  |  | 2,540 |  |
| Total liabilities |  |  | 78,056 |  |  |  | 78,956 |  |
| Total equity |  |  | 45,277 |  |  |  | 45,457 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 123,333 |  |  | $ | 124,413 |  |

[0001193125-24-257224:8k_2_02:101]
7

[0001193125-24-257224:8k_2_02:102]
CISCO SYSTEMS, INC.

[0001193125-24-257224:8k_2_02:103]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-24-257224:8k_2_02:104]
(In millions)

[0001193125-24-257224:8k_2_02:105]
(Unaudited)

[0001193125-24-257224:8k_2_02:106]
|  |  | Three Months Ended |  |
|  |  | October 26,2024 |  |  | October 28,2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 2,711 |  |  | $ | 3,638 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 789 |  |  |  | 401 |  |
| Share-based compensation expense |  |  | 827 |  |  |  | 661 |  |
| Provision (benefit) for receivables |  |  | (1 | ) |  |  | 4 |  |
| Deferred income taxes |  |  | (281 | ) |  |  | (513 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (60 | ) |  |  | 89 |  |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 2,227 |  |  |  | 979 |  |
| Inventories |  |  | 229 |  |  |  | 307 |  |
| Financing receivables |  |  | 173 |  |  |  | 25 |  |
| Other assets |  |  | (190 | ) |  |  | (290 | ) |
| Accounts payable |  |  | (269 | ) |  |  | (235 | ) |
| Income taxes, net |  |  | (806 | ) |  |  | (1,773 | ) |
| Accrued compensation |  |  | (754 | ) |  |  | (908 | ) |
| Deferred revenue |  |  | (971 | ) |  |  | 259 |  |
| Other liabilities |  |  | 37 |  |  |  | (273 | ) |
| Net cash provided by operating activities |  |  | 3,661 |  |  |  | 2,371 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (1,775 | ) |  |  | (1,850 | ) |
| Proceeds from sales of investments |  |  | 1,490 |  |  |  | 1,280 |  |
| Proceeds from maturities of investments |  |  | 1,164 |  |  |  | 2,497 |  |
| Acquisitions, net of cash and cash equivalents acquired and divestitures |  |  | (217 | ) |  |  | (876 | ) |
| Purchases of investments in privately held companies |  |  | (42 | ) |  |  | (13 | ) |
| Return of investments in privately held companies |  |  | 77 |  |  |  | 47 |  |
| Acquisition of property and equipment |  |  | (217 | ) |  |  | (134 | ) |
| Other |  |  | (1 | ) |  |  | 1 |  |
| Net cash provided by investing activities |  |  | 479 |  |  |  | 952 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Repurchases of common stock—repurchase program |  |  | (2,003 | ) |  |  | (1,300 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (165 | ) |  |  | (153 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | 68 |  |  |  | — |  |
| Issuances of debt |  |  | 5,732 |  |  |  | — |  |
| Repayments of debt |  |  | (4,821 | ) |  |  | (750 | ) |
| Dividends paid |  |  | (1,592 | ) |  |  | (1,580 | ) |
| Other |  |  | (3 | ) |  |  | (17 | ) |
| Net cash used in financing activities |  |  | (2,784 | ) |  |  | (3,800 | ) |
| Effect of foreign currency exchange rate changes on cash, cash equivalents, restricted cash and restricted cash equivalents |  |  | 10 |  |  |  | (45 | ) |
| Net increase (decrease) in cash, cash equivalents, restricted cash and restricted cash equivalents |  |  | 1,366 |  |  |  | (522 | ) |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, beginning of period |  |  | 8,842 |  |  |  | 11,627 |  |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, end of period |  | $ | 10,208 |  |  | $ | 11,105 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 545 |  |  | $ | 128 |  |
| Cash paid for income taxes, net |  | $ | 643 |  |  | $ | 3,090 |  |

[0001193125-24-257224:8k_2_02:107]
CISCO SYSTEMS, INC.

[0001193125-24-257224:8k_2_02:108]
REMAINING PERFORMANCE OBLIGATIONS

[0001193125-24-257224:8k_2_02:109]
(In millions, except percentages)

[0001193125-24-257224:8k_2_02:110]
|  |  | October 26, 2024 |  |  | July 27, 2024 |  |  | October 28, 2023 |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Product |  | $ | 19,882 |  |  |  | 24 | % |  | $ | 20,055 |  |  |  | 27 | % |  | $ | 16,011 |  |  |  | 14 | % |
| Services |  |  | 20,108 |  |  |  | 7 | % |  |  | 20,993 |  |  |  | 10 | % |  |  | 18,742 |  |  |  | 11 | % |
| Total |  | $ | 39,990 |  |  |  | 15 | % |  | $ | 41,048 |  |  |  | 18 | % |  | $ | 34,753 |  |  |  | 12 | % |

[0001193125-24-257224:8k_2_02:111]
We expect 51% of total RPO at October 26, 2024 will be recognized as revenue over the next 12 months.

[0001193125-24-257224:8k_2_02:112]
CISCO SYSTEMS, INC.

[0001193125-24-257224:8k_2_02:113]
DEFERRED REVENUE

[0001193125-24-257224:8k_2_02:114]
(In
millions)

[0001193125-24-257224:8k_2_02:115]
|  |  | October 26, 2024 |  |  | July 27, 2024 |  |  | October 28, 2023 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 12,941 |  |  | $ | 13,219 |  |  | $ | 11,689 |  |
| Services |  |  | 14,561 |  |  |  | 15,256 |  |  |  | 13,970 |  |
| Total |  | $ | 27,502 |  |  | $ | 28,475 |  |  | $ | 25,659 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 15,615 |  |  | $ | 16,249 |  |  | $ | 13,812 |  |
| Noncurrent |  |  | 11,887 |  |  |  | 12,226 |  |  |  | 11,847 |  |
| Total |  | $ | 27,502 |  |  | $ | 28,475 |  |  | $ | 25,659 |  |

[0001193125-24-257224:8k_2_02:116]
CISCO SYSTEMS, INC.

[0001193125-24-257224:8k_2_02:117]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-24-257224:8k_2_02:118]
(In millions, except per-share amounts)

[0001193125-24-257224:8k_2_02:119]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2025 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| October 26, 2024 |  | $ | 0.40 |  |  | $ | 1,592 |  |  |  | 40 |  |  | $ | 49.56 |  |  | $ | 2,003 |  |  | $ | 3,595 |  |
| Fiscal 2024 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 27, 2024 |  | $ | 0.40 |  |  | $ | 1,606 |  |  |  | 43 |  |  | $ | 46.80 |  |  | $ | 2,002 |  |  | $ | 3,608 |  |
| April 27, 2024 |  | $ | 0.40 |  |  | $ | 1,615 |  |  |  | 26 |  |  | $ | 49.22 |  |  | $ | 1,256 |  |  | $ | 2,871 |  |
| January 27, 2024 |  | $ | 0.39 |  |  | $ | 1,583 |  |  |  | 25 |  |  | $ | 49.54 |  |  | $ | 1,254 |  |  | $ | 2,837 |  |
| October 28, 2023 |  | $ | 0.39 |  |  | $ | 1,580 |  |  |  | 23 |  |  | $ | 54.53 |  |  | $ | 1,252 |  |  | $ | 2,832 |  |

[0001193125-24-257224:8k_2_02:120]
9

[0001193125-24-257224:8k_2_02:121]
CISCO SYSTEMS, INC.

[0001193125-24-257224:8k_2_02:122]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-24-257224:8k_2_02:123]
GAAP TO NON-GAAP NET INCOME

[0001193125-24-257224:8k_2_02:124]
(In millions)

[0001193125-24-257224:8k_2_02:125]
|  |  | Three Months Ended |  |
|  |  | October 26,2024 |  |  | October 28,2023 |  |
| GAAP net income |  | $ | 2,711 |  |  | $ | 3,638 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 131 |  |  |  | 103 |  |
| Amortization of acquisition-related intangible assets |  |  | 319 |  |  |  | 181 |  |
| Acquisition/divestiture-related costs |  |  | 19 |  |  |  | — |  |
| Total adjustments to GAAP cost of sales |  |  | 469 |  |  |  | 284 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 679 |  |  |  | 550 |  |
| Amortization of acquisition-related intangible assets |  |  | 265 |  |  |  | 67 |  |
| Acquisition/divestiture-related costs |  |  | 285 |  |  |  | 75 |  |
| Russia-Ukraine war costs |  |  | — |  |  |  | (2 | ) |
| Significant asset impairments and restructurings |  |  | 665 |  |  |  | 123 |  |
| Total adjustments to GAAP operating expenses |  |  | 1,894 |  |  |  | 813 |  |
| Adjustments to interest and other income (loss), net: |  |  |  |  |  |  |  |  |
| (Gains) and losses on investments |  |  | (98 | ) |  |  | 51 |  |
| Total adjustments to GAAP interest and other income (loss), net |  |  | (98 | ) |  |  | 51 |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 2,265 |  |  |  | 1,148 |  |
| Income tax effect of non-GAAP adjustments |  |  | (476 | ) |  |  | (258 | ) |
| Significant tax matters (1) |  |  | (829 | ) |  |  | — |  |
| Total adjustments to GAAP provision for income taxes |  |  | (1,305 | ) |  |  | (258 | ) |
| Non-GAAP net income |  | $ | 3,671 |  |  | $ | 4,528 |  |

[0001193125-24-257224:8k_2_02:126]
| (1) | The three months ended October 26, 2024 include a $720 million benefit due to a recent U.S. Tax Court decision regarding the U.S. taxation of deemed foreign dividends in the transition year of the Tax Cuts and Jobs Act. |

[0001193125-24-257224:8k_2_02:127]
10

[0001193125-24-257224:8k_2_02:128]
CISCO SYSTEMS, INC.

[0001193125-24-257224:8k_2_02:129]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-24-257224:8k_2_02:130]
GAAP TO NON-GAAP EPS

[0001193125-24-257224:8k_2_02:131]
|  |  | Three Months Ended |  |
|  |  | October 26,2024 |  |  | October 28,2023 |  |
| GAAP EPS |  | $ | 0.68 |  |  | $ | 0.89 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.20 |  |  |  | 0.16 |  |
| Amortization of acquisition-related intangible assets |  |  | 0.15 |  |  |  | 0.06 |  |
| Acquisition/divestiture-related costs |  |  | 0.08 |  |  |  | 0.02 |  |
| Significant asset impairments and restructurings |  |  | 0.17 |  |  |  | 0.03 |  |
| (Gains) and losses on investments |  |  | (0.02 | ) |  |  | 0.01 |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.12 | ) |  |  | (0.06 | ) |
| Significant tax matters |  |  | (0.21 | ) |  |  | — |  |
| Non-GAAP EPS |  | $ | 0.91 |  |  | $ | 1.11 |  |

[0001193125-24-257224:8k_2_02:132]
Amounts may not sum due to rounding.

[0001193125-24-257224:8k_2_02:133]
11

[0001193125-24-257224:8k_2_02:134]
CISCO SYSTEMS, INC.

[0001193125-24-257224:8k_2_02:135]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-24-257224:8k_2_02:136]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET,

[0001193125-24-257224:8k_2_02:137]
AND NET INCOME

[0001193125-24-257224:8k_2_02:138]
(In
millions, except percentages)

[0001193125-24-257224:8k_2_02:139]
|  |  | Three Months Ended |  |
|  |  | October 26, 2024 |  |
|  |  | ProductGrossMargin |  |  | ServicesGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 6,588 |  |  | $ | 2,533 |  |  | $ | 9,121 |  |  | $ | 6,763 |  |  |  | 28 | % |  | $ | 2,358 |  |  |  | (45 | )% |  | $ | (91 | ) |  | $ | 2,711 |  |  |  | (25 | )% |
| % of revenue |  |  | 65.1 | % |  |  | 68.0 | % |  |  | 65.9 | % |  |  | 48.9 | % |  |  |  |  |  |  | 17.0 | % |  |  |  |  |  |  | (0.7 | )% |  |  | 19.6 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 57 |  |  |  | 74 |  |  |  | 131 |  |  |  | 679 |  |  |  |  |  |  |  | 810 |  |  |  |  |  |  |  | — |  |  |  | 810 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 319 |  |  |  | — |  |  |  | 319 |  |  |  | 265 |  |  |  |  |  |  |  | 584 |  |  |  |  |  |  |  | — |  |  |  | 584 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 5 |  |  |  | 14 |  |  |  | 19 |  |  |  | 285 |  |  |  |  |  |  |  | 304 |  |  |  |  |  |  |  | — |  |  |  | 304 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 665 |  |  |  |  |  |  |  | 665 |  |  |  |  |  |  |  | — |  |  |  | 665 |  |  |  |  |  |
| (Gains) and losses on investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (98 | ) |  |  | (98 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (1,305 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 6,969 |  |  | $ | 2,621 |  |  | $ | 9,590 |  |  | $ | 4,869 |  |  |  | 9 | % |  | $ | 4,721 |  |  |  | (12 | )% |  | $ | (189 | ) |  | $ | 3,671 |  |  |  | (19 | )% |
| % of revenue |  |  | 68.9 | % |  |  | 70.3 | % |  |  | 69.3 | % |  |  | 35.2 | % |  |  |  |  |  |  | 34.1 | % |  |  |  |  |  |  | (1.4 | )% |  |  | 26.5 | % |  |  |  |  |

[0001193125-24-257224:8k_2_02:140]
|  |  | Three Months Ended |  |
|  |  | October 28, 2023 |  |
|  |  | ProductGrossMargin |  |  | ServicesGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |
| GAAP amount |  | $ | 7,182 |  |  | $ | 2,375 |  |  | $ | 9,557 |  |  | $ | 5,281 |  |  | $ | 4,276 |  |  | $ | 166 |  |  | $ | 3,638 |  |
| % of revenue |  |  | 64.5 | % |  |  | 67.3 | % |  |  | 65.2 | % |  |  | 36.0 | % |  |  | 29.2 | % |  |  | 1.1 | % |  |  | 24.8 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 42 |  |  |  | 61 |  |  |  | 103 |  |  |  | 550 |  |  |  | 653 |  |  |  | — |  |  |  | 653 |  |
| Amortization of acquisition-related intangible assets |  |  | 181 |  |  |  | — |  |  |  | 181 |  |  |  | 67 |  |  |  | 248 |  |  |  | — |  |  |  | 248 |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 75 |  |  |  | 75 |  |  |  | — |  |  |  | 75 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 123 |  |  |  | 123 |  |  |  | — |  |  |  | 123 |  |
| Russia-Ukraine war costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  | (2 | ) |  |  | — |  |  |  | (2 | ) |
| (Gains) and losses on investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 51 |  |  |  | 51 |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (258 | ) |
| Non-GAAP amount |  | $ | 7,405 |  |  | $ | 2,436 |  |  | $ | 9,841 |  |  | $ | 4,468 |  |  | $ | 5,373 |  |  | $ | 217 |  |  | $ | 4,528 |  |
| % of revenue |  |  | 66.5 | % |  |  | 69.0 | % |  |  | 67.1 | % |  |  | 30.5 | % |  |  | 36.6 | % |  |  | 1.5 | % |  |  | 30.9 | % |

[0001193125-24-257224:8k_2_02:141]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-24-257224:8k_2_02:142]
12

[0001193125-24-257224:8k_2_02:143]
CISCO SYSTEMS, INC.

[0001193125-24-257224:8k_2_02:144]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-24-257224:8k_2_02:145]
EFFECTIVE TAX RATE

[0001193125-24-257224:8k_2_02:146]
(In
percentages)

[0001193125-24-257224:8k_2_02:147]
|  |  | Three Months Ended |  |
|  |  | October 26,2024 |  |  | October 28,2023 |  |
| GAAP effective tax rate |  |  | (19.6 | )% |  |  | 18.1 | % |
| Total adjustments to GAAP provision for income taxes |  |  | 38.6 | % |  |  | 0.9 | % |
| Non-GAAP effective tax rate |  |  | 19.0 | % |  |  | 19.0 | % |

[0001193125-24-257224:8k_2_02:148]
GAAP TO NON-GAAP GUIDANCE

[0001193125-24-257224:8k_2_02:149]
| Q2 FY 2025 |  | Gross MarginRate |  |  | Operating MarginRate |  |  | Earnings perShare (1) |  |
| GAAP |  |  | 64.5% - 65.5% |  |  |  | 20% - 21% |  |  |  | $0.51 - $0.56 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 1.0% |  |  |  | 7.0% |  |  |  | $0.18 - $0.19 |  |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  |  | 2.5% |  |  |  | 6.0% |  |  |  | $0.16 - $0.17 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | 0.5% |  |  |  | $0.01 - $0.02 |  |
| Non-GAAP |  |  | 68% - 69% |  |  |  | 33.5% - 34.5% |  |  |  | $0.89 - $0.91 |  |

[0001193125-24-257224:8k_2_02:150]
| FY 2025 |  | Earnings perShare (1) |  |
| GAAP |  |  | $2.26 - $2.38 |  |
| Estimated adjustments for: |  |  |  |  |
| Share-based compensation expense |  |  | $0.73 - $0.75 |  |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  |  | $0.60 - $0.62 |  |
| Significant asset impairments and restructurings |  |  | $0.18 - $0.20 |  |
| (Gains) and losses on investments |  |  | ($0.02) |  |
| Significant tax matters |  |  | ($0.21) |  |
| Non-GAAP |  |  | $3.60 - $3.66 |  |

[0001193125-24-257224:8k_2_02:151]
| (1) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-24-257224:8k_2_02:152]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, significant asset impairments and restructurings,
significant litigation settlements and other contingencies, gains and losses on investments, significant tax matters, or other items, which may or may not be significant.

[0001193125-24-257224:8k_2_02:153]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-24-257224:8k_2_02:154]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax rates,
non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross
margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-24-257224:8k_2_02:155]
These
non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles (GAAP) and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used
to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-24-257224:8k_2_02:156]
14

[0001193125-24-257224:8k_2_02:157]
Cisco believes that the presentation of non-GAAP measures when shown
in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-24-257224:8k_2_02:158]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, acquisition/divestiture-related costs, significant asset impairments and restructurings, significant litigation settlements and other contingencies, Russia-Ukraine war costs, gains and losses on
investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing
the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be other
items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP
financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-24-257224:8k_2_02:159]
Annualized recurring revenue represents the annualized revenue run-rate of active subscriptions, term licenses,
operating leases and maintenance contracts at the end of a reporting period, net of rebates to customers and partners as well as certain other revenue adjustments. Includes both revenue recognized ratably as well as upfront on an annualized basis.

[0001193125-24-257224:8k_2_02:160]
About Cisco

[0001193125-24-257224:8k_2_02:161]
Cisco (Nasdaq: CSCO) is the worldwide
technology leader that securely connects everything to make anything possible. Our purpose is to power an inclusive future for all by helping our customers reimagine their applications, power hybrid work, secure their enterprise, transform their
infrastructure, and meet their sustainability goals. Discover more at newsroom.cisco.com and follow us on X at @Cisco.

[0001193125-24-257224:8k_2_02:162]
Copyright © 2024 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a
list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any
other company. This document is Cisco Public Information.

[0001193125-24-257224:8k_2_02:163]
RSS Feed for
Cisco: https://newsroom.cisco.com/rss-feeds

[0001193125-24-257224:8k_2_02:164]
15
