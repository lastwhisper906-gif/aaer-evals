# CSCO note change history — 0000858877-24-000007 → 0000858877-24-000030


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-11-19):
[0000858877-24-000030:note_history:1]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments are directly with suppliers, and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.
  (was, 2024-05-21, similarity 0.9437):
[0000858877-24-000007:note_history:1]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

- changed (2024-11-19):
[0000858877-24-000030:note_history:2]
|  | October 26,2024 |  | July 27,2024 |
| Less than 1 year | $ | 4,309 |  |  | $ | 3,952 |  |
| 1 to 3 years | 886 |  |  | 1,085 |  |
| 3 to 5 years | 126 |  |  | 121 |  |
| Total | $ | 5,321 |  |  | $ | 5,158 |  |
  (was, 2024-05-21, similarity 0.9691):
[0000858877-24-000007:note_history:2]
|  | April 27,2024 |  | July 29,2023 |
| Less than 1 year | $ | 4,581 |  |  | $ | 5,270 |  |
| 1 to 3 years | 1,368 |  |  | 1,783 |  |
| 3 to 5 years | 55 |  |  | 200 |  |
| Total | $ | 6,004 |  |  | $ | 7,253 |  |

- changed (2024-11-19):
[0000858877-24-000030:note_history:3]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 26, 2024 and July 27, 2024, the liability for these purchase commitments was $439 million and $498 million, respectively, and was included in other current liabilities.
  (was, 2024-05-21, similarity 0.984):
[0000858877-24-000007:note_history:3]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 27, 2024 and July 29, 2023, the liability for these purchase commitments was $550 million and $529 million, respectively, and was included in other current liabilities.

- changed (2024-11-19):
[0000858877-24-000030:note_history:4]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.3 billion and $0.2 billion as of October 26, 2024 and July 27, 2024, respectively.
  (was, 2024-05-21, similarity 0.9734):
[0000858877-24-000007:note_history:4]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.2 billion and $0.3 billion as of April 27, 2024 and July 29, 2023, respectively.

- changed (2024-11-19):
[0000858877-24-000030:note_history:5]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |
| Balance at beginning of period | $ | 362 |  |  | $ | 329 |  |
| Provisions for warranties issued | 105 |  |  | 98 |  |
| Adjustments for pre-existing warranties | 1 |  |  | 3 |  |
| Settlements | (111) |  |  | (100) |  |
| Balance at end of period | $ | 357 |  |  | $ | 330 |  |
  (was, 2024-05-21, similarity 0.8628):
[0000858877-24-000007:note_history:5]
|  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |
| Balance at beginning of period | $ | 329 |  |  | $ | 333 |  |
| Provisions for warranties issued | 316 |  |  | 285 |  |
| Adjustments for pre-existing warranties | 20 |  |  | 15 |  |
| Settlements | (302) |  |  | (321) |  |
| Balance at end of period | $ | 363 |  |  | $ | 312 |  |

- changed (2024-11-19):
[0000858877-24-000030:note_history:6]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.0 billion and $8.2 billion for the first quarter of fiscal 2025 and 2024, respectively. The balance of the channel partner financing subject to guarantees was $1.1 billion and $1.2 billion as of October 26, 2024 and July 27, 2024, respectively.
  (was, 2024-05-21, similarity 0.9206):
[0000858877-24-000007:note_history:6]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.1 billion and $8.3 billion for the third quarter of fiscal 2024 and 2023, respectively, and $20.9 billion and $23.4 billion for the first nine months of fiscal 2024 and 2023, respectively. The balance of the channel partner financing subject to guarantees was $1.1 billion and $1.7 billion as of April 27, 2024 and July 29, 2023, respectively.

- changed (2024-11-19):
[0000858877-24-000030:note_history:7]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at October 26, 2024 and July 27, 2024, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2024-05-21, similarity 0.9817):
[0000858877-24-000007:note_history:7]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at April 27, 2024 and July 29, 2023, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2024-11-19):
[0000858877-24-000030:note_history:8]
|  | October 26,2024 |  | July 27,2024 |
| Maximum potential future payments | $ | 123 |  |  | $ | 127 |  |
| Deferred revenue | (12) |  |  | (13) |  |
| Total | $ | 111 |  |  | $ | 114 |  |
  (was, 2024-05-21, similarity 0.9679):
[0000858877-24-000007:note_history:8]
|  | April 27,2024 |  | July 29,2023 |
| Maximum potential future payments | $ | 126 |  |  | $ | 159 |  |
| Deferred revenue | (25) |  |  | (34) |  |
| Total | $ | 101 |  |  | $ | 125 |  |

- changed (2024-11-19):
[0000858877-24-000030:note_history:9]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $142 million for the alleged evasion of import and other taxes, $839 million for interest, and $323 million for various penalties, all determined using an exchange rate as of October 26, 2024.
  (was, 2024-05-21, similarity 0.995):
[0000858877-24-000007:note_history:9]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $157 million for the alleged evasion of import and other taxes, $902 million for interest, and $357 million for various penalties, all determined using an exchange rate as of April 27, 2024.

- changed (2024-11-19):
[0000858877-24-000030:note_history:10]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. After two bench trials and various administrative actions and appeals, we have been found either to not have infringed any of the patents or the patents have been invalidated. Centripetal has appealed one of the invalidity decisions and the non-infringement judgment of the District Court, and both of those proceedings are ongoing.
  (was, 2024-05-21, similarity 0.8466):
[0000858877-24-000007:note_history:10]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. After two bench trials and various administrative actions and appeals, we have been found either to not have infringed any of the patents or the patents have been invalidated. There is an appeal of one of the invalidity decisions and we expect a further appeal by Centripetal.

- changed (2024-11-19):
[0000858877-24-000030:note_history:11]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringed three patents, one patent was invalidated, the utility model was invalidated, and the infringement action on the final patent is stayed due to an invalidity action heard on June 6, 2024 in the Federal Patent Court, in which all claims, aside from one auxiliary claim, were found invalid, for which we are awaiting the entry of judgment from the Federal Patent Court. Centripetal’s appeals of two of the non-infringement findings remain pending and, on March 27, 2024, the Court of Appeals rejected Centripetal’s appeal of the third non-infringement finding.
  (was, 2024-05-21, similarity 0.6311):
[0000858877-24-000007:note_history:11]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringed three patents, one patent was invalidated, the utility model was invalidated, and the infringement action on the final patent is stayed due to a pending invalidity action, which has a hearing set for June 6, 2024. Centripetal’s appeals of two of the non-infringement findings remain pending and, on March 27, 2024, the Court of Appeals rejected Centripetal’s appeal of the third non-infringement finding.

- changed (2024-11-19):
[0000858877-24-000030:note_history:12]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement. We have filed our response and defenses to the complaint and we anticipate that on December 5, 2024, the Court will set a schedule for the remainder of the proceedings.
  (was, 2024-05-21, similarity 0.8181):
[0000858877-24-000007:note_history:12]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement. We

- changed (2024-11-19):
[0000858877-24-000030:note_history:13]
Ramot     On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents and those proceedings are ongoing. The Court set trial in the D. Del. cases for November 3, 2025.
  (was, 2024-05-21, similarity 0.9644):
[0000858877-24-000007:note_history:13]
Ramot     On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents and those proceedings are ongoing.

- changed (2024-11-19):
[0000858877-24-000030:note_history:14]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023. The Federal Circuit heard oral argument on October 11, 2024 and we are awaiting the decision.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.
  (was, 2024-05-21, similarity 0.6988):
[0000858877-24-000007:note_history:14]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023, the appeal is fully briefed and we are awaiting a hearing date from the Federal Circuit.

- removed (2024-11-19):
[0000858877-24-000007:note_history:15]
have filed our response and defenses to the complaint and, on May 24, 2024, we expect the Paris Judiciary Court to decide our motion to dismiss and, if denied, it will set the schedule for the remainder of the proceedings.

- removed (2024-11-19):
[0000858877-24-000007:note_history:16]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward. On June 9, 2020, Viasat filed another suit in SDSC alleging contract and trade secret claims for sales of additional Acacia products. Both matters have been formally dismissed and resolved during fiscal 2024 through a settlement for an amount that did not have a material effect on our Consolidated Financial Statements.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-11-19):
[0000858877-24-000030:note_history:17]
Purchase Commitments with Contract Manufacturers and Suppliers We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments are directly with suppliers, and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.
  (was, 2024-05-21, similarity 0.9559):
[0000858877-24-000007:note_history:17]
Purchase Commitments with Contract Manufacturers and Suppliers We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-11-19):
[0000858877-24-000030:note_history:18]
We have prepared the accompanying financial data as of October 26, 2024 and for the first quarter of fiscal 2025 and 2024, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2024 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2024.
  (was, 2024-05-21, similarity 0.9779):
[0000858877-24-000007:note_history:18]
We have prepared the accompanying financial data as of April 27, 2024 and for the third quarter and first nine months of fiscal 2024 and 2023, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 29, 2023 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 29, 2023.

- added (2024-11-19):
[0000858877-24-000030:note_history:19]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of October 26, 2024, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2025 and 2024, as applicable, have been made. The results of operations for the first quarter of fiscal 2025 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2024-11-19):
[0000858877-24-000007:note_history:20]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of April 27, 2024, the results of operations, the statements of comprehensive income and the statements of equity for the third quarter and first nine months of fiscal 2024 and 2023, and the statements of cash flows for the first nine months of fiscal 2024 and 2023, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2024 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-11-19):
[0000858877-24-000030:note_history:21]
Disaggregation of Income Statement Expenses     In November 2024, the FASB issued an accounting standard update expanding the disclosure requirements about specific expense categories, primarily through disaggregated information on income statement line items. The accounting standard update will be effective for our fiscal 2028 Form 10-K, and early adoption is permitted. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-11-19):
[0000858877-24-000030:note_history:22]
|  | October 26, 2024 |  | July 27, 2024 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 493 |  |  | 6.17 | % |  | $ | 488 |  |  | 6.66 | % |
| Commercial paper | 11,870 |  |  | 5.19 | % |  | 10,853 |  |  | 5.43 | % |
| Current portion of other debt | 1 |  |  | 1.13 | % |  | — |  |  | — |  |
| Total | $ | 12,364 |  |  |  |  | $ | 11,341 |  |  |  |

- changed (2024-11-19):
[0000858877-24-000030:note_history:23]
|  |  |  | October 26, 2024 |  | July 27, 2024 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | 6.17% |  | $ | 500 |  |  | 6.66% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 3 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 20,253 |  |  |  |  | 20,253 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (129) |  |  |  |  | (133) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (7) |  |  |  |  | (11) |  |  |  |
| Total |  |  | $ | 20,117 |  |  |  |  | $ | 20,109 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 494 |  |  |  |  | $ | 488 |  |  |  |
| Long-term debt |  |  | 19,623 |  |  |  |  | 19,621 |  |  |  |
| Total |  |  | $ | 20,117 |  |  |  |  | $ | 20,109 |  |  |  |
  (was, 2024-05-21, similarity 0.7901):
[0000858877-24-000007:note_history:23]
|  |  |  | April 27, 2024 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | — |  |  | — |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.64% |  | 500 |  |  | 6.38% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | — |  |  | — |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | — |  |  | — |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | — |  |  | — |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | — |  |  | — |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | — |  |  | — |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | — |  |  | — |
| Other long-term debt |  |  | 3 |  |  | 1.13% |  | — |  |  | — |
| Total |  |  | 20,253 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (135) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (16) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 20,102 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | — |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 20,102 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 20,102 |  |  |  |  | $ | 8,391 |  |  |  |

- changed (2024-11-19):
[0000858877-24-000030:note_history:24]
We entered into an interest rate swap in a prior period with an aggregate notional amount of $0.5 billion designated as a fair value hedge of certain of our fixed-rate senior notes. This swap converts the fixed interest rate of the fixed-rate note to a floating interest rate based on Secured Overnight Financing Rate (SOFR). The gain and loss related to the change in the fair value of the interest rate swap substantially offsets the change in the fair value of the hedged portion of the underlying debt that is attributable to the change in market interest rates. For additional information, see Note 13.
  (was, 2024-05-21, similarity 0.8593):
[0000858877-24-000007:note_history:24]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $0.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on Secured Overnight Financing Rate (SOFR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

- changed (2024-11-19):
[0000858877-24-000030:note_history:25]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 26, 2024, we were in compliance with all debt covenants.
  (was, 2024-05-21, similarity 0.9859):
[0000858877-24-000007:note_history:25]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 27, 2024, we were in compliance with all debt covenants.

- changed (2024-11-19):
[0000858877-24-000030:note_history:26]
As of October 26, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2024-05-21, similarity 0.9627):
[0000858877-24-000007:note_history:26]
As of April 27, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2024-11-19):
[0000858877-24-000030:note_history:27]
| Fiscal Year | Amount |
| 2025 (remaining nine months) | $ | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | — |  |
| 2029 | 2,500 |  |
| Thereafter | 12,000 |  |
| Total | $ | 20,253 |  |
  (was, 2024-05-21, similarity 0.899):
[0000858877-24-000007:note_history:27]
| Fiscal Year | Amount |
| 2024 (remaining three months) | $ | — |  |
| 2025 | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | — |  |
| Thereafter | 14,500 |  |
| Total | $ | 20,253 |  |

- changed (2024-11-19):
[0000858877-24-000030:note_history:28]
On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of October 26, 2024, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.
  (was, 2024-05-21, similarity 0.749):
[0000858877-24-000007:note_history:28]
On May 13, 2021, we entered into a 5-year $3.0 billion unsecured revolving credit agreement, as amended on April 18, 2023. On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of April 27, 2024, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.

- removed (2024-11-19):
[0000858877-24-000007:note_history:29]
|  | April 27, 2024 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | — |  |  | — |  |  | $ | 1,733 |  |  | 4.45 | % |
| Commercial paper | 11,891 |  |  | 5.42 | % |  | — |  |  | — |  |
| Total | $ | 11,891 |  |  |  |  | $ | 1,733 |  |  |  |

- removed (2024-11-19):
[0000858877-24-000007:note_history:30]
In February 2024, we issued senior notes for an aggregate principal amount of $13.5 billion.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-19):
[0000858877-24-000030:note_history:31]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 26, 2024 and July 27, 2024 (in millions):
  (was, 2024-05-21, similarity 0.9716):
[0000858877-24-000007:note_history:31]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 27, 2024 and July 29, 2023 (in millions):

- changed (2024-11-19):
[0000858877-24-000030:note_history:32]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 26, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,134 |  |  | $ | (11) |  |  | $ | 634 |  |  | $ | (13) |  |  | $ | 1,768 |  |  | $ | (24) |  |
| U.S. government agency securities | 37 |  |  | — |  |  | 60 |  |  | (1) |  |  | 97 |  |  | (1) |  |
| Non-U.S. government and agency securities | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |
| Corporate debt securities | 221 |  |  | (1) |  |  | 2,402 |  |  | (76) |  |  | 2,623 |  |  | (77) |  |
| U.S. agency mortgage-backed securities | 7 |  |  | — |  |  | 896 |  |  | (133) |  |  | 903 |  |  | (133) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 1,435 |  |  | $ | (12) |  |  | $ | 3,992 |  |  | $ | (223) |  |  | $ | 5,427 |  |  | $ | (235) |  |
  (was, 2024-05-21, similarity 0.9882):
[0000858877-24-000007:note_history:32]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,740 |  |  | $ | (25) |  |  | $ | 570 |  |  | $ | (24) |  |  | $ | 2,310 |  |  | $ | (49) |  |
| U.S. government agency securities | 175 |  |  | (1) |  |  | 65 |  |  | (2) |  |  | 240 |  |  | (3) |  |
| Non-U.S. government and agency securities | 239 |  |  | — |  |  | — |  |  | — |  |  | 239 |  |  | — |  |
| Corporate debt securities | 629 |  |  | (7) |  |  | 2,967 |  |  | (161) |  |  | 3,596 |  |  | (168) |  |
| U.S. agency mortgage-backed securities | 486 |  |  | (13) |  |  | 1,344 |  |  | (215) |  |  | 1,830 |  |  | (228) |  |
| Commercial paper | 91 |  |  | — |  |  | — |  |  | — |  |  | 91 |  |  | — |  |
| Total | $ | 3,360 |  |  | $ | (46) |  |  | $ | 4,946 |  |  | $ | (402) |  |  | $ | 8,306 |  |  | $ | (448) |  |

- changed (2024-11-19):
[0000858877-24-000030:note_history:33]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 598 |  |  | $ | (2) |  |  | $ | 1,399 |  |  | $ | (26) |  |  | $ | 1,997 |  |  | $ | (28) |  |
| U.S. government agency securities | 89 |  |  | — |  |  | 109 |  |  | (2) |  |  | 198 |  |  | (2) |  |
| Non-U.S. government and agency securities | 17 |  |  | — |  |  | — |  |  | — |  |  | 17 |  |  | — |  |
| Corporate debt securities | 276 |  |  | (1) |  |  | 2,818 |  |  | (115) |  |  | 3,094 |  |  | (116) |  |
| U.S. agency mortgage-backed securities | 238 |  |  | (1) |  |  | 1,438 |  |  | (177) |  |  | 1,676 |  |  | (178) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 1,228 |  |  | $ | (4) |  |  | $ | 5,764 |  |  | $ | (320) |  |  | $ | 6,992 |  |  | $ | (324) |  |
  (was, 2024-05-21, similarity 0.7333):
[0000858877-24-000007:note_history:33]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 2,394 |  |  | $ | (26) |  |  | $ | 931 |  |  | $ | (36) |  |  | $ | 3,325 |  |  | $ | (62) |  |
| U.S. government agency securities | 343 |  |  | (2) |  |  | 72 |  |  | (3) |  |  | 415 |  |  | (5) |  |
| Non-U.S. government and agency securities | 363 |  |  | (1) |  |  | — |  |  | — |  |  | 363 |  |  | (1) |  |
| Corporate debt securities | 1,736 |  |  | (22) |  |  | 4,315 |  |  | (275) |  |  | 6,051 |  |  | (297) |  |
| U.S. agency mortgage-backed securities | 658 |  |  | (13) |  |  | 1,438 |  |  | (217) |  |  | 2,096 |  |  | (230) |  |
| Commercial paper | 97 |  |  | — |  |  | — |  |  | — |  |  | 97 |  |  | — |  |
| Certificates of deposit | 2 |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |
| Total | $ | 5,593 |  |  | $ | (64) |  |  | $ | 6,756 |  |  | $ | (531) |  |  | $ | 12,349 |  |  | $ | (595) |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-19):
[0000858877-24-000030:note_history:34]
| October 26, 2024 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,390 |  |  | $ | 2 |  |  | $ | (24) |  |  | $ | 2,368 |  |
| U.S. government agency securities | 154 |  |  | — |  |  | (1) |  |  | 153 |  |
| Non-U.S. government and agency securities | 388 |  |  | 1 |  |  | — |  |  | 389 |  |
| Corporate debt securities | 3,610 |  |  | 9 |  |  | (107) |  |  | 3,512 |  |
| U.S. agency mortgage-backed securities | 1,038 |  |  | — |  |  | (133) |  |  | 905 |  |
| Commercial paper | 1,193 |  |  | — |  |  | — |  |  | 1,193 |  |
| Certificates of deposit | 674 |  |  | — |  |  | — |  |  | 674 |  |
| Total | $ | 9,447 |  |  | $ | 12 |  |  | $ | (265) |  |  | $ | 9,194 |  |
  (was, 2024-05-21, similarity 0.9874):
[0000858877-24-000007:note_history:34]
| April 27, 2024 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,411 |  |  | $ | — |  |  | $ | (49) |  |  | $ | 2,362 |  |
| U.S. government agency securities | 248 |  |  | — |  |  | (3) |  |  | 245 |  |
| Non-U.S. government and agency securities | 390 |  |  | — |  |  | — |  |  | 390 |  |
| Corporate debt securities | 3,985 |  |  | 1 |  |  | (198) |  |  | 3,788 |  |
| U.S. agency mortgage-backed securities | 2,058 |  |  | — |  |  | (228) |  |  | 1,830 |  |
| Commercial paper | 563 |  |  | — |  |  | — |  |  | 563 |  |
| Certificates of deposit | 229 |  |  | — |  |  | — |  |  | 229 |  |
| Total | $ | 9,884 |  |  | $ | 1 |  |  | $ | (478) |  |  | $ | 9,407 |  |

- changed (2024-11-19):
[0000858877-24-000030:note_history:35]
| July 27, 2024 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,380 |  |  | $ | 1 |  |  | $ | (28) |  |  | $ | 2,353 |  |
| U.S. government agency securities | 223 |  |  | — |  |  | (2) |  |  | 221 |  |
| Non-U.S. government and agency securities | 370 |  |  | 1 |  |  | — |  |  | 371 |  |
| Corporate debt securities | 3,818 |  |  | 5 |  |  | (146) |  |  | 3,677 |  |
| U.S. agency mortgage-backed securities | 1,959 |  |  | — |  |  | (178) |  |  | 1,781 |  |
| Commercial paper | 1,023 |  |  | — |  |  | — |  |  | 1,023 |  |
| Certificates of deposit | 439 |  |  | — |  |  | — |  |  | 439 |  |
| Total | $ | 10,212 |  |  | $ | 7 |  |  | $ | (354) |  |  | $ | 9,865 |  |
  (was, 2024-05-21, similarity 0.9843):
[0000858877-24-000007:note_history:35]
| July 29, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 3,587 |  |  | $ | 1 |  |  | $ | (62) |  |  | $ | 3,526 |  |
| U.S. government agency securities | 428 |  |  | — |  |  | (5) |  |  | 423 |  |
| Non-U.S. government and agency securities | 364 |  |  | — |  |  | (1) |  |  | 363 |  |
| Corporate debt securities | 7,238 |  |  | 3 |  |  | (327) |  |  | 6,914 |  |
| U.S. agency mortgage-backed securities | 2,421 |  |  | 14 |  |  | (230) |  |  | 2,205 |  |
| Commercial paper | 1,484 |  |  | — |  |  | — |  |  | 1,484 |  |
| Certificates of deposit | 677 |  |  | — |  |  | — |  |  | 677 |  |
| Total | $ | 16,199 |  |  | $ | 18 |  |  | $ | (625) |  |  | $ | 15,592 |  |

- added (2024-11-19):
[0000858877-24-000030:note_history:36]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Gross realized gains | $ | 8 |  |  | $ | — |  |
| Gross realized losses | (33) |  |  | (20) |  |
| Total | $ | (25) |  |  | $ | (20) |  |

- changed (2024-11-19):
[0000858877-24-000030:note_history:37]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 26, 2024 and July 27, 2024 (in millions):
  (was, 2024-05-21, similarity 0.9716):
[0000858877-24-000007:note_history:37]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 27, 2024 and July 29, 2023 (in millions):

- changed (2024-11-19):
[0000858877-24-000030:note_history:38]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 26, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,134 |  |  | $ | (11) |  |  | $ | 634 |  |  | $ | (13) |  |  | $ | 1,768 |  |  | $ | (24) |  |
| U.S. government agency securities | 37 |  |  | — |  |  | 60 |  |  | (1) |  |  | 97 |  |  | (1) |  |
| Non-U.S. government and agency securities | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |
| Corporate debt securities | 221 |  |  | (1) |  |  | 2,402 |  |  | (76) |  |  | 2,623 |  |  | (77) |  |
| U.S. agency mortgage-backed securities | 7 |  |  | — |  |  | 896 |  |  | (133) |  |  | 903 |  |  | (133) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 1,435 |  |  | $ | (12) |  |  | $ | 3,992 |  |  | $ | (223) |  |  | $ | 5,427 |  |  | $ | (235) |  |
  (was, 2024-05-21, similarity 0.9882):
[0000858877-24-000007:note_history:38]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,740 |  |  | $ | (25) |  |  | $ | 570 |  |  | $ | (24) |  |  | $ | 2,310 |  |  | $ | (49) |  |
| U.S. government agency securities | 175 |  |  | (1) |  |  | 65 |  |  | (2) |  |  | 240 |  |  | (3) |  |
| Non-U.S. government and agency securities | 239 |  |  | — |  |  | — |  |  | — |  |  | 239 |  |  | — |  |
| Corporate debt securities | 629 |  |  | (7) |  |  | 2,967 |  |  | (161) |  |  | 3,596 |  |  | (168) |  |
| U.S. agency mortgage-backed securities | 486 |  |  | (13) |  |  | 1,344 |  |  | (215) |  |  | 1,830 |  |  | (228) |  |
| Commercial paper | 91 |  |  | — |  |  | — |  |  | — |  |  | 91 |  |  | — |  |
| Total | $ | 3,360 |  |  | $ | (46) |  |  | $ | 4,946 |  |  | $ | (402) |  |  | $ | 8,306 |  |  | $ | (448) |  |

- changed (2024-11-19):
[0000858877-24-000030:note_history:39]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 598 |  |  | $ | (2) |  |  | $ | 1,399 |  |  | $ | (26) |  |  | $ | 1,997 |  |  | $ | (28) |  |
| U.S. government agency securities | 89 |  |  | — |  |  | 109 |  |  | (2) |  |  | 198 |  |  | (2) |  |
| Non-U.S. government and agency securities | 17 |  |  | — |  |  | — |  |  | — |  |  | 17 |  |  | — |  |
| Corporate debt securities | 276 |  |  | (1) |  |  | 2,818 |  |  | (115) |  |  | 3,094 |  |  | (116) |  |
| U.S. agency mortgage-backed securities | 238 |  |  | (1) |  |  | 1,438 |  |  | (177) |  |  | 1,676 |  |  | (178) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 1,228 |  |  | $ | (4) |  |  | $ | 5,764 |  |  | $ | (320) |  |  | $ | 6,992 |  |  | $ | (324) |  |
  (was, 2024-05-21, similarity 0.7333):
[0000858877-24-000007:note_history:39]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 2,394 |  |  | $ | (26) |  |  | $ | 931 |  |  | $ | (36) |  |  | $ | 3,325 |  |  | $ | (62) |  |
| U.S. government agency securities | 343 |  |  | (2) |  |  | 72 |  |  | (3) |  |  | 415 |  |  | (5) |  |
| Non-U.S. government and agency securities | 363 |  |  | (1) |  |  | — |  |  | — |  |  | 363 |  |  | (1) |  |
| Corporate debt securities | 1,736 |  |  | (22) |  |  | 4,315 |  |  | (275) |  |  | 6,051 |  |  | (297) |  |
| U.S. agency mortgage-backed securities | 658 |  |  | (13) |  |  | 1,438 |  |  | (217) |  |  | 2,096 |  |  | (230) |  |
| Commercial paper | 97 |  |  | — |  |  | — |  |  | — |  |  | 97 |  |  | — |  |
| Certificates of deposit | 2 |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |
| Total | $ | 5,593 |  |  | $ | (64) |  |  | $ | 6,756 |  |  | $ | (531) |  |  | $ | 12,349 |  |  | $ | (595) |  |

- changed (2024-11-19):
[0000858877-24-000030:note_history:40]
The following table summarizes the maturities of our available-for-sale debt investments as of October 26, 2024 (in millions):
  (was, 2024-05-21, similarity 0.9583):
[0000858877-24-000007:note_history:40]
The following table summarizes the maturities of our available-for-sale debt investments as of April 27, 2024 (in millions):

- added (2024-11-19):
[0000858877-24-000030:note_history:41]
We held marketable equity securities of $412 million and $481 million as of October 26, 2024 and July 27, 2024, respectively. We recognized a net unrealized gain of $25 million and a net unrealized loss of $42 million during the first quarter of fiscal 2025 and 2024, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $8 million for the first quarter of fiscal 2025. These adjustments were not material for the first quarter of 2024. We held equity interests in certain private equity funds of $0.8 billion as of each of October 26, 2024 and July 27, 2024, which are accounted for under the NAV practical expedient.

- changed (2024-11-19):
[0000858877-24-000030:note_history:42]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 26, 2024, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2024-05-21, similarity 0.8164):
[0000858877-24-000007:note_history:42]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 27, 2024, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- added (2024-11-19):
[0000858877-24-000030:note_history:43]
The carrying value of our investments in privately held companies was $1.8 billion as of each of October 26, 2024 and July 27, 2024. Of the total carrying value of our investments in privately held companies as of October 26, 2024, $0.8 billion of such investments are considered to be in variable interest entities which are not required to be consolidated. As of October 26, 2024, we have total funding commitments of $0.3 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.

- removed (2024-11-19):
[0000858877-24-000007:note_history:44]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2024 |  | April 29, 2023 |  | April 27, 2024 |  | April 29, 2023 |
| Gross realized gains | $ | 2 |  |  | $ | 1 |  |  | $ | 7 |  |  | $ | 4 |  |
| Gross realized losses | (16) |  |  | (7) |  |  | (64) |  |  | (19) |  |
| Total | $ | (14) |  |  | $ | (6) |  |  | $ | (57) |  |  | $ | (15) |  |

- removed (2024-11-19):
[0000858877-24-000007:note_history:45]
We held marketable equity securities of $450 million and $431 million as of April 27, 2024 and July 29, 2023, respectively. We recognized a net unrealized gain of $20 million and $40 million during the third quarter and first nine months of fiscal 2024, respectively, and a net unrealized loss of $2 million and $11 million during the corresponding periods of fiscal 2023, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $21 million and $155 million for the third quarter and first nine months of fiscal 2024, respectively, and a net gain of $7 million and a net loss of $2 million for the corresponding periods of fiscal 2023, respectively. We held equity interests in certain private equity funds of $0.8 billion and $0.9 billion as of April 27, 2024 and July 29, 2023, respectively, which are accounted for under the NAV practical expedient.

- removed (2024-11-19):
[0000858877-24-000007:note_history:46]
The carrying value of our investments in privately held companies was $1.6 billion and $1.8 billion as of April 27, 2024 and July 29, 2023, respectively. Of the total carrying value of our investments in privately held companies as of April 27, 2024, $0.9 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of April 27, 2024, we have total funding commitments of $0.2 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-19):
[0000858877-24-000030:note_history:47]
|  |  |  | October 26, 2024 |  | July 27, 2024 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | 6.17% |  | $ | 500 |  |  | 6.66% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 3 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 20,253 |  |  |  |  | 20,253 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (129) |  |  |  |  | (133) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (7) |  |  |  |  | (11) |  |  |  |
| Total |  |  | $ | 20,117 |  |  |  |  | $ | 20,109 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 494 |  |  |  |  | $ | 488 |  |  |  |
| Long-term debt |  |  | 19,623 |  |  |  |  | 19,621 |  |  |  |
| Total |  |  | $ | 20,117 |  |  |  |  | $ | 20,109 |  |  |  |
  (was, 2024-05-21, similarity 0.7901):
[0000858877-24-000007:note_history:47]
|  |  |  | April 27, 2024 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | — |  |  | — |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.64% |  | 500 |  |  | 6.38% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | — |  |  | — |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | — |  |  | — |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | — |  |  | — |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | — |  |  | — |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | — |  |  | — |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | — |  |  | — |
| Other long-term debt |  |  | 3 |  |  | 1.13% |  | — |  |  | — |
| Total |  |  | 20,253 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (135) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (16) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 20,102 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | — |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 20,102 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 20,102 |  |  |  |  | $ | 8,391 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-19):
[0000858877-24-000030:note_history:48]
As of October 26, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2024-05-21, similarity 0.9627):
[0000858877-24-000007:note_history:48]
As of April 27, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2024-11-19):
[0000858877-24-000030:note_history:49]
| Fiscal Year | Amount |
| 2025 (remaining nine months) | $ | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | — |  |
| 2029 | 2,500 |  |
| Thereafter | 12,000 |  |
| Total | $ | 20,253 |  |
  (was, 2024-05-21, similarity 0.899):
[0000858877-24-000007:note_history:49]
| Fiscal Year | Amount |
| 2024 (remaining three months) | $ | — |  |
| 2025 | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | — |  |
| Thereafter | 14,500 |  |
| Total | $ | 20,253 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-11-19):
[0000858877-24-000030:note_history:50]
|  | October 26, 2024 |  | July 27, 2024 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 493 |  |  | 6.17 | % |  | $ | 488 |  |  | 6.66 | % |
| Commercial paper | 11,870 |  |  | 5.19 | % |  | 10,853 |  |  | 5.43 | % |
| Current portion of other debt | 1 |  |  | 1.13 | % |  | — |  |  | — |  |
| Total | $ | 12,364 |  |  |  |  | $ | 11,341 |  |  |  |

- removed (2024-11-19):
[0000858877-24-000007:note_history:51]
|  | April 27, 2024 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | — |  |  | — |  |  | $ | 1,733 |  |  | 4.45 | % |
| Commercial paper | 11,891 |  |  | 5.42 | % |  | — |  |  | — |  |
| Total | $ | 11,891 |  |  |  |  | $ | 1,733 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-11-19):
[0000858877-24-000030:note_history:52]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |
| Product revenue: |  |  |  |
| Networking | $ | 6,753 |  |  | $ | 8,822 |  |
| Security | 2,017 |  |  | 1,010 |  |
| Collaboration | 1,085 |  |  | 1,117 |  |
| Observability | 258 |  |  | 190 |  |
| Total Product | 10,114 |  |  | 11,139 |  |
| Services | 3,727 |  |  | 3,529 |  |
| Total | $ | 13,841 |  |  | $ | 14,668 |  |
  (was, 2024-05-21, similarity 0.6375):
[0000858877-24-000007:note_history:52]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 6,522 |  |  | $ | 8,982 |  |  | $ | 22,425 |  |  | $ | 25,105 |  |
| Security | 1,304 |  |  | 958 |  |  | 3,288 |  |  | 2,872 |  |
| Collaboration | 987 |  |  | 985 |  |  | 3,093 |  |  | 3,029 |  |
| Observability | 211 |  |  | 167 |  |  | 589 |  |  | 486 |  |
| Total Product | 9,024 |  |  | 11,092 |  |  | 29,395 |  |  | 31,492 |  |
| Services | 3,678 |  |  | 3,479 |  |  | 10,766 |  |  | 10,303 |  |
| Total | $ | 12,702 |  |  | $ | 14,571 |  |  | $ | 40,161 |  |  | $ | 41,795 |  |

- added (2024-11-19):
[0000858877-24-000030:note_history:53]
Our subscription revenue is recorded in product and services revenue in our Consolidated Statements of Operations as follows (in millions):

- added (2024-11-19):
[0000858877-24-000030:note_history:54]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Product | $ | 4,419 |  |  | $ | 3,207 |  |
| Services | 3,425 |  |  | 3,254 |  |
| Total | $ | 7,844 |  |  | $ | 6,461 |  |

- changed (2024-11-19):
[0000858877-24-000030:note_history:55]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |
| Revenue: |  |  |  |
| Networking | $ | 6,753 |  |  | $ | 8,822 |  |
| Security | 2,017 |  |  | 1,010 |  |
| Collaboration | 1,085 |  |  | 1,117 |  |
| Observability | 258 |  |  | 190 |  |
| Total Product | 10,114 |  |  | 11,139 |  |
| Services | 3,727 |  |  | 3,529 |  |
| Total | $ | 13,841 |  |  | $ | 14,668 |  |
  (was, 2024-05-21, similarity 0.6299):
[0000858877-24-000007:note_history:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Revenue: |  |  |  |  |  |  |  |
| Networking | $ | 6,522 |  |  | $ | 8,982 |  |  | $ | 22,425 |  |  | $ | 25,105 |  |
| Security | 1,304 |  |  | 958 |  |  | 3,288 |  |  | 2,872 |  |
| Collaboration | 987 |  |  | 985 |  |  | 3,093 |  |  | 3,029 |  |
| Observability | 211 |  |  | 167 |  |  | 589 |  |  | 486 |  |
| Total Product | 9,024 |  |  | 11,092 |  |  | 29,395 |  |  | 31,492 |  |
| Services | 3,678 |  |  | 3,479 |  |  | 10,766 |  |  | 10,303 |  |
| Total | $ | 12,702 |  |  | $ | 14,571 |  |  | $ | 40,161 |  |  | $ | 41,795 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-11-19):
[0000858877-24-000030:note_history:56]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers. Revenue from subscription offers includes revenue recognized over time as well as upfront.
  (was, 2024-05-21, similarity 0.961):
[0000858877-24-000007:note_history:56]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

- changed (2024-11-19):
[0000858877-24-000030:note_history:57]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 26, 2024 and July 27, 2024 was $42 million and $37 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2024-05-21, similarity 0.9793):
[0000858877-24-000007:note_history:57]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 27, 2024 and July 29, 2023 was $35 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2024-11-19):
[0000858877-24-000030:note_history:58]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.
Subscription revenue includes revenue recognized from our term software licenses, security software licenses, SaaS, and associated service arrangements.
  (was, 2024-05-21, similarity 0.8484):
[0000858877-24-000007:note_history:58]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-11-19):
[0000858877-24-000030:note_history:59]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers. Revenue from subscription offers includes revenue recognized over time as well as upfront.
  (was, 2024-05-21, similarity 0.961):
[0000858877-24-000007:note_history:59]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

- changed (2024-11-19):
[0000858877-24-000030:note_history:60]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 26, 2024 and July 27, 2024 was $42 million and $37 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2024-05-21, similarity 0.9793):
[0000858877-24-000007:note_history:60]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 27, 2024 and July 29, 2023 was $35 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2024-11-19):
[0000858877-24-000030:note_history:61]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. The following table presents this disaggregation of revenue (in millions):
  (was, 2024-05-21, similarity 0.7629):
[0000858877-24-000007:note_history:61]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. Effective in the first quarter of fiscal 2024, we began reporting our product and service revenue in the following categories: Networking, Security, Collaboration, Observability, and Services and conformed our product revenue for prior periods to the current period presentation. The following table presents this disaggregation of revenue (in millions):

- changed (2024-11-19):
[0000858877-24-000030:note_history:62]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |
| Product revenue: |  |  |  |
| Networking | $ | 6,753 |  |  | $ | 8,822 |  |
| Security | 2,017 |  |  | 1,010 |  |
| Collaboration | 1,085 |  |  | 1,117 |  |
| Observability | 258 |  |  | 190 |  |
| Total Product | 10,114 |  |  | 11,139 |  |
| Services | 3,727 |  |  | 3,529 |  |
| Total | $ | 13,841 |  |  | $ | 14,668 |  |
  (was, 2024-05-21, similarity 0.6375):
[0000858877-24-000007:note_history:62]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 6,522 |  |  | $ | 8,982 |  |  | $ | 22,425 |  |  | $ | 25,105 |  |
| Security | 1,304 |  |  | 958 |  |  | 3,288 |  |  | 2,872 |  |
| Collaboration | 987 |  |  | 985 |  |  | 3,093 |  |  | 3,029 |  |
| Observability | 211 |  |  | 167 |  |  | 589 |  |  | 486 |  |
| Total Product | 9,024 |  |  | 11,092 |  |  | 29,395 |  |  | 31,492 |  |
| Services | 3,678 |  |  | 3,479 |  |  | 10,766 |  |  | 10,303 |  |
| Total | $ | 12,702 |  |  | $ | 14,571 |  |  | $ | 40,161 |  |  | $ | 41,795 |  |

- added (2024-11-19):
[0000858877-24-000030:note_history:63]
Networking consists of our core networking technologies of switching, routing, wireless, and servers. These technologies consist of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2024-11-19):
[0000858877-24-000030:note_history:64]
Security consists of our Network Security, Identity and Access Management, Secure Access Service Edge (SASE) and Threat Intelligence, Detection, and Response offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2024-11-19):
[0000858877-24-000030:note_history:65]
Collaboration consists of our Webex Suite, Collaboration Devices, Contact Center and Communication Platform as a Service (CPaaS) offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2024-11-19):
[0000858877-24-000030:note_history:66]
Observability consists of our network assurance, monitoring and analytics and observability suite offerings. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2024-11-19):
[0000858877-24-000030:note_history:67]
Subscription revenue includes revenue recognized from our term software licenses, security software licenses, SaaS, and associated service arrangements. Our subscription revenue is recorded in product and services revenue in our Consolidated Statements of Operations as follows (in millions):

- changed (2024-11-19):
[0000858877-24-000030:note_history:68]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Product | $ | 4,419 |  |  | $ | 3,207 |  |
| Services | 3,425 |  |  | 3,254 |  |
| Total | $ | 7,844 |  |  | $ | 6,461 |  |
  (was, 2024-05-21, similarity 0.6554):
[0000858877-24-000007:note_history:68]
|  | April 27,2024 |  | July 29,2023 |
| 1 to 4 | $ | 1,176 |  |  | $ | 672 |  |
| 5 to 6 | 1,383 |  |  | 954 |  |
| 7 and Higher | 70 |  |  | 60 |  |
| Total | $ | 2,629 |  |  | $ | 1,686 |  |

- added (2024-11-19):
[0000858877-24-000030:note_history:69]
The majority of our product subscription revenue is recognized over time and the remainder is recognized upfront. Substantially all of our services subscription revenue is recognized over time based on the contract term.

- changed (2024-11-19):
[0000858877-24-000030:note_history:70]
Accounts receivable, net was $4.5 billion as of October 26, 2024 compared to $6.7 billion as of July 27, 2024, as reported on the Consolidated Balance Sheets.
  (was, 2024-05-21, similarity 0.9648):
[0000858877-24-000007:note_history:70]
Accounts receivable, net was $5.1 billion as of April 27, 2024 compared to $5.9 billion as of July 29, 2023, as reported on the Consolidated Balance Sheets.

- changed (2024-11-19):
[0000858877-24-000030:note_history:71]
|  | Three Months Ended |
|  | October 26, 2024 |  | October 28, 2023 |
| Allowance for credit loss at beginning of period | $ | 87 |  |  | $ | 85 |  |
| Provisions (benefits) | — |  |  | 2 |  |
| Recoveries (write-offs), net | (9) |  |  | (5) |  |
| Allowance for credit loss at end of period | $ | 78 |  |  | $ | 82 |  |
  (was, 2024-05-21, similarity 0.6156):
[0000858877-24-000007:note_history:71]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2024 |  | April 29, 2023 |  | April 27, 2024 |  | April 29, 2023 |
| Allowance for credit loss at beginning of period | $ | 79 |  |  | $ | 86 |  |  | $ | 85 |  |  | $ | 83 |  |
| Provisions | 10 |  |  | 9 |  |  | 21 |  |  | 23 |  |
| Recoveries (write-offs), net | (8) |  |  | (12) |  |  | (25) |  |  | (23) |  |
| Allowance for credit loss at end of period | $ | 81 |  |  | $ | 83 |  |  | $ | 81 |  |  | $ | 83 |  |

- added (2024-11-19):
[0000858877-24-000030:note_history:72]
|  | October 26,2024 |  | July 27,2024 |
| 1 to 4 | $ | 1,244 |  |  | $ | 1,266 |  |
| 5 to 6 | 1,599 |  |  | 1,456 |  |
| 7 and Higher | 71 |  |  | 72 |  |
| Total | $ | 2,914 |  |  | $ | 2,794 |  |

- changed (2024-11-19):
[0000858877-24-000030:note_history:73]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $2.9 billion as of October 26, 2024 and $2.7 billion as of July 27, 2024, and were included in other current assets and other assets.
  (was, 2024-05-21, similarity 0.9874):
[0000858877-24-000007:note_history:73]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $2.6 billion as of April 27, 2024 and $1.6 billion as of July 29, 2023, and were included in other current assets and other assets.

- changed (2024-11-19):
[0000858877-24-000030:note_history:74]
Contract liabilities consist of deferred revenue. Deferred revenue was $27.5 billion as of October 26, 2024 compared to $28.5 billion as of July 27, 2024. We recognized approximately $5.3 billion of revenue during the first quarter of fiscal 2025 that was included in the deferred revenue balance at July 27, 2024.
  (was, 2024-05-21, similarity 0.9028):
[0000858877-24-000007:note_history:74]
Contract liabilities consist of deferred revenue. Deferred revenue was $27.5 billion as of April 27, 2024 compared to $25.6 billion as of July 29, 2023. We recognized approximately $3.0 billion and $11.5 billion of revenue during the third quarter and first nine months of fiscal 2024 that was included in the deferred revenue balance at July 29, 2023.

- added (2024-11-19):
[0000858877-24-000030:note_history:75]
(c)Capitalized Contract Acquisition Costs

- changed (2024-11-19):
[0000858877-24-000030:note_history:76]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to 
the period of benefit. Capitalized contract acquisition costs were $1.4 billion and $1.3 billion as of October 26, 2024 and July 27, 2024, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $208 million and $158 million for the first quarter of fiscal 2025 and fiscal 2024, respectively, and was included in sales and marketing expenses.
  (was, 2024-05-21, similarity 0.8363):
[0000858877-24-000007:note_history:76]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Capitalized contract acquisition costs were $1.3 billion and $1.1 billion as of April 27, 2024 and July 29, 2023, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $201 million and $525 million for the third quarter and first nine months fiscal 2024, respectively, and $172 million and $549 million for the corresponding periods of fiscal 2023, respectively, and was included in sales and marketing expenses.

- removed (2024-11-19):
[0000858877-24-000007:note_history:77]
Networking consists of our core networking technologies of switching, routing, wireless, 5G, silicon, optics solutions and compute products. These technologies consist of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2024-11-19):
[0000858877-24-000007:note_history:78]
Security consists of our Cloud and Application Security, Industrial Security, Network Security, and User and Device Security offerings. This product category includes the Splunk Platform and Splunk Security offerings after our acquisition of Splunk, although the Splunk Platform has use cases that can also be applicable for observability offerings. See Note 4. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2024-11-19):
[0000858877-24-000007:note_history:79]
Collaboration consists of our Meetings, Collaboration Devices, Calling, Contact Center and Communication Platform as a Service (CPaaS) offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2024-11-19):
[0000858877-24-000007:note_history:80]
Observability consists of our full stack observability offerings. This product category includes the Splunk Observability Suite after our acquisition of Splunk. This product category excludes the Splunk Platform which includes use cases that can also be associated with observability offerings. See Note 4. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.
