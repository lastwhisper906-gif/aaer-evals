# CSCO MD&A — 0000858877-24-000030


## mdna

[0000858877-24-000030:mdna:1]
[same as prior period, unchanged from 0000858877-24-000007:mdna:1]

[0000858877-24-000030:mdna:2]
[same as prior period, unchanged from 0000858877-24-000007:mdna:2]

[0000858877-24-000030:mdna:3]
[same as prior period, unchanged from 0000858877-24-000007:mdna:3]

[0000858877-24-000030:mdna:4]
Cisco designs and sells a broad range of technologies that help to power, secure, and draw insights from the Internet. We are integrating artificial intelligence (AI) into our product portfolios across networking, security, collaboration and observability to simplify how our technology is delivered, managed and optimized and to help customers maximize the business value of their technology investments and accelerate their digital transformation.

[0000858877-24-000030:mdna:5]
[same as prior period, unchanged from 0000858877-24-000007:mdna:5]

[0000858877-24-000030:mdna:6]
|  | Three Months Ended |  |
|  | October 26,2024 |  | October 28,2023 |  | % Variance |  |
| Revenue | $ | 13,841 |  |  | $ | 14,668 |  |  | (6) | % |  |
| Gross margin percentage | 65.9 | % |  | 65.2 | % |  | 0.7 |  | pts |
| Research and development | $ | 2,286 |  |  | $ | 1,913 |  |  | 19 | % |  |
| Sales and marketing | $ | 2,752 |  |  | $ | 2,506 |  |  | 10 | % |  |
| General and administrative | $ | 795 |  |  | $ | 672 |  |  | 18 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 5,833 |  |  | $ | 5,091 |  |  | 15 | % |  |
| Total as a percentage of revenue | 42.1 | % |  | 34.7 | % |  | 7.4 |  | pts |
| Restructuring and other charges included in operating expenses | $ | 665 |  |  | $ | 123 |  |  | NM |  |
| Operating income as a percentage of revenue | 17.0 | % |  | 29.2 | % |  | (12.2) |  | pts |
| Interest and other income (loss), net | $ | (91) |  |  | $ | 166 |  |  | (155) | % |  |
| Income tax percentage | (19.6) | % |  | 18.1 | % |  | (37.7) |  | pts |
| Net income | $ | 2,711 |  |  | $ | 3,638 |  |  | (25) | % |  |
| Net income as a percentage of revenue | 19.6 | % |  | 24.8 | % |  | (5.2) |  | pts |
| Earnings per share—diluted | $ | 0.68 |  |  | $ | 0.89 |  |  | (24) | % |  |

[0000858877-24-000030:mdna:7]
[same as prior period, unchanged from 0000858877-24-000007:mdna:7]

[0000858877-24-000030:mdna:8]
[same as prior period, unchanged from 0000858877-24-000007:mdna:8]

[0000858877-24-000030:mdna:9]
[same as prior period, unchanged from 0000858877-24-000007:mdna:9]

[0000858877-24-000030:mdna:10]
[same as prior period, unchanged from 0000858877-24-000007:mdna:10]

[0000858877-24-000030:mdna:11]
Three Months Ended October 26, 2024 Compared with Three Months Ended October 28, 2023

[0000858877-24-000030:mdna:12]
In the first quarter of fiscal 2025, we saw improvement in product demand across the majority of our geographic segments and customer markets reflecting normalizing demand patterns. We believe our customers have largely completed the installation of products from the elevated level of product shipments seen during fiscal 2024. Total revenue decreased by 6% compared with the first quarter of fiscal 2024. Excluding Splunk, total revenue decreased 14% compared with the first quarter of fiscal 2024. Within total revenue, product revenue decreased by 9% and services revenue increased by 6%. In the first quarter of fiscal 2025, total software revenue was $5.5 billion across all product areas and services, an increase of 24%, primarily driven by the contribution of Splunk. Total subscription revenue increased 21%, primarily driven by the contribution of Splunk.

[0000858877-24-000030:mdna:13]
Total gross margin increased by 0.7 percentage points. Product gross margin increased by 0.6 percentage points, largely driven by benefits from Splunk, favorable product mix and productivity improvements, partially offset by pricing erosion. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 7.4 percentage points. Operating income as a percentage of revenue decreased by 12.2 percentage points primarily driven by incremental operating expenses from Splunk, higher restructuring and other charges of $665 million and higher amortization of purchased intangible assets in the first quarter of fiscal 2025. Diluted earnings per share decreased 24%, driven by a decrease of 25% in net income, partially offset by a decrease in diluted share count of 74 million shares.

[0000858877-24-000030:mdna:14]
In terms of our geographic segments, revenue from the Americas decreased by $0.8 billion, EMEA revenue decreased by $76 million and APJC revenue increased by $19 million. From a customer market standpoint, we experienced product revenue declines across all of our customer markets. From a product category perspective, the product revenue decrease of 9% was driven by a decline in revenue in Networking of 23% and Collaboration of 3%. This decline was partially offset by product revenue growth in Security of 100% and Observability of 36%, each driven in large part by the contribution of Splunk.

[0000858877-24-000030:mdna:15]
While we continue to operate in a highly competitive environment and the overall macroeconomic environment remains challenging and uncertain, we plan to continue to invest in key priority areas with the objective of driving profitable growth over the long term. We remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformations and on accelerating innovation across our portfolio. We believe that we are making progress on our strategic priorities.

[0000858877-24-000030:mdna:16]
[same as prior period, unchanged from 0000858877-24-000007:mdna:17]

[0000858877-24-000030:mdna:17]
[same as prior period, unchanged from 0000858877-24-000007:mdna:18]

[0000858877-24-000030:mdna:18]
[same as prior period, unchanged from 0000858877-24-000007:mdna:21]

[0000858877-24-000030:mdna:19]
Across the globe, businesses and organizations of every size are leveraging Cisco technology to transform and drive better outcomes and experiences. We also help customers navigate emerging technological shifts. Our strategy is to securely connect everything to make those desired outcomes and experiences possible for our customers.

[0000858877-24-000030:mdna:20]
For additional discussion of our strategy and priorities, see Item 1. Business in our Annual Report on Form 10-K for the fiscal year ended July 27, 2024.

[0000858877-24-000030:mdna:21]
[same as prior period, unchanged from 0000858877-24-000007:mdna:24]

[0000858877-24-000030:mdna:22]
The following is a summary of our other key financial measures for the first quarter of fiscal 2025 (in millions):

[0000858877-24-000030:mdna:23]
|  |  | October 26,2024 |  | July 27,2024 |
| Cash and cash equivalents and investments |  | $ | 18,671 |  |  | $ | 17,854 |  |
| Remaining performance obligations |  | $ | 39,990 |  |  | $ | 41,048 |  |
| Inventories |  | $ | 3,143 |  |  | $ | 3,373 |  |
| Total debt |  | $ | 31,987 |  |  | $ | 30,962 |  |

[0000858877-24-000030:mdna:24]
|  |  | Three Months Ended |
|  |  | October 26,2024 |  | October 28,2023 |
| Cash provided by operating activities |  | $ | 3,661 |  |  | $ | 2,371 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 2,003 |  |  | $ | 1,252 |  |
| Dividends paid |  | $ | 1,592 |  |  | $ | 1,580 |  |

[0000858877-24-000030:mdna:25]
40

[0000858877-24-000030:mdna:26]
[same as prior period, unchanged from 0000858877-24-000007:mdna:28]

[0000858877-24-000030:mdna:27]
[same as prior period, unchanged from 0000858877-24-000007:mdna:29]

[0000858877-24-000030:mdna:28]
[same as prior period, unchanged from 0000858877-24-000007:mdna:30]

[0000858877-24-000030:mdna:29]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements in our Annual Report on Form 10-K for the fiscal year ended July 27, 2024, as updated as applicable in Note 2 to the Consolidated Financial Statements herein, describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-24-000030:mdna:30]
[same as prior period, unchanged from 0000858877-24-000007:mdna:32]

[0000858877-24-000030:mdna:31]
[same as prior period, unchanged from 0000858877-24-000007:mdna:33]

[0000858877-24-000030:mdna:32]
[same as prior period, unchanged from 0000858877-24-000007:mdna:34]

[0000858877-24-000030:mdna:33]
[same as prior period, unchanged from 0000858877-24-000007:mdna:35]

[0000858877-24-000030:mdna:34]
[same as prior period, unchanged from 0000858877-24-000007:mdna:36]

[0000858877-24-000030:mdna:35]
[same as prior period, unchanged from 0000858877-24-000007:mdna:37]

[0000858877-24-000030:mdna:36]
[same as prior period, unchanged from 0000858877-24-000007:mdna:38]

[0000858877-24-000030:mdna:37]
[same as prior period, unchanged from 0000858877-24-000007:mdna:39]

[0000858877-24-000030:mdna:38]
41

[0000858877-24-000030:mdna:39]
[same as prior period, unchanged from 0000858877-24-000007:mdna:41]

[0000858877-24-000030:mdna:40]
[same as prior period, unchanged from 0000858877-24-000007:mdna:42]

[0000858877-24-000030:mdna:41]
[same as prior period, unchanged from 0000858877-24-000007:mdna:43]

[0000858877-24-000030:mdna:42]
Our provision for inventory was $207 million and $133 million for the first quarter of fiscal 2025 and 2024, respectively. The provision (benefit) from the liability related to purchase commitments with contract manufacturers and suppliers was a benefit of $6 million and a provision of $43 million for the first quarter of fiscal 2025 and 2024, respectively. If there were to be a sudden and significant decrease in demand for our products, if there were a higher incidence of inventory obsolescence because of rapidly changing technology or customer requirements, or if supply constraints were to continue, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. For further discussion around the supply chain impacts and risks, see “—Results of Operations—Gross Margin—Supply Chain Impacts and Risks” and “—Liquidity and Capital Resources—Inventory Supply Chain.”

[0000858877-24-000030:mdna:43]
Loss Contingencies

[0000858877-24-000030:mdna:44]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-24-000030:mdna:45]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-24-000030:mdna:46]
Valuation of Goodwill and Purchased Intangible Assets

[0000858877-24-000030:mdna:47]
Goodwill

[0000858877-24-000030:mdna:48]
Our methodology for allocating the purchase price relating to purchase acquisitions is determined through established valuation techniques. Goodwill represents a residual value as of the acquisition date, which in most cases results in measuring goodwill as an excess of the purchase consideration transferred plus the fair value of any noncontrolling interest in the acquired company over the fair value of net assets acquired, including contingent consideration. We perform goodwill impairment tests on an annual basis in the fourth fiscal quarter and between annual tests in certain circumstances for each reporting unit. The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the guidance for the fair value measurement of nonfinancial assets.

[0000858877-24-000030:mdna:49]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first quarter of fiscal 2025 and 2024.

[0000858877-24-000030:mdna:50]
Purchased Intangible Assets

[0000858877-24-000030:mdna:51]
The accounting for acquisitions requires significant estimates and judgments in the valuation of purchased intangible assets. Critical estimates used in the valuation of purchased intangible assets include, but are not limited to, the amount and timing of expected future cash flows, useful lives and discount rates. While our estimates of fair value are based on assumptions that are believed to be reasonable, these assumptions are inherently uncertain and unpredictable and would not reflect unanticipated events and circumstances that may occur.

[0000858877-24-000030:mdna:52]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset group to the future undiscounted cash flows the asset group is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of

[0000858877-24-000030:mdna:53]
[same as prior period, unchanged from 0000858877-24-000007:mdna:54]

[0000858877-24-000030:mdna:54]
[same as prior period, unchanged from 0000858877-24-000007:mdna:55]

[0000858877-24-000030:mdna:55]
factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. Our ongoing consideration of all the factors described previously could result in impairment charges in the future, which could adversely affect our net income.

[0000858877-24-000030:mdna:56]
[same as prior period, unchanged from 0000858877-24-000007:mdna:57]

[0000858877-24-000030:mdna:57]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was a benefit of 19.6% and a tax provision of 18.1% in the first quarter of fiscal 2025 and 2024, respectively.

[0000858877-24-000030:mdna:58]
[same as prior period, unchanged from 0000858877-24-000007:mdna:59]

[0000858877-24-000030:mdna:59]
Significant judgment is also required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. If we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000858877-24-000030:mdna:60]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to foreign-derived intangible income deduction, global intangible low-tax income and base erosion and anti-abuse tax, research and development capitalization and amortization, and corporate alternative minimum tax laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 38 countries, including the United States, has made changes, including a Pillar Two framework that imposes a minimum tax rate of 15% in each taxing jurisdiction, and is contemplating additional changes to numerous long-standing tax principles. There can be no assurance that these changes and any contemplated changes if finalized, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries was subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-24-000030:mdna:61]
43

[0000858877-24-000030:mdna:62]
[same as prior period, unchanged from 0000858877-24-000007:mdna:62]

[0000858877-24-000030:mdna:63]
[same as prior period, unchanged from 0000858877-24-000007:mdna:63]

[0000858877-24-000030:mdna:64]
[same as prior period, unchanged from 0000858877-24-000007:mdna:64]

[0000858877-24-000030:mdna:65]
[same as prior period, unchanged from 0000858877-24-000007:mdna:65]

[0000858877-24-000030:mdna:66]
The following table presents the breakdown of revenue between product and services (in millions, except percentages):

[0000858877-24-000030:mdna:67]
|  |  | Three Months Ended |
|  |  | October 26,2024 |  | October 28,2023 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 10,114 |  |  | $ | 11,139 |  |  | $ | (1,025) |  |  | (9) | % |
| Percentage of revenue |  | 73.1 | % |  | 75.9 | % |  |  |  |  |
| Services |  | 3,727 |  |  | 3,529 |  |  | 198 |  |  | 6 | % |
| Percentage of revenue |  | 26.9 | % |  | 24.1 | % |  |  |  |  |
| Total |  | $ | 13,841 |  |  | $ | 14,668 |  |  | $ | (827) |  |  | (6) | % |

[0000858877-24-000030:mdna:68]
[same as prior period, unchanged from 0000858877-24-000007:mdna:68]

[0000858877-24-000030:mdna:69]
Excluding Splunk, total revenue for the first quarter of fiscal 2025 decreased by 14% as compared with the first quarter of fiscal 2024.

[0000858877-24-000030:mdna:70]
We manage our business primarily on a geographic basis, organized into three geographic segments. Our revenue, which includes product and services for each segment, is summarized in the following table (in millions, except percentages):

[0000858877-24-000030:mdna:71]
|  |  | Three Months Ended |
|  |  | October 26,2024 |  | October 28,2023 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 8,252 |  |  | $ | 9,022 |  |  | $ | (770) |  |  | (9) | % |
| Percentage of revenue |  | 59.6 | % |  | 61.5 | % |  |  |  |  |
| EMEA |  | 3,588 |  |  | 3,664 |  |  | (76) |  |  | (2) | % |
| Percentage of revenue |  | 25.9 | % |  | 25.0 | % |  |  |  |  |
| APJC |  | 2,001 |  |  | 1,982 |  |  | 19 |  |  | 1 | % |
| Percentage of revenue |  | 14.5 | % |  | 13.5 | % |  |  |  |  |
| Total |  | $ | 13,841 |  |  | $ | 14,668 |  |  | $ | (827) |  |  | (6) | % |

[0000858877-24-000030:mdna:72]
[same as prior period, unchanged from 0000858877-24-000007:mdna:72]

[0000858877-24-000030:mdna:73]
Three Months Ended October 26, 2024 Compared with Three Months Ended October 28, 2023

[0000858877-24-000030:mdna:74]
Total revenue decreased by 6%. Product revenue decreased by 9% and services revenue increased by 6%. Our total revenue reflected declines in the Americas and EMEA segment, partially offset by growth in the APJC segment.

[0000858877-24-000030:mdna:75]
[same as prior period, unchanged from 0000858877-24-000007:mdna:75]

[0000858877-24-000030:mdna:76]
[same as prior period, unchanged from 0000858877-24-000007:mdna:78]

[0000858877-24-000030:mdna:77]
[same as prior period, unchanged from 0000858877-24-000007:mdna:79]

[0000858877-24-000030:mdna:78]
[same as prior period, unchanged from 0000858877-24-000007:mdna:80]

[0000858877-24-000030:mdna:79]
[same as prior period, unchanged from 0000858877-24-000007:mdna:81]

[0000858877-24-000030:mdna:80]
|  |  | Three Months Ended |
|  |  | October 26,2024 |  | October 28,2023 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 6,002 |  |  | $ | 6,852 |  |  | $ | (850) |  |  | (12) | % |
| Percentage of product revenue |  | 59.3 | % |  | 61.5 | % |  |  |  |  |
| EMEA |  | 2,686 |  |  | 2,840 |  |  | (154) |  |  | (5) | % |
| Percentage of product revenue |  | 26.6 | % |  | 25.5 | % |  |  |  |  |
| APJC |  | 1,426 |  |  | 1,448 |  |  | (22) |  |  | (2) | % |
| Percentage of product revenue |  | 14.1 | % |  | 13.0 | % |  |  |  |  |
| Total |  | $ | 10,114 |  |  | $ | 11,139 |  |  | $ | (1,025) |  |  | (9) | % |

[0000858877-24-000030:mdna:81]
[same as prior period, unchanged from 0000858877-24-000007:mdna:83]

[0000858877-24-000030:mdna:82]
Three Months Ended October 26, 2024 Compared with Three Months Ended October 28, 2023

[0000858877-24-000030:mdna:83]
[same as prior period, unchanged from 0000858877-24-000007:mdna:84]

[0000858877-24-000030:mdna:84]
Product revenue in the Americas segment decreased by 12%, with declines across each of our customer markets. In the public sector customer market, we saw a decline in product demand due to delayed spending by our U.S. Federal customers. From a country perspective, product revenue decreased in the United States and Mexico by 13% and 23%, respectively, partially offset by growth in Canada and Brazil of 3% and 17%, respectively.

[0000858877-24-000030:mdna:85]
[same as prior period, unchanged from 0000858877-24-000007:mdna:89]

[0000858877-24-000030:mdna:86]
Product revenue in the EMEA segment decreased by 5%, with declines across each of our customer markets. From a country perspective, product revenue decreased in the Netherlands and Switzerland by 24% and 20%, respectively, partially offset by growth in the United Kingdom and France of 12% and 6%, respectively. Product revenue in Germany was flat.

[0000858877-24-000030:mdna:87]
[same as prior period, unchanged from 0000858877-24-000007:mdna:94]

[0000858877-24-000030:mdna:88]
Product revenue in the APJC segment decreased by 2%, with declines across each of our customer markets. From a country perspective, product revenue decreased in India and China by 7% and 4%, respectively, partially offset by growth of 18% in each of Japan and Australia.

[0000858877-24-000030:mdna:89]
[same as prior period, unchanged from 0000858877-24-000007:mdna:99]

[0000858877-24-000030:mdna:90]
[same as prior period, unchanged from 0000858877-24-000007:mdna:100]

[0000858877-24-000030:mdna:91]
[same as prior period, unchanged from 0000858877-24-000007:mdna:101]

[0000858877-24-000030:mdna:92]
In addition to the primary view on a geographic basis, we also prepare financial information related to product categories and customer markets for various purposes.

[0000858877-24-000030:mdna:93]
[same as prior period, unchanged from 0000858877-24-000007:mdna:103]

[0000858877-24-000030:mdna:94]
|  |  | Three Months Ended |
|  |  | October 26,2024 |  | October 28,2023 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue |  |  |  |  |  |  |  |  |
| Networking |  | $ | 6,753 |  |  | $ | 8,822 |  |  | $ | (2,069) |  |  | (23) | % |
| Security |  | 2,017 |  |  | 1,010 |  |  | 1,007 |  |  | 100 | % |
| Collaboration |  | 1,085 |  |  | 1,117 |  |  | (32) |  |  | (3) | % |
| Observability |  | 258 |  |  | 190 |  |  | 68 |  |  | 36 | % |
| Total |  | $ | 10,114 |  |  | $ | 11,139 |  |  | $ | (1,025) |  |  | (9) | % |

[0000858877-24-000030:mdna:95]
[same as prior period, unchanged from 0000858877-24-000007:mdna:105]

[0000858877-24-000030:mdna:96]
Three Months Ended October 26, 2024 Compared with Three Months Ended October 28, 2023

[0000858877-24-000030:mdna:97]
[same as prior period, unchanged from 0000858877-24-000007:mdna:106]

[0000858877-24-000030:mdna:98]
The Networking product category consists of our core networking technologies of switching, routing, wireless, and servers. Revenue from the Networking product category decreased by 23%, or $2.1 billion. Revenue declined across the portfolio as a result of product shipments returning to normalized levels during the quarter from the elevated levels of product shipments we experienced in prior quarters. Revenue declined in both campus switching and data center switching, primarily driven by declines in our Catalyst 9000 series and Nexus 9000 series offerings. We experienced a revenue decline in enterprise routing, although we saw revenue growth in our SD-WAN offerings. The decrease in wireless was primarily driven by our WiFi-6 offerings. We also saw a revenue decline in internet infrastructure.

[0000858877-24-000030:mdna:99]
[same as prior period, unchanged from 0000858877-24-000007:mdna:111]

[0000858877-24-000030:mdna:100]
The Security product category consists of our Network Security, Identity and Access Management, SASE and Threat Intelligence, Detection, and Response offerings. Revenue in our Security product category increased by 100%, or $1.0 billion, primarily driven by Threat Intelligence, Detection, and Response offerings, which includes the offerings from Splunk, growth in our Network Security and SASE offerings. Excluding Splunk, product revenue in the Security product category increased 2%.

[0000858877-24-000030:mdna:101]
[same as prior period, unchanged from 0000858877-24-000007:mdna:116]

[0000858877-24-000030:mdna:102]
The Collaboration product category consists of our Webex Suite, Collaboration Devices, Contact Center and CPaaS offerings. Revenue in our Collaboration product category decreased by 3%, or $32 million, primarily driven by declines in our On-Prem Webex Suite and Collaboration Devices offerings, partially offset by growth in our Contact Center and CPaaS offerings.

[0000858877-24-000030:mdna:103]
[same as prior period, unchanged from 0000858877-24-000007:mdna:123]

[0000858877-24-000030:mdna:104]
The Observability product category consists of our network assurance, monitoring and analytics and observability suite offerings. Revenue in our Observability product category increased 36%, or $68 million, driven by our Observability Suite and growth in our Network Assurance offerings. Excluding Splunk, product revenue in the Observability product category increased 1%.

[0000858877-24-000030:mdna:105]
[same as prior period, unchanged from 0000858877-24-000007:mdna:119]

[0000858877-24-000030:mdna:106]
[same as prior period, unchanged from 0000858877-24-000007:mdna:120]

[0000858877-24-000030:mdna:107]
Services Revenue by Segment

[0000858877-24-000030:mdna:108]
The following table presents the breakdown of services revenue by segment (in millions, except percentages):

[0000858877-24-000030:mdna:109]
|  |  | Three Months Ended |
|  |  | October 26,2024 |  | October 28,2023 |  | Variancein Dollars |  | Variance in Percent |
| Services revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,249 |  |  | $ | 2,171 |  |  | $ | 78 |  |  | 4 | % |
| Percentage of service revenue |  | 60.3 | % |  | 61.5 | % |  |  |  |  |
| EMEA |  | 903 |  |  | 824 |  |  | 79 |  |  | 10 | % |
| Percentage of service revenue |  | 24.2 | % |  | 23.3 | % |  |  |  |  |
| APJC |  | 575 |  |  | 534 |  |  | 41 |  |  | 8 | % |
| Percentage of service revenue |  | 15.5 | % |  | 15.2 | % |  |  |  |  |
| Total |  | $ | 3,727 |  |  | $ | 3,529 |  |  | $ | 198 |  |  | 6 | % |

[0000858877-24-000030:mdna:110]
[same as prior period, unchanged from 0000858877-24-000007:mdna:131]

[0000858877-24-000030:mdna:111]
Services revenue increased 6% in the first quarter of fiscal 2025 compared with the first quarter of fiscal 2024, primarily driven by Splunk and revenue growth in our software support offerings, solution support offerings, and advisory services. Services revenue increased across all of our geographic segments for the first quarter of fiscal 2025.

[0000858877-24-000030:mdna:112]
[same as prior period, unchanged from 0000858877-24-000007:mdna:136]

[0000858877-24-000030:mdna:113]
[same as prior period, unchanged from 0000858877-24-000007:mdna:137]

[0000858877-24-000030:mdna:114]
|  |  | Three Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |
|  |  | October 26,2024 |  | October 28,2023 |  | October 26,2024 |  | October 28,2023 |
| Gross margin: |  |  |  |  |  |  |  |  |
| Product |  | $ | 6,588 |  |  | $ | 7,182 |  |  | 65.1 | % |  | 64.5 | % |
| Services |  | 2,533 |  |  | 2,375 |  |  | 68.0 | % |  | 67.3 | % |
| Total |  | $ | 9,121 |  |  | $ | 9,557 |  |  | 65.9 | % |  | 65.2 | % |

[0000858877-24-000030:mdna:115]
[same as prior period, unchanged from 0000858877-24-000007:mdna:139]

[0000858877-24-000030:mdna:116]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the first quarter of fiscal 2025, as compared with the corresponding prior year periods:

[0000858877-24-000030:mdna:117]
|  |  | Product Gross Margin Percentage |
| Fiscal 2024 |  | 64.5 | % |
| Productivity (1) |  | 0.8 | % |
| Product pricing |  | (1.9) | % |
| Mix of products sold |  | 3.6 | % |
| Amortization of purchased intangible assets |  | (1.5) | % |
| Others |  | (0.4) | % |
| Fiscal 2025 |  | 65.1 | % |

[0000858877-24-000030:mdna:118]
[same as prior period, unchanged from 0000858877-24-000007:mdna:142]

[0000858877-24-000030:mdna:119]
[same as prior period, unchanged from 0000858877-24-000007:mdna:134]

[0000858877-24-000030:mdna:120]
[same as prior period, unchanged from 0000858877-24-000007:mdna:135]

[0000858877-24-000030:mdna:121]
Three Months Ended October 26, 2024 Compared with Three Months Ended October 28, 2023

[0000858877-24-000030:mdna:122]
Product gross margin increased by 0.6 percentage points primarily driven by benefits from Splunk, favorable product mix and  productivity benefits, largely driven by an import duty benefit, partially offset by negative impacts from pricing and the amortization of purchased intangible assets primarily related to Splunk.

[0000858877-24-000030:mdna:123]
[same as prior period, unchanged from 0000858877-24-000007:mdna:147]

[0000858877-24-000030:mdna:124]
In past periods, we took multiple actions in order to mitigate component shortages and address significant supply constraints. These supply constraints resulted in the need to secure long-term supply and increased inventory supply chain balances compared to historical levels. This in turn has significantly increased our supply chain exposure, which has resulted in negative impacts to our product gross margin in recent periods and may result in further negative impacts in future periods. This exposure includes potential material excess and obsolete or other charges if product demand significantly decreases for a sustained duration, we are unable to generate demand for certain products planned for development, or we are unable to mitigate the remaining supply chain exposures.

[0000858877-24-000030:mdna:125]
Services Gross Margin

[0000858877-24-000030:mdna:126]
Three Months Ended October 26, 2024 Compared with Three Months Ended October 28, 2023

[0000858877-24-000030:mdna:127]
Our services gross margin percentage increased by 0.7 percentage points primarily due to higher sales volume, partially offset by higher headcount-related costs, unfavorable mix of service offerings and to a lesser extent, higher delivery costs.

[0000858877-24-000030:mdna:128]
Our services gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-24-000030:mdna:129]
[same as prior period, unchanged from 0000858877-24-000007:mdna:158]

[0000858877-24-000030:mdna:130]
[same as prior period, unchanged from 0000858877-24-000007:mdna:159]

[0000858877-24-000030:mdna:131]
|  | Three Months Ended |
|  | AMOUNT |  | PERCENTAGE |
|  | October 26,2024 |  | October 28,2023 |  | October 26,2024 |  | October 28,2023 |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 5,740 |  |  | $ | 5,968 |  |  | 69.6 | % |  | 66.2 | % |
| EMEA | 2,522 |  |  | 2,545 |  |  | 70.3 | % |  | 69.5 | % |
| APJC | 1,328 |  |  | 1,328 |  |  | 66.4 | % |  | 67.0 | % |
| Segment total | 9,590 |  |  | 9,841 |  |  | 69.3 | % |  | 67.1 | % |
| Unallocated corporate items (1) | (469) |  |  | (284) |  |  |  |  |  |
| Total | $ | 9,121 |  |  | $ | 9,557 |  |  | 65.9 | % |  | 65.2 | % |

[0000858877-24-000030:mdna:132]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-24-000030:mdna:133]
[same as prior period, unchanged from 0000858877-24-000007:mdna:162]

[0000858877-24-000030:mdna:134]
Three Months Ended October 26, 2024 Compared with Three Months Ended October 28, 2023

[0000858877-24-000030:mdna:135]
We experienced a gross margin percentage increase in our Americas segment due to favorable product mix, positive impacts from productivity improvements and higher services gross margin, partially offset by pricing erosion.

[0000858877-24-000030:mdna:136]
Gross margin percentage in our EMEA segment increased primarily due to favorable product mix and higher services gross margin, partially offset by pricing erosion.

[0000858877-24-000030:mdna:137]
The APJC segment gross margin percentage decrease was primarily due to pricing erosion, and to a lesser extent, unfavorable product mix, partially offset by positive impacts from productivity improvements.

[0000858877-24-000030:mdna:138]
[same as prior period, unchanged from 0000858877-24-000007:mdna:149]

[0000858877-24-000030:mdna:139]
[same as prior period, unchanged from 0000858877-24-000007:mdna:150]

[0000858877-24-000030:mdna:140]
[same as prior period, unchanged from 0000858877-24-000007:mdna:173]

[0000858877-24-000030:mdna:141]
[same as prior period, unchanged from 0000858877-24-000007:mdna:174]

[0000858877-24-000030:mdna:142]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 2,286 |  |  | $ | 1,913 |  |  | $ | 373 |  |  | 19 | % |
| Percentage of revenue | 16.5 | % |  | 13.0 | % |  |  |  |  |
| Sales and marketing | 2,752 |  |  | 2,506 |  |  | 246 |  |  | 10 | % |
| Percentage of revenue | 19.9 | % |  | 17.1 | % |  |  |  |  |
| General and administrative | 795 |  |  | 672 |  |  | 123 |  |  | 18 | % |
| Percentage of revenue | 5.7 | % |  | 4.6 | % |  |  |  |  |
| Total | $ | 5,833 |  |  | $ | 5,091 |  |  | $ | 742 |  |  | 15 | % |
| Percentage of revenue | 42.1 | % |  | 34.7 | % |  |  |  |  |

[0000858877-24-000030:mdna:143]
Three Months Ended October 26, 2024 Compared with Three Months Ended October 28, 2023

[0000858877-24-000030:mdna:144]
[same as prior period, unchanged from 0000858877-24-000007:mdna:176]

[0000858877-24-000030:mdna:145]
R&D expenses increased due to incremental expenses from Splunk, higher headcount-related expenses, higher cash compensation from acquisitions, higher share-based compensation expense, and higher discretionary spending.

[0000858877-24-000030:mdna:146]
[same as prior period, unchanged from 0000858877-24-000007:mdna:179]

[0000858877-24-000030:mdna:147]
[same as prior period, unchanged from 0000858877-24-000007:mdna:182]

[0000858877-24-000030:mdna:148]
Sales and marketing expenses increased primarily due to incremental expenses from Splunk, higher headcount-related expenses, higher cash compensation from acquisitions and higher discretionary spending, partially offset by lower contracted services spending.

[0000858877-24-000030:mdna:149]
[same as prior period, unchanged from 0000858877-24-000007:mdna:187]

[0000858877-24-000030:mdna:150]
G&A expenses increased due to incremental expenses from Splunk, higher headcount-related expenses and higher acquisition-related costs, partially offset by lower contracted services spending.

[0000858877-24-000030:mdna:151]
[same as prior period, unchanged from 0000858877-24-000007:mdna:192]

[0000858877-24-000030:mdna:152]
In the first quarter of fiscal 2025, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $8 million, or 0.2%, compared with the first quarter of fiscal 2024.

[0000858877-24-000030:mdna:153]
[same as prior period, unchanged from 0000858877-24-000007:mdna:197]

[0000858877-24-000030:mdna:154]
[same as prior period, unchanged from 0000858877-24-000007:mdna:198]

[0000858877-24-000030:mdna:155]
|  |  | Three Months Ended |
|  |  | October 26,2024 |  | October 28,2023 |
| Amortization of purchased intangible assets: |  |  |  |  |
| Cost of sales |  | $ | 325 |  |  | $ | 186 |  |
| Operating expenses |  | 265 |  |  | 67 |  |
| Total |  | $ | 590 |  |  | $ | 253 |  |

[0000858877-24-000030:mdna:156]
For the first quarter of fiscal 2025, the increase in amortization of purchased intangible assets was primarily due to amortization of purchased intangibles from our recent acquisitions, including the acquisition of Splunk. The increase was partially offset by certain purchased intangible assets that became fully amortized.

[0000858877-24-000030:mdna:157]
[same as prior period, unchanged from 0000858877-24-000007:mdna:171]

[0000858877-24-000030:mdna:158]
[same as prior period, unchanged from 0000858877-24-000007:mdna:172]

[0000858877-24-000030:mdna:159]
[same as prior period, unchanged from 0000858877-24-000007:mdna:201]

[0000858877-24-000030:mdna:160]
In the first quarter of fiscal 2025, we announced a restructuring plan in order to allow us to invest in key growth opportunities and drive more efficiencies in our business. This restructuring plan is expected to impact approximately 7% of our global workforce with estimated pre-tax charges of approximately $1 billion. In connection with this restructuring plan, we incurred charges of $665 million in the first quarter of fiscal 2025. We expect this plan to be substantially completed by the end of fiscal 2025.

[0000858877-24-000030:mdna:161]
We expect to reinvest substantially all of the cost savings from this restructuring plan in our key growth opportunities. As a result, the overall cost savings from this restructuring plan is not expected to be material for future periods.

[0000858877-24-000030:mdna:162]
[same as prior period, unchanged from 0000858877-24-000007:mdna:205]

[0000858877-24-000030:mdna:163]
[same as prior period, unchanged from 0000858877-24-000007:mdna:206]

[0000858877-24-000030:mdna:164]
|  |  | Three Months Ended |
|  |  | October 26,2024 |  | October 28,2023 |
| Operating income |  | $ | 2,358 |  |  | $ | 4,276 |  |
| Operating income as a percentage of revenue |  | 17.0 | % |  | 29.2 | % |

[0000858877-24-000030:mdna:165]
Three Months Ended October 26, 2024 Compared with Three Months Ended October 28, 2023

[0000858877-24-000030:mdna:166]
Operating income decreased by 45%, and operating income as a percentage of revenue decreased by 12.2 percentage points. These changes were primarily from a revenue decrease, incremental expenses from Splunk, higher restructuring and other charges and higher amortization of purchased intangible assets, partially offset by a gross margin percentage increase (driven by favorable product mix and productivity improvements, partially offset by pricing erosion).

[0000858877-24-000030:mdna:167]
[same as prior period, unchanged from 0000858877-24-000007:mdna:215]

[0000858877-24-000030:mdna:168]
[same as prior period, unchanged from 0000858877-24-000007:mdna:216]

[0000858877-24-000030:mdna:169]
|  |  | Three Months Ended |
|  |  | October 26,2024 |  | October 28,2023 |  | Variancein Dollars |
| Interest income |  | $ | 286 |  |  | $ | 360 |  |  | $ | (74) |  |
| Interest expense |  | (418) |  |  | (111) |  |  | (307) |  |
| Interest income (expense), net |  | $ | (132) |  |  | $ | 249 |  |  | $ | (381) |  |

[0000858877-24-000030:mdna:170]
Three Months Ended October 26, 2024 Compared with Three Months Ended October 28, 2023

[0000858877-24-000030:mdna:171]
For the first quarter of fiscal 2025, the decrease in interest income was driven by a lower average balance of cash and available-for-sale debt investments. The increase in interest expense was primarily driven by the issuances of senior notes and commercial paper.

[0000858877-24-000030:mdna:172]
[same as prior period, unchanged from 0000858877-24-000007:mdna:219]

[0000858877-24-000030:mdna:173]
|  |  | Three Months Ended |
|  |  | October 26,2024 |  | October 28,2023 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | (25) |  |  | $ | (20) |  |  | $ | (5) |  |
| Marketable equity investments |  | 24 |  |  | (46) |  |  | 70 |  |
| Privately held investments |  | 74 |  |  | (5) |  |  | 79 |  |
| Net gains (losses) on investments |  | 73 |  |  | (71) |  |  | 144 |  |
| Other gains (losses), net |  | (32) |  |  | (12) |  |  | (20) |  |
| Other income (loss), net |  | $ | 41 |  |  | $ | (83) |  |  | $ | 124 |  |

[0000858877-24-000030:mdna:174]
[same as prior period, unchanged from 0000858877-24-000007:mdna:195]

[0000858877-24-000030:mdna:175]
[same as prior period, unchanged from 0000858877-24-000007:mdna:196]

[0000858877-24-000030:mdna:176]
Three Months Ended October 26, 2024 Compared with Three Months Ended October 28, 2023

[0000858877-24-000030:mdna:177]
The change in our other income (loss), net was primarily driven by net gains on our privately held investments and marketable equity investments and unfavorable impacts from foreign exchange.

[0000858877-24-000030:mdna:178]
Provision for (Benefit from) Income Taxes

[0000858877-24-000030:mdna:179]
Three Months Ended October 26, 2024 Compared with Three Months Ended October 28, 2023

[0000858877-24-000030:mdna:180]
The provision for (benefit from) income taxes resulted in an effective tax rate of (19.6)% for the first quarter of fiscal 2025 compared with an effective tax rate of 18.1% for the first quarter of fiscal 2024. The decrease in the effective tax rate was primarily due to a $720 million benefit related to a U.S. Tax Court opinion issued during the quarter regarding the U.S. taxation of deemed foreign dividends in the transition year of the Tax Cuts and Jobs Act (our fiscal 2018).

[0000858877-24-000030:mdna:181]
[same as prior period, unchanged from 0000858877-24-000007:mdna:213]

[0000858877-24-000030:mdna:182]
[same as prior period, unchanged from 0000858877-24-000007:mdna:214]

[0000858877-24-000030:mdna:183]
[same as prior period, unchanged from 0000858877-24-000007:mdna:233]

[0000858877-24-000030:mdna:184]
[same as prior period, unchanged from 0000858877-24-000007:mdna:234]

[0000858877-24-000030:mdna:185]
[same as prior period, unchanged from 0000858877-24-000007:mdna:235]

[0000858877-24-000030:mdna:186]
[same as prior period, unchanged from 0000858877-24-000007:mdna:236]

[0000858877-24-000030:mdna:187]
|  | October 26,2024 |  | July 27,2024 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 9,065 |  |  | $ | 7,508 |  |  | $ | 1,557 |  |
| Available-for-sale debt investments | 9,194 |  |  | 9,865 |  |  | (671) |  |
| Marketable equity securities | 412 |  |  | 481 |  |  | (69) |  |
| Total | $ | 18,671 |  |  | $ | 17,854 |  |  | $ | 817 |  |

[0000858877-24-000030:mdna:188]
The net increase in cash and cash equivalents and investments in the first quarter of fiscal 2025 was primarily driven by net cash provided by operating activities of $3.7 billion and net issuances of commercial paper of $1.0 billion. These sources of cash were partially offset by cash returned to stockholders in the form of cash dividends of $1.6 billion and repurchases of common stock of $2.0 billion, net cash paid for acquisitions and divestitures of $0.2 billion and capital expenditures of $0.2 billion.

[0000858877-24-000030:mdna:189]
[same as prior period, unchanged from 0000858877-24-000007:mdna:239]

[0000858877-24-000030:mdna:190]
Securities Lending   We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 26, 2024 and July 27, 2024, we had no outstanding securities lending transactions.

[0000858877-24-000030:mdna:191]
[same as prior period, unchanged from 0000858877-24-000007:mdna:241]

[0000858877-24-000030:mdna:192]
[same as prior period, unchanged from 0000858877-24-000007:mdna:242]

[0000858877-24-000030:mdna:193]
|  | Three Months Ended |
|  | October 26,2024 |  | October 28,2023 |
| Net cash provided by operating activities | $ | 3,661 |  |  | $ | 2,371 |  |
| Acquisition of property and equipment | (217) |  |  | (134) |  |
| Free cash flow | $ | 3,444 |  |  | $ | 2,237 |  |

[0000858877-24-000030:mdna:194]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue, and the timing and amount of tax and other payments. For additional discussion, see “Part II, Item 1A. Risk Factors” in this report.

[0000858877-24-000030:mdna:195]
[same as prior period, unchanged from 0000858877-24-000007:mdna:231]

[0000858877-24-000030:mdna:196]
[same as prior period, unchanged from 0000858877-24-000007:mdna:232]

[0000858877-24-000030:mdna:197]
[same as prior period, unchanged from 0000858877-24-000007:mdna:248]

[0000858877-24-000030:mdna:198]
[same as prior period, unchanged from 0000858877-24-000007:mdna:249]

[0000858877-24-000030:mdna:199]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2025 |  |  |  |  |  |  |  |  |  |  |  |  |
| October 26, 2024 |  | $ | 0.40 |  |  | $ | 1,592 |  |  | 40 |  |  | $ | 49.56 |  |  | $ | 2,003 |  |  | $ | 3,595 |  |
| Fiscal 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 27, 2024 |  | $ | 0.40 |  |  | $ | 1,606 |  |  | 43 |  |  | $ | 46.80 |  |  | $ | 2,002 |  |  | $ | 3,608 |  |
| April 27, 2024 |  | $ | 0.40 |  |  | $ | 1,615 |  |  | 26 |  |  | $ | 49.22 |  |  | $ | 1,256 |  |  | $ | 2,871 |  |
| January 27, 2024 |  | $ | 0.39 |  |  | $ | 1,583 |  |  | 25 |  |  | $ | 49.54 |  |  | $ | 1,254 |  |  | $ | 2,837 |  |
| October 28, 2023 |  | $ | 0.39 |  |  | $ | 1,580 |  |  | 23 |  |  | $ | 54.53 |  |  | $ | 1,252 |  |  | $ | 2,832 |  |

[0000858877-24-000030:mdna:200]
On November 13, 2024, our Board of Directors declared a quarterly dividend of $0.40 per common share to be paid on January 22, 2025, to all stockholders of record as of the close of business on January 3, 2025. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-24-000030:mdna:201]
The remaining authorized amount for stock repurchases under this program is approximately $3.2 billion, with no termination date.

[0000858877-24-000030:mdna:202]
[same as prior period, unchanged from 0000858877-24-000007:mdna:253]

[0000858877-24-000030:mdna:203]
|  | October 26,2024 |  | July 27,2024 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,457 |  |  | $ | 6,685 |  |  | $ | (2,228) |  |

[0000858877-24-000030:mdna:204]
Our accounts receivable net, as of October 26, 2024 decreased by approximately 33%, as compared with the end of fiscal 2024, primarily due to timing and amount of product and service billings in the first quarter of fiscal 2025 compared with the fourth quarter of fiscal 2024.

[0000858877-24-000030:mdna:205]
[same as prior period, unchanged from 0000858877-24-000007:mdna:245]

[0000858877-24-000030:mdna:206]
[same as prior period, unchanged from 0000858877-24-000007:mdna:246]

[0000858877-24-000030:mdna:207]
[same as prior period, unchanged from 0000858877-24-000007:mdna:258]

[0000858877-24-000030:mdna:208]
|  | October 26,2024 |  | July 27,2024 |  | July 29,2023 |  | Variance vs. July 27, 2024 |  | Variance vs. July 29, 2023 |
| Inventories | $ | 3,143 |  |  | $ | 3,373 |  |  | $ | 3,644 |  |  | $ | (230) |  |  | $ | (501) |  |
| Inventory purchase commitments | $ | 5,321 |  |  | $ | 5,158 |  |  | $ | 7,253 |  |  | $ | 163 |  |  | $ | (1,932) |  |
| Inventory deposits and prepayments | $ | 935 |  |  | $ | 973 |  |  | $ | 1,109 |  |  | $ | (38) |  |  | $ | (174) |  |

[0000858877-24-000030:mdna:209]
[same as prior period, unchanged from 0000858877-24-000007:mdna:260]

[0000858877-24-000030:mdna:210]
|  | October 26,2024 |  | July 27,2024 |  | July 29,2023 |  | Variance vs. July 27, 2024 |  | Variance vs.July 29, 2023 |
| Less than 1 year | $ | 4,309 |  |  | $ | 3,952 |  |  | $ | 5,270 |  |  | $ | 357 |  |  | $ | (961) |  |
| 1 to 3 years | 886 |  |  | 1,085 |  |  | 1,783 |  |  | (199) |  |  | (897) |  |
| 3 to 5 years | 126 |  |  | 121 |  |  | 200 |  |  | 5 |  |  | (74) |  |
| Total | $ | 5,321 |  |  | $ | 5,158 |  |  | $ | 7,253 |  |  | $ | 163 |  |  | $ | (1,932) |  |

[0000858877-24-000030:mdna:211]
Inventory as of October 26, 2024 decreased by 7% and inventory purchase commitments with contract manufacturers and suppliers increased by 3% from our balances at the end of fiscal 2024. The combined decrease of 1% in our inventory and inventory purchase commitments as compared with the end of fiscal 2024 was primarily due to our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitment levels.

[0000858877-24-000030:mdna:212]
[same as prior period, unchanged from 0000858877-24-000007:mdna:264]

[0000858877-24-000030:mdna:213]
Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments are entered into directly with suppliers and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-24-000030:mdna:214]
[same as prior period, unchanged from 0000858877-24-000007:mdna:266]

[0000858877-24-000030:mdna:215]
[same as prior period, unchanged from 0000858877-24-000007:mdna:267]

[0000858877-24-000030:mdna:216]
|  | October 26,2024 |  | July 27,2024 |  | Increase (Decrease) |
| Loan receivables, net | $ | 5,534 |  |  | $ | 5,808 |  |  | $ | (274) |  |
| Lease receivables, net | 1,000 |  |  | 906 |  |  | 94 |  |
| Total, net | $ | 6,534 |  |  | $ | 6,714 |  |  | $ | (180) |  |

[0000858877-24-000030:mdna:217]
Financing Receivables  Our financing arrangements include loans and leases. Our loan receivables include customer financing for purchases of our hardware, software and services (including technical support and advanced services), and also may include additional funds for other costs associated with network installation and integration of our products and services. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Financing receivables decreased by 3% as compared with the end of fiscal 2024.

[0000858877-24-000030:mdna:218]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and

[0000858877-24-000030:mdna:219]
[same as prior period, unchanged from 0000858877-24-000007:mdna:256]

[0000858877-24-000030:mdna:220]
[same as prior period, unchanged from 0000858877-24-000007:mdna:257]

[0000858877-24-000030:mdna:221]
loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, with payment terms generally ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-24-000030:mdna:222]
The volume of channel partner financing was $6.0 billion and $8.2 billion for the first quarter of fiscal 2025 and 2024, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.1 billion and $1.2 billion as of October 26, 2024 and July 27, 2024, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of October 26, 2024, the total maximum potential future payments related to these guarantees was approximately $123 million, of which approximately $12 million was recorded as deferred revenue.

[0000858877-24-000030:mdna:223]
[same as prior period, unchanged from 0000858877-24-000007:mdna:274]

[0000858877-24-000030:mdna:224]
[same as prior period, unchanged from 0000858877-24-000007:mdna:275]

[0000858877-24-000030:mdna:225]
|  | Maturity Date |  | October 26,2024 |  | July 27,2024 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | $ | 500 |  |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 1,000 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 2,000 |  |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 2,500 |  |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 2,500 |  |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 2,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 2,000 |  |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 1,000 |  |
| Total |  |  | $ | 20,250 |  |  | $ | 20,250 |  |

[0000858877-24-000030:mdna:226]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of October 26, 2024.

[0000858877-24-000030:mdna:227]
Commercial Paper  We have a short-term debt financing program in which up to $15.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had $11.9 billion and $10.9 billion in commercial paper notes outstanding as of October 26, 2024 and July 27, 2024, respectively.

[0000858877-24-000030:mdna:228]
Credit Facility  On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of October 26, 2024, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.

[0000858877-24-000030:mdna:229]
[same as prior period, unchanged from 0000858877-24-000007:mdna:269]

[0000858877-24-000030:mdna:230]
[same as prior period, unchanged from 0000858877-24-000007:mdna:270]

[0000858877-24-000030:mdna:231]
[same as prior period, unchanged from 0000858877-24-000007:mdna:283]

[0000858877-24-000030:mdna:232]
|  | October 26,2024 |  | July 27,2024 |  | Increase (Decrease) |
| Product | $ | 19,882 |  |  | $ | 20,055 |  |  | $ | (173) |  |
| Services | 20,108 |  |  | 20,993 |  |  | (885) |  |
| Total | $ | 39,990 |  |  | $ | 41,048 |  |  | $ | (1,058) |  |
| Short-term RPO | $ | 20,310 |  |  | $ | 20,882 |  |  | $ | (572) |  |
| Long-term RPO | 19,680 |  |  | 20,166 |  |  | (486) |  |
| Total | $ | 39,990 |  |  | $ | 41,048 |  |  | $ | (1,058) |  |

[0000858877-24-000030:mdna:233]
Total remaining performance obligations as of October 26, 2024 decreased 3% compared to the end of fiscal 2024. Remaining performance obligations for product decreased by 1% compared to the end of fiscal 2024. Remaining performance obligations for services decreased by 4%. We expect approximately 51% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-24-000030:mdna:234]
[same as prior period, unchanged from 0000858877-24-000007:mdna:286]

[0000858877-24-000030:mdna:235]
|  | October 26,2024 |  | July 27,2024 |  | Increase (Decrease) |
| Product | $ | 12,941 |  |  | $ | 13,219 |  |  | $ | (278) |  |
| Services | 14,561 |  |  | 15,256 |  |  | (695) |  |
| Total | $ | 27,502 |  |  | $ | 28,475 |  |  | $ | (973) |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 15,615 |  |  | $ | 16,249 |  |  | $ | (634) |  |
| Noncurrent | 11,887 |  |  | 12,226 |  |  | (339) |  |
| Total | $ | 27,502 |  |  | $ | 28,475 |  |  | $ | (973) |  |

[0000858877-24-000030:mdna:236]
Total deferred revenue decreased 3% compared to the end of fiscal 2024. The decrease in deferred product revenue of 2% was primarily due to lower business volume. The decrease in deferred services revenue of 5% was driven by lower business volume and ongoing amortization of deferred services revenue.

[0000858877-24-000030:mdna:237]
[same as prior period, unchanged from 0000858877-24-000007:mdna:289]

[0000858877-24-000030:mdna:238]
[same as prior period, unchanged from 0000858877-24-000007:mdna:290]

[0000858877-24-000030:mdna:239]
The income tax payable outstanding as of October 26, 2024 for the U.S. transition tax on accumulated earnings for foreign subsidiaries was $3.4 billion. Approximately $1.8 billion is payable in the second quarter of fiscal 2025 and $1.6 billion is payable in the second quarter of fiscal 2026.

[0000858877-24-000030:mdna:240]
For our Contractual Obligations see our Annual Report on Form 10-K for the fiscal year ended July 27, 2024.

[0000858877-24-000030:mdna:241]
[same as prior period, unchanged from 0000858877-24-000007:mdna:279]

[0000858877-24-000030:mdna:242]
[same as prior period, unchanged from 0000858877-24-000007:mdna:280]

[0000858877-24-000030:mdna:243]
[same as prior period, unchanged from 0000858877-24-000007:mdna:295]

[0000858877-24-000030:mdna:244]
[same as prior period, unchanged from 0000858877-24-000007:mdna:296]

[0000858877-24-000030:mdna:245]
We also have certain funding commitments primarily related to our privately held investments. The funding commitments were $0.3 billion and $0.2 billion as of October 26, 2024 and July 27, 2024, respectively.

[0000858877-24-000030:mdna:246]
In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of October 26, 2024 there were no material unconsolidated variable interest entities.

[0000858877-24-000030:mdna:247]
[same as prior period, unchanged from 0000858877-24-000007:mdna:299]

[0000858877-24-000030:mdna:248]
[same as prior period, unchanged from 0000858877-24-000007:mdna:300]

[0000858877-24-000030:mdna:249]
[same as prior period, unchanged from 0000858877-24-000007:mdna:301]

[0000858877-24-000030:mdna:250]
[same as prior period, unchanged from 0000858877-24-000007:mdna:302]
