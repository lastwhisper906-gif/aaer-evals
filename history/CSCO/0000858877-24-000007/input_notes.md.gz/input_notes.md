# CSCO notes — 0000858877-24-000007


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-24-000007:notes:1]
[same as prior period, unchanged from 0000858877-24-000003:notes:1]

[0000858877-24-000007:notes:2]
We have prepared the accompanying financial data as of April 27, 2024 and for the third quarter and first nine months of fiscal 2024 and 2023, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 29, 2023 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 29, 2023.

[0000858877-24-000007:notes:3]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of April 27, 2024, the results of operations, the statements of comprehensive income and the statements of equity for the third quarter and first nine months of fiscal 2024 and 2023, and the statements of cash flows for the first nine months of fiscal 2024 and 2023, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2024 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-24-000007:notes:4]
[same as prior period, unchanged from 0000858877-24-000003:notes:4]

[0000858877-24-000007:notes:5]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-24-000007:notes:6]
[same as prior period, unchanged from 0000858877-24-000003:notes:6]

[0000858877-24-000007:notes:7]
[same as prior period, unchanged from 0000858877-24-000003:notes:7]

[0000858877-24-000007:notes:8]
[same as prior period, unchanged from 0000858877-24-000003:notes:8]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-24-000007:notes:9]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

[0000858877-24-000007:notes:10]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-24-000007:notes:11]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 27, 2024 and July 29, 2023 was $35 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-24-000007:notes:12]
Significant Judgments

[0000858877-24-000007:notes:13]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-24-000007:notes:14]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.

[0000858877-24-000007:notes:15]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license’s utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

[0000858877-24-000007:notes:16]
[same as prior period, unchanged from 0000858877-24-000003:notes:18]

[0000858877-24-000007:notes:17]
[same as prior period, unchanged from 0000858877-24-000003:notes:19]

[0000858877-24-000007:notes:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 6,522 |  |  | $ | 8,982 |  |  | $ | 22,425 |  |  | $ | 25,105 |  |
| Security | 1,304 |  |  | 958 |  |  | 3,288 |  |  | 2,872 |  |
| Collaboration | 987 |  |  | 985 |  |  | 3,093 |  |  | 3,029 |  |
| Observability | 211 |  |  | 167 |  |  | 589 |  |  | 486 |  |
| Total Product | 9,024 |  |  | 11,092 |  |  | 29,395 |  |  | 31,492 |  |
| Services | 3,678 |  |  | 3,479 |  |  | 10,766 |  |  | 10,303 |  |
| Total | $ | 12,702 |  |  | $ | 14,571 |  |  | $ | 40,161 |  |  | $ | 41,795 |  |

[0000858877-24-000007:notes:19]
[same as prior period, unchanged from 0000858877-24-000003:notes:21]

[0000858877-24-000007:notes:20]
[same as prior period, unchanged from 0000858877-24-000003:notes:22]

[0000858877-24-000007:notes:21]
Security consists of our Cloud and Application Security, Industrial Security, Network Security, and User and Device Security offerings. This product category includes the Splunk Platform and Splunk Security offerings after our acquisition of Splunk, although the Splunk Platform has use cases that can also be applicable for observability offerings. See Note 4. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-24-000007:notes:22]
[same as prior period, unchanged from 0000858877-24-000003:notes:24]

[0000858877-24-000007:notes:23]
Observability consists of our full stack observability offerings. This product category includes the Splunk Observability Suite after our acquisition of Splunk. This product category excludes the Splunk Platform which includes use cases that can also be associated with observability offerings. See Note 4. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-24-000007:notes:24]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and advanced services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Advanced services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

[0000858877-24-000007:notes:25]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.

[0000858877-24-000007:notes:26]
[same as prior period, unchanged from 0000858877-24-000003:notes:26]

[0000858877-24-000007:notes:27]
[same as prior period, unchanged from 0000858877-24-000003:notes:27]

[0000858877-24-000007:notes:28]
Accounts receivable, net was $5.1 billion as of April 27, 2024 compared to $5.9 billion as of July 29, 2023, as reported on the Consolidated Balance Sheets.

[0000858877-24-000007:notes:29]
[same as prior period, unchanged from 0000858877-24-000003:notes:29]

[0000858877-24-000007:notes:30]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2024 |  | April 29, 2023 |  | April 27, 2024 |  | April 29, 2023 |
| Allowance for credit loss at beginning of period | $ | 79 |  |  | $ | 86 |  |  | $ | 85 |  |  | $ | 83 |  |
| Provisions | 10 |  |  | 9 |  |  | 21 |  |  | 23 |  |
| Recoveries (write-offs), net | (8) |  |  | (12) |  |  | (25) |  |  | (23) |  |
| Allowance for credit loss at end of period | $ | 81 |  |  | $ | 83 |  |  | $ | 81 |  |  | $ | 83 |  |

[0000858877-24-000007:notes:31]
[same as prior period, unchanged from 0000858877-24-000003:notes:31]

[0000858877-24-000007:notes:32]
[same as prior period, unchanged from 0000858877-24-000003:notes:32]

[0000858877-24-000007:notes:33]
|  | April 27,2024 |  | July 29,2023 |
| 1 to 4 | $ | 1,176 |  |  | $ | 672 |  |
| 5 to 6 | 1,383 |  |  | 954 |  |
| 7 and Higher | 70 |  |  | 60 |  |
| Total | $ | 2,629 |  |  | $ | 1,686 |  |

[0000858877-24-000007:notes:34]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $2.6 billion as of April 27, 2024 and $1.6 billion as of July 29, 2023, and were included in other current assets and other assets.

[0000858877-24-000007:notes:35]
Contract liabilities consist of deferred revenue. Deferred revenue was $27.5 billion as of April 27, 2024 compared to $25.6 billion as of July 29, 2023. We recognized approximately $3.0 billion and $11.5 billion of revenue during the third quarter and first nine months of fiscal 2024 that was included in the deferred revenue balance at July 29, 2023.

[0000858877-24-000007:notes:36]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Capitalized contract acquisition costs were $1.3 billion and $1.1 billion as of April 27, 2024 and July 29, 2023, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $201 million and $525 million for the third quarter and first nine months fiscal 2024, respectively, and $172 million and $549 million for the corresponding periods of fiscal 2023, respectively, and was included in sales and marketing expenses.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-24-000007:notes:37]
[same as prior period, unchanged from 0000858877-24-000003:notes:37]

[0000858877-24-000007:notes:38]
[same as prior period, unchanged from 0000858877-24-000003:notes:38]

[0000858877-24-000007:notes:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Revenue: |  |  |  |  |  |  |  |
| Networking | $ | 6,522 |  |  | $ | 8,982 |  |  | $ | 22,425 |  |  | $ | 25,105 |  |
| Security | 1,304 |  |  | 958 |  |  | 3,288 |  |  | 2,872 |  |
| Collaboration | 987 |  |  | 985 |  |  | 3,093 |  |  | 3,029 |  |
| Observability | 211 |  |  | 167 |  |  | 589 |  |  | 486 |  |
| Total Product | 9,024 |  |  | 11,092 |  |  | 29,395 |  |  | 31,492 |  |
| Services | 3,678 |  |  | 3,479 |  |  | 10,766 |  |  | 10,303 |  |
| Total | $ | 12,702 |  |  | $ | 14,571 |  |  | $ | 40,161 |  |  | $ | 41,795 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-24-000007:notes:40]
Acquisitions
Acquisition of Splunk Inc.

[0000858877-24-000007:notes:41]
On March 18, 2024, we completed the acquisition of Splunk Inc. (“Splunk”), a public cybersecurity and observability company. Under the terms of the agreement, we agreed to pay $157 per share in cash, representing approximately $27 billion in merger consideration.

[0000858877-24-000007:notes:42]
Purchase Consideration

[0000858877-24-000007:notes:43]
The following table summarizes the purchase consideration for the Splunk acquisition (in millions):

[0000858877-24-000007:notes:44]
|  |  | Amount |
| Cash paid for outstanding Splunk common stock |  | $ | 26,950 |  |
| Fair value of converted Splunk equity awards attributable to pre-acquisition services |  | 137 |  |
| Settlement of pre-existing relationships |  | 3 |  |
| Total purchase consideration |  | $ | 27,090 |  |

[0000858877-24-000007:notes:45]
A summary of the preliminary allocation of the total purchase consideration for Splunk is presented as follows (in millions):

[0000858877-24-000007:notes:46]
|  |  | Amount |
| Cash and cash equivalents |  | $ | 2,422 |  |
| Investments |  | 285 |  |
| Accounts receivable, net |  | 623 |  |
| Goodwill |  | 19,301 |  |
| Purchased intangible assets |  | 10,550 |  |
| Deferred tax assets |  | 1,308 |  |
| Other current and other assets |  | 1,176 |  |
| Accounts payable |  | (39) |  |
| Accrued compensation |  | (337) |  |
| Current portion of deferred revenue |  | (1,768) |  |
| Splunk convertible notes |  | (3,344) |  |
| Deferred tax liabilities |  | (2,572) |  |
| Long-term portion of deferred revenue |  | (86) |  |
| Other current and other long-term liabilities |  | (429) |  |
| Total |  | $ | 27,090 |  |

[0000858877-24-000007:notes:47]
The purchase price allocation for Splunk is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information that existed as of the acquisition date but is currently unknown to us may become known during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date.

[0000858877-24-000007:notes:48]
Our Consolidated Statements of Operations for the third quarter and first nine months of fiscal 2024 include revenue of $413 million and a net loss of $212 million attributable to Splunk since the date of acquisition.

[0000858877-24-000007:notes:49]
We incurred $85 million of transaction costs related to the Splunk acquisition and these costs were expensed as incurred in general and administrative expenses (“G&A”) expenses in the Consolidated Statements of Operations. We incurred $49 million and $84 million of these costs in the third quarter and first nine months of fiscal 2024, respectively.

[0000858877-24-000007:notes:50]
In connection with the Splunk acquisition, we assumed $3.1 billion aggregate principal amount of notes consisting of Splunk's 1.125% Convertible Senior Notes due 2025, 0.75% Convertible Senior Notes due 2026 and 1.125% Convertible Senior Notes due 2027 (collectively, the “Splunk Convertible Notes”). The Splunk Convertible Notes had an aggregate fair value of $3.3 billion as of the acquisition date. The Splunk Convertible Notes are convertible and may be settled into cash based on a defined conversion ratio for each note. On the date of the acquisition, we notified holders of their right to convert their notes. In addition, we assumed Splunk’s capped call contracts which were intended to reduce potential dilution or offset any cash payments. The capped calls were settled in full in the third quarter of fiscal 2024, which resulted in receipt of aggregate cash proceeds of $202 million, and were included in other current assets in total purchase consideration noted above. As of April 27, 2024, we have settled $3.1 billion of the Splunk Convertible Notes, net of capped calls.

[0000858877-24-000007:notes:51]
The goodwill generated from Splunk is primarily related to expected synergies. Goodwill is not deductible for income tax purposes.

[0000858877-24-000007:notes:52]
Purchased Intangible Assets

[0000858877-24-000007:notes:53]
The following table presents as of the acquisition date details of the purchased intangible assets acquired (in millions, except years):

[0000858877-24-000007:notes:54]
|  |  | Weighted-Average Useful Life (in Years) |  | Amount |
| Technology |  | 6.0 |  | $ | 3,900 |  |
| Customer related |  | 9.1 |  | 6,140 |  |
| Trade name |  | 12.0 |  | 510 |  |
| Total |  |  |  | $ | 10,550 |  |

[0000858877-24-000007:notes:55]
Technology represents the preliminary estimated fair value of Splunk's security and observability technologies. Customer related represents preliminary estimated fair value of the underlying relationships with Splunk's customers. Trade name represents the preliminary estimated fair value of the Splunk trade name.

[0000858877-24-000007:notes:56]
Compensation Expense Related to Splunk

[0000858877-24-000007:notes:57]
In connection with the Splunk acquisition, we have agreed to pay certain additional amounts contingent upon the continued employment with Cisco of certain Splunk employees. For the third quarter and first nine months of fiscal 2024, the compensation expense was $165 million. As of April 27, 2024, we estimated that future cash compensation expense of up to $1.5 billion may be required to be recognized pursuant to acquisition-related agreements.

[0000858877-24-000007:notes:58]
Pro forma Financial Information

[0000858877-24-000007:notes:59]
The unaudited pro forma financial information in the table below summarizes the combined results of our operations and Splunk's operations, as though the acquisition of Splunk had been completed as of the beginning of fiscal 2023. The pro forma financial information for the third quarter of fiscal 2024 combines our results for this period with that of Splunk's results for the three month period beginning February 1, 2024 through April 27, 2024. The pro forma financial information for the first nine months of fiscal 2024 combines our results for this period with the results of Splunk for the nine month period beginning August 1, 2023 through April 27, 2024. The pro forma financial information for the third quarter and first nine months of fiscal 2023 combines our historical results for those periods, with the historical results of Splunk for the three and nine months ended April 30, 2023.

[0000858877-24-000007:notes:60]
The following table summarizes the pro forma financial information (in millions):

[0000858877-24-000007:notes:61]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2024 |  | April 29, 2023 |  | April 27, 2024 |  | April 29, 2023 |
| Total revenue | $ | 13,107 |  |  | $ | 15,323 |  |  | $ | 43,119 |  |  | $ | 44,727 |  |
| Net income | $ | 1,490 |  |  | $ | 2,423 |  |  | $ | 7,127 |  |  | $ | 6,776 |  |

[0000858877-24-000007:notes:62]
The pro forma financial information is presented for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition and the cost of financing the acquisition had taken place at the beginning of fiscal 2023. The financial information for the periods presented above includes pro forma adjustments for amortization of purchased intangible assets, costs related to financing the acquisition and transaction costs.

[0000858877-24-000007:notes:63]
The above pro forma financial information includes only the impacts of the Splunk acquisition because the effects of the other acquisitions detailed below, individually and in the aggregate, were not material to our financial results.

[0000858877-24-000007:notes:64]
Other Acquisitions

[0000858877-24-000007:notes:65]
We completed several additional acquisitions during the first nine months of fiscal 2024 for an aggregate cash consideration of $1.4 billion. A summary of the allocation of the total purchase consideration of these additional acquisitions completed during the first nine months of fiscal 2024 is presented as follows (in millions):

[0000858877-24-000007:notes:66]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total other acquisitions | $ | 1,370 |  |  | $ | (82) |  |  | $ | 500 |  |  | $ | 952 |  |

[0000858877-24-000007:notes:67]
The total purchase consideration related to these other acquisitions completed during the first nine months of fiscal 2024 consisted primarily of cash consideration. The total cash and cash equivalents acquired from these acquisitions was approximately $24 million. Total transaction costs related to these acquisition activities were $18 million and $6 million for the first nine months of fiscal 2024 and 2023, respectively. These transaction costs were expensed as incurred in G&A in the Consolidated Statements of Operations.

[0000858877-24-000007:notes:68]
The purchase price allocation for these acquisitions completed during recent periods is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information that existed as of the acquisition date but is currently unknown to us may become known during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date.

[0000858877-24-000007:notes:69]
The goodwill generated from these acquisitions completed during the first nine months of fiscal 2024 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-24-000007:notes:70]
Compensation Expense Related to Acquisitions including Splunk

[0000858877-24-000007:notes:71]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-24-000007:notes:72]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-24-000007:notes:73]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2024 |  | April 29, 2023 |  | April 27, 2024 |  | April 29, 2023 |
| Compensation expense related to acquisitions | $ | 216 |  |  | $ | 53 |  |  | $ | 310 |  |  | $ | 176 |  |

[0000858877-24-000007:notes:74]
As of April 27, 2024, we estimated that future cash compensation expense of up to $2.0 billion may be required to be recognized pursuant to these applicable acquisition agreements, which includes up to $1.5 billion related to the Splunk acquisition. Total compensation for the third quarter and first nine months of fiscal 2024 includes $165 million related to the Splunk acquisition.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0000858877-24-000007:notes:75]
A summary of the allocation of the total purchase consideration of these additional acquisitions completed during the first nine months of fiscal 2024 is presented as follows (in millions):


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-24-000007:notes:76]
[same as prior period, unchanged from 0000858877-24-000003:notes:47]

[0000858877-24-000007:notes:77]
The following table presents the goodwill allocated to our reportable segments as of April 27, 2024 and during the first nine months of fiscal 2024 (in millions):

[0000858877-24-000007:notes:78]
|  | Balance at July 29, 2023 |  | Splunk |  | Other Acquisitions |  | Foreign Currency Translation and Other |  | Balance at April 27, 2024 |
| Americas | $ | 24,035 |  |  | $ | 11,619 |  |  | $ | 594 |  |  | $ | (96) |  |  | $ | 36,152 |  |
| EMEA | 9,118 |  |  | 4,980 |  |  | 216 |  |  | (37) |  |  | 14,277 |  |
| APJC | 5,382 |  |  | 2,702 |  |  | 142 |  |  | (22) |  |  | 8,204 |  |
| Total | $ | 38,535 |  |  | $ | 19,301 |  |  | $ | 952 |  |  | $ | (155) |  |  | $ | 58,633 |  |

[0000858877-24-000007:notes:79]
[same as prior period, unchanged from 0000858877-24-000003:notes:50]

[0000858877-24-000007:notes:80]
The following table presents details of our intangible assets acquired through acquisitions completed during the first nine months of fiscal 2024 (in millions, except years):

[0000858877-24-000007:notes:81]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATED |  | TRADE NAME |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Splunk | 6.0 |  | $ | 3,900 |  |  | 9.1 |  | $ | 6,140 |  |  | 12.0 |  | $ | 510 |  |  | $ | — |  |  | $ | 10,550 |  |
| Others | 4.8 |  | 405 |  |  | 4.9 |  | 78 |  |  | 1.3 |  | 3 |  |  | 14 |  |  | 500 |  |
| Total |  |  | $ | 4,305 |  |  |  |  | $ | 6,218 |  |  |  |  | $ | 513 |  |  | $ | 14 |  |  | $ | 11,050 |  |

[0000858877-24-000007:notes:82]
[same as prior period, unchanged from 0000858877-24-000003:notes:53]

[0000858877-24-000007:notes:83]
| April 27, 2024 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 6,946 |  |  | $ | (1,948) |  |  | $ | 4,998 |  |
| Customer related |  | 6,882 |  |  | (619) |  |  | 6,263 |  |
| Trade name |  | 553 |  |  | (35) |  |  | 518 |  |
| Total purchased intangible assets with finite lives |  | 14,381 |  |  | (2,602) |  |  | 11,779 |  |
| In-process research and development, with indefinite lives |  | 40 |  |  | — |  |  | 40 |  |
| Total |  | $ | 14,421 |  |  | $ | (2,602) |  |  | $ | 11,819 |  |

[0000858877-24-000007:notes:84]
| July 29, 2023 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 2,998 |  |  | $ | (1,691) |  |  | $ | 1,307 |  |
| Customer related |  | 1,228 |  |  | (905) |  |  | 323 |  |
| Other |  | 40 |  |  | (22) |  |  | 18 |  |
| Total purchased intangible assets with finite lives |  | 4,266 |  |  | (2,618) |  |  | 1,648 |  |
| In-process research and development, with indefinite lives |  | 170 |  |  | — |  |  | 170 |  |
| Total |  | $ | 4,436 |  |  | $ | (2,618) |  |  | $ | 1,818 |  |

[0000858877-24-000007:notes:85]
[same as prior period, unchanged from 0000858877-24-000003:notes:56]

[0000858877-24-000007:notes:86]
Impairment charges related to purchased intangible assets were $139 million and $145 million for the third quarter and first nine months of fiscal 2024, respectively. Impairment charges were as a result of declines in estimated fair value resulting from the reductions in or the elimination of expected future cash flows associated with certain of our IPR&D intangible assets.

[0000858877-24-000007:notes:87]
[same as prior period, unchanged from 0000858877-24-000003:notes:57]

[0000858877-24-000007:notes:88]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2024 |  | April 29, 2023 |  | April 27, 2024 |  | April 29, 2023 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 254 |  |  | $ | 160 |  |  | $ | 620 |  |  | $ | 476 |  |
| Operating expenses | 297 |  |  | 70 |  |  | 430 |  |  | 212 |  |
| Total | $ | 551 |  |  | $ | 230 |  |  | $ | 1,050 |  |  | $ | 688 |  |

[0000858877-24-000007:notes:89]
The estimated future amortization expense of purchased intangible assets with finite lives as of April 27, 2024 is as follows (in millions):

[0000858877-24-000007:notes:90]
| Fiscal Year | Amount |
| 2024 (remaining three months) | $ | 604 |  |
| 2025 | $ | 2,133 |  |
| 2026 | $ | 1,785 |  |
| 2027 | $ | 1,441 |  |
| 2028 | $ | 1,361 |  |
| Thereafter | $ | 4,455 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-24-000007:notes:91]
Restructuring and Other Charges
In the third quarter of fiscal 2024, we initiated a restructuring plan (the “Fiscal 2024 Plan”) in order to realign the organization and enable further investment in key priority areas. The Fiscal 2024 Plan will impact approximately 5% of our global workforce, with estimated pretax charges of up to approximately $800 million. These aggregate pretax charges will be primarily cash-based and consist of severance and other one-time termination benefits and other costs. In connection with the Fiscal 2024 Plan, we incurred charges of $542 million for the third quarter and first nine months of fiscal 2024. We expect this plan to be substantially completed during the first half of fiscal 2025.

[0000858877-24-000007:notes:92]
In the second quarter of fiscal 2023, we announced a restructuring plan (the “Fiscal 2023 Plan”) in order to rebalance the organization and enable further investment in key priority areas. In connection with the Fiscal 2023 Plan, we incurred charges of $135 million for the first nine months of fiscal 2024, and $87 million and $330 million for the third quarter and first nine months of fiscal 2023, respectively. These aggregate pretax charges were primarily cash-based and consist of severance and other one-time termination benefits, real estate-related charges, and other costs. We completed the Fiscal 2023 Plan in the second quarter of fiscal 2024 and incurred cumulative charges of $670 million.

[0000858877-24-000007:notes:93]
The following table summarizes the activities related to the restructuring and other charges (in millions):

[0000858877-24-000007:notes:94]
|  |  | FISCAL 2023 PLAN |  | FISCAL 2024 PLAN |  |  |
|  |  | Employee Severance |  | Other |  | Employee Severance |  | Other |  | Total |
| Liability as of July 29, 2023 |  | $ | 166 |  |  | $ | 44 |  |  | $ | — |  |  | $ | — |  |  | $ | 210 |  |
| Charges |  | 104 |  |  | 31 |  |  | 526 |  |  | 16 |  |  | 677 |  |
| Cash payments |  | (244) |  |  | (10) |  |  | (303) |  |  | (1) |  |  | (558) |  |
| Non-cash items |  | — |  |  | (20) |  |  | (2) |  |  | (7) |  |  | (29) |  |
| Liability as of April 27, 2024 |  | $ | 26 |  |  | $ | 45 |  |  | $ | 221 |  |  | $ | 8 |  |  | $ | 300 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-24-000007:notes:95]
[same as prior period, unchanged from 0000858877-24-000003:notes:65]

[0000858877-24-000007:notes:96]
[same as prior period, unchanged from 0000858877-24-000003:notes:66]

[0000858877-24-000007:notes:97]
|  |  | April 27,2024 |  | July 29,2023 |
| Cash and cash equivalents |  | $ | 8,913 |  |  | $ | 10,123 |  |
| Restricted cash and restricted cash equivalents included in other current assets |  | 765 |  |  | 191 |  |
| Restricted cash and restricted cash equivalents included in other assets |  | 761 |  |  | 1,313 |  |
| Total |  | $ | 10,439 |  |  | $ | 11,627 |  |

[0000858877-24-000007:notes:98]
[same as prior period, unchanged from 0000858877-24-000003:notes:68]

[0000858877-24-000007:notes:99]
[same as prior period, unchanged from 0000858877-24-000003:notes:69]

[0000858877-24-000007:notes:100]
|  |  | April 27,2024 |  | July 29,2023 |
| Raw materials |  | $ | 1,789 |  |  | $ | 1,685 |  |
| Work in process |  | 111 |  |  | 264 |  |
| Finished goods |  | 996 |  |  | 1,493 |  |
| Service-related spares |  | 212 |  |  | 186 |  |
| Demonstration systems |  | 10 |  |  | 16 |  |
| Total |  | $ | 3,118 |  |  | $ | 3,644 |  |

[0000858877-24-000007:notes:101]
[same as prior period, unchanged from 0000858877-24-000003:notes:71]

[0000858877-24-000007:notes:102]
|  |  | April 27,2024 |  | July 29,2023 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,221 |  |  | $ | 4,229 |  |
| Computer equipment and related software |  | 696 |  |  | 744 |  |
| Production, engineering, and other equipment |  | 4,411 |  |  | 4,611 |  |
| Operating lease assets |  | 120 |  |  | 135 |  |
| Furniture, fixtures and other |  | 348 |  |  | 339 |  |
| Total gross property and equipment |  | 9,796 |  |  | 10,058 |  |
| Less: accumulated depreciation and amortization |  | (7,796) |  |  | (7,973) |  |
| Total |  | $ | 2,000 |  |  | $ | 2,085 |  |

[0000858877-24-000007:notes:103]
[same as prior period, unchanged from 0000858877-24-000003:notes:73]

[0000858877-24-000007:notes:104]
|  |  | April 27,2024 |  | July 29,2023 |
| Product |  | $ | 18,876 |  |  | $ | 15,802 |  |
| Service |  | 19,898 |  |  | 19,066 |  |
| Total |  | $ | 38,774 |  |  | $ | 34,868 |  |
| Short-term RPO |  | $ | 20,089 |  |  | $ | 17,910 |  |
| Long-term RPO |  | 18,685 |  |  | 16,958 |  |
| Total |  | $ | 38,774 |  |  | $ | 34,868 |  |
| Amount to be recognized as revenue over the next 12 months |  | 52 | % |  | 51 | % |
| Deferred revenue |  | $ | 27,475 |  |  | $ | 25,550 |  |
| Unbilled contract revenue |  | 11,299 |  |  | 9,318 |  |
| Total |  | $ | 38,774 |  |  | $ | 34,868 |  |

[0000858877-24-000007:notes:105]
[same as prior period, unchanged from 0000858877-24-000003:notes:75]

[0000858877-24-000007:notes:106]
[same as prior period, unchanged from 0000858877-24-000003:notes:76]

[0000858877-24-000007:notes:107]
|  |  | April 27,2024 |  | July 29,2023 |
| Product |  | $ | 12,856 |  |  | $ | 11,505 |  |
| Service |  | 14,619 |  |  | 14,045 |  |
| Total |  | $ | 27,475 |  |  | $ | 25,550 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 15,751 |  |  | $ | 13,908 |  |
| Noncurrent |  | 11,724 |  |  | 11,642 |  |
| Total |  | $ | 27,475 |  |  | $ | 25,550 |  |

[0000858877-24-000007:notes:108]
[same as prior period, unchanged from 0000858877-24-000003:notes:78]

[0000858877-24-000007:notes:109]
[same as prior period, unchanged from 0000858877-24-000003:notes:79]

[0000858877-24-000007:notes:110]
|  |  | April 27,2024 |  | July 29,2023 |
| Current |  | $ | 1,819 |  |  | $ | 1,364 |  |
| Noncurrent |  | 2,273 |  |  | 4,092 |  |
| Total |  | $ | 4,092 |  |  | $ | 5,456 |  |


## us-gaap:OperatingLeasesOfLessorDisclosureTextBlock

[0000858877-24-000007:notes:111]
Leases 
(a)Lessee Arrangements

[0000858877-24-000007:notes:112]
The following table presents our operating lease balances (in millions):

[0000858877-24-000007:notes:113]
|  | Balance Sheet Line Item |  | April 27, 2024 |  | July 29, 2023 |
| Operating lease right-of-use assets | Other assets |  | $ | 1,008 |  |  | $ | 971 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 344 |  |  | $ | 313 |  |
| Operating lease liabilities | Other long-term liabilities |  | 861 |  |  | 707 |  |
| Total operating lease liabilities |  |  | $ | 1,205 |  |  | $ | 1,020 |  |

[0000858877-24-000007:notes:114]
The components of our lease expenses were as follows (in millions):

[0000858877-24-000007:notes:115]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2024 |  | April 29, 2023 |  | April 27, 2024 |  | April 29, 2023 |
| Operating lease expense | $ | 101 |  |  | $ | 106 |  |  | $ | 304 |  |  | $ | 300 |  |
| Short-term lease expense | 19 |  |  | 16 |  |  | 55 |  |  | 50 |  |
| Variable lease expense | 43 |  |  | 61 |  |  | 149 |  |  | 182 |  |
| Total lease expense | $ | 163 |  |  | $ | 183 |  |  | $ | 508 |  |  | $ | 532 |  |

[0000858877-24-000007:notes:116]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-24-000007:notes:117]
|  | Nine Months Ended |
|  | April 27, 2024 |  | April 29, 2023 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 279 |  |  | $ | 290 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 307 |  |  | $ | 278 |  |

[0000858877-24-000007:notes:118]
The weighted-average lease term was 4.9 years and 4.6 years as of April 27, 2024 and July 29, 2023, respectively. The weighted-average discount rate was 3.8% and 3.1% as of April 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000007:notes:119]
The maturities of our operating leases (undiscounted) as of April 27, 2024 are as follows (in millions):

[0000858877-24-000007:notes:120]
| Fiscal Year | Amount |
| 2024 (remaining three months) | $ | 105 |  |
| 2025 | 359 |  |
| 2026 | 259 |  |
| 2027 | 179 |  |
| 2028 | 126 |  |
| Thereafter | 315 |  |
| Total lease payments | 1,343 |  |
| Less interest | (138) |  |
| Total | $ | 1,205 |  |

[0000858877-24-000007:notes:121]
(b)Lessor Arrangements

[0000858877-24-000007:notes:122]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income was $18 million and $48 million for the third quarter and the first nine months of fiscal 2024, respectively, and $13 million and $36 million for the corresponding periods of fiscal 2023, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-24-000007:notes:123]
Future minimum lease payments on our lease receivables as of April 27, 2024 are summarized as follows (in millions):

[0000858877-24-000007:notes:124]
| Fiscal Year | Amount |
| 2024 (remaining three months) | $ | 192 |  |
| 2025 | 360 |  |
| 2026 | 251 |  |
| 2027 | 154 |  |
| 2028 | 126 |  |
| Thereafter | 82 |  |
| Total | 1,165 |  |
| Less: Present value of lease payments | (1,051) |  |
| Unearned income | $ | 114 |  |

[0000858877-24-000007:notes:125]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-24-000007:notes:126]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-24-000007:notes:127]
|  | April 27, 2024 |  | July 29, 2023 |
| Operating lease assets | $ | 120 |  |  | $ | 135 |  |
| Accumulated depreciation | (63) |  |  | (78) |  |
| Operating lease assets, net | $ | 57 |  |  | $ | 57 |  |

[0000858877-24-000007:notes:128]
Our operating lease income was $14 million and $45 million for the third quarter and first nine months of fiscal 2024, respectively, and $18 million and $56 million for the corresponding periods of fiscal 2023, respectively, and was included in product revenue in the Consolidated Statements of Operations.

[0000858877-24-000007:notes:129]
Minimum future rentals on noncancelable operating leases as of April 27, 2024 are summarized as follows (in millions):

[0000858877-24-000007:notes:130]
| Fiscal Year | Amount |
| 2024 (remaining three months) | $ | 8 |  |
| 2025 | 21 |  |
| 2026 | 13 |  |
| 2027 | 2 |  |
| Total | $ | 44 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-24-000007:notes:131]
[same as prior period, unchanged from 0000858877-24-000003:notes:101]

[0000858877-24-000007:notes:132]
[same as prior period, unchanged from 0000858877-24-000003:notes:102]

[0000858877-24-000007:notes:133]
[same as prior period, unchanged from 0000858877-24-000003:notes:103]

[0000858877-24-000007:notes:134]
| April 27, 2024 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,639 |  |  | $ | 1,165 |  |  | $ | 6,804 |  |
| Residual value | — |  |  | 68 |  |  | 68 |  |
| Unearned income | — |  |  | (114) |  |  | (114) |  |
| Allowance for credit loss | (49) |  |  | (15) |  |  | (64) |  |
| Total, net | $ | 5,590 |  |  | $ | 1,104 |  |  | $ | 6,694 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 3,027 |  |  | $ | 416 |  |  | $ | 3,443 |  |
| Noncurrent | 2,563 |  |  | 688 |  |  | 3,251 |  |
| Total, net | $ | 5,590 |  |  | $ | 1,104 |  |  | $ | 6,694 |  |

[0000858877-24-000007:notes:135]
[same as prior period, unchanged from 0000858877-24-000003:notes:105]

[0000858877-24-000007:notes:136]
[same as prior period, unchanged from 0000858877-24-000003:notes:106]

[0000858877-24-000007:notes:137]
[same as prior period, unchanged from 0000858877-24-000003:notes:107]

[0000858877-24-000007:notes:138]
| April 27, 2024 |  |  | Fiscal Year |  | Nine Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 25, 2020 |  | July 31, 2021 |  | July 30, 2022 |  | July 29, 2023 |  | April 27, 2024 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 12 |  |  | $ | 120 |  |  | $ | 445 |  |  | $ | 675 |  |  | $ | 1,009 |  |  | $ | 1,423 |  |  | $ | 3,684 |  |
| 5 to 6 | 18 |  |  | 46 |  |  | 145 |  |  | 187 |  |  | 525 |  |  | 915 |  |  | 1,836 |  |
| 7 and Higher | 3 |  |  | 1 |  |  | 11 |  |  | 82 |  |  | 18 |  |  | 4 |  |  | 119 |  |
| Total Loan Receivables | $ | 33 |  |  | $ | 167 |  |  | $ | 601 |  |  | $ | 944 |  |  | $ | 1,552 |  |  | $ | 2,342 |  |  | $ | 5,639 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 21 |  |  | $ | 54 |  |  | $ | 61 |  |  | $ | 213 |  |  | $ | 268 |  |  | $ | 619 |  |
| 5 to 6 | 3 |  |  | 20 |  |  | 31 |  |  | 60 |  |  | 154 |  |  | 150 |  |  | 418 |  |
| 7 and Higher | — |  |  | — |  |  | 3 |  |  | 3 |  |  | 4 |  |  | 4 |  |  | 14 |  |
| Total Lease Receivables | $ | 5 |  |  | $ | 41 |  |  | $ | 88 |  |  | $ | 124 |  |  | $ | 371 |  |  | $ | 422 |  |  | $ | 1,051 |  |
| Total | $ | 38 |  |  | $ | 208 |  |  | $ | 689 |  |  | $ | 1,068 |  |  | $ | 1,923 |  |  | $ | 2,764 |  |  | $ | 6,690 |  |

[0000858877-24-000007:notes:139]
[same as prior period, unchanged from 0000858877-24-000003:notes:109]

[0000858877-24-000007:notes:140]
The following tables present the aging analysis of gross receivables as of April 27, 2024 and July 29, 2023 (in millions):

[0000858877-24-000007:notes:141]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| April 27, 2024 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 41 |  |  | $ | 14 |  |  | $ | 36 |  |  | $ | 91 |  |  | $ | 5,548 |  |  | $ | 5,639 |  |  | $ | 16 |  |  | $ | 8 |  |  | $ | 8 |  |
| Lease receivables | 17 |  |  | 1 |  |  | 14 |  |  | 32 |  |  | 1,019 |  |  | 1,051 |  |  | 7 |  |  | — |  |  | — |  |
| Total | $ | 58 |  |  | $ | 15 |  |  | $ | 50 |  |  | $ | 123 |  |  | $ | 6,567 |  |  | $ | 6,690 |  |  | $ | 23 |  |  | $ | 8 |  |  | $ | 8 |  |

[0000858877-24-000007:notes:142]
[same as prior period, unchanged from 0000858877-24-000003:notes:112]

[0000858877-24-000007:notes:143]
[same as prior period, unchanged from 0000858877-24-000003:notes:113]

[0000858877-24-000007:notes:144]
[same as prior period, unchanged from 0000858877-24-000003:notes:114]

[0000858877-24-000007:notes:145]
[same as prior period, unchanged from 0000858877-24-000003:notes:115]

[0000858877-24-000007:notes:146]
| Three Months Ended April 27, 2024 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of January 27, 2024 | $ | 53 |  |  | $ | 16 |  |  | $ | 69 |  |
| Provisions (benefits) | (3) |  |  | — |  |  | (3) |  |
| Recoveries (write-offs), net | — |  |  | (1) |  |  | (1) |  |
| Other | (1) |  |  | — |  |  | (1) |  |
| Allowance for credit loss as of April 27, 2024 | $ | 49 |  |  | $ | 15 |  |  | $ | 64 |  |

[0000858877-24-000007:notes:147]
| Three Months Ended April 29, 2023 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of January 28, 2023 | $ | 94 |  |  | $ | 19 |  |  | $ | 113 |  |
| Provisions (benefits) | (3) |  |  | (1) |  |  | (4) |  |
| Recoveries (write-offs), net | (38) |  |  | (1) |  |  | (39) |  |
| Allowance for credit loss as of April 29, 2023 | $ | 53 |  |  | $ | 17 |  |  | $ | 70 |  |

[0000858877-24-000007:notes:148]
| Nine Months Ended April 27, 2024 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 29, 2023 | $ | 53 |  |  | $ | 19 |  |  | $ | 72 |  |
| Provisions (benefits) | 1 |  |  | (3) |  |  | (2) |  |
| Recoveries (write-offs), net | (4) |  |  | (1) |  |  | (5) |  |
| Other | (1) |  |  | — |  |  | (1) |  |
| Allowance for credit loss as of April 27, 2024 | $ | 49 |  |  | $ | 15 |  |  | $ | 64 |  |

[0000858877-24-000007:notes:149]
| Nine Months Ended April 29, 2023 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 30, 2022 | $ | 103 |  |  | $ | 23 |  |  | $ | 126 |  |
| Provisions (benefits) | (7) |  |  | (5) |  |  | (12) |  |
| Recoveries (write-offs), net | (38) |  |  | (1) |  |  | (39) |  |
| Other | (5) |  |  | — |  |  | (5) |  |
| Allowance for credit loss as of April 29, 2023 | $ | 53 |  |  | $ | 17 |  |  | $ | 70 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-24-000007:notes:150]
Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-24-000007:notes:151]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-24-000007:notes:152]
| April 27, 2024 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,411 |  |  | $ | — |  |  | $ | (49) |  |  | $ | 2,362 |  |
| U.S. government agency securities | 248 |  |  | — |  |  | (3) |  |  | 245 |  |
| Non-U.S. government and agency securities | 390 |  |  | — |  |  | — |  |  | 390 |  |
| Corporate debt securities | 3,985 |  |  | 1 |  |  | (198) |  |  | 3,788 |  |
| U.S. agency mortgage-backed securities | 2,058 |  |  | — |  |  | (228) |  |  | 1,830 |  |
| Commercial paper | 563 |  |  | — |  |  | — |  |  | 563 |  |
| Certificates of deposit | 229 |  |  | — |  |  | — |  |  | 229 |  |
| Total | $ | 9,884 |  |  | $ | 1 |  |  | $ | (478) |  |  | $ | 9,407 |  |

[0000858877-24-000007:notes:153]
| July 29, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 3,587 |  |  | $ | 1 |  |  | $ | (62) |  |  | $ | 3,526 |  |
| U.S. government agency securities | 428 |  |  | — |  |  | (5) |  |  | 423 |  |
| Non-U.S. government and agency securities | 364 |  |  | — |  |  | (1) |  |  | 363 |  |
| Corporate debt securities | 7,238 |  |  | 3 |  |  | (327) |  |  | 6,914 |  |
| U.S. agency mortgage-backed securities | 2,421 |  |  | 14 |  |  | (230) |  |  | 2,205 |  |
| Commercial paper | 1,484 |  |  | — |  |  | — |  |  | 1,484 |  |
| Certificates of deposit | 677 |  |  | — |  |  | — |  |  | 677 |  |
| Total | $ | 16,199 |  |  | $ | 18 |  |  | $ | (625) |  |  | $ | 15,592 |  |

[0000858877-24-000007:notes:154]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-24-000007:notes:155]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2024 |  | April 29, 2023 |  | April 27, 2024 |  | April 29, 2023 |
| Gross realized gains | $ | 2 |  |  | $ | 1 |  |  | $ | 7 |  |  | $ | 4 |  |
| Gross realized losses | (16) |  |  | (7) |  |  | (64) |  |  | (19) |  |
| Total | $ | (14) |  |  | $ | (6) |  |  | $ | (57) |  |  | $ | (15) |  |

[0000858877-24-000007:notes:156]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 27, 2024 and July 29, 2023 (in millions):

[0000858877-24-000007:notes:157]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,740 |  |  | $ | (25) |  |  | $ | 570 |  |  | $ | (24) |  |  | $ | 2,310 |  |  | $ | (49) |  |
| U.S. government agency securities | 175 |  |  | (1) |  |  | 65 |  |  | (2) |  |  | 240 |  |  | (3) |  |
| Non-U.S. government and agency securities | 239 |  |  | — |  |  | — |  |  | — |  |  | 239 |  |  | — |  |
| Corporate debt securities | 629 |  |  | (7) |  |  | 2,967 |  |  | (161) |  |  | 3,596 |  |  | (168) |  |
| U.S. agency mortgage-backed securities | 486 |  |  | (13) |  |  | 1,344 |  |  | (215) |  |  | 1,830 |  |  | (228) |  |
| Commercial paper | 91 |  |  | — |  |  | — |  |  | — |  |  | 91 |  |  | — |  |
| Total | $ | 3,360 |  |  | $ | (46) |  |  | $ | 4,946 |  |  | $ | (402) |  |  | $ | 8,306 |  |  | $ | (448) |  |

[0000858877-24-000007:notes:158]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 2,394 |  |  | $ | (26) |  |  | $ | 931 |  |  | $ | (36) |  |  | $ | 3,325 |  |  | $ | (62) |  |
| U.S. government agency securities | 343 |  |  | (2) |  |  | 72 |  |  | (3) |  |  | 415 |  |  | (5) |  |
| Non-U.S. government and agency securities | 363 |  |  | (1) |  |  | — |  |  | — |  |  | 363 |  |  | (1) |  |
| Corporate debt securities | 1,736 |  |  | (22) |  |  | 4,315 |  |  | (275) |  |  | 6,051 |  |  | (297) |  |
| U.S. agency mortgage-backed securities | 658 |  |  | (13) |  |  | 1,438 |  |  | (217) |  |  | 2,096 |  |  | (230) |  |
| Commercial paper | 97 |  |  | — |  |  | — |  |  | — |  |  | 97 |  |  | — |  |
| Certificates of deposit | 2 |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |
| Total | $ | 5,593 |  |  | $ | (64) |  |  | $ | 6,756 |  |  | $ | (531) |  |  | $ | 12,349 |  |  | $ | (595) |  |

[0000858877-24-000007:notes:159]
The following table summarizes the maturities of our available-for-sale debt investments as of April 27, 2024 (in millions):

[0000858877-24-000007:notes:160]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 2,745 |  |  | $ | 2,696 |  |
| After 1 year through 5 years | 5,081 |  |  | 4,881 |  |
| Mortgage-backed securities with no single maturity | 2,058 |  |  | 1,830 |  |
| Total | $ | 9,884 |  |  | $ | 9,407 |  |

[0000858877-24-000007:notes:161]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-24-000007:notes:162]
(b)Summary of Equity Investments

[0000858877-24-000007:notes:163]
We held marketable equity securities of $450 million and $431 million as of April 27, 2024 and July 29, 2023, respectively. We recognized a net unrealized gain of $20 million and $40 million during the third quarter and first nine months of fiscal 2024, respectively, and a net unrealized loss of $2 million and $11 million during the corresponding periods of fiscal 2023, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $21 million and $155 million for the third quarter and first nine months of fiscal 2024, respectively, and a net gain of $7 million and a net loss of $2 million for the corresponding periods of fiscal 2023, respectively. We held equity interests in certain private equity funds of $0.8 billion and $0.9 billion as of April 27, 2024 and July 29, 2023, respectively, which are accounted for under the NAV practical expedient.

[0000858877-24-000007:notes:164]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 27, 2024, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-24-000007:notes:165]
The carrying value of our investments in privately held companies was $1.6 billion and $1.8 billion as of April 27, 2024 and July 29, 2023, respectively. Of the total carrying value of our investments in privately held companies as of April 27, 2024, $0.9 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of April 27, 2024, we have total funding commitments of $0.2 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-24-000007:notes:166]
[same as prior period, unchanged from 0000858877-24-000003:notes:136]

[0000858877-24-000007:notes:167]
[same as prior period, unchanged from 0000858877-24-000003:notes:137]

[0000858877-24-000007:notes:168]
|  | APRIL 27, 2024 |  | JULY 29, 2023 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,625 |  |  | $ | — |  |  | $ | 4,625 |  |  | $ | 6,496 |  |  | $ | — |  |  | $ | 6,496 |  |
| Commercial paper | — |  |  | 519 |  |  | 519 |  |  | — |  |  | 1,090 |  |  | 1,090 |  |
| Certificates of deposit | — |  |  | — |  |  | — |  |  | — |  |  | 47 |  |  | 47 |  |
| Corporate debt securities | — |  |  | 19 |  |  | 19 |  |  | — |  |  | 25 |  |  | 25 |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 2,362 |  |  | 2,362 |  |  | — |  |  | 3,526 |  |  | 3,526 |  |
| U.S. government agency securities | — |  |  | 245 |  |  | 245 |  |  | — |  |  | 423 |  |  | 423 |  |
| Non-U.S. government and agency securities | — |  |  | 390 |  |  | 390 |  |  | — |  |  | 363 |  |  | 363 |  |
| Corporate debt securities | — |  |  | 3,788 |  |  | 3,788 |  |  | — |  |  | 6,914 |  |  | 6,914 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,830 |  |  | 1,830 |  |  | — |  |  | 2,205 |  |  | 2,205 |  |
| Commercial paper | — |  |  | 563 |  |  | 563 |  |  | — |  |  | 1,484 |  |  | 1,484 |  |
| Certificates of deposit | — |  |  | 229 |  |  | 229 |  |  | — |  |  | 677 |  |  | 677 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 450 |  |  | — |  |  | 450 |  |  | 431 |  |  | — |  |  | 431 |  |
| Other current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 750 |  |  | — |  |  | 750 |  |  | 188 |  |  | — |  |  | 188 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 750 |  |  | — |  |  | 750 |  |  | 1,313 |  |  | — |  |  | 1,313 |  |
| Derivative assets | — |  |  | 66 |  |  | 66 |  |  | — |  |  | 32 |  |  | 32 |  |
| Total | $ | 6,575 |  |  | $ | 10,011 |  |  | $ | 16,586 |  |  | $ | 8,428 |  |  | $ | 16,786 |  |  | $ | 25,214 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 84 |  |  | $ | 84 |  |  | $ | — |  |  | $ | 75 |  |  | $ | 75 |  |
| Total | $ | — |  |  | $ | 84 |  |  | $ | 84 |  |  | $ | — |  |  | $ | 75 |  |  | $ | 75 |  |

[0000858877-24-000007:notes:169]
[same as prior period, unchanged from 0000858877-24-000003:notes:139]

[0000858877-24-000007:notes:170]
[same as prior period, unchanged from 0000858877-24-000003:notes:140]

[0000858877-24-000007:notes:171]
[same as prior period, unchanged from 0000858877-24-000003:notes:141]

[0000858877-24-000007:notes:172]
The fair value for purchased intangible assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation. Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable. See Note 5.

[0000858877-24-000007:notes:173]
[same as prior period, unchanged from 0000858877-24-000003:notes:142]

[0000858877-24-000007:notes:174]
The fair value of our short-term loan receivables approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables as of April 27, 2024 and July 29, 2023 was $2.6 billion and $2.9 billion, respectively. The estimated fair value of our long-term loan receivables approximates their carrying value. We use unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables, and therefore they are categorized as Level 3.
As of April 27, 2024, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of April 27, 2024, the fair value of our senior notes was $20.0 billion with a carrying amount of $20.1 billion. This compares to a fair value of $8.7 billion and a carrying amount of $8.4 billion as of July 29, 2023. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2.


## us-gaap:DebtDisclosureTextBlock

[0000858877-24-000007:notes:175]
Borrowings 
(a)Short-Term Debt

[0000858877-24-000007:notes:176]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-24-000007:notes:177]
|  | April 27, 2024 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | — |  |  | — |  |  | $ | 1,733 |  |  | 4.45 | % |
| Commercial paper | 11,891 |  |  | 5.42 | % |  | — |  |  | — |  |
| Total | $ | 11,891 |  |  |  |  | $ | 1,733 |  |  |  |

[0000858877-24-000007:notes:178]
We have a short-term debt financing program of up to $15.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-24-000007:notes:179]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-24-000007:notes:180]
(b)Long-Term Debt

[0000858877-24-000007:notes:181]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-24-000007:notes:182]
|  |  |  | April 27, 2024 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | — |  |  | — |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.64% |  | 500 |  |  | 6.38% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | — |  |  | — |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | — |  |  | — |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | — |  |  | — |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | — |  |  | — |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | — |  |  | — |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | — |  |  | — |
| Other long-term debt |  |  | 3 |  |  | 1.13% |  | — |  |  | — |
| Total |  |  | 20,253 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (135) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (16) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 20,102 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | — |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 20,102 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 20,102 |  |  |  |  | $ | 8,391 |  |  |  |

[0000858877-24-000007:notes:183]
In February 2024, we issued senior notes for an aggregate principal amount of $13.5 billion.

[0000858877-24-000007:notes:184]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $0.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on Secured Overnight Financing Rate (SOFR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-24-000007:notes:185]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 27, 2024, we were in compliance with all debt covenants.

[0000858877-24-000007:notes:186]
As of April 27, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-24-000007:notes:187]
| Fiscal Year | Amount |
| 2024 (remaining three months) | $ | — |  |
| 2025 | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | — |  |
| Thereafter | 14,500 |  |
| Total | $ | 20,253 |  |

[0000858877-24-000007:notes:188]
(c)Credit Facility

[0000858877-24-000007:notes:189]
On May 13, 2021, we entered into a 5-year $3.0 billion unsecured revolving credit agreement, as amended on April 18, 2023. On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of April 27, 2024, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-24-000007:notes:190]
[same as prior period, unchanged from 0000858877-24-000003:notes:158]

[0000858877-24-000007:notes:191]
[same as prior period, unchanged from 0000858877-24-000003:notes:159]

[0000858877-24-000007:notes:192]
[same as prior period, unchanged from 0000858877-24-000003:notes:160]

[0000858877-24-000007:notes:193]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | April 27,2024 |  | July 29,2023 |  | Balance Sheet Line Item |  | April 27,2024 |  | July 29,2023 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 45 |  |  | $ | 22 |  |  | Other current liabilities |  | $ | 1 |  |  | $ | — |  |
| Foreign currency derivatives | Other assets |  | 19 |  |  | 9 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | — |  |  | 17 |  |
| Interest rate derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 16 |  |  | 24 |  |
| Total |  |  | 64 |  |  | 31 |  |  |  |  | 17 |  |  | 41 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 2 |  |  | 1 |  |  | Other current liabilities |  | 47 |  |  | 25 |  |
| Foreign currency derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 20 |  |  | 9 |  |
| Total |  |  | 2 |  |  | 1 |  |  |  |  | 67 |  |  | 34 |  |
| Total |  |  | $ | 66 |  |  | $ | 32 |  |  |  |  | $ | 84 |  |  | $ | 75 |  |

[0000858877-24-000007:notes:194]
[same as prior period, unchanged from 0000858877-24-000003:notes:162]

[0000858877-24-000007:notes:195]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | April 27,2024 |  | July 29,2023 |  | April 27,2024 |  | July 29,2023 |
| Short-term debt |  | $ | — |  |  | $ | (983) |  |  | $ | — |  |  | $ | 17 |  |
| Long-term debt |  | $ | (484) |  |  | $ | (476) |  |  | $ | 16 |  |  | $ | 24 |  |

[0000858877-24-000007:notes:196]
[same as prior period, unchanged from 0000858877-24-000003:notes:164]

[0000858877-24-000007:notes:197]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27, 2024 |  | April 29, 2023 |  | April 27, 2024 |  | April 29, 2023 |
| Interest rate derivatives: |  |  |  |  |  |  |  |  |
| Hedged items |  | $ | (2) |  |  | $ | (6) |  |  | $ | (25) |  |  | $ | 26 |  |
| Derivatives designated as hedging instruments |  | 2 |  |  | 6 |  |  | 25 |  |  | (26) |  |
| Total |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000858877-24-000007:notes:198]
[same as prior period, unchanged from 0000858877-24-000003:notes:166]

[0000858877-24-000007:notes:199]
|  |  |  |  | GAINS (LOSSES) FOR THE THREE MONTHS ENDED |  | GAINS (LOSSES) FOR THE NINE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (84) |  |  | $ | (46) |  |  | $ | (161) |  |  | $ | 22 |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | 16 |  |  | (12) |  |  | 33 |  |  | 7 |  |
| Equity derivatives |  | Other income (loss), net |  | — |  |  | 4 |  |  | 1 |  |  | 8 |  |
| Total |  |  |  | $ | (68) |  |  | $ | (54) |  |  | $ | (127) |  |  | $ | 37 |  |

[0000858877-24-000007:notes:200]
[same as prior period, unchanged from 0000858877-24-000003:notes:168]

[0000858877-24-000007:notes:201]
|  | April 27,2024 |  | July 29,2023 |
| Foreign currency derivatives | $ | 7,077 |  |  | $ | 5,419 |  |
| Interest rate derivatives | 500 |  |  | 1,500 |  |
| Total return swaps—deferred compensation | 915 |  |  | 792 |  |
| Total | $ | 8,492 |  |  | $ | 7,711 |  |

[0000858877-24-000007:notes:202]
[same as prior period, unchanged from 0000858877-24-000003:notes:170]

[0000858877-24-000007:notes:203]
[same as prior period, unchanged from 0000858877-24-000003:notes:171]

[0000858877-24-000007:notes:204]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral provided for was $16 million and $40 million as of April 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000007:notes:205]
[same as prior period, unchanged from 0000858877-24-000003:notes:173]

[0000858877-24-000007:notes:206]
[same as prior period, unchanged from 0000858877-24-000003:notes:174]

[0000858877-24-000007:notes:207]
[same as prior period, unchanged from 0000858877-24-000003:notes:175]

[0000858877-24-000007:notes:208]
[same as prior period, unchanged from 0000858877-24-000003:notes:176]

[0000858877-24-000007:notes:209]
[same as prior period, unchanged from 0000858877-24-000003:notes:177]

[0000858877-24-000007:notes:210]
[same as prior period, unchanged from 0000858877-24-000003:notes:178]

[0000858877-24-000007:notes:211]
We hold an interest rate swap designated as a fair value hedge related to a fixed-rate senior note that is due in fiscal 2025. Under the interest rate swap, we receive fixed-rate interest payments and make interest payments based on SOFR plus a fixed number of basis points. The effect of the swap is to convert the fixed interest rate of the senior fixed-rate note to a floating interest rate based on SOFR. The gain and loss related to changes in the fair value of the interest rate swap is included in interest expense and substantially offset the change in the fair value of the hedged portion of the underlying debt attributable to the change in market interest rates.

[0000858877-24-000007:notes:212]
[same as prior period, unchanged from 0000858877-24-000003:notes:180]

[0000858877-24-000007:notes:213]
[same as prior period, unchanged from 0000858877-24-000003:notes:181]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-24-000007:notes:214]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-24-000007:notes:215]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-24-000007:notes:216]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-24-000007:notes:217]
|  | April 27,2024 |  | July 29,2023 |
| Less than 1 year | $ | 4,581 |  |  | $ | 5,270 |  |
| 1 to 3 years | 1,368 |  |  | 1,783 |  |
| 3 to 5 years | 55 |  |  | 200 |  |
| Total | $ | 6,004 |  |  | $ | 7,253 |  |

[0000858877-24-000007:notes:218]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 27, 2024 and July 29, 2023, the liability for these purchase commitments was $550 million and $529 million, respectively, and was included in other current liabilities.

[0000858877-24-000007:notes:219]
(b)Other Commitments

[0000858877-24-000007:notes:220]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.2 billion and $0.3 billion as of April 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000007:notes:221]
(c)Product Warranties

[0000858877-24-000007:notes:222]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-24-000007:notes:223]
|  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |
| Balance at beginning of period | $ | 329 |  |  | $ | 333 |  |
| Provisions for warranties issued | 316 |  |  | 285 |  |
| Adjustments for pre-existing warranties | 20 |  |  | 15 |  |
| Settlements | (302) |  |  | (321) |  |
| Balance at end of period | $ | 363 |  |  | $ | 312 |  |

[0000858877-24-000007:notes:224]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-24-000007:notes:225]
(d)Financing and Other Guarantees

[0000858877-24-000007:notes:226]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-24-000007:notes:227]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.1 billion and $8.3 billion for the third quarter of fiscal 2024 and 2023, respectively, and $20.9 billion and $23.4 billion for the first nine months of fiscal 2024 and 2023, respectively. The balance of the channel partner financing subject to guarantees was $1.1 billion and $1.7 billion as of April 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000007:notes:228]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at April 27, 2024 and July 29, 2023, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-24-000007:notes:229]
|  | April 27,2024 |  | July 29,2023 |
| Maximum potential future payments | $ | 126 |  |  | $ | 159 |  |
| Deferred revenue | (25) |  |  | (34) |  |
| Total | $ | 101 |  |  | $ | 125 |  |

[0000858877-24-000007:notes:230]
(e)Indemnifications

[0000858877-24-000007:notes:231]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-24-000007:notes:232]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-24-000007:notes:233]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-24-000007:notes:234]
(f)Legal Proceedings

[0000858877-24-000007:notes:235]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $157 million for the alleged evasion of import and other taxes, $902 million for interest, and $357 million for various penalties, all determined using an exchange rate as of April 27, 2024.

[0000858877-24-000007:notes:236]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-24-000007:notes:237]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. After two bench trials and various administrative actions and appeals, we have been found either to not have infringed any of the patents or the patents have been invalidated. There is an appeal of one of the invalidity decisions and we expect a further appeal by Centripetal.

[0000858877-24-000007:notes:238]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringed three patents, one patent was invalidated, the utility model was invalidated, and the infringement action on the final patent is stayed due to a pending invalidity action, which has a hearing set for June 6, 2024. Centripetal’s appeals of two of the non-infringement findings remain pending and, on March 27, 2024, the Court of Appeals rejected Centripetal’s appeal of the third non-infringement finding.

[0000858877-24-000007:notes:239]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement. We

[0000858877-24-000007:notes:240]
have filed our response and defenses to the complaint and, on May 24, 2024, we expect the Paris Judiciary Court to decide our motion to dismiss and, if denied, it will set the schedule for the remainder of the proceedings.

[0000858877-24-000007:notes:241]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of the litigations at this time. If we do not prevail in these litigations, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-24-000007:notes:242]
Ramot     On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents and those proceedings are ongoing.

[0000858877-24-000007:notes:243]
While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-24-000007:notes:244]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023, the appeal is fully briefed and we are awaiting a hearing date from the Federal Circuit.

[0000858877-24-000007:notes:245]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward. On June 9, 2020, Viasat filed another suit in SDSC alleging contract and trade secret claims for sales of additional Acacia products. Both matters have been formally dismissed and resolved during fiscal 2024 through a settlement for an amount that did not have a material effect on our Consolidated Financial Statements.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-24-000007:notes:246]
Purchase Commitments with Contract Manufacturers and Suppliers We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-24-000007:notes:247]
[same as prior period, unchanged from 0000858877-24-000003:notes:219]

[0000858877-24-000007:notes:248]
In September 2001, our Board of Directors authorized a stock repurchase program. As of April 27, 2024, the remaining authorized amount for stock repurchases under this program was approximately $7.2 billion with no termination date. The stock repurchase activity for fiscal 2024 and 2023 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-24-000007:notes:249]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2024 |  |  |  |  |  |  |
| April 27, 2024 |  | 26 |  |  | $ | 49.22 |  |  | $ | 1,256 |  |
| January 27, 2024 |  | 25 |  |  | $ | 49.54 |  |  | $ | 1,254 |  |
| October 28, 2023 |  | 23 |  |  | $ | 54.53 |  |  | $ | 1,252 |  |
| Fiscal 2023 |  |  |  |  |  |  |
| July 29, 2023 |  | 25 |  |  | $ | 50.49 |  |  | $ | 1,254 |  |
| April 29, 2023 |  | 25 |  |  | $ | 49.45 |  |  | $ | 1,259 |  |
| January 28, 2023 |  | 26 |  |  | $ | 47.72 |  |  | $ | 1,256 |  |
| October 29, 2022 |  | 12 |  |  | $ | 43.76 |  |  | $ | 502 |  |

[0000858877-24-000007:notes:250]
There were stock repurchases of $38 million and $48 million that were pending settlement as of April 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000007:notes:251]
[same as prior period, unchanged from 0000858877-24-000003:notes:223]

[0000858877-24-000007:notes:252]
[same as prior period, unchanged from 0000858877-24-000003:notes:224]

[0000858877-24-000007:notes:253]
On May 15, 2024, our Board of Directors declared a quarterly dividend of $0.40 per common share to be paid on July 24, 2024, to all stockholders of record as of the close of business on July 5, 2024. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-24-000007:notes:254]
[same as prior period, unchanged from 0000858877-24-000003:notes:226]

[0000858877-24-000007:notes:255]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock in one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights, if any, of such series, and any qualifications, limitations or restrictions thereof, of the shares of such series. As of April 27, 2024, we had not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-24-000007:notes:256]
[same as prior period, unchanged from 0000858877-24-000003:notes:228]

[0000858877-24-000007:notes:257]
[same as prior period, unchanged from 0000858877-24-000003:notes:229]

[0000858877-24-000007:notes:258]
[same as prior period, unchanged from 0000858877-24-000003:notes:230]

[0000858877-24-000007:notes:259]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of April 27, 2024, 165 million shares were authorized for future grant under the 2005 Plan.

[0000858877-24-000007:notes:260]
[same as prior period, unchanged from 0000858877-24-000003:notes:232]

[0000858877-24-000007:notes:261]
We have an Employee Stock Purchase Plan under which eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. No shares were issued under the Employee Stock Purchase Plan during each of the third quarters of fiscal 2024 and 2023. As of April 27, 2024, 78 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-24-000007:notes:262]
[same as prior period, unchanged from 0000858877-24-000003:notes:234]

[0000858877-24-000007:notes:263]
[same as prior period, unchanged from 0000858877-24-000003:notes:235]

[0000858877-24-000007:notes:264]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2024 |  | April 29, 2023 |  | April 27, 2024 |  | April 29, 2023 |
| Cost of sales—product | $ | 57 |  |  | $ | 40 |  |  | $ | 157 |  |  | $ | 111 |  |
| Cost of sales—service | 82 |  |  | 66 |  |  | 224 |  |  | 182 |  |
| Share-based compensation expense in cost of sales | 139 |  |  | 106 |  |  | 381 |  |  | 293 |  |
| Research and development | 349 |  |  | 272 |  |  | 967 |  |  | 737 |  |
| Sales and marketing | 221 |  |  | 175 |  |  | 628 |  |  | 494 |  |
| General and administrative | 95 |  |  | 71 |  |  | 282 |  |  | 200 |  |
| Restructuring and other charges | 7 |  |  | (1) |  |  | 16 |  |  | (4) |  |
| Share-based compensation expense in operating expenses | 672 |  |  | 517 |  |  | 1,893 |  |  | 1,427 |  |
| Total share-based compensation expense | $ | 811 |  |  | $ | 623 |  |  | $ | 2,274 |  |  | $ | 1,720 |  |
| Income tax benefit for share-based compensation | $ | 179 |  |  | $ | 111 |  |  | $ | 524 |  |  | $ | 319 |  |

[0000858877-24-000007:notes:265]
As of April 27, 2024, the total compensation cost related to unvested share-based awards not yet recognized was $4.5 billion which is expected to be recognized over approximately 2.0 years on a weighted-average basis.

[0000858877-24-000007:notes:266]
[same as prior period, unchanged from 0000858877-24-000003:notes:238]

[0000858877-24-000007:notes:267]
[same as prior period, unchanged from 0000858877-24-000003:notes:239]

[0000858877-24-000007:notes:268]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| Unvested balance at July 30, 2022 | 97 |  |  | $ | 46.67 |  |  |  |
| Granted and assumed | 72 |  |  | 42.08 |  |  |  |
| Vested | (39) |  |  | 46.69 |  |  | $ | 1,746 |  |
| Canceled/forfeited/other | (8) |  |  | 45.17 |  |  |  |
| Unvested balance at July 29, 2023 | 122 |  |  | $ | 44.04 |  |  |  |
| Granted and assumed | 50 |  |  | 50.42 |  |  |  |
| Vested | (44) |  |  | 43.10 |  |  | $ | 2,264 |  |
| Canceled/forfeited/other | (9) |  |  | 45.30 |  |  |  |
| Unvested balance at April 27, 2024 | 119 |  |  | $ | 46.97 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-24-000007:notes:269]
Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first nine months of fiscal 2024 and 2023 are summarized as follows (in millions):

[0000858877-24-000007:notes:270]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 29, 2023 | $ | (440) |  |  | $ | 18 |  |  | $ | (1,153) |  |  | $ | (1,575) |  |
| Other comprehensive income (loss) before reclassifications | 74 |  |  | 122 |  |  | (223) |  |  | (27) |  |
| (Gains) losses reclassified out of AOCI | 57 |  |  | (36) |  |  | (2) |  |  | 19 |  |
| Tax benefit (expense) | (26) |  |  | (20) |  |  | (1) |  |  | (47) |  |
| Balance at April 27, 2024 | $ | (335) |  |  | $ | 84 |  |  | $ | (1,379) |  |  | $ | (1,630) |  |

[0000858877-24-000007:notes:271]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 30, 2022 | $ | (379) |  |  | $ | 44 |  |  | $ | (1,287) |  |  | $ | (1,622) |  |
| Other comprehensive income (loss) before reclassifications | (39) |  |  | 5 |  |  | 42 |  |  | 8 |  |
| (Gains) losses reclassified out of AOCI | 15 |  |  | (50) |  |  | — |  |  | (35) |  |
| Tax benefit (expense) | 8 |  |  | 11 |  |  | 24 |  |  | 43 |  |
| Balance at April 29, 2023 | $ | (395) |  |  | $ | 10 |  |  | $ | (1,221) |  |  | $ | (1,606) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-24-000007:notes:272]
[same as prior period, unchanged from 0000858877-24-000003:notes:244]

[0000858877-24-000007:notes:273]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Income before provision for income taxes | $ | 2,235 |  |  | $ | 3,957 |  |  | $ | 9,838 |  |  | $ | 10,847 |  |
| Provision for income taxes | $ | 349 |  |  | $ | 745 |  |  | $ | 1,680 |  |  | $ | 2,192 |  |
| Effective tax rate | 15.6 | % |  | 18.8 | % |  | 17.1 | % |  | 20.2 | % |

[0000858877-24-000007:notes:274]
As of April 27, 2024, we had $2.2 billion of unrecognized tax benefits, of which $1.5 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-24-000007:notes:275]
[same as prior period, unchanged from 0000858877-24-000003:notes:247]

[0000858877-24-000007:notes:276]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-24-000007:notes:277]
Summarized financial information by segment for the third quarter and first nine months of fiscal 2024 and 2023, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-24-000007:notes:278]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 7,372 |  |  | $ | 8,634 |  |  | $ | 23,904 |  |  | $ | 24,372 |  |
| EMEA | 3,458 |  |  | 3,806 |  |  | 10,606 |  |  | 11,209 |  |
| APJC | 1,873 |  |  | 2,131 |  |  | 5,652 |  |  | 6,214 |  |
| Total | $ | 12,702 |  |  | $ | 14,571 |  |  | $ | 40,161 |  |  | $ | 41,795 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 5,006 |  |  | $ | 5,545 |  |  | $ | 15,906 |  |  | $ | 15,449 |  |
| EMEA | 2,406 |  |  | 2,536 |  |  | 7,324 |  |  | 7,330 |  |
| APJC | 1,262 |  |  | 1,415 |  |  | 3,816 |  |  | 3,986 |  |
| Segment total | 8,673 |  |  | 9,495 |  |  | 27,046 |  |  | 26,764 |  |
| Unallocated corporate items | (400) |  |  | (263) |  |  | (999) |  |  | (759) |  |
| Total | $ | 8,273 |  |  | $ | 9,232 |  |  | $ | 26,047 |  |  | $ | 26,005 |  |

[0000858877-24-000007:notes:279]
Revenue in the United States was $6.6 billion and $7.7 billion for the third quarter of fiscal 2024 and 2023, respectively and $21.4 billion and $21.7 billion for the first nine months of fiscal 2024 and 2023, respectively.

[0000858877-24-000007:notes:280]
[same as prior period, unchanged from 0000858877-24-000003:notes:252]

[0000858877-24-000007:notes:281]
[same as prior period, unchanged from 0000858877-24-000003:notes:253]


## us-gaap:EarningsPerShareTextBlock

[0000858877-24-000007:notes:282]
[same as prior period, unchanged from 0000858877-24-000003:notes:254]

[0000858877-24-000007:notes:283]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Net income | $ | 1,886 |  |  | $ | 3,212 |  |  | $ | 8,158 |  |  | $ | 8,655 |  |
| Weighted-average shares—basic | 4,042 |  |  | 4,089 |  |  | 4,051 |  |  | 4,100 |  |
| Effect of dilutive potential common shares | 18 |  |  | 21 |  |  | 20 |  |  | 11 |  |
| Weighted-average shares—diluted | 4,060 |  |  | 4,110 |  |  | 4,071 |  |  | 4,111 |  |
| Net income per share—basic | $ | 0.47 |  |  | $ | 0.79 |  |  | $ | 2.01 |  |  | $ | 2.11 |  |
| Net income per share—diluted | $ | 0.46 |  |  | $ | 0.78 |  |  | $ | 2.00 |  |  | $ | 2.11 |  |
| Antidilutive employee share-based awards, excluded | 11 |  |  | 24 |  |  | 58 |  |  | 75 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000858877-24-000007:notes:284]
On February 22, 2024, M. Victoria Wong, Cisco’s Senior Vice President and Chief Accounting Officer, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Ms. Wong’s trading plan provides for the sale of 30,151 gross shares, excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Ms. Wong’s trading plan is scheduled to terminate on March 21, 2025, subject to early termination for certain specified events set forth therein.

[0000858877-24-000007:notes:285]
On February 28, 2024, Charles H. Robbins, Cisco’s Chair and Chief Executive Officer, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Mr. Robbins’ trading plan provides for the sale of 484,640 gross shares (with any shares underlying performance-based equity awards being calculated at target), plus any related dividend-equivalent shares earned with respect to such shares and excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Mr. Robbins’ trading plan is scheduled to terminate on March 21, 2025, subject to early termination for certain specified events set forth therein.

[0000858877-24-000007:notes:286]
On March 4, 2024, R. Scott Herren, Cisco’s Executive Vice President and Chief Financial Officer, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Mr. Herren’s trading plan provides for the sale of 256,366 gross shares (with any shares underlying performance-based equity awards being calculated at target), plus any related dividend-equivalent shares earned with respect to such shares and excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Mr. Herren’s trading plan is scheduled to terminate on March 21, 2025, subject to early termination for certain specified events set forth therein.

[0000858877-24-000007:notes:287]
On March 15, 2024, Thimaya Subaiya, Cisco’s Executive Vice President, Operations, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Mr. Subaiya’s trading plan provides for the sale of 112,862 gross shares (with any shares underlying performance-based equity awards being calculated at target), plus any related dividend-equivalent shares earned with respect to such shares and shares from purchases made pursuant to Cisco’s employee stock purchase plan, and excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Mr. Subaiya’s trading plan is scheduled to terminate on March 21, 2025, subject to early termination for certain specified events set forth therein.
