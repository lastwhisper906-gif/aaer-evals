# CSCO MD&A — 0000858877-24-000007


## mdna

[0000858877-24-000007:mdna:1]
[same as prior period, unchanged from 0000858877-24-000003:mdna:1]

[0000858877-24-000007:mdna:2]
[same as prior period, unchanged from 0000858877-24-000003:mdna:2]

[0000858877-24-000007:mdna:3]
[same as prior period, unchanged from 0000858877-24-000003:mdna:3]

[0000858877-24-000007:mdna:4]
[same as prior period, unchanged from 0000858877-24-000003:mdna:4]

[0000858877-24-000007:mdna:5]
[same as prior period, unchanged from 0000858877-24-000003:mdna:5]

[0000858877-24-000007:mdna:6]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | April 27,2024 |  | April 29,2023 |  | % Variance |  |  | April 27, 2024 |  | April 29, 2023 |  | % Variance |  |
| Revenue | $ | 12,702 |  |  | $ | 14,571 |  |  | (13) | % |  |  | $ | 40,161 |  |  | $ | 41,795 |  |  | (4) | % |  |
| Gross margin percentage | 65.1 | % |  | 63.4 | % |  | 1.7 |  | pts |  | 64.9 | % |  | 62.2 | % |  | 2.7 |  | pts |
| Research and development | $ | 1,948 |  |  | $ | 1,962 |  |  | (1) | % |  |  | $ | 5,804 |  |  | $ | 5,598 |  |  | 4 | % |  |
| Sales and marketing | $ | 2,559 |  |  | $ | 2,526 |  |  | 1 | % |  |  | $ | 7,523 |  |  | $ | 7,301 |  |  | 3 | % |  |
| General and administrative | $ | 736 |  |  | $ | 641 |  |  | 15 | % |  |  | $ | 2,050 |  |  | $ | 1,788 |  |  | 15 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 5,243 |  |  | $ | 5,129 |  |  | 2 | % |  |  | $ | 15,377 |  |  | $ | 14,687 |  |  | 5 | % |  |
| Total as a percentage of revenue | 41.3 | % |  | 35.2 | % |  | 6.1 |  | pts |  | 38.3 | % |  | 35.1 | % |  | 3.2 |  | pts |
| Restructuring and other charges included in operating expenses | $ | 542 |  |  | $ | 87 |  |  | NM |  |  | $ | 677 |  |  | $ | 328 |  |  | 106 | % |  |
| Operating income as a percentage of revenue | 17.2 | % |  | 27.1 | % |  | (9.9) |  | pts |  | 23.8 | % |  | 25.8 | % |  | (2.0) |  | pts |
| Interest and other income (loss), net | $ | 44 |  |  | $ | 11 |  |  | NM |  |  | $ | 275 |  |  | $ | 69 |  |  | NM |  |
| Income tax percentage | 15.6 | % |  | 18.8 | % |  | (3.2) |  | pts |  | 17.1 | % |  | 20.2 | % |  | (3.1) |  | pts |
| Net income | $ | 1,886 |  |  | $ | 3,212 |  |  | (41) | % |  |  | $ | 8,158 |  |  | $ | 8,655 |  |  | (6) | % |  |
| Net income as a percentage of revenue | 14.8 | % |  | 22.0 | % |  | (7.2) |  | pts |  | 20.3 | % |  | 20.7 | % |  | (0.4) |  | pts |
| Earnings per share—diluted | $ | 0.46 |  |  | $ | 0.78 |  |  | (41) | % |  |  | $ | 2.00 |  |  | $ | 2.11 |  |  | (5) | % |  |

[0000858877-24-000007:mdna:7]
NM – Not Meaningful

[0000858877-24-000007:mdna:8]
[same as prior period, unchanged from 0000858877-24-000003:mdna:7]

[0000858877-24-000007:mdna:9]
[same as prior period, unchanged from 0000858877-24-000003:mdna:9]

[0000858877-24-000007:mdna:10]
[same as prior period, unchanged from 0000858877-24-000003:mdna:10]

[0000858877-24-000007:mdna:11]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:12]
Total revenue decreased by 13% compared with the third quarter of fiscal 2023. In March 2024, we completed the acquisition of Splunk, which contributed $413 million in total revenue for the third quarter of fiscal 2024. Within total revenue, product revenue decreased by 19% and service revenue increased by 6%. In the third quarter of fiscal 2024, total software revenue was $4.5 billion across all product areas and service, an increase of 5%, driven by the contribution of Splunk. Within total software revenue, subscription revenue increased 17%, driven in large part by the contribution of Splunk.

[0000858877-24-000007:mdna:13]
In the third quarter of fiscal 2024, we continued to see customers scrutinizing spend. We saw a decline in product demand in the first half of fiscal 2024, which was primarily due to customers needing additional time to implement elevated levels of product shipments received in prior quarters. Even though we saw improved product deployments by customers in the third quarter of fiscal 2024, we believe that some impacts on overall product demand may continue through at least the end of fiscal 2024 as customers complete the installation of the majority of their product deployments.

[0000858877-24-000007:mdna:14]
Total gross margin increased by 1.7 percentage points. Product gross margin increased by 0.8 percentage points, largely driven by favorable product mix and productivity improvements, partially offset by pricing erosion. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 6.1 percentage points. Operating income as a percentage of revenue decreased by 9.9 percentage points primarily driven by restructuring and other charges of $542 million and higher amortization of purchased intangible assets in the third quarter of fiscal 2024. Diluted earnings per share decreased 41%, driven by a decrease of 41% in net income, partially offset by a decrease in diluted share count of 50 million shares.

[0000858877-24-000007:mdna:15]
In terms of our geographic segments, revenue from the Americas decreased by $1.3 billion, EMEA revenue decreased by $348 million and APJC revenue decreased by $258 million. From a customer market standpoint, we experienced product revenue declines across all of our customer markets. From a product category perspective, the product revenue decrease of 19% was driven by a decline in revenue in Networking of 27%. This decline was partially offset by product revenue growth in Security of 36% and Observability of 27%, each driven in large part by the contribution of Splunk. Product revenue in Collaboration was flat.

[0000858877-24-000007:mdna:16]
We remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformations and on accelerating innovation across our portfolio. We believe that we are making progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment and while the overall environment remains uncertain, we continue to invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-24-000007:mdna:17]
[same as prior period, unchanged from 0000858877-24-000003:mdna:17]

[0000858877-24-000007:mdna:18]
[same as prior period, unchanged from 0000858877-24-000003:mdna:18]

[0000858877-24-000007:mdna:19]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:20]
Total revenue decreased 4%, with product revenue decreasing 7% and service revenue increasing 5%. Total gross margin increased 2.7 percentage points due to productivity improvements and favorable product mix, partially offset by pricing erosion. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 3.2 percentage points. Operating income as a percentage of revenue decreased by 2.0 percentage points. We incurred restructuring and other charges of $677 million in the first nine months of fiscal 2024. Diluted earnings per share decreased 5%, driven by a decrease of 6% in net income, partially offset by a decrease in diluted share count of 40 million shares.

[0000858877-24-000007:mdna:21]
[same as prior period, unchanged from 0000858877-24-000003:mdna:21]

[0000858877-24-000007:mdna:22]
[same as prior period, unchanged from 0000858877-24-000003:mdna:22]

[0000858877-24-000007:mdna:23]
[same as prior period, unchanged from 0000858877-24-000003:mdna:23]

[0000858877-24-000007:mdna:24]
[same as prior period, unchanged from 0000858877-24-000003:mdna:24]

[0000858877-24-000007:mdna:25]
The following is a summary of our other key financial measures for the third quarter of fiscal 2024 (in millions):

[0000858877-24-000007:mdna:26]
|  |  | April 27,2024 |  | July 29,2023 |
| Cash and cash equivalents and investments |  | $ | 18,770 |  |  | $ | 26,146 |  |
| Remaining performance obligations |  | $ | 38,774 |  |  | $ | 34,868 |  |
| Inventories |  | $ | 3,118 |  |  | $ | 3,644 |  |
| Total debt |  | $ | 31,993 |  |  | $ | 8,391 |  |

[0000858877-24-000007:mdna:27]
|  |  | Nine Months Ended |
|  |  | April 27,2024 |  | April 29,2023 |
| Cash provided by operating activities |  | $ | 7,150 |  |  | $ | 13,920 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 3,762 |  |  | $ | 3,017 |  |
| Dividends paid |  | $ | 4,778 |  |  | $ | 4,713 |  |

[0000858877-24-000007:mdna:28]
[same as prior period, unchanged from 0000858877-24-000003:mdna:28]

[0000858877-24-000007:mdna:29]
[same as prior period, unchanged from 0000858877-24-000003:mdna:29]

[0000858877-24-000007:mdna:30]
[same as prior period, unchanged from 0000858877-24-000003:mdna:30]

[0000858877-24-000007:mdna:31]
[same as prior period, unchanged from 0000858877-24-000003:mdna:31]

[0000858877-24-000007:mdna:32]
[same as prior period, unchanged from 0000858877-24-000003:mdna:32]

[0000858877-24-000007:mdna:33]
[same as prior period, unchanged from 0000858877-24-000003:mdna:33]

[0000858877-24-000007:mdna:34]
[same as prior period, unchanged from 0000858877-24-000003:mdna:34]

[0000858877-24-000007:mdna:35]
[same as prior period, unchanged from 0000858877-24-000003:mdna:35]

[0000858877-24-000007:mdna:36]
[same as prior period, unchanged from 0000858877-24-000003:mdna:36]

[0000858877-24-000007:mdna:37]
[same as prior period, unchanged from 0000858877-24-000003:mdna:37]

[0000858877-24-000007:mdna:38]
[same as prior period, unchanged from 0000858877-24-000003:mdna:38]

[0000858877-24-000007:mdna:39]
[same as prior period, unchanged from 0000858877-24-000003:mdna:39]

[0000858877-24-000007:mdna:40]
44

[0000858877-24-000007:mdna:41]
[same as prior period, unchanged from 0000858877-24-000003:mdna:40]

[0000858877-24-000007:mdna:42]
[same as prior period, unchanged from 0000858877-24-000003:mdna:41]

[0000858877-24-000007:mdna:43]
[same as prior period, unchanged from 0000858877-24-000003:mdna:42]

[0000858877-24-000007:mdna:44]
Our provision for inventory was $90 million and $82 million for the third quarter of fiscal 2024 and 2023, respectively, and $348 million and $174 million for the first nine months of fiscal 2024 and 2023, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $85 million and $134 million for the third quarter of fiscal 2024 and 2023, respectively, and $213 million and $333 million for the first nine months of fiscal 2024 and 2023, respectively. If there were to be a sudden and significant decrease in demand for our products, if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, or if supply constraints were to continue, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. For further discussion around the Supply Constraints Impacts and Risks, see “—Results of Operations—Gross Margin—Supply Constraints Impacts and Risks” and “—Liquidity and Capital Resources—Inventory Supply Chain.”

[0000858877-24-000007:mdna:45]
Loss Contingencies

[0000858877-24-000007:mdna:46]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-24-000007:mdna:47]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-24-000007:mdna:48]
[same as prior period, unchanged from 0000858877-24-000003:mdna:47]

[0000858877-24-000007:mdna:49]
[same as prior period, unchanged from 0000858877-24-000003:mdna:48]

[0000858877-24-000007:mdna:50]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first nine months of fiscal 2024 and 2023.

[0000858877-24-000007:mdna:51]
The accounting for acquisitions requires significant estimates and judgments when allocating the purchase price to the estimated fair values of assets acquired and liabilities assumed at the acquisition date. Critical estimates used in the valuation of intangible assets include, but are not limited to, the amount and timing of expected future cash flows, useful lives and discount rates. While our estimates of fair value are based on assumptions that are believed to be reasonable, these assumptions are inherently uncertain and unpredictable and would not reflect unanticipated events and circumstances that may occur.

[0000858877-24-000007:mdna:52]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset group to the future undiscounted cash flows the asset group is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our

[0000858877-24-000007:mdna:53]
45

[0000858877-24-000007:mdna:54]
[same as prior period, unchanged from 0000858877-24-000003:mdna:53]

[0000858877-24-000007:mdna:55]
[same as prior period, unchanged from 0000858877-24-000003:mdna:54]

[0000858877-24-000007:mdna:56]
business strategy and our internal forecasts. Our ongoing consideration of all the factors described previously could result in impairment charges in the future, which could adversely affect our net income.

[0000858877-24-000007:mdna:57]
[same as prior period, unchanged from 0000858877-24-000003:mdna:55]

[0000858877-24-000007:mdna:58]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was 15.6% and 18.8% in the third quarter of fiscal 2024 and 2023, respectively, and 17.1% and 20.2% in the first nine months of fiscal 2024 and 2023, respectively.

[0000858877-24-000007:mdna:59]
[same as prior period, unchanged from 0000858877-24-000003:mdna:57]

[0000858877-24-000007:mdna:60]
[same as prior period, unchanged from 0000858877-24-000003:mdna:58]

[0000858877-24-000007:mdna:61]
[same as prior period, unchanged from 0000858877-24-000003:mdna:59]

[0000858877-24-000007:mdna:62]
[same as prior period, unchanged from 0000858877-24-000003:mdna:60]

[0000858877-24-000007:mdna:63]
[same as prior period, unchanged from 0000858877-24-000003:mdna:61]

[0000858877-24-000007:mdna:64]
[same as prior period, unchanged from 0000858877-24-000003:mdna:62]

[0000858877-24-000007:mdna:65]
[same as prior period, unchanged from 0000858877-24-000003:mdna:63]

[0000858877-24-000007:mdna:66]
[same as prior period, unchanged from 0000858877-24-000003:mdna:64]

[0000858877-24-000007:mdna:67]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27,2024 |  | April 29,2023 |  | Variancein Dollars |  | Variance in Percent |  | April 27, 2024 |  | April 29, 2023 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,024 |  |  | $ | 11,092 |  |  | $ | (2,068) |  |  | (19) | % |  | $ | 29,395 |  |  | $ | 31,492 |  |  | $ | (2,097) |  |  | (7) | % |
| Percentage of revenue |  | 71.0 | % |  | 76.1 | % |  |  |  |  |  | 73.2 | % |  | 75.3 | % |  |  |  |  |
| Service |  | 3,678 |  |  | 3,479 |  |  | 199 |  |  | 6 | % |  | 10,766 |  |  | 10,303 |  |  | 463 |  |  | 5 | % |
| Percentage of revenue |  | 29.0 | % |  | 23.9 | % |  |  |  |  |  | 26.8 | % |  | 24.7 | % |  |  |  |  |
| Total |  | $ | 12,702 |  |  | $ | 14,571 |  |  | $ | (1,869) |  |  | (13) | % |  | $ | 40,161 |  |  | $ | 41,795 |  |  | $ | (1,634) |  |  | (4) | % |

[0000858877-24-000007:mdna:68]
[same as prior period, unchanged from 0000858877-24-000003:mdna:68]

[0000858877-24-000007:mdna:69]
Total revenue for the third quarter and first nine months of fiscal 2024 includes $413 million relating to the acquisition of Splunk, which consisted of $338 million in product revenue and $75 million in service revenue.

[0000858877-24-000007:mdna:70]
[same as prior period, unchanged from 0000858877-24-000003:mdna:66]

[0000858877-24-000007:mdna:71]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27,2024 |  | April 29,2023 |  | Variancein Dollars |  | Variance in Percent |  | April 27,2024 |  | April 29,2023 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,372 |  |  | $ | 8,634 |  |  | $ | (1,262) |  |  | (15) | % |  | $ | 23,904 |  |  | $ | 24,372 |  |  | $ | (468) |  |  | (2) | % |
| Percentage of revenue |  | 58.1 | % |  | 59.3 | % |  |  |  |  |  | 59.5 | % |  | 58.3 | % |  |  |  |  |
| EMEA |  | 3,458 |  |  | 3,806 |  |  | (348) |  |  | (9) | % |  | 10,606 |  |  | 11,209 |  |  | (603) |  |  | (5) | % |
| Percentage of revenue |  | 27.2 | % |  | 26.1 | % |  |  |  |  |  | 26.4 | % |  | 26.8 | % |  |  |  |  |
| APJC |  | 1,873 |  |  | 2,131 |  |  | (258) |  |  | (12) | % |  | 5,652 |  |  | 6,214 |  |  | (562) |  |  | (9) | % |
| Percentage of revenue |  | 14.7 | % |  | 14.6 | % |  |  |  |  |  | 14.1 | % |  | 14.9 | % |  |  |  |  |
| Total |  | $ | 12,702 |  |  | $ | 14,571 |  |  | $ | (1,869) |  |  | (13) | % |  | $ | 40,161 |  |  | $ | 41,795 |  |  | $ | (1,634) |  |  | (4) | % |

[0000858877-24-000007:mdna:72]
[same as prior period, unchanged from 0000858877-24-000003:mdna:79]

[0000858877-24-000007:mdna:73]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:74]
Total revenue decreased by 13%. Product revenue decreased by 19% and service revenue increased by 6%. Our total revenue reflected declines across each of our geographic segments.

[0000858877-24-000007:mdna:75]
[same as prior period, unchanged from 0000858877-24-000003:mdna:71]

[0000858877-24-000007:mdna:76]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:77]
Total revenue decreased by 4%. Product revenue decreased by 7% and service revenue increased by 5%. Our total revenue reflected declines across each of our geographic segments.

[0000858877-24-000007:mdna:78]
[same as prior period, unchanged from 0000858877-24-000003:mdna:74]

[0000858877-24-000007:mdna:79]
[same as prior period, unchanged from 0000858877-24-000003:mdna:75]

[0000858877-24-000007:mdna:80]
[same as prior period, unchanged from 0000858877-24-000003:mdna:76]

[0000858877-24-000007:mdna:81]
[same as prior period, unchanged from 0000858877-24-000003:mdna:77]

[0000858877-24-000007:mdna:82]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27,2024 |  | April 29,2023 |  | Variancein Dollars |  | Variance in Percent |  | April 27,2024 |  | April 29,2023 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,155 |  |  | $ | 6,519 |  |  | $ | (1,364) |  |  | (21) | % |  | $ | 17,352 |  |  | $ | 18,093 |  |  | $ | (741) |  |  | (4) | % |
| Percentage of product revenue |  | 57.1 | % |  | 58.8 | % |  |  |  |  |  | 59.0 | % |  | 57.5 | % |  |  |  |  |
| EMEA |  | 2,580 |  |  | 2,989 |  |  | (409) |  |  | (14) | % |  | 8,058 |  |  | 8,791 |  |  | (733) |  |  | (8) | % |
| Percentage of product revenue |  | 28.6 | % |  | 26.9 | % |  |  |  |  |  | 27.4 | % |  | 27.9 | % |  |  |  |  |
| APJC |  | 1,289 |  |  | 1,584 |  |  | (295) |  |  | (19) | % |  | 3,985 |  |  | 4,607 |  |  | (622) |  |  | (14) | % |
| Percentage of product revenue |  | 14.3 | % |  | 14.3 | % |  |  |  |  |  | 13.6 | % |  | 14.6 | % |  |  |  |  |
| Total |  | $ | 9,024 |  |  | $ | 11,092 |  |  | $ | (2,068) |  |  | (19) | % |  | $ | 29,395 |  |  | $ | 31,492 |  |  | $ | (2,097) |  |  | (7) | % |

[0000858877-24-000007:mdna:83]
[same as prior period, unchanged from 0000858877-24-000003:mdna:101]

[0000858877-24-000007:mdna:84]
[same as prior period, unchanged from 0000858877-24-000003:mdna:80]

[0000858877-24-000007:mdna:85]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:86]
Product revenue in the Americas segment decreased by 21%, with declines across each of our customer markets. The acquisition of Splunk contributed $221 million of product revenue to the Americas segment for the third quarter and first nine months of fiscal 2024. From a country perspective, product revenue decreased in the United States, Canada, Mexico and Brazil by 21%, 6%, 27% and 18%, respectively.

[0000858877-24-000007:mdna:87]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:88]
Product revenue in the Americas segment decreased by 4%, with declines in the enterprise and service provider and cloud markets, partially offset by growth in the public sector market. From a country perspective, product revenue decreased in the United States, Canada, Mexico and Brazil by 4%, 7%, 7% and 8%, respectively.

[0000858877-24-000007:mdna:89]
[same as prior period, unchanged from 0000858877-24-000003:mdna:85]

[0000858877-24-000007:mdna:90]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:91]
Product revenue in the EMEA segment decreased by 14%, driven by declines across each of the customer markets. The acquisition of Splunk contributed $76 million of product revenue to the EMEA segment for the third quarter and first nine months of fiscal 2024. From a country perspective, product revenue decreased in the United Kingdom, Germany and France by 9%, 18% and 8%, respectively.

[0000858877-24-000007:mdna:92]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:93]
Product revenue in the EMEA segment decreased by 8%, driven by declines in the enterprise and service provider and cloud markets, partially offset by growth in the public sector market. From a country perspective, product revenue decreased in the United Kingdom, Germany, and France by 9%, 12% and 12%, respectively.

[0000858877-24-000007:mdna:94]
[same as prior period, unchanged from 0000858877-24-000003:mdna:90]

[0000858877-24-000007:mdna:95]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:96]
Product revenue in the APJC segment decreased by 19%, with declines across each of the customer markets. The acquisition of Splunk contributed $41 million of product revenue to the APJC segment for the third quarter and first nine months of fiscal 2024. From a country perspective, product revenue decreased in Japan, India, Australia, and China by 11%, 17%, 22% and 32%, respectively.

[0000858877-24-000007:mdna:97]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:98]
Product revenue in the APJC segment decreased by 14%, with declines across each of the customer markets. From a country perspective, product revenue decreased in Japan, India, Australia, and China by 14%, 11%, 12% and 37%, respectively.

[0000858877-24-000007:mdna:99]
[same as prior period, unchanged from 0000858877-24-000003:mdna:95]

[0000858877-24-000007:mdna:100]
[same as prior period, unchanged from 0000858877-24-000003:mdna:96]

[0000858877-24-000007:mdna:101]
[same as prior period, unchanged from 0000858877-24-000003:mdna:97]

[0000858877-24-000007:mdna:102]
[same as prior period, unchanged from 0000858877-24-000003:mdna:98]

[0000858877-24-000007:mdna:103]
[same as prior period, unchanged from 0000858877-24-000003:mdna:99]

[0000858877-24-000007:mdna:104]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27,2024 |  | April 29,2023 |  | Variancein Dollars |  | Variance in Percent |  | April 27, 2024 |  | April 29, 2023 |  | Variance in Dollars |  | Variance in Percent |
| Product Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking |  | $ | 6,522 |  |  | $ | 8,982 |  |  | $ | (2,460) |  |  | (27) | % |  | $ | 22,425 |  |  | $ | 25,105 |  |  | $ | (2,680) |  |  | (11) | % |
| Security |  | 1,304 |  |  | 958 |  |  | 346 |  |  | 36 | % |  | 3,288 |  |  | 2,872 |  |  | 416 |  |  | 14 | % |
| Collaboration |  | 987 |  |  | 985 |  |  | 2 |  |  | — | % |  | 3,093 |  |  | 3,029 |  |  | 64 |  |  | 2 | % |
| Observability |  | 211 |  |  | 167 |  |  | 44 |  |  | 27 | % |  | 589 |  |  | 486 |  |  | 103 |  |  | 21 | % |
| Total |  | $ | 9,024 |  |  | $ | 11,092 |  |  | $ | (2,068) |  |  | (19) | % |  | $ | 29,395 |  |  | $ | 31,492 |  |  | $ | (2,097) |  |  | (7) | % |

[0000858877-24-000007:mdna:105]
[same as prior period, unchanged from 0000858877-24-000003:mdna:127]

[0000858877-24-000007:mdna:106]
[same as prior period, unchanged from 0000858877-24-000003:mdna:102]

[0000858877-24-000007:mdna:107]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:108]
The Networking product category represents our core networking technologies of switching, routing, wireless, 5G, silicon, optics solutions and compute products. Revenue from the Networking product category decreased by 27%, or $2.5 billion. Revenue declined across most of the portfolio and across each of our geographic segments due to continued implementation of inventory by our customers.

[0000858877-24-000007:mdna:109]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:110]
Revenue from the Networking product category decreased by 11%, or $2.7 billion. Revenue declined in both campus switching and data center switching, primarily driven by declines in our Catalyst 9000 series and Nexus 9000 series offerings. We experienced a revenue decline in enterprise routing, although we saw revenue growth in our SD-WAN offerings. The decrease in wireless was primarily driven by our WiFi-6 products and Meraki offerings. We also saw a revenue decline in routed optical networking.

[0000858877-24-000007:mdna:111]
[same as prior period, unchanged from 0000858877-24-000003:mdna:107]

[0000858877-24-000007:mdna:112]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:113]
The Security product category consists of our Cloud and Application Security, Industrial Security, Network Security, and User and Device Security offerings. This product category includes the Splunk Platform and Splunk Security offerings after our acquisition of Splunk, although the Splunk Platform has use cases that can also be applicable for observability offerings. Revenue in our Security product category increased by 36%, or $346 million, primarily driven by the contribution of Splunk offerings and to a lesser extent, growth in our Secure Access Service Edge offerings and double-digit growth in our Zero Trust offerings. The Security product category grew 3%, not including the contribution from Splunk offerings.

[0000858877-24-000007:mdna:114]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:115]
Revenue from the Security product category increased by 14%, or $416 million, primarily driven by the contribution of Splunk offerings and the growth in our Zero Trust offerings. The Security product category grew 3%, not including the contribution from Splunk offerings.

[0000858877-24-000007:mdna:116]
[same as prior period, unchanged from 0000858877-24-000003:mdna:112]

[0000858877-24-000007:mdna:117]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:118]
The Collaboration product category consists of our Meetings, Collaboration Devices, Calling, Contact Center and CPaaS offerings. Revenue in our Collaboration product category was flat, primarily driven by growth in our Calling and Contact Center offerings, offset by a decline in Meetings and Collaboration Devices.

[0000858877-24-000007:mdna:119]
[same as prior period, unchanged from 0000858877-24-000003:mdna:117]

[0000858877-24-000007:mdna:120]
[same as prior period, unchanged from 0000858877-24-000003:mdna:118]

[0000858877-24-000007:mdna:121]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:122]
Revenue from our Collaboration product category increased by 2%, or $64 million, primarily driven by growth in Calling, Collaboration Devices and Contact Center offerings, partially offset by a decline in Meetings.

[0000858877-24-000007:mdna:123]
[same as prior period, unchanged from 0000858877-24-000003:mdna:119]

[0000858877-24-000007:mdna:124]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:125]
The Observability product category consists of our full stack observability offerings. This product category includes the Splunk Observability Suite after our acquisition of Splunk. This product category excludes the Splunk Platform which includes use cases that can also be associated with observability offerings. Revenue in our Observability product category increased 27%, or $44 million, driven by growth in our ThousandEyes network services offerings and the contribution from Splunk. Product revenue in the Observability product category increased 14%, not including the contribution from Splunk.

[0000858877-24-000007:mdna:126]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:127]
Revenue from the Observability product category increased by 21%, or $103 million, primarily driven by growth in our ThousandEyes network services offerings and the contribution from Splunk. Product revenue in the Observability product category increased 17%, not including the contribution from Splunk.

[0000858877-24-000007:mdna:128]
[same as prior period, unchanged from 0000858877-24-000003:mdna:124]

[0000858877-24-000007:mdna:129]
[same as prior period, unchanged from 0000858877-24-000003:mdna:125]

[0000858877-24-000007:mdna:130]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27,2024 |  | April 29,2023 |  | Variancein Dollars |  | Variance in Percent |  | April 27, 2024 |  | April 29, 2023 |  | Variance in Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,217 |  |  | $ | 2,115 |  |  | $ | 102 |  |  | 5 | % |  | $ | 6,552 |  |  | $ | 6,279 |  |  | $ | 273 |  |  | 4 | % |
| Percentage of service revenue |  | 60.3 | % |  | 60.8 | % |  |  |  |  |  | 60.9 | % |  | 60.9 | % |  |  |  |  |
| EMEA |  | 878 |  |  | 817 |  |  | 61 |  |  | 7 | % |  | 2,548 |  |  | 2,417 |  |  | 131 |  |  | 5 | % |
| Percentage of service revenue |  | 23.9 | % |  | 23.5 | % |  |  |  |  |  | 23.7 | % |  | 23.5 | % |  |  |  |  |
| APJC |  | 584 |  |  | 547 |  |  | 37 |  |  | 7 | % |  | 1,667 |  |  | 1,606 |  |  | 61 |  |  | 4 | % |
| Percentage of service revenue |  | 15.8 | % |  | 15.7 | % |  |  |  |  |  | 15.4 | % |  | 15.6 | % |  |  |  |  |
| Total |  | $ | 3,678 |  |  | $ | 3,479 |  |  | $ | 199 |  |  | 6 | % |  | $ | 10,766 |  |  | $ | 10,303 |  |  | $ | 463 |  |  | 5 | % |

[0000858877-24-000007:mdna:131]
[same as prior period, unchanged from 0000858877-24-000003:mdna:157]

[0000858877-24-000007:mdna:132]
Service revenue increased 6% in the third quarter of fiscal 2024 compared with the third quarter of fiscal 2023, primarily driven by revenue growth in our solution support offerings, software support offerings, maintenance business and advisory services. The acquisition of Splunk also contributed to the growth in service revenue in the third quarter of fiscal 2024. Service revenue increased across each of our geographic segments for the third quarter of fiscal 2024. Service revenue grew 4%, not including the contribution from Splunk.

[0000858877-24-000007:mdna:133]
Service revenue increased 5% in the first nine months of fiscal 2024 compared to the first nine months of fiscal 2023, primarily driven by revenue growth in our solution support offerings, advisory services and maintenance business. The acquisition of Splunk also contributed to the growth in service revenue in the first nine months of fiscal 2024. Service revenue increased across each of our geographic segments. Service revenue grew 4%, not including the contribution from Splunk.

[0000858877-24-000007:mdna:134]
[same as prior period, unchanged from 0000858877-24-000003:mdna:133]

[0000858877-24-000007:mdna:135]
[same as prior period, unchanged from 0000858877-24-000003:mdna:134]

[0000858877-24-000007:mdna:136]
[same as prior period, unchanged from 0000858877-24-000003:mdna:130]

[0000858877-24-000007:mdna:137]
[same as prior period, unchanged from 0000858877-24-000003:mdna:131]

[0000858877-24-000007:mdna:138]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,729 |  |  | $ | 6,956 |  |  | 63.5 | % |  | 62.7 | % |  | $ | 18,700 |  |  | $ | 19,139 |  |  | 63.6 | % |  | 60.8 | % |
| Service |  | 2,544 |  |  | 2,276 |  |  | 69.2 | % |  | 65.4 | % |  | 7,347 |  |  | 6,866 |  |  | 68.2 | % |  | 66.6 | % |
| Total |  | $ | 8,273 |  |  | $ | 9,232 |  |  | 65.1 | % |  | 63.4 | % |  | $ | 26,047 |  |  | $ | 26,005 |  |  | 64.9 | % |  | 62.2 | % |

[0000858877-24-000007:mdna:139]
[same as prior period, unchanged from 0000858877-24-000003:mdna:135]

[0000858877-24-000007:mdna:140]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the third quarter and first nine months of fiscal 2024, as compared with the corresponding prior year periods:

[0000858877-24-000007:mdna:141]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Nine Months Ended |
| Fiscal 2023 |  | 62.7 | % |  | 60.8 | % |
| Productivity (1) |  | 1.7 | % |  | 2.1 | % |
| Product pricing |  | (1.9) | % |  | (0.2) | % |
| Mix of products sold |  | 2.1 | % |  | 1.5 | % |
| Amortization of purchased intangible assets |  | (1.4) | % |  | (0.6) | % |
| Impact of Splunk offerings |  | 0.7 | % |  | 0.2 | % |
| Others |  | (0.4) | % |  | (0.2) | % |
| Fiscal 2024 |  | 63.5 | % |  | 63.6 | % |

[0000858877-24-000007:mdna:142]
[same as prior period, unchanged from 0000858877-24-000003:mdna:138]

[0000858877-24-000007:mdna:143]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:144]
Product gross margin increased by 0.8 percentage points primarily driven by favorable product mix, productivity improvements, largely driven by lower freight and other costs, and benefits from the acquisition of Splunk. These impacts were partially offset by pricing erosion and the amortization of purchased intangible assets.

[0000858877-24-000007:mdna:145]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:146]
Product gross margin increased by 2.8 percentage points primarily driven by productivity improvements, largely driven by lower freight and other costs, favorable product mix, and to a lesser extent, benefits from the acquisition of Splunk. These impacts were partially offset by the amortization of purchased intangible assets and pricing erosion.

[0000858877-24-000007:mdna:147]
Supply Chain Impacts and Risks

[0000858877-24-000007:mdna:148]
In past periods, we took multiple actions in order to mitigate component shortages and address significant supply constraints. Additionally, these supply constraints resulted in significant increased costs (i.e., component and other commodity costs, expedite fees, etc.) which had a negative impact on our product gross margin and resulted in extended lead times for us and our customers. The mitigating actions we took included: partnering with several of our key suppliers utilizing our volume purchasing ability and extending supply coverage, including, in certain cases, revising supplier arrangements; paying and committing to pay in the future significantly higher costs for certain components; modifying our product designs in order to leverage alternate suppliers, where possible; and continually optimizing our inventory build and customer delivery plans, among others. These mitigating actions have resulted in increased inventory supply chain balances compared to historical levels. This in turn has increased our supply chain exposure, which could result in negative impacts to our product gross margin in future periods, including material excess and obsolete charges, if product demand significantly decreases for a sustained duration or we are unable to continue to mitigate the remaining supply chain exposures. We believe these mitigating actions have helped us to optimize our access to critical components and meet customer demand for our products as a result of the

[0000858877-24-000007:mdna:149]
[same as prior period, unchanged from 0000858877-24-000003:mdna:149]

[0000858877-24-000007:mdna:150]
[same as prior period, unchanged from 0000858877-24-000003:mdna:150]

[0000858877-24-000007:mdna:151]
component shortages and significant supply constraints we saw in past periods. While we have seen a decrease in our overall inventory supply chain balances in recent periods, these balances continue to be higher as compared to historical levels.

[0000858877-24-000007:mdna:152]
[same as prior period, unchanged from 0000858877-24-000003:mdna:145]

[0000858877-24-000007:mdna:153]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:154]
Our service gross margin percentage increased by 3.8 percentage points primarily due to lower headcount-related costs and higher sales volume, partially offset by unfavorable mix of service offerings and to a lesser extent, higher delivery costs.

[0000858877-24-000007:mdna:155]
[same as prior period, unchanged from 0000858877-24-000003:mdna:148]

[0000858877-24-000007:mdna:156]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:157]
Service gross margin increased by 1.6 percentage points primarily due to higher sales volume and lower headcount-related costs, partially offset by unfavorable mix of service offerings.

[0000858877-24-000007:mdna:158]
[same as prior period, unchanged from 0000858877-24-000003:mdna:153]

[0000858877-24-000007:mdna:159]
[same as prior period, unchanged from 0000858877-24-000003:mdna:154]

[0000858877-24-000007:mdna:160]
|  | Three Months Ended |  | Nine Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 5,006 |  |  | $ | 5,545 |  |  | 67.9 | % |  | 64.2 | % |  | $ | 15,906 |  |  | $ | 15,449 |  |  | 66.5 | % |  | 63.4 | % |
| EMEA | 2,406 |  |  | 2,536 |  |  | 69.6 | % |  | 66.6 | % |  | 7,324 |  |  | 7,330 |  |  | 69.1 | % |  | 65.4 | % |
| APJC | 1,262 |  |  | 1,415 |  |  | 67.4 | % |  | 66.4 | % |  | 3,816 |  |  | 3,986 |  |  | 67.5 | % |  | 64.2 | % |
| Segment total | 8,673 |  |  | 9,495 |  |  | 68.3 | % |  | 65.2 | % |  | 27,046 |  |  | 26,764 |  |  | 67.3 | % |  | 64.0 | % |
| Unallocated corporate items (1) | (400) |  |  | (263) |  |  |  |  |  |  | (999) |  |  | (759) |  |  |  |  |  |
| Total | $ | 8,273 |  |  | $ | 9,232 |  |  | 65.1 | % |  | 63.4 | % |  | $ | 26,047 |  |  | $ | 26,005 |  |  | 64.9 | % |  | 62.2 | % |

[0000858877-24-000007:mdna:161]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-24-000007:mdna:162]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-24-000007:mdna:163]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:164]
We experienced a gross margin percentage increase in our Americas segment due to favorable product mix, higher service gross margin and positive impacts from productivity improvements, partially offset by pricing erosion.

[0000858877-24-000007:mdna:165]
Gross margin percentage in our EMEA segment increased primarily due to favorable product mix, higher service gross margin and positive impacts from productivity improvements, partially offset by pricing erosion.

[0000858877-24-000007:mdna:166]
The APJC segment gross margin percentage increase was primarily due to favorable product mix, higher service gross margin and positive impacts from productivity improvements, partially offset by pricing erosion.

[0000858877-24-000007:mdna:167]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:168]
The Americas segment had a gross margin percentage increase driven by positive impacts from productivity improvements and favorable product mix.

[0000858877-24-000007:mdna:169]
[same as prior period, unchanged from 0000858877-24-000003:mdna:164]

[0000858877-24-000007:mdna:170]
[same as prior period, unchanged from 0000858877-24-000003:mdna:165]

[0000858877-24-000007:mdna:171]
[same as prior period, unchanged from 0000858877-24-000003:mdna:166]

[0000858877-24-000007:mdna:172]
[same as prior period, unchanged from 0000858877-24-000003:mdna:167]

[0000858877-24-000007:mdna:173]
[same as prior period, unchanged from 0000858877-24-000003:mdna:168]

[0000858877-24-000007:mdna:174]
[same as prior period, unchanged from 0000858877-24-000003:mdna:169]

[0000858877-24-000007:mdna:175]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |  | Variancein Dollars |  | Variance in Percent |  | April 27, 2024 |  | April 29, 2023 |  | Variance in Dollars |  | Variance in Percent |
| Research and development | $ | 1,948 |  |  | $ | 1,962 |  |  | $ | (14) |  |  | (1) | % |  | $ | 5,804 |  |  | $ | 5,598 |  |  | $ | 206 |  |  | 4 | % |
| Percentage of revenue | 15.3 | % |  | 13.5 | % |  |  |  |  |  | 14.5 | % |  | 13.4 | % |  |  |  |  |
| Sales and marketing | 2,559 |  |  | 2,526 |  |  | 33 |  |  | 1 | % |  | 7,523 |  |  | 7,301 |  |  | 222 |  |  | 3 | % |
| Percentage of revenue | 20.1 | % |  | 17.3 | % |  |  |  |  |  | 18.7 | % |  | 17.5 | % |  |  |  |  |
| General and administrative | 736 |  |  | 641 |  |  | 95 |  |  | 15 | % |  | 2,050 |  |  | 1,788 |  |  | 262 |  |  | 15 | % |
| Percentage of revenue | 5.8 | % |  | 4.4 | % |  |  |  |  |  | 5.1 | % |  | 4.3 | % |  |  |  |  |
| Total | $ | 5,243 |  |  | $ | 5,129 |  |  | $ | 114 |  |  | 2 | % |  | $ | 15,377 |  |  | $ | 14,687 |  |  | $ | 690 |  |  | 5 | % |
| Percentage of revenue | 41.3 | % |  | 35.2 | % |  |  |  |  |  | 38.3 | % |  | 35.1 | % |  |  |  |  |

[0000858877-24-000007:mdna:176]
[same as prior period, unchanged from 0000858877-24-000003:mdna:171]

[0000858877-24-000007:mdna:177]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:178]
R&D expenses decreased due to lower headcount-related expenses and lower contracted services spending, partially offset by higher share-based compensation expense, higher cash compensation from acquisitions and higher discretionary spending.

[0000858877-24-000007:mdna:179]
[same as prior period, unchanged from 0000858877-24-000003:mdna:174]

[0000858877-24-000007:mdna:180]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:181]
[same as prior period, unchanged from 0000858877-24-000003:mdna:173]

[0000858877-24-000007:mdna:182]
[same as prior period, unchanged from 0000858877-24-000003:mdna:177]

[0000858877-24-000007:mdna:183]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:184]
Sales and marketing expenses increased primarily due to higher share-based compensation expense and higher cash compensation from acquisitions, partially offset by lower contracted services spending and lower headcount-related expenses.

[0000858877-24-000007:mdna:185]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:186]
Sales and marketing expenses increased primarily due to higher share-based compensation expense, higher discretionary spending, higher cash compensation from acquisitions and higher headcount-related expenses, partially offset by lower contracted services spending.

[0000858877-24-000007:mdna:187]
[same as prior period, unchanged from 0000858877-24-000003:mdna:182]

[0000858877-24-000007:mdna:188]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:189]
G&A expenses increased due to higher acquisition-related costs and higher share-based compensation expense, partially offset by lower headcount-related expenses and lower contracted services spending.

[0000858877-24-000007:mdna:190]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:191]
G&A expenses increased due to higher acquisition-related costs, higher share-based compensation expense and higher discretionary spending.

[0000858877-24-000007:mdna:192]
[same as prior period, unchanged from 0000858877-24-000003:mdna:187]

[0000858877-24-000007:mdna:193]
In the third quarter of fiscal 2024, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $3 million, or 0.1%, compared with the third quarter of fiscal 2023.

[0000858877-24-000007:mdna:194]
In the first nine months of fiscal 2024, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $46 million, or 0.3%, compared with the first nine months of fiscal 2023.

[0000858877-24-000007:mdna:195]
[same as prior period, unchanged from 0000858877-24-000003:mdna:191]

[0000858877-24-000007:mdna:196]
[same as prior period, unchanged from 0000858877-24-000003:mdna:192]

[0000858877-24-000007:mdna:197]
[same as prior period, unchanged from 0000858877-24-000003:mdna:193]

[0000858877-24-000007:mdna:198]
[same as prior period, unchanged from 0000858877-24-000003:mdna:194]

[0000858877-24-000007:mdna:199]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 254 |  |  | $ | 160 |  |  | $ | 620 |  |  | $ | 476 |  |
| Operating expenses |  | 297 |  |  | 70 |  |  | 430 |  |  | 212 |  |
| Total |  | $ | 551 |  |  | $ | 230 |  |  | $ | 1,050 |  |  | $ | 688 |  |

[0000858877-24-000007:mdna:200]
For each of the third quarter and first nine months of fiscal 2024, the increase in amortization of purchased intangible assets was primarily due to amortization of purchased intangibles from our recent acquisitions, including $187 million for the third quarter and first nine months of fiscal 2024 due to the acquisition of Splunk, and impairment charges of $139 million and $145 million for the third quarter and first nine months of fiscal 2024, respectively. The increase was partially offset by certain purchased intangible assets that became fully amortized. The impairment charges were primarily due to declines in estimated fair value resulting from reductions in or the elimination of expected future cash flows associated with certain of our IPR&D intangible assets.

[0000858877-24-000007:mdna:201]
[same as prior period, unchanged from 0000858877-24-000003:mdna:197]

[0000858877-24-000007:mdna:202]
In the third quarter of fiscal 2024, we initiated a restructuring plan in order to realign the organization and enable further investment in key priority areas. This restructuring plan will impact approximately 5% of our global workforce, with estimated pretax charges of up to approximately $800 million. In connection with this restructuring plan, we incurred charges of $542 million in the third quarter and the first nine months of fiscal 2024. We expect this plan to be substantially completed during the first half of fiscal 2025.

[0000858877-24-000007:mdna:203]
In the second quarter of fiscal 2023, we announced a restructuring plan in order to rebalance the organization and enable further investment in key priority areas. In connection with this restructuring plan, we incurred charges of $135 million in the first nine months of fiscal 2024. We completed this restructuring plan in the second quarter of fiscal 2024 and incurred cumulative charges of $670 million.

[0000858877-24-000007:mdna:204]
We expect to reinvest substantially all of the cost savings from these restructuring plans in our key priority areas. As a result, the overall cost savings from these restructuring plans are not expected to be material for future periods.

[0000858877-24-000007:mdna:205]
[same as prior period, unchanged from 0000858877-24-000003:mdna:200]

[0000858877-24-000007:mdna:206]
[same as prior period, unchanged from 0000858877-24-000003:mdna:201]

[0000858877-24-000007:mdna:207]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Operating income |  | $ | 2,191 |  |  | $ | 3,946 |  |  | $ | 9,563 |  |  | $ | 10,778 |  |
| Operating income as a percentage of revenue |  | 17.2 | % |  | 27.1 | % |  | 23.8 | % |  | 25.8 | % |

[0000858877-24-000007:mdna:208]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:209]
Operating income decreased by 44%, and operating income as a percentage of revenue decreased by 9.9 percentage points. These changes resulted primarily from a revenue decrease, higher restructuring and other charges and higher amortization of purchased intangible assets, partially offset by a gross margin percentage increase (driven by favorable product mix and productivity improvements, partially offset by pricing erosion).

[0000858877-24-000007:mdna:210]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:211]
Operating income decreased by 11%, and operating income as a percentage of revenue decreased by 2.0 percentage points. These changes resulted primarily from a revenue decrease, higher restructuring and other charges and higher amortization of purchased intangible assets, partially offset by a gross margin percentage increase (driven by productivity improvements and favorable product mix, partially offset by pricing erosion).

[0000858877-24-000007:mdna:212]
54

[0000858877-24-000007:mdna:213]
[same as prior period, unchanged from 0000858877-24-000003:mdna:207]

[0000858877-24-000007:mdna:214]
[same as prior period, unchanged from 0000858877-24-000003:mdna:208]

[0000858877-24-000007:mdna:215]
[same as prior period, unchanged from 0000858877-24-000003:mdna:209]

[0000858877-24-000007:mdna:216]
[same as prior period, unchanged from 0000858877-24-000003:mdna:210]

[0000858877-24-000007:mdna:217]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27,2024 |  | April 29,2023 |  | Variancein Dollars |  | April 27, 2024 |  | April 29, 2023 |  | Variance in Dollars |
| Interest income |  | $ | 411 |  |  | $ | 262 |  |  | $ | 149 |  |  | $ | 1,095 |  |  | $ | 650 |  |  | $ | 445 |  |
| Interest expense |  | (357) |  |  | (109) |  |  | (248) |  |  | (588) |  |  | (316) |  |  | (272) |  |
| Interest income (expense), net |  | $ | 54 |  |  | $ | 153 |  |  | $ | (99) |  |  | $ | 507 |  |  | $ | 334 |  |  | $ | 173 |  |

[0000858877-24-000007:mdna:218]
For the third quarter and first nine months of fiscal 2024, the increase in interest income was driven by higher average balance of cash and available-for-sale debt investments and higher interest rates. The increase in interest expense was primarily driven by higher interest rates and the issuance of senior notes and commercial paper issued in the third quarter of fiscal 2024. We incurred incremental net interest expense of approximately $150 million for the third quarter and first nine months of fiscal 2024 to finance the acquisition of Splunk. We expect lower interest income in future periods due to lower average balance of cash and available-for-sale debt investments and higher interest expense due to a higher balance of debt.

[0000858877-24-000007:mdna:219]
[same as prior period, unchanged from 0000858877-24-000003:mdna:213]

[0000858877-24-000007:mdna:220]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27,2024 |  | April 29,2023 |  | Variancein Dollars |  | April 27, 2024 |  | April 29, 2023 |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | (14) |  |  | $ | (6) |  |  | $ | (8) |  |  | $ | (57) |  |  | $ | (15) |  |  | $ | (42) |  |
| Marketable equity investments |  | 19 |  |  | (8) |  |  | 27 |  |  | 35 |  |  | (10) |  |  | 45 |  |
| Privately held investments |  | (8) |  |  | (120) |  |  | 112 |  |  | (163) |  |  | (193) |  |  | 30 |  |
| Net gains (losses) on investments |  | (3) |  |  | (134) |  |  | 131 |  |  | (185) |  |  | (218) |  |  | 33 |  |
| Other gains (losses), net |  | (7) |  |  | (8) |  |  | 1 |  |  | (47) |  |  | (47) |  |  | — |  |
| Other income (loss), net |  | $ | (10) |  |  | $ | (142) |  |  | $ | 132 |  |  | $ | (232) |  |  | $ | (265) |  |  | $ | 33 |  |

[0000858877-24-000007:mdna:221]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:222]
The change in our other income (loss), net was primarily driven by changes in net gains (losses) on our privately held investments, primarily driven by lower impairment charges and higher realized gains on our privately held investments and changes in net gains (losses) on available-for-sale debt investments and marketable equity investments.

[0000858877-24-000007:mdna:223]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:224]
The change in our other income (loss), net was primarily driven by changes in net gains (losses) on our privately held investments, primarily driven by higher impairment charges on our privately held investments, partially offset by higher realized gains on our privately held investments, and changes in net gain (losses) on available-for-sale debt investments and marketable equity investments.

[0000858877-24-000007:mdna:225]
[same as prior period, unchanged from 0000858877-24-000003:mdna:219]

[0000858877-24-000007:mdna:226]
Three Months Ended April 27, 2024 Compared with Three Months Ended April 29, 2023

[0000858877-24-000007:mdna:227]
The provision for income taxes resulted in an effective tax rate of 15.6% for the third quarter of fiscal 2024 compared with 18.8% for the third quarter of fiscal 2023. The decrease in the effective tax rate was primarily due to an increase in benefit from R&D tax credits.

[0000858877-24-000007:mdna:228]
Nine Months Ended April 27, 2024 Compared with Nine Months Ended April 29, 2023

[0000858877-24-000007:mdna:229]
The provision for income taxes resulted in an effective tax rate of 17.1% for the first nine months of fiscal 2024 compared with 20.2% for the first nine months of fiscal 2023. The decrease in the effective tax rate was primarily due to an increase in benefit from R&D tax credits, a decrease in net discrete tax expenses, and an increase in stock-based compensation windfall.

[0000858877-24-000007:mdna:230]
55

[0000858877-24-000007:mdna:231]
[same as prior period, unchanged from 0000858877-24-000003:mdna:224]

[0000858877-24-000007:mdna:232]
[same as prior period, unchanged from 0000858877-24-000003:mdna:225]

[0000858877-24-000007:mdna:233]
[same as prior period, unchanged from 0000858877-24-000003:mdna:226]

[0000858877-24-000007:mdna:234]
[same as prior period, unchanged from 0000858877-24-000003:mdna:227]

[0000858877-24-000007:mdna:235]
[same as prior period, unchanged from 0000858877-24-000003:mdna:228]

[0000858877-24-000007:mdna:236]
[same as prior period, unchanged from 0000858877-24-000003:mdna:229]

[0000858877-24-000007:mdna:237]
|  | April 27,2024 |  | July 29,2023 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 8,913 |  |  | $ | 10,123 |  |  | $ | (1,210) |  |
| Available-for-sale debt investments | 9,407 |  |  | 15,592 |  |  | (6,185) |  |
| Marketable equity securities | 450 |  |  | 431 |  |  | 19 |  |
| Total | $ | 18,770 |  |  | $ | 26,146 |  |  | $ | (7,376) |  |

[0000858877-24-000007:mdna:238]
The net decrease in cash and cash equivalents and investments in the first nine months of fiscal 2024 was primarily driven by a net outflow for the acquisition of Splunk of $27.4 billion, cash returned to stockholders in the form of cash dividends of $4.8 billion and repurchases of common stock of $3.8 billion, repayment of debt of $1.8 billion, net cash paid for our other acquisitions, excluding Splunk, of $1.6 billion and capital expenditures of $0.5 billion. These uses of cash were partially offset by the issuance of senior notes for net proceeds of $13.4 billion, net issuances of commercial paper notes of $11.8 billion, and net cash provided by operating activities of $7.2 billion. The net cash provided by operating activities for the first nine months of fiscal 2024 includes the fiscal 2023 federal tax payment of $2.8 billion that was deferred by the IRS as a result of the California floods and the U.S. transition tax payment of $1.4 billion.

[0000858877-24-000007:mdna:239]
[same as prior period, unchanged from 0000858877-24-000003:mdna:233]

[0000858877-24-000007:mdna:240]
Securities Lending   We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of April 27, 2024 and July 29, 2023, we had no outstanding securities lending transactions.

[0000858877-24-000007:mdna:241]
[same as prior period, unchanged from 0000858877-24-000003:mdna:235]

[0000858877-24-000007:mdna:242]
[same as prior period, unchanged from 0000858877-24-000003:mdna:236]

[0000858877-24-000007:mdna:243]
|  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |
| Net cash provided by operating activities | $ | 7,150 |  |  | $ | 13,920 |  |
| Acquisition of property and equipment | (472) |  |  | (616) |  |
| Free cash flow | $ | 6,678 |  |  | $ | 13,304 |  |

[0000858877-24-000007:mdna:244]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management,

[0000858877-24-000007:mdna:245]
[same as prior period, unchanged from 0000858877-24-000003:mdna:238]

[0000858877-24-000007:mdna:246]
[same as prior period, unchanged from 0000858877-24-000003:mdna:239]

[0000858877-24-000007:mdna:247]
deferred revenue, and the timing and amount of tax and other payments. For additional discussion, see “Part II, Item 1A. Risk Factors” in this report.

[0000858877-24-000007:mdna:248]
[same as prior period, unchanged from 0000858877-24-000003:mdna:241]

[0000858877-24-000007:mdna:249]
[same as prior period, unchanged from 0000858877-24-000003:mdna:242]

[0000858877-24-000007:mdna:250]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| April 27, 2024 |  | $ | 0.40 |  |  | $ | 1,615 |  |  | 26 |  |  | $ | 49.22 |  |  | $ | 1,256 |  |  | $ | 2,871 |  |
| January 27, 2024 |  | $ | 0.39 |  |  | $ | 1,583 |  |  | 25 |  |  | $ | 49.54 |  |  | $ | 1,254 |  |  | $ | 2,837 |  |
| October 28, 2023 |  | $ | 0.39 |  |  | $ | 1,580 |  |  | 23 |  |  | $ | 54.53 |  |  | $ | 1,252 |  |  | $ | 2,832 |  |
| Fiscal 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 29, 2023 |  | $ | 0.39 |  |  | $ | 1,589 |  |  | 25 |  |  | $ | 50.49 |  |  | $ | 1,254 |  |  | $ | 2,843 |  |
| April 29, 2023 |  | $ | 0.39 |  |  | $ | 1,593 |  |  | 25 |  |  | $ | 49.45 |  |  | $ | 1,259 |  |  | $ | 2,852 |  |
| January 28, 2023 |  | $ | 0.38 |  |  | $ | 1,560 |  |  | 26 |  |  | $ | 47.72 |  |  | $ | 1,256 |  |  | $ | 2,816 |  |
| October 29, 2022 |  | $ | 0.38 |  |  | $ | 1,560 |  |  | 12 |  |  | $ | 43.76 |  |  | $ | 502 |  |  | $ | 2,062 |  |

[0000858877-24-000007:mdna:251]
On May 15, 2024, our Board of Directors declared a quarterly dividend of $0.40 per common share to be paid on July 24, 2024, to all stockholders of record as of the close of business on July 5, 2024. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-24-000007:mdna:252]
The remaining authorized amount for stock repurchases under this program is approximately $7.2 billion, with no termination date.

[0000858877-24-000007:mdna:253]
[same as prior period, unchanged from 0000858877-24-000003:mdna:246]

[0000858877-24-000007:mdna:254]
|  | April 27,2024 |  | July 29,2023 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,127 |  |  | $ | 5,854 |  |  | $ | (727) |  |

[0000858877-24-000007:mdna:255]
Our accounts receivable net, as of April 27, 2024 decreased by approximately 12%, as compared with the end of fiscal 2023, primarily due to timing and amount of product and service billings in the third quarter of fiscal 2024 compared with the fourth quarter of fiscal 2023.

[0000858877-24-000007:mdna:256]
[same as prior period, unchanged from 0000858877-24-000003:mdna:249]

[0000858877-24-000007:mdna:257]
[same as prior period, unchanged from 0000858877-24-000003:mdna:250]

[0000858877-24-000007:mdna:258]
[same as prior period, unchanged from 0000858877-24-000003:mdna:251]

[0000858877-24-000007:mdna:259]
|  | April 27,2024 |  | July 29,2023 |  | July 30,2022 |  | Variance vs. July 29, 2023 |  | Variance vs. July 30, 2022 |
| Inventories | $ | 3,118 |  |  | $ | 3,644 |  |  | $ | 2,568 |  |  | $ | (526) |  |  | $ | 550 |  |
| Inventory purchase commitments | $ | 6,004 |  |  | $ | 7,253 |  |  | $ | 12,964 |  |  | $ | (1,249) |  |  | $ | (6,960) |  |
| Inventory deposits and prepayments | $ | 925 |  |  | $ | 1,109 |  |  | $ | 1,484 |  |  | $ | (184) |  |  | $ | (559) |  |

[0000858877-24-000007:mdna:260]
[same as prior period, unchanged from 0000858877-24-000003:mdna:253]

[0000858877-24-000007:mdna:261]
|  | April 27,2024 |  | July 29,2023 |  | July 30,2022 |  | Variance vs. July 29, 2023 |  | Variance vs.July 30, 2022 |
| Less than 1 year | $ | 4,581 |  |  | $ | 5,270 |  |  | $ | 9,954 |  |  | $ | (689) |  |  | $ | (5,373) |  |
| 1 to 3 years | 1,368 |  |  | 1,783 |  |  | 2,240 |  |  | (415) |  |  | (872) |  |
| 3 to 5 years | 55 |  |  | 200 |  |  | 770 |  |  | (145) |  |  | (715) |  |
| Total | $ | 6,004 |  |  | $ | 7,253 |  |  | $ | 12,964 |  |  | $ | (1,249) |  |  | $ | (6,960) |  |

[0000858877-24-000007:mdna:262]
Inventory as of April 27, 2024 decreased by 14% and inventory purchase commitments with contract manufacturers and suppliers decreased by 17% from our balances at the end of fiscal 2023. The combined decrease of 16% in our inventory and inventory purchase commitments as compared with the end of fiscal 2023 was primarily due to fulfillment of customer demand as overall supply constraints improved and our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitment levels.

[0000858877-24-000007:mdna:263]
[same as prior period, unchanged from 0000858877-24-000003:mdna:256]

[0000858877-24-000007:mdna:264]
[same as prior period, unchanged from 0000858877-24-000003:mdna:257]

[0000858877-24-000007:mdna:265]
[same as prior period, unchanged from 0000858877-24-000003:mdna:258]

[0000858877-24-000007:mdna:266]
[same as prior period, unchanged from 0000858877-24-000003:mdna:259]

[0000858877-24-000007:mdna:267]
[same as prior period, unchanged from 0000858877-24-000003:mdna:260]

[0000858877-24-000007:mdna:268]
|  | April 27,2024 |  | July 29,2023 |  | Increase (Decrease) |
| Loan receivables, net | $ | 5,590 |  |  | $ | 5,857 |  |  | $ | (267) |  |
| Lease receivables, net | 1,104 |  |  | 978 |  |  | 126 |  |
| Total, net | $ | 6,694 |  |  | $ | 6,835 |  |  | $ | (141) |  |

[0000858877-24-000007:mdna:269]
[same as prior period, unchanged from 0000858877-24-000003:mdna:262]

[0000858877-24-000007:mdna:270]
[same as prior period, unchanged from 0000858877-24-000003:mdna:263]

[0000858877-24-000007:mdna:271]
Financing Receivables  Our financing arrangements include loans and leases. Our loan receivables include customer financing for purchases of our hardware, software and services (including technical support and advanced services), and also may include additional funds for other costs associated with network installation and integration of our products and services. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Financing receivables decreased by 2% as compared with the end of fiscal 2023.

[0000858877-24-000007:mdna:272]
[same as prior period, unchanged from 0000858877-24-000003:mdna:265]

[0000858877-24-000007:mdna:273]
The volume of channel partner financing was $6.1 billion and $8.3 billion for the third quarter of fiscal 2024 and 2023, respectively, and $20.9 billion and $23.4 billion for the first nine months of fiscal 2024 and 2023, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.1 billion and $1.7 billion as of April 27, 2024 and July 29, 2023, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of April 27, 2024, the total maximum potential future payments related to these guarantees was approximately $126 million, of which approximately $25 million was recorded as deferred revenue.

[0000858877-24-000007:mdna:274]
[same as prior period, unchanged from 0000858877-24-000003:mdna:267]

[0000858877-24-000007:mdna:275]
[same as prior period, unchanged from 0000858877-24-000003:mdna:268]

[0000858877-24-000007:mdna:276]
|  | Maturity Date |  | April 27,2024 |  | July 29,2023 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | $ | 750 |  |
| 3.625% | March 4, 2024 |  | — |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | — |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | — |  |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | — |  |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | — |  |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | — |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | — |  |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | — |  |
| Total |  |  | $ | 20,250 |  |  | $ | 8,500 |  |

[0000858877-24-000007:mdna:277]
In February 2024, we issued senior notes for an aggregate principal amount of $13.5 billion.

[0000858877-24-000007:mdna:278]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of April 27, 2024.

[0000858877-24-000007:mdna:279]
[same as prior period, unchanged from 0000858877-24-000003:mdna:273]

[0000858877-24-000007:mdna:280]
[same as prior period, unchanged from 0000858877-24-000003:mdna:274]

[0000858877-24-000007:mdna:281]
Commercial Paper  We have a short-term debt financing program in which up to $15.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had $11.9 billion and no commercial paper notes outstanding as of April 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000007:mdna:282]
Credit Facility  On May 13, 2021, we entered into a 5-year $3.0 billion unsecured revolving credit agreement, as amended on April 18, 2023. On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of April 27, 2024, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.

[0000858877-24-000007:mdna:283]
[same as prior period, unchanged from 0000858877-24-000003:mdna:275]

[0000858877-24-000007:mdna:284]
|  | April 27,2024 |  | July 29,2023 |  | Increase (Decrease) |
| Product | $ | 18,876 |  |  | $ | 15,802 |  |  | $ | 3,074 |  |
| Service | 19,898 |  |  | 19,066 |  |  | 832 |  |
| Total | $ | 38,774 |  |  | $ | 34,868 |  |  | $ | 3,906 |  |
| Short-term RPO | $ | 20,089 |  |  | $ | 17,910 |  |  | $ | 2,179 |  |
| Long-term RPO | 18,685 |  |  | 16,958 |  |  | 1,727 |  |
| Total | $ | 38,774 |  |  | $ | 34,868 |  |  | $ | 3,906 |  |

[0000858877-24-000007:mdna:285]
Total remaining performance obligations as of April 27, 2024 increased 11% compared to the end of fiscal 2023. Total remaining performance obligations as of April 27, 2024 includes $3.4 billion related to the acquisition of Splunk. Remaining performance obligations for product increased by 19% compared to the end of fiscal 2023. Remaining performance obligations for service increased by 4%. We expect approximately 52% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-24-000007:mdna:286]
[same as prior period, unchanged from 0000858877-24-000003:mdna:278]

[0000858877-24-000007:mdna:287]
|  | April 27,2024 |  | July 29,2023 |  | Increase (Decrease) |
| Product | $ | 12,856 |  |  | $ | 11,505 |  |  | $ | 1,351 |  |
| Service | 14,619 |  |  | 14,045 |  |  | 574 |  |
| Total | $ | 27,475 |  |  | $ | 25,550 |  |  | $ | 1,925 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 15,751 |  |  | $ | 13,908 |  |  | $ | 1,843 |  |
| Noncurrent | 11,724 |  |  | 11,642 |  |  | 82 |  |
| Total | $ | 27,475 |  |  | $ | 25,550 |  |  | $ | 1,925 |  |

[0000858877-24-000007:mdna:288]
Total deferred revenue increased 8% compared to the end of fiscal 2023. Total deferred revenue as of April 27, 2024 includes $1.8 billion related to the acquisition of Splunk. The increase in deferred product revenue of 12% was primarily due to the contribution from the Splunk acquisition and increased deferrals related to our recurring software offerings. The increase in deferred service revenue of 4% was driven by the contribution of the Splunk acquisition, partially offset by ongoing amortization of deferred service revenue.

[0000858877-24-000007:mdna:289]
[same as prior period, unchanged from 0000858877-24-000003:mdna:281]

[0000858877-24-000007:mdna:290]
[same as prior period, unchanged from 0000858877-24-000003:mdna:282]

[0000858877-24-000007:mdna:291]
The income tax payable outstanding as of April 27, 2024 for the U.S. transition tax on accumulated earnings for foreign subsidiaries was $4.1 billion. Approximately $1.8 billion is payable in fiscal 2025 and $2.3 billion is payable in fiscal 2026.

[0000858877-24-000007:mdna:292]
[same as prior period, unchanged from 0000858877-24-000003:mdna:284]

[0000858877-24-000007:mdna:293]
[same as prior period, unchanged from 0000858877-24-000003:mdna:286]

[0000858877-24-000007:mdna:294]
[same as prior period, unchanged from 0000858877-24-000003:mdna:287]

[0000858877-24-000007:mdna:295]
[same as prior period, unchanged from 0000858877-24-000003:mdna:288]

[0000858877-24-000007:mdna:296]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the continued employment with us of certain employees of the acquired entities. See Note 4 to the Consolidated Financial Statements.

[0000858877-24-000007:mdna:297]
We also have certain funding commitments primarily related to our privately held investments. The funding commitments were $0.2 billion and $0.3 billion as of April 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000007:mdna:298]
In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of April 27, 2024 there were no material unconsolidated variable interest entities.

[0000858877-24-000007:mdna:299]
[same as prior period, unchanged from 0000858877-24-000003:mdna:292]

[0000858877-24-000007:mdna:300]
[same as prior period, unchanged from 0000858877-24-000003:mdna:293]

[0000858877-24-000007:mdna:301]
[same as prior period, unchanged from 0000858877-24-000003:mdna:294]

[0000858877-24-000007:mdna:302]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs (including inventory and other supply related payments), capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.

[0000858877-24-000007:mdna:303]
61
