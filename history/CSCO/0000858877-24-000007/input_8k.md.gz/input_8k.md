# CSCO 8-K — 0001193125-24-139371 filed 2024-05-15

## item codes, every 8-K on or before 2024-05-21

- 2024-05-15 0001193125-24-139371 — 2.02, 5.02, 9.01
- 2024-03-18 0001193125-24-070175 — 2.01, 7.01, 9.01
- 2024-02-26 0001193125-24-046231 — 1.01, 2.03, 9.01
- 2024-02-14 0001193125-24-036201 — 2.02, 2.05, 9.01
- 2024-02-08 0001193125-24-028353 — 1.01, 2.03, 8.01, 9.01
- 2023-12-08 0001193125-23-291721 — 5.02, 5.07, 9.01
- 2023-11-15 0001193125-23-277891 — 2.02, 9.01
- 2023-10-10 0000858877-23-000025 — 5.02
- 2023-09-25 0001193125-23-240975 — 7.01
- 2023-09-21 0001193125-23-239165 — 1.01, 7.01, 8.01, 9.01
- 2023-08-16 0001193125-23-214316 — 2.02, 9.01
- 2023-07-19 0000858877-23-000016 — 5.02
- 2023-05-17 0001193125-23-147021 — 2.02, 9.01
- 2023-03-10 0000858877-23-000009 — 5.03, 9.01
- 2023-02-21 0000858877-23-000006 — 5.02
- 2023-02-15 0001193125-23-040212 — 2.02, 9.01
- 2022-12-16 0000858877-22-000029 — 8.01
- 2022-12-09 0000858877-22-000027 — 5.07
- 2022-11-16 0001628280-22-030151 — 5.02
- 2022-11-16 0001193125-22-286782 — 2.02, 2.05, 9.01
- 2022-10-04 0000858877-22-000018 — 1.01, 1.02, 9.01
- 2022-09-15 0000858877-22-000015 — 8.01
- 2022-08-24 0001193125-22-228572 — 5.02
- 2022-08-17 0001193125-22-223250 — 2.02, 9.01
- 2022-06-17 0001193125-22-176552 — 8.01
- 2022-05-18 0001193125-22-154039 — 2.02, 9.01
- 2022-03-28 0001193125-22-086807 — 8.01
- 2022-02-16 0001193125-22-044372 — 2.02, 9.01
- 2022-02-11 0001193125-22-037227 — 5.02
- 2022-01-31 0001193125-22-023458 — 5.02
- 2021-12-17 0001193125-21-361182 — 8.01
- 2021-12-14 0001193125-21-356837 — 5.07, 8.01
- 2021-11-17 0001193125-21-332467 — 2.02, 9.01
- 2021-09-27 0001193125-21-284199 — 8.01
- 2021-08-18 0001193125-21-250360 — 2.02, 9.01
- 2021-06-29 0001193125-21-203324 — 8.01
- 2021-05-19 0001193125-21-166614 — 2.02, 9.01
- 2021-05-14 0001193125-21-162081 — 1.01, 2.03, 9.01
- 2021-03-08 0001193125-21-073328 — 5.02
- 2021-02-25 0001193125-21-056977 — 5.02
- 2021-02-09 0001193125-21-034339 — 2.02, 9.01
- 2021-01-07 0001193125-21-004250 — 5.02
- 2020-12-17 0001193125-20-320092 — 5.02, 8.01
- 2020-12-11 0001193125-20-315999 — 5.02, 5.07, 9.01
- 2020-11-30 0001193125-20-305352 — 5.02
- 2020-11-13 0001193125-20-293020 — 5.02, 9.01
- 2020-11-12 0001193125-20-291658 — 2.02, 9.01
- 2020-10-09 0001193125-20-267248 — 5.03, 9.01
- 2020-09-23 0001193125-20-252356 — 8.01
- 2020-08-12 0001193125-20-217756 — 5.02
- 2020-08-12 0001193125-20-217658 — 2.02, 2.05, 9.01
- 2020-06-22 0001193125-20-175641 — 8.01
- 2020-05-13 0001193125-20-141598 — 2.02, 9.01
- 2020-03-13 0001193125-20-072960 — 5.02
- 2020-03-06 0001193125-20-065138 — 5.02
- 2020-02-12 0001193125-20-033208 — 2.02, 9.01
- 2020-01-27 0001193125-20-015453 — 5.02
- 2019-12-23 0001193125-19-322662 — 8.01
- 2019-12-12 0001193125-19-312796 — 8.01
- 2019-12-11 0001193125-19-311525 — 5.07
- 2019-12-04 0001193125-19-306229 — 8.01
- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2024-05-21

- none on or before 2024-05-21

## item 2.02 — earnings release, exhibit 99.1

[0001193125-24-139371:8k_2_02:1]
EX-99.1
2
d826117dex991.htm
EX-99.1

[0001193125-24-139371:8k_2_02:2]
EX-99.1

[0001193125-24-139371:8k_2_02:3]
Exhibit 99.1

[0001193125-24-139371:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Sami Badri |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 (469) 420-4834 |
| rojenkin@cisco.com |  |  |  | sambadri@cisco.com |

[0001193125-24-139371:8k_2_02:5]
CISCO REPORTS THIRD QUARTER EARNINGS

[0001193125-24-139371:8k_2_02:6]
News Summary:

[0001193125-24-139371:8k_2_02:7]
|  | • |  | $12.7 billion in revenue, down 13% year over year, in line with expectations and reflects our customers’ continued implementation of products on-hand |

[0001193125-24-139371:8k_2_02:8]
|  | • |  | Strong profitability with GAAP gross margin of 65.1% and non-GAAP gross margin of 68.3% |

[0001193125-24-139371:8k_2_02:9]
|  | • |  | Transformed business model, further enhanced by the Splunk acquisition: |

[0001193125-24-139371:8k_2_02:10]
|  | • |  | Total subscription revenue of $6.9 billion including Splunk, representing 54% of total revenue |

[0001193125-24-139371:8k_2_02:11]
|  | • |  | Total annualized recurring revenue (ARR) at $29.2 billion including $4.2 billion from Splunk, up 22% year over year, and product ARR at $15.5 billion, up 44% year over year |

[0001193125-24-139371:8k_2_02:12]
|  | • |  | Gary Steele, former Splunk CEO, named president of Go-to-Market, effective immediately |

[0001193125-24-139371:8k_2_02:13]
|  | • |  | Q3 FY 2024 Results: |

[0001193125-24-139371:8k_2_02:14]
|  | • |  | Revenue: $12.7 billion |

[0001193125-24-139371:8k_2_02:15]
|  | • |  | Decrease of 13% year over year |

[0001193125-24-139371:8k_2_02:16]
|  | • |  | Splunk contributed $413 million in revenue |

[0001193125-24-139371:8k_2_02:17]
|  | • |  | Earnings per Share: GAAP: $0.46; Non-GAAP: $0.88 |

[0001193125-24-139371:8k_2_02:18]
|  | • |  | GAAP EPS decreased 41% year over year, which includes a negative $0.09 impact from the Splunk acquisition |

[0001193125-24-139371:8k_2_02:19]
|  | • |  | Non-GAAP EPS decreased 12% year over year, which includes a negative $0.01 impact from the Splunk acquisition |

[0001193125-24-139371:8k_2_02:20]
|  | • |  | Q4 FY 2024 Guidance: |

[0001193125-24-139371:8k_2_02:21]
|  | • |  | Revenue: $13.4 billion to $13.6 billion |

[0001193125-24-139371:8k_2_02:22]
|  | • |  | Earnings per Share: GAAP: $0.46 to $0.51; Non-GAAP: $0.84 to $0.86 |

[0001193125-24-139371:8k_2_02:23]
|  | • |  | FY 2024 Guidance: |

[0001193125-24-139371:8k_2_02:24]
|  | • |  | Revenue: $53.6 billion to $53.8 billion |

[0001193125-24-139371:8k_2_02:25]
|  | • |  | Earnings per Share: GAAP: $2.46 to $2.51; Non-GAAP: $3.69 to $3.71 |

[0001193125-24-139371:8k_2_02:26]
SAN JOSE, Calif. — May 15, 2024 — Cisco today reported third quarter results for the period ended April 27, 2024.
Cisco reported third quarter revenue of $12.7 billion, net income on a generally accepted accounting principles (GAAP) basis of $1.9 billion or $0.46 per share, and non-GAAP net income of
$3.6 billion or $0.88 per share.

[0001193125-24-139371:8k_2_02:27]
“We delivered a solid Q3 performance in what remains a dynamic environment” said Chuck Robbins, chair and
CEO of Cisco. “Our unique ability to bring together networking, security, observability, and data enables Cisco to offer our customers unrivaled digital resilience for the AI era.”

[0001193125-24-139371:8k_2_02:28]
“Revenue, gross margin and non-GAAP EPS in Q3 were at the high end or above our guidance range, both including
and excluding Splunk, resulting in continued operating leverage,” said Scott Herren, CFO of Cisco. “Customers are consuming the equipment shipped over the last few quarters in line with our expectations and we are seeing stabilization of
demand as a result. The addition of Splunk to our product line will be a catalyst for further growth.”

[0001193125-24-139371:8k_2_02:29]
Gary Steele Named President of
Go-to-Market

[0001193125-24-139371:8k_2_02:30]
Cisco has named Gary Steele as President of Go-to-Market, effective immediately. Steele is well known for his operational excellence, and
in this new role, he will work closely with Robbins to set and execute against Cisco’s strategic plans and goals. He will continue to lead the Splunk team through the integration process to ensure a seamless integration into Cisco.

[0001193125-24-139371:8k_2_02:31]
Cisco also announced that Jeff Sharritts, Cisco’s Chief Customer and Partner Officer, will depart Cisco after a successful 24-year career at the company.
Sharritts will remain with Cisco until mid-July to ensure a seamless transition.

[0001193125-24-139371:8k_2_02:32]
1

[0001193125-24-139371:8k_2_02:33]
GAAP Results

[0001193125-24-139371:8k_2_02:34]
|  |  | Q3 FY 2024 |  |  | Q3 FY 2023 |  |  | Vs. Q3 FY 2023 |  |
| Revenue |  | $ | 12.7 billion |  |  | $ | 14.6 billion |  |  |  | (13 | )% |
| Net Income |  | $ | 1.9 billion |  |  | $ | 3.2 billion |  |  |  | (41 | )% |
| Diluted Earnings per Share (EPS) |  | $ | 0.46 |  |  | $ | 0.78 |  |  |  | (41 | )% |

[0001193125-24-139371:8k_2_02:35]
The acquisition of Splunk, including financing costs, had a negative impact of $0.09 to GAAP EPS, for the third quarter of
fiscal 2024.

[0001193125-24-139371:8k_2_02:36]
Non-GAAP Results

[0001193125-24-139371:8k_2_02:37]
|  |  | Q3 FY 2024 |  |  | Q3 FY 2023 |  |  | Vs. Q3 FY 2023 |  |
| Net Income |  | $ | 3.6 billion |  |  | $ | 4.1 billion |  |  |  | (14 | )% |
| EPS |  | $ | 0.88 |  |  | $ | 1.00 |  |  |  | (12 | )% |

[0001193125-24-139371:8k_2_02:38]
The acquisition of Splunk, including financing costs, had a negative impact of $0.01 to
Non-GAAP EPS, for the third quarter of fiscal 2024.

[0001193125-24-139371:8k_2_02:39]
Reconciliations between net income, EPS, and other measures
on a GAAP and non-GAAP basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-24-139371:8k_2_02:40]
Cisco Declares Quarterly Dividend

[0001193125-24-139371:8k_2_02:41]
Cisco has declared a
quarterly dividend of $0.40 per common share to be paid on July 24, 2024, to all stockholders of record as of the close of business on July 5, 2024. Future dividends will be subject to Board approval.

[0001193125-24-139371:8k_2_02:42]
2

[0001193125-24-139371:8k_2_02:43]
Financial Summary

[0001193125-24-139371:8k_2_02:44]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-24-139371:8k_2_02:45]
Q3 FY 2024 Highlights

[0001193125-24-139371:8k_2_02:46]
Revenue — Total
revenue was $12.7 billion, down 13%, with product revenue down 19% and service revenue up 6%. Cisco completed the acquisition of Splunk Inc. (“Splunk”) in the third quarter of fiscal 2024. Splunk contributed $413 million of total
revenue for the third quarter of fiscal 2024.

[0001193125-24-139371:8k_2_02:47]
Revenue by geographic segment was: Americas down 15%, EMEA down 9%, and APJC down 12%. Product revenue
performance reflected growth in Security up 36% and Observability up 27%. Networking was down 27%. Product revenue in Collaboration was flat. Security and Observability, excluding Splunk, grew 3% and 14%, respectively, in the third quarter of fiscal
2024.

[0001193125-24-139371:8k_2_02:48]
Gross Margin — On a GAAP basis, total gross margin, product gross margin, and service gross margin were 65.1%, 63.5%, and
69.2%, respectively, as compared with 63.4%, 62.7%, and 65.4%, respectively, in the third quarter of fiscal 2023.

[0001193125-24-139371:8k_2_02:49]
On a
non-GAAP basis, total gross margin, product gross margin, and service gross margin were 68.3%, 66.9%, and 71.6%, respectively, as compared with 65.2%, 64.5%, and 67.3%, respectively, in the third quarter of
fiscal 2023.

[0001193125-24-139371:8k_2_02:50]
Total gross margins by geographic segment were: 67.9% for the Americas, 69.6% for EMEA and 67.4% for APJC.

[0001193125-24-139371:8k_2_02:51]
Operating Expenses — On a GAAP basis, operating expenses were $6.1 billion, up 15%, and were 47.9% of revenue. Non-GAAP operating expenses were $4.3 billion, down 5%, and were 34.0% of revenue.

[0001193125-24-139371:8k_2_02:52]
Operating Income
— GAAP operating income was $2.2 billion, down 44%, with GAAP operating margin of 17.2%. Non-GAAP operating income was $4.3 billion, down 12%, with
non-GAAP operating margin at 34.2%.

[0001193125-24-139371:8k_2_02:53]
Provision for Income Taxes — The GAAP tax provision rate
was 15.6%. The non-GAAP tax provision rate was 19.0%.

[0001193125-24-139371:8k_2_02:54]
Net Income and EPS — On a GAAP basis,
net income was $1.9 billion and EPS was $0.46, each a decrease of 41%. On a non-GAAP basis, net income was $3.6 billion, a decrease of 14%, and EPS was $0.88, a decrease of 12%.

[0001193125-24-139371:8k_2_02:55]
Cash Flow from Operating Activities — $4.0 billion for the third quarter of fiscal 2024, a decrease of 24%, compared with
$5.2 billion for the third quarter of fiscal 2023.

[0001193125-24-139371:8k_2_02:56]
Balance Sheet and Other Financial Highlights

[0001193125-24-139371:8k_2_02:57]
Cash and Cash Equivalents and Investments — $18.8 billion at the end of the third quarter of fiscal 2024, compared with
$26.1 billion at the end of fiscal 2023.

[0001193125-24-139371:8k_2_02:58]
Remaining Performance Obligations (RPO) — $38.8 billion, up 21% in
total, with 52% of this amount to be recognized as revenue over the next 12 months. Product RPO were up 29% and service RPO were up 14%.

[0001193125-24-139371:8k_2_02:59]
Deferred
Revenue — $27.5 billion, up 13% in total, with deferred product revenue up 18%. Deferred service revenue was up 9%.

[0001193125-24-139371:8k_2_02:60]
Capital
Allocation — In the third quarter of fiscal 2024, we returned $2.9 billion to stockholders through share buybacks and dividends. We declared and paid a cash dividend of $0.40 per common share, or $1.6 billion, and repurchased
approximately 26 million shares of common stock under our stock repurchase program at an average price of $49.22 per share for an aggregate purchase price of $1.3 billion. The remaining authorized amount for stock repurchases under the
program is $7.2 billion with no termination date.

[0001193125-24-139371:8k_2_02:61]
Acquisitions

[0001193125-24-139371:8k_2_02:62]
In the third quarter of fiscal 2024, we closed the following acquisitions:

[0001193125-24-139371:8k_2_02:63]
|  | • |  | Splunk Inc., a public cybersecurity and observability company |

[0001193125-24-139371:8k_2_02:64]
|  | • |  | Isovalent, Inc., a privately held cloud native solutions company |

[0001193125-24-139371:8k_2_02:65]
3

[0001193125-24-139371:8k_2_02:66]
Guidance

[0001193125-24-139371:8k_2_02:67]
Cisco estimates the following results for the fourth quarter of fiscal 2024:

[0001193125-24-139371:8k_2_02:68]
| Q4 FY 2024 |  |  |  |
| Revenue |  |  | $13.4 billion - $13.6 billion |  |
| Non-GAAP gross margin rate |  |  | 66.5% – 67.5% |  |
| Non-GAAP operating margin rate |  |  | 31.5% – 32.5% |  |
| Non-GAAP EPS |  |  | $0.84 – $0.86 |  |

[0001193125-24-139371:8k_2_02:69]
Our Q4 FY 2024 guidance includes $950 million to $1 billion in revenue from Splunk and a negative impact to non-GAAP EPS of approximately ($0.03) as the interest impact from financing the acquisition more than offsets the operating benefit.

[0001193125-24-139371:8k_2_02:70]
Cisco estimates that GAAP EPS will be $0.46 to $0.51 for the fourth quarter of fiscal 2024.

[0001193125-24-139371:8k_2_02:71]
Cisco estimates the following results for fiscal 2024:

[0001193125-24-139371:8k_2_02:72]
| FY 2024 |  |  |  |
| Revenue |  |  | $53.6 billion - $53.8 billion |  |
| Non-GAAP EPS |  |  | $3.69 – $3.71 |  |

[0001193125-24-139371:8k_2_02:73]
Cisco estimates that GAAP EPS will be $2.46 to $2.51 for fiscal 2024.

[0001193125-24-139371:8k_2_02:74]
Our Q4 FY 2024 guidance assumes an effective tax provision rate of approximately 18% for GAAP and non-GAAP results.
Our FY 2024 guidance assumes an effective tax provision rate of approximately 17% for GAAP and approximately 19% for non-GAAP results.

[0001193125-24-139371:8k_2_02:75]
A reconciliation between the guidance on a GAAP and non-GAAP basis is provided in the tables entitled “GAAP to non-GAAP Guidance” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-24-139371:8k_2_02:76]
Editor’s Notes:

[0001193125-24-139371:8k_2_02:77]
|  | • |  | Q3 fiscal year 2024 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, May 15, 2024 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-24-139371:8k_2_02:78]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, May 15, 2024 to 4:00 p.m. Pacific Time, May 21, 2024 at 1-800-391-9851 (United States) or 1-203-369-3268 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-24-139371:8k_2_02:79]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, May 15, 2024. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-24-139371:8k_2_02:80]
4

[0001193125-24-139371:8k_2_02:81]
CISCO SYSTEMS, INC.

[0001193125-24-139371:8k_2_02:82]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-24-139371:8k_2_02:83]
(In millions, except per-share amounts)

[0001193125-24-139371:8k_2_02:84]
(Unaudited)

[0001193125-24-139371:8k_2_02:85]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 27,2024 |  |  | April 29,2023 |  |  | April 27,2024 |  |  | April 29,2023 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,024 |  |  | $ | 11,092 |  |  | $ | 29,395 |  |  | $ | 31,492 |  |
| Service |  |  | 3,678 |  |  |  | 3,479 |  |  |  | 10,766 |  |  |  | 10,303 |  |
| Total revenue |  |  | 12,702 |  |  |  | 14,571 |  |  |  | 40,161 |  |  |  | 41,795 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,295 |  |  |  | 4,136 |  |  |  | 10,695 |  |  |  | 12,353 |  |
| Service |  |  | 1,134 |  |  |  | 1,203 |  |  |  | 3,419 |  |  |  | 3,437 |  |
| Total cost of sales |  |  | 4,429 |  |  |  | 5,339 |  |  |  | 14,114 |  |  |  | 15,790 |  |
| GROSS MARGIN |  |  | 8,273 |  |  |  | 9,232 |  |  |  | 26,047 |  |  |  | 26,005 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,948 |  |  |  | 1,962 |  |  |  | 5,804 |  |  |  | 5,598 |  |
| Sales and marketing |  |  | 2,559 |  |  |  | 2,526 |  |  |  | 7,523 |  |  |  | 7,301 |  |
| General and administrative |  |  | 736 |  |  |  | 641 |  |  |  | 2,050 |  |  |  | 1,788 |  |
| Amortization of purchased intangible assets |  |  | 297 |  |  |  | 70 |  |  |  | 430 |  |  |  | 212 |  |
| Restructuring and other charges |  |  | 542 |  |  |  | 87 |  |  |  | 677 |  |  |  | 328 |  |
| Total operating expenses |  |  | 6,082 |  |  |  | 5,286 |  |  |  | 16,484 |  |  |  | 15,227 |  |
| OPERATING INCOME |  |  | 2,191 |  |  |  | 3,946 |  |  |  | 9,563 |  |  |  | 10,778 |  |
| Interest income |  |  | 411 |  |  |  | 262 |  |  |  | 1,095 |  |  |  | 650 |  |
| Interest expense |  |  | (357 | ) |  |  | (109 | ) |  |  | (588 | ) |  |  | (316 | ) |
| Other income (loss), net |  |  | (10 | ) |  |  | (142 | ) |  |  | (232 | ) |  |  | (265 | ) |
| Interest and other income (loss), net |  |  | 44 |  |  |  | 11 |  |  |  | 275 |  |  |  | 69 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 2,235 |  |  |  | 3,957 |  |  |  | 9,838 |  |  |  | 10,847 |  |
| Provision for income taxes |  |  | 349 |  |  |  | 745 |  |  |  | 1,680 |  |  |  | 2,192 |  |
| NET INCOME |  | $ | 1,886 |  |  | $ | 3,212 |  |  | $ | 8,158 |  |  | $ | 8,655 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.47 |  |  | $ | 0.79 |  |  | $ | 2.01 |  |  | $ | 2.11 |  |
| Diluted |  | $ | 0.46 |  |  | $ | 0.78 |  |  | $ | 2.00 |  |  | $ | 2.11 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,042 |  |  |  | 4,089 |  |  |  | 4,051 |  |  |  | 4,100 |  |
| Diluted |  |  | 4,060 |  |  |  | 4,110 |  |  |  | 4,071 |  |  |  | 4,111 |  |

[0001193125-24-139371:8k_2_02:86]
5

[0001193125-24-139371:8k_2_02:87]
CISCO SYSTEMS, INC.

[0001193125-24-139371:8k_2_02:88]
REVENUE BY SEGMENT

[0001193125-24-139371:8k_2_02:89]
(In
millions, except percentages)

[0001193125-24-139371:8k_2_02:90]
|  |  | April 27, 2024 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,372 |  |  |  | (15 | )% |  | $ | 23,904 |  |  |  | (2 | )% |
| EMEA |  |  | 3,458 |  |  |  | (9 | )% |  |  | 10,606 |  |  |  | (5 | )% |
| APJC |  |  | 1,873 |  |  |  | (12 | )% |  |  | 5,652 |  |  |  | (9 | )% |
| Total |  | $ | 12,702 |  |  |  | (13 | )% |  | $ | 40,161 |  |  |  | (4 | )% |

[0001193125-24-139371:8k_2_02:91]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-24-139371:8k_2_02:92]
CISCO SYSTEMS, INC.

[0001193125-24-139371:8k_2_02:93]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-24-139371:8k_2_02:94]
(In percentages)

[0001193125-24-139371:8k_2_02:95]
|  |  | April 27, 2024 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 67.9% |  |  |  | 66.5% |  |
| EMEA |  |  | 69.6% |  |  |  | 69.1% |  |
| APJC |  |  | 67.4% |  |  |  | 67.5% |  |

[0001193125-24-139371:8k_2_02:96]
CISCO SYSTEMS, INC.

[0001193125-24-139371:8k_2_02:97]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-24-139371:8k_2_02:98]
(In millions, except percentages)

[0001193125-24-139371:8k_2_02:99]
|  |  | April 27, 2024 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking |  | $ | 6,522 |  |  |  | (27 | )% |  | $ | 22,425 |  |  |  | (11 | )% |
| Security |  |  | 1,304 |  |  |  | 36 | % |  |  | 3,288 |  |  |  | 14 | % |
| Collaboration |  |  | 987 |  |  |  | — | % |  |  | 3,093 |  |  |  | 2 | % |
| Observability |  |  | 211 |  |  |  | 27 | % |  |  | 589 |  |  |  | 21 | % |
| Total Product |  |  | 9,024 |  |  |  | (19 | )% |  |  | 29,395 |  |  |  | (7 | )% |
| Services |  |  | 3,678 |  |  |  | 6 | % |  |  | 10,766 |  |  |  | 5 | % |
| Total |  | $ | 12,702 |  |  |  | (13 | )% |  | $ | 40,161 |  |  |  | (4 | )% |

[0001193125-24-139371:8k_2_02:100]
Security and Observability, excluding Splunk, grew 3% and 14%, respectively, in the third quarter of fiscal 2024, and 3% and
17%, respectively, for the first nine months of fiscal 2024.

[0001193125-24-139371:8k_2_02:101]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-24-139371:8k_2_02:102]
6

[0001193125-24-139371:8k_2_02:103]
CISCO SYSTEMS, INC.

[0001193125-24-139371:8k_2_02:104]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-24-139371:8k_2_02:105]
(In millions)

[0001193125-24-139371:8k_2_02:106]
(Unaudited)

[0001193125-24-139371:8k_2_02:107]
|  |  | April 27, 2024 |  |  | July 29, 2023 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 8,913 |  |  | $ | 10,123 |  |
| Investments |  |  | 9,857 |  |  |  | 16,023 |  |
| Accounts receivable, net of allowance of $81 at April 27, 2024 and $85 at July 29, 2023 |  |  | 5,127 |  |  |  | 5,854 |  |
| Inventories |  |  | 3,118 |  |  |  | 3,644 |  |
| Financing receivables, net |  |  | 3,443 |  |  |  | 3,352 |  |
| Other current assets |  |  | 5,428 |  |  |  | 4,352 |  |
| Total current assets |  |  | 35,886 |  |  |  | 43,348 |  |
| Property and equipment, net |  |  | 2,000 |  |  |  | 2,085 |  |
| Financing receivables, net |  |  | 3,251 |  |  |  | 3,483 |  |
| Goodwill |  |  | 58,633 |  |  |  | 38,535 |  |
| Purchased intangible assets, net |  |  | 11,819 |  |  |  | 1,818 |  |
| Deferred tax assets |  |  | 5,527 |  |  |  | 6,576 |  |
| Other assets |  |  | 5,882 |  |  |  | 6,007 |  |
| TOTAL ASSETS |  | $ | 122,998 |  |  | $ | 101,852 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 11,891 |  |  | $ | 1,733 |  |
| Accounts payable |  |  | 2,054 |  |  |  | 2,313 |  |
| Income taxes payable |  |  | 1,867 |  |  |  | 4,235 |  |
| Accrued compensation |  |  | 3,211 |  |  |  | 3,984 |  |
| Deferred revenue |  |  | 15,751 |  |  |  | 13,908 |  |
| Other current liabilities |  |  | 5,334 |  |  |  | 5,136 |  |
| Total current liabilities |  |  | 40,108 |  |  |  | 31,309 |  |
| Long-term debt |  |  | 20,102 |  |  |  | 6,658 |  |
| Income taxes payable |  |  | 2,869 |  |  |  | 5,756 |  |
| Deferred revenue |  |  | 11,724 |  |  |  | 11,642 |  |
| Other long-term liabilities |  |  | 2,427 |  |  |  | 2,134 |  |
| Total liabilities |  |  | 77,230 |  |  |  | 57,499 |  |
| Total equity |  |  | 45,768 |  |  |  | 44,353 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 122,998 |  |  | $ | 101,852 |  |

[0001193125-24-139371:8k_2_02:108]
7

[0001193125-24-139371:8k_2_02:109]
CISCO SYSTEMS, INC.

[0001193125-24-139371:8k_2_02:110]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-24-139371:8k_2_02:111]
(In millions)

[0001193125-24-139371:8k_2_02:112]
(Unaudited)

[0001193125-24-139371:8k_2_02:113]
|  |  | Nine Months Ended |  |
|  |  | April 27, 2024 |  |  | April 29, 2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 8,158 |  |  | $ | 8,655 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,684 |  |  |  | 1,304 |  |
| Share-based compensation expense |  |  | 2,274 |  |  |  | 1,720 |  |
| Provision for receivables |  |  | 19 |  |  |  | 11 |  |
| Deferred income taxes |  |  | (245 | ) |  |  | (1,343 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | 224 |  |  |  | 243 |  |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,286 |  |  |  | 1,494 |  |
| Inventories |  |  | 530 |  |  |  | (894 | ) |
| Financing receivables |  |  | 92 |  |  |  | 1,126 |  |
| Other assets |  |  | (382 | ) |  |  | (428 | ) |
| Accounts payable |  |  | (300 | ) |  |  | 156 |  |
| Income taxes, net |  |  | (5,223 | ) |  |  | 1,120 |  |
| Accrued compensation |  |  | (1,092 | ) |  |  | 25 |  |
| Deferred revenue |  |  | 211 |  |  |  | 1,055 |  |
| Other liabilities |  |  | (86 | ) |  |  | (324 | ) |
| Net cash provided by operating activities |  |  | 7,150 |  |  |  | 13,920 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (3,044 | ) |  |  | (7,652 | ) |
| Proceeds from sales of investments |  |  | 3,874 |  |  |  | 802 |  |
| Proceeds from maturities of investments |  |  | 5,804 |  |  |  | 3,789 |  |
| Acquisitions, net of cash and cash equivalents acquired |  |  | (25,874 | ) |  |  | (96 | ) |
| Purchases of investments in privately held companies |  |  | (82 | ) |  |  | (162 | ) |
| Return of investments in privately held companies |  |  | 146 |  |  |  | 72 |  |
| Acquisition of property and equipment |  |  | (472 | ) |  |  | (616 | ) |
| Other |  |  | (2 | ) |  |  | (24 | ) |
| Net cash used in investing activities |  |  | (19,650 | ) |  |  | (3,887 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 347 |  |  |  | 316 |  |
| Repurchases of common stock—repurchase program |  |  | (3,772 | ) |  |  | (3,029 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (765 | ) |  |  | (444 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | 1,547 |  |  |  | (602 | ) |
| Issuances of debt |  |  | 24,159 |  |  |  | — |  |
| Repayments of debt |  |  | (2,195 | ) |  |  | (500 | ) |
| Repayments of Splunk convertible debt, net |  |  | (3,140 | ) |  |  | — |  |
| Dividends paid |  |  | (4,778 | ) |  |  | (4,713 | ) |
| Other |  |  | (52 | ) |  |  | (4 | ) |
| Net cash provided by (used in) financing activities |  |  | 11,351 |  |  |  | (8,976 | ) |
| Effect of foreign currency exchange rate changes on cash, cash equivalents, restricted cash and restricted cash equivalents |  |  | (39 | ) |  |  | (90 | ) |
| Net (decrease) increase in cash, cash equivalents, restricted cash and restricted cash equivalents |  |  | (1,188 | ) |  |  | 967 |  |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, beginning of period |  |  | 11,627 |  |  |  | 8,579 |  |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, end of period |  | $ | 10,439 |  |  | $ | 9,546 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 350 |  |  | $ | 306 |  |
| Cash paid for income taxes, net |  | $ | 7,150 |  |  | $ | 2,414 |  |

[0001193125-24-139371:8k_2_02:114]
8

[0001193125-24-139371:8k_2_02:115]
CISCO SYSTEMS, INC.

[0001193125-24-139371:8k_2_02:116]
REMAINING PERFORMANCE OBLIGATIONS

[0001193125-24-139371:8k_2_02:117]
(In millions, except percentages)

[0001193125-24-139371:8k_2_02:118]
|  |  | April 27, 2024 |  |  | January 27, 2024 |  |  | April 29, 2023 |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Product |  | $ | 18,876 |  |  |  | 29 | % |  | $ | 16,249 |  |  |  | 12 | % |  | $ | 14,681 |  |  |  | 9 | % |
| Service |  |  | 19,898 |  |  |  | 14 | % |  |  | 19,407 |  |  |  | 12 | % |  |  | 17,401 |  |  |  | 4 | % |
| Total |  | $ | 38,774 |  |  |  | 21 | % |  | $ | 35,656 |  |  |  | 12 | % |  | $ | 32,082 |  |  |  | 6 | % |

[0001193125-24-139371:8k_2_02:119]
We expect 52% of total RPO at April 27, 2024 will be recognized as revenue over the next 12 months.

[0001193125-24-139371:8k_2_02:120]
CISCO SYSTEMS, INC.

[0001193125-24-139371:8k_2_02:121]
DEFERRED REVENUE

[0001193125-24-139371:8k_2_02:122]
(In
millions)

[0001193125-24-139371:8k_2_02:123]
|  |  | April 27,2024 |  |  | January 27,2024 |  |  | April 29,2023 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 12,856 |  |  | $ | 11,640 |  |  | $ | 10,895 |  |
| Service |  |  | 14,619 |  |  |  | 14,131 |  |  |  | 13,365 |  |
| Total |  | $ | 27,475 |  |  | $ | 25,771 |  |  | $ | 24,260 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 15,751 |  |  | $ | 14,011 |  |  | $ | 13,249 |  |
| Noncurrent |  |  | 11,724 |  |  |  | 11,760 |  |  |  | 11,011 |  |
| Total |  | $ | 27,475 |  |  | $ | 25,771 |  |  | $ | 24,260 |  |

[0001193125-24-139371:8k_2_02:124]
CISCO SYSTEMS, INC.

[0001193125-24-139371:8k_2_02:125]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-24-139371:8k_2_02:126]
(In millions, except per-share amounts)

[0001193125-24-139371:8k_2_02:127]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2024 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| April 27, 2024 |  | $ | 0.40 |  |  | $ | 1,615 |  |  |  | 26 |  |  | $ | 49.22 |  |  | $ | 1,256 |  |  | $ | 2,871 |  |
| January 27, 2024 |  | $ | 0.39 |  |  | $ | 1,583 |  |  |  | 25 |  |  | $ | 49.54 |  |  | $ | 1,254 |  |  | $ | 2,837 |  |
| October 28, 2023 |  | $ | 0.39 |  |  | $ | 1,580 |  |  |  | 23 |  |  | $ | 54.53 |  |  | $ | 1,252 |  |  | $ | 2,832 |  |
| Fiscal 2023 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 29, 2023 |  | $ | 0.39 |  |  | $ | 1,589 |  |  |  | 25 |  |  | $ | 50.49 |  |  | $ | 1,254 |  |  | $ | 2,843 |  |
| April 29, 2023 |  | $ | 0.39 |  |  | $ | 1,593 |  |  |  | 25 |  |  | $ | 49.45 |  |  | $ | 1,259 |  |  | $ | 2,852 |  |
| January 28, 2023 |  | $ | 0.38 |  |  | $ | 1,560 |  |  |  | 26 |  |  | $ | 47.72 |  |  | $ | 1,256 |  |  | $ | 2,816 |  |
| October 29, 2022 |  | $ | 0.38 |  |  | $ | 1,560 |  |  |  | 12 |  |  | $ | 43.76 |  |  | $ | 502 |  |  | $ | 2,062 |  |

[0001193125-24-139371:8k_2_02:128]
9

[0001193125-24-139371:8k_2_02:129]
CISCO SYSTEMS, INC.

[0001193125-24-139371:8k_2_02:130]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-24-139371:8k_2_02:131]
GAAP TO NON-GAAP NET INCOME

[0001193125-24-139371:8k_2_02:132]
(In millions)

[0001193125-24-139371:8k_2_02:133]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 27,2024 |  |  | April 29,2023 |  |  | April 27,2024 |  |  | April 29,2023 |  |
| GAAP net income |  | $ | 1,886 |  |  | $ | 3,212 |  |  | $ | 8,158 |  |  | $ | 8,655 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 139 |  |  |  | 106 |  |  |  | 381 |  |  |  | 293 |  |
| Amortization of acquisition-related intangible assets |  |  | 249 |  |  |  | 156 |  |  |  | 605 |  |  |  | 462 |  |
| Acquisition-related/divestiture costs |  |  | 12 |  |  |  | 1 |  |  |  | 13 |  |  |  | 4 |  |
| Total adjustments to GAAP cost of sales |  |  | 400 |  |  |  | 263 |  |  |  | 999 |  |  |  | 759 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 665 |  |  |  | 518 |  |  |  | 1,877 |  |  |  | 1,431 |  |
| Amortization of acquisition-related intangible assets |  |  | 297 |  |  |  | 70 |  |  |  | 430 |  |  |  | 212 |  |
| Acquisition-related/divestiture costs |  |  | 264 |  |  |  | 55 |  |  |  | 403 |  |  |  | 178 |  |
| Russia-Ukraine war costs |  |  | (10 | ) |  |  | 2 |  |  |  | (12 | ) |  |  | 7 |  |
| Significant asset impairments and restructurings |  |  | 542 |  |  |  | 87 |  |  |  | 677 |  |  |  | 328 |  |
| Total adjustments to GAAP operating expenses |  |  | 1,758 |  |  |  | 732 |  |  |  | 3,375 |  |  |  | 2,156 |  |
| Adjustments to interest and other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Gains) and losses on investments |  |  | (7 | ) |  |  | 123 |  |  |  | 132 |  |  |  | 188 |  |
| Total adjustments to GAAP interest and other income (loss), net |  |  | (7 | ) |  |  | 123 |  |  |  | 132 |  |  |  | 188 |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 2,151 |  |  |  | 1,118 |  |  |  | 4,506 |  |  |  | 3,103 |  |
| Income tax effect of non-GAAP adjustments |  |  | (484 | ) |  |  | (219 | ) |  |  | (1,045 | ) |  |  | (623 | ) |
| Significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 164 |  |
| Total adjustments to GAAP provision for income taxes |  |  | (484 | ) |  |  | (219 | ) |  |  | (1,045 | ) |  |  | (459 | ) |
| Non-GAAP net income |  | $ | 3,553 |  |  | $ | 4,111 |  |  | $ | 11,619 |  |  | $ | 11,299 |  |

[0001193125-24-139371:8k_2_02:134]
10

[0001193125-24-139371:8k_2_02:135]
CISCO SYSTEMS, INC.

[0001193125-24-139371:8k_2_02:136]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-24-139371:8k_2_02:137]
GAAP TO NON-GAAP EPS

[0001193125-24-139371:8k_2_02:138]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 27,2024 |  |  | April 29,2023 |  |  | April 27,2024 |  |  | April 29,2023 |  |
| GAAP EPS |  | $ | 0.46 |  |  | $ | 0.78 |  |  | $ | 2.00 |  |  | $ | 2.11 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.20 |  |  |  | 0.15 |  |  |  | 0.55 |  |  |  | 0.42 |  |
| Amortization of acquisition-related intangible assets |  |  | 0.13 |  |  |  | 0.06 |  |  |  | 0.25 |  |  |  | 0.16 |  |
| Acquisition-related/divestiture costs |  |  | 0.07 |  |  |  | 0.01 |  |  |  | 0.10 |  |  |  | 0.04 |  |
| Significant asset impairments and restructurings |  |  | 0.13 |  |  |  | 0.02 |  |  |  | 0.17 |  |  |  | 0.08 |  |
| (Gains) and losses on investments |  |  | — |  |  |  | 0.03 |  |  |  | 0.03 |  |  |  | 0.05 |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.12 | ) |  |  | (0.05 | ) |  |  | (0.26 | ) |  |  | (0.15 | ) |
| Significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.04 |  |
| Non-GAAP EPS |  | $ | 0.88 |  |  | $ | 1.00 |  |  | $ | 2.85 |  |  | $ | 2.75 |  |

[0001193125-24-139371:8k_2_02:139]
Amounts may not sum due to rounding.

[0001193125-24-139371:8k_2_02:140]
CISCO SYSTEMS, INC.

[0001193125-24-139371:8k_2_02:141]
GAAP TO NON-GAAP EPS

[0001193125-24-139371:8k_2_02:142]
IMPACT OF SPLUNK ACQUISITION, INCLUDING FINANCING COSTS

[0001193125-24-139371:8k_2_02:143]
|  |  | Three Months Ended |  |
|  |  | April 27, 2024 |  |
| GAAP EPS Impact |  | $ | (0.09 | ) |
| Amortization of intangible assets |  |  | 0.05 |  |
| Acquisition-related costs |  |  | 0.05 |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.02 | ) |
| Non-GAAP EPS Impact |  | $ | (0.01 | ) |

[0001193125-24-139371:8k_2_02:144]
Amounts may not sum due to rounding.

[0001193125-24-139371:8k_2_02:145]
11

[0001193125-24-139371:8k_2_02:146]
CISCO SYSTEMS, INC.

[0001193125-24-139371:8k_2_02:147]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-24-139371:8k_2_02:148]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET,

[0001193125-24-139371:8k_2_02:149]
AND NET INCOME

[0001193125-24-139371:8k_2_02:150]
(In
millions, except percentages)

[0001193125-24-139371:8k_2_02:151]
|  |  | Three Months Ended |  |
|  |  | April 27, 2024 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,729 |  |  | $ | 2,544 |  |  | $ | 8,273 |  |  | $ | 6,082 |  |  |  | 15 | % |  | $ | 2,191 |  |  |  | (44 | )% |  | $ | 44 |  |  | $ | 1,886 |  |  |  | (41 | )% |
| % of revenue |  |  | 63.5 | % |  |  | 69.2 | % |  |  | 65.1 | % |  |  | 47.9 | % |  |  |  |  |  |  | 17.2 | % |  |  |  |  |  |  | 0.3 | % |  |  | 14.8 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 57 |  |  |  | 82 |  |  |  | 139 |  |  |  | 665 |  |  |  |  |  |  |  | 804 |  |  |  |  |  |  |  | — |  |  |  | 804 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 249 |  |  |  | — |  |  |  | 249 |  |  |  | 297 |  |  |  |  |  |  |  | 546 |  |  |  |  |  |  |  | — |  |  |  | 546 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 4 |  |  |  | 8 |  |  |  | 12 |  |  |  | 264 |  |  |  |  |  |  |  | 276 |  |  |  |  |  |  |  | — |  |  |  | 276 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 542 |  |  |  |  |  |  |  | 542 |  |  |  |  |  |  |  | — |  |  |  | 542 |  |  |  |  |  |
| Russia-Ukraine war costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (10 | ) |  |  |  |  |  |  | (10 | ) |  |  |  |  |  |  | — |  |  |  | (10 | ) |  |  |  |  |
| (Gains) and losses on investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (7 | ) |  |  | (7 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (484 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 6,039 |  |  | $ | 2,634 |  |  | $ | 8,673 |  |  | $ | 4,324 |  |  |  | (5 | )% |  | $ | 4,349 |  |  |  | (12 | )% |  | $ | 37 |  |  | $ | 3,553 |  |  |  | (14 | )% |
| % of revenue |  |  | 66.9 | % |  |  | 71.6 | % |  |  | 68.3 | % |  |  | 34.0 | % |  |  |  |  |  |  | 34.2 | % |  |  |  |  |  |  | 0.3 | % |  |  | 28.0 | % |  |  |  |  |

[0001193125-24-139371:8k_2_02:152]
|  |  | Three Months Ended |  |
|  |  | April 29, 2023 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 6,956 |  |  | $ | 2,276 |  |  | $ | 9,232 |  |  | $ | 5,286 |  |  | $ | 3,946 |  |  | $ | 11 |  |  | $ | 3,212 |  |
| % of revenue |  |  | 62.7 | % |  |  | 65.4 | % |  |  | 63.4 | % |  |  | 36.3 | % |  |  | 27.1 | % |  |  | 0.1 | % |  |  | 22.0 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 40 |  |  |  | 66 |  |  |  | 106 |  |  |  | 518 |  |  |  | 624 |  |  |  | — |  |  |  | 624 |  |
| Amortization of acquisition-related intangible assets |  |  | 156 |  |  |  | — |  |  |  | 156 |  |  |  | 70 |  |  |  | 226 |  |  |  | — |  |  |  | 226 |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 55 |  |  |  | 56 |  |  |  | — |  |  |  | 56 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 87 |  |  |  | 87 |  |  |  | — |  |  |  | 87 |  |
| Russia-Ukraine war costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | 2 |  |  |  | — |  |  |  | 2 |  |
| (Gains) and losses on investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 123 |  |  |  | 123 |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (219 | ) |
| Non-GAAP amount |  | $ | 7,153 |  |  | $ | 2,342 |  |  | $ | 9,495 |  |  | $ | 4,554 |  |  | $ | 4,941 |  |  | $ | 134 |  |  | $ | 4,111 |  |
| % of revenue |  |  | 64.5 | % |  |  | 67.3 | % |  |  | 65.2 | % |  |  | 31.3 | % |  |  | 33.9 | % |  |  | 0.9 | % |  |  | 28.2 | % |

[0001193125-24-139371:8k_2_02:153]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-24-139371:8k_2_02:154]
12

[0001193125-24-139371:8k_2_02:155]
CISCO SYSTEMS, INC.

[0001193125-24-139371:8k_2_02:156]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-24-139371:8k_2_02:157]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET,

[0001193125-24-139371:8k_2_02:158]
AND NET INCOME

[0001193125-24-139371:8k_2_02:159]
(In
millions, except percentages)

[0001193125-24-139371:8k_2_02:160]
|  |  | Nine Months Ended |  |
|  |  | April 27, 2024 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 18,700 |  |  | $ | 7,347 |  |  | $ | 26,047 |  |  | $ | 16,484 |  |  |  | 8 | % |  | $ | 9,563 |  |  |  | (11 | )% |  | $ | 275 |  |  | $ | 8,158 |  |  |  | (6 | )% |
| % of revenue |  |  | 63.6 | % |  |  | 68.2 | % |  |  | 64.9 | % |  |  | 41.0 | % |  |  |  |  |  |  | 23.8 | % |  |  |  |  |  |  | 0.7 | % |  |  | 20.3 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 157 |  |  |  | 224 |  |  |  | 381 |  |  |  | 1,877 |  |  |  |  |  |  |  | 2,258 |  |  |  |  |  |  |  | — |  |  |  | 2,258 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 605 |  |  |  | — |  |  |  | 605 |  |  |  | 430 |  |  |  |  |  |  |  | 1,035 |  |  |  |  |  |  |  | — |  |  |  | 1,035 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 5 |  |  |  | 8 |  |  |  | 13 |  |  |  | 403 |  |  |  |  |  |  |  | 416 |  |  |  |  |  |  |  | — |  |  |  | 416 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 677 |  |  |  |  |  |  |  | 677 |  |  |  |  |  |  |  | — |  |  |  | 677 |  |  |  |  |  |
| Russia-Ukraine war costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (12 | ) |  |  |  |  |  |  | (12 | ) |  |  |  |  |  |  | — |  |  |  | (12 | ) |  |  |  |  |
| (Gains) and losses on investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 132 |  |  |  | 132 |  |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (1,045 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 19,467 |  |  | $ | 7,579 |  |  | $ | 27,046 |  |  | $ | 13,109 |  |  |  | — | % |  | $ | 13,937 |  |  |  | 2 | % |  | $ | 407 |  |  | $ | 11,619 |  |  |  | 3 | % |
| % of revenue |  |  | 66.2 | % |  |  | 70.4 | % |  |  | 67.3 | % |  |  | 32.6 | % |  |  |  |  |  |  | 34.7 | % |  |  |  |  |  |  | 1.0 | % |  |  | 28.9 | % |  |  |  |  |

[0001193125-24-139371:8k_2_02:161]
|  |  | Nine Months EndedApril 29, 2023 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 19,139 |  |  | $ | 6,866 |  |  | $ | 26,005 |  |  | $ | 15,227 |  |  | $ | 10,778 |  |  | $ | 69 |  |  | $ | 8,655 |  |
| % of revenue |  |  | 60.8 | % |  |  | 66.6 | % |  |  | 62.2 | % |  |  | 36.4 | % |  |  | 25.8 | % |  |  | 0.2 | % |  |  | 20.7 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 111 |  |  |  | 182 |  |  |  | 293 |  |  |  | 1,431 |  |  |  | 1,724 |  |  |  | — |  |  |  | 1,724 |  |
| Amortization of acquisition-related intangible assets |  |  | 462 |  |  |  | — |  |  |  | 462 |  |  |  | 212 |  |  |  | 674 |  |  |  | — |  |  |  | 674 |  |
| Acquisition/divestiture-related costs |  |  | 4 |  |  |  | — |  |  |  | 4 |  |  |  | 178 |  |  |  | 182 |  |  |  | — |  |  |  | 182 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 328 |  |  |  | 328 |  |  |  | — |  |  |  | 328 |  |
| Russia-Ukraine war costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 7 |  |  |  | 7 |  |  |  | — |  |  |  | 7 |  |
| (Gains) and losses on investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 188 |  |  |  | 188 |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (459 | ) |
| Non-GAAP amount |  | $ | 19,716 |  |  | $ | 7,048 |  |  | $ | 26,764 |  |  | $ | 13,071 |  |  | $ | 13,693 |  |  | $ | 257 |  |  | $ | 11,299 |  |
| % of revenue |  |  | 62.6 | % |  |  | 68.4 | % |  |  | 64.0 | % |  |  | 31.3 | % |  |  | 32.8 | % |  |  | 0.6 | % |  |  | 27.0 | % |

[0001193125-24-139371:8k_2_02:162]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-24-139371:8k_2_02:163]
13

[0001193125-24-139371:8k_2_02:164]
CISCO SYSTEMS, INC.

[0001193125-24-139371:8k_2_02:165]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-24-139371:8k_2_02:166]
EFFECTIVE TAX RATE

[0001193125-24-139371:8k_2_02:167]
(In
percentages)

[0001193125-24-139371:8k_2_02:168]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 27,2024 |  |  | April 29,2023 |  |  | April 27,2024 |  |  | April 29,2023 |  |
| GAAP effective tax rate |  |  | 15.6 | % |  |  | 18.8 | % |  |  | 17.1 | % |  |  | 20.2 | % |
| Total adjustments to GAAP provision for income taxes |  |  | 3.4 | % |  |  | 0.2 | % |  |  | 1.9 | % |  |  | (1.2 | )% |
| Non-GAAP effective tax rate |  |  | 19.0 | % |  |  | 19.0 | % |  |  | 19.0 | % |  |  | 19.0 | % |

[0001193125-24-139371:8k_2_02:169]
GAAP TO NON-GAAP GUIDANCE

[0001193125-24-139371:8k_2_02:170]
| Q4 FY 2024 |  | Gross MarginRate |  | Operating MarginRate |  | Earnings perShare (1) |
| GAAP |  | 63% – 64% |  | 18.5% –19.5% |  | $0.46 – $0.51 |
| Estimated adjustments for: |  |  |  |  |  |  |
| Share-based compensation expense |  | 1.0% |  | 6.0% |  | $0.15 – $0.16 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 2.5% |  | 6.5% |  | $0.19 – $0.20 |
| Significant asset impairments and restructurings |  | — |  | 0.5% |  | $0.01 – $0.02 |
| Non-GAAP |  | 66.5% – 67.5% |  | 31.5% –32.5% |  | $0.84 – $0.86 |

[0001193125-24-139371:8k_2_02:171]
| FY 2024 |  | Earnings perShare (1) |
| GAAP |  | $2.46 – $2.51 |
| Estimated adjustments for: |  |  |
| Share-based compensation expense |  | $0.58 – $0.59 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | $0.46 – $0.47 |
| Significant asset impairments and restructurings |  | $0.13 – $0.14 |
| (Gains) and losses on investments |  | $0.03 |
| Non-GAAP |  | $3.69 – $3.71 |

[0001193125-24-139371:8k_2_02:172]
| (1) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-24-139371:8k_2_02:173]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, Russia-Ukraine war costs,
restructurings, (gains) and losses on investments and significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-24-139371:8k_2_02:174]
14

[0001193125-24-139371:8k_2_02:175]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-24-139371:8k_2_02:176]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating
income and margin, non-GAAP effective tax rates, non-GAAP interest and other income (loss), net, and non-GAAP net income per
share data for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-24-139371:8k_2_02:177]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with
generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any
comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as
determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-24-139371:8k_2_02:178]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP
measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-24-139371:8k_2_02:179]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other contingencies, Russia-Ukraine war costs, gains and losses on
investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing
the financial

[0001193125-24-139371:8k_2_02:180]
15

[0001193125-24-139371:8k_2_02:181]
results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to
time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-24-139371:8k_2_02:182]
Annualized recurring revenue represents the annualized revenue run-rate of active subscriptions, term licenses,
operating leases and maintenance contracts at the end of a reporting period, net of rebates to customers and partners as well as certain other revenue adjustments. Includes both revenue recognized ratably as well as upfront on an annualized basis.

[0001193125-24-139371:8k_2_02:183]
About Cisco

[0001193125-24-139371:8k_2_02:184]
Cisco (Nasdaq: CSCO) is the worldwide
technology leader that securely connects everything to make anything possible. Our purpose is to power an inclusive future for all by helping our customers reimagine their applications, power hybrid work, secure their enterprise, transform their
infrastructure, and meet their sustainability goals. Discover more at newsroom.cisco.com and follow us on X at @Cisco.

[0001193125-24-139371:8k_2_02:185]
Copyright © 2024 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a
list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any
other company. This document is Cisco Public Information.

[0001193125-24-139371:8k_2_02:186]
RSS Feed for
Cisco: https://newsroom.cisco.com/rss-feeds

[0001193125-24-139371:8k_2_02:187]
16

## item 5.02 — body, verbatim

[0001193125-24-139371:8k_body:1]
Item 5.02.

[0001193125-24-139371:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001193125-24-139371:8k_body:3]
Appointment of Certain Officer; Departure of Certain Officer

[0001193125-24-139371:8k_body:4]
Effective May 15, 2024, as part of organizational changes with respect to Cisco’s executive leadership team, Cisco appointed Gary Steele as President, Go-to-Market. As part of Mr. Steele’s new role, he will assume responsibility for Cisco’s global sales, partner, and marketing operations. In connection with Mr. Steele’s appointment, on May 12, 2024, Jeff Sharritts, Cisco’s Executive Vice President and Chief Customer and Partner Officer, was informed that he would no longer remain in his role as Cisco’s Executive Vice President and Chief Customer and Partner Officer, effective May 15, 2024. Mr. Sharritts will remain employed by Cisco until July 15, 2024.

[0001193125-24-139371:8k_body:5]
Mr. Steele, 61, joined Cisco in March 2024 as Cisco’s Executive Vice President and General Manager, Splunk, upon the close of Cisco’s acquisition of Splunk Inc. (“Splunk”). Prior to Cisco, Mr. Steele served as Splunk’s President, Chief Executive Officer, and a member of Splunk’s board of directors, from 2022 until 2024. Prior to joining Splunk, Mr. Steele served as Chief Executive Officer and a member of the board of directors of Proofpoint, Inc. (“Proofpoint”), from 2002 to 2022, and served as the Chair of the board of directors of Proofpoint from 2018 to 2021. From 1997 to 2002, Mr. Steele served as Chief Executive Officer of Portera Systems Inc. (“Portera”). Before Portera, Mr. Steele served as the Vice President and General Manager of the Middleware and Data Warehousing Product Group at Sybase, Inc. Mr. Steele also served in business development, marketing, and engineering roles at Sun Microsystems, Inc. and Hewlett-Packard Company. Since 2018, Mr. Steele has served as a member of the board of directors of Upwork Inc. Mr. Steele previously served as a member of the board of directors of Vonage Holdings Corp., from 2016 to 2021.

[0001193125-24-139371:8k_body:6]
Compensatory Arrangements of Certain Officer

[0001193125-24-139371:8k_body:7]
In connection with his appointment, on May 15, 2024, Mr. Steele entered into a letter agreement with Cisco (the “Letter Agreement”), providing for an annual base salary of $1 million; the ability to participate in Cisco’s Executive Incentive Plan following Mr. Steele’s onboarding with Cisco, which is currently expected to occur in the fourth quarter of Cisco’s fiscal year 2024, with a bonus target equal to 160% of his annual base salary (“Target Annual Bonus”); management’s recommendation to the Compensation and Management Development Committee of Cisco’s Board of Directors that Mr. Steele be approved for a fiscal year 2025 equity award with an approximate grant date fair value of $18 million and a transformational performance-based equity award for fiscal year 2025 with an approximate grant date fair value of $2.5 million; and Cisco’s payment or reimbursement of Mr. Steele’s reasonable legal fees incurred in connection with the Letter Agreement. The Letter Agreement supersedes all prior agreements between Mr. Steele and Cisco, except for the Retention Bonus (as defined below).

[0001193125-24-139371:8k_body:8]
The Letter Agreement further provides that Mr. Steele will remain entitled to the change in control severance protections under Mr. Steele’s employment agreement with Splunk, which provide that, upon a Good Leaver Termination during the period beginning on Mr. Steele’s start date and ending on the 18-month anniversary of the closing date (March 18, 2024) of Cisco’s acquisition of Splunk (the “Closing Date”), Mr. Steele will receive a lump sum cash amount equal to (a) the sum of (i) 24 months of Mr. Steele’s monthly annual salary plus (ii) two times 160% of Mr. Steele’s annual salary plus (iii) a pro-rated Target Annual Bonus (as defined in the Letter Agreement), less applicable deductions, as cash severance; and (b) the premiums required to continue Mr. Steele’s group health care coverage for a period of 18 months. A “Good Leaver Termination” occurs if (a) Cisco terminates Mr. Steele’s employment without “Cause” (as defined in the Letter Agreement); (b) Mr. Steele resigns with “Good Reason” (as

[0001193125-24-139371:8k_body:9]
defined in the Letter Agreement); (c) in the event of Mr. Steele’s death or “Permanent Disability” (as defined in the Letter Agreement); or (d) Mr. Steele voluntarily terminates his active employment effective following the first anniversary of the Closing Date (provided Mr. Steele provides at least 90 days written notice prior to ceasing active employment with Cisco).

[0001193125-24-139371:8k_body:10]
In connection with Cisco’s acquisition of Splunk, Mr. Steele was granted a cash retention bonus in the amount of $15 million (the “Retention Bonus”), which vests one-third on the 12-month anniversary of the Closing Date and then the remaining two-thirds in equal quarterly installments over the immediately following 24 months, subject to Mr. Steele’s continued employment with Cisco. In addition, in connection with Cisco’s acquisition of Splunk, Mr. Steele’s unvested equity awards in Splunk were converted to cash awards (the “Unvested Cash Awards”). The Unvested Cash Awards vest on the same vesting schedule as the corresponding Splunk equity award, subject to Mr. Steele’s continued employment with Cisco, provided that, pursuant to the Letter Agreement, the Unvested Cash Awards other than the award granted on February 27, 2024, will vest on March 18, 2025 or, if earlier, the date of Mr. Steele’s Good Leaver Termination.

[0001193125-24-139371:8k_body:11]
The foregoing description of the Letter Agreement and the Retention Bonus are qualified in their entirety by reference to the Letter Agreement, a copy of which is filed herewith as Exhibit 10.1, and the Retention Bonus agreement, a copy of which is attached as Exhibit A to the Letter Agreement.

[0001193125-24-139371:8k_body:12]
In connection with his appointment, Mr. Steele has entered into a standard form of Indemnity Agreement with Cisco which provides for indemnification of an indemnitee to the fullest extent permitted by law. The foregoing description of the Indemnity Agreement does not purport to be complete and is qualified in its entirety by the full text of the form of Indemnity Agreement, which was filed with the Securities and Exchange Commission on January 25, 2021 as Exhibit 10.1 to Cisco’s Current Report on Form 8-K.
