# CSCO 8-K — 0001193125-17-344129 filed 2017-11-15

## item codes, every 8-K on or before 2017-11-21

- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2017-11-21

- none on or before 2017-11-21

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-344129:8k_2_02:1]
EX-99.1
2
d471971dex991.htm
EXHIBIT 99.1

[0001193125-17-344129:8k_2_02:2]
Exhibit 99.1

[0001193125-17-344129:8k_2_02:3]
Exhibit 99.1

[0001193125-17-344129:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Andrea Duffy |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (646) 295-5241 |  |  |  | 1 (408) 527-7452 |
| anduffy@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-17-344129:8k_2_02:5]
CISCO REPORTS FIRST QUARTER EARNINGS

[0001193125-17-344129:8k_2_02:6]
|  | • |  | Q1 Revenue: $12.1 billion |

[0001193125-17-344129:8k_2_02:7]
|  | • |  | Decrease of (2)% year over year |

[0001193125-17-344129:8k_2_02:8]
|  | • |  | Recurring revenue was 32% of total revenue, up over 3 points year over year |

[0001193125-17-344129:8k_2_02:9]
|  | • |  | Q1 Earnings per Share: $0.48 GAAP; $0.61 non-GAAP |

[0001193125-17-344129:8k_2_02:10]
|  | • |  | Q2 FY 2018 Outlook: |

[0001193125-17-344129:8k_2_02:11]
|  | • |  | Revenue: 1% to 3% growth year over year |

[0001193125-17-344129:8k_2_02:12]
|  | • |  | Earnings per Share: GAAP $0.46 to $0.51; Non-GAAP: $0.58 to $0.60 |

[0001193125-17-344129:8k_2_02:13]
SAN JOSE, Calif. — November 15, 2017 — Cisco today reported first quarter results for the period ended October 28, 2017. Cisco reported
first quarter revenue of $12.1 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.4 billion or $0.48 per share, and non-GAAP net income of $3.0 billion or $0.61
per share.

[0001193125-17-344129:8k_2_02:14]
“Our results in Q1 demonstrate the continued progress we’re making on our strategy,” said Chuck Robbins, CEO of Cisco.
“The network has never been more critical to business success. Cisco is delivering more insights and intelligence as we help our customers build highly secure, intelligent platforms for digital business.”

[0001193125-17-344129:8k_2_02:15]
GAAP Results

[0001193125-17-344129:8k_2_02:16]
|  |  | Q1 FY 2018 |  |  | Q1 FY 2017 |  |  | Vs. Q1 FY 2017 |  |
| Revenue |  | $ | 12.1 billion |  |  | $ | 12.4 billion |  |  |  | (2 | )% |
| Net Income |  | $ | 2.4 billion |  |  | $ | 2.3 billion |  |  |  | 3 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.48 |  |  | $ | 0.46 |  |  |  | 4 | % |

[0001193125-17-344129:8k_2_02:17]
Non-GAAP Results

[0001193125-17-344129:8k_2_02:18]
|  |  | Q1 FY 2018 |  |  | Q1 FY 2017 |  |  | Vs. Q1 FY 2017 |  |
| Net Income |  | $ | 3.0 billion |  |  | $ | 3.1 billion |  |  |  | (2 | )% |
| EPS |  | $ | 0.61 |  |  | $ | 0.61 |  |  |  | — | % |

[0001193125-17-344129:8k_2_02:19]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-17-344129:8k_2_02:20]
“We delivered a solid Q1 and executed well as we focus on strategic priorities and maintaining rigorous discipline on profitability and cash
generation,” said Kelly Kramer, CFO of Cisco. “We delivered strong growth in operating and free cash flow, focused investments on long term profitable growth, and returned $3.1 billion to shareholders through repurchases and quarterly
dividends.”

[0001193125-17-344129:8k_2_02:21]
1

[0001193125-17-344129:8k_2_02:22]
Financial Summary

[0001193125-17-344129:8k_2_02:23]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-17-344129:8k_2_02:24]
Q1 FY 2018 Highlights

[0001193125-17-344129:8k_2_02:25]
Revenue — Total
revenue was $12.1 billion, down 2%, with product revenue down 3% and service revenue up 1%. 32% of total revenue was from recurring offers, up over 3 percentage points from the first quarter of fiscal 2017. Revenue by geographic segment was:
Americas down 1%, EMEA down 3%, and APJC down 1%. Product revenue performance was led by Security and Applications, which increased by 8% and 6%, respectively. Infrastructure Platforms revenue decreased by 4%.

[0001193125-17-344129:8k_2_02:26]
Gross Margin — On a GAAP basis, total gross margin and product gross margin were 61.2% and 60.1%, respectively. The decrease in the
product gross margin compared with 63.4% in the first quarter of fiscal 2017 was primarily due to pricing, legal and indemnification settlements, and lower productivity benefits.

[0001193125-17-344129:8k_2_02:27]
Non-GAAP total gross margin and product gross margin were 63.7% and 63.0%, respectively. The decrease in non-GAAP product gross margin compared with 64.8% in the first quarter of fiscal 2017 was primarily due to pricing and lower productivity benefits. While productivity was positive, the benefit was lower than in the
prior year as productivity improvements continued to be adversely impacted by an increase in the cost of certain memory components, consistent with our expectations.

[0001193125-17-344129:8k_2_02:28]
GAAP service gross margin was 64.5% and non-GAAP service gross margin was 65.6%.

[0001193125-17-344129:8k_2_02:29]
Total gross margins by geographic segment were: 64.2% for the Americas, 63.2% for EMEA and 62.1% for APJC.

[0001193125-17-344129:8k_2_02:30]
Operating Expenses — On a GAAP basis, operating expenses were $4.7 billion, down 7%.
Non-GAAP operating expenses were $4.0 billion, down 3%, and were 33.3% of revenue.

[0001193125-17-344129:8k_2_02:31]
Operating Income
— GAAP operating income was $2.8 billion, down 4%, with GAAP operating margin of 22.7%. Non-GAAP operating income was $3.7 billion, down 5%, with
non-GAAP operating margin of 30.4%.

[0001193125-17-344129:8k_2_02:32]
Provision for Income Taxes — The GAAP tax provision rate
was 19.2%. The non-GAAP tax provision rate was 22.0%.

[0001193125-17-344129:8k_2_02:33]
Net Income and EPS — On a GAAP basis,
net income was $2.4 billion and EPS was $0.48. On a non-GAAP basis, net income was $3.0 billion, a decrease of 2%, and EPS was flat at $0.61.

[0001193125-17-344129:8k_2_02:34]
Cash Flow from Operating Activities — was $3.1 billion, an increase of 13% compared with $2.7 billion for the first quarter of
fiscal 2017.

[0001193125-17-344129:8k_2_02:35]
Balance Sheet and Other Financial Highlights

[0001193125-17-344129:8k_2_02:36]
Cash and Cash Equivalents and Investments — were $71.6 billion at the end of the first quarter of fiscal 2018, compared with
$70.5 billion at the end of fiscal 2017. The total cash and cash equivalents and investments available in the United States at the end of the first quarter of fiscal 2018 were $2.5 billion.

[0001193125-17-344129:8k_2_02:37]
Deferred Revenue — was $18.6 billion, up 10% in total, with deferred product revenue up 16%, driven largely by subscription-based and
software offers, and deferred service revenue was up 5%. The portion of product deferred revenue related to recurring software and subscription offers increased 37%.

[0001193125-17-344129:8k_2_02:38]
Capital Allocation — In the first quarter of fiscal 2018, Cisco declared and paid a cash dividend of $0.29 per common share, or
$1.4 billion. For the first quarter of fiscal 2018, Cisco repurchased approximately 51 million shares of common stock under its stock repurchase program at an average price of $31.80 per share for an aggregate purchase price of
$1.6 billion.

[0001193125-17-344129:8k_2_02:39]
As of October 28, 2017, Cisco had repurchased and retired 4.8 billion shares of Cisco common stock at an average price of
$21.41 per share for an aggregate purchase price of approximately $101.9 billion since the inception of the stock repurchase program. The remaining authorized amount for stock repurchases under this program is approximately $10.1 billion
with no termination date.

[0001193125-17-344129:8k_2_02:40]
2

[0001193125-17-344129:8k_2_02:41]
Acquisitions

[0001193125-17-344129:8k_2_02:42]
In the first quarter of fiscal 2018, we announced the acquisitions of privately held Springpath, Inc. and privately held Perspica, Inc. The Springpath
acquisition is designed to enhance our ability to deliver next-generation data center innovation to customers through hyperconvergence software. The Springpath acquisition closed in the first quarter of fiscal 2018. The Perspica acquisition provides
machine learning and data processing technology which enables customers to analyze large amounts of application-related data, in real-time and with business context. The Perspica acquisition closed in the second quarter of fiscal 2018.

[0001193125-17-344129:8k_2_02:43]
We also closed our acquisitions of Viptela, Inc., a privately held company that provides software-defined wide area networking products, and Observable
Networks, Inc., a privately held company that offers cloud-native network forensics security applications delivered as a service.

[0001193125-17-344129:8k_2_02:44]
On October 23,
2017, we announced a definitive agreement to acquire BroadSoft, Inc., a publicly held company that offers cloud calling and contact center solutions. The acquisition is expected to close after completion of customary regulatory reviews.

[0001193125-17-344129:8k_2_02:45]
Business Outlook for Q2 FY 2018

[0001193125-17-344129:8k_2_02:46]
Cisco expects to achieve
the following results for the second quarter of fiscal 2018:

[0001193125-17-344129:8k_2_02:47]
| Q2 FY 2018 |  |  |
| Revenue |  | 1% to 3% growth Y/Y |
| Non-GAAP gross margin rate |  | 62.5% - 63.5% |
| Non-GAAP operating margin rate |  | 29.5% - 30.5% |
| Non-GAAP tax provision rate |  | 22% |
| Non-GAAP EPS |  | $0.58 - $0.60 |

[0001193125-17-344129:8k_2_02:48]
Our Q2 FY2018 business outlook does not reflect any impact from the pending acquisition of BroadSoft.

[0001193125-17-344129:8k_2_02:49]
Cisco estimates that GAAP EPS will be $0.46 to $0.51 in the second quarter of fiscal 2018.

[0001193125-17-344129:8k_2_02:50]
A reconciliation between the Business Outlook for Q2 FY 2018 on a GAAP and non-GAAP basis is provided in the table
entitled “GAAP to non-GAAP Business Outlook for Q2 FY 2018” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-17-344129:8k_2_02:51]
Editor’s Notes:

[0001193125-17-344129:8k_2_02:52]
|  | • |  | Q1 fiscal year 2018 conference call to discuss Cisco’s results along with its business outlook will be held on Wednesday, November 15, 2017 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-17-344129:8k_2_02:53]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, November 15, 2017 to 4:00 p.m. Pacific Time, November 22, 2017 at 1-866-421-0447 (United States) or 1-203-369-0803 (international). The replay will also be available via webcast on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-17-344129:8k_2_02:54]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, November 15, 2017. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-17-344129:8k_2_02:55]
3

[0001193125-17-344129:8k_2_02:56]
CISCO SYSTEMS, INC.

[0001193125-17-344129:8k_2_02:57]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-17-344129:8k_2_02:58]
(In millions, except per-share amounts)

[0001193125-17-344129:8k_2_02:59]
(Unaudited)

[0001193125-17-344129:8k_2_02:60]
|  |  | Three Months Ended |  |
|  |  | October 28,2017 |  |  | October 29,2016 |  |
| REVENUE: |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,054 |  |  | $ | 9,302 |  |
| Service |  |  | 3,082 |  |  |  | 3,050 |  |
| Total revenue |  |  | 12,136 |  |  |  | 12,352 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |
| Product |  |  | 3,615 |  |  |  | 3,403 |  |
| Service |  |  | 1,094 |  |  |  | 1,065 |  |
| Total cost of sales |  |  | 4,709 |  |  |  | 4,468 |  |
| GROSS MARGIN |  |  | 7,427 |  |  |  | 7,884 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,567 |  |  |  | 1,545 |  |
| Sales and marketing |  |  | 2,334 |  |  |  | 2,418 |  |
| General and administrative |  |  | 557 |  |  |  | 555 |  |
| Amortization of purchased intangible assets |  |  | 61 |  |  |  | 78 |  |
| Restructuring and other charges |  |  | 152 |  |  |  | 411 |  |
| Total operating expenses |  |  | 4,671 |  |  |  | 5,007 |  |
| OPERATING INCOME |  |  | 2,756 |  |  |  | 2,877 |  |
| Interest income |  |  | 379 |  |  |  | 295 |  |
| Interest expense |  |  | (235 | ) |  |  | (198 | ) |
| Other income (loss), net |  |  | 62 |  |  |  | (21 | ) |
| Interest and other income (loss), net |  |  | 206 |  |  |  | 76 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 2,962 |  |  |  | 2,953 |  |
| Provision for income taxes |  |  | 568 |  |  |  | 631 |  |
| NET INCOME |  | $ | 2,394 |  |  | $ | 2,322 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.48 |  |  | $ | 0.46 |  |
| Diluted |  | $ | 0.48 |  |  | $ | 0.46 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,959 |  |  |  | 5,027 |  |
| Diluted |  |  | 4,994 |  |  |  | 5,066 |  |
| Cash dividends declared per common share |  | $ | 0.29 |  |  | $ | 0.26 |  |

[0001193125-17-344129:8k_2_02:61]
4

[0001193125-17-344129:8k_2_02:62]
CISCO SYSTEMS, INC.

[0001193125-17-344129:8k_2_02:63]
REVENUE BY SEGMENT

[0001193125-17-344129:8k_2_02:64]
(In
millions, except percentages)

[0001193125-17-344129:8k_2_02:65]
|  |  | Three Months EndedOctober 28, 2017 |  |
|  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,350 |  |  |  | (1 | )% |
| EMEA |  |  | 2,909 |  |  |  | (3 | )% |
| APJC |  |  | 1,877 |  |  |  | (1 | )% |
| Total |  | $ | 12,136 |  |  |  | (2 | )% |

[0001193125-17-344129:8k_2_02:66]
CISCO SYSTEMS, INC.

[0001193125-17-344129:8k_2_02:67]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-17-344129:8k_2_02:68]
(In percentages)

[0001193125-17-344129:8k_2_02:69]
|  |  | Three Months EndedOctober 28, 2017 |  |
| Gross Margin Percentage: |  |  |  |  |
| Americas |  |  | 64.2 | % |
| EMEA |  |  | 63.2 | % |
| APJC |  |  | 62.1 | % |

[0001193125-17-344129:8k_2_02:70]
CISCO SYSTEMS, INC.

[0001193125-17-344129:8k_2_02:71]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-17-344129:8k_2_02:72]
(In millions, except percentages)

[0001193125-17-344129:8k_2_02:73]
|  |  | Three Months EndedOctober 28, 2017 |  |
|  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 6,970 |  |  |  | (4 | )% |
| Applications |  |  | 1,203 |  |  |  | 6 | % |
| Security |  |  | 585 |  |  |  | 8 | % |
| Other Products |  |  | 296 |  |  |  | (16 | )% |
| Total Product |  |  | 9,054 |  |  |  | (3 | )% |
| Services |  |  | 3,082 |  |  |  | 1 | % |
| Total |  | $ | 12,136 |  |  |  | (2 | )% |

[0001193125-17-344129:8k_2_02:74]
Effective Q1 FY 2018, we began reporting our product and service revenue in the following five categories: Infrastructure
Platforms, Applications, Security, Other Products and Services. The change better aligns our product categories with our evolving business model. Our segments will continue to be based on geographies which consist of the Americas, EMEA, and APJC.
This change only impacts how we report revenue by product category. The reclassified product category revenue by quarter is available on Cisco’s Investor Relations website at
investor.cisco.com/investor-relations/financial-information/Financial-Results/default.aspx.

[0001193125-17-344129:8k_2_02:75]
6

[0001193125-17-344129:8k_2_02:76]
CISCO SYSTEMS, INC.

[0001193125-17-344129:8k_2_02:77]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-17-344129:8k_2_02:78]
(In millions)

[0001193125-17-344129:8k_2_02:79]
(Unaudited)

[0001193125-17-344129:8k_2_02:80]
|  |  | October 28, 2017 |  |  | July 29, 2017 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 11,043 |  |  | $ | 11,708 |  |
| Investments |  |  | 60,545 |  |  |  | 58,784 |  |
| Accounts receivable, net of allowance for doubtful accounts of $193 at October 28, 2017 and $211 at July 29, 2017 |  |  | 4,206 |  |  |  | 5,146 |  |
| Inventories |  |  | 1,693 |  |  |  | 1,616 |  |
| Financing receivables, net |  |  | 5,038 |  |  |  | 4,856 |  |
| Other current assets |  |  | 1,555 |  |  |  | 1,593 |  |
| Total current assets |  |  | 84,080 |  |  |  | 83,703 |  |
| Property and equipment, net |  |  | 3,202 |  |  |  | 3,322 |  |
| Financing receivables, net |  |  | 4,876 |  |  |  | 4,738 |  |
| Goodwill |  |  | 30,233 |  |  |  | 29,766 |  |
| Purchased intangible assets, net |  |  | 2,677 |  |  |  | 2,539 |  |
| Deferred tax assets |  |  | 4,006 |  |  |  | 4,239 |  |
| Other assets |  |  | 1,448 |  |  |  | 1,511 |  |
| TOTAL ASSETS |  | $ | 130,522 |  |  | $ | 129,818 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 10,239 |  |  | $ | 7,992 |  |
| Accounts payable |  |  | 1,155 |  |  |  | 1,385 |  |
| Income taxes payable |  |  | 86 |  |  |  | 98 |  |
| Accrued compensation |  |  | 2,684 |  |  |  | 2,895 |  |
| Deferred revenue |  |  | 10,920 |  |  |  | 10,821 |  |
| Other current liabilities |  |  | 4,200 |  |  |  | 4,392 |  |
| Total current liabilities |  |  | 29,284 |  |  |  | 27,583 |  |
| Long-term debt |  |  | 25,684 |  |  |  | 25,725 |  |
| Income taxes payable |  |  | 883 |  |  |  | 1,250 |  |
| Deferred revenue |  |  | 7,645 |  |  |  | 7,673 |  |
| Other long-term liabilities |  |  | 1,476 |  |  |  | 1,450 |  |
| Total liabilities |  |  | 64,972 |  |  |  | 63,681 |  |
| Total equity |  |  | 65,550 |  |  |  | 66,137 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 130,522 |  |  | $ | 129,818 |  |

[0001193125-17-344129:8k_2_02:81]
CISCO SYSTEMS, INC.

[0001193125-17-344129:8k_2_02:82]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-17-344129:8k_2_02:83]
(In millions)

[0001193125-17-344129:8k_2_02:84]
(Unaudited)

[0001193125-17-344129:8k_2_02:85]
|  |  | Three Months Ended |  |
|  |  | October 28,2017 |  |  | October 29,2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 2,394 |  |  | $ | 2,322 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 566 |  |  |  | 599 |  |
| Share-based compensation expense |  |  | 392 |  |  |  | 372 |  |
| Provision for receivables |  |  | (17 | ) |  |  | 15 |  |
| Deferred income taxes |  |  | 178 |  |  |  | 158 |  |
| Excess tax benefits from share-based compensation |  |  | — |  |  |  | (91 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (56 | ) |  |  | 32 |  |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 957 |  |  |  | 1,049 |  |
| Inventories |  |  | (80 | ) |  |  | 44 |  |
| Financing receivables |  |  | (333 | ) |  |  | (900 | ) |
| Other assets |  |  | 8 |  |  |  | 191 |  |
| Accounts payable |  |  | (235 | ) |  |  | (63 | ) |
| Income taxes, net |  |  | (419 | ) |  |  | (440 | ) |
| Accrued compensation |  |  | (215 | ) |  |  | (333 | ) |
| Deferred revenue |  |  | 77 |  |  |  | 462 |  |
| Other liabilities |  |  | (137 | ) |  |  | (687 | ) |
| Net cash provided by operating activities |  |  | 3,080 |  |  |  | 2,730 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (8,275 | ) |  |  | (18,667 | ) |
| Proceeds from sales of investments |  |  | 2,682 |  |  |  | 11,337 |  |
| Proceeds from maturities of investments |  |  | 3,929 |  |  |  | 2,449 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (725 | ) |  |  | (251 | ) |
| Purchases of investments in privately held companies |  |  | (20 | ) |  |  | (38 | ) |
| Return of investments in privately held companies |  |  | 81 |  |  |  | 24 |  |
| Acquisition of property and equipment |  |  | (168 | ) |  |  | (275 | ) |
| Proceeds from sales of property and equipment |  |  | 1 |  |  |  | 2 |  |
| Other |  |  | — |  |  |  | 23 |  |
| Net cash used in investing activities |  |  | (2,495 | ) |  |  | (5,396 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 9 |  |  |  | 88 |  |
| Repurchases of common stock - repurchase program |  |  | (1,686 | ) |  |  | (1,023 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (342 | ) |  |  | (401 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | (2,498 | ) |  |  | — |  |
| Issuances of debt |  |  | 5,482 |  |  |  | 6,232 |  |
| Repayments of debt |  |  | (748 | ) |  |  | (1 | ) |
| Excess tax benefits from share-based compensation |  |  | — |  |  |  | 91 |  |
| Dividends paid |  |  | (1,436 | ) |  |  | (1,308 | ) |
| Other |  |  | (31 | ) |  |  | (60 | ) |
| Net cash provided by (used in) financing activities |  |  | (1,250 | ) |  |  | 3,618 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | (665 | ) |  |  | 952 |  |
| Cash and cash equivalents, beginning of period |  |  | 11,708 |  |  |  | 7,631 |  |
| Cash and cash equivalents, end of period |  | $ | 11,043 |  |  | $ | 8,583 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 283 |  |  | $ | 248 |  |
| Cash paid for income taxes, net |  | $ | 810 |  |  | $ | 913 |  |

[0001193125-17-344129:8k_2_02:86]
8

[0001193125-17-344129:8k_2_02:87]
CISCO SYSTEMS, INC.

[0001193125-17-344129:8k_2_02:88]
DEFERRED REVENUE

[0001193125-17-344129:8k_2_02:89]
(In
millions)

[0001193125-17-344129:8k_2_02:90]
|  |  | October 28,2017 |  |  | July 29,2017 |  |  | October 29,2016 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 10,991 |  |  | $ | 11,302 |  |  | $ | 10,424 |  |
| Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred revenue related to recurring software and subscription offers |  |  | 5,213 |  |  |  | 4,971 |  |  |  | 3,801 |  |
| Other product deferred revenue |  |  | 2,361 |  |  |  | 2,221 |  |  |  | 2,726 |  |
| Total product deferred revenue |  |  | 7,574 |  |  |  | 7,192 |  |  |  | 6,527 |  |
| Total |  | $ | 18,565 |  |  | $ | 18,494 |  |  | $ | 16,951 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 10,920 |  |  | $ | 10,821 |  |  | $ | 10,215 |  |
| Noncurrent |  |  | 7,645 |  |  |  | 7,673 |  |  |  | 6,736 |  |
| Total |  | $ | 18,565 |  |  | $ | 18,494 |  |  | $ | 16,951 |  |

[0001193125-17-344129:8k_2_02:91]
CISCO SYSTEMS, INC.

[0001193125-17-344129:8k_2_02:92]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-17-344129:8k_2_02:93]
(In millions, except per-share amounts)

[0001193125-17-344129:8k_2_02:94]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| October 28, 2017 |  | $ | 0.29 |  |  | $ | 1,436 |  |  |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |  | $ | 3,056 |  |
| Fiscal 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 29, 2017 |  | $ | 0.29 |  |  | $ | 1,448 |  |  |  | 38 |  |  | $ | 31.61 |  |  | $ | 1,201 |  |  | $ | 2,649 |  |
| April 29, 2017 |  |  | 0.29 |  |  |  | 1,451 |  |  |  | 15 |  |  |  | 33.71 |  |  |  | 503 |  |  |  | 1,954 |  |
| January 28, 2017 |  |  | 0.26 |  |  |  | 1,304 |  |  |  | 33 |  |  |  | 30.33 |  |  |  | 1,001 |  |  |  | 2,305 |  |
| October 29, 2016 |  |  | 0.26 |  |  |  | 1,308 |  |  |  | 32 |  |  |  | 31.12 |  |  |  | 1,001 |  |  |  | 2,309 |  |
| Total |  | $ | 1.10 |  |  | $ | 5,511 |  |  |  | 118 |  |  | $ | 31.38 |  |  | $ | 3,706 |  |  | $ | 9,217 |  |

[0001193125-17-344129:8k_2_02:95]
9

[0001193125-17-344129:8k_2_02:96]
CISCO SYSTEMS, INC.

[0001193125-17-344129:8k_2_02:97]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-17-344129:8k_2_02:98]
GAAP TO NON-GAAP NET INCOME

[0001193125-17-344129:8k_2_02:99]
(In millions, except per-share amounts)

[0001193125-17-344129:8k_2_02:100]
|  |  | Three Months Ended |  |
|  |  | October 28,2017 |  |  | October 29,2016 |  |
| GAAP net income |  | $ | 2,394 |  |  | $ | 2,322 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 57 |  |  |  | 54 |  |
| Amortization of acquisition-related intangible assets |  |  | 139 |  |  |  | 112 |  |
| Supplier component remediation charge (adjustment), net |  |  | (19 | ) |  |  | — |  |
| Legal and indemnification settlements |  |  | 122 |  |  |  | — |  |
| Total adjustments to GAAP cost of sales |  |  | 299 |  |  |  | 166 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 335 |  |  |  | 315 |  |
| Amortization of acquisition-related intangible assets |  |  | 61 |  |  |  | 78 |  |
| Acquisition-related/divestiture costs |  |  | 83 |  |  |  | 53 |  |
| Significant asset impairments and restructurings |  |  | 152 |  |  |  | 411 |  |
| Total adjustments to GAAP operating expenses |  |  | 631 |  |  |  | 857 |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 930 |  |  |  | 1,023 |  |
| Income tax effect of non-GAAP adjustments |  |  | (288 | ) |  |  | (244 | ) |
| Non-GAAP net income |  | $ | 3,036 |  |  | $ | 3,101 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.48 |  |  | $ | 0.46 |  |
| Non-GAAP |  | $ | 0.61 |  |  | $ | 0.61 |  |

[0001193125-17-344129:8k_2_02:101]
10

[0001193125-17-344129:8k_2_02:102]
CISCO SYSTEMS, INC.

[0001193125-17-344129:8k_2_02:103]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-17-344129:8k_2_02:104]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, AND NET INCOME

[0001193125-17-344129:8k_2_02:105]
(In millions, except percentages)

[0001193125-17-344129:8k_2_02:106]
|  |  | Three Months Ended |  |
|  |  | October 28, 2017 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,439 |  |  | $ | 1,988 |  |  | $ | 7,427 |  |  | $ | 4,671 |  |  |  | (7 | )% |  | $ | 2,756 |  |  |  | (4 | )% |  | $ | 2,394 |  |  |  | 3 | % |
| % of revenue |  |  | 60.1 | % |  |  | 64.5 | % |  |  | 61.2 | % |  |  | 38.5 | % |  |  |  |  |  |  | 22.7 | % |  |  |  |  |  |  | 19.7 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 23 |  |  |  | 34 |  |  |  | 57 |  |  |  | 335 |  |  |  |  |  |  |  | 392 |  |  |  |  |  |  |  | 392 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 139 |  |  |  | — |  |  |  | 139 |  |  |  | 61 |  |  |  |  |  |  |  | 200 |  |  |  |  |  |  |  | 200 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | (19 | ) |  |  | — |  |  |  | (19 | ) |  |  | — |  |  |  |  |  |  |  | (19 | ) |  |  |  |  |  |  | (19 | ) |  |  |  |  |
| Legal and indemnification settlements |  |  | 122 |  |  |  | — |  |  |  | 122 |  |  |  | — |  |  |  |  |  |  |  | 122 |  |  |  |  |  |  |  | 122 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 83 |  |  |  |  |  |  |  | 83 |  |  |  |  |  |  |  | 83 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 152 |  |  |  |  |  |  |  | 152 |  |  |  |  |  |  |  | 152 |  |  |  |  |  |
| Income tax effect |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (288 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 5,704 |  |  | $ | 2,022 |  |  | $ | 7,726 |  |  | $ | 4,040 |  |  |  | (3 | )% |  | $ | 3,686 |  |  |  | (5 | )% |  | $ | 3,036 |  |  |  | (2 | )% |
| % of revenue |  |  | 63.0 | % |  |  | 65.6 | % |  |  | 63.7 | % |  |  | 33.3 | % |  |  |  |  |  |  | 30.4 | % |  |  |  |  |  |  | 25.0 | % |  |  |  |  |

[0001193125-17-344129:8k_2_02:107]
|  |  | Three Months Ended |  |
|  |  | October 29, 2016 |  |
|  |  | Product GrossMargin |  |  | Service GrossMargin |  |  | Total GrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | NetIncome |  |
| GAAP amount |  | $ | 5,899 |  |  | $ | 1,985 |  |  | $ | 7,884 |  |  | $ | 5,007 |  |  | $ | 2,877 |  |  | $ | 2,322 |  |
| % of revenue |  |  | 63.4 | % |  |  | 65.1 | % |  |  | 63.8 | % |  |  | 40.5 | % |  |  | 23.3 | % |  |  | 18.8 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 21 |  |  |  | 33 |  |  |  | 54 |  |  |  | 315 |  |  |  | 369 |  |  |  | 369 |  |
| Amortization of acquisition-related intangible assets |  |  | 112 |  |  |  | — |  |  |  | 112 |  |  |  | 78 |  |  |  | 190 |  |  |  | 190 |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 53 |  |  |  | 53 |  |  |  | 53 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 411 |  |  |  | 411 |  |  |  | 411 |  |
| Income tax effect |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (244 | ) |
| Non-GAAP amount |  | $ | 6,032 |  |  | $ | 2,018 |  |  | $ | 8,050 |  |  | $ | 4,150 |  |  | $ | 3,900 |  |  | $ | 3,101 |  |
| % of revenue |  |  | 64.8 | % |  |  | 66.2 | % |  |  | 65.2 | % |  |  | 33.6 | % |  |  | 31.6 | % |  |  | 25.1 | % |

[0001193125-17-344129:8k_2_02:108]
CISCO SYSTEMS, INC.

[0001193125-17-344129:8k_2_02:109]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-17-344129:8k_2_02:110]
EFFECTIVE TAX RATE

[0001193125-17-344129:8k_2_02:111]
(In
percentages)

[0001193125-17-344129:8k_2_02:112]
|  |  | Three Months Ended |  |
|  |  | October 28, 2017 |  |  | October 29, 2016 |  |
| GAAP effective tax rate |  |  | 19.2% |  |  |  | 21.4% |  |
| Total adjustments to GAAP provision for income taxes |  |  | 2.8% |  |  |  | 0.6% |  |
| Non-GAAP effective tax rate |  |  | 22.0% |  |  |  | 22.0% |  |

[0001193125-17-344129:8k_2_02:113]
GAAP TO NON-GAAP BUSINESS OUTLOOK FOR Q2 FY 2018

[0001193125-17-344129:8k_2_02:114]
| Q2 FY 2018 |  | Gross MarginRate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (2) |  |
| GAAP |  | 61.0% - 62.0% |  | 23.0% - 24.0% |  | 18% |  | $ | 0.46 - $0.51 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.5% |  | — |  | $ | 0.05 - $0.06 |  |
| Amortization of purchased intangible assets and other acquisition-related/divestiture costs |  | 1.0% |  | 2.0% |  | — |  | $ | 0.03 - $0.04 |  |
| Restructuring and other charges (1) |  | — |  | 1.0% |  | — |  | $ | 0.01 - $0.02 |  |
| Income tax effect of non-GAAP adjustments |  | — |  | — |  | 4% |  |  |  |  |
| Non-GAAP |  | 62.5% - 63.5% |  | 29.5% - 30.5% |  | 22% |  | $ | 0.58 - $0.60 |  |

[0001193125-17-344129:8k_2_02:115]
| (1) | In August 2016, we began taking action under a restructuring plan in order to reinvest in our key priority areas with estimated pretax charges of approximately $850 million. In the first quarter of fiscal 2018, we extended the restructuring plan to include an additional $150 million of estimated additional pretax charges. We have recognized pretax charges of $908 million to our GAAP financial results in relation to this restructuring plan since its inception. We expect to recognize the remaining charges under this plan primarily in the second quarter of fiscal 2018. |

[0001193125-17-344129:8k_2_02:116]
| (2) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-17-344129:8k_2_02:117]
Our Q2 FY2018 business
outlook does not reflect any impact from the pending acquisition of BroadSoft.

[0001193125-17-344129:8k_2_02:118]
Except as noted above, this business outlook does not include the effects
of any future acquisitions/divestitures, asset impairments, restructurings and significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-17-344129:8k_2_02:119]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-17-344129:8k_2_02:120]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating
income and margin, non-GAAP effective tax rates, and non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross
margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-17-344129:8k_2_02:121]
These
non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles and may be different from
non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes
that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should
only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-17-344129:8k_2_02:122]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition
and its historical and projected results of operations.

[0001193125-17-344129:8k_2_02:123]
13

[0001193125-17-344129:8k_2_02:124]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when
applicable, share-based compensation expense, amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other contingencies,
significant gains and losses on investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the
corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time
to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-17-344129:8k_2_02:125]
About Cisco

[0001193125-17-344129:8k_2_02:126]
Cisco (NASDAQ: CSCO) is the worldwide
technology leader that has been making the Internet work since 1984. Our people, products and partners help society securely connect and seize tomorrow’s digital opportunity today. Discover more at thenetwork.cisco.com and follow us on Twitter
at @Cisco.

[0001193125-17-344129:8k_2_02:127]
Copyright © 2017 Cisco and/or its affiliates. All rights reserved. Cisco and the
Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the
property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.
