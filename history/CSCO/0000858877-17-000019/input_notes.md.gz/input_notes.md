# CSCO notes — 0000858877-17-000019


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-17-000019:notes:1]
[same as prior period, unchanged from 0000858877-17-000010:notes:1]

[0000858877-17-000019:notes:2]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Compensation expense related to acquisitions | $ | 42 |  |  | $ | 64 |  |


## csco:EntityWideDisclosureOnGeographicAreasLongLivedAssetsTableTextBlock

[0000858877-17-000019:notes:3]
[same as prior period, unchanged from 0000858877-17-000010:notes:3]

[0000858877-17-000019:notes:4]
|  | October 28, 2017 |  | July 29, 2017 |
| Property and equipment, net: |  |  |  |
| United States | $ | 2,624 |  |  | $ | 2,711 |  |
| International | 578 |  |  | 611 |  |
| Total | $ | 3,202 |  |  | $ | 3,322 |  |


## csco:IncometaxprovisionTableTextBlock

[0000858877-17-000019:notes:5]
[same as prior period, unchanged from 0000858877-17-000010:notes:5]

[0000858877-17-000019:notes:6]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Income before provision for income taxes | $ | 2,962 |  |  | $ | 2,953 |  |
| Provision for income taxes | $ | 568 |  |  | $ | 631 |  |
| Effective tax rate | 19.2 | % |  | 21.4 | % |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-17-000019:notes:7]
[same as prior period, unchanged from 0000858877-17-000010:notes:7]

[0000858877-17-000019:notes:8]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 6,970 |  |  | $ | 7,273 |  |
| Applications | 1,203 |  |  | 1,136 |  |
| Security | 585 |  |  | 540 |  |
| Other Products | 296 |  |  | 353 |  |
| Total Product | 9,054 |  |  | 9,302 |  |
| Services | 3,082 |  |  | 3,050 |  |
| Total | $ | 12,136 |  |  | $ | 12,352 |  |


## csco:ScheduleOfCommonStockRepurchasedTextBlock

[0000858877-17-000019:notes:9]
[same as prior period, unchanged from 0000858877-17-000010:notes:10]

[0000858877-17-000019:notes:10]
|  | SharesRepurchased |  | Weighted-Average Priceper Share |  | AmountRepurchased |
| Cumulative balance at July 29, 2017 | 4,709 |  |  | $ | 21.30 |  |  | $ | 100,303 |  |
| Repurchase of common stock under the stock repurchase program (1) | 51 |  |  | 31.80 |  |  | 1,620 |  |
| Cumulative balance at October 28, 2017 | 4,760 |  |  | $ | 21.41 |  |  | $ | 101,923 |  |

[0000858877-17-000019:notes:11]
(1) There were no stock repurchases pending settlement as of October 28, 2017. There were $66 million of stock repurchases that were pending settlement as of July 29, 2017.


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-17-000019:notes:12]
[same as prior period, unchanged from 0000858877-17-000010:notes:13]

[0000858877-17-000019:notes:13]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE THREE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | October 28, 2017 |  | October 29, 2016 |  | October 28, 2017 |  | October 29, 2016 |
| Interest rate derivatives |  | Interest expense |  | $ | (46 | ) |  | $ | (91 | ) |  | $ | 46 |  |  | $ | 90 |  |
| Equity derivatives |  | Other income (loss), net |  | (14 | ) |  | — |  |  | 14 |  |  | — |  |
| Total |  |  |  | $ | (60 | ) |  | $ | (91 | ) |  | $ | 60 |  |  | $ | 90 |  |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-17-000019:notes:14]
[same as prior period, unchanged from 0000858877-17-000010:notes:16]

[0000858877-17-000019:notes:15]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Amortization of purchased intangible assets: |  |  |  |
| Cost of sales | $ | 154 |  |  | $ | 129 |  |
| Operating expenses |  |  |  |  |
| Amortization of purchased intangible assets | 61 |  |  | 78 |  |
| Restructuring and other charges | — |  |  | 38 |  |
| Total | $ | 215 |  |  | $ | 245 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-17-000019:notes:16]
The following table presents details of the Company’s intangible assets acquired through acquisitions completed during the three months ended October 28, 2017 (in millions, except years):

[0000858877-17-000019:notes:17]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Viptela | 5.0 |  | $ | 144 |  |  | 6.0 |  | $ | 35 |  |  | 1.0 |  | $ | 1 |  |  | $ | — |  |  | $ | 180 |  |
| Springpath | 4.0 |  | 157 |  |  | 0.0 |  | — |  |  | 0.0 |  | — |  |  | 3 |  |  | 160 |  |
| Other | 5.0 |  | 3 |  |  | 4.0 |  | 3 |  |  | 0.0 |  | — |  |  | — |  |  | 6 |  |
| Total |  |  | $ | 304 |  |  |  |  | $ | 38 |  |  |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | 346 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-17-000019:notes:18]
[same as prior period, unchanged from 0000858877-17-000010:notes:20]

[0000858877-17-000019:notes:19]
| October 28, 2017 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,465 |  |  | $ | (1,514 | ) |  | $ | 1,951 |  |
| Customer relationships |  | 1,391 |  |  | (818 | ) |  | 573 |  |
| Other |  | 82 |  |  | (44 | ) |  | 38 |  |
| Total purchased intangible assets with finite lives |  | 4,938 |  |  | (2,376 | ) |  | 2,562 |  |
| In-process research and development, with indefinite lives |  | 115 |  |  | — |  |  | 115 |  |
| Total |  | $ | 5,053 |  |  | $ | (2,376 | ) |  | $ | 2,677 |  |

[0000858877-17-000019:notes:20]
| July 29, 2017 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,182 |  |  | $ | (1,386 | ) |  | $ | 1,796 |  |
| Customer relationships |  | 1,353 |  |  | (765 | ) |  | 588 |  |
| Other |  | 82 |  |  | (38 | ) |  | 44 |  |
| Total purchased intangible assets with finite lives |  | 4,617 |  |  | (2,189 | ) |  | 2,428 |  |
| In-process research and development, with indefinite lives |  | 111 |  |  | — |  |  | 111 |  |
| Total |  | $ | 4,728 |  |  | $ | (2,189 | ) |  | $ | 2,539 |  |


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-17-000019:notes:21]
[same as prior period, unchanged from 0000858877-17-000010:notes:23]

[0000858877-17-000019:notes:22]
[same as prior period, unchanged from 0000858877-17-000010:notes:24]

[0000858877-17-000019:notes:23]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system. Sales are attributed to a segment based on the ordering location of the customer. The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments. In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-17-000019:notes:24]
Summarized financial information by segment for the three months ended October 28, 2017 and October 29, 2016, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker ("CODM"), is as follows (in millions):

[0000858877-17-000019:notes:25]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Revenue: |  |  |  |
| Americas | $ | 7,350 |  |  | $ | 7,443 |  |
| EMEA | 2,909 |  |  | 3,013 |  |
| APJC | 1,877 |  |  | 1,896 |  |
| Total | $ | 12,136 |  |  | $ | 12,352 |  |
| Gross margin: |  |  |  |
| Americas | $ | 4,722 |  |  | $ | 4,833 |  |
| EMEA | 1,839 |  |  | 2,013 |  |
| APJC | 1,165 |  |  | 1,204 |  |
| Segment total | 7,726 |  |  | 8,050 |  |
| Unallocated corporate items | (299 | ) |  | (166 | ) |
| Total | $ | 7,427 |  |  | $ | 7,884 |  |

[0000858877-17-000019:notes:26]
Revenue in the United States was $6.5 billion and $6.6 billion for the three months ended October 28, 2017 and October 29, 2016, respectively.

[0000858877-17-000019:notes:27]
[same as prior period, unchanged from 0000858877-17-000010:notes:29]

[0000858877-17-000019:notes:28]
The Company designs, manufactures, and sells Internet Protocol (IP)-based networking and other products related to the communications and IT industry and provides services associated with these products and their use. Effective in the first quarter of fiscal 2018, the Company began reporting its product and service revenue in the following five categories: Infrastructure Platforms, Applications, Security, Other Products, and Services. The change better aligns the Company's product categories with its evolving business model.  Prior period amounts have been reclassified to conform to the current period's presentation. These products, primarily integrated by Cisco IOS Software, link geographically dispersed local-area networks (LANs), metropolitan-area networks (MANs), and wide-area networks (WANs).

[0000858877-17-000019:notes:29]
[same as prior period, unchanged from 0000858877-17-000010:notes:32]

[0000858877-17-000019:notes:30]
The majority of the Company’s assets, excluding cash and cash equivalents and investments, was attributable to its U.S. operations as of each of October 28, 2017 and July 29, 2017. The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $69.1 billion and $67.5 billion as of October 28, 2017 and July 29, 2017, respectively, and the remaining $2.5 billion and $3.0 billion at the respective period ends were available in the United States.

[0000858877-17-000019:notes:31]
[same as prior period, unchanged from 0000858877-17-000010:notes:34]


## csco:StockRepurchasesSinceInceptionOfProgramTableTextBlock

[0000858877-17-000019:notes:32]
[same as prior period, unchanged from 0000858877-17-000010:notes:35]

[0000858877-17-000019:notes:33]
|  | Shares ofCommonStock |  | Common Stockand AdditionalPaid-In Capital |  | RetainedEarnings |  | Total CiscoShareholders’Equity |
| Repurchases of common stock under the repurchase program | 4,760 |  |  | $ | 25,407 |  |  | $ | 76,516 |  |  | $ | 101,923 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-17-000019:notes:34]
[same as prior period, unchanged from 0000858877-17-000010:notes:37]

[0000858877-17-000019:notes:35]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 29, 2017 | $ | 162 |  |  | $ | 103 |  |  | $ | 30 |  |  | $ | 295 |  |
| Provisions | (2 | ) |  | 2 |  |  | (6 | ) |  | (6 | ) |
| Foreign exchange and other | — |  |  | 1 |  |  | (1 | ) |  | — |  |
| Allowance for credit loss as of October 28, 2017 | $ | 160 |  |  | $ | 106 |  |  | $ | 23 |  |  | $ | 289 |  |

[0000858877-17-000019:notes:36]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 30, 2016 | $ | 230 |  |  | $ | 97 |  |  | $ | 48 |  |  | $ | 375 |  |
| Provisions | (4 | ) |  | 12 |  |  | — |  |  | 8 |  |
| Foreign exchange and other | 1 |  |  | 2 |  |  | — |  |  | 3 |  |
| Allowance for credit loss as of October 29, 2016 | $ | 227 |  |  | $ | 111 |  |  | $ | 48 |  |  | $ | 386 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000858877-17-000019:notes:37]
[same as prior period, unchanged from 0000858877-17-000010:notes:42]

[0000858877-17-000019:notes:38]
The accompanying financial data as of October 28, 2017 and for the three months ended October 28, 2017 and October 29, 2016 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 29, 2017 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 29, 2017.

[0000858877-17-000019:notes:39]
[same as prior period, unchanged from 0000858877-17-000010:notes:44]

[0000858877-17-000019:notes:40]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 28, 2017; the results of operations and the statements of comprehensive income, the statements of cash flows and equity for the three months ended October 28, 2017 and October 29, 2016, as applicable, have been made. The results of operations for the three months ended October 28, 2017 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-17-000019:notes:41]
[same as prior period, unchanged from 0000858877-17-000010:notes:46]

[0000858877-17-000019:notes:42]
The Company completed three acquisitions during the three months ended October 28, 2017. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-17-000019:notes:43]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Viptela | $ | 497 |  |  | $ | (18 | ) |  | $ | 180 |  |  | $ | 335 |  |
| Springpath | 248 |  |  | (11 | ) |  | 160 |  |  | 99 |  |
| Other | 16 |  |  | 1 |  |  | 6 |  |  | 9 |  |
| Total | $ | 761 |  |  | $ | (28 | ) |  | $ | 346 |  |  | $ | 443 |  |

[0000858877-17-000019:notes:44]
On July 31, 2017, the Company completed its acquisition of privately held Viptela Inc. ("Viptela"), a provider of software-defined wide area networking products. Revenue from the Viptela acquisition has been included in the Company's Infrastructure Platforms product category.

[0000858877-17-000019:notes:45]
On September 22, 2017, the Company completed its acquisition of privately held Springpath, Inc. ("Springpath"), a hyperconvergence software company. Revenue from the Springpath acquisition has been included in the Company's Infrastructure Platforms product category.

[0000858877-17-000019:notes:46]
The total purchase consideration related to acquisitions completed during the three months ended October 28, 2017 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $11 million. Total transaction costs related to acquisition activities were $9 million and $1 million for the three months ended October 28, 2017 and October 29, 2016, respectively. These transaction costs were expensed as incurred in general and administrative expenses ("G&A") in the Consolidated Statements of Operations. The Company recognized a gain of $46 million during the three months ended October 28, 2017 in connection with its acquisitions. This gain was recognized in Other income (loss), net in the Consolidated Statement of Operations.

[0000858877-17-000019:notes:47]
The purchase price allocation for acquisitions completed during recent periods is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information that existed as of the acquisition date but at that time was unknown to the Company may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date. Adjustments in the purchase price allocation may require a recasting of the amounts allocated to goodwill retroactive to the period in which the acquisition occurred.

[0000858877-17-000019:notes:48]
The goodwill generated from acquisitions completed during the three months ended October 28, 2017 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-17-000019:notes:49]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations for the acquisitions completed during the three months ended October 28, 2017 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.

[0000858877-17-000019:notes:50]
Pending Acquisition of BroadSoft On October 23, 2017, the Company announced a definitive agreement to acquire publicly held BroadSoft, Inc. ("BroadSoft"), a cloud calling and contact center solutions company. Under the terms of the agreement, the Company will pay $55 per share, in cash, in exchange for each share of BroadSoft, or an aggregate purchase price of approximately $1.9 billion net of cash and short-term investments. The acquisition is expected to close after completion of customary regulatory reviews.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-17-000019:notes:51]
Commitments and Contingencies

[0000858877-17-000019:notes:52]
| (a) | Operating Leases |

[0000858877-17-000019:notes:53]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of October 28, 2017 are as follows (in millions):

[0000858877-17-000019:notes:54]
| Fiscal Year | Amount |
| 2018 (remaining nine months) | $ | 316 |  |
| 2019 | 292 |  |
| 2020 | 203 |  |
| 2021 | 120 |  |
| 2022 | 99 |  |
| Thereafter | 147 |  |
| Total | $ | 1,177 |  |

[0000858877-17-000019:notes:55]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-17-000019:notes:56]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of October 28, 2017 and July 29, 2017, the Company had total purchase commitments for inventory of $4,205 million and $4,640 million, respectively.

[0000858877-17-000019:notes:57]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of October 28, 2017 and July 29, 2017, the liability for these purchase commitments was $161 million and $162 million, respectively, and was included in other current liabilities.

[0000858877-17-000019:notes:58]
| (c) | Other Commitments |

[0000858877-17-000019:notes:59]
In connection with the Company’s acquisitions, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-17-000019:notes:60]
As of October 28, 2017, the Company estimated that future cash compensation expense of up to $298 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-17-000019:notes:61]
Insieme Networks, Inc.    In fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. This investment included $100 million of funding and a license to certain of the Company’s technology. During fiscal 2014, the Company acquired the remaining interests in Insieme, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which were determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $1 million and $323 million during the three months ended October 28, 2017 and October 29, 2016, respectively. The Company recorded compensation expense of $1 million and $20 million during the three months ended October 28, 2017 and October 29, 2016, respectively, related to these milestone payments. The Company does not expect a material amount of future compensation expense or further milestone payments related to this acquisition.

[0000858877-17-000019:notes:62]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $213 million and $216 million as of October 28, 2017 and July 29, 2017, respectively.

[0000858877-17-000019:notes:63]
| (d) | Product Warranties |

[0000858877-17-000019:notes:64]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-17-000019:notes:65]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Balance at beginning of period | $ | 407 |  |  | $ | 414 |  |
| Provisions for warranty issued | 148 |  |  | 176 |  |
| Adjustments for pre-existing warranties | (12 | ) |  | — |  |
| Settlements | (149 | ) |  | (177 | ) |
| Balance at end of period | $ | 394 |  |  | $ | 413 |  |

[0000858877-17-000019:notes:66]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-17-000019:notes:67]
| (e) | Financing and Other Guarantees |

[0000858877-17-000019:notes:68]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-17-000019:notes:69]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.7 billion and $6.9 billion for the three months ended October 28, 2017 and October 29, 2016, respectively. The balance of the channel partner financing subject to guarantees was $1.0 billion as of each of October 28, 2017 and July 29, 2017.

[0000858877-17-000019:notes:70]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $14 million and $6 million for the three months ended October 28, 2017 and October 29, 2016, respectively.

[0000858877-17-000019:notes:71]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 28, 2017 and July 29, 2017, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-17-000019:notes:72]
|  | October 28, 2017 |  | July 29, 2017 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 266 |  |  | $ | 240 |  |
| End user | 65 |  |  | 74 |  |
| Total | $ | 331 |  |  | $ | 314 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (79 | ) |  | $ | (82 | ) |
| End user | (46 | ) |  | (52 | ) |
| Total | $ | (125 | ) |  | $ | (134 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 206 |  |  | $ | 180 |  |

[0000858877-17-000019:notes:73]
Other Guarantees   The Company’s other guarantee arrangements as of October 28, 2017 and July 29, 2017 that were subject to recognition and disclosure requirements were not material.

[0000858877-17-000019:notes:74]
| (f) | Supplier Component Remediation Liabilities |

[0000858877-17-000019:notes:75]
In fiscal 2014, the Company recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. The Company performs regular assessments of the sufficiency of this liability and reduced the amount by $74 million and $164 million in fiscal 2016 and fiscal 2015, respectively based on updated analyses. During the second quarter of fiscal 2017, the Company further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. In addition, during the second quarter of fiscal 2017, the Company recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of the Company’s products. The liabilities related to the supplier component remediation matters as of October 28, 2017 and July 29, 2017 were $146 million and $174 million, respectively.

[0000858877-17-000019:notes:76]
| (g) | Indemnifications |

[0000858877-17-000019:notes:77]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-17-000019:notes:78]
The Company has been asked to indemnify certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. in federal court in Kansas and Delaware. Sprint alleges that the service provider customers infringed Sprint’s patents by offering VoIP telephone services utilizing products provided by the Company generally in combination with those of other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017 against Time Warner Inc., a jury in Kansas found that Time Warner Cable willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied Time Warner Cable's post-trial motions. Time Warner Cable has appealed. On October 16, 2017, Sprint and Comcast Cable Communications, LLC reached resolution of the claims in Sprint's lawsuit against Comcast and on October 19, 2017, the Kansas court dismissed Sprint's lawsuit. Sprint's trial against Cox Communications, Inc. in Delaware is scheduled for December 7, 2017.

[0000858877-17-000019:notes:79]
For the remaining cases, the Company believes that the service providers continue to have strong non-infringement and invalidity defenses and arguments and/or that Sprint’s damages claims are inconsistent with prevailing law at trial and/or on appeal. Due to the uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the ultimate outcome of the remaining litigation at this time. Should Sprint prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products. At this time, the Company does not anticipate that its obligations regarding the final outcome of the remaining matters would be material.

[0000858877-17-000019:notes:80]
On January 15, 2016, Huawei Technologies Co. Ltd. (“Huawei”) filed four patent infringement actions against T-Mobile US, Inc. and T-Mobile USA, Inc. (collectively, “T-Mobile”) in federal court in the Eastern District of Texas. Huawei alleged that T-Mobile’s use of 3GPP standards to implement its 3G and 4G cellular networks infringe 12 patents, now reduced to 10 patents as a result of pre-trial dismissals. Huawei's infringement allegations for some of the patents are based on T-Mobile's use of products provided by the Company in combination with those of other manufacturers. T-Mobile has requested indemnity by the Company with respect to portions of the network that use the Company's equipment. On November 9, 2017, the court continued the trial date to January 2, 2018.

[0000858877-17-000019:notes:81]
The Company believes that the patents are invalid and/or not infringed, and that Huawei’s claims should be rejected for Huawei's failure to comply with its licensing and disclosure obligations to standards setting organizations that issued the relevant standards. If T-Mobile is found to infringe any of the patents warranting an award of damages, the Company believes damages against T-Mobile, as appropriately measured, should be governed by reasonable and nondiscriminatory licensing principles. Due to uncertainty surrounding patent litigation processes, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation and the Company does not anticipate that its obligations, if any, regarding the final outcome of the matters would be material.

[0000858877-17-000019:notes:82]
During the first quarter of fiscal 2018, the Company recorded legal and indemnification settlement charges of $122 million to product cost of sales in relation to these matters.

[0000858877-17-000019:notes:83]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-17-000019:notes:84]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-17-000019:notes:85]
| (h) | Legal Proceedings |

[0000858877-17-000019:notes:86]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-17-000019:notes:87]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $250 million for the alleged evasion of import and other taxes, $1.5 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of October 28, 2017. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

[0000858877-17-000019:notes:88]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against the Company in the U.S. District Court for the District of Delaware, accusing the Company's products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. The Company has appealed to the United States Court of Appeals for the Federal Circuit on various grounds. The Company believes it has strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, the Company does not expect it to be material.

[0000858877-17-000019:notes:89]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, the Company petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art. On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that the Company would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. On June 28, 2016, in light of the PTAB’s decision to review the patent’s validity, the district court issued an order staying the district court case pending the final written decision from the PTAB. On February 22, 2017, following a hearing, the PTAB issued its Final Written Decision that the patent’s claims are unpatentable. SSL has appealed this decision to the Court of Appeals for the Federal Circuit. The Company believes it has strong arguments that the Company's products do not infringe and the patent is invalid. If the Company does not prevail and a jury were to find that the Company's AnyConnect products infringe, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding patent litigation processes, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

[0000858877-17-000019:notes:90]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against the Company in U.S. District Court for the Northern District of California, accusing the Company’s 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted the Company's motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against the Company and cancelling a trial which had been set for March 12, 2018.

[0000858877-17-000019:notes:91]
DXC Technology     On August 21, 2015, the Company and Cisco Systems Capital Corporation (“Cisco Capital”) filed an action in Santa Clara County Superior Court for declaratory judgment and breach of contract against HP Inc. (“HP”) regarding a services agreement for management services of a third party’s network. HP prepaid the service agreement through a financing arrangement with Cisco Capital. HP terminated its agreement with the Company, and pursuant to the terms of the service agreement with HP, the Company determined the credit HP was entitled to receive under the agreement. HP disputed the Company’s credit calculation and contended that the Company owes a larger credit to HP than the Company had calculated. In December 2015, the Company filed an amended complaint which dropped the breach of contract claim in light of HP’s continuing payments to Cisco Capital under the financing arrangement. On January 19, 2016, HP Inc. filed a counterclaim for breach of contract simultaneously with its answer to the amended complaint. The court continued the trial date from November 6, 2017 to March 12, 2018. DXC Technology Corporation (“DXC”) reported that it is the party in interest in this matter pursuant to the Separation and Distribution Agreement between the then Hewlett-Packard Co. and Hewlett Packard Enterprise Company (“HPE") and the subsequent Separation and Distribution Agreement between HPE and DXC. On August 30, 2017, the Company and DXC attended a court ordered mediation and, on September 1, 2017, the parties jointly informed the court that they are continuing to discuss the details of a business resolution to the dispute. The Company is unable to reasonably estimate the ultimate outcome of this litigation due to uncertainty surrounding the litigation process. However, the Company does not anticipate that its obligation, if any, regarding the final outcome of the dispute would be material.

[0000858877-17-000019:notes:92]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-17-000019:notes:93]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.

[0000858877-17-000019:notes:94]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-17-000019:notes:95]
[same as prior period, unchanged from 0000858877-17-000010:notes:97]

[0000858877-17-000019:notes:96]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, for the three months ended October 28, 2017 and October 29, 2016 are summarized as follows (in millions):

[0000858877-17-000019:notes:97]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 29, 2017 | $ | 373 |  |  | $ | 32 |  |  | $ | (359 | ) |  | $ | 46 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 18 |  |  | 8 |  |  | 18 |  |  | 44 |  |
| (Gains) losses reclassified out of AOCI | (33 | ) |  | (13 | ) |  | 1 |  |  | (45 | ) |
| Tax benefit (expense) | (13 | ) |  | 1 |  |  | (2 | ) |  | (14 | ) |
| BALANCE AT OCTOBER 28, 2017 | $ | 345 |  |  | $ | 28 |  |  | $ | (342 | ) |  | $ | 31 |  |

[0000858877-17-000019:notes:98]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 30, 2016 | $ | 413 |  |  | $ | (59 | ) |  | $ | (680 | ) |  | $ | (326 | ) |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (210 | ) |  | (46 | ) |  | (26 | ) |  | (282 | ) |
| (Gains) losses reclassified out of AOCI | (15 | ) |  | 12 |  |  | — |  |  | (3 | ) |
| Tax benefit (expense) | 86 |  |  | 2 |  |  | (1 | ) |  | 87 |  |
| BALANCE AT OCTOBER 29, 2016 | $ | 274 |  |  | $ | (91 | ) |  | $ | (707 | ) |  | $ | (524 | ) |

[0000858877-17-000019:notes:99]
[same as prior period, unchanged from 0000858877-17-000010:notes:101]

[0000858877-17-000019:notes:100]
|  |  | Three Months Ended |  |  |
|  |  | October 28, 2017 |  | October 29, 2016 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains and losses on available-for-sale investments |  | $ | 33 |  |  | $ | 15 |  |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |
| Foreign currency derivatives |  | 10 |  |  | (9 | ) |  | Operating expenses |
| Foreign currency derivatives |  | 3 |  |  | (3 | ) |  | Cost of sales—service |
|  |  | 13 |  |  | (12 | ) |  |  |
| Cumulative translation adjustment and actuarial gains and losses |  | (1 | ) |  | — |  |  | Operating expenses |
| Total amounts reclassified out of AOCI |  | $ | 45 |  |  | $ | 3 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-17-000019:notes:101]
Borrowings

[0000858877-17-000019:notes:102]
| (a) | Short-Term Debt |

[0000858877-17-000019:notes:103]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-17-000019:notes:104]
|  | October 28, 2017 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,748 |  |  | 1.70 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | 5,491 |  |  | 1.25 | % |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 10,239 |  |  |  |  | $ | 7,992 |  |  |  |

[0000858877-17-000019:notes:105]
The Company has a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-17-000019:notes:106]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-17-000019:notes:107]
| (b) | Long-Term Debt |

[0000858877-17-000019:notes:108]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-17-000019:notes:109]
|  |  |  | October 28, 2017 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | 1,000 |  |  | 1.98% |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.70% |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.88% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 1.71% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.96% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.85% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.85% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.01% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.28% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.13% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.44% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 30,500 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (130 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 62 |  |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 30,432 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,748 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 25,684 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 30,432 |  |  |  |  | $ | 30,472 |  |  |  |

[0000858877-17-000019:notes:110]
The Company entered into interest rate swaps in prior periods with an aggregate notional amount of $6.75 billion designated as fair value hedges of certain of its fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate ("LIBOR"). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 11.

[0000858877-17-000019:notes:111]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 28, 2017, the Company was in compliance with all debt covenants.

[0000858877-17-000019:notes:112]
As of October 28, 2017, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-17-000019:notes:113]
| Fiscal Year | Amount |
| 2018 (remaining nine months) | $ | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 30,500 |  |

[0000858877-17-000019:notes:114]
| (c) | Credit Facilities |

[0000858877-17-000019:notes:115]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.

[0000858877-17-000019:notes:116]
In addition, on March 30, 2017, the Company entered into a 364-Day credit agreement with certain institutional lenders that provides for a $2.0 billion unsecured revolving credit facility that is scheduled to expire on March 29, 2018. The credit agreement also provides the Company with the option to, for a fee, convert any borrowing outstanding thereunder on March 29, 2018 to a term loan maturing no later than March 29, 2019. The interest rate applicable to outstanding balances under the credit agreement will be based on either (i) the higher of (a) the rates on overnight Federal Funds transactions with members of the Federal Reserve System (i.e., Federal Funds rate) plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time or (c) LIBOR for an interest period of one month plus 1.00%, or (ii) LIBOR plus a margin that is based on the Company's senior debt credit ratings as published by S&P Global Rating, a business unit of Standard & Poor’s Financial Services LLC, and Moody’s Investors Service, Inc.

[0000858877-17-000019:notes:117]
These credit agreements require that the Company comply with certain covenants, including that the Company maintains an interest coverage ratio as defined in these agreements. As of October 28, 2017, the Company was in compliance with the required interest coverage ratios and the other covenants, and the Company had not borrowed any funds under these credit facilities.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-17-000019:notes:118]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 10,991 |  |  | $ | 11,302 |  |
| Product: |  |  |  |  |
| Deferred revenue related to recurring software and subscription offers |  | 5,213 |  |  | 4,971 |  |
| Other product deferred revenue |  | 2,361 |  |  | 2,221 |  |
| Total product deferred revenue |  | 7,574 |  |  | 7,192 |  |
| Total |  | $ | 18,565 |  |  | $ | 18,494 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 10,920 |  |  | $ | 10,821 |  |
| Noncurrent |  | 7,645 |  |  | 7,673 |  |
| Total |  | $ | 18,565 |  |  | $ | 18,494 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-17-000019:notes:119]
[same as prior period, unchanged from 0000858877-17-000010:notes:127]

[0000858877-17-000019:notes:120]
[same as prior period, unchanged from 0000858877-17-000010:notes:128]

[0000858877-17-000019:notes:121]
[same as prior period, unchanged from 0000858877-17-000010:notes:129]

[0000858877-17-000019:notes:122]
[same as prior period, unchanged from 0000858877-17-000010:notes:130]

[0000858877-17-000019:notes:123]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | October 28, 2017 |  | July 29, 2017 |  | Balance Sheet Line Item |  | October 28, 2017 |  | July 29, 2017 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 40 |  |  | $ | 46 |  |  | Other current liabilities |  | $ | — |  |  | $ | 1 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 14 |  |  | — |  |
| Interest rate derivatives | Other assets |  | 58 |  |  | 102 |  |  | Other long-term liabilities |  | 2 |  |  | — |  |
| Total |  |  | 98 |  |  | 148 |  |  |  |  | 16 |  |  | 1 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 1 |  |  | 1 |  |  | Other current liabilities |  | 2 |  |  | 3 |  |
| Equity derivatives/warrants | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 1 |  |  | 1 |  |  |  |  | 2 |  |  | 3 |  |
| Total |  |  | $ | 99 |  |  | $ | 149 |  |  |  |  | $ | 18 |  |  | $ | 4 |  |

[0000858877-17-000019:notes:124]
[same as prior period, unchanged from 0000858877-17-000010:notes:132]

[0000858877-17-000019:notes:125]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE THREE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THETHREE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | October 28, 2017 |  | October 29, 2016 |  | Line Item in Statements of Operations |  | October 28, 2017 |  | October 29, 2016 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 8 |  |  | $ | (46 | ) |  | Operating expenses |  | $ | 10 |  |  | $ | (9 | ) |
|  |  |  |  |  |  | Cost of sales—service |  | 3 |  |  | (3 | ) |
| Total |  | $ | 8 |  |  | $ | (46 | ) |  |  |  | $ | 13 |  |  | $ | (12 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (5 | ) |  | $ | 9 |  |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-17-000019:notes:126]
As of October 28, 2017, the Company estimates that approximately $44 million of net derivative gains related to its cash flow hedges included in accumulated other comprehensive income ("AOCI") will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-17-000019:notes:127]
[same as prior period, unchanged from 0000858877-17-000010:notes:136]

[0000858877-17-000019:notes:128]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | October 28, 2017 |  | October 29, 2016 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | 7 |  |  | $ | (16 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | 16 |  |  | (3 | ) |
| Equity derivatives |  | Other income (loss), net |  | 1 |  |  | 1 |  |
| Total |  |  |  | $ | 24 |  |  | $ | (18 | ) |

[0000858877-17-000019:notes:129]
[same as prior period, unchanged from 0000858877-17-000010:notes:138]

[0000858877-17-000019:notes:130]
|  | October 28, 2017 |  | July 29, 2017 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 1,219 |  |  | $ | 1,696 |  |
| Interest rate derivatives | 6,750 |  |  | 6,750 |  |
| Net investment hedging instruments | 266 |  |  | 351 |  |
| Equity derivatives | 302 |  |  | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 1,918 |  |  | 2,258 |  |
| Total return swaps—deferred compensation | 564 |  |  | 535 |  |
| Total | $ | 11,019 |  |  | $ | 11,590 |  |

[0000858877-17-000019:notes:131]
[same as prior period, unchanged from 0000858877-17-000010:notes:140]

[0000858877-17-000019:notes:132]
[same as prior period, unchanged from 0000858877-17-000010:notes:141]

[0000858877-17-000019:notes:133]
|  | October 28, 2017 |
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEETS |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETSBUT WITH LEGAL RIGHTS TO OFFSET |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 99 |  |  | $ | — |  |  | $ | 99 |  |  | $ | (14 | ) |  | $ | (57 | ) |  | $ | 28 |  |
| Derivatives liabilities | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |  | $ | (14 | ) |  | $ | — |  |  | $ | 4 |  |

[0000858877-17-000019:notes:134]
|  | July 29, 2017 |
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEETS |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETSBUT WITH LEGAL RIGHTS TO OFFSET |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 149 |  |  | $ | — |  |  | $ | 149 |  |  | $ | (4 | ) |  | $ | (81 | ) |  | $ | 64 |  |
| Derivatives liabilities | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |  | $ | (4 | ) |  | $ | — |  |  | $ | — |  |

[0000858877-17-000019:notes:135]
[same as prior period, unchanged from 0000858877-17-000010:notes:144]

[0000858877-17-000019:notes:136]
[same as prior period, unchanged from 0000858877-17-000010:notes:145]

[0000858877-17-000019:notes:137]
[same as prior period, unchanged from 0000858877-17-000010:notes:146]

[0000858877-17-000019:notes:138]
[same as prior period, unchanged from 0000858877-17-000010:notes:147]

[0000858877-17-000019:notes:139]
[same as prior period, unchanged from 0000858877-17-000010:notes:148]

[0000858877-17-000019:notes:140]
[same as prior period, unchanged from 0000858877-17-000010:notes:149]

[0000858877-17-000019:notes:141]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of October 28, 2017 and July 29, 2017, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-17-000019:notes:142]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt  In the three months ended October 28, 2017, the Company did not enter into any interest rate swaps. In prior fiscal years, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2019 through 2025. Under these interest rate swaps, the Company receives fixed-rate interest payments and makes interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps was reflected in other current assets and other assets.

[0000858877-17-000019:notes:143]
[same as prior period, unchanged from 0000858877-17-000010:notes:152]

[0000858877-17-000019:notes:144]
[same as prior period, unchanged from 0000858877-17-000010:notes:153]

[0000858877-17-000019:notes:145]
[same as prior period, unchanged from 0000858877-17-000010:notes:154]

[0000858877-17-000019:notes:146]
[same as prior period, unchanged from 0000858877-17-000010:notes:155]

[0000858877-17-000019:notes:147]
[same as prior period, unchanged from 0000858877-17-000010:notes:156]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-17-000019:notes:148]
[same as prior period, unchanged from 0000858877-17-000010:notes:157]

[0000858877-17-000019:notes:149]
[same as prior period, unchanged from 0000858877-17-000010:notes:158]

[0000858877-17-000019:notes:150]
Stock Incentive Plan Program Description    As of October 28, 2017, the Company had one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company.  The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors. The Company’s primary stock incentive plan is summarized as follows:

[0000858877-17-000019:notes:151]
2005 Plan    As of October 28, 2017, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus shares from certain previous plans that are forfeited or are terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan. In addition, starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-17-000019:notes:152]
Pursuant to an amendment approved by the Company's shareholders on November 12, 2009, the number of shares available for issuance under the 2005 Plan is reduced by 1.5 shares for each share awarded as a stock grant or a stock unit, and any shares underlying awards outstanding from certain previous plans that expire unexercised at the end of their maximum terms become available for reissuance under the 2005 Plan. The 2005 Plan permits the granting of stock options, restricted stock, and restricted stock units ("RSUs"), the vesting of which may be performance-based or market-based along with the requisite service requirement, and stock appreciation rights to employees (including employee directors and officers), consultants of the Company and its subsidiaries and affiliates, and non-employee directors of the Company.  Stock options and stock appreciation rights granted under the 2005 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date. The expiration date for stock options and stock appreciation rights shall be no later than 10 years from the grant date.

[0000858877-17-000019:notes:153]
The stock options will generally become exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively. Time-based stock grants and time-based RSUs will generally vest over a four year term. The majority of the performance-based and market-based RSUs vests at the end of the three-year requisite service period or earlier if the award recipient meets certain retirement eligibility conditions. Certain performance-based RSUs, that are based on the achievement of financial and/or non-financial operating goals, typically vest upon the achievement of milestones (and may require subsequent service periods), with overall vesting of the shares underlying the award ranging from six months to three years. The Compensation and Management Development Committee of the Board of Directors has the discretion to use different vesting schedules. Stock appreciation rights may be awarded in combination with stock options or stock grants, and such awards shall provide that the stock appreciation rights will not be exercisable unless the related stock options or stock grants are forfeited. Stock grants may be awarded in combination with non-statutory stock options, and such awards may provide that the stock grants will be forfeited in the event that the related non-statutory stock options are exercised.

[0000858877-17-000019:notes:154]
[same as prior period, unchanged from 0000858877-17-000010:notes:162]

[0000858877-17-000019:notes:155]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 621 million shares of the Company’s common stock have been reserved for issuance as of October 28, 2017. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period.  The Purchase Plan is scheduled to terminate on January 3, 2020. No shares were issued under the Purchase Plan during each of the three months ended October 28, 2017 and October 29, 2016, respectively. As of October 28, 2017, 100 million shares were available for issuance under the Purchase Plan.

[0000858877-17-000019:notes:156]
[same as prior period, unchanged from 0000858877-17-000010:notes:164]

[0000858877-17-000019:notes:157]
[same as prior period, unchanged from 0000858877-17-000010:notes:165]

[0000858877-17-000019:notes:158]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Cost of sales—product | $ | 23 |  |  | $ | 21 |  |
| Cost of sales—service | 34 |  |  | 33 |  |
| Share-based compensation expense in cost of sales | 57 |  |  | 54 |  |
| Research and development | 136 |  |  | 126 |  |
| Sales and marketing | 135 |  |  | 140 |  |
| General and administrative | 64 |  |  | 49 |  |
| Restructuring and other charges | 6 |  |  | 3 |  |
| Share-based compensation expense in operating expenses | 341 |  |  | 318 |  |
| Total share-based compensation expense | $ | 398 |  |  | $ | 372 |  |
| Income tax benefit for share-based compensation | $ | 175 |  |  | $ | 105 |  |

[0000858877-17-000019:notes:159]
As of October 28, 2017, the total compensation cost related to unvested share-based awards not yet recognized was $2.9 billion, which is expected to be recognized over approximately 2.6 years on a weighted-average basis.

[0000858877-17-000019:notes:160]
[same as prior period, unchanged from 0000858877-17-000010:notes:168]

[0000858877-17-000019:notes:161]
[same as prior period, unchanged from 0000858877-17-000010:notes:169]

[0000858877-17-000019:notes:162]
|  | Share-Based Awards Available for Grant |
| BALANCE AT JULY 30, 2016 | 242 |  |
| Restricted stock, stock units, and other share-based awards granted | (76 | ) |
| Share-based awards canceled/forfeited/expired | 78 |  |
| Shares withheld for taxes and not issued | 28 |  |
| BALANCE AT JULY 29, 2017 | 272 |  |
| Restricted stock, stock units, and other share-based awards granted | (16 | ) |
| Share-based awards canceled/forfeited/expired | 5 |  |
| Shares withheld for taxes and not issued | 15 |  |
| BALANCE AT OCTOBER 28, 2017 | 276 |  |

[0000858877-17-000019:notes:163]
[same as prior period, unchanged from 0000858877-17-000010:notes:171]

[0000858877-17-000019:notes:164]
[same as prior period, unchanged from 0000858877-17-000010:notes:172]

[0000858877-17-000019:notes:165]
[same as prior period, unchanged from 0000858877-17-000010:notes:173]

[0000858877-17-000019:notes:166]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 30, 2016 | 145 |  |  | $ | 24.26 |  |  |  |
| Granted | 50 |  |  | 27.89 |  |  |  |
| Assumed from acquisitions | 15 |  |  | 32.21 |  |  |  |
| Vested | (54 | ) |  | 23.14 |  |  | $ | 1,701 |  |
| Canceled/forfeited | (15 | ) |  | 23.56 |  |  |  |
| UNVESTED BALANCE AT JULY 29, 2017 | 141 |  |  | 26.94 |  |  |  |
| Granted | 10 |  |  | 30.19 |  |  |  |
| Assumed from acquisitions | 1 |  |  | 28.70 |  |  |  |
| Vested | (29 | ) |  | 24.52 |  |  | $ | 927 |  |
| Canceled/forfeited | (6 | ) |  | 28.73 |  |  |  |
| UNVESTED BALANCE AT OCTOBER 28, 2017 | 117 |  |  | $ | 27.75 |  |  |  |

[0000858877-17-000019:notes:167]
[same as prior period, unchanged from 0000858877-17-000010:notes:175]

[0000858877-17-000019:notes:168]
[same as prior period, unchanged from 0000858877-17-000010:notes:176]

[0000858877-17-000019:notes:169]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 30, 2016 | 73 |  |  | $ | 26.78 |  |
| Assumed from acquisitions | 8 |  |  | 4.47 |  |
| Exercised | (14 | ) |  | 12.11 |  |
| Canceled/forfeited/expired | (55 | ) |  | 31.83 |  |
| BALANCE AT JULY 29, 2017 | 12 |  |  | 6.15 |  |
| Assumed from acquisitions | 3 |  |  | 8.07 |  |
| Exercised | (2 | ) |  | 5.19 |  |
| BALANCE AT OCTOBER 28, 2017 | 13 |  |  | $ | 6.68 |  |

[0000858877-17-000019:notes:170]
The following table summarizes significant ranges of outstanding and exercisable stock options as of October 28, 2017 (in millions, except years and share prices):

[0000858877-17-000019:notes:171]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 30.00 |  | 13 |  |  | 6.6 |  | $ | 6.68 |  |  | $ | 371 |  |  | 7 |  |  | $ | 5.90 |  |  | $ | 193 |  |

[0000858877-17-000019:notes:172]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on the Company’s closing stock price of $34.43 as of October 27, 2017, that would have been received by the option holders had those option holders exercised their stock options as of that date. The total number of in-the-money stock options exercisable as of October 28, 2017 was 7 million. As of July 29, 2017, 6 million outstanding stock options were exercisable and the weighted-average exercise price was $5.61.

[0000858877-17-000019:notes:173]
[same as prior period, unchanged from 0000858877-17-000010:notes:181]

[0000858877-17-000019:notes:174]
[same as prior period, unchanged from 0000858877-17-000010:notes:182]

[0000858877-17-000019:notes:175]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE BASEDRESTRICTED STOCK UNITS |
| Three Months Ended | October 28, 2017 |  | October 29, 2016 |  | October 28, 2017 |  | October 29, 2016 |
| Number of shares granted (in millions) | 7 |  |  | 7 |  |  | 3 |  |  | 3 |  |
| Grant date fair value per share | $ | 29.81 |  |  | $ | 28.55 |  |  | $ | 31.31 |  |  | $ | 29.62 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.6 | % |  | 3.3 | % |  | 3.6 | % |  | 3.3 | % |
| Range of risk-free interest rates | 1.0% – 1.9% |  |  | 0.0% – 1.2% |  |  | 1.0% – 1.6% |  |  | 0.1% – 0.9% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 13.2% – 81.0% |  |  | 16.7% – 46.8% |  |

[0000858877-17-000019:notes:176]
[same as prior period, unchanged from 0000858877-17-000010:notes:185]


## us-gaap:EarningsPerSharePolicyTextBlock

[0000858877-17-000019:notes:177]
Employee equity share options, unvested shares, and similar equity instruments are treated as potential common shares outstanding in computing diluted earnings per share. Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that has not yet recognized would be recorded in additional paid-in capital when the award becomes deductible are collectively assumed to be used to repurchase shares.


## us-gaap:EarningsPerShareTextBlock

[0000858877-17-000019:notes:178]
[same as prior period, unchanged from 0000858877-17-000010:notes:187]

[0000858877-17-000019:notes:179]
[same as prior period, unchanged from 0000858877-17-000010:notes:188]

[0000858877-17-000019:notes:180]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Net income | $ | 2,394 |  |  | $ | 2,322 |  |
| Weighted-average shares—basic | 4,959 |  |  | 5,027 |  |
| Effect of dilutive potential common shares | 35 |  |  | 39 |  |
| Weighted-average shares—diluted | 4,994 |  |  | 5,066 |  |
| Net income per share—basic | $ | 0.48 |  |  | $ | 0.46 |  |
| Net income per share—diluted | $ | 0.48 |  |  | $ | 0.46 |  |
| Antidilutive employee share-based awards, excluded | 15 |  |  | 67 |  |


## us-gaap:EquityMethodInvestmentsTextBlock

[0000858877-17-000019:notes:181]
For such investments that were accounted for under the equity and cost method as of October 28, 2017 and July 29, 2017, the amounts are summarized in the following table (in millions):

[0000858877-17-000019:notes:182]
|  | October 28, 2017 |  | July 29, 2017 |
| Equity method investments | $ | 108 |  |  | $ | 124 |  |
| Cost method investments | 839 |  |  | 859 |  |
| Total | $ | 947 |  |  | $ | 983 |  |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-17-000019:notes:183]
[same as prior period, unchanged from 0000858877-17-000010:notes:192]

[0000858877-17-000019:notes:184]
|  | TOTAL GAINS (LOSSES) FOR THE THREE MONTHS ENDED |
|  | October 28, 2017 |  | October 29, 2016 |
| Investments in privately held companies (impaired) | $ | (21 | ) |  | $ | (47 | ) |
| Purchased intangible assets (impaired) | — |  |  | (42 | ) |
| Total gains (losses) for nonrecurring measurements | $ | (21 | ) |  | $ | (89 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-17-000019:notes:185]
[same as prior period, unchanged from 0000858877-17-000010:notes:194]

[0000858877-17-000019:notes:186]
[same as prior period, unchanged from 0000858877-17-000010:notes:195]

[0000858877-17-000019:notes:187]
[same as prior period, unchanged from 0000858877-17-000010:notes:196]

[0000858877-17-000019:notes:188]
[same as prior period, unchanged from 0000858877-17-000010:notes:197]

[0000858877-17-000019:notes:189]
[same as prior period, unchanged from 0000858877-17-000010:notes:198]

[0000858877-17-000019:notes:190]
[same as prior period, unchanged from 0000858877-17-000010:notes:199]

[0000858877-17-000019:notes:191]
[same as prior period, unchanged from 0000858877-17-000010:notes:200]

[0000858877-17-000019:notes:192]
[same as prior period, unchanged from 0000858877-17-000010:notes:201]

[0000858877-17-000019:notes:193]
Assets and liabilities measured at fair value on a recurring basis as of October 28, 2017 and July 29, 2017 were as follows (in millions):

[0000858877-17-000019:notes:194]
|  | OCTOBER 28, 2017FAIR VALUE MEASUREMENTS |  | JULY 29, 2017FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 9,103 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,103 |  |  | $ | 9,567 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,567 |  |
| U.S. government securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 139 |  |  | — |  |  | 139 |  |
| Commercial paper | — |  |  | 115 |  |  | — |  |  | 115 |  |  | — |  |  | 160 |  |  | — |  |  | 160 |  |
| Certificates of deposit | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 25 |  |  | — |  |  | 25 |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 20,471 |  |  | — |  |  | 20,471 |  |  | — |  |  | 19,823 |  |  | — |  |  | 19,823 |  |
| U.S. government agency securities | — |  |  | 1,917 |  |  | — |  |  | 1,917 |  |  | — |  |  | 2,052 |  |  | — |  |  | 2,052 |  |
| Non-U.S. government and agency securities | — |  |  | 357 |  |  | — |  |  | 357 |  |  | — |  |  | 388 |  |  | — |  |  | 388 |  |
| Corporate debt securities | — |  |  | 32,030 |  |  | — |  |  | 32,030 |  |  | — |  |  | 31,735 |  |  | — |  |  | 31,735 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,074 |  |  | — |  |  | 2,074 |  |  | — |  |  | 2,023 |  |  | — |  |  | 2,023 |  |
| Commercial paper | — |  |  | 1,775 |  |  | — |  |  | 1,775 |  |  | — |  |  | 996 |  |  | — |  |  | 996 |  |
| Certificates of deposit | — |  |  | 140 |  |  | — |  |  | 140 |  |  | — |  |  | 60 |  |  | — |  |  | 60 |  |
| Publicly traded equity securities | 1,781 |  |  | — |  |  | — |  |  | 1,781 |  |  | 1,707 |  |  | — |  |  | — |  |  | 1,707 |  |
| Derivative assets | — |  |  | 99 |  |  | — |  |  | 99 |  |  | — |  |  | 149 |  |  | — |  |  | 149 |  |
| Total | $ | 10,884 |  |  | $ | 58,978 |  |  | $ | — |  |  | $ | 69,862 |  |  | $ | 11,274 |  |  | $ | 57,550 |  |  | $ | — |  |  | $ | 68,824 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Total | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |

[0000858877-17-000019:notes:195]
[same as prior period, unchanged from 0000858877-17-000010:notes:204]

[0000858877-17-000019:notes:196]
[same as prior period, unchanged from 0000858877-17-000010:notes:205]

[0000858877-17-000019:notes:197]
[same as prior period, unchanged from 0000858877-17-000010:notes:206]

[0000858877-17-000019:notes:198]
[same as prior period, unchanged from 0000858877-17-000010:notes:207]

[0000858877-17-000019:notes:199]
The fair value measurement of the impaired investments was classified as Level 3 because significant unobservable inputs were used in the valuation due to the absence of quoted market prices and inherent lack of liquidity. Significant unobservable inputs, which included financial metrics of comparable private and public companies, financial condition and near-term prospects of the investees, recent financing activities of the investees, and the investees’ capital structure as well as other economic variables, reflected the assumptions market participants would use in pricing these assets. The impairment charges, representing the difference between the net book value and the fair value as a result of the evaluation, were recorded to other income (loss), net. The remaining carrying value of the investments that were impaired was $25 million and $46 million as of October 28, 2017 and October 29, 2016, respectively.

[0000858877-17-000019:notes:200]
The fair value for purchased intangible assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation. Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable. See Note 4. The remaining carrying value of the specific purchased intangible assets that were impaired was zero and $11 million as of October 28, 2017 and October 29, 2016, respectively.

[0000858877-17-000019:notes:201]
[same as prior period, unchanged from 0000858877-17-000010:notes:211]

[0000858877-17-000019:notes:202]
The carrying value of investments in privately held companies that were accounted for under the cost method was $839 million and $859 million as of October 28, 2017 and July 29, 2017, respectively. It was not practicable to estimate the fair value of this portfolio.

[0000858877-17-000019:notes:203]
The fair value of short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of long-term loan receivables and financed service contracts as of October 28, 2017 and July 29, 2017 was $3.5 billion and $3.4 billion, respectively. The estimated fair value of long-term loan receivables and financed service contracts approximates their carrying value. The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-17-000019:notes:204]
As of October 28, 2017, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.  As of October 28, 2017, the fair value of the Company’s senior notes and other long-term debt was $32.0 billion with a carrying amount of $30.4 billion. This compares to a fair value of $32.1 billion and a carrying amount of $30.5 billion as of July 29, 2017. The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-17-000019:notes:205]
Gross receivables, excluding residual value, less unearned income categorized by the Company’s internal credit risk rating as of October 28, 2017 and July 29, 2017 are summarized as follows (in millions):

[0000858877-17-000019:notes:206]
|  | INTERNAL CREDIT RISK RATING |
| October 28, 2017 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,320 |  |  | $ | 1,337 |  |  | $ | 48 |  |  | $ | 2,705 |  |
| Loan receivables | 2,988 |  |  | 1,571 |  |  | 189 |  |  | 4,748 |  |
| Financed service contracts | 1,656 |  |  | 911 |  |  | 16 |  |  | 2,583 |  |
| Total | $ | 5,964 |  |  | $ | 3,819 |  |  | $ | 253 |  |  | $ | 10,036 |  |

[0000858877-17-000019:notes:207]
|  | INTERNAL CREDIT RISK RATING |
| July 29, 2017 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,408 |  |  | $ | 1,181 |  |  | $ | 50 |  |  | $ | 2,639 |  |
| Loan receivables | 2,865 |  |  | 1,516 |  |  | 179 |  |  | 4,560 |  |
| Financed service contracts | 1,593 |  |  | 902 |  |  | 22 |  |  | 2,517 |  |
| Total | $ | 5,866 |  |  | $ | 3,599 |  |  | $ | 251 |  |  | $ | 9,716 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-17-000019:notes:208]
[same as prior period, unchanged from 0000858877-17-000010:notes:218]

[0000858877-17-000019:notes:209]
[same as prior period, unchanged from 0000858877-17-000010:notes:219]

[0000858877-17-000019:notes:210]
Financing receivables primarily consist of lease receivables, loan receivables, and financed service contracts. Lease receivables represent sales-type and direct-financing leases resulting from the sale of the Company’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average. Loan receivables represent financing arrangements related to the sale of the Company’s hardware, software, and services, which may include additional funding for other costs associated with network installation and integration of the Company’s products and services. Loan receivables generally have terms of up to three years. Financed service contracts include financing receivables related to technical support and advanced services. Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one to three years.

[0000858877-17-000019:notes:211]
[same as prior period, unchanged from 0000858877-17-000010:notes:221]

[0000858877-17-000019:notes:212]
| October 28, 2017 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,848 |  |  | $ | 4,748 |  |  | $ | 2,583 |  |  | $ | 10,179 |  |
| Residual value | 167 |  |  | — |  |  | — |  |  | 167 |  |
| Unearned income | (143 | ) |  | — |  |  | — |  |  | (143 | ) |
| Allowance for credit loss | (160 | ) |  | (106 | ) |  | (23 | ) |  | (289 | ) |
| Total, net | $ | 2,712 |  |  | $ | 4,642 |  |  | $ | 2,560 |  |  | $ | 9,914 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,290 |  |  | $ | 2,236 |  |  | $ | 1,512 |  |  | $ | 5,038 |  |
| Noncurrent | 1,422 |  |  | 2,406 |  |  | 1,048 |  |  | 4,876 |  |
| Total, net | $ | 2,712 |  |  | $ | 4,642 |  |  | $ | 2,560 |  |  | $ | 9,914 |  |

[0000858877-17-000019:notes:213]
| July 29, 2017 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,784 |  |  | $ | 4,560 |  |  | $ | 2,517 |  |  | $ | 9,861 |  |
| Residual value | 173 |  |  | — |  |  | — |  |  | 173 |  |
| Unearned income | (145 | ) |  | — |  |  | — |  |  | (145 | ) |
| Allowance for credit loss | (162 | ) |  | (103 | ) |  | (30 | ) |  | (295 | ) |
| Total, net | $ | 2,650 |  |  | $ | 4,457 |  |  | $ | 2,487 |  |  | $ | 9,594 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,301 |  |  | $ | 2,104 |  |  | $ | 1,451 |  |  | $ | 4,856 |  |
| Noncurrent | 1,349 |  |  | 2,353 |  |  | 1,036 |  |  | 4,738 |  |
| Total, net | $ | 2,650 |  |  | $ | 4,457 |  |  | $ | 2,487 |  |  | $ | 9,594 |  |

[0000858877-17-000019:notes:214]
Future minimum lease payments to the Company on lease receivables as of October 28, 2017 are summarized as follows (in millions):

[0000858877-17-000019:notes:215]
| Fiscal Year | Amount |
| 2018 (remaining nine months) | $ | 1,106 |  |
| 2019 | 932 |  |
| 2020 | 512 |  |
| 2021 | 239 |  |
| 2022 | 57 |  |
| Thereafter | 2 |  |
| Total | $ | 2,848 |  |

[0000858877-17-000019:notes:216]
[same as prior period, unchanged from 0000858877-17-000010:notes:227]

[0000858877-17-000019:notes:217]
[same as prior period, unchanged from 0000858877-17-000010:notes:228]

[0000858877-17-000019:notes:218]
The Company determines the adequacy of its allowance for credit loss by assessing the risks and losses inherent in its financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by the Company to its customers, which consist of the following: lease receivables, loan receivables, and financed service contracts.

[0000858877-17-000019:notes:219]
[same as prior period, unchanged from 0000858877-17-000010:notes:230]

[0000858877-17-000019:notes:220]
In circumstances when collectibility is not deemed reasonably assured, the associated revenue is deferred in accordance with the Company’s revenue recognition policies, and the related allowance for credit loss, if any, is included in deferred revenue. The Company also records deferred revenue associated with financing receivables when there are remaining performance obligations, as it does for financed service contracts.

[0000858877-17-000019:notes:221]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of October 28, 2017 and July 29, 2017 (in millions):

[0000858877-17-000019:notes:222]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| October 28, 2017 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 161 |  |  | $ | 86 |  |  | $ | 320 |  |  | $ | 567 |  |  | $ | 2,138 |  |  | $ | 2,705 |  |  | $ | 14 |  |  | $ | 14 |  |
| Loan receivables | 145 |  |  | 81 |  |  | 407 |  |  | 633 |  |  | 4,115 |  |  | 4,748 |  |  | 44 |  |  | 44 |  |
| Financed service contracts | 261 |  |  | 184 |  |  | 106 |  |  | 551 |  |  | 2,032 |  |  | 2,583 |  |  | 13 |  |  | 2 |  |
| Total | $ | 567 |  |  | $ | 351 |  |  | $ | 833 |  |  | $ | 1,751 |  |  | $ | 8,285 |  |  | $ | 10,036 |  |  | $ | 71 |  |  | $ | 60 |  |

[0000858877-17-000019:notes:223]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 29, 2017 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 160 |  |  | $ | 60 |  |  | $ | 216 |  |  | $ | 436 |  |  | $ | 2,203 |  |  | $ | 2,639 |  |  | $ | 14 |  |  | $ | 14 |  |
| Loan receivables | 230 |  |  | 48 |  |  | 259 |  |  | 537 |  |  | 4,023 |  |  | 4,560 |  |  | 43 |  |  | 43 |  |
| Financed service contracts | 160 |  |  | 77 |  |  | 523 |  |  | 760 |  |  | 1,757 |  |  | 2,517 |  |  | 18 |  |  | 2 |  |
| Total | $ | 550 |  |  | $ | 185 |  |  | $ | 998 |  |  | $ | 1,733 |  |  | $ | 7,983 |  |  | $ | 9,716 |  |  | $ | 75 |  |  | $ | 59 |  |

[0000858877-17-000019:notes:224]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract. The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $595 million and $666 million as of October 28, 2017 and July 29, 2017, respectively.

[0000858877-17-000019:notes:225]
As of October 28, 2017, the Company had financing receivables of $215 million, net of unbilled or current receivables, that were in the category of 91 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $315 million as of July 29, 2017.

[0000858877-17-000019:notes:226]
[same as prior period, unchanged from 0000858877-17-000010:notes:237]

[0000858877-17-000019:notes:227]
[same as prior period, unchanged from 0000858877-17-000010:notes:238]

[0000858877-17-000019:notes:228]
Typically, the Company also considers receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. These balances, as of October 28, 2017 and July 29, 2017, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-17-000019:notes:229]
[same as prior period, unchanged from 0000858877-17-000010:notes:240]

[0000858877-17-000019:notes:230]
[same as prior period, unchanged from 0000858877-17-000010:notes:241]

[0000858877-17-000019:notes:231]
[same as prior period, unchanged from 0000858877-17-000010:notes:242]

[0000858877-17-000019:notes:232]
|  | October 28, 2017 |  | July 29, 2017 |
| Operating lease assets | $ | 352 |  |  | $ | 356 |  |
| Accumulated depreciation | (221 | ) |  | (212 | ) |
| Operating lease assets, net | $ | 131 |  |  | $ | 144 |  |

[0000858877-17-000019:notes:233]
Minimum future rentals on noncancelable operating leases as of October 28, 2017 are summarized as follows (in millions):

[0000858877-17-000019:notes:234]
| Fiscal Year | Amount |
| 2018 (remaining nine months) | $ | 139 |  |
| 2019 | 110 |  |
| 2020 | 48 |  |
| 2021 | 7 |  |
| Thereafter | 2 |  |
| Total | $ | 306 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-17-000019:notes:235]
[same as prior period, unchanged from 0000858877-17-000010:notes:246]

[0000858877-17-000019:notes:236]
[same as prior period, unchanged from 0000858877-17-000010:notes:247]

[0000858877-17-000019:notes:237]
The following table presents the goodwill allocated to the Company’s reportable segments as of and during the three months ended October 28, 2017 (in millions):

[0000858877-17-000019:notes:238]
|  | Balance at |  |  |  |  |  | Balance at |
|  | July 29, 2017 |  | Acquisitions |  | Other |  | October 28, 2017 |
| Americas | $ | 18,691 |  |  | $ | 323 |  |  | $ | 15 |  |  | $ | 19,029 |  |
| EMEA | 7,057 |  |  | 92 |  |  | 6 |  |  | 7,155 |  |
| APJC | 4,018 |  |  | 28 |  |  | 3 |  |  | 4,049 |  |
| Total | $ | 29,766 |  |  | $ | 443 |  |  | $ | 24 |  |  | $ | 30,233 |  |

[0000858877-17-000019:notes:239]
[same as prior period, unchanged from 0000858877-17-000010:notes:250]

[0000858877-17-000019:notes:240]
[same as prior period, unchanged from 0000858877-17-000010:notes:251]

[0000858877-17-000019:notes:241]
[same as prior period, unchanged from 0000858877-17-000010:notes:252]

[0000858877-17-000019:notes:242]
Impairment charges related to purchased intangible assets were zero and $42 million for the three months ended October 28, 2017 and October 29, 2016, respectively. Impairment charges were primarily as a result of declines in estimated fair values of certain purchased intangible assets resulting from the reduction or elimination of expected future cash flows associated with certain of the Company’s technology and IPR&D intangible assets. Of these impairment charges, $38 million for the three months ended October 29, 2016 was recorded to restructuring and other charges in connection with the Company's decision to exit certain products lines, and the corresponding elimination of future associated cash flows.

[0000858877-17-000019:notes:243]
The estimated future amortization expense of purchased intangible assets with finite lives as of October 28, 2017 is as follows (in millions):

[0000858877-17-000019:notes:244]
| Fiscal Year | Amount |
| 2018 (remaining nine months) | $ | 647 |  |
| 2019 | 776 |  |
| 2020 | 559 |  |
| 2021 | 362 |  |
| 2022 | 145 |  |
| Thereafter | 73 |  |
| Total | $ | 2,562 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-17-000019:notes:245]
[same as prior period, unchanged from 0000858877-17-000010:notes:256]

[0000858877-17-000019:notes:246]
As of October 28, 2017, the Company had $2.1 billion of unrecognized tax benefit, of which $1.5 billion, if recognized, would favorably impact the effective tax rate. The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. The Company believes it is reasonably possible that certain federal, foreign and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.  The Company estimates that the unrecognized tax benefits at October 28, 2017 could be reduced by approximately $100 million in the next 12 months.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-17-000019:notes:247]
The following table summarizes the maturities of the Company’s fixed income securities as of October 28, 2017 (in millions):

[0000858877-17-000019:notes:248]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 16,376 |  |  | $ | 16,360 |  |
| Due in 1 to 2 years | 14,866 |  |  | 14,820 |  |
| Due in 2 to 5 years | 21,852 |  |  | 21,883 |  |
| Due after 5 years | 3,665 |  |  | 3,627 |  |
| Mortgage-backed securities with no single maturity | 2,095 |  |  | 2,074 |  |
| Total | $ | 58,854 |  |  | $ | 58,764 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-17-000019:notes:249]
Investments

[0000858877-17-000019:notes:250]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-17-000019:notes:251]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-17-000019:notes:252]
| October 28, 2017 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 20,564 |  |  | $ | — |  |  | $ | (93 | ) |  | $ | 20,471 |  |
| U.S. government agency securities | 1,923 |  |  | — |  |  | (6 | ) |  | 1,917 |  |
| Non-U.S. government and agency securities | 358 |  |  | — |  |  | (1 | ) |  | 357 |  |
| Corporate debt securities | 31,999 |  |  | 162 |  |  | (131 | ) |  | 32,030 |  |
| U.S. agency mortgage-backed securities | 2,095 |  |  | 2 |  |  | (23 | ) |  | 2,074 |  |
| Commercial paper | 1,775 |  |  | — |  |  | — |  |  | 1,775 |  |
| Certificates of deposit | 140 |  |  | — |  |  | — |  |  | 140 |  |
| Total fixed income securities | 58,854 |  |  | 164 |  |  | (254 | ) |  | 58,764 |  |
| Publicly traded equity securities | 1,134 |  |  | 653 |  |  | (6 | ) |  | 1,781 |  |
| Total (1) | $ | 59,988 |  |  | $ | 817 |  |  | $ | (260 | ) |  | $ | 60,545 |  |

[0000858877-17-000019:notes:253]
| July 29, 2017 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 19,880 |  |  | $ | 3 |  |  | $ | (60 | ) |  | $ | 19,823 |  |
| U.S. government agency securities | 2,057 |  |  | — |  |  | (5 | ) |  | 2,052 |  |
| Non-U.S. government and agency securities | 389 |  |  | — |  |  | (1 | ) |  | 388 |  |
| Corporate debt securities | 31,626 |  |  | 202 |  |  | (93 | ) |  | 31,735 |  |
| U.S. agency mortgage-backed securities | 2,037 |  |  | 3 |  |  | (17 | ) |  | 2,023 |  |
| Commercial paper | 996 |  |  | — |  |  | — |  |  | 996 |  |
| Certificates of deposit | 60 |  |  | — |  |  | — |  |  | 60 |  |
| Total fixed income securities | 57,045 |  |  | 208 |  |  | (176 | ) |  | 57,077 |  |
| Publicly traded equity securities | 1,180 |  |  | 554 |  |  | (27 | ) |  | 1,707 |  |
| Total (1) | $ | 58,225 |  |  | $ | 762 |  |  | $ | (203 | ) |  | $ | 58,784 |  |

[0000858877-17-000019:notes:254]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases (sales) were $95 million and $(30) million as of October 28, 2017 and July 29, 2017, respectively.

[0000858877-17-000019:notes:255]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-17-000019:notes:256]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-17-000019:notes:257]
The following table presents the gross realized gains and gross realized losses related to available-for-sale investments (in millions):

[0000858877-17-000019:notes:258]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Gross realized gains | $ | 67 |  |  | $ | 30 |  |
| Gross realized losses | (34 | ) |  | (15 | ) |
| Total | $ | 33 |  |  | $ | 15 |  |

[0000858877-17-000019:notes:259]
The following table presents the realized net gains (losses) related to available-for-sale investments by security type (in millions):

[0000858877-17-000019:notes:260]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 29 |  |  | $ | 5 |  |
| Net gains (losses) on investments in fixed income securities | 4 |  |  | 10 |  |
| Total | $ | 33 |  |  | $ | 15 |  |

[0000858877-17-000019:notes:261]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at October 28, 2017 and July 29, 2017 (in millions):

[0000858877-17-000019:notes:262]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 28, 2017 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 16,719 |  |  | $ | (66 | ) |  | $ | 3,602 |  |  | $ | (27 | ) |  | $ | 20,321 |  |  | $ | (93 | ) |
| U.S. government agency securities | 1,696 |  |  | (4 | ) |  | 222 |  |  | (2 | ) |  | 1,918 |  |  | (6 | ) |
| Non-U.S. government and agency securities | 316 |  |  | (1 | ) |  | 41 |  |  | — |  |  | 357 |  |  | (1 | ) |
| Corporate debt securities | 8,129 |  |  | (45 | ) |  | 4,209 |  |  | (86 | ) |  | 12,338 |  |  | (131 | ) |
| U.S. agency mortgage-backed securities | 1,562 |  |  | (16 | ) |  | 266 |  |  | (7 | ) |  | 1,828 |  |  | (23 | ) |
| Total fixed income securities | 28,422 |  |  | (132 | ) |  | 8,340 |  |  | (122 | ) |  | 36,762 |  |  | (254 | ) |
| Publicly traded equity securities | 54 |  |  | (6 | ) |  | — |  |  | — |  |  | 54 |  |  | (6 | ) |
| Total | $ | 28,476 |  |  | $ | (138 | ) |  | $ | 8,340 |  |  | $ | (122 | ) |  | $ | 36,816 |  |  | $ | (260 | ) |

[0000858877-17-000019:notes:263]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2017 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 14,962 |  |  | $ | (55 | ) |  | $ | 771 |  |  | $ | (5 | ) |  | $ | 15,733 |  |  | $ | (60 | ) |
| U.S. government agency securities | 1,791 |  |  | (4 | ) |  | 130 |  |  | (1 | ) |  | 1,921 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 368 |  |  | (1 | ) |  | — |  |  | — |  |  | 368 |  |  | (1 | ) |
| Corporate debt securities | 9,487 |  |  | (92 | ) |  | 101 |  |  | (1 | ) |  | 9,588 |  |  | (93 | ) |
| U.S. agency mortgage-backed securities | 1,485 |  |  | (16 | ) |  | 38 |  |  | (1 | ) |  | 1,523 |  |  | (17 | ) |
| Total fixed income securities | 28,093 |  |  | (168 | ) |  | 1,040 |  |  | (8 | ) |  | 29,133 |  |  | (176 | ) |
| Publicly traded equity securities | 122 |  |  | (27 | ) |  | — |  |  | — |  |  | 122 |  |  | (27 | ) |
| Total | $ | 28,215 |  |  | $ | (195 | ) |  | $ | 1,040 |  |  | $ | (8 | ) |  | $ | 29,255 |  |  | $ | (203 | ) |

[0000858877-17-000019:notes:264]
For the three months ended October 28, 2017, the net realized losses related to available-for-sale investments included impairment charges of $26 million. These impairment charges related primarily to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the three months ended October 29, 2016.

[0000858877-17-000019:notes:265]
As of October 28, 2017, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of October 28, 2017, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the three months ended October 28, 2017.

[0000858877-17-000019:notes:266]
The Company has evaluated its publicly traded equity securities as of October 28, 2017 and has determined that there were no additional other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-17-000019:notes:267]
| (c) | Maturities of Fixed Income Securities |

[0000858877-17-000019:notes:268]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-17-000019:notes:269]
| (d) | Securities Lending |

[0000858877-17-000019:notes:270]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the three months ended October 28, 2017 and October 29, 2016 was $0.5 billion and $1.2 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 28, 2017 and July 29, 2017, the Company had no outstanding securities lending transactions.

[0000858877-17-000019:notes:271]
| (e) | Investments in Privately Held Companies |

[0000858877-17-000019:notes:272]
The carrying value of the investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of October 28, 2017 and July 29, 2017, the amounts are summarized in the following table (in millions):

[0000858877-17-000019:notes:273]
For additional information on impairment charges related to investments in privately held companies, see Note 9.

[0000858877-17-000019:notes:274]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of October 28, 2017, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

[0000858877-17-000019:notes:275]
As of October 28, 2017, the carrying value of investments in privately held companies was $947 million, of which $519 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $213 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000858877-17-000019:notes:276]
(a) New Accounting Updates Recently Adopted

[0000858877-17-000019:notes:277]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. Cisco adopted this accounting standard update beginning the first quarter of fiscal 2018 on a prospective basis. This resulted in an overall decrease in the effective tax rate for the first quarter of fiscal 2018 due to recognition of excess tax benefits from share-based compensation. The application of this accounting standard update did not have a material impact on the Company's Consolidated Financial Statements.

[0000858877-17-000019:notes:278]
(b) Recent Accounting Standards or Updates Not Yet Effective

[0000858877-17-000019:notes:279]
Revenue Recognition  In May 2014, the FASB issued a new accounting standard related to revenue recognition. The new standard will supersede nearly all U.S. GAAP on revenue recognition and eliminate industry-specific guidance. The underlying principle of the new standard is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. It also requires increased disclosures including the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

[0000858877-17-000019:notes:280]
The standard allows two methods of adoption: i) retrospectively to each prior period presented (“full retrospective method”), or ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective method"). Cisco will adopt the new standard using the modified retrospective method at the beginning of its first quarter of fiscal 2019.

[0000858877-17-000019:notes:281]
Cisco is on schedule in establishing new accounting policies, implementing systems and processes (including more extensive use of estimates), and internal controls necessary to support the requirements of the new standard. Cisco has completed its preliminary assessment of the financial statement impact of the new standard, as discussed below, and will continue to update that assessment as more information becomes available.

[0000858877-17-000019:notes:282]
The new standard will primarily impact Cisco’s revenue recognition for software arrangements and sales to two-tier distributors. In both areas, the new standard will accelerate the recognition of revenue. The table below details both the current and expected revenue recognition timing in these areas:

[0000858877-17-000019:notes:283]
|  |  | Current Revenue Standard |  | New Revenue Standard |
| Software arrangements: |  |  |  |  |
| Perpetual software licenses |  | Upfront |  | Upfront |
| Term software licenses |  | Ratable |  | Upfront |
| Security software licenses |  | Ratable |  | Ratable |
| Enterprise license agreements |  | Ratable |  | Upfront |
| Software support services |  | Ratable |  | Ratable |
| Software-as-a-service |  | Ratable |  | Ratable |
| Two-tier distribution |  | Sell-Through |  | Sell-In |

[0000858877-17-000019:notes:284]
Cisco expects that the new standard will not have a material impact on total revenue in the year of adoption based on two factors: i) revenue will be accelerated consistent with the changes in timing as indicated in the preceding table, largely offset by ii) the reduction of revenue from software arrangements where revenue was previously deferred in prior periods and recognized ratably over time as required under the current standard. This preliminary assessment is based on the types and number of revenue arrangements currently in place. The exact impact of the new standard will be dependent on facts and circumstances at adoption and could vary from quarter to quarter.

[0000858877-17-000019:notes:285]
In addition to the above revenue recognition timing impacts, the new standard will require incremental contract acquisition costs (such as sales commissions) for customer contracts to be capitalized and amortized over the contract period. Currently, these costs are expensed as incurred.

[0000858877-17-000019:notes:286]
Cisco will be required to record cumulative effect adjustments to retained earnings upon adopting the new standard at the beginning of fiscal 2019. The most significant of these adjustments will be to reduce product deferred revenue and increase retained earnings at the date of adoption to reflect revenue that would have been already recognized under the new standard related to existing arrangements. There will also be an adjustment to increase accounts receivable and reduce inventories related to the changes in revenue recognition on sales to two-tier distributors. Lastly, an adjustment will be recorded to establish an asset and increase retained earnings related to the requirement to capitalize incremental contract acquisition costs for customer contracts.

[0000858877-17-000019:notes:287]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019, and early adoption is permitted. The most significant impact of this accounting standard update for Cisco is that it will require the remeasurement of investments that are not accounted for under the equity method at fair value at the end of each reporting period with the changes recorded to the income statement. While Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements, Cisco expects that this accounting standard update will increase the variability of other income (loss), net.

[0000858877-17-000019:notes:288]
Leases  In February 2016, the FASB issued an accounting standard update related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2020 on a modified retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-17-000019:notes:289]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2021 on a modified retrospective basis, and early adoption in fiscal 2020 is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-17-000019:notes:290]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Statements of Cash Flows.

[0000858877-17-000019:notes:291]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-17-000019:notes:292]
Restricted Cash in Statement of Cash Flow  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented, and early adoption is permitted. Cisco does not expect that this accounting standard update will have a material impact on its Consolidated Statements of Cash Flows.

[0000858877-17-000019:notes:293]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be fact dependent, but Cisco expects that some transactions that were previously accounted for as business combinations or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.

[0000858877-17-000019:notes:294]
Simplifying the Test for Goodwill Impairment  In January 2017, the FASB issued an accounting standard update that removes Step 2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2021 on a prospective basis, and early adoption is permitted. Cisco does not expect that this accounting standard update will impact its Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-17-000019:notes:295]
[same as prior period, unchanged from 0000858877-17-000010:notes:300]

[0000858877-17-000019:notes:296]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2018 and fiscal 2017 are each 52-week fiscal years. The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated. The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-17-000019:notes:297]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-17-000019:notes:298]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,854 |  |  | $ | 4,926 |  |
| Computer equipment and related software |  | 1,251 |  |  | 1,258 |  |
| Production, engineering, and other equipment |  | 5,681 |  |  | 5,707 |  |
| Operating lease assets |  | 352 |  |  | 356 |  |
| Furniture and fixtures |  | 393 |  |  | 572 |  |
| Total gross property and equipment |  | 12,531 |  |  | 12,819 |  |
| Less: accumulated depreciation and amortization |  | (9,329 | ) |  | (9,497 | ) |
| Total |  | $ | 3,202 |  |  | $ | 3,322 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-17-000019:notes:299]
[same as prior period, unchanged from 0000858877-17-000010:notes:304]

[0000858877-17-000019:notes:300]
The Company began taking action under a restructuring plan in August 2016 (the "Fiscal 2017 Plan"), in order to reinvest in its key priority areas. In the first quarter of fiscal 2018, the Company extended the Fiscal 2017 Plan to include an additional $150 million of estimated additional pretax charges for employee severance and other one-time termination benefits. The Company's estimated aggregate pretax charges of approximately $1.0 billion under the Fiscal 2017 Plan are primarily cash based and consist primarily of employee severance and other one-time termination benefits, and other associated costs. In connection with this plan, the Company has incurred cumulative charges of approximately $908 million and it expects the Fiscal 2017 Plan to be substantially completed by the end of the second quarter of fiscal 2018.

[0000858877-17-000019:notes:301]
[same as prior period, unchanged from 0000858877-17-000010:notes:307]

[0000858877-17-000019:notes:302]
|  |  | FISCAL 2017 AND PRIOR PLANS |  |  |
|  |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 29, 2017 |  | $ | 74 |  |  | $ | 43 |  |  | $ | 117 |  |
| Charges |  | 145 |  |  | 7 |  |  | 152 |  |
| Cash payments |  | (79 | ) |  | (16 | ) |  | (95 | ) |
| Non-cash items |  | — |  |  | (6 | ) |  | (6 | ) |
| Liability as of October 28, 2017 |  | $ | 140 |  |  | $ | 28 |  |  | $ | 168 |  |

[0000858877-17-000019:notes:303]
|  |  | FISCAL 2017 AND PRIOR PLANS |  |  |
|  |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 30, 2016 |  | $ | 21 |  |  | $ | 24 |  |  | $ | 45 |  |
| Charges |  | 369 |  |  | 42 |  |  | 411 |  |
| Cash payments |  | (269 | ) |  | (1 | ) |  | (270 | ) |
| Non-cash items |  | (4 | ) |  | (43 | ) |  | (47 | ) |
| Liability as of October 29, 2016 |  | $ | 117 |  |  | $ | 22 |  |  | $ | 139 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000858877-17-000019:notes:304]
[same as prior period, unchanged from 0000858877-17-000010:notes:310]

[0000858877-17-000019:notes:305]
|  |  | October 28, 2017 |  | July 29, 2017 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 358 |  |  | $ | 289 |  |
| Work in Process |  | 1 |  |  | 1 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 457 |  |  | 451 |  |
| Manufactured finished goods |  | 550 |  |  | 552 |  |
| Total finished goods |  | 1,007 |  |  | 1,003 |  |
| Service-related spares |  | 303 |  |  | 300 |  |
| Demonstration systems |  | 24 |  |  | 23 |  |
| Total |  | $ | 1,693 |  |  | $ | 1,616 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-17-000019:notes:306]
[same as prior period, unchanged from 0000858877-17-000010:notes:312]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-17-000019:notes:307]
[same as prior period, unchanged from 0000858877-17-000010:notes:313]

[0000858877-17-000019:notes:308]
[same as prior period, unchanged from 0000858877-17-000010:notes:314]

[0000858877-17-000019:notes:309]
During the three months ended October 28, 2017, the Company declared and paid cash dividends of $0.29 per common share, or $1.4 billion, on the Company’s outstanding common stock. During the three months ended October 29, 2016, the Company declared and paid cash dividends of $0.26 per common share, or $1.3 billion, on the Company’s outstanding common stock.

[0000858877-17-000019:notes:310]
[same as prior period, unchanged from 0000858877-17-000010:notes:316]

[0000858877-17-000019:notes:311]
[same as prior period, unchanged from 0000858877-17-000010:notes:317]

[0000858877-17-000019:notes:312]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of October 28, 2017, the Company’s Board of Directors had authorized an aggregate repurchase of up to $112 billion of common stock under this program, and the remaining authorized repurchase amount was $10.1 billion with no termination date. A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-17-000019:notes:313]
[same as prior period, unchanged from 0000858877-17-000010:notes:319]

[0000858877-17-000019:notes:314]
[same as prior period, unchanged from 0000858877-17-000010:notes:320]

[0000858877-17-000019:notes:315]
For the three months ended October 28, 2017 and October 29, 2016, the Company repurchased approximately 11 million and 13 million shares, or $342 million and $401 million of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.

[0000858877-17-000019:notes:316]
[same as prior period, unchanged from 0000858877-17-000010:notes:322]

[0000858877-17-000019:notes:317]
[same as prior period, unchanged from 0000858877-17-000010:notes:323]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-17-000019:notes:318]
[same as prior period, unchanged from 0000858877-17-000010:notes:324]


## us-gaap:TreasuryStockTextBlock

[0000858877-17-000019:notes:319]
[same as prior period, unchanged from 0000858877-17-000010:notes:325]

[0000858877-17-000019:notes:320]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of October 28, 2017, the Company’s Board of Directors had authorized an aggregate repurchase of up to $112 billion of common stock under this program with no termination date. For additional information regarding stock repurchase, see Note 13 to the Consolidated Financial Statements. The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):
