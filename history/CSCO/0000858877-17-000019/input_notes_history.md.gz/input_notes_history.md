# CSCO note change history — 0000858877-17-000010 → 0000858877-17-000019


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-11-21):
[0000858877-17-000019:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of October 28, 2017 are as follows (in millions):
  (was, 2017-05-23, similarity 0.9858):
[0000858877-17-000010:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 29, 2017 are as follows (in millions):

- changed (2017-11-21):
[0000858877-17-000019:note_history:2]
| Fiscal Year | Amount |
| 2018 (remaining nine months) | $ | 316 |  |
| 2019 | 292 |  |
| 2020 | 203 |  |
| 2021 | 120 |  |
| 2022 | 99 |  |
| Thereafter | 147 |  |
| Total | $ | 1,177 |  |
  (was, 2017-05-23, similarity 0.9772):
[0000858877-17-000010:note_history:2]
| Fiscal Year | Amount |
| 2017 (remaining three months) | $ | 115 |  |
| 2018 | 355 |  |
| 2019 | 230 |  |
| 2020 | 161 |  |
| 2021 | 98 |  |
| Thereafter | 201 |  |
| Total | $ | 1,160 |  |

- changed (2017-11-21):
[0000858877-17-000019:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of October 28, 2017 and July 29, 2017, the Company had total purchase commitments for inventory of $4,205 million and $4,640 million, respectively.
  (was, 2017-05-23, similarity 0.994):
[0000858877-17-000010:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of April 29, 2017 and July 30, 2016, the Company had total purchase commitments for inventory of $4,720 million and $3,896 million, respectively.

- changed (2017-11-21):
[0000858877-17-000019:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of October 28, 2017 and July 29, 2017, the liability for these purchase commitments was $161 million and $162 million, respectively, and was included in other current liabilities.
  (was, 2017-05-23, similarity 0.9848):
[0000858877-17-000010:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of April 29, 2017 and July 30, 2016, the liability for these purchase commitments was $179 million and $159 million, respectively, and was included in other current liabilities.

- changed (2017-11-21):
[0000858877-17-000019:note_history:5]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Compensation expense related to acquisitions | $ | 42 |  |  | $ | 64 |  |
  (was, 2017-05-23, similarity 0.7134):
[0000858877-17-000010:note_history:5]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2017 |  | April 30, 2016 |  | April 29, 2017 |  | April 30, 2016 |
| Compensation expense related to acquisitions | $ | 36 |  |  | $ | 68 |  |  | $ | 173 |  |  | $ | 212 |  |

- changed (2017-11-21):
[0000858877-17-000019:note_history:6]
As of October 28, 2017, the Company estimated that future cash compensation expense of up to $298 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2017-05-23, similarity 0.6932):
[0000858877-17-000010:note_history:6]
As of April 29, 2017, the Company estimated that future cash compensation expense of up to $222 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.

- added (2017-11-21):
[0000858877-17-000019:note_history:7]
Insieme Networks, Inc.    In fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. This investment included $100 million of funding and a license to certain of the Company’s technology. During fiscal 2014, the Company acquired the remaining interests in Insieme, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which were determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $1 million and $323 million during the three months ended October 28, 2017 and October 29, 2016, respectively. The Company recorded compensation expense of $1 million and $20 million during the three months ended October 28, 2017 and October 29, 2016, respectively, related to these milestone payments. The Company does not expect a material amount of future compensation expense or further milestone payments related to this acquisition.

- added (2017-11-21):
[0000858877-17-000019:note_history:8]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $213 million and $216 million as of October 28, 2017 and July 29, 2017, respectively.

- changed (2017-11-21):
[0000858877-17-000019:note_history:9]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Balance at beginning of period | $ | 407 |  |  | $ | 414 |  |
| Provisions for warranty issued | 148 |  |  | 176 |  |
| Adjustments for pre-existing warranties | (12 | ) |  | — |  |
| Settlements | (149 | ) |  | (177 | ) |
| Balance at end of period | $ | 394 |  |  | $ | 413 |  |
  (was, 2017-05-23, similarity 0.7348):
[0000858877-17-000010:note_history:9]
|  | Nine Months Ended |
|  | April 29, 2017 |  | April 30, 2016 |
| Balance at beginning of period | $ | 414 |  |  | $ | 449 |  |
| Provisions for warranty issued | 528 |  |  | 520 |  |
| Adjustments for pre-existing warranties | (17 | ) |  | (8 | ) |
| Settlements | (511 | ) |  | (524 | ) |
| Divestitures | — |  |  | (28 | ) |
| Balance at end of period | $ | 414 |  |  | $ | 409 |  |

- changed (2017-11-21):
[0000858877-17-000019:note_history:10]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.7 billion and $6.9 billion for the three months ended October 28, 2017 and October 29, 2016, respectively. The balance of the channel partner financing subject to guarantees was $1.0 billion as of each of October 28, 2017 and July 29, 2017.
  (was, 2017-05-23, similarity 0.8661):
[0000858877-17-000010:note_history:10]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.6 billion and $6.4 billion for the three months ended April 29, 2017 and April 30, 2016, respectively, and was $19.7 billion and $19.8 billion for the nine months ended April 29, 2017 and April 30, 2016, respectively. The balance of the channel partner financing subject to guarantees was $0.9 billion and $1.1 billion as of April 29, 2017 and July 30, 2016, respectively.

- changed (2017-11-21):
[0000858877-17-000019:note_history:11]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $14 million and $6 million for the three months ended October 28, 2017 and October 29, 2016, respectively.
  (was, 2017-05-23, similarity 0.8569):
[0000858877-17-000010:note_history:11]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $10 million and $18 million for the three months ended April 29, 2017 and April 30, 2016, respectively, and was $47 million and $57 million for the nine months ended April 29, 2017 and April 30, 2016, respectively.

- changed (2017-11-21):
[0000858877-17-000019:note_history:12]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 28, 2017 and July 29, 2017, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2017-05-23, similarity 0.9807):
[0000858877-17-000010:note_history:12]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 29, 2017 and July 30, 2016, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2017-11-21):
[0000858877-17-000019:note_history:13]
|  | October 28, 2017 |  | July 29, 2017 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 266 |  |  | $ | 240 |  |
| End user | 65 |  |  | 74 |  |
| Total | $ | 331 |  |  | $ | 314 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (79 | ) |  | $ | (82 | ) |
| End user | (46 | ) |  | (52 | ) |
| Total | $ | (125 | ) |  | $ | (134 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 206 |  |  | $ | 180 |  |
  (was, 2017-05-23, similarity 0.9885):
[0000858877-17-000010:note_history:13]
|  | April 29, 2017 |  | July 30, 2016 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 260 |  |  | $ | 281 |  |
| End user | 83 |  |  | 96 |  |
| Total | $ | 343 |  |  | $ | 377 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (83 | ) |  | $ | (85 | ) |
| End user | (57 | ) |  | (76 | ) |
| Total | $ | (140 | ) |  | $ | (161 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 203 |  |  | $ | 216 |  |

- changed (2017-11-21):
[0000858877-17-000019:note_history:14]
Other Guarantees   The Company’s other guarantee arrangements as of October 28, 2017 and July 29, 2017 that were subject to recognition and disclosure requirements were not material.
  (was, 2017-05-23, similarity 0.9704):
[0000858877-17-000010:note_history:14]
Other Guarantees   The Company’s other guarantee arrangements as of April 29, 2017 and July 30, 2016 that were subject to recognition and disclosure requirements were not material.

- added (2017-11-21):
[0000858877-17-000019:note_history:15]
In fiscal 2014, the Company recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. The Company performs regular assessments of the sufficiency of this liability and reduced the amount by $74 million and $164 million in fiscal 2016 and fiscal 2015, respectively based on updated analyses. During the second quarter of fiscal 2017, the Company further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. In addition, during the second quarter of fiscal 2017, the Company recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of the Company’s products. The liabilities related to the supplier component remediation matters as of October 28, 2017 and July 29, 2017 were $146 million and $174 million, respectively.

- added (2017-11-21):
[0000858877-17-000019:note_history:16]
The Company has been asked to indemnify certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. in federal court in Kansas and Delaware. Sprint alleges that the service provider customers infringed Sprint’s patents by offering VoIP telephone services utilizing products provided by the Company generally in combination with those of other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017 against Time Warner Inc., a jury in Kansas found that Time Warner Cable willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied Time Warner Cable's post-trial motions. Time Warner Cable has appealed. On October 16, 2017, Sprint and Comcast Cable Communications, LLC reached resolution of the claims in Sprint's lawsuit against Comcast and on October 19, 2017, the Kansas court dismissed Sprint's lawsuit. Sprint's trial against Cox Communications, Inc. in Delaware is scheduled for December 7, 2017.

- changed (2017-11-21):
[0000858877-17-000019:note_history:17]
For the remaining cases, the Company believes that the service providers continue to have strong non-infringement and invalidity defenses and arguments and/or that Sprint’s damages claims are inconsistent with prevailing law at trial and/or on appeal. Due to the uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the ultimate outcome of the remaining litigation at this time. Should Sprint prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products. At this time, the Company does not anticipate that its obligations regarding the final outcome of the remaining matters would be material.
  (was, 2017-05-23, similarity 0.816):
[0000858877-17-000010:note_history:17]
The Company believes that the service providers have strong defenses and arguments that the Company's products do not infringe the patents and/or that Sprint's patents are invalid and/or that Sprint’s damages claims are inconsistent with prevailing law. Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. Should Sprint prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products. At this time, the Company does not anticipate that its obligations regarding the final outcome of the matters would be material.

- added (2017-11-21):
[0000858877-17-000019:note_history:18]
On January 15, 2016, Huawei Technologies Co. Ltd. (“Huawei”) filed four patent infringement actions against T-Mobile US, Inc. and T-Mobile USA, Inc. (collectively, “T-Mobile”) in federal court in the Eastern District of Texas. Huawei alleged that T-Mobile’s use of 3GPP standards to implement its 3G and 4G cellular networks infringe 12 patents, now reduced to 10 patents as a result of pre-trial dismissals. Huawei's infringement allegations for some of the patents are based on T-Mobile's use of products provided by the Company in combination with those of other manufacturers. T-Mobile has requested indemnity by the Company with respect to portions of the network that use the Company's equipment. On November 9, 2017, the court continued the trial date to January 2, 2018.

- added (2017-11-21):
[0000858877-17-000019:note_history:19]
The Company believes that the patents are invalid and/or not infringed, and that Huawei’s claims should be rejected for Huawei's failure to comply with its licensing and disclosure obligations to standards setting organizations that issued the relevant standards. If T-Mobile is found to infringe any of the patents warranting an award of damages, the Company believes damages against T-Mobile, as appropriately measured, should be governed by reasonable and nondiscriminatory licensing principles. Due to uncertainty surrounding patent litigation processes, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation and the Company does not anticipate that its obligations, if any, regarding the final outcome of the matters would be material.

- added (2017-11-21):
[0000858877-17-000019:note_history:20]
During the first quarter of fiscal 2018, the Company recorded legal and indemnification settlement charges of $122 million to product cost of sales in relation to these matters.

- changed (2017-11-21):
[0000858877-17-000019:note_history:21]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $250 million for the alleged evasion of import and other taxes, $1.5 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of October 28, 2017. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.
  (was, 2017-05-23, similarity 0.9949):
[0000858877-17-000010:note_history:21]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $255 million for the alleged evasion of import and other taxes, $1.5 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of April 29, 2017. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

- added (2017-11-21):
[0000858877-17-000019:note_history:22]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against the Company in the U.S. District Court for the District of Delaware, accusing the Company's products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. The Company has appealed to the United States Court of Appeals for the Federal Circuit on various grounds. The Company believes it has strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, the Company does not expect it to be material.

- changed (2017-11-21):
[0000858877-17-000019:note_history:23]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, the Company petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art. On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that the Company would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. On June 28, 2016, in light of the PTAB’s decision to review the patent’s validity, the district court issued an order staying the district court case pending the final written decision from the PTAB. On February 22, 2017, following a hearing, the PTAB issued its Final Written Decision that the patent’s claims are unpatentable. SSL has appealed this decision to the Court of Appeals for the Federal Circuit. The Company believes it has strong arguments that the Company's products do not infringe and the patent is invalid. If the Company does not prevail and a jury were to find that the Company's AnyConnect products infringe, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding patent litigation processes, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.
  (was, 2017-05-23, similarity 0.9731):
[0000858877-17-000010:note_history:23]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, Cisco petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art. On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that Cisco would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. On June 28, 2016, in light of the PTAB’s decision to review the patent’s validity, the district court issued an order staying the district court case pending the final written decision from the PTAB. On February 22, 2017, following a hearing, the PTAB issued its Final Written Decision that the patent’s claims are unpatentable. SSL has filed a notice that it intends to appeal this decision to the Court of Appeals for the Federal Circuit. The Company believes it has strong arguments that the Company's products do not infringe and the patent is invalid. If the Company does not prevail and a jury were to find that the Company's AnyConnect products infringe, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding patent litigation processes, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

- added (2017-11-21):
[0000858877-17-000019:note_history:24]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against the Company in U.S. District Court for the Northern District of California, accusing the Company’s 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted the Company's motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against the Company and cancelling a trial which had been set for March 12, 2018.

- added (2017-11-21):
[0000858877-17-000019:note_history:25]
DXC Technology     On August 21, 2015, the Company and Cisco Systems Capital Corporation (“Cisco Capital”) filed an action in Santa Clara County Superior Court for declaratory judgment and breach of contract against HP Inc. (“HP”) regarding a services agreement for management services of a third party’s network. HP prepaid the service agreement through a financing arrangement with Cisco Capital. HP terminated its agreement with the Company, and pursuant to the terms of the service agreement with HP, the Company determined the credit HP was entitled to receive under the agreement. HP disputed the Company’s credit calculation and contended that the Company owes a larger credit to HP than the Company had calculated. In December 2015, the Company filed an amended complaint which dropped the breach of contract claim in light of HP’s continuing payments to Cisco Capital under the financing arrangement. On January 19, 2016, HP Inc. filed a counterclaim for breach of contract simultaneously with its answer to the amended complaint. The court continued the trial date from November 6, 2017 to March 12, 2018. DXC Technology Corporation (“DXC”) reported that it is the party in interest in this matter pursuant to the Separation and Distribution Agreement between the then Hewlett-Packard Co. and Hewlett Packard Enterprise Company (“HPE") and the subsequent Separation and Distribution Agreement between HPE and DXC. On August 30, 2017, the Company and DXC attended a court ordered mediation and, on September 1, 2017, the parties jointly informed the court that they are continuing to discuss the details of a business resolution to the dispute. The Company is unable to reasonably estimate the ultimate outcome of this litigation due to uncertainty surrounding the litigation process. However, the Company does not anticipate that its obligation, if any, regarding the final outcome of the dispute would be material.

- removed (2017-11-21):
[0000858877-17-000010:note_history:26]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology. Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and has consolidated the results of Insieme in its Consolidated Financial Statements. In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

- removed (2017-11-21):
[0000858877-17-000010:note_history:27]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $9 million and $35 million during the three months ended April 29, 2017 and April 30, 2016, respectively, and $41 million and $136 million during the nine months ended April 29, 2017 and April 30, 2016, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting will result in additional compensation expense in future periods. Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $831 million (which includes the $824 million that has been expensed to date), net of forfeitures. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $436 million and $375 million during the nine months ended April 29, 2017 and April 30, 2016, respectively. As of April 29, 2017, the Company paid a total of approximately $825 million pursuant to these two milestone payments.

- removed (2017-11-21):
[0000858877-17-000010:note_history:28]
In the second quarter of fiscal 2014, the Company recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. The Company performs regular assessments of the sufficiency of this liability and reduced the amount by a total of $238 million in fiscal 2016 and fiscal 2015 based on updated analyses. During the second quarter of fiscal 2017, the Company further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program.

- removed (2017-11-21):
[0000858877-17-000010:note_history:29]
In addition, during the second quarter of fiscal 2017, the Company recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of the Company’s products.

- removed (2017-11-21):
[0000858877-17-000010:note_history:30]
The liability related to these matters as of April 29, 2017 and July 30, 2016 was $206 million and $276 million, respectively.

- removed (2017-11-21):
[0000858877-17-000010:note_history:31]
The Company has been asked to provide partial indemnification in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. in Kansas and Delaware. Sprint alleges that the service provider customers infringe Sprint’s patents by offering VoIP telephone services utilizing products provided by the Company and other manufacturers. Sprint seeks monetary damages. Sprint’s Kansas cases were stayed pending resolution of Sprint’s appeal of the Delaware court’s judgment that certain Sprint patents were invalid. The Court of Appeals for the Federal Circuit overturned the Delaware court’s judgment on September 23, 2016. As a result, Sprint’s Kansas cases were set for trial on February 13, 2017 against Time Warner Cable, Inc., et al., and March 6, 2017 against Comcast Cable Communications, LLC, et al., and its Delaware case was reset for trial on November 6, 2017 against Cox Communications, Inc., et al. On March 3, 2017, a jury in Kansas found that Time Warner Cable willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages a portion of which if upheld on appeal could be subject to indemnification by the Company. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages based on the jury's willfulness finding and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. Sprint has since requested $20.3 million in pre-judgment interest. Time Warner Cable has opposed Sprint's request for pre-judgment interest and has filed post-trial motions to set aside the verdict or seek a new trial. Sprint's trial against Comcast was continued until October 30, 2017.

- removed (2017-11-21):
[0000858877-17-000010:note_history:32]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against the Company in the U.S. District Court for the District of Delaware, accusing Cisco products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. On May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million, and the Court will decide whether to award enhanced damages and attorneys’ fees and whether an ongoing royalty should be awarded through the expiration of the patents in 2018. In June 2016, the Company filed post-trial motions. The Company also intends to pursue an appeal to the United States Court of Appeals for the Federal Circuit on various grounds. The Company believes it has strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, the Company does not expect it to be material.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-21):
[0000858877-17-000019:note_history:33]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2018 and fiscal 2017 are each 52-week fiscal years. The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated. The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).
  (was, 2017-05-23, similarity 0.9427):
[0000858877-17-000010:note_history:33]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2017 is a 52-week fiscal year, and fiscal 2016 was a 53-week fiscal year. The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated. The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

- changed (2017-11-21):
[0000858877-17-000019:note_history:34]
The accompanying financial data as of October 28, 2017 and for the three months ended October 28, 2017 and October 29, 2016 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 29, 2017 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 29, 2017.
  (was, 2017-05-23, similarity 0.966):
[0000858877-17-000010:note_history:34]
The accompanying financial data as of April 29, 2017 and for the three and nine months ended April 29, 2017 and April 30, 2016 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 30, 2016 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 30, 2016.

- added (2017-11-21):
[0000858877-17-000019:note_history:35]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 28, 2017; the results of operations and the statements of comprehensive income, the statements of cash flows and equity for the three months ended October 28, 2017 and October 29, 2016, as applicable, have been made. The results of operations for the three months ended October 28, 2017 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2017-11-21):
[0000858877-17-000010:note_history:36]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of April 29, 2017; the results of operations and the statements of comprehensive income for the three and nine months ended April 29, 2017 and April 30, 2016; and the statements of cash flows and equity for the nine months ended April 29, 2017 and April 30, 2016, as applicable, have been made. The results of operations for the three and nine months ended April 29, 2017 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2017-11-21):
[0000858877-17-000019:note_history:37]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. Cisco adopted this accounting standard update beginning the first quarter of fiscal 2018 on a prospective basis. This resulted in an overall decrease in the effective tax rate for the first quarter of fiscal 2018 due to recognition of excess tax benefits from share-based compensation. The application of this accounting standard update did not have a material impact on the Company's Consolidated Financial Statements.

- added (2017-11-21):
[0000858877-17-000019:note_history:38]
Revenue Recognition  In May 2014, the FASB issued a new accounting standard related to revenue recognition. The new standard will supersede nearly all U.S. GAAP on revenue recognition and eliminate industry-specific guidance. The underlying principle of the new standard is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. It also requires increased disclosures including the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

- added (2017-11-21):
[0000858877-17-000019:note_history:39]
The standard allows two methods of adoption: i) retrospectively to each prior period presented (“full retrospective method”), or ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective method"). Cisco will adopt the new standard using the modified retrospective method at the beginning of its first quarter of fiscal 2019.

- added (2017-11-21):
[0000858877-17-000019:note_history:40]
Cisco is on schedule in establishing new accounting policies, implementing systems and processes (including more extensive use of estimates), and internal controls necessary to support the requirements of the new standard. Cisco has completed its preliminary assessment of the financial statement impact of the new standard, as discussed below, and will continue to update that assessment as more information becomes available.

- added (2017-11-21):
[0000858877-17-000019:note_history:41]
The new standard will primarily impact Cisco’s revenue recognition for software arrangements and sales to two-tier distributors. In both areas, the new standard will accelerate the recognition of revenue. The table below details both the current and expected revenue recognition timing in these areas:

- added (2017-11-21):
[0000858877-17-000019:note_history:42]
|  |  | Current Revenue Standard |  | New Revenue Standard |
| Software arrangements: |  |  |  |  |
| Perpetual software licenses |  | Upfront |  | Upfront |
| Term software licenses |  | Ratable |  | Upfront |
| Security software licenses |  | Ratable |  | Ratable |
| Enterprise license agreements |  | Ratable |  | Upfront |
| Software support services |  | Ratable |  | Ratable |
| Software-as-a-service |  | Ratable |  | Ratable |
| Two-tier distribution |  | Sell-Through |  | Sell-In |

- added (2017-11-21):
[0000858877-17-000019:note_history:43]
Cisco expects that the new standard will not have a material impact on total revenue in the year of adoption based on two factors: i) revenue will be accelerated consistent with the changes in timing as indicated in the preceding table, largely offset by ii) the reduction of revenue from software arrangements where revenue was previously deferred in prior periods and recognized ratably over time as required under the current standard. This preliminary assessment is based on the types and number of revenue arrangements currently in place. The exact impact of the new standard will be dependent on facts and circumstances at adoption and could vary from quarter to quarter.

- added (2017-11-21):
[0000858877-17-000019:note_history:44]
In addition to the above revenue recognition timing impacts, the new standard will require incremental contract acquisition costs (such as sales commissions) for customer contracts to be capitalized and amortized over the contract period. Currently, these costs are expensed as incurred.

- added (2017-11-21):
[0000858877-17-000019:note_history:45]
Cisco will be required to record cumulative effect adjustments to retained earnings upon adopting the new standard at the beginning of fiscal 2019. The most significant of these adjustments will be to reduce product deferred revenue and increase retained earnings at the date of adoption to reflect revenue that would have been already recognized under the new standard related to existing arrangements. There will also be an adjustment to increase accounts receivable and reduce inventories related to the changes in revenue recognition on sales to two-tier distributors. Lastly, an adjustment will be recorded to establish an asset and increase retained earnings related to the requirement to capitalize incremental contract acquisition costs for customer contracts.

- added (2017-11-21):
[0000858877-17-000019:note_history:46]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019, and early adoption is permitted. The most significant impact of this accounting standard update for Cisco is that it will require the remeasurement of investments that are not accounted for under the equity method at fair value at the end of each reporting period with the changes recorded to the income statement. While Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements, Cisco expects that this accounting standard update will increase the variability of other income (loss), net.

- changed (2017-11-21):
[0000858877-17-000019:note_history:47]
Leases  In February 2016, the FASB issued an accounting standard update related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2020 on a modified retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.
  (was, 2017-05-23, similarity 0.9668):
[0000858877-17-000010:note_history:47]
Leases  In February 2016, the FASB issued an accounting standard update related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2020 on a modified retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- changed (2017-11-21):
[0000858877-17-000019:note_history:48]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2021 on a modified retrospective basis, and early adoption in fiscal 2020 is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.
  (was, 2017-05-23, similarity 0.9564):
[0000858877-17-000010:note_history:48]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2021 on a modified retrospective basis, and early adoption in fiscal 2020 is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- changed (2017-11-21):
[0000858877-17-000019:note_history:49]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Statements of Cash Flows.
  (was, 2017-05-23, similarity 0.9426):
[0000858877-17-000010:note_history:49]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Statements of Cash Flows.

- changed (2017-11-21):
[0000858877-17-000019:note_history:50]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.
  (was, 2017-05-23, similarity 0.9705):
[0000858877-17-000010:note_history:50]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- changed (2017-11-21):
[0000858877-17-000019:note_history:51]
Restricted Cash in Statement of Cash Flow  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented, and early adoption is permitted. Cisco does not expect that this accounting standard update will have a material impact on its Consolidated Statements of Cash Flows.
  (was, 2017-05-23, similarity 0.9727):
[0000858877-17-000010:note_history:51]
Restricted Cash in Statement of Cash Flow  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented, and early adoption is permitted. The Company does not expect that this accounting standard update will have a material impact on its Consolidated Statements of Cash Flows.

- changed (2017-11-21):
[0000858877-17-000019:note_history:52]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be fact dependent, but Cisco expects that some transactions that were previously accounted for as business combinations or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.
  (was, 2017-05-23, similarity 0.9764):
[0000858877-17-000010:note_history:52]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be fact dependent, but the Company expects that some transactions that were previously accounted for as business combinations or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.

- changed (2017-11-21):
[0000858877-17-000019:note_history:53]
Simplifying the Test for Goodwill Impairment  In January 2017, the FASB issued an accounting standard update that removes Step 2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2021 on a prospective basis, and early adoption is permitted. Cisco does not expect that this accounting standard update will impact its Consolidated Financial Statements.
  (was, 2017-05-23, similarity 0.9763):
[0000858877-17-000010:note_history:53]
Simplifying the Test for Goodwill Impairment  In January 2017, the FASB issued an accounting standard update that removes Step 2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2021 on a prospective basis, and early adoption is permitted. The Company does not expect that this accounting standard update will impact its Consolidated Financial Statements.

- removed (2017-11-21):
[0000858877-17-000010:note_history:54]
Consolidation of Certain Types of Legal Entities  In February 2015, the FASB issued an accounting standard update that changes the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. The accounting standard update became effective for the Company beginning in the first quarter of fiscal 2017. The application of this accounting standard update did not have any impact on the Company's Consolidated Balance Sheet or Statement of Operations upon adoption, but the Company has provided additional disclosures in Note 8 pursuant to this accounting standard update.

- removed (2017-11-21):
[0000858877-17-000010:note_history:55]
Revenue Recognition  In May 2014, the Financial Accounting Standards Board ("FASB") issued an accounting standard update related to revenue from contracts with customers, which, along with amendments issued in 2015 and 2016, will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance. The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. This accounting standard update, as amended, will be effective for the Company beginning in the first quarter of fiscal 2019. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective basis"). Early adoption is permitted, but no earlier than fiscal 2018. The Company expects to adopt this accounting standard update on a modified retrospective basis in the first quarter of fiscal 2019, and it is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- removed (2017-11-21):
[0000858877-17-000010:note_history:56]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- removed (2017-11-21):
[0000858877-17-000010:note_history:57]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. The accounting standard will be effective for the Company beginning the first quarter of fiscal 2018, and early adoption is permitted. The Company does not expect that this accounting standard update will have a material impact on its Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-21):
[0000858877-17-000019:note_history:58]
|  | October 28, 2017 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,748 |  |  | 1.70 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | 5,491 |  |  | 1.25 | % |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 10,239 |  |  |  |  | $ | 7,992 |  |  |  |
  (was, 2017-05-23, similarity 0.8832):
[0000858877-17-000010:note_history:58]
|  | April 29, 2017 |  | July 30, 2016 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 2,248 |  |  | 1.58 | % |  | $ | 4,159 |  |  | 0.97 | % |
| Commercial paper | 2,000 |  |  | 0.88 | % |  | — |  |  | — |  |
| Other notes and borrowings | — |  |  | — |  |  | 1 |  |  | 2.08 | % |
| Total short-term debt | $ | 4,248 |  |  |  |  | $ | 4,160 |  |  |  |

- added (2017-11-21):
[0000858877-17-000019:note_history:59]
The Company has a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes.

- added (2017-11-21):
[0000858877-17-000019:note_history:60]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

- changed (2017-11-21):
[0000858877-17-000019:note_history:61]
|  |  |  | October 28, 2017 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | 1,000 |  |  | 1.98% |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.70% |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.88% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 1.71% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.96% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.85% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.85% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.01% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.28% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.13% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.44% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 30,500 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (130 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 62 |  |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 30,432 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,748 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 25,684 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 30,432 |  |  |  |  | $ | 30,472 |  |  |  |
  (was, 2017-05-23, similarity 0.6789):
[0000858877-17-000010:note_history:61]
|  |  |  | April 29, 2017 |  | July 30, 2016 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 | (1) | $ | — |  |  | — |  | $ | 1,000 |  |  | 1.03% |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1.72% |  | 1,000 |  |  | 1.32% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.51% |  | 900 |  |  | 1.03% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.62% |  | 500 |  |  | 1.23% |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (2) | 500 |  |  | 1.53% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.10% | March 3, 2017 | (1) | — |  |  | — |  | 2,400 |  |  | 0.87% |
| 3.15% | March 14, 2017 | (1) | — |  |  | — |  | 750 |  |  | 1.22% |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.76% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.60% |  | 1,750 |  |  | 1.08% |
| 1.40% | September 20, 2019 | (2) | 1,500 |  |  | 1.48% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.66% |  | 2,500 |  |  | 3.25% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.76% |  | 500 |  |  | 1.24% |
| 1.85% | September 20, 2021 | (2) | 2,000 |  |  | 1.90% |  | — |  |  | — |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.03% |  | 500 |  |  | 1.51% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 | (2) | 750 |  |  | 2.27% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.88% |  | 1,000 |  |  | 1.36% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.19% |  | 500 |  |  | 1.67% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 | (2) | 1,500 |  |  | 2.55% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 30,500 |  |  |  |  | 28,400 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (140 | ) |  |  |  | (137 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 110 |  |  |  |  | 379 |  |  |  |
| Total |  |  | $ | 30,470 |  |  |  |  | $ | 28,642 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 2,248 |  |  |  |  | $ | 4,159 |  |  |  |
| Long-term debt |  |  | 28,222 |  |  |  |  | 24,483 |  |  |  |
| Total |  |  | $ | 30,470 |  |  |  |  | $ | 28,642 |  |  |  |

- changed (2017-11-21):
[0000858877-17-000019:note_history:62]
The Company entered into interest rate swaps in prior periods with an aggregate notional amount of $6.75 billion designated as fair value hedges of certain of its fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate ("LIBOR"). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 11.
  (was, 2017-05-23, similarity 0.9474):
[0000858877-17-000010:note_history:62]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps in prior periods with an aggregate notional amount of $6.8 billion designated as fair value hedges of certain of its fixed-rate senior notes.  In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate ("LIBOR"). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.  For additional information, see Note 11.

- added (2017-11-21):
[0000858877-17-000019:note_history:63]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 28, 2017, the Company was in compliance with all debt covenants.

- changed (2017-11-21):
[0000858877-17-000019:note_history:64]
As of October 28, 2017, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2017-05-23, similarity 0.9627):
[0000858877-17-000010:note_history:64]
As of April 29, 2017, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2017-11-21):
[0000858877-17-000019:note_history:65]
| Fiscal Year | Amount |
| 2018 (remaining nine months) | $ | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 30,500 |  |
  (was, 2017-05-23, similarity 0.9707):
[0000858877-17-000010:note_history:65]
| Fiscal Year | Amount |
| 2017 (remaining three months) | $ | — |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| Thereafter | 11,500 |  |
| Total | $ | 30,500 |  |

- changed (2017-11-21):
[0000858877-17-000019:note_history:66]
These credit agreements require that the Company comply with certain covenants, including that the Company maintains an interest coverage ratio as defined in these agreements. As of October 28, 2017, the Company was in compliance with the required interest coverage ratios and the other covenants, and the Company had not borrowed any funds under these credit facilities.
  (was, 2017-05-23, similarity 0.6236):
[0000858877-17-000010:note_history:66]
These credit agreements require that the Company comply with certain covenants, including that the Company maintains an interest coverage ratio as defined in these agreements. As of April 29, 2017, the Company was in compliance with the required interest coverage ratios and the other covenants, and the Company had not borrowed any funds under these credit facilities.

- removed (2017-11-21):
[0000858877-17-000010:note_history:67]
The effective interest rate on the current portion of long-term debt includes the impact of interest rate swaps, as discussed further in "

- removed (2017-11-21):
[0000858877-17-000010:note_history:68]
." Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements. These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.

- removed (2017-11-21):
[0000858877-17-000010:note_history:69]
Effective March 31, 2017, the Company increased its borrowing capacity under its existing commercial paper program from $3.0 billion to $10.0 billion. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had $2.0 billion and no commercial paper notes outstanding as of April 29, 2017 and July 30, 2016, respectively.

- removed (2017-11-21):
[0000858877-17-000010:note_history:70]
(b)

- removed (2017-11-21):
[0000858877-17-000010:note_history:71]
Long-Term Debt

- removed (2017-11-21):
[0000858877-17-000010:note_history:72]
(1) In March 2017, the Company repaid senior notes with an aggregate principal amount of $4.15 billion upon maturity.

- removed (2017-11-21):
[0000858877-17-000010:note_history:73]
(2) In September 2016, the Company issued senior notes for an aggregate principal amount of $6.25 billion.

- removed (2017-11-21):
[0000858877-17-000010:note_history:74]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging. Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

- removed (2017-11-21):
[0000858877-17-000010:note_history:75]
The senior notes rank at par with the commercial paper notes that have been issued pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 29, 2017, the Company was in compliance with all debt covenants.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-21):
[0000858877-17-000019:note_history:76]
| October 28, 2017 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 20,564 |  |  | $ | — |  |  | $ | (93 | ) |  | $ | 20,471 |  |
| U.S. government agency securities | 1,923 |  |  | — |  |  | (6 | ) |  | 1,917 |  |
| Non-U.S. government and agency securities | 358 |  |  | — |  |  | (1 | ) |  | 357 |  |
| Corporate debt securities | 31,999 |  |  | 162 |  |  | (131 | ) |  | 32,030 |  |
| U.S. agency mortgage-backed securities | 2,095 |  |  | 2 |  |  | (23 | ) |  | 2,074 |  |
| Commercial paper | 1,775 |  |  | — |  |  | — |  |  | 1,775 |  |
| Certificates of deposit | 140 |  |  | — |  |  | — |  |  | 140 |  |
| Total fixed income securities | 58,854 |  |  | 164 |  |  | (254 | ) |  | 58,764 |  |
| Publicly traded equity securities | 1,134 |  |  | 653 |  |  | (6 | ) |  | 1,781 |  |
| Total (1) | $ | 59,988 |  |  | $ | 817 |  |  | $ | (260 | ) |  | $ | 60,545 |  |
  (was, 2017-05-23, similarity 0.9914):
[0000858877-17-000010:note_history:76]
| April 29, 2017 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 20,951 |  |  | $ | 4 |  |  | $ | (67 | ) |  | $ | 20,888 |  |
| U.S. government agency securities | 2,233 |  |  | — |  |  | (6 | ) |  | 2,227 |  |
| Non-U.S. government and agency securities | 721 |  |  | — |  |  | (2 | ) |  | 719 |  |
| Corporate debt securities | 31,649 |  |  | 145 |  |  | (160 | ) |  | 31,634 |  |
| U.S. agency mortgage-backed securities | 2,038 |  |  | 3 |  |  | (18 | ) |  | 2,023 |  |
| Commercial paper | 635 |  |  | — |  |  | — |  |  | 635 |  |
| Certificates of deposit | 26 |  |  | — |  |  | — |  |  | 26 |  |
| Total fixed income securities | 58,253 |  |  | 152 |  |  | (253 | ) |  | 58,152 |  |
| Publicly traded equity securities | 1,177 |  |  | 533 |  |  | (4 | ) |  | 1,706 |  |
| Total (1) | $ | 59,430 |  |  | $ | 685 |  |  | $ | (257 | ) |  | $ | 59,858 |  |

- changed (2017-11-21):
[0000858877-17-000019:note_history:77]
| July 29, 2017 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 19,880 |  |  | $ | 3 |  |  | $ | (60 | ) |  | $ | 19,823 |  |
| U.S. government agency securities | 2,057 |  |  | — |  |  | (5 | ) |  | 2,052 |  |
| Non-U.S. government and agency securities | 389 |  |  | — |  |  | (1 | ) |  | 388 |  |
| Corporate debt securities | 31,626 |  |  | 202 |  |  | (93 | ) |  | 31,735 |  |
| U.S. agency mortgage-backed securities | 2,037 |  |  | 3 |  |  | (17 | ) |  | 2,023 |  |
| Commercial paper | 996 |  |  | — |  |  | — |  |  | 996 |  |
| Certificates of deposit | 60 |  |  | — |  |  | — |  |  | 60 |  |
| Total fixed income securities | 57,045 |  |  | 208 |  |  | (176 | ) |  | 57,077 |  |
| Publicly traded equity securities | 1,180 |  |  | 554 |  |  | (27 | ) |  | 1,707 |  |
| Total (1) | $ | 58,225 |  |  | $ | 762 |  |  | $ | (203 | ) |  | $ | 58,784 |  |
  (was, 2017-05-23, similarity 0.7275):
[0000858877-17-000010:note_history:77]
| July 30, 2016 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 26,473 |  |  | $ | 73 |  |  | $ | (2 | ) |  | $ | 26,544 |  |
| U.S. government agency securities | 2,809 |  |  | 8 |  |  | — |  |  | 2,817 |  |
| Non-U.S. government and agency securities | 1,096 |  |  | 4 |  |  | — |  |  | 1,100 |  |
| Corporate debt securities | 24,044 |  |  | 263 |  |  | (15 | ) |  | 24,292 |  |
| U.S. agency mortgage-backed securities | 1,846 |  |  | 22 |  |  | — |  |  | 1,868 |  |
| Total fixed income securities | 56,268 |  |  | 370 |  |  | (17 | ) |  | 56,621 |  |
| Publicly traded equity securities | 1,211 |  |  | 333 |  |  | (40 | ) |  | 1,504 |  |
| Total (1) | $ | 57,479 |  |  | $ | 703 |  |  | $ | (57 | ) |  | $ | 58,125 |  |

- changed (2017-11-21):
[0000858877-17-000019:note_history:78]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases (sales) were $95 million and $(30) million as of October 28, 2017 and July 29, 2017, respectively.
  (was, 2017-05-23, similarity 0.942):
[0000858877-17-000010:note_history:78]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases were $80 million and $654 million as of April 29, 2017 and July 30, 2016, respectively.

- changed (2017-11-21):
[0000858877-17-000019:note_history:79]
The following table presents the gross realized gains and gross realized losses related to available-for-sale investments (in millions):
  (was, 2017-05-23, similarity 0.951):
[0000858877-17-000010:note_history:79]
The following table presents the gross realized gains and gross realized losses related to the Company’s available-for-sale investments (in millions):

- changed (2017-11-21):
[0000858877-17-000019:note_history:80]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Gross realized gains | $ | 67 |  |  | $ | 30 |  |
| Gross realized losses | (34 | ) |  | (15 | ) |
| Total | $ | 33 |  |  | $ | 15 |  |
  (was, 2017-05-23, similarity 0.6588):
[0000858877-17-000010:note_history:80]
|  | April 29, 2017 |  | July 30, 2016 |
| Equity method investments | $ | 130 |  |  | $ | 174 |  |
| Cost method investments | 820 |  |  | 829 |  |
| Total | $ | 950 |  |  | $ | 1,003 |  |

- changed (2017-11-21):
[0000858877-17-000019:note_history:81]
The following table presents the realized net gains (losses) related to available-for-sale investments by security type (in millions):
  (was, 2017-05-23, similarity 0.9504):
[0000858877-17-000010:note_history:81]
The following table presents the realized net gains (losses) related to the Company’s available-for-sale investments by security type (in millions):

- added (2017-11-21):
[0000858877-17-000019:note_history:82]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 29 |  |  | $ | 5 |  |
| Net gains (losses) on investments in fixed income securities | 4 |  |  | 10 |  |
| Total | $ | 33 |  |  | $ | 15 |  |

- changed (2017-11-21):
[0000858877-17-000019:note_history:83]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at October 28, 2017 and July 29, 2017 (in millions):
  (was, 2017-05-23, similarity 0.9709):
[0000858877-17-000010:note_history:83]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at April 29, 2017 and July 30, 2016 (in millions):

- changed (2017-11-21):
[0000858877-17-000019:note_history:84]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 28, 2017 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 16,719 |  |  | $ | (66 | ) |  | $ | 3,602 |  |  | $ | (27 | ) |  | $ | 20,321 |  |  | $ | (93 | ) |
| U.S. government agency securities | 1,696 |  |  | (4 | ) |  | 222 |  |  | (2 | ) |  | 1,918 |  |  | (6 | ) |
| Non-U.S. government and agency securities | 316 |  |  | (1 | ) |  | 41 |  |  | — |  |  | 357 |  |  | (1 | ) |
| Corporate debt securities | 8,129 |  |  | (45 | ) |  | 4,209 |  |  | (86 | ) |  | 12,338 |  |  | (131 | ) |
| U.S. agency mortgage-backed securities | 1,562 |  |  | (16 | ) |  | 266 |  |  | (7 | ) |  | 1,828 |  |  | (23 | ) |
| Total fixed income securities | 28,422 |  |  | (132 | ) |  | 8,340 |  |  | (122 | ) |  | 36,762 |  |  | (254 | ) |
| Publicly traded equity securities | 54 |  |  | (6 | ) |  | — |  |  | — |  |  | 54 |  |  | (6 | ) |
| Total | $ | 28,476 |  |  | $ | (138 | ) |  | $ | 8,340 |  |  | $ | (122 | ) |  | $ | 36,816 |  |  | $ | (260 | ) |
  (was, 2017-05-23, similarity 0.9733):
[0000858877-17-000010:note_history:84]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 29, 2017 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 17,231 |  |  | $ | (67 | ) |  | $ | 16 |  |  | $ | — |  |  | $ | 17,247 |  |  | $ | (67 | ) |
| U.S. government agency securities | 1,980 |  |  | (6 | ) |  | — |  |  | — |  |  | 1,980 |  |  | (6 | ) |
| Non-U.S. government and agency securities | 607 |  |  | (2 | ) |  | 6 |  |  | — |  |  | 613 |  |  | (2 | ) |
| Corporate debt securities | 11,915 |  |  | (159 | ) |  | 78 |  |  | (1 | ) |  | 11,993 |  |  | (160 | ) |
| U.S. agency mortgage-backed securities | 1,448 |  |  | (18 | ) |  | 4 |  |  | — |  |  | 1,452 |  |  | (18 | ) |
| Total fixed income securities | 33,181 |  |  | (252 | ) |  | 104 |  |  | (1 | ) |  | 33,285 |  |  | (253 | ) |
| Publicly traded equity securities | 50 |  |  | (4 | ) |  | — |  |  | — |  |  | 50 |  |  | (4 | ) |
| Total | $ | 33,231 |  |  | $ | (256 | ) |  | $ | 104 |  |  | $ | (1 | ) |  | $ | 33,335 |  |  | $ | (257 | ) |

- changed (2017-11-21):
[0000858877-17-000019:note_history:85]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2017 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 14,962 |  |  | $ | (55 | ) |  | $ | 771 |  |  | $ | (5 | ) |  | $ | 15,733 |  |  | $ | (60 | ) |
| U.S. government agency securities | 1,791 |  |  | (4 | ) |  | 130 |  |  | (1 | ) |  | 1,921 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 368 |  |  | (1 | ) |  | — |  |  | — |  |  | 368 |  |  | (1 | ) |
| Corporate debt securities | 9,487 |  |  | (92 | ) |  | 101 |  |  | (1 | ) |  | 9,588 |  |  | (93 | ) |
| U.S. agency mortgage-backed securities | 1,485 |  |  | (16 | ) |  | 38 |  |  | (1 | ) |  | 1,523 |  |  | (17 | ) |
| Total fixed income securities | 28,093 |  |  | (168 | ) |  | 1,040 |  |  | (8 | ) |  | 29,133 |  |  | (176 | ) |
| Publicly traded equity securities | 122 |  |  | (27 | ) |  | — |  |  | — |  |  | 122 |  |  | (27 | ) |
| Total | $ | 28,215 |  |  | $ | (195 | ) |  | $ | 1,040 |  |  | $ | (8 | ) |  | $ | 29,255 |  |  | $ | (203 | ) |
  (was, 2017-05-23, similarity 0.8688):
[0000858877-17-000010:note_history:85]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 30, 2016 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 2,414 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |  | $ | 2,414 |  |  | $ | (2 | ) |
| U.S. government agency securities | 144 |  |  | — |  |  | — |  |  | — |  |  | 144 |  |  | — |  |
| Non-U.S. government and agency securities | 61 |  |  | — |  |  | — |  |  | — |  |  | 61 |  |  | — |  |
| Corporate debt securities | 2,499 |  |  | (7 | ) |  | 1,208 |  |  | (8 | ) |  | 3,707 |  |  | (15 | ) |
| U.S. agency mortgage-backed securities | 174 |  |  | — |  |  | — |  |  | — |  |  | 174 |  |  | — |  |
| Total fixed income securities | 5,292 |  |  | (9 | ) |  | 1,208 |  |  | (8 | ) |  | 6,500 |  |  | (17 | ) |
| Publicly traded equity securities | 188 |  |  | (40 | ) |  | — |  |  | — |  |  | 188 |  |  | (40 | ) |
| Total | $ | 5,480 |  |  | $ | (49 | ) |  | $ | 1,208 |  |  | $ | (8 | ) |  | $ | 6,688 |  |  | $ | (57 | ) |

- changed (2017-11-21):
[0000858877-17-000019:note_history:86]
For the three months ended October 28, 2017, the net realized losses related to available-for-sale investments included impairment charges of $26 million. These impairment charges related primarily to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the three months ended October 29, 2016.
  (was, 2017-05-23, similarity 0.6816):
[0000858877-17-000010:note_history:86]
For the three and nine months ended April 29, 2017, the net realized losses related to the Company's available-for-sale investments included impairment charges of $73 million. These impairment charges related primarily to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. For the three and nine months ended April 30, 2016, the net realized losses related to the Company's available-for-sale investments included impairment charges of zero and $3 million, respectively, for fixed income securities.

- changed (2017-11-21):
[0000858877-17-000019:note_history:87]
As of October 28, 2017, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of October 28, 2017, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the three months ended October 28, 2017.
  (was, 2017-05-23, similarity 0.9422):
[0000858877-17-000010:note_history:87]
As of April 29, 2017, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of April 29, 2017, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the nine months ended April 29, 2017.

- added (2017-11-21):
[0000858877-17-000019:note_history:88]
The Company has evaluated its publicly traded equity securities as of October 28, 2017 and has determined that there were no additional other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

- changed (2017-11-21):
[0000858877-17-000019:note_history:89]
The following table summarizes the maturities of the Company’s fixed income securities as of October 28, 2017 (in millions):
  (was, 2017-05-23, similarity 0.9576):
[0000858877-17-000010:note_history:89]
The following table summarizes the maturities of the Company’s fixed income securities as of April 29, 2017 (in millions):

- changed (2017-11-21):
[0000858877-17-000019:note_history:90]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the three months ended October 28, 2017 and October 29, 2016 was $0.5 billion and $1.2 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 28, 2017 and July 29, 2017, the Company had no outstanding securities lending transactions.
  (was, 2017-05-23, similarity 0.9788):
[0000858877-17-000010:note_history:90]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 29, 2017 and April 30, 2016 was $0.8 billion and $0.6 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of April 29, 2017 and July 30, 2016, the Company had no outstanding securities lending transactions.

- changed (2017-11-21):
[0000858877-17-000019:note_history:91]
The carrying value of the investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of October 28, 2017 and July 29, 2017, the amounts are summarized in the following table (in millions):
  (was, 2017-05-23, similarity 0.9597):
[0000858877-17-000010:note_history:91]
The carrying value of the Company’s investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of April 29, 2017 and July 30, 2016, the amounts are summarized in the following table (in millions):

- added (2017-11-21):
[0000858877-17-000019:note_history:92]
|  | October 28, 2017 |  | July 29, 2017 |
| Equity method investments | $ | 108 |  |  | $ | 124 |  |
| Cost method investments | 839 |  |  | 859 |  |
| Total | $ | 947 |  |  | $ | 983 |  |

- changed (2017-11-21):
[0000858877-17-000019:note_history:93]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of October 28, 2017, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.
  (was, 2017-05-23, similarity 0.9897):
[0000858877-17-000010:note_history:93]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of April 29, 2017, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

- changed (2017-11-21):
[0000858877-17-000019:note_history:94]
As of October 28, 2017, the carrying value of investments in privately held companies was $947 million, of which $519 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $213 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.
  (was, 2017-05-23, similarity 0.8393):
[0000858877-17-000010:note_history:94]
As discussed in Note 2, during the first quarter of fiscal 2017, the Company adopted a new accounting standard update related to the consolidation of certain types of legal entities. As of April 29, 2017, the carrying value of the Company's investments in privately held companies was $950 million, of which $547 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $170 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.

- removed (2017-11-21):
[0000858877-17-000010:note_history:95]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2017 |  | April 30, 2016 |  | April 29, 2017 |  | April 30, 2016 |
| Gross realized gains | $ | 43 |  |  | $ | 68 |  |  | $ | 91 |  |  | $ | 119 |  |
| Gross realized losses | (119 | ) |  | (74 | ) |  | (182 | ) |  | (145 | ) |
| Total | $ | (76 | ) |  | $ | (6 | ) |  | $ | (91 | ) |  | $ | (26 | ) |

- removed (2017-11-21):
[0000858877-17-000010:note_history:96]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2017 |  | April 30, 2016 |  | April 29, 2017 |  | April 30, 2016 |
| Net gains (losses) on investments in publicly traded equity securities | $ | (59 | ) |  | $ | 25 |  |  | $ | (50 | ) |  | $ | 18 |  |
| Net gains (losses) on investments in fixed income securities | (17 | ) |  | (31 | ) |  | (41 | ) |  | (44 | ) |
| Total | $ | (76 | ) |  | $ | (6 | ) |  | $ | (91 | ) |  | $ | (26 | ) |

- removed (2017-11-21):
[0000858877-17-000010:note_history:97]
The Company has evaluated its publicly traded equity securities as of April 29, 2017 and has determined that there were no additional other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-21):
[0000858877-17-000019:note_history:98]
|  |  |  | October 28, 2017 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | 1,000 |  |  | 1.98% |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.70% |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.88% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 1.71% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.96% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.85% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.85% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.01% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.28% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.13% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.44% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 30,500 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (130 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 62 |  |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 30,432 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,748 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 25,684 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 30,432 |  |  |  |  | $ | 30,472 |  |  |  |
  (was, 2017-05-23, similarity 0.6789):
[0000858877-17-000010:note_history:98]
|  |  |  | April 29, 2017 |  | July 30, 2016 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 | (1) | $ | — |  |  | — |  | $ | 1,000 |  |  | 1.03% |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1.72% |  | 1,000 |  |  | 1.32% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.51% |  | 900 |  |  | 1.03% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.62% |  | 500 |  |  | 1.23% |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (2) | 500 |  |  | 1.53% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.10% | March 3, 2017 | (1) | — |  |  | — |  | 2,400 |  |  | 0.87% |
| 3.15% | March 14, 2017 | (1) | — |  |  | — |  | 750 |  |  | 1.22% |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.76% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.60% |  | 1,750 |  |  | 1.08% |
| 1.40% | September 20, 2019 | (2) | 1,500 |  |  | 1.48% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.66% |  | 2,500 |  |  | 3.25% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.76% |  | 500 |  |  | 1.24% |
| 1.85% | September 20, 2021 | (2) | 2,000 |  |  | 1.90% |  | — |  |  | — |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.03% |  | 500 |  |  | 1.51% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 | (2) | 750 |  |  | 2.27% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.88% |  | 1,000 |  |  | 1.36% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.19% |  | 500 |  |  | 1.67% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 | (2) | 1,500 |  |  | 2.55% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 30,500 |  |  |  |  | 28,400 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (140 | ) |  |  |  | (137 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 110 |  |  |  |  | 379 |  |  |  |
| Total |  |  | $ | 30,470 |  |  |  |  | $ | 28,642 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 2,248 |  |  |  |  | $ | 4,159 |  |  |  |
| Long-term debt |  |  | 28,222 |  |  |  |  | 24,483 |  |  |  |
| Total |  |  | $ | 30,470 |  |  |  |  | $ | 28,642 |  |  |  |

- removed (2017-11-21):
[0000858877-17-000010:note_history:99]
(1) In March 2017, the Company repaid senior notes with an aggregate principal amount of $4.15 billion upon maturity.

- removed (2017-11-21):
[0000858877-17-000010:note_history:100]
(2) In September 2016, the Company issued senior notes for an aggregate principal amount of $6.25 billion.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-21):
[0000858877-17-000019:note_history:101]
As of October 28, 2017, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2017-05-23, similarity 0.9627):
[0000858877-17-000010:note_history:101]
As of April 29, 2017, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2017-11-21):
[0000858877-17-000019:note_history:102]
| Fiscal Year | Amount |
| 2018 (remaining nine months) | $ | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 30,500 |  |
  (was, 2017-05-23, similarity 0.9707):
[0000858877-17-000010:note_history:102]
| Fiscal Year | Amount |
| 2017 (remaining three months) | $ | — |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| Thereafter | 11,500 |  |
| Total | $ | 30,500 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-21):
[0000858877-17-000019:note_history:103]
|  | October 28, 2017 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,748 |  |  | 1.70 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | 5,491 |  |  | 1.25 | % |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 10,239 |  |  |  |  | $ | 7,992 |  |  |  |
  (was, 2017-05-23, similarity 0.8832):
[0000858877-17-000010:note_history:103]
|  | April 29, 2017 |  | July 30, 2016 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 2,248 |  |  | 1.58 | % |  | $ | 4,159 |  |  | 0.97 | % |
| Commercial paper | 2,000 |  |  | 0.88 | % |  | — |  |  | — |  |
| Other notes and borrowings | — |  |  | — |  |  | 1 |  |  | 2.08 | % |
| Total short-term debt | $ | 4,248 |  |  |  |  | $ | 4,160 |  |  |  |
