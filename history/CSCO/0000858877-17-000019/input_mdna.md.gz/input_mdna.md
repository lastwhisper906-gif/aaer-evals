# CSCO MD&A — 0000858877-17-000019


## mdna

[0000858877-17-000019:mdna:1]
[same as prior period, unchanged from 0000858877-17-000010:mdna:1]

[0000858877-17-000019:mdna:2]
[same as prior period, unchanged from 0000858877-17-000010:mdna:2]

[0000858877-17-000019:mdna:3]
[same as prior period, unchanged from 0000858877-17-000010:mdna:3]

[0000858877-17-000019:mdna:4]
Cisco designs and sells a broad range of technologies that have been powering the Internet since 1984. Across networking, security, collaboration and the cloud, our evolving intent-based technologies are constantly learning and adapting to provide customers with a highly secure, intelligent platform for their digital business.

[0000858877-17-000019:mdna:5]
[same as prior period, unchanged from 0000858877-17-000010:mdna:5]

[0000858877-17-000019:mdna:6]
|  | Three Months Ended |  |
|  | October 28, 2017 |  | October 29, 2016 |  | Variance |  |
| Revenue | $ | 12,136 |  |  | $ | 12,352 |  |  | (2 | )% |  |
| Gross margin percentage | 61.2 | % |  | 63.8 | % |  | (2.6 | ) | pts |
| Research and development | $ | 1,567 |  |  | $ | 1,545 |  |  | 1 | % |  |
| Sales and marketing | $ | 2,334 |  |  | $ | 2,418 |  |  | (3 | )% |  |
| General and administrative | $ | 557 |  |  | $ | 555 |  |  | — | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,458 |  |  | $ | 4,518 |  |  | (1 | )% |  |
| Total as a percentage of revenue | 36.7 | % |  | 36.6 | % |  | 0.1 |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 61 |  |  | $ | 78 |  |  | (22 | )% |  |
| Restructuring and other charges included in operating expenses | $ | 152 |  |  | $ | 411 |  |  | (63 | )% |  |
| Operating income as a percentage of revenue | 22.7 | % |  | 23.3 | % |  | (0.6 | ) | pts |
| Income tax percentage | 19.2 | % |  | 21.4 | % |  | (2.2 | ) | pts |
| Net income | $ | 2,394 |  |  | $ | 2,322 |  |  | 3 | % |  |
| Net income as a percentage of revenue | 19.7 | % |  | 18.8 | % |  | 0.9 |  | pts |
| Earnings per share—diluted | $ | 0.48 |  |  | $ | 0.46 |  |  | 4 | % |  |

[0000858877-17-000019:mdna:7]
[same as prior period, unchanged from 0000858877-17-000010:mdna:8]

[0000858877-17-000019:mdna:8]
[same as prior period, unchanged from 0000858877-17-000010:mdna:9]

[0000858877-17-000019:mdna:9]
[same as prior period, unchanged from 0000858877-17-000010:mdna:10]

[0000858877-17-000019:mdna:10]
Three Months Ended October 28, 2017 Compared with Three Months Ended October 29, 2016

[0000858877-17-000019:mdna:11]
In the first quarter of fiscal 2018, we delivered solid financial results including strong operating cash flows. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. We continue to operate in a challenging and highly competitive environment, which has negatively impacted certain of our offerings within our Infrastructure Platforms product category. We continued to see weakness in the service provider market and we expect ongoing uncertainty in that area. In addition, we continued to see weakness in emerging countries in the aggregate.  We experienced solid revenue growth in Security and Applications, and we continued to make progress in the transition of our business model to increased software and subscriptions which is part of our strategy. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-17-000019:mdna:12]
Total revenue decreased by 2% compared with the first quarter of fiscal 2017. Within total revenue, product revenue decreased 3% while service revenue increased by 1%. Total gross margin decreased by 2.6 percentage points, driven by unfavorable impacts from pricing, lower productivity benefits driven by an increase in the cost of certain memory components and the $122 million legal and indemnification settlement charge. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 0.1 percentage points. Operating income as a percentage of revenue decreased by 0.6 percentage points. Diluted earnings per share increased by 4%, driven by a 3% increase in net income.

[0000858877-17-000019:mdna:13]
In terms of our geographic segments, revenue from the Americas decreased $93 million, driven in large part by lower product revenue in the Unites States. EMEA revenue decreased by $104 million, led by a product revenue decline in the United Kingdom. Revenue in our APJC segment decreased by $19 million, led by a product revenue decline in Japan. The “BRICM” countries experienced a product revenue decline of 2% in the aggregate, driven by declines in the emerging countries of Mexico and China of 26% and 2%, respectively, partially offset by increased product revenue in Brazil, Russia and India of 29%, 6% and 2%, respectively.

[0000858877-17-000019:mdna:14]
From a customer market standpoint, we experienced product revenue declines in the service provider, enterprise and public sector markets, partially offset by product revenue growth in the commercial market.

[0000858877-17-000019:mdna:15]
From a product category perspective, product revenue decreased 3%, led by a 4% product revenue decrease in our Infrastructure Platforms. The vast majority of the decrease in Infrastructure Platforms revenue was driven by a decrease in revenue from routing products. We experienced solid product revenue growth in Security and Applications, which grew by 8% and 6%, respectively.

[0000858877-17-000019:mdna:16]
[same as prior period, unchanged from 0000858877-17-000010:mdna:17]

[0000858877-17-000019:mdna:17]
[same as prior period, unchanged from 0000858877-17-000010:mdna:18]

[0000858877-17-000019:mdna:18]
Strategy and Priorities

[0000858877-17-000019:mdna:19]
As our customers add billions of new connections to their enterprises, we believe the network is becoming more critical than ever.  We believe that our customers are looking for intelligent networks that provide meaningful business value through automation, security, and analytics. Our vision is to deliver a highly secure, intelligent, platform for digital businesses. Our strategic priorities include accelerating our pace of innovation, increasing the value of the network, and delivering technology the way our customers want to consume it.

[0000858877-17-000019:mdna:20]
For additional discussion of our strategy and priorities, see Item 1. Business in our Annual Report on Form 10-K for the year ended July 29, 2017.

[0000858877-17-000019:mdna:21]
[same as prior period, unchanged from 0000858877-17-000010:mdna:25]

[0000858877-17-000019:mdna:22]
The following is a summary of our other key financial measures for the first quarter of fiscal 2018 (in millions, except annualized inventory turns):

[0000858877-17-000019:mdna:23]
|  |  | October 28, 2017 |  | July 29, 2017 |
| Cash and cash equivalents and investments |  | $ | 71,588 |  |  | $ | 70,492 |  |
| Deferred revenue |  | $ | 18,565 |  |  | $ | 18,494 |  |
| Inventories |  | $ | 1,693 |  |  | $ | 1,616 |  |
| Annualized inventory turns |  | 11.4 |  |  | 12.3 |  |

[0000858877-17-000019:mdna:24]
|  |  | Three Months Ended |
|  |  | October 28, 2017 |  | October 29, 2016 |
| Cash provided by operating activities |  | $ | 3,080 |  |  | $ | 2,730 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 1,620 |  |  | $ | 1,001 |  |
| Dividends |  | $ | 1,436 |  |  | $ | 1,308 |  |

[0000858877-17-000019:mdna:25]
[same as prior period, unchanged from 0000858877-17-000010:mdna:32]

[0000858877-17-000019:mdna:26]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements in our Annual Report on Form 10-K for the year ended July 29, 2017, as updated as applicable in Note 2 to the Consolidated Financial Statements herein, describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-17-000019:mdna:27]
[same as prior period, unchanged from 0000858877-17-000010:mdna:34]

[0000858877-17-000019:mdna:28]
[same as prior period, unchanged from 0000858877-17-000010:mdna:35]

[0000858877-17-000019:mdna:29]
[same as prior period, unchanged from 0000858877-17-000010:mdna:36]

[0000858877-17-000019:mdna:30]
[same as prior period, unchanged from 0000858877-17-000010:mdna:37]

[0000858877-17-000019:mdna:31]
[same as prior period, unchanged from 0000858877-17-000010:mdna:38]

[0000858877-17-000019:mdna:32]
[same as prior period, unchanged from 0000858877-17-000010:mdna:39]

[0000858877-17-000019:mdna:33]
[same as prior period, unchanged from 0000858877-17-000010:mdna:29]

[0000858877-17-000019:mdna:34]
[same as prior period, unchanged from 0000858877-17-000010:mdna:30]

[0000858877-17-000019:mdna:35]
[same as prior period, unchanged from 0000858877-17-000010:mdna:31]

[0000858877-17-000019:mdna:36]
In instances where final acceptance of the product, system, or solution is specified by the customer, revenue is deferred until all acceptance criteria have been met. When a sale involves multiple deliverables, such as sales of products that include services, the multiple deliverables are evaluated to determine the unit of accounting, and the entire fee from the arrangement is allocated to each unit of accounting based on the relative selling price. Revenue is recognized when the revenue recognition criteria for each unit of accounting are met.  For hosting arrangements, we recognize revenue ratably over the hosting period, while usage revenue is recognized based on utilization. Software subscription revenue is deferred and recognized ratably over the subscription term upon delivery of the first product and commencement of the term.

[0000858877-17-000019:mdna:37]
[same as prior period, unchanged from 0000858877-17-000010:mdna:41]

[0000858877-17-000019:mdna:38]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during the first quarter of fiscal 2018, nor do we currently expect a material impact in the next 12 months on our revenue recognition due to any changes in our VSOE, TPE, or ESP.

[0000858877-17-000019:mdna:39]
[same as prior period, unchanged from 0000858877-17-000010:mdna:46]

[0000858877-17-000019:mdna:40]
[same as prior period, unchanged from 0000858877-17-000010:mdna:47]

[0000858877-17-000019:mdna:41]
[same as prior period, unchanged from 0000858877-17-000010:mdna:48]

[0000858877-17-000019:mdna:42]
|  |  | October 28, 2017 |  | July 29, 2017 |
| Allowance for doubtful accounts |  | $ | 193 |  |  | $ | 211 |  |
| Percentage of gross accounts receivable |  | 4.4 | % |  | 3.9 | % |
| Allowance for credit loss—lease receivables |  | $ | 160 |  |  | $ | 162 |  |
| Percentage of gross lease receivables(1) |  | 5.3 | % |  | 5.5 | % |
| Allowance for credit loss—loan receivables |  | $ | 106 |  |  | $ | 103 |  |
| Percentage of gross loan receivables |  | 2.2 | % |  | 2.3 | % |

[0000858877-17-000019:mdna:43]
[same as prior period, unchanged from 0000858877-17-000010:mdna:50]

[0000858877-17-000019:mdna:44]
[same as prior period, unchanged from 0000858877-17-000010:mdna:44]

[0000858877-17-000019:mdna:45]
[same as prior period, unchanged from 0000858877-17-000010:mdna:45]

[0000858877-17-000019:mdna:46]
[same as prior period, unchanged from 0000858877-17-000010:mdna:51]

[0000858877-17-000019:mdna:47]
[same as prior period, unchanged from 0000858877-17-000010:mdna:52]

[0000858877-17-000019:mdna:48]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of October 28, 2017 and July 29, 2017 was $121 million and $122 million, respectively, and was recorded as a reduction of our accounts receivable and revenue. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-17-000019:mdna:49]
[same as prior period, unchanged from 0000858877-17-000010:mdna:54]

[0000858877-17-000019:mdna:50]
[same as prior period, unchanged from 0000858877-17-000010:mdna:55]

[0000858877-17-000019:mdna:51]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 28, 2017, the liability for these purchase commitments was $161 million, compared with $162 million as of July 29, 2017, and was included in other current liabilities.

[0000858877-17-000019:mdna:52]
Our provision for inventory was $15 million and $12 million for the first quarter of fiscal 2018 and 2017, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $21 million and $30 million for the first quarter of fiscal 2018 and 2017, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence, particularly in light of current macroeconomic uncertainties and conditions and the resulting potential for changes in future demand forecast.

[0000858877-17-000019:mdna:53]
Loss Contingencies and Product Warranties

[0000858877-17-000019:mdna:54]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-17-000019:mdna:55]
49

[0000858877-17-000019:mdna:56]
[same as prior period, unchanged from 0000858877-17-000010:mdna:57]

[0000858877-17-000019:mdna:57]
[same as prior period, unchanged from 0000858877-17-000010:mdna:58]

[0000858877-17-000019:mdna:58]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-17-000019:mdna:59]
In fiscal 2014, we recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. We perform regular assessments of the sufficiency of this liability and reduced the amount by $74 million and $164 million in fiscal 2016 and fiscal 2015, respectively based on updated analyses.  During the second quarter of fiscal 2017, we further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. In addition, during the second quarter of fiscal 2017, we recorded a $125 million charge to product cost of sales related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of our products.  The liabilities related to the supplier component remediation matters as of October 28, 2017 and July 29, 2017 was $146 million and $174 million, respectively.

[0000858877-17-000019:mdna:60]
[same as prior period, unchanged from 0000858877-17-000010:mdna:66]

[0000858877-17-000019:mdna:61]
[same as prior period, unchanged from 0000858877-17-000010:mdna:67]

[0000858877-17-000019:mdna:62]
[same as prior period, unchanged from 0000858877-17-000010:mdna:68]

[0000858877-17-000019:mdna:63]
[same as prior period, unchanged from 0000858877-17-000010:mdna:72]

[0000858877-17-000019:mdna:64]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $60.5 billion as of October 28, 2017, compared with $58.8 billion as of July 29, 2017. Our fixed income investment portfolio as of October 28, 2017 consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-17-000019:mdna:65]
[same as prior period, unchanged from 0000858877-17-000010:mdna:74]

[0000858877-17-000019:mdna:66]
[same as prior period, unchanged from 0000858877-17-000010:mdna:75]

[0000858877-17-000019:mdna:67]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of October 28, 2017. Level 3 assets do not represent a significant portion of our total assets measured at fair value on a recurring basis as of October 28, 2017 and July 29, 2017.

[0000858877-17-000019:mdna:68]
[same as prior period, unchanged from 0000858877-17-000010:mdna:70]

[0000858877-17-000019:mdna:69]
[same as prior period, unchanged from 0000858877-17-000010:mdna:71]

[0000858877-17-000019:mdna:70]
[same as prior period, unchanged from 0000858877-17-000010:mdna:77]

[0000858877-17-000019:mdna:71]
[same as prior period, unchanged from 0000858877-17-000010:mdna:78]

[0000858877-17-000019:mdna:72]
[same as prior period, unchanged from 0000858877-17-000010:mdna:79]

[0000858877-17-000019:mdna:73]
[same as prior period, unchanged from 0000858877-17-000010:mdna:80]

[0000858877-17-000019:mdna:74]
We also have investments in privately held companies, some of which are in the startup or development stages. As of October 28, 2017, our investments in privately held companies were $947 million, compared with $983 million as of July 29, 2017, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize.

[0000858877-17-000019:mdna:75]
[same as prior period, unchanged from 0000858877-17-000010:mdna:84]

[0000858877-17-000019:mdna:76]
[same as prior period, unchanged from 0000858877-17-000010:mdna:85]

[0000858877-17-000019:mdna:77]
The goodwill recorded in the Consolidated Balance Sheets as of October 28, 2017 and July 29, 2017 was $30.2 billion and $29.8 billion, respectively. In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first quarters of fiscal 2018 and 2017.

[0000858877-17-000019:mdna:78]
[same as prior period, unchanged from 0000858877-17-000010:mdna:87]

[0000858877-17-000019:mdna:79]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts.

[0000858877-17-000019:mdna:80]
51

[0000858877-17-000019:mdna:81]
[same as prior period, unchanged from 0000858877-17-000010:mdna:82]

[0000858877-17-000019:mdna:82]
[same as prior period, unchanged from 0000858877-17-000010:mdna:83]

[0000858877-17-000019:mdna:83]
There were no impairment charges related to purchased intangible assets for the first quarter of fiscal 2018, and there were $42 million of such impairment charges for the first quarter of fiscal 2017. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-17-000019:mdna:84]
[same as prior period, unchanged from 0000858877-17-000010:mdna:89]

[0000858877-17-000019:mdna:85]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 19.2% and 21.4% in the first quarter of fiscal 2018 and 2017, respectively.

[0000858877-17-000019:mdna:86]
[same as prior period, unchanged from 0000858877-17-000010:mdna:91]

[0000858877-17-000019:mdna:87]
[same as prior period, unchanged from 0000858877-17-000010:mdna:92]

[0000858877-17-000019:mdna:88]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to domestic manufacturing deduction laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our intercompany R&D cost-sharing arrangement and legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including possible changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, or the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 35 countries, including the United States, has made changes to numerous long-standing tax principles. There can be no assurance that these changes, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-17-000019:mdna:89]
[same as prior period, unchanged from 0000858877-17-000010:mdna:93]

[0000858877-17-000019:mdna:90]
[same as prior period, unchanged from 0000858877-17-000010:mdna:94]

[0000858877-17-000019:mdna:91]
[same as prior period, unchanged from 0000858877-17-000010:mdna:99]

[0000858877-17-000019:mdna:92]
[same as prior period, unchanged from 0000858877-17-000010:mdna:100]

[0000858877-17-000019:mdna:93]
[same as prior period, unchanged from 0000858877-17-000010:mdna:101]

[0000858877-17-000019:mdna:94]
|  |  | Three Months Ended |
|  |  | October 28, 2017 |  | October 29, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,054 |  |  | $ | 9,302 |  |  | $ | (248 | ) |  | (3 | )% |
| Percentage of revenue |  | 74.6 | % |  | 75.3 | % |  |  |  |  |  |  |
| Service |  | 3,082 |  |  | 3,050 |  |  | 32 |  |  | 1 | % |
| Percentage of revenue |  | 25.4 | % |  | 24.7 | % |  |  |  |  |  |  |
| Total |  | $ | 12,136 |  |  | $ | 12,352 |  |  | $ | (216 | ) |  | (2 | )% |

[0000858877-17-000019:mdna:95]
[same as prior period, unchanged from 0000858877-17-000010:mdna:103]

[0000858877-17-000019:mdna:96]
|  |  | Three Months Ended |
|  |  | October 28, 2017 |  | October 29, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,350 |  |  | $ | 7,443 |  |  | $ | (93 | ) |  | (1 | )% |
| Percentage of revenue |  | 60.5 | % |  | 60.3 | % |  |  |  |  |
| EMEA |  | 2,909 |  |  | 3,013 |  |  | (104 | ) |  | (3 | )% |
| Percentage of revenue |  | 24.0 | % |  | 24.4 | % |  |  |  |  |
| APJC |  | 1,877 |  |  | 1,896 |  |  | (19 | ) |  | (1 | )% |
| Percentage of revenue |  | 15.5 | % |  | 15.3 | % |  |  |  |  |
| Total |  | $ | 12,136 |  |  | $ | 12,352 |  |  | $ | (216 | ) |  | (2 | )% |

[0000858877-17-000019:mdna:97]
Three Months Ended October 28, 2017 Compared with Three Months Ended October 29, 2016

[0000858877-17-000019:mdna:98]
Total revenue decreased by 2%. Product revenue decreased by 3%, while service revenue increased by 1%. The decrease in total revenue reflected declines across our three geographic segments. The emerging countries of BRICM, in the aggregate, experienced a 2% product revenue decline, with declines in Mexico and China partially offset by increases in the other three BRICM countries.

[0000858877-17-000019:mdna:99]
[same as prior period, unchanged from 0000858877-17-000010:mdna:108]

[0000858877-17-000019:mdna:100]
[same as prior period, unchanged from 0000858877-17-000010:mdna:97]

[0000858877-17-000019:mdna:101]
[same as prior period, unchanged from 0000858877-17-000010:mdna:98]

[0000858877-17-000019:mdna:102]
[same as prior period, unchanged from 0000858877-17-000010:mdna:114]

[0000858877-17-000019:mdna:103]
[same as prior period, unchanged from 0000858877-17-000010:mdna:115]

[0000858877-17-000019:mdna:104]
|  |  | Three Months Ended |
|  |  | October 28, 2017 |  | October 29, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,392 |  |  | $ | 5,480 |  |  | $ | (88 | ) |  | (2 | )% |
| Percentage of product revenue |  | 59.6 | % |  | 58.9 | % |  |  |  |  |
| EMEA |  | 2,239 |  |  | 2,364 |  |  | (125 | ) |  | (5 | )% |
| Percentage of product revenue |  | 24.7 | % |  | 25.4 | % |  |  |  |  |
| APJC |  | 1,423 |  |  | 1,458 |  |  | (35 | ) |  | (2 | )% |
| Percentage of product revenue |  | 15.7 | % |  | 15.7 | % |  |  |  |  |
| Total |  | $ | 9,054 |  |  | $ | 9,302 |  |  | $ | (248 | ) |  | (3 | )% |

[0000858877-17-000019:mdna:105]
Three Months Ended October 28, 2017 Compared with Three Months Ended October 29, 2016

[0000858877-17-000019:mdna:106]
[same as prior period, unchanged from 0000858877-17-000010:mdna:118]

[0000858877-17-000019:mdna:107]
The 2% decrease in product revenue in the Americas segment was driven by a decline in the service provider market and, to a lesser extent, declines in the enterprise and public sector markets, partially offset by solid growth in the commercial market. The product revenue decline in the public sector market was due primarily to lower sales to the U.S. federal government and to state and local governments. From a country perspective, product revenue decreased by 2% in the United States, 26% in Mexico and 2% in Canada, partially offset by an increase in product revenue of 29% in Brazil.

[0000858877-17-000019:mdna:108]
[same as prior period, unchanged from 0000858877-17-000010:mdna:125]

[0000858877-17-000019:mdna:109]
Product revenue in the EMEA segment decreased by 5%, led by declines in the service provider and enterprise markets and, to a lesser extent, declines in the public sector and commercial markets. Product revenue from emerging countries within EMEA and product revenue for the remainder of the EMEA segment each decreased by 5%.

[0000858877-17-000019:mdna:110]
[same as prior period, unchanged from 0000858877-17-000010:mdna:130]

[0000858877-17-000019:mdna:111]
Product revenue in the APJC segment decreased by 2%.  The product revenue decrease was led by a decline in the service provider market, partially offset by solid product revenue growth in the commercial market and, to a lesser extent, the public sector and enterprise markets. From a country perspective, product revenue decreased by 9% in Japan, 4% in Australia and 2% in China, while product revenue increased by 2% in India.

[0000858877-17-000019:mdna:112]
[same as prior period, unchanged from 0000858877-17-000010:mdna:109]

[0000858877-17-000019:mdna:113]
[same as prior period, unchanged from 0000858877-17-000010:mdna:110]

[0000858877-17-000019:mdna:114]
[same as prior period, unchanged from 0000858877-17-000010:mdna:111]

[0000858877-17-000019:mdna:115]
[same as prior period, unchanged from 0000858877-17-000010:mdna:138]

[0000858877-17-000019:mdna:116]
In addition to the primary view on a geographic basis, we also prepare financial information related to groups of similar products and customer markets for various purposes. Effective in the first quarter of fiscal 2018, we began reporting our product revenue in the following categories: Infrastructure Platforms, Applications, Security, and Other Products. This change better aligns our product categories with our evolving business model. Prior period amounts have been reclassified to conform to the current period’s presentation.

[0000858877-17-000019:mdna:117]
[same as prior period, unchanged from 0000858877-17-000010:mdna:140]

[0000858877-17-000019:mdna:118]
|  |  | Three Months Ended |
|  |  | October 28, 2017 |  | October 29, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 6,970 |  |  | $ | 7,273 |  |  | $ | (303 | ) |  | (4 | )% |
| Applications |  | 1,203 |  |  | 1,136 |  |  | 67 |  |  | 6 | % |
| Security |  | 585 |  |  | 540 |  |  | 45 |  |  | 8 | % |
| Other Products |  | 296 |  |  | 353 |  |  | (57 | ) |  | (16 | )% |
| Total |  | $ | 9,054 |  |  | $ | 9,302 |  |  | $ | (248 | ) |  | (3 | )% |

[0000858877-17-000019:mdna:119]
Three Months Ended October 28, 2017 Compared with Three Months Ended October 29, 2016

[0000858877-17-000019:mdna:120]
Infrastructure Platforms

[0000858877-17-000019:mdna:121]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center.  The Infrastructure Platforms product category decreased by 4%, or $303 million, with the vast majority of the decrease driven by lower revenue from routing products. The decrease in routing revenue was driven by weakness in the service provider market and a slowdown in enterprise routing.  Our switching revenue decreased slightly but we saw solid momentum in campus switching with our intent-based networking Catalyst 9000 Series.  Within switching, we experienced an increase in sales of data center switches, driven by strength in our Application Centric Infrastructure (ACI) portfolio.  We experienced solid revenue growth from wireless products and our hyperconverged data center offering, HyperFlex.

[0000858877-17-000019:mdna:122]
Applications

[0000858877-17-000019:mdna:123]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as IoT and analytics software offerings from AppDynamics and Jasper.  Revenue in our Applications product category increased by 6% or $67 million. Our revenue performance reflects a modest revenue increase from collaboration offerings, with analytics from our fiscal 2017 acquisition of AppDynamics driving the majority of the increase.  We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Applications product category.

[0000858877-17-000019:mdna:124]
[same as prior period, unchanged from 0000858877-17-000010:mdna:175]

[0000858877-17-000019:mdna:125]
Revenue in our Security product category increased 8%, or $45 million, driven by higher sales of unified threat management, advanced threat security and web security products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Security product category.

[0000858877-17-000019:mdna:126]
[same as prior period, unchanged from 0000858877-17-000010:mdna:185]

[0000858877-17-000019:mdna:127]
The decrease in revenue from our Other Products category of 16%, or $57 million, was driven by a decrease in revenue from Service Provider Video software and solutions.

[0000858877-17-000019:mdna:128]
[same as prior period, unchanged from 0000858877-17-000010:mdna:123]

[0000858877-17-000019:mdna:129]
[same as prior period, unchanged from 0000858877-17-000010:mdna:124]

[0000858877-17-000019:mdna:130]
[same as prior period, unchanged from 0000858877-17-000010:mdna:190]

[0000858877-17-000019:mdna:131]
[same as prior period, unchanged from 0000858877-17-000010:mdna:191]

[0000858877-17-000019:mdna:132]
|  |  | Three Months Ended |
|  |  | October 28, 2017 |  | October 29, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,958 |  |  | $ | 1,963 |  |  | $ | (5 | ) |  | — | % |
| Percentage of service revenue |  | 63.5 | % |  | 64.4 | % |  |  |  |  |
| EMEA |  | 670 |  |  | 649 |  |  | 21 |  |  | 3 | % |
| Percentage of service revenue |  | 21.8 | % |  | 21.3 | % |  |  |  |  |
| APJC |  | 454 |  |  | 438 |  |  | 16 |  |  | 4 | % |
| Percentage of service revenue |  | 14.7 | % |  | 14.3 | % |  |  |  |  |
| Total |  | $ | 3,082 |  |  | $ | 3,050 |  |  | $ | 32 |  |  | 1 | % |

[0000858877-17-000019:mdna:133]
Three Months Ended October 28, 2017 Compared with Three Months Ended October 29, 2016

[0000858877-17-000019:mdna:134]
Service revenue increased 1%.  Technical support services revenue increased by 1% and advanced services revenue increased by 2%. Technical support services revenue increased in our APJC and EMEA segments and was flat in our Americas segment. The increase in technical support services revenue was driven by an increase in software and solution support offerings. Advanced services revenue, which relates to professional services for specific customer network needs, had solid revenue growth in our EMEA and APJC segments and declined in our Americas segment.

[0000858877-17-000019:mdna:135]
[same as prior period, unchanged from 0000858877-17-000010:mdna:199]

[0000858877-17-000019:mdna:136]
[same as prior period, unchanged from 0000858877-17-000010:mdna:200]

[0000858877-17-000019:mdna:137]
|  |  | Three Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |
|  |  | October 28, 2017 |  | October 29, 2016 |  | October 28, 2017 |  | October 29, 2016 |
| Gross margin: |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,439 |  |  | $ | 5,899 |  |  | 60.1 | % |  | 63.4 | % |
| Service |  | 1,988 |  |  | 1,985 |  |  | 64.5 | % |  | 65.1 | % |
| Total |  | $ | 7,427 |  |  | $ | 7,884 |  |  | 61.2 | % |  | 63.8 | % |

[0000858877-17-000019:mdna:138]
[same as prior period, unchanged from 0000858877-17-000010:mdna:136]

[0000858877-17-000019:mdna:139]
[same as prior period, unchanged from 0000858877-17-000010:mdna:137]

[0000858877-17-000019:mdna:140]
[same as prior period, unchanged from 0000858877-17-000010:mdna:202]

[0000858877-17-000019:mdna:141]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the first quarter of fiscal 2018 as compared with the corresponding prior year period:

[0000858877-17-000019:mdna:142]
|  |  | Product Gross Margin Percentage |
| Fiscal 2017 |  | 63.4 | % |
| Product pricing |  | (2.4 | )% |
| Legal and indemnification settlements |  | (1.3 | )% |
| Amortization of purchased intangibles |  | (0.3 | )% |
| Mix of products sold |  | (0.1 | )% |
| Productivity (1) |  | 0.6 | % |
| Other |  | 0.2 | % |
| Fiscal 2018 |  | 60.1 | % |

[0000858877-17-000019:mdna:143]
[same as prior period, unchanged from 0000858877-17-000010:mdna:205]

[0000858877-17-000019:mdna:144]
Three Months Ended October 28, 2017 Compared with Three Months Ended October 29, 2016

[0000858877-17-000019:mdna:145]
Product gross margin decreased by 3.3 percentage points due largely to unfavorable impacts from product pricing, lower productivity benefits and a charge of $122 million to product cost of sales recorded in the first quarter of fiscal 2018 related to legal and indemnification settlements.

[0000858877-17-000019:mdna:146]
The negative pricing impact was driven by typical market factors and impacted each of our geographic segments and customer markets. While productivity was positive to overall product gross margin, the benefit was lower than the prior year as these improvements were adversely impacted by an increase in the cost of certain memory components which are currently constrained. We expect the higher costs related to the constraint on these memory components to continue to impact productivity in the near term.  In addition, productivity was negatively impacted by decreases in Infrastructure Platforms revenue which limited our ability to generate cost savings. Productivity improvements were driven by value engineering efforts (e.g. component redesign, board configuration, test processes, and transformation processes), lower warranty expenses and continued operational efficiency in manufacturing operations. Our product gross margin for the first quarter of fiscal 2018 was also negatively impacted by higher amortization expense from purchased intangible assets.

[0000858877-17-000019:mdna:147]
57

[0000858877-17-000019:mdna:148]
[same as prior period, unchanged from 0000858877-17-000010:mdna:147]

[0000858877-17-000019:mdna:149]
[same as prior period, unchanged from 0000858877-17-000010:mdna:148]

[0000858877-17-000019:mdna:150]
[same as prior period, unchanged from 0000858877-17-000010:mdna:213]

[0000858877-17-000019:mdna:151]
Three Months Ended October 28, 2017 Compared with Three Months Ended October 29, 2016

[0000858877-17-000019:mdna:152]
Our service gross margin percentage decreased by 0.6 percentage points due largely to increased headcount-related costs and, to a lesser extent, increased delivery costs. These cost impacts were partially offset by the resulting benefit to gross margin of higher sales volume in both advanced services and technical support services.

[0000858877-17-000019:mdna:153]
Our service gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations and renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Another factor is the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-17-000019:mdna:154]
[same as prior period, unchanged from 0000858877-17-000010:mdna:219]

[0000858877-17-000019:mdna:155]
[same as prior period, unchanged from 0000858877-17-000010:mdna:220]

[0000858877-17-000019:mdna:156]
|  | Three Months Ended |
|  | AMOUNT |  | PERCENTAGE |
|  | October 28, 2017 |  | October 29, 2016 |  | October 28, 2017 |  | October 29, 2016 |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,722 |  |  | $ | 4,833 |  |  | 64.2 | % |  | 64.9 | % |
| EMEA | 1,839 |  |  | 2,013 |  |  | 63.2 | % |  | 66.8 | % |
| APJC | 1,165 |  |  | 1,204 |  |  | 62.1 | % |  | 63.5 | % |
| Segment total | 7,726 |  |  | 8,050 |  |  | 63.7 | % |  | 65.2 | % |
| Unallocated corporate items (1) | (299 | ) |  | (166 | ) |  |  |  |  |
| Total | $ | 7,427 |  |  | $ | 7,884 |  |  | 61.2 | % |  | 63.8 | % |

[0000858877-17-000019:mdna:157]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-17-000019:mdna:158]
Three Months Ended October 28, 2017 Compared with Three Months Ended October 29, 2016

[0000858877-17-000019:mdna:159]
The Americas segment experienced a gross margin percentage decrease due to negative impacts from pricing and product mix, partially offset by productivity improvements. The unfavorable mix impact was driven by our service provider video products within our other products.

[0000858877-17-000019:mdna:160]
The gross margin percentage decrease in our EMEA segment was due primarily to unfavorable impacts from pricing and productivity. Lower service gross margin also contributed to the decrease in the gross margin in this geographic segment.

[0000858877-17-000019:mdna:161]
Our APJC segment gross margin percentage decreased due to negative impacts from pricing partially offset by productivity improvements.

[0000858877-17-000019:mdna:162]
[same as prior period, unchanged from 0000858877-17-000010:mdna:163]

[0000858877-17-000019:mdna:163]
[same as prior period, unchanged from 0000858877-17-000010:mdna:164]

[0000858877-17-000019:mdna:164]
[same as prior period, unchanged from 0000858877-17-000010:mdna:235]

[0000858877-17-000019:mdna:165]
[same as prior period, unchanged from 0000858877-17-000010:mdna:236]

[0000858877-17-000019:mdna:166]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,567 |  |  | $ | 1,545 |  |  | $ | 22 |  |  | 1 | % |
| Percentage of revenue | 12.9 | % |  | 12.5 | % |  |  |  |  |
| Sales and marketing | 2,334 |  |  | 2,418 |  |  | (84 | ) |  | (3 | )% |
| Percentage of revenue | 19.2 | % |  | 19.6 | % |  |  |  |  |
| General and administrative | 557 |  |  | 555 |  |  | 2 |  |  | — | % |
| Percentage of revenue | 4.6 | % |  | 4.5 | % |  |  |  |  |
| Total | $ | 4,458 |  |  | $ | 4,518 |  |  | $ | (60 | ) |  | (1 | )% |
| Percentage of revenue | 36.7 | % |  | 36.6 | % |  |  |  |  |

[0000858877-17-000019:mdna:167]
[same as prior period, unchanged from 0000858877-17-000010:mdna:239]

[0000858877-17-000019:mdna:168]
R&D expenses increased in the first quarter of fiscal 2018, as compared with the first quarter of fiscal 2017, primarily due to higher headcount-related expenses, higher discretionary spending and higher share-based compensation expense, partially offset by lower contracted services and lower acquisition-related costs.

[0000858877-17-000019:mdna:169]
[same as prior period, unchanged from 0000858877-17-000010:mdna:241]

[0000858877-17-000019:mdna:170]
[same as prior period, unchanged from 0000858877-17-000010:mdna:244]

[0000858877-17-000019:mdna:171]
Sales and marketing expenses decreased in the first quarter of fiscal 2018, as compared with the first quarter of fiscal 2017, due to lower discretionary spending, lower contracted services and, to a lesser extent, lower share-based compensation expense, partially offset by higher headcount-related expenses.

[0000858877-17-000019:mdna:172]
[same as prior period, unchanged from 0000858877-17-000010:mdna:246]

[0000858877-17-000019:mdna:173]
G&A expenses were flat in the first quarter of fiscal 2018, as compared with the first quarter of fiscal 2017, as the increases in acquisition-related costs and share-based compensation expense significantly offset the decreases in headcount-related expenses and contracted services.

[0000858877-17-000019:mdna:174]
[same as prior period, unchanged from 0000858877-17-000010:mdna:249]

[0000858877-17-000019:mdna:175]
In the first quarter of fiscal 2018, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $17 million, or 0.4%, compared with the first quarter of fiscal 2017.

[0000858877-17-000019:mdna:176]
[same as prior period, unchanged from 0000858877-17-000010:mdna:188]

[0000858877-17-000019:mdna:177]
[same as prior period, unchanged from 0000858877-17-000010:mdna:189]

[0000858877-17-000019:mdna:178]
[same as prior period, unchanged from 0000858877-17-000010:mdna:254]

[0000858877-17-000019:mdna:179]
[same as prior period, unchanged from 0000858877-17-000010:mdna:255]

[0000858877-17-000019:mdna:180]
|  |  | Three Months Ended |
|  |  | October 28, 2017 |  | October 29, 2016 |
| Cost of sales—product |  | $ | 23 |  |  | $ | 21 |  |
| Cost of sales—service |  | 34 |  |  | 33 |  |
| Share-based compensation expense in cost of sales |  | 57 |  |  | 54 |  |
| Research and development |  | 136 |  |  | 126 |  |
| Sales and marketing |  | 135 |  |  | 140 |  |
| General and administrative |  | 64 |  |  | 49 |  |
| Restructuring and other charges |  | 6 |  |  | 3 |  |
| Share-based compensation expense in operating expenses |  | 341 |  |  | 318 |  |
| Total share-based compensation expense |  | $ | 398 |  |  | $ | 372 |  |

[0000858877-17-000019:mdna:181]
The increase in share-based compensation expense in the first quarter of fiscal 2018, as compared with the first quarter of fiscal 2017, was due primarily to higher expense related to equity awards assumed with respect to our recent acquisitions.

[0000858877-17-000019:mdna:182]
[same as prior period, unchanged from 0000858877-17-000010:mdna:260]

[0000858877-17-000019:mdna:183]
[same as prior period, unchanged from 0000858877-17-000010:mdna:261]

[0000858877-17-000019:mdna:184]
|  |  | Three Months Ended |
|  |  | October 28, 2017 |  | October 29, 2016 |
| Amortization of purchased intangible assets: |  |  |  |  |
| Cost of sales |  | $ | 154 |  |  | $ | 129 |  |
| Operating expenses: |  |  |  |  |
| Amortization of purchased intangible assets |  | 61 |  |  | 78 |  |
| Restructuring and other charges |  | — |  |  | 38 |  |
| Total |  | $ | 215 |  |  | $ | 245 |  |

[0000858877-17-000019:mdna:185]
Amortization of purchased intangible assets decreased for the first quarter of fiscal 2018, as compared with the first quarter of fiscal 2017, due to the impact of lower impairment charges partially offset by amortization of purchased intangible assets from our recent acquisitions.

[0000858877-17-000019:mdna:186]
[same as prior period, unchanged from 0000858877-17-000010:mdna:265]

[0000858877-17-000019:mdna:187]
In the first quarter of fiscal 2018, we incurred restructuring and other charges of approximately $152 million, which were related primarily to employee severance charges for employees impacted by the restructuring action announced in August 2016. In the first quarter of fiscal 2018, we extended the restructuring action to include an additional $150 million of estimated additional pretax charges for employee severance and other one-time termination benefits. Our estimated aggregate pretax charges pursuant to the restructuring action are expected to be approximately $1.0 billion. In connection with the restructuring action, we have incurred cumulative charges of approximately $908 million and we expect to substantially complete this action by the end of the second quarter of fiscal 2018.

[0000858877-17-000019:mdna:188]
We expect to reinvest substantially all of the cost savings from the restructuring action in our key priority areas.  As a result, the overall cost savings from the restructuring action are not expected to be material for future periods.

[0000858877-17-000019:mdna:189]
[same as prior period, unchanged from 0000858877-17-000010:mdna:197]

[0000858877-17-000019:mdna:190]
[same as prior period, unchanged from 0000858877-17-000010:mdna:198]

[0000858877-17-000019:mdna:191]
[same as prior period, unchanged from 0000858877-17-000010:mdna:268]

[0000858877-17-000019:mdna:192]
[same as prior period, unchanged from 0000858877-17-000010:mdna:269]

[0000858877-17-000019:mdna:193]
|  |  | Three Months Ended |
|  |  | October 28, 2017 |  | October 29, 2016 |
| Operating income |  | $ | 2,756 |  |  | $ | 2,877 |  |
| Operating income as a percentage of revenue |  | 22.7 | % |  | 23.3 | % |

[0000858877-17-000019:mdna:194]
For the first quarter of fiscal 2018, as compared with the first quarter of fiscal 2017, operating income decreased by 4% and as a percentage of revenue operating income decreased by 0.6 percentage points. These decreases resulted primarily from a gross margin percentage decrease, driven by unfavorable impacts from pricing, lower productivity benefits driven by an increase in the cost of certain memory components and the charge of $122 million for legal and indemnification settlements, partially offset by a decrease in restructuring and other charges related to the restructuring actions announced in August 2016.

[0000858877-17-000019:mdna:195]
[same as prior period, unchanged from 0000858877-17-000010:mdna:275]

[0000858877-17-000019:mdna:196]
[same as prior period, unchanged from 0000858877-17-000010:mdna:276]

[0000858877-17-000019:mdna:197]
|  |  | Three Months Ended |
|  |  | October 28, 2017 |  | October 29, 2016 |  | Variancein Dollars |
| Interest income |  | $ | 379 |  |  | $ | 295 |  |  | $ | 84 |  |
| Interest expense |  | (235 | ) |  | (198 | ) |  | (37 | ) |
| Interest income (expense), net |  | $ | 144 |  |  | $ | 97 |  |  | $ | 47 |  |

[0000858877-17-000019:mdna:198]
Three Months Ended October 28, 2017 Compared with Three Months Ended October 29, 2016

[0000858877-17-000019:mdna:199]
Interest income increased driven by an increase in our portfolio of cash, cash equivalents, and fixed income investments as well as higher yields on our portfolio. The increase in interest expense was driven by higher average debt balances which include commercial paper notes and the impact of higher effective interest rates on floating-rate senior notes and interest rate swaps associated with fixed-rate senior notes.

[0000858877-17-000019:mdna:200]
[same as prior period, unchanged from 0000858877-17-000010:mdna:279]

[0000858877-17-000019:mdna:201]
|  |  | Three Months Ended |
|  |  | October 28, 2017 |  | October 29, 2016 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |
| Publicly traded equity securities |  | $ | 29 |  |  | $ | 5 |  |  | $ | 24 |  |
| Fixed income securities |  | 4 |  |  | 10 |  |  | (6 | ) |
| Total available-for-sale investments |  | 33 |  |  | 15 |  |  | 18 |  |
| Privately held companies |  | 35 |  |  | (50 | ) |  | 85 |  |
| Net gains (losses) on investments |  | 68 |  |  | (35 | ) |  | 103 |  |
| Other gains (losses), net |  | (6 | ) |  | 14 |  |  | (20 | ) |
| Other income (loss), net |  | $ | 62 |  |  | $ | (21 | ) |  | $ | 83 |  |

[0000858877-17-000019:mdna:202]
61

[0000858877-17-000019:mdna:203]
[same as prior period, unchanged from 0000858877-17-000010:mdna:209]

[0000858877-17-000019:mdna:204]
[same as prior period, unchanged from 0000858877-17-000010:mdna:210]

[0000858877-17-000019:mdna:205]
Three Months Ended October 28, 2017 Compared with Three Months Ended October 29, 2016

[0000858877-17-000019:mdna:206]
The change in total net gains (losses) on available-for-sale investments was primarily attributable to higher realized gains on publicly traded equity securities as a result of market conditions and the timing of sales of these securities, partially offset by $26 million of impairment charges on publicly traded equity securities.

[0000858877-17-000019:mdna:207]
The change in net gains (losses) on investments in privately held companies was primarily due to higher realized gains and lower impairment charges on investments in privately held companies.

[0000858877-17-000019:mdna:208]
The change in other gains (losses), net was primarily driven by net unfavorable foreign exchange impacts.

[0000858877-17-000019:mdna:209]
[same as prior period, unchanged from 0000858877-17-000010:mdna:291]

[0000858877-17-000019:mdna:210]
[same as prior period, unchanged from 0000858877-17-000010:mdna:292]

[0000858877-17-000019:mdna:211]
The provision for income taxes resulted in an effective tax rate of 19.2% for the first quarter of fiscal 2018 compared with 21.4% for the first quarter of fiscal 2017, a net 2.2 percentage point decrease in the effective tax rate for the first quarter of fiscal 2018 as compared with the first quarter of fiscal 2017. The decrease in the effective tax rate was primarily due to the recognition of excess tax benefits from share-based compensation for the first quarter of fiscal 2018 as compared with the first quarter of fiscal 2017.

[0000858877-17-000019:mdna:212]
As a result of the adoption of the new accounting standard on share-based compensation, our effective tax rate will increase or decrease based upon the tax effect of the difference between the share-based compensation expenses and the benefits taken on the company's tax returns. We recognize excess tax benefits on a discrete basis and therefore anticipate the effective tax rate to vary from quarter to quarter depending on our share price in each period.

[0000858877-17-000019:mdna:213]
[same as prior period, unchanged from 0000858877-17-000010:mdna:226]

[0000858877-17-000019:mdna:214]
[same as prior period, unchanged from 0000858877-17-000010:mdna:227]

[0000858877-17-000019:mdna:215]
[same as prior period, unchanged from 0000858877-17-000010:mdna:228]

[0000858877-17-000019:mdna:216]
[same as prior period, unchanged from 0000858877-17-000010:mdna:297]

[0000858877-17-000019:mdna:217]
[same as prior period, unchanged from 0000858877-17-000010:mdna:298]

[0000858877-17-000019:mdna:218]
[same as prior period, unchanged from 0000858877-17-000010:mdna:299]

[0000858877-17-000019:mdna:219]
[same as prior period, unchanged from 0000858877-17-000010:mdna:300]

[0000858877-17-000019:mdna:220]
|  | October 28, 2017 |  | July 29, 2017 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 11,043 |  |  | $ | 11,708 |  |  | $ | (665 | ) |
| Fixed income securities | 58,764 |  |  | 57,077 |  |  | 1,687 |  |
| Publicly traded equity securities | 1,781 |  |  | 1,707 |  |  | 74 |  |
| Total | $ | 71,588 |  |  | $ | 70,492 |  |  | $ | 1,096 |  |

[0000858877-17-000019:mdna:221]
The net increase in cash and cash equivalents and investments in the first quarter of fiscal 2018 was primarily driven by cash provided by operating activities of $3.1 billion and a net increase in debt of $2.2 billion. These sources of cash were partially offset by cash returned to shareholders in the form of repurchases of common stock of $1.7 billion under the stock repurchase program and cash dividends of $1.4 billion; net cash paid for acquisitions of $0.7 billion; and capital expenditures of $0.2 billion.

[0000858877-17-000019:mdna:222]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $69.1 billion and $67.5 billion as of October 28, 2017 and July 29, 2017, respectively. Under current tax laws and regulations, if these assets were to be distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. The balance of cash and cash equivalents and investments available in the United States as of October 28, 2017 and July 29, 2017 was $2.5 billion and $3.0 billion, respectively.

[0000858877-17-000019:mdna:223]
[same as prior period, unchanged from 0000858877-17-000010:mdna:304]

[0000858877-17-000019:mdna:224]
[same as prior period, unchanged from 0000858877-17-000010:mdna:305]

[0000858877-17-000019:mdna:225]
[same as prior period, unchanged from 0000858877-17-000010:mdna:306]

[0000858877-17-000019:mdna:226]
|  | Three Months Ended |
|  | October 28, 2017 |  | October 29, 2016 |
| Net cash provided by operating activities | $ | 3,080 |  |  | $ | 2,730 |  |
| Acquisition of property and equipment | (168 | ) |  | (275 | ) |
| Free cash flow | $ | 2,912 |  |  | $ | 2,455 |  |

[0000858877-17-000019:mdna:227]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue, and the timing and amount of tax and other payments. For additional discussion, see “Part II, Item 1A. Risk Factors” in this report.

[0000858877-17-000019:mdna:228]
[same as prior period, unchanged from 0000858877-17-000010:mdna:242]

[0000858877-17-000019:mdna:229]
[same as prior period, unchanged from 0000858877-17-000010:mdna:243]

[0000858877-17-000019:mdna:230]
[same as prior period, unchanged from 0000858877-17-000010:mdna:311]

[0000858877-17-000019:mdna:231]
[same as prior period, unchanged from 0000858877-17-000010:mdna:312]

[0000858877-17-000019:mdna:232]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2018 |  |  |  |  |  |  |  |  |  |  |  |  |
| October 28, 2017 |  | $ | 0.29 |  |  | $ | 1,436 |  |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |  | $ | 3,056 |  |
| Fiscal 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 29, 2017 |  | $ | 0.29 |  |  | $ | 1,448 |  |  | 38 |  |  | $ | 31.61 |  |  | $ | 1,201 |  |  | $ | 2,649 |  |
| April 29, 2017 |  | $ | 0.29 |  |  | $ | 1,451 |  |  | 15 |  |  | $ | 33.71 |  |  | $ | 503 |  |  | $ | 1,954 |  |
| January 28, 2017 |  | $ | 0.26 |  |  | $ | 1,304 |  |  | 33 |  |  | $ | 30.33 |  |  | $ | 1,001 |  |  | $ | 2,305 |  |
| October 29, 2016 |  | $ | 0.26 |  |  | $ | 1,308 |  |  | 32 |  |  | $ | 31.12 |  |  | $ | 1,001 |  |  | $ | 2,309 |  |

[0000858877-17-000019:mdna:233]
[same as prior period, unchanged from 0000858877-17-000010:mdna:314]

[0000858877-17-000019:mdna:234]
[same as prior period, unchanged from 0000858877-17-000010:mdna:315]

[0000858877-17-000019:mdna:235]
|  | October 28, 2017 |  | July 29, 2017 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,206 |  |  | $ | 5,146 |  |  | $ | (940 | ) |

[0000858877-17-000019:mdna:236]
Our accounts receivable net, as of October 28, 2017 decreased by approximately 18%, as compared with the end of fiscal 2017, primarily due to the amount and timing of service billings, and also due to product billings being more linear in the first quarter of fiscal 2018 compared with the fourth quarter of fiscal 2017.

[0000858877-17-000019:mdna:237]
[same as prior period, unchanged from 0000858877-17-000010:mdna:318]

[0000858877-17-000019:mdna:238]
|  | October 28, 2017 |  | July 29, 2017 |  | Increase (Decrease) |
| Inventories | $ | 1,693 |  |  | $ | 1,616 |  |  | $ | 77 |  |
| Annualized inventory turns | 11.4 |  |  | 12.3 |  |  | (0.9 | ) |
| Purchase commitments with contract manufacturers and suppliers | $ | 4,205 |  |  | $ | 4,640 |  |  | $ | (435 | ) |

[0000858877-17-000019:mdna:239]
Inventory as of October 28, 2017 increased by 5% from our inventory balance at the end of fiscal 2017, and for the same period purchase commitments with contract manufacturers and suppliers decreased by approximately 9%. On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers decreased by 6% compared with the end of fiscal 2017. The increase in inventory was due to an increase in raw materials due to securing memory supply which is currently constrained. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-17-000019:mdna:240]
[same as prior period, unchanged from 0000858877-17-000010:mdna:324]

[0000858877-17-000019:mdna:241]
64

[0000858877-17-000019:mdna:242]
[same as prior period, unchanged from 0000858877-17-000010:mdna:258]

[0000858877-17-000019:mdna:243]
[same as prior period, unchanged from 0000858877-17-000010:mdna:259]

[0000858877-17-000019:mdna:244]
[same as prior period, unchanged from 0000858877-17-000010:mdna:325]

[0000858877-17-000019:mdna:245]
[same as prior period, unchanged from 0000858877-17-000010:mdna:326]

[0000858877-17-000019:mdna:246]
[same as prior period, unchanged from 0000858877-17-000010:mdna:327]

[0000858877-17-000019:mdna:247]
Financing Receivables and Guarantees  The following table summarizes our financing receivables (in millions):

[0000858877-17-000019:mdna:248]
|  | October 28, 2017 |  | July 29, 2017 |  | Increase (Decrease) |
| Lease receivables, net | $ | 2,712 |  |  | $ | 2,650 |  |  | $ | 62 |  |
| Loan receivables, net | 4,642 |  |  | 4,457 |  |  | 185 |  |
| Financed service contracts, net | 2,560 |  |  | 2,487 |  |  | 73 |  |
| Total, net | $ | 9,914 |  |  | $ | 9,594 |  |  | $ | 320 |  |

[0000858877-17-000019:mdna:249]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type and direct-financing leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customers financing purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services.  The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed.  Financing receivables increased by 3%. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-17-000019:mdna:250]
[same as prior period, unchanged from 0000858877-17-000010:mdna:331]

[0000858877-17-000019:mdna:251]
The volume of channel partner financing was $6.7 billion and $6.9 billion for the first quarter of fiscal 2018 and 2017, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.0 billion as of each of October 28, 2017 and July 29, 2017. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of October 28, 2017, the total maximum potential future payments related to these guarantees was approximately $331 million, of which approximately $125 million was recorded as deferred revenue.

[0000858877-17-000019:mdna:252]
[same as prior period, unchanged from 0000858877-17-000010:mdna:273]

[0000858877-17-000019:mdna:253]
[same as prior period, unchanged from 0000858877-17-000010:mdna:274]

[0000858877-17-000019:mdna:254]
[same as prior period, unchanged from 0000858877-17-000010:mdna:338]

[0000858877-17-000019:mdna:255]
[same as prior period, unchanged from 0000858877-17-000010:mdna:339]

[0000858877-17-000019:mdna:256]
|  | Maturity Date |  | October 28, 2017 |  | July 29, 2017 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | 1,000 |  |  | $ | 1,000 |  |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 900 |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 500 |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1,250 |  |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1,600 |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1,000 |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1,500 |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 30,500 |  |  | $ | 30,500 |  |

[0000858877-17-000019:mdna:257]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of October 28, 2017.

[0000858877-17-000019:mdna:258]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.  We had $5.5 billion and $3.2 billion commercial paper notes outstanding as of October 28, 2017 and July 29, 2017, respectively.

[0000858877-17-000019:mdna:259]
Credit Facilities On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.

[0000858877-17-000019:mdna:260]
[same as prior period, unchanged from 0000858877-17-000010:mdna:289]

[0000858877-17-000019:mdna:261]
[same as prior period, unchanged from 0000858877-17-000010:mdna:290]

[0000858877-17-000019:mdna:262]
In addition, on March 30, 2017 we entered into a 364-Day credit agreement with certain institutional lenders that provides for a $2.0 billion unsecured revolving credit facility that is scheduled to expire on March 29, 2018. The credit agreement also provides us the option to, for a fee, convert any borrowings outstanding thereunder on March 29, 2018 to a term loan maturing no later than March 29, 2019. The interest rate applicable to outstanding balances under the credit agreement will be based on either (i) the higher of (a) the rates on overnight Federal Funds transactions with members of the Federal Reserve System (i.e., Federal Funds rate) plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time or (c) LIBOR for an interest period of one month plus 1.00%, or (ii) LIBOR plus a margin that is based on our senior debt credit ratings as published by S&P Global Rating, a business unit of Standard & Poor’s Financial Services LLC, and Moody’s Investors Service, Inc.

[0000858877-17-000019:mdna:263]
These credit agreements require that we comply with certain covenants, including that we maintain interest coverage ratios as defined in these agreements. As of October 28, 2017, we were in compliance with the required interest coverage ratios and the other covenants, and we had not borrowed any funds under these credit facilities.

[0000858877-17-000019:mdna:264]
[same as prior period, unchanged from 0000858877-17-000010:mdna:351]

[0000858877-17-000019:mdna:265]
|  | October 28, 2017 |  | July 29, 2017 |  | Increase (Decrease) |
| Service | $ | 10,991 |  |  | $ | 11,302 |  |  | $ | (311 | ) |
| Product: |  |  |  |  |  |  |
| Deferred revenue related to recurring software and subscription offers | 5,213 |  |  | 4,971 |  |  | 242 |  |
| Other product deferred revenue | 2,361 |  |  | 2,221 |  |  | 140 |  |
| Total product deferred revenue | 7,574 |  |  | 7,192 |  |  | 382 |  |
| Total | $ | 18,565 |  |  | $ | 18,494 |  |  | $ | 71 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 10,920 |  |  | $ | 10,821 |  |  | $ | 99 |  |
| Noncurrent | 7,645 |  |  | 7,673 |  |  | (28 | ) |
| Total | $ | 18,565 |  |  | $ | 18,494 |  |  | $ | 71 |  |

[0000858877-17-000019:mdna:266]
Deferred product revenue increased 5% primarily due to increased deferrals related to recurring software and subscription offers. The portion of product deferred revenue related to recurring software and subscription offers grew 37% on a year-over-year basis to $5.2 billion as of October 28, 2017. Security and Applications continued to experience strong product deferred revenue growth during the period. The 3% decrease in deferred service revenue was driven by the timing of multiyear arrangements and the impact of ongoing amortization of deferred service revenue.

[0000858877-17-000019:mdna:267]
[same as prior period, unchanged from 0000858877-17-000010:mdna:357]

[0000858877-17-000019:mdna:268]
[same as prior period, unchanged from 0000858877-17-000010:mdna:358]

[0000858877-17-000019:mdna:269]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of October 28, 2017 were $1.2 billion.

[0000858877-17-000019:mdna:270]
[same as prior period, unchanged from 0000858877-17-000010:mdna:360]

[0000858877-17-000019:mdna:271]
[same as prior period, unchanged from 0000858877-17-000010:mdna:361]

[0000858877-17-000019:mdna:272]
Insieme Networks, Inc.  In fiscal 2012, we made an investment in Insieme, an early stage company focused on research and development in the data center market. This investment included $100 million of funding and a license to certain of our technology. During fiscal 2014, we acquired the remaining interests in Insieme, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which were determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $1 million and $323 million during the first quarters of fiscal 2018 and fiscal 2017, respectively. During the first quarters of fiscal 2018 and fiscal 2017, we recorded compensation expense of $1 million and $20 million, respectively, related to these milestone payments. We do not expect a material amount of future compensation expense or further milestone payments related to this acquisition.

[0000858877-17-000019:mdna:273]
67

[0000858877-17-000019:mdna:274]
[same as prior period, unchanged from 0000858877-17-000010:mdna:295]

[0000858877-17-000019:mdna:275]
[same as prior period, unchanged from 0000858877-17-000010:mdna:296]

[0000858877-17-000019:mdna:276]
Other Funding Commitments  We also have certain funding commitments primarily related to our investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $213 million as of October 28, 2017, compared with $216 million as of July 29, 2017.

[0000858877-17-000019:mdna:277]
[same as prior period, unchanged from 0000858877-17-000010:mdna:364]

[0000858877-17-000019:mdna:278]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have investments in privately held companies including venture funds and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and customer financings, and we have determined that as of October 28, 2017 there were no material unconsolidated variable interest entities.

[0000858877-17-000019:mdna:279]
[same as prior period, unchanged from 0000858877-17-000010:mdna:367]

[0000858877-17-000019:mdna:280]
[same as prior period, unchanged from 0000858877-17-000010:mdna:368]

[0000858877-17-000019:mdna:281]
[same as prior period, unchanged from 0000858877-17-000010:mdna:371]

[0000858877-17-000019:mdna:282]
We periodically engage in securities lending activities with certain of our available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the three months ended October 28, 2017 and October 29, 2016 was $0.5 billion and $1.2 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of October 28, 2017 and July 29, 2017, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-17-000019:mdna:283]
[same as prior period, unchanged from 0000858877-17-000010:mdna:373]

[0000858877-17-000019:mdna:284]
[same as prior period, unchanged from 0000858877-17-000010:mdna:374]

[0000858877-17-000019:mdna:285]
68
