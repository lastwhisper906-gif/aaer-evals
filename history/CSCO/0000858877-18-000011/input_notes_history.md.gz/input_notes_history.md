# CSCO note change history — 0000858877-18-000004 → 0000858877-18-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-22):
[0000858877-18-000007:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, Germany, India, Israel, Japan, Mexico, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 28, 2018 are as follows (in millions):
  (was, 2018-02-20, similarity 0.9858):
[0000858877-18-000004:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, Germany, India, Israel, Japan, Mexico, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of January 27, 2018 are as follows (in millions):

- changed (2018-05-22):
[0000858877-18-000007:note_history:2]
| Fiscal Year | Amount |
| 2018 (remaining three months) | $ | 110 |  |
| 2019 | 343 |  |
| 2020 | 251 |  |
| 2021 | 164 |  |
| 2022 | 131 |  |
| Thereafter | 194 |  |
| Total | $ | 1,193 |  |
  (was, 2018-02-20, similarity 0.9739):
[0000858877-18-000004:note_history:2]
| Fiscal Year | Amount |
| 2018 (remaining six months) | $ | 220 |  |
| 2019 | 323 |  |
| 2020 | 239 |  |
| 2021 | 147 |  |
| 2022 | 122 |  |
| Thereafter | 178 |  |
| Total | $ | 1,229 |  |

- changed (2018-05-22):
[0000858877-18-000007:note_history:3]
| Commitments by Period | April 28, 2018 |  | July 29, 2017 |
| Less than 1 year | $ | 5,077 |  |  | $ | 4,620 |  |
| 1 to 3 years | 700 |  |  | 20 |  |
| 3 to 5 years | 450 |  |  | — |  |
| Total | $ | 6,227 |  |  | $ | 4,640 |  |
  (was, 2018-02-20, similarity 0.9787):
[0000858877-18-000004:note_history:3]
| Commitments by Period | January 27, 2018 |  | July 29, 2017 |
| Less than 1 year | $ | 4,498 |  |  | $ | 4,620 |  |
| 1 to 3 years | 690 |  |  | 20 |  |
| 3 to 5 years | 540 |  |  | — |  |
| Total | $ | 5,728 |  |  | $ | 4,640 |  |

- changed (2018-05-22):
[0000858877-18-000007:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of April 28, 2018 and July 29, 2017, the liability for these purchase commitments was $163 million and $162 million, respectively, and was included in other current liabilities.
  (was, 2018-02-20, similarity 0.9621):
[0000858877-18-000004:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of January 27, 2018 and July 29, 2017, the liability for these purchase commitments was $159 million and $162 million, respectively, and was included in other current liabilities.

- changed (2018-05-22):
[0000858877-18-000007:note_history:5]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Compensation expense related to acquisitions | $ | 53 |  |  | $ | 36 |  |  | $ | 141 |  |  | $ | 173 |  |
  (was, 2018-02-20, similarity 0.7309):
[0000858877-18-000004:note_history:5]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Compensation expense related to acquisitions | $ | 46 |  |  | $ | 73 |  |  | $ | 88 |  |  | $ | 137 |  |

- changed (2018-05-22):
[0000858877-18-000007:note_history:6]
As of April 28, 2018, the Company estimated that future cash compensation expense of up to $370 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2018-02-20, similarity 0.9788):
[0000858877-18-000004:note_history:6]
As of January 27, 2018, the Company estimated that future cash compensation expense of up to $246 million may be required to be recognized pursuant to the applicable business combination agreements.

- changed (2018-05-22):
[0000858877-18-000007:note_history:7]
Insieme Networks, Inc.    In fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. This investment included $100 million of funding and a license to certain of the Company’s technology. During fiscal 2014, the Company acquired the remaining interests in Insieme, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which were determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $436 million during the nine months ended April 29, 2017. The Company recorded compensation expense of $9 million and $41 million during the three and nine months ended April 29, 2017, respectively, related to these milestone payments. The Company does not expect a material amount of future compensation expense or further milestone payments related to this acquisition.
  (was, 2018-02-20, similarity 0.8837):
[0000858877-18-000004:note_history:7]
Insieme Networks, Inc.    In fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. This investment included $100 million of funding and a license to certain of the Company’s technology. During fiscal 2014, the Company acquired the remaining interests in Insieme, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which were determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $422 million during the six months ended January 28, 2017. The Company recorded compensation expense of $12 million during the three months ended January 28, 2017, and $32 million during the six months ended January 28, 2017, related to these milestone payments. The Company does not expect a material amount of future compensation expense or further milestone payments related to this acquisition.

- changed (2018-05-22):
[0000858877-18-000007:note_history:8]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $212 million and $216 million as of April 28, 2018 and July 29, 2017, respectively.
  (was, 2018-02-20, similarity 0.9589):
[0000858877-18-000004:note_history:8]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $215 million and $216 million as of January 27, 2018 and July 29, 2017, respectively.

- changed (2018-05-22):
[0000858877-18-000007:note_history:9]
|  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |
| Balance at beginning of period | $ | 407 |  |  | $ | 414 |  |
| Provisions for warranty issued | 431 |  |  | 528 |  |
| Adjustments for pre-existing warranties | (32 | ) |  | (17 | ) |
| Settlements | (441 | ) |  | (511 | ) |
| Balance at end of period | $ | 365 |  |  | $ | 414 |  |
  (was, 2018-02-20, similarity 0.9213):
[0000858877-18-000004:note_history:9]
|  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |
| Balance at beginning of period | $ | 407 |  |  | $ | 414 |  |
| Provisions for warranty issued | 287 |  |  | 367 |  |
| Adjustments for pre-existing warranties | (21 | ) |  | (3 | ) |
| Settlements | (292 | ) |  | (352 | ) |
| Balance at end of period | $ | 381 |  |  | $ | 426 |  |

- changed (2018-05-22):
[0000858877-18-000007:note_history:10]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $7.1 billion and $6.6 billion for the three months ended April 28, 2018 and April 29, 2017, respectively, and was $20.7 billion and $19.7 billion for the nine months ended April 28, 2018 and April 29, 2017, respectively. The balance of the channel partner financing subject to guarantees was $1.0 billion as of each of April 28, 2018 and July 29, 2017.
  (was, 2018-02-20, similarity 0.8928):
[0000858877-18-000004:note_history:10]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.9 billion and $6.3 billion for the three months ended January 27, 2018 and January 28, 2017, respectively, and was $13.6 billion and $13.2 billion for the six months ended January 27, 2018 and January 28, 2017, respectively. The balance of the channel partner financing subject to guarantees was $1.0 billion as of each of January 27, 2018 and July 29, 2017.

- changed (2018-05-22):
[0000858877-18-000007:note_history:11]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $3 million and $10 million for the three months ended April 28, 2018 and April 29, 2017, respectively, and was $29 million and $47 million for the nine months ended April 28, 2018 and April 29, 2017, respectively.
  (was, 2018-02-20, similarity 0.8897):
[0000858877-18-000004:note_history:11]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $12 million and $30 million for the three months ended January 27, 2018 and January 28, 2017, respectively, and was $26 million and $36 million for the six months ended January 27, 2018 and January 28, 2017, respectively.

- changed (2018-05-22):
[0000858877-18-000007:note_history:12]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 28, 2018 and July 29, 2017, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2018-02-20, similarity 0.9807):
[0000858877-18-000004:note_history:12]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 27, 2018 and July 29, 2017, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- added (2018-05-22):
[0000858877-18-000007:note_history:13]
|  | April 28, 2018 |  | July 29, 2017 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 262 |  |  | $ | 240 |  |
| End user | 41 |  |  | 74 |  |
| Total | $ | 303 |  |  | $ | 314 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (90 | ) |  | $ | (82 | ) |
| End user | (32 | ) |  | (52 | ) |
| Total | $ | (122 | ) |  | $ | (134 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 181 |  |  | $ | 180 |  |

- changed (2018-05-22):
[0000858877-18-000007:note_history:14]
Other Guarantees   The Company’s other guarantee arrangements as of April 28, 2018 and July 29, 2017 that were subject to recognition and disclosure requirements were not material.
  (was, 2018-02-20, similarity 0.9763):
[0000858877-18-000004:note_history:14]
Other Guarantees   The Company’s other guarantee arrangements as of January 27, 2018 and July 29, 2017 that were subject to recognition and disclosure requirements were not material.

- changed (2018-05-22):
[0000858877-18-000007:note_history:15]
In fiscal 2014, the Company recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. The Company performs regular assessments of the sufficiency of this liability and reduced the amount by $74 million and $164 million in fiscal 2016 and fiscal 2015, respectively based on updated analyses. During the second quarter of fiscal 2017, the Company further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. In addition, during the second quarter of fiscal 2017, the Company recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of the Company’s products. The liabilities related to the supplier component remediation matters as of April 28, 2018 and July 29, 2017 were $98 million and $174 million, respectively.
  (was, 2018-02-20, similarity 0.9872):
[0000858877-18-000004:note_history:15]
In fiscal 2014, the Company recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. The Company performs regular assessments of the sufficiency of this liability and reduced the amount by $74 million and $164 million in fiscal 2016 and fiscal 2015, respectively based on updated analyses. During the second quarter of fiscal 2017, the Company further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. In addition, during the second quarter of fiscal 2017, the Company recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of the Company’s products. The liabilities related to the supplier component remediation matters as of January 27, 2018 and July 29, 2017 were $120 million and $174 million, respectively.

- changed (2018-05-22):
[0000858877-18-000007:note_history:16]
For the nine months ended April 28, 2018, the Company recorded legal and indemnification settlement charges of $127 million to product cost of sales in relation to these matters. At this time, the Company does not anticipate that its obligations regarding the final outcome of the above matters would be material.
  (was, 2018-02-20, similarity 0.886):
[0000858877-18-000004:note_history:16]
During the first six months of fiscal 2018, the Company recorded legal and indemnification settlement charges of $127 million to product cost of sales in relation to these matters. At this time, the Company does not anticipate that its obligations regarding the final outcome of the above matters would be material.

- changed (2018-05-22):
[0000858877-18-000007:note_history:17]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $234 million for the alleged evasion of import and other taxes, $1.5 billion for interest, and $1.1 billion for various penalties, all determined using an exchange rate as of April 28, 2018. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.
  (was, 2018-02-20, similarity 0.9949):
[0000858877-18-000004:note_history:17]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $257 million for the alleged evasion of import and other taxes, $1.6 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of January 27, 2018. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

- changed (2018-05-22):
[0000858877-18-000007:note_history:18]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, the Company petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art. On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that the Company would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. On June 28, 2016, in light of the PTAB’s decision to review the patent’s validity, the district court issued an order staying the district court case pending the final written decision from the PTAB. On February 22, 2017, following a hearing, the PTAB issued its Final Written Decision that the patent’s claims are unpatentable. SSL appealed this decision to the Court of Appeals for the Federal Circuit and, on May 7, 2018, the Federal Circuit summarily affirmed the PTAB's decision of unpatentability.
  (was, 2018-02-20, similarity 0.7632):
[0000858877-18-000004:note_history:18]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, the Company petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art. On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that the Company would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. On June 28, 2016, in light of the PTAB’s decision to review the patent’s validity, the district court issued an order staying the district court case pending the final written decision from the PTAB. On February 22, 2017, following a hearing, the PTAB issued its Final Written Decision that the patent’s claims are unpatentable. SSL has appealed this decision to the Court of Appeals for the Federal Circuit. The Company believes it has strong arguments that the Company's products do not infringe and the patent is invalid. If the Company does not prevail and a jury were to find that the Company's AnyConnect products infringe, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding patent litigation processes, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

- changed (2018-05-22):
[0000858877-18-000007:note_history:19]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against the Company in the U.S. District Court for the Northern District of California, accusing the Company’s 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted the Company's motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against the Company and cancelling a trial which had been set for March 12, 2018. On January 16, 2018, Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit.
  (was, 2018-02-20, similarity 0.9975):
[0000858877-18-000004:note_history:19]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against the Company in U.S. District Court for the Northern District of California, accusing the Company’s 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted the Company's motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against the Company and cancelling a trial which had been set for March 12, 2018. On January 16, 2018, Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit.

- changed (2018-05-22):
[0000858877-18-000007:note_history:20]
DXC Technology     On August 21, 2015, the Company and Cisco Systems Capital Corporation (“Cisco Capital”) filed an action in Santa Clara County Superior Court for declaratory judgment and breach of contract against HP Inc. (“HP”) regarding a services agreement for management services of a third party’s network. HP had prepaid the service agreement through a financing arrangement with Cisco Capital, and had terminated its agreement with the Company. Pursuant to the terms of the service agreement with HP, the Company determined the credit HP was entitled to receive under the agreement for certain prepaid amounts. HP disputed the Company’s credit calculation and contended that the Company owes a larger credit to HP than the Company had calculated. In December 2015, the Company filed an amended complaint which dropped the breach of contract claim in light of HP’s continuing payments to Cisco Capital under the financing arrangement. On January 19, 2016, HP Inc. filed a counterclaim for breach of contract simultaneously with its answer to the amended complaint. DXC Technology Corporation (“DXC”) reported that it is the party in interest in this matter pursuant to the Separation and Distribution Agreement between the then Hewlett-Packard Co. and Hewlett Packard Enterprise Company (“HPE") and the subsequent Separation and Distribution Agreement between HPE and DXC. On January 8, 2018, the court continued the trial date from March 12, 2018 to June 11, 2018. The Company is unable to reasonably estimate the ultimate outcome of this litigation due to uncertainty surrounding the litigation process. However, the Company does not anticipate that its obligation, if any, regarding the final outcome of the dispute would be material.
  (was, 2018-02-20, similarity 0.8928):
[0000858877-18-000004:note_history:20]
DXC Technology     On August 21, 2015, the Company and Cisco Systems Capital Corporation (“Cisco Capital”) filed an action in Santa Clara County Superior Court for declaratory judgment and breach of contract against HP Inc. (“HP”) regarding a services agreement for management services of a third party’s network. HP prepaid the service agreement through a financing arrangement with Cisco Capital. HP terminated its agreement with the Company, and pursuant to the terms of the service agreement with HP, the Company determined the credit HP was entitled to receive under the agreement. HP disputed the Company’s credit calculation and contended that the Company owes a larger credit to HP than the Company had calculated. In December 2015, the Company filed an amended complaint which dropped the breach of contract claim in light of HP’s continuing payments to Cisco Capital under the financing arrangement. On January 19, 2016, HP Inc. filed a counterclaim for breach of contract simultaneously with its answer to the amended complaint. DXC Technology Corporation (“DXC”) reported that it is the party in interest in this matter pursuant to the Separation and Distribution Agreement between the then Hewlett-Packard Co. and Hewlett Packard Enterprise Company (“HPE") and the subsequent Separation and Distribution Agreement between HPE and DXC. On January 8, 2018, the court continued the trial date from March 12, 2018 to June 11, 2018. The Company is unable to reasonably estimate the ultimate outcome of this litigation due to uncertainty surrounding the litigation process. However, the Company does not anticipate that its obligation, if any, regarding the final outcome of the dispute would be material.

- added (2018-05-22):
[0000858877-18-000007:note_history:21]
Arista Networks, Inc.     On February 24, 2016, Arista Networks, Inc. (“Arista”) filed a complaint against the Company in the U.S. District Court for the Northern District of California asserting monopolization claims in violation of Section 2 of the Sherman Act and an unfair competition claim under California Bus. and Prof. Code § 17200. On October 31, 2017, Arista filed an amended complaint for Sherman Act monopolization and § 17200 claims, alleging an anticompetitive scheme comprising the Company's copyright infringement action against Arista (which was based on Arista’s copying of the Company's copyright-protected user interfaces) and communications related to that litigation. Arista seeks injunctive relief, lost profits, enhanced damages, and restitution. A jury trial is scheduled for August 6, 2018.  The Company believes it has strong arguments that its conduct was lawful, legally protected, and not anticompetitive, as well as strong defenses to defeat Arista’s claims. However, due to uncertainty surrounding litigation processes, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. However, the Company does not anticipate that any final outcome of the dispute would be material.

- added (2018-05-22):
[0000858877-18-000007:note_history:22]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against the Company in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the court consolidated the cases alleging infringement of the ‘327 Patent. The court set a trial date of June 4, 2018 for the cases against Infinera, Alcatel-Lucent, the Company and Huawei. While the Company believes that it has strong non-infringement arguments and that the patent is invalid, if the Company does not prevail in the District Court, the Company believes damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. However, the Company does not anticipate that any final outcome of the dispute would be material.

- removed (2018-05-22):
[0000858877-18-000004:note_history:23]
|  | January 27, 2018 |  | July 29, 2017 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 288 |  |  | $ | 240 |  |
| End user | 53 |  |  | 74 |  |
| Total | $ | 341 |  |  | $ | 314 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (91 | ) |  | $ | (82 | ) |
| End user | (40 | ) |  | (52 | ) |
| Total | $ | (131 | ) |  | $ | (134 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 210 |  |  | $ | 180 |  |


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-22):
[0000858877-18-000007:note_history:24]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.
  (was, 2018-02-20, similarity 0.9995):
[0000858877-18-000004:note_history:24]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-05-22):
[0000858877-18-000007:note_history:25]
The accompanying financial data as of April 28, 2018 and for the three and nine months ended April 28, 2018 and April 29, 2017 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 29, 2017 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 29, 2017.
  (was, 2018-02-20, similarity 0.9661):
[0000858877-18-000004:note_history:25]
The accompanying financial data as of January 27, 2018 and for the three and six months ended January 27, 2018 and January 28, 2017 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 29, 2017 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 29, 2017.

- changed (2018-05-22):
[0000858877-18-000007:note_history:26]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of April 28, 2018; the results of operations and the statements of comprehensive income (loss) for the three and nine months ended April 28, 2018 and April 29, 2017; the statements of cash flows and equity for the nine months ended April 28, 2018 and April 29, 2017, as applicable, have been made. The results of operations for the three and nine months ended April 28, 2018 are not necessarily indicative of the operating results for the full fiscal year or any future periods.
  (was, 2018-02-20, similarity 0.8153):
[0000858877-18-000004:note_history:26]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 27, 2018; the results of operations and the statements of comprehensive income (loss) for the three and six months ended January 27, 2018 and January 28, 2017; the statements of cash flows and equity for the six months ended January 27, 2018 and January 28, 2017, as applicable, have been made. The results of operations for the three and six months ended January 27, 2018 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-05-22):
[0000858877-18-000007:note_history:27]
| (a) | New Accounting Updates Recently Adopted |
  (was, 2018-02-20, similarity 0.9348):
[0000858877-18-000004:note_history:27]
(a) New Accounting Updates Recently Adopted

- changed (2018-05-22):
[0000858877-18-000007:note_history:28]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. Cisco adopted this accounting standard update beginning the first quarter of fiscal 2018 on a prospective basis. This resulted in an overall decrease in the effective tax rate for the nine months ended April 28, 2018 due to recognition of excess tax benefits from share-based compensation. The application of this accounting standard update did not have a material impact on the Company's Consolidated Financial Statements.
  (was, 2018-02-20, similarity 0.9674):
[0000858877-18-000004:note_history:28]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. Cisco adopted this accounting standard update beginning the first quarter of fiscal 2018 on a prospective basis. This resulted in an overall decrease in the effective tax rate for the six months ended January 27, 2018 due to recognition of excess tax benefits from share-based compensation. The application of this accounting standard update did not have a material impact on the Company's Consolidated Financial Statements.

- added (2018-05-22):
[0000858877-18-000007:note_history:29]
Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income  In February 2018, the FASB issued an accounting standard update that allows companies to reclassify from accumulated other comprehensive income ("AOCI") to retained earnings stranded tax effects resulting from the enactment of the Tax Cuts and Jobs Act (the "Tax Act"). The guidance is effective January 1, 2019 with early adoption permitted. Cisco early adopted this accounting standard update in the third quarter of fiscal 2018 and elected not to reclassify prior periods. Adoption of this standard resulted in a decrease of $45 million to retained earnings due to the reclassification from AOCI to retained earnings.

- changed (2018-05-22):
[0000858877-18-000007:note_history:30]
| (b) | Recent Accounting Standards or Updates Not Yet Effective as of Period End |
  (was, 2018-02-20, similarity 0.9625):
[0000858877-18-000004:note_history:30]
(b) Recent Accounting Standards or Updates Not Yet Effective as of Period End

- changed (2018-05-22):
[0000858877-18-000007:note_history:31]
The new standard will primarily impact Cisco’s revenue recognition for software arrangements and sales to two-tier distributors. In both areas, the new standard will accelerate the recognition of revenue. The table below details the timing of when revenue is typically recognized under the current revenue standard compared to the timing of when revenue will typically be recognized under the New Revenue Standard for these major areas:
  (was, 2018-02-20, similarity 0.6621):
[0000858877-18-000004:note_history:31]
The new standard will primarily impact Cisco’s revenue recognition for software arrangements and sales to two-tier distributors. In both areas, the new standard will accelerate the recognition of revenue. The table below details both the current and expected revenue recognition timing in these areas:

- added (2018-05-22):
[0000858877-18-000007:note_history:32]
Leases  In February 2016, the FASB issued an accounting standard update and subsequent amendments related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2020 on a modified retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- changed (2018-05-22):
[0000858877-18-000007:note_history:33]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. Cisco currently estimates a net increase of approximately $1.3 billion to net deferred tax assets and retained earnings upon adoption of the standard related to the unrecognized income tax effects of asset transfers that occurred prior to the adoption date. The ongoing impact of this standard will be facts and circumstances dependent on any transactions within its scope.
  (was, 2018-02-20, similarity 0.6637):
[0000858877-18-000004:note_history:33]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- removed (2018-05-22):
[0000858877-18-000004:note_history:34]
Leases  In February 2016, the FASB issued an accounting standard update related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2020 on a modified retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- removed (2018-05-22):
[0000858877-18-000004:note_history:35]
Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income  In February 2018, the FASB issued a new accounting standard update that allows companies to reclassify from Accumulated Other Comprehensive Income to Retained Earnings stranded tax effects resulting from the enactment of the Tax Cuts and Jobs Act (the "Tax Act"). Cisco will adopt this accounting standard update in the third quarter of fiscal 2018 on a retrospective basis. The application of this accounting standard update will not have a material impact on the Company's Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-22):
[0000858877-18-000007:note_history:36]
|  | April 28, 2018 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 7,736 |  |  | 2.91 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | — |  |  | — | % |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 7,736 |  |  |  |  | $ | 7,992 |  |  |  |
  (was, 2018-02-20, similarity 0.9468):
[0000858877-18-000004:note_history:36]
|  | January 27, 2018 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,749 |  |  | 1.78 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | 8,992 |  |  | 1.51 | % |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 13,741 |  |  |  |  | $ | 7,992 |  |  |  |

- changed (2018-05-22):
[0000858877-18-000007:note_history:37]
|  |  |  | April 28, 2018 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | — |  |  | — |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 2.50% |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 2.57% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.58% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | — |  |  | — |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.12% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.50% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.38% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.66% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.94% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.78% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.10% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 28,250 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (119 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (59 | ) |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 28,072 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 7,736 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 20,336 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 28,072 |  |  |  |  | $ | 30,472 |  |  |  |
  (was, 2018-02-20, similarity 0.9873):
[0000858877-18-000004:note_history:37]
|  |  |  | January 27, 2018 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | 1,000 |  |  | 2.11% |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.96% |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 2.04% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.01% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.04% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.18% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.11% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.34% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.60% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.46% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.76% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 30,500 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (125 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (1 | ) |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 30,374 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,749 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 25,625 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 30,374 |  |  |  |  | $ | 30,472 |  |  |  |

- changed (2018-05-22):
[0000858877-18-000007:note_history:38]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 28, 2018, the Company was in compliance with all debt covenants.
  (was, 2018-02-20, similarity 0.9884):
[0000858877-18-000004:note_history:38]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 27, 2018, the Company was in compliance with all debt covenants.

- changed (2018-05-22):
[0000858877-18-000007:note_history:39]
As of April 28, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2018-02-20, similarity 0.9701):
[0000858877-18-000004:note_history:39]
As of January 27, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2018-05-22):
[0000858877-18-000007:note_history:40]
| Fiscal Year | Amount |
| 2018 (remaining three months) | $ | 2,500 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 28,250 |  |
  (was, 2018-02-20, similarity 0.9739):
[0000858877-18-000004:note_history:40]
| Fiscal Year | Amount |
| 2018 (remaining six months) | $ | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 30,500 |  |

- changed (2018-05-22):
[0000858877-18-000007:note_history:41]
| (c) | Credit Facility |
  (was, 2018-02-20, similarity 0.9231):
[0000858877-18-000004:note_history:41]
| (c) | Credit Facilities |

- added (2018-05-22):
[0000858877-18-000007:note_history:42]
This credit agreement requires that the Company comply with certain covenants, including that the Company maintains an interest coverage ratio as defined in the agreement. As of April 28, 2018, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under this credit facility.

- removed (2018-05-22):
[0000858877-18-000004:note_history:43]
In addition, on March 30, 2017, the Company entered into a 364-Day credit agreement with certain institutional lenders that provides for a $2.0 billion unsecured revolving credit facility that is scheduled to expire on March 29, 2018. The credit agreement also provides the Company with the option to, for a fee, convert any borrowing outstanding thereunder on March 29, 2018 to a term loan maturing no later than March 29, 2019. The interest rate applicable to outstanding balances under the credit agreement will be based on either (i) the higher of (a) the rates on overnight Federal Funds transactions with members of the Federal Reserve System (i.e., Federal Funds rate) plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time or (c) LIBOR for an interest period of one month plus 1.00%, or (ii) LIBOR plus a margin that is based on the Company's senior debt credit ratings as published by S&P Global Rating, a business unit of Standard & Poor’s Financial Services LLC, and Moody’s Investors Service, Inc.

- removed (2018-05-22):
[0000858877-18-000004:note_history:44]
These credit agreements require that the Company comply with certain covenants, including that the Company maintains an interest coverage ratio as defined in these agreements. As of January 27, 2018, the Company was in compliance with the required interest coverage ratios and the other covenants, and the Company had not borrowed any funds under these credit facilities.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-22):
[0000858877-18-000007:note_history:45]
| April 28, 2018 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 13,672 |  |  | $ | — |  |  | $ | (141 | ) |  | $ | 13,531 |  |
| U.S. government agency securities | 1,166 |  |  | — |  |  | (10 | ) |  | 1,156 |  |
| Non-U.S. government and agency securities | 282 |  |  | — |  |  | (1 | ) |  | 281 |  |
| Corporate debt securities | 29,639 |  |  | 53 |  |  | (454 | ) |  | 29,238 |  |
| U.S. agency mortgage-backed securities | 2,009 |  |  | — |  |  | (73 | ) |  | 1,936 |  |
| Commercial paper | 195 |  |  | — |  |  | — |  |  | 195 |  |
| Certificates of deposit | 50 |  |  | — |  |  | — |  |  | 50 |  |
| Total fixed income securities | 47,013 |  |  | 53 |  |  | (679 | ) |  | 46,387 |  |
| Publicly traded equity securities | 843 |  |  | 486 |  |  | (4 | ) |  | 1,325 |  |
| Total (1) | $ | 47,856 |  |  | $ | 539 |  |  | $ | (683 | ) |  | $ | 47,712 |  |
  (was, 2018-02-20, similarity 0.9927):
[0000858877-18-000004:note_history:45]
| January 27, 2018 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 17,506 |  |  | $ | — |  |  | $ | (140 | ) |  | $ | 17,366 |  |
| U.S. government agency securities | 1,722 |  |  | — |  |  | (10 | ) |  | 1,712 |  |
| Non-U.S. government and agency securities | 340 |  |  | — |  |  | (1 | ) |  | 339 |  |
| Corporate debt securities | 31,508 |  |  | 80 |  |  | (233 | ) |  | 31,355 |  |
| U.S. agency mortgage-backed securities | 2,106 |  |  | — |  |  | (49 | ) |  | 2,057 |  |
| Commercial paper | 1,414 |  |  | — |  |  | — |  |  | 1,414 |  |
| Certificates of deposit | 196 |  |  | — |  |  | — |  |  | 196 |  |
| Total fixed income securities | 54,792 |  |  | 80 |  |  | (433 | ) |  | 54,439 |  |
| Publicly traded equity securities | 924 |  |  | 697 |  |  | (1 | ) |  | 1,620 |  |
| Total (1) | $ | 55,716 |  |  | $ | 777 |  |  | $ | (434 | ) |  | $ | 56,059 |  |

- changed (2018-05-22):
[0000858877-18-000007:note_history:46]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases (sales) were $(7) million and $(30) million as of April 28, 2018 and July 29, 2017, respectively.
  (was, 2018-02-20, similarity 0.9299):
[0000858877-18-000004:note_history:46]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases (sales) were $(3) million and $(30) million as of January 27, 2018 and July 29, 2017, respectively.

- changed (2018-05-22):
[0000858877-18-000007:note_history:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Gross realized gains | $ | 101 |  |  | $ | 43 |  |  | $ | 333 |  |  | $ | 91 |  |
| Gross realized losses | (84 | ) |  | (119 | ) |  | (225 | ) |  | (182 | ) |
| Total | $ | 17 |  |  | $ | (76 | ) |  | $ | 108 |  |  | $ | (91 | ) |
  (was, 2018-02-20, similarity 0.8266):
[0000858877-18-000004:note_history:47]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Gross realized gains | $ | 165 |  |  | $ | 18 |  |  | $ | 232 |  |  | $ | 48 |  |
| Gross realized losses | (107 | ) |  | (48 | ) |  | (141 | ) |  | (63 | ) |
| Total | $ | 58 |  |  | $ | (30 | ) |  | $ | 91 |  |  | $ | (15 | ) |

- changed (2018-05-22):
[0000858877-18-000007:note_history:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 56 |  |  | $ | (59 | ) |  | $ | 239 |  |  | $ | (50 | ) |
| Net gains (losses) on investments in fixed income securities | (39 | ) |  | (17 | ) |  | (131 | ) |  | (41 | ) |
| Total | $ | 17 |  |  | $ | (76 | ) |  | $ | 108 |  |  | $ | (91 | ) |
  (was, 2018-02-20, similarity 0.789):
[0000858877-18-000004:note_history:48]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2018 |  | January 28, 2017 |  | January 27, 2018 |  | January 28, 2017 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 154 |  |  | $ | 4 |  |  | $ | 183 |  |  | $ | 9 |  |
| Net gains (losses) on investments in fixed income securities | (96 | ) |  | (34 | ) |  | (92 | ) |  | (24 | ) |
| Total | $ | 58 |  |  | $ | (30 | ) |  | $ | 91 |  |  | $ | (15 | ) |

- changed (2018-05-22):
[0000858877-18-000007:note_history:49]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at April 28, 2018 and July 29, 2017 (in millions):
  (was, 2018-02-20, similarity 0.9709):
[0000858877-18-000004:note_history:49]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at January 27, 2018 and July 29, 2017 (in millions):

- changed (2018-05-22):
[0000858877-18-000007:note_history:50]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 28, 2018 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 7,585 |  |  | $ | (99 | ) |  | $ | 5,508 |  |  | $ | (42 | ) |  | $ | 13,093 |  |  | $ | (141 | ) |
| U.S. government agency securities | 473 |  |  | (5 | ) |  | 682 |  |  | (5 | ) |  | 1,155 |  |  | (10 | ) |
| Non-U.S. government and agency securities | 110 |  |  | — |  |  | 171 |  |  | (1 | ) |  | 281 |  |  | (1 | ) |
| Corporate debt securities | 18,094 |  |  | (348 | ) |  | 3,706 |  |  | (106 | ) |  | 21,800 |  |  | (454 | ) |
| U.S. agency mortgage-backed securities | 1,104 |  |  | (32 | ) |  | 827 |  |  | (41 | ) |  | 1,931 |  |  | (73 | ) |
| Total fixed income securities | 27,366 |  |  | (484 | ) |  | 10,894 |  |  | (195 | ) |  | 38,260 |  |  | (679 | ) |
| Publicly traded equity securities | 41 |  |  | (4 | ) |  | — |  |  | — |  |  | 41 |  |  | (4 | ) |
| Total | $ | 27,407 |  |  | $ | (488 | ) |  | $ | 10,894 |  |  | $ | (195 | ) |  | $ | 38,301 |  |  | $ | (683 | ) |
  (was, 2018-02-20, similarity 0.9942):
[0000858877-18-000004:note_history:50]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 27, 2018 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 11,553 |  |  | $ | (96 | ) |  | $ | 5,804 |  |  | $ | (44 | ) |  | $ | 17,357 |  |  | $ | (140 | ) |
| U.S. government agency securities | 1,152 |  |  | (5 | ) |  | 559 |  |  | (5 | ) |  | 1,711 |  |  | (10 | ) |
| Non-U.S. government and agency securities | 136 |  |  | — |  |  | 203 |  |  | (1 | ) |  | 339 |  |  | (1 | ) |
| Corporate debt securities | 16,003 |  |  | (146 | ) |  | 4,287 |  |  | (87 | ) |  | 20,290 |  |  | (233 | ) |
| U.S. agency mortgage-backed securities | 1,161 |  |  | (19 | ) |  | 876 |  |  | (30 | ) |  | 2,037 |  |  | (49 | ) |
| Total fixed income securities | 30,005 |  |  | (266 | ) |  | 11,729 |  |  | (167 | ) |  | 41,734 |  |  | (433 | ) |
| Publicly traded equity securities | 10 |  |  | (1 | ) |  | — |  |  | — |  |  | 10 |  |  | (1 | ) |
| Total | $ | 30,015 |  |  | $ | (267 | ) |  | $ | 11,729 |  |  | $ | (167 | ) |  | $ | 41,744 |  |  | $ | (434 | ) |

- added (2018-05-22):
[0000858877-18-000007:note_history:51]
The net realized losses related to the Company's available-for-sale investments included impairment charges of $26 million and $52 million for the three and nine months ended April 28, 2018, respectively. For the three and nine months ended April 29, 2017, the net realized losses related to the Company's available-for-sale investments included impairment charges of $73 million. These impairment charges related primarily to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary.

- added (2018-05-22):
[0000858877-18-000007:note_history:52]
As of April 28, 2018, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of April 28, 2018, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the nine months ended April 28, 2018.

- changed (2018-05-22):
[0000858877-18-000007:note_history:53]
The Company has evaluated its publicly traded equity securities as of April 28, 2018 and has determined that there were no additional other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.
  (was, 2018-02-20, similarity 0.9899):
[0000858877-18-000004:note_history:53]
The Company has evaluated its publicly traded equity securities as of January 27, 2018 and has determined that there were no additional other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

- changed (2018-05-22):
[0000858877-18-000007:note_history:54]
The following table summarizes the maturities of the Company’s fixed income securities as of April 28, 2018 (in millions):
  (was, 2018-02-20, similarity 0.9661):
[0000858877-18-000004:note_history:54]
The following table summarizes the maturities of the Company’s fixed income securities as of January 27, 2018 (in millions):

- changed (2018-05-22):
[0000858877-18-000007:note_history:55]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 28, 2018 and April 29, 2017 was $0.3 billion and $0.8 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of April 28, 2018 and July 29, 2017, the Company had no outstanding securities lending transactions.
  (was, 2018-02-20, similarity 0.9787):
[0000858877-18-000004:note_history:55]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the six months ended January 27, 2018 and January 28, 2017 was $0.4 billion and $0.9 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 27, 2018 and July 29, 2017, the Company had no outstanding securities lending transactions.

- changed (2018-05-22):
[0000858877-18-000007:note_history:56]
The carrying value of the investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of April 28, 2018 and July 29, 2017, the amounts are summarized in the following table (in millions):
  (was, 2018-02-20, similarity 0.9776):
[0000858877-18-000004:note_history:56]
The carrying value of the investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of January 27, 2018 and July 29, 2017, the amounts are summarized in the following table (in millions):

- changed (2018-05-22):
[0000858877-18-000007:note_history:57]
|  | April 28, 2018 |  | July 29, 2017 |
| Equity method investments | $ | 118 |  |  | $ | 124 |  |
| Cost method investments | 851 |  |  | 859 |  |
| Total | $ | 969 |  |  | $ | 983 |  |
  (was, 2018-02-20, similarity 0.9742):
[0000858877-18-000004:note_history:57]
|  | January 27, 2018 |  | July 29, 2017 |
| Equity method investments | $ | 121 |  |  | $ | 124 |  |
| Cost method investments | 861 |  |  | 859 |  |
| Total | $ | 982 |  |  | $ | 983 |  |

- changed (2018-05-22):
[0000858877-18-000007:note_history:58]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of April 28, 2018, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.
  (was, 2018-02-20, similarity 0.9897):
[0000858877-18-000004:note_history:58]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of January 27, 2018, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

- changed (2018-05-22):
[0000858877-18-000007:note_history:59]
As of April 28, 2018, the carrying value of investments in privately held companies was $969 million, of which $511 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $212 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.
  (was, 2018-02-20, similarity 0.9904):
[0000858877-18-000004:note_history:59]
As of January 27, 2018, the carrying value of investments in privately held companies was $982 million, of which $528 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $215 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.

- removed (2018-05-22):
[0000858877-18-000004:note_history:60]
The net realized losses related to the Company's available-for-sale investments included impairment charges of zero and $26 million for the three and six months ended January 27, 2018, respectively. These impairment charges related primarily to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the corresponding periods in fiscal 2017.

- removed (2018-05-22):
[0000858877-18-000004:note_history:61]
As of January 27, 2018, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of January 27, 2018, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the six months ended January 27, 2018.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-22):
[0000858877-18-000007:note_history:62]
|  |  |  | April 28, 2018 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | — |  |  | — |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 2.50% |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 2.57% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.58% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | — |  |  | — |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.12% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.50% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.38% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.66% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.94% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.78% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.10% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 28,250 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (119 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (59 | ) |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 28,072 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 7,736 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 20,336 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 28,072 |  |  |  |  | $ | 30,472 |  |  |  |
  (was, 2018-02-20, similarity 0.9873):
[0000858877-18-000004:note_history:62]
|  |  |  | January 27, 2018 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | 1,000 |  |  | 2.11% |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.96% |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 2.04% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.01% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.04% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.18% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.11% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.34% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.60% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.46% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.76% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 30,500 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (125 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (1 | ) |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 30,374 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,749 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 25,625 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 30,374 |  |  |  |  | $ | 30,472 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-22):
[0000858877-18-000007:note_history:63]
As of April 28, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2018-02-20, similarity 0.9701):
[0000858877-18-000004:note_history:63]
As of January 27, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2018-05-22):
[0000858877-18-000007:note_history:64]
| Fiscal Year | Amount |
| 2018 (remaining three months) | $ | 2,500 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 28,250 |  |
  (was, 2018-02-20, similarity 0.9739):
[0000858877-18-000004:note_history:64]
| Fiscal Year | Amount |
| 2018 (remaining six months) | $ | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 30,500 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-22):
[0000858877-18-000007:note_history:65]
|  | April 28, 2018 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 7,736 |  |  | 2.91 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | — |  |  | — | % |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 7,736 |  |  |  |  | $ | 7,992 |  |  |  |
  (was, 2018-02-20, similarity 0.9468):
[0000858877-18-000004:note_history:65]
|  | January 27, 2018 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,749 |  |  | 1.78 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | 8,992 |  |  | 1.51 | % |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 13,741 |  |  |  |  | $ | 7,992 |  |  |  |
