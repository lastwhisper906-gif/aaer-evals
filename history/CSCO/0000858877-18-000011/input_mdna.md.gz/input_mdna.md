# CSCO MD&A — 0000858877-18-000011


## mdna

[0000858877-18-000011:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000858877-18-000011:mdna:2]
Forward-Looking Statements

[0000858877-18-000011:mdna:3]
OVERVIEW

[0000858877-18-000011:mdna:4]
Cisco designs and sells a broad range of technologies that have been powering the Internet since 1984. Across networking, security, collaboration, applications and the cloud, our evolving intent-based technologies are constantly learning and adapting to provide customers with a highly secure, intelligent platform for their digital business.

[0000858877-18-000011:mdna:5]
A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-18-000011:mdna:6]
|  | Three Months Ended |  | Years Ended |  |
|  | July 28, 2018 |  | July 29, 2017 |  | Variance |  | July 28, 2018 |  | July 29, 2017 |  | Variance |  |
| Revenue | $ | 12,844 |  |  | $ | 12,133 |  |  | 6 | % |  | $ | 49,330 |  |  | $ | 48,005 |  |  | 3 | % |  |
| Gross margin percentage | 61.7 | % |  | 62.2 | % |  | (0.5 | ) | pts | 62.0 | % |  | 63.0 | % |  | (1.0 | ) | pts |
| Research and development | $ | 1,626 |  |  | $ | 1,499 |  |  | 8 | % |  | $ | 6,332 |  |  | $ | 6,059 |  |  | 5 | % |  |
| Sales and marketing | $ | 2,348 |  |  | $ | 2,318 |  |  | 1 | % |  | $ | 9,242 |  |  | $ | 9,184 |  |  | 1 | % |  |
| General and administrative | $ | 543 |  |  | $ | 495 |  |  | 10 | % |  | $ | 2,144 |  |  | $ | 1,993 |  |  | 8 | % |  |
| Total R&D, sales and marketing, general and administrative | $ | 4,517 |  |  | $ | 4,312 |  |  | 5 | % |  | $ | 17,718 |  |  | $ | 17,236 |  |  | 3 | % |  |
| Total as a percentage of revenue | 35.2 | % |  | 35.5 | % |  | (0.3 | ) | pts | 35.9 | % |  | 35.9 | % |  | — |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 33 |  |  | $ | 58 |  |  | (43 | )% |  | $ | 221 |  |  | $ | 259 |  |  | (15 | )% |  |
| Restructuring and other charges included in operating expenses | $ | 26 |  |  | $ | 142 |  |  | (82 | )% |  | $ | 358 |  |  | $ | 756 |  |  | (53 | )% |  |
| Operating income as a percentage of revenue | 26.1 | % |  | 25.0 | % |  | 1.1 |  | pts | 25.0 | % |  | 24.9 | % |  | 0.1 |  | pts |
| Income tax percentage (1) | (5.9 | )% |  | 23.8 | % |  | (29.7 | ) | pts | 99.2 | % |  | 21.8 | % |  | 77.4 |  | pts |
| Net income (1) | $ | 3,803 |  |  | $ | 2,424 |  |  | 57 | % |  | $ | 110 |  |  | $ | 9,609 |  |  | (99 | )% |  |
| Net income as a percentage of revenue | 29.6 | % |  | 20.0 | % |  | 9.6 |  | pts | 0.2 | % |  | 20.0 | % |  | (19.8 | ) | pts |
| Earnings per share—diluted (1) | $ | 0.81 |  |  | $ | 0.48 |  |  | 69 | % |  | $ | 0.02 |  |  | $ | 1.90 |  |  | (99 | )% |  |

[0000858877-18-000011:mdna:7]
(1) Fourth quarter and fiscal year 2018 results include an $863 million benefit and a $10.4 billion charge, respectively, related to the enactment of the Tax Act.

[0000858877-18-000011:mdna:8]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:9]
In fiscal 2018, we saw broad strength across the business and delivered solid revenue growth, margins, cash flow and returns for our shareholders.  We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. Our product revenue reflected growth in Infrastructure Platforms, Applications and Security, and we continued to make progress in the transition of our business model to increased software and subscriptions. We continue to operate in a challenging and highly competitive environment. We experienced some weakness in the service provider market and we expect ongoing uncertainty in that area. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-18-000011:mdna:10]
Total revenue increased by 3% compared with fiscal 2017. Within total revenue, product and service revenue each increased by 3%. Total gross margin decreased by 1.0 percentage points, driven primarily by unfavorable impacts from pricing, a $127 million legal and indemnification settlement charge, and unfavorable product mix, partially offset by productivity benefits. While productivity was positive to overall product gross margin, the benefit was lower than in the prior year as these improvements were adversely impacted by an increase in the cost of certain components which are currently constrained.  As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, were flat. Operating income as a percentage of revenue increased by 0.1 percentage points. Diluted earnings per share and net income each decreased by 99% due to the $10.4 billion provisional tax expense related to the Tax Act, comprised of $8.1 billion U.S. transition tax, $1.2 billion of foreign withholding tax, and $1.1 billion of net deferred tax assets re-measurement.

[0000858877-18-000011:mdna:11]
In terms of our geographic segments, revenue from the Americas increased by $0.7 billion, EMEA revenue increased by $0.4 billion, and revenue in our APJC segment increased by $0.2 billion. These increases reflect broad strength across several countries within these segments. The “BRICM” countries experienced product revenue growth of 2% in the aggregate, driven by increased product revenue in the emerging countries of Brazil, Russia, India and China of 17%, 10%, 3% and 3%, respectively, partially offset by a product revenue decline of 16% in Mexico.

[0000858877-18-000011:mdna:12]
From a customer market standpoint, we experienced solid product revenue growth in the commercial market and, to a lesser extent, in the enterprise and public sector markets. Product revenue in the service provider market declined with ongoing uncertainty in that area.

[0000858877-18-000011:mdna:13]
From a product category perspective, the product revenue increase of 3% was driven by a 2% product revenue increase in Infrastructure Platforms and solid product revenue growth in Applications and Security of 10% and 9%, respectively. We saw broad strength across the portfolio, with the exception of routing related to the weakness in the service provider market.

[0000858877-18-000011:mdna:14]
Fourth Quarter Snapshot

[0000858877-18-000011:mdna:15]
For the fourth quarter of fiscal 2018, as compared with the fourth quarter of fiscal 2017, total revenue increased by 6%. Within total revenue, product revenue increased by 7% and service revenue increased by 3%.  With regard to our geographic segment performance, on a year-over-year basis, revenue in the Americas, EMEA and APJC increased by 5%, 8% and 6%, respectively. From a product category perspective, we experienced broad strength across the portfolio. Total gross margin decreased by 0.5 percentage points, driven by some specific transactions with service providers in our APJC segment. Our gross margin also decreased due to unfavorable pricing, product mix and higher component costs, partially offset by improved productivity benefits. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively decreased by 0.3 percentage points. Operating income as a percentage of revenue increased by 1.1 percentage points. Diluted earnings per share increased by 69% and net income increased by 57%, due in part to an $863 million tax benefit related to the Tax Act.

[0000858877-18-000011:mdna:16]
Strategy and Priorities

[0000858877-18-000011:mdna:17]
As our customers add billions of new connections to their enterprises, and as more applications move to a multi-cloud environment, we believe the network continues to be extremely critical. We believe that our customers are looking for intent-based networks that provide meaningful business value through automation, security, and analytics across private, hybrid, and multi-cloud environments. Our vision is to deliver highly secure, software-defined, automated and intelligent platforms for our customers. Our strategic priorities include the following: accelerating our pace of innovation, increasing the value of the network, and transforming our business model.

[0000858877-18-000011:mdna:18]
For a full discussion of our strategy and priorities, see Item 1. Business.

[0000858877-18-000011:mdna:19]
Other Key Financial Measures

[0000858877-18-000011:mdna:20]
The following is a summary of our other key financial measures for fiscal 2018 compared with fiscal 2017 (in millions):

[0000858877-18-000011:mdna:21]
|  |  | Fiscal 2018 |  | Fiscal 2017 |
| Cash and cash equivalents and investments |  | $46,548 |  | $70,492 |
| Cash provided by operating activities |  | $13,666 |  | $13,876 |
| Deferred revenue |  | $19,685 |  | $18,494 |
| Repurchases of common stock—stock repurchase program |  | $17,661 |  | $3,706 |
| Dividends |  | $5,968 |  | $5,511 |
| Inventories |  | $1,846 |  | $1,616 |

[0000858877-18-000011:mdna:22]
33

[0000858877-18-000011:mdna:23]
CRITICAL ACCOUNTING ESTIMATES

[0000858877-18-000011:mdna:24]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-18-000011:mdna:25]
Revenue Recognition

[0000858877-18-000011:mdna:26]
Revenue is recognized when all of the following criteria have been met:

[0000858877-18-000011:mdna:27]
| • | Persuasive evidence of an arrangement exists. Contracts, Internet commerce agreements, and customer purchase orders are generally used to determine the existence of an arrangement. |

[0000858877-18-000011:mdna:28]
| • | Delivery has occurred. Shipping documents and customer acceptance, when applicable, are used to verify delivery. For software, delivery is considered to have occurred upon unrestricted license access and license term commencement, when applicable. |

[0000858877-18-000011:mdna:29]
| • | The fee is fixed or determinable. We assess whether the fee is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. |

[0000858877-18-000011:mdna:30]
| • | Collectibility is reasonably assured. We assess collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer’s payment history. |

[0000858877-18-000011:mdna:31]
In instances where final acceptance of the product, system, or solution is specified by the customer, revenue is deferred until all acceptance criteria have been met. When a sale involves multiple deliverables, such as sales of products that include services, the multiple deliverables are evaluated to determine the unit of accounting, and the entire fee from the arrangement is allocated to each unit of accounting based on the relative selling price. Revenue is recognized when the revenue recognition criteria for each unit of accounting are met. For hosting arrangements, we recognize revenue ratably over the hosting period, while usage revenue is recognized based on utilization. Software subscription revenue is deferred and recognized ratably over the subscription term upon delivery of the first product and commencement of the term.

[0000858877-18-000011:mdna:32]
The amount of revenue recognized in a given period is affected by our judgment as to whether an arrangement includes multiple deliverables and, if so, our valuation of the units of accounting.  Our multiple element arrangements may contain only deliverables within the scope of Accounting Standards Codification (ASC) 605, Revenue Recognition, deliverables within the scope of ASC 985-605, Software-Revenue Recognition, or a combination of both. According to the accounting guidance prescribed in ASC 605, we use vendor-specific objective evidence of selling price (VSOE) for each of those units, when available. We determine VSOE based on our normal pricing and discounting practices for the specific product or service when sold separately. In determining VSOE, we require that a substantial majority of the historical standalone transactions have the selling prices for a product or service fall within a reasonably narrow pricing range, generally evidenced by approximately 80% of such historical standalone transactions falling within plus or minus 15% of the median rates. When VSOE does not exist, we apply the selling price hierarchy to applicable multiple-deliverable arrangements. Under the selling price hierarchy, third-party evidence of selling price (TPE) will be considered if VSOE does not exist, and estimated selling price (ESP) will be used if neither VSOE nor TPE is available. Generally, we are not able to determine TPE because our go-to-market strategy differs from that of others in our markets, and the extent of our proprietary technology varies among comparable products or services from those of our peers. In determining ESP, we apply significant judgment as we weigh a variety of factors, based on the characteristics of the deliverable. We typically arrive at an ESP for a product or service that is not sold separately by considering company-specific factors such as geographies, competitive landscape, internal costs, profitability objectives, pricing practices used to establish bundled pricing, and existing portfolio pricing and discounting.

[0000858877-18-000011:mdna:33]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during fiscal 2018 from changes in VSOE, TPE, or ESP.

[0000858877-18-000011:mdna:34]
We make sales to distributors which we refer to as two-tier sales to the end customer. Revenue from two-tier distributors is recognized based on a sell-through method using point-of-sale information provided by these distributors. Distributors participate in various cooperative marketing and other incentive programs, and we maintain estimated accruals and allowances for these programs. If actual credits received by distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-18-000011:mdna:35]
In May 2014, the Financial Accounting Standards Board (FASB) issued ASC 606, Revenue from Contracts with Customers, a new accounting standard related to revenue recognition. ASC 606 will supersede nearly all U.S. GAAP on revenue recognition and eliminate industry-specific guidance. The underlying principle of the new standard is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. It also requires increased disclosures including the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

[0000858877-18-000011:mdna:36]
ASC 606 allows two methods of adoption: i) retrospectively to each prior period presented (“full retrospective method”), or ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption (“modified retrospective method”). We will adopt the new standard using the modified retrospective method at the beginning of our first quarter of fiscal 2019.

[0000858877-18-000011:mdna:37]
We do not expect that ASC 606 will have a material impact on total revenue for fiscal 2019 based on two factors: i) revenue will be accelerated consistent with the changes in timing as indicated in the table in Note 2 to the Consolidated Financial Statements, largely offset by ii) the reduction of revenue from software arrangements where revenue was previously deferred in prior periods and recognized ratably over time as required under the current standard. This preliminary assessment is based on the types and number of revenue arrangements currently in place. The exact impact of ASC 606 will be dependent on facts and circumstances at adoption and could vary from quarter to quarter.

[0000858877-18-000011:mdna:38]
For the first quarter of fiscal 2019, we expect that the adoption of ASC 606 may increase total revenue by about 1% on a year-over-year basis.  For further discussion of ASC 606, including the estimated impacts on transition date, see Note 2 to the Consolidated Financial Statements.

[0000858877-18-000011:mdna:39]
Allowances for Receivables and Sales Returns

[0000858877-18-000011:mdna:40]
The allowances for receivables were as follows (in millions, except percentages):

[0000858877-18-000011:mdna:41]
|  |  | July 28, 2018 |  |  | July 29, 2017 |  |
| Allowance for doubtful accounts |  | $ | 129 |  |  | $ | 211 |  |
| Percentage of gross accounts receivable |  | 2.3 | % |  | 3.9 | % |
| Allowance for credit loss—lease receivables |  | $ | 135 |  |  | $ | 162 |  |
| Percentage of gross lease receivables (1) |  | 4.7 | % |  | 5.5 | % |
| Allowance for credit loss—loan receivables |  | $ | 60 |  |  | $ | 103 |  |
| Percentage of gross loan receivables |  | 1.2 | % |  | 2.3 | % |

[0000858877-18-000011:mdna:42]
(1) Calculated as allowance for credit loss on lease receivables as a percentage of gross lease receivables and residual value before unearned income.

[0000858877-18-000011:mdna:43]
The allowance for doubtful accounts is based on our assessment of the collectibility of customer accounts. We regularly review the adequacy of these allowances by considering internal factors such as historical experience, credit quality and age of the receivable balances as well as external factors such as economic conditions that may affect a customer’s ability to pay as well as historical and expected default frequency rates, which are published by major third-party credit-rating agencies and are updated on a quarterly basis. We also consider the concentration of receivables outstanding with a particular customer in assessing the adequacy of our allowances for doubtful accounts. If a major customer’s creditworthiness deteriorates, if actual defaults are higher than our historical experience, or if other circumstances arise, our estimates of the recoverability of amounts due to us could be overstated, and additional allowances could be required, which could have an adverse impact on our operating results.

[0000858877-18-000011:mdna:44]
The allowance for credit loss on financing receivables is also based on the assessment of collectibility of customer accounts. We regularly review the adequacy of the credit allowances determined either on an individual or a collective basis. When evaluating the financing receivables on an individual basis, we consider historical experience, credit quality and age of receivable balances, and economic conditions that may affect a customer’s ability to pay. When evaluating financing receivables on a collective basis, we use expected default frequency rates published by a major third-party credit-rating agency as well as our own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk and correlation.  Determining expected default frequency rates and loss factors associated with internal credit risk ratings, as well as assessing factors such as economic conditions, concentration of risk, and correlation, are complex and subjective. Our ongoing consideration of all these factors could result in an increase in our allowance for credit loss in the future, which could adversely affect our operating results. Both accounts receivable and financing receivables are charged off at the point when they are considered uncollectible.

[0000858877-18-000011:mdna:45]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of July 28, 2018 and July 29, 2017 was $123 million and $122 million, respectively, and was recorded as a reduction of our accounts receivable and revenue. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-18-000011:mdna:46]
Inventory Valuation and Liability for Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-18-000011:mdna:47]
Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and market, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-18-000011:mdna:48]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.

[0000858877-18-000011:mdna:49]
Our provision for inventory was $63 million, $74 million, and $65 million in fiscal 2018, 2017, and 2016, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $105 million, $124 million, and $134 million in fiscal 2018, 2017, and 2016, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments.

[0000858877-18-000011:mdna:50]
Loss Contingencies and Product Warranties

[0000858877-18-000011:mdna:51]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-18-000011:mdna:52]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-18-000011:mdna:53]
Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty. We accrue for warranty costs as part of our cost of sales based on associated material costs, technical support labor costs, and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends in the rate of customer cases and the cost to support the customer cases within the warranty period. Overhead cost is applied based on estimated time to support warranty activities.

[0000858877-18-000011:mdna:54]
If we experience an increase in warranty claims compared with our historical experience, or if the cost of servicing warranty claims is greater than expected, our profitability could be adversely affected.

[0000858877-18-000011:mdna:55]
Fair Value Measurements

[0000858877-18-000011:mdna:56]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $37.6 billion as of July 28, 2018, compared with $58.8 billion as of July 29, 2017. Our fixed income investment portfolio, as of July 28, 2018, consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-18-000011:mdna:57]
As described more fully in Note 2 to the Consolidated Financial Statements, a valuation hierarchy is based on the level of independent, objective evidence available regarding the value of the investments. It encompasses three classes of investments: Level 1 consists of securities for which there are quoted prices in active markets for identical securities; Level 2 consists of securities for which observable inputs other than Level 1 inputs are used, such as quoted prices for similar securities in active markets or quoted prices for identical securities in less active markets and model-derived valuations for which the variables are derived from, or corroborated by, observable market data; and Level 3 consists of securities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value.

[0000858877-18-000011:mdna:58]
Our Level 2 securities are valued using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from independent pricing vendors, quoted market prices, or other sources to determine the ultimate fair value of our assets and liabilities. We use such pricing data as the primary input, to which we have not made any material adjustments during fiscal 2018 and 2017, to make our assessments and determinations as to the ultimate valuation of our investment portfolio. We are ultimately responsible for the financial statements and underlying estimates.

[0000858877-18-000011:mdna:59]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of July 28, 2018.

[0000858877-18-000011:mdna:60]
Other-than-Temporary Impairments

[0000858877-18-000011:mdna:61]
We recognize an impairment charge when the declines in the fair values of our fixed income or publicly traded equity securities below their cost basis are judged to be other than temporary. The ultimate value realized on these securities, to the extent unhedged, is subject to market price volatility until they are sold.

[0000858877-18-000011:mdna:62]
If the fair value of a debt security is less than its amortized cost, we assess whether the impairment is other than temporary. An impairment is considered other than temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of its entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost of the security. If an impairment is considered other than temporary based on (i) or (ii) described in the prior sentence, the entire difference between the amortized cost and the fair value of the security is recognized in earnings. If an impairment is considered other than temporary based on condition (iii), the amount representing credit loss, defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security, will be recognized in earnings, and the amount relating to all other factors will be recognized in other comprehensive income (OCI). In estimating the amount and timing of cash flows expected to be collected, we consider all available information, including past events, current conditions, the remaining payment terms of the security, the financial condition of the issuer, expected defaults, and the value of underlying collateral.

[0000858877-18-000011:mdna:63]
For publicly traded equity securities, we consider various factors in determining whether we should recognize an impairment charge, including the length of time and extent to which the fair value has been less than our cost basis, the financial condition and near-term prospects of the issuer, and our intent and ability to hold the investment for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-18-000011:mdna:64]
We also have investments in privately held companies, some of which are in the startup or development stages. As of July 28, 2018, our investments in privately held companies were $1,096 million, compared with $983 million as of July 29, 2017, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize.

[0000858877-18-000011:mdna:65]
Goodwill and Purchased Intangible Asset Impairments

[0000858877-18-000011:mdna:66]
Our methodology for allocating the purchase price relating to purchase acquisitions is determined through established valuation techniques. Goodwill represents a residual value as of the acquisition date, which in most cases results in measuring goodwill as an excess of the purchase consideration transferred plus the fair value of any noncontrolling interest in the acquired company over the fair value of net assets acquired, including contingent consideration. We perform goodwill impairment tests on an annual basis in the fourth fiscal quarter and between annual tests in certain circumstances for each reporting unit. The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the new accounting guidance for the fair value measurement of nonfinancial assets.

[0000858877-18-000011:mdna:67]
The goodwill recorded in the Consolidated Balance Sheets as of July 28, 2018 and July 29, 2017 was $31.7 billion and $29.8 billion, respectively. The increase in goodwill during fiscal 2018 was due in large part to our acquisition of BroadSoft. In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in fiscal 2018, 2017, and 2016. For the annual impairment testing in fiscal 2018, the excess of the fair value over the carrying value for each of our reporting units was $73.0 billion for the Americas, $53.0 billion for EMEA, and $35.5 billion for APJC.

[0000858877-18-000011:mdna:68]
During the fourth quarter of fiscal 2018, we performed a sensitivity analysis for goodwill impairment with respect to each of our respective reporting units and determined that a hypothetical 10% decline in the fair value of each reporting unit would not result in an impairment of goodwill for any reporting unit.

[0000858877-18-000011:mdna:69]
The fair value of acquired technology and patents, as well as acquired technology under development, is determined at acquisition date primarily using the income approach, which discounts expected future cash flows to present value. The discount rates used in the present value calculations are typically derived from a weighted-average cost of capital analysis and then adjusted to reflect risks inherent in the development lifecycle as appropriate. We consider the pricing model for products related to these acquisitions to be standard within the high-technology communications industry, and the applicable discount rates represent the rates that market participants would use for valuation of such intangible assets.

[0000858877-18-000011:mdna:70]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. Our impairment charges related to purchased intangible assets were $1 million, $47 million, and $74 million during fiscal 2018, 2017, and 2016, respectively. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-18-000011:mdna:71]
Income Taxes

[0000858877-18-000011:mdna:72]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 99.2%, 21.8%, and 16.9% in fiscal 2018, 2017, and 2016, respectively.

[0000858877-18-000011:mdna:73]
On December 22, 2017, the Tax Act was enacted. The Tax Act significantly revises the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (“federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries.  As a fiscal-year taxpayer, certain provisions of the Tax Act impact us in fiscal 2018, including the change in the federal tax rate and the one-time transition tax, while other provisions will be effective at the beginning of fiscal 2019 including the implementation of a modified territorial tax system and other changes to how foreign earnings are subject to U.S. tax, and elimination of the domestic manufacturing deduction.

[0000858877-18-000011:mdna:74]
As a result of the decrease in the federal tax rate from 35% to 21% effective January 1, 2018, we have computed our income tax expense for the July 28, 2018 fiscal year using a blended federal tax rate of 27%.  The 21% federal tax rate will apply to our fiscal year ending July 27, 2019 and each year thereafter. We must remeasure our DTA using the federal tax rate that will apply when the related temporary differences are expected to reverse.

[0000858877-18-000011:mdna:75]
In December 2017, the Securities and Exchange Commission staff issued Staff Accounting Bulletin No. 118, which addresses how a company recognizes provisional estimates when it does not have the necessary information available, prepared or analyzed (including computations) in reasonable detail to complete its accounting for the effect of the changes in the Tax Act. The measurement period ends when a company has obtained, prepared, and analyzed the information necessary to finalize its accounting, but cannot extend beyond one year. The final impact of the Tax Act may differ from the provisional estimates due to changes in interpretations of the Tax Act, any legislative action to address questions that arise because of the Tax Act, by changes in accounting standard for income taxes and related interpretations in response to the Tax Act, and any updates or changes to estimates used in the provisional amounts. We have determined that the $8.1 billion of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries, the $1.2 billion of foreign withholding tax, and the $1.1 billion of tax expense for DTA re-measurement were each provisional amounts and reasonable estimates for fiscal 2018. Estimates used in the provisional amounts include: the anticipated reversal pattern of the gross DTAs; and earnings, cash positions, foreign taxes and withholding taxes attributable to foreign subsidiaries.

[0000858877-18-000011:mdna:76]
38

[0000858877-18-000011:mdna:77]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.

[0000858877-18-000011:mdna:78]
Significant judgment is also required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000858877-18-000011:mdna:79]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to domestic manufacturing deduction laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 36 countries, including the United States, has made changes to numerous long-standing tax principles. There can be no assurance that these changes, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-18-000011:mdna:80]
39

[0000858877-18-000011:mdna:81]
RESULTS OF OPERATIONS

[0000858877-18-000011:mdna:82]
Revenue

[0000858877-18-000011:mdna:83]
The following table presents the breakdown of revenue between product and service (in millions, except percentages):

[0000858877-18-000011:mdna:84]
|  |  | Years Ended |  | 2018 vs. 2017 |  | 2017 vs. 2016 |
|  |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 36,709 |  |  | $ | 35,705 |  |  | $ | 37,254 |  |  | $ | 1,004 |  |  | 3 | % |  | $ | (1,549 | ) |  | (4 | )% |
| Percentage of revenue |  | 74.4 | % |  | 74.4 | % |  | 75.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | 12,621 |  |  | 12,300 |  |  | 11,993 |  |  | 321 |  |  | 3 | % |  | 307 |  |  | 3 | % |
| Percentage of revenue |  | 25.6 | % |  | 25.6 | % |  | 24.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 49,330 |  |  | $ | 48,005 |  |  | $ | 49,247 |  |  | $ | 1,325 |  |  | 3 | % |  | $ | (1,242 | ) |  | (3 | )% |

[0000858877-18-000011:mdna:85]
We manage our business primarily on a geographic basis, organized into three geographic segments. Our revenue, which includes product and service for each segment, is summarized in the following table (in millions, except percentages):

[0000858877-18-000011:mdna:86]
|  |  | Years Ended |  | 2018 vs. 2017 |  | 2017 vs. 2016 |
|  |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 29,070 |  |  | $ | 28,351 |  |  | $ | 29,392 |  |  | $ | 719 |  |  | 3 | % |  | $ | (1,041 | ) |  | (4 | )% |
| Percentage of revenue |  | 58.9 | % |  | 59.1 | % |  | 59.7 | % |  |  |  |  |  |  |  |  |
| EMEA |  | 12,425 |  |  | 12,004 |  |  | 12,302 |  |  | 421 |  |  | 4 | % |  | (298 | ) |  | (2 | )% |
| Percentage of revenue |  | 25.2 | % |  | 25.0 | % |  | 25.0 | % |  |  |  |  |  |  |  |  |
| APJC |  | 7,834 |  |  | 7,650 |  |  | 7,553 |  |  | 184 |  |  | 2 | % |  | 97 |  |  | 1 | % |
| Percentage of revenue |  | 15.9 | % |  | 15.9 | % |  | 15.3 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 49,330 |  |  | $ | 48,005 |  |  | $ | 49,247 |  |  | $ | 1,325 |  |  | 3 | % |  | $ | (1,242 | ) |  | (3 | )% |

[0000858877-18-000011:mdna:87]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-18-000011:mdna:88]
During the second quarter of fiscal 2016, we completed the sale of the Customer Premises Equipment portion of our Service Provider Video Connected Devices business (“SP Video CPE Business”). SP Video CPE Business revenue was $504 million for fiscal 2016.

[0000858877-18-000011:mdna:89]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:90]
Total revenue increased by 3%. Product and service revenue each increased by 3%. Our total revenue reflected growth across each of our geographic segments. Product revenue for the emerging countries of BRICM, in the aggregate, experienced 2% product revenue growth, with increases in Brazil, Russia, India and China partially offset by a decrease in Mexico.

[0000858877-18-000011:mdna:91]
In addition to the impact of macroeconomic factors, including a reduced IT spending environment and reductions in spending by government entities, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple-element arrangements; the mix of financing arrangements provided to channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment. As has been the case in certain emerging countries from time to time, customers require greater levels of financing arrangements, service, and support, and these activities may occur in future periods, which may also impact the timing of the recognition of revenue.

[0000858877-18-000011:mdna:92]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:93]
Total revenue decreased by 3%. Total company revenue not including SP Video CPE products decreased 2%. Product revenue decreased by 4% while service revenue increased by 3%. Fiscal 2017 had 52 weeks, compared with 53 weeks in fiscal 2016, thus our results for fiscal 2017 reflect one less extra week. We estimate that the additional revenue associated with the extra week was approximately $265 million, $200 million of which was from our services subscriptions, and $65 million from our SaaS offerings such as WebEx, and a small amount from product distribution. Our total revenue declined in the Americas and EMEA geographic segments, while revenue grew in our APJC geographic segment. The emerging countries of BRICM, in the aggregate, experienced a 7% product revenue decline, with revenue declines in Mexico, China, and Brazil partially offset by increases in the other two BRICM countries.

[0000858877-18-000011:mdna:94]
Product Revenue by Segment

[0000858877-18-000011:mdna:95]
The following table presents the breakdown of product revenue by segment (in millions, except percentages):

[0000858877-18-000011:mdna:96]
|  |  | Years Ended |  | 2018 vs. 2017 |  | 2017 vs. 2016 |
|  |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 21,088 |  |  | $ | 20,487 |  |  | $ | 21,663 |  |  | $ | 601 |  |  | 3 | % |  | $ | (1,176 | ) |  | (5 | )% |
| Percentage of product revenue |  | 57.5 | % |  | 57.4 | % |  | 58.1 | % |  |  |  |  |  |  |  |  |
| EMEA |  | 9,671 |  |  | 9,369 |  |  | 9,682 |  |  | 302 |  |  | 3 | % |  | (313 | ) |  | (3 | )% |
| Percentage of product revenue |  | 26.3 | % |  | 26.2 | % |  | 26.0 | % |  |  |  |  |  |  |  |  |
| APJC |  | 5,950 |  |  | 5,849 |  |  | 5,909 |  |  | 101 |  |  | 2 | % |  | (60 | ) |  | (1 | )% |
| Percentage of product revenue |  | 16.2 | % |  | 16.4 | % |  | 15.9 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 36,709 |  |  | $ | 35,705 |  |  | $ | 37,254 |  |  | $ | 1,004 |  |  | 3 | % |  | $ | (1,549 | ) |  | (4 | )% |

[0000858877-18-000011:mdna:97]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-18-000011:mdna:98]
Americas

[0000858877-18-000011:mdna:99]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:100]
Product revenue in the Americas segment increased by 3%, driven by solid growth in the commercial and enterprise markets and, to a lesser extent, growth in the public sector market. Product revenue in the service provider market was flat. From a country perspective, product revenue increased by 3% in the United States, 9% in Canada and 17% in Brazil, partially offset by a decrease of 16% in Mexico.

[0000858877-18-000011:mdna:101]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:102]
The 5% decrease in product revenue in the Americas segment was driven by declines in the service provider, public sector and commercial markets. Product revenue in the enterprise market was flat.  The product revenue decrease in the service provider market was driven in large part by the absence of product sales related to our SP Video CPE Business in fiscal 2017. We had $378 million in product sales related to our SP Video CPE Business in fiscal 2016 in this segment. The product revenue decline in the public sector market was due primarily to lower sales to state and local governments and to the U.S. federal government. From a country perspective, product revenue decreased by 5% in the United States, 28% in Mexico and 7% in Brazil, partially offset by an increase of 2% in Canada.

[0000858877-18-000011:mdna:103]
EMEA

[0000858877-18-000011:mdna:104]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:105]
The increase in product revenue in the EMEA segment of 3% was driven by solid growth in the commercial and public sector markets and, to a lesser extent, growth in the enterprise market. These increases were partially offset by a product revenue decline in the service provider market. Product revenue from emerging countries within EMEA and the remainder of the EMEA segment, which primarily consists of countries in Western Europe, each increased by 3%.

[0000858877-18-000011:mdna:106]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:107]
Product revenue in the EMEA segment decreased by 3%, driven by a decline in the service provider market and, to a lesser extent, declines in the public sector and enterprise markets. Product revenue in the commercial market was flat. The product revenue decrease in the service provider market was driven in part by the absence of product sales related to our SP Video CPE Business in fiscal 2017. We had $108 million in product sales related to our SP Video CPE Business in fiscal 2016 in this segment. Product revenue from emerging countries within EMEA and product revenue for the remainder of the EMEA segment each decreased by 3%.

[0000858877-18-000011:mdna:108]
APJC

[0000858877-18-000011:mdna:109]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:110]
Product revenue in the APJC segment increased by 2%. The product revenue increase was led by solid growth in the commercial and enterprise markets. These increases were partially offset by product revenue declines in the service provider and public sector markets. From a country perspective, product revenue increased by 3% in China and 3% in India, partially offset by a decrease of 3% in Japan.

[0000858877-18-000011:mdna:111]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:112]
Product revenue in the APJC segment decreased by 1%. The product revenue decrease was led by declines in the service provider and public sector markets, partially offset by product revenue growth in the commercial market. Product revenue in the enterprise market was flat. From a country perspective, product revenue decreased by 12% in China, driven by a decrease in sales of Service Provider Video Software and Solutions products, while product revenue increased by 11% in India, 9% in Australia and 2% in Japan. Product sales for this geographic segment were adversely impacted by an $18 million decrease in product sales related to the absence of our SP Video CPE Business.

[0000858877-18-000011:mdna:113]
Product Revenue by Groups of Similar Products

[0000858877-18-000011:mdna:114]
In addition to the primary view on a geographic basis, we also prepare financial information related to groups of similar products and customer markets for various purposes. Effective in the first quarter of fiscal 2018, we began reporting our product revenue in the following categories: Infrastructure Platforms, Applications, Security, and Other Products. This change better aligns our product categories with our evolving business model. Prior period amounts have been reclassified to conform to the current period’s presentation.

[0000858877-18-000011:mdna:115]
The following table presents revenue for groups of similar products (in millions, except percentages):

[0000858877-18-000011:mdna:116]
|  |  | Years Ended |  | 2018 vs. 2017 |  | 2017 vs. 2016 |
|  |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 28,270 |  |  | $ | 27,779 |  |  | $ | 28,851 |  |  | $ | 491 |  |  | 2 | % |  | $ | (1,072 | ) |  | (4 | )% |
| Applications |  | 5,035 |  |  | 4,568 |  |  | 4,438 |  |  | 467 |  |  | 10 | % |  | 130 |  |  | 3 | % |
| Security |  | 2,353 |  |  | 2,153 |  |  | 1,969 |  |  | 200 |  |  | 9 | % |  | 184 |  |  | 9 | % |
| Other Products |  | 1,050 |  |  | 1,205 |  |  | 1,996 |  |  | (155 | ) |  | (13 | )% |  | (791 | ) |  | (40 | )% |
|  |  | $ | 36,709 |  |  | $ | 35,705 |  |  | $ | 37,254 |  |  | $ | 1,004 |  |  | 3 | % |  | $ | (1,549 | ) |  | (4 | )% |

[0000858877-18-000011:mdna:117]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-18-000011:mdna:118]
Infrastructure Platforms

[0000858877-18-000011:mdna:119]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:120]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center. Infrastructure Platforms revenue increased by 2%, or $491 million, with strength across the portfolio with the exception of routing. Switching experienced growth, with solid revenue growth in data center switching driven by an increase in sales of Cisco Nexus 9000 Series products, and with revenue growth in campus switching driven by our intent-based networking Cisco Catalyst 9000 Series. Data center had strong double digit growth driven by higher sales of server products and our hyperconverged data center offering, HyperFlex. We also experienced solid revenue growth from wireless products driven by Meraki as well as our Wave 2 offerings. We had a decrease in sales of routing products, driven by continued weakness in the service provider market.

[0000858877-18-000011:mdna:121]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:122]
Revenue from the Infrastructure Platforms product category decreased by 4% or $1,072 million, driven primarily by lower revenue from switching products. Within switching, we experienced a decrease in sales of  switching products used in campus environments, which we believe was driven both by the uncertainty in the macro environment which led to a slowdown in customer spending, as well as by a highly competitive landscape. These impacts were partially offset by an increase in sales of our ACI portfolio which is included in our data center switching portfolio. We also experienced a decrease in revenue from routing products driven by weakness in enterprise access and a decrease in revenue from data center due to lower sales of server products. We had revenue growth from wireless products driven by Meraki.

[0000858877-18-000011:mdna:123]
Applications

[0000858877-18-000011:mdna:124]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:125]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as the Internet of Things (IoT) and analytics software offerings from Jasper and AppDynamics, respectively.  Revenue in our Applications product category increased by 10%, or $467 million, with growth across all of the businesses. We experienced solid growth in the Telepresence, unified communications, conferencing and analytics from our fiscal 2017 acquisition of AppDynamics.  We continued to increase the amount of deferred revenue and the proportion of recurring revenue related to our Applications product category.

[0000858877-18-000011:mdna:126]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:127]
The increase in revenue in our Applications product category by 3%, or $130 million, was in large part due to increased revenue from our IoT software offerings, driven by our fiscal 2016 Jasper acquisition. The growth in Conferencing revenue and the acquisition of AppDynamics in the third quarter of fiscal 2017 also contributed to the revenue increase in this product category. These increases in revenue were partially offset by decreased revenue from unified communications and Telepresence.

[0000858877-18-000011:mdna:128]
Security

[0000858877-18-000011:mdna:129]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:130]
Revenue in our Security product category increased 9%, or $200 million, driven by higher sales of unified threat management, web security, policy and access and advanced threat products. We continued to increase the amount of deferred revenue and the proportion of recurring revenue related to our Security product category.

[0000858877-18-000011:mdna:131]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:132]
Revenue in our Security product category increased 9%, or $184 million, driven by higher sales of unified threat management, advanced threat security, and web security products.

[0000858877-18-000011:mdna:133]
Other Products

[0000858877-18-000011:mdna:134]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:135]
The decrease in revenue from our Other Products category was primarily driven by a decrease in revenue from Service Provider Video Software and Solutions (“SPVSS”).

[0000858877-18-000011:mdna:136]
On May 1, 2018, we announced a definitive agreement to sell the SPVSS business.  We expect this transaction to close in the first half of fiscal 2019 subject to regulatory approvals and customary closing conditions.

[0000858877-18-000011:mdna:137]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:138]
The decrease in revenue in our Other Products category was in large part due to a decrease in product sales of $504 million related to our SP Video CPE Business and a decrease in revenue from SPVSS products.

[0000858877-18-000011:mdna:139]
Service Revenue by Segment

[0000858877-18-000011:mdna:140]
The following table presents the breakdown of service revenue by segment (in millions, except percentages):

[0000858877-18-000011:mdna:141]
|  | Years Ended |  | 2018 vs. 2017 |  | 2017 vs. 2016 |
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 7,982 |  |  | $ | 7,864 |  |  | $ | 7,729 |  |  | $ | 118 |  |  | 2 | % |  | $ | 135 |  |  | 2 | % |
| Percentage of service revenue | 63.3 | % |  | 63.9 | % |  | 64.4 | % |  |  |  |  |  |  |  |  |
| EMEA | 2,754 |  |  | 2,635 |  |  | 2,620 |  |  | 119 |  |  | 5 | % |  | 15 |  |  | 1 | % |
| Percentage of service revenue | 21.8 | % |  | 21.4 | % |  | 21.9 | % |  |  |  |  |  |  |  |  |
| APJC | 1,885 |  |  | 1,801 |  |  | 1,644 |  |  | 84 |  |  | 5 | % |  | 157 |  |  | 10 | % |
| Percentage of service revenue | 14.9 | % |  | 14.7 | % |  | 13.7 | % |  |  |  |  |  |  |  |  |
| Total | $ | 12,621 |  |  | $ | 12,300 |  |  | $ | 11,993 |  |  | $ | 321 |  |  | 3 | % |  | $ | 307 |  |  | 3 | % |

[0000858877-18-000011:mdna:142]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-18-000011:mdna:143]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:144]
Service revenue increased across all geographic segments. Technical support services revenue increased by 2% and advanced services revenue increased by 4%. Technical support services revenue increased across all geographic segments. The increase in technical support services revenue was driven by an increase in software and solution support offerings. Advanced services revenue, which relates to professional services for specific customer network needs, had solid growth in the EMEA segment and, to a lesser extent, increased in our Americas and APJC segments.

[0000858877-18-000011:mdna:145]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:146]
Service revenue grew 3%. Excluding the $200 million of additional revenue as a result of the extra week in fiscal 2016, service revenue grew 4%. Service revenue grew across all of our geographic segments. Technical support services revenue increased by 3% and advanced services revenue increased by 1%. Technical support services revenue increased across all geographic segments. The increase in technical support services revenue was driven by contract initiations and renewals associated with product sales and an increase in software support offerings. Advanced services revenue had solid revenue growth in our APJC segment, declined slightly in our EMEA segment and was flat in our Americas segment.

[0000858877-18-000011:mdna:147]
Gross Margin

[0000858877-18-000011:mdna:148]
The following table presents the gross margin for products and services (in millions, except percentages):

[0000858877-18-000011:mdna:149]
|  | AMOUNT |  | PERCENTAGE |
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 22,282 |  |  | $ | 22,006 |  |  | $ | 23,093 |  |  | 60.7 | % |  | 61.6 | % |  | 62.0 | % |
| Service | 8,324 |  |  | 8,218 |  |  | 7,867 |  |  | 66.0 | % |  | 66.8 | % |  | 65.6 | % |
| Total | $ | 30,606 |  |  | $ | 30,224 |  |  | $ | 30,960 |  |  | 62.0 | % |  | 63.0 | % |  | 62.9 | % |

[0000858877-18-000011:mdna:150]
Product Gross Margin

[0000858877-18-000011:mdna:151]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:152]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2017 to fiscal 2018:

[0000858877-18-000011:mdna:153]
|  |  | Product Gross Margin Percentage |
| Fiscal 2017 |  | 61.6 | % |
| Product pricing |  | (1.4 | )% |
| Legal and indemnification settlements |  | (0.3 | )% |
| Mix of products sold |  | (0.2 | )% |
| Amortization of purchased intangible assets |  | (0.2 | )% |
| Productivity (1) |  | 1.2 | % |
| Fiscal 2018 |  | 60.7 | % |

[0000858877-18-000011:mdna:154]
(1) Productivity includes overall manufacturing-related costs, such as component costs, warranty expense, provision for inventory, freight, logistics, shipment volume, and other items not categorized elsewhere.

[0000858877-18-000011:mdna:155]
Product gross margin decreased by 0.9 percentage points due largely to unfavorable impacts from product pricing, a charge of $127 million to product cost of sales recorded in fiscal 2018 related to legal and indemnification settlements, and unfavorable product mix, partially offset by productivity benefits.

[0000858877-18-000011:mdna:156]
The negative pricing impact, which was lower than the year-over-year impact we experienced in fiscal 2017, was driven by typical market factors and impacted each of our geographic segments and customer markets. While productivity was positive to overall product gross margin, the benefit was lower than the prior year as these improvements were adversely impacted by an increase in the costs of certain components which are currently constrained. We expect the higher component costs to continue to impact productivity in the near term. Productivity improvements were driven by cost reductions including value engineering efforts (e.g. component redesign, board configuration, test processes, and transformation processes), lower warranty expenses and continued operational efficiency in manufacturing operations. The decrease in product gross margin was also due to an unfavorable mix of products sold driven by negative mix impacts from our Infrastructure Platforms products, partially offset by favorability from Security, Applications and Other Products. Our product gross margin in fiscal 2018 was also negatively impacted by higher amortization expense from purchased intangible assets.

[0000858877-18-000011:mdna:157]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:158]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2016 to fiscal 2017:

[0000858877-18-000011:mdna:159]
|  |  | Product Gross Margin Percentage |
| Fiscal 2016 |  | 62.0 | % |
| Product pricing |  | (2.1 | )% |
| Mix of products sold |  | (0.3 | )% |
| Supplier component remediation adjustment |  | (0.1 | )% |
| Other |  | (0.1 | )% |
| Productivity (1) |  | 1.4 | % |
| SP Video CPE Business impact |  | 0.8 | % |
| Fiscal 2017 |  | 61.6 | % |

[0000858877-18-000011:mdna:160]
Product gross margin decreased by 0.4 percentage points as compared with fiscal 2016. The decrease in product gross margin was largely due to unfavorable impacts from product pricing, lower productivity benefits, and unfavorable product mix, partially offset by a benefit from the divestiture of the lower margin SP Video CPE business in fiscal 2016.

[0000858877-18-000011:mdna:161]
The negative pricing impact was driven by typical market factors and impacted each of our geographic segments and customer markets. While productivity was positive to overall product gross margin, the benefit was lower than the prior year as these improvements were adversely impacted by an increase in the cost of certain memory components.   In addition, productivity was negatively impacted by decreases in core routing and switching revenue which limited our ability to generate cost savings. Productivity improvements were driven by value engineering efforts (e.g. component redesign, board configuration, test processes, and transformation processes), lower warranty expenses and continued operational efficiency in manufacturing operations. The decrease in product gross margin was also due to an unfavorable mix of products sold driven by negative mix impacts from our Infrastructure platform products.

[0000858877-18-000011:mdna:162]
Service Gross Margin

[0000858877-18-000011:mdna:163]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:164]
Our service gross margin percentage decreased by 0.8 percentage points due to increased headcount-related costs and, to a lesser extent, unfavorable mix and increased delivery costs. These cost impacts were partially offset by the resulting benefit to gross margin of higher sales volume in both advanced services and technical support services.

[0000858877-18-000011:mdna:165]
Our service gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-18-000011:mdna:166]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:167]
Our service gross margin percentage increased by 1.2 percentage points due to higher sales volume, decreased delivery costs, favorable mix and, to a lesser extent, lower share-based compensation expense. These benefits to service gross margin were partially offset by increased headcount-related costs.

[0000858877-18-000011:mdna:168]
Gross Margin by Segment

[0000858877-18-000011:mdna:169]
The following table presents the total gross margin for each segment (in millions, except percentages):

[0000858877-18-000011:mdna:170]
|  |  | AMOUNT |  | PERCENTAGE |
| Years Ended |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 18,792 |  |  | $ | 18,284 |  |  | $ | 18,986 |  |  | 64.6 | % |  | 64.5 | % |  | 64.6 | % |
| EMEA |  | 7,945 |  |  | 7,855 |  |  | 7,998 |  |  | 63.9 | % |  | 65.4 | % |  | 65.0 | % |
| APJC |  | 4,726 |  |  | 4,741 |  |  | 4,620 |  |  | 60.3 | % |  | 62.0 | % |  | 61.2 | % |
| Segment total |  | 31,463 |  |  | 30,880 |  |  | 31,604 |  |  | 63.8 | % |  | 64.3 | % |  | 64.2 | % |
| Unallocated corporate items (1) |  | (857 | ) |  | (656 | ) |  | (644 | ) |  |  |  |  |  |  |
| Total |  | $ | 30,606 |  |  | $ | 30,224 |  |  | $ | 30,960 |  |  | 62.0 | % |  | 63.0 | % |  | 62.9 | % |

[0000858877-18-000011:mdna:171]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-18-000011:mdna:172]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-18-000011:mdna:173]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:174]
We experienced a slight gross margin percentage increase in our Americas segment due to productivity improvements, partially offset by unfavorable impacts from pricing and product mix. The unfavorable mix of products sold in this segment was driven by negative mix impacts from our Infrastructure Platforms products, partially offset by favorability from Security, Applications and Other products.

[0000858877-18-000011:mdna:175]
The gross margin percentage decrease in our EMEA segment was due primarily to negative impacts from pricing and, to a lesser extent, an unfavorable product mix, partially offset by productivity improvements. Lower service gross margin also contributed to the decrease in the gross margin in this geographic segment.

[0000858877-18-000011:mdna:176]
The APJC segment gross margin percentage decreased due primarily to the negative impacts from pricing and an unfavorable product mix, partially offset by productivity improvements. Lower service gross margin also contributed to the decrease in the gross margin in this geographic segment.  Our gross margin in this segment was also negatively impacted by specific transactions with service providers.

[0000858877-18-000011:mdna:177]
The gross margin percentage for a particular segment may fluctuate, and period-to-period changes in such percentages may or may not be indicative of a trend for that segment.

[0000858877-18-000011:mdna:178]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:179]
The Americas segment experienced a slight gross margin percentage decrease due to negative impacts from pricing and product mix, partially offset by productivity improvements and the sale of the lower margin SP Video CPE Business. The unfavorable mix impact was driven by Infrastructure Platforms products.

[0000858877-18-000011:mdna:180]
The gross margin percentage increase in our EMEA segment was due primarily to higher service gross margin. Product gross margin in this segment also increased slightly due to the impact of productivity improvements, the sale of the lower margin SP Video CPE Business and a favorable product mix, partially offset by unfavorable impacts from pricing.

[0000858877-18-000011:mdna:181]
The APJC segment gross margin percentage increased due primarily to higher service gross margin. Product gross margin in this segment decreased due to negative impacts from pricing and product mix, partially offset by productivity improvements. The unfavorable mix impact was driven by Infrastructure Platforms products.

[0000858877-18-000011:mdna:182]
Research and Development (“R&D”), Sales and Marketing, and General and Administrative (“G&A”) Expenses

[0000858877-18-000011:mdna:183]
R&D, sales and marketing, and G&A expenses are summarized in the following table (in millions, except percentages):

[0000858877-18-000011:mdna:184]
|  |  | Years Ended |  | 2018 vs. 2017 |  | 2017 vs. 2016 |
|  |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Research and development |  | $ | 6,332 |  |  | $ | 6,059 |  |  | $ | 6,296 |  |  | $ | 273 |  |  | 5 | % |  | $ | (237 | ) |  | (4 | )% |
| Percentage of revenue |  | 12.8 | % |  | 12.6 | % |  | 12.8 | % |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 9,242 |  |  | 9,184 |  |  | 9,619 |  |  | 58 |  |  | 1 | % |  | (435 | ) |  | (5 | )% |
| Percentage of revenue |  | 18.7 | % |  | 19.1 | % |  | 19.5 | % |  |  |  |  |  |  |  |  |
| General and administrative |  | 2,144 |  |  | 1,993 |  |  | 1,814 |  |  | 151 |  |  | 8 | % |  | 179 |  |  | 10 | % |
| Percentage of revenue |  | 4.3 | % |  | 4.2 | % |  | 3.7 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 17,718 |  |  | $ | 17,236 |  |  | $ | 17,729 |  |  | $ | 482 |  |  | 3 | % |  | $ | (493 | ) |  | (3 | )% |
| Percentage of revenue |  | 35.9 | % |  | 35.9 | % |  | 36.0 | % |  |  |  |  |  |  |  |  |

[0000858877-18-000011:mdna:185]
Our fiscal 2016 had an extra week compared with fiscal 2017. We estimate that the extra week in fiscal 2016 contributed approximately $116 million of the year-over-year decrease in total operating expenses (not including share-based compensation expense).

[0000858877-18-000011:mdna:186]
R&D Expenses

[0000858877-18-000011:mdna:187]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:188]
R&D expenses increased primarily due to higher headcount-related expenses, higher discretionary spending and, to a lesser extent, higher acquisition-related costs and higher share-based compensation expense, partially offset by lower contracted services.

[0000858877-18-000011:mdna:189]
We continue to invest in R&D in order to bring a broad range of products to market in a timely fashion. If we believe that we are unable to enter a particular market in a timely manner with internally developed products, we may purchase or license technology from other businesses, or we may partner with or acquire businesses as an alternative to internal R&D.

[0000858877-18-000011:mdna:190]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:191]
R&D expenses decreased primarily due to lower contracted services, lower headcount-related expenses, lower discretionary spending and lower acquisition-related costs, partially offset by higher share-based compensation expense. Lower headcount- related expenses were due to efficiencies related to our restructuring actions and the extra week in fiscal 2016.

[0000858877-18-000011:mdna:192]
Sales and Marketing Expenses

[0000858877-18-000011:mdna:193]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:194]
Sales and marketing expenses increased due to increases in headcount-related expenses, discretionary spending, share-based compensation expense and acquisition-related costs, partially offset by a decrease in contracted services.

[0000858877-18-000011:mdna:195]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:196]
Sales and marketing expenses decreased due to lower headcount-related expenses, lower contracted services, lower discretionary spending, lower acquisition-related costs and, to a lesser extent, lower share-based compensation expense. Lower headcount-related expenses were due to efficiencies related to our restructuring actions. The extra week in fiscal 2016 also contributed to the decrease in headcount-related expenses.

[0000858877-18-000011:mdna:197]
G&A Expenses

[0000858877-18-000011:mdna:198]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:199]
G&A expenses increased due to increases in contracted services, headcount-related expenses, discretionary spending, acquisition-related/divestiture costs and share-based compensation expense, partially offset by gains on divestitures.

[0000858877-18-000011:mdna:200]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:201]
G&A expenses increased primarily due to the $253 million pre-tax gain from the sale of our SP Video CPE Business recorded during fiscal 2016 and, to a lesser extent, higher share-based compensation expense. These increases were partially offset by lower headcount-related expenses and lower contracted services. The extra week in fiscal 2016 contributed to the decreased headcount-related expense.

[0000858877-18-000011:mdna:202]
Effect of Foreign Currency

[0000858877-18-000011:mdna:203]
In fiscal 2018, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $93 million, or 0.5%, compared with fiscal 2017. In fiscal 2017, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $77 million, or 0.4%, compared with fiscal 2016.

[0000858877-18-000011:mdna:204]
Share-Based Compensation Expense

[0000858877-18-000011:mdna:205]
The following table presents share-based compensation expense (in millions):

[0000858877-18-000011:mdna:206]
| Years Ended |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Cost of sales—product |  | $ | 94 |  |  | $ | 85 |  |  | $ | 70 |  |
| Cost of sales—service |  | 133 |  |  | 134 |  |  | 142 |  |
| Share-based compensation expense in cost of sales |  | 227 |  |  | 219 |  |  | 212 |  |
| Research and development |  | 538 |  |  | 529 |  |  | 470 |  |
| Sales and marketing |  | 555 |  |  | 542 |  |  | 545 |  |
| General and administrative |  | 246 |  |  | 236 |  |  | 205 |  |
| Restructuring and other charges |  | 33 |  |  | 3 |  |  | 26 |  |
| Share-based compensation expense in operating expenses |  | 1,372 |  |  | 1,310 |  |  | 1,246 |  |
| Total share-based compensation expense |  | $ | 1,599 |  |  | $ | 1,529 |  |  | $ | 1,458 |  |

[0000858877-18-000011:mdna:207]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:208]
The increase in share-based compensation expense was due primarily to higher expense related to equity awards assumed with respect to our recent acquisitions.

[0000858877-18-000011:mdna:209]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:210]
The increase in share-based compensation expense was due primarily to higher expense related to equity awards assumed with respect to our recent acquisitions.

[0000858877-18-000011:mdna:211]
Amortization of Purchased Intangible Assets

[0000858877-18-000011:mdna:212]
The following table presents the amortization of purchased intangible assets (in millions):

[0000858877-18-000011:mdna:213]
| Years Ended |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 640 |  |  | $ | 556 |  |  | $ | 577 |  |
| Operating expenses |  |  |  |  |  |  |
| Amortization of purchased intangible assets |  | 221 |  |  | 259 |  |  | 303 |  |
| Restructuring and other charges |  | — |  |  | 38 |  |  | — |  |
| Total |  | $ | 861 |  |  | $ | 853 |  |  | $ | 880 |  |

[0000858877-18-000011:mdna:214]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:215]
Amortization of purchased intangible assets increased slightly as amortization from our recent acquisitions was partially offset by decreases related to SPVSS purchased intangibles which were held for sale and lower impairment charges in fiscal 2018.

[0000858877-18-000011:mdna:216]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:217]
Amortization of purchased intangible assets decreased due to certain purchased intangible assets having become fully amortized and lower impairment charges in fiscal 2017, partially offset by amortization of purchased intangible assets from our recent acquisitions.

[0000858877-18-000011:mdna:218]
Restructuring and Other Charges

[0000858877-18-000011:mdna:219]
The following table presents the restructuring and other charges (in millions):

[0000858877-18-000011:mdna:220]
| Years Ended |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Restructuring and other charges: |  |  |  |  |  |  |
| Cost of sales |  | $ | — |  |  | $ | — |  |  | $ | (2 | ) |
| Operating expenses |  |  |  |  |  |  |
| Restructuring and other charges |  | 358 |  |  | 756 |  |  | 268 |  |
| Total |  | $ | 358 |  |  | $ | 756 |  |  | $ | 266 |  |

[0000858877-18-000011:mdna:221]
We initiated a restructuring plan during fiscal 2018 in order to realign our organization and enable further investment in key priority areas, with estimated pretax charges of approximately $300 million. We expect this restructuring plan to be substantially completed in fiscal 2019. See Note 5 to the Consolidated Financial Statements.

[0000858877-18-000011:mdna:222]
We incurred restructuring and other charges of $358 million during fiscal 2018, $108 million of which was related to the restructuring plan initiated during fiscal 2018 and the remainder of which was related to the restructuring plan announced in August 2016.

[0000858877-18-000011:mdna:223]
We incurred restructuring and other charges of $756 million and $266 million during fiscal 2017 and 2016, respectively, in connection with the restructuring plans announced in August 2016 and August 2014.

[0000858877-18-000011:mdna:224]
These charges were primarily cash-based and consisted of employee severance and other one-time termination benefits, and other associated costs. We expect to reinvest substantially all of the cost savings from these restructuring actions in our key priority areas.  As a result, the overall cost savings from these restructuring actions are not expected to be material for future periods.

[0000858877-18-000011:mdna:225]
Operating Income

[0000858877-18-000011:mdna:226]
The following table presents our operating income and our operating income as a percentage of revenue (in millions, except percentages):

[0000858877-18-000011:mdna:227]
| Years Ended |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Operating income |  | $ | 12,309 |  |  | $ | 11,973 |  |  | $ | 12,660 |  |
| Operating income as a percentage of revenue |  | 25.0 | % |  | 24.9 | % |  | 25.7 | % |

[0000858877-18-000011:mdna:228]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:229]
Operating income increased by 3%, and as a percentage of revenue operating income increased by 0.1 percentage points. These increases resulted primarily from an increase in revenue and a decrease in restructuring and other charges.

[0000858877-18-000011:mdna:230]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:231]
Operating income decreased by 5%, and as a percentage of revenue operating income decreased by 0.8 percentage points. These decreases resulted primarily from an increase in restructuring and other charges related to the restructuring action announced in August 2016 and the $253 million pre-tax gain from the sale of our SP Video CPE Business recorded in fiscal 2016.

[0000858877-18-000011:mdna:232]
Interest and Other Income (Loss), Net

[0000858877-18-000011:mdna:233]
Interest Income (Expense), Net   The following table summarizes interest income and interest expense (in millions):

[0000858877-18-000011:mdna:234]
|  | Years Ended |  | 2018 vs. 2017 |  | 2017 vs. 2016 |
|  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |  | Variance in Dollars |  | Variance in Dollars |
| Interest income | $ | 1,508 |  |  | $ | 1,338 |  |  | $ | 1,005 |  |  | $ | 170 |  |  | $ | 333 |  |
| Interest expense | (943 | ) |  | (861 | ) |  | (676 | ) |  | (82 | ) |  | (185 | ) |
| Interest income (expense), net | $ | 565 |  |  | $ | 477 |  |  | $ | 329 |  |  | $ | 88 |  |  | $ | 148 |  |

[0000858877-18-000011:mdna:235]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:236]
Interest income increased driven by higher yields on our portfolio. The increase in interest expense was driven by the impact of higher effective interest rates.

[0000858877-18-000011:mdna:237]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:238]
Interest income increased driven by an increase in our portfolio of cash, cash equivalents, and fixed income investments as well as higher yields on our portfolio. The increase in interest expense was driven by higher average debt balances, which includes commercial paper notes, and the impact of higher effective interest rates on floating-rate senior notes and interest rate swaps associated with fixed-rate senior notes.

[0000858877-18-000011:mdna:239]
Other Income (Loss), Net   The components of other income (loss), net, are summarized as follows (in millions):

[0000858877-18-000011:mdna:240]
|  | Years Ended |  | 2018 vs. 2017 |  | 2017 vs. 2016 |
|  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |  | Variance in Dollars |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |
| Publicly traded equity securities | $ | 529 |  |  | $ | (45 | ) |  | $ | 33 |  |  | $ | 574 |  |  | $ | (78 | ) |
| Fixed income securities | (242 | ) |  | (42 | ) |  | (34 | ) |  | (200 | ) |  | (8 | ) |
| Total available-for-sale investments | 287 |  |  | (87 | ) |  | (1 | ) |  | 374 |  |  | (86 | ) |
| Privately held companies | 11 |  |  | (46 | ) |  | (35 | ) |  | 57 |  |  | (11 | ) |
| Net gains (losses) on investments | 298 |  |  | (133 | ) |  | (36 | ) |  | 431 |  |  | (97 | ) |
| Other gains (losses), net | (133 | ) |  | (30 | ) |  | (33 | ) |  | (103 | ) |  | 3 |  |
| Other income (loss), net | $ | 165 |  |  | $ | (163 | ) |  | $ | (69 | ) |  | $ | 328 |  |  | $ | (94 | ) |

[0000858877-18-000011:mdna:241]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:242]
The change in total net gains (losses) on available-for-sale investments was primarily attributable to higher realized gains on publicly traded equity securities and lower impairment charges on publicly traded equity securities, partially offset by higher realized losses on fixed income securities as a result of market conditions and the timing of sales of these securities.

[0000858877-18-000011:mdna:243]
The change in net gains (losses) on investments in privately held companies was primarily due to lower impairment charges partially offset by lower realized gains on investments in privately held companies.

[0000858877-18-000011:mdna:244]
The change in other gains (losses), net was primarily driven by higher donation expense, net unfavorable foreign exchange impacts and impacts from equity derivatives.

[0000858877-18-000011:mdna:245]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:246]
The change in total net gains (losses) on available-for-sale investments was driven by $74 million of impairment charges on publicly traded equity securities.

[0000858877-18-000011:mdna:247]
The change in net gains (losses) on investments in privately held companies was primarily due to higher impairment charges on investments in privately held companies, partially offset by higher realized gains on investments in privately held companies.

[0000858877-18-000011:mdna:248]
The change in other gains (losses), net was driven by lower donation expense partially offset by impacts from customer lease terminations, foreign exchange and equity derivatives.

[0000858877-18-000011:mdna:249]
Provision for Income Taxes

[0000858877-18-000011:mdna:250]
Fiscal 2018 Compared with Fiscal 2017

[0000858877-18-000011:mdna:251]
The provision for income taxes resulted in an effective tax rate of 99.2% for fiscal 2018, compared with 21.8% for fiscal 2017. The net 77.4 percentage point increase in the effective tax rate was primarily due to the mandatory one-time transition tax on accumulated earnings of foreign subsidiaries, foreign withholding tax, and DTA re-measurement during fiscal 2018.

[0000858877-18-000011:mdna:252]
During fiscal 2018, we recorded a provisional tax expense of $10.4 billion related to the Tax Act, comprised of $8.1 billion of U.S. transition tax, $1.2 billion of foreign withholding tax, and $1.1 billion re-measurement of net DTA. We plan to pay the transition tax in installments over eight years in accordance with the Tax Act. The Tax Act is discussed more fully in Note 16 to the Consolidated Financial Statements.

[0000858877-18-000011:mdna:253]
As a result of the adoption of the new accounting standard on share-based compensation in fiscal 2018, our effective tax rate will increase or decrease based upon the tax effect of the difference between the share-based compensation expenses and the benefits taken on the company's tax returns. We recognize excess tax benefits on a discrete basis and therefore anticipate the effective tax rate to vary from quarter to quarter depending on our share price in each period.

[0000858877-18-000011:mdna:254]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 27% and for further explanation of our provision for income taxes, see Note 16 to the Consolidated Financial Statements.

[0000858877-18-000011:mdna:255]
Fiscal 2017 Compared with Fiscal 2016

[0000858877-18-000011:mdna:256]
The provision for income taxes resulted in an effective tax rate of 21.8% for fiscal 2017, compared with 16.9% for fiscal 2016. The net 4.9 percentage point increase in the effective tax rate was primarily due to the recognition of a net benefit to the provision for income taxes in fiscal 2016 related to our settlement with the IRS of all outstanding items covering fiscal 2008 through fiscal 2010 and reinstatement of the U.S. federal R&D tax credit on December 18, 2015.

[0000858877-18-000011:mdna:257]
LIQUIDITY AND CAPITAL RESOURCES

[0000858877-18-000011:mdna:258]
The following sections discuss the effects of changes in our balance sheet, our capital allocation strategy including stock repurchase program and dividends, our contractual obligations, and certain other commitments and activities on our liquidity and capital resources.

[0000858877-18-000011:mdna:259]
Balance Sheet and Cash Flows

[0000858877-18-000011:mdna:260]
Cash and Cash Equivalents and Investments  The following table summarizes our cash and cash equivalents and investments (in millions):

[0000858877-18-000011:mdna:261]
|  | July 28, 2018 |  | July 29, 2017 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 8,934 |  |  | $ | 11,708 |  |  | $ | (2,774 | ) |
| Fixed income securities | 37,009 |  |  | 57,077 |  |  | (20,068 | ) |
| Publicly traded equity securities | 605 |  |  | 1,707 |  |  | (1,102 | ) |
| Total | $ | 46,548 |  |  | $ | 70,492 |  |  | $ | (23,944 | ) |

[0000858877-18-000011:mdna:262]
The net decrease in cash and cash equivalents and investments from fiscal 2017 to fiscal 2018 was primarily driven by cash returned to shareholders in the form of repurchases of common stock of $17.5 billion under the stock repurchase program and cash dividends of $6.0 billion, net decrease in debt of $8.0 billion, net cash paid for acquisitions of $3.0 billion, the timing of settlements of investments and other of $2.0 billion, and capital expenditures of $0.8 billion.  These uses of cash were partially offset by cash provided by operating activities of $13.7 billion.

[0000858877-18-000011:mdna:263]
In fiscal 2018, we repatriated $70 billion of foreign subsidiary earnings to the U.S. (in the form of cash, cash equivalents, or investments), and paid foreign withholding tax of $1.2 billion. We also paid approximately $125 million of other one-time foreign taxes as a result of the Tax Act. Future repatriation of cash and other property held by our foreign subsidiaries will generally not be subject to U.S. federal tax. As we evaluate the impact of the Tax Act and the future cash needs of our global operations, we may revise the amount of foreign earnings considered to be permanently reinvested in our foreign subsidiaries.

[0000858877-18-000011:mdna:264]
In addition to cash requirements in the normal course of business, on August 2, 2018 we announced our intent to acquire Duo Security, Inc. for a purchase consideration of approximately $2.35 billion in cash and assumed equity awards. See further discussion of liquidity and future payments under “Contractual Obligations” and “Liquidity and Capital Resource Requirements” below.

[0000858877-18-000011:mdna:265]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our fixed income investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-18-000011:mdna:266]
Free Cash Flow and Capital Allocation  As part of our capital allocation strategy, we intend to return a minimum of 50% of our free cash flow annually to our shareholders through cash dividends and repurchases of common stock.

[0000858877-18-000011:mdna:267]
We define free cash flow as net cash provided by operating activities less cash used to acquire property and equipment. The following table reconciles our net cash provided by operating activities to free cash flow (in millions):

[0000858877-18-000011:mdna:268]
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Net cash provided by operating activities | $ | 13,666 |  |  | $ | 13,876 |  |  | $ | 13,570 |  |
| Acquisition of property and equipment | (834 | ) |  | (964 | ) |  | (1,146 | ) |
| Free cash flow | $ | 12,832 |  |  | $ | 12,912 |  |  | $ | 12,424 |  |

[0000858877-18-000011:mdna:269]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue and the timing and amount of tax and other payments. For additional discussion, see “Part I, Item 1A. Risk Factors” in this report.

[0000858877-18-000011:mdna:270]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases. We further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period.  In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness. Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net income provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-18-000011:mdna:271]
The following table summarizes the dividends paid and stock repurchases (in millions, except per-share amounts):

[0000858877-18-000011:mdna:272]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  | TOTAL |
| Years Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | Amount |
| July 28, 2018 |  | $ | 1.24 |  |  | $ | 5,968 |  |  | 432 |  |  | $ | 40.88 |  |  | $ | 17,661 |  |  | $ | 23,629 |  |
| July 29, 2017 |  | $ | 1.10 |  |  | $ | 5,511 |  |  | 118 |  |  | $ | 31.38 |  |  | $ | 3,706 |  |  | $ | 9,217 |  |
| July 30, 2016 |  | $ | 0.94 |  |  | $ | 4,750 |  |  | 148 |  |  | $ | 26.45 |  |  | $ | 3,918 |  |  | $ | 8,668 |  |

[0000858877-18-000011:mdna:273]
Any future dividends are subject to the approval of our Board of Directors.

[0000858877-18-000011:mdna:274]
On February 14, 2018, our Board of Directors authorized a $25 billion increase to the stock repurchase program. The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $19.0 billion, with no termination date.  We expect to utilize this remaining authorized amount for stock repurchases over the next 12 to 18 months.

[0000858877-18-000011:mdna:275]
The purchase price for the shares of our stock repurchased is reflected as a reduction to shareholders’ equity. We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings and (ii) a reduction of common stock and additional paid-in capital. As a result of future stock repurchases, we may report an accumulated deficit in future periods in shareholders’ equity.

[0000858877-18-000011:mdna:276]
Accounts Receivable, Net  The following table summarizes our accounts receivable, net (in millions):

[0000858877-18-000011:mdna:277]
|  | July 28, 2018 |  | July 29, 2017 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,554 |  |  | $ | 5,146 |  |  | $ | 408 |  |

[0000858877-18-000011:mdna:278]
Our accounts receivable net, as of July 28, 2018 increased by approximately 8% compared with the end of fiscal 2017, primarily due to higher product billings in the fourth quarter of fiscal 2018 compared with the fourth quarter of fiscal 2017.

[0000858877-18-000011:mdna:279]
Inventory Supply Chain  The following table summarizes our inventories and purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-18-000011:mdna:280]
|  | July 28, 2018 |  | July 29, 2017 |  | Increase (Decrease) |
| Inventories | $ | 1,846 |  |  | $ | 1,616 |  |  | $ | 230 |  |

[0000858877-18-000011:mdna:281]
Inventory as of July 28, 2018 increased by 14% from our inventory balance at the end of fiscal 2017. The increase in inventory was due to an increase in raw materials due to securing memory supply which is currently constrained and also higher levels of manufactured finished goods in support of current order activity.

[0000858877-18-000011:mdna:282]
Our finished goods consist of distributor inventory and deferred cost of sales and manufactured finished goods. Distributor inventory and deferred cost of sales are related to unrecognized revenue on shipments to distributors and retail partners as well as shipments to customers. Manufactured finished goods consist primarily of build-to-order and build-to-stock products.

[0000858877-18-000011:mdna:283]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity.

[0000858877-18-000011:mdna:284]
Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.  The following table summarizes our purchase commitments with contract manufacturers and suppliers as of the respective period ends (in millions):

[0000858877-18-000011:mdna:285]
| Commitments by Period | July 28, 2018 |  | July 29, 2017 |
| Less than 1 year | $ | 5,407 |  |  | $ | 4,620 |  |
| 1 to 3 years | 710 |  |  | 20 |  |
| 3 to 5 years | 360 |  |  | — |  |
| Total | $ | 6,477 |  |  | $ | 4,640 |  |

[0000858877-18-000011:mdna:286]
Purchase commitments with contract manufacturers and suppliers increased by approximately 40% compared to the end of fiscal 2017.  On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers increased by 33% compared with the end of fiscal 2017.

[0000858877-18-000011:mdna:287]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of rapidly changing technology and customer requirements. We believe the amount of our inventory and purchase commitments is appropriate for our revenue levels.

[0000858877-18-000011:mdna:288]
Financing Receivables and Guarantees  The following table summarizes our financing receivables (in millions):

[0000858877-18-000011:mdna:289]
|  | July 28, 2018 |  | July 29, 2017 |  | Increase (Decrease) |
| Lease receivables, net | $ | 2,576 |  |  | $ | 2,650 |  |  | $ | (74 | ) |
| Loan receivables, net | 4,939 |  |  | 4,457 |  |  | 482 |  |
| Financed service contracts, net | 2,316 |  |  | 2,487 |  |  | (171 | ) |
| Total, net | $ | 9,831 |  |  | $ | 9,594 |  |  | $ | 237 |  |

[0000858877-18-000011:mdna:290]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type and direct-financing leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services.  The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed.  Financing receivables increased by 2%. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-18-000011:mdna:291]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements to customers provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-18-000011:mdna:292]
The volume of channel partner financing was $28.2 billion, $27.0 billion, and $26.9 billion in fiscal 2018, 2017, and 2016, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $953 million and $1.0 billion as of July 28, 2018 and July 29, 2017, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of July 28, 2018, the total maximum potential future payments related to these guarantees was approximately $308 million, of which approximately $122 million was recorded as deferred revenue.

[0000858877-18-000011:mdna:293]
Borrowings

[0000858877-18-000011:mdna:294]
Senior Notes  The following table summarizes the principal amount of our senior notes (in millions):

[0000858877-18-000011:mdna:295]
|  | Maturity Date |  | July 28, 2018 |  | July 29, 2017 |  |
| Senior notes: |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | — |  |  | $ | 1,000 |  |  |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | — |  |  | 900 |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 500 |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 500 |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | — |  |  | 1,250 |  |  |
| 1.65% | June 15, 2018 |  | — |  |  | 1,600 |  |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |  |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1,000 |  |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |  |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1,500 |  |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |  |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2,500 |  |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |  |
| Total |  |  | $ | 25,750 |  |  | $ | 30,500 |  |  |

[0000858877-18-000011:mdna:296]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of July 28, 2018.

[0000858877-18-000011:mdna:297]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes and $3.2 billion in commercial paper notes outstanding as of July 28, 2018 and July 29, 2017, respectively.

[0000858877-18-000011:mdna:298]
55

[0000858877-18-000011:mdna:299]
Credit Facility  On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of July 28, 2018, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-18-000011:mdna:300]
Deferred Revenue   The following table presents the breakdown of deferred revenue (in millions):

[0000858877-18-000011:mdna:301]
|  | July 28, 2018 |  | July 29, 2017 |  | Increase (Decrease) |
| Service | $ | 11,431 |  |  | $ | 11,302 |  |  | $ | 129 |  |
| Product: |  |  |  |  |  |  |
| Deferred revenue related to recurring software and subscription offers | 6,120 |  |  | 4,971 |  |  | 1,149 |  |
| Other product deferred revenue | 2,134 |  |  | 2,221 |  |  | (87 | ) |
| Total product deferred revenue | 8,254 |  |  | 7,192 |  |  | 1,062 |  |
| Total | $ | 19,685 |  |  | $ | 18,494 |  |  | $ | 1,191 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 11,490 |  |  | $ | 10,821 |  |  | $ | 669 |  |
| Noncurrent | 8,195 |  |  | 7,673 |  |  | 522 |  |
| Total | $ | 19,685 |  |  | $ | 18,494 |  |  | $ | 1,191 |  |

[0000858877-18-000011:mdna:302]
Total deferred revenue increased 6% in fiscal 2018. Deferred product revenue increased 15% primarily due to product deferred revenue related to recurring software and subscription offers, which grew 23% on a year-over-year basis to $6.1 billion. Deferred service revenue increased 1%, driven by the impact of contract renewals, partially offset by amortization of deferred service revenue.

[0000858877-18-000011:mdna:303]
Contractual Obligations

[0000858877-18-000011:mdna:304]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. In addition, we plan for and measure our liquidity and capital resources through an annual budgeting process. The following table summarizes our contractual obligations at July 28, 2018 (in millions):

[0000858877-18-000011:mdna:305]
|  | PAYMENTS DUE BY PERIOD |
| July 28, 2018 | Total |  | Less than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than 5 Years |
| Operating leases | $ | 1,220 |  |  | $ | 392 |  |  | $ | 483 |  |  | $ | 234 |  |  | $ | 111 |  |
| Purchase commitments with contract manufacturers and suppliers | 6,477 |  |  | 5,407 |  |  | 710 |  |  | 360 |  |  | — |  |
| Other purchase obligations | 2,192 |  |  | 956 |  |  | 976 |  |  | 125 |  |  | 135 |  |
| Senior notes | 25,750 |  |  | 5,250 |  |  | 9,000 |  |  | 3,000 |  |  | 8,500 |  |
| Transition tax payable | 8,094 |  |  | 787 |  |  | 1,302 |  |  | 1,302 |  |  | 4,703 |  |
| Other long-term liabilities | 1,293 |  |  | — |  |  | 264 |  |  | 168 |  |  | 861 |  |
| Total by period | $ | 45,026 |  |  | $ | 12,792 |  |  | $ | 12,735 |  |  | $ | 5,189 |  |  | $ | 14,310 |  |
| Other long-term liabilities (uncertainty in the timing of future payments) | 1,419 |  |  |  |  |  |  |  |  |  |
| Total | $ | 46,445 |  |  |  |  |  |  |  |  |  |

[0000858877-18-000011:mdna:306]
Operating Leases  For more information on our operating leases, see Note 12 to the Consolidated Financial Statements.

[0000858877-18-000011:mdna:307]
Purchase Commitments with Contract Manufacturers and Suppliers  We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. A significant portion of our reported estimated purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. See further discussion in “Inventory Supply Chain.” As of July 28, 2018, the liability for these purchase commitments was $159 million and is recorded in other current liabilities and is not included in the preceding table.

[0000858877-18-000011:mdna:308]
Other Purchase Obligations  Other purchase obligations represent an estimate of all contractual obligations in the ordinary course of business, other than operating leases and commitments with contract manufacturers and suppliers, for which we have not received the goods or services. Purchase orders are not included in the preceding table as they typically represent our authorization to purchase rather than binding contractual purchase obligations.

[0000858877-18-000011:mdna:309]
Long-Term Debt  The amount of long-term debt in the preceding table represents the principal amount of the respective debt instruments. See Note 10 to the Consolidated Financial Statements.

[0000858877-18-000011:mdna:310]
Transition Tax Payable  In connection with the Tax Act, we recorded an income tax payable of $8.1 billion for the U.S. transition tax on accumulated earnings of foreign subsidiaries. Amounts associated with the Tax Act are considered provisional and may be subject to further adjustment during the measurement period. See Note 16 to the Consolidated Financial Statements.

[0000858877-18-000011:mdna:311]
Other Long-Term Liabilities  Other long-term liabilities primarily include noncurrent income taxes payable, accrued liabilities for deferred compensation, deferred tax liabilities, and certain other long-term liabilities. Due to the uncertainty in the timing of future payments, our noncurrent income taxes payable of approximately $1,278 million and deferred tax liabilities of $141 million were presented as one aggregated amount in the total column on a separate line in the preceding table. Noncurrent income taxes payable include uncertain tax positions. See Note 16 to the Consolidated Financial Statements.

[0000858877-18-000011:mdna:312]
Other Commitments

[0000858877-18-000011:mdna:313]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or the continued employment with us of certain employees of the acquired entities. See Note 12 to the Consolidated Financial Statements.

[0000858877-18-000011:mdna:314]
We also have certain funding commitments primarily related to our investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $223 million as of July 28, 2018, compared with $216 million as of July 29, 2017.

[0000858877-18-000011:mdna:315]
Off-Balance Sheet Arrangements

[0000858877-18-000011:mdna:316]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have investments in privately held companies including venture funds and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and customer financings, and we have determined that as of July 28, 2018 there were no material unconsolidated variable interest entities.

[0000858877-18-000011:mdna:317]
On an ongoing basis, we reassess our investments in privately held companies and customer financings to determine if they are variable interest entities and if we would be regarded as the primary beneficiary pursuant to the applicable accounting guidance. As a result of this ongoing assessment, we may be required to make additional disclosures or consolidate these entities. Because we may not control these entities, we may not have the ability to influence these events.

[0000858877-18-000011:mdna:318]
We provide financing guarantees, which are generally for various third-party financing arrangements extended to our channel partners and end-user customers. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. See the previous discussion of these financing guarantees under “Financing Receivables and Guarantees.”

[0000858877-18-000011:mdna:319]
Liquidity and Capital Resource Requirements

[0000858877-18-000011:mdna:320]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.

[0000858877-18-000011:mdna:321]
57
