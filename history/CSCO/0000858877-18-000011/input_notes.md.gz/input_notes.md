# CSCO notes — 0000858877-18-000011


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-18-000011:notes:1]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-18-000011:notes:2]
|  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Compensation expense related to acquisitions | $ | 203 |  |  | $ | 212 |  |  | $ | 282 |  |


## csco:ConcentrationOfCreditRiskPolicyTextBlock

[0000858877-18-000011:notes:3]
(n) Concentrations of Risk   Cash and cash equivalents are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. We seek to mitigate our credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties.

[0000858877-18-000011:notes:4]
We perform ongoing credit evaluations of our customers and, with the exception of certain financing transactions, do not require collateral from our customers. We receive certain of our components from sole suppliers. Additionally, we rely on a limited number of contract manufacturers and suppliers to provide manufacturing services for our products. The inability of a contract manufacturer or supplier to fulfill our supply requirements could materially impact future operating results.


## csco:DepreciationAndAmortizationPeriodByTypeOfAssetTextBlock

[0000858877-18-000011:notes:5]
Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-18-000011:notes:6]
| Asset Category |  | Period |
| Buildings |  | 25 years |
| Building improvements |  | 10 years |
| Leasehold improvements |  | Shorter of remaining lease term or up to 10 years |
| Computer equipment and related software |  | 30 to 36 months |
| Production, engineering, and other equipment |  | Up to 5 years |
| Operating lease assets |  | Based on lease term |
| Furniture and fixtures |  | 5 years |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-18-000011:notes:7]
The following table presents revenue for groups of similar products and services (in millions):

[0000858877-18-000011:notes:8]
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Revenue: |  |  |  |  |  |
| Infrastructure Platforms | $ | 28,270 |  |  | $ | 27,779 |  |  | $ | 28,851 |  |
| Applications | 5,035 |  |  | 4,568 |  |  | 4,438 |  |
| Security | 2,353 |  |  | 2,153 |  |  | 1,969 |  |
| Other Products (1) | 1,050 |  |  | 1,205 |  |  | 1,996 |  |
| Total Product | 36,709 |  |  | 35,705 |  |  | 37,254 |  |
| Services | 12,621 |  |  | 12,300 |  |  | 11,993 |  |
| Total | $ | 49,330 |  |  | $ | 48,005 |  |  | $ | 49,247 |  |

[0000858877-18-000011:notes:9]
(1) During the second quarter of fiscal 2016, we completed the sale of our SP Video CPE Business.  SP Video CPE Business revenue was $504 million for fiscal 2016.


## csco:OtherThanTemporaryImpairmentLossesOnInvestmentsPolicyTextBlock

[0000858877-18-000011:notes:10]
(c) Other-than-Temporary Impairments on Investments   When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and we will assess whether the impairment is other than temporary. An impairment is considered other than temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of the entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost basis of the security. If impairment is considered other than temporary based on condition (i) or (ii) described earlier, the entire difference between the amortized cost and the fair value of the debt security is recognized in earnings. If an impairment is considered other than temporary based on condition (iii), the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) will be recognized in earnings, and the amount relating to all other factors will be recognized in other comprehensive income (OCI).

[0000858877-18-000011:notes:11]
We recognize an impairment charge on publicly traded equity securities when a decline in the fair value of a security below the respective cost basis is judged to be other than temporary. We consider various factors in determining whether a decline in the fair value of these investments is other than temporary, including the length of time and extent to which the fair value of the security has been less than our cost basis, the financial condition and near-term prospects of the issuer, and our intent and ability to hold the investment for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-18-000011:notes:12]
Investments in privately held companies are included in other assets in the Consolidated Balance Sheets and are accounted for using either the cost or equity method. We monitor these investments for impairments and make reductions in carrying values if we determine that an impairment charge is required based primarily on the financial condition and near-term prospects of these companies.


## csco:ScheduleOfCommonStockRepurchasedTextBlockTableTextBlock

[0000858877-18-000011:notes:13]
A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is as follows (in millions, except per-share amounts):

[0000858877-18-000011:notes:14]
| Years Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| July 28, 2018 |  | 432 |  |  | $ | 40.88 |  |  | $ | 17,661 |  |
| July 29, 2017 |  | 118 |  |  | $ | 31.38 |  |  | $ | 3,706 |  |
| July 30, 2016 |  | 148 |  |  | $ | 26.45 |  |  | $ | 3,918 |  |


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-18-000011:notes:15]
The effect on the Consolidated Statements of Operations of derivative instruments designated as fair value hedges and the underlying hedged items is summarized as follows (in millions):

[0000858877-18-000011:notes:16]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVE INSTRUMENTS FOR THE YEARS ENDED |  | GAINS (LOSSES) RELATED TO HEDGED ITEMS FOR THE YEARS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Interest rate derivatives |  | Interest expense |  | $ | (174 | ) |  | $ | (275 | ) |  | $ | 175 |  |  | $ | 173 |  |  | $ | 271 |  |  | $ | (169 | ) |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-18-000011:notes:17]
The following table presents the amortization of purchased intangible assets (in millions):

[0000858877-18-000011:notes:18]
| Years Ended |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 640 |  |  | $ | 556 |  |  | $ | 577 |  |
| Operating expenses |  |  |  |  |  |  |
| Amortization of purchased intangible assets |  | 221 |  |  | 259 |  |  | 303 |  |
| Restructuring and other charges |  | — |  |  | 38 |  |  | — |  |
| Total |  | $ | 861 |  |  | $ | 853 |  |  | $ | 880 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-18-000011:notes:19]
The following tables present details of our intangible assets acquired through acquisitions completed during fiscal 2018 and 2017 (in millions, except years):

[0000858877-18-000011:notes:20]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2018 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Viptela | 5.0 |  | $ | 144 |  |  | 6.0 |  |  | $ | 35 |  |  | 1.0 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 180 |  |
| Springpath | 4.0 |  | 157 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | 160 |  |
| BroadSoft | 4.0 |  | 255 |  |  | 6.0 |  |  | 169 |  |  | 2.0 |  |  | 6 |  |  | — |  |  | 430 |  |
| Accompany | 4.0 |  | 55 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 55 |  |
| Others (four in total) | 3.9 |  | 39 |  |  | 4.0 |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | 42 |  |
| Total |  |  | $ | 650 |  |  |  |  | $ | 207 |  |  |  |  | $ | 7 |  |  | $ | 3 |  |  | $ | 867 |  |

[0000858877-18-000011:notes:21]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2017 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| CloudLock | 6.0 |  | $ | 32 |  |  | 4.0 |  |  | $ | 3 |  |  | 1.5 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 36 |  |
| AppDynamics | 4.0 |  | 525 |  |  | 7.0 |  |  | 235 |  |  | 2.3 |  |  | 25 |  |  | — |  |  | 785 |  |
| MindMeld | 4.0 |  | 51 |  |  | 1.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 51 |  |
| Others (four in total) | 3.0 |  | 6 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 6 |  |
| Total |  |  | $ | 614 |  |  |  |  | $ | 238 |  |  |  |  | $ | 26 |  |  | $ | — |  |  | $ | 878 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-18-000011:notes:22]
The following tables present details of our purchased intangible assets (in millions):

[0000858877-18-000011:notes:23]
| July 28, 2018 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,711 |  |  | $ | (1,888 | ) |  | $ | 1,823 |  |
| Customer relationships |  | 1,538 |  |  | (937 | ) |  | 601 |  |
| Other |  | 63 |  |  | (38 | ) |  | 25 |  |
| Total purchased intangible assets with finite lives |  | 5,312 |  |  | (2,863 | ) |  | 2,449 |  |
| In-process research and development, with indefinite lives |  | 103 |  |  | — |  |  | 103 |  |
| Total |  | $ | 5,415 |  |  | $ | (2,863 | ) |  | $ | 2,552 |  |

[0000858877-18-000011:notes:24]
| July 29, 2017 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,182 |  |  | $ | (1,386 | ) |  | $ | 1,796 |  |
| Customer relationships |  | 1,353 |  |  | (765 | ) |  | 588 |  |
| Other |  | 82 |  |  | (38 | ) |  | 44 |  |
| Total purchased intangible assets with finite lives |  | 4,617 |  |  | (2,189 | ) |  | 2,428 |  |
| In-process research and development, with indefinite lives |  | 111 |  |  | — |  |  | 111 |  |
| Total |  | $ | 4,728 |  |  | $ | (2,189 | ) |  | $ | 2,539 |  |


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-18-000011:notes:25]
Segment Information and Major Customers

[0000858877-18-000011:notes:26]
| (a) | Revenue and Gross Margin by Segment |

[0000858877-18-000011:notes:27]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-18-000011:notes:28]
Summarized financial information by segment for fiscal 2018, 2017, and 2016, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-18-000011:notes:29]
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Revenue: |  |  |  |  |  |
| Americas | $ | 29,070 |  |  | $ | 28,351 |  |  | $ | 29,392 |  |
| EMEA | 12,425 |  |  | 12,004 |  |  | 12,302 |  |
| APJC | 7,834 |  |  | 7,650 |  |  | 7,553 |  |
| Total | $ | 49,330 |  |  | $ | 48,005 |  |  | $ | 49,247 |  |
| Gross margin: |  |  |  |  |  |
| Americas | $ | 18,792 |  |  | $ | 18,284 |  |  | $ | 18,986 |  |
| EMEA | 7,945 |  |  | 7,855 |  |  | 7,998 |  |
| APJC | 4,726 |  |  | 4,741 |  |  | 4,620 |  |
| Segment total | 31,463 |  |  | 30,880 |  |  | 31,604 |  |
| Unallocated corporate items | (857 | ) |  | (656 | ) |  | (644 | ) |
| Total | $ | 30,606 |  |  | $ | 30,224 |  |  | $ | 30,960 |  |

[0000858877-18-000011:notes:30]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-18-000011:notes:31]
Revenue in the United States was $25.5 billion, $25.0 billion, and $25.9 billion for fiscal 2018, 2017, and 2016, respectively.

[0000858877-18-000011:notes:32]
| (b) | Revenue for Groups of Similar Products and Services |

[0000858877-18-000011:notes:33]
We design, manufacture, and sell IP-based networking and other products related to the communications and IT industry and provide services associated with these products and their use. Effective in the first quarter of fiscal 2018, we began reporting our product and service revenue in the following five categories: Infrastructure Platforms, Applications, Security, Other Products, and Services. The change better aligns our product categories with our evolving business model. Prior period amounts have been reclassified to conform to the current period's presentation.

[0000858877-18-000011:notes:34]
| (c) | Additional Segment Information |

[0000858877-18-000011:notes:35]
The majority of our assets as of July 28, 2018 and July 29, 2017 were attributable to our U.S. operations. In fiscal 2018, 2017, and 2016, no single customer accounted for 10% or more of revenue.

[0000858877-18-000011:notes:36]
Property and equipment information is based on the physical location of the assets. The following table presents property and equipment information for geographic areas (in millions):

[0000858877-18-000011:notes:37]
|  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Property and equipment, net: |  |  |  |  |  |
| United States | $ | 2,487 |  |  | $ | 2,711 |  |  | $ | 2,822 |  |
| International | 519 |  |  | 611 |  |  | 684 |  |
| Total | $ | 3,006 |  |  | $ | 3,322 |  |  | $ | 3,506 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000858877-18-000011:notes:38]
SCHEDULE II

[0000858877-18-000011:notes:39]
VALUATION AND QUALIFYING ACCOUNTS

[0000858877-18-000011:notes:40]
(in millions)

[0000858877-18-000011:notes:41]
|  | Allowances For |
|  | FinancingReceivables |  | AccountsReceivable |
| Year ended July 30, 2016 |  |  |  |
| Balance at beginning of fiscal year | $ | 382 |  |  | $ | 302 |  |
| Provisions (benefits) | 17 |  |  | (26 | ) |
| Recoveries (write-offs), net | (15 | ) |  | (28 | ) |
| Foreign exchange and other | (9 | ) |  | 1 |  |
| Balance at end of fiscal year | $ | 375 |  |  | $ | 249 |  |
| Year ended July 29, 2017 |  |  |  |
| Balance at beginning of fiscal year | $ | 375 |  |  | $ | 249 |  |
| Provisions (benefits) | (35 | ) |  | 27 |  |
| Recoveries (write-offs), net | (49 | ) |  | (61 | ) |
| Foreign exchange and other | 4 |  |  | (4 | ) |
| Balance at end of fiscal year | $ | 295 |  |  | $ | 211 |  |
| Year ended July 28, 2018 |  |  |  |
| Balance at beginning of fiscal year | $ | 295 |  |  | $ | 211 |  |
| Provisions (benefits) | (89 | ) |  | (45 | ) |
| Recoveries (write-offs), net | (6 | ) |  | (37 | ) |
| Foreign exchange and other | 5 |  |  | — |  |
| Balance at end of fiscal year | $ | 205 |  |  | $ | 129 |  |

[0000858877-18-000011:notes:42]
Foreign exchange and other includes the impact of foreign exchange and certain immaterial reclassifications.


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000858877-18-000011:notes:43]
(p) Advertising Costs   We expense all advertising costs as incurred.


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-18-000011:notes:44]
The allowances for credit loss and the related financing receivables are summarized as follows (in millions):

[0000858877-18-000011:notes:45]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 29, 2017 | $ | 162 |  |  | $ | 103 |  |  | $ | 30 |  |  | $ | 295 |  |
| Provisions (benefits) | (26 | ) |  | (43 | ) |  | (20 | ) |  | (89 | ) |
| Recoveries (write-offs), net | (1 | ) |  | (5 | ) |  | — |  |  | (6 | ) |
| Foreign exchange and other | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Allowance for credit loss as of July 28, 2018 | $ | 135 |  |  | $ | 60 |  |  | $ | 10 |  |  | $ | 205 |  |

[0000858877-18-000011:notes:46]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 30, 2016 | $ | 230 |  |  | $ | 97 |  |  | $ | 48 |  |  | $ | 375 |  |
| Provisions (benefits) | (25 | ) |  | 7 |  |  | (17 | ) |  | (35 | ) |
| Recoveries (write-offs), net | (37 | ) |  | (11 | ) |  | (1 | ) |  | (49 | ) |
| Foreign exchange and other | (6 | ) |  | 10 |  |  | — |  |  | 4 |  |
| Allowance for credit loss as of July 29, 2017 | $ | 162 |  |  | $ | 103 |  |  | $ | 30 |  |  | $ | 295 |  |

[0000858877-18-000011:notes:47]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 25, 2015 | $ | 259 |  |  | $ | 87 |  |  | $ | 36 |  |  | $ | 382 |  |
| Provisions (benefits) | (13 | ) |  | 13 |  |  | 17 |  |  | 17 |  |
| Recoveries (write-offs), net | (10 | ) |  | — |  |  | (5 | ) |  | (15 | ) |
| Foreign exchange and other | (6 | ) |  | (3 | ) |  | — |  |  | (9 | ) |
| Allowance for credit loss as of July 30, 2016 | $ | 230 |  |  | $ | 97 |  |  | $ | 48 |  |  | $ | 375 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000858877-18-000011:notes:48]
The Consolidated Financial Statements include the accounts of ours and those of our subsidiaries. All intercompany accounts and transactions have been eliminated.  We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-18-000011:notes:49]
We consolidate our investments in a venture fund managed by SOFTBANK Corp. and its affiliates (“SOFTBANK”) as this is a variable interest entity and we are the primary beneficiary. The noncontrolling interests attributed to SOFTBANK are presented as a separate component from our equity in the equity section of the Consolidated Balance Sheets. SOFTBANK's share of the earnings in the venture fund are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-18-000011:notes:50]
Acquisitions and Divestitures

[0000858877-18-000011:notes:51]
| (a) | Acquisition Summary |

[0000858877-18-000011:notes:52]
We completed eight acquisitions during fiscal 2018. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-18-000011:notes:53]
| Fiscal 2018 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Viptela | $ | 497 |  |  | $ | (18 | ) |  | $ | 180 |  |  | $ | 335 |  |
| Springpath | 248 |  |  | (11 | ) |  | 160 |  |  | 99 |  |
| BroadSoft | 2,179 |  |  | 353 |  |  | 430 |  |  | 1,396 |  |
| Accompany | 222 |  |  | 6 |  |  | 55 |  |  | 161 |  |
| Others (four in total) | 72 |  |  | 4 |  |  | 42 |  |  | 26 |  |
| Total | $ | 3,218 |  |  | $ | 334 |  |  | $ | 867 |  |  | $ | 2,017 |  |

[0000858877-18-000011:notes:54]
On July 31, 2017, we completed our acquisition of privately held Viptela Inc. ("Viptela"), a provider of software-defined wide area networking products. Revenue from the Viptela acquisition has been included in our Infrastructure Platforms product category.

[0000858877-18-000011:notes:55]
On September 22, 2017, we completed our acquisition of privately held Springpath, Inc. ("Springpath"), a hyperconvergence software company. Revenue from the Springpath acquisition has been included in our Infrastructure Platforms product category.

[0000858877-18-000011:notes:56]
On February 1, 2018, we completed our acquisition of publicly held BroadSoft, Inc. ("BroadSoft"), a cloud calling and contact center solutions company. Revenue from the BroadSoft acquisition has been included in our Applications product category.

[0000858877-18-000011:notes:57]
On May 10, 2018, we completed our acquisition of privately held Accompany, a provider of an AI-driven relationship intelligence platform. Results from the Accompany acquisition will be included in our Applications product category.

[0000858877-18-000011:notes:58]
The total purchase consideration related to our acquisitions completed during fiscal 2018 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $187 million.

[0000858877-18-000011:notes:59]
Fiscal 2017 Acquisitions

[0000858877-18-000011:notes:60]
Allocation of the purchase consideration for acquisitions completed in fiscal 2017 is summarized as follows (in millions):

[0000858877-18-000011:notes:61]
| Fiscal 2017 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| CloudLock | $ | 249 |  |  | $ | — |  |  | $ | 36 |  |  | $ | 213 |  |
| AppDynamics | 3,258 |  |  | (175 | ) |  | 785 |  |  | 2,648 |  |
| MindMeld | 104 |  |  | (11 | ) |  | 51 |  |  | 64 |  |
| Others (four in total) | 26 |  |  | — |  |  | 6 |  |  | 20 |  |
| Total | $ | 3,637 |  |  | $ | (186 | ) |  | $ | 878 |  |  | $ | 2,945 |  |

[0000858877-18-000011:notes:62]
On August 1, 2016, we acquired privately held CloudLock Inc. ("CloudLock"), a provider of cloud security that specializes in cloud access security broker technology that provides enterprises with visibility and analytics around user behavior and sensitive data in cloud services. Revenue from the CloudLock acquisition has been included in our Security product category.

[0000858877-18-000011:notes:63]
On March 17, 2017, we acquired privately held AppDynamics, Inc. ("AppDynamics"), an application intelligence software company. AppDynamics's cloud application and business monitoring platform is designed to enable companies to improve application and business performance. With the AppDynamics acquisition, we seek to provide end-to-end visibility and intelligence from the customer's network through to the application. Product revenue from the AppDynamics acquisition has been included in our Other product category.

[0000858877-18-000011:notes:64]
On May 26, 2017, we acquired privately held MindMeld, Inc. ("MindMeld"), an artificial intelligence (AI) company. MindMeld's unique AI platform enables customers to build intelligent and human-like conversational interfaces for any application or device. Revenue from the MindMeld acquisition has been included in our Collaboration product category.

[0000858877-18-000011:notes:65]
The total purchase consideration related to our acquisitions completed during fiscal 2017 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $138 million.

[0000858877-18-000011:notes:66]
Fiscal 2016 Acquisitions

[0000858877-18-000011:notes:67]
In fiscal 2016, we completed 12 acquisitions for total purchase consideration of $3.4 billion.

[0000858877-18-000011:notes:68]
| (b) | Pending Divestiture of Service Provider Video Software Solutions Business |

[0000858877-18-000011:notes:69]
In the fourth quarter of fiscal 2018, we announced a definitive agreement to sell our Service Provider Video Software Solutions ("SPVSS") business. As of July 28, 2018, this business had tangible assets of approximately $175 million (primarily comprised of accounts receivables, inventories and various other current and long-term assets) and net intangible assets and goodwill (based on relative fair value) of $300 million. In addition, the business had total liabilities of approximately $320 million (primarily comprised of deferred revenue and various other current and long-term liabilities). These assets and liabilities were held for sale and were not presented separately as the amounts were not material to the Consolidated Balance Sheet. We expect to have an  immaterial financial statement impact from this transaction upon closing. The transaction is expected to close in the first half of fiscal 2019, subject to customary closing conditions and regulatory approvals.

[0000858877-18-000011:notes:70]
(c)   Pending Acquisition of Duo Security

[0000858877-18-000011:notes:71]
On August 2, 2018, we announced our intent to acquire Duo Security, Inc., the leading provider of unified access security and multi-factor authentication delivered through the cloud. Integrating our network, device and cloud security platforms with Duo Security's zero-trust authentication and access products is designed to enable customers to easily and securely connect users to any application on any networked device.

[0000858877-18-000011:notes:72]
Under the terms of the agreement, we have agreed to pay approximately $2.35 billion in cash and assumed equity awards to acquire Duo Security. The acquisition is expected to close during the first quarter of fiscal 2019 subject to customary closing conditions and regulatory approvals. Upon close of the acquisition, revenue from Duo Security will be included in our Security product category.

[0000858877-18-000011:notes:73]
(d)   Other Acquisition and Divestiture Information

[0000858877-18-000011:notes:74]
Total transaction costs related to our acquisition and divestiture activities during fiscal 2018, 2017, and 2016 were $41 million, $10 million, and $32 million, respectively. These transaction costs were expensed as incurred in G&A expenses in the Consolidated Statements of Operations.

[0000858877-18-000011:notes:75]
Our purchase price allocation for acquisitions completed during recent periods is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information that existed as of the acquisition date but at that time was unknown to us, may become known to us during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date. Adjustments in the purchase price allocation may require a recasting of the amounts allocated to goodwill retroactive to the period in which the acquisition occurred.

[0000858877-18-000011:notes:76]
The goodwill generated from our acquisitions completed during fiscal 2018 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-18-000011:notes:77]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations for the acquisitions completed during fiscal 2018, 2017, and 2016 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.

[0000858877-18-000011:notes:78]
We completed two divestitures during fiscal 2018. The financial statement impact of these divestitures was not material for fiscal 2018.


## us-gaap:BusinessCombinationsAndOtherPurchaseOfBusinessTransactionsPolicyTextBlock

[0000858877-18-000011:notes:79]
(h) Business Combinations We allocate the fair value of the purchase consideration of our acquisitions to the tangible assets, liabilities, and intangible assets acquired, including in-process research and development (IPR&D), based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life. Acquisition-related expenses and related restructuring costs are recognized separately from the business combination and are expensed as incurred.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000858877-18-000011:notes:80]
(a) Cash and Cash Equivalents   We consider all highly liquid investments purchased with an original or remaining maturity of three months or less at the date of purchase to be cash equivalents. Cash and cash equivalents are maintained with various financial institutions.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-18-000011:notes:81]
Commitments and Contingencies

[0000858877-18-000011:notes:82]
| (a) | Operating Leases |

[0000858877-18-000011:notes:83]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, Germany, India, Israel, Japan, Mexico, Poland, and the United Kingdom.  We also lease equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of July 28, 2018 are as follows (in millions):

[0000858877-18-000011:notes:84]
| Fiscal Year | Amount |
| 2019 | $ | 392 |  |
| 2020 | 293 |  |
| 2021 | 190 |  |
| 2022 | 138 |  |
| 2023 | 96 |  |
| Thereafter | 111 |  |
| Total | $ | 1,220 |  |

[0000858877-18-000011:notes:85]
Rent expense for office space and equipment totaled $442 million, $403 million, and $385 million in fiscal 2018, 2017, and 2016, respectively.

[0000858877-18-000011:notes:86]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-18-000011:notes:87]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-18-000011:notes:88]
The following table summarizes our purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-18-000011:notes:89]
| Commitments by Period | July 28, 2018 |  | July 29, 2017 |
| Less than 1 year | $ | 5,407 |  |  | $ | 4,620 |  |
| 1 to 3 years | 710 |  |  | 20 |  |
| 3 to 5 years | 360 |  |  | — |  |
| Total | $ | 6,477 |  |  | $ | 4,640 |  |

[0000858877-18-000011:notes:90]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.  As of July 28, 2018 and July 29, 2017, the liability for these purchase commitments was $159 million and $162 million, respectively, and was included in other current liabilities.

[0000858877-18-000011:notes:91]
| (c) | Other Commitments |

[0000858877-18-000011:notes:92]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-18-000011:notes:93]
As of July 28, 2018, we estimated that future cash compensation expense of up to $352 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-18-000011:notes:94]
In fiscal 2012, we made an investment in Insieme, an early stage company focused on research and development in the data center market. This investment included $100 million of funding and a license to certain of our technology. During fiscal 2014, we acquired the remaining interests in Insieme, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which were determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $441 million during fiscal 2017. We recorded compensation expense of $47 million and $160 million during fiscal 2017 and fiscal 2016, respectively, related to these milestone payments.

[0000858877-18-000011:notes:95]
We also have certain funding commitments, primarily related to our investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $223 million and $216 million as of July 28, 2018 and July 29, 2017, respectively.

[0000858877-18-000011:notes:96]
| (d) | Product Warranties |

[0000858877-18-000011:notes:97]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-18-000011:notes:98]
|  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Balance at beginning of fiscal year | $ | 407 |  |  | $ | 414 |  |  | $ | 449 |  |
| Provisions for warranties issued | 582 |  |  | 691 |  |  | 715 |  |
| Adjustments for pre-existing warranties | (38 | ) |  | (21 | ) |  | (8 | ) |
| Settlements | (592 | ) |  | (677 | ) |  | (714 | ) |
| Divestiture | — |  |  | — |  |  | (28 | ) |
| Balance at end of fiscal year | $ | 359 |  |  | $ | 407 |  |  | $ | 414 |  |

[0000858877-18-000011:notes:99]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-18-000011:notes:100]
| (e) | Financing and Other Guarantees |

[0000858877-18-000011:notes:101]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-18-000011:notes:102]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $28.2 billion, $27.0 billion, and $26.9 billion in fiscal 2018, 2017, and 2016, respectively. The balance of the channel partner financing subject to guarantees was $953 million and $1.0 billion as of July 28, 2018 and July 29, 2017, respectively.

[0000858877-18-000011:notes:103]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $35 million, $51 million, and $63 million in fiscal 2018, 2017, and 2016, respectively.

[0000858877-18-000011:notes:104]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at July 28, 2018 and July 29, 2017, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-18-000011:notes:105]
|  | July 28, 2018 |  | July 29, 2017 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 277 |  |  | $ | 240 |  |
| End user | 31 |  |  | 74 |  |
| Total | $ | 308 |  |  | $ | 314 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (94 | ) |  | $ | (82 | ) |
| End user | (28 | ) |  | (52 | ) |
| Total | $ | (122 | ) |  | $ | (134 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 186 |  |  | $ | 180 |  |

[0000858877-18-000011:notes:106]
Other Guarantees   Our other guarantee arrangements as of July 28, 2018 and July 29, 2017 that were subject to recognition and disclosure requirements were not material.

[0000858877-18-000011:notes:107]
| (f) | Supplier Component Remediation Liability |

[0000858877-18-000011:notes:108]
In fiscal 2014, we recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. We perform regular assessments of the sufficiency of this liability and reduced the amount by $164 million and $74 million in fiscal 2015 and fiscal 2016, respectively, based on updated analyses. We further reduced the liability by $141 million and $58 million in fiscal 2017 and fiscal 2018, respectively, to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program.

[0000858877-18-000011:notes:109]
During the second quarter of fiscal 2017, we recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of our products.

[0000858877-18-000011:notes:110]
The liabilities related to the supplier component remediation matters were $44 million and $174 million as of July 28, 2018 and July 29, 2017, respectively.

[0000858877-18-000011:notes:111]
| (g) | Indemnifications |

[0000858877-18-000011:notes:112]
In the normal course of business, we indemnify other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-18-000011:notes:113]
We have been asked to indemnify certain of our service provider customers that have been subject to patent infringement claims asserted by Sprint Communications Company, L.P. in federal court in Kansas and Delaware. Sprint alleges that the service provider customers infringed Sprint’s patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017 against Time Warner Inc., a jury in Kansas found that Time Warner Cable willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied Time Warner Cable's post-trial motions. Time Warner Cable has appealed. On October 16, 2017, Sprint and Comcast Cable Communications, LLC reached resolution of the claims in Sprint's lawsuit against Comcast and, on October 19, 2017, the Kansas court dismissed Sprint's lawsuit. On December 6, 2017, Sprint and Cox Communications, Inc. reached resolution of the claims in Sprint's lawsuit against Cox, and the Delaware court dismissed Sprint's lawsuit against Cox on December 7, 2017.

[0000858877-18-000011:notes:114]
We believe that Time Warner Cable continues to have strong non-infringement and invalidity defenses and arguments and/or that Sprint's damages claims are inconsistent with prevailing law at trial and/or on appeal. Due to the uncertainty surrounding the litigation process, we are unable to reasonably estimate the ultimate outcome of the Time Warner Cable litigation at this time. Should Sprint prevail in litigation, mediation, or settlement, we, in accordance with our agreements, may have an obligation to indemnify Time Warner Cable for damages, mediation awards, or settlement amounts arising from its use of our products.

[0000858877-18-000011:notes:115]
On January 15, 2016, Huawei Technologies Co. Ltd. (“Huawei”) filed four patent infringement actions against T-Mobile US, Inc. and T-Mobile USA, Inc. (collectively, “T-Mobile”) in federal court in the Eastern District of Texas. Huawei alleged that T-Mobile’s use of 3GPP standards to implement its 3G and 4G cellular networks infringed 12 patents. Huawei's infringement allegations for some of the patents were based on T-Mobile's use of products provided by us in combination with those of other manufacturers. T-Mobile requested indemnity by Cisco with respect to portions of the network that use our equipment. On December 22, 2017, the Eastern District of Texas court dismissed Huawei's four lawsuits after the parties reached settlement, and T-Mobile's indemnity request was subsequently resolved.

[0000858877-18-000011:notes:116]
During fiscal 2018, we recorded legal and indemnification settlement charges of $127 million to product cost of sales in relation to these matters. At this time, we do not anticipate that our obligations regarding the final outcome of the above matters would be material.

[0000858877-18-000011:notes:117]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-18-000011:notes:118]
It is not possible to determine the maximum potential amount under these indemnification agreements due to our limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by us under these agreements have not had a material effect on our operating results, financial position, or cash flows.

[0000858877-18-000011:notes:119]
| (h) | Legal Proceedings |

[0000858877-18-000011:notes:120]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of our former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-18-000011:notes:121]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $218 million for the alleged evasion of import and other taxes, $1.4 billion for interest, and $1.0 billion for various penalties, all determined using an exchange rate as of July 28, 2018. We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-18-000011:notes:122]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and, on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We have appealed to the United States Court of Appeals for the Federal Circuit on various grounds. We believe we have strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, we do not expect it to be material.

[0000858877-18-000011:notes:123]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against us in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that our AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from us. On August 18, 2015, we petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against us is valid over prior art.  On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that we would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. On June 28, 2016, in light of the PTAB's decision to review the patent's validity, the district court issued an order staying the district court case pending the final written decision from the PTAB. On February 22, 2017, following a hearing, the PTAB issued its Final Written Decision that the patent's claims are unpatentable. SSL appealed this decision to the Court of Appeals for the Federal Circuit and, on May 7, 2018, the Federal Circuit summarily affirmed the PTAB's decision of unpatentability.

[0000858877-18-000011:notes:124]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against us and cancelling a trial which had been set for March 12, 2018. On January 16, 2018, Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit.

[0000858877-18-000011:notes:125]
DXC Technology     On August 21, 2015, Cisco and Cisco Systems Capital Corporation (“Cisco Capital”) filed an action in Santa Clara County Superior Court for declaratory judgment and breach of contract against HP Inc. (“HP”) regarding a services agreement for management services of a third party’s network. HP had prepaid the service agreement through a financing arrangement with Cisco Capital, and had terminated its agreement with us. Pursuant to the terms of the service agreement with HP, we determined the credit HP was entitled to receive under the agreement for certain prepaid amounts. HP disputed our credit calculation and contended that we owe a larger credit to HP than we had calculated. In December 2015, we filed an amended complaint which dropped the breach of contract claim in light of HP’s continuing payments to Cisco Capital under the financing arrangement. On January 19, 2016, HP Inc. filed a counterclaim for breach of contract simultaneously with its answer to the amended complaint. DXC Technology Corporation (“DXC”) reported that it is the party in interest in this matter pursuant to the Separation and Distribution Agreement between the then Hewlett-Packard Co. and Hewlett Packard Enterprise Company (“HPE") and the subsequent Separation and Distribution Agreement between HPE and DXC. On January 8, 2018, the court continued the trial date from March 12, 2018 to June 11, 2018. The parties entered into a settlement agreement effective June 30, 2018, resolving all of the claims and cross-claims in the case, and on August 1, 2018, the Court dismissed all claims and cross-claims with prejudice. The settlement did not have a material impact on our results of operations.

[0000858877-18-000011:notes:126]
Arista Networks, Inc.     On February 24, 2016, Arista Networks, Inc. (“Arista”) filed a complaint against us in the U.S. District Court for the Northern District of California, asserting monopolization claims in violation of Section 2 of the Sherman Act and an unfair competition claim under California Bus. and Prof. Code § 17200. On October 31, 2017, Arista filed an amended complaint for Sherman Act monopolization and § 17200 claims, alleging an anticompetitive scheme comprising our copyright infringement action against Arista (which was based on Arista’s copying of our copyright-protected user interfaces) and communications related to that litigation. Arista sought injunctive relief, lost profits, enhanced damages, and restitution. A jury trial was scheduled for August 6, 2018. On August 6, 2018, Cisco and Arista entered into a binding term sheet resolving, except as described below, all of the outstanding litigation between the companies. The terms are as follows: (i) Arista shall pay $400 million to Cisco; (ii) Cisco will not assert against Arista patents that were included in the litigation as long as Arista continues to implement workarounds it had put in place to certain of those patents; (iii) for three years (subject to earlier termination in some circumstances), any claim against the other party regarding patent infringement for its new products, or new features of existing products, will be resolved by an arbitration process; the process will not apply to claims of copyright infringement, trade secret misappropriation or certain other claims; (iv) for five years, neither party will bring an action against the other for patent or copyright (except for any claims of source code misappropriation) infringement regarding their respective products on the market before August 6, 2018; and (v) certain limited changes shall be implemented by Arista to its user interfaces for operation of its products, and the parties will continue to undertake the appeal of the ruling in U.S. District Court for the Northern District of California regarding copyright infringement, with further limited changes if the case is remanded or reversed. The parties also agreed that for five years neither party would bring an action against the other's contract manufacturers, partners or customers for patent or copyright (excluding claims of source code misappropriation) infringement regarding the other party's products on the market before August 6, 2018. We received payment from Arista of $400 million on August 20, 2018, which will be reflected in Cisco's first quarter fiscal 2019 results.

[0000858877-18-000011:notes:127]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the court consolidated the cases alleging infringement of the ‘327 Patent. During the course of the case, defendants ZTE, Nokia, NEC, Fujitsu, Infinera and Huawei reached settlements with Oyster. On August 9, 2018, the court reset the trial for November 5, 2018. While we believe that we have strong non-infringement arguments and that the patent is invalid, if we do not prevail in the District Court, we believe damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, we are unable to reasonably estimate the ultimate outcome of this litigation at this time. However, we do not anticipate that any final outcome of the dispute would be material.

[0000858877-18-000011:notes:128]
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows.

[0000858877-18-000011:notes:129]
For additional information regarding intellectual property litigation, see “Part I, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” of this Annual Report on Form 10-K.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0000858877-18-000011:notes:130]
(q) Share-Based Compensation Expense   We measure and recognize the compensation expense for all share-based awards made to employees and directors, including employee stock options, restricted stock units (RSUs), performance-based restricted stock units (PRSUs), and employee stock purchases related to the Employee Stock Purchase Plan (Employee Stock Purchase Rights) based on estimated fair values. The fair value of employee stock options is estimated on the date of grant using a lattice-binomial option-pricing model (Lattice-Binomial Model) or the Black-Scholes model, and for employee stock purchase rights we estimate the fair value using the Black-Scholes model. The fair value for time-based stock awards and stock awards that are contingent upon the achievement of financial performance metrics is based on the grant date share price reduced by the present value of the expected dividend yield prior to vesting. The fair value of market-based stock awards is estimated using an option-pricing model on the date of grant. Share-based compensation expense is reduced for forfeitures.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-18-000011:notes:131]
Comprehensive Income (Loss)

[0000858877-18-000011:notes:132]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, are summarized as follows (in millions):

[0000858877-18-000011:notes:133]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains and Losses |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 25, 2015 | $ | 310 |  |  | $ | (16 | ) |  | $ | (233 | ) |  | $ | 61 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 151 |  |  | (66 | ) |  | (399 | ) |  | (314 | ) |
| (Gains) losses reclassified out of AOCI | 1 |  |  | 20 |  |  | (6 | ) |  | 15 |  |
| Tax benefit (expense) | (49 | ) |  | 3 |  |  | (42 | ) |  | (88 | ) |
| Total change for the period | 103 |  |  | (43 | ) |  | (447 | ) |  | (387 | ) |
| BALANCE AT JULY 30, 2016 | 413 |  |  | (59 | ) |  | (680 | ) |  | (326 | ) |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (164 | ) |  | 22 |  |  | 318 |  |  | 176 |  |
| (Gains) losses reclassified out of AOCI | 87 |  |  | 79 |  |  | 16 |  |  | 182 |  |
| Tax benefit (expense) | 37 |  |  | (10 | ) |  | (13 | ) |  | 14 |  |
| Total change for the period | (40 | ) |  | 91 |  |  | 321 |  |  | 372 |  |
| BALANCE AT JULY 29, 2017 | 373 |  |  | 32 |  |  | (359 | ) |  | 46 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (543 | ) |  | 21 |  |  | (159 | ) |  | (681 | ) |
| (Gains) losses reclassified out of AOCI | (287 | ) |  | (68 | ) |  | 7 |  |  | (348 | ) |
| Tax benefit (expense) | 93 |  |  | 4 |  |  | (8 | ) |  | 89 |  |
| Total change for the period | (737 | ) |  | (43 | ) |  | (160 | ) |  | (940 | ) |
| Effect of adoption of accounting standard | 54 |  |  | — |  |  | (9 | ) |  | 45 |  |
| BALANCE AT JULY 28, 2018 | $ | (310 | ) |  | $ | (11 | ) |  | $ | (528 | ) |  | $ | (849 | ) |

[0000858877-18-000011:notes:134]
The net gains (losses) reclassified out of AOCI into the Consolidated Statements of Operations, with line item location, during each period were as follows (in millions):

[0000858877-18-000011:notes:135]
|  |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains and losses on available-for-sale investments |  | $ | 287 |  |  | $ | (87 | ) |  | $ | (1 | ) |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | 52 |  |  | (59 | ) |  | (15 | ) |  | Operating expenses |
| Foreign currency derivatives |  | 16 |  |  | (20 | ) |  | (5 | ) |  | Cost of sales—service |
|  |  | 68 |  |  | (79 | ) |  | (20 | ) |  |  |
| Cumulative translation adjustment and actuarial gains and losses |  | (7 | ) |  | (16 | ) |  | 6 |  |  | Operating expenses |
| Total amounts reclassified out of AOCI |  | $ | 348 |  |  | $ | (182 | ) |  | $ | (15 | ) |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-18-000011:notes:136]
Borrowings

[0000858877-18-000011:notes:137]
| (a) | Short-Term Debt |

[0000858877-18-000011:notes:138]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-18-000011:notes:139]
|  | July 28, 2018 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 5,238 |  |  | 3.46 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | — |  |  | — |  |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 5,238 |  |  |  |  | $ | 7,992 |  |  |  |

[0000858877-18-000011:notes:140]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-18-000011:notes:141]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-18-000011:notes:142]
| (b) | Long-Term Debt |

[0000858877-18-000011:notes:143]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-18-000011:notes:144]
|  |  |  | July 28, 2018 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | — |  |  | — |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | — |  |  | — |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 2.86% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.71% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | — |  |  | — |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | — |  |  | — |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.17% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.71% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.52% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.86% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 3.11% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.98% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.27% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 25,750 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (116 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (65 | ) |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 25,569 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 5,238 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 20,331 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 25,569 |  |  |  |  | $ | 30,472 |  |  |  |

[0000858877-18-000011:notes:145]
We entered into interest rate swaps in prior periods with an aggregate notional amount of $6.75 billion designated as fair value hedges of certain of our fixed-rate senior notes.  These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR).  The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.  For additional information, see Note 11.

[0000858877-18-000011:notes:146]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes.  Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.”  As of July 28, 2018, we were in compliance with all debt covenants.

[0000858877-18-000011:notes:147]
As of July 28, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-18-000011:notes:148]
| Fiscal Year | Amount |
| 2019 | $ | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| Thereafter | 8,500 |  |
| Total | $ | 25,750 |  |

[0000858877-18-000011:notes:149]
| (c) | Credit Facility |

[0000858877-18-000011:notes:150]
On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.

[0000858877-18-000011:notes:151]
This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of July 28, 2018, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-18-000011:notes:152]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 11,431 |  |  | $ | 11,302 |  |
| Product: |  |  |  |  |
| Deferred revenue related to recurring software and subscription offers |  | 6,120 |  |  | 4,971 |  |
| Other product deferred revenue |  | 2,134 |  |  | 2,221 |  |
| Total product deferred revenue |  | 8,254 |  |  | 7,192 |  |
| Total |  | $ | 19,685 |  |  | $ | 18,494 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 11,490 |  |  | $ | 10,821 |  |
| Noncurrent |  | 8,195 |  |  | 7,673 |  |
| Total |  | $ | 19,685 |  |  | $ | 18,494 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-18-000011:notes:153]
Derivative Instruments

[0000858877-18-000011:notes:154]
| (a) | Summary of Derivative Instruments |

[0000858877-18-000011:notes:155]
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We do, however, seek to mitigate such risks by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-18-000011:notes:156]
The fair values of our derivative instruments and the line items on the Consolidated Balance Sheets to which they were recorded are summarized as follows (in millions):

[0000858877-18-000011:notes:157]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | July 28, 2018 |  | July 29, 2017 |  | Balance Sheet Line Item |  | July 28, 2018 |  | July 29, 2017 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 1 |  |  | $ | 46 |  |  | Other current liabilities |  | $ | — |  |  | $ | 1 |  |
| Interest rate derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 10 |  |  | — |  |
| Interest rate derivatives | Other assets |  | — |  |  | 102 |  |  | Other long-term liabilities |  | 62 |  |  | — |  |
| Total |  |  | 1 |  |  | 148 |  |  |  |  | 72 |  |  | 1 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 1 |  |  | 1 |  |  | Other current liabilities |  | 2 |  |  | 3 |  |
| Total |  |  | 1 |  |  | 1 |  |  |  |  | 2 |  |  | 3 |  |
| Total |  |  | $ | 2 |  |  | $ | 149 |  |  |  |  | $ | 74 |  |  | $ | 4 |  |

[0000858877-18-000011:notes:158]
The effects of our cash flow and net investment hedging instruments on other comprehensive income (OCI) and the Consolidated Statements of Operations are summarized as follows (in millions):

[0000858877-18-000011:notes:159]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FORTHE YEARS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FORTHE YEARS ENDED (EFFECTIVE PORTION) |
|  |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |  | Line Item in Statements of Operations |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 20 |  |  | $ | 22 |  |  | $ | (66 | ) |  | Operating expenses |  | $ | 52 |  |  | $ | (59 | ) |  | $ | (15 | ) |
|  |  |  |  |  |  |  |  | Cost of sales — service |  | 16 |  |  | (20 | ) |  | (5 | ) |
| Total |  | $ | 20 |  |  | $ | 22 |  |  | $ | (66 | ) |  | Total |  | $ | 68 |  |  | $ | (79 | ) |  | $ | (20 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (1 | ) |  | $ | (15 | ) |  | $ | 16 |  |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000858877-18-000011:notes:160]
As of July 28, 2018, we estimate that approximately $1 million of net derivative gains related to our cash flow hedges included in AOCI will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-18-000011:notes:161]
The effect on the Consolidated Statements of Operations of derivative instruments not designated as hedges is summarized as follows (in millions):

[0000858877-18-000011:notes:162]
|  |  |  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (24 | ) |  | $ | 13 |  |  | $ | (19 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | 50 |  |  | 53 |  |  | 6 |  |
|  |  | Cost of sales — product |  | 1 |  |  | 2 |  |  | — |  |
|  |  | Cost of sales — service |  | 3 |  |  | 3 |  |  | 1 |  |
|  |  | Other income (loss), net |  | (11 | ) |  | — |  |  | — |  |
| Equity derivatives |  | Other income (loss), net |  | (4 | ) |  | 11 |  |  | 13 |  |
| Total |  |  |  | $ | 15 |  |  | $ | 82 |  |  | $ | 1 |  |

[0000858877-18-000011:notes:163]
The notional amounts of our outstanding derivatives are summarized as follows (in millions):

[0000858877-18-000011:notes:164]
|  | July 28, 2018 |  | July 29, 2017 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 147 |  |  | $ | 1,696 |  |
| Interest rate derivatives | 6,750 |  |  | 6,750 |  |
| Net investment hedging instruments | 250 |  |  | 351 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,298 |  |  | 2,258 |  |
| Total return swaps—deferred compensation | 566 |  |  | 535 |  |
| Total | $ | 10,011 |  |  | $ | 11,590 |  |

[0000858877-18-000011:notes:165]
| (b) | Offsetting of Derivative Instruments |

[0000858877-18-000011:notes:166]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets.  However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty.  To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Information related to these offsetting arrangements is summarized as follows (in millions):

[0000858877-18-000011:notes:167]
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEET |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETBUT WITH LEGAL RIGHTS TO OFFSET |
| July 28, 2018 | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |
| Derivatives liabilities | $ | 74 |  |  | $ | — |  |  | $ | 74 |  |  | $ | (2 | ) |  | $ | (53 | ) |  | $ | 19 |  |

[0000858877-18-000011:notes:168]
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEET |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETBUT WITH LEGAL RIGHTS TO OFFSET |
| July 29, 2017 | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 149 |  |  | $ | — |  |  | $ | 149 |  |  | $ | (4 | ) |  | $ | (81 | ) |  | $ | 64 |  |
| Derivatives liabilities | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |  | $ | (4 | ) |  | $ | — |  |  | $ | — |  |

[0000858877-18-000011:notes:169]
| (c) | Foreign Currency Exchange Risk |

[0000858877-18-000011:notes:170]
We conduct business globally in numerous currencies. Therefore, we are exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, we enter into foreign currency contracts. We do not enter into such contracts for speculative purposes.

[0000858877-18-000011:notes:171]
We may hedge forecasted foreign currency transactions related to certain revenues, operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. We assess effectiveness based on changes in total fair value of the derivatives. The effective portion of the derivative instrument’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion, if any, of the gain or loss is reported in earnings immediately. During the fiscal years presented, we did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-18-000011:notes:172]
We enter into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, including long-term customer financings, investments, and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of intercompany balances or other current assets, investments, or liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-18-000011:notes:173]
We hedge certain net investments in our foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on our net investment in those foreign subsidiaries. These derivative instruments generally have maturities of up to six months.

[0000858877-18-000011:notes:174]
| (d) | Interest Rate Risk |

[0000858877-18-000011:notes:175]
Interest Rate Derivatives, Investments   Our primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, we may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of July 28, 2018 and July 29, 2017, we did not have any outstanding interest rate derivatives related to our fixed income securities.

[0000858877-18-000011:notes:176]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt   In fiscal 2018, we did not enter into any interest rate swaps. In prior fiscal years, we entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2019 through 2025. Under these interest rate swaps, we receive fixed-rate interest payments and make interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps were reflected in other assets and other current and long-term liabilities.

[0000858877-18-000011:notes:177]
| (e) | Equity Price Risk |

[0000858877-18-000011:notes:178]
We may hold equity securities for strategic purposes or to diversify our overall investment portfolio. The publicly traded equity securities in our portfolio are subject to price risk. To manage our exposure to changes in the fair value of certain equity securities, we have periodically entered into equity derivatives that are designated as fair value hedges. The changes in the value of the hedging instruments are included in other income (loss), net, and offset the change in the fair value of the underlying hedged investment. In addition, we periodically enter into equity derivatives that are not designated as accounting hedges. The changes in the fair value of these derivatives are also included in other income (loss), net.

[0000858877-18-000011:notes:179]
We are also exposed to variability in compensation charges related to certain deferred compensation obligations to employees. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure.

[0000858877-18-000011:notes:180]
| (f) | Hedge Effectiveness |

[0000858877-18-000011:notes:181]
For the fiscal years presented, amounts excluded from the assessment of hedge effectiveness were not material for fair value, cash flow, and net investment hedges. In addition, hedge ineffectiveness for fair value, cash flow, and net investment hedges was not material for any of the fiscal years presented.


## us-gaap:DerivativesPolicyTextBlock

[0000858877-18-000011:notes:182]
(l) Derivative Instruments   We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the effective portion of the derivative’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion of the gain or loss is reported in earnings immediately. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. Any ineffective portion of the net investment hedges is reported in earnings during the period of change. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.

[0000858877-18-000011:notes:183]
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-18-000011:notes:184]
Employee Benefit Plans

[0000858877-18-000011:notes:185]
| (a) | Employee Stock Incentive Plans |

[0000858877-18-000011:notes:186]
Stock Incentive Plan Program Description    As of July 28, 2018, we had one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with Cisco. The number and frequency of share-based awards are based on competitive practices, operating results of Cisco, government regulations, and other factors. Our primary stock incentive plan is summarized as follows:

[0000858877-18-000011:notes:187]
2005 Plan    As of July 28, 2018, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus shares from certain previous plans that are forfeited or are terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan. In addition, starting November 19, 2013, shares withheld by Cisco from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-18-000011:notes:188]
Pursuant to an amendment approved by our shareholders on November 12, 2009, the number of shares available for issuance under the 2005 Plan is reduced by 1.5 shares for each share awarded as a stock grant or a stock unit, and any shares underlying awards outstanding from certain previous plans that expire unexercised at the end of their maximum terms become available for reissuance under the 2005 Plan. The 2005 Plan permits the granting of stock options, restricted stock, and RSUs, the vesting of which may be performance-based or market-based along with the requisite service requirement, and stock appreciation rights to employees (including employee directors and officers), consultants of Cisco and its subsidiaries and affiliates, and non-employee directors of Cisco. Stock options and stock appreciation rights granted under the 2005 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date. The expiration date for stock options and stock appreciation rights shall be no later than 10 years from the grant date.

[0000858877-18-000011:notes:189]
The stock options will generally become exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively. Time-based stock grants and time-based RSUs will generally vest over a four year term.  The majority of the performance-based and market-based RSUs vests at the end of the three-year requisite service period or earlier if the award recipient meets certain retirement eligibility conditions. Certain performance-based RSUs that are based on the achievement of financial and/or non-financial operating goals typically vest upon the achievement of milestones (and may require subsequent service periods), with overall vesting of the shares underlying the award ranging from six months to three years.  The Compensation and Management Development Committee of our Board of Directors has the discretion to use different vesting schedules. Stock appreciation rights may be awarded in combination with stock options or stock grants, and such awards shall provide that the stock appreciation rights will not be exercisable unless the related stock options or stock grants are forfeited. Stock grants may be awarded in combination with non-statutory stock options, and such awards may provide that the stock grants will be forfeited in the event that the related non-statutory stock options are exercised.

[0000858877-18-000011:notes:190]
| (b) | Employee Stock Purchase Plan |

[0000858877-18-000011:notes:191]
We have an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 621 million shares of our common stock have been reserved for issuance as of July 28, 2018. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of our stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. The Purchase Plan is scheduled to terminate on January 3, 2020. We issued 22 million, 23 million, and 25 million shares under the Purchase Plan in fiscal 2018, 2017, and 2016, respectively. As of July 28, 2018, 78 million shares were available for issuance under the Purchase Plan.

[0000858877-18-000011:notes:192]
| (c) | Summary of Share-Based Compensation Expense |

[0000858877-18-000011:notes:193]
Share-based compensation expense consists primarily of expenses for stock options, stock purchase rights, restricted stock, and RSUs granted to employees. The following table summarizes share-based compensation expense (in millions):

[0000858877-18-000011:notes:194]
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Cost of sales—product | $ | 94 |  |  | $ | 85 |  |  | $ | 70 |  |
| Cost of sales—service | 133 |  |  | 134 |  |  | 142 |  |
| Share-based compensation expense in cost of sales | 227 |  |  | 219 |  |  | 212 |  |
| Research and development | 538 |  |  | 529 |  |  | 470 |  |
| Sales and marketing | 555 |  |  | 542 |  |  | 545 |  |
| General and administrative | 246 |  |  | 236 |  |  | 205 |  |
| Restructuring and other charges | 33 |  |  | 3 |  |  | 26 |  |
| Share-based compensation expense in operating expenses | 1,372 |  |  | 1,310 |  |  | 1,246 |  |
| Total share-based compensation expense | $ | 1,599 |  |  | $ | 1,529 |  |  | $ | 1,458 |  |
| Income tax benefit for share-based compensation | $ | 558 |  |  | $ | 451 |  |  | $ | 429 |  |

[0000858877-18-000011:notes:195]
As of July 28, 2018, the total compensation cost related to unvested share-based awards not yet recognized was $3.1 billion, which is expected to be recognized over approximately 2.5 years on a weighted-average basis.

[0000858877-18-000011:notes:196]
| (d) | Share-Based Awards Available for Grant |

[0000858877-18-000011:notes:197]
A summary of share-based awards available for grant is as follows (in millions):

[0000858877-18-000011:notes:198]
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Balance at beginning of fiscal year | 272 |  |  | 242 |  |  | 276 |  |
| Restricted stock, stock units, and other share-based awards granted | (70 | ) |  | (76 | ) |  | (96 | ) |
| Share-based awards canceled/forfeited/expired | 18 |  |  | 78 |  |  | 30 |  |
| Shares withheld for taxes and not issued | 25 |  |  | 28 |  |  | 30 |  |
| Other | — |  |  | — |  |  | 2 |  |
| Balance at end of fiscal year | 245 |  |  | 272 |  |  | 242 |  |

[0000858877-18-000011:notes:199]
For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. For restricted stock units that were awarded with vesting contingent upon the achievement of future financial performance or market-based metrics, the maximum awards that can be achieved upon full vesting of such awards were reflected in the preceding table.

[0000858877-18-000011:notes:200]
| (e) | Restricted Stock and Stock Unit Awards |

[0000858877-18-000011:notes:201]
A summary of the restricted stock and stock unit activity, which includes time-based and performance-based or market-based RSUs, is as follows (in millions, except per-share amounts):

[0000858877-18-000011:notes:202]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 25, 2015 | 143 |  |  | $ | 22.08 |  |  |  |
| Granted | 62 |  |  | 25.90 |  |  |  |
| Assumed from acquisitions | 6 |  |  | 24.58 |  |  |  |
| Vested | (54 | ) |  | 20.68 |  |  | $ | 1,428 |  |
| Canceled/forfeited/other | (12 | ) |  | 22.91 |  |  |  |
| UNVESTED BALANCE AT JULY 30, 2016 | 145 |  |  | 24.26 |  |  |  |
| Granted | 50 |  |  | 27.89 |  |  |  |
| Assumed from acquisitions | 15 |  |  | 32.21 |  |  |  |
| Vested | (54 | ) |  | 23.14 |  |  | $ | 1,701 |  |
| Canceled/forfeited/other | (15 | ) |  | 23.56 |  |  |  |
| UNVESTED BALANCE AT JULY 29, 2017 | 141 |  |  | 26.94 |  |  |  |
| Granted | 46 |  |  | 35.62 |  |  |  |
| Assumed from acquisitions | 1 |  |  | 28.26 |  |  |  |
| Vested | (53 | ) |  | 26.02 |  |  | $ | 1,909 |  |
| Canceled/forfeited/other | (16 | ) |  | 28.37 |  |  |  |
| UNVESTED BALANCE AT JULY 28, 2018 | 119 |  |  | $ | 30.56 |  |  |  |

[0000858877-18-000011:notes:203]
| (f) | Stock Option Awards |

[0000858877-18-000011:notes:204]
A summary of the stock option activity is as follows (in millions, except per-share amounts):

[0000858877-18-000011:notes:205]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 25, 2015 | 103 |  |  | $ | 28.68 |  |
| Assumed from acquisitions | 18 |  |  | 5.17 |  |
| Exercised | (32 | ) |  | 19.22 |  |
| Canceled/forfeited/expired | (16 | ) |  | 30.01 |  |
| BALANCE AT JULY 30, 2016 | 73 |  |  | 26.78 |  |
| Assumed from acquisitions | 8 |  |  | 4.47 |  |
| Exercised | (14 | ) |  | 12.11 |  |
| Canceled/forfeited/expired | (55 | ) |  | 31.83 |  |
| BALANCE AT JULY 29, 2017 | 12 |  |  | 6.15 |  |
| Assumed from acquisitions | 3 |  |  | 8.20 |  |
| Exercised | (8 | ) |  | 5.77 |  |
| Canceled/forfeited/expired | (1 | ) |  | 8.75 |  |
| BALANCE AT JULY 28, 2018 | 6 |  |  | $ | 7.18 |  |

[0000858877-18-000011:notes:206]
The total pretax intrinsic value of stock options exercised during fiscal 2018, 2017, and 2016 was $257 million, $283 million, and $266 million, respectively.

[0000858877-18-000011:notes:207]
The following table summarizes significant ranges of outstanding and exercisable stock options as of July 28, 2018 (in millions, except years and share prices):

[0000858877-18-000011:notes:208]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 35.00 |  | 6 |  |  | 5.9 |  | $ | 7.18 |  |  | $ | 228 |  |  | 4 |  |  | $ | 6.84 |  |  | $ | 153 |  |

[0000858877-18-000011:notes:209]
The aggregate intrinsic value represents the total pretax intrinsic value, based on Cisco's closing stock price of $42.57 as of July 27, 2018.  The total number of in-the-money stock options exercisable as of July 28, 2018 was 4 million. As of July 29, 2017, 6 million outstanding stock options were exercisable, and the weighted-average exercise price was $5.61.

[0000858877-18-000011:notes:210]
| (g) | Valuation of Employee Share-Based Awards |

[0000858877-18-000011:notes:211]
Time-based restricted stock units and PRSUs that are based on our financial performance metrics or non-financial operating goals are valued using the market value of our common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, we estimated the fair value of the total shareholder return (TSR) component of the PRSUs using a Monte Carlo simulation model. The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-18-000011:notes:212]
|  | RESTRICTED STOCK UNITS |
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Number of shares granted (in millions) | 43 |  |  | 43 |  |  | 57 |  |
| Grant date fair value per share | $ | 35.81 |  |  | $ | 28.38 |  |  | $ | 26.01 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 3.2 | % |  | 3.5 | % |  | 3.2 | % |
| Range of risk-free interest rates | 0.0% – 2.7% |  |  | 0.0% – 1.5% |  |  | 0.0% – 1.2% |  |

[0000858877-18-000011:notes:213]
|  | PERFORMANCE BASED RESTRICTED STOCK UNITS |
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Number of shares granted (in millions) | 3 |  |  | 7 |  |  | 5 |  |
| Grant date fair value per share | $ | 32.69 |  |  | $ | 28.94 |  |  | $ | 24.70 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 3.5 | % |  | 3.4 | % |  | 3.1 | % |
| Range of risk-free interest rates | 1.0% – 2.7% |  |  | 0.1% – 1.5% |  |  | 0.0% – 1.2% |  |
| Range of expected volatilities for index | 12.5% - 82.8% |  |  | 16.7% – 46.8% |  |  | 15.3% – 54.3% |  |

[0000858877-18-000011:notes:214]
The PRSUs granted during the fiscal years presented are contingent on the achievement of our financial performance metrics, our comparative market-based returns, or the achievement of financial and non-financial operating goals.  For the awards based on financial performance metrics or comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period. Generally, the remaining 50% of the PRSUs are earned based on our TSR measured against the benchmark TSR of a peer group over the same period. Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of our financial performance metrics or our comparative market-based returns, and 0% to 100% of the target shares granted contingent on the achievement of non-financial operating goals.

[0000858877-18-000011:notes:215]
The assumptions for the valuation of employee stock purchase rights are summarized as follows:

[0000858877-18-000011:notes:216]
|  | EMPLOYEE STOCK PURCHASE RIGHTS |
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Weighted-average assumptions: |  |  |  |  |  |
| Expected volatility | 22.1 | % |  | 24.6 | % |  | 23.9 | % |
| Risk-free interest rate | 1.3 | % |  | 0.7 | % |  | 0.4 | % |
| Expected dividend | 3.1 | % |  | 3.2 | % |  | 3.1 | % |
| Expected life (in years) | 1.3 |  |  | 1.3 |  |  | 1.3 |  |
| Weighted-average estimated grant date fair value per share | $ | 7.48 |  |  | $ | 6.52 |  |  | $ | 5.73 |  |

[0000858877-18-000011:notes:217]
The valuation of employee stock purchase rights and the related assumptions are for the employee stock purchases made during the respective fiscal years.

[0000858877-18-000011:notes:218]
We used third-party analyses to assist in developing the assumptions used in our Black-Scholes model. We are responsible for determining the assumptions used in estimating the fair value of our share-based payment awards.

[0000858877-18-000011:notes:219]
We used the implied volatility for traded options (with contract terms corresponding to the expected life of the employee stock purchase rights) on our stock as the expected volatility assumption required in the Black-Scholes model. The implied volatility is more representative of future stock price trends than historical volatility. The risk-free interest rate assumption is based upon observed interest rates appropriate for the term of our employee stock purchase rights. The dividend yield assumption is based on the history and expectation of dividend payouts at the grant date.

[0000858877-18-000011:notes:220]
| (h) | Employee 401(k) Plans |

[0000858877-18-000011:notes:221]
We sponsor the Cisco Systems, Inc. 401(k) Plan (the “Plan”) to provide retirement benefits for our employees. As allowed under Section 401(k) of the Internal Revenue Code, the Plan provides for tax-deferred salary contributions and after-tax contributions for eligible employees. The Plan allows employees to contribute up to 75% of their annual eligible earnings to the Plan on a pretax and after-tax basis, including Roth contributions. Employee contributions are limited to a maximum annual amount as set periodically by the Internal Revenue Code. We match pretax and Roth employee contributions up to 100% of the first 4.5% of eligible earnings that are contributed by employees. Therefore, the maximum matching contribution that we may allocate to each participant’s account will not exceed $12,375 for the 2018 calendar year due to the $275,000 annual limit on eligible earnings imposed by the Internal Revenue Code. All matching contributions vest immediately. Our matching contributions to the Plan totaled $269 million, $265 million, and $262 million in fiscal 2018, 2017, and 2016, respectively.

[0000858877-18-000011:notes:222]
The Plan allows employees who meet the age requirements and reach the Plan contribution limits to make catch-up contributions (pretax or Roth) not to exceed the lesser of 75% of their annual eligible earnings or the limit set forth in the Internal Revenue Code. Catch-up contributions are not eligible for matching contributions. In addition, the Plan provides for discretionary profit-sharing contributions as determined by the Board of Directors. Such contributions to the Plan are allocated among eligible participants in the proportion of their salaries to the total salaries of all participants. There were no discretionary profit-sharing contributions made in fiscal 2018, 2017, and 2016.

[0000858877-18-000011:notes:223]
We also sponsor other 401(k) plans as a result of acquisitions of other companies. Our contributions to these plans were not material to Cisco on either an individual or aggregate basis for any of the fiscal years presented.

[0000858877-18-000011:notes:224]
| (i) | Deferred Compensation Plans |

[0000858877-18-000011:notes:225]
The Cisco Systems, Inc. Deferred Compensation Plan (the “Deferred Compensation Plan”), a nonqualified deferred compensation plan, became effective in 2007. As required by applicable law, participation in the Deferred Compensation Plan is limited to a select group of our management employees. Under the Deferred Compensation Plan, which is an unfunded and unsecured deferred compensation arrangement, a participant may elect to defer base salary, bonus, and/or commissions, pursuant to such rules as may be established by Cisco, up to the maximum percentages for each deferral election as described in the plan. We may also, at our discretion, make a matching contribution to the employee under the Deferred Compensation Plan. A matching contribution equal to 4.5% of eligible compensation in excess of the Internal Revenue Code limit for qualified plans for calendar year 2018 that is deferred by participants under the Deferred Compensation Plan (with a $1.5 million cap on eligible compensation) will be made to eligible participants’ accounts at the end of calendar year 2018. The total deferred compensation liability under the Deferred Compensation Plan, together with deferred compensation plans assumed from acquired companies, was approximately $651 million and $622 million as of July 28, 2018 and July 29, 2017, respectively, and was recorded primarily in other long-term liabilities.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000858877-18-000011:notes:226]
(t) Computation of Net Income per Share   Basic net income per share is computed using the weighted-average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted-average number of common shares and dilutive potential common shares outstanding during the period. Diluted shares outstanding includes the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares.

[0000858877-18-000011:notes:227]
Employee equity share options, unvested shares, and similar equity instruments granted and assumed by Cisco are treated as potential common shares outstanding in computing diluted earnings per share. Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that has not yet recognized are collectively assumed to be used to repurchase shares.


## us-gaap:EarningsPerShareTextBlock

[0000858877-18-000011:notes:228]
Net Income per Share

[0000858877-18-000011:notes:229]
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-18-000011:notes:230]
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Net income | $ | 110 |  |  | $ | 9,609 |  |  | $ | 10,739 |  |
| Weighted-average shares—basic | 4,837 |  |  | 5,010 |  |  | 5,053 |  |
| Effect of dilutive potential common shares | 44 |  |  | 39 |  |  | 35 |  |
| Weighted-average shares—diluted | 4,881 |  |  | 5,049 |  |  | 5,088 |  |
| Net income per share—basic | $ | 0.02 |  |  | $ | 1.92 |  |  | $ | 2.13 |  |
| Net income per share—diluted | $ | 0.02 |  |  | $ | 1.90 |  |  | $ | 2.11 |  |
| Antidilutive employee share-based awards, excluded | 61 |  |  | 136 |  |  | 148 |  |


## us-gaap:EquityMethodInvestmentsTextBlock

[0000858877-18-000011:notes:231]
For such investments that were accounted for under the equity and cost method as of July 28, 2018 and July 29, 2017, the amounts are summarized in the following table (in millions):

[0000858877-18-000011:notes:232]
|  | July 28, 2018 |  | July 29, 2017 |
| Equity method investments | $ | 118 |  |  | $ | 124 |  |
| Cost method investments | 978 |  |  | 859 |  |
| Total | $ | 1,096 |  |  | $ | 983 |  |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-18-000011:notes:233]
The following table presents gains and losses on assets that were measured at fair value on a nonrecurring basis(in millions):

[0000858877-18-000011:notes:234]
|  | TOTAL GAINS (LOSSES) FOR THE YEARS ENDED |
|  | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Investments in privately held companies (impaired) | $ | (56 | ) |  | $ | (175 | ) |  | $ | (57 | ) |
| Purchased intangible assets (impaired) | (1 | ) |  | (47 | ) |  | (74 | ) |
| Property held for sale - land and buildings | 20 |  |  | (30 | ) |  | — |  |
| Gains (losses) on assets no longer held at end of fiscal year | (6 | ) |  | (2 | ) |  | (10 | ) |
| Total gains (losses) for nonrecurring measurements | $ | (43 | ) |  | $ | (254 | ) |  | $ | (141 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-18-000011:notes:235]
Fair Value

[0000858877-18-000011:notes:236]
| (a) | Assets and Liabilities Measured at Fair Value on a Recurring Basis |

[0000858877-18-000011:notes:237]
Assets and liabilities measured at fair value on a recurring basis were as follows (in millions):

[0000858877-18-000011:notes:238]
|  | JULY 28, 2018 |  | JULY 29, 2017 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 6,890 |  |  | $ | — |  |  | $ | 6,890 |  |  | $ | 9,567 |  |  | $ | — |  |  | $ | 9,567 |  |
| U.S. government securities | — |  |  | — |  |  | — |  |  | — |  |  | 139 |  |  | 139 |  |
| Commercial paper | — |  |  | — |  |  | — |  |  | — |  |  | 160 |  |  | 160 |  |
| Certificates of deposit | — |  |  | — |  |  | — |  |  | — |  |  | 25 |  |  | 25 |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 7,275 |  |  | 7,275 |  |  | — |  |  | 19,823 |  |  | 19,823 |  |
| U.S. government agency securities | — |  |  | 727 |  |  | 727 |  |  | — |  |  | 2,052 |  |  | 2,052 |  |
| Non-U.S. government and agency securities | — |  |  | 208 |  |  | 208 |  |  | — |  |  | 388 |  |  | 388 |  |
| Corporate debt securities | — |  |  | 27,364 |  |  | 27,364 |  |  | — |  |  | 31,735 |  |  | 31,735 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,435 |  |  | 1,435 |  |  | — |  |  | 2,023 |  |  | 2,023 |  |
| Commercial paper | — |  |  | — |  |  | — |  |  | — |  |  | 996 |  |  | 996 |  |
| Certificates of deposit | — |  |  | — |  |  | — |  |  | — |  |  | 60 |  |  | 60 |  |
| Publicly traded equity securities | 605 |  |  | — |  |  | 605 |  |  | 1,707 |  |  | — |  |  | 1,707 |  |
| Derivative assets | — |  |  | 2 |  |  | 2 |  |  | — |  |  | 149 |  |  | 149 |  |
| Total | $ | 7,495 |  |  | $ | 37,011 |  |  | $ | 44,506 |  |  | $ | 11,274 |  |  | $ | 57,550 |  |  | $ | 68,824 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 4 |  |
| Total | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 4 |  |

[0000858877-18-000011:notes:239]
We classify our cash equivalents and available-for-sale investments within Level 1 or Level 2 in the fair value hierarchy because we use quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value. Our derivative instruments are classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs. We did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.

[0000858877-18-000011:notes:240]
| (b) | Assets Measured at Fair Value on a Nonrecurring Basis |

[0000858877-18-000011:notes:241]
These assets were measured at fair value due to events or circumstances we identified as having significant impact on their fair value during the respective periods. To arrive at the valuation of these assets, we consider any significant changes in the financial metrics and economic variables and also use third-party valuation reports to assist in the valuation as necessary.

[0000858877-18-000011:notes:242]
The fair value measurement of the impaired investments was classified as Level 3 because significant unobservable inputs were used in the valuation due to the absence of quoted market prices and inherent lack of liquidity.  Significant unobservable inputs, which included financial metrics of comparable private and public companies, financial condition and near-term prospects of the investees, recent financing activities of the investees, and the investees’ capital structure as well as other economic variables, reflected the assumptions market participants would use in pricing these assets.  The impairment charges, representing the difference between the net book value and the fair value as a result of the evaluation, were recorded to other income (loss), net.  The remaining carrying value of the investments that were impaired was $57 million and $81 million as of July 28, 2018 and July 29, 2017, respectively.

[0000858877-18-000011:notes:243]
The fair value for purchased intangibles assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation. Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets.  The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable.  See Note 4.  The remaining carrying value of the specific purchased intangible assets that were impaired was zero and $63 million as of July 28, 2018 and July 29, 2017, respectively.

[0000858877-18-000011:notes:244]
The fair value of property held for sale was measured with the assistance of third-party valuation models, which used discounted cash flow techniques as part of their analysis.  The fair value measurement was categorized as Level 3, as significant unobservable inputs were used in the valuation report. The impairment charges as a result of the valuations, which represented the difference between the fair value less cost to sell and the carrying amount of the assets held for sale, was included in restructuring and other charges. The remaining carrying value of the property held for sale that was impaired was zero and $5 million as of July 28, 2018 and July 29, 2017, respectively.

[0000858877-18-000011:notes:245]
| (c) | Other Fair Value Disclosures |

[0000858877-18-000011:notes:246]
The carrying value of our investments in privately held companies that were accounted for under the cost method was $978 million and $859 million as of July 28, 2018 and July 29, 2017, respectively. It was not practicable to estimate the fair value of this portfolio.

[0000858877-18-000011:notes:247]
The fair value of our short-term loan receivables and financed service contracts approximates their carrying value due to their short duration.  The aggregate carrying value of our long-term loan receivables and financed service contracts as of July 28, 2018 and July 29, 2017 was $3.6 billion and $3.4 billion, respectively. The estimated fair value of our long-term loan receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-18-000011:notes:248]
As of July 28, 2018 and July 29, 2017, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities.  As of July 28, 2018, the fair value of our senior notes and other long-term debt was $26.4 billion, with a carrying amount of $25.6 billion.  This compares to a fair value of $32.1 billion and a carrying amount of $30.5 billion as of July 29, 2017.  The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-18-000011:notes:249]
Gross receivables, excluding residual value, less unearned income categorized by our internal credit risk rating as of July 28, 2018 and July 29, 2017 are summarized as follows (in millions):

[0000858877-18-000011:notes:250]
|  | INTERNAL CREDIT RISK RATING |
| July 28, 2018 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,294 |  |  | $ | 1,199 |  |  | $ | 54 |  |  | $ | 2,547 |  |
| Loan receivables | 3,184 |  |  | 1,752 |  |  | 63 |  |  | 4,999 |  |
| Financed service contracts | 1,468 |  |  | 835 |  |  | 23 |  |  | 2,326 |  |
| Total | $ | 5,946 |  |  | $ | 3,786 |  |  | $ | 140 |  |  | $ | 9,872 |  |

[0000858877-18-000011:notes:251]
|  | INTERNAL CREDIT RISK RATING |
| July 29, 2017 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,408 |  |  | $ | 1,181 |  |  | $ | 50 |  |  | $ | 2,639 |  |
| Loan receivables | 2,865 |  |  | 1,516 |  |  | 179 |  |  | 4,560 |  |
| Financed service contracts | 1,593 |  |  | 902 |  |  | 22 |  |  | 2,517 |  |
| Total | $ | 5,866 |  |  | $ | 3,599 |  |  | $ | 251 |  |  | $ | 9,716 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-18-000011:notes:252]
Financing Receivables and Operating Leases

[0000858877-18-000011:notes:253]
| (a) | Financing Receivables |

[0000858877-18-000011:notes:254]
Financing receivables primarily consist of lease receivables, loan receivables, and financed service contracts. Lease receivables represent sales-type and direct-financing leases resulting from the sale of Cisco's and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services, which may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables generally have terms of up to three years. Financed service contracts include financing receivables related to technical support and advanced services. Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one to three years.

[0000858877-18-000011:notes:255]
A summary of our financing receivables is presented as follows (in millions):

[0000858877-18-000011:notes:256]
| July 28, 2018 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,688 |  |  | $ | 4,999 |  |  | $ | 2,326 |  |  | $ | 10,013 |  |
| Residual value | 164 |  |  | — |  |  | — |  |  | 164 |  |
| Unearned income | (141 | ) |  | — |  |  | — |  |  | (141 | ) |
| Allowance for credit loss | (135 | ) |  | (60 | ) |  | (10 | ) |  | (205 | ) |
| Total, net | $ | 2,576 |  |  | $ | 4,939 |  |  | $ | 2,316 |  |  | $ | 9,831 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,249 |  |  | $ | 2,376 |  |  | $ | 1,324 |  |  | $ | 4,949 |  |
| Noncurrent | 1,327 |  |  | 2,563 |  |  | 992 |  |  | 4,882 |  |
| Total, net | $ | 2,576 |  |  | $ | 4,939 |  |  | $ | 2,316 |  |  | $ | 9,831 |  |

[0000858877-18-000011:notes:257]
| July 29, 2017 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,784 |  |  | $ | 4,560 |  |  | $ | 2,517 |  |  | $ | 9,861 |  |
| Residual value | 173 |  |  | — |  |  | — |  |  | 173 |  |
| Unearned income | (145 | ) |  | — |  |  | — |  |  | (145 | ) |
| Allowance for credit loss | (162 | ) |  | (103 | ) |  | (30 | ) |  | (295 | ) |
| Total, net | $ | 2,650 |  |  | $ | 4,457 |  |  | $ | 2,487 |  |  | $ | 9,594 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,301 |  |  | $ | 2,104 |  |  | $ | 1,451 |  |  | $ | 4,856 |  |
| Noncurrent | 1,349 |  |  | 2,353 |  |  | 1,036 |  |  | 4,738 |  |
| Total, net | $ | 2,650 |  |  | $ | 4,457 |  |  | $ | 2,487 |  |  | $ | 9,594 |  |

[0000858877-18-000011:notes:258]
Future minimum lease payments to Cisco on lease receivables as of July 28, 2018 are summarized as follows (in millions):

[0000858877-18-000011:notes:259]
| Fiscal Year | Amount |
| 2019 | $ | 1,311 |  |
| 2020 | 745 |  |
| 2021 | 415 |  |
| 2022 | 177 |  |
| 2023 | 12 |  |
| Thereafter | 28 |  |
| Total | $ | 2,688 |  |

[0000858877-18-000011:notes:260]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-18-000011:notes:261]
| (b) | Credit Quality of Financing Receivables |

[0000858877-18-000011:notes:262]
We determine the adequacy of our allowance for credit loss by assessing the risks and losses inherent in our financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by us to our customers, which consist of the following: lease receivables, loan receivables, and financed service contracts.

[0000858877-18-000011:notes:263]
Our internal credit risk ratings of 1 through 4 correspond to investment-grade ratings, while credit risk ratings of 5 and 6 correspond to non-investment grade ratings. Credit risk ratings of 7 and higher correspond to substandard ratings.

[0000858877-18-000011:notes:264]
In circumstances when collectibility is not deemed reasonably assured, the associated revenue is deferred in accordance with our revenue recognition policies, and the related allowance for credit loss, if any, is included in deferred revenue. We also record deferred revenue associated with financing receivables when there are remaining performance obligations, as we do for financed service contracts.

[0000858877-18-000011:notes:265]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of July 28, 2018 and July 29, 2017 (in millions):

[0000858877-18-000011:notes:266]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 28, 2018 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 72 |  |  | $ | 27 |  |  | $ | 155 |  |  | $ | 254 |  |  | $ | 2,293 |  |  | $ | 2,547 |  |  | $ | 9 |  |  | $ | 9 |  |
| Loan receivables | 104 |  |  | 55 |  |  | 252 |  |  | 411 |  |  | 4,588 |  |  | 4,999 |  |  | 30 |  |  | 30 |  |
| Financed service contracts | 138 |  |  | 78 |  |  | 304 |  |  | 520 |  |  | 1,806 |  |  | 2,326 |  |  | 3 |  |  | 3 |  |
| Total | $ | 314 |  |  | $ | 160 |  |  | $ | 711 |  |  | $ | 1,185 |  |  | $ | 8,687 |  |  | $ | 9,872 |  |  | $ | 42 |  |  | $ | 42 |  |

[0000858877-18-000011:notes:267]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 29, 2017 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 160 |  |  | $ | 60 |  |  | $ | 216 |  |  | $ | 436 |  |  | $ | 2,203 |  |  | $ | 2,639 |  |  | $ | 14 |  |  | $ | 14 |  |
| Loan receivables | 230 |  |  | 48 |  |  | 259 |  |  | 537 |  |  | 4,023 |  |  | 4,560 |  |  | 43 |  |  | 43 |  |
| Financed service contracts | 160 |  |  | 77 |  |  | 523 |  |  | 760 |  |  | 1,757 |  |  | 2,517 |  |  | 18 |  |  | 2 |  |
| Total | $ | 550 |  |  | $ | 185 |  |  | $ | 998 |  |  | $ | 1,733 |  |  | $ | 7,983 |  |  | $ | 9,716 |  |  | $ | 75 |  |  | $ | 59 |  |

[0000858877-18-000011:notes:268]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract. The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $503 million and $666 million as of July 28, 2018 and July 29, 2017, respectively.

[0000858877-18-000011:notes:269]
As of July 28, 2018, we had financing receivables of $182 million, net of unbilled or current receivables, that were in the category of 91 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $315 million as of July 29, 2017.

[0000858877-18-000011:notes:270]
| (c) | Allowance for Credit Loss Rollforward |

[0000858877-18-000011:notes:271]
| (d) | Operating Leases |

[0000858877-18-000011:notes:272]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-18-000011:notes:273]
|  | July 28, 2018 |  | July 29, 2017 |
| Operating lease assets | $ | 356 |  |  | $ | 356 |  |
| Accumulated depreciation | (238 | ) |  | (212 | ) |
| Operating lease assets, net | $ | 118 |  |  | $ | 144 |  |

[0000858877-18-000011:notes:274]
Minimum future rentals on noncancelable operating leases as of July 28, 2018 are summarized as follows (in millions):

[0000858877-18-000011:notes:275]
| Fiscal Year | Amount |
| 2019 | $ | 166 |  |
| 2020 | 97 |  |
| 2021 | 34 |  |
| 2022 | 2 |  |
| Thereafter | 1 |  |
| Total | $ | 300 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000858877-18-000011:notes:276]
(m) Foreign Currency Translation   Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated to U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of AOCI. Income and expense accounts are translated at average exchange rates during the year. Remeasurement adjustments are recorded in other income (loss), net. The effect of foreign currency exchange rates on cash and cash equivalents was not material for any of the fiscal years presented.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-18-000011:notes:277]
Goodwill and Purchased Intangible Assets

[0000858877-18-000011:notes:278]
| (a) | Goodwill |

[0000858877-18-000011:notes:279]
The following tables present the goodwill allocated to our reportable segments as of July 28, 2018 and July 29, 2017, as well as the changes to goodwill during fiscal 2018 and 2017 (in millions):

[0000858877-18-000011:notes:280]
|  | Balance at July 29, 2017 |  | Acquisitions |  | Other |  | Balance at July 28, 2018 |
| Americas | $ | 18,691 |  |  | $ | 1,355 |  |  | $ | (48 | ) |  | $ | 19,998 |  |
| EMEA | 7,057 |  |  | 491 |  |  | (19 | ) |  | 7,529 |  |
| APJC | 4,018 |  |  | 171 |  |  | (10 | ) |  | 4,179 |  |
| Total | $ | 29,766 |  |  | $ | 2,017 |  |  | $ | (77 | ) |  | $ | 31,706 |  |

[0000858877-18-000011:notes:281]
|  | Balance at July 30, 2016 |  | Acquisitions |  | Other |  | Balance at July 29, 2017 |
| Americas | $ | 16,529 |  |  | $ | 2,042 |  |  | $ | 120 |  |  | $ | 18,691 |  |
| EMEA | 6,269 |  |  | 740 |  |  | 48 |  |  | 7,057 |  |
| APJC | 3,827 |  |  | 163 |  |  | 28 |  |  | 4,018 |  |
| Total | $ | 26,625 |  |  | $ | 2,945 |  |  | $ | 196 |  |  | $ | 29,766 |  |

[0000858877-18-000011:notes:282]
“Other” in the tables above primarily consists of divestitures, foreign currency translation, as well as immaterial purchase accounting adjustments.

[0000858877-18-000011:notes:283]
| (b) | Purchased Intangible Assets |

[0000858877-18-000011:notes:284]
Purchased intangible assets include intangible assets acquired through acquisitions as well as through direct purchases or licenses.

[0000858877-18-000011:notes:285]
Impairment charges related to purchased intangible assets were approximately $1 million, $47 million, and $74 million for fiscal 2018, fiscal 2017, and fiscal 2016, respectively. Impairment charges were as a result of declines in estimated fair value resulting from the reduction or elimination of expected future cash flows associated with certain of our technology and IPR&D intangible assets.

[0000858877-18-000011:notes:286]
The estimated future amortization expense of purchased intangible assets with finite lives as of July 28, 2018 is as follows (in millions):

[0000858877-18-000011:notes:287]
| Fiscal Year | Amount |
| 2019 | $ | 714 |  |
| 2020 | $ | 667 |  |
| 2021 | $ | 475 |  |
| 2022 | $ | 222 |  |
| 2023 | $ | 82 |  |
| Thereafter | $ | 37 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000858877-18-000011:notes:288]
(i) Goodwill and Purchased Intangible Assets   Goodwill is tested for impairment on an annual basis in the fourth fiscal quarter and, when specific circumstances dictate, between annual tests. When impaired, the carrying value of goodwill is written down to fair value. The goodwill impairment test involves a two-step process. The first step, identifying a potential impairment, compares the fair value of a reporting unit with its carrying amount, including goodwill. If the carrying value of the reporting unit exceeds its fair value, the second step would need to be conducted; otherwise, no further steps are necessary as no potential impairment exists. If necessary, the second step to measure the impairment loss would be to compare the implied fair value of the reporting unit goodwill with the carrying amount of that goodwill. Any excess of the reporting unit goodwill carrying value over the respective implied fair value is recognized as an impairment loss. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. See “Long-Lived Assets” for our policy regarding impairment testing of purchased intangible assets with finite lives. Purchased intangible assets with indefinite lives are assessed for potential impairment annually or when events or circumstances indicate that their carrying amounts might be impaired.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000858877-18-000011:notes:289]
(j) Long-Lived Assets   Long-lived assets that are held and used by us are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability of long-lived assets is based on an estimate of the undiscounted future cash flows resulting from the use of the asset and its eventual disposition. Measurement of an impairment loss for long-lived assets that management expects to hold and use is based on the difference between the fair value of the asset and its carrying value. Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-18-000011:notes:290]
Income Taxes

[0000858877-18-000011:notes:291]
| (a) | Provision for Income Taxes |

[0000858877-18-000011:notes:292]
The provision for income taxes consists of the following (in millions):

[0000858877-18-000011:notes:293]
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Federal: |  |  |  |  |  |
| Current | $ | 9,900 |  |  | $ | 1,300 |  |  | $ | 865 |  |
| Deferred | 1,156 |  |  | (42 | ) |  | (93 | ) |
|  | 11,056 |  |  | 1,258 |  |  | 772 |  |
| State: |  |  |  |  |  |
| Current | 340 |  |  | 86 |  |  | 78 |  |
| Deferred | (232 | ) |  | 56 |  |  | 13 |  |
|  | 108 |  |  | 142 |  |  | 91 |  |
| Foreign: |  |  |  |  |  |
| Current | 1,789 |  |  | 1,416 |  |  | 1,432 |  |
| Deferred | (24 | ) |  | (138 | ) |  | (114 | ) |
|  | 1,765 |  |  | 1,278 |  |  | 1,318 |  |
| Total | $ | 12,929 |  |  | $ | 2,678 |  |  | $ | 2,181 |  |

[0000858877-18-000011:notes:294]
Income before provision for income taxes consists of the following (in millions):

[0000858877-18-000011:notes:295]
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| United States | $ | 3,765 |  |  | $ | 2,393 |  |  | $ | 2,907 |  |
| International | 9,274 |  |  | 9,894 |  |  | 10,013 |  |
| Total | $ | 13,039 |  |  | $ | 12,287 |  |  | $ | 12,920 |  |

[0000858877-18-000011:notes:296]
The items accounting for the difference between income taxes computed at the federal statutory rate and the provision for income taxes consist of the following:

[0000858877-18-000011:notes:297]
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Federal statutory rate | 27.0 | % |  | 35.0 | % |  | 35.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 0.6 |  |  | 1.1 |  |  | 0.5 |  |
| Foreign income at other than U.S. rates | (5.2 | ) |  | (13.4 | ) |  | (14.5 | ) |
| Tax credits | (2.5 | ) |  | (1.2 | ) |  | (1.7 | ) |
| Domestic manufacturing deduction | (0.5 | ) |  | (0.4 | ) |  | (0.6 | ) |
| Stock-based compensation | (0.1 | ) |  | 1.4 |  |  | 1.4 |  |
| Tax audit settlement | — |  |  | — |  |  | (2.8 | ) |
| Impact of the Tax Act | 80.1 |  |  | — |  |  | — |  |
| Other, net | (0.2 | ) |  | (0.7 | ) |  | (0.4 | ) |
| Total | 99.2 | % |  | 21.8 | % |  | 16.9 | % |

[0000858877-18-000011:notes:298]
On December 22, 2017, the Tax Act was enacted. The Tax Act significantly revises the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (“federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries. As a fiscal-year taxpayer, certain provisions of the Tax Act impact Cisco in fiscal 2018, including the change in the federal tax rate and the one-time transition tax, while other provisions will be effective at the beginning of fiscal 2019, including the implementation of a modified territorial tax system and other changes to how foreign earnings are subject to U.S. tax, and elimination of the domestic manufacturing deduction.

[0000858877-18-000011:notes:299]
As a result of the decrease in the federal tax rate from 35% to 21% effective January 1, 2018, we have computed our income tax expense for the July 28, 2018 fiscal year using a blended federal tax rate of 27%. The 21% federal tax rate will apply to our fiscal year ending July 27, 2019 and each year thereafter. We must remeasure our deferred tax assets and liabilities ("DTA") using the federal tax rate that will apply when the related temporary differences are expected to reverse.

[0000858877-18-000011:notes:300]
As of December 31, 2017, we had approximately $76 billion in undistributed earnings for certain foreign subsidiaries. These undistributed earnings were subject to the U.S. mandatory one-time transition tax and are eligible to be repatriated to the U.S. without additional U.S. tax under the Tax Act. We have historically asserted our intention to indefinitely reinvest foreign earnings in certain foreign subsidiaries. We have reevaluated our historic assertion as a result of enactment of the Tax Act and no longer consider these earnings to be indefinitely reinvested in our foreign subsidiaries. As a result of this change in assertion, we recorded a $1.2 billion tax expense for foreign withholding tax in the second quarter of fiscal 2018. In fiscal 2018, we repatriated $70 billion of foreign subsidiary earnings to the U.S. (in the form of cash, cash equivalents, or investments), and paid foreign withholding tax of $1.2 billion.

[0000858877-18-000011:notes:301]
In the fourth quarter of fiscal 2018, we recorded adjustments to the provisional amounts originally recorded in the second quarter of fiscal 2018 related to the U.S transition tax on accumulated earnings of foreign subsidiaries and re-measurement of net DTA. These adjustments include an $863 million benefit to the U.S. transition tax provisional amount related to the U.S taxation of deemed foreign dividends in the transition fiscal year. This benefit may be reduced or eliminated in future legislation. If such legislation is enacted, we will record the impact of the legislation in the quarter of enactment.

[0000858877-18-000011:notes:302]
During fiscal 2018, we recorded a provisional tax expense of $10.4 billion related to the Tax Act, comprised of $8.1 billion of U.S. transition tax, $1.2 billion of foreign withholding tax (discussed above), and $1.1 billion re-measurement of net DTA. We plan to pay the transition tax in installments over eight years in accordance with the Tax Act. The $1.2 billion foreign withholding tax was paid in February 2018.

[0000858877-18-000011:notes:303]
In December 2017, the Securities and Exchange Commission staff issued Staff Accounting Bulletin No. 118, which addresses how a company recognizes provisional estimates when a company does not have the necessary information available, prepared or analyzed (including computations) in reasonable detail to complete its accounting for the effect of the changes in the Tax Act. The measurement period ends when a company has obtained, prepared, and analyzed the information necessary to finalize its accounting, but cannot extend beyond one year. The final impact of the Tax Act may differ from the above provisional estimates due to changes in interpretations of the Tax Act, any legislative action to address questions that arise because of the Tax Act, by changes in accounting standard for income taxes and related interpretations in response to the Tax Act, and any updates or changes to estimates used in the provisional amounts. We have determined that the $8.1 billion of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries, the $1.2 billion of foreign withholding tax, and the $1.1 billion of tax expense for DTA re-measurement were each provisional amounts and reasonable estimates for fiscal 2018. Estimates used in the provisional amounts include: the anticipated reversal pattern of the gross DTAs; and earnings, cash positions, foreign taxes and withholding taxes attributable to foreign subsidiaries.

[0000858877-18-000011:notes:304]
During fiscal 2016, the Internal Revenue Service (IRS) and Cisco settled all outstanding items related to the audit of our federal income tax returns for the fiscal years ended July 26, 2008 through July 31, 2010. As a result of the settlement, we recognized a net benefit to the provision for income taxes of $367 million, which included a reduction of interest expense of $21 million. In addition, the Protecting Americans from Tax Hikes Act of 2015 reinstated the U.S. federal R&D tax credit permanently. As a result, the tax provision in fiscal 2016 included a tax benefit of $226 million related to the U.S. federal R&D tax credit, of which $81 million was attributable to fiscal 2015.

[0000858877-18-000011:notes:305]
Foreign taxes associated with the repatriation of earnings of foreign subsidiaries were not provided for on a cumulative total of $77 million of undistributed earnings for certain foreign subsidiaries as of the end of fiscal 2018. We intend to reinvest these earnings indefinitely in such foreign subsidiaries. If these earnings were distributed in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, we would be subject to additional foreign taxes. The amount of unrecognized deferred income tax liability related to these earnings is approximately $15 million.

[0000858877-18-000011:notes:306]
As a result of certain employment and capital investment actions, our income in certain foreign countries is subject to reduced tax rates.  A portion of these incentives expired at the end of fiscal 2015. The majority of the remaining tax incentives are reasonably expected to expire at the end of fiscal 2019.  The gross income tax benefit attributable to tax incentives was estimated to be $0.9 billion ($0.19 per diluted share) in fiscal 2018. As of the end of fiscal 2017 and 2016, the gross income tax benefits attributable to tax incentives were estimated to be $1.3 billion and $1.2 billion ($0.25 and $0.23 per diluted share) for the respective years. The gross income tax benefits were partially offset by accruals of U.S. income taxes on foreign earnings.

[0000858877-18-000011:notes:307]
Unrecognized Tax Benefits

[0000858877-18-000011:notes:308]
The aggregate changes in the balance of gross unrecognized tax benefits were as follows (in millions):

[0000858877-18-000011:notes:309]
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Beginning balance | $ | 1,973 |  |  | $ | 1,627 |  |  | $ | 2,029 |  |
| Additions based on tax positions related to the current year | 251 |  |  | 336 |  |  | 255 |  |
| Additions for tax positions of prior years | 84 |  |  | 180 |  |  | 116 |  |
| Reductions for tax positions of prior years | (129 | ) |  | (78 | ) |  | (457 | ) |
| Settlements | (124 | ) |  | (43 | ) |  | (241 | ) |
| Lapse of statute of limitations | (55 | ) |  | (49 | ) |  | (75 | ) |
| Ending balance | $ | 2,000 |  |  | $ | 1,973 |  |  | $ | 1,627 |  |

[0000858877-18-000011:notes:310]
As a result of the IRS tax settlement related to the federal income tax returns for the fiscal years ended July 26, 2008 through July 31, 2010, the amount of gross unrecognized tax benefits in fiscal 2016 was reduced by approximately $563 million. We also reduced the amount of accrued interest by $63 million.

[0000858877-18-000011:notes:311]
As of July 28, 2018, $1.7 billion of the unrecognized tax benefits would affect the effective tax rate if realized. During fiscal 2018, we recognized $10 million of net interest expense and reduced penalties by less than $1 million. During fiscal 2017, we recognized $26 million of net interest expense and a $4 million reduction in penalties. During fiscal 2016, we recognized a $55 million reduction in net interest expense and a $40 million reduction in penalties. Our total accrual for interest and penalties was $180 million, $186 million, and $154 million as of the end of fiscal 2018, 2017, and 2016, respectively. We are no longer subject to U.S. federal income tax audit for returns covering tax years through fiscal 2010. We are no longer subject to foreign or state income tax audits for returns covering tax years through fiscal 1999, and fiscal 2008, respectively.

[0000858877-18-000011:notes:312]
We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months.  Specific positions that may be resolved include issues involving transfer pricing and various other matters. We estimate that the unrecognized tax benefits at July 28, 2018 could be reduced by approximately $300 million in the next 12 months.

[0000858877-18-000011:notes:313]
| (b) | Deferred Tax Assets and Liabilities |

[0000858877-18-000011:notes:314]
The following table presents the breakdown for net deferred tax assets (in millions):

[0000858877-18-000011:notes:315]
|  | July 28, 2018 |  | July 29, 2017 |
| Deferred tax assets | $ | 3,219 |  |  | $ | 4,239 |  |
| Deferred tax liabilities | (141 | ) |  | (271 | ) |
| Total net deferred tax assets | $ | 3,078 |  |  | $ | 3,968 |  |

[0000858877-18-000011:notes:316]
The following table presents the components of the deferred tax assets and liabilities (in millions):

[0000858877-18-000011:notes:317]
|  | July 28, 2018 |  | July 29, 2017 |
| ASSETS |  |  |  |
| Allowance for doubtful accounts and returns | $ | 285 |  |  | $ | 443 |  |
| Sales-type and direct-financing leases | 171 |  |  | 277 |  |
| Inventory write-downs and capitalization | 289 |  |  | 446 |  |
| Investment provisions | 54 |  |  | 171 |  |
| IPR&D, goodwill, and purchased intangible assets | 63 |  |  | 125 |  |
| Deferred revenue | 1,584 |  |  | 2,057 |  |
| Credits and net operating loss carryforwards | 1,087 |  |  | 976 |  |
| Share-based compensation expense | 190 |  |  | 273 |  |
| Accrued compensation | 370 |  |  | 504 |  |
| Other | 408 |  |  | 559 |  |
| Gross deferred tax assets | 4,501 |  |  | 5,831 |  |
| Valuation allowance | (374 | ) |  | (244 | ) |
| Total deferred tax assets | 4,127 |  |  | 5,587 |  |
| LIABILITIES |  |  |  |
| Purchased intangible assets | (753 | ) |  | (1,037 | ) |
| Depreciation | (118 | ) |  | (340 | ) |
| Unrealized gains on investments | (33 | ) |  | (203 | ) |
| Other | (145 | ) |  | (39 | ) |
| Total deferred tax liabilities | (1,049 | ) |  | (1,619 | ) |
| Total net deferred tax assets | $ | 3,078 |  |  | $ | 3,968 |  |

[0000858877-18-000011:notes:318]
As of July 28, 2018, our federal, state, and foreign net operating loss carryforwards for income tax purposes were $703 million, $891 million, and $808 million, respectively.  A significant amount of the net operating loss carryforwards relates to acquisitions and, as a result, is limited in the amount that can be recognized in any one year. If not utilized, the federal, state and foreign net operating loss carryforwards will begin to expire in fiscal 2019. We have provided a valuation allowance of $125 million for deferred tax assets related to foreign net operating losses that are not expected to be realized.

[0000858877-18-000011:notes:319]
As of July 28, 2018, our federal, state, and foreign tax credit carryforwards for income tax purposes were approximately $47 million, $1.0 billion, and $5 million, respectively. The federal tax credit carryforwards will begin to expire in fiscal 2019. The majority of state and foreign tax credits can be carried forward indefinitely. We have provided a valuation allowance of $249 million for deferred tax assets related to state and foreign tax credits that are not expected to be realized.


## us-gaap:IncomeTaxPolicyTextBlock

[0000858877-18-000011:notes:320]
(s) Income Taxes   Income tax expense is based on pretax financial accounting income. Deferred tax assets and liabilities are recognized for the expected tax consequences of temporary differences between the tax bases of assets and liabilities and their reported amounts. Valuation allowances are recorded to reduce deferred tax assets to the amount that will more likely than not be realized.

[0000858877-18-000011:notes:321]
We account for uncertainty in income taxes using a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. We classify the liability for unrecognized tax benefits as current to the extent that we anticipate payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.


## us-gaap:InventoryPolicyTextBlock

[0000858877-18-000011:notes:322]
(d) Inventories   Inventories are stated at the lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. We provide inventory write-downs based on excess and obsolete inventories determined primarily by future demand forecasts. The write-down is measured as the difference between the cost of the inventory and market based upon assumptions about future demand and charged to the provision for inventory, which is a component of cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In addition, we record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-18-000011:notes:323]
The following table summarizes the maturities of our fixed income securities at July 28, 2018 (in millions):

[0000858877-18-000011:notes:324]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 12,361 |  |  | $ | 12,316 |  |
| Due in 1 to 2 years | 7,573 |  |  | 7,514 |  |
| Due in 2 to 5 years | 14,290 |  |  | 14,012 |  |
| Due after 5 years | 1,800 |  |  | 1,732 |  |
| Mortgage-backed securities with no single maturity | 1,488 |  |  | 1,435 |  |
| Total | $ | 37,512 |  |  | $ | 37,009 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-18-000011:notes:325]
Investments

[0000858877-18-000011:notes:326]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-18-000011:notes:327]
The following tables summarize our available-for-sale investments (in millions):

[0000858877-18-000011:notes:328]
| July 28, 2018 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 7,318 |  |  | $ | — |  |  | $ | (43 | ) |  | $ | 7,275 |  |
| U.S. government agency securities | 732 |  |  | — |  |  | (5 | ) |  | 727 |  |
| Non-U.S. government and agency securities | 209 |  |  | — |  |  | (1 | ) |  | 208 |  |
| Corporate debt securities | 27,765 |  |  | 44 |  |  | (445 | ) |  | 27,364 |  |
| U.S. agency mortgage-backed securities | 1,488 |  |  | — |  |  | (53 | ) |  | 1,435 |  |
| Total fixed income securities | 37,512 |  |  | 44 |  |  | (547 | ) |  | 37,009 |  |
| Publicly traded equity securities | 372 |  |  | 233 |  |  | — |  |  | 605 |  |
| Total | $ | 37,884 |  |  | $ | 277 |  |  | $ | (547 | ) |  | $ | 37,614 |  |
| July 29, 2017 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 19,880 |  |  | $ | 3 |  |  | $ | (60 | ) |  | $ | 19,823 |  |
| U.S. government agency securities | 2,057 |  |  | — |  |  | (5 | ) |  | 2,052 |  |
| Non-U.S. government and agency securities | 389 |  |  | — |  |  | (1 | ) |  | 388 |  |
| Corporate debt securities | 31,626 |  |  | 202 |  |  | (93 | ) |  | 31,735 |  |
| U.S. agency mortgage-backed securities | 2,037 |  |  | 3 |  |  | (17 | ) |  | 2,023 |  |
| Commercial paper | 996 |  |  | — |  |  | — |  |  | 996 |  |
| Certificates of deposit | 60 |  |  | — |  |  | — |  |  | 60 |  |
| Total fixed income securities | 57,045 |  |  | 208 |  |  | (176 | ) |  | 57,077 |  |
| Publicly traded equity securities | 1,180 |  |  | 554 |  |  | (27 | ) |  | 1,707 |  |
| Total | $ | 58,225 |  |  | $ | 762 |  |  | $ | (203 | ) |  | $ | 58,784 |  |

[0000858877-18-000011:notes:329]
Net unsettled investment sales as of July 28, 2018 and July 29, 2017 were $1.5 billion and $30 million, respectively and were included in other current assets and other current liabilities.

[0000858877-18-000011:notes:330]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-18-000011:notes:331]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-18-000011:notes:332]
The following table presents the gross realized gains and gross realized losses related to our available-for-sale investments (in millions):

[0000858877-18-000011:notes:333]
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Gross realized gains | $ | 628 |  |  | $ | 114 |  |  | $ | 152 |  |
| Gross realized losses | (341 | ) |  | (201 | ) |  | (153 | ) |
| Total | $ | 287 |  |  | $ | (87 | ) |  | $ | (1 | ) |

[0000858877-18-000011:notes:334]
The following table presents the realized net gains and losses related to our available-for-sale investments by security type (in millions):

[0000858877-18-000011:notes:335]
| Years Ended | July 28, 2018 |  | July 29, 2017 |  | July 30, 2016 |
| Net gains/(losses) on investments in publicly traded equity securities | $ | 529 |  |  | $ | (45 | ) |  | $ | 33 |  |
| Net gains/(losses) on investments in fixed income securities | (242 | ) |  | (42 | ) |  | (34 | ) |
| Total | $ | 287 |  |  | $ | (87 | ) |  | $ | (1 | ) |

[0000858877-18-000011:notes:336]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at July 28, 2018 and July 29, 2017 (in millions):

[0000858877-18-000011:notes:337]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 28, 2018 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 2,966 |  |  | $ | (20 | ) |  | $ | 4,303 |  |  | $ | (23 | ) |  | $ | 7,269 |  |  | $ | (43 | ) |
| U.S. government agency securities | 206 |  |  | (2 | ) |  | 521 |  |  | (3 | ) |  | 727 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 105 |  |  | (1 | ) |  | 103 |  |  | — |  |  | 208 |  |  | (1 | ) |
| Corporate debt securities | 16,990 |  |  | (344 | ) |  | 3,511 |  |  | (101 | ) |  | 20,501 |  |  | (445 | ) |
| U.S. agency mortgage-backed securities | 826 |  |  | (24 | ) |  | 581 |  |  | (29 | ) |  | 1,407 |  |  | (53 | ) |
| Total fixed income securities | 21,093 |  |  | (391 | ) |  | 9,019 |  |  | (156 | ) |  | 30,112 |  |  | (547 | ) |
| Publicly traded equity securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 21,093 |  |  | $ | (391 | ) |  | $ | 9,019 |  |  | $ | (156 | ) |  | $ | 30,112 |  |  | $ | (547 | ) |

[0000858877-18-000011:notes:338]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2017 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 14,962 |  |  | $ | (55 | ) |  | $ | 771 |  |  | $ | (5 | ) |  | $ | 15,733 |  |  | $ | (60 | ) |
| U.S. government agency securities | 1,791 |  |  | (4 | ) |  | 130 |  |  | (1 | ) |  | 1,921 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 368 |  |  | (1 | ) |  | — |  |  | — |  |  | 368 |  |  | (1 | ) |
| Corporate debt securities | 9,487 |  |  | (92 | ) |  | 101 |  |  | (1 | ) |  | 9,588 |  |  | (93 | ) |
| U.S. agency mortgage-backed securities | 1,485 |  |  | (16 | ) |  | 38 |  |  | (1 | ) |  | 1,523 |  |  | (17 | ) |
| Total fixed income securities | 28,093 |  |  | (168 | ) |  | 1,040 |  |  | (8 | ) |  | 29,133 |  |  | (176 | ) |
| Publicly traded equity securities | 122 |  |  | (27 | ) |  | — |  |  | — |  |  | 122 |  |  | (27 | ) |
| Total | $ | 28,215 |  |  | $ | (195 | ) |  | $ | 1,040 |  |  | $ | (8 | ) |  | $ | 29,255 |  |  | $ | (203 | ) |

[0000858877-18-000011:notes:339]
For fiscal 2018, the realized net losses for available-for-sale investments included impairment charges of $52 million. These impairment charges related primarily to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. For fiscal 2017, the realized net losses related to available-for-sale investments included impairment charges of $74 million, primarily related to publicly traded equity securities. These impairment charges were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. For fiscal 2016, the realized net losses related to available-for-sale investments included impairment charges of $3 million for fixed income securities.

[0000858877-18-000011:notes:340]
As of July 28, 2018, for available-for-sale investments  that were in unrealized loss positions, we have determined that no additional other-than-temporary impairments were required to be recognized.

[0000858877-18-000011:notes:341]
| (c) | Maturities of Fixed Income Securities |

[0000858877-18-000011:notes:342]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations. The remaining contractual principal maturities for mortgage-backed securities were allocated assuming no prepayments.

[0000858877-18-000011:notes:343]
| (d) | Securities Lending |

[0000858877-18-000011:notes:344]
We periodically engage in securities lending activities with certain of our available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for fiscal 2018 and 2017 was $0.3 billion and $0.7 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented.  As of July 28, 2018 and July 29, 2017, we had no outstanding securities lending transactions.

[0000858877-18-000011:notes:345]
| (e) | Investments in Privately Held Companies |

[0000858877-18-000011:notes:346]
The carrying value of our investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of July 28, 2018 and July 29, 2017, the amounts are summarized in the following table (in millions):

[0000858877-18-000011:notes:347]
For additional information on impairment charges related to investments in privately held companies, see Note 9.

[0000858877-18-000011:notes:348]
Variable Interest Entities  In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings and have determined that as of July 28, 2018, except as disclosed herein, there were no variable interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-18-000011:notes:349]
As of July 28, 2018, the carrying value of our investments in privately held companies was $1.1 billion, of which $531 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, we have additional funding commitments of $223 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these variable interest entities.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000858877-18-000011:notes:350]
(w) New Accounting Updates Recently Adopted

[0000858877-18-000011:notes:351]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. We adopted this accounting standard update beginning the first quarter of fiscal 2018 on a prospective basis. This resulted in an overall decrease in the effective tax rate for fiscal 2018 due to recognition of excess tax benefits from share-based compensation. The application of this accounting standard update did not have a material impact on our Consolidated Financial Statements.

[0000858877-18-000011:notes:352]
Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income  In February 2018, the FASB issued an accounting standard update that allows companies to reclassify from AOCI to retained earnings stranded tax effects resulting from the enactment of the Tax Cuts and Jobs Act (the "Tax Act"). The guidance is effective January 1, 2019 with early adoption permitted. We early adopted this accounting standard update in the third quarter of fiscal 2018 and elected not to reclassify prior periods. Adoption of this standard resulted in a decrease of $45 million to retained earnings due to the reclassification from AOCI to retained earnings.

[0000858877-18-000011:notes:353]
(x) Recent Accounting Standards or Updates Not Yet Effective as of Fiscal Year End

[0000858877-18-000011:notes:354]
Revenue Recognition  In May 2014, the FASB issued ASC 606, a new accounting standard related to revenue recognition. ASC 606 will supersede nearly all U.S. GAAP on revenue recognition and eliminate industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. It also requires increased disclosures including the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

[0000858877-18-000011:notes:355]
ASC 606 allows two methods of adoption: i) retrospectively to each prior period presented (“full retrospective method”), or ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective method"). We will adopt ASC 606 using the modified retrospective method at the beginning of our first quarter of fiscal 2019.

[0000858877-18-000011:notes:356]
We are in process of finalizing our new accounting policies, systems, processes, and internal controls necessary to support the requirements of  ASC 606. We have substantially completed our assessment of the financial statement impact of ASC 606, the impacts of which are as discussed below.

[0000858877-18-000011:notes:357]
ASC 606 will primarily impact our revenue recognition for software arrangements and sales to two-tier distributors. In both areas, the new standard will accelerate the recognition of revenue. The table below details the timing of when revenue is typically recognized under the current revenue standard compared to the timing of when revenue will typically be recognized under ASC 606 for these major areas:

[0000858877-18-000011:notes:358]
|  |  | Current Revenue Standard |  | New Revenue Standard |
| Software arrangements: |  |  |  |  |
| Perpetual software licenses |  | Upfront |  | Upfront |
| Term software licenses |  | Ratable |  | Upfront |
| Security software licenses |  | Ratable |  | Ratable |
| Enterprise license agreements |  | Ratable |  | Upfront |
| Software support services |  | Ratable |  | Ratable |
| Software-as-a-service |  | Ratable |  | Ratable |
| Two-tier distribution |  | Sell-Through |  | Sell-In |

[0000858877-18-000011:notes:359]
In addition to the above revenue recognition timing impacts, ASC 606 requires incremental contract acquisition costs (such as sales commissions) for customer contracts to be capitalized and amortized over the contract term. Currently, these costs are expensed as incurred.

[0000858877-18-000011:notes:360]
Upon adopting ASC 606 at the beginning of fiscal 2019, our cumulative effect adjustment will increase retained earnings by approximately $2.3 billion. This cumulative effect adjustment is primarily driven by a reduction to our deferred product revenue of approximately $2.8 billion, of which $1.3 billion relates to our recurring software and subscription offers, $0.6 billion relates to two-tier distribution, and the remainder relates to non-recurring software, services and other adjustments. In addition to the adjustment to deferred product revenue, other adjustments at transition include adjustments to accounts receivable, inventories, other current and noncurrent assets, and other liabilities. The adjustment to other current and noncurrent assets is primarily for capitalized incremental contract acquisitions costs and the establishment of contract assets. The cumulative effect adjustment is recorded net of tax with the direct tax effect recorded primarily as a reduction of deferred tax assets. We also expect to record in the first quarter of fiscal 2019 a net indirect tax benefit to our provision for income taxes related to intercompany adjustments associated with the new standard. See Critical Accounting Estimates, "Revenue Recognition" for further discussion on the fiscal 2019 revenue impacts of ASC 606.

[0000858877-18-000011:notes:361]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. We will adopt this accounting standard update in the first quarter of fiscal 2019. The most significant impact of this accounting standard update for us is that it will require the remeasurement of investments that are not accounted for under the equity method at fair value at the end of each reporting period with the changes recorded to the income statement. We estimate an increase to retained earnings of approximately $0.3 billion upon adoption of the accounting standard at the beginning of fiscal 2019. The adjustment is primarily driven by a reclassification of net unrealized gains (losses), net of tax on available-for-sale equity investments from accumulated other comprehensive income, and an increase related to our privately held investments. We expect that this accounting standard update will increase the variability of other income (loss), net in future periods.

[0000858877-18-000011:notes:362]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. We will adopt this accounting standard update in the first quarter of fiscal 2019 on a modified retrospective basis. We estimate an increase to retained earnings of approximately $1.3 billion upon adoption of the accounting standard at the beginning of fiscal 2019. The increase to retained earnings reflects estimated changes to deferred tax assets and other assets related to the recognition of income tax effects of intra-entity asset transfers (other than inventory) that occurred prior to the adoption date. The ongoing impact of this standard will be facts and circumstances dependent on any transactions within its scope.

[0000858877-18-000011:notes:363]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. We will adopt this accounting standard update in the first quarter of fiscal 2019 on a retrospective basis. We do not expect that this accounting standard update will have a material impact on our Consolidated Statements of Cash Flows.

[0000858877-18-000011:notes:364]
Restricted Cash in Statement of Cash Flow  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. We will adopt this accounting standard update in the first quarter of fiscal 2019 using a retrospective transition method for each period presented. We do not expect this accounting update will have a material impact, though it will change the presentation of the Consolidated Statements of Cash Flows.

[0000858877-18-000011:notes:365]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. We will adopt this accounting standard update beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be fact dependent, but we expect that some transactions that were previously accounted for as business combinations or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.

[0000858877-18-000011:notes:366]
Simplifying the Test for Goodwill Impairment  In January 2017, the FASB issued an accounting standard update that removes Step 2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. We will early adopt this standard in the first quarter of fiscal 2019 on a prospective basis. We do not expect this accounting standard update will have a material impact on our Consolidated Financial Statements.

[0000858877-18-000011:notes:367]
Leases  In February 2016, the FASB issued an accounting standard update, as well as subsequent amendments, related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2020 on a modified retrospective basis, and early adoption is permitted. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.

[0000858877-18-000011:notes:368]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2021 on a modified retrospective basis, and early adoption in fiscal 2020 is permitted. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-18-000011:notes:369]
Basis of Presentation

[0000858877-18-000011:notes:370]
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2018 and fiscal 2017 were each 52-week fiscal years, while fiscal 2016 was a 53-week fiscal year. The Consolidated Financial Statements include the accounts of ours and those of our subsidiaries. All intercompany accounts and transactions have been eliminated.  We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-18-000011:notes:371]
Certain reclassifications have been made to the amounts for prior years in order to conform to the current year’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000858877-18-000011:notes:372]
(g) Depreciation and Amortization   Property and equipment are stated at cost, less accumulated depreciation or amortization, whenever applicable. Depreciation and amortization expenses for property and equipment were approximately $1.1 billion, $1.1 billion, and $1.0 billion for fiscal 2018, 2017, and 2016, respectively. Depreciation and amortization are computed using the straight-line method, generally over the following periods:


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-18-000011:notes:373]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,710 |  |  | $ | 4,926 |  |
| Computer equipment and related software |  | 1,085 |  |  | 1,258 |  |
| Production, engineering, and other equipment |  | 5,734 |  |  | 5,707 |  |
| Operating lease assets |  | 356 |  |  | 356 |  |
| Furniture and fixtures |  | 358 |  |  | 572 |  |
| Total gross property and equipment |  | 12,243 |  |  | 12,819 |  |
| Less: accumulated depreciation and amortization |  | (9,237 | ) |  | (9,497 | ) |
| Total |  | $ | 3,006 |  |  | $ | 3,322 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000858877-18-000011:notes:374]
Supplementary Financial Data (Unaudited)

[0000858877-18-000011:notes:375]
(in millions, except per-share amounts)

[0000858877-18-000011:notes:376]
| Quarters Ended | July 28, 2018 (1) |  | April 28, 2018 |  | January 27, 2018 (2) |  | October 28, 2017 |
| Revenue | $ | 12,844 |  |  | $ | 12,463 |  |  | $ | 11,887 |  |  | $ | 12,136 |  |
| Gross margin | $ | 7,922 |  |  | $ | 7,759 |  |  | $ | 7,498 |  |  | $ | 7,427 |  |
| Operating income | $ | 3,346 |  |  | $ | 3,134 |  |  | $ | 3,073 |  |  | $ | 2,756 |  |
| Net income (loss) | $ | 3,803 |  |  | $ | 2,691 |  |  | $ | (8,778 | ) |  | $ | 2,394 |  |
| Net income (loss) per share - basic | $ | 0.81 |  |  | $ | 0.56 |  |  | $ | (1.78 | ) |  | $ | 0.48 |  |
| Net income (loss) per share - diluted | $ | 0.81 |  |  | $ | 0.56 |  |  | $ | (1.78 | ) |  | $ | 0.48 |  |
| Cash dividends declared per common share | $ | 0.33 |  |  | $ | 0.33 |  |  | $ | 0.29 |  |  | $ | 0.29 |  |
| Cash and cash equivalents and investments | $ | 46,548 |  |  | $ | 54,431 |  |  | $ | 73,683 |  |  | $ | 71,588 |  |

[0000858877-18-000011:notes:377]
| Quarters Ended | July 29, 2017 |  | April 29, 2017 |  | January 28, 2017 |  | October 29, 2016 |
| Revenue | $ | 12,133 |  |  | $ | 11,940 |  |  | $ | 11,580 |  |  | $ | 12,352 |  |
| Gross margin | $ | 7,546 |  |  | $ | 7,518 |  |  | $ | 7,276 |  |  | $ | 7,884 |  |
| Operating income | $ | 3,034 |  |  | $ | 3,169 |  |  | $ | 2,893 |  |  | $ | 2,877 |  |
| Net income | $ | 2,424 |  |  | $ | 2,515 |  |  | $ | 2,348 |  |  | $ | 2,322 |  |
| Net income per share - basic | $ | 0.49 |  |  | $ | 0.50 |  |  | $ | 0.47 |  |  | $ | 0.46 |  |
| Net income per share - diluted | $ | 0.48 |  |  | $ | 0.50 |  |  | $ | 0.47 |  |  | $ | 0.46 |  |
| Cash dividends declared per common share | $ | 0.29 |  |  | $ | 0.29 |  |  | $ | 0.26 |  |  | $ | 0.26 |  |
| Cash and cash equivalents and investments | $ | 70,492 |  |  | $ | 67,974 |  |  | $ | 71,845 |  |  | $ | 70,968 |  |

[0000858877-18-000011:notes:378]
(1) In the fourth quarter of fiscal 2018, we recorded adjustments to the provisional amounts related to the U.S. transition tax on accumulated earnings of foreign subsidiaries and re-measurement of net deferred tax assets. These adjustments included an $863 million benefit to the U.S. transition tax provisional amount related to the U.S. taxation of deemed foreign dividends after the date of enactment in the transition fiscal year.

[0000858877-18-000011:notes:379]
(2) In the second quarter of fiscal 2018, we recorded a provisional tax expense of $11.1 billion related to the Tax Act, comprised of $9.0 billion of U.S. transition tax, $1.2 billion of foreign withholding tax, and $0.9 billion re-measurement of net DTA.


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000858877-18-000011:notes:380]
(r) Software Development Costs   Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-18-000011:notes:381]
Restructuring and Other Charges

[0000858877-18-000011:notes:382]
We initiated a restructuring plan during fiscal 2018 (the “Fiscal 2018 Plan”), in order to realign our organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $300 million. In connection with the Fiscal 2018 Plan, we incurred charges of $108 million during fiscal 2018. These aggregate pretax charges are primarily cash-based and consist of employee severance and other one-time termination benefits, and other associated costs. We expect the Fiscal 2018 Plan to be substantially completed in fiscal 2019.

[0000858877-18-000011:notes:383]
We announced a restructuring plan in August 2016 (the “Fiscal 2017 Plan”), in order to reinvest in our key priority areas. In connection with the Fiscal 2017 Plan, we incurred cumulative charges of $1.0 billion, which were primarily cash-based and consisted of employee severance and other one-time termination benefits, and other associated costs. We completed the Fiscal 2017 Plan in fiscal 2018.

[0000858877-18-000011:notes:384]
We announced a restructuring action in August 2014 (the “Fiscal 2015 Plan”), in order to realign our workforce towards key growth areas of our business such as data center, software, security, and cloud. In connection with this plan, we incurred cumulative charges of approximately $756 million. We completed the Fiscal 2015 Plan at the end of fiscal 2016.

[0000858877-18-000011:notes:385]
The following table summarizes the activities related to the restructuring and other charges, as discussed above (in millions):

[0000858877-18-000011:notes:386]
|  |  | FISCAL 2017 AND PRIOR YEAR PLANS |  | FISCAL 2018 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 25, 2015 |  | $ | 60 |  |  | $ | 29 |  |  | $ | — |  |  | $ | — |  |  | $ | 89 |  |
| Charges |  | 225 |  |  | 43 |  |  | — |  |  | — |  |  | 268 |  |
| Cash payments |  | (264 | ) |  | (15 | ) |  | — |  |  | — |  |  | (279 | ) |
| Non-cash items |  | — |  |  | (33 | ) |  | — |  |  | — |  |  | (33 | ) |
| Liability as of July 30, 2016 |  | 21 |  |  | 24 |  |  | — |  |  | — |  |  | 45 |  |
| Charges |  | 625 |  |  | 131 |  |  | — |  |  | — |  |  | 756 |  |
| Cash payments |  | (569 | ) |  | (37 | ) |  | — |  |  | — |  |  | (606 | ) |
| Non-cash items |  | (3 | ) |  | (75 | ) |  | — |  |  | — |  |  | (78 | ) |
| Liability as of July 29, 2017 |  | 74 |  |  | 43 |  |  | — |  |  | — |  |  | 117 |  |
| Charges |  | 227 |  |  | 23 |  |  | 92 |  |  | 16 |  |  | 358 |  |
| Cash payments |  | (262 | ) |  | (35 | ) |  | (73 | ) |  | (2 | ) |  | (372 | ) |
| Non-cash items |  | 2 |  |  | (18 | ) |  | — |  |  | (14 | ) |  | (30 | ) |
| Liability as of July 28, 2018 |  | $ | 41 |  |  | $ | 13 |  |  | $ | 19 |  |  | $ | — |  |  | $ | 73 |  |

[0000858877-18-000011:notes:387]
In addition to the above amounts, we incurred $2 million credit of restructuring and other charges within cost of sales during fiscal 2016.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000858877-18-000011:notes:388]
(o) Revenue Recognition   We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is reasonably assured. In instances where final acceptance of the product, system, or solution is specified by the customer, revenue is deferred until all acceptance criteria have been met. For hosting arrangements, we recognize revenue ratably over the hosting period, while usage revenue is recognized based on utilization. Software subscription revenue is deferred and recognized ratably over the subscription term upon delivery of the first product and commencement of the term. Technical support and consulting services revenue is deferred and recognized ratably over the period during which the services are to be performed, which is typically from one to three years. Transactional advanced services revenue is recognized upon delivery or completion of performance milestones.

[0000858877-18-000011:notes:389]
We use distributors that typically stock inventory and sell to systems integrators, service providers, and other resellers. We refer to this as our two-tier sales to the end customer. Revenue from distributors is recognized based on a sell-through method using point-of-sale information provided by the distributors. Distributors and other partners participate in various rebate, cooperative marketing, and other incentive programs, and we maintain estimated accruals and allowances for these programs. The ending liability for these programs was included in other current liabilities, and the balance was $1.0 billion as of each of July 28, 2018 and July 29, 2017. We accrue for warranty costs, sales returns, and other allowances based on our historical experience. Shipping and handling fees billed to customers are included in revenue, with the associated costs included in cost of sales.

[0000858877-18-000011:notes:390]
Many of our products have both software and non-software components that function together to deliver the products’ essential functionality. We also provide technical support and advanced services. We have a broad customer base that encompasses virtually all types of public and private entities, including enterprise businesses, service providers, and commercial customers. Cisco and our salesforce are not organized by product divisions, and our products and services can be sold standalone or together in various combinations across our geographic segments or customer markets. For example, service provider arrangements are typically larger in scale with longer deployment schedules and involve the delivery of a variety of product technologies, including high-end routing, video and network management software, and other product technologies along with technical support and advanced services. Our enterprise and commercial arrangements are unique for each customer and smaller in scale and may include network infrastructure products such as routers and switches or collaboration technologies such as Unified Communications and Cisco TelePresence systems products along with technical support services.

[0000858877-18-000011:notes:391]
We enter into revenue arrangements that may consist of multiple deliverables of our product and service offerings due to the needs of our customers. For example, a customer may purchase routing products along with a contract for technical support services. This arrangement would consist of multiple elements, with the products delivered in one reporting period and the technical support services delivered across multiple reporting periods. Another customer may purchase networking products along with advanced service offerings, in which all the elements are delivered within the same reporting period. In addition, distributors purchase products or technical support services on a standalone basis for resale to an end user or for purposes of stocking certain products, and these transactions would not result in a multiple-element arrangement. We consider several factors when reviewing multiple purchases made by the same customer within a short time frame in order to identify multiple-element arrangements, including whether the deliverables are closely interrelated, whether the deliverables are essential to each other’s functionality, whether payment terms are linked, whether the customer is entitled to a refund or concession if another purchase is not completed satisfactorily, and/or whether the purchases were negotiated together as one overall arrangement.

[0000858877-18-000011:notes:392]
In many instances, products are sold separately in standalone arrangements as customers may support the products themselves or purchase support on a time-and-materials basis. Advanced services are sometimes sold in standalone engagements such as general consulting, network management, or security advisory projects, and technical support services are sold separately through renewals of annual contracts. We determine our vendor-specific objective evidence (VSOE) based on our normal pricing and discounting practices for products or services when sold separately. VSOE determination requires that a substantial majority of the historical standalone transactions has the selling prices for a product or service that fall within a reasonably narrow pricing range, generally evidenced by approximately 80% of such historical standalone transactions falling within plus or minus 15% of the median rates. In addition, we consider the geographies in which the products or services are sold, major product and service groups and customer classifications, and other environmental or marketing variables in determining VSOE.

[0000858877-18-000011:notes:393]
When we are not able to establish VSOE for all deliverables in an arrangement with multiple elements, which may be due to us infrequently selling each element separately, not pricing products within a narrow range, or only having a limited sales history, such as in the case of certain newly introduced product categories, we attempt to determine the selling price of each element based on third-party evidence of selling price (TPE). TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers, and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products’ selling prices are on a standalone basis. Therefore, we are typically not able to determine TPE.

[0000858877-18-000011:notes:394]
When we are unable to establish fair value using VSOE or TPE, we use estimated selling prices (ESP) in our allocation of arrangement consideration. The objective of ESP is to determine the price at which we would transact a sale if the product or service were regularly sold on a standalone basis. ESP is generally used for new or highly proprietary offerings and solutions or for offerings not priced within a reasonably narrow range. We determine ESP for a product or service by considering multiple factors, including, but not limited to, geographies, market conditions, competitive landscape, internal costs, gross margin objectives, and pricing practices. The determination of ESP is made through consultation with and formal approval by our management, taking into consideration the go-to-market strategy.

[0000858877-18-000011:notes:395]
We regularly review VSOE, TPE, and ESP and maintains internal controls over the establishment and updates of these estimates. There were no material impacts during fiscal 2018 from changes in VSOE, TPE, or ESP.

[0000858877-18-000011:notes:396]
Our arrangements with multiple deliverables may include one or more software deliverables that are subject to the software revenue recognition guidance. In these cases, revenue for the software is generally recognized upon shipment or electronic delivery and granting of the license. The revenue for these multiple-element arrangements is allocated to the software deliverables and the non-software deliverables based on the relative selling prices of all of the deliverables in the arrangement using the hierarchy in the applicable accounting guidance. In the circumstances where we cannot determine VSOE or TPE of the selling price for all of the deliverables in the arrangement, including the software deliverables, ESP is used for the purposes of performing this allocation. VSOE is required to allocate the revenue between multiple software deliverables. If VSOE is available for the undelivered software elements, we apply the residual method; where VSOE is not available, software revenue is either recognized when all software elements have been delivered or recognized ratably when post-contract support is the only undelivered software element remaining.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0000858877-18-000011:notes:397]
A summary of the allocation of the total purchase consideration is presented as follows (in millions):


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000858877-18-000011:notes:398]
The following tables provide details of selected balance sheet items (in millions):

[0000858877-18-000011:notes:399]
|  |  | July 28, 2018 |  | July 29, 2017 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 423 |  |  | $ | 289 |  |
| Work in process |  | — |  |  | 1 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 443 |  |  | 451 |  |
| Manufactured finished goods |  | 689 |  |  | 552 |  |
| Total finished goods |  | 1,132 |  |  | 1,003 |  |
| Service-related spares |  | 258 |  |  | 300 |  |
| Demonstration systems |  | 33 |  |  | 23 |  |
| Total |  | $ | 1,846 |  |  | $ | 1,616 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-18-000011:notes:400]
Summary of Significant Accounting Policies

[0000858877-18-000011:notes:401]
(b) Available-for-Sale Investments   We classify our investments in both fixed income securities and publicly traded equity securities as available-for-sale investments. Fixed income securities primarily consist of U.S. government securities, U.S. government agency securities, non-U.S. government and agency securities, corporate debt securities, and U.S. agency mortgage-backed securities. These available-for-sale investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of fixed income and public equity securities sold. These investments are recorded in the Consolidated Balance Sheets at fair value. Unrealized gains and losses on these investments, to the extent the investments are unhedged, are included as a separate component of accumulated other comprehensive income (AOCI), net of tax. We classify our investments as current based on the nature of the investments and their availability for use in current operations.

[0000858877-18-000011:notes:402]
(e) Allowance for Doubtful Accounts   The allowance for doubtful accounts is based on our assessment of the collectibility of customer accounts. We regularly review the allowance by considering factors such as historical experience, credit quality, age of the accounts receivable balances, economic conditions that may affect a customer’s ability to pay, and expected default frequency rates. Trade receivables are written off at the point when they are considered uncollectible.

[0000858877-18-000011:notes:403]
(f) Financing Receivables and Guarantees   We provide financing arrangements, including leases, financed service contracts, and loans, for certain qualified end-user customers to build, maintain, and upgrade their networks. Lease receivables primarily represent sales-type and direct-financing leases. Leases have on average a four-year term and are usually collateralized by a security interest in the underlying assets. Loan receivables include customers financing purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. Loan receivables generally have terms of up to three years. Financed service contracts typically have terms of one to three years and primarily relate to technical support services.

[0000858877-18-000011:notes:404]
We determine the adequacy of our allowance for credit loss by assessing the risks and losses inherent in our financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by us to our customers: lease receivables, loan receivables, and financed service contracts.

[0000858877-18-000011:notes:405]
We assess the allowance for credit loss related to financing receivables on either an individual or a collective basis. We consider various factors in evaluating lease and loan receivables and the earned portion of financed service contracts for possible impairment on an individual basis. These factors include our historical experience, credit quality and age of the receivable balances, and economic conditions that may affect a customer’s ability to pay. When the evaluation indicates that it is probable that all amounts due pursuant to the contractual terms of the financing agreement, including scheduled interest payments, are unable to be collected, the financing receivable is considered impaired. All such outstanding amounts, including any accrued interest, are assessed and reserved at the customer level. Our internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality financing receivables. Typically, we also consider financing receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. We evaluate the remainder of our financing receivables portfolio for impairment on a collective basis and record an allowance for credit loss at the portfolio segment level. When evaluating the financing receivables on a collective basis, we use historical default rates and expected default frequency rates published by major third-party credit-rating agencies as well as our own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk, and correlation.

[0000858877-18-000011:notes:406]
Expected default frequency rates and historical default rates are published quarterly by major third-party credit-rating agencies, and the internal credit risk rating is derived by taking into consideration various customer-specific factors and macroeconomic conditions. These factors, which include the strength of the customer’s business and financial performance, the quality of the customer’s banking relationships, our specific historical experience with the customer, the performance and outlook of the customer’s industry, the customer’s legal and regulatory environment, the potential sovereign risk of the geographic locations in which the customer is operating, and independent third-party evaluations, are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000858877-18-000011:notes:407]
Financing receivables are written off at the point when they are considered uncollectible, and all outstanding balances, including any previously earned but uncollected interest income, will be reversed and charged against the allowance for credit loss. We do not typically have any partially written-off financing receivables.

[0000858877-18-000011:notes:408]
Outstanding financing receivables that are aged 31 days or more from the contractual payment date are considered past due. We do not accrue interest on financing receivables that are considered impaired or more than 90 days past due unless either the receivable has not been collected due to administrative reasons or the receivable is well secured and in the process of collection. Financing receivables may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain. After a financing receivable has been categorized as nonaccrual, interest will be recognized when cash is received. A financing receivable may be returned to accrual status after all of the customer’s delinquent balances of principal and interest have been settled, and the customer remains current for an appropriate period.

[0000858877-18-000011:notes:409]
We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive a payment for the receivables from the third party based on our standard payment terms. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Deferred revenue relating to these financing arrangements is recorded in accordance with revenue recognition policies or for the fair value of the financing guarantees.

[0000858877-18-000011:notes:410]
(k) Fair Value   Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, we consider the principal or most advantageous market in which we would transact, and we also consider assumptions that market participants would use when pricing the asset or liability.

[0000858877-18-000011:notes:411]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. The standard establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000858877-18-000011:notes:412]
Level 1 applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000858877-18-000011:notes:413]
Level 2 applies to assets or liabilities for which there are inputs other than quoted prices that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets); or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of assets or liabilities.

[0000858877-18-000011:notes:414]
Level 3 applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities. The fair values are determined based on model-based techniques such as discounted cash flow models using inputs that we could not corroborate with market data.

[0000858877-18-000011:notes:415]
(p) Advertising Costs   We expense all advertising costs as incurred. Advertising costs included within sales and marketing expenses were approximately $166 million, $209 million, and $186 million for fiscal 2018, 2017, and 2016, respectively.

[0000858877-18-000011:notes:416]
(u) Consolidation of Variable Interest Entities  We use a qualitative approach in assessing the consolidation requirement for variable interest entities. The approach focuses on identifying which enterprise has the power to direct the activities that most significantly impact the variable interest entity’s economic performance and which enterprise has the obligation to absorb losses or the right to receive benefits from the variable interest entity. In the event that we are the primary beneficiary of a variable interest entity, the assets, liabilities, and results of operations of the variable interest entity will be included in our Consolidated Financial Statements.

[0000858877-18-000011:notes:417]
(v) Use of Estimates   The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Estimates are used for the following, among others:

[0000858877-18-000011:notes:418]
| ▪ | Revenue recognition |

[0000858877-18-000011:notes:419]
| ▪ | Allowances for accounts receivable, sales returns, and financing receivables |

[0000858877-18-000011:notes:420]
| ▪ | Inventory valuation and liability for purchase commitments with contract manufacturers and suppliers |

[0000858877-18-000011:notes:421]
| ▪ | Loss contingencies and product warranties |

[0000858877-18-000011:notes:422]
| ▪ | Fair value measurements and other-than-temporary impairments |

[0000858877-18-000011:notes:423]
| ▪ | Goodwill and purchased intangible asset impairments |

[0000858877-18-000011:notes:424]
| ▪ | Income taxes |

[0000858877-18-000011:notes:425]
The actual results experienced by us may differ materially from management’s estimates.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-18-000011:notes:426]
Shareholders’ Equity

[0000858877-18-000011:notes:427]
| (a) | Cash Dividends on Shares of Common Stock |

[0000858877-18-000011:notes:428]
We declared and paid cash dividends of $1.24, $1.10 and $0.94 per common share, or $6.0 billion, $5.5 billion and $4.8 billion, on our outstanding common stock during fiscal 2018, 2017, and 2016, respectively.

[0000858877-18-000011:notes:429]
Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-18-000011:notes:430]
| (b) | Stock Repurchase Program |

[0000858877-18-000011:notes:431]
In September 2001, our Board of Directors authorized a stock repurchase program.  On February 14, 2018, our Board of Directors authorized a $25 billion increase to the stock repurchase program.  As of July 28, 2018, the remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $19.0 billion, with no termination date.

[0000858877-18-000011:notes:432]
There were $180 million, $66 million and $45 million in stock repurchases pending settlement as of July 28, 2018, July 29, 2017 and July 30, 2016, respectively.

[0000858877-18-000011:notes:433]
The purchase price for the shares of our stock repurchased is reflected as a reduction to shareholders’ equity. We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings and (ii) a reduction of common stock and additional paid-in capital.

[0000858877-18-000011:notes:434]
| (c) | Restricted Stock Unit Withholdings |

[0000858877-18-000011:notes:435]
We repurchased approximately 20 million, 20 million and 21 million shares, or $703 million, $619 million and $557 million of common stock in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units during fiscal 2018, 2017, and 2016, respectively.

[0000858877-18-000011:notes:436]
| (d) | Preferred Stock |

[0000858877-18-000011:notes:437]
Under the terms of our Articles of Incorporation, the Board of Directors may determine the rights, preferences, and terms of our authorized but unissued shares of preferred stock.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-18-000011:notes:438]
Balance Sheet Details
