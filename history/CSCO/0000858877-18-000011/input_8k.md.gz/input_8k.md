# CSCO 8-K — 0001193125-18-249746 filed 2018-08-15

## item codes, every 8-K on or before 2018-09-06

- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2018-09-06

- none on or before 2018-09-06

## item 2.02 — earnings release, exhibit 99.1

[0001193125-18-249746:8k_2_02:1]
EX-99.1
2
d605437dex991.htm
EXHIBIT 99.1

[0001193125-18-249746:8k_2_02:2]
Exhibit 99.1

[0001193125-18-249746:8k_2_02:3]
Exhibit 99.1

[0001193125-18-249746:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 853-9848 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-18-249746:8k_2_02:5]
CISCO REPORTS FOURTH QUARTER AND FISCAL YEAR 2018 EARNINGS

[0001193125-18-249746:8k_2_02:6]
|  | • |  | Q4 Results: |

[0001193125-18-249746:8k_2_02:7]
|  | • |  | Revenue: $12.8 billion |

[0001193125-18-249746:8k_2_02:8]
|  | • |  | Increase of 6% year over year |

[0001193125-18-249746:8k_2_02:9]
|  | • |  | Recurring revenue was 32% of total revenue, up 1 point year over year |

[0001193125-18-249746:8k_2_02:10]
|  | • |  | Earnings per Share: GAAP: $0.81; Non-GAAP: $0.70 |

[0001193125-18-249746:8k_2_02:11]
|  | • |  | Non-GAAP EPS increased 15% year over year |

[0001193125-18-249746:8k_2_02:12]
|  | • |  | FY 2018 Results: |

[0001193125-18-249746:8k_2_02:13]
|  | • |  | Revenue: $49.3 billion; increase of 3% year over year |

[0001193125-18-249746:8k_2_02:14]
|  | • |  | Earnings per Share: GAAP: $0.02; Non-GAAP: $2.60 |

[0001193125-18-249746:8k_2_02:15]
|  | • |  | Non-GAAP EPS increased 9% year over year |

[0001193125-18-249746:8k_2_02:16]
|  | • |  | GAAP results include a $10.4 billion charge related to the enactment of the Tax Cuts and Jobs Acts |

[0001193125-18-249746:8k_2_02:17]
|  | • |  | Q1 FY 2019 Guidance: |

[0001193125-18-249746:8k_2_02:18]
|  | • |  | Revenue: 5% to 7% growth year over year |

[0001193125-18-249746:8k_2_02:19]
|  | • |  | Earnings per Share: GAAP: $0.69 to $0.74; Non-GAAP: $0.70 to $0.72 |

[0001193125-18-249746:8k_2_02:20]
SAN JOSE, Calif. — August 15, 2018 — Cisco today reported fourth quarter and fiscal year results for the period ended
July 28, 2018. Cisco reported fourth quarter revenue of $12.8 billion, net income on a generally accepted accounting principles (GAAP) basis of $3.8 billion or $0.81 per share, and non-GAAP net
income of $3.3 billion or $0.70 per share.

[0001193125-18-249746:8k_2_02:21]
“We had a very strong finish to a great year and generated our highest quarterly revenue of $12.8
billion,” said Chuck Robbins, Chairman and CEO of Cisco. “Our results demonstrate a combination of strong customer adoption of our latest innovations, the ongoing value customers see in our software and subscription offerings, and
excellent execution across our customer segments and geographies. Our strategy is working and we believe that are well-positioned to capture growth across our portfolio with our pipeline of innovation.”

[0001193125-18-249746:8k_2_02:22]
Q4 GAAP Results

[0001193125-18-249746:8k_2_02:23]
|  |  | Q4 FY 2018 |  |  | Q4 FY 2017 |  |  | Vs. Q4 FY 2017 |  |
| Revenue |  | $ | 12.8 billion |  |  | $ | 12.1 billion |  |  |  | 6 | % |
| Net Income |  | $ | 3.8 billion |  |  | $ | 2.4 billion |  |  |  | 57 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.81 |  |  | $ | 0.48 |  |  |  | 69 | % |

[0001193125-18-249746:8k_2_02:24]
Q4 GAAP results include an $863 million benefit related to the Tax Cuts and Jobs Act.
Non-GAAP results exclude this benefit.

[0001193125-18-249746:8k_2_02:25]
Q4 Non-GAAP
Results

[0001193125-18-249746:8k_2_02:26]
|  |  | Q4 FY 2018 |  |  | Q4 FY 2017 |  |  | Vs. Q4 FY 2017 |  |
| Net Income |  | $ | 3.3 billion |  |  | $ | 3.1 billion |  |  |  | 8 | % |
| EPS |  | $ | 0.70 |  |  | $ | 0.61 |  |  |  | 15 | % |

[0001193125-18-249746:8k_2_02:27]
1

[0001193125-18-249746:8k_2_02:28]
Fiscal Year GAAP Results

[0001193125-18-249746:8k_2_02:29]
|  |  | FY 2018 |  |  | FY 2017 |  |  | Vs. FY 2017 |  |
| Revenue |  | $ | 49.3 billion |  |  | $ | 48.0 billion |  |  |  | 3 | % |
| Net Income |  | $ | 0.1 billion |  |  | $ | 9.6 billion |  |  |  | (99 | )% |
| EPS |  | $ | 0.02 |  |  | $ | 1.90 |  |  |  | (99 | )% |

[0001193125-18-249746:8k_2_02:30]
Fiscal year GAAP results include a $10.4 billion charge related to the enactment of the Tax Cuts and Jobs Act comprised
of $8.1 billion for the U.S. transition tax, $1.2 billion for foreign withholding tax and $1.1 billion for the re-measurement of net deferred tax assets.

[0001193125-18-249746:8k_2_02:31]
Fiscal Year Non-GAAP Results

[0001193125-18-249746:8k_2_02:32]
|  |  | FY 2018 |  |  | FY 2017 |  |  | Vs. FY 2017 |  |
| Net Income |  | $ | 12.7 billion |  |  | $ | 12.1 billion |  |  |  | 5 | % |
| EPS |  | $ | 2.60 |  |  | $ | 2.39 |  |  |  | 9 | % |

[0001193125-18-249746:8k_2_02:33]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-18-249746:8k_2_02:34]
“Q4 was another quarter of broad-based strength across our portfolio reflecting our strong execution and momentum. We delivered record quarterly revenue,
up 6%, and non-GAAP EPS, up 15%,” said Kelly Kramer, CFO of Cisco. “We are seeing solid demand for our products and solutions while continuing to make progress in transforming our business model and driving long-term shareholder
value.”

[0001193125-18-249746:8k_2_02:35]
2

[0001193125-18-249746:8k_2_02:36]
Financial Summary

[0001193125-18-249746:8k_2_02:37]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-18-249746:8k_2_02:38]
Q4 FY 2018 Highlights

[0001193125-18-249746:8k_2_02:39]
Revenue —
Total revenue was $12.8 billion, up 6%, with product revenue up 7% and service revenue up 3%. Recurring revenue as a percentage of total revenue was 32%, up 1 point year over year. Revenue by geographic segment was: Americas up 5%, EMEA
up 8%, and APJC up 6%. Product revenue performance was generally broad based with growth in Security, up 12%, Applications, up 10%, and Infrastructure Platforms, up 7%.

[0001193125-18-249746:8k_2_02:40]
Gross Margin — On a GAAP basis, total gross margin, product gross margin, and service gross margin were 61.7%, 60.2%, and 66.0%,
respectively, as compared with 62.2%, 60.3%, and 67.8%, respectively, in the fourth quarter of 2017.

[0001193125-18-249746:8k_2_02:41]
On a
non-GAAP basis, total gross margin, product gross margin, and service gross margin were 62.9%, 61.5%, and 67.1%, respectively, as compared with 63.7%, 61.9%, and 68.8%, respectively, in the fourth quarter of
2017.

[0001193125-18-249746:8k_2_02:42]
Total gross margins by geographic segment were: 64.1% for the Americas, 63.7% for EMEA and 57.7% for APJC.

[0001193125-18-249746:8k_2_02:43]
Operating Expenses — On a GAAP basis, operating expenses were $4.6 billion, up 1%.
Non-GAAP operating expenses were $4.1 billion, up 5%, and were 32.0% of revenue.

[0001193125-18-249746:8k_2_02:44]
Operating Income
— GAAP operating income was $3.3 billion, up 10%, with GAAP operating margin of 26.1%. Non-GAAP operating income was $4.0 billion, up 4%, with
non-GAAP operating margin at 30.9%.

[0001193125-18-249746:8k_2_02:45]
Provision for (benefit from) Income Taxes — The GAAP tax
provision rate was (5.9)%, which includes an $863 million benefit related to the Tax Cuts and Jobs Act. The non-GAAP tax provision rate was 21.2%.

[0001193125-18-249746:8k_2_02:46]
Net Income and EPS — On a GAAP basis, net income was $3.8 billion and EPS was $0.81. On a
non-GAAP basis, net income was $3.3 billion, an increase of 8%, and EPS was $0.70, an increase of 15%.

[0001193125-18-249746:8k_2_02:47]
Cash Flow from Operating Activities — $4.1 billion for the fourth quarter of fiscal 2018, an increase of 2% compared with
$4.0 billion for the fourth quarter of fiscal 2017.

[0001193125-18-249746:8k_2_02:48]
FY 2018 Highlights

[0001193125-18-249746:8k_2_02:49]
Revenue — Total revenue was $49.3 billion, an increase of 3%.

[0001193125-18-249746:8k_2_02:50]
Net Income and EPS — On a GAAP basis, net income was $0.1 billion and EPS was $0.02. GAAP net income includes a $10.4 billion
charge related to the enactment of the Tax Cuts and Jobs Act comprised of $8.1 billion for the U.S. transition tax, $1.2 billion for foreign withholding tax and $1.1 billion for the
re-measurement of net deferred tax assets.

[0001193125-18-249746:8k_2_02:51]
On a non-GAAP basis, net
income was $12.7 billion, up 5% compared to fiscal 2017, and EPS was $2.60, an increase of 9%.

[0001193125-18-249746:8k_2_02:52]
Cash Flow from Operating Activities
— $13.7 billion for fiscal 2018, compared with $13.9 billion for fiscal 2017, a decrease of 2%. Operating cash flow for fiscal 2018 includes the payments of $1.4 billion of one-time
foreign taxes as related to the Tax Cuts and Jobs Act. Operating cash flow increased 8%, normalized for these tax payments.

[0001193125-18-249746:8k_2_02:53]
3

[0001193125-18-249746:8k_2_02:54]
Balance Sheet and Other Financial Highlights

[0001193125-18-249746:8k_2_02:55]
Cash and Cash Equivalents and Investments — $46.5 billion at the end of the fourth quarter of fiscal 2018, compared with
$54.4 billion at the end of the third quarter of fiscal 2018, and compared with $70.5 billion at the end of fiscal 2017. The total cash and cash equivalents and investments available in the United States at the end of the fourth quarter of
fiscal 2018 were $40.4 billion.

[0001193125-18-249746:8k_2_02:56]
Deferred Revenue — $19.7 billion, up 6% in total, with deferred product revenue up 15%,
driven largely by subscription-based and software offers, and deferred service revenue was up 1%. The portion of deferred product revenue related to recurring software and subscription offers increased 23%.

[0001193125-18-249746:8k_2_02:57]
Product Backlog — $6.6 billion at the end of fiscal 2018, an increase of 38% compared with the balance at the end of fiscal
2017.

[0001193125-18-249746:8k_2_02:58]
Capital Allocation — For the fourth quarter of fiscal 2018, Cisco returned $7.5 billion to shareholders through share
buybacks and dividends. Cisco declared and paid a cash dividend of $0.33 per common share, or $1.5 billion. Cisco repurchased approximately 138 million shares of common stock under its stock repurchase program at an average price of $43.58
per share for an aggregate purchase price of $6.0 billion.

[0001193125-18-249746:8k_2_02:59]
For the full fiscal year, Cisco returned $23.6 billion to shareholders through share
buybacks and dividends. Cisco declared and paid cash dividends of $1.24 per common share, or $6.0 billion. Cisco repurchased approximately 432 million shares of common stock under its stock repurchase program at an average price of $40.88
per share for an aggregate purchase price of $17.7 billion. The remaining authorized amount for stock repurchases under the program is approximately $19.0 billion with no termination date.

[0001193125-18-249746:8k_2_02:60]
Acquisitions and Divestitures

[0001193125-18-249746:8k_2_02:61]
In the fourth quarter of
fiscal 2018, we closed the acquisition of Accompany, a privately held company that provides an AI-driven relationship intelligence platform. We also announced our intent to acquire July Systems, Inc., a
privately held company that provides enterprise-grade location platform through cloud-based subscription offerings. This acquisition closed in the first quarter of fiscal 2019. In the fourth quarter of fiscal 2018, we announced an agreement to sell
our Service Provider Video Software Solutions (SPVSS) business. We expect this transaction to close in the first half of fiscal 2019 subject to customary closing conditions and regulatory approvals.

[0001193125-18-249746:8k_2_02:62]
On August 2, 2018, we announced our intent to acquire Duo Security, a privately held company that provides unified access security and multi-factor
authentication delivered through the cloud. The acquisition is expected to close in the first quarter of fiscal 2019, subject to customary closing conditions and regulatory approvals.

[0001193125-18-249746:8k_2_02:63]
4

[0001193125-18-249746:8k_2_02:64]
Guidance for Q1 FY 2019

[0001193125-18-249746:8k_2_02:65]
Cisco expects to achieve the following results for the first quarter of fiscal 2019:

[0001193125-18-249746:8k_2_02:66]
| Q1 FY 2019 |  |  |
| Revenue |  | 5% to 7% growth Y/Y |
| Non-GAAP gross margin rate |  | 63% - 64% |
| Non-GAAP operating margin rate |  | 30% - 31% |
| Non-GAAP tax provision rate |  | 19% |
| Non-GAAP EPS |  | $0.70 - $0.72 |

[0001193125-18-249746:8k_2_02:67]
The guidance includes our SPVSS business that we recently agreed to sell and excludes the Duo Security acquisition since both
transactions have not closed. We expect the SPVSS transaction to close in the first half of fiscal 2019 subject to customary closing conditions and regulatory approvals.

[0001193125-18-249746:8k_2_02:68]
At the beginning of fiscal 2019, Cisco adopted the Financial Accounting Standards Board new standard on revenue recognition (ASC 606) using the modified
retrospective method. The revenue guidance in the preceding table includes the impact of ASC 606 which we estimate to be a benefit of about 1% year over year.

[0001193125-18-249746:8k_2_02:69]
Cisco estimates that GAAP EPS will be $0.69 to $0.74 in the first quarter of fiscal 2019.

[0001193125-18-249746:8k_2_02:70]
A reconciliation between the Guidance for Q1 FY 2019 on a GAAP and non-GAAP basis is provided in the table entitled
“GAAP to non-GAAP Guidance for Q1 FY 2019” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-18-249746:8k_2_02:71]
Editor’s Notes:

[0001193125-18-249746:8k_2_02:72]
|  | • |  | Q4 fiscal year 2018 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, August 15, 2018 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-18-249746:8k_2_02:73]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, August 15, 2018 to 4:00 p.m. Pacific Time, August 22, 2018 at 1-866-417-5767 (United States) or 1-203-369-0735 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-18-249746:8k_2_02:74]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, August 15, 2018. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-18-249746:8k_2_02:75]
5

[0001193125-18-249746:8k_2_02:76]
CISCO SYSTEMS, INC.

[0001193125-18-249746:8k_2_02:77]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-18-249746:8k_2_02:78]
(In millions, except per-share amounts)

[0001193125-18-249746:8k_2_02:79]
(Unaudited)

[0001193125-18-249746:8k_2_02:80]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 28,2018 |  |  | July 29,2017 |  |  | July 28,2018 |  |  | July 29,2017 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,642 |  |  | $ | 9,027 |  |  | $ | 36,709 |  |  | $ | 35,705 |  |
| Service |  |  | 3,202 |  |  |  | 3,106 |  |  |  | 12,621 |  |  |  | 12,300 |  |
| Total revenue |  |  | 12,844 |  |  |  | 12,133 |  |  |  | 49,330 |  |  |  | 48,005 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,833 |  |  |  | 3,586 |  |  |  | 14,427 |  |  |  | 13,699 |  |
| Service |  |  | 1,089 |  |  |  | 1,001 |  |  |  | 4,297 |  |  |  | 4,082 |  |
| Total cost of sales |  |  | 4,922 |  |  |  | 4,587 |  |  |  | 18,724 |  |  |  | 17,781 |  |
| GROSS MARGIN |  |  | 7,922 |  |  |  | 7,546 |  |  |  | 30,606 |  |  |  | 30,224 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,626 |  |  |  | 1,499 |  |  |  | 6,332 |  |  |  | 6,059 |  |
| Sales and marketing |  |  | 2,348 |  |  |  | 2,318 |  |  |  | 9,242 |  |  |  | 9,184 |  |
| General and administrative |  |  | 543 |  |  |  | 495 |  |  |  | 2,144 |  |  |  | 1,993 |  |
| Amortization of purchased intangible assets |  |  | 33 |  |  |  | 58 |  |  |  | 221 |  |  |  | 259 |  |
| Restructuring and other charges |  |  | 26 |  |  |  | 142 |  |  |  | 358 |  |  |  | 756 |  |
| Total operating expenses |  |  | 4,576 |  |  |  | 4,512 |  |  |  | 18,297 |  |  |  | 18,251 |  |
| OPERATING INCOME |  |  | 3,346 |  |  |  | 3,034 |  |  |  | 12,309 |  |  |  | 11,973 |  |
| Interest income |  |  | 353 |  |  |  | 360 |  |  |  | 1,508 |  |  |  | 1,338 |  |
| Interest expense |  |  | (224 | ) |  |  | (222 | ) |  |  | (943 | ) |  |  | (861 | ) |
| Other income (loss), net |  |  | 117 |  |  |  | 8 |  |  |  | 165 |  |  |  | (163 | ) |
| Interest and other income (loss), net |  |  | 246 |  |  |  | 146 |  |  |  | 730 |  |  |  | 314 |  |
| INCOME BEFORE PROVISION FOR (BENEFIT FROM) INCOME TAXES |  |  | 3,592 |  |  |  | 3,180 |  |  |  | 13,039 |  |  |  | 12,287 |  |
| Provision for (benefit from) income taxes (1) |  |  | (211 | ) |  |  | 756 |  |  |  | 12,929 |  |  |  | 2,678 |  |
| NET INCOME |  | $ | 3,803 |  |  | $ | 2,424 |  |  | $ | 110 |  |  | $ | 9,609 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.81 |  |  | $ | 0.49 |  |  | $ | 0.02 |  |  | $ | 1.92 |  |
| Diluted |  | $ | 0.81 |  |  | $ | 0.48 |  |  | $ | 0.02 |  |  | $ | 1.90 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,672 |  |  |  | 4,993 |  |  |  | 4,837 |  |  |  | 5,010 |  |
| Diluted |  |  | 4,722 |  |  |  | 5,027 |  |  |  | 4,881 |  |  |  | 5,049 |  |
| Cash dividends declared per common share |  | $ | 0.33 |  |  | $ | 0.29 |  |  | $ | 1.24 |  |  | $ | 1.10 |  |

[0001193125-18-249746:8k_2_02:81]
| (1) | For the three months ended July 28, 2018, the provision for (benefit from) income taxes includes an $863 million benefit as related to the Tax Cuts and Jobs Act. For fiscal year ended 2018, the provision for income taxes includes a $10.4 billion charge as related to the enactment of the Tax Cuts and Jobs Act. |

[0001193125-18-249746:8k_2_02:82]
6

[0001193125-18-249746:8k_2_02:83]
CISCO SYSTEMS, INC.

[0001193125-18-249746:8k_2_02:84]
REVENUE BY SEGMENT

[0001193125-18-249746:8k_2_02:85]
(In
millions, except percentages)

[0001193125-18-249746:8k_2_02:86]
|  |  | July 28, 2018 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,555 |  |  |  | 5 | % |  | $ | 29,070 |  |  |  | 3 | % |
| EMEA |  |  | 3,174 |  |  |  | 8 | % |  |  | 12,425 |  |  |  | 4 | % |
| APJC |  |  | 2,116 |  |  |  | 6 | % |  |  | 7,834 |  |  |  | 2 | % |
| Total |  | $ | 12,844 |  |  |  | 6 | % |  | $ | 49,330 |  |  |  | 3 | % |

[0001193125-18-249746:8k_2_02:87]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-18-249746:8k_2_02:88]
CISCO SYSTEMS, INC.

[0001193125-18-249746:8k_2_02:89]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-18-249746:8k_2_02:90]
(In percentages)

[0001193125-18-249746:8k_2_02:91]
|  |  | July 28, 2018 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 64.1 | % |  |  | 64.6 | % |
| EMEA |  |  | 63.7 | % |  |  | 63.9 | % |
| APJC |  |  | 57.7 | % |  |  | 60.3 | % |

[0001193125-18-249746:8k_2_02:92]
7

[0001193125-18-249746:8k_2_02:93]
CISCO SYSTEMS, INC.

[0001193125-18-249746:8k_2_02:94]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-18-249746:8k_2_02:95]
(In millions, except percentages)

[0001193125-18-249746:8k_2_02:96]
|  |  | July 28, 2018 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,443 |  |  |  | 7 | % |  | $ | 28,270 |  |  |  | 2 | % |
| Applications |  |  | 1,339 |  |  |  | 10 | % |  |  | 5,035 |  |  |  | 10 | % |
| Security |  |  | 627 |  |  |  | 12 | % |  |  | 2,353 |  |  |  | 9 | % |
| Other Products |  |  | 232 |  |  |  | (18 | )% |  |  | 1,050 |  |  |  | (13 | )% |
| Total Product |  |  | 9,642 |  |  |  | 7 | % |  |  | 36,709 |  |  |  | 3 | % |
| Services |  |  | 3,202 |  |  |  | 3 | % |  |  | 12,621 |  |  |  | 3 | % |
| Total |  | $ | 12,844 |  |  |  | 6 | % |  | $ | 49,330 |  |  |  | 3 | % |

[0001193125-18-249746:8k_2_02:97]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-18-249746:8k_2_02:98]
8

[0001193125-18-249746:8k_2_02:99]
CISCO SYSTEMS, INC.

[0001193125-18-249746:8k_2_02:100]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-18-249746:8k_2_02:101]
(In millions)

[0001193125-18-249746:8k_2_02:102]
(Unaudited)

[0001193125-18-249746:8k_2_02:103]
|  |  | July 28,2018 |  |  | July 29,2017 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 8,934 |  |  | $ | 11,708 |  |
| Investments |  |  | 37,614 |  |  |  | 58,784 |  |
| Accounts receivable, net of allowance for doubtful accountsof $129 at July 28, 2018 and $211 at July 29, 2017 |  |  | 5,554 |  |  |  | 5,146 |  |
| Inventories |  |  | 1,846 |  |  |  | 1,616 |  |
| Financing receivables, net |  |  | 4,949 |  |  |  | 4,856 |  |
| Other current assets |  |  | 2,940 |  |  |  | 1,593 |  |
| Total current assets |  |  | 61,837 |  |  |  | 83,703 |  |
| Property and equipment, net |  |  | 3,006 |  |  |  | 3,322 |  |
| Financing receivables, net |  |  | 4,882 |  |  |  | 4,738 |  |
| Goodwill |  |  | 31,706 |  |  |  | 29,766 |  |
| Purchased intangible assets, net |  |  | 2,552 |  |  |  | 2,539 |  |
| Deferred tax assets |  |  | 3,219 |  |  |  | 4,239 |  |
| Other assets |  |  | 1,582 |  |  |  | 1,511 |  |
| TOTAL ASSETS |  | $ | 108,784 |  |  | $ | 129,818 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 5,238 |  |  | $ | 7,992 |  |
| Accounts payable |  |  | 1,904 |  |  |  | 1,385 |  |
| Income taxes payable |  |  | 1,004 |  |  |  | 98 |  |
| Accrued compensation |  |  | 2,986 |  |  |  | 2,895 |  |
| Deferred revenue |  |  | 11,490 |  |  |  | 10,821 |  |
| Other current liabilities |  |  | 4,413 |  |  |  | 4,392 |  |
| Total current liabilities |  |  | 27,035 |  |  |  | 27,583 |  |
| Long-term debt |  |  | 20,331 |  |  |  | 25,725 |  |
| Income taxes payable |  |  | 8,585 |  |  |  | 1,250 |  |
| Deferred revenue |  |  | 8,195 |  |  |  | 7,673 |  |
| Other long-term liabilities |  |  | 1,434 |  |  |  | 1,450 |  |
| Total liabilities |  |  | 65,580 |  |  |  | 63,681 |  |
| Total equity |  |  | 43,204 |  |  |  | 66,137 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 108,784 |  |  | $ | 129,818 |  |

[0001193125-18-249746:8k_2_02:104]
9

[0001193125-18-249746:8k_2_02:105]
CISCO SYSTEMS, INC.

[0001193125-18-249746:8k_2_02:106]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-18-249746:8k_2_02:107]
(In millions)

[0001193125-18-249746:8k_2_02:108]
(Unaudited)

[0001193125-18-249746:8k_2_02:109]
|  |  | Fiscal Year Ended |  |
|  |  | July 28,2018 |  |  | July 29,2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 110 |  |  | $ | 9,609 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 2,192 |  |  |  | 2,286 |  |
| Share-based compensation expense |  |  | 1,576 |  |  |  | 1,526 |  |
| Provision for receivables |  |  | (134 | ) |  |  | (8 | ) |
| Deferred income taxes |  |  | 900 |  |  |  | (124 | ) |
| Excess tax benefits from share-based compensation |  |  | — |  |  |  | (153 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (322 | ) |  |  | 154 |  |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (269 | ) |  |  | 756 |  |
| Inventories |  |  | (244 | ) |  |  | (394 | ) |
| Financing receivables |  |  | (219 | ) |  |  | (1,038 | ) |
| Other assets |  |  | 66 |  |  |  | 15 |  |
| Accounts payable |  |  | 504 |  |  |  | 311 |  |
| Income taxes, net |  |  | 8,118 |  |  |  | 60 |  |
| Accrued compensation |  |  | 100 |  |  |  | (110 | ) |
| Deferred revenue |  |  | 1,205 |  |  |  | 1,683 |  |
| Other liabilities |  |  | 83 |  |  |  | (697 | ) |
| Net cash provided by operating activities |  |  | 13,666 |  |  |  | 13,876 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (14,285 | ) |  |  | (42,702 | ) |
| Proceeds from sales of investments |  |  | 17,706 |  |  |  | 28,827 |  |
| Proceeds from maturities of investments |  |  | 15,769 |  |  |  | 12,143 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (3,006 | ) |  |  | (3,324 | ) |
| Proceeds from business divestitures |  |  | 27 |  |  |  | — |  |
| Purchases of investments in privately held companies |  |  | (267 | ) |  |  | (222 | ) |
| Return of investments in privately held companies |  |  | 168 |  |  |  | 203 |  |
| Acquisition of property and equipment |  |  | (834 | ) |  |  | (964 | ) |
| Proceeds from sales of property and equipment |  |  | 59 |  |  |  | 7 |  |
| Other |  |  | (13 | ) |  |  | 39 |  |
| Net cash provided by (used in) investing activities |  |  | 15,324 |  |  |  | (5,993 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 623 |  |  |  | 708 |  |
| Repurchases of common stock—repurchase program |  |  | (17,547 | ) |  |  | (3,685 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (703 | ) |  |  | (619 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | (2,502 | ) |  |  | 2,497 |  |
| Issuances of debt |  |  | 6,877 |  |  |  | 6,980 |  |
| Repayments of debt |  |  | (12,375 | ) |  |  | (4,151 | ) |
| Excess tax benefits from share-based compensation |  |  | — |  |  |  | 153 |  |
| Dividends paid |  |  | (5,968 | ) |  |  | (5,511 | ) |
| Other |  |  | (169 | ) |  |  | (178 | ) |
| Net cash used in financing activities |  |  | (31,764 | ) |  |  | (3,806 | ) |
| Net (decrease) increase in cash and cash equivalents |  |  | (2,774 | ) |  |  | 4,077 |  |
| Cash and cash equivalents, beginning of fiscal year |  |  | 11,708 |  |  |  | 7,631 |  |
| Cash and cash equivalents, end of fiscal year |  | $ | 8,934 |  |  | $ | 11,708 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 910 |  |  | $ | 897 |  |
| Cash paid for income taxes, net |  | $ | 3,911 |  |  | $ | 2,742 |  |

[0001193125-18-249746:8k_2_02:110]
10

[0001193125-18-249746:8k_2_02:111]
CISCO SYSTEMS, INC.

[0001193125-18-249746:8k_2_02:112]
DEFERRED REVENUE

[0001193125-18-249746:8k_2_02:113]
(In
millions)

[0001193125-18-249746:8k_2_02:114]
|  |  | July 28,2018 |  |  | April 28,2018 |  |  | July 29,2017 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 11,431 |  |  | $ | 10,960 |  |  | $ | 11,302 |  |
| Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred revenue related to recurring software and subscription offers |  |  | 6,120 |  |  |  | 5,635 |  |  |  | 4,971 |  |
| Other product deferred revenue |  |  | 2,134 |  |  |  | 2,358 |  |  |  | 2,221 |  |
| Total product deferred revenue |  |  | 8,254 |  |  |  | 7,993 |  |  |  | 7,192 |  |
| Total |  | $ | 19,685 |  |  | $ | 18,953 |  |  | $ | 18,494 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 11,490 |  |  | $ | 11,301 |  |  | $ | 10,821 |  |
| Noncurrent |  |  | 8,195 |  |  |  | 7,652 |  |  |  | 7,673 |  |
| Total |  | $ | 19,685 |  |  | $ | 18,953 |  |  | $ | 18,494 |  |

[0001193125-18-249746:8k_2_02:115]
CISCO SYSTEMS, INC.

[0001193125-18-249746:8k_2_02:116]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-18-249746:8k_2_02:117]
(In millions, except per-share amounts)

[0001193125-18-249746:8k_2_02:118]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 28, 2018 |  | $ | 0.33 |  |  | $ | 1,535 |  |  |  | 138 |  |  | $ | 43.58 |  |  | $ | 6,015 |  |  | $ | 7,550 |  |
| April 28, 2018 |  | $ | 0.33 |  |  | $ | 1,572 |  |  |  | 140 |  |  | $ | 42.83 |  |  | $ | 6,015 |  |  | $ | 7,587 |  |
| January 27, 2018 |  | $ | 0.29 |  |  | $ | 1,425 |  |  |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |  | $ | 5,436 |  |
| October 28, 2017 |  | $ | 0.29 |  |  | $ | 1,436 |  |  |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |  | $ | 3,056 |  |
| Fiscal 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 29, 2017 |  | $ | 0.29 |  |  | $ | 1,448 |  |  |  | 38 |  |  | $ | 31.61 |  |  | $ | 1,201 |  |  | $ | 2,649 |  |
| April 29, 2017 |  | $ | 0.29 |  |  | $ | 1,451 |  |  |  | 15 |  |  | $ | 33.71 |  |  | $ | 503 |  |  | $ | 1,954 |  |
| January 28, 2017 |  | $ | 0.26 |  |  | $ | 1,304 |  |  |  | 33 |  |  | $ | 30.33 |  |  | $ | 1,001 |  |  | $ | 2,305 |  |
| October 29, 2016 |  | $ | 0.26 |  |  | $ | 1,308 |  |  |  | 32 |  |  | $ | 31.12 |  |  | $ | 1,001 |  |  | $ | 2,309 |  |

[0001193125-18-249746:8k_2_02:119]
CISCO SYSTEMS, INC.

[0001193125-18-249746:8k_2_02:120]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-18-249746:8k_2_02:121]
GAAP TO NON-GAAP NET INCOME

[0001193125-18-249746:8k_2_02:122]
(In millions, except per-share amounts)

[0001193125-18-249746:8k_2_02:123]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 28,2018 |  |  | July 29,2017 |  |  | July 28,2018 |  |  | July 29,2017 |  |
| GAAP net income |  | $ | 3,803 |  |  | $ | 2,424 |  |  | $ | 110 |  |  | $ | 9,609 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 59 |  |  |  | 56 |  |  |  | 227 |  |  |  | 219 |  |
| Amortization of acquisition-related intangible assets |  |  | 134 |  |  |  | 140 |  |  |  | 578 |  |  |  | 483 |  |
| Supplier component remediation charge (adjustment), net |  |  | (36 | ) |  |  | (18 | ) |  |  | (77 | ) |  |  | (47 | ) |
| Acquisition-related/divestiture costs |  |  | 3 |  |  |  | — |  |  |  | 7 |  |  |  | 1 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | 122 |  |  |  | — |  |
| Total adjustments to GAAP cost of sales |  |  | 160 |  |  |  | 178 |  |  |  | 857 |  |  |  | 656 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 329 |  |  |  | 344 |  |  |  | 1,339 |  |  |  | 1,307 |  |
| Amortization of acquisition-related intangible assets |  |  | 33 |  |  |  | 58 |  |  |  | 221 |  |  |  | 259 |  |
| Acquisition-related/divestiture costs |  |  | 79 |  |  |  | 62 |  |  |  | 274 |  |  |  | 219 |  |
| Significant asset impairments and restructurings |  |  | 26 |  |  |  | 142 |  |  |  | 358 |  |  |  | 756 |  |
| Total adjustments to GAAP operating expenses |  |  | 467 |  |  |  | 606 |  |  |  | 2,192 |  |  |  | 2,541 |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 627 |  |  |  | 784 |  |  |  | 3,049 |  |  |  | 3,197 |  |
| Income tax effect of non-GAAP adjustments |  |  | (253 | ) |  |  | (235 | ) |  |  | (866 | ) |  |  | (847 | ) |
| Significant tax matters (1) |  |  | (851 | ) |  |  | 108 |  |  |  | 10,410 |  |  |  | 108 |  |
| Total adjustments to GAAP provision for income taxes |  |  | (1,104 | ) |  |  | (127 | ) |  |  | 9,544 |  |  |  | (739 | ) |
| Non-GAAP net income |  | $ | 3,326 |  |  | $ | 3,081 |  |  | $ | 12,703 |  |  | $ | 12,067 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.81 |  |  | $ | 0.48 |  |  | $ | 0.02 |  |  | $ | 1.90 |  |
| Non-GAAP |  | $ | 0.70 |  |  | $ | 0.61 |  |  | $ | 2.60 |  |  | $ | 2.39 |  |

[0001193125-18-249746:8k_2_02:124]
| (1) | In the fourth quarter of fiscal 2018, Cisco recorded adjustments to the provisional amounts related to the U.S. transition tax on accumulated earnings of foreign subsidiaries and re-measurement of net deferred tax assets. These adjustments include an $863 million benefit to the U.S. transition tax provisional amount related to the U.S. taxation of deemed foreign dividends after the date of enactment in the transition fiscal year. |

[0001193125-18-249746:8k_2_02:125]
|  | For fiscal year 2018, Cisco recorded charges relating to significant tax matters that were excluded from non-GAAP net income. $10.4 billion of these charges were provisional amounts related to the enactment of the Tax Cuts and Jobs Act comprised of $8.1 billion related to the U.S. transition tax, $1.2 billion related to foreign withholding tax and $1.1 billion related to the re-measurement of net deferred tax assets. The amounts are provisional based on Securities and Exchange Commission Staff Accounting Bulletin No. 118. |

[0001193125-18-249746:8k_2_02:126]
12

[0001193125-18-249746:8k_2_02:127]
CISCO SYSTEMS, INC.

[0001193125-18-249746:8k_2_02:128]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-18-249746:8k_2_02:129]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, AND NET INCOME

[0001193125-18-249746:8k_2_02:130]
(In millions, except percentages)

[0001193125-18-249746:8k_2_02:131]
|  |  | Three Months Ended |  |
|  |  | July 28, 2018 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,809 |  |  | $ | 2,113 |  |  | $ | 7,922 |  |  | $ | 4,576 |  |  |  | 1 | % |  | $ | 3,346 |  |  |  | 10 | % |  | $ | 3,803 |  |  |  | 57 | % |
| % of revenue |  |  | 60.2 | % |  |  | 66.0 | % |  |  | 61.7 | % |  |  | 35.6 | % |  |  |  |  |  |  | 26.1 | % |  |  |  |  |  |  | 29.6 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 24 |  |  |  | 35 |  |  |  | 59 |  |  |  | 329 |  |  |  |  |  |  |  | 388 |  |  |  |  |  |  |  | 388 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 134 |  |  |  | — |  |  |  | 134 |  |  |  | 33 |  |  |  |  |  |  |  | 167 |  |  |  |  |  |  |  | 167 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | (36 | ) |  |  | — |  |  |  | (36 | ) |  |  | — |  |  |  |  |  |  |  | (36 | ) |  |  |  |  |  |  | (36 | ) |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 2 |  |  |  | 1 |  |  |  | 3 |  |  |  | 79 |  |  |  |  |  |  |  | 82 |  |  |  |  |  |  |  | 82 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 26 |  |  |  |  |  |  |  | 26 |  |  |  |  |  |  |  | 26 |  |  |  |  |  |
| Income tax effect/significant tax matters (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (1,104 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 5,933 |  |  | $ | 2,149 |  |  | $ | 8,082 |  |  | $ | 4,109 |  |  |  | 5 | % |  | $ | 3,973 |  |  |  | 4 | % |  | $ | 3,326 |  |  |  | 8 | % |
| % of revenue |  |  | 61.5 | % |  |  | 67.1 | % |  |  | 62.9 | % |  |  | 32.0 | % |  |  |  |  |  |  | 30.9 | % |  |  |  |  |  |  | 25.9 | % |  |  |  |  |
| (1) Includes an $863 million benefit as related to the Tax Cuts and Jobs Act. |  |
|  |  | Three Months Ended |  |
|  |  | July 29, 2017 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,441 |  |  | $ | 2,105 |  |  | $ | 7,546 |  |  | $ | 4,512 |  |  |  | (3 | )% |  | $ | 3,034 |  |  |  | (8 | )% |  | $ | 2,424 |  |  |  | (14 | )% |
| % of revenue |  |  | 60.3 | % |  |  | 67.8 | % |  |  | 62.2 | % |  |  | 37.2 | % |  |  |  |  |  |  | 25.0 | % |  |  |  |  |  |  | 20.0 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 23 |  |  |  | 33 |  |  |  | 56 |  |  |  | 344 |  |  |  |  |  |  |  | 400 |  |  |  |  |  |  |  | 400 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 140 |  |  |  | — |  |  |  | 140 |  |  |  | 58 |  |  |  |  |  |  |  | 198 |  |  |  |  |  |  |  | 198 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | (18 | ) |  |  | — |  |  |  | (18 | ) |  |  | — |  |  |  |  |  |  |  | (18 | ) |  |  |  |  |  |  | (18 | ) |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 62 |  |  |  |  |  |  |  | 62 |  |  |  |  |  |  |  | 62 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 142 |  |  |  |  |  |  |  | 142 |  |  |  |  |  |  |  | 142 |  |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (127 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 5,586 |  |  | $ | 2,138 |  |  | $ | 7,724 |  |  | $ | 3,906 |  |  |  | (7 | )% |  | $ | 3,818 |  |  |  | (4 | )% |  | $ | 3,081 |  |  |  | (3 | )% |
| % of revenue |  |  | 61.9 | % |  |  | 68.8 | % |  |  | 63.7 | % |  |  | 32.2 | % |  |  |  |  |  |  | 31.5 | % |  |  |  |  |  |  | 25.4 | % |  |  |  |  |

[0001193125-18-249746:8k_2_02:132]
CISCO SYSTEMS, INC.

[0001193125-18-249746:8k_2_02:133]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-18-249746:8k_2_02:134]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, AND NET INCOME

[0001193125-18-249746:8k_2_02:135]
(In millions, except percentages)

[0001193125-18-249746:8k_2_02:136]
|  |  | Fiscal Year Ended |  |
|  |  | July 28, 2018 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 22,282 |  |  | $ | 8,324 |  |  | $ | 30,606 |  |  | $ | 18,297 |  |  |  | — | % |  | $ | 12,309 |  |  |  | 3 | % |  | $ | 110 |  |  |  | (99 | )% |
| % of revenue |  |  | 60.7 | % |  |  | 66.0 | % |  |  | 62.0 | % |  |  | 37.1 | % |  |  |  |  |  |  | 25.0 | % |  |  |  |  |  |  | 0.2 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 94 |  |  |  | 133 |  |  |  | 227 |  |  |  | 1,339 |  |  |  |  |  |  |  | 1,566 |  |  |  |  |  |  |  | 1,566 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 578 |  |  |  | — |  |  |  | 578 |  |  |  | 221 |  |  |  |  |  |  |  | 799 |  |  |  |  |  |  |  | 799 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | (77 | ) |  |  | — |  |  |  | (77 | ) |  |  | — |  |  |  |  |  |  |  | (77 | ) |  |  |  |  |  |  | (77 | ) |  |  |  |  |
| Legal and indemnification settlements |  |  | 122 |  |  |  | — |  |  |  | 122 |  |  |  | — |  |  |  |  |  |  |  | 122 |  |  |  |  |  |  |  | 122 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 3 |  |  |  | 4 |  |  |  | 7 |  |  |  | 274 |  |  |  |  |  |  |  | 281 |  |  |  |  |  |  |  | 281 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 358 |  |  |  |  |  |  |  | 358 |  |  |  |  |  |  |  | 358 |  |  |  |  |  |
| Income tax effect/significant tax matters (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 9,544 | (1) |  |  |  |  |
| Non-GAAP amount |  | $ | 23,002 |  |  | $ | 8,461 |  |  | $ | 31,463 |  |  | $ | 16,105 |  |  |  | 3 | % |  | $ | 15,358 |  |  |  | 1 | % |  | $ | 12,703 |  |  |  | 5 | % |
| % of revenue |  |  | 62.7 | % |  |  | 67.0 | % |  |  | 63.8 | % |  |  | 32.6 | % |  |  |  |  |  |  | 31.1 | % |  |  |  |  |  |  | 25.8 | % |  |  |  |  |
| (1) Includes a $10.4 billion charge as related to the enactment of the Tax Cuts and Jobs Act. |  |
|  |  | Fiscal Year Ended |  |
|  |  | July 29, 2017 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 22,006 |  |  | $ | 8,218 |  |  | $ | 30,224 |  |  | $ | 18,251 |  |  |  | — | % |  | $ | 11,973 |  |  |  | (5 | )% |  | $ | 9,609 |  |  |  | (11 | )% |
| % of revenue |  |  | 61.6 | % |  |  | 66.8 | % |  |  | 63.0 | % |  |  | 38.0 | % |  |  |  |  |  |  | 24.9 | % |  |  |  |  |  |  | 20.0 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 85 |  |  |  | 134 |  |  |  | 219 |  |  |  | 1,307 |  |  |  |  |  |  |  | 1,526 |  |  |  |  |  |  |  | 1,526 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 483 |  |  |  | — |  |  |  | 483 |  |  |  | 259 |  |  |  |  |  |  |  | 742 |  |  |  |  |  |  |  | 742 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | (47 | ) |  |  | — |  |  |  | (47 | ) |  |  | — |  |  |  |  |  |  |  | (47 | ) |  |  |  |  |  |  | (47 | ) |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 219 |  |  |  |  |  |  |  | 220 |  |  |  |  |  |  |  | 220 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 756 |  |  |  |  |  |  |  | 756 |  |  |  |  |  |  |  | 756 |  |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (739 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 22,527 |  |  | $ | 8,353 |  |  | $ | 30,880 |  |  | $ | 15,710 |  |  |  | (4 | )% |  | $ | 15,170 |  |  |  | — | % |  | $ | 12,067 |  |  |  | — | % |
| % of revenue |  |  | 63.1 | % |  |  | 67.9 | % |  |  | 64.3 | % |  |  | 32.7 | % |  |  |  |  |  |  | 31.6 | % |  |  |  |  |  |  | 25.1 | % |  |  |  |  |

[0001193125-18-249746:8k_2_02:137]
14

[0001193125-18-249746:8k_2_02:138]
CISCO SYSTEMS, INC.

[0001193125-18-249746:8k_2_02:139]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-18-249746:8k_2_02:140]
EFFECTIVE TAX RATE

[0001193125-18-249746:8k_2_02:141]
(In
percentages)

[0001193125-18-249746:8k_2_02:142]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 28, 2018 |  |  | July 29, 2017 |  |  | July 28, 2018 |  |  | July 29, 2017 |  |
| GAAP effective tax rate (1) |  |  | (5.9)% |  |  |  | 23.8% |  |  |  | 99.2% |  |  |  | 21.8% |  |
| Total adjustments to GAAP provision for income taxes |  |  | 27.1% |  |  |  | (1.5)% |  |  |  | (78.2)% |  |  |  | 0.3% |  |
| Non-GAAP effective tax rate |  |  | 21.2% |  |  |  | 22.3% |  |  |  | 21.0% |  |  |  | 22.1% |  |

[0001193125-18-249746:8k_2_02:143]
| (1) | The three months ended July 28, 2018 includes an $863 million benefit as related to the Tax Cuts and Jobs Act. The fiscal year ended July 28, 2018 includes a $10.4 billion charge as related to the enactment of the Tax Cuts and Jobs Act. |

[0001193125-18-249746:8k_2_02:144]
GAAP TO NON-GAAP GUIDANCE FOR Q1 FY 2019

[0001193125-18-249746:8k_2_02:145]
| Q1 FY 2019 |  | Gross MarginRate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (4) |
| GAAP |  | 61.5% - 62.5% |  | 27.5% - 28.5% |  | 9% |  | $0.69 - $0.74 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.0% |  |  |  | $0.04 - $0.05 |
| Amortization of purchased intangible assets and other acquisition-related/divestiture costs |  | 1.0% |  | 2.0% |  |  |  | $0.04 - $0.05 |
| Restructuring and other charges (1) |  | — |  | 0.5% |  |  |  | $0.01 |
| Legal settlements (2) |  | — |  | (3.0)% |  |  |  | ($0.07) |
| Significant tax matters (3) |  |  |  |  |  |  |  | ($0.03) - ($0.04) |
| Income tax effect of non-GAAP adjustments |  |  |  |  |  | 10% |  |  |
| Non-GAAP |  | 63% - 64% |  | 30% - 31% |  | 19% |  | $0.70 - $0.72 |

[0001193125-18-249746:8k_2_02:146]
| (1) | In the third quarter of fiscal 2018, we initiated a restructuring plan in order to realign the organization and enable further investment in key priority areas. The total pretax cash charges to the GAAP financial results is estimated to be approximately $300 million consisting of severance and other one-time benefits, and other associated costs. During fiscal 2018, we have recognized pretax charges of approximately $108 million to our GAAP financial results in relation to this restructuring plan. We expect to recognize up to $70 million of these charges in the first quarter of fiscal 2019 with the remaining amount to be recognized during the rest of the fiscal year. |

[0001193125-18-249746:8k_2_02:147]
| (2) | In the first quarter of fiscal 2019, we entered into a binding term sheet with Arista Networks, settling most of the outstanding litigation between the companies, which will result in a payment to Cisco of $400 million. We will recognize this benefit in our GAAP financial results in the first quarter of fiscal 2019. The remaining litigation will not have a financial impact on Cisco. |

[0001193125-18-249746:8k_2_02:148]
| (3) | We will recognize net indirect benefits to our GAAP provision for income taxes related to intercompany adjustments upon adoption of ASC 606. |

[0001193125-18-249746:8k_2_02:149]
| (4) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-18-249746:8k_2_02:150]
The guidance includes our SPVSS business that we recently agreed to sell and excludes the Duo Security acquisition since both transactions have not closed. We
expect the SPVSS transaction to close in the first half of fiscal 2019 subject to customary closing conditions and regulatory approvals.

[0001193125-18-249746:8k_2_02:151]
At the beginning
of fiscal 2019, we adopted the Financial Accounting Standards Board new standard on revenue recognition (ASC 606) using the modified retrospective method. The revenue guidance in the preceding table includes the impact of ASC 606 which we estimate
to be a benefit of about 1% year over year.

[0001193125-18-249746:8k_2_02:152]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures,
asset impairments, restructurings and significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-18-249746:8k_2_02:153]
15

[0001193125-18-249746:8k_2_02:154]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-18-249746:8k_2_02:155]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax rates, and
non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a
non-GAAP basis.

[0001193125-18-249746:8k_2_02:156]
These non-GAAP measures are not in accordance with, or an
alternative for, measures prepared in accordance with generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect
all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP
measures.

[0001193125-18-249746:8k_2_02:157]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the
corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-18-249746:8k_2_02:158]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other contingencies, significant gains and losses on investments,
the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the
financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be other items
that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP
financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-18-249746:8k_2_02:159]
16

[0001193125-18-249746:8k_2_02:160]
About Cisco

[0001193125-18-249746:8k_2_02:161]
Cisco (NASDAQ: CSCO) is the worldwide technology leader that has been making the Internet work since 1984. Our people, products and partners help society
securely connect and seize tomorrow’s digital opportunity today. Discover more at thenetwork.cisco.com and follow us on Twitter at @Cisco.

[0001193125-18-249746:8k_2_02:162]
Copyright
© 2018 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To
view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco
and any other company. This document is Cisco Public Information.
