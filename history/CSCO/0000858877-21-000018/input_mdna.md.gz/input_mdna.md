# CSCO MD&A — 0000858877-21-000018


## mdna

[0000858877-21-000018:mdna:1]
[same as prior period, unchanged from 0000858877-21-000008:mdna:1]

[0000858877-21-000018:mdna:2]
[same as prior period, unchanged from 0000858877-21-000008:mdna:2]

[0000858877-21-000018:mdna:3]
[same as prior period, unchanged from 0000858877-21-000008:mdna:3]

[0000858877-21-000018:mdna:4]
Cisco designs and sells a broad range of technologies that power the Internet. We are integrating our platforms across networking, security, collaboration, applications and the cloud. These platforms are designed to help our customers manage more users, devices and things connecting to their networks. This will enable us to provide customers with a highly secure, intelligent platform for their digital business.

[0000858877-21-000018:mdna:5]
[same as prior period, unchanged from 0000858877-21-000008:mdna:5]

[0000858877-21-000018:mdna:6]
|  | Three Months Ended |  |
|  | October 30,2021 |  | October 24,2020 |  | % Variance |  |
| Revenue | $ | 12,900 |  |  | $ | 11,929 |  |  | 8 | % |  |
| Gross margin percentage | 62.4 | % |  | 63.6 | % |  | (1.2) |  | pts |
| Research and development | $ | 1,714 |  |  | $ | 1,612 |  |  | 6 | % |  |
| Sales and marketing | $ | 2,261 |  |  | $ | 2,217 |  |  | 2 | % |  |
| General and administrative | $ | 551 |  |  | $ | 544 |  |  | 1 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,526 |  |  | $ | 4,373 |  |  | 3 | % |  |
| Total as a percentage of revenue | 35.1 | % |  | 36.7 | % |  | (1.6) |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 84 |  |  | $ | 36 |  |  | 133 | % |  |
| Restructuring and other charges included in operating expenses | $ | 5 |  |  | $ | 602 |  |  | (99) | % |  |
| Operating income as a percentage of revenue | 26.7 | % |  | 21.5 | % |  | 5.2 |  | pts |
| Interest and other income (loss), net | $ | 219 |  |  | $ | 111 |  |  | 97 | % |  |
| Income tax percentage | 18.5 | % |  | 18.9 | % |  | (0.4) |  | pts |
| Net income | $ | 2,980 |  |  | $ | 2,174 |  |  | 37 | % |  |
| Net income as a percentage of revenue | 23.1 | % |  | 18.2 | % |  | 4.9 |  | pts |
| Earnings per share—diluted | $ | 0.70 |  |  | $ | 0.51 |  |  | 37 | % |  |

[0000858877-21-000018:mdna:7]
[same as prior period, unchanged from 0000858877-21-000008:mdna:7]

[0000858877-21-000018:mdna:8]
[same as prior period, unchanged from 0000858877-21-000008:mdna:8]

[0000858877-21-000018:mdna:9]
Three Months Ended October 30, 2021 Compared with Three Months Ended October 24, 2020

[0000858877-21-000018:mdna:10]
In the first quarter of fiscal 2022, we had strong performance delivering solid revenue growth and strong profitability. As customers are defining their hybrid work strategy, we remain focused on executing and increasing our investments in our technologies to assist in that transition. Total revenue increased by 8% compared with the first quarter of fiscal 2021. Our product revenue reflected growth in Secure, Agile Networks; Internet for the Future; End-to-End Security; and Optimized Application Experiences; partially offset by declines in Hybrid Work. While our revenue growth was solid, it was negatively impacted by supply constraints seen industry wide. We continue to manage these significant supply constraints due to component shortages and are taking multiple steps in order to mitigate the supply shortages and deliver products to our customers. We expect these supply constraints to continue into the second half of fiscal 2022. We continued to make progress in the transition of our business model delivering increased software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-21-000018:mdna:11]
Within total revenue, product revenue increased by 11% and service revenue increased by 1%. In the first quarter of fiscal 2022, total software revenue was $3.7 billion across all product areas and service, an increase of 1%. Within total software revenue, subscription revenue increased 4%. Total gross margin decreased by 1.2 percentage points. Product gross margin decreased by 1.2 percentage points, largely driven by increased costs related to supply constraints. The effect of pricing erosion was moderate, partially offset by favorable product mix. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 1.6 percentage points. Operating income as a percentage of revenue increased by 5.2 percentage points. Diluted earnings per share increased 37%, driven by a 37% increase in net income.

[0000858877-21-000018:mdna:12]
In terms of our geographic segments, revenue from the Americas increased $363 million, EMEA revenue increased by $339 million and APJC revenue increased by $269 million. The “BRICM” countries experienced product revenue growth of 21% in the aggregate, driven by an increase in product revenue across each of the BRICM countries with the exception of Russia.

[0000858877-21-000018:mdna:13]
From a customer market standpoint, we experienced product revenue growth in all customer markets. We continued to see improvement in business momentum in our customer markets.

[0000858877-21-000018:mdna:14]
From a product category perspective, the product revenue increase of 11% was driven by growth in revenue in Secure, Agile Networks of 10%; Internet for the Future of 46%; End-to-End Security of 4%; and Optimized Application Experiences of 18%; partially offset by a product revenue decline in Hybrid Work of 7%.

[0000858877-21-000018:mdna:15]
[same as prior period, unchanged from 0000858877-21-000008:mdna:15]

[0000858877-21-000018:mdna:16]
[same as prior period, unchanged from 0000858877-21-000008:mdna:16]

[0000858877-21-000018:mdna:17]
[same as prior period, unchanged from 0000858877-21-000008:mdna:19]

[0000858877-21-000018:mdna:18]
During the COVID-19 pandemic, our priority has been supporting our employees, customers, partners and communities, while positioning Cisco for the future. The pandemic has driven organizations across the globe to digitize their operations and support remote workforces at a faster speed and greater scale than ever before. We remain focused on providing the technology and solutions our customers need to accelerate their digital organizations. The actions we have taken and are taking include:

[0000858877-21-000018:mdna:19]
[same as prior period, unchanged from 0000858877-21-000008:mdna:21]

[0000858877-21-000018:mdna:20]
•Most of our global workforce is working from home.

[0000858877-21-000018:mdna:21]
[same as prior period, unchanged from 0000858877-21-000008:mdna:23]

[0000858877-21-000018:mdna:22]
[same as prior period, unchanged from 0000858877-21-000008:mdna:24]

[0000858877-21-000018:mdna:23]
[same as prior period, unchanged from 0000858877-21-000008:mdna:25]

[0000858877-21-000018:mdna:24]
[same as prior period, unchanged from 0000858877-21-000008:mdna:26]

[0000858877-21-000018:mdna:25]
[same as prior period, unchanged from 0000858877-21-000008:mdna:27]

[0000858877-21-000018:mdna:26]
[same as prior period, unchanged from 0000858877-21-000008:mdna:28]

[0000858877-21-000018:mdna:27]
[same as prior period, unchanged from 0000858877-21-000008:mdna:29]

[0000858877-21-000018:mdna:28]
[same as prior period, unchanged from 0000858877-21-000008:mdna:30]

[0000858877-21-000018:mdna:29]
We are moving towards a hybrid work model, giving our employees the flexibility to work offsite or at onsite Cisco locations.

[0000858877-21-000018:mdna:30]
42

[0000858877-21-000018:mdna:31]
[same as prior period, unchanged from 0000858877-21-000008:mdna:32]

[0000858877-21-000018:mdna:32]
[same as prior period, unchanged from 0000858877-21-000008:mdna:33]

[0000858877-21-000018:mdna:33]
[same as prior period, unchanged from 0000858877-21-000008:mdna:34]

[0000858877-21-000018:mdna:34]
As our customers add billions of new connections to their enterprises, and as more applications move to a multicloud environment, the network becomes even more critical. Our customers are navigating change at an unprecedented pace and our mission is to shape the future of the Internet by inspiring new possibilities for them by helping transform their infrastructure, expand applications and analytics, address their security needs, and empower their teams. We believe that our customers are looking for outcomes that are data-driven and provide meaningful business value through automation, security, and analytics across private, hybrid, and multicloud environments. Our strategy is to help our customers connect, secure, and automate in order to accelerate their digital agility in a cloud-first world.

[0000858877-21-000018:mdna:35]
For additional discussion of our strategy and priorities, see Item 1. Business in our Annual Report on Form 10-K for the year ended July 31, 2021.

[0000858877-21-000018:mdna:36]
[same as prior period, unchanged from 0000858877-21-000008:mdna:37]

[0000858877-21-000018:mdna:37]
The following is a summary of our other key financial measures for the first quarter of fiscal 2022 (in millions):

[0000858877-21-000018:mdna:38]
|  |  | October 30,2021 |  | July 31,2021 |
| Cash and cash equivalents and investments |  | $ | 23,346 |  |  | $ | 24,518 |  |
| Remaining performance obligations |  | $ | 30,135 |  |  | $ | 30,893 |  |
| Inventories |  | $ | 1,832 |  |  | $ | 1,559 |  |

[0000858877-21-000018:mdna:39]
|  |  | Three Months Ended |
|  |  | October 30,2021 |  | October 24,2020 |
| Cash provided by operating activities |  | $ | 3,427 |  |  | $ | 4,096 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 256 |  |  | $ | 800 |  |
| Dividends paid |  | $ | 1,561 |  |  | $ | 1,520 |  |

[0000858877-21-000018:mdna:40]
[same as prior period, unchanged from 0000858877-21-000008:mdna:42]

[0000858877-21-000018:mdna:41]
[same as prior period, unchanged from 0000858877-21-000008:mdna:43]

[0000858877-21-000018:mdna:42]
[same as prior period, unchanged from 0000858877-21-000008:mdna:44]

[0000858877-21-000018:mdna:43]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements in our Annual Report on Form 10-K for the year ended July 31, 2021, as updated as applicable in Note 2 to the Consolidated Financial Statements herein, describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-21-000018:mdna:44]
The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The COVID-19 pandemic did not have a material impact on our significant judgments, assumptions and estimates that are reflected in our results for the first quarter of fiscal 2022. These estimates are listed in our Annual Report on Form 10-K for the year ending July 31, 2021, and include: goodwill and identified purchased intangible assets and income taxes, among other items. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-21-000018:mdna:45]
[same as prior period, unchanged from 0000858877-21-000008:mdna:47]

[0000858877-21-000018:mdna:46]
[same as prior period, unchanged from 0000858877-21-000008:mdna:48]

[0000858877-21-000018:mdna:47]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-21-000018:mdna:48]
[same as prior period, unchanged from 0000858877-21-000008:mdna:50]

[0000858877-21-000018:mdna:49]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable. If actual credits received by distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-21-000018:mdna:50]
[same as prior period, unchanged from 0000858877-21-000008:mdna:52]

[0000858877-21-000018:mdna:51]
44

[0000858877-21-000018:mdna:52]
[same as prior period, unchanged from 0000858877-21-000008:mdna:53]

[0000858877-21-000018:mdna:53]
[same as prior period, unchanged from 0000858877-21-000008:mdna:54]

[0000858877-21-000018:mdna:54]
Inventory Valuation and Liability for Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-21-000018:mdna:55]
Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and market, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-21-000018:mdna:56]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.

[0000858877-21-000018:mdna:57]
Our provision for inventory was $22 million and $29 million for the first quarter of fiscal 2022 and 2021, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $47 million and $32 million for the first quarter of fiscal 2022 and 2021, respectively. If there were to be a sudden and significant decrease in demand for our products, if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, or if supply constraints were to continue, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. We continue to manage through significant supply constraints seen industry wide due to component shortages caused, in part, by the COVID-19 pandemic. For further discussion around the Supply Constraints Impacts and Risks, see Result of Operations—Product Gross Margin and Liquidity and Capital Resources—Inventory Supply Chain.

[0000858877-21-000018:mdna:58]
Loss Contingencies

[0000858877-21-000018:mdna:59]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-21-000018:mdna:60]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-21-000018:mdna:61]
[same as prior period, unchanged from 0000858877-21-000008:mdna:58]

[0000858877-21-000018:mdna:62]
[same as prior period, unchanged from 0000858877-21-000008:mdna:59]

[0000858877-21-000018:mdna:63]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first quarters of fiscal 2022 and 2021.

[0000858877-21-000018:mdna:64]
[same as prior period, unchanged from 0000858877-21-000008:mdna:61]

[0000858877-21-000018:mdna:65]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured

[0000858877-21-000018:mdna:66]
[same as prior period, unchanged from 0000858877-21-000008:mdna:68]

[0000858877-21-000018:mdna:67]
[same as prior period, unchanged from 0000858877-21-000008:mdna:69]

[0000858877-21-000018:mdna:68]
by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts.

[0000858877-21-000018:mdna:69]
[same as prior period, unchanged from 0000858877-21-000008:mdna:63]

[0000858877-21-000018:mdna:70]
[same as prior period, unchanged from 0000858877-21-000008:mdna:64]

[0000858877-21-000018:mdna:71]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 18.5% and 18.9% in the first quarter of fiscal 2022 and 2021, respectively.

[0000858877-21-000018:mdna:72]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.

[0000858877-21-000018:mdna:73]
[same as prior period, unchanged from 0000858877-21-000008:mdna:71]

[0000858877-21-000018:mdna:74]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to foreign-derived intangible income deduction, global intangible low-tax income and base erosion and anti-abuse tax laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 38 countries, including the United States, has made changes and is contemplating additional changes to numerous long-standing tax principles. There can be no assurance that these changes and any contemplated changes if finalized, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries was subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-21-000018:mdna:75]
[same as prior period, unchanged from 0000858877-21-000008:mdna:41]

[0000858877-21-000018:mdna:76]
[same as prior period, unchanged from 0000858877-21-000008:mdna:74]

[0000858877-21-000018:mdna:77]
[same as prior period, unchanged from 0000858877-21-000008:mdna:75]

[0000858877-21-000018:mdna:78]
[same as prior period, unchanged from 0000858877-21-000008:mdna:76]

[0000858877-21-000018:mdna:79]
[same as prior period, unchanged from 0000858877-21-000008:mdna:77]

[0000858877-21-000018:mdna:80]
[same as prior period, unchanged from 0000858877-21-000008:mdna:78]

[0000858877-21-000018:mdna:81]
|  |  | Three Months Ended |
|  |  | October 30,2021 |  | October 24,2020 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,529 |  |  | $ | 8,587 |  |  | $ | 942 |  |  | 11 | % |
| Percentage of revenue |  | 73.9 | % |  | 72.0 | % |  |  |  |  |
| Service |  | 3,371 |  |  | 3,342 |  |  | 29 |  |  | 1 | % |
| Percentage of revenue |  | 26.1 | % |  | 28.0 | % |  |  |  |  |
| Total |  | $ | 12,900 |  |  | $ | 11,929 |  |  | $ | 971 |  |  | 8 | % |

[0000858877-21-000018:mdna:82]
[same as prior period, unchanged from 0000858877-21-000008:mdna:80]

[0000858877-21-000018:mdna:83]
|  |  | Three Months Ended |
|  |  | October 30,2021 |  | October 24,2020 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,561 |  |  | $ | 7,198 |  |  | $ | 363 |  |  | 5 | % |
| Percentage of revenue |  | 58.6 | % |  | 60.4 | % |  |  |  |  |
| EMEA |  | 3,303 |  |  | 2,964 |  |  | 339 |  |  | 11 | % |
| Percentage of revenue |  | 25.6 | % |  | 24.8 | % |  |  |  |  |
| APJC |  | 2,036 |  |  | 1,767 |  |  | 269 |  |  | 15 | % |
| Percentage of revenue |  | 15.8 | % |  | 14.8 | % |  |  |  |  |
| Total |  | $ | 12,900 |  |  | $ | 11,929 |  |  | $ | 971 |  |  | 8 | % |

[0000858877-21-000018:mdna:84]
[same as prior period, unchanged from 0000858877-21-000008:mdna:82]

[0000858877-21-000018:mdna:85]
Three Months Ended October 30, 2021 Compared with Three Months Ended October 24, 2020

[0000858877-21-000018:mdna:86]
Total revenue increased by 8%. Product revenue increased by 11% and service revenue increased by 1%. Our total revenue reflected growth across each of our geographic segments. Product revenue for the emerging countries of BRICM, in the aggregate, experienced product revenue growth of 21%, with growth in each of these countries with the exception of Russia.

[0000858877-21-000018:mdna:87]
[same as prior period, unchanged from 0000858877-21-000008:mdna:85]

[0000858877-21-000018:mdna:88]
[same as prior period, unchanged from 0000858877-21-000008:mdna:88]

[0000858877-21-000018:mdna:89]
[same as prior period, unchanged from 0000858877-21-000008:mdna:89]

[0000858877-21-000018:mdna:90]
[same as prior period, unchanged from 0000858877-21-000008:mdna:90]

[0000858877-21-000018:mdna:91]
[same as prior period, unchanged from 0000858877-21-000008:mdna:91]

[0000858877-21-000018:mdna:92]
|  |  | Three Months Ended |
|  |  | October 30,2021 |  | October 24,2020 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,522 |  |  | $ | 5,129 |  |  | $ | 393 |  |  | 8 | % |
| Percentage of product revenue |  | 57.9 | % |  | 59.8 | % |  |  |  |  |
| EMEA |  | 2,513 |  |  | 2,210 |  |  | 303 |  |  | 14 | % |
| Percentage of product revenue |  | 26.4 | % |  | 25.7 | % |  |  |  |  |
| APJC |  | 1,495 |  |  | 1,248 |  |  | 247 |  |  | 20 | % |
| Percentage of product revenue |  | 15.7 | % |  | 14.5 | % |  |  |  |  |
| Total |  | $ | 9,529 |  |  | $ | 8,587 |  |  | $ | 942 |  |  | 11 | % |

[0000858877-21-000018:mdna:93]
[same as prior period, unchanged from 0000858877-21-000008:mdna:93]

[0000858877-21-000018:mdna:94]
Three Months Ended October 30, 2021 Compared with Three Months Ended October 24, 2020

[0000858877-21-000018:mdna:95]
[same as prior period, unchanged from 0000858877-21-000008:mdna:94]

[0000858877-21-000018:mdna:96]
Product revenue in the Americas segment increased by 8%, with growth in the service provider, commercial and enterprise markets, partially offset by a slight decline in the public sector market. From a country perspective, product revenue increased in the United States, Canada, Mexico and Brazil by 8%, 22%, 11% and 29%, respectively.

[0000858877-21-000018:mdna:97]
[same as prior period, unchanged from 0000858877-21-000008:mdna:99]

[0000858877-21-000018:mdna:98]
Product revenue in the EMEA segment increased by 14%, with growth in all customer markets. Product revenue from emerging countries within EMEA increased by 18% and product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, increased by 13%. From a country perspective, product revenue increased by 2% in Germany, 15% in the United Kingdom and 7% in France.

[0000858877-21-000018:mdna:99]
[same as prior period, unchanged from 0000858877-21-000008:mdna:104]

[0000858877-21-000018:mdna:100]
Product revenue in the APJC segment increased by 20%, driven by growth in all customer markets. From a country perspective, product revenue increased in Australia, China and India by 35%, 20% and 44%, respectively, partially offset by a decline of 10% in Japan.

[0000858877-21-000018:mdna:101]
[same as prior period, unchanged from 0000858877-21-000008:mdna:107]

[0000858877-21-000018:mdna:102]
[same as prior period, unchanged from 0000858877-21-000008:mdna:108]

[0000858877-21-000018:mdna:103]
[same as prior period, unchanged from 0000858877-21-000008:mdna:111]

[0000858877-21-000018:mdna:104]
In addition to the primary view on a geographic basis, we also prepare financial information related to product categories and customer markets for various purposes. Effective in the first quarter of fiscal 2022, we began reporting our product revenue in the following categories: Secure, Agile Networks; Hybrid Work; End-to-End Security; Internet for the Future; Optimized Application Experiences; and Other Products. This change will better align our product categories with our strategic priorities.

[0000858877-21-000018:mdna:105]
[same as prior period, unchanged from 0000858877-21-000008:mdna:113]

[0000858877-21-000018:mdna:106]
|  |  | Three Months Ended |
|  |  | October 30,2021 |  | October 24,2020 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Secure, Agile Networks |  | $ | 5,967 |  |  | $ | 5,434 |  |  | $ | 533 |  |  | 10 | % |
| Hybrid Work |  | 1,109 |  |  | 1,193 |  |  | (84) |  |  | (7) | % |
| End-to-End Security |  | 895 |  |  | 861 |  |  | 34 |  |  | 4 | % |
| Internet for the Future |  | 1,374 |  |  | 942 |  |  | 432 |  |  | 46 | % |
| Optimized Application Experiences |  | 181 |  |  | 153 |  |  | 28 |  |  | 18 | % |
| Other Products |  | 3 |  |  | 3 |  |  | — |  |  | 9 | % |
| Total |  | $ | 9,529 |  |  | $ | 8,587 |  |  | $ | 942 |  |  | 11 | % |

[0000858877-21-000018:mdna:107]
[same as prior period, unchanged from 0000858877-21-000008:mdna:136]

[0000858877-21-000018:mdna:108]
Three Months Ended October 30, 2021 Compared with Three Months Ended October 24, 2020

[0000858877-21-000018:mdna:109]
Secure, Agile Networks

[0000858877-21-000018:mdna:110]
The Secure, Agile Networks product category represents our core networking offerings related to switching, enterprise routing, wireless, and compute. Secure, Agile Networks revenue increased by 10%, or $533 million, with growth across the portfolio with the exception of compute. Switching revenue grew in both campus switching and data center switching. This was primarily driven by strong growth in our Catalyst 9000 series and Meraki switching offerings. We experienced an increase in sales of our enterprise routing products driven by growth in our Edge and SD-WAN offerings. Wireless had strong double-digit growth driven by our WiFi-6 products and Meraki offerings. Revenue from compute declined primarily driven by our Hyper Converged offerings.

[0000858877-21-000018:mdna:111]
Hybrid Work

[0000858877-21-000018:mdna:112]
The Hybrid Work product category includes our collaboration and contact center offerings. Revenue in our Hybrid Work product category decreased by 7%, or $84 million, driven by declines in our Calling, Meetings and Contact Center offerings, partially offset by growth in our Communication Platform as a Service (CPaaS) offerings and Collaboration Devices.

[0000858877-21-000018:mdna:113]
End-to-End Security

[0000858877-21-000018:mdna:114]
Revenue in our End-to-End Security product category increased 4%, or $34 million primarily driven by our cloud-based solutions partially offset by declines in our perpetual and security hardware offerings. Our zero trust portfolio reflected strong double-digit growth driven by continued momentum with our Duo offerings. We also experienced growth in our Unified Threat Management offerings.

[0000858877-21-000018:mdna:115]
Internet for the Future

[0000858877-21-000018:mdna:116]
The Internet for the Future product category includes our routed optical networking, public 5G, silicon and optics offerings. Revenue in our Internet for the Future product category increased by 46%, or $432 million, driven by the growth in the webscale provider market. This was primarily driven by strong growth in our Cisco 8000 portfolio, NCS 5500 series and ASR 9000 series offerings. We also saw a benefit from our acquisition of Acacia.

[0000858877-21-000018:mdna:117]
Optimized Application Experiences

[0000858877-21-000018:mdna:118]
The Optimized Application Experiences product category includes our full stack observability and cloud-native platforms offerings. Revenue in our Optimized Application Experiences product category increased 18%, or $28 million, driven by growth in ThousandEyes and Intersight offerings.

[0000858877-21-000018:mdna:119]
[same as prior period, unchanged from 0000858877-21-000008:mdna:73]

[0000858877-21-000018:mdna:120]
[same as prior period, unchanged from 0000858877-21-000008:mdna:126]

[0000858877-21-000018:mdna:121]
[same as prior period, unchanged from 0000858877-21-000008:mdna:127]

[0000858877-21-000018:mdna:122]
[same as prior period, unchanged from 0000858877-21-000008:mdna:133]

[0000858877-21-000018:mdna:123]
[same as prior period, unchanged from 0000858877-21-000008:mdna:134]

[0000858877-21-000018:mdna:124]
|  |  | Three Months Ended |
|  |  | October 30,2021 |  | October 24,2020 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,039 |  |  | $ | 2,070 |  |  | $ | (31) |  |  | (1) | % |
| Percentage of service revenue |  | 60.5 | % |  | 61.9 | % |  |  |  |  |
| EMEA |  | 790 |  |  | 754 |  |  | 36 |  |  | 5 | % |
| Percentage of service revenue |  | 23.4 | % |  | 22.6 | % |  |  |  |  |
| APJC |  | 541 |  |  | 519 |  |  | 22 |  |  | 4 | % |
| Percentage of service revenue |  | 16.1 | % |  | 15.5 | % |  |  |  |  |
| Total |  | $ | 3,371 |  |  | $ | 3,342 |  |  | $ | 29 |  |  | 1 | % |

[0000858877-21-000018:mdna:125]
[same as prior period, unchanged from 0000858877-21-000008:mdna:165]

[0000858877-21-000018:mdna:126]
Service revenue increased 1% in the first quarter of fiscal 2022 driven by revenue growth in our maintenance business and solution support offerings. Service revenue increased in the EMEA and APJC segments, partially offset by lower revenue in the Americas segment.

[0000858877-21-000018:mdna:127]
[same as prior period, unchanged from 0000858877-21-000008:mdna:140]

[0000858877-21-000018:mdna:128]
[same as prior period, unchanged from 0000858877-21-000008:mdna:141]

[0000858877-21-000018:mdna:129]
|  |  | Three Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |
|  |  | October 30,2021 |  | October 24,2020 |  | October 30,2021 |  | October 24,2020 |
| Gross margin: |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,856 |  |  | $ | 5,381 |  |  | 61.5 | % |  | 62.7 | % |
| Service |  | 2,197 |  |  | 2,200 |  |  | 65.2 | % |  | 65.8 | % |
| Total |  | $ | 8,053 |  |  | $ | 7,581 |  |  | 62.4 | % |  | 63.6 | % |

[0000858877-21-000018:mdna:130]
[same as prior period, unchanged from 0000858877-21-000008:mdna:143]

[0000858877-21-000018:mdna:131]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the first quarter of fiscal 2022, as compared with the corresponding prior year period:

[0000858877-21-000018:mdna:132]
|  |  | Product Gross Margin Percentage |
| Fiscal 2021 |  | 62.7 | % |
| Productivity (1) |  | (0.6) | % |
| Product pricing |  | (1.4) | % |
| Mix of products sold |  | 0.4 | % |
| Legal and indemnification charge |  | 0.5 | % |
| Others |  | (0.1) | % |
| Fiscal 2022 |  | 61.5 | % |

[0000858877-21-000018:mdna:133]
[same as prior period, unchanged from 0000858877-21-000008:mdna:146]

[0000858877-21-000018:mdna:134]
[same as prior period, unchanged from 0000858877-21-000008:mdna:138]

[0000858877-21-000018:mdna:135]
[same as prior period, unchanged from 0000858877-21-000008:mdna:139]

[0000858877-21-000018:mdna:136]
Three Months Ended October 30, 2021 Compared with Three Months Ended October 24, 2020

[0000858877-21-000018:mdna:137]
Product gross margin decreased by 1.2 percentage points primarily driven by lower productivity, largely driven by increased costs related to supply constraints from freight, expedites, and component costs. We also saw moderate pricing erosion, partially offset by favorable product mix. The effect of pricing erosion was moderate driven by typical market factors and primarily impacted the Americas and EMEA segments. Productivity was adversely impacted by increased costs related to supply constraints. The favorable mix was driven by changes in the proportion of products sold from Secure, Agile Networks and End-to-End Security, partially offset by unfavorable mix in Internet for the Future and Hybrid Work, as compared to the corresponding period of fiscal 2021.

[0000858877-21-000018:mdna:138]
Supply Constraints Impacts and Risks

[0000858877-21-000018:mdna:139]
We continue to manage through significant supply constraints seen industry wide due to component shortages caused, in part, by the COVID-19 pandemic. These shortages have resulted in increased costs (i.e., component and other commodity costs, freight, expedite fees, etc.) which have had a negative impact on our product gross margin and have resulted in extended lead times for us and our customers. We have taken a number of steps in order to mitigate the supply constraint related impacts including: partnering with several of our key suppliers utilizing our volume purchasing ability and extending supply coverage, including, in certain cases, revising supplier arrangements; paying significantly higher component and logistics costs to secure supply; modifying our product designs in order to leverage alternate suppliers, where possible; continually optimizing our inventory build and customer delivery plans; among others. We believe these actions are helping us to optimize our access to critical components and meet customer demand for our products. We have recently seen substantially increased demand for our hardware products. As a result, in order to secure supply to meet customer demand, we have increased our inventory balances and inventory purchase commitments (see Liquidity and Capital Resources—Inventory Supply Chain section), which, in turn, has increased our supply chain exposure. Additionally, in certain situations, we have prepaid or made deposits with suppliers to secure future supply. These actions significantly increase the risk of future material excess and obsolete inventory and related losses if customer demand were to suddenly and significantly decrease in future periods. While we believe we are taking the right strategic and operational actions to address the supply situation, we recognize the increased risks.

[0000858877-21-000018:mdna:140]
[same as prior period, unchanged from 0000858877-21-000008:mdna:152]

[0000858877-21-000018:mdna:141]
Three Months Ended October 30, 2021 Compared with Three Months Ended October 24, 2020

[0000858877-21-000018:mdna:142]
Our service gross margin percentage decreased by 0.6 percentage points primarily due to higher headcount-related and delivery costs, partially offset by favorable mix of service offerings and higher sales volume.

[0000858877-21-000018:mdna:143]
[same as prior period, unchanged from 0000858877-21-000008:mdna:158]

[0000858877-21-000018:mdna:144]
[same as prior period, unchanged from 0000858877-21-000008:mdna:156]

[0000858877-21-000018:mdna:145]
[same as prior period, unchanged from 0000858877-21-000008:mdna:157]

[0000858877-21-000018:mdna:146]
[same as prior period, unchanged from 0000858877-21-000008:mdna:161]

[0000858877-21-000018:mdna:147]
[same as prior period, unchanged from 0000858877-21-000008:mdna:162]

[0000858877-21-000018:mdna:148]
|  | Three Months Ended |
|  | AMOUNT |  | PERCENTAGE |
|  | October 30,2021 |  | October 24,2020 |  | October 30,2021 |  | October 24,2020 |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,875 |  |  | $ | 4,847 |  |  | 64.5 | % |  | 67.3 | % |
| EMEA | 2,128 |  |  | 1,894 |  |  | 64.4 | % |  | 63.9 | % |
| APJC | 1,317 |  |  | 1,113 |  |  | 64.7 | % |  | 63.0 | % |
| Segment total | 8,321 |  |  | 7,853 |  |  | 64.5 | % |  | 65.8 | % |
| Unallocated corporate items (1) | (268) |  |  | (272) |  |  |  |  |  |
| Total | $ | 8,053 |  |  | $ | 7,581 |  |  | 62.4 | % |  | 63.6 | % |

[0000858877-21-000018:mdna:149]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-21-000018:mdna:150]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-21-000018:mdna:151]
Three Months Ended October 30, 2021 Compared with Three Months Ended October 24, 2020

[0000858877-21-000018:mdna:152]
We experienced a gross margin percentage decrease in our Americas segment due to pricing erosion, negative impacts from productivity and unfavorable impacts from product mix.

[0000858877-21-000018:mdna:153]
Gross margin in our EMEA segment increased due to favorable impacts from productivity improvements and favorable impacts from product mix, partially offset by pricing erosion. Higher service gross margin also contributed to the increase in the gross margin in this geographic segment.

[0000858877-21-000018:mdna:154]
The APJC segment gross margin percentage increase was due to favorable impacts from product mix, productivity improvements and favorable pricing.

[0000858877-21-000018:mdna:155]
[same as prior period, unchanged from 0000858877-21-000008:mdna:170]

[0000858877-21-000018:mdna:156]
[same as prior period, unchanged from 0000858877-21-000008:mdna:177]

[0000858877-21-000018:mdna:157]
[same as prior period, unchanged from 0000858877-21-000008:mdna:178]

[0000858877-21-000018:mdna:158]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,714 |  |  | $ | 1,612 |  |  | $ | 102 |  |  | 6 | % |
| Percentage of revenue | 13.3 | % |  | 13.5 | % |  |  |  |  |
| Sales and marketing | 2,261 |  |  | 2,217 |  |  | 44 |  |  | 2 | % |
| Percentage of revenue | 17.5 | % |  | 18.6 | % |  |  |  |  |
| General and administrative | 551 |  |  | 544 |  |  | 7 |  |  | 1 | % |
| Percentage of revenue | 4.3 | % |  | 4.6 | % |  |  |  |  |
| Total | $ | 4,526 |  |  | $ | 4,373 |  |  | $ | 153 |  |  | 3 | % |
| Percentage of revenue | 35.1 | % |  | 36.7 | % |  |  |  |  |

[0000858877-21-000018:mdna:159]
[same as prior period, unchanged from 0000858877-21-000008:mdna:175]

[0000858877-21-000018:mdna:160]
[same as prior period, unchanged from 0000858877-21-000008:mdna:176]

[0000858877-21-000018:mdna:161]
Three Months Ended October 30, 2021 Compared with Three Months Ended October 24, 2020

[0000858877-21-000018:mdna:162]
[same as prior period, unchanged from 0000858877-21-000008:mdna:181]

[0000858877-21-000018:mdna:163]
R&D expenses increased due to higher headcount-related expenses, higher acquisition-related costs, higher share-based compensation expense and higher contracted services spending.

[0000858877-21-000018:mdna:164]
[same as prior period, unchanged from 0000858877-21-000008:mdna:184]

[0000858877-21-000018:mdna:165]
[same as prior period, unchanged from 0000858877-21-000008:mdna:187]

[0000858877-21-000018:mdna:166]
Sales and marketing expenses increased due to higher headcount-related expenses and discretionary spending.

[0000858877-21-000018:mdna:167]
[same as prior period, unchanged from 0000858877-21-000008:mdna:192]

[0000858877-21-000018:mdna:168]
G&A expenses increased slightly due to higher discretionary spending and contracted services spending.

[0000858877-21-000018:mdna:169]
[same as prior period, unchanged from 0000858877-21-000008:mdna:199]

[0000858877-21-000018:mdna:170]
In the first quarter of fiscal 2022, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $19 million, or 0.4%, compared with the first quarter of fiscal 2021.

[0000858877-21-000018:mdna:171]
[same as prior period, unchanged from 0000858877-21-000008:mdna:202]

[0000858877-21-000018:mdna:172]
[same as prior period, unchanged from 0000858877-21-000008:mdna:203]

[0000858877-21-000018:mdna:173]
|  |  | Three Months Ended |
|  |  | October 30,2021 |  | October 24,2020 |
| Amortization of purchased intangible assets: |  |  |  |  |
| Cost of sales |  | $ | 202 |  |  | $ | 170 |  |
| Operating expenses |  | 84 |  |  | 36 |  |
| Total |  | $ | 286 |  |  | $ | 206 |  |

[0000858877-21-000018:mdna:174]
For the first quarter of fiscal 2022, the increase in amortization of purchased intangible assets was due largely to the amortization of purchased intangibles from our recent acquisitions.

[0000858877-21-000018:mdna:175]
[same as prior period, unchanged from 0000858877-21-000008:mdna:206]

[0000858877-21-000018:mdna:176]
We initiated a restructuring plan in fiscal 2021, which included a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $900 million. In connection with this restructuring plan, we have incurred cumulative charges of $887 million and substantially completed this plan in fiscal 2021.

[0000858877-21-000018:mdna:177]
[same as prior period, unchanged from 0000858877-21-000008:mdna:209]

[0000858877-21-000018:mdna:178]
[same as prior period, unchanged from 0000858877-21-000008:mdna:210]

[0000858877-21-000018:mdna:179]
|  |  | Three Months Ended |
|  |  | October 30,2021 |  | October 24,2020 |
| Operating income |  | $ | 3,438 |  |  | $ | 2,570 |  |
| Operating income as a percentage of revenue |  | 26.7 | % |  | 21.5 | % |

[0000858877-21-000018:mdna:180]
Three Months Ended October 30, 2021 Compared with Three Months Ended October 24, 2020

[0000858877-21-000018:mdna:181]
Operating income increased by 34%, and operating income as a percentage of revenue increased by 5.2 percentage points. These changes resulted primarily from a revenue increase and lower restructuring and other charges partially offset by a gross margin percentage decrease (driven by lower productivity and pricing erosion, partially offset by favorable product mix).

[0000858877-21-000018:mdna:182]
[same as prior period, unchanged from 0000858877-21-000008:mdna:197]

[0000858877-21-000018:mdna:183]
[same as prior period, unchanged from 0000858877-21-000008:mdna:198]

[0000858877-21-000018:mdna:184]
[same as prior period, unchanged from 0000858877-21-000008:mdna:219]

[0000858877-21-000018:mdna:185]
[same as prior period, unchanged from 0000858877-21-000008:mdna:220]

[0000858877-21-000018:mdna:186]
|  |  | Three Months Ended |
|  |  | October 30,2021 |  | October 24,2020 |  | Variancein Dollars |
| Interest income |  | $ | 121 |  |  | $ | 174 |  |  | $ | (53) |  |
| Interest expense |  | (89) |  |  | (112) |  |  | 23 |  |
| Interest income (expense), net |  | $ | 32 |  |  | $ | 62 |  |  | $ | (30) |  |

[0000858877-21-000018:mdna:187]
For the first quarter of fiscal 2022, the decrease in interest income was driven by lower interest rates and lower average balances of cash and available-for-sale debt investments. The decrease in interest expense was driven by a lower average debt balance.

[0000858877-21-000018:mdna:188]
[same as prior period, unchanged from 0000858877-21-000008:mdna:223]

[0000858877-21-000018:mdna:189]
|  |  | Three Months Ended |
|  |  | October 30,2021 |  | October 24,2020 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | 6 |  |  | $ | 15 |  |  | $ | (9) |  |
| Marketable equity investments |  | 5 |  |  | (1) |  |  | 6 |  |
| Privately held investments |  | 205 |  |  | 42 |  |  | 163 |  |
| Net gains (losses) on investments |  | 216 |  |  | 56 |  |  | 160 |  |
| Other gains (losses), net |  | (29) |  |  | (7) |  |  | (22) |  |
| Other income (loss), net |  | $ | 187 |  |  | $ | 49 |  |  | $ | 138 |  |

[0000858877-21-000018:mdna:190]
Three Months Ended October 30, 2021 Compared with Three Months Ended October 24, 2020

[0000858877-21-000018:mdna:191]
The change in net gains (losses) on available-for-sale debt investments was primarily attributable to lower realized gains as a result of market conditions, and the timing of sales of these investments. The change in net gains (losses) on marketable equity investments was attributable to market value fluctuations and the timing of recognition of gains and losses. The change in net gains (losses) on privately held investments was primarily due to higher net unrealized gains and higher net realized gains. The change in other gains (losses), net was primarily driven by higher donation expense.

[0000858877-21-000018:mdna:192]
[same as prior period, unchanged from 0000858877-21-000008:mdna:229]

[0000858877-21-000018:mdna:193]
Three Months Ended October 30, 2021 Compared with Three Months Ended October 24, 2020

[0000858877-21-000018:mdna:194]
The provision for income taxes resulted in an effective tax rate of 18.5% for the first quarter of fiscal 2022 compared with 18.9% for the first quarter of fiscal 2021. The decrease in the effective tax rate was primarily due to an increase in the tax benefit from share-based compensation windfall in the first quarter of fiscal 2022 as compared to the first quarter of fiscal 2021.

[0000858877-21-000018:mdna:195]
[same as prior period, unchanged from 0000858877-21-000008:mdna:217]

[0000858877-21-000018:mdna:196]
[same as prior period, unchanged from 0000858877-21-000008:mdna:218]

[0000858877-21-000018:mdna:197]
[same as prior period, unchanged from 0000858877-21-000008:mdna:240]

[0000858877-21-000018:mdna:198]
[same as prior period, unchanged from 0000858877-21-000008:mdna:241]

[0000858877-21-000018:mdna:199]
[same as prior period, unchanged from 0000858877-21-000008:mdna:242]

[0000858877-21-000018:mdna:200]
[same as prior period, unchanged from 0000858877-21-000008:mdna:243]

[0000858877-21-000018:mdna:201]
|  | October 30,2021 |  | July 31,2021 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 7,619 |  |  | $ | 9,175 |  |  | $ | (1,556) |  |
| Available-for-sale debt investments | 15,513 |  |  | 15,206 |  |  | 307 |  |
| Marketable equity securities | 214 |  |  | 137 |  |  | 77 |  |
| Total | $ | 23,346 |  |  | $ | 24,518 |  |  | $ | (1,172) |  |

[0000858877-21-000018:mdna:202]
The net decrease in cash and cash equivalents and investments in the first quarter of fiscal 2022 was driven by a net decrease in debt of $2.0 billion, cash returned to stockholders in the form of repurchases of common stock of $0.3 billion, cash dividends of $1.6 billion, net cash paid for acquisitions and divestitures of $0.3 billion and capital expenditures of $0.1 billion. These uses of cash were partially offset by cash provided by operating activities of $3.4 billion.

[0000858877-21-000018:mdna:203]
[same as prior period, unchanged from 0000858877-21-000008:mdna:247]

[0000858877-21-000018:mdna:204]
[same as prior period, unchanged from 0000858877-21-000008:mdna:248]

[0000858877-21-000018:mdna:205]
[same as prior period, unchanged from 0000858877-21-000008:mdna:249]

[0000858877-21-000018:mdna:206]
[same as prior period, unchanged from 0000858877-21-000008:mdna:250]

[0000858877-21-000018:mdna:207]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |
| Net cash provided by operating activities | $ | 3,427 |  |  | $ | 4,096 |  |
| Acquisition of property and equipment | (122) |  |  | (171) |  |
| Free cash flow | $ | 3,305 |  |  | $ | 3,925 |  |

[0000858877-21-000018:mdna:208]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue, and the timing and amount of tax and other payments. For additional discussion, see “Part II, Item 1A. Risk Factors” in this report.

[0000858877-21-000018:mdna:209]
[same as prior period, unchanged from 0000858877-21-000008:mdna:234]

[0000858877-21-000018:mdna:210]
[same as prior period, unchanged from 0000858877-21-000008:mdna:235]

[0000858877-21-000018:mdna:211]
[same as prior period, unchanged from 0000858877-21-000008:mdna:256]

[0000858877-21-000018:mdna:212]
[same as prior period, unchanged from 0000858877-21-000008:mdna:257]

[0000858877-21-000018:mdna:213]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| October 30, 2021 |  | $ | 0.37 |  |  | $ | 1,561 |  |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |  | $ | 1,817 |  |
| Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 31, 2021 |  | $ | 0.37 |  |  | $ | 1,562 |  |  | 15 |  |  | $ | 53.30 |  |  | $ | 791 |  |  | $ | 2,353 |  |
| May 1, 2021 |  | $ | 0.37 |  |  | $ | 1,560 |  |  | 10 |  |  | $ | 48.71 |  |  | $ | 510 |  |  | $ | 2,070 |  |
| January 23, 2021 |  | $ | 0.36 |  |  | $ | 1,521 |  |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |  | $ | 2,322 |  |
| October 24, 2020 |  | $ | 0.36 |  |  | $ | 1,520 |  |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |  | $ | 2,320 |  |

[0000858877-21-000018:mdna:214]
[same as prior period, unchanged from 0000858877-21-000008:mdna:259]

[0000858877-21-000018:mdna:215]
The remaining authorized amount for stock repurchases under this program is approximately $7.7 billion, with no termination date.

[0000858877-21-000018:mdna:216]
[same as prior period, unchanged from 0000858877-21-000008:mdna:261]

[0000858877-21-000018:mdna:217]
|  | October 30,2021 |  | July 31,2021 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,306 |  |  | $ | 5,766 |  |  | $ | (460) |  |

[0000858877-21-000018:mdna:218]
Our accounts receivable net, as of October 30, 2021 decreased by approximately 8%, as compared with the end of fiscal 2021, primarily due to timing and amount of product and service billings in the first quarter of fiscal 2022 compared with the fourth quarter of fiscal 2021.

[0000858877-21-000018:mdna:219]
56

[0000858877-21-000018:mdna:220]
[same as prior period, unchanged from 0000858877-21-000008:mdna:238]

[0000858877-21-000018:mdna:221]
[same as prior period, unchanged from 0000858877-21-000008:mdna:239]

[0000858877-21-000018:mdna:222]
Inventory Supply Chain  The following table summarizes our inventories and inventory purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-21-000018:mdna:223]
|  | October 30,2021 |  | July 31,2021 |  | July 25,2020 |  | Variance vs. July 31, 2021 |  | Variance vs. July 25, 2020 |
| Inventories | $ | 1,832 |  |  | $ | 1,559 |  |  | $ | 1,282 |  |  | $ | 273 |  |  | $ | 550 |  |
| Inventory purchase commitments | $ | 11,052 |  |  | $ | 10,254 |  |  | $ | 4,406 |  |  | $ | 798 |  |  | $ | 6,646 |  |
| Inventory prepayments and deposits | $ | 229 |  |  | $ | 162 |  |  | $ | 117 |  |  | $ | 67 |  |  | $ | 112 |  |

[0000858877-21-000018:mdna:224]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-21-000018:mdna:225]
|  | October 30,2021 |  | July 31,2021 |  | July 25,2020 |  | Variance vs. July 31, 2021 |  | Variance vs.July 25, 2020 |
| Less than 1 year | $ | 7,621 |  |  | $ | 6,903 |  |  | $ | 3,994 |  |  | $ | 718 |  |  | $ | 3,627 |  |
| 1 to 3 years | 2,072 |  |  | 1,806 |  |  | 412 |  |  | 266 |  |  | 1,660 |  |
| 3 to 5 years | 1,359 |  |  | 1,545 |  |  | — |  |  | (186) |  |  | 1,359 |  |
| Total | $ | 11,052 |  |  | $ | 10,254 |  |  | $ | 4,406 |  |  | $ | 798 |  |  | $ | 6,646 |  |

[0000858877-21-000018:mdna:226]
Inventories and inventory purchase commitments increased as compared to the prior fiscal periods as we increased our balances in order to address significant supply constraints seen industry wide. Inventory as of October 30, 2021 increased by 18% and 43% from our inventory balances at the end of fiscal 2021 and fiscal 2020, respectively. Inventory purchase commitments with contract manufacturers and suppliers increased by 8% and 151% from our balances at the end of fiscal 2021 and fiscal 2020, respectively. These increases compared with the end of fiscal 2021 and fiscal 2020 were primarily due to arrangements to secure supply and pricing for certain product components and commitments with contract manufacturers to meet customer demand and to address extended lead times, as a result of the supply constraints. We have partnered with several of our key suppliers utilizing our volume purchasing and extending supply coverage, including revising supplier arrangements. Our inventory prepayments and deposits are to secure future supply with our contract manufacturers and suppliers. As discussed, our risks of future material excess and obsolete inventory and related losses are further outlined in the Result of Operations—Product Gross Margin section.

[0000858877-21-000018:mdna:227]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity.

[0000858877-21-000018:mdna:228]
Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-21-000018:mdna:229]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of supply constraints, rapidly changing technology and customer requirements. We believe the amount of our inventory and inventory purchase commitments is appropriate for our current and expected customer demand and revenue levels.

[0000858877-21-000018:mdna:230]
[same as prior period, unchanged from 0000858877-21-000008:mdna:276]

[0000858877-21-000018:mdna:231]
|  | October 30,2021 |  | July 31,2021 |  | Increase (Decrease) |
| Lease receivables, net | $ | 1,554 |  |  | $ | 1,697 |  |  | $ | (143) |  |
| Loan receivables, net | 4,735 |  |  | 5,117 |  |  | (382) |  |
| Financed service contracts, net | 2,327 |  |  | 2,450 |  |  | (123) |  |
| Total, net | $ | 8,616 |  |  | $ | 9,264 |  |  | $ | (648) |  |

[0000858877-21-000018:mdna:232]
[same as prior period, unchanged from 0000858877-21-000008:mdna:253]

[0000858877-21-000018:mdna:233]
[same as prior period, unchanged from 0000858877-21-000008:mdna:254]

[0000858877-21-000018:mdna:234]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services. The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed. Financing receivables decreased by 7%, as compared with the end of fiscal 2021.

[0000858877-21-000018:mdna:235]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements to customers provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, with payment terms generally ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-21-000018:mdna:236]
The volume of channel partner financing was $6.6 billion and $6.1 billion for the first quarter of fiscal 2022 and 2021, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.3 billion as of each of October 30, 2021 and July 31, 2021. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of October 30, 2021, the total maximum potential future payments related to these guarantees was approximately $201 million, of which approximately $9 million was recorded as deferred revenue.

[0000858877-21-000018:mdna:237]
[same as prior period, unchanged from 0000858877-21-000008:mdna:283]

[0000858877-21-000018:mdna:238]
[same as prior period, unchanged from 0000858877-21-000008:mdna:284]

[0000858877-21-000018:mdna:239]
|  | Maturity Date |  | October 30,2021 |  | July 31,2021 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | $ | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 9,500 |  |  | $ | 11,500 |  |

[0000858877-21-000018:mdna:240]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of October 30, 2021.

[0000858877-21-000018:mdna:241]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of October 30, 2021 and July 31, 2021.

[0000858877-21-000018:mdna:242]
[same as prior period, unchanged from 0000858877-21-000008:mdna:269]

[0000858877-21-000018:mdna:243]
[same as prior period, unchanged from 0000858877-21-000008:mdna:270]

[0000858877-21-000018:mdna:244]
Credit Facility  On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. The credit agreement is structured as an amendment and restatement of our 364-day credit agreement, which would have terminated on May 14, 2021. As of October 30, 2021, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.

[0000858877-21-000018:mdna:245]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

[0000858877-21-000018:mdna:246]
[same as prior period, unchanged from 0000858877-21-000008:mdna:298]

[0000858877-21-000018:mdna:247]
|  | October 30,2021 |  | July 31,2021 |  | Increase (Decrease) |
| Product | $ | 13,384 |  |  | $ | 13,270 |  |  | $ | 114 |  |
| Service | 16,751 |  |  | 17,623 |  |  | (872) |  |
| Total | $ | 30,135 |  |  | $ | 30,893 |  |  | $ | (758) |  |
| Current | $ | 15,941 |  |  | $ | 16,289 |  |  | $ | (348) |  |
| Noncurrent | 14,194 |  |  | 14,604 |  |  | (410) |  |
| Total | $ | 30,135 |  |  | $ | 30,893 |  |  | $ | (758) |  |

[0000858877-21-000018:mdna:248]
Total remaining performance obligations decreased 2% in the first quarter of fiscal 2022 compared to the end of fiscal 2021. Remaining performance obligations for product increased 1% compared to the end of fiscal 2021. Remaining performance obligations for service decreased 5%. We expect approximately 53% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-21-000018:mdna:249]
[same as prior period, unchanged from 0000858877-21-000008:mdna:295]

[0000858877-21-000018:mdna:250]
|  | October 30,2021 |  | July 31,2021 |  | Increase (Decrease) |
| Product | $ | 9,681 |  |  | $ | 9,416 |  |  | $ | 265 |  |
| Service | 12,391 |  |  | 12,748 |  |  | (357) |  |
| Total | $ | 22,072 |  |  | $ | 22,164 |  |  | $ | (92) |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 12,017 |  |  | $ | 12,148 |  |  | $ | (131) |  |
| Noncurrent | 10,055 |  |  | 10,016 |  |  | 39 |  |
| Total | $ | 22,072 |  |  | $ | 22,164 |  |  | $ | (92) |  |

[0000858877-21-000018:mdna:251]
[same as prior period, unchanged from 0000858877-21-000008:mdna:297]

[0000858877-21-000018:mdna:252]
[same as prior period, unchanged from 0000858877-21-000008:mdna:280]

[0000858877-21-000018:mdna:253]
[same as prior period, unchanged from 0000858877-21-000008:mdna:281]

[0000858877-21-000018:mdna:254]
[same as prior period, unchanged from 0000858877-21-000008:mdna:301]

[0000858877-21-000018:mdna:255]
[same as prior period, unchanged from 0000858877-21-000008:mdna:302]

[0000858877-21-000018:mdna:256]
The income tax payable outstanding as of October 30, 2021 for the U.S. transition tax on accumulated earnings for foreign subsidiaries is $6.9 billion. Approximately $0.7 billion is payable in less than one year; $2.1 billion is payable between 1 to 3 years; and $4.1 billion is payable between 3 to 5 years.

[0000858877-21-000018:mdna:257]
For our Contractual Obligations see our Annual Report on Form 10-K for the year ended July 31, 2021.

[0000858877-21-000018:mdna:258]
[same as prior period, unchanged from 0000858877-21-000008:mdna:305]

[0000858877-21-000018:mdna:259]
[same as prior period, unchanged from 0000858877-21-000008:mdna:306]

[0000858877-21-000018:mdna:260]
We also have certain funding commitments primarily related to our privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.2 billion as of each of October 30, 2021 and July 31, 2021.

[0000858877-21-000018:mdna:261]
In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of October 30, 2021 there were no material unconsolidated variable interest entities.

[0000858877-21-000018:mdna:262]
On an ongoing basis, we reassess our privately held investments and customer financings to determine if they are variable interest entities and if we would be regarded as the primary beneficiary pursuant to the applicable accounting guidance. As a result of this ongoing assessment, we may be required to make additional disclosures or consolidate these entities. Because we may not control these entities, we may not have the ability to influence these events.

[0000858877-21-000018:mdna:263]
[same as prior period, unchanged from 0000858877-21-000008:mdna:313]

[0000858877-21-000018:mdna:264]
[same as prior period, unchanged from 0000858877-21-000008:mdna:314]

[0000858877-21-000018:mdna:265]
While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to increased disruption and volatility in capital markets and credit markets. The pandemic and resulting economic uncertainty could adversely affect our liquidity and capital resources in the future. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs (including inventory and other supply related payments), capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. We expect increased payments related to inventory and other supply related payments through at least the next 12 months. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.
