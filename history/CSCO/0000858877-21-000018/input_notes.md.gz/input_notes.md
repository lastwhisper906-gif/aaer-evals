# CSCO notes — 0000858877-21-000018


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-21-000018:notes:1]
Organization and Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2022 is a 52-week fiscal year and fiscal 2021 was a 53-week fiscal year. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-21-000018:notes:2]
We have prepared the accompanying financial data as of October 30, 2021 and for the first quarter of fiscal 2022 and 2021, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 31, 2021 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021.

[0000858877-21-000018:notes:3]
[same as prior period, unchanged from 0000858877-21-000008:notes:4]

[0000858877-21-000018:notes:4]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 30, 2021, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2022 and 2021, as applicable, have been made. The results of operations for the first quarter of fiscal 2022 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-21-000018:notes:5]
Our consolidated financial statements include our accounts and entities consolidated under the variable interest and voting models. The noncontrolling interests attributed to these investments, if material, are presented as a separate component from our equity in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-21-000018:notes:6]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-21-000018:notes:7]
[same as prior period, unchanged from 0000858877-21-000008:notes:8]

[0000858877-21-000018:notes:8]
Acquired Revenue Contracts with Customers in Business Combination  In October 2021, the Financial Accounting Standards Board (FASB) issued an accounting standard update that requires companies to apply Accounting Standards Codification 606 to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination. We early adopted this accounting standard update beginning in the first quarter of fiscal 2022 and did not have a material impact on our Consolidated Financial Statements. The ongoing impact of this standard will be fact dependent on the transactions within its scope.

[0000858877-21-000018:notes:9]
(b)Recent Accounting Standards or Updates Not Yet Effective

[0000858877-21-000018:notes:10]
Reference Rate Reform  In March 2020, the FASB issued an accounting standard update and subsequent amendments that provide optional expedients and exceptions to the current guidance on contract modification and hedging relationships to ease the financial reporting burden of the expected market transition from the London InterBank Offered Rate (LIBOR) and other interbank offered rates to alternative reference rates. This accounting standard update was effective upon issuance and may be 
applied prospectively through December 31, 2022. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-21-000018:notes:11]
[same as prior period, unchanged from 0000858877-21-000008:notes:15]

[0000858877-21-000018:notes:12]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-21-000018:notes:13]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 30, 2021 and July 31, 2021 was $49 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-21-000018:notes:14]
[same as prior period, unchanged from 0000858877-21-000008:notes:18]

[0000858877-21-000018:notes:15]
[same as prior period, unchanged from 0000858877-21-000008:notes:19]

[0000858877-21-000018:notes:16]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.

[0000858877-21-000018:notes:17]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license’s utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

[0000858877-21-000018:notes:18]
[same as prior period, unchanged from 0000858877-21-000008:notes:22]

[0000858877-21-000018:notes:19]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. Effective in the first quarter of fiscal 2022, we began reporting our product and service revenue in the following categories: Secure, Agile Networks; Hybrid Work; End-to-End Security; Internet for the Future; Optimized Application Experiences; Other Products; and Services. This change will better align our product categories with our strategic priorities. The following table presents this disaggregation of revenue (in millions):

[0000858877-21-000018:notes:20]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |
| Product revenue: |  |  |  |
| Secure, Agile Networks | $ | 5,967 |  |  | $ | 5,434 |  |
| Hybrid Work | 1,109 |  |  | 1,193 |  |
| End-to-End Security | 895 |  |  | 861 |  |
| Internet for the Future | 1,374 |  |  | 942 |  |
| Optimized Application Experiences | 181 |  |  | 153 |  |
| Other Products | 3 |  |  | 3 |  |
| Total Product | 9,529 |  |  | 8,587 |  |
| Services | 3,371 |  |  | 3,342 |  |
| Total | $ | 12,900 |  |  | $ | 11,929 |  |

[0000858877-21-000018:notes:21]
Amounts may not sum due to rounding.

[0000858877-21-000018:notes:22]
Secure, Agile Networks consists of our core networking technologies of switching, enterprise routing, wireless, and compute products. These technologies consist of both hardware and software offerings, including software licenses and SaaS, that help our customers build networks, automate, orchestrate, integrate, and digitize data. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-21-000018:notes:23]
Hybrid Work consists of our collaboration offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-21-000018:notes:24]
End-to-End Security consists of our overall security offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-21-000018:notes:25]
Internet for the Future consists of our routed optical networking, public 5G, silicon, and optics offerings. These products consist primarily of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-21-000018:notes:26]
Optimized Application Experiences consists of our full stack observability and cloud-native platform offerings. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-21-000018:notes:27]
[same as prior period, unchanged from 0000858877-21-000008:notes:31]

[0000858877-21-000018:notes:28]
[same as prior period, unchanged from 0000858877-21-000008:notes:32]

[0000858877-21-000018:notes:29]
[same as prior period, unchanged from 0000858877-21-000008:notes:33]

[0000858877-21-000018:notes:30]
Accounts receivable, net was $5.3 billion as of October 30, 2021 compared to $5.8 billion as of July 31, 2021, as reported on the Consolidated Balance Sheets.

[0000858877-21-000018:notes:31]
The allowances for credit loss for our accounts receivable are summarized as follows (in millions):

[0000858877-21-000018:notes:32]
|  | Three Months Ended |
|  | October 30, 2021 |  | October 24, 2020 |
| Allowance for credit loss at beginning of period | $ | 109 |  |  | $ | 143 |  |
| Provisions (benefits) | 19 |  |  | 14 |  |
| Recoveries (write-offs), net | (14) |  |  | (6) |  |
| Foreign exchange and other | — |  |  | (26) |  |
| Allowance for credit loss at end of period | $ | 114 |  |  | $ | 125 |  |

[0000858877-21-000018:notes:33]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $1.4 billion as of each of October 30, 2021 and July 31, 2021, and were included in other current assets and other assets.

[0000858877-21-000018:notes:34]
[same as prior period, unchanged from 0000858877-21-000008:notes:36]

[0000858877-21-000018:notes:35]
|  | October 30,2021 |  | July 31,2021 |
| 1 to 4 | $ | 445 |  |  | $ | 521 |  |
| 5 to 6 | 839 |  |  | 770 |  |
| 7 and Higher | 154 |  |  | 166 |  |
| Total | $ | 1,438 |  |  | $ | 1,457 |  |

[0000858877-21-000018:notes:36]
Contract liabilities consist of deferred revenue. Deferred revenue was $22.1 billion as of October 30, 2021 compared to $22.2 billion as of July 31, 2021. We recognized approximately $4.1 billion of revenue during the first quarter of fiscal 2022 that was included in the deferred revenue balance at July 31, 2021.

[0000858877-21-000018:notes:37]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $994 million and $967 million as of October 30, 2021 and July 31, 2021, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $187 million and $123 million for the first quarter of fiscal 2022 and 2021, respectively, and was included in sales and marketing expenses.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-21-000018:notes:38]
[same as prior period, unchanged from 0000858877-21-000008:notes:40]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-21-000018:notes:39]
[same as prior period, unchanged from 0000858877-21-000008:notes:41]

[0000858877-21-000018:notes:40]
[same as prior period, unchanged from 0000858877-21-000008:notes:42]

[0000858877-21-000018:notes:41]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |
| Revenue: |  |  |  |
| Secure, Agile Networks | $ | 5,967 |  |  | $ | 5,434 |  |
| Hybrid Work | 1,109 |  |  | 1,193 |  |
| End-to-End Security | 895 |  |  | 861 |  |
| Internet for the Future | 1,374 |  |  | 942 |  |
| Optimized Application Experiences | 181 |  |  | 153 |  |
| Other Products | 3 |  |  | 3 |  |
| Total Product | 9,529 |  |  | 8,587 |  |
| Services | 3,371 |  |  | 3,342 |  |
| Total | $ | 12,900 |  |  | $ | 11,929 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-21-000018:notes:42]
Acquisitions and Divestitures
We completed one acquisition during the first quarter of fiscal 2022. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-21-000018:notes:43]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions (one in total) | $ | 323 |  |  | $ | 8 |  |  | $ | 10 |  |  | $ | 305 |  |

[0000858877-21-000018:notes:44]
The total purchase consideration related to our acquisitions completed during the first quarter of fiscal 2022 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $6 million. Total transaction costs related to acquisition and divestiture activities were $19 million and $4 million for the first quarter of fiscal 2022 and 2021, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-21-000018:notes:45]
The goodwill generated from acquisitions completed during the first quarter of fiscal 2022 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first quarter of fiscal 2022 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-21-000018:notes:46]
[same as prior period, unchanged from 0000858877-21-000008:notes:48]

[0000858877-21-000018:notes:47]
The following table presents the goodwill allocated to our reportable segments as of October 30, 2021 and during the first quarter of fiscal 2022 (in millions):

[0000858877-21-000018:notes:48]
|  | Balance at July 31, 2021 |  | Acquisitions & Divestitures |  | Foreign Currency Translation and Other |  | Balance at October 30, 2021 |
| Americas | $ | 23,673 |  |  | $ | 204 |  |  | $ | 315 |  |  | $ | 24,192 |  |
| EMEA | 9,094 |  |  | 77 |  |  | 9 |  |  | 9,180 |  |
| APJC | 5,401 |  |  | 24 |  |  | 5 |  |  | 5,430 |  |
| Total | $ | 38,168 |  |  | $ | 305 |  |  | $ | 329 |  |  | $ | 38,802 |  |

[0000858877-21-000018:notes:49]
[same as prior period, unchanged from 0000858877-21-000008:notes:51]

[0000858877-21-000018:notes:50]
The following table presents details of our intangible assets acquired through acquisitions completed during the first quarter of fiscal 2022 (in millions, except years):

[0000858877-21-000018:notes:51]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions (one in total) | 2.0 |  | $ | 6 |  |  | 2.0 |  | $ | 4 |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 10 |  |

[0000858877-21-000018:notes:52]
[same as prior period, unchanged from 0000858877-21-000008:notes:54]

[0000858877-21-000018:notes:53]
| October 30, 2021 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,485 |  |  | $ | (1,482) |  |  | $ | 2,003 |  |
| Customer relationships |  | 1,391 |  |  | (597) |  |  | 794 |  |
| Other |  | 71 |  |  | (23) |  |  | 48 |  |
| Total purchased intangible assets with finite lives |  | 4,947 |  |  | (2,102) |  |  | 2,845 |  |
| In-process research and development, with indefinite lives |  | 505 |  |  | — |  |  | 505 |  |
| Total |  | $ | 5,452 |  |  | $ | (2,102) |  |  | $ | 3,350 |  |

[0000858877-21-000018:notes:54]
| July 31, 2021 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,629 |  |  | $ | (1,437) |  |  | $ | 2,192 |  |
| Customer relationships |  | 1,387 |  |  | (523) |  |  | 864 |  |
| Other |  | 71 |  |  | (13) |  |  | 58 |  |
| Total purchased intangible assets with finite lives |  | 5,087 |  |  | (1,973) |  |  | 3,114 |  |
| In-process research and development, with indefinite lives |  | 505 |  |  | — |  |  | 505 |  |
| Total |  | $ | 5,592 |  |  | $ | (1,973) |  |  | $ | 3,619 |  |

[0000858877-21-000018:notes:55]
[same as prior period, unchanged from 0000858877-21-000008:notes:57]

[0000858877-21-000018:notes:56]
[same as prior period, unchanged from 0000858877-21-000008:notes:58]

[0000858877-21-000018:notes:57]
|  | Three Months Ended |
|  | October 30, 2021 |  | October 24, 2020 |
| Amortization of purchased intangible assets: |  |  |  |
| Cost of sales | $ | 202 |  |  | $ | 170 |  |
| Operating expenses | 84 |  |  | 36 |  |
| Total | $ | 286 |  |  | $ | 206 |  |

[0000858877-21-000018:notes:58]
The estimated future amortization expense of purchased intangible assets with finite lives as of October 30, 2021 is as follows (in millions):

[0000858877-21-000018:notes:59]
| Fiscal Year | Amount |
| 2022 (remaining nine months) | $ | 763 |  |
| 2023 | $ | 879 |  |
| 2024 | $ | 750 |  |
| 2025 | $ | 394 |  |
| 2026 | $ | 58 |  |
| Thereafter | $ | 1 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-21-000018:notes:60]
Restructuring and Other Charges
We initiated a restructuring plan in fiscal 2021 (the “Fiscal 2021 Plan”), which included a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $900 million. In connection with the Fiscal 2021 Plan, we have incurred cumulative charges of $887 million and substantially completed this plan in fiscal 2021.

[0000858877-21-000018:notes:61]
We initiated a restructuring plan in fiscal 2020 (the “Fiscal 2020 Plan”) in order to realign the organization and enable further investment in key priority areas. In connection with the Fiscal 2020 Plan, we incurred cumulative charges of $259 million. We completed the Fiscal 2020 Plan in fiscal 2021.

[0000858877-21-000018:notes:62]
The aggregate pretax charges related to these plans are primarily cash-based and consist of severance and other one-time termination benefits, and other costs.

[0000858877-21-000018:notes:63]
[same as prior period, unchanged from 0000858877-21-000008:notes:65]

[0000858877-21-000018:notes:64]
|  |  | FISCAL 2020 AND PRIOR PLANS |  | FISCAL 2021 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 31, 2021 |  | $ | — |  |  | $ | 10 |  |  | $ | 16 |  |  | $ | 8 |  |  | $ | 34 |  |
| Charges |  | — |  |  | (1) |  |  | 4 |  |  | 2 |  |  | 5 |  |
| Cash payments |  | — |  |  | (1) |  |  | (8) |  |  | — |  |  | (9) |  |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (4) |  |  | (4) |  |
| Liability as of October 30, 2021 |  | $ | — |  |  | $ | 8 |  |  | $ | 12 |  |  | $ | 6 |  |  | $ | 26 |  |

[0000858877-21-000018:notes:65]
|  |  | FISCAL 2020 AND PRIOR PLANS |  | FISCAL 2021 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | Employee Severance |  | Other |  | Total |
| Liability as of July 25, 2020 |  | $ | 58 |  |  | $ | 14 |  |  | $ | — |  |  | $ | — |  |  | $ | 72 |  |
| Charges |  | — |  |  | — |  |  | 590 |  |  | 12 |  |  | 602 |  |
| Cash payments |  | (58) |  |  | — |  |  | (272) |  |  | — |  |  | (330) |  |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (11) |  |  | (11) |  |
| Liability as of October 24, 2020 |  | $ | — |  |  | $ | 14 |  |  | $ | 318 |  |  | $ | 1 |  |  | $ | 333 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-21-000018:notes:66]
[same as prior period, unchanged from 0000858877-21-000008:notes:68]

[0000858877-21-000018:notes:67]
Cash, Cash Equivalents, and Restricted Cash

[0000858877-21-000018:notes:68]
|  |  | October 30,2021 |  | July 31,2021 |
| Cash and cash equivalents |  | $ | 7,619 |  |  | $ | 9,175 |  |
| Restricted cash included in other current assets |  | 10 |  |  | 14 |  |
| Restricted cash included in other assets |  | 750 |  |  | 753 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 8,379 |  |  | $ | 9,942 |  |

[0000858877-21-000018:notes:69]
Our restricted cash balances are funds primarily related to contractual obligations with suppliers.

[0000858877-21-000018:notes:70]
Inventories

[0000858877-21-000018:notes:71]
|  |  | October 30,2021 |  | July 31,2021 |
| Raw materials |  | $ | 1,090 |  |  | $ | 801 |  |
| Work in process |  | 41 |  |  | 54 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales |  | 85 |  |  | 97 |  |
| Manufactured finished goods |  | 465 |  |  | 422 |  |
| Total finished goods |  | 550 |  |  | 519 |  |
| Service-related spares |  | 142 |  |  | 174 |  |
| Demonstration systems |  | 9 |  |  | 11 |  |
| Total |  | $ | 1,832 |  |  | $ | 1,559 |  |

[0000858877-21-000018:notes:72]
Property and Equipment, Net

[0000858877-21-000018:notes:73]
|  |  | October 30,2021 |  | July 31,2021 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,310 |  |  | $ | 4,304 |  |
| Computer equipment and related software |  | 861 |  |  | 858 |  |
| Production, engineering, and other equipment |  | 5,023 |  |  | 5,106 |  |
| Operating lease assets |  | 250 |  |  | 273 |  |
| Furniture, fixtures and other |  | 377 |  |  | 377 |  |
| Total gross property and equipment |  | 10,821 |  |  | 10,918 |  |
| Less: accumulated depreciation and amortization |  | (8,583) |  |  | (8,580) |  |
| Total |  | $ | 2,238 |  |  | $ | 2,338 |  |

[0000858877-21-000018:notes:74]
Remaining Performance Obligations

[0000858877-21-000018:notes:75]
|  |  | October 30,2021 |  | July 31,2021 |
| Product |  | $ | 13,384 |  |  | $ | 13,270 |  |
| Service |  | 16,751 |  |  | 17,623 |  |
| Total |  | $ | 30,135 |  |  | $ | 30,893 |  |
| Current |  | $ | 15,941 |  |  | $ | 16,289 |  |
| Noncurrent |  | 14,194 |  |  | 14,604 |  |
| Total |  | $ | 30,135 |  |  | $ | 30,893 |  |

[0000858877-21-000018:notes:76]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of October 30, 2021, the aggregate amount of RPO was comprised of $22.1 billion of deferred revenue and $8.1 billion of unbilled contract revenue. We expect approximately 53% of this amount to be recognized as revenue over the next 12 months. As of July 31, 2021, the aggregate amount of RPO was comprised of $22.2 billion of deferred revenue and $8.7 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

[0000858877-21-000018:notes:77]
Deferred Revenue

[0000858877-21-000018:notes:78]
|  |  | October 30,2021 |  | July 31,2021 |
| Product |  | $ | 9,681 |  |  | $ | 9,416 |  |
| Service |  | 12,391 |  |  | 12,748 |  |
| Total |  | $ | 22,072 |  |  | $ | 22,164 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 12,017 |  |  | $ | 12,148 |  |
| Noncurrent |  | 10,055 |  |  | 10,016 |  |
| Total |  | $ | 22,072 |  |  | $ | 22,164 |  |


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000858877-21-000018:notes:79]
Leases 
(a)Lessee Arrangements

[0000858877-21-000018:notes:80]
The following table presents our operating lease balances (in millions):

[0000858877-21-000018:notes:81]
|  | Balance Sheet Line Item |  | October 30, 2021 |  | July 31, 2021 |
| Operating lease right-of-use assets | Other assets |  | $ | 1,118 |  |  | $ | 1,095 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 353 |  |  | $ | 337 |  |
| Operating lease liabilities | Other long-term liabilities |  | 834 |  |  | 831 |  |
| Total operating lease liabilities |  |  | $ | 1,187 |  |  | $ | 1,168 |  |

[0000858877-21-000018:notes:82]
The components of our lease expenses were as follows (in millions):

[0000858877-21-000018:notes:83]
|  | Three Months Ended |
|  | October 30, 2021 |  | October 24, 2020 |
| Operating lease expense | $ | 95 |  |  | $ | 98 |  |
| Short-term lease expense | 17 |  |  | 18 |  |
| Variable lease expense | 49 |  |  | 46 |  |
| Total lease expense | $ | 161 |  |  | $ | 162 |  |

[0000858877-21-000018:notes:84]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-21-000018:notes:85]
|  | Three Months Ended |
|  | October 30, 2021 |  | October 24, 2020 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 98 |  |  | $ | 105 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 120 |  |  | $ | 115 |  |

[0000858877-21-000018:notes:86]
The weighted-average lease term was 4.9 years and 5.2 years as of October 30, 2021 and July 31, 2021, respectively. The weighted-average discount rate was 1.7% as of each of October 30, 2021 and July 31, 2021.

[0000858877-21-000018:notes:87]
The maturities of our operating leases (undiscounted) as of October 30, 2021 are as follows (in millions):

[0000858877-21-000018:notes:88]
| Fiscal Year | Amount |
| 2022 (remaining nine months) | $ | 283 |  |
| 2023 | 307 |  |
| 2024 | 224 |  |
| 2025 | 145 |  |
| 2026 | 84 |  |
| Thereafter | 218 |  |
| Total lease payments | 1,261 |  |
| Less interest | (74) |  |
| Total | $ | 1,187 |  |

[0000858877-21-000018:notes:89]
(b)Lessor Arrangements

[0000858877-21-000018:notes:90]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income was $15 million and $21 million for the first quarter of fiscal 2022 and 2021, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-21-000018:notes:91]
Future minimum lease payments on our lease receivables as of October 30, 2021 are summarized as follows (in millions):

[0000858877-21-000018:notes:92]
| Fiscal Year | Amount |
| 2022 (remaining nine months) | $ | 557 |  |
| 2023 | 514 |  |
| 2024 | 290 |  |
| 2025 | 146 |  |
| 2026 | 48 |  |
| Thereafter | 5 |  |
| Total | 1,560 |  |
| Less: Present value of lease payments | 1,490 |  |
| Unearned income | $ | 70 |  |

[0000858877-21-000018:notes:93]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-21-000018:notes:94]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-21-000018:notes:95]
|  | October 30, 2021 |  | July 31, 2021 |
| Operating lease assets | $ | 250 |  |  | $ | 273 |  |
| Accumulated depreciation | (156) |  |  | (165) |  |
| Operating lease assets, net | $ | 94 |  |  | $ | 108 |  |

[0000858877-21-000018:notes:96]
Our operating lease income was $32 million and $43 million for the first quarter of fiscal 2022 and 2021, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-21-000018:notes:97]
Minimum future rentals on noncancelable operating leases as of October 30, 2021 are summarized as follows (in millions):

[0000858877-21-000018:notes:98]
| Fiscal Year | Amount |
| 2022 (remaining nine months) | $ | 35 |  |
| 2023 | 25 |  |
| 2024 | 7 |  |
| 2025 | 1 |  |
| Total | $ | 68 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-21-000018:notes:99]
[same as prior period, unchanged from 0000858877-21-000008:notes:96]

[0000858877-21-000018:notes:100]
[same as prior period, unchanged from 0000858877-21-000008:notes:97]

[0000858877-21-000018:notes:101]
[same as prior period, unchanged from 0000858877-21-000008:notes:98]

[0000858877-21-000018:notes:102]
| October 30, 2021 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 1,560 |  |  | $ | 4,809 |  |  | $ | 2,329 |  |  | $ | 8,698 |  |
| Residual value | 97 |  |  | — |  |  | — |  |  | 97 |  |
| Unearned income | (70) |  |  | — |  |  | — |  |  | (70) |  |
| Allowance for credit loss | (33) |  |  | (74) |  |  | (2) |  |  | (109) |  |
| Total, net | $ | 1,554 |  |  | $ | 4,735 |  |  | $ | 2,327 |  |  | $ | 8,616 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 736 |  |  | $ | 2,198 |  |  | $ | 1,136 |  |  | $ | 4,070 |  |
| Noncurrent | 818 |  |  | 2,537 |  |  | 1,191 |  |  | 4,546 |  |
| Total, net | $ | 1,554 |  |  | $ | 4,735 |  |  | $ | 2,327 |  |  | $ | 8,616 |  |

[0000858877-21-000018:notes:103]
| July 31, 2021 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 1,710 |  |  | $ | 5,203 |  |  | $ | 2,453 |  |  | $ | 9,366 |  |
| Residual value | 103 |  |  | — |  |  | — |  |  | 103 |  |
| Unearned income | (78) |  |  | — |  |  | — |  |  | (78) |  |
| Allowance for credit loss | (38) |  |  | (86) |  |  | (3) |  |  | (127) |  |
| Total, net | $ | 1,697 |  |  | $ | 5,117 |  |  | $ | 2,450 |  |  | $ | 9,264 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 780 |  |  | $ | 2,372 |  |  | $ | 1,228 |  |  | $ | 4,380 |  |
| Noncurrent | 917 |  |  | 2,745 |  |  | 1,222 |  |  | 4,884 |  |
| Total, net | $ | 1,697 |  |  | $ | 5,117 |  |  | $ | 2,450 |  |  | $ | 9,264 |  |

[0000858877-21-000018:notes:104]
[same as prior period, unchanged from 0000858877-21-000008:notes:101]

[0000858877-21-000018:notes:105]
Gross financing receivables(1) categorized by our internal credit risk rating by period of origination as of October 30, 2021 and July 31, 2021 are summarized as follows (in millions):

[0000858877-21-000018:notes:106]
|  |  |  | Fiscal Year |  | Three Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 28, 2018 |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | October 30, 2021 |  | Total |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 11 |  |  | $ | 75 |  |  | $ | 134 |  |  | $ | 204 |  |  | $ | 244 |  |  | $ | 58 |  |  | $ | 726 |  |
| 5 to 6 | 10 |  |  | 44 |  |  | 141 |  |  | 258 |  |  | 247 |  |  | 15 |  |  | 715 |  |
| 7 and Higher | 1 |  |  | 4 |  |  | 9 |  |  | 19 |  |  | 4 |  |  | 12 |  |  | 49 |  |
| Total Lease Receivables | $ | 22 |  |  | $ | 123 |  |  | $ | 284 |  |  | $ | 481 |  |  | $ | 495 |  |  | $ | 85 |  |  | $ | 1,490 |  |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 27 |  |  | $ | 108 |  |  | $ | 265 |  |  | $ | 733 |  |  | $ | 1,299 |  |  | $ | 503 |  |  | $ | 2,935 |  |
| 5 to 6 | 11 |  |  | 55 |  |  | 170 |  |  | 439 |  |  | 764 |  |  | 307 |  |  | 1,746 |  |
| 7 and Higher | 2 |  |  | 3 |  |  | 41 |  |  | 40 |  |  | 28 |  |  | 14 |  |  | 128 |  |
| Total Loan Receivables | $ | 40 |  |  | $ | 166 |  |  | $ | 476 |  |  | $ | 1,212 |  |  | $ | 2,091 |  |  | $ | 824 |  |  | $ | 4,809 |  |
| Financed Service Contracts: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 3 |  |  | $ | 20 |  |  | $ | 85 |  |  | $ | 189 |  |  | $ | 824 |  |  | $ | 334 |  |  | $ | 1,455 |  |
| 5 to 6 | 3 |  |  | 19 |  |  | 90 |  |  | 257 |  |  | 370 |  |  | 116 |  |  | 855 |  |
| 7 and Higher | — |  |  | 1 |  |  | 4 |  |  | 7 |  |  | 4 |  |  | 3 |  |  | 19 |  |
| Total Financed Service Contracts | $ | 6 |  |  | $ | 40 |  |  | $ | 179 |  |  | $ | 453 |  |  | $ | 1,198 |  |  | $ | 453 |  |  | $ | 2,329 |  |
| Total | $ | 68 |  |  | $ | 329 |  |  | $ | 939 |  |  | $ | 2,146 |  |  | $ | 3,784 |  |  | $ | 1,362 |  |  | $ | 8,628 |  |

[0000858877-21-000018:notes:107]
|  |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 29, 2017 |  | July 28, 2018 |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | Total |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 20 |  |  | $ | 100 |  |  | $ | 168 |  |  | $ | 282 |  |  | $ | 227 |  |  | $ | 799 |  |
| 5 to 6 | 1 |  |  | 17 |  |  | 65 |  |  | 187 |  |  | 285 |  |  | 231 |  |  | 786 |  |
| 7 and Higher | — |  |  | 2 |  |  | 6 |  |  | 12 |  |  | 23 |  |  | 4 |  |  | 47 |  |
| Total Lease Receivables | $ | 3 |  |  | $ | 39 |  |  | $ | 171 |  |  | $ | 367 |  |  | $ | 590 |  |  | $ | 462 |  |  | $ | 1,632 |  |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 4 |  |  | $ | 86 |  |  | $ | 134 |  |  | $ | 577 |  |  | $ | 990 |  |  | $ | 1,552 |  |  | $ | 3,343 |  |
| 5 to 6 | — |  |  | 19 |  |  | 75 |  |  | 202 |  |  | 505 |  |  | 925 |  |  | 1,726 |  |
| 7 and Higher | 1 |  |  | 2 |  |  | 4 |  |  | 50 |  |  | 43 |  |  | 34 |  |  | 134 |  |
| Total Loan Receivables | $ | 5 |  |  | $ | 107 |  |  | $ | 213 |  |  | $ | 829 |  |  | $ | 1,538 |  |  | $ | 2,511 |  |  | $ | 5,203 |  |
| Financed Service Contracts: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | — |  |  | $ | 38 |  |  | $ | 26 |  |  | $ | 106 |  |  | $ | 252 |  |  | $ | 1,053 |  |  | $ | 1,475 |  |
| 5 to 6 | — |  |  | 6 |  |  | 26 |  |  | 105 |  |  | 302 |  |  | 520 |  |  | 959 |  |
| 7 and Higher | — |  |  | — |  |  | 1 |  |  | 6 |  |  | 7 |  |  | 5 |  |  | 19 |  |
| Total Financed Service Contracts | $ | — |  |  | $ | 44 |  |  | $ | 53 |  |  | $ | 217 |  |  | $ | 561 |  |  | $ | 1,578 |  |  | $ | 2,453 |  |
| Total | $ | 8 |  |  | $ | 190 |  |  | $ | 437 |  |  | $ | 1,413 |  |  | $ | 2,689 |  |  | $ | 4,551 |  |  | $ | 9,288 |  |

[0000858877-21-000018:notes:108]
(1) Lease receivables calculated as gross lease receivables less unearned income.

[0000858877-21-000018:notes:109]
The following tables present the aging analysis of gross receivables as of October 30, 2021 and July 31, 2021 (in millions):

[0000858877-21-000018:notes:110]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| October 30, 2021 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 34 |  |  | $ | 12 |  |  | $ | 22 |  |  | $ | 68 |  |  | $ | 1,422 |  |  | $ | 1,490 |  |  | $ | 8 |  |  | $ | 24 |  |  | $ | 24 |  |
| Loan receivables | 77 |  |  | 17 |  |  | 27 |  |  | 121 |  |  | 4,688 |  |  | 4,809 |  |  | 6 |  |  | 29 |  |  | 29 |  |
| Financed service contracts | 21 |  |  | 39 |  |  | 18 |  |  | 78 |  |  | 2,251 |  |  | 2,329 |  |  | 4 |  |  | 3 |  |  | 3 |  |
| Total | $ | 132 |  |  | $ | 68 |  |  | $ | 67 |  |  | $ | 267 |  |  | $ | 8,361 |  |  | $ | 8,628 |  |  | $ | 18 |  |  | $ | 56 |  |  | $ | 56 |  |

[0000858877-21-000018:notes:111]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| July 31, 2021 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 21 |  |  | $ | 17 |  |  | $ | 29 |  |  | $ | 67 |  |  | $ | 1,565 |  |  | $ | 1,632 |  |  | $ | 1 |  |  | $ | 33 |  |  | $ | 26 |  |
| Loan receivables | 71 |  |  | 17 |  |  | 35 |  |  | 123 |  |  | 5,080 |  |  | 5,203 |  |  | 4 |  |  | 33 |  |  | 33 |  |
| Financed service contracts | 18 |  |  | 13 |  |  | 18 |  |  | 49 |  |  | 2,404 |  |  | 2,453 |  |  | 3 |  |  | 3 |  |  | 3 |  |
| Total | $ | 110 |  |  | $ | 47 |  |  | $ | 82 |  |  | $ | 239 |  |  | $ | 9,049 |  |  | $ | 9,288 |  |  | $ | 8 |  |  | $ | 69 |  |  | $ | 62 |  |

[0000858877-21-000018:notes:112]
[same as prior period, unchanged from 0000858877-21-000008:notes:110]

[0000858877-21-000018:notes:113]
[same as prior period, unchanged from 0000858877-21-000008:notes:112]

[0000858877-21-000018:notes:114]
[same as prior period, unchanged from 0000858877-21-000008:notes:113]

[0000858877-21-000018:notes:115]
| Three months ended October 30, 2021 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 31, 2021 | $ | 38 |  |  | $ | 86 |  |  | $ | 3 |  |  | $ | 127 |  |
| Provisions (benefits) | (5) |  |  | (12) |  |  | (1) |  |  | (18) |  |
| Allowance for credit loss as of October 30, 2021 | $ | 33 |  |  | $ | 74 |  |  | $ | 2 |  |  | $ | 109 |  |

[0000858877-21-000018:notes:116]
| Three months ended October 24, 2020 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 25, 2020 | $ | 48 |  |  | $ | 81 |  |  | $ | 9 |  |  | $ | 138 |  |
| Provisions (benefits) | (3) |  |  | 3 |  |  | (1) |  |  | (1) |  |
| Other | 1 |  |  | 17 |  |  | (1) |  |  | 17 |  |
| Allowance for credit loss as of October 24, 2020 | $ | 46 |  |  | $ | 101 |  |  | $ | 7 |  |  | $ | 154 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-21-000018:notes:117]
Available-for-Sale Debt and Equity Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-21-000018:notes:118]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-21-000018:notes:119]
| October 30, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,032 |  |  | $ | 12 |  |  | $ | (9) |  |  | $ | 2,035 |  |
| U.S. government agency securities | 142 |  |  | — |  |  | — |  |  | 142 |  |
| Corporate debt securities | 9,114 |  |  | 156 |  |  | (50) |  |  | 9,220 |  |
| U.S. agency mortgage-backed securities | 2,790 |  |  | 24 |  |  | (21) |  |  | 2,793 |  |
| Commercial paper | 1,054 |  |  | — |  |  | — |  |  | 1,054 |  |
| Certificates of deposit | 269 |  |  | — |  |  | — |  |  | 269 |  |
| Total | $ | 15,401 |  |  | $ | 192 |  |  | $ | (80) |  |  | $ | 15,513 |  |

[0000858877-21-000018:notes:120]
| July 31, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,773 |  |  | $ | 21 |  |  | $ | — |  |  | $ | 1,794 |  |
| U.S. government agency securities | 152 |  |  | — |  |  | — |  |  | 152 |  |
| Non-U.S. government and agency securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Corporate debt securities | 8,727 |  |  | 213 |  |  | (30) |  |  | 8,910 |  |
| U.S. agency mortgage-backed securities | 2,838 |  |  | 34 |  |  | (10) |  |  | 2,862 |  |
| Commercial paper | 1,190 |  |  | — |  |  | — |  |  | 1,190 |  |
| Certificates of deposit | 295 |  |  | — |  |  | — |  |  | 295 |  |
| Total | $ | 14,978 |  |  | $ | 268 |  |  | $ | (40) |  |  | $ | 15,206 |  |

[0000858877-21-000018:notes:121]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-21-000018:notes:122]
|  | Three Months Ended |
|  | October 30, 2021 |  | October 24, 2020 |
| Gross realized gains | $ | 6 |  |  | $ | 15 |  |
| Gross realized losses | — |  |  | — |  |
| Total | $ | 6 |  |  | $ | 15 |  |

[0000858877-21-000018:notes:123]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 30, 2021 and July 31, 2021 (in millions):

[0000858877-21-000018:notes:124]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 30, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,341 |  |  | $ | (9) |  |  | $ | 2 |  |  | $ | — |  |  | $ | 1,343 |  |  | $ | (9) |  |
| U.S. government agency securities | 100 |  |  | — |  |  | — |  |  | — |  |  | 100 |  |  | — |  |
| Corporate debt securities | 3,204 |  |  | (24) |  |  | 27 |  |  | (1) |  |  | 3,231 |  |  | (25) |  |
| U.S. agency mortgage-backed securities | 1,937 |  |  | (20) |  |  | 52 |  |  | (1) |  |  | 1,989 |  |  | (21) |  |
| Commercial paper | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |  | — |  |
| Total | $ | 6,607 |  |  | $ | (53) |  |  | $ | 81 |  |  | $ | (2) |  |  | $ | 6,688 |  |  | $ | (55) |  |

[0000858877-21-000018:notes:125]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 31, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 468 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 468 |  |  | $ | — |  |
| U.S. government agency securities | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |
| Corporate debt securities | 1,086 |  |  | (5) |  |  | 6 |  |  | — |  |  | 1,092 |  |  | (5) |  |
| U.S. agency mortgage-backed securities | 1,293 |  |  | (10) |  |  | 13 |  |  | — |  |  | 1,306 |  |  | (10) |  |
| Commercial paper | 37 |  |  | — |  |  | — |  |  | — |  |  | 37 |  |  | — |  |
| Total | $ | 2,910 |  |  | $ | (15) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 2,929 |  |  | $ | (15) |  |

[0000858877-21-000018:notes:126]
The following table summarizes the maturities of our available-for-sale debt investments as of October 30, 2021 (in millions):

[0000858877-21-000018:notes:127]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 4,291 |  |  | $ | 4,281 |  |
| After 1 year through 5 years | 8,013 |  |  | 8,106 |  |
| After 5 years through 10 years | 301 |  |  | 326 |  |
| After 10 years | 6 |  |  | 7 |  |
| Mortgage-backed securities with no single maturity | 2,790 |  |  | 2,793 |  |
| Total | $ | 15,401 |  |  | $ | 15,513 |  |

[0000858877-21-000018:notes:128]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-21-000018:notes:129]
(b)Summary of Equity Investments

[0000858877-21-000018:notes:130]
We recognized a net unrealized gain of $5 million during the first quarter of fiscal 2022 on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $2 million for the first quarter of fiscal 2022. We held equity interests in certain private equity funds of $1.0 billion and $0.9 billion as of October 30, 2021 and July 31, 2021, respectively, which are accounted for under the NAV practical expedient.

[0000858877-21-000018:notes:131]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 30, 2021, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-21-000018:notes:132]
The carrying value of our investments in privately held companies was $1.7 billion and $1.5 billion as of October 30, 2021 and July 31, 2021, respectively. Of the total carrying value of our investments in privately held companies as of October 30, 2021, $1.0 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of October 30, 2021, we have total funding commitments of $0.2 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-21-000018:notes:133]
[same as prior period, unchanged from 0000858877-21-000008:notes:135]

[0000858877-21-000018:notes:134]
[same as prior period, unchanged from 0000858877-21-000008:notes:136]

[0000858877-21-000018:notes:135]
[same as prior period, unchanged from 0000858877-21-000008:notes:137]

[0000858877-21-000018:notes:136]
[same as prior period, unchanged from 0000858877-21-000008:notes:138]

[0000858877-21-000018:notes:137]
[same as prior period, unchanged from 0000858877-21-000008:notes:139]

[0000858877-21-000018:notes:138]
[same as prior period, unchanged from 0000858877-21-000008:notes:140]

[0000858877-21-000018:notes:139]
[same as prior period, unchanged from 0000858877-21-000008:notes:141]

[0000858877-21-000018:notes:140]
[same as prior period, unchanged from 0000858877-21-000008:notes:142]

[0000858877-21-000018:notes:141]
|  | OCTOBER 30, 2021 |  | JULY 31, 2021 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,351 |  |  | $ | — |  |  | $ | 4,351 |  |  | $ | 5,694 |  |  | $ | — |  |  | $ | 5,694 |  |
| Commercial paper | — |  |  | 10 |  |  | 10 |  |  | — |  |  | 114 |  |  | 114 |  |
| Certificates of deposit | — |  |  | 27 |  |  | 27 |  |  | — |  |  | — |  |  | — |  |
| U.S. government securities | — |  |  | — |  |  | — |  |  | — |  |  | 300 |  |  | 300 |  |
| Corporate debt securities | — |  |  | 41 |  |  | 41 |  |  | — |  |  | — |  |  | — |  |
| Non-U.S. government and agency securities | — |  |  | 30 |  |  | 30 |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 2,035 |  |  | 2,035 |  |  | — |  |  | 1,794 |  |  | 1,794 |  |
| U.S. government agency securities | — |  |  | 142 |  |  | 142 |  |  | — |  |  | 152 |  |  | 152 |  |
| Corporate debt securities | — |  |  | 9,220 |  |  | 9,220 |  |  | — |  |  | 8,910 |  |  | 8,910 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,793 |  |  | 2,793 |  |  | — |  |  | 2,862 |  |  | 2,862 |  |
| Non-U.S. government and agency securities | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | 3 |  |
| Commercial paper | — |  |  | 1,054 |  |  | 1,054 |  |  | — |  |  | 1,190 |  |  | 1,190 |  |
| Certificates of deposit | — |  |  | 269 |  |  | 269 |  |  | — |  |  | 295 |  |  | 295 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 214 |  |  | — |  |  | 214 |  |  | 137 |  |  | — |  |  | 137 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 750 |  |  | — |  |  | 750 |  |  | 750 |  |  | — |  |  | 750 |  |
| Derivative assets | — |  |  | 116 |  |  | 116 |  |  | — |  |  | 126 |  |  | 126 |  |
| Total | $ | 5,315 |  |  | $ | 15,737 |  |  | $ | 21,052 |  |  | $ | 6,581 |  |  | $ | 15,746 |  |  | $ | 22,327 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 33 |  |  | $ | 33 |  |  | $ | — |  |  | $ | 20 |  |  | $ | 20 |  |
| Total | $ | — |  |  | $ | 33 |  |  | $ | 33 |  |  | $ | — |  |  | $ | 20 |  |  | $ | 20 |  |

[0000858877-21-000018:notes:142]
Level 1 marketable securities are determined by using quoted prices in active markets for identical assets. Level 2 available-for-sale debt investments are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of these assets and liabilities. We use such pricing data as the primary input to make our assessments and determinations as to the ultimate valuation of our investment portfolio and have not made, during the periods presented, any material adjustments to such inputs. We are ultimately responsible for the financial statements and underlying estimates. Our derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs. We did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.

[0000858877-21-000018:notes:143]
[same as prior period, unchanged from 0000858877-21-000008:notes:145]

[0000858877-21-000018:notes:144]
Our non-marketable equity securities using the measurement alternative are adjusted to fair value on a non-recurring basis. Adjustments are made when observable transactions for identical or similar investments of the same issuer occur, or due to impairment. These securities are classified as Level 3 in the fair value hierarchy because we estimate the value based on

[0000858877-21-000018:notes:145]
valuation methods using the observable transaction price at the transaction date and other unobservable inputs such as volatility, rights, and obligations of the securities we hold.

[0000858877-21-000018:notes:146]
[same as prior period, unchanged from 0000858877-21-000008:notes:147]

[0000858877-21-000018:notes:147]
The fair value of our short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables and financed service contracts as of October 30, 2021 and July 31, 2021 was $3.7 billion and $4.0 billion, respectively. The estimated fair value of our long-term loan receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.
As of October 30, 2021, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of October 30, 2021, the fair value of our senior notes was $11.5 billion with a carrying amount of $9.5 billion. This compares to a fair value of $13.7 billion and a carrying amount of $11.5 billion as of July 31, 2021. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:DebtDisclosureTextBlock

[0000858877-21-000018:notes:148]
Borrowings 
(a)Short-Term Debt

[0000858877-21-000018:notes:149]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-21-000018:notes:150]
|  | October 30, 2021 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 506 |  |  | 1.13 | % |  | $ | 2,508 |  |  | 1.75 | % |

[0000858877-21-000018:notes:151]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of October 30, 2021 and July 31, 2021.

[0000858877-21-000018:notes:152]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-21-000018:notes:153]
(b)Long-Term Debt

[0000858877-21-000018:notes:154]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-21-000018:notes:155]
|  |  |  | October 30, 2021 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.13% |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 0.97% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.29% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,500 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (78) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 80 |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 9,502 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 506 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,996 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 9,502 |  |  |  |  | $ | 11,526 |  |  |  |

[0000858877-21-000018:notes:156]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $2.0 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (“LIBOR”). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-21-000018:notes:157]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 30, 2021, we were in compliance with all debt covenants.

[0000858877-21-000018:notes:158]
As of October 30, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-21-000018:notes:159]
| Fiscal Year | Amount |
| 2022 (remaining nine months) | $ | 500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 9,500 |  |

[0000858877-21-000018:notes:160]
(c)Credit Facility

[0000858877-21-000018:notes:161]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. The credit agreement is structured as an amendment and restatement of our 364-day credit agreement, which would have terminated on May 14, 2021. As of October 30, 2021, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.

[0000858877-21-000018:notes:162]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-21-000018:notes:163]
[same as prior period, unchanged from 0000858877-21-000008:notes:164]

[0000858877-21-000018:notes:164]
[same as prior period, unchanged from 0000858877-21-000008:notes:165]

[0000858877-21-000018:notes:165]
[same as prior period, unchanged from 0000858877-21-000008:notes:166]

[0000858877-21-000018:notes:166]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | October 30,2021 |  | July 31,2021 |  | Balance Sheet Line Item |  | October 30,2021 |  | July 31,2021 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 21 |  |  | $ | 14 |  |  | Other current liabilities |  | $ | 7 |  |  | $ | 3 |  |
| Foreign currency derivatives | Other assets |  | 4 |  |  | 1 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other current assets |  | 6 |  |  | 9 |  |  | Other current liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other assets |  | 75 |  |  | 99 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 106 |  |  | 123 |  |  |  |  | 7 |  |  | 3 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 10 |  |  | 3 |  |  | Other current liabilities |  | 22 |  |  | 16 |  |
| Foreign currency derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 4 |  |  | 1 |  |
| Total |  |  | 10 |  |  | 3 |  |  |  |  | 26 |  |  | 17 |  |
| Total |  |  | $ | 116 |  |  | $ | 126 |  |  |  |  | $ | 33 |  |  | $ | 20 |  |

[0000858877-21-000018:notes:167]
[same as prior period, unchanged from 0000858877-21-000008:notes:168]

[0000858877-21-000018:notes:168]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | October 30,2021 |  | July 31,2021 |  | October 30,2021 |  | July 31,2021 |
| Short-term debt |  | $ | (506) |  |  | $ | (508) |  |  | $ | (6) |  |  | $ | (9) |  |
| Long-term debt |  | $ | (1,571) |  |  | $ | (1,594) |  |  | $ | (74) |  |  | $ | (97) |  |

[0000858877-21-000018:notes:169]
[same as prior period, unchanged from 0000858877-21-000008:notes:170]

[0000858877-21-000018:notes:170]
|  |  | Three Months Ended |
|  |  | October 30, 2021 |  | October 24, 2020 |
| Interest rate derivatives: |  |  |  |  |
| Hedged items |  | $ | 26 |  |  | $ | 19 |  |
| Derivatives designated as hedging instruments |  | (27) |  |  | (20) |  |
| Total |  | $ | (1) |  |  | $ | (1) |  |

[0000858877-21-000018:notes:171]
[same as prior period, unchanged from 0000858877-21-000008:notes:172]

[0000858877-21-000018:notes:172]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | October 30,2021 |  | October 24,2020 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (20) |  |  | $ | 14 |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | 21 |  |  | 23 |  |
| Equity derivatives |  | Other income (loss), net |  | 4 |  |  | 5 |  |
| Total |  |  |  | $ | 5 |  |  | $ | 42 |  |

[0000858877-21-000018:notes:173]
[same as prior period, unchanged from 0000858877-21-000008:notes:174]

[0000858877-21-000018:notes:174]
|  | October 30,2021 |  | July 31,2021 |
| Foreign currency derivatives | $ | 4,778 |  |  | $ | 4,139 |  |
| Interest rate derivatives | 2,000 |  |  | 2,000 |  |
| Total return swaps—deferred compensation | 778 |  |  | 730 |  |
| Total | $ | 7,556 |  |  | $ | 6,869 |  |

[0000858877-21-000018:notes:175]
[same as prior period, unchanged from 0000858877-21-000008:notes:176]

[0000858877-21-000018:notes:176]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty. As of October 30, 2021 and July 31, 2021, the potential effects of these rights of set-off associated with the derivative contracts would be a reduction to both derivative assets and derivative liabilities of $32 million and $17 million, respectively.

[0000858877-21-000018:notes:177]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral received as of October 30, 2021 and July 31, 2021 was $82 million and $109 million, respectively. Including the effects of collateral, this results in a net derivative asset of $1 million and a net derivative liability of $3 million as of October 30, 2021 and July 31, 2021, respectively.

[0000858877-21-000018:notes:178]
[same as prior period, unchanged from 0000858877-21-000008:notes:179]

[0000858877-21-000018:notes:179]
[same as prior period, unchanged from 0000858877-21-000008:notes:180]

[0000858877-21-000018:notes:180]
[same as prior period, unchanged from 0000858877-21-000008:notes:181]

[0000858877-21-000018:notes:181]
We enter into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, long-term customer financings and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of intercompany balances, other current assets, or liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-21-000018:notes:182]
[same as prior period, unchanged from 0000858877-21-000008:notes:183]

[0000858877-21-000018:notes:183]
[same as prior period, unchanged from 0000858877-21-000008:notes:184]

[0000858877-21-000018:notes:184]
We hold interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2022 through 2025. Under these interest rate swaps, we receive fixed-rate interest payments and make interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.

[0000858877-21-000018:notes:185]
[same as prior period, unchanged from 0000858877-21-000008:notes:186]

[0000858877-21-000018:notes:186]
[same as prior period, unchanged from 0000858877-21-000008:notes:187]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-21-000018:notes:187]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-21-000018:notes:188]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-21-000018:notes:189]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-21-000018:notes:190]
|  | October 30,2021 |  | July 31,2021 |
| Less than 1 year | $ | 7,621 |  |  | $ | 6,903 |  |
| 1 to 3 years | 2,072 |  |  | 1,806 |  |
| 3 to 5 years | 1,359 |  |  | 1,545 |  |
| Total | $ | 11,052 |  |  | $ | 10,254 |  |

[0000858877-21-000018:notes:191]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 30, 2021 and July 31, 2021, the liability for these purchase commitments was $179 million and $151 million, respectively, and was included in other current liabilities. For further discussion around the Supply Constraints Impacts and Risks, see Result of Operations—Product Gross Margin and Liquidity and Capital Resources—Inventory Supply Chain.

[0000858877-21-000018:notes:192]
(b)Other Commitments

[0000858877-21-000018:notes:193]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-21-000018:notes:194]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-21-000018:notes:195]
|  | Three Months Ended |
|  | October 30, 2021 |  | October 24, 2020 |
| Compensation expense related to acquisitions | $ | 89 |  |  | $ | 57 |  |

[0000858877-21-000018:notes:196]
As of October 30, 2021, we estimated that future cash compensation expense of up to $673 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-21-000018:notes:197]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.2 billion as of each of October 30, 2021 and July 31, 2021.

[0000858877-21-000018:notes:198]
(c)Product Warranties

[0000858877-21-000018:notes:199]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-21-000018:notes:200]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |
| Balance at beginning of period | $ | 336 |  |  | $ | 331 |  |
| Provisions for warranties issued | 114 |  |  | 121 |  |
| Adjustments for pre-existing warranties | 2 |  |  | 1 |  |
| Settlements | (111) |  |  | (122) |  |
| Balance at end of period | $ | 341 |  |  | $ | 331 |  |

[0000858877-21-000018:notes:201]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-21-000018:notes:202]
(d)Financing and Other Guarantees

[0000858877-21-000018:notes:203]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-21-000018:notes:204]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.6 billion and $6.1 billion for the first quarter of fiscal 2022 and 2021, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion as of each of October 30, 2021 and July 31, 2021.

[0000858877-21-000018:notes:205]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $2 million and $5 million for the first quarter of fiscal 2022 and 2021, respectively.

[0000858877-21-000018:notes:206]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 30, 2021 and July 31, 2021, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-21-000018:notes:207]
|  | October 30,2021 |  | July 31,2021 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 197 |  |  | $ | 155 |  |
| End user | 4 |  |  | 5 |  |
| Total | $ | 201 |  |  | $ | 160 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (5) |  |  | $ | (16) |  |
| End user | (4) |  |  | (5) |  |
| Total | $ | (9) |  |  | $ | (21) |  |
| Total | $ | 192 |  |  | $ | 139 |  |

[0000858877-21-000018:notes:208]
(e)Indemnifications

[0000858877-21-000018:notes:209]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-21-000018:notes:210]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations discussed in this section (e) due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these cases, and the unique facts and circumstances involved in each particular case and agreement. We are unable to reasonably estimate the ultimate outcome of the cases discussed below in this section (e), but we do not believe that any potential indemnity liability would be material, and historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-21-000018:notes:211]
We were asked by seven of our customers to indemnify them in connection with patent infringement claims asserted against them by Estech Systems, Inc. (“Estech”) in the Eastern District of Texas (“E.D. Tex.”) court and the Western District of Texas  (“W.D. Tex.”) court between April 24, 2020 and August 25, 2020. Estech alleged that the customer defendants infringe three patents generally related to IP telephony by using collaboration technology from us and other providers. Estech was seeking monetary damages from the customer defendants. Estech and the customer defendants resolved Estech’s claims, and we resolved the customer defendants’ indemnity claims for an amount that did not have a material effect on our Consolidated Financial Statements.

[0000858877-21-000018:notes:212]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-21-000018:notes:213]
(f)Legal Proceedings

[0000858877-21-000018:notes:214]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $144 million for the alleged evasion of import and other taxes, $719 million for interest, and $355 million for various penalties, all determined using an exchange rate as of October 30, 2021.

[0000858877-21-000018:notes:215]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-21-000018:notes:216]
China     We are investigating allegations of a self-enrichment scheme involving now-former employees in China. Some of those employees are also alleged to have made or directed payments from the funds they received to various third parties, including employees of state-owned enterprises. We voluntarily disclosed this investigation to the Department of Justice (“DOJ”) and Securities and Exchange Commission (“SEC”). We take such allegations very seriously and we are providing results of our investigation to the DOJ and SEC. While the outcome of our investigation is currently not determinable, we do not expect that it will have a material adverse effect on our Consolidated Financial Statements.

[0000858877-21-000018:notes:217]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted claims against us in the U.S. District Court for the District of Delaware (“D. Del.”), accusing our products and services in the area of network intrusion detection of infringing two patents. On May 12, 2016, a jury returned a verdict finding willful infringement. The jury awarded SRI damages of $24 million. On May 25, 2017, the district court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit (“Federal Circuit”), and on July 12, 2019, the Federal Circuit vacated the enhanced damages award; vacated and remanded in part the willful infringement finding; vacated and remanded the attorneys’ fees award for further proceedings; and affirmed the district court’s other findings. Cisco paid SRI $28 million, representing the portion of the judgment that the Federal Circuit affirmed, plus interest and royalties on post-verdict sales.

[0000858877-21-000018:notes:218]
On April 1, 2020, the district court issued a final judgment on the remanded issues, finding no evidence of willful infringement and reinstating the $8 million award of attorneys’ fees. In a second round of appeals to the Federal Circuit in April 2020, SRI appealed the judgment of no willful infringement, and Cisco filed a cross-appeal on the attorneys’ fees award. On September 28, 2021, the Federal Circuit reversed the district court’s denial of SRI’s motion to reinstate the willfulness verdict, restored the district court’s award of enhanced damages, and affirmed the district court’s award of attorney fees. We intend to seek review of the Federal Circuit’s decision. While the remaining proceedings may result in an additional loss, we do not believe it would have a material effect on our Consolidated Financial Statements.

[0000858877-21-000018:notes:219]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal U.S. patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (PTAB) of the United States Patent and Trademark Office (“PTO”) to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal appealed the PTAB’s findings of unpatentability to the Federal Circuit. The Federal Circuit affirmed the PTAB’s findings of unpatentability as to three of the patents on March 10, 2021, and affirmed the PTAB’s findings of unpatentability as to the remaining four patents on May 11, 2021. On August 9, 2021, Centripetal filed a writ of certiorari seeking review of the Federal Circuit’s affirmance of several of the PTAB’s unpatentability findings, which the U.S. Supreme Court denied on October 4, 2021.

[0000858877-21-000018:notes:220]
For the five asserted U.S. patents not subject to the IPR Proceedings, the district court conducted a bench trial by videoconference from May 6, 2020 to June 25, 2020. On October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The district court awarded

[0000858877-21-000018:notes:221]
Centripetal $1.9 billion, comprised of $756 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $14 million. The district court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $168 million and a maximum annual royalty of $300 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $84 million and a maximum annual royalty of $150 million. We believe that the district court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We have appealed the district court’s judgment as to the four patents found valid and infringed to the Federal Circuit. On October 28, 2020, by agreement of the parties, the district court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment.

[0000858877-21-000018:notes:222]
On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. district court proceedings, one of which has been invalidated by the PTAB. On June 22, 2021, Centripetal amended one of its complaints to assert one additional European patent and one additional German Utility Model patent. Centripetal seeks both injunctive relief and damages on these newly added patents. We believe we have strong defenses.

[0000858877-21-000018:notes:223]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of either litigation at this time. If we do not prevail in either litigation, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-21-000018:notes:224]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in E.D. Tex., seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. As of November 27, 2020, the PTO preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings. On January 13, 2021, the court entered an order staying the case pending the conclusion of the ex parte reexamination proceedings (“Reexamination Proceedings”). While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in court, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-21-000018:notes:225]
On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) (which we subsequently acquired) in D. Del, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot has asserted in its E.D. Tex. case. On September 3, 2021, the court stayed the case pending the ultimate resolution of the Reexamination Proceedings. Due to the early stage of the litigation as well as uncertainties in the litigation processes, we are unable, at this time, to reasonably estimate a potential range of loss, if any, or the ultimate outcome of this litigation.

[0000858877-21-000018:notes:226]
Viasat     On January 21, 2016, Viasat, Inc. (“Viasat”) filed suit against Acacia (which we subsequently acquired) in the California Superior Court for San Diego County (“SDSC”) seeking unpaid royalties for breach of contract and the implied covenant of good faith and fair dealing, and damages for trade secret misappropriation for certain products (“Viasat 1”). Acacia counterclaimed for patent and trade secret misappropriation, contract, and unfair competition claims. On July 17, 2019, the jury found for Viasat on its contract claims, and awarded Viasat $49 million for unpaid royalties through 2018. The jury further found that Acacia willfully misappropriated Viasat’s trade secrets and awarded Viasat $1. On Acacia’s counterclaims, the jury found for Acacia on its contract and trade secret claims and awarded Acacia $1. Both Acacia and Viasat have pending appeals to the California Court of Appeal. On November 6, 2019, Viasat filed a second suit in SDSC, alleging contract and trade secret claims for Acacia products sold from January 1, 2019 forward (“Viasat 2”). On February 28, 2020, the court stayed Viasat 2 pending the appeal in Viasat 1. On June 9, 2020, Viasat filed a third suit in SDSC (“Viasat 3”). In Viasat 3, Viasat alleges contract and trade secrets claims for sales of additional Acacia products. On August 11, 2020, the court stayed Viasat 3 pending the appeal in Viasat 1.

[0000858877-21-000018:notes:227]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court - Business Litigation Session against ViaSat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation. On April 5, 2018, ViaSat counterclaimed with contract, trade secret, and unfair competition claims (collectively, with Viasat 1, Viasat 2 and Viasat 3, the “Viasat Cases”). On December 13, 2018, the Massachusetts court entered an order staying the Massachusetts litigation, which has been extended to December 31, 2021.
While we believe Acacia has strong defenses in each of the Viasat Cases, we are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If Acacia does not prevail, we believe that any relief ultimately assessed in any of the Viasat Cases would not have a material effect on our Consolidated Financial Statements.In addition, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-21-000018:notes:228]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-21-000018:notes:229]
[same as prior period, unchanged from 0000858877-21-000008:notes:235]

[0000858877-21-000018:notes:230]
We declared and paid cash dividends of $0.37 and $0.36 per common share, or $1.6 billion and $1.5 billion, on our outstanding common stock for the first quarter of fiscal 2022 and 2021, respectively.

[0000858877-21-000018:notes:231]
[same as prior period, unchanged from 0000858877-21-000008:notes:237]

[0000858877-21-000018:notes:232]
[same as prior period, unchanged from 0000858877-21-000008:notes:238]

[0000858877-21-000018:notes:233]
In September 2001, our Board of Directors authorized a stock repurchase program. As of October 30, 2021, the remaining authorized amount for stock repurchases under this program was approximately $7.7 billion with no termination date. A summary of the stock repurchase activity for fiscal 2022 and 2021 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-21-000018:notes:234]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2022 |  |  |  |  |  |  |
| October 30, 2021 |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |
| Fiscal 2021 |  |  |  |  |  |  |
| July 31, 2021 |  | 15 |  |  | $ | 53.30 |  |  | $ | 791 |  |
| May 1, 2021 |  | 10 |  |  | $ | 48.71 |  |  | $ | 510 |  |
| January 23, 2021 |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |
| October 24, 2020 |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |

[0000858877-21-000018:notes:235]
There were stock repurchases of $8 million and $25 million that were pending settlement as of October 30, 2021 and July 31, 2021, respectively.

[0000858877-21-000018:notes:236]
[same as prior period, unchanged from 0000858877-21-000008:notes:242]

[0000858877-21-000018:notes:237]
[same as prior period, unchanged from 0000858877-21-000008:notes:243]

[0000858877-21-000018:notes:238]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock of one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights of such series, and any qualification, limitations or restrictions thereof, of the shares of such series. As of October 30, 2021, we had not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-21-000018:notes:239]
[same as prior period, unchanged from 0000858877-21-000008:notes:245]

[0000858877-21-000018:notes:240]
[same as prior period, unchanged from 0000858877-21-000008:notes:246]

[0000858877-21-000018:notes:241]
2005 Plan    The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions. Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. As of October 30, 2021, the maximum number of shares issuable under the 2005 Plan over its term was 790 million shares. The 2005 Plan may be terminated by our Board of Directors at any time and for any reason, and is currently set to terminate at the 2030 Annual Meeting unless re-adopted or extended by our stockholders prior to or on such date.

[0000858877-21-000018:notes:242]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of October 30, 2021, 241 million shares were authorized for future grant under the 2005 Plan.

[0000858877-21-000018:notes:243]
[same as prior period, unchanged from 0000858877-21-000008:notes:249]

[0000858877-21-000018:notes:244]
We have an Employee Stock Purchase Plan under which 721 million shares of our common stock have been reserved for issuance as of October 30, 2021. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. No shares were issued under the Employee Stock Purchase Plan during each of the first quarters of fiscal 2022 and 2021. As of October 30, 2021, 125 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-21-000018:notes:245]
[same as prior period, unchanged from 0000858877-21-000008:notes:251]

[0000858877-21-000018:notes:246]
Share-based compensation expense consists primarily of expenses for RSUs, stock purchase rights, and stock options, granted to employees or assumed from acquisitions. The following table summarizes share-based compensation expense (in millions):

[0000858877-21-000018:notes:247]
|  | Three Months Ended |
|  | October 30, 2021 |  | October 24, 2020 |
| Cost of sales—product | $ | 25 |  |  | $ | 24 |  |
| Cost of sales—service | 44 |  |  | 41 |  |
| Share-based compensation expense in cost of sales | 69 |  |  | 65 |  |
| Research and development | 181 |  |  | 167 |  |
| Sales and marketing | 140 |  |  | 134 |  |
| General and administrative | 62 |  |  | 61 |  |
| Restructuring and other charges | 1 |  |  | 11 |  |
| Share-based compensation expense in operating expenses | 384 |  |  | 373 |  |
| Total share-based compensation expense | $ | 453 |  |  | $ | 438 |  |
| Income tax benefit for share-based compensation | $ | 104 |  |  | $ | 81 |  |

[0000858877-21-000018:notes:248]
As of October 30, 2021, the total compensation cost related to unvested share-based awards not yet recognized was $3.7 billion which is expected to be recognized over approximately 2.6 years on a weighted-average basis.

[0000858877-21-000018:notes:249]
(d)Restricted Stock Unit Awards

[0000858877-21-000018:notes:250]
[same as prior period, unchanged from 0000858877-21-000008:notes:256]

[0000858877-21-000018:notes:251]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| Unvested balance at July 25, 2020 | 96 |  |  | $ | 42.03 |  |  |  |
| Granted and assumed | 51 |  |  | 41.89 |  |  |  |
| Vested | (39) |  |  | 39.63 |  |  | $ | 1,813 |  |
| Canceled/forfeited/other | (14) |  |  | 42.13 |  |  |  |
| Unvested balance at July 31, 2021 | 94 |  |  | 42.93 |  |  |  |
| Granted and assumed | 8 |  |  | 54.37 |  |  |  |
| Vested | (8) |  |  | 41.84 |  |  | $ | 393 |  |
| Canceled/forfeited/other | (3) |  |  | 43.51 |  |  |  |
| Unvested balance at October 30, 2021 | 91 |  |  | $ | 43.99 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-21-000018:notes:252]
Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first quarter of fiscal 2022 and 2021 are summarized as follows (in millions):

[0000858877-21-000018:notes:253]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 31, 2021 | $ | 182 |  |  | $ | (1) |  |  | $ | (598) |  |  | $ | (417) |  |
| Other comprehensive income (loss) before reclassifications | (111) |  |  | 8 |  |  | 16 |  |  | (87) |  |
| (Gains) losses reclassified out of AOCI | (6) |  |  | (1) |  |  | — |  |  | (7) |  |
| Tax benefit (expense) | 30 |  |  | (1) |  |  | 9 |  |  | 38 |  |
| Balance at October 30, 2021 | $ | 95 |  |  | $ | 5 |  |  | $ | (573) |  |  | $ | (473) |  |

[0000858877-21-000018:notes:254]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 25, 2020 | $ | 315 |  |  | $ | (6) |  |  | $ | (828) |  |  | $ | (519) |  |
| Other comprehensive income (loss) before reclassifications | (41) |  |  | (2) |  |  | 110 |  |  | 67 |  |
| (Gains) losses reclassified out of AOCI | (15) |  |  | (2) |  |  | — |  |  | (17) |  |
| Tax benefit (expense) | 22 |  |  | 1 |  |  | (1) |  |  | 22 |  |
| Balance at October 24, 2020 | $ | 281 |  |  | $ | (9) |  |  | $ | (719) |  |  | $ | (447) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-21-000018:notes:255]
[same as prior period, unchanged from 0000858877-21-000008:notes:261]

[0000858877-21-000018:notes:256]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |
| Income before provision for income taxes | $ | 3,657 |  |  | $ | 2,681 |  |
| Provision for income taxes | $ | 677 |  |  | $ | 507 |  |
| Effective tax rate | 18.5 | % |  | 18.9 | % |

[0000858877-21-000018:notes:257]
As of October 30, 2021, we had $3.1 billion of unrecognized tax benefits, of which $2.3 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-21-000018:notes:258]
[same as prior period, unchanged from 0000858877-21-000008:notes:264]

[0000858877-21-000018:notes:259]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-21-000018:notes:260]
Summarized financial information by segment for the first quarter of fiscal 2022 and 2021, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-21-000018:notes:261]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |
| Revenue: |  |  |  |
| Americas | $ | 7,561 |  |  | $ | 7,198 |  |
| EMEA | 3,303 |  |  | 2,964 |  |
| APJC | 2,036 |  |  | 1,767 |  |
| Total | $ | 12,900 |  |  | $ | 11,929 |  |
| Gross margin: |  |  |  |
| Americas | $ | 4,875 |  |  | $ | 4,847 |  |
| EMEA | 2,128 |  |  | 1,894 |  |
| APJC | 1,317 |  |  | 1,113 |  |
| Segment total | 8,321 |  |  | 7,853 |  |
| Unallocated corporate items | (268) |  |  | (272) |  |
| Total | $ | 8,053 |  |  | $ | 7,581 |  |

[0000858877-21-000018:notes:262]
[same as prior period, unchanged from 0000858877-21-000008:notes:268]

[0000858877-21-000018:notes:263]
Revenue in the United States was $6.8 billion and $6.5 billion for the first quarter of fiscal 2022 and 2021, respectively.

[0000858877-21-000018:notes:264]
[same as prior period, unchanged from 0000858877-21-000008:notes:270]

[0000858877-21-000018:notes:265]
We design and sell Internet Protocol (IP)-based networking and other products related to the communications and IT industry and provide services associated with these products and their use. Effective in the first quarter of fiscal 2022, we began reporting our product and service revenue in the following categories: Secure, Agile Networks; Hybrid Work; End-to-End Security; Internet for the Future; Optimized Application Experiences; Other Products; and Services. This change will better align our product categories with our strategic priorities.


## us-gaap:EarningsPerShareTextBlock

[0000858877-21-000018:notes:266]
[same as prior period, unchanged from 0000858877-21-000008:notes:272]

[0000858877-21-000018:notes:267]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |
| Net income | $ | 2,980 |  |  | $ | 2,174 |  |
| Weighted-average shares—basic | 4,218 |  |  | 4,230 |  |
| Effect of dilutive potential common shares | 25 |  |  | 14 |  |
| Weighted-average shares—diluted | 4,243 |  |  | 4,244 |  |
| Net income per share—basic | $ | 0.71 |  |  | $ | 0.51 |  |
| Net income per share—diluted | $ | 0.70 |  |  | $ | 0.51 |  |
| Antidilutive employee share-based awards, excluded | 12 |  |  | 35 |  |

[0000858877-21-000018:notes:268]
[same as prior period, unchanged from 0000858877-21-000008:notes:274]
