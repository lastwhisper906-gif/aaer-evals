# CSCO 8-K — 0001193125-21-332467 filed 2021-11-17

## item codes, every 8-K on or before 2021-11-23

- 2021-11-17 0001193125-21-332467 — 2.02, 9.01
- 2021-09-27 0001193125-21-284199 — 8.01
- 2021-08-18 0001193125-21-250360 — 2.02, 9.01
- 2021-06-29 0001193125-21-203324 — 8.01
- 2021-05-19 0001193125-21-166614 — 2.02, 9.01
- 2021-05-14 0001193125-21-162081 — 1.01, 2.03, 9.01
- 2021-03-08 0001193125-21-073328 — 5.02
- 2021-02-25 0001193125-21-056977 — 5.02
- 2021-02-09 0001193125-21-034339 — 2.02, 9.01
- 2021-01-07 0001193125-21-004250 — 5.02
- 2020-12-17 0001193125-20-320092 — 5.02, 8.01
- 2020-12-11 0001193125-20-315999 — 5.02, 5.07, 9.01
- 2020-11-30 0001193125-20-305352 — 5.02
- 2020-11-13 0001193125-20-293020 — 5.02, 9.01
- 2020-11-12 0001193125-20-291658 — 2.02, 9.01
- 2020-10-09 0001193125-20-267248 — 5.03, 9.01
- 2020-09-23 0001193125-20-252356 — 8.01
- 2020-08-12 0001193125-20-217756 — 5.02
- 2020-08-12 0001193125-20-217658 — 2.02, 2.05, 9.01
- 2020-06-22 0001193125-20-175641 — 8.01
- 2020-05-13 0001193125-20-141598 — 2.02, 9.01
- 2020-03-13 0001193125-20-072960 — 5.02
- 2020-03-06 0001193125-20-065138 — 5.02
- 2020-02-12 0001193125-20-033208 — 2.02, 9.01
- 2020-01-27 0001193125-20-015453 — 5.02
- 2019-12-23 0001193125-19-322662 — 8.01
- 2019-12-12 0001193125-19-312796 — 8.01
- 2019-12-11 0001193125-19-311525 — 5.07
- 2019-12-04 0001193125-19-306229 — 8.01
- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2021-11-23

- none on or before 2021-11-23

## item 2.02 — earnings release, exhibit 99.1

[0001193125-21-332467:8k_2_02:1]
EX-99.1
2
d233827dex991.htm
EX-99.1

[0001193125-21-332467:8k_2_02:2]
EX-99.1

[0001193125-21-332467:8k_2_02:3]
Exhibit 99.1

[0001193125-21-332467:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-21-332467:8k_2_02:5]
CISCO REPORTS FIRST QUARTER EARNINGS

[0001193125-21-332467:8k_2_02:6]
News Summary:

[0001193125-21-332467:8k_2_02:7]
|  | • |  | Overall performance: $12.9 billion in revenue, up 8% year over year, with broad-based strength across the business; GAAP EPS $0.70, up 37% year over year, and Non-GAAP EPS $0.82, up 8% year over year |

[0001193125-21-332467:8k_2_02:8]
|  | • |  | Strong demand across the business with 33% year-over-year total product order growth |

[0001193125-21-332467:8k_2_02:9]
|  | • |  | Solid progress on business model transformation: Total Annualized Recurring Revenue was $21.6 billion for the first quarter of fiscal 2022, up 10% year over year |

[0001193125-21-332467:8k_2_02:10]
|  | • |  | Q1 Results: |

[0001193125-21-332467:8k_2_02:11]
|  | • |  | Revenue: $12.9 billion |

[0001193125-21-332467:8k_2_02:12]
|  | • |  | Increase of 8% year over year |

[0001193125-21-332467:8k_2_02:13]
|  | • |  | Earnings per Share: GAAP: $0.70; Non-GAAP: $0.82 |

[0001193125-21-332467:8k_2_02:14]
|  | • |  | GAAP EPS increased 37% year over year |

[0001193125-21-332467:8k_2_02:15]
|  | • |  | Non-GAAP EPS increased 8% year over year |

[0001193125-21-332467:8k_2_02:16]
|  | • |  | Q2 Guidance: |

[0001193125-21-332467:8k_2_02:17]
|  | • |  | Revenue: 4.5% to 6.5% growth year over year |

[0001193125-21-332467:8k_2_02:18]
|  | • |  | Earnings per Share: GAAP: $0.64 to $0.68; Non-GAAP: $0.80 to $0.82 |

[0001193125-21-332467:8k_2_02:19]
|  | • |  | FY 2022 Guidance: |

[0001193125-21-332467:8k_2_02:20]
|  | • |  | Revenue: 5% to 7% growth year over year |

[0001193125-21-332467:8k_2_02:21]
|  | • |  | Earnings per Share: GAAP: $2.77 to $2.89; Non-GAAP: $3.38 to $3.45 |

[0001193125-21-332467:8k_2_02:22]
SAN JOSE, Calif. — November 17, 2021 — Cisco today reported first quarter results for the period ended October 30, 2021. Cisco reported
first quarter revenue of $12.9 billion, net income on a generally accepted accounting principles (GAAP) basis of $3.0 billion or $0.70 per share, and non-GAAP net income of $3.5 billion or $0.82 per share.

[0001193125-21-332467:8k_2_02:23]
“In Q1, we had robust growth and continued strong demand despite the very dynamic supply environment,” said Chuck Robbins, Chair and CEO of Cisco.
“Cisco’s technology sits at the heart of the accelerated digital transformation happening today. Our breakthrough innovation, strong demand, and the success of our business transformation position us well for another year of growth in
fiscal 2022.”

[0001193125-21-332467:8k_2_02:24]
“Our teams executed well in a challenging environment, delivering balanced profitable growth with revenue and non-GAAP EPS both
growing 8% year over year,” said Scott Herren, CFO of Cisco. “We also continued to make significant progress in our business model transformation. Remaining performance obligations and annualized recurring revenue both grew 10% year over
year with product ARR growth of 21% providing more predictability and visibility to our long-term growth.”

[0001193125-21-332467:8k_2_02:25]
1

[0001193125-21-332467:8k_2_02:26]
GAAP Results

[0001193125-21-332467:8k_2_02:27]
|  |  | Q1 FY 2022 |  |  | Q1 FY 2021 |  |  | Vs. Q1 FY 2021 |  |
| Revenue |  | $ | 12.9 billion |  |  | $ | 11.9 billion |  |  |  | 8 | % |
| Net Income |  | $ | 3.0 billion |  |  | $ | 2.2 billion |  |  |  | 37 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.70 |  |  | $ | 0.51 |  |  |  | 37 | % |

[0001193125-21-332467:8k_2_02:28]
Non-GAAP Results

[0001193125-21-332467:8k_2_02:29]
|  |  | Q1 FY 2022 |  |  | Q1 FY 2021 |  |  | Vs. Q1 FY 2021 |  |
| Net Income |  | $ | 3.5 billion |  |  | $ | 3.2 billion |  |  |  | 8 | % |
| EPS |  | $ | 0.82 |  |  | $ | 0.76 |  |  |  | 8 | % |

[0001193125-21-332467:8k_2_02:30]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP basis are provided in the tables located in
the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-21-332467:8k_2_02:31]
2

[0001193125-21-332467:8k_2_02:32]
Financial Summary

[0001193125-21-332467:8k_2_02:33]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-21-332467:8k_2_02:34]
Q1 FY 2022 Highlights

[0001193125-21-332467:8k_2_02:35]
Revenue — Total
revenue was up 8% at $12.9 billion, with product revenue up 11% and service revenue up 1%. Revenue by geographic segment was: Americas up 5%, EMEA up 11%, and APJC up 15%. Product revenue performance was led by growth in Secure, Agile Networks up
10%, Internet for the Future up 46%, End-to-End Security up 4%, and Optimized Application Experiences up 18%. Hybrid Work was down 7%.

[0001193125-21-332467:8k_2_02:36]
Gross Margin — On a GAAP basis, total gross margin, product gross margin, and service gross margin were 62.4%, 61.5%, and 65.2%,
respectively, as compared with 63.6%, 62.7%, and 65.8%, respectively, in the first quarter of fiscal 2021.

[0001193125-21-332467:8k_2_02:37]
On a non-GAAP basis, total
gross margin, product gross margin, and service gross margin were 64.5%, 63.8%, and 66.5%, respectively, as compared with 65.8%, 65.3%, and 67.1%, respectively, in the first quarter of fiscal 2021.

[0001193125-21-332467:8k_2_02:38]
Total gross margins by geographic segment were: 64.5% for the Americas, 64.4% for EMEA and 64.7% for APJC.

[0001193125-21-332467:8k_2_02:39]
Operating Expenses — On a GAAP basis, operating expenses were $4.6 billion, down 8%, and were 35.8% of revenue. Non-GAAP operating expenses
were $4.0 billion, up 2%, and were 31.2% of revenue.

[0001193125-21-332467:8k_2_02:40]
Operating Income — GAAP operating income was $3.4 billion, up 34%,
with GAAP operating margin of 26.7%. Non-GAAP operating income was $4.3 billion, up 10%, with non-GAAP operating margin at 33.3%.

[0001193125-21-332467:8k_2_02:41]
Provision for Income Taxes — The GAAP tax provision rate was 18.5%. The non-GAAP tax provision rate was 19.0%.

[0001193125-21-332467:8k_2_02:42]
Net Income and EPS — On a GAAP basis, net income was $3.0 billion, an increase of 37%, and EPS was $0.70, an increase of 37%. On a non-GAAP
basis, net income was $3.5 billion, an increase of 8%, and EPS was $0.82, an increase of 8%.

[0001193125-21-332467:8k_2_02:43]
Cash Flow from Operating Activities
— $3.4 billion for the first quarter of fiscal 2022, a decrease of 16% compared with $4.1 billion for the first quarter of fiscal 2021.

[0001193125-21-332467:8k_2_02:44]
Balance Sheet and Other Financial Highlights

[0001193125-21-332467:8k_2_02:45]
Cash
and Cash Equivalents and Investments — $23.3 billion at the end of the first quarter of fiscal 2022, compared with $24.5 billion at the end of fiscal 2021.

[0001193125-21-332467:8k_2_02:46]
Remaining Performance Obligations (RPO) — $30.1 billion, up 10% in total, with 53% of this amount to be recognized as revenue over the next
12 months. Product RPO were up 18% and service RPO were up 4%.

[0001193125-21-332467:8k_2_02:47]
Deferred Revenue — $22.1 billion, up 8% in total, with
deferred product revenue up 19%. Deferred service revenue was flat.

[0001193125-21-332467:8k_2_02:48]
Capital Allocation — In the first quarter of fiscal
2022, we returned $1.8 billion to stockholders through share buybacks and dividends. We declared and paid a cash dividend of $0.37 per common share, or $1.6 billion, and repurchased approximately 5 million shares of common stock under our stock
repurchase program at an average price of $56.49 per share for an aggregate purchase price of $256 million. The remaining authorized amount for stock repurchases under the program is $7.7 billion with no termination date.

[0001193125-21-332467:8k_2_02:49]
Acquisitions

[0001193125-21-332467:8k_2_02:50]
In the first quarter of fiscal 2022, we
closed the acquisition of Epsagon Ltd., a privately held modern observability company with expertise in distributed tracing solutions for modern applications and technologies, including containers and serverless environments.

[0001193125-21-332467:8k_2_02:51]
In addition, we announced our intent to acquire replex GmbH, a privately held enterprise software company based in Germany.

[0001193125-21-332467:8k_2_02:52]
3

[0001193125-21-332467:8k_2_02:53]
Guidance

[0001193125-21-332467:8k_2_02:54]
Cisco expects to achieve the following results for the second quarter of fiscal 2022:

[0001193125-21-332467:8k_2_02:55]
| Q2 FY 2022 |  |  |
| Revenue |  | 4.5% - 6.5% growth Y/Y |
| Non-GAAP gross margin rate |  | 63.5% - 64.5% |
| Non-GAAP operating margin rate |  | 32.5% - 33.5% |
| Non-GAAP EPS |  | $0.80 - $0.82 |

[0001193125-21-332467:8k_2_02:56]
Cisco estimates that GAAP EPS will be $0.64 to $0.68 for the second quarter of fiscal 2022.

[0001193125-21-332467:8k_2_02:57]
Cisco expects to achieve the following results for fiscal 2022 (no change from our previous guidance):

[0001193125-21-332467:8k_2_02:58]
| FY 2022 |  |  |
| Revenue |  | 5% - 7% growth Y/Y |
| Non-GAAP EPS |  | $3.38 - $3.45 |

[0001193125-21-332467:8k_2_02:59]
Cisco estimates that GAAP EPS will be $2.77 to $2.89 for fiscal 2022.

[0001193125-21-332467:8k_2_02:60]
Our Q2 FY 2022 and FY 2022 guidance assumes an effective tax provision rate of 18% for GAAP and 19% for non-GAAP results.

[0001193125-21-332467:8k_2_02:61]
A reconciliation between the Guidance on a GAAP and non-GAAP basis is provided in the tables entitled “GAAP to non-GAAP Guidance” located in the
section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-21-332467:8k_2_02:62]
Editor’s Notes:

[0001193125-21-332467:8k_2_02:63]
|  | • |  | Q1 fiscal year 2022 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, November 17, 2021 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-21-332467:8k_2_02:64]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, November 17, 2021 to 4:00 p.m. Pacific Time, November 24, 2021 at 1-866-360-3304 (United States) or 1-203-369-0159 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-21-332467:8k_2_02:65]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, November 17, 2021. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-21-332467:8k_2_02:66]
4

[0001193125-21-332467:8k_2_02:67]
CISCO SYSTEMS, INC.

[0001193125-21-332467:8k_2_02:68]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-21-332467:8k_2_02:69]
(In millions, except per-share amounts)

[0001193125-21-332467:8k_2_02:70]
(Unaudited)

[0001193125-21-332467:8k_2_02:71]
|  |  | Three Months Ended |  |
|  |  | October 30,2021 |  |  | October 24,2020 |  |
| REVENUE: |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,529 |  |  | $ | 8,587 |  |
| Service |  |  | 3,371 |  |  |  | 3,342 |  |
| Total revenue |  |  | 12,900 |  |  |  | 11,929 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |
| Product |  |  | 3,673 |  |  |  | 3,206 |  |
| Service |  |  | 1,174 |  |  |  | 1,142 |  |
| Total cost of sales |  |  | 4,847 |  |  |  | 4,348 |  |
| GROSS MARGIN |  |  | 8,053 |  |  |  | 7,581 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,714 |  |  |  | 1,612 |  |
| Sales and marketing |  |  | 2,261 |  |  |  | 2,217 |  |
| General and administrative |  |  | 551 |  |  |  | 544 |  |
| Amortization of purchased intangible assets |  |  | 84 |  |  |  | 36 |  |
| Restructuring and other charges |  |  | 5 |  |  |  | 602 |  |
| Total operating expenses |  |  | 4,615 |  |  |  | 5,011 |  |
| OPERATING INCOME |  |  | 3,438 |  |  |  | 2,570 |  |
| Interest income |  |  | 121 |  |  |  | 174 |  |
| Interest expense |  |  | (89 | ) |  |  | (112 | ) |
| Other income (loss), net |  |  | 187 |  |  |  | 49 |  |
| Interest and other income (loss), net |  |  | 219 |  |  |  | 111 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,657 |  |  |  | 2,681 |  |
| Provision for income taxes |  |  | 677 |  |  |  | 507 |  |
| NET INCOME |  | $ | 2,980 |  |  | $ | 2,174 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.71 |  |  | $ | 0.51 |  |
| Diluted |  | $ | 0.70 |  |  | $ | 0.51 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,218 |  |  |  | 4,230 |  |
| Diluted |  |  | 4,243 |  |  |  | 4,244 |  |

[0001193125-21-332467:8k_2_02:72]
5

[0001193125-21-332467:8k_2_02:73]
CISCO SYSTEMS, INC.

[0001193125-21-332467:8k_2_02:74]
REVENUE BY SEGMENT

[0001193125-21-332467:8k_2_02:75]
(In
millions, except percentages)

[0001193125-21-332467:8k_2_02:76]
|  |  | Three Months EndedOctober 30, 2021 |  |
|  |  | Amount |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,561 |  |  |  | 5 | % |
| EMEA |  |  | 3,303 |  |  |  | 11 | % |
| APJC |  |  | 2,036 |  |  |  | 15 | % |
| Total |  | $ | 12,900 |  |  |  | 8 | % |

[0001193125-21-332467:8k_2_02:77]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-21-332467:8k_2_02:78]
CISCO SYSTEMS, INC.

[0001193125-21-332467:8k_2_02:79]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-21-332467:8k_2_02:80]
(In percentages)

[0001193125-21-332467:8k_2_02:81]
|  |  | Three Months EndedOctober 30, 2021 |
| Gross Margin Percentage: |  |  |  |  |  |
| Americas |  |  |  | 64.5 | % |
| EMEA |  |  |  | 64.4 | % |
| APJC |  |  |  | 64.7 | % |

[0001193125-21-332467:8k_2_02:82]
CISCO SYSTEMS, INC.

[0001193125-21-332467:8k_2_02:83]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-21-332467:8k_2_02:84]
(In millions, except percentages)

[0001193125-21-332467:8k_2_02:85]
|  |  | Three Months EndedOctober 30, 2021 |  |
|  |  | Amount |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Secure, Agile Networks |  | $ | 5,967 |  |  |  | 10 | % |
| Hybrid Work |  |  | 1,109 |  |  |  | (7 | )% |
| End-to-End Security |  |  | 895 |  |  |  | 4 | % |
| Internet for the Future |  |  | 1,374 |  |  |  | 46 | % |
| Optimized Application Experiences |  |  | 181 |  |  |  | 18 | % |
| Other Products |  |  | 3 |  |  |  | 9 | % |
| Total Product |  |  | 9,529 |  |  |  | 11 | % |
| Services |  |  | 3,371 |  |  |  | 1 | % |
| Total |  | $ | 12,900 |  |  |  | 8 | % |

[0001193125-21-332467:8k_2_02:86]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-21-332467:8k_2_02:87]
Effective for the first quarter of fiscal 2022, we began reporting our revenue in the following categories: Secure, Agile Networks; Hybrid Work; End-to-End
Security; Internet for the Future; Optimized Application Experiences; Other Products and Services. This change better aligns our product categories with our strategic priorities. The reclassified product category revenue by quarter for fiscal 2019
through fiscal 2021 as well as other information is available on Cisco’s Investor Relations website at https://investor.cisco.com/investor-relations/financial-information/Financial-Results/default.aspx.

[0001193125-21-332467:8k_2_02:88]
CISCO SYSTEMS, INC.

[0001193125-21-332467:8k_2_02:89]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-21-332467:8k_2_02:90]
(In millions)

[0001193125-21-332467:8k_2_02:91]
(Unaudited)

[0001193125-21-332467:8k_2_02:92]
|  |  | October 30, 2021 |  |  | July 31, 2021 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 7,619 |  |  | $ | 9,175 |  |
| Investments |  |  | 15,727 |  |  |  | 15,343 |  |
| Accounts receivable, net of allowance of $114 at October 30, 2021 and $109 at July 31, 2021 |  |  | 5,306 |  |  |  | 5,766 |  |
| Inventories |  |  | 1,832 |  |  |  | 1,559 |  |
| Financing receivables, net |  |  | 4,070 |  |  |  | 4,380 |  |
| Other current assets |  |  | 3,034 |  |  |  | 2,889 |  |
| Total current assets |  |  | 37,588 |  |  |  | 39,112 |  |
| Property and equipment, net |  |  | 2,238 |  |  |  | 2,338 |  |
| Financing receivables, net |  |  | 4,546 |  |  |  | 4,884 |  |
| Goodwill |  |  | 38,802 |  |  |  | 38,168 |  |
| Purchased intangible assets, net |  |  | 3,350 |  |  |  | 3,619 |  |
| Deferred tax assets |  |  | 4,198 |  |  |  | 4,360 |  |
| Other assets |  |  | 5,259 |  |  |  | 5,016 |  |
| TOTAL ASSETS |  | $ | 95,981 |  |  | $ | 97,497 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 506 |  |  | $ | 2,508 |  |
| Accounts payable |  |  | 2,261 |  |  |  | 2,362 |  |
| Income taxes payable |  |  | 816 |  |  |  | 801 |  |
| Accrued compensation |  |  | 3,231 |  |  |  | 3,818 |  |
| Deferred revenue |  |  | 12,017 |  |  |  | 12,148 |  |
| Other current liabilities |  |  | 4,407 |  |  |  | 4,620 |  |
| Total current liabilities |  |  | 23,238 |  |  |  | 26,257 |  |
| Long-term debt |  |  | 8,996 |  |  |  | 9,018 |  |
| Income taxes payable |  |  | 8,553 |  |  |  | 8,538 |  |
| Deferred revenue |  |  | 10,055 |  |  |  | 10,016 |  |
| Other long-term liabilities |  |  | 2,438 |  |  |  | 2,393 |  |
| Total liabilities |  |  | 53,280 |  |  |  | 56,222 |  |
| Total equity |  |  | 42,701 |  |  |  | 41,275 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 95,981 |  |  | $ | 97,497 |  |

[0001193125-21-332467:8k_2_02:93]
7

[0001193125-21-332467:8k_2_02:94]
CISCO SYSTEMS, INC.

[0001193125-21-332467:8k_2_02:95]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-21-332467:8k_2_02:96]
(In millions)

[0001193125-21-332467:8k_2_02:97]
(Unaudited)

[0001193125-21-332467:8k_2_02:98]
|  |  | Three Months Ended |  |
|  |  | October 30,2021 |  |  | October 24,2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 2,980 |  |  | $ | 2,174 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 533 |  |  |  | 451 |  |
| Share-based compensation expense |  |  | 453 |  |  |  | 438 |  |
| Provision (benefit) for receivables |  |  | 1 |  |  |  | 13 |  |
| Deferred income taxes |  |  | (98 | ) |  |  | (120 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (211 | ) |  |  | (59 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 427 |  |  |  | 1,526 |  |
| Inventories |  |  | (275 | ) |  |  | (21 | ) |
| Financing receivables |  |  | 672 |  |  |  | 167 |  |
| Other assets |  |  | (170 | ) |  |  | (259 | ) |
| Accounts payable |  |  | (93 | ) |  |  | 73 |  |
| Income taxes, net |  |  | 17 |  |  |  | (84 | ) |
| Accrued compensation |  |  | (585 | ) |  |  | (165 | ) |
| Deferred revenue |  |  | (95 | ) |  |  | (45 | ) |
| Other liabilities |  |  | (129 | ) |  |  | 7 |  |
| Net cash provided by operating activities |  |  | 3,427 |  |  |  | 4,096 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (2,951 | ) |  |  | (3,756 | ) |
| Proceeds from sales of investments |  |  | 580 |  |  |  | 657 |  |
| Proceeds from maturities of investments |  |  | 1,856 |  |  |  | 1,425 |  |
| Acquisitions, net of cash and cash equivalents acquired and divestitures |  |  | (336 | ) |  |  | (830 | ) |
| Purchases of investments in privately held companies |  |  | (101 | ) |  |  | (68 | ) |
| Return of investments in privately held companies |  |  | 53 |  |  |  | 29 |  |
| Acquisition of property and equipment |  |  | (122 | ) |  |  | (171 | ) |
| Proceeds from sales of property and equipment |  |  | 1 |  |  |  | 4 |  |
| Net cash used in investing activities |  |  | (1,020 | ) |  |  | (2,710 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | — |  |  |  | 1 |  |
| Repurchases of common stock - repurchase program |  |  | (273 | ) |  |  | (800 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (133 | ) |  |  | (89 | ) |
| Repayments of debt |  |  | (2,000 | ) |  |  | — |  |
| Dividends paid |  |  | (1,561 | ) |  |  | (1,520 | ) |
| Other |  |  | (3 | ) |  |  | 35 |  |
| Net cash used in financing activities |  |  | (3,970 | ) |  |  | (2,373 | ) |
| Net decrease in cash, cash equivalents, and restricted cash |  |  | (1,563 | ) |  |  | (987 | ) |
| Cash, cash equivalents, and restricted cash, beginning of period |  |  | 9,942 |  |  |  | 11,812 |  |
| Cash, cash equivalents, and restricted cash, end of period |  | $ | 8,379 |  |  | $ | 10,825 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 124 |  |  | $ | 160 |  |
| Cash paid for income taxes, net |  | $ | 758 |  |  | $ | 710 |  |

[0001193125-21-332467:8k_2_02:99]
8

[0001193125-21-332467:8k_2_02:100]
CISCO SYSTEMS, INC.

[0001193125-21-332467:8k_2_02:101]
REMAINING PERFORMANCE OBLIGATIONS

[0001193125-21-332467:8k_2_02:102]
(In millions, except percentages)

[0001193125-21-332467:8k_2_02:103]
|  |  | October 30, 2021 |  |  | July 31, 2021 |  |  | October 24, 2020 |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Product |  | $ | 13,384 |  |  |  | 18 | % |  | $ | 13,270 |  |  |  | 18 | % |  | $ | 11,340 |  |  |  | 15 | % |
| Service |  |  | 16,751 |  |  |  | 4 | % |  |  | 17,623 |  |  |  | 3 | % |  |  | 16,129 |  |  |  | 8 | % |
| Total |  | $ | 30,135 |  |  |  | 10 | % |  | $ | 30,893 |  |  |  | 9 | % |  | $ | 27,469 |  |  |  | 10 | % |

[0001193125-21-332467:8k_2_02:104]
We expect 53% of total RPO at October 30, 2021 will be recognized as revenue over the next 12 months.

[0001193125-21-332467:8k_2_02:105]
CISCO SYSTEMS, INC.

[0001193125-21-332467:8k_2_02:106]
DEFERRED REVENUE

[0001193125-21-332467:8k_2_02:107]
(In
millions)

[0001193125-21-332467:8k_2_02:108]
|  |  | October 30,2021 |  |  | July 31,2021 |  |  | October 24,2020 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,681 |  |  | $ | 9,416 |  |  | $ | 8,139 |  |
| Service |  |  | 12,391 |  |  |  | 12,748 |  |  |  | 12,334 |  |
| Total |  | $ | 22,072 |  |  | $ | 22,164 |  |  | $ | 20,473 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 12,017 |  |  | $ | 12,148 |  |  | $ | 11,271 |  |
| Noncurrent |  |  | 10,055 |  |  |  | 10,016 |  |  |  | 9,202 |  |
| Total |  | $ | 22,072 |  |  | $ | 22,164 |  |  | $ | 20,473 |  |

[0001193125-21-332467:8k_2_02:109]
CISCO SYSTEMS, INC.

[0001193125-21-332467:8k_2_02:110]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-21-332467:8k_2_02:111]
(In millions, except per-share amounts)

[0001193125-21-332467:8k_2_02:112]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| October 30, 2021 |  | $ | 0.37 |  |  | $ | 1,561 |  |  |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |  | $ | 1,817 |  |
| Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 31, 2021 |  | $ | 0.37 |  |  | $ | 1,562 |  |  |  | 15 |  |  | $ | 53.30 |  |  | $ | 791 |  |  | $ | 2,353 |  |
| May 1, 2021 |  | $ | 0.37 |  |  | $ | 1,560 |  |  |  | 10 |  |  | $ | 48.71 |  |  | $ | 510 |  |  | $ | 2,070 |  |
| January 23, 2021 |  | $ | 0.36 |  |  | $ | 1,521 |  |  |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |  | $ | 2,322 |  |
| October 24, 2020 |  | $ | 0.36 |  |  | $ | 1,520 |  |  |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |  | $ | 2,320 |  |

[0001193125-21-332467:8k_2_02:113]
9

[0001193125-21-332467:8k_2_02:114]
CISCO SYSTEMS, INC.

[0001193125-21-332467:8k_2_02:115]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-332467:8k_2_02:116]
GAAP TO NON-GAAP NET INCOME

[0001193125-21-332467:8k_2_02:117]
(In millions)

[0001193125-21-332467:8k_2_02:118]
|  |  | Three Months Ended |  |
|  |  | October 30,2021 |  |  | October 24,2020 |  |
| GAAP net income |  | $ | 2,980 |  |  | $ | 2,174 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 69 |  |  |  | 65 |  |
| Amortization of acquisition-related intangible assets |  |  | 198 |  |  |  | 163 |  |
| Acquisition-related/divestiture costs |  |  | 1 |  |  |  | 1 |  |
| Legal and indemnification settlements/charges |  |  | — |  |  |  | 43 |  |
| Total adjustments to GAAP cost of sales |  |  | 268 |  |  |  | 272 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 383 |  |  |  | 362 |  |
| Amortization of acquisition-related intangible assets |  |  | 84 |  |  |  | 36 |  |
| Acquisition-related/divestiture costs |  |  | 112 |  |  |  | 59 |  |
| Significant asset impairments and restructurings |  |  | 5 |  |  |  | 602 |  |
| Total adjustments to GAAP operating expenses |  |  | 584 |  |  |  | 1,059 |  |
| Adjustments to interest and other income (loss), net: |  |  |  |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | (219 | ) |  |  | (48 | ) |
| Total adjustments to GAAP interest and other income (loss), net |  |  | (219 | ) |  |  | (48 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 633 |  |  |  | 1,283 |  |
| Income tax effect of non-GAAP adjustments |  |  | (138 | ) |  |  | (246 | ) |
| Total adjustments to GAAP provision for income taxes |  |  | (138 | ) |  |  | (246 | ) |
| Non-GAAP net income |  | $ | 3,475 |  |  | $ | 3,211 |  |

[0001193125-21-332467:8k_2_02:119]
10

[0001193125-21-332467:8k_2_02:120]
CISCO SYSTEMS, INC.

[0001193125-21-332467:8k_2_02:121]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-332467:8k_2_02:122]
GAAP TO NON-GAAP EPS

[0001193125-21-332467:8k_2_02:123]
|  |  | Three Months Ended |  |
|  |  | October 30,2021 |  |  | October 24,2020 |  |
| GAAP EPS |  | $ | 0.70 |  |  | $ | 0.51 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.11 |  |  |  | 0.10 |  |
| Amortization of acquisition-related intangible assets |  |  | 0.07 |  |  |  | 0.05 |  |
| Acquisition-related/divestiture costs |  |  | 0.03 |  |  |  | 0.01 |  |
| Legal and indemnification settlements/charges |  |  | — |  |  |  | 0.01 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | 0.14 |  |
| (Gains) and losses on equity investments |  |  | (0.05 | ) |  |  | (0.01 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.03 | ) |  |  | (0.06 | ) |
| Non-GAAP EPS |  | $ | 0.82 |  |  | $ | 0.76 |  |

[0001193125-21-332467:8k_2_02:124]
Amounts may not sum due to rounding.

[0001193125-21-332467:8k_2_02:125]
11

[0001193125-21-332467:8k_2_02:126]
CISCO SYSTEMS, INC.

[0001193125-21-332467:8k_2_02:127]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-332467:8k_2_02:128]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-21-332467:8k_2_02:129]
(In millions, except percentages)

[0001193125-21-332467:8k_2_02:130]
|  |  | Three Months EndedOctober 30, 2021 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestand otherincome(loss),net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,856 |  |  | $ | 2,197 |  |  | $ | 8,053 |  |  | $ | 4,615 |  |  |  | (8 | )% |  | $ | 3,438 |  |  |  | 34 | % |  | $ | 219 |  |  | $ | 2,980 |  |  |  | 37 | % |
| % of revenue |  |  | 61.5 | % |  |  | 65.2 | % |  |  | 62.4 | % |  |  | 35.8 | % |  |  |  |  |  |  | 26.7 | % |  |  |  |  |  |  | 1.7 | % |  |  | 23.1 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 25 |  |  |  | 44 |  |  |  | 69 |  |  |  | 383 |  |  |  |  |  |  |  | 452 |  |  |  |  |  |  |  | — |  |  |  | 452 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 198 |  |  |  | — |  |  |  | 198 |  |  |  | 84 |  |  |  |  |  |  |  | 282 |  |  |  |  |  |  |  | — |  |  |  | 282 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 112 |  |  |  |  |  |  |  | 113 |  |  |  |  |  |  |  | — |  |  |  | 113 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  |  |  |  |  | 5 |  |  |  |  |  |  |  | — |  |  |  | 5 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (219 | ) |  |  | (219 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (138 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 6,080 |  |  | $ | 2,241 |  |  | $ | 8,321 |  |  | $ | 4,031 |  |  |  | 2 | % |  | $ | 4,290 |  |  |  | 10 | % |  | $ | — |  |  | $ | 3,475 |  |  |  | 8 | % |
| % of revenue |  |  | 63.8 | % |  |  | 66.5 | % |  |  | 64.5 | % |  |  | 31.2 | % |  |  |  |  |  |  | 33.3 | % |  |  |  |  |  |  | — | % |  |  | 26.9 | % |  |  |  |  |

[0001193125-21-332467:8k_2_02:131]
|  |  | Three Months EndedOctober 24, 2020 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | Total GrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interest andotherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 5,381 |  |  | $ | 2,200 |  |  | $ | 7,581 |  |  | $ | 5,011 |  |  | $ | 2,570 |  |  | $ | 111 |  |  | $ | 2,174 |  |
| % of revenue |  |  | 62.7 | % |  |  | 65.8 | % |  |  | 63.6 | % |  |  | 42.0 | % |  |  | 21.5 | % |  |  | 0.9 | % |  |  | 18.2 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 24 |  |  |  | 41 |  |  |  | 65 |  |  |  | 362 |  |  |  | 427 |  |  |  | — |  |  |  | 427 |  |
| Amortization of acquisition-related intangible assets |  |  | 163 |  |  |  | — |  |  |  | 163 |  |  |  | 36 |  |  |  | 199 |  |  |  | — |  |  |  | 199 |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 59 |  |  |  | 60 |  |  |  | — |  |  |  | 60 |  |
| Legal and indemnification settlements/charges |  |  | 43 |  |  |  | — |  |  |  | 43 |  |  |  | — |  |  |  | 43 |  |  |  | — |  |  |  | 43 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 602 |  |  |  | 602 |  |  |  | — |  |  |  | 602 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (48 | ) |  |  | (48 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (246 | ) |
| Non-GAAP amount |  | $ | 5,611 |  |  | $ | 2,242 |  |  | $ | 7,853 |  |  | $ | 3,952 |  |  | $ | 3,901 |  |  | $ | 63 |  |  | $ | 3,211 |  |
| % of revenue |  |  | 65.3 | % |  |  | 67.1 | % |  |  | 65.8 | % |  |  | 33.1 | % |  |  | 32.7 | % |  |  | 0.5 | % |  |  | 26.9 | % |

[0001193125-21-332467:8k_2_02:132]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-21-332467:8k_2_02:133]
12

[0001193125-21-332467:8k_2_02:134]
CISCO SYSTEMS, INC.

[0001193125-21-332467:8k_2_02:135]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-332467:8k_2_02:136]
EFFECTIVE TAX RATE

[0001193125-21-332467:8k_2_02:137]
(In
percentages)

[0001193125-21-332467:8k_2_02:138]
|  |  | Three Months Ended |  |
|  |  | October 30,2021 |  |  | October 24,2020 |  |
| GAAP effective tax rate |  |  | 18.5 | % |  |  | 18.9 | % |
| Total adjustments to GAAP provision for income taxes |  |  | 0.5 | % |  |  | 0.1 | % |
| Non-GAAP effective tax rate |  |  | 19.0 | % |  |  | 19.0 | % |

[0001193125-21-332467:8k_2_02:139]
GAAP TO NON-GAAP GUIDANCE

[0001193125-21-332467:8k_2_02:140]
| Q2 FY 2022 |  | Gross MarginRate |  |  | Operating MarginRate |  |  | Earnings perShare (1) |  |
| GAAP |  |  | 61.5% - 62.5% |  |  |  | 26% - 27% |  |  | $ | 0.64 - $0.68 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.5% |  |  |  | 4.0% |  |  | $ | 0.08 - $0.09 |  |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  |  | 1.5% |  |  |  | 2.5% |  |  | $ | 0.06 - $0.07 |  |
| Non-GAAP |  |  | 63.5% - 64.5% |  |  |  | 32.5% -33.5% |  |  | $ | 0.80 - $0.82 |  |

[0001193125-21-332467:8k_2_02:141]
| FY 2022 |  | Earnings perShare (1) |
| GAAP |  |  | $ | 2.77 - $2.89 |  |
| Estimated adjustments for: |  |  |  |  |  |
| Share-based compensation expense |  |  | $ | 0.34 - $0.36 |  |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  |  | $ | 0.26 - $0.28 |  |
| Significant asset impairments and restructurings |  |  | $ | 0.00 - $0.01 |  |
| (Gains) and losses on equity investments |  |  |  | ($0.04) |  |
| Non-GAAP |  |  | $ | 3.38 - $3.45 |  |

[0001193125-21-332467:8k_2_02:142]
| (1) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-21-332467:8k_2_02:143]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings, (gains) and
losses on equity investments and significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-21-332467:8k_2_02:144]
13

[0001193125-21-332467:8k_2_02:145]
Forward Looking Statements, Non-GAAP Information and Additional Information

[0001193125-21-332467:8k_2_02:146]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP
effective tax rates, non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a
non-GAAP basis.

[0001193125-21-332467:8k_2_02:147]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted
accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have
limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in
conjunction with the corresponding GAAP measures.

[0001193125-21-332467:8k_2_02:148]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the
corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-21-332467:8k_2_02:149]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other contingencies, gains and losses on equity investments, the
income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco
has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its
financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-21-332467:8k_2_02:150]
14

[0001193125-21-332467:8k_2_02:151]
Annualized Recurring Revenue represents the annualized revenue run-rate of active subscriptions, term
licenses, and maintenance contracts at the end of a reporting period, net of rebates to customers and partners as well as certain other revenue adjustments. Includes both revenue recognized ratably as well as upfront on an annualized basis.

[0001193125-21-332467:8k_2_02:152]
About Cisco

[0001193125-21-332467:8k_2_02:153]
Cisco (Nasdaq: CSCO) is the worldwide
leader in technology that powers the Internet. Cisco inspires new possibilities by reimagining your applications, securing your data, transforming your infrastructure, and empowering your teams for a global and inclusive future.
Discover more at newsroom.cisco.com and follow us on Twitter at @Cisco.

[0001193125-21-332467:8k_2_02:154]
Copyright © 2021 Cisco
and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks.
Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-21-332467:8k_2_02:155]
RSS Feed for Cisco: https://newsroom.cisco.com/rss-feeds

[0001193125-21-332467:8k_2_02:156]
15
