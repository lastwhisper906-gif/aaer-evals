# CSCO note change history — 0000858877-21-000008 → 0000858877-21-000018


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-23):
[0000858877-21-000018:note_history:1]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.
  (was, 2021-05-25, similarity 0.9863):
[0000858877-21-000008:note_history:1]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

- changed (2021-11-23):
[0000858877-21-000018:note_history:2]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):
  (was, 2021-05-25, similarity 0.918):
[0000858877-21-000008:note_history:2]
The following table summarizes our purchase commitments with contract manufacturers and suppliers (in millions):

- changed (2021-11-23):
[0000858877-21-000018:note_history:3]
|  | October 30,2021 |  | July 31,2021 |
| Less than 1 year | $ | 7,621 |  |  | $ | 6,903 |  |
| 1 to 3 years | 2,072 |  |  | 1,806 |  |
| 3 to 5 years | 1,359 |  |  | 1,545 |  |
| Total | $ | 11,052 |  |  | $ | 10,254 |  |
  (was, 2021-05-25, similarity 0.9012):
[0000858877-21-000008:note_history:3]
| Commitments by Period | May 1,2021 |  | July 25,2020 |
| Less than 1 year | $ | 6,461 |  |  | $ | 3,994 |  |
| 1 to 3 years | 1,615 |  |  | 412 |  |
| 3 to 5 years | 1,733 |  |  | — |  |
| Total | $ | 9,809 |  |  | $ | 4,406 |  |

- added (2021-11-23):
[0000858877-21-000018:note_history:4]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 30, 2021 and July 31, 2021, the liability for these purchase commitments was $179 million and $151 million, respectively, and was included in other current liabilities. For further discussion around the Supply Constraints Impacts and Risks, see Result of Operations—Product Gross Margin and Liquidity and Capital Resources—Inventory Supply Chain.

- changed (2021-11-23):
[0000858877-21-000018:note_history:5]
|  | Three Months Ended |
|  | October 30, 2021 |  | October 24, 2020 |
| Compensation expense related to acquisitions | $ | 89 |  |  | $ | 57 |  |
  (was, 2021-05-25, similarity 0.716):
[0000858877-21-000008:note_history:5]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1, 2021 |  | April 25, 2020 |  | May 1, 2021 |  | April 25, 2020 |
| Compensation expense related to acquisitions | $ | 66 |  |  | $ | 61 |  |  | $ | 182 |  |  | $ | 172 |  |

- changed (2021-11-23):
[0000858877-21-000018:note_history:6]
As of October 30, 2021, we estimated that future cash compensation expense of up to $673 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2021-05-25, similarity 0.9721):
[0000858877-21-000008:note_history:6]
As of May 1, 2021, we estimated that future cash compensation expense of up to $616 million may be required to be recognized pursuant to the applicable business combination agreements.

- added (2021-11-23):
[0000858877-21-000018:note_history:7]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.2 billion as of each of October 30, 2021 and July 31, 2021.

- changed (2021-11-23):
[0000858877-21-000018:note_history:8]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |
| Balance at beginning of period | $ | 336 |  |  | $ | 331 |  |
| Provisions for warranties issued | 114 |  |  | 121 |  |
| Adjustments for pre-existing warranties | 2 |  |  | 1 |  |
| Settlements | (111) |  |  | (122) |  |
| Balance at end of period | $ | 341 |  |  | $ | 331 |  |
  (was, 2021-05-25, similarity 0.8661):
[0000858877-21-000008:note_history:8]
|  | Nine Months Ended |
|  | May 1,2021 |  | April 25,2020 |
| Balance at beginning of period | $ | 331 |  |  | $ | 342 |  |
| Provisions for warranties issued | 382 |  |  | 423 |  |
| Adjustments for pre-existing warranties | 1 |  |  | (5) |  |
| Settlements | (373) |  |  | (436) |  |
| Balance at end of period | $ | 341 |  |  | $ | 324 |  |

- changed (2021-11-23):
[0000858877-21-000018:note_history:9]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.6 billion and $6.1 billion for the first quarter of fiscal 2022 and 2021, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion as of each of October 30, 2021 and July 31, 2021.
  (was, 2021-05-25, similarity 0.7429):
[0000858877-21-000008:note_history:9]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. During fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.6 billion and $6.3 billion for the third quarter of fiscal 2021 and 2020, respectively, and was $19.5 billion and $20.5 billion for the first nine months of fiscal 2021 and 2020, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.1 billion as of May 1, 2021 and July 25, 2020, respectively.

- changed (2021-11-23):
[0000858877-21-000018:note_history:10]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $2 million and $5 million for the first quarter of fiscal 2022 and 2021, respectively.
  (was, 2021-05-25, similarity 0.9064):
[0000858877-21-000008:note_history:10]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $1 million and $2 million for the third quarter of fiscal 2021 and 2020, respectively, and was $8 million for each of the first nine months of fiscal 2021 and 2020.

- changed (2021-11-23):
[0000858877-21-000018:note_history:11]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 30, 2021 and July 31, 2021, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2021-05-25, similarity 0.9839):
[0000858877-21-000008:note_history:11]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at May 1, 2021 and July 25, 2020, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2021-11-23):
[0000858877-21-000018:note_history:12]
|  | October 30,2021 |  | July 31,2021 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 197 |  |  | $ | 155 |  |
| End user | 4 |  |  | 5 |  |
| Total | $ | 201 |  |  | $ | 160 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (5) |  |  | $ | (16) |  |
| End user | (4) |  |  | (5) |  |
| Total | $ | (9) |  |  | $ | (21) |  |
| Total | $ | 192 |  |  | $ | 139 |  |
  (was, 2021-05-25, similarity 0.9879):
[0000858877-21-000008:note_history:12]
|  | May 1,2021 |  | July 25,2020 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 165 |  |  | $ | 198 |  |
| End user | 6 |  |  | 9 |  |
| Total | $ | 171 |  |  | $ | 207 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (16) |  |  | $ | (19) |  |
| End user | (6) |  |  | (9) |  |
| Total | $ | (22) |  |  | $ | (28) |  |
| Total | $ | 149 |  |  | $ | 179 |  |

- changed (2021-11-23):
[0000858877-21-000018:note_history:13]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations discussed in this section (e) due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these cases, and the unique facts and circumstances involved in each particular case and agreement. We are unable to reasonably estimate the ultimate outcome of the cases discussed below in this section (e), but we do not believe that any potential indemnity liability would be material, and historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.
  (was, 2021-05-25, similarity 0.9395):
[0000858877-21-000008:note_history:13]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations discussed in this section (e) due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these cases, and the unique facts and circumstances involved in each particular case and agreement. We are unable to reasonably estimate the ultimate outcome of the cases discussed below in this section (e), but we do not believe that any potential indemnity liability would be material, and historically, indemnity payments made by us have not had a material effect on our operating results, financial position, or cash flows.

- added (2021-11-23):
[0000858877-21-000018:note_history:14]
We were asked by seven of our customers to indemnify them in connection with patent infringement claims asserted against them by Estech Systems, Inc. (“Estech”) in the Eastern District of Texas (“E.D. Tex.”) court and the Western District of Texas  (“W.D. Tex.”) court between April 24, 2020 and August 25, 2020. Estech alleged that the customer defendants infringe three patents generally related to IP telephony by using collaboration technology from us and other providers. Estech was seeking monetary damages from the customer defendants. Estech and the customer defendants resolved Estech’s claims, and we resolved the customer defendants’ indemnity claims for an amount that did not have a material effect on our Consolidated Financial Statements.

- changed (2021-11-23):
[0000858877-21-000018:note_history:15]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $144 million for the alleged evasion of import and other taxes, $719 million for interest, and $355 million for various penalties, all determined using an exchange rate as of October 30, 2021.
  (was, 2021-05-25, similarity 0.9958):
[0000858877-21-000008:note_history:15]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $149 million for the alleged evasion of import and other taxes, $735 million for interest, and $368 million for various penalties, all determined using an exchange rate as of May 1, 2021.

- changed (2021-11-23):
[0000858877-21-000018:note_history:16]
China     We are investigating allegations of a self-enrichment scheme involving now-former employees in China. Some of those employees are also alleged to have made or directed payments from the funds they received to various third parties, including employees of state-owned enterprises. We voluntarily disclosed this investigation to the Department of Justice (“DOJ”) and Securities and Exchange Commission (“SEC”). We take such allegations very seriously and we are providing results of our investigation to the DOJ and SEC. While the outcome of our investigation is currently not determinable, we do not expect that it will have a material adverse effect on our Consolidated Financial Statements.
  (was, 2021-05-25, similarity 0.9622):
[0000858877-21-000008:note_history:16]
China     We are investigating allegations of a self-enrichment scheme involving now-former employees in China. Some of those employees are also alleged to have made or directed payments from the funds they received to various third parties, including employees of state-owned enterprises. We voluntarily disclosed this investigation to the Department of Justice (“DOJ”) and Securities and Exchange Commission (“SEC”). We take such allegations very seriously and we are providing results of our investigation to the DOJ and SEC. While the outcome of our investigation is currently not determinable, we do not expect that it will have a material adverse effect on our consolidated financial position, results of operations, or cash flows.

- changed (2021-11-23):
[0000858877-21-000018:note_history:17]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted claims against us in the U.S. District Court for the District of Delaware (“D. Del.”), accusing our products and services in the area of network intrusion detection of infringing two patents. On May 12, 2016, a jury returned a verdict finding willful infringement. The jury awarded SRI damages of $24 million. On May 25, 2017, the district court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit (“Federal Circuit”), and on July 12, 2019, the Federal Circuit vacated the enhanced damages award; vacated and remanded in part the willful infringement finding; vacated and remanded the attorneys’ fees award for further proceedings; and affirmed the district court’s other findings. Cisco paid SRI $28 million, representing the portion of the judgment that the Federal Circuit affirmed, plus interest and royalties on post-verdict sales.
  (was, 2021-05-25, similarity 0.7723):
[0000858877-21-000008:note_history:17]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware (“D. Del.”), accusing our products and services in the area of network intrusion detection of infringing two patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. On May 12, 2016, a jury returned a verdict finding willful infringement. The jury awarded SRI damages of $24 million. On May 25, 2017, the district court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit (“Federal Circuit”) on various grounds, and after various proceedings, on July 12, 2019, the Federal Circuit vacated the enhanced damages award; vacated and remanded in part the willful infringement finding; vacated and remanded the attorneys’ fees award for further proceedings; and affirmed the district court’s other findings. On April 1, 2020, the district court issued a final judgment on the remanded issues, finding no evidence of willful infringement and reinstating the $8 million award of attorneys’ fees. SRI appealed the judgment of no willful infringement to the Federal Circuit on April 3, 2020, and Cisco filed a cross-appeal on the attorneys’ fees award on April 9, 2020. Cisco has paid SRI $28 million, representing the portion of the judgment that the Federal Circuit previously affirmed, plus interest and royalties on post-verdict sales. While the remaining proceedings may result in an additional loss, we do not expect it to be material.

- added (2021-11-23):
[0000858877-21-000018:note_history:18]
On April 1, 2020, the district court issued a final judgment on the remanded issues, finding no evidence of willful infringement and reinstating the $8 million award of attorneys’ fees. In a second round of appeals to the Federal Circuit in April 2020, SRI appealed the judgment of no willful infringement, and Cisco filed a cross-appeal on the attorneys’ fees award. On September 28, 2021, the Federal Circuit reversed the district court’s denial of SRI’s motion to reinstate the willfulness verdict, restored the district court’s award of enhanced damages, and affirmed the district court’s award of attorney fees. We intend to seek review of the Federal Circuit’s decision. While the remaining proceedings may result in an additional loss, we do not believe it would have a material effect on our Consolidated Financial Statements.

- changed (2021-11-23):
[0000858877-21-000018:note_history:19]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal U.S. patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (PTAB) of the United States Patent and Trademark Office (“PTO”) to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal appealed the PTAB’s findings of unpatentability to the Federal Circuit. The Federal Circuit affirmed the PTAB’s findings of unpatentability as to three of the patents on March 10, 2021, and affirmed the PTAB’s findings of unpatentability as to the remaining four patents on May 11, 2021. On August 9, 2021, Centripetal filed a writ of certiorari seeking review of the Federal Circuit’s affirmance of several of the PTAB’s unpatentability findings, which the U.S. Supreme Court denied on October 4, 2021.
  (was, 2021-05-25, similarity 0.6734):
[0000858877-21-000008:note_history:19]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office (“PTO”) to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal appealed the PTAB’s findings of unpatentability to the Federal Circuit. The Federal Circuit affirmed the PTAB’s findings of unpatentability as to

- added (2021-11-23):
[0000858877-21-000018:note_history:20]
For the five asserted U.S. patents not subject to the IPR Proceedings, the district court conducted a bench trial by videoconference from May 6, 2020 to June 25, 2020. On October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The district court awarded

- changed (2021-11-23):
[0000858877-21-000018:note_history:21]
Centripetal $1.9 billion, comprised of $756 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $14 million. The district court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $168 million and a maximum annual royalty of $300 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $84 million and a maximum annual royalty of $150 million. We believe that the district court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We have appealed the district court’s judgment as to the four patents found valid and infringed to the Federal Circuit. On October 28, 2020, by agreement of the parties, the district court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment.
  (was, 2021-05-25, similarity 0.8532):
[0000858877-21-000008:note_history:21]
From May 6, 2020 to June 25, 2020, the district court conducted a bench trial by videoconference on the claims in the five patents not subject to the IPR Proceedings. On October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The district court awarded Centripetal $1.9 billion, comprised of $756 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $14 million. The district court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $168 million and a maximum annual royalty of $300 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $84 million and a maximum annual royalty of $150 million. We believe that the district court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We have appealed the district court’s judgment as to the four patents found valid and infringed to the Federal Circuit, and we believe that any relief ultimately awarded would not be material. On October 28, 2020, by agreement of the parties, the district court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment.

- changed (2021-11-23):
[0000858877-21-000018:note_history:22]
On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. district court proceedings, one of which has been invalidated by the PTAB. On June 22, 2021, Centripetal amended one of its complaints to assert one additional European patent and one additional German Utility Model patent. Centripetal seeks both injunctive relief and damages on these newly added patents. We believe we have strong defenses.
  (was, 2021-05-25, similarity 0.6551):
[0000858877-21-000008:note_history:22]
On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. district court proceedings, one of which has been invalidated by the PTAB. We believe we have strong defenses. Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of the cases at this time.

- added (2021-11-23):
[0000858877-21-000018:note_history:23]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of either litigation at this time. If we do not prevail in either litigation, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

- added (2021-11-23):
[0000858877-21-000018:note_history:24]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in E.D. Tex., seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. As of November 27, 2020, the PTO preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings. On January 13, 2021, the court entered an order staying the case pending the conclusion of the ex parte reexamination proceedings (“Reexamination Proceedings”). While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in court, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

- changed (2021-11-23):
[0000858877-21-000018:note_history:25]
On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) (which we subsequently acquired) in D. Del, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot has asserted in its E.D. Tex. case. On September 3, 2021, the court stayed the case pending the ultimate resolution of the Reexamination Proceedings. Due to the early stage of the litigation as well as uncertainties in the litigation processes, we are unable, at this time, to reasonably estimate a potential range of loss, if any, or the ultimate outcome of this litigation.
  (was, 2021-05-25, similarity 0.6043):
[0000858877-21-000008:note_history:25]
On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) (which we subsequently acquired) in D. Del, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot has asserted in its E.D. Tex case. We are currently assessing this case. Due to the early stage of the litigation as well as uncertainties in the litigation processes, we are unable, at this time, to reasonably estimate a potential range of loss, if any, or the ultimate outcome of this litigation.

- changed (2021-11-23):
[0000858877-21-000018:note_history:26]
Viasat     On January 21, 2016, Viasat, Inc. (“Viasat”) filed suit against Acacia (which we subsequently acquired) in the California Superior Court for San Diego County (“SDSC”) seeking unpaid royalties for breach of contract and the implied covenant of good faith and fair dealing, and damages for trade secret misappropriation for certain products (“Viasat 1”). Acacia counterclaimed for patent and trade secret misappropriation, contract, and unfair competition claims. On July 17, 2019, the jury found for Viasat on its contract claims, and awarded Viasat $49 million for unpaid royalties through 2018. The jury further found that Acacia willfully misappropriated Viasat’s trade secrets and awarded Viasat $1. On Acacia’s counterclaims, the jury found for Acacia on its contract and trade secret claims and awarded Acacia $1. Both Acacia and Viasat have pending appeals to the California Court of Appeal. On November 6, 2019, Viasat filed a second suit in SDSC, alleging contract and trade secret claims for Acacia products sold from January 1, 2019 forward (“Viasat 2”). On February 28, 2020, the court stayed Viasat 2 pending the appeal in Viasat 1. On June 9, 2020, Viasat filed a third suit in SDSC (“Viasat 3”). In Viasat 3, Viasat alleges contract and trade secrets claims for sales of additional Acacia products. On August 11, 2020, the court stayed Viasat 3 pending the appeal in Viasat 1.
  (was, 2021-05-25, similarity 0.9059):
[0000858877-21-000008:note_history:26]
covenant of good faith and fair dealing, and damages for trade secret misappropriation for certain products (“Viasat 1”). Acacia counterclaimed for patent and trade secret misappropriation, contract, and unfair competition claims. On July 17, 2019, the jury found for Viasat on its contract claims, and awarded Viasat $49 million for unpaid royalties through 2018. The jury further found that Acacia willfully misappropriated Viasat’s trade secrets and awarded Viasat $1. On Acacia’s counterclaims, the jury found for Acacia on its contract and trade secret claims and awarded Acacia $1. Both Acacia and Viasat have pending appeals to the California Court of Appeal. On November 6, 2019, Viasat filed a second suit in SDSC, alleging contract and trade secret claims for Acacia products sold from January 1, 2019 forward (“Viasat 2”). On February 28, 2020, the court stayed Viasat 2 pending the appeal in Viasat 1. On June 9, 2020, Viasat filed a third suit in SDSC (“Viasat 3”). In Viasat 3, Viasat alleges contract and trade secrets claims for sales of additional Acacia products. On August 11, 2020, the court stayed Viasat 3 pending the appeal in Viasat 1.

- added (2021-11-23):
[0000858877-21-000018:note_history:27]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court - Business Litigation Session against ViaSat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation. On April 5, 2018, ViaSat counterclaimed with contract, trade secret, and unfair competition claims (collectively, with Viasat 1, Viasat 2 and Viasat 3, the “Viasat Cases”). On December 13, 2018, the Massachusetts court entered an order staying the Massachusetts litigation, which has been extended to December 31, 2021.
While we believe Acacia has strong defenses in each of the Viasat Cases, we are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If Acacia does not prevail, we believe that any relief ultimately assessed in any of the Viasat Cases would not have a material effect on our Consolidated Financial Statements.In addition, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.

- removed (2021-11-23):
[0000858877-21-000008:note_history:28]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of May 1, 2021 and July 25, 2020, the liability for these purchase commitments was $129 million and $141 million, respectively, and was included in other current liabilities. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $35 million and $131 million for the first nine months of fiscal 2021 and 2020, respectively.

- removed (2021-11-23):
[0000858877-21-000008:note_history:29]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.2 billion and $0.3 billion as of May 1, 2021 and July 25, 2020, respectively.

- removed (2021-11-23):
[0000858877-21-000008:note_history:30]
Charter Communications, Inc. (“Charter”), which acquired Time Warner Cable (“TWC”) in May 2016, sought indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Following a trial on March 3, 2017, the jury found that TWC willfully infringed five patents and awarded Sprint $140 million in damages, as well as pre- and post-judgment interest of approximately $10 million. After the judgment was affirmed on appeal, Charter reported that it paid the judgment in full. We resolved Charter’s indemnity claim effective February 4, 2021 for an amount that does not have a material effect on our financial position.

- removed (2021-11-23):
[0000858877-21-000008:note_history:31]
We have been asked to indemnify certain of our service provider customers that have been subject to patent infringement claims asserted by ChanBond, LLC (“ChanBond”) in federal court in Delaware on September 21, 2015. ChanBond alleges that 13 service provider defendants, including among others, Comcast Corporation, Charter Communications, Inc. (“Charter”), Time Warner Cable, Inc. (subsequently acquired by Charter), Cox Communications, Inc. (“Cox”), and Cablevision Systems Corporation (subsequently acquired by Altice USA, Inc.), infringe three patents by providing high speed cable internet services to their customers utilizing cable modems and cable modem termination systems, consistent with the DOCSIS 3.0 standard, provided by us and other manufacturers generally used in combination with each other. ChanBond seeks monetary damages and injunctive relief against the service provider customers, although two of the asserted patents expire on June 19, 2021, and the third expires on September 17, 2021. The Court has set ChanBond’s case against Cox for trial on May 20, 2021. The other cases against the remaining service provider defendants have not yet been set for trial. We believe that the service provider defendants have strong non-infringement, invalidity and other defenses and that ChanBond will not be able to meet its burden required for injunctive relief.

- removed (2021-11-23):
[0000858877-21-000008:note_history:32]
Verizon Communications Inc. has requested that we indemnify it and seven of its subsidiaries (collectively, “Verizon”) for a subset of the patent infringement claims asserted by Huawei Technologies Co. Ltd. (“Huawei”) in lawsuits filed against Verizon on February 5, 2020, in the United States District Court for the Eastern District of Texas (“E.D. Tex”) and the United States District Court for the Western District of Texas (“W.D. Tex”). In the E.D. Tex case, Huawei alleges infringement of four patents required to operate the G.709 standard adopted by the Telecommunication Standardization Sector of the International Telecommunications Union by using products supplied by us. Huawei seeks monetary damages. The E.D. Tex court has set a trial date for July 9, 2021. In the W.D. Tex case, Huawei alleges infringement of four patents, two patents involving Cisco

- removed (2021-11-23):
[0000858877-21-000008:note_history:33]
Webex and Cisco video endpoints that allow content sharing in a video conference, and two patents involving Cisco routers that support Ethernet Flow Point functionality and/or specific network convergence functionalities. Huawei seeks monetary damages and injunctive relief in the W.D. Tex case. The W.D. Tex court has set a trial date for October 4, 2021. We believe that Verizon has strong defenses in the cases and that Huawei will not be able to meet its burden required for injunctive relief in the W.D. Tex case.

- removed (2021-11-23):
[0000858877-21-000008:note_history:34]
three of the patents on March 10, 2021, and affirmed the PTAB’s findings of unpatentability as to the remaining four patents on May 11, 2021.

- removed (2021-11-23):
[0000858877-21-000008:note_history:35]
Finjan     On January 6, 2017, Finjan, Inc. (“Finjan”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, originally seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Finjan alleged that Cisco’s AMP and ThreatGrid products and the URL rewrite feature of Cisco’s ESA Outbreak Filter product infringe five patents. On May 24, 2021, we resolved all claims for an amount that does not have a material effect on our financial position.

- removed (2021-11-23):
[0000858877-21-000008:note_history:36]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in E.D. Tex, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. As of November 27, 2020, the PTO preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings. On January 13, 2021, the court entered an order staying the case pending the conclusion of the ex parte reexamination proceedings. While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in court, we believe that any damages ultimately assessed would not be material.

- removed (2021-11-23):
[0000858877-21-000008:note_history:37]
Monarch     On January 21, 2020, Monarch Networking Solutions LLC (“Monarch”) asserted patent infringement claims against us in E.D. Tex alleging that certain Cisco routers and firewalls infringe three U.S. patents. Monarch seeks damages, including enhanced damages for alleged willful infringement, and a running royalty on future sales. The E.D. Tex court set trial to begin on July 12, 2021. On May 13, 2020, Monarch filed a second action against us in W.D. Tex, alleging that two factor authentication functionality in Duo and Meraki MR and MX access point products infringe one U.S. patent. Monarch seeks damages, including enhanced damages for alleged willful infringement, and a running royalty on future sales. The W.D. Tex court set trial to begin on November 14, 2021. While we believe that we have strong non-infringement and invalidity arguments, and that Monarch’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court, we believe that any damages ultimately assessed would not be material.

- removed (2021-11-23):
[0000858877-21-000008:note_history:38]
Viasat     On January 21, 2016, Viasat, Inc. (“Viasat”) filed suit against Acacia (which we subsequently acquired) in the California Superior Court for San Diego County (“SDSC”) seeking unpaid royalties for breach of contract and the implied

- removed (2021-11-23):
[0000858877-21-000008:note_history:39]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court - Business Litigation Session against ViaSat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation. On April 5, 2018, ViaSat counterclaimed with contract, trade secret, and unfair competition claims (collectively, with Viasat 1, Viasat 2 and Viasat 3, the “Viasat Cases”). On December 13, 2018, the Massachusetts court entered an order staying the Massachusetts litigation, which has been extended to June 30, 2021.

- removed (2021-11-23):
[0000858877-21-000008:note_history:40]
While we believe Acacia has strong defenses in each of the Viasat Cases, we are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If Acacia does not prevail, we believe that any relief ultimately assessed in any of the Viasat Cases would not be material.
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-23):
[0000858877-21-000018:note_history:41]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.
  (was, 2021-05-25, similarity 0.9887):
[0000858877-21-000008:note_history:41]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-23):
[0000858877-21-000018:note_history:42]
We have prepared the accompanying financial data as of October 30, 2021 and for the first quarter of fiscal 2022 and 2021, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 31, 2021 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021.
  (was, 2021-05-25, similarity 0.9739):
[0000858877-21-000008:note_history:42]
We have prepared the accompanying financial data as of May 1, 2021 and for the third quarter and first nine months of fiscal 2021 and 2020, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 25, 2020 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 25, 2020.

- added (2021-11-23):
[0000858877-21-000018:note_history:43]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 30, 2021, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2022 and 2021, as applicable, have been made. The results of operations for the first quarter of fiscal 2022 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- changed (2021-11-23):
[0000858877-21-000018:note_history:44]
Our consolidated financial statements include our accounts and entities consolidated under the variable interest and voting models. The noncontrolling interests attributed to these investments, if material, are presented as a separate component from our equity in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.
  (was, 2021-05-25, similarity 0.9897):
[0000858877-21-000008:note_history:44]
Our consolidated financial statements include our accounts and entities consolidated under the variable interest and voting models. The noncontrolling interests attributed to these investments, if any, are presented as a separate component from our equity in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

- removed (2021-11-23):
[0000858877-21-000008:note_history:45]
At our annual meeting of shareholders held on December 10, 2020, shareholders voted to approve changing our state of incorporation from California to Delaware. The reincorporation became effective January 25, 2021.

- removed (2021-11-23):
[0000858877-21-000008:note_history:46]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of May 1, 2021, the results of operations, the statements of comprehensive income (loss) and the statements of equity for the third quarter and first nine months of fiscal 2021 and 2020, and the statements of cash flows for the first nine months of fiscal 2021 and 2020, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2021 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-11-23):
[0000858877-21-000018:note_history:47]
Acquired Revenue Contracts with Customers in Business Combination  In October 2021, the Financial Accounting Standards Board (FASB) issued an accounting standard update that requires companies to apply Accounting Standards Codification 606 to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination. We early adopted this accounting standard update beginning in the first quarter of fiscal 2022 and did not have a material impact on our Consolidated Financial Statements. The ongoing impact of this standard will be fact dependent on the transactions within its scope.

- added (2021-11-23):
[0000858877-21-000018:note_history:48]
(b)Recent Accounting Standards or Updates Not Yet Effective

- added (2021-11-23):
[0000858877-21-000018:note_history:49]
Reference Rate Reform  In March 2020, the FASB issued an accounting standard update and subsequent amendments that provide optional expedients and exceptions to the current guidance on contract modification and hedging relationships to ease the financial reporting burden of the expected market transition from the London InterBank Offered Rate (LIBOR) and other interbank offered rates to alternative reference rates. This accounting standard update was effective upon issuance and may be 
applied prospectively through December 31, 2022. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.

- removed (2021-11-23):
[0000858877-21-000008:note_history:50]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. We adopted this standard at the beginning of our first quarter of fiscal 2021, applied it at the beginning of the period of adoption and did not restate prior periods. The standard primarily impacts our financial assets measured at amortized cost and available-for-sale debt securities. The standard did not have a material impact on our consolidated financial statements upon adoption.

- removed (2021-11-23):
[0000858877-21-000008:note_history:51]
Our significant accounting policies have been updated as a result of adopting this standard are as follows:

- removed (2021-11-23):
[0000858877-21-000008:note_history:52]
Allowance for Accounts Receivable, Contract Assets and Financing Receivables     We estimate our allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, we determine collectibility by pooling our assets with similar characteristics.

- removed (2021-11-23):
[0000858877-21-000008:note_history:53]
The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. Our internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality. Our assets within each internal credit risk rating share similar risk characteristics and therefore are assessed as one portfolio segment for credit loss. Assets that do not share risk characteristics are evaluated on an individual basis. The allowances for credit losses are each measured by multiplying the exposure probability of default, the probability the asset will default within a given time frame, by the loss given default rate, the percentage of the asset not expected to be collected due to default, based on the pool of assets.

- removed (2021-11-23):
[0000858877-21-000008:note_history:54]
Probability of default rates are published quarterly by third-party credit agencies. Adjustments to our internal credit risk ratings may take into account including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

- removed (2021-11-23):
[0000858877-21-000008:note_history:55]
Available-for-Sale Debt Investments     For our available-for-sale debt securities in an unrealized loss position, we determine whether a credit loss exists. In this assessment, we consider the extent to which the fair value is less than the amortized cost, any changes to the rating of the security by a rating agency, and adverse conditions specifically related to the security, among other factors. If factors indicate a credit loss exists, an allowance for credit loss is recorded to other income (loss), net, limited by the amount that the fair value is less than the amortized cost basis. The amount of fair value change relating to all other factors will be recognized in other comprehensive income (OCI).


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-23):
[0000858877-21-000018:note_history:56]
|  | October 30, 2021 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 506 |  |  | 1.13 | % |  | $ | 2,508 |  |  | 1.75 | % |
  (was, 2021-05-25, similarity 0.9706):
[0000858877-21-000008:note_history:56]
|  | May 1, 2021 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 2,000 |  |  | 1.90 | % |  | $ | 3,005 |  |  | 2.07 | % |

- changed (2021-11-23):
[0000858877-21-000018:note_history:57]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of October 30, 2021 and July 31, 2021.
  (was, 2021-05-25, similarity 0.9818):
[0000858877-21-000008:note_history:57]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of May 1, 2021 and July 25, 2020.

- changed (2021-11-23):
[0000858877-21-000018:note_history:58]
|  |  |  | October 30, 2021 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.13% |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 0.97% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.29% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,500 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (78) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 80 |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 9,502 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 506 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,996 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 9,502 |  |  |  |  | $ | 11,526 |  |  |  |
  (was, 2021-05-25, similarity 0.9368):
[0000858877-21-000008:note_history:58]
|  |  |  | May 1, 2021 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | — |  |  | — |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | — |  |  | — |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.15% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.00% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.31% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 11,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (81) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 113 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 11,532 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 2,000 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,532 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 11,532 |  |  |  |  | $ | 14,583 |  |  |  |

- changed (2021-11-23):
[0000858877-21-000018:note_history:59]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 30, 2021, we were in compliance with all debt covenants.
  (was, 2021-05-25, similarity 0.9885):
[0000858877-21-000008:note_history:59]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of May 1, 2021, we were in compliance with all debt covenants.

- changed (2021-11-23):
[0000858877-21-000018:note_history:60]
As of October 30, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2021-05-25, similarity 0.9624):
[0000858877-21-000008:note_history:60]
As of May 1, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2021-11-23):
[0000858877-21-000018:note_history:61]
| Fiscal Year | Amount |
| 2022 (remaining nine months) | $ | 500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 9,500 |  |
  (was, 2021-05-25, similarity 0.9707):
[0000858877-21-000008:note_history:61]
| Fiscal Year | Amount |
| 2021 (remaining three months) | $ | — |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 11,500 |  |

- changed (2021-11-23):
[0000858877-21-000018:note_history:62]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. The credit agreement is structured as an amendment and restatement of our 364-day credit agreement, which would have terminated on May 14, 2021. As of October 30, 2021, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.
  (was, 2021-05-25, similarity 0.7347):
[0000858877-21-000008:note_history:62]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. The credit agreement is structured as an amendment and restatement of our 364-day credit agreement, which would have terminated on May 14, 2021. As of May 1, 2021, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the 364-day credit facility.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-23):
[0000858877-21-000018:note_history:63]
| October 30, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,032 |  |  | $ | 12 |  |  | $ | (9) |  |  | $ | 2,035 |  |
| U.S. government agency securities | 142 |  |  | — |  |  | — |  |  | 142 |  |
| Corporate debt securities | 9,114 |  |  | 156 |  |  | (50) |  |  | 9,220 |  |
| U.S. agency mortgage-backed securities | 2,790 |  |  | 24 |  |  | (21) |  |  | 2,793 |  |
| Commercial paper | 1,054 |  |  | — |  |  | — |  |  | 1,054 |  |
| Certificates of deposit | 269 |  |  | — |  |  | — |  |  | 269 |  |
| Total | $ | 15,401 |  |  | $ | 192 |  |  | $ | (80) |  |  | $ | 15,513 |  |
  (was, 2021-05-25, similarity 0.9755):
[0000858877-21-000008:note_history:63]
| July 25, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 2,614 |  |  | $ | 71 |  |  | $ | — |  |  | $ | 2,685 |  |
| U.S. government agency securities | 110 |  |  | — |  |  | — |  |  | 110 |  |
| Corporate debt securities | 11,549 |  |  | 334 |  |  | (6) |  |  | 11,877 |  |
| U.S. agency mortgage-backed securities | 1,987 |  |  | 49 |  |  | (1) |  |  | 2,035 |  |
| Commercial paper | 727 |  |  | — |  |  | — |  |  | 727 |  |
| Certificates of deposit | 176 |  |  | — |  |  | — |  |  | 176 |  |
| Total | $ | 17,163 |  |  | $ | 454 |  |  | $ | (7) |  |  | $ | 17,610 |  |

- changed (2021-11-23):
[0000858877-21-000018:note_history:64]
| July 31, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,773 |  |  | $ | 21 |  |  | $ | — |  |  | $ | 1,794 |  |
| U.S. government agency securities | 152 |  |  | — |  |  | — |  |  | 152 |  |
| Non-U.S. government and agency securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Corporate debt securities | 8,727 |  |  | 213 |  |  | (30) |  |  | 8,910 |  |
| U.S. agency mortgage-backed securities | 2,838 |  |  | 34 |  |  | (10) |  |  | 2,862 |  |
| Commercial paper | 1,190 |  |  | — |  |  | — |  |  | 1,190 |  |
| Certificates of deposit | 295 |  |  | — |  |  | — |  |  | 295 |  |
| Total | $ | 14,978 |  |  | $ | 268 |  |  | $ | (40) |  |  | $ | 15,206 |  |
  (was, 2021-05-25, similarity 0.9248):
[0000858877-21-000008:note_history:64]
| May 1, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,881 |  |  | $ | 22 |  |  | $ | — |  |  | $ | 1,903 |  |
| U.S. government agency securities | 167 |  |  | — |  |  | — |  |  | 167 |  |
| Non-U.S. government and agency securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Corporate debt securities | 9,329 |  |  | 218 |  |  | (35) |  |  | 9,512 |  |
| U.S. agency mortgage-backed securities | 2,788 |  |  | 35 |  |  | (13) |  |  | 2,810 |  |
| Commercial paper | 1,333 |  |  | — |  |  | — |  |  | 1,333 |  |
| Certificates of deposit | 440 |  |  | — |  |  | — |  |  | 440 |  |
| Total (1) | $ | 15,941 |  |  | $ | 275 |  |  | $ | (48) |  |  | $ | 16,168 |  |

- added (2021-11-23):
[0000858877-21-000018:note_history:65]
|  | Three Months Ended |
|  | October 30, 2021 |  | October 24, 2020 |
| Gross realized gains | $ | 6 |  |  | $ | 15 |  |
| Gross realized losses | — |  |  | — |  |
| Total | $ | 6 |  |  | $ | 15 |  |

- changed (2021-11-23):
[0000858877-21-000018:note_history:66]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 30, 2021 and July 31, 2021 (in millions):
  (was, 2021-05-25, similarity 0.9762):
[0000858877-21-000008:note_history:66]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at May 1, 2021 and July 25, 2020 (in millions):

- added (2021-11-23):
[0000858877-21-000018:note_history:67]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 30, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,341 |  |  | $ | (9) |  |  | $ | 2 |  |  | $ | — |  |  | $ | 1,343 |  |  | $ | (9) |  |
| U.S. government agency securities | 100 |  |  | — |  |  | — |  |  | — |  |  | 100 |  |  | — |  |
| Corporate debt securities | 3,204 |  |  | (24) |  |  | 27 |  |  | (1) |  |  | 3,231 |  |  | (25) |  |
| U.S. agency mortgage-backed securities | 1,937 |  |  | (20) |  |  | 52 |  |  | (1) |  |  | 1,989 |  |  | (21) |  |
| Commercial paper | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |  | — |  |
| Total | $ | 6,607 |  |  | $ | (53) |  |  | $ | 81 |  |  | $ | (2) |  |  | $ | 6,688 |  |  | $ | (55) |  |

- changed (2021-11-23):
[0000858877-21-000018:note_history:68]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 31, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 468 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 468 |  |  | $ | — |  |
| U.S. government agency securities | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |
| Corporate debt securities | 1,086 |  |  | (5) |  |  | 6 |  |  | — |  |  | 1,092 |  |  | (5) |  |
| U.S. agency mortgage-backed securities | 1,293 |  |  | (10) |  |  | 13 |  |  | — |  |  | 1,306 |  |  | (10) |  |
| Commercial paper | 37 |  |  | — |  |  | — |  |  | — |  |  | 37 |  |  | — |  |
| Total | $ | 2,910 |  |  | $ | (15) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 2,929 |  |  | $ | (15) |  |
  (was, 2021-05-25, similarity 0.9476):
[0000858877-21-000008:note_history:68]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| May 1, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 468 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 468 |  |  | $ | — |  |
| U.S. government agency securities | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |
| Corporate debt securities | 1,242 |  |  | (10) |  |  | 6 |  |  | — |  |  | 1,248 |  |  | (10) |  |
| U.S. agency mortgage-backed securities | 1,618 |  |  | (13) |  |  | — |  |  | — |  |  | 1,618 |  |  | (13) |  |
| Commercial paper | 46 |  |  | — |  |  | — |  |  | — |  |  | 46 |  |  | — |  |
| Certificates of deposit | 16 |  |  | — |  |  | — |  |  | — |  |  | 16 |  |  | — |  |
| Total | $ | 3,416 |  |  | $ | (23) |  |  | $ | 6 |  |  | $ | — |  |  | $ | 3,422 |  |  | $ | (23) |  |

- changed (2021-11-23):
[0000858877-21-000018:note_history:69]
The following table summarizes the maturities of our available-for-sale debt investments as of October 30, 2021 (in millions):
  (was, 2021-05-25, similarity 0.958):
[0000858877-21-000008:note_history:69]
The following table summarizes the maturities of our available-for-sale debt investments as of May 1, 2021 (in millions):

- added (2021-11-23):
[0000858877-21-000018:note_history:70]
We recognized a net unrealized gain of $5 million during the first quarter of fiscal 2022 on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $2 million for the first quarter of fiscal 2022. We held equity interests in certain private equity funds of $1.0 billion and $0.9 billion as of October 30, 2021 and July 31, 2021, respectively, which are accounted for under the NAV practical expedient.

- changed (2021-11-23):
[0000858877-21-000018:note_history:71]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 30, 2021, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2021-05-25, similarity 0.8136):
[0000858877-21-000008:note_history:71]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of May 1, 2021, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- changed (2021-11-23):
[0000858877-21-000018:note_history:72]
The carrying value of our investments in privately held companies was $1.7 billion and $1.5 billion as of October 30, 2021 and July 31, 2021, respectively. Of the total carrying value of our investments in privately held companies as of October 30, 2021, $1.0 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of October 30, 2021, we have total funding commitments of $0.2 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.
  (was, 2021-05-25, similarity 0.9453):
[0000858877-21-000008:note_history:72]
The carrying value of our investments in privately held companies was $1.4 billion and $1.3 billion as of May 1, 2021 and July 25, 2020, respectively. 
Of the total carrying value of our investments in privately held companies as of May 1, 2021, $0.8 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of May 1, 2021, we have total funding commitments of $0.2 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to privately held investments.

- removed (2021-11-23):
[0000858877-21-000008:note_history:73]
(1) Net unsettled investment sales were $262 million as of May 1, 2021 and were included in other current assets.

- removed (2021-11-23):
[0000858877-21-000008:note_history:74]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1, 2021 |  | April 25, 2020 |  | May 1, 2021 |  | April 25, 2020 |
| Gross realized gains | $ | 24 |  |  | $ | 20 |  |  | $ | 48 |  |  | $ | 45 |  |
| Gross realized losses | (2) |  |  | (21) |  |  | (2) |  |  | (25) |  |
| Total | $ | 22 |  |  | $ | (1) |  |  | $ | 46 |  |  | $ | 20 |  |

- removed (2021-11-23):
[0000858877-21-000008:note_history:75]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 25, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government agency securities | $ | 33 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 33 |  |  | $ | — |  |
| Corporate debt securities | 1,060 |  |  | (6) |  |  | 3 |  |  | — |  |  | 1,063 |  |  | (6) |  |
| U.S. agency mortgage-backed securities | 265 |  |  | (1) |  |  | — |  |  | — |  |  | 265 |  |  | (1) |  |
| Total | $ | 1,358 |  |  | $ | (7) |  |  | $ | 3 |  |  | $ | — |  |  | $ | 1,361 |  |  | $ | (7) |  |

- removed (2021-11-23):
[0000858877-21-000008:note_history:76]
Our net unrealized gains recognized during the reporting period on our marketable securities still held as of May 1, 2021 was $3 million for each of the third quarter and first nine months of fiscal 2021. Our net adjustments to non-marketable equity securities measured using the measurement alternative was a net loss of $3 million and a net gain of $1 million for the third quarter and first nine months of fiscal 2021, respectively. These adjustments were net losses of $4 million and $1 million for the corresponding periods of fiscal 2020, respectively. We held equity interests in certain private equity funds of $0.8 billion and $0.7 billion as of May 1, 2021 and July 25, 2020, respectively, which are accounted for under the NAV practical expedient.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-23):
[0000858877-21-000018:note_history:77]
|  |  |  | October 30, 2021 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.13% |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 0.97% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.29% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,500 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (78) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 80 |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 9,502 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 506 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,996 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 9,502 |  |  |  |  | $ | 11,526 |  |  |  |
  (was, 2021-05-25, similarity 0.9368):
[0000858877-21-000008:note_history:77]
|  |  |  | May 1, 2021 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | — |  |  | — |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | — |  |  | — |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.15% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.00% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.31% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 11,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (81) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 113 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 11,532 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 2,000 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,532 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 11,532 |  |  |  |  | $ | 14,583 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-23):
[0000858877-21-000018:note_history:78]
As of October 30, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2021-05-25, similarity 0.9624):
[0000858877-21-000008:note_history:78]
As of May 1, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2021-11-23):
[0000858877-21-000018:note_history:79]
| Fiscal Year | Amount |
| 2022 (remaining nine months) | $ | 500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 9,500 |  |
  (was, 2021-05-25, similarity 0.9707):
[0000858877-21-000008:note_history:79]
| Fiscal Year | Amount |
| 2021 (remaining three months) | $ | — |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 11,500 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-23):
[0000858877-21-000018:note_history:80]
|  | October 30, 2021 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 506 |  |  | 1.13 | % |  | $ | 2,508 |  |  | 1.75 | % |
  (was, 2021-05-25, similarity 0.9706):
[0000858877-21-000008:note_history:80]
|  | May 1, 2021 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 2,000 |  |  | 1.90 | % |  | $ | 3,005 |  |  | 2.07 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-11-23):
[0000858877-21-000018:note_history:81]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |
| Product revenue: |  |  |  |
| Secure, Agile Networks | $ | 5,967 |  |  | $ | 5,434 |  |
| Hybrid Work | 1,109 |  |  | 1,193 |  |
| End-to-End Security | 895 |  |  | 861 |  |
| Internet for the Future | 1,374 |  |  | 942 |  |
| Optimized Application Experiences | 181 |  |  | 153 |  |
| Other Products | 3 |  |  | 3 |  |
| Total Product | 9,529 |  |  | 8,587 |  |
| Services | 3,371 |  |  | 3,342 |  |
| Total | $ | 12,900 |  |  | $ | 11,929 |  |

- added (2021-11-23):
[0000858877-21-000018:note_history:82]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |
| Revenue: |  |  |  |
| Secure, Agile Networks | $ | 5,967 |  |  | $ | 5,434 |  |
| Hybrid Work | 1,109 |  |  | 1,193 |  |
| End-to-End Security | 895 |  |  | 861 |  |
| Internet for the Future | 1,374 |  |  | 942 |  |
| Optimized Application Experiences | 181 |  |  | 153 |  |
| Other Products | 3 |  |  | 3 |  |
| Total Product | 9,529 |  |  | 8,587 |  |
| Services | 3,371 |  |  | 3,342 |  |
| Total | $ | 12,900 |  |  | $ | 11,929 |  |

- removed (2021-11-23):
[0000858877-21-000008:note_history:83]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,832 |  |  | $ | 6,447 |  |  | $ | 19,564 |  |  | $ | 20,566 |  |
| Applications | 1,426 |  |  | 1,363 |  |  | 4,160 |  |  | 4,211 |  |
| Security | 876 |  |  | 778 |  |  | 2,559 |  |  | 2,343 |  |
| Other Products | 6 |  |  | 9 |  |  | 15 |  |  | 27 |  |
| Total Product | 9,139 |  |  | 8,597 |  |  | 26,298 |  |  | 27,146 |  |
| Services | 3,664 |  |  | 3,386 |  |  | 10,394 |  |  | 10,001 |  |
| Total | $ | 12,803 |  |  | $ | 11,983 |  |  | $ | 36,692 |  |  | $ | 37,147 |  |

- removed (2021-11-23):
[0000858877-21-000008:note_history:84]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,832 |  |  | $ | 6,447 |  |  | $ | 19,564 |  |  | $ | 20,566 |  |
| Applications | 1,426 |  |  | 1,363 |  |  | 4,160 |  |  | 4,211 |  |
| Security | 876 |  |  | 778 |  |  | 2,559 |  |  | 2,343 |  |
| Other Products | 6 |  |  | 9 |  |  | 15 |  |  | 27 |  |
| Total Product | 9,139 |  |  | 8,597 |  |  | 26,298 |  |  | 27,146 |  |
| Services | 3,664 |  |  | 3,386 |  |  | 10,394 |  |  | 10,001 |  |
| Total | $ | 12,803 |  |  | $ | 11,983 |  |  | $ | 36,692 |  |  | $ | 37,147 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-11-23):
[0000858877-21-000018:note_history:85]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

- changed (2021-11-23):
[0000858877-21-000018:note_history:86]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 30, 2021 and July 31, 2021 was $49 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2021-05-25, similarity 0.9827):
[0000858877-21-000008:note_history:86]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of May 1, 2021 and July 25, 2020 was $61 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2021-11-23):
[0000858877-21-000018:note_history:87]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.
  (was, 2021-05-25, similarity 0.9136):
[0000858877-21-000008:note_history:87]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

- changed (2021-11-23):
[0000858877-21-000018:note_history:88]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license’s utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.
  (was, 2021-05-25, similarity 0.9985):
[0000858877-21-000008:note_history:88]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license's utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

- removed (2021-11-23):
[0000858877-21-000008:note_history:89]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

- removed (2021-11-23):
[0000858877-21-000008:note_history:90]
Infrastructure Platforms consist of our core networking technologies of switching, routing, wireless, and data center products that are designed to work together to deliver networking capabilities and transport and/or store data. These technologies consist of both hardware and software offerings, including software licenses and SaaS, that help our customers build networks, automate, orchestrate, integrate, and digitize data. We are shifting and expanding more of our business to software and subscriptions across our core networking portfolio. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2021-11-23):
[0000858877-21-000008:note_history:91]
Applications consists of offerings that utilize the core networking and data center platforms to provide their functions. The products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon

- removed (2021-11-23):
[0000858877-21-000008:note_history:92]
transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2021-11-23):
[0000858877-21-000008:note_history:93]
Security primarily includes our network security, cloud and email security, identity and access management, advanced threat protection, and unified threat management products. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers' network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2021-11-23):
[0000858877-21-000008:note_history:94]
Other Products primarily includes our cloud and system management products. These products include both hardware and software licenses. Our offerings in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-11-23):
[0000858877-21-000018:note_history:95]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

- changed (2021-11-23):
[0000858877-21-000018:note_history:96]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 30, 2021 and July 31, 2021 was $49 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2021-05-25, similarity 0.9827):
[0000858877-21-000008:note_history:96]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of May 1, 2021 and July 25, 2020 was $61 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2021-11-23):
[0000858877-21-000018:note_history:97]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.
  (was, 2021-05-25, similarity 0.9136):
[0000858877-21-000008:note_history:97]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

- changed (2021-11-23):
[0000858877-21-000018:note_history:98]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license’s utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.
  (was, 2021-05-25, similarity 0.9985):
[0000858877-21-000008:note_history:98]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license's utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

- changed (2021-11-23):
[0000858877-21-000018:note_history:99]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. Effective in the first quarter of fiscal 2022, we began reporting our product and service revenue in the following categories: Secure, Agile Networks; Hybrid Work; End-to-End Security; Internet for the Future; Optimized Application Experiences; Other Products; and Services. This change will better align our product categories with our strategic priorities. The following table presents this disaggregation of revenue (in millions):
  (was, 2021-05-25, similarity 0.7144):
[0000858877-21-000008:note_history:99]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. The following table presents this disaggregation of revenue (in millions):

- added (2021-11-23):
[0000858877-21-000018:note_history:100]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |
| Product revenue: |  |  |  |
| Secure, Agile Networks | $ | 5,967 |  |  | $ | 5,434 |  |
| Hybrid Work | 1,109 |  |  | 1,193 |  |
| End-to-End Security | 895 |  |  | 861 |  |
| Internet for the Future | 1,374 |  |  | 942 |  |
| Optimized Application Experiences | 181 |  |  | 153 |  |
| Other Products | 3 |  |  | 3 |  |
| Total Product | 9,529 |  |  | 8,587 |  |
| Services | 3,371 |  |  | 3,342 |  |
| Total | $ | 12,900 |  |  | $ | 11,929 |  |

- added (2021-11-23):
[0000858877-21-000018:note_history:101]
Amounts may not sum due to rounding.

- added (2021-11-23):
[0000858877-21-000018:note_history:102]
Secure, Agile Networks consists of our core networking technologies of switching, enterprise routing, wireless, and compute products. These technologies consist of both hardware and software offerings, including software licenses and SaaS, that help our customers build networks, automate, orchestrate, integrate, and digitize data. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2021-11-23):
[0000858877-21-000018:note_history:103]
Hybrid Work consists of our collaboration offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- changed (2021-11-23):
[0000858877-21-000018:note_history:104]
End-to-End Security consists of our overall security offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.
  (was, 2021-05-25, similarity 0.8759):
[0000858877-21-000008:note_history:104]
Security primarily includes our network security, cloud and email security, identity and access management, advanced threat protection, and unified threat management products. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers' network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2021-11-23):
[0000858877-21-000018:note_history:105]
Internet for the Future consists of our routed optical networking, public 5G, silicon, and optics offerings. These products consist primarily of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2021-11-23):
[0000858877-21-000018:note_history:106]
Optimized Application Experiences consists of our full stack observability and cloud-native platform offerings. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- changed (2021-11-23):
[0000858877-21-000018:note_history:107]
Accounts receivable, net was $5.3 billion as of October 30, 2021 compared to $5.8 billion as of July 31, 2021, as reported on the Consolidated Balance Sheets.
  (was, 2021-05-25, similarity 0.9645):
[0000858877-21-000008:note_history:107]
Accounts receivable, net was $4.4 billion as of May 1, 2021 compared to $5.5 billion as of July 25, 2020, as reported on the Consolidated Balance Sheets.

- added (2021-11-23):
[0000858877-21-000018:note_history:108]
The allowances for credit loss for our accounts receivable are summarized as follows (in millions):

- added (2021-11-23):
[0000858877-21-000018:note_history:109]
|  | Three Months Ended |
|  | October 30, 2021 |  | October 24, 2020 |
| Allowance for credit loss at beginning of period | $ | 109 |  |  | $ | 143 |  |
| Provisions (benefits) | 19 |  |  | 14 |  |
| Recoveries (write-offs), net | (14) |  |  | (6) |  |
| Foreign exchange and other | — |  |  | (26) |  |
| Allowance for credit loss at end of period | $ | 114 |  |  | $ | 125 |  |

- changed (2021-11-23):
[0000858877-21-000018:note_history:110]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $1.4 billion as of each of October 30, 2021 and July 31, 2021, and were included in other current assets and other assets.
  (was, 2021-05-25, similarity 0.9404):
[0000858877-21-000008:note_history:110]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $1.3 billion and $1.2 billion as of May 1, 2021 and July 25, 2020, respectively, and were included in other current assets and other assets.

- changed (2021-11-23):
[0000858877-21-000018:note_history:111]
|  | October 30,2021 |  | July 31,2021 |
| 1 to 4 | $ | 445 |  |  | $ | 521 |  |
| 5 to 6 | 839 |  |  | 770 |  |
| 7 and Higher | 154 |  |  | 166 |  |
| Total | $ | 1,438 |  |  | $ | 1,457 |  |
  (was, 2021-05-25, similarity 0.7531):
[0000858877-21-000008:note_history:111]
|  | May 1,2021 |
| 1 to 4 | $ | 379 |  |
| 5 to 6 | 840 |  |
| 7 and Higher | 91 |  |
| Total | $ | 1,310 |  |

- changed (2021-11-23):
[0000858877-21-000018:note_history:112]
Contract liabilities consist of deferred revenue. Deferred revenue was $22.1 billion as of October 30, 2021 compared to $22.2 billion as of July 31, 2021. We recognized approximately $4.1 billion of revenue during the first quarter of fiscal 2022 that was included in the deferred revenue balance at July 31, 2021.
  (was, 2021-05-25, similarity 0.8498):
[0000858877-21-000008:note_history:112]
Contract liabilities consist of deferred revenue. Deferred revenue was $20.9 billion as of May 1, 2021 compared to $20.4 billion as of July 25, 2020. We recognized approximately $2.6 billion and $9.5 billion of revenue during the third quarter and first nine months of fiscal 2021, respectively, that was included in the deferred revenue balance at July 25, 2020.

- changed (2021-11-23):
[0000858877-21-000018:note_history:113]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $994 million and $967 million as of October 30, 2021 and July 31, 2021, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $187 million and $123 million for the first quarter of fiscal 2022 and 2021, respectively, and was included in sales and marketing expenses.
  (was, 2021-05-25, similarity 0.9098):
[0000858877-21-000008:note_history:113]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $893 million and $732 million as of May 1, 2021 and July 25, 2020, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $134 million and $386 million for the third quarter and first nine months of fiscal 2021, respectively, and $118 million and $356 million for the corresponding periods of fiscal 2020, respectively, and was included in sales and marketing expenses.

- removed (2021-11-23):
[0000858877-21-000008:note_history:114]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

- removed (2021-11-23):
[0000858877-21-000008:note_history:115]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,832 |  |  | $ | 6,447 |  |  | $ | 19,564 |  |  | $ | 20,566 |  |
| Applications | 1,426 |  |  | 1,363 |  |  | 4,160 |  |  | 4,211 |  |
| Security | 876 |  |  | 778 |  |  | 2,559 |  |  | 2,343 |  |
| Other Products | 6 |  |  | 9 |  |  | 15 |  |  | 27 |  |
| Total Product | 9,139 |  |  | 8,597 |  |  | 26,298 |  |  | 27,146 |  |
| Services | 3,664 |  |  | 3,386 |  |  | 10,394 |  |  | 10,001 |  |
| Total | $ | 12,803 |  |  | $ | 11,983 |  |  | $ | 36,692 |  |  | $ | 37,147 |  |

- removed (2021-11-23):
[0000858877-21-000008:note_history:116]
Amounts may not sum due to rounding. We have made certain reclassifications to the product revenue amounts for prior period to conform to the current year presentation.

- removed (2021-11-23):
[0000858877-21-000008:note_history:117]
Infrastructure Platforms consist of our core networking technologies of switching, routing, wireless, and data center products that are designed to work together to deliver networking capabilities and transport and/or store data. These technologies consist of both hardware and software offerings, including software licenses and SaaS, that help our customers build networks, automate, orchestrate, integrate, and digitize data. We are shifting and expanding more of our business to software and subscriptions across our core networking portfolio. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2021-11-23):
[0000858877-21-000008:note_history:118]
Applications consists of offerings that utilize the core networking and data center platforms to provide their functions. The products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon

- removed (2021-11-23):
[0000858877-21-000008:note_history:119]
transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2021-11-23):
[0000858877-21-000008:note_history:120]
Other Products primarily includes our cloud and system management products. These products include both hardware and software licenses. Our offerings in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control.
