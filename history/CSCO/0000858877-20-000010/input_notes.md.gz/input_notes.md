# CSCO notes — 0000858877-20-000010


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000858877-20-000010:notes:1]
Portions of the registrant’s Proxy Statement relating to the registrant’s 2020 Annual Meeting of Shareholders, to be held on December 10, 2020, are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-20-000010:notes:2]
Basis of Presentation

[0000858877-20-000010:notes:3]
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2020, fiscal 2019 and fiscal 2018 were each 52-week fiscal years. The Consolidated Financial Statements include the accounts of ours and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-20-000010:notes:4]
Our consolidated financial statements include our accounts and entities consolidated under the variable interest and voting models. The noncontrolling interests attributed to these investments, if any, are presented as a separate component from our equity in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-20-000010:notes:5]
Certain reclassifications have been made to the amounts for prior years in order to conform to the current year’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-20-000010:notes:6]
Summary of Significant Accounting Policies

[0000858877-20-000010:notes:7]
(a) Cash and Cash Equivalents   We consider all highly liquid investments purchased with an original or remaining maturity of three months or less at the date of purchase to be cash equivalents. Cash and cash equivalents are maintained with various financial institutions.

[0000858877-20-000010:notes:8]
(b) Available-for-Sale Debt Investments   We classify our investments in fixed income securities as available-for-sale debt investments. Our available-for-sale debt investments primarily consist of U.S. government, U.S. government agency, corporate debt, and U.S. agency mortgage-backed securities. These available-for-sale debt investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of available-for-sale debt investments sold. These investments are recorded in the Consolidated Balance Sheets at fair value. Unrealized gains and losses on these investments, to the extent the investments are unhedged, are included as a separate component of accumulated other comprehensive income (AOCI), net of tax. We classify our investments as current based on the nature of the investments and their availability for use in current operations.

[0000858877-20-000010:notes:9]
(c) Equity Instruments   Our equity investments are accounted for as follows:

[0000858877-20-000010:notes:10]
| • | Marketable equity securities have readily determinable fair value (RDFV) that are measured and recorded at fair value through income. |

[0000858877-20-000010:notes:11]
| • | Non-marketable equity securities do not have RDFV and are measured using a measurement alternative recorded at cost less any impairment, plus or minus changes resulting from qualifying observable price changes. For certain of these securities, we have elected to apply the net asset value (NAV) practical expedient. The NAV is the estimated fair value of these investments. |

[0000858877-20-000010:notes:12]
| • | Equity method investments are securities we do not control, but are able to exert significant influence over the investee. These investments are measured at cost less any impairment, plus or minus our share of equity method investee income or loss. |

[0000858877-20-000010:notes:13]
(d) Impairments of Investments   When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and we will assess whether the impairment is other than temporary. An impairment is considered other than temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of the entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost basis of the security. If impairment is considered other than temporary based on condition (i) or (ii) described earlier, the entire difference between the amortized cost and the fair value of the debt security is recognized in earnings. If an impairment is considered other than temporary based on condition (iii), the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) will be recognized in earnings, and the amount relating to all other factors will be recognized in other comprehensive income (OCI).

[0000858877-20-000010:notes:14]
We hold non-marketable equity and other investments which are included in other assets in the Consolidated Balance Sheets. We monitor these investments for impairments and make reductions in carrying values if we determine that an impairment charge is required based primarily on the financial condition and near-term prospects of these companies.

[0000858877-20-000010:notes:15]
(e) Inventories   Inventories are stated at the lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. We provide inventory write-downs based on excess and obsolete inventories determined primarily by future demand forecasts. The write-down is measured as the difference between the cost of the inventory and market based upon assumptions about future demand and charged to the provision for inventory, which is a component of cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In addition, we record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0000858877-20-000010:notes:16]
(f) Allowance for Doubtful Accounts   The allowance for doubtful accounts is based on our assessment of the collectibility of customer accounts. We regularly review the allowance by considering factors such as historical experience, credit quality, age of the accounts receivable balances, economic conditions that may affect a customer’s ability to pay, and expected default frequency rates. Trade receivables are written off at the point when they are considered uncollectible.

[0000858877-20-000010:notes:17]
(g) Financing Receivables and Guarantees   We provide financing arrangements, including leases, financed service contracts, and loans, for certain qualified end-user customers to build, maintain, and upgrade their networks. Lease receivables primarily represent sales-type and direct-financing leases. Leases have on average a four-year term and are usually collateralized by a security interest in the underlying assets. Loan receivables include customers financing purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. Loan receivables have terms of three years on average. Financed service contracts typically have terms of one to three years and primarily relate to technical support services.

[0000858877-20-000010:notes:18]
We determine the adequacy of our allowance for credit loss by assessing the risks and losses inherent in our financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by us to our customers: lease receivables, loan receivables, and financed service contracts.

[0000858877-20-000010:notes:19]
We assess the allowance for credit loss related to financing receivables on either an individual or a collective basis. We consider various factors in evaluating lease and loan receivables and the earned portion of financed service contracts for possible impairment on an individual basis. These factors include our historical experience, credit quality and age of the receivable balances, and economic conditions that may affect a customer’s ability to pay. When the evaluation indicates that it is probable that all amounts due pursuant to the contractual terms of the financing agreement, including scheduled interest payments, are unable to be collected, the financing receivable is considered impaired. All such outstanding amounts, including any accrued interest, are assessed and reserved at the customer level. Our internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality financing receivables. Typically, we also consider financing receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. We evaluate the remainder of our financing receivables portfolio for impairment on a collective basis and record an allowance for credit loss at the portfolio segment level. When evaluating the financing receivables on a collective basis, we use historical default rates and expected default frequency rates published by major third-party credit-rating agencies as well as our own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk, and correlation.

[0000858877-20-000010:notes:20]
Expected default frequency rates and historical default rates are published quarterly by major third-party credit-rating agencies, and the internal credit risk rating is derived by taking into consideration various customer-specific factors and macroeconomic conditions. These factors, which include the strength of the customer’s business and financial performance, the quality of the customer’s banking relationships, our specific historical experience with the customer, the performance and outlook of the customer’s industry, the customer’s legal and regulatory environment, the potential sovereign risk of the geographic locations in which the customer is operating, and independent third-party evaluations, are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000858877-20-000010:notes:21]
Financing receivables are written off at the point when they are considered uncollectible, and all outstanding balances, including any previously earned but uncollected interest income, will be reversed and charged against the allowance for credit loss. We do not typically have any partially written-off financing receivables.

[0000858877-20-000010:notes:22]
Outstanding financing receivables that are aged 31 days or more from the contractual payment date are considered past due. We do not accrue interest on financing receivables that are considered impaired or more than 120 days past due unless either the receivable has not been collected due to administrative reasons or the receivable is well secured and in the process of collection. Financing receivables may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain. After a financing receivable has been categorized as nonaccrual, interest will be recognized when cash is received. A financing receivable may be returned to accrual status after all of the customer’s delinquent balances of principal and interest have been settled, and the customer remains current for an appropriate period.

[0000858877-20-000010:notes:23]
We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive a payment for the receivables from the third party based on our standard payment terms. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Deferred revenue relating to these financing arrangements is recorded in accordance with revenue recognition policies or for the fair value of the financing guarantees.

[0000858877-20-000010:notes:24]
(h) Leases   We lease real estate, information technology (IT) and other equipment and vehicles. We also have arrangements with certain suppliers and contract manufacturers which includes the leasing of dedicated space and equipment costs. Our leases have the option to extend or terminate the lease when it is reasonably certain that we will exercise that option.

[0000858877-20-000010:notes:25]
As a lessee, we determine if an arrangement is a lease at commencement. Our ROU lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments related to the lease. Operating lease ROU assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. We use incremental borrowing rates based on information available at the commencement date to determine the present value of our lease payments. Certain of our lease agreements contain variable lease payments. Our variable lease payments can fluctuate depending on the level of activity or the cost of certain services where we have elected to combine lease and non-lease components. While these payments are not included as part of our lease liabilities, they are recognized as variable lease expense in the period they are incurred.

[0000858877-20-000010:notes:26]
We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. As a lessor, we determine if an arrangement is a lease at inception. We provide leasing arrangements for our equipment to certain qualified customers. Our lease portfolio primarily consists of sales-type leases. We allocate the consideration in a bundled contract with our customers based on relative standalone selling prices of our lease and non-lease components. The residual value on our leased equipment is determined at the inception of the lease based on an analysis of estimates of the value of equipment, market factors and historical customer behavior. Residual value estimates are reviewed on a periodic basis and other-than-temporary declines are expensed in the period they occur. Our leases generally provide an end-of-term option for the customer to extend the lease under mutually-agreed terms, return the leased equipment, or purchase the equipment for either the then-market value of the equipment or a pre-determined purchase price. If a customer chooses to terminate their lease prior to the original end of term date, the customer is required to pay all remaining lease payments in full.

[0000858877-20-000010:notes:27]
For additional information, see Note 8.

[0000858877-20-000010:notes:28]
(i) Depreciation and Amortization   Property and equipment are stated at cost, less accumulated depreciation or amortization, whenever applicable. Depreciation and amortization expenses for property and equipment were approximately $0.9 billion, $1.0 billion, and $1.1 billion for fiscal 2020, 2019, and 2018, respectively. Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-20-000010:notes:29]
| Asset Category |  | Period |
| Buildings |  | 25 years |
| Building improvements |  | 10 years |
| Leasehold improvements |  | Shorter of remaining lease term or up to 10 years |
| Computer equipment and related software |  | 30 to 36 months |
| Production, engineering, and other equipment |  | Up to 5 years |
| Operating lease assets |  | Based on lease term |
| Furniture and fixtures |  | 5 years |

[0000858877-20-000010:notes:30]
(j) Business Combinations We allocate the fair value of the purchase consideration of our acquisitions to the tangible assets, liabilities, and intangible assets acquired, including in-process research and development (IPR&D), based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life. Acquisition-related expenses and related restructuring costs are recognized separately from the business combination and are expensed as incurred.

[0000858877-20-000010:notes:31]
(k) Goodwill and Purchased Intangible Assets   Goodwill is tested for impairment on an annual basis in the fourth fiscal quarter and, when specific circumstances dictate, between annual tests. When impaired, the carrying value of goodwill is written down to fair value. Identifying a potential impairment consists of comparing the fair value of a reporting unit with its carrying amount, including goodwill. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. See “Long-Lived Assets” for our policy regarding impairment testing of purchased intangible assets with finite lives. Purchased intangible assets with indefinite lives are assessed for potential impairment annually or when events or circumstances indicate that their carrying amounts might be impaired.

[0000858877-20-000010:notes:32]
(l) Long-Lived Assets   Long-lived assets that are held and used by us are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability of long-lived assets is based on an estimate of the undiscounted future cash flows resulting from the use of the asset and its eventual disposition. Measurement of an impairment loss for long-lived assets that management expects to hold and use is based on the difference between the fair value of the asset and its carrying value. Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0000858877-20-000010:notes:33]
(m) Fair Value   Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, we consider the principal or most advantageous market in which we would transact, and we also consider assumptions that market participants would use when pricing the asset or liability.

[0000858877-20-000010:notes:34]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. The standard establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement.

[0000858877-20-000010:notes:35]
The fair value hierarchy is as follows:

[0000858877-20-000010:notes:36]
Level 1 applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000858877-20-000010:notes:37]
Level 2 applies to assets or liabilities for which there are inputs other than quoted prices that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets); or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of assets or liabilities.

[0000858877-20-000010:notes:38]
Level 3 applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities. The fair values are determined based on model-based techniques such as discounted cash flow models using inputs that we could not corroborate with market data.

[0000858877-20-000010:notes:39]
(n) Derivative Instruments   We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the effective portion of the derivative’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion of the gain or loss is reported in earnings immediately. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. Any ineffective portion of the net investment hedges is reported in earnings during the period of change. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.

[0000858877-20-000010:notes:40]
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.

[0000858877-20-000010:notes:41]
(o) Foreign Currency Translation   Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated to U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of AOCI. Income and expense accounts are translated at average exchange rates during the year. Remeasurement adjustments are recorded in other income (loss), net. The effect of foreign currency exchange rates on cash and cash equivalents was not material for any of the fiscal years presented.

[0000858877-20-000010:notes:42]
(p) Concentrations of Risk   Cash and cash equivalents are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. We seek to mitigate our credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties.

[0000858877-20-000010:notes:43]
We perform ongoing credit evaluations of our customers and, with the exception of certain financing transactions, do not require collateral from our customers. We receive certain of our components from sole suppliers. Additionally, we rely on a limited number of contract manufacturers and suppliers to provide manufacturing services for our products. The inability of a contract manufacturer or supplier to fulfill our supply requirements could materially impact future operating results.

[0000858877-20-000010:notes:44]
(q) Revenue Recognition   We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

[0000858877-20-000010:notes:45]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-20-000010:notes:46]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of July 25, 2020 and July 27, 2019 was $79 million and $84 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-20-000010:notes:47]
Significant Judgments

[0000858877-20-000010:notes:48]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-20-000010:notes:49]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

[0000858877-20-000010:notes:50]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license's utility as the risks and threats in the environment are rapidly

[0000858877-20-000010:notes:51]
changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

[0000858877-20-000010:notes:52]
We adopted ASC 606 at the beginning of fiscal 2019 using the modified retrospective method to those contracts that were not completed as of July 28, 2018. For the additional information, see Note 3.

[0000858877-20-000010:notes:53]
(r) Advertising Costs   We expense all advertising costs as incurred. Advertising costs included within sales and marketing expenses were approximately $187 million, $204 million, and $166 million for fiscal 2020, 2019, and 2018, respectively.

[0000858877-20-000010:notes:54]
(s) Share-Based Compensation Expense   We measure and recognize the compensation expense for all share-based awards made to employees and directors, including employee stock options, restricted stock units (RSUs), performance-based restricted stock units (PRSUs), and employee stock purchases related to the Employee Stock Purchase Plan (Employee Stock Purchase Rights) based on estimated fair values. The fair value of employee stock options is estimated on the date of grant using a lattice-binomial option-pricing model (Lattice-Binomial Model) or the Black-Scholes model, and for employee stock purchase rights we estimate the fair value using the Black-Scholes model. The fair value for time-based stock awards and stock awards that are contingent upon the achievement of financial performance metrics is based on the grant date share price reduced by the present value of the expected dividend yield prior to vesting. The fair value of market-based stock awards is estimated using an option-pricing model on the date of grant. Share-based compensation expense is reduced for forfeitures.

[0000858877-20-000010:notes:55]
(t) Software Development Costs   Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.

[0000858877-20-000010:notes:56]
(u) Income Taxes   Income tax expense is based on pretax financial accounting income. Deferred tax assets and liabilities are recognized for the expected tax consequences of temporary differences between the tax bases of assets and liabilities and their reported amounts. Valuation allowances are recorded to reduce deferred tax assets to the amount that will more likely than not be realized.

[0000858877-20-000010:notes:57]
We account for uncertainty in income taxes using a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. We classify the liability for unrecognized tax benefits as current to the extent that we anticipate payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.

[0000858877-20-000010:notes:58]
(v) Computation of Net Income per Share   Basic net income per share is computed using the weighted-average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted-average number of common shares and dilutive potential common shares outstanding during the period. Diluted shares outstanding includes the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares.

[0000858877-20-000010:notes:59]
(w) Consolidation of Variable Interest Entities  Our approach in assessing the consolidation requirement for variable interest entities focuses on identifying which enterprise has the power to direct the activities that most significantly impact the variable interest entity’s economic performance and which enterprise has the obligation to absorb losses or the right to receive benefits from the variable interest entity. Should we conclude that we are the primary beneficiary of a variable interest entity, the assets, liabilities, and results of operations of the variable interest entity will be included in our Consolidated Financial Statements.

[0000858877-20-000010:notes:60]
(x) Use of Estimates   The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Estimates are used for the following, among others:

[0000858877-20-000010:notes:61]
| ▪ | Revenue recognition |

[0000858877-20-000010:notes:62]
| ▪ | Allowances for accounts receivable, sales returns, and financing receivables |

[0000858877-20-000010:notes:63]
| ▪ | Inventory valuation and liability for purchase commitments with contract manufacturers and suppliers |

[0000858877-20-000010:notes:64]
| ▪ | Loss contingencies and product warranties |

[0000858877-20-000010:notes:65]
| ▪ | Fair value measurements and other-than-temporary impairments |

[0000858877-20-000010:notes:66]
| ▪ | Goodwill and purchased intangible asset impairments |

[0000858877-20-000010:notes:67]
| ▪ | Income taxes |

[0000858877-20-000010:notes:68]
The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The actual results experienced by us may differ materially from our estimates. As the COVID-19 pandemic continues to develop, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-20-000010:notes:69]
(y) New Accounting Updates Recently Adopted

[0000858877-20-000010:notes:70]
Leases  In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Codification (ASC) 842, Leases, a new standard requiring lessees to recognize operating and finance lease liabilities on the balance sheet, as well as corresponding right-of-use (ROU) assets. This standard also made some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. We adopted this standard at the beginning of fiscal 2020 and applied it at the beginning of the period of adoption and did not restate prior periods. In connection with the adoption of ASC 842, we recognized $1.2 billion of operating lease ROU assets, which was included in other assets and $1.2 billion of operating lease liabilities which was included in other current liabilities and other long-term liabilities. There were no transition adjustments recorded from the adoption of ASC 842 as a lessor.

[0000858877-20-000010:notes:71]
We elected to apply the package of practical expedients permitted under the transition guidance within ASC 842 which does not require reassessment of initial direct costs, classification of a lease and definition of a lease. We also elected additional practical expedients which resulted in: i) allowing us not to reassess the accounting treatment for existing or expired land easements in transition; ii) combining lease and non-lease components and iii) not recording leases with an initial term of less than 12 months on our Consolidated Balance Sheet.

[0000858877-20-000010:notes:72]
(z) Recent Accounting Standards or Updates Not Yet Effective as of Fiscal Year End

[0000858877-20-000010:notes:73]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The new standard replaces the incurred loss impairment model. Under this standard, we will be required to use a forward-looking expected credit loss model for accounts receivable, financing receivables, contract assets, and other financial instruments. Credit losses relating to available-for-sale debt securities will also be recorded through an allowance for credit losses rather than as a reduction in the amortized cost basis of the securities. We will adopt this standard at the beginning of our first quarter of fiscal 2021 on a modified retrospective basis with the cumulative effect of adoption recorded as an adjustment to retained earnings. This standard will not have a material impact on our consolidated financial statements at adoption.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-20-000010:notes:74]
Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-20-000010:notes:75]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,252 |  |  | $ | 4,545 |  |
| Computer equipment and related software |  | 875 |  |  | 922 |  |
| Production, engineering, and other equipment |  | 5,163 |  |  | 5,711 |  |
| Operating lease assets |  | 337 |  |  | 485 |  |
| Furniture, fixtures and other |  | 387 |  |  | 376 |  |
| Total gross property and equipment |  | 11,014 |  |  | 12,039 |  |
| Less: accumulated depreciation and amortization |  | (8,561 | ) |  | (9,250 | ) |
| Total |  | $ | 2,453 |  |  | $ | 2,789 |  |


## us-gaap:DerivativesPolicyTextBlock

[0000858877-20-000010:notes:76]
(n) Derivative Instruments   We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the effective portion of the derivative’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion of the gain or loss is reported in earnings immediately. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. Any ineffective portion of the net investment hedges is reported in earnings during the period of change. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We do, however, seek to mitigate such risks by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000858877-20-000010:notes:77]
Employee equity share options, unvested shares, and similar equity instruments granted and assumed by Cisco are treated as potential common shares outstanding in computing diluted earnings per share. Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that has not yet been recognized are collectively assumed to be used to repurchase shares.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-20-000010:notes:78]
Revenue

[0000858877-20-000010:notes:79]
| (a) | Disaggregation of Revenue |

[0000858877-20-000010:notes:80]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category.

[0000858877-20-000010:notes:81]
The following table presents this disaggregation of revenue (in millions):

[0000858877-20-000010:notes:82]
| Years Ended | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Revenue: |  |  |  |  |  |
| Infrastructure Platforms | $ | 27,122 |  |  | $ | 30,099 |  |  | $ | 28,286 |  |
| Applications | 5,568 |  |  | 5,803 |  |  | 5,036 |  |
| Security | 3,154 |  |  | 2,821 |  |  | 2,388 |  |
| Other Products | 135 |  |  | 281 |  |  | 999 |  |
| Total Product | 35,978 |  |  | 39,005 |  |  | 36,709 |  |
| Services | 13,323 |  |  | 12,899 |  |  | 12,621 |  |
| Total (1) | $ | 49,301 |  |  | $ | 51,904 |  |  | $ | 49,330 |  |

[0000858877-20-000010:notes:83]
Amounts may not sum due to rounding. We have made certain reclassifications to the product revenue amounts for prior years to conform to the current year’s presentation.

[0000858877-20-000010:notes:84]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (SPVSS) business. Total revenue includes SPVSS business revenue of $168 million and $903 million for fiscal 2019 and 2018, respectively.

[0000858877-20-000010:notes:85]
Infrastructure Platforms consist of our core networking technologies of switching, routing, wireless, and data center products that are designed to work together to deliver networking capabilities and transport and/or store data. These technologies consist of both hardware and software offerings, including software licenses and software-as-a-service (SaaS), that help our customers build networks, automate, orchestrate, integrate, and digitize data. We are shifting and expanding more of our business to software and subscriptions across our core networking portfolio. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-20-000010:notes:86]
Applications consists of offerings that utilize the core networking and data center platforms to provide their functions. The products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-20-000010:notes:87]
Security primarily includes our network security, cloud and email security, identity and access management, advanced threat protection, and unified threat management products. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers' network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-20-000010:notes:88]
Other Products primarily include our Service Provider Video Software Solutions and cloud and system management products. On October 28, 2018, we completed the sale of the SPVSS business. These products include both hardware and software licenses. Our offerings in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control.

[0000858877-20-000010:notes:89]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and advanced services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Advanced services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

[0000858877-20-000010:notes:90]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for all of our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.

[0000858877-20-000010:notes:91]
| (b) | Contract Balances |

[0000858877-20-000010:notes:92]
Accounts receivable, net was $5.5 billion as of each of July 25, 2020 and July 27, 2019, as reported on the Consolidated Balance Sheet.

[0000858877-20-000010:notes:93]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of July 25, 2020 and July 27, 2019, our contract assets for these unbilled receivables were $1.2 billion and $860 million, respectively, and were included in other current assets and other assets.

[0000858877-20-000010:notes:94]
Contract liabilities consist of deferred revenue. Deferred revenue was $20.4 billion as of July 25, 2020 compared to $18.5 billion as of July 27, 2019. We recognized approximately $10.6 billion of revenue during fiscal 2020 that was included in the deferred revenue balance at July 27, 2019.

[0000858877-20-000010:notes:95]
| (c) | Capitalized Contract Acquisition Costs |

[0000858877-20-000010:notes:96]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $732 million and $750 million as of July 25, 2020 and July 27, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $477 million and $471 million for fiscal 2020 and 2019, respectively, and was included in sales and marketing expenses.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-20-000010:notes:97]
The following table presents revenue for groups of similar products and services (in millions):

[0000858877-20-000010:notes:98]
(1) Includes SPVSS business revenue of $168 million and $903 million for fiscal 2019 and 2018, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-20-000010:notes:99]
Acquisitions and Divestitures

[0000858877-20-000010:notes:100]
| (a) | Acquisition Summary |

[0000858877-20-000010:notes:101]
We completed six acquisitions during fiscal 2020. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-20-000010:notes:102]
| Fiscal 2020 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions (six in total) | $ | 359 |  |  | $ | (11 | ) |  | $ | 172 |  |  | $ | 198 |  |

[0000858877-20-000010:notes:103]
The total purchase consideration related to our acquisitions completed during fiscal 2020 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $23 million.

[0000858877-20-000010:notes:104]
Fiscal 2019 Acquisitions

[0000858877-20-000010:notes:105]
Allocation of the purchase consideration for acquisitions completed in fiscal 2019 is summarized as follows (in millions):

[0000858877-20-000010:notes:106]
| Fiscal 2019 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Duo | $ | 2,025 |  |  | $ | (57 | ) |  | $ | 342 |  |  | $ | 1,740 |  |
| Luxtera | 596 |  |  | (19 | ) |  | 319 |  |  | 296 |  |
| Others (three in total) | 65 |  |  | 2 |  |  | 11 |  |  | 52 |  |
| Total | $ | 2,686 |  |  | $ | (74 | ) |  | $ | 672 |  |  | $ | 2,088 |  |

[0000858877-20-000010:notes:107]
On September 28, 2018, we completed our acquisition of privately held Duo Security, Inc. (“Duo”), a leading provider of unified access security and multi-factor authentication delivered through the cloud. Revenue from the Duo acquisition has been included in our Security product category.

[0000858877-20-000010:notes:108]
On February 6, 2019, we completed our acquisition of Luxtera, Inc. (“Luxtera”), a privately held semiconductor company. Revenue from the Luxtera acquisition has been included in our Infrastructure Platforms product category.

[0000858877-20-000010:notes:109]
The total purchase consideration related to our acquisitions completed during fiscal 2019 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $100 million.

[0000858877-20-000010:notes:110]
Fiscal 2018 Acquisitions

[0000858877-20-000010:notes:111]
In fiscal 2018, we completed eight acquisitions for total purchase consideration of $3.2 billion.

[0000858877-20-000010:notes:112]
| (b) | Divestiture of Service Provider Video Software Solutions Business |

[0000858877-20-000010:notes:113]
On October 28, 2018, we completed the sale of the Service Provider Video Software Solutions business. This business had tangible assets of approximately $160 million (primarily comprised of accounts receivables, inventories and various other current and long-term assets) and net intangible assets and goodwill (based on relative fair value) of $340 million. In addition, the business had total liabilities of approximately $200 million (primarily comprised of deferred revenue and various other current and long-term liabilities). We recognized an immaterial gain from this transaction in fiscal 2019.

[0000858877-20-000010:notes:114]
We completed two divestitures during fiscal 2018. The financial statement impact of these divestitures was not material for fiscal 2018.

[0000858877-20-000010:notes:115]
(c)   Pending Acquisitions at Year End

[0000858877-20-000010:notes:116]
On July 9, 2019, we announced our intent to acquire Acacia Communications, Inc. (“Acacia”), a public fabless semiconductor company that develops, manufactures and sells high-speed coherent optical interconnect products that are designed to transform communications networks through improvements in performance, capacity and cost.

[0000858877-20-000010:notes:117]
Under the terms of the agreement, we have agreed to pay total consideration of approximately $2.6 billion, net of cash and marketable securities, to acquire Acacia. The acquisition is expected to close during the first half of fiscal 2021, subject to customary closing conditions and regulatory approvals. Upon close of the acquisition, revenue from Acacia will be included in our Infrastructure Platforms product category.

[0000858877-20-000010:notes:118]
On August 7, 2020, we completed the acquisition of ThousandEyes, Inc. (“ThousandEyes”), a privately-held company. ThousandEyes’ Internet and Cloud intelligence platform delivers deep visibility and insights into the digital delivery of applications and services over the internet. We expect that most of the purchase price for the acquisition of ThousandEyes will be allocated to goodwill and purchased intangible assets. The financial statement impact of this acquisition will not have a material impact to our consolidated financial statements.

[0000858877-20-000010:notes:119]
(d)   Other Acquisition and Divestiture Information

[0000858877-20-000010:notes:120]
Total transaction costs related to our acquisition and divestiture activities during fiscal 2020, 2019, and 2018 were $21 million, $21 million, and $41 million, respectively. These transaction costs were expensed as incurred in G&A expenses in the Consolidated Statements of Operations.

[0000858877-20-000010:notes:121]
The goodwill generated from our acquisitions completed during fiscal 2020 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-20-000010:notes:122]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations for the acquisitions completed during fiscal 2020, 2019, and 2018 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0000858877-20-000010:notes:123]
A summary of the allocation of the total purchase consideration is presented as follows (in millions):


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-20-000010:notes:124]
Goodwill and Purchased Intangible Assets

[0000858877-20-000010:notes:125]
| (a) | Goodwill |

[0000858877-20-000010:notes:126]
The following tables present the goodwill allocated to our reportable segments as of July 25, 2020 and July 27, 2019, as well as the changes to goodwill during fiscal 2020 and 2019 (in millions):

[0000858877-20-000010:notes:127]
|  | Balance at July 27, 2019 |  | Acquisitions |  | Foreign Currency Translation and Other |  | Balance at July 25, 2020 |
| Americas | $ | 21,120 |  |  | $ | 132 |  |  | $ | 52 |  |  | $ | 21,304 |  |
| EMEA | 7,977 |  |  | 44 |  |  | 19 |  |  | 8,040 |  |
| APJC | 4,432 |  |  | 22 |  |  | 8 |  |  | 4,462 |  |
| Total | $ | 33,529 |  |  | $ | 198 |  |  | $ | 79 |  |  | $ | 33,806 |  |

[0000858877-20-000010:notes:128]
|  | Balance at July 28, 2018 |  | Acquisitions & Divestitures |  | Foreign Currency Translation and Other |  | Balance at July 27, 2019 |
| Americas | $ | 19,998 |  |  | $ | 1,240 |  |  | $ | (118 | ) |  | $ | 21,120 |  |
| EMEA | 7,529 |  |  | 486 |  |  | (38 | ) |  | 7,977 |  |
| APJC | 4,179 |  |  | 274 |  |  | (21 | ) |  | 4,432 |  |
| Total | $ | 31,706 |  |  | $ | 2,000 |  |  | $ | (177 | ) |  | $ | 33,529 |  |

[0000858877-20-000010:notes:129]
| (b) | Purchased Intangible Assets |

[0000858877-20-000010:notes:130]
The following tables present details of our intangible assets acquired through acquisitions completed during fiscal 2020 and 2019 (in millions, except years):

[0000858877-20-000010:notes:131]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2020 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions (six in total) | 4.8 |  | $ | 161 |  |  | 4.2 |  | $ | 10 |  |  | 1.5 |  | $ | 1 |  |  | $ | — |  |  | $ | 172 |  |

[0000858877-20-000010:notes:132]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2019 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Duo | 5.0 |  | $ | 153 |  |  | 5.0 |  |  | $ | 94 |  |  | 2.5 |  |  | $ | 18 |  |  | $ | 77 |  |  | $ | 342 |  |
| Luxtera | 4.0 |  | 2 |  |  | 5.0 |  |  | 58 |  |  | 1.6 |  |  | 3 |  |  | 256 |  |  | 319 |  |
| Others (three in total) | 4.4 |  | 11 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Total |  |  | $ | 166 |  |  |  |  | $ | 152 |  |  |  |  | $ | 21 |  |  | $ | 333 |  |  | $ | 672 |  |

[0000858877-20-000010:notes:133]
The following tables present details of our purchased intangible assets (in millions):

[0000858877-20-000010:notes:134]
| July 25, 2020 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,298 |  |  | $ | (2,336 | ) |  | $ | 962 |  |
| Customer relationships |  | 760 |  |  | (365 | ) |  | 395 |  |
| Other |  | 26 |  |  | (20 | ) |  | 6 |  |
| Total purchased intangible assets with finite lives |  | 4,084 |  |  | (2,721 | ) |  | 1,363 |  |
| In-process research and development, with indefinite lives |  | 213 |  |  | — |  |  | 213 |  |
| Total |  | $ | 4,297 |  |  | $ | (2,721 | ) |  | $ | 1,576 |  |

[0000858877-20-000010:notes:135]
| July 27, 2019 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,270 |  |  | $ | (1,933 | ) |  | $ | 1,337 |  |
| Customer relationships |  | 840 |  |  | (331 | ) |  | 509 |  |
| Other |  | 41 |  |  | (22 | ) |  | 19 |  |
| Total purchased intangible assets with finite lives |  | 4,151 |  |  | (2,286 | ) |  | 1,865 |  |
| In-process research and development, with indefinite lives |  | 336 |  |  | — |  |  | 336 |  |
| Total |  | $ | 4,487 |  |  | $ | (2,286 | ) |  | $ | 2,201 |  |

[0000858877-20-000010:notes:136]
Purchased intangible assets include intangible assets acquired through acquisitions as well as through direct purchases or licenses.

[0000858877-20-000010:notes:137]
The following table presents the amortization of purchased intangible assets, including impairment charges (in millions):

[0000858877-20-000010:notes:138]
| Years Ended |  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 659 |  |  | $ | 624 |  |  | $ | 640 |  |
| Operating expenses |  | 141 |  |  | 150 |  |  | 221 |  |
| Total |  | $ | 800 |  |  | $ | 774 |  |  | $ | 861 |  |

[0000858877-20-000010:notes:139]
The estimated future amortization expense of purchased intangible assets with finite lives as of July 25, 2020 is as follows (in millions):

[0000858877-20-000010:notes:140]
| Fiscal Year | Amount |
| 2021 | $ | 633 |  |
| 2022 | $ | 371 |  |
| 2023 | $ | 229 |  |
| 2024 | $ | 118 |  |
| 2025 | $ | 12 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-20-000010:notes:141]
Restructuring and Other Charges

[0000858877-20-000010:notes:142]
In the first quarter of fiscal 2021, we initiated a restructuring plan (the “Fiscal 2021 Plan”), which includes a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas with estimated pretax charges of approximately $900 million. These aggregate pretax charges will be primarily cash-based and will consist of severance and other one-time termination benefits, and other costs. We expect the plan to be substantially completed in fiscal 2021.

[0000858877-20-000010:notes:143]
We initiated a restructuring plan during fiscal 2020 (the “Fiscal 2020 Plan”) in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $300 million. These aggregate pretax charges related to the Fiscal 2020 Plan are primarily cash-based and consist of employee severance and other one-time termination benefits, and other costs. In connection with the Fiscal 2020 Plan, we incurred charges of $255 million during fiscal 2020. We expect the Fiscal 2020 Plan to be substantially completed in fiscal 2021.

[0000858877-20-000010:notes:144]
In prior years, we initiated restructuring plans in order to realign our organization and enable further investment in key priority areas. The aggregate pretax charges related to these plans were primarily cash-based and consisted of employee severance and other one-time termination benefits, and other associated costs. These plans have been completed.

[0000858877-20-000010:notes:145]
The following table summarizes the activities related to the restructuring and other charges, as discussed above (in millions):

[0000858877-20-000010:notes:146]
|  |  | FISCAL 2018 AND PRIOR PLANS |  | FISCAL 2020 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 29, 2017 |  | $ | 74 |  |  | $ | 43 |  |  | $ | — |  |  | $ | — |  |  | $ | 117 |  |
| Charges |  | 319 |  |  | 39 |  |  | — |  |  | — |  |  | 358 |  |
| Cash payments |  | (335 | ) |  | (37 | ) |  | — |  |  | — |  |  | (372 | ) |
| Non-cash items |  | 2 |  |  | (32 | ) |  | — |  |  | — |  |  | (30 | ) |
| Liability as of July 28, 2018 |  | 60 |  |  | 13 |  |  | — |  |  | — |  |  | 73 |  |
| Charges |  | 252 |  |  | 70 |  |  | — |  |  | — |  |  | 322 |  |
| Cash payments |  | (289 | ) |  | (10 | ) |  | — |  |  | — |  |  | (299 | ) |
| Non-cash items |  | (1 | ) |  | (62 | ) |  | — |  |  | — |  |  | (63 | ) |
| Liability as of July 27, 2019 |  | 22 |  |  | 11 |  |  | — |  |  | — |  |  | 33 |  |
| Charges |  | 209 |  |  | 17 |  |  | 144 |  |  | 111 |  |  | 481 |  |
| Cash payments |  | (224 | ) |  | (3 | ) |  | (93 | ) |  | (7 | ) |  | (327 | ) |
| Non-cash items |  | — |  |  | (23 | ) |  | — |  |  | (92 | ) |  | (115 | ) |
| Liability as of July 25, 2020 |  | $ | 7 |  |  | $ | 2 |  |  | $ | 51 |  |  | $ | 12 |  |  | $ | 72 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-20-000010:notes:147]
Balance Sheet Details

[0000858877-20-000010:notes:148]
The following tables provide details of selected balance sheet items (in millions):

[0000858877-20-000010:notes:149]
|  |  | July 25, 2020 |  | July 27, 2019 |
| Cash and cash equivalents |  | $ | 11,809 |  |  | $ | 11,750 |  |
| Restricted cash included in other current assets |  | — |  |  | 21 |  |
| Restricted cash included in other assets |  | 3 |  |  | 1 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 11,812 |  |  | $ | 11,772 |  |

[0000858877-20-000010:notes:150]
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 456 |  |  | $ | 374 |  |
| Work in process |  | 25 |  |  | 10 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales |  | 59 |  |  | 109 |  |
| Manufactured finished goods |  | 542 |  |  | 643 |  |
| Total finished goods |  | 601 |  |  | 752 |  |
| Service-related spares |  | 184 |  |  | 225 |  |
| Demonstration systems |  | 16 |  |  | 22 |  |
| Total |  | $ | 1,282 |  |  | $ | 1,383 |  |

[0000858877-20-000010:notes:151]
Our provision for inventory was $74 million, $77 million, and $63 million in fiscal 2020, 2019, and 2018, respectively.

[0000858877-20-000010:notes:152]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 12,551 |  |  | $ | 11,709 |  |
| Product |  | 7,895 |  |  | 6,758 |  |
| Total |  | $ | 20,446 |  |  | $ | 18,467 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 11,406 |  |  | $ | 10,668 |  |
| Noncurrent |  | 9,040 |  |  | 7,799 |  |
| Total |  | $ | 20,446 |  |  | $ | 18,467 |  |

[0000858877-20-000010:notes:153]
| Remaining Performance Obligations: |  |  |  |  |
| Product |  | $ | 11,261 |  |  | $ | 9,603 |  |
| Service |  | 17,093 |  |  | 15,702 |  |
| Total |  | $ | 28,354 |  |  | $ | 25,305 |  |

[0000858877-20-000010:notes:154]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of July 25, 2020, the aggregate amount of RPO was comprised of $20.4 billion of deferred revenue and $7.9 billion of unbilled contract revenue. We expect approximately 54% of this amount to be recognized as revenue over the next year. As of July 27, 2019, the aggregate amount of RPO was comprised of $18.5 billion of deferred revenue and $6.8 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.


## us-gaap:OperatingLeasesOfLessorDisclosureTextBlock

[0000858877-20-000010:notes:155]
Leases

[0000858877-20-000010:notes:156]
| (a) | Lessee Arrangements |

[0000858877-20-000010:notes:157]
As of July 25, 2020, our operating lease right-of-use assets were $921 million and were recorded in other assets, and our operating lease liabilities were $1.0 billion, of which $341 million was included in other current liabilities and $661 million was included in other long-term liabilities. The weighted-average lease term was 4.0 years and the weighted-average discount rate was 1.5% as of July 25, 2020.

[0000858877-20-000010:notes:158]
The components of our lease expenses were as follows (in millions):

[0000858877-20-000010:notes:159]
| Year Ended | July 25, 2020 |
| Operating lease expense | $ | 428 |  |
| Short-term lease expense | 69 |  |
| Variable lease expense | 157 |  |
| Total lease expense | $ | 654 |  |

[0000858877-20-000010:notes:160]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-20-000010:notes:161]
| Year Ended | July 25, 2020 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 413 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 197 |  |

[0000858877-20-000010:notes:162]
The maturities of our operating leases (undiscounted) as of July 25, 2020 are as follows (in millions):

[0000858877-20-000010:notes:163]
| Fiscal Year | Amount |
| 2021 | $ | 354 |  |
| 2022 | 247 |  |
| 2023 | 192 |  |
| 2024 | 120 |  |
| 2025 | 68 |  |
| Thereafter | 52 |  |
| Total lease payments | 1,033 |  |
| Less interest | (31 | ) |
| Total | $ | 1,002 |  |

[0000858877-20-000010:notes:164]
Prior to the adoption of the new leasing standard, future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of July 27, 2019 were as follows (in millions):

[0000858877-20-000010:notes:165]
| Fiscal Year | Amount |
| 2020 | $ | 441 |  |
| 2021 | 299 |  |
| 2022 | 195 |  |
| 2023 | 120 |  |
| 2024 | 70 |  |
| Thereafter | 54 |  |
| Total | $ | 1,179 |  |

[0000858877-20-000010:notes:166]
| (b) | Lessor Arrangements |

[0000858877-20-000010:notes:167]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income for fiscal 2020 was $94 million and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-20-000010:notes:168]
Future minimum lease payments on our lease receivables as of July 25, 2020 are summarized as follows (in millions):

[0000858877-20-000010:notes:169]
| Fiscal Year | Amount |
| 2021 | $ | 946 |  |
| 2022 | 590 |  |
| 2023 | 353 |  |
| 2024 | 166 |  |
| 2025 | 72 |  |
| Total | 2,127 |  |
| Less: Present value of lease payments | 2,013 |  |
| Difference between undiscounted cash flows and discounted cash flows | $ | 114 |  |

[0000858877-20-000010:notes:170]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-20-000010:notes:171]
Prior to the adoption of the new leasing standard, future minimum lease payments on our lease receivables as of July 27, 2019 were summarized as follows (in millions):

[0000858877-20-000010:notes:172]
| Fiscal Year | Amount |
| 2020 | $ | 1,028 |  |
| 2021 | 702 |  |
| 2022 | 399 |  |
| 2023 | 185 |  |
| 2024 | 53 |  |
| Total | $ | 2,367 |  |

[0000858877-20-000010:notes:173]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by Cisco and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-20-000010:notes:174]
|  | July 25, 2020 |  | July 27, 2019 |
| Operating lease assets | $ | 337 |  |  | $ | 485 |  |
| Accumulated depreciation | (198 | ) |  | (306 | ) |
| Operating lease assets, net | $ | 139 |  |  | $ | 179 |  |

[0000858877-20-000010:notes:175]
Our lease income for fiscal 2020 was $190 million and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-20-000010:notes:176]
Minimum future rentals on noncancelable operating leases as of July 25, 2020 are summarized as follows (in millions):

[0000858877-20-000010:notes:177]
| Fiscal Year | Amount |
| 2021 | $ | 74 |  |
| 2022 | 27 |  |
| 2023 | 7 |  |
| Total | $ | 108 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-20-000010:notes:178]
Financing Receivables

[0000858877-20-000010:notes:179]
| (a) | Financing Receivables |

[0000858877-20-000010:notes:180]
Financing receivables primarily consist of lease receivables, loan receivables, and financed service contracts. Lease receivables represent sales-type leases resulting from the sale of Cisco's and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services, which may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables have terms of three years on average. Financed service contracts include financing receivables related to technical support and advanced services. Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one to three years.

[0000858877-20-000010:notes:181]
A summary of our financing receivables is presented as follows (in millions):

[0000858877-20-000010:notes:182]
| July 25, 2020 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,127 |  |  | $ | 5,937 |  |  | $ | 2,830 |  |  | $ | 10,894 |  |
| Residual value | 123 |  |  | — |  |  | — |  |  | 123 |  |
| Unearned income | (114 | ) |  | — |  |  | — |  |  | (114 | ) |
| Allowance for credit loss | (48 | ) |  | (81 | ) |  | (9 | ) |  | (138 | ) |
| Total, net | $ | 2,088 |  |  | $ | 5,856 |  |  | $ | 2,821 |  |  | $ | 10,765 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 918 |  |  | $ | 2,692 |  |  | $ | 1,441 |  |  | $ | 5,051 |  |
| Noncurrent | 1,170 |  |  | 3,164 |  |  | 1,380 |  |  | 5,714 |  |
| Total, net | $ | 2,088 |  |  | $ | 5,856 |  |  | $ | 2,821 |  |  | $ | 10,765 |  |

[0000858877-20-000010:notes:183]
| July 27, 2019 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,367 |  |  | $ | 5,438 |  |  | $ | 2,369 |  |  | $ | 10,174 |  |
| Residual value | 142 |  |  | — |  |  | — |  |  | 142 |  |
| Unearned income | (137 | ) |  | — |  |  | — |  |  | (137 | ) |
| Allowance for credit loss | (46 | ) |  | (71 | ) |  | (9 | ) |  | (126 | ) |
| Total, net | $ | 2,326 |  |  | $ | 5,367 |  |  | $ | 2,360 |  |  | $ | 10,053 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,029 |  |  | $ | 2,653 |  |  | $ | 1,413 |  |  | $ | 5,095 |  |
| Noncurrent | 1,297 |  |  | 2,714 |  |  | 947 |  |  | 4,958 |  |
| Total, net | $ | 2,326 |  |  | $ | 5,367 |  |  | $ | 2,360 |  |  | $ | 10,053 |  |

[0000858877-20-000010:notes:184]
| (b) | Credit Quality of Financing Receivables |

[0000858877-20-000010:notes:185]
Gross receivables, excluding residual value, less unearned income categorized by our internal credit risk rating as of July 25, 2020 and July 27, 2019 are summarized as follows (in millions):

[0000858877-20-000010:notes:186]
|  | INTERNAL CREDIT RISK RATING |
| July 25, 2020 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 992 |  |  | $ | 952 |  |  | $ | 69 |  |  | $ | 2,013 |  |
| Loan receivables | 3,808 |  |  | 1,961 |  |  | 168 |  |  | 5,937 |  |
| Financed service contracts | 1,645 |  |  | 1,153 |  |  | 32 |  |  | 2,830 |  |
| Total | $ | 6,445 |  |  | $ | 4,066 |  |  | $ | 269 |  |  | $ | 10,780 |  |

[0000858877-20-000010:notes:187]
|  | INTERNAL CREDIT RISK RATING |
| July 27, 2019 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,204 |  |  | $ | 991 |  |  | $ | 35 |  |  | $ | 2,230 |  |
| Loan receivables | 3,367 |  |  | 1,920 |  |  | 151 |  |  | 5,438 |  |
| Financed service contracts | 1,413 |  |  | 939 |  |  | 17 |  |  | 2,369 |  |
| Total | $ | 5,984 |  |  | $ | 3,850 |  |  | $ | 203 |  |  | $ | 10,037 |  |

[0000858877-20-000010:notes:188]
We determine the adequacy of our allowance for credit loss by assessing the risks and losses inherent in our financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by us to our customers, which consist of the following: lease receivables, loan receivables, and financed service contracts.

[0000858877-20-000010:notes:189]
Our internal credit risk ratings of 1 through 4 correspond to investment-grade ratings, while credit risk ratings of 5 and 6 correspond to non-investment grade ratings. Credit risk ratings of 7 and higher correspond to substandard ratings.

[0000858877-20-000010:notes:190]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of July 25, 2020 and July 27, 2019 (in millions):

[0000858877-20-000010:notes:191]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 25, 2020 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 29 |  |  | $ | 47 |  |  | $ | 48 |  |  | $ | 124 |  |  | $ | 1,889 |  |  | $ | 2,013 |  |  | $ | 43 |  |  | $ | 43 |  |
| Loan receivables | 129 |  |  | 78 |  |  | 78 |  |  | 285 |  |  | 5,652 |  |  | 5,937 |  |  | 65 |  |  | 65 |  |
| Financed service contracts | 69 |  |  | 75 |  |  | 124 |  |  | 268 |  |  | 2,562 |  |  | 2,830 |  |  | 4 |  |  | 4 |  |
| Total | $ | 227 |  |  | $ | 200 |  |  | $ | 250 |  |  | $ | 677 |  |  | $ | 10,103 |  |  | $ | 10,780 |  |  | $ | 112 |  |  | $ | 112 |  |

[0000858877-20-000010:notes:192]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 27, 2019 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 101 |  |  | $ | 42 |  |  | $ | 291 |  |  | $ | 434 |  |  | $ | 1,796 |  |  | $ | 2,230 |  |  | $ | 13 |  |  | $ | 13 |  |
| Loan receivables | 257 |  |  | 67 |  |  | 338 |  |  | 662 |  |  | 4,776 |  |  | 5,438 |  |  | 31 |  |  | 31 |  |
| Financed service contracts | 145 |  |  | 131 |  |  | 271 |  |  | 547 |  |  | 1,822 |  |  | 2,369 |  |  | 3 |  |  | 3 |  |
| Total | $ | 503 |  |  | $ | 240 |  |  | $ | 900 |  |  | $ | 1,643 |  |  | $ | 8,394 |  |  | $ | 10,037 |  |  | $ | 47 |  |  | $ | 47 |  |

[0000858877-20-000010:notes:193]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract.

[0000858877-20-000010:notes:194]
As of July 25, 2020, we had financing receivables of $67 million, net of unbilled or current receivables, that were greater than 120 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $215 million as of July 27, 2019.

[0000858877-20-000010:notes:195]
| (c) | Allowance for Credit Loss Rollforward |

[0000858877-20-000010:notes:196]
The allowances for credit loss and the related financing receivables are summarized as follows (in millions):

[0000858877-20-000010:notes:197]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 27, 2019 | $ | 46 |  |  | $ | 71 |  |  | $ | 9 |  |  | $ | 126 |  |
| Provisions (benefits) | 5 |  |  | 32 |  |  | 1 |  |  | 38 |  |
| Recoveries (write-offs), net | (3 | ) |  | (19 | ) |  | — |  |  | (22 | ) |
| Foreign exchange and other | — |  |  | (3 | ) |  | (1 | ) |  | (4 | ) |
| Allowance for credit loss as of July 25, 2020 | $ | 48 |  |  | $ | 81 |  |  | $ | 9 |  |  | $ | 138 |  |

[0000858877-20-000010:notes:198]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 28, 2018 | $ | 135 |  |  | $ | 60 |  |  | $ | 10 |  |  | $ | 205 |  |
| Provisions (benefits) | (54 | ) |  | 11 |  |  | 27 |  |  | (16 | ) |
| Recoveries (write-offs), net | (14 | ) |  | — |  |  | (28 | ) |  | (42 | ) |
| Foreign exchange and other | (21 | ) |  | — |  |  | — |  |  | (21 | ) |
| Allowance for credit loss as of July 27, 2019 | $ | 46 |  |  | $ | 71 |  |  | $ | 9 |  |  | $ | 126 |  |

[0000858877-20-000010:notes:199]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 29, 2017 | $ | 162 |  |  | $ | 103 |  |  | $ | 30 |  |  | $ | 295 |  |
| Provisions (benefits) | (26 | ) |  | (43 | ) |  | (20 | ) |  | (89 | ) |
| Recoveries (write-offs), net | (1 | ) |  | (5 | ) |  | — |  |  | (6 | ) |
| Foreign exchange and other | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Allowance for credit loss as of July 28, 2018 | $ | 135 |  |  | $ | 60 |  |  | $ | 10 |  |  | $ | 205 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-20-000010:notes:200]
Available-for-Sale Debt and Equity Investments

[0000858877-20-000010:notes:201]
The following table summarizes our available-for-sale debt investments and equity investments (in millions):

[0000858877-20-000010:notes:202]
|  | July 25, 2020 |  | July 27, 2019 |
| Available-for-sale debt investments | $ | 17,610 |  |  | $ | 21,660 |  |
| Marketable equity securities | — |  |  | 3 |  |
| Total investments | 17,610 |  |  | 21,663 |  |
| Non-marketable equity securities included in other assets | 1,207 |  |  | 1,113 |  |
| Equity method investments included in other assets | 71 |  |  | 87 |  |
| Total | $ | 18,888 |  |  | $ | 22,863 |  |

[0000858877-20-000010:notes:203]
| (a) | Summary of Available-for-Sale Debt Investments |

[0000858877-20-000010:notes:204]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-20-000010:notes:205]
| July 25, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 2,614 |  |  | $ | 71 |  |  | $ | — |  |  | $ | 2,685 |  |
| U.S. government agency securities | 110 |  |  | — |  |  | — |  |  | 110 |  |
| Corporate debt securities | 11,549 |  |  | 334 |  |  | (6 | ) |  | 11,877 |  |
| U.S. agency mortgage-backed securities | 1,987 |  |  | 49 |  |  | (1 | ) |  | 2,035 |  |
| Commercial paper | 727 |  |  | — |  |  | — |  |  | 727 |  |
| Certificates of deposit | 176 |  |  | — |  |  | — |  |  | 176 |  |
| Total | $ | 17,163 |  |  | $ | 454 |  |  | $ | (7 | ) |  | $ | 17,610 |  |

[0000858877-20-000010:notes:206]
| July 27, 2019 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 808 |  |  | $ | 1 |  |  | $ | (1 | ) |  | $ | 808 |  |
| U.S. government agency securities | 169 |  |  | — |  |  | — |  |  | 169 |  |
| Corporate debt securities | 19,188 |  |  | 103 |  |  | (29 | ) |  | 19,262 |  |
| U.S. agency mortgage-backed securities | 1,425 |  |  | 7 |  |  | (11 | ) |  | 1,421 |  |
| Total | $ | 21,590 |  |  | $ | 111 |  |  | $ | (41 | ) |  | $ | 21,660 |  |

[0000858877-20-000010:notes:207]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-20-000010:notes:208]
| Years Ended | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Gross realized gains | $ | 70 |  |  | $ | 17 |  |  | $ | 16 |  |
| Gross realized losses | (28 | ) |  | (30 | ) |  | (258 | ) |
| Total | $ | 42 |  |  | $ | (13 | ) |  | $ | (242 | ) |

[0000858877-20-000010:notes:209]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at July 25, 2020 and July 27, 2019 (in millions):

[0000858877-20-000010:notes:210]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 25, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government agency securities | $ | 33 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 33 |  |  | $ | — |  |
| Corporate debt securities | 1,060 |  |  | (6 | ) |  | 3 |  |  | — |  |  | 1,063 |  |  | (6 | ) |
| U.S. agency mortgage-backed securities | 265 |  |  | (1 | ) |  | — |  |  | — |  |  | 265 |  |  | (1 | ) |
| Total | $ | 1,358 |  |  | $ | (7 | ) |  | $ | 3 |  |  | $ | — |  |  | $ | 1,361 |  |  | $ | (7 | ) |

[0000858877-20-000010:notes:211]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2019 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 204 |  |  | $ | — |  |  | $ | 488 |  |  | $ | (1 | ) |  | $ | 692 |  |  | $ | (1 | ) |
| U.S. government agency securities | — |  |  | — |  |  | 169 |  |  | — |  |  | 169 |  |  | — |  |
| Corporate debt securities | 2,362 |  |  | (4 | ) |  | 5,271 |  |  | (25 | ) |  | 7,633 |  |  | (29 | ) |
| U.S. agency mortgage-backed securities | 123 |  |  | — |  |  | 847 |  |  | (11 | ) |  | 970 |  |  | (11 | ) |
| Total | $ | 2,689 |  |  | $ | (4 | ) |  | $ | 6,775 |  |  | $ | (37 | ) |  | $ | 9,464 |  |  | $ | (41 | ) |

[0000858877-20-000010:notes:212]
As of July 25, 2020, for available-for-sale debt investments that were in an unrealized loss position, we have determined that no other-than-temporary impairments were required to be recognized.

[0000858877-20-000010:notes:213]
The following table summarizes the maturities of our available-for-sale debt investments as of July 25, 2020 (in millions):

[0000858877-20-000010:notes:214]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 5,773 |  |  | $ | 5,812 |  |
| After 1 year through 5 years | 7,360 |  |  | 7,532 |  |
| After 5 years through 10 years | 2,032 |  |  | 2,218 |  |
| After 10 years | 11 |  |  | 13 |  |
| Mortgage-backed securities with no single maturity | 1,987 |  |  | 2,035 |  |
| Total | $ | 17,163 |  |  | $ | 17,610 |  |

[0000858877-20-000010:notes:215]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-20-000010:notes:216]
| (b) | Summary of Equity Investments |

[0000858877-20-000010:notes:217]
Gains and losses recognized on our marketable and non-marketable equity securities are summarized below (in millions):

[0000858877-20-000010:notes:218]
|  | July 25, 2020 |  | July 27, 2019 |
| Net gains and losses recognized during the period on equity investments | $ | 63 |  |  | $ | 58 |  |
| Less: Net gains and losses recognized on equity investments sold | (76 | ) |  | (69 | ) |
| Net unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | (13 | ) |  | $ | (11 | ) |

[0000858877-20-000010:notes:219]
We recorded adjustments to the carrying value of our non-marketable equity securities measured using the measurement alternative as follows (in millions):

[0000858877-20-000010:notes:220]
|  | July 25, 2020 |  | July 27, 2019 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |  |  |
| Upward adjustments | $ | 28 |  |  | $ | 26 |  |
| Downward adjustments, including impairments | (41 | ) |  | (57 | ) |
| Net adjustments | $ | (13 | ) |  | $ | (31 | ) |

[0000858877-20-000010:notes:221]
As of July 25, 2020 and July 27, 2019, we held equity interests in certain private equity funds of $0.7 billion and $0.6 billion, respectively, which are accounted for under the NAV practical expedient.

[0000858877-20-000010:notes:222]
| (c) | Variable Interest Entities |

[0000858877-20-000010:notes:223]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of July 25, 2020, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
As of July 25, 2020, the carrying value of our investments in privately held companies was $1.3 billion. $0.7 billion of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $0.3 billion related to these privately held investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-20-000010:notes:224]
Fair Value

[0000858877-20-000010:notes:225]
| (a) | Assets and Liabilities Measured at Fair Value on a Recurring Basis |

[0000858877-20-000010:notes:226]
Assets and liabilities measured at fair value on a recurring basis were as follows (in millions):

[0000858877-20-000010:notes:227]
|  | JULY 25, 2020 |  | JULY 27, 2019 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 10,024 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,024 |  |  | $ | 10,083 |  |  | $ | — |  |  | $ | 10,083 |  |
| Corporate debt securities | — |  |  | 8 |  |  | — |  |  | 8 |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 2,685 |  |  | — |  |  | 2,685 |  |  | — |  |  | 808 |  |  | 808 |  |
| U.S. government agency securities | — |  |  | 110 |  |  | — |  |  | 110 |  |  | — |  |  | 169 |  |  | 169 |  |
| Corporate debt securities | — |  |  | 11,877 |  |  | — |  |  | 11,877 |  |  | — |  |  | 19,262 |  |  | 19,262 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,035 |  |  | — |  |  | 2,035 |  |  | — |  |  | 1,421 |  |  | 1,421 |  |
| Commercial paper | — |  |  | 727 |  |  | — |  |  | 727 |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposit | — |  |  | 176 |  |  | — |  |  | 176 |  |  | — |  |  | — |  |  | — |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Derivative assets | — |  |  | 190 |  |  | 1 |  |  | 191 |  |  | — |  |  | 89 |  |  | 89 |  |
| Total | $ | 10,024 |  |  | $ | 17,808 |  |  | $ | 1 |  |  | $ | 27,833 |  |  | $ | 10,086 |  |  | $ | 21,749 |  |  | $ | 31,835 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 15 |  |  | $ | 15 |  |
| Total | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 15 |  |  | $ | 15 |  |

[0000858877-20-000010:notes:228]
Level 1 marketable equity securities are determined by using quoted prices in active markets for identical assets. Level 2 available-for-sale debt investments are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. Our derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs. We did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented. Level 3 assets include certain derivative instruments, the values of which are determined based on discounted cash flow models using inputs that we could not corroborate with market data.

[0000858877-20-000010:notes:229]
| (b) | Assets Measured at Fair Value on a Nonrecurring Basis |

[0000858877-20-000010:notes:230]
The carrying value of our non-marketable equity securities recorded to fair value on a non-recurring basis is adjusted for observable transactions for identical or similar investments of the same issuer or impairment. These securities are classified as Level 3 in the fair value hierarchy because we estimate the value based on valuation methods using the observable transaction price at the transaction date and other unobservable inputs such as volatility, rights, and obligations of the securities we hold.

[0000858877-20-000010:notes:231]
The fair value for purchased intangible assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation. Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable. The remaining carrying value of the specific purchased intangible assets that were impaired were zero as of July 25, 2020.

[0000858877-20-000010:notes:232]
The fair value of property held for sale was measured with the assistance of third-party valuation models, which used discounted cash flow techniques as part of their analysis. The fair value measurement was categorized as Level 3, as significant unobservable inputs were used in the valuation report. The impairment charges as a result of the valuations, which represented the difference between the fair value less cost to sell and the carrying amount of the assets held for sale, were included in restructuring and other charges. We recognized an impairment charge of $65 million during fiscal 2020 and the remaining carrying value of the property held for sale that was impaired was $9 million as of July 25, 2020.

[0000858877-20-000010:notes:233]
| (c) | Other Fair Value Disclosures |

[0000858877-20-000010:notes:234]
The fair value of our short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables and financed service contracts as of July 25, 2020 and July 27, 2019 was $4.5 billion and $3.7 billion, respectively. The estimated fair value of our long-term loan receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.
As of July 25, 2020 and July 27, 2019, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of July 25, 2020, the fair value of our senior notes and other long-term debt was $17.4 billion, with a carrying amount of $14.6 billion. This compares to a fair value of $22.1 billion and a carrying amount of $20.5 billion as of July 27, 2019. The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:DebtDisclosureTextBlock

[0000858877-20-000010:notes:235]
Borrowings

[0000858877-20-000010:notes:236]
| (a) | Short-Term Debt |

[0000858877-20-000010:notes:237]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-20-000010:notes:238]
|  | July 25, 2020 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 3,005 |  |  | 2.07 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 3,005 |  |  |  |  | $ | 10,191 |  |  |  |

[0000858877-20-000010:notes:239]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-20-000010:notes:240]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-20-000010:notes:241]
| (b) | Long-Term Debt |

[0000858877-20-000010:notes:242]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-20-000010:notes:243]
|  |  |  | July 25, 2020 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | — |  |  | — |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | — |  |  | — |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.94% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.21% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.06% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.37% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 14,500 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (88 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 171 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 14,583 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 3,005 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 11,578 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 14,583 |  |  |  |  | $ | 20,473 |  |  |  |

[0000858877-20-000010:notes:244]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $2.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-20-000010:notes:245]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of July 25, 2020, we were in compliance with all debt covenants.

[0000858877-20-000010:notes:246]
As of July 25, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-20-000010:notes:247]
| Fiscal Year | Amount |
| 2021 | $ | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 14,500 |  |

[0000858877-20-000010:notes:248]
| (c) | Credit Facility |

[0000858877-20-000010:notes:249]
On May 15, 2020, we entered into a 364-day credit agreement with certain institutional lenders that provides for a $2.75 billion unsecured revolving credit facility that is scheduled to expire on May 14, 2021. The credit agreement is structured as an amendment and restatement of our five-year credit facility which would have terminated on May 15, 2020, the end of its five-year term. As of July 25, 2020, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-20-000010:notes:250]
Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than 0.25%. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-20-000010:notes:251]
Derivative Instruments

[0000858877-20-000010:notes:252]
| (a) | Summary of Derivative Instruments |

[0000858877-20-000010:notes:253]
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We do, however, seek to mitigate such risks by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-20-000010:notes:254]
The fair values of our derivative instruments and the line items on the Consolidated Balance Sheets to which they were recorded are summarized as follows (in millions):

[0000858877-20-000010:notes:255]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | July 25, 2020 |  | July 27, 2019 |  | Balance Sheet Line Item |  | July 25, 2020 |  | July 27, 2019 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 7 |  |  | $ | 5 |  |  | Other current liabilities |  | $ | 2 |  |  | $ | 8 |  |
| Interest rate derivatives | Other current assets |  | 6 |  |  | — |  |  | Other current liabilities |  | — |  |  | 1 |  |
| Interest rate derivatives | Other assets |  | 169 |  |  | 75 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 182 |  |  | 80 |  |  |  |  | 2 |  |  | 9 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 8 |  |  | 9 |  |  | Other current liabilities |  | 8 |  |  | 6 |  |
| Equity derivatives | Other assets |  | 1 |  |  | — |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 9 |  |  | 9 |  |  |  |  | 8 |  |  | 6 |  |
| Total |  |  | $ | 191 |  |  | $ | 89 |  |  |  |  | $ | 10 |  |  | $ | 15 |  |

[0000858877-20-000010:notes:256]
The following amounts were recorded on the Consolidated Balance Sheets related to cumulative basis adjustments for our fair value hedges (in millions):

[0000858877-20-000010:notes:257]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | July 25, 2020 |  | July 27, 2019 |  | July 25, 2020 |  | July 27, 2019 |
| Short-term debt |  | $ | (506 | ) |  | $ | (2,000 | ) |  | $ | (6 | ) |  | $ | — |  |
| Long-term debt |  | $ | (2,159 | ) |  | $ | (2,565 | ) |  | $ | (165 | ) |  | $ | (73 | ) |

[0000858877-20-000010:notes:258]
See Note 17 for the effects of our cash flow hedging instruments on other comprehensive income (OCI) and the Consolidated Statements of Operations.

[0000858877-20-000010:notes:259]
The effect on the Consolidated Statements of Operations of derivative instruments designated as fair value and cash flow hedges is summarized as follows (in millions):

[0000858877-20-000010:notes:260]
|  | July 25, 2020 |  | July 27, 2019 |
|  | Revenue |  | Cost of sales |  | Operating expenses |  | Interest and other income (loss), net |  | Revenue |  | Cost of sales |  | Operating expenses |  | Interest and other income (loss), net |
| Total amounts presented in the Consolidated Statements of Operations in which the effects of fair value or cash flow hedges are recorded | $ | 49,301 |  |  | $ | 17,618 |  |  | $ | 18,063 |  |  | $ | 350 |  |  | $ | 51,904 |  |  | $ | 19,238 |  |  | $ | 18,447 |  |  | $ | 352 |  |
| The effects of fair value and cash flow hedging: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gains (losses) on fair value hedging relationships: |
| Interest rate derivatives |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hedged items | — |  |  | — |  |  | — |  |  | (98 | ) |  | — |  |  | — |  |  | — |  |  | (138 | ) |
| Derivatives designated as hedging instruments | — |  |  | — |  |  | — |  |  | 101 |  |  | — |  |  | — |  |  | — |  |  | 145 |  |
| Gains (losses) on cash flow hedging relationships: |
| Foreign currency derivatives |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amount of gains (losses) reclassified from AOCI to income | (1 | ) |  | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |  | 1 |  |  | — |  |
| Total gains (losses) | $ | (1 | ) |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 7 |  |

[0000858877-20-000010:notes:261]
The effect on the Consolidated Statements of Operations of derivative instruments not designated as hedges is summarized as follows (in millions):

[0000858877-20-000010:notes:262]
|  |  |  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (5 | ) |  | $ | (60 | ) |  | $ | (24 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | 24 |  |  | 19 |  |  | 50 |  |
|  |  | Cost of sales |  | 1 |  |  | 2 |  |  | 4 |  |
|  |  | Other income (loss), net |  | (10 | ) |  | (16 | ) |  | (11 | ) |
| Equity derivatives |  | Other income (loss), net |  | 9 |  |  | 3 |  |  | (4 | ) |
| Total |  |  |  | $ | 19 |  |  | $ | (52 | ) |  | $ | 15 |  |

[0000858877-20-000010:notes:263]
The notional amounts of our outstanding derivatives are summarized as follows (in millions):

[0000858877-20-000010:notes:264]
|  | July 25, 2020 |  | July 27, 2019 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 743 |  |  | $ | 663 |  |
| Interest rate derivatives | 2,500 |  |  | 4,500 |  |
| Net investment hedging instruments | 331 |  |  | 309 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 3,241 |  |  | 2,708 |  |
| Total return swaps—deferred compensation | 580 |  |  | 574 |  |
| Total | $ | 7,395 |  |  | $ | 8,754 |  |

[0000858877-20-000010:notes:265]
| (b) | Offsetting of Derivative Instruments |

[0000858877-20-000010:notes:266]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty. As of July 25, 2020 and July 27, 2019, the potential effects of these rights of set-off associated with the derivative contracts would be a reduction to both derivative assets and derivative liabilities of $10 million and $13 million, respectively.

[0000858877-20-000010:notes:267]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral received as of July 25, 2020 and July 27, 2019 was $173 million and $76 million, respectively. Including the effects of collateral, this results in a net derivative asset of $8 million and $2 million as of July 25, 2020 and July 27, 2019, respectively.

[0000858877-20-000010:notes:268]
| (c) | Foreign Currency Exchange Risk |

[0000858877-20-000010:notes:269]
We conduct business globally in numerous currencies. Therefore, we are exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, we enter into foreign currency contracts. We do not enter into such contracts for speculative purposes.

[0000858877-20-000010:notes:270]
We hedge forecasted foreign currency transactions related to certain revenues, operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The derivative instrument’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. During the fiscal years presented, we did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-20-000010:notes:271]
We enter into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, including long-term customer financings, investments, and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of intercompany balances or other current assets, investments, or liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-20-000010:notes:272]
We hedge certain net investments in our foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on our net investment in those foreign subsidiaries. These derivative instruments generally have maturities of up to six months.

[0000858877-20-000010:notes:273]
| (d) | Interest Rate Risk |

[0000858877-20-000010:notes:274]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt   We hold interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2021 through 2025. Under these interest rate swaps, we receive fixed-rate interest payments and make interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.

[0000858877-20-000010:notes:275]
| (e) | Equity Price Risk |

[0000858877-20-000010:notes:276]
We may hold marketable equity securities in our portfolio that are subject to price risk. To diversify our overall portfolio, we also hold equity derivatives that are not designated as accounting hedges. The change in the fair value of each of these investment types are included in other income (loss), net. 
We are also exposed to variability in compensation charges related to certain deferred compensation obligations to employees. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure and offset the related compensation expense.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-20-000010:notes:277]
Commitments and Contingencies

[0000858877-20-000010:notes:278]
| (a) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-20-000010:notes:279]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of July 25, 2020 and July 27, 2019, we had total purchase commitments for inventory of $4.4 billion and $5.0 billion, respectively.

[0000858877-20-000010:notes:280]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 25, 2020 and July 27, 2019, the liability for these purchase commitments was $141 million and $129 million, respectively, and was included in other current liabilities. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $139 million, $95 million, and $105 million in fiscal 2020, 2019, and 2018, respectively.

[0000858877-20-000010:notes:281]
| (b) | Other Commitments |

[0000858877-20-000010:notes:282]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-20-000010:notes:283]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-20-000010:notes:284]
|  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Compensation expense related to acquisitions | $ | 214 |  |  | $ | 313 |  |  | $ | 203 |  |

[0000858877-20-000010:notes:285]
As of July 25, 2020, we estimated that future cash compensation expense of up to $271 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-20-000010:notes:286]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.3 billion as of each of July 25, 2020 and July 27, 2019.

[0000858877-20-000010:notes:287]
| (c) | Product Warranties |

[0000858877-20-000010:notes:288]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-20-000010:notes:289]
|  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Balance at beginning of fiscal year | $ | 342 |  |  | $ | 359 |  |  | $ | 407 |  |
| Provisions for warranties issued | 561 |  |  | 600 |  |  | 582 |  |
| Adjustments for pre-existing warranties | (8 | ) |  | (12 | ) |  | (38 | ) |
| Settlements | (564 | ) |  | (603 | ) |  | (592 | ) |
| Acquisitions and divestitures | — |  |  | (2 | ) |  | — |  |
| Balance at end of fiscal year | $ | 331 |  |  | $ | 342 |  |  | $ | 359 |  |

[0000858877-20-000010:notes:290]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-20-000010:notes:291]
| (d) | Financing and Other Guarantees |

[0000858877-20-000010:notes:292]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-20-000010:notes:293]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. During fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic environment. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $26.9 billion, $29.6 billion, and $28.2 billion in fiscal 2020, 2019, and 2018, respectively. The balance of the channel partner financing subject to guarantees was $1.1 billion and $1.4 billion as of July 25, 2020 and July 27, 2019, respectively.

[0000858877-20-000010:notes:294]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $9 million, $14 million, and $35 million in fiscal 2020, 2019, and 2018, respectively.

[0000858877-20-000010:notes:295]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at July 25, 2020 and July 27, 2019, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-20-000010:notes:296]
|  | July 25, 2020 |  | July 27, 2019 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 198 |  |  | $ | 197 |  |
| End user | 9 |  |  | 21 |  |
| Total | $ | 207 |  |  | $ | 218 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (19 | ) |  | $ | (62 | ) |
| End user | (9 | ) |  | (15 | ) |
| Total | $ | (28 | ) |  | $ | (77 | ) |
| Total | $ | 179 |  |  | $ | 141 |  |

[0000858877-20-000010:notes:297]
| (e) | Indemnifications |

[0000858877-20-000010:notes:298]
In the normal course of business, we indemnify other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-20-000010:notes:299]
Charter Communications, Inc. (“Charter”), which acquired Time Warner Cable (“TWC”) in May 2016, is seeking indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Sprint sought monetary damages, alleging that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. The Court awarded Sprint pre and post judgment interest of approximately $10 million and denied TWC’s post-trial motions and appeals. Charter reported that it paid the judgment in full. At this time, we are working with Charter to calculate the correct amount of indemnification. We do not believe that our indemnity obligations under our agreement will be material.

[0000858877-20-000010:notes:300]
We also have been asked to indemnify certain of our service provider customers that have been subject to patent infringement claims asserted by Chanbond, LLC (“Chanbond”) in the United States District Court for the District of Delaware on September 21, 2015. Chanbond alleges that 13 service provider companies, including among others, Comcast Corporation, Charter Communications, Inc. (“Charter”), Time Warner Cable, Inc. (subsequently acquired by Charter), Cox Communications, Inc. (“Cox”), and Cablevision Systems Corporation, infringe three patents by providing high speed cable internet services to their customers utilizing cable modems and cable modem termination systems, consistent with the DOCSIS 3.0 standard, provided by

[0000858877-20-000010:notes:301]
us and other manufacturers generally used in combination with each other. Chanbond seeks monetary damages. On July 15, 2020, the Court vacated the August 19, 2020 trial date for Chanbond’s case against Cox and has not yet set a new trial date. The other cases against the remaining service provider defendants also have not yet been set for trial. We believe that the service provider defendants have strong non-infringement, invalidity and other defenses. Due to uncertainties surrounding the litigation processes, we are unable to reasonably estimate the ultimate outcome of the cases at this time, but should Chanbond prevail in its cases against the service provider defendants, we do not believe that any potential indemnity liability would be material.

[0000858877-20-000010:notes:302]
During fiscal 2018, we recorded legal and indemnification settlement charges of $127 million to product cost of sales related to prior indemnification matters resolved in fiscal 2018.

[0000858877-20-000010:notes:303]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-20-000010:notes:304]
It is not possible to determine the maximum potential amount under these indemnification agreements due to uncertainties in the litigation process, coordination with other suppliers and the defendants in these cases, and the unique facts and circumstances involved in each particular agreement. Historically, payments made by us under these agreements have not had a material effect on our operating results, financial position, or cash flows.

[0000858877-20-000010:notes:305]
| (f) | Legal Proceedings |

[0000858877-20-000010:notes:306]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-20-000010:notes:307]
During the second quarter of fiscal 2020, $0.8 billion of penalty and interest asserted by the Brazilian federal tax authorities against our Brazilian subsidiary on the theory of joint liability was dismissed on its merits. The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total remaining asserted claims by Brazilian state and federal tax authorities aggregate to $155 million for the alleged evasion of import and other taxes, $756 million for interest, and $383 million for various penalties, all determined using an exchange rate as of July 25, 2020.

[0000858877-20-000010:notes:308]
We have completed a thorough review of the matters and believe the remaining asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-20-000010:notes:309]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial started on May 2, 2016, and, on May 12, 2016, the jury returned a verdict finding willful infringement. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the District Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit on various grounds, and after various proceedings, on July 12, 2019, the Federal Circuit vacated the enhanced damages award; vacated and remanded in part the willful infringement finding; vacated and remanded the attorneys’ fees award for further proceedings; and affirmed the District Court’s other findings. On April 1, 2020, the District Court issued a final judgment on the remanded issues, finding no evidence of willful infringement and reinstating the $8 million award of attorneys’ fees. SRI appealed the judgment of no willful infringement to the Federal Circuit on April 3, 2020, and Cisco filed a cross-appeal on the attorneys’ fees award on April 9, 2020. Cisco has paid SRI $28.1 million, representing the portion of the judgment that the Federal Circuit previously affirmed, plus interest and royalties on post-verdict sales. While the remaining proceedings may result in an additional loss, we do not expect it to be material.

[0000858877-20-000010:notes:310]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the

[0000858877-20-000010:notes:311]
claims of the other two patents have been found unpatentable. Starting on May 6, 2020 and concluding on June 25, 2020, the District Court conducted a bench trial by videoconference on the claims in the five patents not subject to the IPR Proceedings, including claims in three for which the PTAB declined to institute IPR Proceedings. Centripetal seeks damages, enhanced damages for willful infringement, and broad injunctive relief. While the trial result is uncertain, we believe that a District Court finding of validity and infringement, finding of willfulness, award of damages including any enhancement, and/or entry of injunctive relief are not supported by either the law or the evidence presented at trial. We intend to appeal any adverse outcome to the United States Court of Appeals for the Federal Circuit, and we believe that any relief ultimately awarded would not be material. On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. District Court proceedings, one of which has been invalidated by the PTAB. We are currently assessing the cases filed in Germany. Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of the cases at this time.

[0000858877-20-000010:notes:312]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleged that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster sought monetary damages. Oyster also had filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the District Court consolidated the cases alleging infringement of the ‘327 Patent. Oyster’s cases against some of the defendants were resolved. The District Court vacated the November 4, 2018 trial date set for Oyster’s claims against Cisco and one other remaining defendant, pending resolution of Oyster’s December 6, 2018 appeal of the District Court’s summary judgment ruling dismissing certain of Oyster’s claims. On May 8, 2020, the Federal Circuit affirmed the District Court’s summary judgment ruling. On June 18, 2020, Oyster dismissed its case against us based on the ‘327 Patent with prejudice.

[0000858877-20-000010:notes:313]
Finjan     On January 6, 2017, Finjan, Inc. (“Finjan”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Finjan alleges that Cisco’s AMP and ThreatGrid products and the URL rewrite feature of Cisco’s ESA Outbreak Filter product infringe five patents, four of which have expired. Finjan has conceded that they are not entitled to any pre-suit damages, accordingly it seeks approximately three weeks of damages for the alleged infringement of the 8,677,494 and 6,154,844 patents, approximately ten months of damages for the 6,804,780 patent, approximately three years of damages for the 7,647,633 patent, and approximately three-and-a-half years of past damages for the 8,141,154 patent and an ongoing royalty until its expiration on December 12, 2025. The case is currently set for jury trial starting October 19, 2020. While we believe that we have strong non-infringement arguments, that the patents are invalid, that Finjan’s damages theories are not supported by prevailing law and that Finjan will not be able to meet its burden required for injunctive relief, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.

[0000858877-20-000010:notes:314]
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. 
For additional information regarding intellectual property litigation, see “Part I, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” of this Annual Report on Form 10-K.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-20-000010:notes:315]
Shareholders’ Equity

[0000858877-20-000010:notes:316]
| (a) | Cash Dividends on Shares of Common Stock |

[0000858877-20-000010:notes:317]
We declared and paid cash dividends of $1.42, $1.36 and $1.24 per common share, or $6.0 billion each year, on our outstanding common stock during fiscal 2020, 2019, and 2018, respectively.

[0000858877-20-000010:notes:318]
Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-20-000010:notes:319]
| (b) | Stock Repurchase Program |

[0000858877-20-000010:notes:320]
In September 2001, our Board of Directors authorized a stock repurchase program. As of July 25, 2020, the remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $10.8 billion, with no termination date.

[0000858877-20-000010:notes:321]
A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-20-000010:notes:322]
| Years Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| July 25, 2020 |  | 59 |  |  | $ | 44.36 |  |  | $ | 2,619 |  |
| July 27, 2019 |  | 418 |  |  | $ | 49.22 |  |  | $ | 20,577 |  |
| July 28, 2018 |  | 432 |  |  | $ | 40.88 |  |  | $ | 17,661 |  |

[0000858877-20-000010:notes:323]
There were no stock repurchases pending settlement as of July 25, 2020. There were $40 million and $180 million in stock repurchases that were pending settlement as of  July 27, 2019 and July 28, 2018, respectively.

[0000858877-20-000010:notes:324]
The purchase price for the shares of our stock repurchased is reflected as a reduction to shareholders’ equity.

[0000858877-20-000010:notes:325]
We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings or an increase to accumulated deficit and (ii) a reduction of common stock and additional paid-in capital.

[0000858877-20-000010:notes:326]
| (c) | Preferred Stock |

[0000858877-20-000010:notes:327]
Under the terms of our Articles of Incorporation, the Board of Directors may determine the rights, preferences, and terms of our authorized but unissued shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-20-000010:notes:328]
Employee Benefit Plans

[0000858877-20-000010:notes:329]
| (a) | Employee Stock Incentive Plans |

[0000858877-20-000010:notes:330]
Stock Incentive Plan Program Description    As of July 25, 2020, we had one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with Cisco. The number and frequency of share-based awards are based on competitive practices, operating results of Cisco, government regulations, and other factors. Our primary stock incentive plan is summarized as follows:

[0000858877-20-000010:notes:331]
2005 Plan    The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions.  Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. As of July 25, 2020, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares. The 2005 Plan may be terminated by the Board of Directors at any time and for any reason, and is currently set to terminate at the 2021 Annual Meeting unless re-adopted or extended by the shareholders prior to or on such date.

[0000858877-20-000010:notes:332]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. For restricted stock units that were awarded with vesting contingent upon the achievement of future financial performance or market-based metrics, the maximum awards that can be achieved upon full vesting of such awards. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available

[0000858877-20-000010:notes:333]
for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of July 25, 2020, 183 million shares were authorized for future grant under the 2005 Plan.

[0000858877-20-000010:notes:334]
| (b) | Employee Stock Purchase Plan |

[0000858877-20-000010:notes:335]
We have an Employee Stock Purchase Plan under which 721.4 million shares of our common stock have been reserved for issuance as of July 25, 2020. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. We issued 18 million, 19 million, and 22 million shares under the Employee Stock Purchase Plan in fiscal 2020, 2019, and 2018, respectively. As of July 25, 2020, 141 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-20-000010:notes:336]
| (c) | Summary of Share-Based Compensation Expense |

[0000858877-20-000010:notes:337]
Share-based compensation expense consists primarily of expenses for stock options, stock purchase rights, restricted stock, and RSUs granted to employees. The following table summarizes share-based compensation expense (in millions):

[0000858877-20-000010:notes:338]
| Years Ended | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Cost of sales—product | $ | 93 |  |  | $ | 90 |  |  | $ | 94 |  |
| Cost of sales—service | 144 |  |  | 130 |  |  | 133 |  |
| Share-based compensation expense in cost of sales | 237 |  |  | 220 |  |  | 227 |  |
| Research and development | 592 |  |  | 540 |  |  | 538 |  |
| Sales and marketing | 500 |  |  | 519 |  |  | 555 |  |
| General and administrative | 215 |  |  | 250 |  |  | 246 |  |
| Restructuring and other charges | 25 |  |  | 62 |  |  | 33 |  |
| Share-based compensation expense in operating expenses | 1,332 |  |  | 1,371 |  |  | 1,372 |  |
| Total share-based compensation expense | $ | 1,569 |  |  | $ | 1,591 |  |  | $ | 1,599 |  |
| Income tax benefit for share-based compensation | $ | 452 |  |  | $ | 542 |  |  | $ | 558 |  |

[0000858877-20-000010:notes:339]
As of July 25, 2020, the total compensation cost related to unvested share-based awards not yet recognized was $3.9 billion, which is expected to be recognized over approximately 2.7 years on a weighted-average basis.

[0000858877-20-000010:notes:340]
| (d) | Restricted Stock and Stock Unit Awards |

[0000858877-20-000010:notes:341]
A summary of the restricted stock and stock unit activity, which includes time-based and performance-based or market-based RSUs, is as follows (in millions, except per-share amounts):

[0000858877-20-000010:notes:342]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 29, 2017 | 141 |  |  | $ | 26.94 |  |  |  |
| Granted | 46 |  |  | 35.62 |  |  |  |
| Assumed from acquisitions | 1 |  |  | 28.26 |  |  |  |
| Vested | (53 | ) |  | 26.02 |  |  | $ | 1,909 |  |
| Canceled/forfeited/other | (16 | ) |  | 28.37 |  |  |  |
| UNVESTED BALANCE AT JULY 28, 2018 | 119 |  |  | 30.56 |  |  |  |
| Granted | 45 |  |  | 47.71 |  |  |  |
| Vested | (50 | ) |  | 29.25 |  |  | $ | 2,446 |  |
| Canceled/forfeited/other | (14 | ) |  | 32.01 |  |  |  |
| UNVESTED BALANCE AT JULY 27, 2019 | 100 |  |  | 38.66 |  |  |  |
| Granted | 49 |  |  | 42.61 |  |  |  |
| Vested | (44 | ) |  | 35.20 |  |  | $ | 2,045 |  |
| Canceled/forfeited/other | (9 | ) |  | 40.45 |  |  |  |
| UNVESTED BALANCE AT JULY 25, 2020 | 96 |  |  | $ | 42.03 |  |  |  |

[0000858877-20-000010:notes:343]
| (e) | Valuation of Employee Share-Based Awards |

[0000858877-20-000010:notes:344]
Time-based restricted stock units and PRSUs that are based on our financial performance metrics or non-financial operating goals are valued using the market value of our common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, we estimated the fair value of the total shareholder return (TSR) component of the PRSUs using a Monte Carlo simulation model. The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-20-000010:notes:345]
|  | RESTRICTED STOCK UNITS |
| Years Ended | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Number of shares granted (in millions) | 47 |  |  | 43 |  |  | 43 |  |
| Grant date fair value per share | $ | 42.68 |  |  | $ | 47.75 |  |  | $ | 35.81 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 3.1 | % |  | 2.7 | % |  | 3.2 | % |
| Range of risk-free interest rates | 0.0% – 2.0% |  |  | 0.0% – 2.9% |  |  | 0.0% – 2.7% |  |

[0000858877-20-000010:notes:346]
|  | PERFORMANCE BASED RESTRICTED STOCK UNITS |
| Years Ended | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Number of shares granted (in millions) | 2 |  |  | 2 |  |  | 3 |  |
| Grant date fair value per share | $ | 41.91 |  |  | $ | 47.00 |  |  | $ | 32.69 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 2.8 | % |  | 2.8 | % |  | 3.5 | % |
| Range of risk-free interest rates | 1.7% – 2.0% |  |  | 2.1% – 3.0% |  |  | 1.0% – 2.7% |  |
| Range of expected volatilities for index | 13.7% - 69.0% |  |  | 13.0% - 65.2% |  |  | 12.5% – 82.8% |  |

[0000858877-20-000010:notes:347]
The PRSUs granted during the fiscal years presented are contingent on the achievement of our financial performance metrics, our comparative market-based returns, or the achievement of financial and non-financial operating goals. For the awards based on financial performance metrics or comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period. Generally, the remaining 50% of the PRSUs are earned based on our TSR measured against the benchmark TSR of a peer group over the same period. Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of our financial performance metrics or our comparative market-based returns, and 0% to 100% of the target shares granted contingent on the achievement of non-financial operating goals.

[0000858877-20-000010:notes:348]
The assumptions for the valuation of employee stock purchase rights are summarized as follows:

[0000858877-20-000010:notes:349]
|  | EMPLOYEE STOCK PURCHASE RIGHTS |
| Years Ended | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Weighted-average assumptions: |  |  |  |  |  |
| Expected volatility | 22.2 | % |  | 20.4 | % |  | 22.1 | % |
| Risk-free interest rate | 1.8 | % |  | 1.9 | % |  | 1.3 | % |
| Expected dividend | 3.0 | % |  | 3.0 | % |  | 3.1 | % |
| Expected life (in years) | 1.3 |  |  | 1.3 |  |  | 1.3 |  |
| Weighted-average estimated grant date fair value per share | $ | 10.20 |  |  | $ | 9.06 |  |  | $ | 7.48 |  |

[0000858877-20-000010:notes:350]
The valuation of employee stock purchase rights and the related assumptions are for the employee stock purchases made during the respective fiscal years.

[0000858877-20-000010:notes:351]
We used third-party analyses to assist in developing the assumptions used in our Black-Scholes model. We are responsible for determining the assumptions used in estimating the fair value of our share-based payment awards.

[0000858877-20-000010:notes:352]
We used the implied volatility for traded options (with contract terms corresponding to the expected life of the employee stock purchase rights) on our stock as the expected volatility assumption required in the Black-Scholes model. The implied volatility is more representative of future stock price trends than historical volatility. The risk-free interest rate assumption is based upon observed interest rates appropriate for the term of our employee stock purchase rights. The dividend yield assumption is based on the history and expectation of dividend payouts at the grant date.

[0000858877-20-000010:notes:353]
| (f) | Employee 401(k) Plans |

[0000858877-20-000010:notes:354]
We sponsor the Cisco Systems, Inc. 401(k) Plan (the “Plan”) to provide retirement benefits for our employees. As allowed under Section 401(k) of the Internal Revenue Code, the Plan provides for tax-deferred salary contributions and after-tax contributions for eligible employees. The Plan allows employees to contribute up to 75% of their annual eligible earnings to the Plan on a pretax and after-tax basis, including Roth contributions. Employee contributions are limited to a maximum annual amount as set periodically by the Internal Revenue Code. We match pretax and Roth employee contributions up to 100% of the first 4.5% of eligible earnings that are contributed by employees. Therefore, the maximum matching contribution that we may allocate to each participant’s account will not exceed $12,825 for the 2020 calendar year due to the $285,000 annual limit on eligible earnings imposed by the Internal Revenue Code. All matching contributions vest immediately. Our matching contributions to the Plan totaled $295 million, $283 million, and $269 million in fiscal 2020, 2019, and 2018, respectively.

[0000858877-20-000010:notes:355]
The Plan allows employees who meet the age requirements and reach the Plan contribution limits to make catch-up contributions (pretax or Roth) not to exceed the lesser of 75% of their annual eligible earnings or the limit set forth in the Internal Revenue Code. Catch-up contributions are not eligible for matching contributions. In addition, the Plan provides for discretionary profit-sharing contributions as determined by the Board of Directors. Such contributions to the Plan are allocated among eligible participants in the proportion of their salaries to the total salaries of all participants. There were no discretionary profit-sharing contributions made in fiscal 2020, 2019, and 2018.

[0000858877-20-000010:notes:356]
We also sponsor other 401(k) plans as a result of acquisitions of other companies. Our contributions to these plans were not material to Cisco on either an individual or aggregate basis for any of the fiscal years presented.

[0000858877-20-000010:notes:357]
| (g) | Deferred Compensation Plans |

[0000858877-20-000010:notes:358]
The Cisco Systems, Inc. Deferred Compensation Plan (the “Deferred Compensation Plan”), a nonqualified deferred compensation plan, became effective in 2007. As required by applicable law, participation in the Deferred Compensation Plan is limited to a select group of our management employees. Under the Deferred Compensation Plan, which is an unfunded and unsecured deferred compensation arrangement, a participant may elect to defer base salary, bonus, and/or commissions, pursuant to such rules as may be established by Cisco, up to the maximum percentages for each deferral election as described in the plan. We may also, at our discretion, make a matching contribution to the employee under the Deferred Compensation Plan. A matching contribution equal to 4.5% of eligible compensation in excess of the Internal Revenue Code limit for qualified plans for calendar year 2020 that is deferred by participants under the Deferred Compensation Plan (with a $1.5 million cap on eligible compensation) will be made to eligible participants’ accounts at the end of calendar year 2020. The total deferred compensation liability under the Deferred Compensation Plan, together with deferred compensation plans assumed from acquired companies, was approximately $704 million and $678 million as of July 25, 2020 and July 27, 2019, respectively, and was recorded primarily in other long-term liabilities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-20-000010:notes:359]
Comprehensive Income (Loss)

[0000858877-20-000010:notes:360]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, are summarized as follows (in millions):

[0000858877-20-000010:notes:361]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains and Losses |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 29, 2017 | $ | 373 |  |  | $ | 32 |  |  | $ | (359 | ) |  | $ | 46 |  |
| Other comprehensive income (loss) before reclassifications | (543 | ) |  | 21 |  |  | (159 | ) |  | (681 | ) |
| (Gains) losses reclassified out of AOCI | (287 | ) |  | (68 | ) |  | 7 |  |  | (348 | ) |
| Tax benefit (expense) | 93 |  |  | 4 |  |  | (8 | ) |  | 89 |  |
| Total change for the period | (737 | ) |  | (43 | ) |  | (160 | ) |  | (940 | ) |
| Effect of adoption of accounting standard | 54 |  |  | — |  |  | (9 | ) |  | 45 |  |
| BALANCE AT JULY 28, 2018 | (310 | ) |  | (11 | ) |  | (528 | ) |  | (849 | ) |
| Other comprehensive income (loss) before reclassifications | 560 |  |  | — |  |  | (267 | ) |  | 293 |  |
| (Gains) losses reclassified out of AOCI | 13 |  |  | (3 | ) |  | 2 |  |  | 12 |  |
| Tax benefit (expense) | (95 | ) |  | — |  |  | 15 |  |  | (80 | ) |
| Total change for the period | 478 |  |  | (3 | ) |  | (250 | ) |  | 225 |  |
| Effect of adoption of accounting standard | (168 | ) |  | — |  |  | — |  |  | (168 | ) |
| BALANCE AT JULY 27, 2019 | — |  |  | (14 | ) |  | (778 | ) |  | (792 | ) |
| Other comprehensive income (loss) before reclassifications | 420 |  |  | 7 |  |  | (51 | ) |  | 376 |  |
| (Gains) losses reclassified out of AOCI | (42 | ) |  | 1 |  |  | 6 |  |  | (35 | ) |
| Tax benefit (expense) | (63 | ) |  | — |  |  | (5 | ) |  | (68 | ) |
| BALANCE AT JULY 25, 2020 | $ | 315 |  |  | $ | (6 | ) |  | $ | (828 | ) |  | $ | (519 | ) |

[0000858877-20-000010:notes:362]
The net gains (losses) reclassified out of AOCI into the Consolidated Statements of Operations, with line item location, during each period were as follows (in millions):

[0000858877-20-000010:notes:363]
|  |  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains and losses on available-for-sale investments |  | $ | 42 |  |  | $ | (13 | ) |  | $ | 287 |  |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | (1 | ) |  | 2 |  |  | — |  |  | Revenue |
| Foreign currency derivatives |  | — |  |  | — |  |  | 16 |  |  | Cost of sales |
| Foreign currency derivatives |  | — |  |  | 1 |  |  | 52 |  |  | Operating expenses |
|  |  | (1 | ) |  | 3 |  |  | 68 |  |  |  |
| Cumulative translation adjustment and actuarial gains and losses |  | — |  |  | — |  |  | (7 | ) |  | Operating expenses |
| Cumulative translation adjustment and actuarial gains and losses |  | (6 | ) |  | (2 | ) |  | — |  |  | Other income (loss), net |
| Total amounts reclassified out of AOCI |  | $ | 35 |  |  | $ | (12 | ) |  | $ | 348 |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-20-000010:notes:364]
Income Taxes

[0000858877-20-000010:notes:365]
| (a) | Provision for Income Taxes |

[0000858877-20-000010:notes:366]
The provision for income taxes consists of the following (in millions):

[0000858877-20-000010:notes:367]
| Years Ended | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Federal: |  |  |  |  |  |
| Current | $ | 1,101 |  |  | $ | 1,760 |  |  | $ | 9,900 |  |
| Deferred | (374 | ) |  | (84 | ) |  | 1,156 |  |
|  | 727 |  |  | 1,676 |  |  | 11,056 |  |
| State: |  |  |  |  |  |
| Current | 264 |  |  | 302 |  |  | 340 |  |
| Deferred | 287 |  |  | (2 | ) |  | (232 | ) |
|  | 551 |  |  | 300 |  |  | 108 |  |
| Foreign: |  |  |  |  |  |
| Current | 1,429 |  |  | 1,238 |  |  | 1,789 |  |
| Deferred | 49 |  |  | (264 | ) |  | (24 | ) |
|  | 1,478 |  |  | 974 |  |  | 1,765 |  |
| Total | $ | 2,756 |  |  | $ | 2,950 |  |  | $ | 12,929 |  |

[0000858877-20-000010:notes:368]
Income before provision for income taxes consists of the following (in millions):

[0000858877-20-000010:notes:369]
| Years Ended | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| United States | $ | 7,534 |  |  | $ | 7,611 |  |  | $ | 3,765 |  |
| International | 6,436 |  |  | 6,960 |  |  | 9,274 |  |
| Total | $ | 13,970 |  |  | $ | 14,571 |  |  | $ | 13,039 |  |

[0000858877-20-000010:notes:370]
The items accounting for the difference between income taxes computed at the federal statutory rate and the provision for income taxes consist of the following:

[0000858877-20-000010:notes:371]
| Years Ended | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Federal statutory rate | 21.0 | % |  | 21.0 | % |  | 27.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 3.5 |  |  | 2.0 |  |  | 0.6 |  |
| Foreign income at other than U.S. rates | (1.5 | ) |  | (4.5 | ) |  | (5.2 | ) |
| Tax credits | (0.9 | ) |  | (1.7 | ) |  | (2.5 | ) |
| Foreign-derived intangible income deduction | (2.6 | ) |  | (1.3 | ) |  | — |  |
| Domestic manufacturing deduction | — |  |  | — |  |  | (0.5 | ) |
| Stock-based compensation | (0.1 | ) |  | (0.6 | ) |  | (0.1 | ) |
| Impact of the Tax Act | — |  |  | 6.1 |  |  | 80.1 |  |
| Other, net | 0.3 |  |  | (0.8 | ) |  | (0.2 | ) |
| Total | 19.7 | % |  | 20.2 | % |  | 99.2 | % |

[0000858877-20-000010:notes:372]
During fiscal 2018 and 2019, we recorded a total tax charge as a result of the Tax Act of $11.3 billion, consisting of $9.0 billion of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries, $1.2 billion of foreign withholding tax and $1.1 billion of tax expense for DTA re-measurement.

[0000858877-20-000010:notes:373]
During fiscal 2020, the Internal Revenue Service (IRS) and Cisco settled all outstanding items related to the audit of our federal income tax returns for the fiscal year ended July 30, 2011 through July 27, 2013. As a result of the settlement, we recognized a net benefit to the provision for income taxes of $102 million, which included a reduction in interest expense of $4 million. We are no longer subject to U.S. federal tax audit through fiscal 2013.

[0000858877-20-000010:notes:374]
Foreign taxes associated with the repatriation of earnings of foreign subsidiaries were not provided on a cumulative total of $6.8 billion of undistributed earnings for certain foreign subsidiaries as of the end of fiscal 2020. We intend to reinvest these earnings indefinitely in such foreign subsidiaries. If these earnings were distributed in the form of dividends or otherwise, or if the shares

[0000858877-20-000010:notes:375]
of the relevant foreign subsidiaries were sold or otherwise transferred, we could be subject to additional foreign taxes. The amount of potential unrecognized deferred income tax liability related to these earnings is approximately $706 million.

[0000858877-20-000010:notes:376]
As a result of certain employment and capital investment actions, our income in certain foreign countries was subject to reduced tax rates. The tax incentives expired at the end of fiscal 2019. As of the end of fiscal 2019 and 2018, the gross income tax benefits attributable to tax incentives were estimated to be $0.3 billion and $0.9 billion ($0.08 and $0.19 per diluted share) for the respective years. The gross income tax benefits were partially offset by accruals of U.S. income taxes on foreign earnings.

[0000858877-20-000010:notes:377]
Unrecognized Tax Benefits

[0000858877-20-000010:notes:378]
The aggregate changes in the balance of gross unrecognized tax benefits were as follows (in millions):

[0000858877-20-000010:notes:379]
| Years Ended | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Beginning balance | $ | 1,925 |  |  | $ | 2,000 |  |  | $ | 1,973 |  |
| Additions based on tax positions related to the current year | 188 |  |  | 185 |  |  | 251 |  |
| Additions for tax positions of prior years | 554 |  |  | 84 |  |  | 84 |  |
| Reductions for tax positions of prior years | (136 | ) |  | (283 | ) |  | (129 | ) |
| Settlements | (4 | ) |  | (38 | ) |  | (124 | ) |
| Lapse of statute of limitations | (9 | ) |  | (23 | ) |  | (55 | ) |
| Ending balance | $ | 2,518 |  |  | $ | 1,925 |  |  | $ | 2,000 |  |

[0000858877-20-000010:notes:380]
As of July 25, 2020, $2.2 billion of the unrecognized tax benefits would affect the effective tax rate if realized. During fiscal 2020, we recognized $104 million of net interest expense and increased our unrecognized tax benefits for prior year tax positions by $554 million to reflect expected settlement positions in on-going U.S. federal, state, and foreign income tax return examinations. We recognized net interest expense of $30 million and $10 million, respectively, during fiscal 2019 and 2018. Our net penalty expense for fiscal 2020, 2019 and 2018 was not material. Our total accrual for interest and penalties was $340 million, $220 million, and $180 million as of the end of fiscal 2020, 2019, and 2018, respectively. We are no longer subject to U.S. federal income tax audit for returns covering tax years through fiscal 2013. We are no longer subject to foreign or state income tax audits for returns covering tax years through fiscal 1999 and fiscal 2008, respectively.

[0000858877-20-000010:notes:381]
We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters. We estimate that the unrecognized tax benefits at July 25, 2020 could be reduced by $150 million in the next 12 months.

[0000858877-20-000010:notes:382]
| (b) | Deferred Tax Assets and Liabilities |

[0000858877-20-000010:notes:383]
The following table presents the breakdown for net deferred tax assets (in millions):

[0000858877-20-000010:notes:384]
|  | July 25, 2020 |  | July 27, 2019 |
| Deferred tax assets | $ | 3,990 |  |  | $ | 4,065 |  |
| Deferred tax liabilities | (81 | ) |  | (95 | ) |
| Total net deferred tax assets | $ | 3,909 |  |  | $ | 3,970 |  |

[0000858877-20-000010:notes:385]
The following table presents the components of the deferred tax assets and liabilities (in millions):

[0000858877-20-000010:notes:386]
|  | July 25, 2020 |  | July 27, 2019 |
| ASSETS |  |  |  |
| Allowance for doubtful accounts and returns | $ | 110 |  |  | $ | 127 |  |
| Sales-type and direct-financing leases | 179 |  |  | 176 |  |
| Inventory write-downs and capitalization | 350 |  |  | 409 |  |
| Deferred foreign income | 253 |  |  | — |  |
| IPR&D, goodwill, and purchased intangible assets | 1,289 |  |  | 1,427 |  |
| Deferred revenue | 1,182 |  |  | 1,150 |  |
| Credits and net operating loss carryforwards | 1,105 |  |  | 1,241 |  |
| Share-based compensation expense | 135 |  |  | 164 |  |
| Accrued compensation | 353 |  |  | 342 |  |
| Lease liabilities | 240 |  |  | — |  |
| Other | 571 |  |  | 419 |  |
| Gross deferred tax assets | 5,767 |  |  | 5,455 |  |
| Valuation allowance | (700 | ) |  | (457 | ) |
| Total deferred tax assets | 5,067 |  |  | 4,998 |  |
| LIABILITIES |  |  |  |
| Purchased intangible assets | (577 | ) |  | (705 | ) |
| Depreciation | (179 | ) |  | (141 | ) |
| Unrealized gains on investments | (119 | ) |  | (70 | ) |
| ROU lease assets | (222 | ) |  | — |  |
| Other | (61 | ) |  | (112 | ) |
| Total deferred tax liabilities | (1,158 | ) |  | (1,028 | ) |
| Total net deferred tax assets | $ | 3,909 |  |  | $ | 3,970 |  |

[0000858877-20-000010:notes:387]
As of July 25, 2020, our federal, state, and foreign net operating loss carryforwards for income tax purposes were $405 million, $1.2 billion, and $644 million, respectively. A significant amount of the net operating loss carryforwards relates to acquisitions and, as a result, is limited in the amount that can be recognized in any one year. If not utilized, the federal net operating loss carryforwards will begin to expire in fiscal 2022, and the state and foreign net operating loss carryforwards will begin to expire in fiscal 2021. We have provided a valuation allowance of $98 million for deferred tax assets related to foreign net operating losses that are not expected to be realized.
As of July 25, 2020, our federal, state, and foreign tax credit carryforwards for income tax purposes were approximately $10 million, $1.2 billion, and $5 million, respectively. The federal tax credit carryforwards will begin to expire in fiscal 2021. The majority of state and foreign tax credits can be carried forward indefinitely. We have provided a valuation allowance of $541 million for deferred tax assets related to state and foreign tax credits that are not expected to be realized.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-20-000010:notes:388]
Segment Information and Major Customers

[0000858877-20-000010:notes:389]
| (a) | Revenue and Gross Margin by Segment |

[0000858877-20-000010:notes:390]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-20-000010:notes:391]
Summarized financial information by segment for fiscal 2020, 2019, and 2018, based on our internal management system and as utilized by our Chief Operating Decision Maker (CODM), is as follows (in millions):

[0000858877-20-000010:notes:392]
| Years Ended | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Revenue: |  |  |  |  |  |
| Americas | $ | 29,291 |  |  | $ | 30,927 |  |  | $ | 29,070 |  |
| EMEA | 12,659 |  |  | 13,100 |  |  | 12,425 |  |
| APJC | 7,352 |  |  | 7,877 |  |  | 7,834 |  |
| Total | $ | 49,301 |  |  | $ | 51,904 |  |  | $ | 49,330 |  |
| Gross margin: |  |  |  |  |  |
| Americas | $ | 19,547 |  |  | $ | 20,338 |  |  | $ | 18,792 |  |
| EMEA | 8,304 |  |  | 8,457 |  |  | 7,945 |  |
| APJC | 4,688 |  |  | 4,683 |  |  | 4,726 |  |
| Segment total | 32,538 |  |  | 33,479 |  |  | 31,463 |  |
| Unallocated corporate items | (855 | ) |  | (813 | ) |  | (857 | ) |
| Total | $ | 31,683 |  |  | $ | 32,666 |  |  | $ | 30,606 |  |

[0000858877-20-000010:notes:393]
Amounts may not sum due to rounding.

[0000858877-20-000010:notes:394]
Revenue in the United States was $26.1 billion, $27.4 billion, and $25.5 billion for fiscal 2020, 2019, and 2018, respectively.

[0000858877-20-000010:notes:395]
| (b) | Revenue for Groups of Similar Products and Services |

[0000858877-20-000010:notes:396]
We design, manufacture, and sell IP-based networking and other products related to the communications and IT industry and provide services associated with these products and their use.

[0000858877-20-000010:notes:397]
| (c) | Additional Segment Information |

[0000858877-20-000010:notes:398]
The majority of our assets as of July 25, 2020 and July 27, 2019 were attributable to our U.S. operations. In fiscal 2020, 2019, and 2018, no single customer accounted for 10% or more of revenue.

[0000858877-20-000010:notes:399]
Our long-lived assets are based on the physical location of the assets. The following table presents our long-lived assets, which consists of property and equipment, net and operating lease right-of-use assets information for geographic areas (in millions):

[0000858877-20-000010:notes:400]
|  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Long-lived assets: |  |  |  |  |  |
| United States | $ | 2,328 |  |  | $ | 2,266 |  |  | $ | 2,487 |  |
| International | 1,046 |  |  | 523 |  |  | 519 |  |
| Total | $ | 3,374 |  |  | $ | 2,789 |  |  | $ | 3,006 |  |


## us-gaap:EarningsPerShareTextBlock

[0000858877-20-000010:notes:401]
Net Income per Share

[0000858877-20-000010:notes:402]
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-20-000010:notes:403]
| Years Ended | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Net income | $ | 11,214 |  |  | $ | 11,621 |  |  | $ | 110 |  |
| Weighted-average shares—basic | 4,236 |  |  | 4,419 |  |  | 4,837 |  |
| Effect of dilutive potential common shares | 18 |  |  | 34 |  |  | 44 |  |
| Weighted-average shares—diluted | 4,254 |  |  | 4,453 |  |  | 4,881 |  |
| Net income per share—basic | $ | 2.65 |  |  | $ | 2.63 |  |  | $ | 0.02 |  |
| Net income per share—diluted | $ | 2.64 |  |  | $ | 2.61 |  |  | $ | 0.02 |  |
| Antidilutive employee share-based awards, excluded | 76 |  |  | 55 |  |  | 61 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000858877-20-000010:notes:404]
Supplementary Financial Data (Unaudited)

[0000858877-20-000010:notes:405]
(in millions, except per-share amounts)

[0000858877-20-000010:notes:406]
| Quarters Ended | July 25, 2020 |  | April 25, 2020 |  | January 25, 2020 |  | October 26, 2019 |
| Revenue | $ | 12,154 |  |  | $ | 11,983 |  |  | $ | 12,005 |  |  | $ | 13,159 |  |
| Gross margin | $ | 7,684 |  |  | $ | 7,771 |  |  | $ | 7,764 |  |  | $ | 8,464 |  |
| Operating income | $ | 3,247 |  |  | $ | 3,414 |  |  | $ | 3,380 |  |  | $ | 3,579 |  |
| Net income | $ | 2,636 |  |  | $ | 2,774 |  |  | $ | 2,878 |  |  | $ | 2,926 |  |
| Net income per share - basic | $ | 0.62 |  |  | $ | 0.66 |  |  | $ | 0.68 |  |  | $ | 0.69 |  |
| Net income per share - diluted | $ | 0.62 |  |  | $ | 0.65 |  |  | $ | 0.68 |  |  | $ | 0.68 |  |
| Cash dividends declared per common share | $ | 0.36 |  |  | $ | 0.36 |  |  | $ | 0.35 |  |  | $ | 0.35 |  |
| Cash and cash equivalents and investments | $ | 29,419 |  |  | $ | 28,574 |  |  | $ | 27,062 |  |  | $ | 28,035 |  |

[0000858877-20-000010:notes:407]
| Quarters Ended | July 27, 2019 (1) |  | April 27, 2019 |  | January 26, 2019 |  | October 27, 2018 |
| Revenue | $ | 13,428 |  |  | $ | 12,958 |  |  | $ | 12,446 |  |  | $ | 13,072 |  |
| Gross margin | $ | 8,574 |  |  | $ | 8,173 |  |  | $ | 7,773 |  |  | $ | 8,146 |  |
| Operating income | $ | 3,690 |  |  | $ | 3,513 |  |  | $ | 3,211 |  |  | $ | 3,805 |  |
| Net income | $ | 2,206 |  |  | $ | 3,044 |  |  | $ | 2,822 |  |  | $ | 3,549 |  |
| Net income per share - basic | $ | 0.52 |  |  | $ | 0.70 |  |  | $ | 0.63 |  |  | $ | 0.78 |  |
| Net income per share - diluted | $ | 0.51 |  |  | $ | 0.69 |  |  | $ | 0.63 |  |  | $ | 0.77 |  |
| Cash dividends declared per common share | $ | 0.35 |  |  | $ | 0.35 |  |  | $ | 0.33 |  |  | $ | 0.33 |  |
| Cash and cash equivalents and investments | $ | 33,413 |  |  | $ | 34,643 |  |  | $ | 40,383 |  |  | $ | 42,593 |  |

[0000858877-20-000010:notes:408]
(1) In the fourth quarter of fiscal 2019, we recorded an $872 million charge which was the reversal of the previously recorded benefit associated with the U.S. taxation of deemed foreign dividends recorded in fiscal 2018 as a result of a retroactive final U.S. Treasury regulation issued during the quarter.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000858877-20-000010:notes:409]
SCHEDULE II

[0000858877-20-000010:notes:410]
VALUATION AND QUALIFYING ACCOUNTS

[0000858877-20-000010:notes:411]
(in millions)

[0000858877-20-000010:notes:412]
|  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Allowance for Doubtful Accounts: |  |  |  |  |  |
| Balance at beginning of fiscal year | $ | 136 |  |  | $ | 129 |  |  | $ | 211 |  |
| Provisions (benefits) | 55 |  |  | 56 |  |  | (45 | ) |
| Recoveries (write-offs), net | (48 | ) |  | (50 | ) |  | (37 | ) |
| Foreign exchange and other | — |  |  | 1 |  |  | — |  |
| Balance at end of fiscal year | $ | 143 |  |  | $ | 136 |  |  | $ | 129 |  |
| Allowance for Financing Receivables: |  |  |  |  |  |
| Balance at beginning of fiscal year | $ | 126 |  |  | $ | 205 |  |  | $ | 295 |  |
| Provisions (benefits) | 38 |  |  | (16 | ) |  | (89 | ) |
| Recoveries (write-offs), net | (22 | ) |  | (42 | ) |  | (6 | ) |
| Foreign exchange and other | (4 | ) |  | (21 | ) |  | 5 |  |
| Balance at end of fiscal year | $ | 138 |  |  | $ | 126 |  |  | $ | 205 |  |
| Deferred Tax Asset Valuation Allowance: |  |  |  |  |  |
| Balance at beginning of fiscal year | $ | 457 |  |  | $ | 374 |  |  | $ | 244 |  |
| Additions | 279 |  |  | 112 |  |  | 163 |  |
| Deductions | (29 | ) |  | (20 | ) |  | (7 | ) |
| Write-offs | (7 | ) |  | (8 | ) |  | (26 | ) |
| Foreign exchange and other | — |  |  | (1 | ) |  | — |  |
| Balance at end of fiscal year | $ | 700 |  |  | $ | 457 |  |  | $ | 374 |  |
