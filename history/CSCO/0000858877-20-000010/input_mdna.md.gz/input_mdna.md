# CSCO MD&A — 0000858877-20-000010


## mdna

[0000858877-20-000010:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000858877-20-000010:mdna:2]
Forward-Looking Statements

[0000858877-20-000010:mdna:3]
OVERVIEW

[0000858877-20-000010:mdna:4]
Cisco designs and sells a broad range of technologies that have been powering the Internet since 1984. We are integrating intent-based technologies across networking, security, collaboration, applications and the cloud. These technologies are designed to help our customers manage more users, devices and things connecting to their networks. This will enable us to provide customers with a highly secure, intelligent platform for their digital business.

[0000858877-20-000010:mdna:5]
A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-20-000010:mdna:6]
|  | Three Months Ended |  | Years Ended |  |
|  | July 25, 2020 |  | July 27, 2019 |  | Variance |  | July 25, 2020 |  | July 27, 2019 |  | Variance |  |
| Revenue (1) | $ | 12,154 |  |  | $ | 13,428 |  |  | (9 | )% |  | $ | 49,301 |  |  | $ | 51,904 |  |  | (5 | )% |  |
| Gross margin percentage | 63.2 | % |  | 63.9 | % |  | (0.7 | ) | pts | 64.3 | % |  | 62.9 | % |  | 1.4 |  | pts |
| Research and development | $ | 1,565 |  |  | $ | 1,753 |  |  | (11 | )% |  | $ | 6,347 |  |  | $ | 6,577 |  |  | (3 | )% |  |
| Sales and marketing | $ | 2,218 |  |  | $ | 2,487 |  |  | (11 | )% |  | $ | 9,169 |  |  | $ | 9,571 |  |  | (4 | )% |  |
| General and administrative | $ | 494 |  |  | $ | 566 |  |  | (13 | )% |  | $ | 1,925 |  |  | $ | 1,827 |  |  | 5 | % |  |
| Total R&D, sales and marketing, general and administrative | $ | 4,277 |  |  | $ | 4,806 |  |  | (11 | )% |  | $ | 17,441 |  |  | $ | 17,975 |  |  | (3 | )% |  |
| Total as a percentage of revenue | 35.2 | % |  | 35.8 | % |  | (0.6 | ) | pts | 35.4 | % |  | 34.6 | % |  | 0.8 |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 33 |  |  | $ | 38 |  |  | (13 | )% |  | $ | 141 |  |  | $ | 150 |  |  | (6 | )% |  |
| Restructuring and other charges included in operating expenses | $ | 127 |  |  | $ | 40 |  |  | 218 | % |  | $ | 481 |  |  | $ | 322 |  |  | 49 | % |  |
| Operating income as a percentage of revenue | 26.7 | % |  | 27.5 | % |  | (0.8 | ) | pts | 27.6 | % |  | 27.4 | % |  | 0.2 |  | pts |
| Interest and other income (loss), net | $ | 59 |  |  | $ | 14 |  |  | 321 | % |  | $ | 350 |  |  | $ | 352 |  |  | (1 | )% |  |
| Income tax percentage (2) | 20.3 | % |  | 40.4 | % |  | (20.1 | ) | pts | 19.7 | % |  | 20.2 | % |  | (0.5 | ) | pts |
| Net income (2) | $ | 2,636 |  |  | $ | 2,206 |  |  | 19 | % |  | $ | 11,214 |  |  | $ | 11,621 |  |  | (4 | )% |  |
| Net income as a percentage of revenue | 21.7 | % |  | 16.4 | % |  | 5.3 |  | pts | 22.7 | % |  | 22.4 | % |  | 0.3 |  | pts |
| Earnings per share—diluted (2) | $ | 0.62 |  |  | $ | 0.51 |  |  | 22 | % |  | $ | 2.64 |  |  | $ | 2.61 |  |  | 1 | % |  |

[0000858877-20-000010:mdna:7]
(1) During the second quarter of fiscal 2019, we completed the sale of our SPVSS business. As a result, revenue from this business will not recur in future periods. Includes SPVSS business revenue of $168 million for fiscal 2019.

[0000858877-20-000010:mdna:8]
(2) Includes a $0.9 billion charge for the fourth quarter of fiscal 2019 and fiscal 2019 related to the Tax Act.

[0000858877-20-000010:mdna:9]
33

[0000858877-20-000010:mdna:10]
Fiscal 2020 Compared with Fiscal 2019

[0000858877-20-000010:mdna:11]
In fiscal 2020, we delivered growth in margins and earnings per share in a very challenging environment with the COVID-19 pandemic. Total revenue decreased by 5% compared with fiscal 2019. Our product revenue declined in Infrastructure Platforms and Applications, partially offset by growth in Security, and we continued to make progress in the transition of our business model to increased software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment. We saw broad-based weakening in the global macroeconomic environment during the fiscal year which impacted our commercial and enterprise markets. We also experienced continuing weakness in the service provider market and emerging countries, and we expect ongoing uncertainty in these markets. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-20-000010:mdna:12]
Within total revenue, product revenue decreased 8% and service revenue increased by 3%. Total gross margin increased by 1.4 percentage points, driven primarily by productivity benefits and product mix partially offset by unfavorable impacts from pricing. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 0.8 percentage points. Operating income as a percentage of revenue increased by 0.2 percentage points. Diluted earnings per share increased by 1%, driven by a decrease in diluted share count of 199 million shares, partially offset by a decrease in net income of 4%.

[0000858877-20-000010:mdna:13]
In terms of our geographic segments, revenue from the Americas decreased by $1.6 billion, driven in large part by a product revenue decline in the United States. EMEA revenue decreased by $0.4 billion and revenue in our APJC segment decreased by $0.5 billion. The “BRICM” countries experienced a product revenue decline of 25% in the aggregate, driven by decreased product revenue in the emerging countries of India, China, Mexico and Brazil.

[0000858877-20-000010:mdna:14]
From a customer market standpoint, we experienced product revenue declines across all customer segments, with the most significant declines in the commercial and service provider markets. During fiscal 2020, we saw a decline in business momentum in the commercial and enterprise markets, which we believe was significantly related to weakness in the global macroeconomic environment.

[0000858877-20-000010:mdna:15]
From a product category perspective, total product revenue decreased 8% year over year. The decrease was driven by declines in revenue in Infrastructure Platforms and Applications of 10% and 4%, respectively.  These declines were partially offset by a product revenue increase in Security of 12%.

[0000858877-20-000010:mdna:16]
Fourth Quarter Snapshot

[0000858877-20-000010:mdna:17]
For the fourth quarter of fiscal 2020, as compared with the fourth quarter of fiscal 2019, total revenue decreased by 9%. Within total revenue, product revenue decreased by 13% and service revenue was flat. With regard to our geographic segment performance, on a year-over-year basis, revenue in the Americas, EMEA and APJC decreased by 12%, 6% and 7% respectively. From a product category perspective, we experienced product revenue declines in Infrastructure Platforms and Applications, offset by growth in Security. Total gross margin decreased by 0.7 percentage points, driven by unfavorable pricing partially offset by favorable product mix. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively decreased by 0.6 percentage points. Operating income as a percentage of revenue decreased by 0.8 percentage points. Diluted earnings per share increased by 22% and net income increased by 19%. The fourth quarter of fiscal 2019 included a $0.9 billion tax charge related to the Tax Act.

[0000858877-20-000010:mdna:18]
COVID-19 Pandemic Response Summary

[0000858877-20-000010:mdna:19]
During this extraordinary time, our priority has been supporting our employees, customers, partners and communities, while positioning Cisco for the future. The pandemic has driven organizations across the globe to digitize their operations and support remote workforces at a faster speed and greater scale than ever before. We remain focused on providing the technology and solutions our customers need to accelerate their digital organizations. The actions we are taking include:

[0000858877-20-000010:mdna:20]
Employees

[0000858877-20-000010:mdna:21]
| • | Most of our global workforce working from home. |

[0000858877-20-000010:mdna:22]
| • | Seamless transition to work from home with a long-standing flexible work policy, and we build the technologies that allow organizations to stay connected, secure and productive. |

[0000858877-20-000010:mdna:23]
| • | For the remainder who must be in the office to perform their roles, we are focused on their health and safety, and are taking all of the necessary precautions. |

[0000858877-20-000010:mdna:24]
Customer and Partners

[0000858877-20-000010:mdna:25]
| • | Introduced a variety of free offers and trials for our Webex and security technologies as they dramatically shifted entire workforces to be remote. |

[0000858877-20-000010:mdna:26]
| • | Announced a Cisco Capital Business Resiliency Program leveraging currently available funds to provide organizations with access to financing solutions to offer financial flexibility and support business continuity. This will help customers and partners access the technology they need now, invest for recovery, and defer most of the payments until early 2021. |

[0000858877-20-000010:mdna:27]
Communities

[0000858877-20-000010:mdna:28]
| • | Committed significant funds to support both global and local pandemic response efforts. |

[0000858877-20-000010:mdna:29]
| • | Providing technology and financial support for non-profits, first responders, and governments. |

[0000858877-20-000010:mdna:30]
| • | Donating personal protective equipment to hospital workers including N95 masks and face shields 3D-printed by Cisco volunteers around the world. |

[0000858877-20-000010:mdna:31]
Strategy and Priorities

[0000858877-20-000010:mdna:32]
As our customers add billions of new connections to their enterprises, and as more applications move to a multicloud environment, the network becomes even more critical. Our customers are navigating change at an unprecedented pace and our mission is to inspire new possibilities for them by helping transform their infrastructure, expand applications and analytics, address their security needs, and empower their teams. We believe that our customers are looking for intent-based networks that provide meaningful business value through automation, security, and analytics across private, hybrid, and multicloud environments. Our vision is to deliver highly secure, software-defined, automated and intelligent platforms for our customers.

[0000858877-20-000010:mdna:33]
For a full discussion of our strategy and priorities, see “Item 1. Business.”

[0000858877-20-000010:mdna:34]
Other Key Financial Measures

[0000858877-20-000010:mdna:35]
The following is a summary of our other key financial measures for fiscal 2020 compared with fiscal 2019 (in millions):

[0000858877-20-000010:mdna:36]
|  |  | Fiscal 2020 |  | Fiscal 2019 |
| Cash and cash equivalents and investments |  | $29,419 |  | $33,413 |
| Cash provided by operating activities |  | $15,426 |  | $15,831 |
| Deferred revenue |  | $20,446 |  | $18,467 |
| Repurchases of common stock—stock repurchase program |  | $2,619 |  | $20,577 |
| Dividends |  | $6,016 |  | $5,979 |
| Inventories |  | $1,282 |  | $1,383 |

[0000858877-20-000010:mdna:37]
CRITICAL ACCOUNTING ESTIMATES

[0000858877-20-000010:mdna:38]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-20-000010:mdna:39]
The inputs into certain of our judgments, assumptions and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The COVID-19 pandemic did not have a material impact on our significant judgments, assumptions and estimates that are reflected in our results for fiscal 2020. These estimates include: goodwill and identified purchased intangible assets and income taxes, among other items. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues to develop, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-20-000010:mdna:40]
Revenue Recognition

[0000858877-20-000010:mdna:41]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis.

[0000858877-20-000010:mdna:42]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-20-000010:mdna:43]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-20-000010:mdna:44]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable. If actual credits received by distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-20-000010:mdna:45]
See Note 3 to the Consolidated Financial Statements for more details.

[0000858877-20-000010:mdna:46]
Loss Contingencies

[0000858877-20-000010:mdna:47]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-20-000010:mdna:48]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-20-000010:mdna:49]
Goodwill and Purchased Intangible Asset Impairments

[0000858877-20-000010:mdna:50]
Our methodology for allocating the purchase price relating to purchase acquisitions is determined through established valuation techniques. Goodwill represents a residual value as of the acquisition date, which in most cases results in measuring goodwill as an excess of the purchase consideration transferred plus the fair value of any noncontrolling interest in the acquired company over the fair value of net assets acquired, including contingent consideration. We perform goodwill impairment tests on an annual basis in the fourth fiscal quarter and between annual tests in certain circumstances for each reporting unit. The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the new accounting guidance for the fair value measurement of nonfinancial assets.

[0000858877-20-000010:mdna:51]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in fiscal 2020, 2019, and 2018. For the annual impairment testing in fiscal 2020, the excess of the fair value over the carrying value for each of our reporting units was $72.8 billion for the Americas, $51.6 billion for EMEA, and $31.3 billion for APJC.

[0000858877-20-000010:mdna:52]
During the fourth quarter of fiscal 2020, we performed a sensitivity analysis for goodwill impairment with respect to each of our respective reporting units and determined that a hypothetical 10% decline in the fair value of each reporting unit would not result in an impairment of goodwill for any reporting unit.

[0000858877-20-000010:mdna:53]
The fair value of acquired technology and patents, as well as acquired technology under development, is determined at acquisition date primarily using the income approach, which discounts expected future cash flows to present value. The discount rates used in the present value calculations are typically derived from a weighted-average cost of capital analysis and then adjusted to reflect risks inherent in the development lifecycle as appropriate. We consider the pricing model for products related to these acquisitions to be standard within the high-technology communications industry, and the applicable discount rates represent the rates that market participants would use for valuation of such intangible assets.

[0000858877-20-000010:mdna:54]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. Our ongoing consideration of all the factors described previously could result in impairment charges in the future, which could adversely affect our net income.

[0000858877-20-000010:mdna:55]
Income Taxes

[0000858877-20-000010:mdna:56]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 19.7%, 20.2%, and 99.2% in fiscal 2020, 2019, and 2018, respectively.

[0000858877-20-000010:mdna:57]
During fiscal 2018 and fiscal 2019, we recorded a total tax charge of $11.3 billion, consisting of $9 billion of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries, $1.2 billion of foreign withholding tax, and $1.1 billion of tax expense for DTA re-measurement as a result of the Tax Act.

[0000858877-20-000010:mdna:58]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.

[0000858877-20-000010:mdna:59]
Significant judgment is also required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000858877-20-000010:mdna:60]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to domestic manufacturing deduction, foreign-derived intangible income deduction, global intangible low-tax income and base erosion and anti-abuse tax laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 37 countries, including the United States, has made changes to numerous long-standing tax principles. There can be no assurance that these changes, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries was subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-20-000010:mdna:61]
38

[0000858877-20-000010:mdna:62]
RESULTS OF OPERATIONS

[0000858877-20-000010:mdna:63]
A discussion regarding our financial condition and results of operations for fiscal 2020 compared to fiscal 2019 is presented below. A discussion regarding our financial condition and results of operations for fiscal 2019 compared to fiscal 2018 can be found under Item 7 in our Annual Report on Form 10-K for the fiscal year ended July 27, 2019, filed with the SEC on September 5, 2019, which is available free of charge on the SEC’s website at www.sec.gov and our Investor Relations website at investor.cisco.com.

[0000858877-20-000010:mdna:64]
Revenue

[0000858877-20-000010:mdna:65]
The following table presents the breakdown of revenue between product and service (in millions, except percentages):

[0000858877-20-000010:mdna:66]
|  |  | Years Ended |  | 2020 vs. 2019 |
|  |  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |  | Variance in Dollars |  | Variance in Percent (1) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 35,978 |  |  | $ | 39,005 |  |  | $ | 36,709 |  |  | $ | (3,027 | ) |  | (8 | )% |
| Percentage of revenue |  | 73.0 | % |  | 75.1 | % |  | 74.4 | % |  |  |  |  |  |  |
| Service |  | 13,323 |  |  | 12,899 |  |  | 12,621 |  |  | 424 |  |  | 3 | % |
| Percentage of revenue |  | 27.0 | % |  | 24.9 | % |  | 25.6 | % |  |  |  |  |  |  |
| Total |  | $ | 49,301 |  |  | $ | 51,904 |  |  | $ | 49,330 |  |  | $ | (2,603 | ) |  | (5 | )% |

[0000858877-20-000010:mdna:67]
(1) Total revenue and product revenue not including the SPVSS business in the prior year decreased 5% and 7%, respectively. Service revenue not including the SPVSS business in the prior year increased 3%.

[0000858877-20-000010:mdna:68]
We manage our business primarily on a geographic basis, organized into three geographic segments. Our revenue, which includes product and service for each segment, is summarized in the following table (in millions, except percentages):

[0000858877-20-000010:mdna:69]
|  |  | Years Ended |  | 2020 vs. 2019 |
|  |  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 29,291 |  |  | $ | 30,927 |  |  | $ | 29,070 |  |  | $ | (1,636 | ) |  | (5 | )% |
| Percentage of revenue |  | 59.4 | % |  | 59.6 | % |  | 58.9 | % |  |  |  |  |
| EMEA |  | 12,659 |  |  | 13,100 |  |  | 12,425 |  |  | (441 | ) |  | (3 | )% |
| Percentage of revenue |  | 25.7 | % |  | 25.2 | % |  | 25.2 | % |  |  |  |  |
| APJC |  | 7,352 |  |  | 7,877 |  |  | 7,834 |  |  | (525 | ) |  | (7 | )% |
| Percentage of revenue |  | 14.9 | % |  | 15.2 | % |  | 15.9 | % |  |  |  |  |
| Total |  | $ | 49,301 |  |  | $ | 51,904 |  |  | $ | 49,330 |  |  | $ | (2,603 | ) |  | (5 | )% |

[0000858877-20-000010:mdna:70]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-20-000010:mdna:71]
Total revenue in fiscal 2020 decreased by 5% compared with fiscal 2019. Product revenue decreased by 8% and service revenue increased by 3%. Our total revenue reflected declines across each of our geographic segments. Product revenue for the emerging countries of BRICM, in the aggregate, experienced a 25% product revenue decline, with decreases in India, China, Mexico and Brazil.

[0000858877-20-000010:mdna:72]
In addition to the impact of macroeconomic factors, including a reduced IT spending environment and reductions in spending by government entities, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple performance obligations; the mix of financing arrangements provided to channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment.

[0000858877-20-000010:mdna:73]
Product Revenue by Segment

[0000858877-20-000010:mdna:74]
The following table presents the breakdown of product revenue by segment (in millions, except percentages):

[0000858877-20-000010:mdna:75]
|  |  | Years Ended |  | 2020 vs. 2019 |
|  |  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 21,006 |  |  | $ | 22,754 |  |  | $ | 21,088 |  |  | $ | (1,748 | ) |  | (8 | )% |
| Percentage of product revenue |  | 58.4 | % |  | 58.3 | % |  | 57.5 | % |  |  |  |  |
| EMEA |  | 9,647 |  |  | 10,246 |  |  | 9,671 |  |  | (599 | ) |  | (6 | )% |
| Percentage of product revenue |  | 26.8 | % |  | 26.3 | % |  | 26.3 | % |  |  |  |  |
| APJC |  | 5,326 |  |  | 6,005 |  |  | 5,950 |  |  | (679 | ) |  | (11 | )% |
| Percentage of product revenue |  | 14.8 | % |  | 15.4 | % |  | 16.2 | % |  |  |  |  |
| Total |  | $ | 35,978 |  |  | $ | 39,005 |  |  | $ | 36,709 |  |  | $ | (3,027 | ) |  | (8 | )% |

[0000858877-20-000010:mdna:76]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-20-000010:mdna:77]
Americas

[0000858877-20-000010:mdna:78]
Product revenue in the Americas segment decreased by 8%. The product revenue decrease was across all of our customer segments. From a country perspective, product revenue decreased by 7% in the United States, 13% in Canada, 27% in Mexico and 14% in Brazil.

[0000858877-20-000010:mdna:79]
EMEA

[0000858877-20-000010:mdna:80]
The decrease in product revenue in the EMEA segment of 6% was driven by declines in the service provider, commercial and enterprise markets, partially offset by growth in the public sector market. Product revenue from emerging countries within EMEA decreased by 4%, and product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, decreased by 6%. From a country perspective, product revenue decreased in the United Kingdom and France by 12% and 7%, respectively, partially offset by a product revenue increase of 2% in Germany.

[0000858877-20-000010:mdna:81]
APJC

[0000858877-20-000010:mdna:82]
Product revenue in the APJC segment decreased by 11%, driven by declines across all of our customer segments. From a country perspective, product revenue decreased in Australia, India and China by 16%, 29% and 34%, respectively, partially offset by a product revenue increase of 8% in Japan.

[0000858877-20-000010:mdna:83]
40

[0000858877-20-000010:mdna:84]
Product Revenue by Groups of Similar Products

[0000858877-20-000010:mdna:85]
In addition to the primary view on a geographic basis, we also prepare financial information related to groups of similar products and customer markets for various purposes. We report our product revenue in the following categories: Infrastructure Platforms, Applications, Security, and Other Products. This aligns our product categories with our evolving business model. Prior period amounts have been reclassified to conform to the current period’s presentation.

[0000858877-20-000010:mdna:86]
The following table presents revenue for groups of similar products (in millions, except percentages):

[0000858877-20-000010:mdna:87]
|  |  | Years Ended |  | 2020 vs. 2019 |
|  |  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 27,122 |  |  | $ | 30,099 |  |  | $ | 28,286 |  |  | $ | (2,977 | ) |  | (10 | )% |
| Applications |  | 5,568 |  |  | 5,803 |  |  | 5,036 |  |  | (235 | ) |  | (4 | )% |
| Security |  | 3,154 |  |  | 2,821 |  |  | 2,388 |  |  | 333 |  |  | 12 | % |
| Other Products |  | 135 |  |  | 281 |  |  | 999 |  |  | (146 | ) |  | (52 | )% |
| Total |  | $ | 35,978 |  |  | $ | 39,005 |  |  | $ | 36,709 |  |  | $ | (3,027 | ) |  | (8 | )% |

[0000858877-20-000010:mdna:88]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-20-000010:mdna:89]
Infrastructure Platforms

[0000858877-20-000010:mdna:90]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center. Infrastructure Platforms revenue decreased by 10%, or $3.0 billion. This was the product area most impacted by the COVID-19 pandemic environment in the second half of fiscal 2020. Switching revenue declined in both campus switching and data center switching, although we had revenue growth in our intent-based networking Catalyst 9000 Series. We experienced a decrease in sales of routing products, with declines primarily in the service provider and enterprise markets. Revenue from wireless products declined, although we saw revenue growth in our Meraki and WiFi6 products. Revenue from data center declined driven by continued market contraction impacting primarily our servers products.

[0000858877-20-000010:mdna:91]
Applications

[0000858877-20-000010:mdna:92]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as IoT and AppDynamics analytics software offerings. Revenue in our Applications product category decreased by 4%, or $235 million, with a decline in Unified Communications and Cisco TelePresence partially offset by double digit growth in AppDynamics and growth in IoT software offerings and Webex.

[0000858877-20-000010:mdna:93]
Security

[0000858877-20-000010:mdna:94]
Revenue in our Security product category increased 12%, or $333 million, driven by higher sales of identity and access, advanced threat security, unified threat management and web security products. Revenue from our cloud security portfolio reflected strong double-digit growth and continued momentum with our Duo and Umbrella offerings.

[0000858877-20-000010:mdna:95]
Other Products

[0000858877-20-000010:mdna:96]
The decrease in revenue from our Other Products category was primarily driven by a decrease in revenue from the SPVSS business which we divested in the second quarter of fiscal 2019.

[0000858877-20-000010:mdna:97]
Service Revenue by Segment

[0000858877-20-000010:mdna:98]
The following table presents the breakdown of service revenue by segment (in millions, except percentages):

[0000858877-20-000010:mdna:99]
|  | Years Ended |  | 2020 vs. 2019 |
| Years Ended | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |  | Variance in Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 8,285 |  |  | $ | 8,173 |  |  | $ | 7,982 |  |  | $ | 112 |  |  | 1 | % |
| Percentage of service revenue | 62.2 | % |  | 63.4 | % |  | 63.3 | % |  |  |  |  |
| EMEA | 3,012 |  |  | 2,854 |  |  | 2,754 |  |  | 158 |  |  | 6 | % |
| Percentage of service revenue | 22.6 | % |  | 22.1 | % |  | 21.8 | % |  |  |  |  |
| APJC | 2,026 |  |  | 1,872 |  |  | 1,885 |  |  | 154 |  |  | 8 | % |
| Percentage of service revenue | 15.2 | % |  | 14.5 | % |  | 14.9 | % |  |  |  |  |
| Total | $ | 13,323 |  |  | $ | 12,899 |  |  | $ | 12,621 |  |  | $ | 424 |  |  | 3 | % |

[0000858877-20-000010:mdna:100]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-20-000010:mdna:101]
Service revenue increased 3%, driven by an increase in software and solution support offerings. Service revenue increased in all geographic segments.

[0000858877-20-000010:mdna:102]
Gross Margin

[0000858877-20-000010:mdna:103]
The following table presents the gross margin for products and services (in millions, except percentages):

[0000858877-20-000010:mdna:104]
|  | AMOUNT |  | PERCENTAGE |
| Years Ended | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 22,779 |  |  | $ | 24,142 |  |  | $ | 22,282 |  |  | 63.3 | % |  | 61.9 | % |  | 60.7 | % |
| Service | 8,904 |  |  | 8,524 |  |  | 8,324 |  |  | 66.8 | % |  | 66.1 | % |  | 66.0 | % |
| Total | $ | 31,683 |  |  | $ | 32,666 |  |  | $ | 30,606 |  |  | 64.3 | % |  | 62.9 | % |  | 62.0 | % |

[0000858877-20-000010:mdna:105]
Product Gross Margin

[0000858877-20-000010:mdna:106]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2019 to fiscal 2020:

[0000858877-20-000010:mdna:107]
|  |  | Product Gross Margin Percentage |
| Fiscal 2019 |  | 61.9 | % |
| Productivity (1) |  | 1.9 | % |
| Product pricing |  | (1.3 | )% |
| Mix of products sold |  | 0.9 | % |
| Impact from divestiture of SPVSS business |  | 0.1 | % |
| Others |  | (0.2 | )% |
| Fiscal 2020 |  | 63.3 | % |

[0000858877-20-000010:mdna:108]
(1) Productivity includes overall manufacturing-related costs, such as component costs, warranty expense, provision for inventory, freight, logistics, shipment volume, and other items not categorized elsewhere.

[0000858877-20-000010:mdna:109]
Product gross margin increased by 1.4 percentage points driven by productivity improvements and favorable product mix, partially offset by unfavorable impacts from product pricing. In the second half of fiscal 2020 as a result of the COVID-19 pandemic, we incurred additional logistics costs, such as freight which had a negative impact on product gross margin. Our product gross margin benefited slightly from the sale of our lower margin SPVSS business during the second quarter of fiscal 2019.

[0000858877-20-000010:mdna:110]
Productivity improvements were driven by memory cost savings and other cost reductions including value engineering efforts (e.g. component redesign, board configuration, test processes and transformation processes) and continued operational efficiency

[0000858877-20-000010:mdna:111]
42

[0000858877-20-000010:mdna:112]
in manufacturing operations. The negative pricing impact, which was higher than the year-over-year impact we experienced in fiscal 2019, was driven by typical market factors and impacted each of our geographic segments. The favorable product mix impact was driven by impacts from each of our product categories.

[0000858877-20-000010:mdna:113]
Service Gross Margin

[0000858877-20-000010:mdna:114]
Our service gross margin percentage increased by 0.7 percentage point primarily due to higher sales volume.

[0000858877-20-000010:mdna:115]
Our service gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-20-000010:mdna:116]
Gross Margin by Segment

[0000858877-20-000010:mdna:117]
The following table presents the total gross margin for each segment (in millions, except percentages):

[0000858877-20-000010:mdna:118]
|  |  | AMOUNT |  | PERCENTAGE |
| Years Ended |  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 19,547 |  |  | $ | 20,338 |  |  | $ | 18,792 |  |  | 66.7 | % |  | 65.8 | % |  | 64.6 | % |
| EMEA |  | 8,304 |  |  | 8,457 |  |  | 7,945 |  |  | 65.6 | % |  | 64.6 | % |  | 63.9 | % |
| APJC |  | 4,688 |  |  | 4,683 |  |  | 4,726 |  |  | 63.8 | % |  | 59.5 | % |  | 60.3 | % |
| Segment total |  | 32,538 |  |  | 33,479 |  |  | 31,463 |  |  | 66.0 | % |  | 64.5 | % |  | 63.8 | % |
| Unallocated corporate items (1) |  | (855 | ) |  | (813 | ) |  | (857 | ) |  |  |  |  |  |  |
| Total |  | $ | 31,683 |  |  | $ | 32,666 |  |  | $ | 30,606 |  |  | 64.3 | % |  | 62.9 | % |  | 62.0 | % |

[0000858877-20-000010:mdna:119]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-20-000010:mdna:120]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-20-000010:mdna:121]
We experienced a gross margin percentage increase in our Americas segment due to productivity improvements and favorable product mix, partially offset by unfavorable impacts from pricing.

[0000858877-20-000010:mdna:122]
Product gross margin in our EMEA segment increased due to productivity improvements and, to a lesser extent, favorable product mix, partially offset by negative impacts from pricing.

[0000858877-20-000010:mdna:123]
The APJC segment gross margin percentage increase was due to productivity improvements and favorable product mix, partially offset by negative impacts from pricing. Higher service gross margin also contributed to the increase in the gross margin in this geographic segment.

[0000858877-20-000010:mdna:124]
The gross margin percentage for a particular segment may fluctuate, and period-to-period changes in such percentages may or may not be indicative of a trend for that segment.

[0000858877-20-000010:mdna:125]
Research and Development (“R&D”), Sales and Marketing, and General and Administrative (“G&A”) Expenses

[0000858877-20-000010:mdna:126]
R&D, sales and marketing, and G&A expenses are summarized in the following table (in millions, except percentages):

[0000858877-20-000010:mdna:127]
|  |  | Years Ended |  | 2020 vs. 2019 |
|  |  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |  | Variance in Dollars |  | Variance in Percent |
| Research and development |  | $ | 6,347 |  |  | $ | 6,577 |  |  | $ | 6,332 |  |  | $ | (230 | ) |  | (3 | )% |
| Percentage of revenue |  | 12.9 | % |  | 12.7 | % |  | 12.8 | % |  |  |  |  |
| Sales and marketing |  | 9,169 |  |  | 9,571 |  |  | 9,242 |  |  | (402 | ) |  | (4 | )% |
| Percentage of revenue |  | 18.6 | % |  | 18.4 | % |  | 18.7 | % |  |  |  |  |
| General and administrative |  | 1,925 |  |  | 1,827 |  |  | 2,144 |  |  | 98 |  |  | 5 | % |
| Percentage of revenue |  | 3.9 | % |  | 3.5 | % |  | 4.3 | % |  |  |  |  |
| Total |  | $ | 17,441 |  |  | $ | 17,975 |  |  | $ | 17,718 |  |  | $ | (534 | ) |  | (3 | )% |
| Percentage of revenue |  | 35.4 | % |  | 34.6 | % |  | 35.9 | % |  |  |  |  |

[0000858877-20-000010:mdna:128]
R&D Expenses

[0000858877-20-000010:mdna:129]
R&D expenses decreased due to lower headcount-related expenses, lower discretionary spending and lower contracted services spending, partially offset by higher share-based compensation expense.

[0000858877-20-000010:mdna:130]
We continue to invest in R&D in order to bring a broad range of products to market in a timely fashion. If we believe that we are unable to enter a particular market in a timely manner with internally developed products, we may purchase or license technology from other businesses, or we may partner with or acquire businesses as an alternative to internal R&D.

[0000858877-20-000010:mdna:131]
Sales and Marketing Expenses

[0000858877-20-000010:mdna:132]
Sales and marketing expenses decreased primarily due to lower discretionary spending and contracted services spending.

[0000858877-20-000010:mdna:133]
G&A Expenses

[0000858877-20-000010:mdna:134]
G&A expenses increased due to the benefit from the $400 million litigation settlement with Arista Networks, Inc. (“Arista”) in fiscal 2019 and higher discretionary spending, partially offset by gains recognized on the sale of property that had been held for sale, lower headcount-related expenses, lower contracted services spending, and lower share-based compensation expense.

[0000858877-20-000010:mdna:135]
Effect of Foreign Currency

[0000858877-20-000010:mdna:136]
In fiscal 2020, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $141 million, or 0.8%, compared with fiscal 2019.

[0000858877-20-000010:mdna:137]
Amortization of Purchased Intangible Assets

[0000858877-20-000010:mdna:138]
The following table presents the amortization of purchased intangible assets (in millions):

[0000858877-20-000010:mdna:139]
| Years Ended |  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 659 |  |  | $ | 624 |  |  | $ | 640 |  |
| Operating expenses |  | 141 |  |  | 150 |  |  | 221 |  |
| Total |  | $ | 800 |  |  | $ | 774 |  |  | $ | 861 |  |

[0000858877-20-000010:mdna:140]
The increase in amortization of purchased intangible assets was due largely to the amortization of purchased intangibles from our recent acquisitions.

[0000858877-20-000010:mdna:141]
Restructuring and Other Charges

[0000858877-20-000010:mdna:142]
In the first quarter of fiscal 2021, we initiated a restructuring plan, which includes a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $900 million. We expect the plan to be substantially completed in fiscal 2021 and estimate it will generate cost savings of approximately $1.0 billion on an annualized basis over the next few quarters.

[0000858877-20-000010:mdna:143]
The following table presents restructuring and other charges (in millions):

[0000858877-20-000010:mdna:144]
| Years Ended |  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Restructuring and other charges included in operating expenses |  | $ | 481 |  |  | $ | 322 |  |  | $ | 358 |  |

[0000858877-20-000010:mdna:145]
We initiated a restructuring plan during fiscal 2020 in order to realign the organization and enable further investment in key priority areas, with estimated pretax charges of approximately $300 million. In connection with this restructuring plan, we incurred charges of $255 million during fiscal 2020. We expect this restructuring plan to be substantially completed in fiscal 2021.

[0000858877-20-000010:mdna:146]
We incurred total restructuring and other charges of $481 million in fiscal 2020. We incurred charges of $255 million related to the restructuring plan initiated during fiscal 2020 and the remainder of which was related to the restructuring plan announced during fiscal 2018.

[0000858877-20-000010:mdna:147]
These charges were primarily cash-based and consisted of employee severance and other one-time termination benefits, and other costs. We expect to reinvest substantially all of the cost savings from these restructuring actions in our key priority areas. As a result, the overall cost savings from these restructuring actions are not expected to be material for future periods.

[0000858877-20-000010:mdna:148]
Operating Income

[0000858877-20-000010:mdna:149]
The following table presents our operating income and our operating income as a percentage of revenue (in millions, except percentages):

[0000858877-20-000010:mdna:150]
| Years Ended |  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Operating income |  | $ | 13,620 |  |  | $ | 14,219 |  |  | $ | 12,309 |  |
| Operating income as a percentage of revenue |  | 27.6 | % |  | 27.4 | % |  | 25.0 | % |

[0000858877-20-000010:mdna:151]
Operating income decreased by 4%, and as a percentage of revenue operating income increased by 0.2 percentage points. These changes resulted primarily from: a revenue decrease, the impact of the benefit from the $400 million litigation settlement with Arista in the first quarter of fiscal 2019 and higher restructuring and other charges, partially offset by a gross margin percentage increase (driven by productivity improvements and product mix, partially offset by unfavorable impacts from pricing).

[0000858877-20-000010:mdna:152]
Interest and Other Income (Loss), Net

[0000858877-20-000010:mdna:153]
Interest Income (Expense), Net   The following table summarizes interest income and interest expense (in millions):

[0000858877-20-000010:mdna:154]
|  | Years Ended |  | 2020 vs. 2019 |
|  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |  | Variance in Dollars |
| Interest income | $ | 920 |  |  | $ | 1,308 |  |  | $ | 1,508 |  |  | $ | (388 | ) |
| Interest expense | (585 | ) |  | (859 | ) |  | (943 | ) |  | 274 |  |
| Interest income (expense), net | $ | 335 |  |  | $ | 449 |  |  | $ | 565 |  |  | $ | (114 | ) |

[0000858877-20-000010:mdna:155]
Interest income decreased driven by a lower average balance of cash and available-for-sale debt investments and lower interest rates. The decrease in interest expense was driven by a lower average debt balance and the impact of lower effective interest rates.

[0000858877-20-000010:mdna:156]
Other Income (Loss), Net   The components of other income (loss), net, are summarized as follows (in millions):

[0000858877-20-000010:mdna:157]
|  | Years Ended |  | 2020 vs. 2019 |
|  | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |
| Available-for-sale debt investments | $ | 42 |  |  | $ | (13 | ) |  | $ | (242 | ) |  | $ | 55 |  |
| Marketable equity investments | (5 | ) |  | (3 | ) |  | 529 |  |  | (2 | ) |
| Non-marketable equity and other investments | 95 |  |  | 6 |  |  | 11 |  |  | 89 |  |
| Net gains (losses) on investments | 132 |  |  | (10 | ) |  | 298 |  |  | 142 |  |
| Other gains (losses), net | (117 | ) |  | (87 | ) |  | (133 | ) |  | (30 | ) |
| Other income (loss), net | $ | 15 |  |  | $ | (97 | ) |  | $ | 165 |  |  | $ | 112 |  |

[0000858877-20-000010:mdna:158]
The total change in net gains (losses) on available-for-sale debt investments was primarily attributable to higher realized gains as a result of market conditions, and the timing of sales of these investments. The change in net gains (losses) on non-marketable equity and other investments was primarily due to higher realized gains and higher unrealized gains, partially offset by higher impairment charges. The change in other gains (losses), net was primarily driven by higher donation expense as related to COVID-19 programs, partially offset by net favorable foreign exchange impacts.

[0000858877-20-000010:mdna:159]
Provision for Income Taxes

[0000858877-20-000010:mdna:160]
The provision for income taxes resulted in an effective tax rate of 19.7% for fiscal 2020, compared with 20.2% for fiscal 2019. The net 0.5 percentage point decrease in the effective tax rate was primarily due to a decrease in net discrete tax charges.

[0000858877-20-000010:mdna:161]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 21% and for further explanation of our provision for income taxes, see Note 18 to the Consolidated Financial Statements.

[0000858877-20-000010:mdna:162]
46

[0000858877-20-000010:mdna:163]
LIQUIDITY AND CAPITAL RESOURCES

[0000858877-20-000010:mdna:164]
The following sections discuss the effects of changes in our balance sheet, our capital allocation strategy including stock repurchase program and dividends, our contractual obligations, and certain other commitments and activities on our liquidity and capital resources.

[0000858877-20-000010:mdna:165]
Balance Sheet and Cash Flows

[0000858877-20-000010:mdna:166]
Cash and Cash Equivalents and Investments  The following table summarizes our cash and cash equivalents and investments (in millions):

[0000858877-20-000010:mdna:167]
|  | July 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 11,809 |  |  | $ | 11,750 |  |  | $ | 59 |  |
| Available-for-sale debt investments | 17,610 |  |  | 21,660 |  |  | (4,050 | ) |
| Marketable equity securities | — |  |  | 3 |  |  | (3 | ) |
| Total | $ | 29,419 |  |  | $ | 33,413 |  |  | $ | (3,994 | ) |

[0000858877-20-000010:mdna:168]
The net decrease in cash and cash equivalents and investments from fiscal 2019 to fiscal 2020 was primarily driven by a net decrease in debt of $10.2 billion, cash returned to shareholders in the form of repurchases of common stock of $2.7 billion under the stock repurchase program and cash dividends of $6.0 billion, capital expenditures of $0.8 billion and net cash paid for acquisitions and divestitures of $0.3 billion. These uses of cash were partially offset by cash provided by operating activities of $15.4 billion.

[0000858877-20-000010:mdna:169]
In addition to cash requirements in the normal course of business, on July 9, 2019 we announced our intent to acquire Acacia Communications, Inc. for a net purchase consideration of approximately $2.6 billion in cash. Additionally, approximately $0.7 billion of the U.S. transition tax on accumulated earnings for foreign subsidiaries and $3.0 billion of long-term debt outstanding at July 25, 2020 will mature within the next 12 months from the balance sheet date. See further discussion of liquidity and future payments under “Contractual Obligations” and “Liquidity and Capital Resource Requirements” below.

[0000858877-20-000010:mdna:170]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our available-for-sale debt investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position is critical at this time of uncertainty due to the COVID-19 pandemic and allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-20-000010:mdna:171]
Securities Lending  We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented.

[0000858877-20-000010:mdna:172]
Free Cash Flow and Capital Allocation  As part of our capital allocation strategy, we intend to return a minimum of 50% of our free cash flow annually to our shareholders through cash dividends and repurchases of common stock.

[0000858877-20-000010:mdna:173]
We define free cash flow as net cash provided by operating activities less cash used to acquire property and equipment. The following table reconciles our net cash provided by operating activities to free cash flow (in millions):

[0000858877-20-000010:mdna:174]
| Years Ended | July 25, 2020 |  | July 27, 2019 |  | July 28, 2018 |
| Net cash provided by operating activities | $ | 15,426 |  |  | $ | 15,831 |  |  | $ | 13,666 |  |
| Acquisition of property and equipment | (770 | ) |  | (909 | ) |  | (834 | ) |
| Free cash flow | $ | 14,656 |  |  | $ | 14,922 |  |  | $ | 12,832 |  |

[0000858877-20-000010:mdna:175]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue and the timing and amount of tax and other payments. For additional discussion, see “Part I, Item 1A. Risk Factors” in this report.

[0000858877-20-000010:mdna:176]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases. We further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness. Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net cash provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-20-000010:mdna:177]
The following table summarizes the dividends paid and stock repurchases (in millions, except per-share amounts):

[0000858877-20-000010:mdna:178]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  | TOTAL |
| Years Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | Amount |
| July 25, 2020 |  | $ | 1.42 |  |  | $ | 6,016 |  |  | 59 |  |  | $ | 44.36 |  |  | $ | 2,619 |  |  | $ | 8,635 |  |
| July 27, 2019 |  | $ | 1.36 |  |  | $ | 5,979 |  |  | 418 |  |  | $ | 49.22 |  |  | $ | 20,577 |  |  | $ | 26,556 |  |
| July 28, 2018 |  | $ | 1.24 |  |  | $ | 5,968 |  |  | 432 |  |  | $ | 40.88 |  |  | $ | 17,661 |  |  | $ | 23,629 |  |

[0000858877-20-000010:mdna:179]
Any future dividends are subject to the approval of our Board of Directors.

[0000858877-20-000010:mdna:180]
The remaining authorized amount for stock repurchases under this program is approximately $10.8 billion, with no termination date.

[0000858877-20-000010:mdna:181]
Accounts Receivable, Net  The following table summarizes our accounts receivable, net (in millions):

[0000858877-20-000010:mdna:182]
|  | July 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,472 |  |  | $ | 5,491 |  |  | $ | (19 | ) |

[0000858877-20-000010:mdna:183]
Our accounts receivable net, as of July 25, 2020 was flat compared with the end of fiscal 2019.

[0000858877-20-000010:mdna:184]
Inventory Supply Chain  The following table summarizes our inventories and purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-20-000010:mdna:185]
|  | July 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Inventories | $ | 1,282 |  |  | $ | 1,383 |  |  | $ | (101 | ) |
| Purchase commitments with contract manufacturers and suppliers | $ | 4,406 |  |  | $ | 4,967 |  |  | $ | (561 | ) |

[0000858877-20-000010:mdna:186]
Inventory as of July 25, 2020 decreased by 7% from our inventory balance at the end of fiscal 2019, and for the same period purchase commitments with contract manufacturers and suppliers decreased by approximately 11%. On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers decreased by 10% compared with the end of fiscal 2019. The decrease in inventory was primarily due to a decrease in finished goods and lower deferred cost of sales, partially offset by an increase in raw materials.

[0000858877-20-000010:mdna:187]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity.

[0000858877-20-000010:mdna:188]
Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-20-000010:mdna:189]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of rapidly changing technology and customer requirements. We believe the amount of our inventory and purchase commitments is appropriate for our revenue levels.

[0000858877-20-000010:mdna:190]
Financing Receivables and Guarantees  The following table summarizes our financing receivables (in millions):

[0000858877-20-000010:mdna:191]
|  | July 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Lease receivables, net | $ | 2,088 |  |  | $ | 2,326 |  |  | $ | (238 | ) |
| Loan receivables, net | 5,856 |  |  | 5,367 |  |  | 489 |  |
| Financed service contracts, net | 2,821 |  |  | 2,360 |  |  | 461 |  |
| Total, net | $ | 10,765 |  |  | $ | 10,053 |  |  | $ | 712 |  |

[0000858877-20-000010:mdna:192]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services. The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed. Financing receivables increased by 7%.

[0000858877-20-000010:mdna:193]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements to customers provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, with payment terms generally ranging from 60 to 90 days. During fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic environment. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-20-000010:mdna:194]
The volume of channel partner financing was $26.9 billion, $29.6 billion, and $28.2 billion in fiscal 2020, 2019, and 2018, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.1 billion and $1.4 billion as of July 25, 2020 and July 27, 2019, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of July 25, 2020, the total maximum potential future payments related to these guarantees was approximately $207 million, of which approximately $28 million was recorded as deferred revenue.

[0000858877-20-000010:mdna:195]
COVID-19 Business Resiliency Program  At the end of the third quarter of fiscal 2020, we initiated a new Business Resiliency Program designed to help customers and channel partners mitigate financial challenges resulting from the COVID-19 pandemic. This program includes $2.5 billion in currently available funds to provide organizations with access to financing solutions. The new Business Resiliency Program offered by us includes an up-front 90-day payment holiday and allows a customer to defer 95 percent of the payments for a new product or solution until calendar 2021, which in turn protects their business and increases their existing cash flow.

[0000858877-20-000010:mdna:196]
49

[0000858877-20-000010:mdna:197]
Borrowings

[0000858877-20-000010:mdna:198]
Senior Notes  The following table summarizes the principal amount of our senior notes (in millions):

[0000858877-20-000010:mdna:199]
|  | Maturity Date |  | July 25, 2020 |  | July 27, 2019 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | $ | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | 1,500 |  |
| 4.45% | January 15, 2020 |  | — |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | — |  |  | 1,500 |  |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 14,500 |  |  | $ | 20,500 |  |

[0000858877-20-000010:mdna:200]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of July 25, 2020.

[0000858877-20-000010:mdna:201]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of July 25, 2020. We had $4.2 billion in commercial paper notes outstanding as of July 27, 2019.

[0000858877-20-000010:mdna:202]
Credit Facility  On May 15, 2020, we entered into a 364-day credit agreement with certain institutional lenders that provides for a $2.75 billion unsecured revolving credit facility that is scheduled to expire on May 14, 2021. The credit agreement is structured as an amendment and restatement of our five-year credit facility which would have terminated on May 15, 2020, the end of its five-year term. As of July 25, 2020, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than 0.25%. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion. This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

[0000858877-20-000010:mdna:203]
50

[0000858877-20-000010:mdna:204]
Deferred Revenue   The following table presents the breakdown of deferred revenue (in millions):

[0000858877-20-000010:mdna:205]
|  | July 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Service | $ | 12,551 |  |  | $ | 11,709 |  |  | $ | 842 |  |
| Product | 7,895 |  |  | 6,758 |  |  | 1,137 |  |
| Total | $ | 20,446 |  |  | $ | 18,467 |  |  | $ | 1,979 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 11,406 |  |  | $ | 10,668 |  |  | $ | 738 |  |
| Noncurrent | 9,040 |  |  | 7,799 |  |  | 1,241 |  |
| Total | $ | 20,446 |  |  | $ | 18,467 |  |  | $ | 1,979 |  |

[0000858877-20-000010:mdna:206]
Total deferred revenue increased 11% in fiscal 2020. The increase in deferred product revenue of 17% was primarily due to increased deferrals related to our recurring software offerings. The increase in deferred service revenue was driven by the impact of contract renewals, partially offset by amortization of deferred service revenue.

[0000858877-20-000010:mdna:207]
Remaining Performance Obligations   The following table presents the breakdown of remaining performance obligations (in millions):

[0000858877-20-000010:mdna:208]
|  | July 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Product | $ | 11,261 |  |  | $ | 9,603 |  |  | $ | 1,658 |  |
| Service | 17,093 |  |  | 15,702 |  |  | 1,391 |  |
| Total | $ | 28,354 |  |  | $ | 25,305 |  |  | $ | 3,049 |  |

[0000858877-20-000010:mdna:209]
Total remaining performance obligations increased 12% in fiscal 2020. Remaining performance obligations for product and service increased 17% and 9%, respectively, compared to fiscal 2019.

[0000858877-20-000010:mdna:210]
Contractual Obligations

[0000858877-20-000010:mdna:211]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. In addition, we plan for and measure our liquidity and capital resources through an annual budgeting process. The following table summarizes our contractual obligations at July 25, 2020 (in millions):

[0000858877-20-000010:mdna:212]
|  | PAYMENTS DUE BY PERIOD |
| July 25, 2020 | Total |  | Less than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than 5 Years |
| Operating leases | $ | 1,033 |  |  | $ | 354 |  |  | $ | 439 |  |  | $ | 188 |  |  | $ | 52 |  |
| Purchase commitments with contract manufacturers and suppliers | 4,406 |  |  | 3,994 |  |  | 412 |  |  | — |  |  | — |  |
| Other purchase obligations | 1,226 |  |  | 522 |  |  | 423 |  |  | 209 |  |  | 72 |  |
| Senior notes | 14,500 |  |  | 3,000 |  |  | 3,000 |  |  | 2,250 |  |  | 6,250 |  |
| Transition tax payable | 7,638 |  |  | 727 |  |  | 1,455 |  |  | 3,183 |  |  | 2,273 |  |
| Other long-term liabilities | 1,405 |  |  | — |  |  | 358 |  |  | 93 |  |  | 954 |  |
| Total by period | $ | 30,208 |  |  | $ | 8,597 |  |  | $ | 6,087 |  |  | $ | 5,923 |  |  | $ | 9,601 |  |
| Other long-term liabilities (uncertainty in the timing of future payments) | 2,007 |  |  |  |  |  |  |  |  |  |
| Total | $ | 32,215 |  |  |  |  |  |  |  |  |  |

[0000858877-20-000010:mdna:213]
Operating Leases  For more information on our operating leases, see Note 8 to the Consolidated Financial Statements.

[0000858877-20-000010:mdna:214]
Purchase Commitments with Contract Manufacturers and Suppliers  We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. A significant portion of our reported estimated purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. We record a liability for firm, noncancelable, and

[0000858877-20-000010:mdna:215]
unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. See further discussion in “Inventory Supply Chain.”

[0000858877-20-000010:mdna:216]
Other Purchase Obligations  Other purchase obligations represent an estimate of all contractual obligations in the ordinary course of business, other than operating leases and commitments with contract manufacturers and suppliers, for which we have not received the goods or services. Purchase orders are not included in the preceding table as they typically represent our authorization to purchase rather than binding contractual purchase obligations.

[0000858877-20-000010:mdna:217]
Long-Term Debt  The amount of long-term debt in the preceding table represents the principal amount of the respective debt instruments. See Note 12 to the Consolidated Financial Statements.

[0000858877-20-000010:mdna:218]
Transition Tax Payable Transition tax payable represents future cash tax payments associated with the one-time U.S. transition tax on accumulated earnings of foreign subsidiaries as a result of the Tax Act. See Note 18 to the Consolidated Financial Statements.

[0000858877-20-000010:mdna:219]
Other Long-Term Liabilities  Other long-term liabilities primarily include noncurrent income taxes payable, accrued liabilities for deferred compensation, deferred tax liabilities, and certain other long-term liabilities. Due to the uncertainty in the timing of future payments, our noncurrent income taxes payable of approximately $1.9 billion and deferred tax liabilities of $81 million were presented as one aggregated amount in the total column on a separate line in the preceding table. Noncurrent income taxes payable include uncertain tax positions. See Note 18 to the Consolidated Financial Statements.

[0000858877-20-000010:mdna:220]
Other Commitments

[0000858877-20-000010:mdna:221]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or the continued employment with us of certain employees of the acquired entities. See Note 14 to the Consolidated Financial Statements.

[0000858877-20-000010:mdna:222]
We also have certain funding commitments primarily related to our non-marketable equity and other investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.3 billion as of each of July 25, 2020 and July 27, 2019.

[0000858877-20-000010:mdna:223]
Off-Balance Sheet Arrangements

[0000858877-20-000010:mdna:224]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have non-marketable equity and other investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our non-marketable equity and other investments and customer financings, and we have determined that as of July 25, 2020 there were no material unconsolidated variable interest entities.

[0000858877-20-000010:mdna:225]
On an ongoing basis, we reassess our non-marketable equity and other investments and customer financings to determine if they are variable interest entities and if we would be regarded as the primary beneficiary pursuant to the applicable accounting guidance. As a result of this ongoing assessment, we may be required to make additional disclosures or consolidate these entities. Because we may not control these entities, we may not have the ability to influence these events.

[0000858877-20-000010:mdna:226]
We provide financing guarantees, which are generally for various third-party financing arrangements extended to our channel partners and end-user customers. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. See the previous discussion of these financing guarantees under “Financing Receivables and Guarantees.”

[0000858877-20-000010:mdna:227]
Liquidity and Capital Resource Requirements

[0000858877-20-000010:mdna:228]
While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to increased disruption and volatility in capital markets and credit markets. The pandemic and resulting economic uncertainty could adversely affect our liquidity and capital resources in the future. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.

[0000858877-20-000010:mdna:229]
52
