# CSCO 8-K — 0001193125-20-217658 filed 2020-08-12

## item codes, every 8-K on or before 2020-09-03

- 2020-08-12 0001193125-20-217756 — 5.02
- 2020-08-12 0001193125-20-217658 — 2.02, 2.05, 9.01
- 2020-06-22 0001193125-20-175641 — 8.01
- 2020-05-13 0001193125-20-141598 — 2.02, 9.01
- 2020-03-13 0001193125-20-072960 — 5.02
- 2020-03-06 0001193125-20-065138 — 5.02
- 2020-02-12 0001193125-20-033208 — 2.02, 9.01
- 2020-01-27 0001193125-20-015453 — 5.02
- 2019-12-23 0001193125-19-322662 — 8.01
- 2019-12-12 0001193125-19-312796 — 8.01
- 2019-12-11 0001193125-19-311525 — 5.07
- 2019-12-04 0001193125-19-306229 — 8.01
- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2020-09-03

- none on or before 2020-09-03

## item 2.02 — earnings release, exhibit 99.1

[0001193125-20-217658:8k_2_02:1]
EX-99.1
2
d50157dex991.htm
EX-99.1

[0001193125-20-217658:8k_2_02:2]
EX-99.1

[0001193125-20-217658:8k_2_02:3]
Exhibit 99.1

[0001193125-20-217658:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-20-217658:8k_2_02:5]
CISCO REPORTS FOURTH QUARTER AND FISCAL YEAR 2020 EARNINGS

[0001193125-20-217658:8k_2_02:6]
|  | • |  | Q4 Results: |

[0001193125-20-217658:8k_2_02:7]
|  | • |  | Revenue: $12.2 billion |

[0001193125-20-217658:8k_2_02:8]
|  | • |  | Decrease of (9)% year over year |

[0001193125-20-217658:8k_2_02:9]
|  | • |  | Earnings per Share: GAAP: $0.62; Non-GAAP: $0.80 |

[0001193125-20-217658:8k_2_02:10]
|  | • |  | GAAP EPS increased 22% year over year |

[0001193125-20-217658:8k_2_02:11]
|  | • |  | Non-GAAP EPS decreased (4)% year over year |

[0001193125-20-217658:8k_2_02:12]
|  | • |  | FY 2020 Results: |

[0001193125-20-217658:8k_2_02:13]
|  | • |  | Revenue: $49.3 billion |

[0001193125-20-217658:8k_2_02:14]
|  | • |  | Decrease of (5)% year over year |

[0001193125-20-217658:8k_2_02:15]
|  | • |  | 51% of revenue from software and services |

[0001193125-20-217658:8k_2_02:16]
|  | • |  | Earnings per Share: GAAP: $2.64; Non-GAAP: $3.21 |

[0001193125-20-217658:8k_2_02:17]
|  | • |  | GAAP EPS increased 1% year over year |

[0001193125-20-217658:8k_2_02:18]
|  | • |  | Non-GAAP EPS increased 4% year over year |

[0001193125-20-217658:8k_2_02:19]
|  | • |  | Q1 Guidance: |

[0001193125-20-217658:8k_2_02:20]
|  | • |  | Revenue: (9)% to (11)% decline year over year |

[0001193125-20-217658:8k_2_02:21]
|  | • |  | Earnings per Share: GAAP: $0.41 to $0.47; Non-GAAP: $0.69 to $0.71 |

[0001193125-20-217658:8k_2_02:22]
SAN JOSE, Calif. — August 12, 2020 — Cisco today reported fourth quarter and fiscal year results for the period ended
July 25, 2020. Cisco reported fourth quarter revenue of $12.2 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.6 billion or $0.62 per share, and non-GAAP net
income of $3.4 billion or $0.80 per share.

[0001193125-20-217658:8k_2_02:23]
As previously disclosed, Cisco completed the divestiture of the Service Provider Video Software Solutions
(SPVSS) business in the second quarter of fiscal 2019 on October 28, 2018. Revenue and non-GAAP financial information have been normalized to exclude the SPVSS business from prior periods for comparative
purposes.

[0001193125-20-217658:8k_2_02:24]
“By the end of fiscal 2020, we achieved our goal of more than half of our revenue coming from software and services, and this strategy
continues to resonate with customers as they digitize their organizations. Throughout fiscal 2020, Cisco has demonstrated operational resilience based on our strong customer relationships, solid financial foundation, and differentiated
innovation,” said Chuck Robbins, chairman and CEO of Cisco. “As we focus on the future, we are rebalancing our R&D investments to focus on new areas so we can continue to offer customers the best, most relevant technology in simpler,
more easily consumable ways.”

[0001193125-20-217658:8k_2_02:25]
Q4 GAAP Results

[0001193125-20-217658:8k_2_02:26]
|  |  | Q4 FY 2020 |  |  | Q4 FY 2019 |  |  | Vs. Q4 FY 2019 |  |
| Revenue |  | $ | 12.2 billion |  |  | $ | 13.4 billion |  |  |  | (9 | )% |
| Net Income |  | $ | 2.6 billion |  |  | $ | 2.2 billion |  |  |  | 19 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.62 |  |  | $ | 0.51 |  |  |  | 22 | % |

[0001193125-20-217658:8k_2_02:27]
Q4 GAAP results for fiscal 2019 include a $0.9 billion charge related to the Tax Cuts and Jobs Act.

[0001193125-20-217658:8k_2_02:28]
1

[0001193125-20-217658:8k_2_02:29]
Q4 Non-GAAP Results

[0001193125-20-217658:8k_2_02:30]
|  |  | Q4 FY 2020 |  |  | Q4 FY 2019 |  |  | Vs. Q4 FY 2019 |  |
| Net Income |  | $ | 3.4 billion |  |  | $ | 3.6 billion |  |  |  | (5 | )% |
| EPS |  | $ | 0.80 |  |  | $ | 0.83 |  |  |  | (4 | )% |

[0001193125-20-217658:8k_2_02:31]
Fiscal Year GAAP Results

[0001193125-20-217658:8k_2_02:32]
|  |  | FY 2020 |  |  | FY 2019 |  |  | Vs. FY 2019 |  |
| Revenue (including SPVSS business for all periods) |  | $ | 49.3 billion |  |  | $ | 51.9 billion |  |  |  | (5 | )% |
| Revenue (excluding SPVSS business for all periods) |  | $ | 49.3 billion |  |  | $ | 51.7 billion |  |  |  | (5 | )% |
| Net Income |  | $ | 11.2 billion |  |  | $ | 11.6 billion |  |  |  | (4 | )% |
| EPS |  | $ | 2.64 |  |  | $ | 2.61 |  |  |  | 1 | % |

[0001193125-20-217658:8k_2_02:33]
GAAP results for fiscal 2019 include charges related to the Tax Cuts and Jobs Act of $0.9 billion.

[0001193125-20-217658:8k_2_02:34]
Fiscal Year Non-GAAP Results

[0001193125-20-217658:8k_2_02:35]
|  |  | FY 2020 |  |  | FY 2019 |  |  | Vs. FY 2019 |  |
| Net Income (excluding SPVSS business for all periods) |  | $ | 13.7 billion |  |  | $ | 13.8 billion |  |  |  | (1 | )% |
| EPS (excluding SPVSS business for all periods) |  | $ | 3.21 |  |  | $ | 3.10 |  |  |  | 4 | % |

[0001193125-20-217658:8k_2_02:36]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-20-217658:8k_2_02:37]
“We executed well in Q4, delivering strong margins despite the very challenging environment,” said Kelly Kramer, CFO of Cisco. “Software
subscriptions now make up 78% of our software revenue and remaining performance obligations continued to grow strongly in the quarter, reflecting the strength of our portfolio of software and services. We are seeing the returns on our investments in
innovation as we focus on delivering long term growth and shareholder value.”

[0001193125-20-217658:8k_2_02:38]
2

[0001193125-20-217658:8k_2_02:39]
Financial Summary

[0001193125-20-217658:8k_2_02:40]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-20-217658:8k_2_02:41]
All revenue, non-GAAP, and geographic financial information in the “FY 2020 Highlights” sections are
presented excluding the SPVSS business for all prior periods as it was divested during the second quarter of fiscal 2019, on October 28, 2018.

[0001193125-20-217658:8k_2_02:42]
Q4 FY 2020 Highlights

[0001193125-20-217658:8k_2_02:43]
Revenue —
Total revenue was $12.2 billion, down 9%, with product revenue down 13% and service revenue was flat. Revenue by geographic segment was: Americas down 12%, EMEA down 6%, and APJC down 7%. Product revenue was led by growth in Security,
up 10%. Infrastructure Platforms was down 16% and Applications was down 9%.

[0001193125-20-217658:8k_2_02:44]
Gross Margin — On a GAAP basis, total gross margin,
product gross margin, and service gross margin were 63.2%, 61.2%, and 68.7%, respectively, as compared with 63.9%, 62.9%, and 66.8%, respectively, in the fourth quarter of 2019.

[0001193125-20-217658:8k_2_02:45]
On a non-GAAP basis, total gross margin, product gross margin, and service gross margin were 65.0%, 63.2%, and 69.8%,
respectively, as compared with 65.5%, 64.7%, and 67.9%, respectively, in the fourth quarter of 2019.

[0001193125-20-217658:8k_2_02:46]
Total gross margins by geographic segment were:
65.6% for the Americas, 64.9% for EMEA and 63.2% for APJC.

[0001193125-20-217658:8k_2_02:47]
Operating Expenses — On a GAAP basis, operating expenses were
$4.4 billion, down 9%, and were 36.5% of revenue. Non-GAAP operating expenses were $3.9 billion, down 12%, and were 32.0% of revenue.

[0001193125-20-217658:8k_2_02:48]
Operating Income — GAAP operating income was $3.2 billion, down 12%, with GAAP operating margin of 26.7%. Non-GAAP operating income was $4.0 billion, down 8%, with non-GAAP operating margin at 33.0%.

[0001193125-20-217658:8k_2_02:49]
Provision for Income Taxes — The GAAP tax provision rate was 20.3%. The non-GAAP tax provision rate
was 16.7%.

[0001193125-20-217658:8k_2_02:50]
Net Income and EPS — On a GAAP basis, net income was $2.6 billion, an increase of 19%, and EPS was $0.62, an increase
of 22%. On a non-GAAP basis, net income was $3.4 billion, a decrease of 5%, and EPS was $0.80, a decrease of 4%.

[0001193125-20-217658:8k_2_02:51]
Cash Flow from Operating Activities — $3.8 billion for the fourth quarter of fiscal 2020, a decrease of 4% compared with
$3.9 billion for the fourth quarter of fiscal 2019.

[0001193125-20-217658:8k_2_02:52]
FY 2020 Highlights

[0001193125-20-217658:8k_2_02:53]
Revenue — Total revenue was $49.3 billion, a decrease of 5%.

[0001193125-20-217658:8k_2_02:54]
Net Income and EPS — On a GAAP basis, net income was $11.2 billion, a decrease of 4%, and EPS was $2.64, an increase of 1%. On a non-GAAP basis, net income was $13.7 billion, a decrease of 1% compared to fiscal 2019, and EPS was $3.21, an increase of 4%.

[0001193125-20-217658:8k_2_02:55]
Cash Flow from Operating Activities — $15.4 billion for fiscal 2020 compared with $15.8 billion for fiscal 2019, a decrease of
3%. Operating cash flow for fiscal 2019 includes the receipt of $0.4 billion related to a litigation settlement with Arista Networks. Operating cash flow was flat normalized for this item.

[0001193125-20-217658:8k_2_02:56]
3

[0001193125-20-217658:8k_2_02:57]
Balance Sheet and Other Financial Highlights

[0001193125-20-217658:8k_2_02:58]
Cash and Cash Equivalents and Investments — $29.4 billion at the end of the fourth quarter of fiscal 2020, compared with
$28.6 billion at the end of the third quarter of fiscal 2020, and compared with $33.4 billion at the end of fiscal 2019.

[0001193125-20-217658:8k_2_02:59]
Deferred Revenue
— $20.4 billion, up 11% in total, with deferred product revenue up 17%. Deferred service revenue was up 7%.

[0001193125-20-217658:8k_2_02:60]
Remaining Performance
Obligations — $28.4 billion at the end of fiscal 2020, up 12%.

[0001193125-20-217658:8k_2_02:61]
Capital Allocation — In the fourth quarter of
fiscal 2020, we declared and paid a cash dividend of $0.36 per common share, or $1.5 billion.

[0001193125-20-217658:8k_2_02:62]
Acquisitions

[0001193125-20-217658:8k_2_02:63]
In the first quarter of fiscal 2021, we closed the acquisition of privately held ThousandEyes, Inc. ThousandEyes’ Internet and Cloud intelligence platform
delivers deep visibility and insights into the digital delivery of applications and services over the Internet.

[0001193125-20-217658:8k_2_02:64]
4

[0001193125-20-217658:8k_2_02:65]
Guidance for Q1 FY 2021

[0001193125-20-217658:8k_2_02:66]
Cisco expects to achieve the following results for the first quarter of fiscal 2021:

[0001193125-20-217658:8k_2_02:67]
| Q1 FY 2021 |  |  |
| Revenue |  | (9)% - (11)% decline Y/Y |
| Non-GAAP gross margin rate |  | 64% - 65% |
| Non-GAAP operating margin rate |  | 30% - 31% |
| Non-GAAP tax provision rate |  | 19% |
| Non-GAAP EPS |  | $0.69 - $0.71 |

[0001193125-20-217658:8k_2_02:68]
Cisco estimates that GAAP EPS will be $0.41 to $0.47 in the first quarter of fiscal 2021.

[0001193125-20-217658:8k_2_02:69]
A reconciliation between the Guidance for Q1 FY 2021 on a GAAP and non-GAAP basis is provided in the table entitled
“GAAP to non-GAAP Guidance for Q1 FY 2021” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-20-217658:8k_2_02:70]
Editor’s Notes:

[0001193125-20-217658:8k_2_02:71]
|  | • |  | Q4 fiscal year 2020 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, August 12, 2020 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-20-217658:8k_2_02:72]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, August 12, 2020 to 4:00 p.m. Pacific Time, August 19, 2020 at 1-866-429-0574 (United States) or 1-203-369-0916 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-20-217658:8k_2_02:73]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, August 12, 2020. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-20-217658:8k_2_02:74]
5

[0001193125-20-217658:8k_2_02:75]
CISCO SYSTEMS, INC.

[0001193125-20-217658:8k_2_02:76]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-20-217658:8k_2_02:77]
(In millions, except per-share amounts)

[0001193125-20-217658:8k_2_02:78]
(Unaudited)

[0001193125-20-217658:8k_2_02:79]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 25,2020 |  |  | July 27,2019 |  |  | July 25,2020 |  |  | July 27,2019 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,832 |  |  | $ | 10,120 |  |  | $ | 35,978 |  |  | $ | 39,005 |  |
| Service |  |  | 3,322 |  |  |  | 3,308 |  |  |  | 13,323 |  |  |  | 12,899 |  |
| Total revenue |  |  | 12,154 |  |  |  | 13,428 |  |  |  | 49,301 |  |  |  | 51,904 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,429 |  |  |  | 3,757 |  |  |  | 13,199 |  |  |  | 14,863 |  |
| Service |  |  | 1,041 |  |  |  | 1,097 |  |  |  | 4,419 |  |  |  | 4,375 |  |
| Total cost of sales |  |  | 4,470 |  |  |  | 4,854 |  |  |  | 17,618 |  |  |  | 19,238 |  |
| GROSS MARGIN |  |  | 7,684 |  |  |  | 8,574 |  |  |  | 31,683 |  |  |  | 32,666 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,565 |  |  |  | 1,753 |  |  |  | 6,347 |  |  |  | 6,577 |  |
| Sales and marketing |  |  | 2,218 |  |  |  | 2,487 |  |  |  | 9,169 |  |  |  | 9,571 |  |
| General and administrative |  |  | 494 |  |  |  | 566 |  |  |  | 1,925 |  |  |  | 1,827 |  |
| Amortization of purchased intangible assets |  |  | 33 |  |  |  | 38 |  |  |  | 141 |  |  |  | 150 |  |
| Restructuring and other charges |  |  | 127 |  |  |  | 40 |  |  |  | 481 |  |  |  | 322 |  |
| Total operating expenses |  |  | 4,437 |  |  |  | 4,884 |  |  |  | 18,063 |  |  |  | 18,447 |  |
| OPERATING INCOME |  |  | 3,247 |  |  |  | 3,690 |  |  |  | 13,620 |  |  |  | 14,219 |  |
| Interest income |  |  | 187 |  |  |  | 305 |  |  |  | 920 |  |  |  | 1,308 |  |
| Interest expense |  |  | (119 | ) |  |  | (204 | ) |  |  | (585 | ) |  |  | (859 | ) |
| Other income (loss), net |  |  | (9 | ) |  |  | (87 | ) |  |  | 15 |  |  |  | (97 | ) |
| Interest and other income (loss), net |  |  | 59 |  |  |  | 14 |  |  |  | 350 |  |  |  | 352 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,306 |  |  |  | 3,704 |  |  |  | 13,970 |  |  |  | 14,571 |  |
| Provision for income taxes (1) |  |  | 670 |  |  |  | 1,498 |  |  |  | 2,756 |  |  |  | 2,950 |  |
| NET INCOME |  | $ | 2,636 |  |  | $ | 2,206 |  |  | $ | 11,214 |  |  | $ | 11,621 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.62 |  |  | $ | 0.52 |  |  | $ | 2.65 |  |  | $ | 2.63 |  |
| Diluted |  | $ | 0.62 |  |  | $ | 0.51 |  |  | $ | 2.64 |  |  | $ | 2.61 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,227 |  |  |  | 4,269 |  |  |  | 4,236 |  |  |  | 4,419 |  |
| Diluted |  |  | 4,244 |  |  |  | 4,307 |  |  |  | 4,254 |  |  |  | 4,453 |  |

[0001193125-20-217658:8k_2_02:80]
The Consolidated Statements of Operations include the results of the SPVSS business prior to its divestiture during the second
quarter of fiscal 2019 on October 28, 2018. Accordingly, the fiscal year ended July 27, 2019 includes three months of financial results for this business.

[0001193125-20-217658:8k_2_02:81]
| (1) | The provision for income taxes included a $0.9 billion charge for the three months and fiscal year ended July 27, 2019 related to the Tax Cuts and Jobs Act. |

[0001193125-20-217658:8k_2_02:82]
6

[0001193125-20-217658:8k_2_02:83]
CISCO SYSTEMS, INC.

[0001193125-20-217658:8k_2_02:84]
REVENUE BY SEGMENT

[0001193125-20-217658:8k_2_02:85]
(In
millions, except percentages)

[0001193125-20-217658:8k_2_02:86]
|  |  | July 25, 2020 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  |  |  |  |  |  |  |  |  |  | ExcludingSPVSSbusiness |  |  | IncludingSPVSSbusiness |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,185 |  |  |  | (12 | )% |  | $ | 29,291 |  |  |  | (5 | )% |  |  | (5 | )% |
| EMEA |  |  | 3,106 |  |  |  | (6 | )% |  |  | 12,659 |  |  |  | (3 | )% |  |  | (3 | )% |
| APJC |  |  | 1,863 |  |  |  | (7 | )% |  |  | 7,352 |  |  |  | (6 | )% |  |  | (7 | )% |
| Total |  | $ | 12,154 |  |  |  | (9 | )% |  | $ | 49,301 |  |  |  | (5 | )% |  |  | (5 | )% |

[0001193125-20-217658:8k_2_02:87]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-20-217658:8k_2_02:88]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. SPVSS business revenue for the fiscal
year ended July 27, 2019 was $168 million.

[0001193125-20-217658:8k_2_02:89]
CISCO SYSTEMS, INC.

[0001193125-20-217658:8k_2_02:90]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-20-217658:8k_2_02:91]
(In percentages)

[0001193125-20-217658:8k_2_02:92]
|  |  | July 25, 2020 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 65.6 | % |  |  | 66.7 | % |
| EMEA |  |  | 64.9 | % |  |  | 65.6 | % |
| APJC |  |  | 63.2 | % |  |  | 63.8 | % |

[0001193125-20-217658:8k_2_02:93]
CISCO SYSTEMS, INC.

[0001193125-20-217658:8k_2_02:94]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-20-217658:8k_2_02:95]
(In millions, except percentages)

[0001193125-20-217658:8k_2_02:96]
|  |  | July 25, 2020 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  |  |  |  |  |  |  |  |  |  | ExcludingSPVSSbusiness |  |  | IncludingSPVSSbusiness |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 6,626 |  |  |  | (16 | )% |  | $ | 27,122 |  |  |  | (10 | )% |  |  | (10 | )% |
| Applications |  |  | 1,357 |  |  |  | (9 | )% |  |  | 5,568 |  |  |  | (4 | )% |  |  | (4 | )% |
| Security |  |  | 814 |  |  |  | 10 | % |  |  | 3,154 |  |  |  | 12 | % |  |  | 12 | % |
| Other Products |  |  | 35 |  |  |  | (17 | )% |  |  | 135 |  |  |  | — | % |  |  | (52 | )% |
| Total Product |  |  | 8,832 |  |  |  | (13 | )% |  |  | 35,978 |  |  |  | (7 | )% |  |  | (8 | )% |
| Services |  |  | 3,322 |  |  |  | — | % |  |  | 13,323 |  |  |  | 3 | % |  |  | 3 | % |
| Total |  | $ | 12,154 |  |  |  | (9 | )% |  | $ | 49,301 |  |  |  | (5 | )% |  |  | (5 | )% |

[0001193125-20-217658:8k_2_02:97]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-20-217658:8k_2_02:98]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. SPVSS business revenue for the fiscal
year ended July 27, 2019 was $168 million.

[0001193125-20-217658:8k_2_02:99]
8

[0001193125-20-217658:8k_2_02:100]
CISCO SYSTEMS, INC.

[0001193125-20-217658:8k_2_02:101]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-20-217658:8k_2_02:102]
(In millions)

[0001193125-20-217658:8k_2_02:103]
(Unaudited)

[0001193125-20-217658:8k_2_02:104]
|  |  | July 25, 2020 |  |  | July 27, 2019 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 11,809 |  |  | $ | 11,750 |  |
| Investments |  |  | 17,610 |  |  |  | 21,663 |  |
| Accounts receivable, net of allowance for doubtful accounts of $143 at July 25, 2020 and $136 at July 27, 2019 |  |  | 5,472 |  |  |  | 5,491 |  |
| Inventories |  |  | 1,282 |  |  |  | 1,383 |  |
| Financing receivables, net |  |  | 5,051 |  |  |  | 5,095 |  |
| Other current assets |  |  | 2,349 |  |  |  | 2,373 |  |
| Total current assets |  |  | 43,573 |  |  |  | 47,755 |  |
| Property and equipment, net |  |  | 2,453 |  |  |  | 2,789 |  |
| Financing receivables, net |  |  | 5,714 |  |  |  | 4,958 |  |
| Goodwill |  |  | 33,806 |  |  |  | 33,529 |  |
| Purchased intangible assets, net |  |  | 1,576 |  |  |  | 2,201 |  |
| Deferred tax assets |  |  | 3,990 |  |  |  | 4,065 |  |
| Other assets |  |  | 3,741 |  |  |  | 2,496 |  |
| TOTAL ASSETS |  | $ | 94,853 |  |  | $ | 97,793 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 3,005 |  |  | $ | 10,191 |  |
| Accounts payable |  |  | 2,218 |  |  |  | 2,059 |  |
| Income taxes payable |  |  | 839 |  |  |  | 1,149 |  |
| Accrued compensation |  |  | 3,122 |  |  |  | 3,221 |  |
| Deferred revenue |  |  | 11,406 |  |  |  | 10,668 |  |
| Other current liabilities |  |  | 4,741 |  |  |  | 4,424 |  |
| Total current liabilities |  |  | 25,331 |  |  |  | 31,712 |  |
| Long-term debt |  |  | 11,578 |  |  |  | 14,475 |  |
| Income taxes payable |  |  | 8,837 |  |  |  | 8,927 |  |
| Deferred revenue |  |  | 9,040 |  |  |  | 7,799 |  |
| Other long-term liabilities |  |  | 2,147 |  |  |  | 1,309 |  |
| Total liabilities |  |  | 56,933 |  |  |  | 64,222 |  |
| Total equity |  |  | 37,920 |  |  |  | 33,571 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 94,853 |  |  | $ | 97,793 |  |

[0001193125-20-217658:8k_2_02:105]
9

[0001193125-20-217658:8k_2_02:106]
CISCO SYSTEMS, INC.

[0001193125-20-217658:8k_2_02:107]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-20-217658:8k_2_02:108]
(In millions)

[0001193125-20-217658:8k_2_02:109]
(Unaudited)

[0001193125-20-217658:8k_2_02:110]
|  |  | Fiscal Year Ended |  |
|  |  | July 25,2020 |  |  | July 27,2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 11,214 |  |  | $ | 11,621 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,808 |  |  |  | 1,897 |  |
| Share-based compensation expense |  |  | 1,569 |  |  |  | 1,570 |  |
| Provision for receivables |  |  | 93 |  |  |  | 40 |  |
| Deferred income taxes |  |  | (38 | ) |  |  | (350 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (138 | ) |  |  | (24 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (107 | ) |  |  | (84 | ) |
| Inventories |  |  | 84 |  |  |  | 131 |  |
| Financing receivables |  |  | (797 | ) |  |  | (249 | ) |
| Other assets |  |  | 96 |  |  |  | (955 | ) |
| Accounts payable |  |  | 141 |  |  |  | 87 |  |
| Income taxes, net |  |  | (322 | ) |  |  | 312 |  |
| Accrued compensation |  |  | (78 | ) |  |  | 277 |  |
| Deferred revenue |  |  | 2,011 |  |  |  | 1,407 |  |
| Other liabilities |  |  | (110 | ) |  |  | 151 |  |
| Net cash provided by operating activities |  |  | 15,426 |  |  |  | 15,831 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (9,212 | ) |  |  | (2,416 | ) |
| Proceeds from sales of investments |  |  | 5,631 |  |  |  | 7,388 |  |
| Proceeds from maturities of investments |  |  | 7,975 |  |  |  | 12,928 |  |
| Acquisitions and divestitures |  |  | (327 | ) |  |  | (2,175 | ) |
| Purchases of investments in privately held companies |  |  | (190 | ) |  |  | (148 | ) |
| Return of investments in privately held companies |  |  | 224 |  |  |  | 159 |  |
| Acquisition of property and equipment |  |  | (770 | ) |  |  | (909 | ) |
| Proceeds from sales of property and equipment |  |  | 179 |  |  |  | 22 |  |
| Other |  |  | (10 | ) |  |  | (12 | ) |
| Net cash provided by investing activities |  |  | 3,500 |  |  |  | 14,837 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 655 |  |  |  | 640 |  |
| Repurchases of common stock - repurchase program |  |  | (2,659 | ) |  |  | (20,717 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (727 | ) |  |  | (862 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | (3,470 | ) |  |  | 3,446 |  |
| Issuances of debt |  |  | — |  |  |  | 2,250 |  |
| Repayments of debt |  |  | (6,720 | ) |  |  | (6,780 | ) |
| Dividends paid |  |  | (6,016 | ) |  |  | (5,979 | ) |
| Other |  |  | 51 |  |  |  | 113 |  |
| Net cash used in financing activities |  |  | (18,886 | ) |  |  | (27,889 | ) |
| Net increase in cash, cash equivalents, and restricted cash |  |  | 40 |  |  |  | 2,779 |  |
| Cash, cash equivalents, and restricted cash, beginning of fiscal year |  |  | 11,772 |  |  |  | 8,993 |  |
| Cash, cash equivalents, and restricted cash, end of fiscal year |  | $ | 11,812 |  |  | $ | 11,772 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 603 |  |  | $ | 892 |  |
| Cash paid for income taxes, net |  | $ | 3,116 |  |  | $ | 2,986 |  |

[0001193125-20-217658:8k_2_02:111]
10

[0001193125-20-217658:8k_2_02:112]
CISCO SYSTEMS, INC.

[0001193125-20-217658:8k_2_02:113]
DEFERRED REVENUE

[0001193125-20-217658:8k_2_02:114]
(In
millions)

[0001193125-20-217658:8k_2_02:115]
|  |  | July 25,2020 |  |  | April 25,2020 |  |  | July 27,2019 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 12,551 |  |  | $ | 11,423 |  |  | $ | 11,709 |  |
| Product |  |  | 7,895 |  |  |  | 7,225 |  |  |  | 6,758 |  |
| Total |  | $ | 20,446 |  |  | $ | 18,648 |  |  | $ | 18,467 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 11,406 |  |  | $ | 10,710 |  |  | $ | 10,668 |  |
| Noncurrent |  |  | 9,040 |  |  |  | 7,938 |  |  |  | 7,799 |  |
| Total |  | $ | 20,446 |  |  | $ | 18,648 |  |  | $ | 18,467 |  |

[0001193125-20-217658:8k_2_02:116]
CISCO SYSTEMS, INC.

[0001193125-20-217658:8k_2_02:117]
REMAINING PERFORMANCE OBLIGATIONS

[0001193125-20-217658:8k_2_02:118]
(In millions, except percentages)

[0001193125-20-217658:8k_2_02:119]
|  |  | July 25, 2020 |  |  | April 25, 2020 |  |  | July 27, 2019 |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Product |  | $ | 11,261 |  |  |  | 17 | % |  | $ | 10,386 |  |  |  | 25 | % |  | $ | 9,603 |  |  |  | N/A |  |
| Service |  |  | 17,093 |  |  |  | 9 | % |  |  | 15,142 |  |  |  | 3 | % |  |  | 15,702 |  |  |  | N/A |  |
| Total |  | $ | 28,354 |  |  |  | 12 | % |  | $ | 25,528 |  |  |  | 11 | % |  | $ | 25,305 |  |  |  | N/A |  |

[0001193125-20-217658:8k_2_02:120]
CISCO SYSTEMS, INC.

[0001193125-20-217658:8k_2_02:121]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-20-217658:8k_2_02:122]
(In millions, except per-share amounts)

[0001193125-20-217658:8k_2_02:123]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 25, 2020 |  | $ | 0.36 |  |  | $ | 1,525 |  |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,525 |  |
| April 25, 2020 |  | $ | 0.36 |  |  | $ | 1,519 |  |  |  | 25 |  |  | $ | 39.71 |  |  | $ | 981 |  |  | $ | 2,500 |  |
| January 25, 2020 |  | $ | 0.35 |  |  | $ | 1,486 |  |  |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |  | $ | 2,356 |  |
| October 26, 2019 |  | $ | 0.35 |  |  | $ | 1,486 |  |  |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |  | $ | 2,254 |  |
| Fiscal 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 27, 2019 |  | $ | 0.35 |  |  | $ | 1,490 |  |  |  | 82 |  |  | $ | 54.99 |  |  | $ | 4,515 |  |  | $ | 6,005 |  |
| April 27, 2019 |  | $ | 0.35 |  |  | $ | 1,519 |  |  |  | 116 |  |  | $ | 52.14 |  |  | $ | 6,020 |  |  | $ | 7,539 |  |
| January 26, 2019 |  | $ | 0.33 |  |  | $ | 1,470 |  |  |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |  | $ | 6,486 |  |
| October 27, 2018 |  | $ | 0.33 |  |  | $ | 1,500 |  |  |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |  | $ | 6,526 |  |

[0001193125-20-217658:8k_2_02:124]
The remaining authorized amount for stock repurchases under the program is $10.8 billion with no termination date.

[0001193125-20-217658:8k_2_02:125]
11

[0001193125-20-217658:8k_2_02:126]
CISCO SYSTEMS, INC.

[0001193125-20-217658:8k_2_02:127]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-20-217658:8k_2_02:128]
GAAP TO NON-GAAP NET INCOME

[0001193125-20-217658:8k_2_02:129]
(In millions)

[0001193125-20-217658:8k_2_02:130]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 25,2020 |  |  | July 27,2019 |  |  | July 25,2020 |  |  | July 27,2019 |  |
| GAAP net income |  | $ | 2,636 |  |  | $ | 2,206 |  |  | $ | 11,214 |  |  | $ | 11,621 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 61 |  |  |  | 57 |  |  |  | 237 |  |  |  | 220 |  |
| Amortization of acquisition-related intangible assets |  |  | 157 |  |  |  | 144 |  |  |  | 611 |  |  |  | 562 |  |
| Supplier component remediation charge (adjustment), net |  |  | — |  |  |  | 17 |  |  |  | — |  |  |  | 16 |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | 1 |  |  |  | 3 |  |  |  | 10 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | 4 |  |  |  | 5 |  |
| Total adjustments to GAAP cost of sales |  |  | 218 |  |  |  | 219 |  |  |  | 855 |  |  |  | 813 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 332 |  |  |  | 335 |  |  |  | 1,307 |  |  |  | 1,309 |  |
| Amortization of acquisition-related intangible assets |  |  | 33 |  |  |  | 38 |  |  |  | 141 |  |  |  | 150 |  |
| Acquisition-related/divestiture costs |  |  | 55 |  |  |  | 61 |  |  |  | 246 |  |  |  | 299 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (396 | ) |
| Significant asset impairments and restructurings |  |  | 127 |  |  |  | 40 |  |  |  | 481 |  |  |  | 322 |  |
| Total adjustments to GAAP operating expenses |  |  | 547 |  |  |  | 474 |  |  |  | 2,175 |  |  |  | 1,684 |  |
| Adjustments to GAAP interest and other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | 2 |  |  |  | 20 |  |  |  | (97 | ) |  |  | (57 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 767 |  |  |  | 713 |  |  |  | 2,933 |  |  |  | 2,440 |  |
| Income tax effect of non-GAAP adjustments |  |  | (175 | ) |  |  | (168 | ) |  |  | (722 | ) |  |  | (722 | ) |
| Significant tax matters (1) |  |  | 166 |  |  |  | 835 |  |  |  | 233 |  |  |  | 448 |  |
| Total adjustments to GAAP provision for income taxes |  |  | (9 | ) |  |  | 667 |  |  |  | (489 | ) |  |  | (274 | ) |
| Non-GAAP net income |  | $ | 3,394 |  |  | $ | 3,586 |  |  | $ | 13,658 |  |  | $ | 13,787 |  |

[0001193125-20-217658:8k_2_02:131]
| (1) | The three months and fiscal year ended July 27, 2019 includes a $0.9 billion charge related to the Tax Cuts and Jobs Act. |

[0001193125-20-217658:8k_2_02:132]
12

[0001193125-20-217658:8k_2_02:133]
CISCO SYSTEMS, INC.

[0001193125-20-217658:8k_2_02:134]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-20-217658:8k_2_02:135]
GAAP TO NON-GAAP EPS

[0001193125-20-217658:8k_2_02:136]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 25,2020 |  |  | July 27,2019 |  |  | July 25,2020 |  |  | July 27,2019 |  |
| GAAP EPS |  | $ | 0.62 |  |  | $ | 0.51 |  |  | $ | 2.64 |  |  | $ | 2.61 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.09 |  |  |  | 0.09 |  |  |  | 0.36 |  |  |  | 0.34 |  |
| Amortization of acquisition-related intangible assets |  |  | 0.04 |  |  |  | 0.04 |  |  |  | 0.18 |  |  |  | 0.16 |  |
| Acquisition-related/divestiture costs |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.06 |  |  |  | 0.07 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.09 | ) |
| Significant asset impairments and restructurings |  |  | 0.03 |  |  |  | 0.01 |  |  |  | 0.11 |  |  |  | 0.07 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | (0.02 | ) |  |  | (0.01 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.04 | ) |  |  | (0.04 | ) |  |  | (0.17 | ) |  |  | (0.16 | ) |
| Significant tax matters |  |  | 0.04 |  |  |  | 0.19 |  |  |  | 0.05 |  |  |  | 0.10 |  |
| Non-GAAP EPS |  | $ | 0.80 |  |  | $ | 0.83 |  |  | $ | 3.21 |  |  | $ | 3.10 |  |

[0001193125-20-217658:8k_2_02:137]
Amounts may not sum due to rounding.

[0001193125-20-217658:8k_2_02:138]
CISCO SYSTEMS, INC.

[0001193125-20-217658:8k_2_02:139]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-20-217658:8k_2_02:140]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-20-217658:8k_2_02:141]
(In millions, except percentages)

[0001193125-20-217658:8k_2_02:142]
|  |  | Three Months Ended |  |
|  |  | July 25, 2020 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,403 |  |  | $ | 2,281 |  |  | $ | 7,684 |  |  | $ | 4,437 |  |  |  | (9 | )% |  | $ | 3,247 |  |  |  | (12 | )% |  | $ | 59 |  |  | $ | 2,636 |  |  |  | 19 | % |
| % of revenue |  |  | 61.2 | % |  |  | 68.7 | % |  |  | 63.2 | % |  |  | 36.5 | % |  |  |  |  |  |  | 26.7 | % |  |  |  |  |  |  | 0.5 | % |  |  | 21.7 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 24 |  |  |  | 37 |  |  |  | 61 |  |  |  | 332 |  |  |  |  |  |  |  | 393 |  |  |  |  |  |  |  | — |  |  |  | 393 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 157 |  |  |  | — |  |  |  | 157 |  |  |  | 33 |  |  |  |  |  |  |  | 190 |  |  |  |  |  |  |  | — |  |  |  | 190 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 55 |  |  |  |  |  |  |  | 55 |  |  |  |  |  |  |  | — |  |  |  | 55 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 127 |  |  |  |  |  |  |  | 127 |  |  |  |  |  |  |  | — |  |  |  | 127 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 2 |  |  |  | 2 |  |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (9 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 5,584 |  |  | $ | 2,318 |  |  | $ | 7,902 |  |  | $ | 3,890 |  |  |  | (12 | )% |  | $ | 4,012 |  |  |  | (8 | )% |  | $ | 61 |  |  | $ | 3,394 |  |  |  | (5 | )% |
| % of revenue |  |  | 63.2 | % |  |  | 69.8 | % |  |  | 65.0 | % |  |  | 32.0 | % |  |  |  |  |  |  | 33.0 | % |  |  |  |  |  |  | 0.5 | % |  |  | 27.9 | % |  |  |  |  |

[0001193125-20-217658:8k_2_02:143]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-20-217658:8k_2_02:144]
|  |  | Three Months Ended |  |
|  |  | July 27, 2019 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 6,363 |  |  | $ | 2,211 |  |  | $ | 8,574 |  |  | $ | 4,884 |  |  | $ | 3,690 |  |  | $ | 14 |  |  | $ | 2,206 |  |
| % of revenue |  |  | 62.9 | % |  |  | 66.8 | % |  |  | 63.9 | % |  |  | 36.4 | % |  |  | 27.5 | % |  |  | 0.1 | % |  |  | 16.4 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 23 |  |  |  | 34 |  |  |  | 57 |  |  |  | 335 |  |  |  | 392 |  |  |  | — |  |  |  | 392 |  |
| Amortization of acquisition-related intangible assets |  |  | 144 |  |  |  | — |  |  |  | 144 |  |  |  | 38 |  |  |  | 182 |  |  |  | — |  |  |  | 182 |  |
| Supplier component remediation charge (adjustment), net |  |  | 17 |  |  |  | — |  |  |  | 17 |  |  |  | — |  |  |  | 17 |  |  |  | — |  |  |  | 17 |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 61 |  |  |  | 62 |  |  |  | — |  |  |  | 62 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 40 |  |  |  | 40 |  |  |  | — |  |  |  | 40 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20 |  |  |  | 20 |  |
| Income tax effect/significant tax matters (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 667 |  |
| Non-GAAP amount |  | $ | 6,547 |  |  | $ | 2,246 |  |  | $ | 8,793 |  |  | $ | 4,410 |  |  | $ | 4,383 |  |  | $ | 34 |  |  | $ | 3,586 |  |
| % of revenue |  |  | 64.7 | % |  |  | 67.9 | % |  |  | 65.5 | % |  |  | 32.8 | % |  |  | 32.6 | % |  |  | 0.3 | % |  |  | 26.7 | % |

[0001193125-20-217658:8k_2_02:145]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-20-217658:8k_2_02:146]
| (1) | Includes a $0.9 billion charge related to the Tax Cuts and Jobs Act. |

[0001193125-20-217658:8k_2_02:147]
14

[0001193125-20-217658:8k_2_02:148]
CISCO SYSTEMS, INC.

[0001193125-20-217658:8k_2_02:149]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-20-217658:8k_2_02:150]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-20-217658:8k_2_02:151]
(In millions, except percentages)

[0001193125-20-217658:8k_2_02:152]
|  |  | Fiscal Year Ended |  |
|  |  | July 25, 2020 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 22,779 |  |  | $ | 8,904 |  |  | $ | 31,683 |  |  | $ | 18,063 |  |  |  | (2 | )% |  | $ | 13,620 |  |  |  | (4 | )% |  | $ | 350 |  |  | $ | 11,214 |  |  |  | (4 | )% |
| % of revenue |  |  | 63.3 | % |  |  | 66.8 | % |  |  | 64.3 | % |  |  | 36.6 | % |  |  |  |  |  |  | 27.6 | % |  |  |  |  |  |  | 0.7 | % |  |  | 22.7 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 93 |  |  |  | 144 |  |  |  | 237 |  |  |  | 1,307 |  |  |  |  |  |  |  | 1,544 |  |  |  |  |  |  |  | — |  |  |  | 1,544 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 611 |  |  |  | — |  |  |  | 611 |  |  |  | 141 |  |  |  |  |  |  |  | 752 |  |  |  |  |  |  |  | — |  |  |  | 752 |  |  |  |  |  |
| Legal and indemnification settlements |  |  | 4 |  |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  |  |  |  |  | 4 |  |  |  |  |  |  |  | — |  |  |  | 4 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 3 |  |  |  | 3 |  |  |  | 246 |  |  |  |  |  |  |  | 249 |  |  |  |  |  |  |  | — |  |  |  | 249 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 481 |  |  |  |  |  |  |  | 481 |  |  |  |  |  |  |  | — |  |  |  | 481 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (97 | ) |  |  | (97 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (489 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 23,487 |  |  | $ | 9,051 |  |  | $ | 32,538 |  |  | $ | 15,888 |  |  |  | (5 | )% |  | $ | 16,650 |  |  |  | — | % |  | $ | 253 |  |  | $ | 13,658 |  |  |  | (1 | )% |
| % of revenue |  |  | 65.3 | % |  |  | 67.9 | % |  |  | 66.0 | % |  |  | 32.2 | % |  |  |  |  |  |  | 33.8 | % |  |  |  |  |  |  | 0.5 | % |  |  | 27.7 | % |  |  |  |  |

[0001193125-20-217658:8k_2_02:153]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-20-217658:8k_2_02:154]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. Accordingly, the non-GAAP growth rates are normalized to exclude the SPVSS business for fiscal 2019.

[0001193125-20-217658:8k_2_02:155]
15

[0001193125-20-217658:8k_2_02:156]
|  |  | Fiscal Year Ended |  |
|  |  | July 27, 2019 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |
| GAAP amount |  | $ | 24,142 |  |  | $ | 8,524 |  |  | $ | 32,666 |  |  | $ | 18,447 |  |  | $ | 14,219 |  |  | $ | 352 |  |  | $ | 11,621 |  |
| % of revenue |  |  | 61.9 | % |  |  | 66.1 | % |  |  | 62.9 | % |  |  | 35.5 | % |  |  | 27.4 | % |  |  | 0.7 | % |  |  | 22.4 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 90 |  |  |  | 130 |  |  |  | 220 |  |  |  | 1,309 |  |  |  | 1,529 |  |  |  | — |  |  |  | 1,529 |  |
| Amortization of acquisition-related intangible assets |  |  | 562 |  |  |  | — |  |  |  | 562 |  |  |  | 150 |  |  |  | 712 |  |  |  | — |  |  |  | 712 |  |
| Supplier component remediation charge (adjustment), net |  |  | 16 |  |  |  | — |  |  |  | 16 |  |  |  | — |  |  |  | 16 |  |  |  | — |  |  |  | 16 |  |
| Legal and indemnification settlements |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | (396 | ) |  |  | (391 | ) |  |  | — |  |  |  | (391 | ) |
| Acquisition/divestiture-related costs |  |  | 4 |  |  |  | 6 |  |  |  | 10 |  |  |  | 299 |  |  |  | 309 |  |  |  | — |  |  |  | 309 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 322 |  |  |  | 322 |  |  |  | — |  |  |  | 322 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (57 | ) |  |  | (57 | ) |
| Income tax effect/significant tax matters (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (274 | ) |
| Non-GAAP amount |  | $ | 24,819 |  |  | $ | 8,660 |  |  | $ | 33,479 |  |  | $ | 16,763 |  |  | $ | 16,716 |  |  | $ | 295 |  |  | $ | 13,787 |  |
| Less: SPVSS business (2) |  |  | (51 | ) |  |  | (9 | ) |  |  | (61 | ) |  |  | (60 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-GAAP amount (excluding SPVSS business) |  | $ | 24,768 |  |  | $ | 8,651 |  |  | $ | 33,418 |  |  | $ | 16,703 |  |  | $ | 16,716 |  |  | $ | 295 |  |  | $ | 13,787 |  |
| % of revenue |  |  | 63.7 | % |  |  | 67.2 | % |  |  | 64.6 | % |  |  | 32.3 | % |  |  | 32.3 | % |  |  | 0.6 | % |  |  | 26.6 | % |

[0001193125-20-217658:8k_2_02:157]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-20-217658:8k_2_02:158]
| (1) | Includes a $0.9 billion charge related to the Tax Cuts and Jobs Act. |

[0001193125-20-217658:8k_2_02:159]
| (2) | Reflects three months of operations for the SPVSS business. |

[0001193125-20-217658:8k_2_02:160]
16

[0001193125-20-217658:8k_2_02:161]
CISCO SYSTEMS, INC.

[0001193125-20-217658:8k_2_02:162]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-20-217658:8k_2_02:163]
EFFECTIVE TAX RATE

[0001193125-20-217658:8k_2_02:164]
(In
percentages)

[0001193125-20-217658:8k_2_02:165]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 25,2020 |  |  | July 27,2019 |  |  | July 25,2020 |  |  | July 27,2019 |  |
| GAAP effective tax rate (1) |  |  | 20.3 | % |  |  | 40.4 | % |  |  | 19.7 | % |  |  | 20.2 | % |
| Total adjustments to GAAP provision for income taxes |  |  | (3.6 | )% |  |  | (21.6 | )% |  |  | (0.5 | )% |  |  | (1.2 | )% |
| Non-GAAP effective tax rate |  |  | 16.7 | % |  |  | 18.8 | % |  |  | 19.2 | % |  |  | 19.0 | % |

[0001193125-20-217658:8k_2_02:166]
| (1) | The three months and fiscal year ended July 27, 2019 includes a $0.9 billion charge related to the Tax Cuts and Jobs Act. |

[0001193125-20-217658:8k_2_02:167]
GAAP TO NON-GAAP GUIDANCE FOR Q1 FY 2021

[0001193125-20-217658:8k_2_02:168]
| Q1 FY 2021 |  | Gross Margin Rate |  | Operating Margin Rate |  | Tax ProvisionRate |  | Earnings perShare (2) |
| GAAP |  | 62% - 63% |  | 18% - 19% |  | 19% |  | $0.41 - $0.47 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.5% |  |  |  | $0.07 - $0.08 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 1.5% |  | 2.0% |  |  |  | $0.04 - $0.05 |
| Significant asset impairments and restructurings (1) |  | — |  | 6.5% |  |  |  | $0.13 - $0.15 |
| Income tax effect of non-GAAP adjustments |  |  |  |  |  | — |  |  |
| Non-GAAP |  | 64% - 65% |  | 30% - 31% |  | 19% |  | $0.69 - $0.71 |

[0001193125-20-217658:8k_2_02:169]
| (1) | In the first quarter of fiscal 2021, we initiated a restructuring plan, which includes a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas with estimated pretax charges of approximately $900 million consisting of severance and other one-time termination benefits, and other costs. We expect to recognize approximately $800 million of these charges in the first quarter of fiscal 2021 with the remaining amount to be recognized during the rest of the fiscal year. |

[0001193125-20-217658:8k_2_02:170]
| (2) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-20-217658:8k_2_02:171]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and significant
tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-20-217658:8k_2_02:172]
17

[0001193125-20-217658:8k_2_02:173]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-20-217658:8k_2_02:174]
This release includes non-GAAP net income,
non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin,
non-GAAP effective tax rates, non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the
periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-20-217658:8k_2_02:175]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with
generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any
comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as
determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-20-217658:8k_2_02:176]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP
measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-20-217658:8k_2_02:177]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other contingencies, gains and losses on equity investments, the
income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial
results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be other items that
Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial
measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-20-217658:8k_2_02:178]
18

[0001193125-20-217658:8k_2_02:179]
Cisco divested its Service Provider Video Software Solutions business (SPVSS) during the second quarter of
fiscal 2019 on October 28, 2018. This release includes, where indicated, financial measures that exclude the SPVSS business. Cisco believes that the presentation of these measures provides useful information to investors and management
regarding financial and business trends relating to its financial condition and its historical and projected results of operations because the SPVSS business will not be part of Cisco on a go forward basis. Cisco’s management also uses the
financial measures excluding the SPVSS business in reviewing the financial results of Cisco.

[0001193125-20-217658:8k_2_02:180]
About Cisco

[0001193125-20-217658:8k_2_02:181]
Cisco (Nasdaq: CSCO) is the worldwide leader in technology that powers the Internet. Cisco inspires new possibilities by reimagining your
applications, securing your data, transforming your infrastructure, and empowering your teams for a global and inclusive future. Discover more at newsroom.cisco.com and follow us on Twitter at @Cisco.

[0001193125-20-217658:8k_2_02:182]
Copyright © 2020 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are
trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their
respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-20-217658:8k_2_02:183]
RSS Feed for Cisco: https://newsroom.cisco.com/rss-feeds

[0001193125-20-217658:8k_2_02:184]
19
