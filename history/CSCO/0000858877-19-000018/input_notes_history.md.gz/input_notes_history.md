# CSCO note change history — 0000858877-19-000007 → 0000858877-19-000018


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-11-19):
[0000858877-19-000018:note_history:1]
| (a) | Purchase Commitments with Contract Manufacturers and Suppliers |
  (was, 2019-05-21, similarity 0.9861):
[0000858877-19-000007:note_history:1]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

- changed (2019-11-19):
[0000858877-19-000018:note_history:2]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported
  (was, 2019-05-21, similarity 0.6815):
[0000858877-19-000007:note_history:2]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

- added (2019-11-19):
[0000858877-19-000018:note_history:3]
purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

- changed (2019-11-19):
[0000858877-19-000018:note_history:4]
| Commitments by Period | October 26, 2019 |  | July 27, 2019 |
| Less than 1 year | $ | 3,903 |  |  | $ | 4,239 |  |
| 1 to 3 years | 633 |  |  | 728 |  |
| Total | $ | 4,536 |  |  | $ | 4,967 |  |
  (was, 2019-05-21, similarity 0.8812):
[0000858877-19-000007:note_history:4]
| Commitments by Period | April 27, 2019 |  | July 28, 2018 |
| Less than 1 year | $ | 4,738 |  |  | $ | 5,407 |  |
| 1 to 3 years | 734 |  |  | 710 |  |
| 3 to 5 years | 90 |  |  | 360 |  |
| Total | $ | 5,562 |  |  | $ | 6,477 |  |

- changed (2019-11-19):
[0000858877-19-000018:note_history:5]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 26, 2019 and July 27, 2019, the liability for these purchase commitments was $121 million and $129 million, respectively, and was included in other current liabilities.
  (was, 2019-05-21, similarity 0.984):
[0000858877-19-000007:note_history:5]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 27, 2019 and July 28, 2018, the liability for these purchase commitments was $129 million and $159 million, respectively, and was included in other current liabilities.

- changed (2019-11-19):
[0000858877-19-000018:note_history:6]
| (b) | Other Commitments |
  (was, 2019-05-21, similarity 0.963):
[0000858877-19-000007:note_history:6]
| (c) | Other Commitments |

- changed (2019-11-19):
[0000858877-19-000018:note_history:7]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Compensation expense related to acquisitions | $ | 61 |  |  | $ | 109 |  |
  (was, 2019-05-21, similarity 0.7134):
[0000858877-19-000007:note_history:7]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2019 |  | April 28, 2018 |  | April 27, 2019 |  | April 28, 2018 |
| Compensation expense related to acquisitions | $ | 76 |  |  | $ | 53 |  |  | $ | 251 |  |  | $ | 141 |  |

- changed (2019-11-19):
[0000858877-19-000018:note_history:8]
As of October 26, 2019, we estimated that future cash compensation expense of up to $430 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2019-05-21, similarity 0.9722):
[0000858877-19-000007:note_history:8]
As of April 27, 2019, we estimated that future cash compensation expense of up to $512 million may be required to be recognized pursuant to the applicable business combination agreements.

- changed (2019-11-19):
[0000858877-19-000018:note_history:9]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $311 million and $326 million as of October 26, 2019 and July 27, 2019, respectively.
  (was, 2019-05-21, similarity 0.9825):
[0000858877-19-000007:note_history:9]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $345 million and $223 million as of April 27, 2019 and July 28, 2018, respectively.

- changed (2019-11-19):
[0000858877-19-000018:note_history:10]
| (c) | Product Warranties |
  (was, 2019-05-21, similarity 0.9643):
[0000858877-19-000007:note_history:10]
| (d) | Product Warranties |

- changed (2019-11-19):
[0000858877-19-000018:note_history:11]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Balance at beginning of period | $ | 342 |  |  | $ | 359 |  |
| Provisions for warranties issued | 140 |  |  | 156 |  |
| Adjustments for pre-existing warranties | (3 | ) |  | (3 | ) |
| Settlements | (149 | ) |  | (145 | ) |
| Balance at end of period | $ | 330 |  |  | $ | 367 |  |
  (was, 2019-05-21, similarity 0.7971):
[0000858877-19-000007:note_history:11]
|  | Nine Months Ended |
|  | April 27, 2019 |  | April 28, 2018 |
| Balance at beginning of period | $ | 359 |  |  | $ | 407 |  |
| Provisions for warranties issued | 447 |  |  | 431 |  |
| Adjustments for pre-existing warranties | (6 | ) |  | (32 | ) |
| Settlements | (449 | ) |  | (441 | ) |
| Acquisitions and divestitures | (2 | ) |  | — |  |
| Balance at end of period | $ | 349 |  |  | $ | 365 |  |

- changed (2019-11-19):
[0000858877-19-000018:note_history:12]
| (d) | Financing and Other Guarantees |
  (was, 2019-05-21, similarity 0.975):
[0000858877-19-000007:note_history:12]
| (e) | Financing and Other Guarantees |

- changed (2019-11-19):
[0000858877-19-000018:note_history:13]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.6 billion and $7.2 billion for the first quarter of fiscal 2020 and 2019, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.4 billion as of October 26, 2019 and July 27, 2019, respectively.
  (was, 2019-05-21, similarity 0.918):
[0000858877-19-000007:note_history:13]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.2 billion and $7.1 billion for the third quarter of fiscal 2019 and 2018, respectively, and was $21.7 billion and $20.7 billion for the first nine months of fiscal 2019 and 2018, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.0 billion as of April 27, 2019 and July 28, 2018, respectively.

- changed (2019-11-19):
[0000858877-19-000018:note_history:14]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $5 million and $3 million for the first quarter of fiscal 2020 and 2019, respectively.
  (was, 2019-05-21, similarity 0.8877):
[0000858877-19-000007:note_history:14]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $1 million and $3 million for the third quarter of fiscal 2019 and 2018, respectively, and was $11 million and $29 million for the first nine months of fiscal 2019 and 2018, respectively.

- changed (2019-11-19):
[0000858877-19-000018:note_history:15]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 26, 2019 and July 27, 2019, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2019-05-21, similarity 0.9807):
[0000858877-19-000007:note_history:15]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 27, 2019 and July 28, 2018, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2019-11-19):
[0000858877-19-000018:note_history:16]
|  | October 26, 2019 |  | July 27, 2019 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 148 |  |  | $ | 197 |  |
| End user | 15 |  |  | 21 |  |
| Total | $ | 163 |  |  | $ | 218 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (61 | ) |  | $ | (62 | ) |
| End user | (15 | ) |  | (15 | ) |
| Total | $ | (76 | ) |  | $ | (77 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 87 |  |  | $ | 141 |  |
  (was, 2019-05-21, similarity 0.9885):
[0000858877-19-000007:note_history:16]
|  | April 27, 2019 |  | July 28, 2018 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 221 |  |  | $ | 277 |  |
| End user | 19 |  |  | 31 |  |
| Total | $ | 240 |  |  | $ | 308 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (63 | ) |  | $ | (94 | ) |
| End user | (18 | ) |  | (28 | ) |
| Total | $ | (81 | ) |  | $ | (122 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 159 |  |  | $ | 186 |  |

- changed (2019-11-19):
[0000858877-19-000018:note_history:17]
| (e) | Indemnifications |
  (was, 2019-05-21, similarity 0.9615):
[0000858877-19-000007:note_history:17]
| (f) | Indemnifications |

- changed (2019-11-19):
[0000858877-19-000018:note_history:18]
Charter Communications, Inc., which acquired Time Warner Cable (“TWC”) in May 2016, is seeking indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Sprint sought monetary damages, alleging that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied TWC's post-trial motions. TWC appealed to the U.S. Court of Appeals for the Federal Circuit, and, on November 30, 2018, a panel of the court affirmed the judgment. TWC filed a petition for rehearing en banc on January 29, 2019, which was denied on March 19, 2019. TWC petitioned the U.S. Supreme Court for review of the judgment, which was denied on November 4, 2019. At this time, we do not believe that our indemnity obligations under our agreement will be material.
  (was, 2019-05-21, similarity 0.7622):
[0000858877-19-000007:note_history:18]
We have been asked to indemnify Time Warner Cable (“TWC”) for patent infringement claims asserted against it by Sprint Communications Company, L.P. (“Sprint”) in federal court in Kansas. Sprint alleges that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied TWC's post-trial motions. TWC appealed to the U.S. Court of Appeals for the Federal Circuit, and, on November 30, 2018, a panel of the court affirmed the judgment. TWC filed a petition for rehearing en banc on January 29, 2019, which was denied on March 19, 2019. At this time, we do not believe that our indemnity obligations under our agreement would be material.

- changed (2019-11-19):
[0000858877-19-000018:note_history:19]
| (f) | Legal Proceedings |
  (was, 2019-05-21, similarity 0.963):
[0000858877-19-000007:note_history:19]
| (g) | Legal Proceedings |

- changed (2019-11-19):
[0000858877-19-000018:note_history:20]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $202 million for the alleged evasion of import and other taxes, $1.4 billion for interest, and $0.9 billion for various penalties, all determined using an exchange rate as of October 26, 2019. We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.
  (was, 2019-05-21, similarity 0.9946):
[0000858877-19-000007:note_history:20]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $206 million for the alleged evasion of import and other taxes, $1.3 billion for interest, and $1.0 billion for various penalties, all determined using an exchange rate as of April 27, 2019. We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

- added (2019-11-19):
[0000858877-19-000018:note_history:21]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and, on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit on various grounds, a panel of which, after various proceedings, on July 12, 2019, issued an opinion vacating the enhanced damages award; vacating and remanding in part the willful infringement finding; vacating and remanding the attorneys’ fees award for further proceedings; and affirming the district court's other findings. Cisco paid SRI $28.1 million, representing the portion of the judgment that the Federal Circuit affirmed, plus interest and royalties on post-verdict sales. This payment is subject to a refund if any portion of the affirmed judgment is reversed or vacated by the U.S. Supreme Court. On November 8, 2019, Cisco filed a petition for a writ of certiorari with the U.S. Supreme Court, seeking review of the judgment on the grounds that the asserted patents describe patent-ineligible subject matter. While the remanded proceedings may result in an additional loss, we do not expect it to be material.

- changed (2019-11-19):
[0000858877-19-000018:note_history:22]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against us and cancelling a trial which had been set for March 12, 2018. Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit, and, on January 23, 2019, the court summarily affirmed the finding of non-infringement. On August 23, 2019, Straight Path filed a petition with the United States Supreme Court challenging the constitutionality of the Federal Circuit’s rule allowing summary affirmance, which was denied on November 18, 2019.
  (was, 2019-05-21, similarity 0.8903):
[0000858877-19-000007:note_history:22]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against us and cancelling a trial which had been set for March 12, 2018. Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit, and, on January 23, 2019, the court summarily affirmed the finding of non-infringement.

- changed (2019-11-19):
[0000858877-19-000018:note_history:23]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the court consolidated the cases alleging infringement of the ‘327 Patent. Oyster's cases against some of the defendants were resolved. The court vacated the November 4, 2018 trial date set for Oyster's claims against Cisco and one other remaining defendant, pending resolution of Oyster's appeal of the court's summary judgment ruling dismissing certain of Oyster's claims. Oyster appealed the summary judgment ruling on December 6, 2018. While we believe that we have strong non-infringement arguments and that the patent is invalid, if Oyster prevails in its appeal of the summary judgment ruling, and if we do not prevail in the District Court in a subsequent trial, we believe damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, we are unable to reasonably estimate the ultimate outcome of this litigation at this time. However, we do not anticipate that any final outcome of the dispute would be material.
  (was, 2019-05-21, similarity 0.7503):
[0000858877-19-000007:note_history:23]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the court consolidated the cases alleging infringement of the ‘327 Patent. Oyster's cases against some of the defendants were resolved. The court vacated the November 4, 2018 trial date set for Oyster's claims against Cisco and one other remaining defendant, pending resolution of Oyster's appeal of the court's summary judgment ruling dismissing certain of Oyster's claims. Oyster appealed the summary judgment ruling on December 6, 2018. While we believe that we have strong non-infringement arguments and that the patent is invalid, if we do not prevail in the District Court, we believe damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, we are unable to reasonably estimate the ultimate outcome of this litigation at this time. However, we do not anticipate that any final outcome of the dispute would be material.

- removed (2019-11-19):
[0000858877-19-000007:note_history:24]
| (a) | Operating Leases |

- removed (2019-11-19):
[0000858877-19-000007:note_history:25]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Australia, Belgium, Canada, China, Germany, India, Japan, Mexico, Poland and the United Kingdom. We also lease equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 27, 2019 are as follows (in millions):

- removed (2019-11-19):
[0000858877-19-000007:note_history:26]
| Fiscal Year | Amount |
| 2019 (remaining three months) | $ | 111 |  |
| 2020 | 372 |  |
| 2021 | 257 |  |
| 2022 | 177 |  |
| 2023 | 112 |  |
| Thereafter | 121 |  |
| Total | $ | 1,150 |  |

- removed (2019-11-19):
[0000858877-19-000007:note_history:27]
Other Guarantees   Our other guarantee arrangements as of April 27, 2019 and July 28, 2018 that were subject to recognition and disclosure requirements were not material.

- removed (2019-11-19):
[0000858877-19-000007:note_history:28]
During the first nine months of fiscal 2018, we recorded legal and indemnification settlement charges of $127 million to product cost of sales related to prior indemnification matters resolved in fiscal 2018.

- removed (2019-11-19):
[0000858877-19-000007:note_history:29]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and, on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit on various grounds. On March 20, 2019, the Federal Circuit vacated the enhanced damages award; vacated and remanded in part the willful infringement finding; and affirmed the district court's other findings. Cisco filed a petition for rehearing with the Federal Circuit on May 10, 2019. While the ultimate outcome of the case may still result in a loss, we do not expect it to be material.

- removed (2019-11-19):
[0000858877-19-000007:note_history:30]
Arista Networks, Inc.     As reported in our Form 10-K for the fiscal year ended July 28, 2018 we received a payment of $400 million from Arista Networks, Inc. ("Arista") in connection with the settlement of litigation. The payment was recognized in general and administrative expenses in our first quarter of fiscal 2019.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-11-19):
[0000858877-19-000018:note_history:31]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported

- changed (2019-11-19):
[0000858877-19-000018:note_history:32]
purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.
  (was, 2019-05-21, similarity 0.6506):
[0000858877-19-000007:note_history:32]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

- removed (2019-11-19):
[0000858877-19-000007:note_history:33]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-11-19):
[0000858877-19-000018:note_history:34]
We have prepared the accompanying financial data as of October 26, 2019 and for the first quarter of fiscal 2020 and fiscal 2019, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2019 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2019.
  (was, 2019-05-21, similarity 0.9712):
[0000858877-19-000007:note_history:34]
We have prepared the accompanying financial data as of April 27, 2019 and for the third quarter and first nine months of fiscal 2019 and fiscal 2018, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 28, 2018 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 28, 2018.

- added (2019-11-19):
[0000858877-19-000018:note_history:35]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 26, 2019, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2020 and fiscal 2019, as applicable, have been made. The results of operations for the first quarter of fiscal 2020 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2019-11-19):
[0000858877-19-000007:note_history:36]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of April 27, 2019; the results of operations and the statements of comprehensive income (loss) for the third quarter and first nine months of fiscal 2019 and fiscal 2018; the statements of cash flows for the first nine months of fiscal 2019 and fiscal 2018; and the statements of equity for the third quarter and first nine months of fiscal 2019 and fiscal 2018, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2019 and fiscal 2018 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-11-19):
[0000858877-19-000018:note_history:37]
Leases  In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Codification (ASC) 842, Leases, a new standard requiring lessees to recognize operating and finance lease liabilities on the balance sheet, as well as corresponding right-of-use (ROU) assets. This standard also made some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, new disclosures are required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. ASC 842 requires adoption using the modified retrospective approach, with the option of applying the requirements of the standard either i) retrospectively to each prior comparative reporting period presented, or ii) retrospectively at the beginning of the period of adoption. We adopted this standard at the beginning of our first quarter of fiscal 2020 and applied it at the beginning of the period of adoption and did not restate prior periods. We adopted ASC 842 on July 28, 2019 which resulted in the recognition of $1.2 billion of operating lease ROU assets included in other assets and $1.2 billion of operating lease liabilities included in other current liabilities and other long-term liabilities. There were no transition adjustments recorded from the adoption of ASC 842 as a lessor.

- added (2019-11-19):
[0000858877-19-000018:note_history:38]
We have elected to apply the package of practical expedients permitted under the transition guidance within ASC 842 which does not require reassessment of initial direct costs, classification of a lease and definition of a lease. We also elected additional practical expedients which resulted in: i) allowing us not to reassess the accounting treatment for existing or expired land easements in transition; ii) combining lease and non-lease components and iii) not recording leases with an initial term of less than 12 months on our Consolidated Balance Sheet.

- added (2019-11-19):
[0000858877-19-000018:note_history:39]
As a lessee, we determine if an arrangement is a lease at commencement. Our ROU lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments related to the lease. Operating lease ROU assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. We use incremental borrowing rates based on information available at the commencement date to determine the present value of our lease payments.

- added (2019-11-19):
[0000858877-19-000018:note_history:40]
As a lessor, we determine if an arrangement is a lease at inception. We provide leasing arrangements for our equipment to certain qualified customers. Our lease portfolio primarily consists of sales-type leases. We allocate the consideration in a bundled contract with our customers based on relative standalone selling prices of our lease and non-lease components. The residual value on our leased equipment is determined at the inception of the lease based on an analysis of estimates of the value of equipment, market factors and historical customer behavior. Residual value estimates are reviewed on a periodic basis and other-than-temporary declines are expensed in the period they occur. Our leases generally provide an end-of-term option for the customer to extend the lease under mutually-agreed terms, return the leased equipment, or purchase the equipment for either the then-market value of the equipment or a pre-determined purchase price. If a customer chooses to terminate their lease prior to the original end of term date, the customer is required to pay all remaining lease payments in full.

- added (2019-11-19):
[0000858877-19-000018:note_history:41]
For additional information, see Note 8.

- changed (2019-11-19):
[0000858877-19-000018:note_history:42]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2021 on a modified retrospective basis. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.
  (was, 2019-05-21, similarity 0.7132):
[0000858877-19-000007:note_history:42]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2021 and early adoption in fiscal 2020 is permitted. We expect to adopt this accounting standard update on a modified retrospective basis in the first quarter of fiscal 2021, and we are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.

- removed (2019-11-19):
[0000858877-19-000007:note_history:43]
Revenue Recognition  In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers, a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP on revenue recognition and eliminated industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. It also requires increased disclosures including the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

- removed (2019-11-19):
[0000858877-19-000007:note_history:44]
ASC 606 allows two methods of adoption: i) retrospectively to each prior period presented (“full retrospective method”), or ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective method"). At the beginning of the first quarter of fiscal 2019, we adopted ASC 606 using the modified retrospective method to those contracts that were not completed as of July 28, 2018. Refer to Opening Balance Adjustments below for the impact of adoption on our Consolidated Financial Statements.

- removed (2019-11-19):
[0000858877-19-000007:note_history:45]
We have implemented new accounting policies, systems, processes, and internal controls necessary to support the requirements of ASC 606.

- removed (2019-11-19):
[0000858877-19-000007:note_history:46]
ASC 606 primarily impacts our revenue recognition for software arrangements and sales to two-tier distributors. In both areas, the new standard accelerates the recognition of revenue.

- removed (2019-11-19):
[0000858877-19-000007:note_history:47]
The table below details the timing of when revenue was typically recognized under the prior revenue standard compared to the timing of when revenue is typically recognized under ASC 606 for these major areas:

- removed (2019-11-19):
[0000858877-19-000007:note_history:48]
|  |  | Prior Revenue Standard |  | ASC 606 |
| Software arrangements: |  |  |  |  |
| Perpetual software licenses |  | Upfront |  | Upfront |
| Term software licenses |  | Ratable |  | Upfront |
| Security software licenses |  | Ratable |  | Ratable |
| Enterprise license agreements (software licenses) |  | Ratable |  | Upfront |
| Software support (maintenance) |  | Ratable |  | Ratable |
| Software-as-a-service |  | Ratable |  | Ratable |
| Two-tier distribution |  | Sell-Through |  | Sell-In |

- removed (2019-11-19):
[0000858877-19-000007:note_history:49]
In addition to the above revenue recognition timing impacts, ASC 606 requires incremental contract acquisition costs (such as sales commissions) for customer contracts to be capitalized and amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the assets relates.

- removed (2019-11-19):
[0000858877-19-000007:note_history:50]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

- removed (2019-11-19):
[0000858877-19-000007:note_history:51]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or once delivery and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

- removed (2019-11-19):
[0000858877-19-000007:note_history:52]
Significant Judgments

- removed (2019-11-19):
[0000858877-19-000007:note_history:53]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

- removed (2019-11-19):
[0000858877-19-000007:note_history:54]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes various rebate, cooperative marketing, and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

- removed (2019-11-19):
[0000858877-19-000007:note_history:55]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license's utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a distinct performance obligation satisfied over the contract term.

- removed (2019-11-19):
[0000858877-19-000007:note_history:56]
For the additional disclosures required as part of ASC 606 see Note 3.

- removed (2019-11-19):
[0000858877-19-000007:note_history:57]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The most significant impact of this accounting standard update is that it requires the remeasurement of investments not accounted for under the equity method to be recorded at fair value through the Consolidated Statement of Operations at the end of each reporting period. The application of this accounting standard update increases the variability of other income (loss), net.

- removed (2019-11-19):
[0000858877-19-000007:note_history:58]
Our equity investments are accounted for as follows:

- removed (2019-11-19):
[0000858877-19-000007:note_history:59]
| • | Marketable equity securities have readily determinable fair value (RDFV) that are measured and recorded at fair value. |

- removed (2019-11-19):
[0000858877-19-000007:note_history:60]
| • | Non-marketable equity securities do not have RDFV and are measured using a measurement alternative recorded at cost less any impairment, plus or minus changes resulting from qualifying observable price changes. For certain of these securities, we have elected to apply the net asset value (NAV) practical expedient. The NAV is the estimated fair value of these investments. |

- removed (2019-11-19):
[0000858877-19-000007:note_history:61]
| • | Equity method investments are securities we do not control, but are able to exert significant influence over the investee. These investments are measured at cost less any impairment, plus or minus our share of equity method investee income or loss. |

- removed (2019-11-19):
[0000858877-19-000007:note_history:62]
We adopted this accounting standard update beginning the first quarter of fiscal 2019. The standard was adopted using the modified retrospective method for our marketable equity securities and non-marketable equity securities measured using the NAV practical expedient. For our non-marketable equity securities measured using the measurement alternative, we applied the prospective method. Refer to Opening Balance Adjustments below for the impact of adoption on our Consolidated Balance Sheet.

- removed (2019-11-19):
[0000858877-19-000007:note_history:63]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a modified retrospective basis. The ongoing impact of this standard will be facts and circumstances dependent on any transactions within its scope. Refer to Opening Balance Adjustments below for the impact of adoption on our Consolidated Balance Sheet.

- removed (2019-11-19):
[0000858877-19-000007:note_history:64]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a retrospective basis. The application of this accounting standard update did not have an impact on our Consolidated Statements of Cash Flows.

- removed (2019-11-19):
[0000858877-19-000007:note_history:65]
Restricted Cash in Statement of Cash Flows  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented. The application of this accounting standard update did not have a material impact on our Consolidated Statements of Cash Flows. Prior period information has been retrospectively adjusted due to the adoption of ASU 2016-18, Statement of Cash Flows, Restricted Cash at the beginning of the first quarter of fiscal 2019.

- removed (2019-11-19):
[0000858877-19-000007:note_history:66]
Simplifying the Test for Goodwill Impairment  In January 2017, the FASB issued an accounting standard update that removes Step

- removed (2019-11-19):
[0000858877-19-000007:note_history:67]
2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. We early adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a prospective basis. The application of this accounting standard update did not have any impact on our Consolidated Financial Statements.

- removed (2019-11-19):
[0000858877-19-000007:note_history:68]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be fact dependent, but we expect that some transactions that were previously accounted for as business combinations or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.

- removed (2019-11-19):
[0000858877-19-000007:note_history:69]
Opening Balance Adjustments

- removed (2019-11-19):
[0000858877-19-000007:note_history:70]
The following table summarizes the cumulative effect of the changes made to the Consolidated Balance Sheet for the adoption of ASC 606, ASU 2016-01, Financial Instruments, and ASU 2016-16, Intra-Entity Transfers of Assets Other than Inventory (in millions):

- removed (2019-11-19):
[0000858877-19-000007:note_history:71]
| Line Item in Consolidated Balance Sheet: |  | Balance at July 28, 2018 |  | New Revenue Recognition Standard |  | New Financial Instruments Standard |  | New Intra-Entity Transfers Standard |  | Adjusted Balance at July 29, 2018 |
| ASSETS |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 5,554 |  |  | $ | (104 | ) | (1) | $ | — |  |  | $ | — |  |  | $ | 5,450 |  |
| Inventories |  | $ | 1,846 |  |  | $ | (302 | ) | (2) | $ | — |  |  | $ | — |  |  | $ | 1,544 |  |
| Other current assets (includes capitalized contract acquisition costs) |  | $ | 2,940 |  |  | $ | 371 |  | (3), (4) | $ | — |  |  | $ | (25 | ) | (3) | $ | 3,286 |  |
| Deferred tax assets |  | $ | 3,219 |  |  | $ | (624 | ) | (3) | $ | (15 | ) | (3) | $ | 1,415 |  | (8) | $ | 3,995 |  |
| Other assets (includes capitalized contract acquisition costs) |  | $ | 1,582 |  |  | $ | 327 |  | (4) | $ | 136 |  | (7) | $ | (91 | ) | (3) | $ | 1,954 |  |
| TOTAL ASSETS |  | $ | 108,784 |  |  | $ | (332 | ) |  | $ | 121 |  |  | $ | 1,299 |  |  | $ | 109,872 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |  |  |
| Income taxes payable |  | $ | 1,004 |  |  | $ | — |  |  | $ | — |  |  | $ | 11 |  | (3) | $ | 1,015 |  |
| Deferred revenue — current |  | $ | 11,490 |  |  | $ | (1,702 | ) | (5) | $ | — |  |  | $ | — |  |  | $ | 9,788 |  |
| Other current liabilities |  | $ | 4,413 |  |  | $ | 33 |  | (6) | $ | — |  |  | $ | — |  |  | $ | 4,446 |  |
| Deferred revenue — non-current |  | $ | 8,195 |  |  | $ | (1,081 | ) | (5) | $ | — |  |  | $ | — |  |  | $ | 7,114 |  |
| Other long-term liabilities |  | $ | 1,434 |  |  | $ | 85 |  | (3) | $ | 13 |  | (3) | $ | — |  |  | $ | 1,532 |  |
| Retained earnings |  | $ | 1,233 |  |  | $ | 2,333 |  | (10) | $ | 283 |  | (10) | $ | 1,281 |  | (10) | $ | 5,130 |  |
| Accumulated other comprehensive income (loss) |  | $ | (849 | ) |  | $ | — |  |  | $ | (175 | ) | (9) | $ | 7 |  | (3) | $ | (1,017 | ) |
| TOTAL LIABILITIES AND EQUITY |  | $ | 108,784 |  |  | $ | (332 | ) |  | $ | 121 |  |  | $ | 1,299 |  |  | $ | 109,872 |  |

- removed (2019-11-19):
[0000858877-19-000007:note_history:72]
(1) Primarily represents the decrease to accounts receivable related to the change in recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis

- removed (2019-11-19):
[0000858877-19-000007:note_history:73]
(2) Primarily represents the reduction of inventory for the change from recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis

- removed (2019-11-19):
[0000858877-19-000007:note_history:74]
(3) Includes the impacts to deferred tax assets, liabilities and other income tax balances

- removed (2019-11-19):
[0000858877-19-000007:note_history:75]
(4) Primarily represents capitalized contract acquisition costs (e.g. commissions)

- removed (2019-11-19):
[0000858877-19-000007:note_history:76]
(5) Primarily represents deferred revenue adjusted to retained earnings primarily due to the change in revenue recognition for certain software arrangements from ratable to upfront, recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis. Of this total $2.8 billion adjustment, $2.6 billion related to product deferred revenue, of which $1.3 billion relates to our recurring software and subscription offers, $0.6 billion relates to two-tier distribution, and the remainder relates to non-recurring software and other adjustments.

- removed (2019-11-19):
[0000858877-19-000007:note_history:77]
(6) Primarily represents the reclassification of accounts receivable contra balances to other current liabilities, adjustments to rebate liabilities for the change from recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis, and reclassifications from other current liabilities for amounts that are not contract liabilities under ASC 606

- removed (2019-11-19):
[0000858877-19-000007:note_history:78]
(7) Represents the adjustment due to the remeasurement of non-marketable equity investments at fair value

- removed (2019-11-19):
[0000858877-19-000007:note_history:79]
(8) Primarily represents the change in net deferred tax assets related to unrecognized income tax effects of intra-entity asset transfers

- removed (2019-11-19):
[0000858877-19-000007:note_history:80]
(9) Represents the reclassification of net unrealized gains from accumulated other comprehensive income (loss) to retained earnings

- removed (2019-11-19):
[0000858877-19-000007:note_history:81]
(10) Retained earnings impact from the adjustments noted above

- removed (2019-11-19):
[0000858877-19-000007:note_history:82]
Impact of ASC 606 Adoption

- removed (2019-11-19):
[0000858877-19-000007:note_history:83]
The application of ASC 606 increased our total revenue by $146 million and $662 million in the third quarter and first nine months of fiscal 2019, respectively. The application of ASC 606 did not have a material impact to either our cost of sales or our operating expenses in the third quarter and first nine months of fiscal 2019. We recognized a $152 million benefit to our provision for income taxes relating to indirect effects from the adoption of ASC 606 in the first quarter of fiscal 2019. For additional information regarding ASC 606, see Note 3 to the Consolidated Financial Statements.

- removed (2019-11-19):
[0000858877-19-000007:note_history:84]
In connection with the adoption of ASC 606, we recorded a transition adjustment to increase retained earnings by $2.3 billion. See above for the transition impact of ASC 606 by balance sheet line item. As of April 27, 2019, the balance sheet changes attributable to ASC 606 related to accounts receivable, inventories, and deferred revenue were not materially different than the impacts upon adoption. In connection with the adoption of ASC 606, we established contract assets for unbilled receivables. As of April 27, 2019, we had total contract assets of $637 million, of which $254 million was recorded in other current assets and $383 million was recorded in other assets. As of April 27, 2019, we had total capitalized contract acquisition costs of $705 million, of which $390 million was recorded in other current assets and $315 million was recorded in other assets. The adoption of ASC 606 did not have any impact on net cash provided by operating activities.

- removed (2019-11-19):
[0000858877-19-000007:note_history:85]
Leases  In February 2016, the FASB issued an accounting standard update and subsequent amendments related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2020 and early adoption is permitted. We expect to adopt this accounting standard update on a modified retrospective basis in the first quarter of fiscal 2020, and we are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-19):
[0000858877-19-000018:note_history:86]
|  | October 26, 2019 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,000 |  |  | 3.70 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 4,000 |  |  |  |  | $ | 10,191 |  |  |  |
  (was, 2019-05-21, similarity 0.9181):
[0000858877-19-000007:note_history:86]
|  | April 27, 2019 |  | July 28, 2018 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,494 |  |  | 3.52 | % |  | $ | 5,238 |  |  | 3.46 | % |
| Commercial paper | 3,283 |  |  | 2.53 | % |  | — |  |  | — | % |
| Total short-term debt | $ | 7,777 |  |  |  |  | $ | 5,238 |  |  |  |

- changed (2019-11-19):
[0000858877-19-000018:note_history:87]
|  |  |  | October 26, 2019 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.39% |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.77% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.95% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.89% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 18,500 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (97 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 94 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 18,497 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,000 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 14,497 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 18,497 |  |  |  |  | $ | 20,473 |  |  |  |
  (was, 2019-05-21, similarity 0.9056):
[0000858877-19-000007:note_history:87]
|  |  |  | April 27, 2019 |  | July 28, 2018 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | $ | — |  |  | —% |  | $ | 500 |  |  | 2.86% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 3.01% |  | 500 |  |  | 2.71% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.95% | February 15, 2019 |  | — |  |  | —% |  | 2,000 |  |  | 5.17% |
| 1.60% | February 28, 2019 |  | — |  |  | —% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | — |  |  | —% |  | 1,750 |  |  | 2.71% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.84% |  | 2,500 |  |  | 4.52% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 3.25% |  | 500 |  |  | 2.86% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 3.51% |  | 500 |  |  | 3.11% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 3.37% |  | 1,000 |  |  | 2.98% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.67% |  | 500 |  |  | 3.27% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 20,500 |  |  |  |  | 25,750 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (103 | ) |  |  |  | (116 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 18 |  |  |  |  | (65 | ) |  |  |
| Total |  |  | $ | 20,415 |  |  |  |  | $ | 25,569 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,494 |  |  |  |  | $ | 5,238 |  |  |  |
| Long-term debt |  |  | 15,921 |  |  |  |  | 20,331 |  |  |  |
| Total |  |  | $ | 20,415 |  |  |  |  | $ | 25,569 |  |  |  |

- changed (2019-11-19):
[0000858877-19-000018:note_history:88]
We entered into interest rate swaps in prior periods with an aggregate notional amount of $4.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (“LIBOR”). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.
  (was, 2019-05-21, similarity 0.9884):
[0000858877-19-000007:note_history:88]
We entered into interest rate swaps in prior periods with an aggregate notional amount of $4.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate ("LIBOR"). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 12.

- changed (2019-11-19):
[0000858877-19-000018:note_history:89]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 26, 2019, we were in compliance with all debt covenants.
  (was, 2019-05-21, similarity 0.9877):
[0000858877-19-000007:note_history:89]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 27, 2019, we were in compliance with all debt covenants.

- changed (2019-11-19):
[0000858877-19-000018:note_history:90]
As of October 26, 2019, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2019-05-21, similarity 0.9627):
[0000858877-19-000007:note_history:90]
As of April 27, 2019, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2019-11-19):
[0000858877-19-000018:note_history:91]
| Fiscal Year | Amount |
| 2020 (remaining nine months) | $ | 4,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 18,500 |  |
  (was, 2019-05-21, similarity 0.9707):
[0000858877-19-000007:note_history:91]
| Fiscal Year | Amount |
| 2019 (remaining three months) | $ | — |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| Thereafter | 8,500 |  |
| Total | $ | 20,500 |  |

- changed (2019-11-19):
[0000858877-19-000018:note_history:92]
This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of October 26, 2019, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under this credit facility.
  (was, 2019-05-21, similarity 0.9812):
[0000858877-19-000007:note_history:92]
This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of April 27, 2019, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under this credit facility.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-19):
[0000858877-19-000018:note_history:93]
|  | October 26, 2019 |  | July 27, 2019 |
| Available-for-sale debt investments | $ | 19,445 |  |  | $ | 21,660 |  |
| Marketable equity securities | 3 |  |  | 3 |  |
| Total investments | 19,448 |  |  | 21,663 |  |
| Non-marketable equity securities included in other assets (1) | 1,151 |  |  | 1,113 |  |
| Equity method investments included in other assets | 66 |  |  | 87 |  |
| Total | $ | 20,665 |  |  | $ | 22,863 |  |
  (was, 2019-05-21, similarity 0.9831):
[0000858877-19-000007:note_history:93]
|  | April 27, 2019 |  | July 28, 2018 |
| Available-for-sale debt investments | $ | 24,387 |  |  | $ | 37,009 |  |
| Marketable equity securities | 5 |  |  | 605 |  |
| Total investments | 24,392 |  |  | 37,614 |  |
| Non-marketable equity securities included in other assets (1) | 1,135 |  |  | 978 |  |
| Equity method investments included in other assets | 115 |  |  | 118 |  |
| Total | $ | 25,642 |  |  | $ | 38,710 |  |

- added (2019-11-19):
[0000858877-19-000018:note_history:94]
(1) We held equity interests in certain private equity funds of $0.7 billion and $0.6 billion as of October 26, 2019 and July 27, 2019, respectively, which are accounted for under the NAV practical expedient.

- changed (2019-11-19):
[0000858877-19-000018:note_history:95]
| October 26, 2019 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 1,322 |  |  | $ | 3 |  |  | $ | (1 | ) |  | $ | 1,324 |  |
| U.S. government agency securities | 98 |  |  | — |  |  | — |  |  | 98 |  |
| Corporate debt securities | 16,057 |  |  | 153 |  |  | (11 | ) |  | 16,199 |  |
| U.S. agency mortgage-backed securities | 1,509 |  |  | 9 |  |  | (8 | ) |  | 1,510 |  |
| Commercial paper | 283 |  |  | — |  |  | — |  |  | 283 |  |
| Certificates of deposit | 31 |  |  | — |  |  | — |  |  | 31 |  |
| Total | $ | 19,300 |  |  | $ | 165 |  |  | $ | (20 | ) |  | $ | 19,445 |  |
  (was, 2019-05-21, similarity 0.7535):
[0000858877-19-000007:note_history:95]
| April 27, 2019 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 1,455 |  |  | $ | 1 |  |  | $ | (4 | ) |  | $ | 1,452 |  |
| U.S. government agency securities | 264 |  |  | — |  |  | (1 | ) |  | 263 |  |
| Corporate debt securities | 21,307 |  |  | 40 |  |  | (115 | ) |  | 21,232 |  |
| U.S. agency mortgage-backed securities | 1,465 |  |  | 3 |  |  | (28 | ) |  | 1,440 |  |
| Total (1) | $ | 24,491 |  |  | $ | 44 |  |  | $ | (148 | ) |  | $ | 24,387 |  |

- changed (2019-11-19):
[0000858877-19-000018:note_history:96]
| July 27, 2019 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 808 |  |  | $ | 1 |  |  | $ | (1 | ) |  | $ | 808 |  |
| U.S. government agency securities | 169 |  |  | — |  |  | — |  |  | 169 |  |
| Corporate debt securities | 19,188 |  |  | 103 |  |  | (29 | ) |  | 19,262 |  |
| U.S. agency mortgage-backed securities | 1,425 |  |  | 7 |  |  | (11 | ) |  | 1,421 |  |
| Total | $ | 21,590 |  |  | $ | 111 |  |  | $ | (41 | ) |  | $ | 21,660 |  |
  (was, 2019-05-21, similarity 0.8029):
[0000858877-19-000007:note_history:96]
| July 28, 2018 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 7,318 |  |  | $ | — |  |  | $ | (43 | ) |  | $ | 7,275 |  |
| U.S. government agency securities | 732 |  |  | — |  |  | (5 | ) |  | 727 |  |
| Non-U.S. government and agency securities | 209 |  |  | — |  |  | (1 | ) |  | 208 |  |
| Corporate debt securities | 27,765 |  |  | 44 |  |  | (445 | ) |  | 27,364 |  |
| U.S. agency mortgage-backed securities | 1,488 |  |  | — |  |  | (53 | ) |  | 1,435 |  |
| Total (1) | $ | 37,512 |  |  | $ | 44 |  |  | $ | (547 | ) |  | $ | 37,009 |  |

- added (2019-11-19):
[0000858877-19-000018:note_history:97]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Gross realized gains | $ | 12 |  |  | $ | 2 |  |
| Gross realized losses | (2 | ) |  | (8 | ) |
| Total | $ | 10 |  |  | $ | (6 | ) |

- changed (2019-11-19):
[0000858877-19-000018:note_history:98]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 26, 2019 and July 27, 2019 (in millions):
  (was, 2019-05-21, similarity 0.9716):
[0000858877-19-000007:note_history:98]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 27, 2019 and July 28, 2018 (in millions):

- changed (2019-11-19):
[0000858877-19-000018:note_history:99]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 26, 2019 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 479 |  |  | $ | (1 | ) |  | $ | 25 |  |  | $ | — |  |  | $ | 504 |  |  | $ | (1 | ) |
| U.S. government agency securities | — |  |  | — |  |  | 98 |  |  | — |  |  | 98 |  |  | — |  |
| Corporate debt securities | 1,642 |  |  | (4 | ) |  | 1,200 |  |  | (7 | ) |  | 2,842 |  |  | (11 | ) |
| U.S. agency mortgage-backed securities | 378 |  |  | (1 | ) |  | 462 |  |  | (7 | ) |  | 840 |  |  | (8 | ) |
| Commercial paper | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |  | — |  |
| Certificates of deposit | 6 |  |  | — |  |  | — |  |  | — |  |  | 6 |  |  | — |  |
| Total | $ | 2,530 |  |  | $ | (6 | ) |  | $ | 1,785 |  |  | $ | (14 | ) |  | $ | 4,315 |  |  | $ | (20 | ) |
  (was, 2019-05-21, similarity 0.6719):
[0000858877-19-000007:note_history:99]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 27, 2019 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 8 |  |  | $ | — |  |  | $ | 1,409 |  |  | $ | (4 | ) |  | $ | 1,417 |  |  | $ | (4 | ) |
| U.S. government agency securities | — |  |  | — |  |  | 263 |  |  | (1 | ) |  | 263 |  |  | (1 | ) |
| Corporate debt securities | 1,851 |  |  | (7 | ) |  | 12,662 |  |  | (108 | ) |  | 14,513 |  |  | (115 | ) |
| U.S. agency mortgage-backed securities | 48 |  |  | — |  |  | 1,155 |  |  | (28 | ) |  | 1,203 |  |  | (28 | ) |
| Total | $ | 1,907 |  |  | $ | (7 | ) |  | $ | 15,489 |  |  | $ | (141 | ) |  | $ | 17,396 |  |  | $ | (148 | ) |

- added (2019-11-19):
[0000858877-19-000018:note_history:100]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2019 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 204 |  |  | $ | — |  |  | $ | 488 |  |  | $ | (1 | ) |  | $ | 692 |  |  | $ | (1 | ) |
| U.S. government agency securities | — |  |  | — |  |  | 169 |  |  | — |  |  | 169 |  |  | — |  |
| Corporate debt securities | 2,362 |  |  | (4 | ) |  | 5,271 |  |  | (25 | ) |  | 7,633 |  |  | (29 | ) |
| U.S. agency mortgage-backed securities | 123 |  |  | — |  |  | 847 |  |  | (11 | ) |  | 970 |  |  | (11 | ) |
| Total | $ | 2,689 |  |  | $ | (4 | ) |  | $ | 6,775 |  |  | $ | (37 | ) |  | $ | 9,464 |  |  | $ | (41 | ) |

- added (2019-11-19):
[0000858877-19-000018:note_history:101]
For available-for-sale debt investments that were in an unrealized loss position as of October 26, 2019, we have determined that no other-than-temporary impairments were required to be recognized.

- changed (2019-11-19):
[0000858877-19-000018:note_history:102]
The following table summarizes the maturities of our available-for-sale debt investments as of October 26, 2019 (in millions):
  (was, 2019-05-21, similarity 0.9583):
[0000858877-19-000007:note_history:102]
The following table summarizes the maturities of our available-for-sale debt investments as of April 27, 2019 (in millions):

- changed (2019-11-19):
[0000858877-19-000018:note_history:103]
We recorded adjustments to the carrying value of our non-marketable equity securities measured using the measurement alternative as follows (in millions):
  (was, 2019-05-21, similarity 0.8392):
[0000858877-19-000007:note_history:103]
We recorded adjustments to the carrying value of our non-marketable equity securities measured using the measurement alternative during the third quarter and first nine months of fiscal 2019 as follows (in millions):

- added (2019-11-19):
[0000858877-19-000018:note_history:104]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |  |  |
| Upward adjustments | $ | 1 |  |  | $ | 10 |  |
| Downward adjustments, including impairments | (2 | ) |  | (16 | ) |
| Net adjustments | $ | (1 | ) |  | $ | (6 | ) |

- changed (2019-11-19):
[0000858877-19-000018:note_history:105]
Gains and losses recognized on our marketable and non-marketable equity securities are summarized below (in millions):
  (was, 2019-05-21, similarity 0.8082):
[0000858877-19-000007:note_history:105]
Gains and losses recognized on our marketable and non-marketable equity securities for the third quarter and first nine months of fiscal 2019 are summarized below (in millions):

- added (2019-11-19):
[0000858877-19-000018:note_history:106]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Net gains and losses recognized during the period on equity investments | $ | 7 |  |  | $ | 8 |  |
| Less: Net gains and losses recognized on equity investments sold | (8 | ) |  | (12 | ) |
| Net unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | (1 | ) |  | $ | (4 | ) |

- changed (2019-11-19):
[0000858877-19-000018:note_history:107]
We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending was $21 million and $0.5 billion for the first quarter of fiscal 2020 and 2019, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 26, 2019 and July 27, 2019, we had no outstanding securities lending transactions.
  (was, 2019-05-21, similarity 0.9831):
[0000858877-19-000007:note_history:107]
We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending was $1.3 billion and $0.3 billion for the first nine months of fiscal 2019 and 2018, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of April 27, 2019 and July 28, 2018, we had no outstanding securities lending transactions.

- changed (2019-11-19):
[0000858877-19-000018:note_history:108]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 26, 2019, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2019-05-21, similarity 0.8122):
[0000858877-19-000007:note_history:108]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 27, 2019, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- changed (2019-11-19):
[0000858877-19-000018:note_history:109]
As of October 26, 2019, the carrying value of investments in privately held companies was $1.2 billion. $659 million of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $311 million related to these privately held investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these privately held investments.
  (was, 2019-05-21, similarity 0.9899):
[0000858877-19-000007:note_history:109]
As of April 27, 2019, the carrying value of investments in privately held companies was $1.3 billion. $683 million of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $345 million related to these privately held investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these privately held investments.

- removed (2019-11-19):
[0000858877-19-000007:note_history:110]
(1) We held equity interests in certain private equity funds of $0.6 billion as of April 27, 2019 which are accounted for under the NAV practical expedient following the adoption of ASU 2016-01, Financial Instruments, in the first quarter of fiscal 2019.

- removed (2019-11-19):
[0000858877-19-000007:note_history:111]
(1) Net unsettled investment purchases were $1 million and net unsettled investment sales were $1.5 billion as of April 27, 2019 and July 28, 2018, respectively and were included in other current assets and other current liabilities.

- removed (2019-11-19):
[0000858877-19-000007:note_history:112]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

- removed (2019-11-19):
[0000858877-19-000007:note_history:113]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2019 |  | April 28, 2018 |  | April 27, 2019 |  | April 28, 2018 |
| Gross realized gains | $ | 7 |  |  | $ | 1 |  |  | $ | 10 |  |  | $ | 15 |  |
| Gross realized losses | (14 | ) |  | (40 | ) |  | (28 | ) |  | (146 | ) |
| Total | $ | (7 | ) |  | $ | (39 | ) |  | $ | (18 | ) |  | $ | (131 | ) |

- removed (2019-11-19):
[0000858877-19-000007:note_history:114]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 28, 2018 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 2,966 |  |  | $ | (20 | ) |  | $ | 4,303 |  |  | $ | (23 | ) |  | $ | 7,269 |  |  | $ | (43 | ) |
| U.S. government agency securities | 206 |  |  | (2 | ) |  | 521 |  |  | (3 | ) |  | 727 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 105 |  |  | (1 | ) |  | 103 |  |  | — |  |  | 208 |  |  | (1 | ) |
| Corporate debt securities | 16,990 |  |  | (344 | ) |  | 3,511 |  |  | (101 | ) |  | 20,501 |  |  | (445 | ) |
| U.S. agency mortgage-backed securities | 826 |  |  | (24 | ) |  | 581 |  |  | (29 | ) |  | 1,407 |  |  | (53 | ) |
| Total | $ | 21,093 |  |  | $ | (391 | ) |  | $ | 9,019 |  |  | $ | (156 | ) |  | $ | 30,112 |  |  | $ | (547 | ) |

- removed (2019-11-19):
[0000858877-19-000007:note_history:115]
There were no impairment charges related to our available-for-sale debt investments for the third quarter and first nine months of fiscal 2019, and for the corresponding periods of fiscal 2018. For available-for-sale debt investments that were in an unrealized loss position as of April 27, 2019, we have determined that no other-than-temporary impairments were required to be recognized.

- removed (2019-11-19):
[0000858877-19-000007:note_history:116]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2019 |  | April 27, 2019 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |  |  |
| Upward adjustments | $ | 9 |  |  | $ | 33 |  |
| Downward adjustments, including impairments | (4 | ) |  | (22 | ) |
| Net upward adjustments | $ | 5 |  |  | $ | 11 |  |

- removed (2019-11-19):
[0000858877-19-000007:note_history:117]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2019 |  | April 27, 2019 |
| Net gains and losses recognized during the period on equity investments | $ | 3 |  |  | $ | 78 |  |
| Less: Net gains and losses recognized on equity investments sold | (44 | ) |  | (51 | ) |
| Unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | (41 | ) |  | $ | 27 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-19):
[0000858877-19-000018:note_history:118]
|  |  |  | October 26, 2019 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.39% |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.77% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.95% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.89% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 18,500 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (97 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 94 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 18,497 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,000 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 14,497 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 18,497 |  |  |  |  | $ | 20,473 |  |  |  |
  (was, 2019-05-21, similarity 0.9056):
[0000858877-19-000007:note_history:118]
|  |  |  | April 27, 2019 |  | July 28, 2018 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | $ | — |  |  | —% |  | $ | 500 |  |  | 2.86% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 3.01% |  | 500 |  |  | 2.71% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.95% | February 15, 2019 |  | — |  |  | —% |  | 2,000 |  |  | 5.17% |
| 1.60% | February 28, 2019 |  | — |  |  | —% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | — |  |  | —% |  | 1,750 |  |  | 2.71% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.84% |  | 2,500 |  |  | 4.52% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 3.25% |  | 500 |  |  | 2.86% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 3.51% |  | 500 |  |  | 3.11% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 3.37% |  | 1,000 |  |  | 2.98% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.67% |  | 500 |  |  | 3.27% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 20,500 |  |  |  |  | 25,750 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (103 | ) |  |  |  | (116 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 18 |  |  |  |  | (65 | ) |  |  |
| Total |  |  | $ | 20,415 |  |  |  |  | $ | 25,569 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,494 |  |  |  |  | $ | 5,238 |  |  |  |
| Long-term debt |  |  | 15,921 |  |  |  |  | 20,331 |  |  |  |
| Total |  |  | $ | 20,415 |  |  |  |  | $ | 25,569 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-19):
[0000858877-19-000018:note_history:119]
As of October 26, 2019, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2019-05-21, similarity 0.9627):
[0000858877-19-000007:note_history:119]
As of April 27, 2019, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2019-11-19):
[0000858877-19-000018:note_history:120]
| Fiscal Year | Amount |
| 2020 (remaining nine months) | $ | 4,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 18,500 |  |
  (was, 2019-05-21, similarity 0.9707):
[0000858877-19-000007:note_history:120]
| Fiscal Year | Amount |
| 2019 (remaining three months) | $ | — |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| Thereafter | 8,500 |  |
| Total | $ | 20,500 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-19):
[0000858877-19-000018:note_history:121]
|  | October 26, 2019 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,000 |  |  | 3.70 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 4,000 |  |  |  |  | $ | 10,191 |  |  |  |
  (was, 2019-05-21, similarity 0.9181):
[0000858877-19-000007:note_history:121]
|  | April 27, 2019 |  | July 28, 2018 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,494 |  |  | 3.52 | % |  | $ | 5,238 |  |  | 3.46 | % |
| Commercial paper | 3,283 |  |  | 2.53 | % |  | — |  |  | — | % |
| Total short-term debt | $ | 7,777 |  |  |  |  | $ | 5,238 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-11-19):
[0000858877-19-000018:note_history:122]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 7,538 |  |  | $ | 7,622 |  |
| Applications | 1,499 |  |  | 1,419 |  |
| Security | 815 |  |  | 670 |  |
| Other Products | 26 |  |  | 178 |  |
| Total Product | 9,878 |  |  | 9,890 |  |
| Services | 3,281 |  |  | 3,182 |  |
| Total (1) | $ | 13,159 |  |  | $ | 13,072 |  |
  (was, 2019-05-21, similarity 0.6519):
[0000858877-19-000007:note_history:122]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2019 |  | April 28, 2018 |  | April 27, 2019 |  | April 28, 2018 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 7,545 |  |  | $ | 7,180 |  |  | $ | 22,315 |  |  | $ | 20,870 |  |
| Applications | 1,431 |  |  | 1,310 |  |  | 4,315 |  |  | 3,697 |  |
| Security | 707 |  |  | 583 |  |  | 2,016 |  |  | 1,725 |  |
| Other Products | 39 |  |  | 231 |  |  | 239 |  |  | 775 |  |
| Total Product | 9,722 |  |  | 9,304 |  |  | 28,885 |  |  | 27,067 |  |
| Services | 3,236 |  |  | 3,159 |  |  | 9,591 |  |  | 9,419 |  |
| Total (1) | $ | 12,958 |  |  | $ | 12,463 |  |  | $ | 38,476 |  |  | $ | 36,486 |  |

- changed (2019-11-19):
[0000858877-19-000018:note_history:123]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (“SPVSS”) business. Total revenue includes SPVSS business revenue of $168 million for the first quarter of fiscal 2019.
  (was, 2019-05-21, similarity 0.7057):
[0000858877-19-000007:note_history:123]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions ("SPVSS") business. Total revenue includes SPVSS business revenue of $0 and $219 million for the third quarter of fiscal 2019 and 2018, respectively, and $168 million and $697 million for the first nine months of fiscal 2019 and 2018, respectively.

- added (2019-11-19):
[0000858877-19-000018:note_history:124]
The following table presents revenue for groups of similar products and services (in millions):

- added (2019-11-19):
[0000858877-19-000018:note_history:125]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 7,538 |  |  | $ | 7,622 |  |
| Applications | 1,499 |  |  | 1,419 |  |
| Security | 815 |  |  | 670 |  |
| Other Products | 26 |  |  | 178 |  |
| Total Product | 9,878 |  |  | 9,890 |  |
| Services | 3,281 |  |  | 3,182 |  |
| Total (1) | $ | 13,159 |  |  | $ | 13,072 |  |

- added (2019-11-19):
[0000858877-19-000018:note_history:126]
Amounts may not sum due to rounding.

- added (2019-11-19):
[0000858877-19-000018:note_history:127]
(1) Includes SPVSS business revenue of $168 million for the first quarter of fiscal 2019.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-11-19):
[0000858877-19-000018:note_history:128]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

- added (2019-11-19):
[0000858877-19-000018:note_history:129]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

- added (2019-11-19):
[0000858877-19-000018:note_history:130]
Significant Judgments

- added (2019-11-19):
[0000858877-19-000018:note_history:131]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

- added (2019-11-19):
[0000858877-19-000018:note_history:132]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

- added (2019-11-19):
[0000858877-19-000018:note_history:133]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license's utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

- added (2019-11-19):
[0000858877-19-000018:note_history:134]
Infrastructure Platforms consist of our core networking technologies of switching, routing, wireless, and data center products that are designed to work together to deliver networking capabilities and transport and/or store data. These technologies consist of both hardware and software offerings, including software licenses and SaaS, that help our customers build networks, automate, orchestrate, integrate, and digitize data. We are shifting and expanding more of our business to software and subscriptions across our core networking portfolio. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2019-11-19):
[0000858877-19-000018:note_history:135]
Applications consists of offerings that utilize the core networking and data center platforms to provide their functions. The products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2019-11-19):
[0000858877-19-000018:note_history:136]
Security primarily includes our network security, cloud and email security, identity and access management, advanced threat protection, and unified threat management products. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers' network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2019-11-19):
[0000858877-19-000018:note_history:137]
Other Products primarily includes our cloud and system management products. These products include both hardware and software licenses. Our offerings in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control.

- added (2019-11-19):
[0000858877-19-000018:note_history:138]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and advanced services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Advanced services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

- added (2019-11-19):
[0000858877-19-000018:note_history:139]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for all of our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-11-19):
[0000858877-19-000018:note_history:140]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

- added (2019-11-19):
[0000858877-19-000018:note_history:141]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

- added (2019-11-19):
[0000858877-19-000018:note_history:142]
Significant Judgments

- added (2019-11-19):
[0000858877-19-000018:note_history:143]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

- added (2019-11-19):
[0000858877-19-000018:note_history:144]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

- added (2019-11-19):
[0000858877-19-000018:note_history:145]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license's utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

- changed (2019-11-19):
[0000858877-19-000018:note_history:146]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 7,538 |  |  | $ | 7,622 |  |
| Applications | 1,499 |  |  | 1,419 |  |
| Security | 815 |  |  | 670 |  |
| Other Products | 26 |  |  | 178 |  |
| Total Product | 9,878 |  |  | 9,890 |  |
| Services | 3,281 |  |  | 3,182 |  |
| Total (1) | $ | 13,159 |  |  | $ | 13,072 |  |
  (was, 2019-05-21, similarity 0.6519):
[0000858877-19-000007:note_history:146]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2019 |  | April 28, 2018 |  | April 27, 2019 |  | April 28, 2018 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 7,545 |  |  | $ | 7,180 |  |  | $ | 22,315 |  |  | $ | 20,870 |  |
| Applications | 1,431 |  |  | 1,310 |  |  | 4,315 |  |  | 3,697 |  |
| Security | 707 |  |  | 583 |  |  | 2,016 |  |  | 1,725 |  |
| Other Products | 39 |  |  | 231 |  |  | 239 |  |  | 775 |  |
| Total Product | 9,722 |  |  | 9,304 |  |  | 28,885 |  |  | 27,067 |  |
| Services | 3,236 |  |  | 3,159 |  |  | 9,591 |  |  | 9,419 |  |
| Total (1) | $ | 12,958 |  |  | $ | 12,463 |  |  | $ | 38,476 |  |  | $ | 36,486 |  |

- changed (2019-11-19):
[0000858877-19-000018:note_history:147]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (“SPVSS”) business. Total revenue includes SPVSS business revenue of $168 million for the first quarter of fiscal 2019.
  (was, 2019-05-21, similarity 0.7057):
[0000858877-19-000007:note_history:147]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions ("SPVSS") business. Total revenue includes SPVSS business revenue of $0 and $219 million for the third quarter of fiscal 2019 and 2018, respectively, and $168 million and $697 million for the first nine months of fiscal 2019 and 2018, respectively.

- changed (2019-11-19):
[0000858877-19-000018:note_history:148]
Infrastructure Platforms consist of our core networking technologies of switching, routing, wireless, and data center products that are designed to work together to deliver networking capabilities and transport and/or store data. These technologies consist of both hardware and software offerings, including software licenses and SaaS, that help our customers build networks, automate, orchestrate, integrate, and digitize data. We are shifting and expanding more of our business to software and subscriptions across our core networking portfolio. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.
  (was, 2019-05-21, similarity 0.9625):
[0000858877-19-000007:note_history:148]
Infrastructure Platforms consist of our core networking technologies of switching, routing, data center products, and wireless that are designed to work together to deliver networking capabilities and transport and/or store data. These technologies consist of both hardware and software offerings, including software licenses and software-as-a-service (SaaS), that help our customers build networks, automate, orchestrate, integrate, and digitize data. We are shifting and expanding more of our business to software and subscriptions across our core networking portfolio. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2019-11-19):
[0000858877-19-000018:note_history:149]
Security primarily includes our network security, cloud and email security, identity and access management, advanced threat protection, and unified threat management products. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers' network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- changed (2019-11-19):
[0000858877-19-000018:note_history:150]
Other Products primarily includes our cloud and system management products. These products include both hardware and software licenses. Our offerings in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control.
  (was, 2019-05-21, similarity 0.699):
[0000858877-19-000007:note_history:150]
Other Products primarily include our Service Provider Video Software Solutions and cloud and system management products. On May 1, 2018, we announced a definitive agreement to sell the SPVSS business. The sale closed on October 28, 2018. These products include both hardware and software licenses. Our offerings in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control.

- changed (2019-11-19):
[0000858877-19-000018:note_history:151]
Accounts receivable, net was $4.9 billion as of October 26, 2019 compared to $5.5 billion as of July 27, 2019, as reported on the Consolidated Balance Sheet.
  (was, 2019-05-21, similarity 0.9645):
[0000858877-19-000007:note_history:151]
Accounts receivable, net was $3.8 billion as of April 27, 2019 compared to $5.6 billion as of July 28, 2018, as reported on the Consolidated Balance Sheet.

- changed (2019-11-19):
[0000858877-19-000018:note_history:152]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of October 26, 2019 and July 27, 2019, our contract assets for these unbilled receivables were $954 million and $860 million, respectively, and were included in other current assets and other assets.
  (was, 2019-05-21, similarity 0.9873):
[0000858877-19-000007:note_history:152]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of April 27, 2019 and July 29, 2018, our contract assets for these unbilled receivables were $637 million and $122 million, respectively, and were included in other current assets and other assets.

- changed (2019-11-19):
[0000858877-19-000018:note_history:153]
Contract liabilities consist of deferred revenue. Deferred revenue was $18.6 billion as of October 26, 2019 compared to $18.5 billion as of July 27, 2019. We recognized approximately $3.7 billion of revenue during the first quarter of fiscal 2020, that was included in the deferred revenue balance at July 27, 2019.
  (was, 2019-05-21, similarity 0.6844):
[0000858877-19-000007:note_history:153]
Contract liabilities consist of deferred revenue. Deferred revenue was $17.5 billion as of April 27, 2019 compared to $19.7 billion as of July 28, 2018. In connection with the adoption of ASC 606, we recorded an adjustment to retained earnings to reduce deferred revenue by $2.8 billion. We recognized approximately $2.0 billion and $8.0 billion of revenue during the third quarter and first nine months of fiscal 2019, respectively, that was included in the deferred revenue balance at July 29, 2018.

- added (2019-11-19):
[0000858877-19-000018:note_history:154]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of October 26, 2019, the aggregate amount of RPO was $24.9 billion, comprised of $18.6 billion of deferred revenue and $6.3 billion of unbilled contract revenue. We expect approximately 56% of this amount to be recognized as revenue over the next year. As of July 27, 2019, the aggregate amount of RPO was $25.3 billion, comprised of $18.5 billion of deferred revenue and $6.8 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

- changed (2019-11-19):
[0000858877-19-000018:note_history:155]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $707 million and $750 million as of October 26, 2019 and July 27, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $116 million and $112 million for the first quarter of fiscal 2020 and fiscal 2019, respectively, and was included in sales and marketing expenses.
  (was, 2019-05-21, similarity 0.927):
[0000858877-19-000007:note_history:155]
In connection with the adoption of ASC 606, we began to capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $705 million and $644 million as of April 27, 2019 and July 29, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $124 million and $349 million for the third quarter and first nine months of fiscal 2019, respectively, and was included in sales and marketing expenses.

- removed (2019-11-19):
[0000858877-19-000007:note_history:156]
Security primarily includes our unified threat management, advanced threat security, and web security products. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers' network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2019-11-19):
[0000858877-19-000007:note_history:157]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of April 27, 2019, the aggregate amount of RPO was $23.0 billion, comprised of $17.5 billion of deferred revenue and $5.5 billion of unbilled contract revenue. We expect approximately 56% of this amount to be recognized as revenue over the next year. Unbilled contract revenue represents non-cancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.
