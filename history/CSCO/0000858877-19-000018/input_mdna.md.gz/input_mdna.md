# CSCO MD&A — 0000858877-19-000018


## mdna

[0000858877-19-000018:mdna:1]
[same as prior period, unchanged from 0000858877-19-000007:mdna:1]

[0000858877-19-000018:mdna:2]
[same as prior period, unchanged from 0000858877-19-000007:mdna:2]

[0000858877-19-000018:mdna:3]
[same as prior period, unchanged from 0000858877-19-000007:mdna:3]

[0000858877-19-000018:mdna:4]
Cisco designs and sells a broad range of technologies that have been powering the Internet since 1984. Across networking, security, collaboration, applications and the cloud, we are integrating intent-based technologies to help our customers manage more users, devices and things connecting to their networks. This will enable us to provide customers with a highly secure, intelligent platform for their digital business.

[0000858877-19-000018:mdna:5]
A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-19-000018:mdna:6]
|  | Three Months Ended |  |
|  | October 26, 2019 |  | October 27, 2018 |  | % Variance |  |
| Revenue (1) | $ | 13,159 |  |  | $ | 13,072 |  |  | 1 | % |  |
| Gross margin percentage | 64.3 | % |  | 62.3 | % |  | 2.0 |  | pts |
| Research and development | $ | 1,666 |  |  | $ | 1,608 |  |  | 4 | % |  |
| Sales and marketing | $ | 2,480 |  |  | $ | 2,410 |  |  | 3 | % |  |
| General and administrative | $ | 519 |  |  | $ | 211 |  |  | 146 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,665 |  |  | $ | 4,229 |  |  | 10 | % |  |
| Total as a percentage of revenue | 35.5 | % |  | 32.4 | % |  | 3.1 |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 36 |  |  | $ | 34 |  |  | 6 | % |  |
| Restructuring and other charges included in operating expenses | $ | 184 |  |  | $ | 78 |  |  | 136 | % |  |
| Operating income as a percentage of revenue | 27.2 | % |  | 29.1 | % |  | (1.9 | ) | pts |
| Interest and other income (loss), net | $ | 107 |  |  | $ | 104 |  |  | 3 | % |  |
| Income tax percentage | 20.6 | % |  | 9.2 | % |  | 11.4 |  | pts |
| Net income | $ | 2,926 |  |  | $ | 3,549 |  |  | (18 | )% |  |
| Net income as a percentage of revenue | 22.2 | % |  | 27.1 | % |  | (4.9 | ) | pts |
| Earnings per share—diluted | $ | 0.68 |  |  | $ | 0.77 |  |  | (12 | )% |  |

[0000858877-19-000018:mdna:7]
(1) During the second quarter of fiscal 2019, we completed the sale of our Service Provider Video Software Solutions (“SPVSS”) business. As a result, revenue from this business will not recur in future periods. Includes SPVSS business revenue of $168 million for the first quarter of fiscal 2019.

[0000858877-19-000018:mdna:8]
[same as prior period, unchanged from 0000858877-19-000007:mdna:10]

[0000858877-19-000018:mdna:9]
[same as prior period, unchanged from 0000858877-19-000007:mdna:11]

[0000858877-19-000018:mdna:10]
Three Months Ended October 26, 2019 Compared with Three Months Ended October 27, 2018

[0000858877-19-000018:mdna:11]
In the first quarter of fiscal 2020, we delivered solid results with growth in revenue and strong gross margin. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. Our product revenue reflected growth in Applications and Security, offset by a decline in Infrastructure Platforms, and we continued to make progress in the transition of our business model to increased software and subscriptions. We continue to operate in a challenging macroeconomic and highly competitive environment.  During the first quarter of fiscal 2020, we experienced continuing weakness in the service provider market and emerging countries and we expect ongoing uncertainty in these markets. We also saw a more broad-based weakening in the global macroeconomic environment during the quarter which impacted our enterprise and commercial markets. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-19-000018:mdna:12]
Total revenue increased by 1% compared with the first quarter of fiscal 2019. Within total revenue, product revenue was flat and service revenue increased by 3%. In the second quarter of fiscal 2019 we completed the sale of our SPVSS business. Total revenue for the first quarter of fiscal 2020 increased 2% not including revenue from the SPVSS business in the prior year period. Total gross margin increased by 2.0 percentage points, driven by productivity improvements and product mix, and to a lesser extent, partially offset by unfavorable impacts from pricing. Our gross margin also benefited from the sale of our lower margin SPVSS business during the second quarter of fiscal 2019. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 3.1 percentage points. Operating income as a percentage of revenue decreased by 1.9 percentage points. Diluted earnings per share decreased by 12%, driven by a 18% decrease in net income and a decrease in diluted share count of 341 million shares.

[0000858877-19-000018:mdna:13]
In terms of our geographic segments, revenue from the Americas increased $226 million and EMEA revenue increased by $59 million. Revenue in our APJC segment decreased by $197 million. The “BRICM” countries experienced a product revenue decline of 30% in the aggregate, driven by decreased product revenue in the emerging countries of Mexico, India, China, Russia and Brazil of 41%, 37%, 33%, 8% and 7%, respectively.

[0000858877-19-000018:mdna:14]
From a customer market standpoint, we experienced a product revenue decline in the service provider market and a slight decline in the enterprise market. These decreases were substantially offset by product revenue growth in the public sector and commercial markets. During the quarter, we saw a decline in business momentum in the enterprise and commercial markets, which we believe was significantly related to weakness in the global macroeconomic environment.

[0000858877-19-000018:mdna:15]
From a product category perspective, total product revenue, not including SPVSS products in the prior year period, increased 1% year over year. The increase was driven by solid product revenue growth in Security and Applications of 22% and 6%, respectively, and was offset by a product revenue decrease in Infrastructure Platforms of 1%.

[0000858877-19-000018:mdna:16]
43

[0000858877-19-000018:mdna:17]
[same as prior period, unchanged from 0000858877-19-000007:mdna:18]

[0000858877-19-000018:mdna:18]
[same as prior period, unchanged from 0000858877-19-000007:mdna:19]

[0000858877-19-000018:mdna:19]
[same as prior period, unchanged from 0000858877-19-000007:mdna:22]

[0000858877-19-000018:mdna:20]
As our customers add billions of new connections to their enterprises, and as more applications move to a multicloud environment, the network continues to be extremely critical. We believe that our customers are looking for intent-based networks that provide meaningful business value through automation, security, and analytics across private, hybrid, and multicloud environments. Our vision is to deliver highly secure, software-defined, automated and intelligent platforms for our customers. Our strategic priorities include the following: accelerating our pace of innovation, increasing the value of the network, and transforming our business model.

[0000858877-19-000018:mdna:21]
For additional discussion of our strategy and priorities, see Item 1. Business in our Annual Report on Form 10-K for the year ended July 27, 2019.

[0000858877-19-000018:mdna:22]
[same as prior period, unchanged from 0000858877-19-000007:mdna:25]

[0000858877-19-000018:mdna:23]
The following is a summary of our other key financial measures for the first quarter of fiscal 2020 (in millions):

[0000858877-19-000018:mdna:24]
|  |  | October 26, 2019 |  | July 27, 2019 |
| Cash and cash equivalents and investments |  | $ | 28,035 |  |  | $ | 33,413 |  |
| Deferred revenue |  | $ | 18,602 |  |  | $ | 18,467 |  |
| Inventories |  | $ | 1,344 |  |  | $ | 1,383 |  |

[0000858877-19-000018:mdna:25]
|  |  | Three Months Ended |
|  |  | October 26, 2019 |  | October 27, 2018 |
| Cash provided by operating activities |  | $ | 3,587 |  |  | $ | 3,763 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 768 |  |  | $ | 5,026 |  |
| Dividends |  | $ | 1,486 |  |  | $ | 1,500 |  |

[0000858877-19-000018:mdna:26]
[same as prior period, unchanged from 0000858877-19-000007:mdna:30]

[0000858877-19-000018:mdna:27]
[same as prior period, unchanged from 0000858877-19-000007:mdna:31]

[0000858877-19-000018:mdna:28]
[same as prior period, unchanged from 0000858877-19-000007:mdna:32]

[0000858877-19-000018:mdna:29]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements in our Annual Report on Form 10-K for the year ended July 27, 2019, as updated as applicable in Note 2 to the Consolidated Financial Statements herein, describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-19-000018:mdna:30]
[same as prior period, unchanged from 0000858877-19-000007:mdna:34]

[0000858877-19-000018:mdna:31]
[same as prior period, unchanged from 0000858877-19-000007:mdna:38]

[0000858877-19-000018:mdna:32]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-19-000018:mdna:33]
[same as prior period, unchanged from 0000858877-19-000007:mdna:40]

[0000858877-19-000018:mdna:34]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable. If actual credits received by distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-19-000018:mdna:35]
See Note 3 to the Consolidated Financial Statements for more details.

[0000858877-19-000018:mdna:36]
[same as prior period, unchanged from 0000858877-19-000007:mdna:43]

[0000858877-19-000018:mdna:37]
[same as prior period, unchanged from 0000858877-19-000007:mdna:44]

[0000858877-19-000018:mdna:38]
[same as prior period, unchanged from 0000858877-19-000007:mdna:45]

[0000858877-19-000018:mdna:39]
[same as prior period, unchanged from 0000858877-19-000007:mdna:46]

[0000858877-19-000018:mdna:40]
|  |  | October 26, 2019 |  | July 27, 2019 |
| Allowance for doubtful accounts |  | $ | 136 |  |  | $ | 136 |  |
| Percentage of gross accounts receivable |  | 2.7 | % |  | 2.4 | % |
| Allowance for credit loss—lease receivables |  | $ | 43 |  |  | $ | 46 |  |
| Percentage of gross lease receivables(1) |  | 1.8 | % |  | 1.8 | % |
| Allowance for credit loss—loan receivables |  | $ | 81 |  |  | $ | 71 |  |
| Percentage of gross loan receivables |  | 1.5 | % |  | 1.3 | % |

[0000858877-19-000018:mdna:41]
[same as prior period, unchanged from 0000858877-19-000007:mdna:48]

[0000858877-19-000018:mdna:42]
[same as prior period, unchanged from 0000858877-19-000007:mdna:49]

[0000858877-19-000018:mdna:43]
[same as prior period, unchanged from 0000858877-19-000007:mdna:50]

[0000858877-19-000018:mdna:44]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of October 26, 2019 and July 27, 2019 was $85 million and $84 million, respectively, and was recorded as a reduction of our accounts receivable and revenue. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-19-000018:mdna:45]
[same as prior period, unchanged from 0000858877-19-000007:mdna:52]

[0000858877-19-000018:mdna:46]
[same as prior period, unchanged from 0000858877-19-000007:mdna:53]

[0000858877-19-000018:mdna:47]
[same as prior period, unchanged from 0000858877-19-000007:mdna:54]

[0000858877-19-000018:mdna:48]
Our provision for inventory was $18 million and $6 million for the first quarter of fiscal 2020 and 2019, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $29 million and $18 million for the first quarter of fiscal 2020 and 2019, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments.

[0000858877-19-000018:mdna:49]
46

[0000858877-19-000018:mdna:50]
[same as prior period, unchanged from 0000858877-19-000007:mdna:56]

[0000858877-19-000018:mdna:51]
[same as prior period, unchanged from 0000858877-19-000007:mdna:57]

[0000858877-19-000018:mdna:52]
Loss Contingencies and Product Warranties

[0000858877-19-000018:mdna:53]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-19-000018:mdna:54]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-19-000018:mdna:55]
[same as prior period, unchanged from 0000858877-19-000007:mdna:61]

[0000858877-19-000018:mdna:56]
[same as prior period, unchanged from 0000858877-19-000007:mdna:62]

[0000858877-19-000018:mdna:57]
[same as prior period, unchanged from 0000858877-19-000007:mdna:63]

[0000858877-19-000018:mdna:58]
[same as prior period, unchanged from 0000858877-19-000007:mdna:64]

[0000858877-19-000018:mdna:59]
[same as prior period, unchanged from 0000858877-19-000007:mdna:65]

[0000858877-19-000018:mdna:60]
We hold non-marketable equity and other investments, some of which are in startup or development stage companies. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize.

[0000858877-19-000018:mdna:61]
[same as prior period, unchanged from 0000858877-19-000007:mdna:67]

[0000858877-19-000018:mdna:62]
[same as prior period, unchanged from 0000858877-19-000007:mdna:68]

[0000858877-19-000018:mdna:63]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first quarters of fiscal 2020 and 2019.

[0000858877-19-000018:mdna:64]
[same as prior period, unchanged from 0000858877-19-000007:mdna:70]

[0000858877-19-000018:mdna:65]
[same as prior period, unchanged from 0000858877-19-000007:mdna:71]

[0000858877-19-000018:mdna:66]
[same as prior period, unchanged from 0000858877-19-000007:mdna:73]

[0000858877-19-000018:mdna:67]
[same as prior period, unchanged from 0000858877-19-000007:mdna:74]

[0000858877-19-000018:mdna:68]
Our ongoing consideration of all the factors described previously could result in impairment charges in the future, which could adversely affect our net income.

[0000858877-19-000018:mdna:69]
[same as prior period, unchanged from 0000858877-19-000007:mdna:76]

[0000858877-19-000018:mdna:70]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 20.6% and 9.2% in the first quarter of fiscal 2020 and 2019, respectively.

[0000858877-19-000018:mdna:71]
[same as prior period, unchanged from 0000858877-19-000007:mdna:79]

[0000858877-19-000018:mdna:72]
[same as prior period, unchanged from 0000858877-19-000007:mdna:80]

[0000858877-19-000018:mdna:73]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to domestic manufacturing deduction, foreign-derived intangible income deduction, global intangible low-tax income and base erosion and anti-abuse tax laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 36 countries, including the United States, has made changes to numerous long-standing tax principles. There can be no assurance that these changes, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-19-000018:mdna:74]
[same as prior period, unchanged from 0000858877-19-000007:mdna:81]

[0000858877-19-000018:mdna:75]
[same as prior period, unchanged from 0000858877-19-000007:mdna:82]

[0000858877-19-000018:mdna:76]
[same as prior period, unchanged from 0000858877-19-000007:mdna:87]

[0000858877-19-000018:mdna:77]
[same as prior period, unchanged from 0000858877-19-000007:mdna:88]

[0000858877-19-000018:mdna:78]
[same as prior period, unchanged from 0000858877-19-000007:mdna:89]

[0000858877-19-000018:mdna:79]
|  |  | Three Months Ended (1) |
|  |  | October 26, 2019 |  | October 27, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,878 |  |  | $ | 9,890 |  |  | $ | (12 | ) |  | — | % |
| Percentage of revenue |  | 75.1 | % |  | 75.7 | % |  |  |  |  |  |  |
| Service |  | 3,281 |  |  | 3,182 |  |  | 99 |  |  | 3 | % |
| Percentage of revenue |  | 24.9 | % |  | 24.3 | % |  |  |  |  |  |  |
| Total |  | $ | 13,159 |  |  | $ | 13,072 |  |  | $ | 87 |  |  | 1 | % |

[0000858877-19-000018:mdna:80]
(1) Total revenue, product revenue and service revenue not including the SPVSS business in the prior year period increased 2%, 1% and 4%, respectively.

[0000858877-19-000018:mdna:81]
[same as prior period, unchanged from 0000858877-19-000007:mdna:92]

[0000858877-19-000018:mdna:82]
|  |  | Three Months Ended |
|  |  | October 26, 2019 |  | October 27, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,977 |  |  | $ | 7,751 |  |  | $ | 226 |  |  | 3 | % |
| Percentage of revenue |  | 60.7 | % |  | 59.3 | % |  |  |  |  |
| EMEA |  | 3,283 |  |  | 3,224 |  |  | 59 |  |  | 2 | % |
| Percentage of revenue |  | 24.9 | % |  | 24.7 | % |  |  |  |  |
| APJC |  | 1,899 |  |  | 2,096 |  |  | (197 | ) |  | (9 | )% |
| Percentage of revenue |  | 14.4 | % |  | 16.0 | % |  |  |  |  |
| Total |  | $ | 13,159 |  |  | $ | 13,072 |  |  | $ | 87 |  |  | 1 | % |

[0000858877-19-000018:mdna:83]
[same as prior period, unchanged from 0000858877-19-000007:mdna:94]

[0000858877-19-000018:mdna:84]
Three Months Ended October 26, 2019 Compared with Three Months Ended October 27, 2018

[0000858877-19-000018:mdna:85]
Total revenue increased by 1%. Product revenue was flat and service revenue increased by 3%. Total revenue reflected growth in the Americas and EMEA segments while revenue declined in the APJC segment. Product revenue for the emerging countries of BRICM, in the aggregate, experienced a 30% product revenue decline, with decreases across each of these countries.

[0000858877-19-000018:mdna:86]
In addition to the impact of macroeconomic factors, including a reduced IT spending environment and reductions in spending by government entities, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple performance obligations; the mix of financing arrangements provided to channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment.

[0000858877-19-000018:mdna:87]
[same as prior period, unchanged from 0000858877-19-000007:mdna:85]

[0000858877-19-000018:mdna:88]
[same as prior period, unchanged from 0000858877-19-000007:mdna:86]

[0000858877-19-000018:mdna:89]
[same as prior period, unchanged from 0000858877-19-000007:mdna:103]

[0000858877-19-000018:mdna:90]
[same as prior period, unchanged from 0000858877-19-000007:mdna:104]

[0000858877-19-000018:mdna:91]
|  |  | Three Months Ended |
|  |  | October 26, 2019 |  | October 27, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,907 |  |  | $ | 5,712 |  |  | $ | 195 |  |  | 3 | % |
| Percentage of product revenue |  | 59.8 | % |  | 57.8 | % |  |  |  |  |
| EMEA |  | 2,557 |  |  | 2,527 |  |  | 30 |  |  | 1 | % |
| Percentage of product revenue |  | 25.9 | % |  | 25.5 | % |  |  |  |  |
| APJC |  | 1,413 |  |  | 1,652 |  |  | (239 | ) |  | (14 | )% |
| Percentage of product revenue |  | 14.3 | % |  | 16.7 | % |  |  |  |  |
| Total |  | $ | 9,878 |  |  | $ | 9,890 |  |  | $ | (12 | ) |  | — | % |

[0000858877-19-000018:mdna:92]
[same as prior period, unchanged from 0000858877-19-000007:mdna:106]

[0000858877-19-000018:mdna:93]
Three Months Ended October 26, 2019 Compared with Three Months Ended October 27, 2018

[0000858877-19-000018:mdna:94]
[same as prior period, unchanged from 0000858877-19-000007:mdna:107]

[0000858877-19-000018:mdna:95]
Product revenue in the Americas segment increased by 3%, led by growth in the public sector, commercial and enterprise markets, partially offset by a decline in the service provider market. From a country perspective, product revenue increased by 4% in the United States while product revenue in Mexico, Brazil and Canada decreased by 41%, 7% and 6%, respectively.

[0000858877-19-000018:mdna:96]
[same as prior period, unchanged from 0000858877-19-000007:mdna:112]

[0000858877-19-000018:mdna:97]
Product revenue in the EMEA segment increased by 1%, with growth in the public sector and commercial markets partially offset by declines in the service provider and enterprise markets. Product revenue from emerging countries within EMEA increased by 3%, while product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, increased by 1%.

[0000858877-19-000018:mdna:98]
[same as prior period, unchanged from 0000858877-19-000007:mdna:117]

[0000858877-19-000018:mdna:99]
Product revenue in the APJC segment decreased by 14%, driven by declines in the service provider, commercial and enterprise markets, partially offset by growth in the public sector market. From a country perspective, product revenue decreased in India, China, and Australia by 37%, 33%, and 14%, respectively, partially offset by a product revenue increase in Japan of 10%.

[0000858877-19-000018:mdna:100]
[same as prior period, unchanged from 0000858877-19-000007:mdna:101]

[0000858877-19-000018:mdna:101]
[same as prior period, unchanged from 0000858877-19-000007:mdna:102]

[0000858877-19-000018:mdna:102]
[same as prior period, unchanged from 0000858877-19-000007:mdna:125]

[0000858877-19-000018:mdna:103]
[same as prior period, unchanged from 0000858877-19-000007:mdna:126]

[0000858877-19-000018:mdna:104]
[same as prior period, unchanged from 0000858877-19-000007:mdna:127]

[0000858877-19-000018:mdna:105]
|  |  | Three Months Ended |
|  |  | October 26, 2019 |  | October 27, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,538 |  |  | $ | 7,622 |  |  | $ | (84 | ) |  | (1 | )% |
| Applications |  | 1,499 |  |  | 1,419 |  |  | 80 |  |  | 6 | % |
| Security |  | 815 |  |  | 670 |  |  | 145 |  |  | 22 | % |
| Other Products |  | 26 |  |  | 178 |  |  | (152 | ) |  | (85 | )% |
| Total |  | $ | 9,878 |  |  | $ | 9,890 |  |  | $ | (12 | ) |  | — | % |

[0000858877-19-000018:mdna:106]
[same as prior period, unchanged from 0000858877-19-000007:mdna:129]

[0000858877-19-000018:mdna:107]
Three Months Ended October 26, 2019 Compared with Three Months Ended October 27, 2018

[0000858877-19-000018:mdna:108]
[same as prior period, unchanged from 0000858877-19-000007:mdna:130]

[0000858877-19-000018:mdna:109]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center. Infrastructure Platforms revenue decreased by 1%, or $84 million, with growth across the portfolio with the exception of routing. Switching had increased revenue, with revenue growth in campus switching driven by an increase in sales of our intent-based networking Catalyst 9000 Series, and with growth in the data center switching driven by increased revenue from our Nexus 9000 Series. We experienced a decrease in sales of routing products, driven by continued weakness in the service provider market. We experienced revenue growth from wireless products driven by Meraki offerings. Revenue from data center had solid growth driven by higher sales of our HyperFlex products.

[0000858877-19-000018:mdna:110]
[same as prior period, unchanged from 0000858877-19-000007:mdna:135]

[0000858877-19-000018:mdna:111]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as the Internet of Things (IoT) and AppDynamics analytics software offerings. Revenue in our Applications product category increased by 6%, or $80 million, with growth across the businesses, including double digit growth in AppDynamics.

[0000858877-19-000018:mdna:112]
[same as prior period, unchanged from 0000858877-19-000007:mdna:140]

[0000858877-19-000018:mdna:113]
Revenue in our Security product category increased 22%, or $145 million, driven by strong sales of our identity and access, advanced threat security, unified threat management and web security products. The acquisition of Duo Security in the first quarter of fiscal 2019 also contributed to the revenue increase in this product category.

[0000858877-19-000018:mdna:114]
[same as prior period, unchanged from 0000858877-19-000007:mdna:148]

[0000858877-19-000018:mdna:115]
The decrease in revenue from our Other Products category was primarily driven by a decrease in revenue from the SPVSS business which we divested in the second quarter of fiscal 2019.

[0000858877-19-000018:mdna:116]
[same as prior period, unchanged from 0000858877-19-000007:mdna:123]

[0000858877-19-000018:mdna:117]
[same as prior period, unchanged from 0000858877-19-000007:mdna:124]

[0000858877-19-000018:mdna:118]
[same as prior period, unchanged from 0000858877-19-000007:mdna:150]

[0000858877-19-000018:mdna:119]
[same as prior period, unchanged from 0000858877-19-000007:mdna:151]

[0000858877-19-000018:mdna:120]
|  |  | Three Months Ended |
|  |  | October 26, 2019 |  | October 27, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,070 |  |  | $ | 2,040 |  |  | $ | 30 |  |  | 1 | % |
| Percentage of service revenue |  | 63.1 | % |  | 64.1 | % |  |  |  |  |
| EMEA |  | 726 |  |  | 697 |  |  | 29 |  |  | 4 | % |
| Percentage of service revenue |  | 22.1 | % |  | 21.9 | % |  |  |  |  |
| APJC |  | 486 |  |  | 445 |  |  | 41 |  |  | 9 | % |
| Percentage of service revenue |  | 14.8 | % |  | 14.0 | % |  |  |  |  |
| Total |  | $ | 3,281 |  |  | $ | 3,182 |  |  | $ | 99 |  |  | 3 | % |

[0000858877-19-000018:mdna:121]
[same as prior period, unchanged from 0000858877-19-000007:mdna:153]

[0000858877-19-000018:mdna:122]
Three Months Ended October 26, 2019 Compared with Three Months Ended October 27, 2018

[0000858877-19-000018:mdna:123]
Service revenue increased 3%, driven by an increase in software and solution support offerings. Service revenue not including the SPVSS business in the prior year period increased by 4%. Service revenue increased across all geographic segments.

[0000858877-19-000018:mdna:124]
[same as prior period, unchanged from 0000858877-19-000007:mdna:158]

[0000858877-19-000018:mdna:125]
[same as prior period, unchanged from 0000858877-19-000007:mdna:159]

[0000858877-19-000018:mdna:126]
|  |  | Three Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |
|  |  | October 26, 2019 |  | October 27, 2018 |  | October 26, 2019 |  | October 27, 2018 |
| Gross margin: |  |  |  |  |  |  |  |  |
| Product |  | $ | 6,354 |  |  | $ | 6,091 |  |  | 64.3 | % |  | 61.6 | % |
| Service |  | 2,110 |  |  | 2,055 |  |  | 64.3 | % |  | 64.6 | % |
| Total |  | $ | 8,464 |  |  | $ | 8,146 |  |  | 64.3 | % |  | 62.3 | % |

[0000858877-19-000018:mdna:127]
[same as prior period, unchanged from 0000858877-19-000007:mdna:164]

[0000858877-19-000018:mdna:128]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the first quarter of fiscal 2020 as compared with the corresponding prior year period:

[0000858877-19-000018:mdna:129]
|  |  | Product Gross Margin Percentage |
| Fiscal 2019 |  | 61.6 | % |
| Productivity (1) |  | 2.4 | % |
| Product pricing |  | (0.4 | )% |
| Mix of products sold |  | 0.5 | % |
| Impact from divestiture of SPVSS business |  | 0.4 | % |
| Others |  | (0.2 | )% |
| Fiscal 2020 |  | 64.3 | % |

[0000858877-19-000018:mdna:130]
[same as prior period, unchanged from 0000858877-19-000007:mdna:167]

[0000858877-19-000018:mdna:131]
[same as prior period, unchanged from 0000858877-19-000007:mdna:144]

[0000858877-19-000018:mdna:132]
[same as prior period, unchanged from 0000858877-19-000007:mdna:145]

[0000858877-19-000018:mdna:133]
Three Months Ended October 26, 2019 Compared with Three Months Ended October 27, 2018

[0000858877-19-000018:mdna:134]
Product gross margin increased by 2.7 percentage points driven by productivity improvements and product mix, partially offset by unfavorable impacts from product pricing. Our product gross margin also benefited from the sale of our lower margin SPVSS business during the second quarter of fiscal 2019.

[0000858877-19-000018:mdna:135]
Productivity improvements were driven by cost reductions including value engineering efforts (e.g. component redesign, board configuration, test processes and transformation processes) and continued operational efficiency in manufacturing operations. The negative pricing impact, which was lower than the year-over-year impact we experienced in the first quarter of fiscal 2019, was driven by typical market factors and impacted each of our geographic segments. The favorable product mix impact was driven by the Security and Applications product categories.

[0000858877-19-000018:mdna:136]
[same as prior period, unchanged from 0000858877-19-000007:mdna:173]

[0000858877-19-000018:mdna:137]
Three Months Ended October 26, 2019 Compared with Three Months Ended October 27, 2018

[0000858877-19-000018:mdna:138]
Our service gross margin percentage decreased by 0.3 percentage points due to increased headcount-related and delivery costs, partially offset by higher sales volume.

[0000858877-19-000018:mdna:139]
Our service gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-19-000018:mdna:140]
[same as prior period, unchanged from 0000858877-19-000007:mdna:182]

[0000858877-19-000018:mdna:141]
[same as prior period, unchanged from 0000858877-19-000007:mdna:183]

[0000858877-19-000018:mdna:142]
|  | Three Months Ended |
|  | AMOUNT |  | PERCENTAGE |
|  | October 26, 2019 |  | October 27, 2018 |  | October 26, 2019 |  | October 27, 2018 |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 5,316 |  |  | $ | 5,070 |  |  | 66.6 | % |  | 65.4 | % |
| EMEA | 2,166 |  |  | 2,070 |  |  | 66.0 | % |  | 64.2 | % |
| APJC | 1,194 |  |  | 1,200 |  |  | 62.9 | % |  | 57.2 | % |
| Segment total | 8,676 |  |  | 8,341 |  |  | 65.9 | % |  | 63.8 | % |
| Unallocated corporate items (1) | (212 | ) |  | (195 | ) |  |  |  |  |
| Total | $ | 8,464 |  |  | $ | 8,146 |  |  | 64.3 | % |  | 62.3 | % |

[0000858877-19-000018:mdna:143]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-19-000018:mdna:144]
[same as prior period, unchanged from 0000858877-19-000007:mdna:186]

[0000858877-19-000018:mdna:145]
Three Months Ended October 26, 2019 Compared with Three Months Ended October 27, 2018

[0000858877-19-000018:mdna:146]
We experienced a gross margin percentage increase in our Americas segment due to productivity improvements, partially offset by unfavorable impacts from pricing and product mix. Our gross margin in this segment also benefited from the sale of our lower margin SPVSS business during the second quarter of fiscal 2019.

[0000858877-19-000018:mdna:147]
Gross margin in our EMEA segment increased due to productivity improvements, partially offset by negative impacts from pricing and mix.

[0000858877-19-000018:mdna:148]
The APJC segment gross margin percentage increase was due to favorable impacts from productivity improvements and product mix, partially offset by negative impacts from pricing.

[0000858877-19-000018:mdna:149]
[same as prior period, unchanged from 0000858877-19-000007:mdna:191]

[0000858877-19-000018:mdna:150]
[same as prior period, unchanged from 0000858877-19-000007:mdna:162]

[0000858877-19-000018:mdna:151]
[same as prior period, unchanged from 0000858877-19-000007:mdna:163]

[0000858877-19-000018:mdna:152]
[same as prior period, unchanged from 0000858877-19-000007:mdna:198]

[0000858877-19-000018:mdna:153]
[same as prior period, unchanged from 0000858877-19-000007:mdna:199]

[0000858877-19-000018:mdna:154]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,666 |  |  | $ | 1,608 |  |  | $ | 58 |  |  | 4 | % |
| Percentage of revenue | 12.7 | % |  | 12.3 | % |  |  |  |  |
| Sales and marketing | 2,480 |  |  | 2,410 |  |  | 70 |  |  | 3 | % |
| Percentage of revenue | 18.8 | % |  | 18.4 | % |  |  |  |  |
| General and administrative | 519 |  |  | 211 |  |  | 308 |  |  | 146 | % |
| Percentage of revenue | 3.9 | % |  | 1.6 | % |  |  |  |  |
| Total | $ | 4,665 |  |  | $ | 4,229 |  |  | $ | 436 |  |  | 10 | % |
| Percentage of revenue | 35.5 | % |  | 32.4 | % |  |  |  |  |

[0000858877-19-000018:mdna:155]
Three Months Ended October 26, 2019 Compared with Three Months Ended October 27, 2018

[0000858877-19-000018:mdna:156]
[same as prior period, unchanged from 0000858877-19-000007:mdna:201]

[0000858877-19-000018:mdna:157]
R&D expenses increased due to higher headcount-related expenses, higher share-based compensation expense and, to a lesser extent, higher discretionary spending. These increases were partially offset by lower contracted services spending.

[0000858877-19-000018:mdna:158]
[same as prior period, unchanged from 0000858877-19-000007:mdna:204]

[0000858877-19-000018:mdna:159]
[same as prior period, unchanged from 0000858877-19-000007:mdna:207]

[0000858877-19-000018:mdna:160]
Sales and marketing expenses increased due to higher headcount-related expenses, partially offset by lower discretionary spending and, to a lesser extent, lower share-based compensation expense.

[0000858877-19-000018:mdna:161]
[same as prior period, unchanged from 0000858877-19-000007:mdna:212]

[0000858877-19-000018:mdna:162]
G&A expenses increased due to the impact of the benefit from the $400 million litigation settlement with Arista Networks, Inc. (“Arista”) from the first quarter of fiscal 2019 and higher discretionary spending, partially offset by lower contracted services.

[0000858877-19-000018:mdna:163]
[same as prior period, unchanged from 0000858877-19-000007:mdna:220]

[0000858877-19-000018:mdna:164]
In the first quarter of fiscal 2020, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $46 million, or 1.1%, compared with the first quarter of fiscal 2019.

[0000858877-19-000018:mdna:165]
[same as prior period, unchanged from 0000858877-19-000007:mdna:230]

[0000858877-19-000018:mdna:166]
[same as prior period, unchanged from 0000858877-19-000007:mdna:231]

[0000858877-19-000018:mdna:167]
|  |  | Three Months Ended |
|  |  | October 26, 2019 |  | October 27, 2018 |
| Amortization of purchased intangible assets: |  |  |  |  |
| Cost of sales |  | $ | 166 |  |  | $ | 151 |  |
| Operating expenses |  | 36 |  |  | 34 |  |
| Total |  | $ | 202 |  |  | $ | 185 |  |

[0000858877-19-000018:mdna:168]
Three Months Ended October 26, 2019 Compared with Three Months Ended October 27, 2018

[0000858877-19-000018:mdna:169]
The increase in amortization of purchased intangible assets in the first quarter of fiscal 2020 was due largely to the amortization of purchased intangibles from our recent acquisitions.

[0000858877-19-000018:mdna:170]
[same as prior period, unchanged from 0000858877-19-000007:mdna:180]

[0000858877-19-000018:mdna:171]
[same as prior period, unchanged from 0000858877-19-000007:mdna:181]

[0000858877-19-000018:mdna:172]
[same as prior period, unchanged from 0000858877-19-000007:mdna:234]

[0000858877-19-000018:mdna:173]
We initiated a restructuring plan during fiscal 2018 in order to realign our organization and enable further investment in key priority areas, with estimated pretax charges of $600 million. In connection with this restructuring plan, we incurred charges of $184 million for the first quarter of fiscal 2020 and have incurred cumulative charges of $614 million since inception. We do not expect to incur significant charges under this plan in the future and expect this plan to be substantially completed in the first half of fiscal 2020.

[0000858877-19-000018:mdna:174]
[same as prior period, unchanged from 0000858877-19-000007:mdna:240]

[0000858877-19-000018:mdna:175]
[same as prior period, unchanged from 0000858877-19-000007:mdna:241]

[0000858877-19-000018:mdna:176]
[same as prior period, unchanged from 0000858877-19-000007:mdna:242]

[0000858877-19-000018:mdna:177]
|  |  | Three Months Ended |
|  |  | October 26, 2019 |  | October 27, 2018 |
| Operating income |  | $ | 3,579 |  |  | $ | 3,805 |  |
| Operating income as a percentage of revenue |  | 27.2 | % |  | 29.1 | % |

[0000858877-19-000018:mdna:178]
Three Months Ended October 26, 2019 Compared with Three Months Ended October 27, 2018

[0000858877-19-000018:mdna:179]
Operating income decreased by 6%, and as a percentage of revenue operating income decreased by 1.9 percentage points. These decreases resulted primarily from: the benefit from the $400 million litigation settlement with Arista in the first quarter of fiscal 2019 and higher restructuring and other charges, partially offset by a gross margin percentage increase (driven by productivity improvements, product mix and sale of our lower margin SPVSS business during the second quarter of fiscal 2019, partially offset by unfavorable impacts from pricing).

[0000858877-19-000018:mdna:180]
[same as prior period, unchanged from 0000858877-19-000007:mdna:248]

[0000858877-19-000018:mdna:181]
[same as prior period, unchanged from 0000858877-19-000007:mdna:249]

[0000858877-19-000018:mdna:182]
|  |  | Three Months Ended |
|  |  | October 26, 2019 |  | October 27, 2018 |  | Variancein Dollars |
| Interest income |  | $ | 273 |  |  | $ | 344 |  |  | $ | (71 | ) |
| Interest expense |  | (178 | ) |  | (221 | ) |  | 43 |  |
| Interest income (expense), net |  | $ | 95 |  |  | $ | 123 |  |  | $ | (28 | ) |

[0000858877-19-000018:mdna:183]
Three Months Ended October 26, 2019 Compared with Three Months Ended October 27, 2018

[0000858877-19-000018:mdna:184]
Interest income decreased driven by a decrease in the average balance of cash and available-for-sale debt investments. The decrease in interest expense was driven by a lower average debt balance.

[0000858877-19-000018:mdna:185]
[same as prior period, unchanged from 0000858877-19-000007:mdna:196]

[0000858877-19-000018:mdna:186]
[same as prior period, unchanged from 0000858877-19-000007:mdna:197]

[0000858877-19-000018:mdna:187]
[same as prior period, unchanged from 0000858877-19-000007:mdna:252]

[0000858877-19-000018:mdna:188]
|  |  | Three Months Ended |
|  |  | October 26, 2019 |  | October 27, 2018 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | 10 |  |  | $ | (6 | ) |  | $ | 16 |  |
| Marketable equity investments |  | — |  |  | (4 | ) |  | 4 |  |
| Non-marketable equity and other investments |  | 10 |  |  | 4 |  |  | 6 |  |
| Net gains (losses) on investments |  | 20 |  |  | (6 | ) |  | 26 |  |
| Other gains (losses), net |  | (8 | ) |  | (13 | ) |  | 5 |  |
| Other income (loss), net |  | $ | 12 |  |  | $ | (19 | ) |  | $ | 31 |  |

[0000858877-19-000018:mdna:189]
Three Months Ended October 26, 2019 Compared with Three Months Ended October 27, 2018

[0000858877-19-000018:mdna:190]
The total change in net gains (losses) on available-for-sale debt investments was primarily attributable to higher realized gains as a result of market conditions, and the timing of sales of these investments. The total change in net gains (losses) on marketable equity investments was attributable to market value fluctuations and the timing of recognition of gains and losses. The change in net gains (losses) on non-marketable equity and other investments was primarily due to higher net realized gains, partially offset by higher impairment charges. The change in other gains (losses), net was driven by higher gains from customer lease terminations, partially offset by higher donation expense and net unfavorable foreign exchange impacts.

[0000858877-19-000018:mdna:191]
[same as prior period, unchanged from 0000858877-19-000007:mdna:266]

[0000858877-19-000018:mdna:192]
The provision for income taxes resulted in an effective tax rate of 20.6% for the first quarter of fiscal 2020 compared with 9.2% for the first quarter of fiscal 2019. The increase in the effective tax rate was primarily due to the recognition of a tax benefit relating to indirect effects from the adoption of ASC 606 at the beginning of our first quarter of fiscal 2019 and a decrease in foreign income taxed at lower than U.S. rates in fiscal 2020 as compared to fiscal 2019.

[0000858877-19-000018:mdna:193]
[same as prior period, unchanged from 0000858877-19-000007:mdna:269]

[0000858877-19-000018:mdna:194]
[same as prior period, unchanged from 0000858877-19-000007:mdna:218]

[0000858877-19-000018:mdna:195]
[same as prior period, unchanged from 0000858877-19-000007:mdna:219]

[0000858877-19-000018:mdna:196]
[same as prior period, unchanged from 0000858877-19-000007:mdna:274]

[0000858877-19-000018:mdna:197]
[same as prior period, unchanged from 0000858877-19-000007:mdna:275]

[0000858877-19-000018:mdna:198]
[same as prior period, unchanged from 0000858877-19-000007:mdna:276]

[0000858877-19-000018:mdna:199]
[same as prior period, unchanged from 0000858877-19-000007:mdna:277]

[0000858877-19-000018:mdna:200]
|  | October 26, 2019 |  | July 27, 2019 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 8,587 |  |  | $ | 11,750 |  |  | $ | (3,163 | ) |
| Available-for-sale debt investments | 19,445 |  |  | 21,660 |  |  | (2,215 | ) |
| Marketable equity securities | 3 |  |  | 3 |  |  | — |  |
| Total | $ | 28,035 |  |  | $ | 33,413 |  |  | $ | (5,378 | ) |

[0000858877-19-000018:mdna:201]
The decrease in cash and cash equivalents and investments in the first quarter of fiscal 2020 was primarily driven by cash returned to shareholders in the form of repurchases of common stock of $0.8 billion under the stock repurchase program and cash dividends of $1.5 billion; net cash paid for acquisitions and divestitures of $0.2 billion; a net decrease in debt of $6.2 billion and capital expenditures of $0.2 billion. These uses of cash were partially offset by cash provided by operating activities of $3.6 billion.

[0000858877-19-000018:mdna:202]
In addition to cash requirements in the normal course of business, on July 9, 2019 we announced our intent to acquire Acacia for a purchase consideration of approximately $2.6 billion in cash. In addition, approximately $0.7 billion of the U.S. transition tax on accumulated earnings for foreign subsidiaries is payable in less than one year. Also, $4.0 billion of long-term debt outstanding at October 26, 2019 will mature within the next 12 months from the balance sheet date. See further discussion of liquidity under “Liquidity and Capital Resource Requirements” below.

[0000858877-19-000018:mdna:203]
[same as prior period, unchanged from 0000858877-19-000007:mdna:281]

[0000858877-19-000018:mdna:204]
[same as prior period, unchanged from 0000858877-19-000007:mdna:282]

[0000858877-19-000018:mdna:205]
[same as prior period, unchanged from 0000858877-19-000007:mdna:283]

[0000858877-19-000018:mdna:206]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Net cash provided by operating activities | $ | 3,587 |  |  | $ | 3,763 |  |
| Acquisition of property and equipment | (202 | ) |  | (212 | ) |
| Free cash flow | $ | 3,385 |  |  | $ | 3,551 |  |

[0000858877-19-000018:mdna:207]
[same as prior period, unchanged from 0000858877-19-000007:mdna:285]

[0000858877-19-000018:mdna:208]
[same as prior period, unchanged from 0000858877-19-000007:mdna:238]

[0000858877-19-000018:mdna:209]
[same as prior period, unchanged from 0000858877-19-000007:mdna:239]

[0000858877-19-000018:mdna:210]
[same as prior period, unchanged from 0000858877-19-000007:mdna:289]

[0000858877-19-000018:mdna:211]
[same as prior period, unchanged from 0000858877-19-000007:mdna:290]

[0000858877-19-000018:mdna:212]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2020 |  |  |  |  |  |  |  |  |  |  |  |  |
| October 26, 2019 |  | $ | 0.35 |  |  | $ | 1,486 |  |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |  | $ | 2,254 |  |
| Fiscal 2019 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 27, 2019 |  | $ | 0.35 |  |  | $ | 1,490 |  |  | 82 |  |  | $ | 54.99 |  |  | $ | 4,515 |  |  | $ | 6,005 |  |
| April 27, 2019 |  | $ | 0.35 |  |  | $ | 1,519 |  |  | 116 |  |  | $ | 52.14 |  |  | $ | 6,020 |  |  | $ | 7,539 |  |
| January 26, 2019 |  | $ | 0.33 |  |  | $ | 1,470 |  |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |  | $ | 6,486 |  |
| October 27, 2018 |  | $ | 0.33 |  |  | $ | 1,500 |  |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |  | $ | 6,526 |  |

[0000858877-19-000018:mdna:213]
Any future dividends are subject to the approval of our Board of Directors.

[0000858877-19-000018:mdna:214]
The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $12.7 billion, with no termination date.

[0000858877-19-000018:mdna:215]
[same as prior period, unchanged from 0000858877-19-000007:mdna:294]

[0000858877-19-000018:mdna:216]
|  | October 26, 2019 |  | July 27, 2019 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,878 |  |  | $ | 5,491 |  |  | $ | (613 | ) |

[0000858877-19-000018:mdna:217]
Our accounts receivable net, as of October 26, 2019 decreased by approximately 11%, as compared with the end of fiscal 2019, primarily due to timing and amount of product and service billings in the first quarter of fiscal 2020 compared with the fourth quarter of fiscal 2019.

[0000858877-19-000018:mdna:218]
[same as prior period, unchanged from 0000858877-19-000007:mdna:297]

[0000858877-19-000018:mdna:219]
|  | October 26, 2019 |  | July 27, 2019 |  | Increase (Decrease) |
| Inventories | $ | 1,344 |  |  | $ | 1,383 |  |  | $ | (39 | ) |

[0000858877-19-000018:mdna:220]
Inventory as of October 26, 2019 decreased by 3% from our inventory balance at the end of fiscal 2019. The decrease in inventory was primarily due to lower manufactured finished goods partially offset by an increase in raw materials.

[0000858877-19-000018:mdna:221]
[same as prior period, unchanged from 0000858877-19-000007:mdna:303]

[0000858877-19-000018:mdna:222]
Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. A significant portion of our

[0000858877-19-000018:mdna:223]
[same as prior period, unchanged from 0000858877-19-000007:mdna:122]

[0000858877-19-000018:mdna:224]
[same as prior period, unchanged from 0000858877-19-000007:mdna:254]

[0000858877-19-000018:mdna:225]
[same as prior period, unchanged from 0000858877-19-000007:mdna:255]

[0000858877-19-000018:mdna:226]
reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.  The following table summarizes our purchase commitments with contract manufacturers and suppliers as of the respective period ends (in millions):

[0000858877-19-000018:mdna:227]
| Commitments by Period | October 26, 2019 |  | July 27, 2019 |
| Less than 1 year | $ | 3,903 |  |  | $ | 4,239 |  |
| 1 to 3 years | 633 |  |  | 728 |  |
| Total | $ | 4,536 |  |  | $ | 4,967 |  |

[0000858877-19-000018:mdna:228]
Purchase commitments with contract manufacturers and suppliers decreased 9% compared to the end of fiscal 2019. On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers decreased by 7% compared with the end of fiscal 2019.

[0000858877-19-000018:mdna:229]
[same as prior period, unchanged from 0000858877-19-000007:mdna:307]

[0000858877-19-000018:mdna:230]
[same as prior period, unchanged from 0000858877-19-000007:mdna:308]

[0000858877-19-000018:mdna:231]
|  | October 26, 2019 |  | July 27, 2019 |  | Increase (Decrease) |
| Lease receivables, net | $ | 2,179 |  |  | $ | 2,326 |  |  | $ | (147 | ) |
| Loan receivables, net | 5,254 |  |  | 5,367 |  |  | (113 | ) |
| Financed service contracts, net | 2,424 |  |  | 2,360 |  |  | 64 |  |
| Total, net | $ | 9,857 |  |  | $ | 10,053 |  |  | $ | (196 | ) |

[0000858877-19-000018:mdna:232]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services.  The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed.  Financing receivables decreased by 2%. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-19-000018:mdna:233]
[same as prior period, unchanged from 0000858877-19-000007:mdna:311]

[0000858877-19-000018:mdna:234]
The volume of channel partner financing was $7.6 billion and $7.2 billion for the first quarter of fiscal 2020 and 2019, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.4 billion as of October 26, 2019 and July 27, 2019, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of October 26, 2019, the total maximum potential future payments related to these guarantees was approximately $163 million, of which approximately $76 million was recorded as deferred revenue.

[0000858877-19-000018:mdna:235]
[same as prior period, unchanged from 0000858877-19-000007:mdna:143]

[0000858877-19-000018:mdna:236]
[same as prior period, unchanged from 0000858877-19-000007:mdna:272]

[0000858877-19-000018:mdna:237]
[same as prior period, unchanged from 0000858877-19-000007:mdna:273]

[0000858877-19-000018:mdna:238]
[same as prior period, unchanged from 0000858877-19-000007:mdna:316]

[0000858877-19-000018:mdna:239]
[same as prior period, unchanged from 0000858877-19-000007:mdna:317]

[0000858877-19-000018:mdna:240]
|  | Maturity Date |  | October 26, 2019 |  | July 27, 2019 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | $ | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | 1,500 |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 18,500 |  |  | $ | 20,500 |  |

[0000858877-19-000018:mdna:241]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of October 26, 2019.

[0000858877-19-000018:mdna:242]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.  We had $4.2 billion in commercial paper notes outstanding as of July 27, 2019. We had no commercial paper outstanding as of October 26, 2019.

[0000858877-19-000018:mdna:243]
Credit Facility On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.  As of October 26, 2019, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-19-000018:mdna:244]
[same as prior period, unchanged from 0000858877-19-000007:mdna:287]

[0000858877-19-000018:mdna:245]
[same as prior period, unchanged from 0000858877-19-000007:mdna:288]

[0000858877-19-000018:mdna:246]
[same as prior period, unchanged from 0000858877-19-000007:mdna:325]

[0000858877-19-000018:mdna:247]
|  | October 26, 2019 |  | July 27, 2019 |  | Increase (Decrease) |
| Service | $ | 11,497 |  |  | $ | 11,709 |  |  | $ | (212 | ) |
| Product | 7,105 |  |  | 6,758 |  |  | 347 |  |
| Total | $ | 18,602 |  |  | $ | 18,467 |  |  | $ | 135 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 10,646 |  |  | $ | 10,668 |  |  | $ | (22 | ) |
| Noncurrent | 7,956 |  |  | 7,799 |  |  | 157 |  |
| Total | $ | 18,602 |  |  | $ | 18,467 |  |  | $ | 135 |  |

[0000858877-19-000018:mdna:248]
Deferred revenue increased primarily due to increased deferrals related to our recurring software offerings. The 2% decrease in deferred service revenue was driven by the impact of ongoing amortization of deferred service revenue.

[0000858877-19-000018:mdna:249]
[same as prior period, unchanged from 0000858877-19-000007:mdna:328]

[0000858877-19-000018:mdna:250]
[same as prior period, unchanged from 0000858877-19-000007:mdna:331]

[0000858877-19-000018:mdna:251]
The income tax payable outstanding as of October 26, 2019 for the U.S. transition tax on accumulated earnings for foreign subsidiaries is $8.3 billion. Approximately $0.7 billion is payable in less than one year; $1.5 billion is payable between 1 to 3 years; $2.1 billion is payable between 3 to 5 years; and the remaining $4.0 billion is payable in more than 5 years.

[0000858877-19-000018:mdna:252]
For our Contractual Obligations see our Annual Report on Form 10-K for the year ended July 27, 2019

[0000858877-19-000018:mdna:253]
[same as prior period, unchanged from 0000858877-19-000007:mdna:333]

[0000858877-19-000018:mdna:254]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or the continued employment with us of certain employees of the acquired entities. See Note 14 to the Consolidated Financial Statements.

[0000858877-19-000018:mdna:255]
We also have certain funding commitments primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $311 million as of October 26, 2019, compared with $326 million as of July 27, 2019.

[0000858877-19-000018:mdna:256]
[same as prior period, unchanged from 0000858877-19-000007:mdna:338]

[0000858877-19-000018:mdna:257]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have non-marketable equity and other investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our non-marketable equity and other investments and customer financings, and we have determined that as of October 26, 2019 there were no material unconsolidated variable interest entities.

[0000858877-19-000018:mdna:258]
[same as prior period, unchanged from 0000858877-19-000007:mdna:340]

[0000858877-19-000018:mdna:259]
[same as prior period, unchanged from 0000858877-19-000007:mdna:341]

[0000858877-19-000018:mdna:260]
[same as prior period, unchanged from 0000858877-19-000007:mdna:342]

[0000858877-19-000018:mdna:261]
[same as prior period, unchanged from 0000858877-19-000007:mdna:343]
