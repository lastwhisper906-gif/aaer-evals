# CSCO notes — 0000858877-19-000018


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-19-000018:notes:1]
[same as prior period, unchanged from 0000858877-19-000007:notes:321]

[0000858877-19-000018:notes:2]
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2020 and fiscal 2019 are each 52-week fiscal years. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-19-000018:notes:3]
We have prepared the accompanying financial data as of October 26, 2019 and for the first quarter of fiscal 2020 and fiscal 2019, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2019 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2019.

[0000858877-19-000018:notes:4]
Our consolidated financial statements include our accounts and entities consolidated under the variable interest and voting models. The noncontrolling interests attributed to these investments, if any, are presented as a separate component from our equity in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-19-000018:notes:5]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 26, 2019, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2020 and fiscal 2019, as applicable, have been made. The results of operations for the first quarter of fiscal 2020 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-19-000018:notes:6]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-19-000018:notes:7]
[same as prior period, unchanged from 0000858877-19-000007:notes:351]

[0000858877-19-000018:notes:8]
[same as prior period, unchanged from 0000858877-19-000007:notes:352]

[0000858877-19-000018:notes:9]
Leases  In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Codification (ASC) 842, Leases, a new standard requiring lessees to recognize operating and finance lease liabilities on the balance sheet, as well as corresponding right-of-use (ROU) assets. This standard also made some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, new disclosures are required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. ASC 842 requires adoption using the modified retrospective approach, with the option of applying the requirements of the standard either i) retrospectively to each prior comparative reporting period presented, or ii) retrospectively at the beginning of the period of adoption. We adopted this standard at the beginning of our first quarter of fiscal 2020 and applied it at the beginning of the period of adoption and did not restate prior periods. We adopted ASC 842 on July 28, 2019 which resulted in the recognition of $1.2 billion of operating lease ROU assets included in other assets and $1.2 billion of operating lease liabilities included in other current liabilities and other long-term liabilities. There were no transition adjustments recorded from the adoption of ASC 842 as a lessor.

[0000858877-19-000018:notes:10]
We have elected to apply the package of practical expedients permitted under the transition guidance within ASC 842 which does not require reassessment of initial direct costs, classification of a lease and definition of a lease. We also elected additional practical expedients which resulted in: i) allowing us not to reassess the accounting treatment for existing or expired land easements in transition; ii) combining lease and non-lease components and iii) not recording leases with an initial term of less than 12 months on our Consolidated Balance Sheet.

[0000858877-19-000018:notes:11]
As a lessee, we determine if an arrangement is a lease at commencement. Our ROU lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments related to the lease. Operating lease ROU assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. We use incremental borrowing rates based on information available at the commencement date to determine the present value of our lease payments.

[0000858877-19-000018:notes:12]
As a lessor, we determine if an arrangement is a lease at inception. We provide leasing arrangements for our equipment to certain qualified customers. Our lease portfolio primarily consists of sales-type leases. We allocate the consideration in a bundled contract with our customers based on relative standalone selling prices of our lease and non-lease components. The residual value on our leased equipment is determined at the inception of the lease based on an analysis of estimates of the value of equipment, market factors and historical customer behavior. Residual value estimates are reviewed on a periodic basis and other-than-temporary declines are expensed in the period they occur. Our leases generally provide an end-of-term option for the customer to extend the lease under mutually-agreed terms, return the leased equipment, or purchase the equipment for either the then-market value of the equipment or a pre-determined purchase price. If a customer chooses to terminate their lease prior to the original end of term date, the customer is required to pay all remaining lease payments in full.

[0000858877-19-000018:notes:13]
For additional information, see Note 8.

[0000858877-19-000018:notes:14]
| (b) | Recent Accounting Standards or Updates Not Yet Effective |

[0000858877-19-000018:notes:15]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2021 on a modified retrospective basis. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-19-000018:notes:16]
[same as prior period, unchanged from 0000858877-19-000007:notes:331]

[0000858877-19-000018:notes:17]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

[0000858877-19-000018:notes:18]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-19-000018:notes:19]
Significant Judgments

[0000858877-19-000018:notes:20]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-19-000018:notes:21]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

[0000858877-19-000018:notes:22]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license's utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

[0000858877-19-000018:notes:23]
[same as prior period, unchanged from 0000858877-19-000007:notes:332]

[0000858877-19-000018:notes:24]
[same as prior period, unchanged from 0000858877-19-000007:notes:333]

[0000858877-19-000018:notes:25]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 7,538 |  |  | $ | 7,622 |  |
| Applications | 1,499 |  |  | 1,419 |  |
| Security | 815 |  |  | 670 |  |
| Other Products | 26 |  |  | 178 |  |
| Total Product | 9,878 |  |  | 9,890 |  |
| Services | 3,281 |  |  | 3,182 |  |
| Total (1) | $ | 13,159 |  |  | $ | 13,072 |  |

[0000858877-19-000018:notes:26]
Amounts may not sum due to rounding.

[0000858877-19-000018:notes:27]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (“SPVSS”) business. Total revenue includes SPVSS business revenue of $168 million for the first quarter of fiscal 2019.

[0000858877-19-000018:notes:28]
Infrastructure Platforms consist of our core networking technologies of switching, routing, wireless, and data center products that are designed to work together to deliver networking capabilities and transport and/or store data. These technologies consist of both hardware and software offerings, including software licenses and SaaS, that help our customers build networks, automate, orchestrate, integrate, and digitize data. We are shifting and expanding more of our business to software and subscriptions across our core networking portfolio. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-19-000018:notes:29]
[same as prior period, unchanged from 0000858877-19-000007:notes:335]

[0000858877-19-000018:notes:30]
Security primarily includes our network security, cloud and email security, identity and access management, advanced threat protection, and unified threat management products. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers' network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-19-000018:notes:31]
Other Products primarily includes our cloud and system management products. These products include both hardware and software licenses. Our offerings in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control.

[0000858877-19-000018:notes:32]
[same as prior period, unchanged from 0000858877-19-000007:notes:338]

[0000858877-19-000018:notes:33]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for all of our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.

[0000858877-19-000018:notes:34]
[same as prior period, unchanged from 0000858877-19-000007:notes:340]

[0000858877-19-000018:notes:35]
Accounts receivable, net was $4.9 billion as of October 26, 2019 compared to $5.5 billion as of July 27, 2019, as reported on the Consolidated Balance Sheet.

[0000858877-19-000018:notes:36]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of October 26, 2019 and July 27, 2019, our contract assets for these unbilled receivables were $954 million and $860 million, respectively, and were included in other current assets and other assets.

[0000858877-19-000018:notes:37]
Contract liabilities consist of deferred revenue. Deferred revenue was $18.6 billion as of October 26, 2019 compared to $18.5 billion as of July 27, 2019. We recognized approximately $3.7 billion of revenue during the first quarter of fiscal 2020, that was included in the deferred revenue balance at July 27, 2019.

[0000858877-19-000018:notes:38]
[same as prior period, unchanged from 0000858877-19-000007:notes:344]

[0000858877-19-000018:notes:39]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of October 26, 2019, the aggregate amount of RPO was $24.9 billion, comprised of $18.6 billion of deferred revenue and $6.3 billion of unbilled contract revenue. We expect approximately 56% of this amount to be recognized as revenue over the next year. As of July 27, 2019, the aggregate amount of RPO was $25.3 billion, comprised of $18.5 billion of deferred revenue and $6.8 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

[0000858877-19-000018:notes:40]
[same as prior period, unchanged from 0000858877-19-000007:notes:346]

[0000858877-19-000018:notes:41]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $707 million and $750 million as of October 26, 2019 and July 27, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $116 million and $112 million for the first quarter of fiscal 2020 and fiscal 2019, respectively, and was included in sales and marketing expenses.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-19-000018:notes:42]
[same as prior period, unchanged from 0000858877-19-000007:notes:144]

[0000858877-19-000018:notes:43]
The following table presents revenue for groups of similar products and services (in millions):

[0000858877-19-000018:notes:44]
(1) Includes SPVSS business revenue of $168 million for the first quarter of fiscal 2019.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-19-000018:notes:45]
[same as prior period, unchanged from 0000858877-19-000007:notes:42]

[0000858877-19-000018:notes:46]
We completed four acquisitions during the first quarter of fiscal 2020. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-19-000018:notes:47]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions (four in total) | $ | 182 |  |  | $ | (9 | ) |  | $ | 108 |  |  | $ | 83 |  |

[0000858877-19-000018:notes:48]
The total purchase consideration related to acquisitions completed during the first quarter of fiscal 2020 consisted of cash consideration. The total cash and cash equivalents acquired from these acquisitions was approximately $10 million. Total transaction costs related to acquisition and divestiture activities were $5 million and $10 million for the first quarter of fiscal 2020 and 2019, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-19-000018:notes:49]
The goodwill generated from acquisitions completed during the first quarter of fiscal 2020 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-19-000018:notes:50]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first quarter of fiscal 2020 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.

[0000858877-19-000018:notes:51]
Pending Acquisition of Acacia Communications     On July 9, 2019, we announced our intent to acquire Acacia Communications, Inc. (“Acacia”), a public fabless semiconductor company that develops, manufactures and sells high-speed coherent optical interconnect products that are designed to transform communications networks through improvements in performance, capacity and cost.

[0000858877-19-000018:notes:52]
Under the terms of the agreement, we have agreed to pay total consideration of approximately $2.6 billion, net of cash and marketable securities, to acquire Acacia. The acquisition is expected to close during the second half of fiscal 2020, subject to customary closing conditions and regulatory approvals. Upon close of the acquisition, revenue from Acacia will be included in our Infrastructure Platforms product category.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-19-000018:notes:53]
[same as prior period, unchanged from 0000858877-19-000007:notes:235]

[0000858877-19-000018:notes:54]
[same as prior period, unchanged from 0000858877-19-000007:notes:236]

[0000858877-19-000018:notes:55]
The following table presents the goodwill allocated to our reportable segments as of October 26, 2019 and during the first quarter of fiscal 2020 (in millions):

[0000858877-19-000018:notes:56]
|  | Balance at July 27, 2019 |  | Acquisitions |  | Other |  | Balance at October 26, 2019 |
| Americas | $ | 21,120 |  |  | $ | 62 |  |  | $ | (21 | ) |  | $ | 21,161 |  |
| EMEA | 7,977 |  |  | 17 |  |  | (8 | ) |  | 7,986 |  |
| APJC | 4,432 |  |  | 4 |  |  | (5 | ) |  | 4,431 |  |
| Total | $ | 33,529 |  |  | $ | 83 |  |  | $ | (34 | ) |  | $ | 33,578 |  |

[0000858877-19-000018:notes:57]
[same as prior period, unchanged from 0000858877-19-000007:notes:239]

[0000858877-19-000018:notes:58]
[same as prior period, unchanged from 0000858877-19-000007:notes:240]

[0000858877-19-000018:notes:59]
The following table presents details of our intangible assets acquired through acquisitions completed during the first quarter of fiscal 2020 (in millions, except years):

[0000858877-19-000018:notes:60]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions (four in total) | 5.0 |  | $ | 108 |  |  | — |  |  | $ | — |  |  | — |  |  | $ | — |  |  | — |  |  | $ | 108 |  |

[0000858877-19-000018:notes:61]
The following tables present details of our purchased intangible assets (in millions):

[0000858877-19-000018:notes:62]
| October 26, 2019 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,342 |  |  | $ | (2,062 | ) |  | $ | 1,280 |  |
| Customer relationships |  | 749 |  |  | (273 | ) |  | 476 |  |
| Other |  | 41 |  |  | (26 | ) |  | 15 |  |
| Total purchased intangible assets with finite lives |  | 4,132 |  |  | (2,361 | ) |  | 1,771 |  |
| In-process research and development, with indefinite lives |  | 336 |  |  | — |  |  | 336 |  |
| Total |  | $ | 4,468 |  |  | $ | (2,361 | ) |  | $ | 2,107 |  |

[0000858877-19-000018:notes:63]
| July 27, 2019 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,270 |  |  | $ | (1,933 | ) |  | $ | 1,337 |  |
| Customer relationships |  | 840 |  |  | (331 | ) |  | 509 |  |
| Other |  | 41 |  |  | (22 | ) |  | 19 |  |
| Total purchased intangible assets with finite lives |  | 4,151 |  |  | (2,286 | ) |  | 1,865 |  |
| In-process research and development, with indefinite lives |  | 336 |  |  | — |  |  | 336 |  |
| Total |  | $ | 4,487 |  |  | $ | (2,286 | ) |  | $ | 2,201 |  |

[0000858877-19-000018:notes:64]
[same as prior period, unchanged from 0000858877-19-000007:notes:241]

[0000858877-19-000018:notes:65]
The following table presents the amortization of purchased intangible assets, including impairment charges (in millions):

[0000858877-19-000018:notes:66]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Amortization of purchased intangible assets: |  |  |  |
| Cost of sales | $ | 166 |  |  | $ | 151 |  |
| Operating expenses | 36 |  |  | 34 |  |
| Total | $ | 202 |  |  | $ | 185 |  |

[0000858877-19-000018:notes:67]
The estimated future amortization expense of purchased intangible assets with finite lives as of October 26, 2019 is as follows (in millions):

[0000858877-19-000018:notes:68]
| Fiscal Year | Amount |
| 2020 (remaining nine months) | $ | 579 |  |
| 2021 | $ | 586 |  |
| 2022 | $ | 328 |  |
| 2023 | $ | 187 |  |
| 2024 | $ | 89 |  |
| Thereafter | $ | 2 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-19-000018:notes:69]
[same as prior period, unchanged from 0000858877-19-000007:notes:325]

[0000858877-19-000018:notes:70]
We initiated a restructuring plan during fiscal 2018 (the “Fiscal 2018 Plan”) in order to realign the organization and enable further investment in key priority areas with estimated pretax charges of approximately $600 million. These aggregate pretax charges are primarily cash-based and consist of employee severance and other one-time termination benefits, and other associated costs. In connection with the Fiscal 2018 Plan, we have incurred charges of $184 million for the first quarter of fiscal 2020, and have incurred cumulative charges of $614 million. We do not expect to incur significant charges under the Fiscal 2018 Plan in the future and expect this plan to be substantially completed in the first half of fiscal 2020.

[0000858877-19-000018:notes:71]
[same as prior period, unchanged from 0000858877-19-000007:notes:328]

[0000858877-19-000018:notes:72]
|  |  | FISCAL 2017 AND PRIOR PLANS |  | FISCAL 2018 PLAN |  |  |
|  |  | Employee Severance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 27, 2019 |  | $ | — |  |  | $ | 5 |  |  | $ | 22 |  |  | $ | 6 |  |  | $ | 33 |  |
| Charges |  | — |  |  | — |  |  | 175 |  |  | 9 |  |  | 184 |  |
| Cash payments |  | — |  |  | — |  |  | (154 | ) |  | (1 | ) |  | (155 | ) |
| Non-cash items |  | — |  |  | (2 | ) |  | — |  |  | (13 | ) |  | (15 | ) |
| Liability as of October 26, 2019 |  | $ | — |  |  | $ | 3 |  |  | $ | 43 |  |  | $ | 1 |  |  | $ | 47 |  |

[0000858877-19-000018:notes:73]
|  |  | FISCAL 2017 AND PRIOR PLANS |  | FISCAL 2018 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 28, 2018 |  | $ | 41 |  |  | $ | 13 |  |  | $ | 19 |  |  | $ | — |  |  | $ | 73 |  |
| Charges |  | — |  |  | — |  |  | 54 |  |  | 24 |  |  | 78 |  |
| Cash payments |  | (10 | ) |  | (1 | ) |  | (52 | ) |  | (1 | ) |  | (64 | ) |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (23 | ) |  | (23 | ) |
| Liability as of October 27, 2018 |  | $ | 31 |  |  | $ | 12 |  |  | $ | 21 |  |  | $ | — |  |  | $ | 64 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-19-000018:notes:74]
[same as prior period, unchanged from 0000858877-19-000007:notes:362]

[0000858877-19-000018:notes:75]
The following tables provide details of selected balance sheet items (in millions):

[0000858877-19-000018:notes:76]
|  |  | October 26, 2019 |  | July 27, 2019 |
| Cash and cash equivalents |  | $ | 8,587 |  |  | $ | 11,750 |  |
| Restricted cash included in other current assets |  | 23 |  |  | 21 |  |
| Restricted cash included in other assets |  | 3 |  |  | 1 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 8,613 |  |  | $ | 11,772 |  |

[0000858877-19-000018:notes:77]
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 424 |  |  | $ | 374 |  |
| Work in process |  | 9 |  |  | 10 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales |  | 87 |  |  | 109 |  |
| Manufactured finished goods |  | 576 |  |  | 643 |  |
| Total finished goods |  | 663 |  |  | 752 |  |
| Service-related spares |  | 226 |  |  | 225 |  |
| Demonstration systems |  | 22 |  |  | 22 |  |
| Total |  | $ | 1,344 |  |  | $ | 1,383 |  |

[0000858877-19-000018:notes:78]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,413 |  |  | $ | 4,545 |  |
| Computer equipment and related software |  | 908 |  |  | 922 |  |
| Production, engineering, and other equipment |  | 5,668 |  |  | 5,711 |  |
| Operating lease assets |  | 438 |  |  | 485 |  |
| Furniture, fixtures and other |  | 384 |  |  | 376 |  |
| Total gross property and equipment |  | 11,811 |  |  | 12,039 |  |
| Less: accumulated depreciation and amortization |  | (9,142 | ) |  | (9,250 | ) |
| Total |  | $ | 2,669 |  |  | $ | 2,789 |  |

[0000858877-19-000018:notes:79]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 11,497 |  |  | $ | 11,709 |  |
| Product |  | 7,105 |  |  | 6,758 |  |
| Total |  | $ | 18,602 |  |  | $ | 18,467 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 10,646 |  |  | $ | 10,668 |  |
| Noncurrent |  | 7,956 |  |  | 7,799 |  |
| Total |  | $ | 18,602 |  |  | $ | 18,467 |  |


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000858877-19-000018:notes:80]
Leases

[0000858877-19-000018:notes:81]
| (a) | Lessee Arrangements |

[0000858877-19-000018:notes:82]
We lease real estate, IT and other equipment and vehicles. We also have arrangements with certain suppliers and contract manufacturers which includes the leasing of dedicated space and equipment costs. Our leases have the option to extend or terminate the lease when it is reasonably certain that we will exercise that option.

[0000858877-19-000018:notes:83]
Certain of our lease agreements contain variable lease payments. Our variable lease payments can fluctuate depending on the level of activity or the cost of certain services where we have elected to combine lease and non-lease components. While these payments are not included as part of our lease liabilities, they are recognized as variable lease expense in the period they are incurred.

[0000858877-19-000018:notes:84]
As of October 26, 2019, our operating lease right-of-use assets were $1.1 billion and were recorded in other assets, and our operating lease liabilities were $1.1 billion, of which $367 million was included in other current liabilities and $780 million was included in other long-term liabilities.

[0000858877-19-000018:notes:85]
The components of our lease expenses were as follows (in millions):

[0000858877-19-000018:notes:86]
|  | Three Months Ended |
|  | October 26, 2019 |
| Operating lease expense | $ | 113 |  |
| Short-term lease expense | 17 |  |
| Variable lease expense | 40 |  |
| Total lease expense | $ | 170 |  |

[0000858877-19-000018:notes:87]
Supplemental information related to our operating leases is as follows:

[0000858877-19-000018:notes:88]
|  | Three Months Ended |
|  | October 26, 2019 |
| Weighted-average remaining lease term (in years) | 4.2 |  |
| Weighted-average discount rate | 1.9 | % |

[0000858877-19-000018:notes:89]
|  | Three Months Ended |
| In millions: | October 26, 2019 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 104 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 48 |  |

[0000858877-19-000018:notes:90]
The maturities of our operating leases (undiscounted) as of October 26, 2019 are as follows (in millions):

[0000858877-19-000018:notes:91]
| Fiscal Year | Amount |
| 2020 (remaining nine months) | $ | 296 |  |
| 2021 | 308 |  |
| 2022 | 212 |  |
| 2023 | 163 |  |
| 2024 | 102 |  |
| Thereafter | 107 |  |
| Total lease payments | 1,188 |  |
| Less interest | (41 | ) |
| Total | $ | 1,147 |  |

[0000858877-19-000018:notes:92]
Prior to the adoption of the new leasing standard, future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of July 27, 2019 were as follows (in millions):

[0000858877-19-000018:notes:93]
| Fiscal Year | Amount |
| 2020 | $ | 441 |  |
| 2021 | 299 |  |
| 2022 | 195 |  |
| 2023 | 120 |  |
| 2024 | 70 |  |
| Thereafter | 54 |  |
| Total | $ | 1,179 |  |

[0000858877-19-000018:notes:94]
| (b) | Lessor Arrangements |

[0000858877-19-000018:notes:95]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income for the first quarter of fiscal 2020 was $26 million and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-19-000018:notes:96]
Future minimum lease payments on our lease receivables as of October 26, 2019 are summarized as follows (in millions):

[0000858877-19-000018:notes:97]
| Fiscal Year | Amount |
| 2020 (remaining nine months) | $ | 595 |  |
| 2021 | 736 |  |
| 2022 | 470 |  |
| 2023 | 268 |  |
| 2024 | 120 |  |
| Thereafter | 29 |  |
| Total | 2,218 |  |
| Less: Present value of lease payments | 2,084 |  |
| Difference between undiscounted cash flows and discounted cash flows | $ | 134 |  |

[0000858877-19-000018:notes:98]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-19-000018:notes:99]
Prior to the adoption of the new leasing standard, future minimum lease payments on our lease receivables as of July 27, 2019 were summarized as follows (in millions):

[0000858877-19-000018:notes:100]
| Fiscal Year | Amount |
| 2020 | $ | 1,028 |  |
| 2021 | 702 |  |
| 2022 | 399 |  |
| 2023 | 185 |  |
| 2024 | 53 |  |
| Total | $ | 2,367 |  |

[0000858877-19-000018:notes:101]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by Cisco and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-19-000018:notes:102]
|  | October 26, 2019 |  | July 27, 2019 |
| Operating lease assets | $ | 438 |  |  | $ | 485 |  |
| Accumulated depreciation | (274 | ) |  | (306 | ) |
| Operating lease assets, net | $ | 164 |  |  | $ | 179 |  |

[0000858877-19-000018:notes:103]
Our lease income for the first quarter of fiscal 2020 was $44 million and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-19-000018:notes:104]
Minimum future rentals on noncancelable operating leases as of October 26, 2019 are summarized as follows (in millions):

[0000858877-19-000018:notes:105]
| Fiscal Year | Amount |
| 2020 (remaining nine months) | $ | 90 |  |
| 2021 | 64 |  |
| 2022 | 17 |  |
| 2023 | 2 |  |
| Total | $ | 173 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-19-000018:notes:106]
Financing Receivables

[0000858877-19-000018:notes:107]
[same as prior period, unchanged from 0000858877-19-000007:notes:210]

[0000858877-19-000018:notes:108]
Financing receivables primarily consist of lease receivables, loan receivables, and financed service contracts. Lease receivables represent sales-type leases resulting from the sale of Cisco’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services, which may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables have terms of three years on average. Financed service contracts include financing receivables related to technical support and advanced services. Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one to three years.

[0000858877-19-000018:notes:109]
[same as prior period, unchanged from 0000858877-19-000007:notes:212]

[0000858877-19-000018:notes:110]
| October 26, 2019 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,218 |  |  | $ | 5,335 |  |  | $ | 2,433 |  |  | $ | 9,986 |  |
| Residual value | 138 |  |  | — |  |  | — |  |  | 138 |  |
| Unearned income | (134 | ) |  | — |  |  | — |  |  | (134 | ) |
| Allowance for credit loss | (43 | ) |  | (81 | ) |  | (9 | ) |  | (133 | ) |
| Total, net | $ | 2,179 |  |  | $ | 5,254 |  |  | $ | 2,424 |  |  | $ | 9,857 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 976 |  |  | $ | 2,575 |  |  | $ | 1,475 |  |  | $ | 5,026 |  |
| Noncurrent | 1,203 |  |  | 2,679 |  |  | 949 |  |  | 4,831 |  |
| Total, net | $ | 2,179 |  |  | $ | 5,254 |  |  | $ | 2,424 |  |  | $ | 9,857 |  |

[0000858877-19-000018:notes:111]
| July 27, 2019 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,367 |  |  | $ | 5,438 |  |  | $ | 2,369 |  |  | $ | 10,174 |  |
| Residual value | 142 |  |  | — |  |  | — |  |  | 142 |  |
| Unearned income | (137 | ) |  | — |  |  | — |  |  | (137 | ) |
| Allowance for credit loss | (46 | ) |  | (71 | ) |  | (9 | ) |  | (126 | ) |
| Total, net | $ | 2,326 |  |  | $ | 5,367 |  |  | $ | 2,360 |  |  | $ | 10,053 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,029 |  |  | $ | 2,653 |  |  | $ | 1,413 |  |  | $ | 5,095 |  |
| Noncurrent | 1,297 |  |  | 2,714 |  |  | 947 |  |  | 4,958 |  |
| Total, net | $ | 2,326 |  |  | $ | 5,367 |  |  | $ | 2,360 |  |  | $ | 10,053 |  |

[0000858877-19-000018:notes:112]
[same as prior period, unchanged from 0000858877-19-000007:notes:218]

[0000858877-19-000018:notes:113]
Gross receivables, excluding residual value, less unearned income categorized by our internal credit risk rating as of October 26, 2019 and July 27, 2019 are summarized as follows (in millions):

[0000858877-19-000018:notes:114]
|  | INTERNAL CREDIT RISK RATING |
| October 26, 2019 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,128 |  |  | $ | 904 |  |  | $ | 52 |  |  | $ | 2,084 |  |
| Loan receivables | 3,267 |  |  | 1,866 |  |  | 202 |  |  | 5,335 |  |
| Financed service contracts | 1,466 |  |  | 935 |  |  | 32 |  |  | 2,433 |  |
| Total | $ | 5,861 |  |  | $ | 3,705 |  |  | $ | 286 |  |  | $ | 9,852 |  |

[0000858877-19-000018:notes:115]
|  | INTERNAL CREDIT RISK RATING |
| July 27, 2019 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,204 |  |  | $ | 991 |  |  | $ | 35 |  |  | $ | 2,230 |  |
| Loan receivables | 3,367 |  |  | 1,920 |  |  | 151 |  |  | 5,438 |  |
| Financed service contracts | 1,413 |  |  | 939 |  |  | 17 |  |  | 2,369 |  |
| Total | $ | 5,984 |  |  | $ | 3,850 |  |  | $ | 203 |  |  | $ | 10,037 |  |

[0000858877-19-000018:notes:116]
[same as prior period, unchanged from 0000858877-19-000007:notes:219]

[0000858877-19-000018:notes:117]
[same as prior period, unchanged from 0000858877-19-000007:notes:220]

[0000858877-19-000018:notes:118]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of October 26, 2019 and July 27, 2019 (in millions):

[0000858877-19-000018:notes:119]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| October 26, 2019 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 91 |  |  | $ | 73 |  |  | $ | 215 |  |  | $ | 379 |  |  | $ | 1,705 |  |  | $ | 2,084 |  |  | $ | 24 |  |  | $ | 24 |  |
| Loan receivables | 173 |  |  | 127 |  |  | 242 |  |  | 542 |  |  | 4,793 |  |  | 5,335 |  |  | 11 |  |  | 11 |  |
| Financed service contracts | 140 |  |  | 129 |  |  | 395 |  |  | 664 |  |  | 1,769 |  |  | 2,433 |  |  | 3 |  |  | 3 |  |
| Total | $ | 404 |  |  | $ | 329 |  |  | $ | 852 |  |  | $ | 1,585 |  |  | $ | 8,267 |  |  | $ | 9,852 |  |  | $ | 38 |  |  | $ | 38 |  |

[0000858877-19-000018:notes:120]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 27, 2019 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 101 |  |  | $ | 42 |  |  | $ | 291 |  |  | $ | 434 |  |  | $ | 1,796 |  |  | $ | 2,230 |  |  | $ | 13 |  |  | $ | 13 |  |
| Loan receivables | 257 |  |  | 67 |  |  | 338 |  |  | 662 |  |  | 4,776 |  |  | 5,438 |  |  | 31 |  |  | 31 |  |
| Financed service contracts | 145 |  |  | 131 |  |  | 271 |  |  | 547 |  |  | 1,822 |  |  | 2,369 |  |  | 3 |  |  | 3 |  |
| Total | $ | 503 |  |  | $ | 240 |  |  | $ | 900 |  |  | $ | 1,643 |  |  | $ | 8,394 |  |  | $ | 10,037 |  |  | $ | 47 |  |  | $ | 47 |  |

[0000858877-19-000018:notes:121]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract.

[0000858877-19-000018:notes:122]
As of October 26, 2019, we had financing receivables of $188 million, net of unbilled or current receivables, that were greater than 120 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $215 million as of July 27, 2019.

[0000858877-19-000018:notes:123]
[same as prior period, unchanged from 0000858877-19-000007:notes:226]

[0000858877-19-000018:notes:124]
The allowances for credit loss and the related financing receivables are summarized as follows (in millions):

[0000858877-19-000018:notes:125]
| Three months ended October 26, 2019 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 27, 2019 | $ | 46 |  |  | $ | 71 |  |  | $ | 9 |  |  | $ | 126 |  |
| Provisions (benefits) | (3 | ) |  | 27 |  |  | — |  |  | 24 |  |
| Recoveries (write-offs), net | — |  |  | (16 | ) |  | — |  |  | (16 | ) |
| Foreign exchange and other | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Allowance for credit loss as of October 26, 2019 | $ | 43 |  |  | $ | 81 |  |  | $ | 9 |  |  | $ | 133 |  |

[0000858877-19-000018:notes:126]
| Three months ended October 27, 2018 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 28, 2018 | $ | 135 |  |  | $ | 60 |  |  | $ | 10 |  |  | $ | 205 |  |
| Provisions (benefits) | (3 | ) |  | — |  |  | (2 | ) |  | (5 | ) |
| Foreign exchange and other | (1 | ) |  | — |  |  | — |  |  | (1 | ) |
| Allowance for credit loss as of October 27, 2018 | $ | 131 |  |  | $ | 60 |  |  | $ | 8 |  |  | $ | 199 |  |

[0000858877-19-000018:notes:127]
[same as prior period, unchanged from 0000858877-19-000007:notes:227]

[0000858877-19-000018:notes:128]
Typically, we also consider receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. These balances, as of October 26, 2019 and July 27, 2019, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-19-000018:notes:129]
[same as prior period, unchanged from 0000858877-19-000007:notes:229]


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-19-000018:notes:130]
Available-for-Sale Debt Investments and Equity Investments

[0000858877-19-000018:notes:131]
The following table summarizes our available-for-sale debt investments and equity investments (in millions):

[0000858877-19-000018:notes:132]
|  | October 26, 2019 |  | July 27, 2019 |
| Available-for-sale debt investments | $ | 19,445 |  |  | $ | 21,660 |  |
| Marketable equity securities | 3 |  |  | 3 |  |
| Total investments | 19,448 |  |  | 21,663 |  |
| Non-marketable equity securities included in other assets (1) | 1,151 |  |  | 1,113 |  |
| Equity method investments included in other assets | 66 |  |  | 87 |  |
| Total | $ | 20,665 |  |  | $ | 22,863 |  |

[0000858877-19-000018:notes:133]
(1) We held equity interests in certain private equity funds of $0.7 billion and $0.6 billion as of October 26, 2019 and July 27, 2019, respectively, which are accounted for under the NAV practical expedient.

[0000858877-19-000018:notes:134]
| (a) | Summary of Available-for-Sale Debt Investments |

[0000858877-19-000018:notes:135]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-19-000018:notes:136]
| October 26, 2019 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 1,322 |  |  | $ | 3 |  |  | $ | (1 | ) |  | $ | 1,324 |  |
| U.S. government agency securities | 98 |  |  | — |  |  | — |  |  | 98 |  |
| Corporate debt securities | 16,057 |  |  | 153 |  |  | (11 | ) |  | 16,199 |  |
| U.S. agency mortgage-backed securities | 1,509 |  |  | 9 |  |  | (8 | ) |  | 1,510 |  |
| Commercial paper | 283 |  |  | — |  |  | — |  |  | 283 |  |
| Certificates of deposit | 31 |  |  | — |  |  | — |  |  | 31 |  |
| Total | $ | 19,300 |  |  | $ | 165 |  |  | $ | (20 | ) |  | $ | 19,445 |  |

[0000858877-19-000018:notes:137]
| July 27, 2019 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 808 |  |  | $ | 1 |  |  | $ | (1 | ) |  | $ | 808 |  |
| U.S. government agency securities | 169 |  |  | — |  |  | — |  |  | 169 |  |
| Corporate debt securities | 19,188 |  |  | 103 |  |  | (29 | ) |  | 19,262 |  |
| U.S. agency mortgage-backed securities | 1,425 |  |  | 7 |  |  | (11 | ) |  | 1,421 |  |
| Total | $ | 21,590 |  |  | $ | 111 |  |  | $ | (41 | ) |  | $ | 21,660 |  |

[0000858877-19-000018:notes:138]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-19-000018:notes:139]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Gross realized gains | $ | 12 |  |  | $ | 2 |  |
| Gross realized losses | (2 | ) |  | (8 | ) |
| Total | $ | 10 |  |  | $ | (6 | ) |

[0000858877-19-000018:notes:140]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 26, 2019 and July 27, 2019 (in millions):

[0000858877-19-000018:notes:141]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 26, 2019 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 479 |  |  | $ | (1 | ) |  | $ | 25 |  |  | $ | — |  |  | $ | 504 |  |  | $ | (1 | ) |
| U.S. government agency securities | — |  |  | — |  |  | 98 |  |  | — |  |  | 98 |  |  | — |  |
| Corporate debt securities | 1,642 |  |  | (4 | ) |  | 1,200 |  |  | (7 | ) |  | 2,842 |  |  | (11 | ) |
| U.S. agency mortgage-backed securities | 378 |  |  | (1 | ) |  | 462 |  |  | (7 | ) |  | 840 |  |  | (8 | ) |
| Commercial paper | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |  | — |  |
| Certificates of deposit | 6 |  |  | — |  |  | — |  |  | — |  |  | 6 |  |  | — |  |
| Total | $ | 2,530 |  |  | $ | (6 | ) |  | $ | 1,785 |  |  | $ | (14 | ) |  | $ | 4,315 |  |  | $ | (20 | ) |

[0000858877-19-000018:notes:142]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2019 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 204 |  |  | $ | — |  |  | $ | 488 |  |  | $ | (1 | ) |  | $ | 692 |  |  | $ | (1 | ) |
| U.S. government agency securities | — |  |  | — |  |  | 169 |  |  | — |  |  | 169 |  |  | — |  |
| Corporate debt securities | 2,362 |  |  | (4 | ) |  | 5,271 |  |  | (25 | ) |  | 7,633 |  |  | (29 | ) |
| U.S. agency mortgage-backed securities | 123 |  |  | — |  |  | 847 |  |  | (11 | ) |  | 970 |  |  | (11 | ) |
| Total | $ | 2,689 |  |  | $ | (4 | ) |  | $ | 6,775 |  |  | $ | (37 | ) |  | $ | 9,464 |  |  | $ | (41 | ) |

[0000858877-19-000018:notes:143]
For available-for-sale debt investments that were in an unrealized loss position as of October 26, 2019, we have determined that no other-than-temporary impairments were required to be recognized.

[0000858877-19-000018:notes:144]
The following table summarizes the maturities of our available-for-sale debt investments as of October 26, 2019 (in millions):

[0000858877-19-000018:notes:145]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 5,472 |  |  | $ | 5,481 |  |
| After 1 year through 5 years | 10,604 |  |  | 10,676 |  |
| After 5 years through 10 years | 1,709 |  |  | 1,773 |  |
| After 10 years | 6 |  |  | 5 |  |
| Mortgage-backed securities with no single maturity | 1,509 |  |  | 1,510 |  |
| Total | $ | 19,300 |  |  | $ | 19,445 |  |

[0000858877-19-000018:notes:146]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-19-000018:notes:147]
| (b) | Summary of Equity Investments |

[0000858877-19-000018:notes:148]
We recorded adjustments to the carrying value of our non-marketable equity securities measured using the measurement alternative as follows (in millions):

[0000858877-19-000018:notes:149]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |  |  |
| Upward adjustments | $ | 1 |  |  | $ | 10 |  |
| Downward adjustments, including impairments | (2 | ) |  | (16 | ) |
| Net adjustments | $ | (1 | ) |  | $ | (6 | ) |

[0000858877-19-000018:notes:150]
Gains and losses recognized on our marketable and non-marketable equity securities are summarized below (in millions):

[0000858877-19-000018:notes:151]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Net gains and losses recognized during the period on equity investments | $ | 7 |  |  | $ | 8 |  |
| Less: Net gains and losses recognized on equity investments sold | (8 | ) |  | (12 | ) |
| Net unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | (1 | ) |  | $ | (4 | ) |

[0000858877-19-000018:notes:152]
| (c) | Securities Lending |

[0000858877-19-000018:notes:153]
We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending was $21 million and $0.5 billion for the first quarter of fiscal 2020 and 2019, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 26, 2019 and July 27, 2019, we had no outstanding securities lending transactions.

[0000858877-19-000018:notes:154]
| (d) | Variable Interest Entities |

[0000858877-19-000018:notes:155]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 26, 2019, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-19-000018:notes:156]
As of October 26, 2019, the carrying value of investments in privately held companies was $1.2 billion. $659 million of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $311 million related to these privately held investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-19-000018:notes:157]
Fair Value 
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, we consider the principal or most advantageous market in which we would transact, and we also consider assumptions that market participants would use when pricing the asset or liability.

[0000858877-19-000018:notes:158]
[same as prior period, unchanged from 0000858877-19-000007:notes:190]

[0000858877-19-000018:notes:159]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. The standard establishes a fair value hierarchy based on the level of

[0000858877-19-000018:notes:160]
independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000858877-19-000018:notes:161]
[same as prior period, unchanged from 0000858877-19-000007:notes:192]

[0000858877-19-000018:notes:162]
[same as prior period, unchanged from 0000858877-19-000007:notes:193]

[0000858877-19-000018:notes:163]
[same as prior period, unchanged from 0000858877-19-000007:notes:194]

[0000858877-19-000018:notes:164]
[same as prior period, unchanged from 0000858877-19-000007:notes:195]

[0000858877-19-000018:notes:165]
[same as prior period, unchanged from 0000858877-19-000007:notes:196]

[0000858877-19-000018:notes:166]
|  | OCTOBER 26, 2019FAIR VALUE MEASUREMENTS |  | JULY 27, 2019FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 6,648 |  |  | $ | — |  |  | $ | 6,648 |  |  | $ | 10,083 |  |  | $ | — |  |  | $ | 10,083 |  |
| Corporate debt securities | — |  |  | 90 |  |  | 90 |  |  | — |  |  | — |  |  | — |  |
| Commercial paper | — |  |  | 60 |  |  | 60 |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 1,324 |  |  | 1,324 |  |  | — |  |  | 808 |  |  | 808 |  |
| U.S. government agency securities | — |  |  | 98 |  |  | 98 |  |  | — |  |  | 169 |  |  | 169 |  |
| Corporate debt securities | — |  |  | 16,199 |  |  | 16,199 |  |  | — |  |  | 19,262 |  |  | 19,262 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,510 |  |  | 1,510 |  |  | — |  |  | 1,421 |  |  | 1,421 |  |
| Commercial paper | — |  |  | 283 |  |  | 283 |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposit | — |  |  | 31 |  |  | 31 |  |  | — |  |  | — |  |  | — |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 3 |  |  | — |  |  | 3 |  |  | 3 |  |  | — |  |  | 3 |  |
| Derivative assets | — |  |  | 103 |  |  | 103 |  |  | — |  |  | 89 |  |  | 89 |  |
| Total | $ | 6,651 |  |  | $ | 19,698 |  |  | $ | 26,349 |  |  | $ | 10,086 |  |  | $ | 21,749 |  |  | $ | 31,835 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 8 |  |  | $ | 8 |  |  | $ | — |  |  | $ | 15 |  |  | $ | 15 |  |
| Total | $ | — |  |  | $ | 8 |  |  | $ | 8 |  |  | $ | — |  |  | $ | 15 |  |  | $ | 15 |  |

[0000858877-19-000018:notes:167]
[same as prior period, unchanged from 0000858877-19-000007:notes:198]

[0000858877-19-000018:notes:168]
[same as prior period, unchanged from 0000858877-19-000007:notes:199]

[0000858877-19-000018:notes:169]
The following table presents gains and losses on assets that were measured at fair value on a nonrecurring basis (in millions):

[0000858877-19-000018:notes:170]
|  | TOTAL GAINS (LOSSES) FOR THE THREE MONTHS ENDED |
|  | October 26, 2019 |  | October 27, 2018 |
| Non-marketable equity securities and equity method investments | $ | (21 | ) |  | $ | (6 | ) |

[0000858877-19-000018:notes:171]
[same as prior period, unchanged from 0000858877-19-000007:notes:200]

[0000858877-19-000018:notes:172]
[same as prior period, unchanged from 0000858877-19-000007:notes:203]

[0000858877-19-000018:notes:173]
The fair value of short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of long-term loan receivables and financed service contracts as of October 26, 2019 and July 27, 2019 was $3.6 billion and $3.7 billion, respectively. The estimated fair value of long-term loan receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.
As of October 26, 2019, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of October 26, 2019, the fair value of our senior notes and other long-term debt was $20.3 billion with a carrying amount of $18.5 billion. This compares to a fair value of $22.1 billion and a carrying amount of $20.5 billion as of July 27, 2019. The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:DebtDisclosureTextBlock

[0000858877-19-000018:notes:174]
Borrowings

[0000858877-19-000018:notes:175]
| (a) | Short-Term Debt |

[0000858877-19-000018:notes:176]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-19-000018:notes:177]
|  | October 26, 2019 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,000 |  |  | 3.70 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 4,000 |  |  |  |  | $ | 10,191 |  |  |  |

[0000858877-19-000018:notes:178]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-19-000018:notes:179]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-19-000018:notes:180]
| (b) | Long-Term Debt |

[0000858877-19-000018:notes:181]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-19-000018:notes:182]
|  |  |  | October 26, 2019 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.39% |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.77% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.95% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.89% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 18,500 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (97 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 94 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 18,497 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,000 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 14,497 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 18,497 |  |  |  |  | $ | 20,473 |  |  |  |

[0000858877-19-000018:notes:183]
We entered into interest rate swaps in prior periods with an aggregate notional amount of $4.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (“LIBOR”). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-19-000018:notes:184]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 26, 2019, we were in compliance with all debt covenants.

[0000858877-19-000018:notes:185]
As of October 26, 2019, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-19-000018:notes:186]
| Fiscal Year | Amount |
| 2020 (remaining nine months) | $ | 4,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 18,500 |  |

[0000858877-19-000018:notes:187]
| (c) | Credit Facility |

[0000858877-19-000018:notes:188]
On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.

[0000858877-19-000018:notes:189]
This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of October 26, 2019, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under this credit facility.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-19-000018:notes:190]
[same as prior period, unchanged from 0000858877-19-000007:notes:114]

[0000858877-19-000018:notes:191]
[same as prior period, unchanged from 0000858877-19-000007:notes:115]

[0000858877-19-000018:notes:192]
[same as prior period, unchanged from 0000858877-19-000007:notes:116]

[0000858877-19-000018:notes:193]
[same as prior period, unchanged from 0000858877-19-000007:notes:117]

[0000858877-19-000018:notes:194]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | October 26, 2019 |  | July 27, 2019 |  | Balance Sheet Line Item |  | October 26, 2019 |  | July 27, 2019 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 3 |  |  | $ | 5 |  |  | Other current liabilities |  | $ | 5 |  |  | $ | 8 |  |
| Interest rate derivatives | Other current assets |  | 1 |  |  | — |  |  | Other current liabilities |  | — |  |  | 1 |  |
| Interest rate derivatives | Other assets |  | 94 |  |  | 75 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 98 |  |  | 80 |  |  |  |  | 5 |  |  | 9 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 5 |  |  | 9 |  |  | Other current liabilities |  | 3 |  |  | 6 |  |
| Total |  |  | 5 |  |  | 9 |  |  |  |  | 3 |  |  | 6 |  |
| Total |  |  | $ | 103 |  |  | $ | 89 |  |  |  |  | $ | 8 |  |  | $ | 15 |  |

[0000858877-19-000018:notes:195]
The following amounts were recorded on the Consolidated Balance Sheets related to cumulative basis adjustments for our fair value hedges (in millions):

[0000858877-19-000018:notes:196]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |
| Balance Sheet Line Item of Hedged Item |  | October 26, 2019 |  | July 27, 2019 |  | October 26, 2019 |  | July 27, 2019 |
| Short-term debt |  | $ | (2,001 | ) |  | $ | (2,000 | ) |  | $ | (2 | ) |  | $ | — |  |
| Long-term debt |  | $ | (2,585 | ) |  | $ | (2,565 | ) |  | $ | (92 | ) |  | $ | 73 |  |

[0000858877-19-000018:notes:197]
See Note 17 for the effects of our cash flow hedging instruments on other comprehensive income (OCI) and the Consolidated Statements of Operations. As of October 26, 2019, we estimate that approximately $3 million of net derivative losses related to our cash flow hedges included in accumulated other comprehensive income (AOCI) will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-19-000018:notes:198]
The effect on the Consolidated Statements of Operations of derivative instruments designated as fair value and cash flow hedges is summarized as follows (in millions):

[0000858877-19-000018:notes:199]
|  |  | Three Months Ended |
|  |  | October 26, 2019 |
|  |  | Revenue |  | Cost of sales |  | Operating expenses |  | Interest and other income (loss), net |
| Total amounts presented in the Consolidated Statements of Operations in which the effects of fair value or cash flow hedges are recorded |  | $ | 13,159 |  |  | $ | 4,695 |  |  | $ | 4,885 |  |  | $ | 107 |  |
| The effects of fair value and cash flow hedging: |  |  |  |  |  |  |  |  |
| Gains (losses) on fair value hedging relationships: |  |  |  |  |  |  |  |  |
| Interest rate derivatives |  |  |  |  |  |  |  |  |
| Hedged items |  | — |  |  | — |  |  | — |  |  | (21 | ) |
| Derivatives designated as hedging instruments |  | — |  |  | — |  |  | — |  |  | 22 |  |
| Gains (losses) on cash flow hedging relationships: |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  |  |  |  |  |  |  |  |
| Amount of gains (losses) reclassified from AOCI to income |  | (3 | ) |  | 1 |  |  | 2 |  |  | — |  |
| Total gains (losses) |  | $ | (3 | ) |  | $ | 1 |  |  | $ | 2 |  |  | $ | 1 |  |

[0000858877-19-000018:notes:200]
|  |  | Three Months Ended |
|  |  | October 27, 2018 |
|  |  | Revenue |  | Cost of sales |  | Operating expenses |  | Interest and other income (loss), net |
| Total amounts presented in the Consolidated Statements of Operations in which the effects of fair value or cash flow hedges are recorded |  | $ | 13,072 |  |  | $ | 4,926 |  |  | $ | 4,341 |  |  | $ | 104 |  |
| The effects of fair value and cash flow hedging: |  |  |  |  |  |  |  |  |
| Gains (losses) on fair value hedging relationships: |  |  |  |  |  |  |  |  |
| Interest rate derivatives |  |  |  |  |  |  |  |  |
| Hedged items |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Derivatives designated as hedging instruments |  | — |  |  | — |  |  | — |  |  | (9 | ) |
| Gains (losses) on cash flow hedging relationships: |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  |  |  |  |  |  |  |  |
| Amount of gains (losses) reclassified from AOCI to income |  | 1 |  |  | — |  |  | (1 | ) |  | — |  |
| Total gains (losses) |  | $ | 1 |  |  | $ | — |  |  | $ | (1 | ) |  | $ | — |  |

[0000858877-19-000018:notes:201]
[same as prior period, unchanged from 0000858877-19-000007:notes:123]

[0000858877-19-000018:notes:202]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | October 26, 2019 |  | October 27, 2018 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (7 | ) |  | $ | (27 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | 4 |  |  | (24 | ) |
|  |  | Cost of sales |  | — |  |  | (2 | ) |
|  |  | Other income (loss), net |  | (4 | ) |  | (4 | ) |
| Equity derivatives |  | Other income (loss), net |  | 2 |  |  | 1 |  |
| Total |  |  |  | $ | (5 | ) |  | $ | (56 | ) |

[0000858877-19-000018:notes:203]
[same as prior period, unchanged from 0000858877-19-000007:notes:125]

[0000858877-19-000018:notes:204]
|  | October 26, 2019 |  | July 27, 2019 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 647 |  |  | $ | 663 |  |
| Interest rate derivatives | 4,500 |  |  | 4,500 |  |
| Net investment hedging instruments | 281 |  |  | 309 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,680 |  |  | 2,708 |  |
| Total return swaps—deferred compensation | 602 |  |  | 574 |  |
| Total | $ | 8,710 |  |  | $ | 8,754 |  |

[0000858877-19-000018:notes:205]
[same as prior period, unchanged from 0000858877-19-000007:notes:127]

[0000858877-19-000018:notes:206]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty. As of October 26, 2019 and July 27, 2019, the potential effects of these rights of set-off associated with the derivative contracts would be a reduction to both derivative assets and derivative liabilities of $7 million and $13 million, respectively.

[0000858877-19-000018:notes:207]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral received as of October 26, 2019 and July 27, 2019 was $94 million and $76 million, respectively. Including the effects of collateral, this results in a net derivative asset of $1 million and a net derivative liability of $2 million as of October 26, 2019 and July 27, 2019, respectively.

[0000858877-19-000018:notes:208]
[same as prior period, unchanged from 0000858877-19-000007:notes:131]

[0000858877-19-000018:notes:209]
[same as prior period, unchanged from 0000858877-19-000007:notes:132]

[0000858877-19-000018:notes:210]
We hedge forecasted foreign currency transactions related to certain revenues, operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The derivative instrument’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. During the periods presented, we did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-19-000018:notes:211]
[same as prior period, unchanged from 0000858877-19-000007:notes:134]

[0000858877-19-000018:notes:212]
[same as prior period, unchanged from 0000858877-19-000007:notes:135]

[0000858877-19-000018:notes:213]
[same as prior period, unchanged from 0000858877-19-000007:notes:136]

[0000858877-19-000018:notes:214]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt  We hold interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2020 through 2025. Under these interest rate swaps, we receive fixed-rate interest payments and make interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.

[0000858877-19-000018:notes:215]
[same as prior period, unchanged from 0000858877-19-000007:notes:139]

[0000858877-19-000018:notes:216]
We hold marketable equity securities in our portfolio that are subject to price risk. To diversify our overall portfolio, we also hold equity derivatives that are not designated as accounting hedges. The change in the fair value of each of these investment types are included in other income (loss), net. 
We are also exposed to variability in compensation charges related to certain deferred compensation obligations to employees. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure and offset the related compensation expense.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-19-000018:notes:217]
Commitments and Contingencies

[0000858877-19-000018:notes:218]
| (a) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-19-000018:notes:219]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported

[0000858877-19-000018:notes:220]
purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-19-000018:notes:221]
The following table summarizes our purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-19-000018:notes:222]
| Commitments by Period | October 26, 2019 |  | July 27, 2019 |
| Less than 1 year | $ | 3,903 |  |  | $ | 4,239 |  |
| 1 to 3 years | 633 |  |  | 728 |  |
| Total | $ | 4,536 |  |  | $ | 4,967 |  |

[0000858877-19-000018:notes:223]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 26, 2019 and July 27, 2019, the liability for these purchase commitments was $121 million and $129 million, respectively, and was included in other current liabilities.

[0000858877-19-000018:notes:224]
| (b) | Other Commitments |

[0000858877-19-000018:notes:225]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-19-000018:notes:226]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-19-000018:notes:227]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Compensation expense related to acquisitions | $ | 61 |  |  | $ | 109 |  |

[0000858877-19-000018:notes:228]
As of October 26, 2019, we estimated that future cash compensation expense of up to $430 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-19-000018:notes:229]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $311 million and $326 million as of October 26, 2019 and July 27, 2019, respectively.

[0000858877-19-000018:notes:230]
| (c) | Product Warranties |

[0000858877-19-000018:notes:231]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-19-000018:notes:232]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Balance at beginning of period | $ | 342 |  |  | $ | 359 |  |
| Provisions for warranties issued | 140 |  |  | 156 |  |
| Adjustments for pre-existing warranties | (3 | ) |  | (3 | ) |
| Settlements | (149 | ) |  | (145 | ) |
| Balance at end of period | $ | 330 |  |  | $ | 367 |  |

[0000858877-19-000018:notes:233]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-19-000018:notes:234]
| (d) | Financing and Other Guarantees |

[0000858877-19-000018:notes:235]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-19-000018:notes:236]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.6 billion and $7.2 billion for the first quarter of fiscal 2020 and 2019, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.4 billion as of October 26, 2019 and July 27, 2019, respectively.

[0000858877-19-000018:notes:237]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $5 million and $3 million for the first quarter of fiscal 2020 and 2019, respectively.

[0000858877-19-000018:notes:238]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 26, 2019 and July 27, 2019, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-19-000018:notes:239]
|  | October 26, 2019 |  | July 27, 2019 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 148 |  |  | $ | 197 |  |
| End user | 15 |  |  | 21 |  |
| Total | $ | 163 |  |  | $ | 218 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (61 | ) |  | $ | (62 | ) |
| End user | (15 | ) |  | (15 | ) |
| Total | $ | (76 | ) |  | $ | (77 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 87 |  |  | $ | 141 |  |

[0000858877-19-000018:notes:240]
| (e) | Indemnifications |

[0000858877-19-000018:notes:241]
In the normal course of business, we indemnify other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-19-000018:notes:242]
Charter Communications, Inc., which acquired Time Warner Cable (“TWC”) in May 2016, is seeking indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Sprint sought monetary damages, alleging that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied TWC's post-trial motions. TWC appealed to the U.S. Court of Appeals for the Federal Circuit, and, on November 30, 2018, a panel of the court affirmed the judgment. TWC filed a petition for rehearing en banc on January 29, 2019, which was denied on March 19, 2019. TWC petitioned the U.S. Supreme Court for review of the judgment, which was denied on November 4, 2019. At this time, we do not believe that our indemnity obligations under our agreement will be material.

[0000858877-19-000018:notes:243]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-19-000018:notes:244]
It is not possible to determine the maximum potential amount under these indemnification agreements due to our limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by us under these agreements have not had a material effect on our operating results, financial position, or cash flows.

[0000858877-19-000018:notes:245]
| (f) | Legal Proceedings |

[0000858877-19-000018:notes:246]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of our former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-19-000018:notes:247]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $202 million for the alleged evasion of import and other taxes, $1.4 billion for interest, and $0.9 billion for various penalties, all determined using an exchange rate as of October 26, 2019. We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-19-000018:notes:248]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and, on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit on various grounds, a panel of which, after various proceedings, on July 12, 2019, issued an opinion vacating the enhanced damages award; vacating and remanding in part the willful infringement finding; vacating and remanding the attorneys’ fees award for further proceedings; and affirming the district court's other findings. Cisco paid SRI $28.1 million, representing the portion of the judgment that the Federal Circuit affirmed, plus interest and royalties on post-verdict sales. This payment is subject to a refund if any portion of the affirmed judgment is reversed or vacated by the U.S. Supreme Court. On November 8, 2019, Cisco filed a petition for a writ of certiorari with the U.S. Supreme Court, seeking review of the judgment on the grounds that the asserted patents describe patent-ineligible subject matter. While the remanded proceedings may result in an additional loss, we do not expect it to be material.

[0000858877-19-000018:notes:249]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against us and cancelling a trial which had been set for March 12, 2018. Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit, and, on January 23, 2019, the court summarily affirmed the finding of non-infringement. On August 23, 2019, Straight Path filed a petition with the United States Supreme Court challenging the constitutionality of the Federal Circuit’s rule allowing summary affirmance, which was denied on November 18, 2019.

[0000858877-19-000018:notes:250]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the court consolidated the cases alleging infringement of the ‘327 Patent. Oyster's cases against some of the defendants were resolved. The court vacated the November 4, 2018 trial date set for Oyster's claims against Cisco and one other remaining defendant, pending resolution of Oyster's appeal of the court's summary judgment ruling dismissing certain of Oyster's claims. Oyster appealed the summary judgment ruling on December 6, 2018. While we believe that we have strong non-infringement arguments and that the patent is invalid, if Oyster prevails in its appeal of the summary judgment ruling, and if we do not prevail in the District Court in a subsequent trial, we believe damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, we are unable to reasonably estimate the ultimate outcome of this litigation at this time. However, we do not anticipate that any final outcome of the dispute would be material.

[0000858877-19-000018:notes:251]
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to 
resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-19-000018:notes:252]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-19-000018:notes:253]
[same as prior period, unchanged from 0000858877-19-000007:notes:353]

[0000858877-19-000018:notes:254]
[same as prior period, unchanged from 0000858877-19-000007:notes:354]

[0000858877-19-000018:notes:255]
We declared and paid cash dividends of $0.35 and $0.33 per common share, or $1.5 billion, on our outstanding common stock for each the first quarter of fiscal 2020 and fiscal 2019.

[0000858877-19-000018:notes:256]
Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-19-000018:notes:257]
[same as prior period, unchanged from 0000858877-19-000007:notes:356]

[0000858877-19-000018:notes:258]
In September 2001, our Board of Directors authorized a stock repurchase program.  As of October 26, 2019, the remaining authorized amount for stock repurchases under this program, including the additional authorization, was approximately $12.7 billion with no termination date. A summary of the stock repurchase activity for the first quarter of fiscal 2020 and fiscal 2019 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-19-000018:notes:259]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2020 |  |  |  |  |  |  |
| October 26, 2019 |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |
| Fiscal 2019 |  |  |  |  |  |  |
| July 27, 2019 |  | 82 |  |  | $ | 54.99 |  |  | $ | 4,515 |  |
| April 27, 2019 |  | 116 |  |  | $ | 52.14 |  |  | $ | 6,020 |  |
| January 26, 2019 |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |
| October 27, 2018 |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |

[0000858877-19-000018:notes:260]
There were $24 million and $40 million of stock repurchases that were pending settlement as of October 26, 2019 and July 27, 2019, respectively.

[0000858877-19-000018:notes:261]
[same as prior period, unchanged from 0000858877-19-000007:notes:359]

[0000858877-19-000018:notes:262]
[same as prior period, unchanged from 0000858877-19-000007:notes:360]

[0000858877-19-000018:notes:263]
[same as prior period, unchanged from 0000858877-19-000007:notes:361]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-19-000018:notes:264]
[same as prior period, unchanged from 0000858877-19-000007:notes:147]

[0000858877-19-000018:notes:265]
[same as prior period, unchanged from 0000858877-19-000007:notes:148]

[0000858877-19-000018:notes:266]
Stock Incentive Plan Program Description    As of October 26, 2019, we had one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with Cisco. The number and frequency of share-based awards are based on competitive practices, operating results of Cisco, government regulations, and other factors. Our primary stock incentive plan is summarized as follows:

[0000858877-19-000018:notes:267]
2005 Plan    The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions.  Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. As of October 26, 2019, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares. The 2005 Plan may be terminated by the Board of Directors at any time and for any reason, and is currently set to terminate at the 2021 Annual Meeting unless re-adopted or extended by the shareholders prior to or on such date.

[0000858877-19-000018:notes:268]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan.

[0000858877-19-000018:notes:269]
[same as prior period, unchanged from 0000858877-19-000007:notes:153]

[0000858877-19-000018:notes:270]
We have an Employee Stock Purchase Plan under which 721.4 million shares of our common stock have been reserved for issuance as of October 26, 2019. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. No shares were issued under the Employee Stock Purchase Plan during each of the first quarters of fiscal 2020 and 2019. As of October 26, 2019, 159 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-19-000018:notes:271]
[same as prior period, unchanged from 0000858877-19-000007:notes:155]

[0000858877-19-000018:notes:272]
[same as prior period, unchanged from 0000858877-19-000007:notes:156]

[0000858877-19-000018:notes:273]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Cost of sales—product | $ | 23 |  |  | $ | 23 |  |
| Cost of sales—service | 34 |  |  | 33 |  |
| Share-based compensation expense in cost of sales | 57 |  |  | 56 |  |
| Research and development | 146 |  |  | 130 |  |
| Sales and marketing | 127 |  |  | 137 |  |
| General and administrative | 60 |  |  | 62 |  |
| Restructuring and other charges | 8 |  |  | 23 |  |
| Share-based compensation expense in operating expenses | 341 |  |  | 352 |  |
| Total share-based compensation expense | $ | 398 |  |  | $ | 408 |  |
| Income tax benefit for share-based compensation | $ | 131 |  |  | $ | 165 |  |

[0000858877-19-000018:notes:274]
As of October 26, 2019, the total compensation cost related to unvested share-based awards not yet recognized was $3.1 billion which is expected to be recognized over approximately 2.8 years on a weighted-average basis.

[0000858877-19-000018:notes:275]
[same as prior period, unchanged from 0000858877-19-000007:notes:159]

[0000858877-19-000018:notes:276]
[same as prior period, unchanged from 0000858877-19-000007:notes:160]

[0000858877-19-000018:notes:277]
|  | Share-Based Awards Available for Grant |
| BALANCE AT JULY 28, 2018 | 245 |  |
| Restricted stock, stock units, and other share-based awards granted | (67 | ) |
| Share-based awards canceled/forfeited/expired | 18 |  |
| Shares withheld for taxes and not issued | 23 |  |
| Other | 1 |  |
| BALANCE AT JULY 27, 2019 | 220 |  |
| Restricted stock, stock units, and other share-based awards granted | (13 | ) |
| Share-based awards canceled/forfeited/expired | 4 |  |
| Shares withheld for taxes and not issued | 5 |  |
| BALANCE AT OCTOBER 26, 2019 | 216 |  |

[0000858877-19-000018:notes:278]
[same as prior period, unchanged from 0000858877-19-000007:notes:162]

[0000858877-19-000018:notes:279]
[same as prior period, unchanged from 0000858877-19-000007:notes:163]

[0000858877-19-000018:notes:280]
[same as prior period, unchanged from 0000858877-19-000007:notes:164]

[0000858877-19-000018:notes:281]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 28, 2018 | 119 |  |  | $ | 30.56 |  |  |  |
| Granted | 45 |  |  | 47.71 |  |  |  |
| Vested | (50 | ) |  | 29.25 |  |  | $ | 2,446 |  |
| Canceled/forfeited/other | (14 | ) |  | 32.01 |  |  |  |
| UNVESTED BALANCE AT JULY 27, 2019 | 100 |  |  | 38.66 |  |  |  |
| Granted | 8 |  |  | 44.56 |  |  |  |
| Vested | (12 | ) |  | 29.71 |  |  | $ | 551 |  |
| Canceled/forfeited/other | (3 | ) |  | 38.57 |  |  |  |
| UNVESTED BALANCE AT OCTOBER 26, 2019 | 93 |  |  | $ | 40.28 |  |  |  |

[0000858877-19-000018:notes:282]
| (f) | Valuation of Employee Share-Based Awards |

[0000858877-19-000018:notes:283]
Time-based restricted stock units and performance-based restricted stock units (“PRSUs”) that are based on our financial performance metrics or non-financial operating goals are valued using the market value of our common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, we estimated the fair value of the total shareholder return (“TSR”) component of the PRSUs using a Monte Carlo simulation model. The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-19-000018:notes:284]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE BASEDRESTRICTED STOCK UNITS |
| Three Months Ended | October 26, 2019 |  | October 27, 2018 |  | October 26, 2019 |  | October 27, 2018 |
| Number of shares granted (in millions) | 6 |  |  | 6 |  |  | 2 |  |  | 2 |  |
| Grant date fair value per share | $ | 45.97 |  |  | $ | 44.32 |  |  | $ | 41.91 |  |  | $ | 47.00 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 2.8 | % |  | 2.8 | % |  | 2.8 | % |  | 2.8 | % |
| Range of risk-free interest rates | 1.7% - 2.0% |  |  | 2.1% - 2.9% |  |  | 1.7% - 2.0% |  |  | 2.1% - 3.0% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 13.7% - 69.0% |  |  | 13.0%-65.2% |  |

[0000858877-19-000018:notes:285]
The PRSUs granted during the periods presented are contingent on the achievement of our financial performance metrics or our comparative market-based returns.  For the awards based on financial performance metrics or comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period. Generally, the remaining 50% of the PRSUs are earned based on our TSR measured against the benchmark TSR of a peer group over the same period. Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of our financial performance metrics or our comparative market-based returns.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-19-000018:notes:286]
Comprehensive Income

[0000858877-19-000018:notes:287]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, for the first quarter of fiscal 2020 and 2019 are summarized as follows (in millions):

[0000858877-19-000018:notes:288]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 27, 2019 | $ | — |  |  | $ | (14 | ) |  | $ | (778 | ) |  | $ | (792 | ) |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 87 |  |  | (1 | ) |  | (92 | ) |  | (6 | ) |
| (Gains) losses reclassified out of AOCI | (10 | ) |  | — |  |  | 1 |  |  | (9 | ) |
| Tax benefit (expense) | (9 | ) |  | 1 |  |  | — |  |  | (8 | ) |
| BALANCE AT OCTOBER 26, 2019 | $ | 68 |  |  | $ | (14 | ) |  | $ | (869 | ) |  | $ | (815 | ) |

[0000858877-19-000018:notes:289]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 28, 2018 | $ | (310 | ) |  | $ | (11 | ) |  | $ | (528 | ) |  | $ | (849 | ) |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (8 | ) |  | (4 | ) |  | (207 | ) |  | (219 | ) |
| (Gains) losses reclassified out of AOCI | 6 |  |  | — |  |  | (1 | ) |  | 5 |  |
| Tax benefit (expense) | 13 |  |  | 1 |  |  | (1 | ) |  | 13 |  |
| Total change for the period | 11 |  |  | (3 | ) |  | (209 | ) |  | (201 | ) |
| Effect of adoption of accounting standard | (168 | ) |  | — |  |  | — |  |  | (168 | ) |
| BALANCE AT OCTOBER 27, 2018 | $ | (467 | ) |  | $ | (14 | ) |  | $ | (737 | ) |  | $ | (1,218 | ) |

[0000858877-19-000018:notes:290]
[same as prior period, unchanged from 0000858877-19-000007:notes:95]

[0000858877-19-000018:notes:291]
|  |  | Three Months Ended |  |  |
|  |  | October 26, 2019 |  | October 27, 2018 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains and losses on available-for-sale investments |  | $ | 10 |  |  | $ | (6 | ) |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |
| Foreign currency derivatives |  | (3 | ) |  | 1 |  |  | Revenue |
| Foreign currency derivatives |  | 1 |  |  | — |  |  | Cost of sales |
| Foreign currency derivatives |  | 2 |  |  | (1 | ) |  | Operating expenses |
|  |  | — |  |  | — |  |  |  |
| Cumulative translation adjustment and actuarial gains and losses |  | (1 | ) |  | 1 |  |  | Other income (loss), net |
| Total amounts reclassified out of AOCI |  | $ | 9 |  |  | $ | (5 | ) |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-19-000018:notes:292]
[same as prior period, unchanged from 0000858877-19-000007:notes:245]

[0000858877-19-000018:notes:293]
The following table provides details of income taxes (in millions, except percentages):

[0000858877-19-000018:notes:294]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Income before provision for income taxes | $ | 3,686 |  |  | $ | 3,909 |  |
| Provision for income taxes | $ | 760 |  |  | $ | 360 |  |
| Effective tax rate | 20.6 | % |  | 9.2 | % |

[0000858877-19-000018:notes:295]
The effective tax rate for the first quarter of fiscal 2019 includes a $152 million tax benefit relating to indirect effects from adoption of ASC 606 at the beginning of fiscal 2019.

[0000858877-19-000018:notes:296]
In the first quarter of fiscal 2020, the Internal Revenue Service (IRS) and Cisco settled all outstanding items related to the audit of our federal income tax returns for the fiscal year ended July 30, 2011 through July 27, 2013. As a result of the settlement, we recognized a net benefit to the provision for income taxes of $102 million, which included a reduction in interest expense of $4 million. We are no longer subject to U.S. federal tax audit through fiscal 2013.

[0000858877-19-000018:notes:297]
As of October 26, 2019, we had $2.0 billion of unrecognized tax benefits, of which $1.7 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters. We estimate that the unrecognized tax benefits at October 26, 2019 could be reduced by approximately $50 million in the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-19-000018:notes:298]
Segment Information and Major Customers

[0000858877-19-000018:notes:299]
| (a) | Revenue and Gross Margin by Segment |

[0000858877-19-000018:notes:300]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-19-000018:notes:301]
Summarized financial information by segment for the first quarter of fiscal 2020 and 2019, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-19-000018:notes:302]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Revenue: |  |  |  |
| Americas | $ | 7,977 |  |  | $ | 7,751 |  |
| EMEA | 3,283 |  |  | 3,224 |  |
| APJC | 1,899 |  |  | 2,096 |  |
| Total | $ | 13,159 |  |  | $ | 13,072 |  |
| Gross margin: |  |  |  |
| Americas | $ | 5,316 |  |  | $ | 5,070 |  |
| EMEA | 2,166 |  |  | 2,070 |  |
| APJC | 1,194 |  |  | 1,200 |  |
| Segment total | 8,676 |  |  | 8,341 |  |
| Unallocated corporate items | (212 | ) |  | (195 | ) |
| Total | $ | 8,464 |  |  | $ | 8,146 |  |

[0000858877-19-000018:notes:303]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-19-000018:notes:304]
Revenue in the United States was $7.1 billion and $6.9 billion for the first quarter of fiscal 2020 and 2019, respectively.

[0000858877-19-000018:notes:305]
| (b) | Revenue for Groups of Similar Products and Services |

[0000858877-19-000018:notes:306]
We design, manufacture, and sell Internet Protocol (IP)-based networking and other products related to the communications and information technology (IT) industry and provide services associated with these products and their use.

[0000858877-19-000018:notes:307]
| (c) | Additional Segment Information |

[0000858877-19-000018:notes:308]
The majority of our assets were attributable to our U.S. operations as of each of October 26, 2019 and July 27, 2019.

[0000858877-19-000018:notes:309]
Property and equipment information is based on the physical location of the assets. The following table presents property and equipment information for geographic areas (in millions):

[0000858877-19-000018:notes:310]
|  | October 26, 2019 |  | July 27, 2019 |
| Property and equipment, net: |  |  |  |
| United States | $ | 2,168 |  |  | $ | 2,266 |  |
| International | 501 |  |  | 523 |  |
| Total | $ | 2,669 |  |  | $ | 2,789 |  |


## us-gaap:EarningsPerShareTextBlock

[0000858877-19-000018:notes:311]
Net Income per Share

[0000858877-19-000018:notes:312]
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-19-000018:notes:313]
|  | Three Months Ended |
|  | October 26, 2019 |  | October 27, 2018 |
| Net income | $ | 2,926 |  |  | $ | 3,549 |  |
| Weighted-average shares—basic | 4,246 |  |  | 4,565 |  |
| Effect of dilutive potential common shares | 27 |  |  | 49 |  |
| Weighted-average shares—diluted | 4,273 |  |  | 4,614 |  |
| Net income per share—basic | $ | 0.69 |  |  | $ | 0.78 |  |
| Net income per share—diluted | $ | 0.68 |  |  | $ | 0.77 |  |
| Antidilutive employee share-based awards, excluded | 11 |  |  | 9 |  |

[0000858877-19-000018:notes:314]
Employee equity share options, unvested shares, and similar equity instruments granted and assumed by Cisco are treated as potential common shares outstanding in computing diluted earnings per share. Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that has not yet been recognized are collectively assumed to be used to repurchase shares.
