# CSCO 8-K — 0001193125-19-291002 filed 2019-11-13

## item codes, every 8-K on or before 2019-11-19

- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2019-11-19

- none on or before 2019-11-19

## item 2.02 — earnings release, exhibit 99.1

[0001193125-19-291002:8k_2_02:1]
EX-99.1
2
d827567dex991.htm
EX-99.1

[0001193125-19-291002:8k_2_02:2]
EX-99.1

[0001193125-19-291002:8k_2_02:3]
Exhibit 99.1

[0001193125-19-291002:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-19-291002:8k_2_02:5]
CISCO REPORTS FIRST QUARTER EARNINGS

[0001193125-19-291002:8k_2_02:6]
|  | • |  | Q1 Results: 1 |

[0001193125-19-291002:8k_2_02:7]
|  | • |  | Revenue: $13.2 billion |

[0001193125-19-291002:8k_2_02:8]
|  | • |  | Growth of 2% year over year |

[0001193125-19-291002:8k_2_02:9]
|  | • |  | Earnings per Share: GAAP: $0.68; Non-GAAP: $0.84 |

[0001193125-19-291002:8k_2_02:10]
|  | • |  | Non-GAAP EPS increased 12% year over year |

[0001193125-19-291002:8k_2_02:11]
|  | • |  | Q2 Guidance: |

[0001193125-19-291002:8k_2_02:12]
|  | • |  | Revenue: (3)% to (5)% decline year over year |

[0001193125-19-291002:8k_2_02:13]
|  | • |  | Earnings per Share: GAAP: $0.61 to $0.67; Non-GAAP: $0.75 to $0.77 |

[0001193125-19-291002:8k_2_02:14]
1 Normalized to exclude the divested SPVSS business

[0001193125-19-291002:8k_2_02:15]
SAN JOSE, Calif. — November 13, 2019 — Cisco today reported first quarter results for the period ended October 26, 2019. Cisco reported
first quarter revenue of $13.2 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.9 billion or $0.68 per share, and non-GAAP net income of $3.6 billion or $0.84
per share.

[0001193125-19-291002:8k_2_02:16]
As previously disclosed, Cisco completed the divestiture of the Service Provider Video Software Solutions (SPVSS) business in the second
quarter of fiscal 2019 on October 28, 2018. Revenue and non-GAAP financial information have been normalized to exclude the SPVSS business from prior periods for comparative purposes.

[0001193125-19-291002:8k_2_02:17]
“We delivered a solid quarter against a challenging macro environment,” said Chuck Robbins, chairman and CEO of Cisco. “We’re focused on
continuing to drive innovation, transform our business and exceed our customers’ expectations.”

[0001193125-19-291002:8k_2_02:18]
GAAP Results

[0001193125-19-291002:8k_2_02:19]
|  |  | Q1 FY 2020 |  |  | Q1 FY 2019 |  |  | Vs. Q1 FY 2019 |  |
| Revenue (including SPVSS business for all periods) |  | $ | 13.2 billion |  |  | $ | 13.1 billion |  |  |  | 1 | % |
| Revenue (excluding SPVSS business for all periods) |  | $ | 13.2 billion |  |  | $ | 12.9 billion |  |  |  | 2 | % |
| Net Income |  | $ | 2.9 billion |  |  | $ | 3.5 billion |  |  |  | (18 | )% |
| Diluted Earnings per Share (EPS) |  | $ | 0.68 |  |  | $ | 0.77 |  |  |  | (12 | )% |

[0001193125-19-291002:8k_2_02:20]
Non-GAAP Results

[0001193125-19-291002:8k_2_02:21]
|  |  | Q1 FY 2020 |  |  | Q1 FY 2019 |  |  | Vs. Q1 FY 2019 |  |
| Net Income (excluding SPVSS business for all periods) |  | $ | 3.6 billion |  |  | $ | 3.5 billion |  |  |  | 5 | % |
| EPS (excluding SPVSS business for all periods) |  | $ | 0.84 |  |  | $ | 0.75 |  |  |  | 12 | % |

[0001193125-19-291002:8k_2_02:22]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-19-291002:8k_2_02:23]
“We performed well in Q1, growing revenue and delivering strong margins and EPS,” said Kelly Kramer, CFO of Cisco. “With software subscriptions
now at 71% of our software revenue, we are making good progress in transforming our business model. We continue to invest in our innovation pipeline to generate long-term profitable growth and deliver value for shareholders.”

[0001193125-19-291002:8k_2_02:24]
1

[0001193125-19-291002:8k_2_02:25]
Financial Summary

[0001193125-19-291002:8k_2_02:26]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-19-291002:8k_2_02:27]
All revenue, non-GAAP, and geographic financial information in the “Q1 FY 2020 Highlights” section are
presented excluding the SPVSS business for all periods as it was divested during the second quarter of fiscal 2019 on October 28, 2018.

[0001193125-19-291002:8k_2_02:28]
Q1 FY
2020 Highlights

[0001193125-19-291002:8k_2_02:29]
Revenue — Total revenue was $13.2 billion, up 2%, with product revenue up 1% and service revenue up 4%.
Revenue by geographic segment was: Americas up 4%, EMEA up 4%, and APJC down 8%. Product revenue was led by growth in Security, up 22% and Applications, up 6%. Infrastructure Platforms was down 1%.

[0001193125-19-291002:8k_2_02:30]
Gross Margin — On a GAAP basis, total gross margin, product gross margin, and service gross margin were each 64.3%, as compared with
62.3%, 61.6%, and 64.6%, respectively, in the first quarter of fiscal 2019.

[0001193125-19-291002:8k_2_02:31]
On a non-GAAP basis, total gross
margin, product gross margin, and service gross margin were 65.9%, 66.1%, and 65.4%, respectively, as compared with 64.2%, 63.6%, and 65.8%, respectively, in the first quarter of fiscal 2019.

[0001193125-19-291002:8k_2_02:32]
Total gross margins by geographic segment were: 66.6% for the Americas, 66.0% for EMEA and 62.9% for APJC.

[0001193125-19-291002:8k_2_02:33]
Operating Expenses — On a GAAP basis, operating expenses were $4.9 billion, up 13%.
Non-GAAP operating expenses were $4.3 billion, up 4%, and were 32.4% of revenue.

[0001193125-19-291002:8k_2_02:34]
Operating Income
— GAAP operating income was $3.6 billion, down 6%, with GAAP operating margin of 27.2%. Non-GAAP operating income was $4.4 billion, up 6%, with
non-GAAP operating margin at 33.6%.

[0001193125-19-291002:8k_2_02:35]
Provision for Income Taxes — The GAAP tax provision rate
was 20.6%. The non-GAAP tax provision rate was 20.0%.

[0001193125-19-291002:8k_2_02:36]
Net Income and EPS — On a GAAP basis,
net income was $2.9 billion and EPS was $0.68. On a non-GAAP basis, net income was $3.6 billion, an increase of 5%, and EPS was $0.84, an increase of 12%.

[0001193125-19-291002:8k_2_02:37]
Cash Flow from Operating Activities — $3.6 billion for the first quarter of fiscal 2020, a decrease of 5% compared with
$3.8 billion for the first quarter of fiscal 2019. Operating cash flow for the first quarter of fiscal 2019 included the receipt of $0.4 billion in relation to the litigation settlement with Arista Networks. Operating cash flow increased
7%, normalized for this receipt.

[0001193125-19-291002:8k_2_02:38]
Balance Sheet and Other Financial Highlights

[0001193125-19-291002:8k_2_02:39]
Cash and Cash Equivalents and Investments — $28.0 billion at the end of the first quarter of fiscal 2020, compared with
$33.4 billion at the end of fiscal 2019.

[0001193125-19-291002:8k_2_02:40]
Deferred Revenue — $18.6 billion, up 11% in total, with deferred product revenue up
24%. Deferred service revenue was up 4%.

[0001193125-19-291002:8k_2_02:41]
Remaining Performance Obligations — $24.9 billion at the end of the first
quarter of fiscal 2020, up 11%.

[0001193125-19-291002:8k_2_02:42]
Capital Allocation — In the first quarter of fiscal 2020, we returned $2.3 billion to
shareholders through share buybacks and dividends. We declared and paid a cash dividend of $0.35 per common share, or $1.5 billion, and repurchased approximately 16 million shares of common stock under our stock repurchase program at an
average price of $48.91 per share for an aggregate purchase price of $768 million. The remaining authorized amount for stock repurchases under the program is $12.7 billion with no termination date.

[0001193125-19-291002:8k_2_02:43]
Acquisitions

[0001193125-19-291002:8k_2_02:44]
We completed several acquisitions in the
first quarter of fiscal 2020. In addition, in the fourth quarter of fiscal 2019, we announced our intent to acquire Acacia Communications, Inc., a publicly-traded fabless semiconductor company that develops, manufactures and sells high-speed
coherent optical interconnect products that are designed to transform communications networks through improvements in performance, capacity and cost. The acquisition is expected to close during the second half of fiscal 2020, subject to customary
closing conditions and regulatory approvals.

[0001193125-19-291002:8k_2_02:45]
2

[0001193125-19-291002:8k_2_02:46]
Guidance for Q2 FY 2020

[0001193125-19-291002:8k_2_02:47]
Cisco expects to achieve the following results for the second quarter of fiscal 2020:

[0001193125-19-291002:8k_2_02:48]
| Q2 FY 2020 |  |  |
| Revenue |  | (3)% - (5)% decline Y/Y |
| Non-GAAP gross margin rate |  | 64.5% - 65.5% |
| Non-GAAP operating margin rate |  | 32.5% - 33.5% |
| Non-GAAP tax provision rate |  | 20% |
| Non-GAAP EPS |  | $0.75 - $0.77 |

[0001193125-19-291002:8k_2_02:49]
Cisco estimates that GAAP EPS will be $0.61 to $0.67 in the second quarter of fiscal 2020.

[0001193125-19-291002:8k_2_02:50]
A reconciliation between the Guidance for Q2 FY 2020 on a GAAP and non-GAAP basis is provided in the table entitled
“GAAP to non-GAAP Guidance for Q2 FY 2020” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-19-291002:8k_2_02:51]
Editor’s Notes:

[0001193125-19-291002:8k_2_02:52]
|  | • |  | Q1 fiscal year 2020 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, November 13, 2019 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-19-291002:8k_2_02:53]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, November 13, 2019 to 4:00 p.m. Pacific Time, November 20, 2019 at 1-800-835-4610 (United States) or 1-203-369-3352 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-19-291002:8k_2_02:54]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, November 13, 2019. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-19-291002:8k_2_02:55]
3

[0001193125-19-291002:8k_2_02:56]
CISCO SYSTEMS, INC.

[0001193125-19-291002:8k_2_02:57]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-19-291002:8k_2_02:58]
(In millions, except per-share amounts)

[0001193125-19-291002:8k_2_02:59]
(Unaudited)

[0001193125-19-291002:8k_2_02:60]
|  |  | Three Months Ended |  |
|  |  | October 26,2019 |  |  | October 27,2018 |  |
| REVENUE: |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,878 |  |  | $ | 9,890 |  |
| Service |  |  | 3,281 |  |  |  | 3,182 |  |
| Total revenue |  |  | 13,159 |  |  |  | 13,072 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |
| Product |  |  | 3,524 |  |  |  | 3,799 |  |
| Service |  |  | 1,171 |  |  |  | 1,127 |  |
| Total cost of sales |  |  | 4,695 |  |  |  | 4,926 |  |
| GROSS MARGIN |  |  | 8,464 |  |  |  | 8,146 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,666 |  |  |  | 1,608 |  |
| Sales and marketing |  |  | 2,480 |  |  |  | 2,410 |  |
| General and administrative |  |  | 519 |  |  |  | 211 |  |
| Amortization of purchased intangible assets |  |  | 36 |  |  |  | 34 |  |
| Restructuring and other charges |  |  | 184 |  |  |  | 78 |  |
| Total operating expenses |  |  | 4,885 |  |  |  | 4,341 |  |
| OPERATING INCOME |  |  | 3,579 |  |  |  | 3,805 |  |
| Interest income |  |  | 273 |  |  |  | 344 |  |
| Interest expense |  |  | (178 | ) |  |  | (221 | ) |
| Other income (loss), net |  |  | 12 |  |  |  | (19 | ) |
| Interest and other income (loss), net |  |  | 107 |  |  |  | 104 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,686 |  |  |  | 3,909 |  |
| Provision for income taxes |  |  | 760 |  |  |  | 360 |  |
| NET INCOME |  | $ | 2,926 |  |  | $ | 3,549 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.69 |  |  | $ | 0.78 |  |
| Diluted |  | $ | 0.68 |  |  | $ | 0.77 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,246 |  |  |  | 4,565 |  |
| Diluted |  |  | 4,273 |  |  |  | 4,614 |  |

[0001193125-19-291002:8k_2_02:61]
The Consolidated Statements of Operations include the results of the SPVSS business prior to its divestiture during the second
quarter of fiscal 2019 on October 28, 2018. Accordingly, the three months ended October 27, 2018 includes three months of financial results for this business.

[0001193125-19-291002:8k_2_02:62]
4

[0001193125-19-291002:8k_2_02:63]
CISCO SYSTEMS, INC.

[0001193125-19-291002:8k_2_02:64]
REVENUE BY SEGMENT

[0001193125-19-291002:8k_2_02:65]
(In
millions, except percentages)

[0001193125-19-291002:8k_2_02:66]
|  |  | Three Months Ended |  |
|  |  | October 26, 2019 |  |
|  |  | Amount |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Including SPVSS business for all periods: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,977 |  |  |  | 3 | % |
| EMEA |  |  | 3,283 |  |  |  | 2 | % |
| APJC |  |  | 1,899 |  |  |  | (9 | )% |
| Total |  | $ | 13,159 |  |  |  | 1 | % |
| Excluding SPVSS business for all periods: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,977 |  |  |  | 4 | % |
| EMEA |  |  | 3,283 |  |  |  | 4 | % |
| APJC |  |  | 1,899 |  |  |  | (8 | )% |
| Total |  | $ | 13,159 |  |  |  | 2 | % |

[0001193125-19-291002:8k_2_02:67]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-291002:8k_2_02:68]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. SPVSS business revenue for the three
months ended October 27, 2018 was $168 million.

[0001193125-19-291002:8k_2_02:69]
CISCO SYSTEMS, INC.

[0001193125-19-291002:8k_2_02:70]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-19-291002:8k_2_02:71]
(In percentages)

[0001193125-19-291002:8k_2_02:72]
|  |  | Three Months Ended |  |
|  |  | October 26, 2019 |  |
| Gross Margin Percentage: |  |  |  |  |
| Americas |  |  | 66.6 | % |
| EMEA |  |  | 66.0 | % |
| APJC |  |  | 62.9 | % |

[0001193125-19-291002:8k_2_02:73]
5

[0001193125-19-291002:8k_2_02:74]
CISCO SYSTEMS, INC.

[0001193125-19-291002:8k_2_02:75]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-19-291002:8k_2_02:76]
(In millions, except percentages)

[0001193125-19-291002:8k_2_02:77]
|  |  | Three Months EndedOctober 26, 2019 |  |
|  |  | Amount |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Including SPVSS business for all periods: |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,538 |  |  |  | (1 | )% |
| Applications |  |  | 1,499 |  |  |  | 6 | % |
| Security |  |  | 815 |  |  |  | 22 | % |
| Other Products |  |  | 26 |  |  |  | (85 | )% |
| Total Product |  |  | 9,878 |  |  |  | — | % |
| Services |  |  | 3,281 |  |  |  | 3 | % |
| Total |  | $ | 13,159 |  |  |  | 1 | % |
| Excluding SPVSS business for all periods: |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,538 |  |  |  | (1 | )% |
| Applications |  |  | 1,499 |  |  |  | 6 | % |
| Security |  |  | 815 |  |  |  | 22 | % |
| Other Products |  |  | 26 |  |  |  | (20 | )% |
| Total Product |  |  | 9,878 |  |  |  | 1 | % |
| Services |  |  | 3,281 |  |  |  | 4 | % |
| Total |  | $ | 13,159 |  |  |  | 2 | % |

[0001193125-19-291002:8k_2_02:78]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-291002:8k_2_02:79]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. SPVSS business revenue for the three
months ended October 27, 2018 was $168 million.

[0001193125-19-291002:8k_2_02:80]
6

[0001193125-19-291002:8k_2_02:81]
CISCO SYSTEMS, INC.

[0001193125-19-291002:8k_2_02:82]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-19-291002:8k_2_02:83]
(In millions)

[0001193125-19-291002:8k_2_02:84]
(Unaudited)

[0001193125-19-291002:8k_2_02:85]
|  |  | October 26,2019 |  |  | July 27,2019 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 8,587 |  |  | $ | 11,750 |  |
| Investments |  |  | 19,448 |  |  |  | 21,663 |  |
| Accounts receivable, net of allowance for doubtful accounts of $136 as of each October 26, 2019 and July 27, 2019 |  |  | 4,878 |  |  |  | 5,491 |  |
| Inventories |  |  | 1,344 |  |  |  | 1,383 |  |
| Financing receivables, net |  |  | 5,026 |  |  |  | 5,095 |  |
| Other current assets |  |  | 2,433 |  |  |  | 2,373 |  |
| Total current assets |  |  | 41,716 |  |  |  | 47,755 |  |
| Property and equipment, net |  |  | 2,669 |  |  |  | 2,789 |  |
| Financing receivables, net |  |  | 4,831 |  |  |  | 4,958 |  |
| Goodwill |  |  | 33,578 |  |  |  | 33,529 |  |
| Purchased intangible assets, net |  |  | 2,107 |  |  |  | 2,201 |  |
| Deferred tax assets |  |  | 3,963 |  |  |  | 4,065 |  |
| Other assets |  |  | 3,628 |  |  |  | 2,496 |  |
| TOTAL ASSETS |  | $ | 92,492 |  |  | $ | 97,793 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 4,000 |  |  | $ | 10,191 |  |
| Accounts payable |  |  | 2,016 |  |  |  | 2,059 |  |
| Income taxes payable |  |  | 794 |  |  |  | 1,149 |  |
| Accrued compensation |  |  | 2,735 |  |  |  | 3,221 |  |
| Deferred revenue |  |  | 10,646 |  |  |  | 10,668 |  |
| Other current liabilities |  |  | 4,406 |  |  |  | 4,424 |  |
| Total current liabilities |  |  | 24,597 |  |  |  | 31,712 |  |
| Long-term debt |  |  | 14,497 |  |  |  | 14,475 |  |
| Income taxes payable |  |  | 8,919 |  |  |  | 8,927 |  |
| Deferred revenue |  |  | 7,956 |  |  |  | 7,799 |  |
| Other long-term liabilities |  |  | 2,100 |  |  |  | 1,309 |  |
| Total liabilities |  |  | 58,069 |  |  |  | 64,222 |  |
| Total equity |  |  | 34,423 |  |  |  | 33,571 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 92,492 |  |  | $ | 97,793 |  |

[0001193125-19-291002:8k_2_02:86]
7

[0001193125-19-291002:8k_2_02:87]
CISCO SYSTEMS, INC.

[0001193125-19-291002:8k_2_02:88]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-19-291002:8k_2_02:89]
(In millions)

[0001193125-19-291002:8k_2_02:90]
(Unaudited)

[0001193125-19-291002:8k_2_02:91]
|  |  | Three Months Ended |  |
|  |  | October 26,2019 |  |  | October 27,2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 2,926 |  |  | $ | 3,549 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 461 |  |  |  | 465 |  |
| Share-based compensation expense |  |  | 395 |  |  |  | 403 |  |
| Provision (benefit) for receivables |  |  | 50 |  |  |  | 8 |  |
| Deferred income taxes |  |  | 81 |  |  |  | (72 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (8 | ) |  |  | 7 |  |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 515 |  |  |  | 892 |  |
| Inventories |  |  | 34 |  |  |  | (34 | ) |
| Financing receivables |  |  | 146 |  |  |  | 273 |  |
| Other assets |  |  | 59 |  |  |  | (295 | ) |
| Accounts payable |  |  | (45 | ) |  |  | (153 | ) |
| Income taxes, net |  |  | (330 | ) |  |  | (437 | ) |
| Accrued compensation |  |  | (473 | ) |  |  | (348 | ) |
| Deferred revenue |  |  | 158 |  |  |  | (309 | ) |
| Other liabilities |  |  | (382 | ) |  |  | (186 | ) |
| Net cash provided by operating activities |  |  | 3,587 |  |  |  | 3,763 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (2,028 | ) |  |  | (484 | ) |
| Proceeds from sales of investments |  |  | 2,342 |  |  |  | 2,805 |  |
| Proceeds from maturities of investments |  |  | 1,966 |  |  |  | 2,541 |  |
| Acquisitions and divestitures |  |  | (163 | ) |  |  | (1,964 | ) |
| Purchases of investments in privately held companies |  |  | (54 | ) |  |  | (29 | ) |
| Return of investments in privately held companies |  |  | 57 |  |  |  | 16 |  |
| Acquisition of property and equipment |  |  | (202 | ) |  |  | (212 | ) |
| Proceeds from sales of property and equipment |  |  | 4 |  |  |  | 2 |  |
| Net cash provided by investing activities |  |  | 1,922 |  |  |  | 2,675 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 2 |  |  |  | 8 |  |
| Repurchases of common stock—repurchase program |  |  | (784 | ) |  |  | (5,076 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (194 | ) |  |  | (318 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | (3,470 | ) |  |  | — |  |
| Repayments of debt |  |  | (2,720 | ) |  |  | — |  |
| Dividends paid |  |  | (1,486 | ) |  |  | (1,500 | ) |
| Other |  |  | (16 | ) |  |  | (59 | ) |
| Net cash used in financing activities |  |  | (8,668 | ) |  |  | (6,945 | ) |
| Net increase (decrease) in cash, cash equivalents, and restricted cash |  |  | (3,159 | ) |  |  | (507 | ) |
| Cash, cash equivalents, and restricted cash, beginning of period |  |  | 11,772 |  |  |  | 8,993 |  |
| Cash, cash equivalents, and restricted cash, end of period |  | $ | 8,613 |  |  | $ | 8,486 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 204 |  |  | $ | 271 |  |
| Cash paid for income taxes, net |  | $ | 1,009 |  |  | $ | 869 |  |

[0001193125-19-291002:8k_2_02:92]
8

[0001193125-19-291002:8k_2_02:93]
CISCO SYSTEMS, INC.

[0001193125-19-291002:8k_2_02:94]
DEFERRED REVENUE

[0001193125-19-291002:8k_2_02:95]
(In
millions)

[0001193125-19-291002:8k_2_02:96]
|  |  | October 26,2019 |  |  | July 27,2019 |  |  | October 27,2018 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 11,497 |  |  | $ | 11,709 |  |  | $ | 11,062 |  |
| Product |  |  | 7,105 |  |  |  | 6,758 |  |  |  | 5,752 |  |
| Total |  | $ | 18,602 |  |  | $ | 18,467 |  |  | $ | 16,814 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 10,646 |  |  | $ | 10,668 |  |  | $ | 9,637 |  |
| Noncurrent |  |  | 7,956 |  |  |  | 7,799 |  |  |  | 7,177 |  |
| Total |  | $ | 18,602 |  |  | $ | 18,467 |  |  | $ | 16,814 |  |

[0001193125-19-291002:8k_2_02:97]
CISCO SYSTEMS, INC.

[0001193125-19-291002:8k_2_02:98]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-19-291002:8k_2_02:99]
(In millions, except per-share amounts)

[0001193125-19-291002:8k_2_02:100]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| October 26, 2019 |  | $ | 0.35 |  |  | $ | 1,486 |  |  |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |  | $ | 2,254 |  |
| Fiscal 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 27, 2019 |  | $ | 0.35 |  |  | $ | 1,490 |  |  |  | 82 |  |  | $ | 54.99 |  |  | $ | 4,515 |  |  | $ | 6,005 |  |
| April 27, 2019 |  | $ | 0.35 |  |  | $ | 1,519 |  |  |  | 116 |  |  | $ | 52.14 |  |  | $ | 6,020 |  |  | $ | 7,539 |  |
| January 26, 2019 |  | $ | 0.33 |  |  | $ | 1,470 |  |  |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |  | $ | 6,486 |  |
| October 27, 2018 |  | $ | 0.33 |  |  | $ | 1,500 |  |  |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |  | $ | 6,526 |  |

[0001193125-19-291002:8k_2_02:101]
CISCO SYSTEMS, INC.

[0001193125-19-291002:8k_2_02:102]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-19-291002:8k_2_02:103]
GAAP TO NON-GAAP NET INCOME

[0001193125-19-291002:8k_2_02:104]
(In millions, except per-share amounts)

[0001193125-19-291002:8k_2_02:105]
|  |  | Three Months Ended |  |
|  |  | October 26,2019 |  |  | October 27,2018 |  |
| GAAP net income |  | $ | 2,926 |  |  | $ | 3,549 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 57 |  |  |  | 56 |  |
| Amortization of acquisition-related intangible assets |  |  | 150 |  |  |  | 136 |  |
| Supplier component remediation charge (adjustment), net |  |  | — |  |  |  | (1 | ) |
| Acquisition-related/divestiture costs |  |  | 1 |  |  |  | 4 |  |
| Legal and indemnification settlements |  |  | 4 |  |  |  | — |  |
| Total adjustments to GAAP cost of sales |  |  | 212 |  |  |  | 195 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 333 |  |  |  | 329 |  |
| Amortization of acquisition-related intangible assets |  |  | 36 |  |  |  | 34 |  |
| Acquisition-related/divestiture costs |  |  | 72 |  |  |  | 121 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | (395 | ) |
| Significant asset impairments and restructurings |  |  | 184 |  |  |  | 78 |  |
| Total adjustments to GAAP operating expenses |  |  | 625 |  |  |  | 167 |  |
| Adjustments to GAAP interest and other income (loss), net: |  |  |  |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | (13 | ) |  |  | (9 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 824 |  |  |  | 353 |  |
| Income tax effect of non-GAAP adjustments |  |  | (209 | ) |  |  | (185 | ) |
| Significant tax matters |  |  | 67 |  |  |  | (265 | ) |
| Total adjustments to GAAP provision for income taxes |  |  | (142 | ) |  |  | (450 | ) |
| Non-GAAP net income |  | $ | 3,608 |  |  | $ | 3,452 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.68 |  |  | $ | 0.77 |  |
| Non-GAAP |  | $ | 0.84 |  |  | $ | 0.75 |  |

[0001193125-19-291002:8k_2_02:106]
10

[0001193125-19-291002:8k_2_02:107]
CISCO SYSTEMS, INC.

[0001193125-19-291002:8k_2_02:108]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-19-291002:8k_2_02:109]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-19-291002:8k_2_02:110]
(In millions, except percentages)

[0001193125-19-291002:8k_2_02:111]
|  |  | Three Months Ended |  |
|  |  | October 26, 2019 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 6,354 |  |  | $ | 2,110 |  |  | $ | 8,464 |  |  | $ | 4,885 |  |  |  | 13 | % |  | $ | 3,579 |  |  |  | (6 | )% |  | $ | 107 |  |  |  | 3 | % |  | $ | 2,926 |  |  |  | (18 | )% |
| % of revenue |  |  | 64.3 | % |  |  | 64.3 | % |  |  | 64.3 | % |  |  | 37.1 | % |  |  |  |  |  |  | 27.2 | % |  |  |  |  |  |  | 0.8 | % |  |  |  |  |  |  | 22.2 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 23 |  |  |  | 34 |  |  |  | 57 |  |  |  | 333 |  |  |  |  |  |  |  | 390 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 390 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 150 |  |  |  | — |  |  |  | 150 |  |  |  | 36 |  |  |  |  |  |  |  | 186 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 186 |  |  |  |  |  |
| Legal and indemnification settlements |  |  | 4 |  |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  |  |  |  |  | 4 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 4 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 72 |  |  |  |  |  |  |  | 73 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 73 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 184 |  |  |  |  |  |  |  | 184 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 184 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (13 | ) |  |  |  |  |  |  | (13 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (142 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 6,531 |  |  | $ | 2,145 |  |  | $ | 8,676 |  |  | $ | 4,260 |  |  |  | 4 | % |  | $ | 4,416 |  |  |  | 6 | % |  | $ | 94 |  |  |  | (1 | )% |  | $ | 3,608 |  |  |  | 5 | % |
| % of revenue |  |  | 66.1 | % |  |  | 65.4 | % |  |  | 65.9 | % |  |  | 32.4 | % |  |  |  |  |  |  | 33.6 | % |  |  |  |  |  |  | 0.7 | % |  |  |  |  |  |  | 27.4 | % |  |  |  |  |

[0001193125-19-291002:8k_2_02:112]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-291002:8k_2_02:113]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. Accordingly, the non-GAAP growth rates are normalized to exclude the SPVSS business for the first quarter of fiscal 2019.

[0001193125-19-291002:8k_2_02:114]
|  |  | Three Months Ended |  |
|  |  | October 27, 2018 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 6,091 |  |  | $ | 2,055 |  |  | $ | 8,146 |  |  | $ | 4,341 |  |  | $ | 3,805 |  |  | $ | 104 |  |  | $ | 3,549 |  |
| % of revenue |  |  | 61.6 | % |  |  | 64.6 | % |  |  | 62.3 | % |  |  | 33.2 | % |  |  | 29.1 | % |  |  | 0.8 | % |  |  | 27.1 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 23 |  |  |  | 33 |  |  |  | 56 |  |  |  | 329 |  |  |  | 385 |  |  |  | — |  |  |  | 385 |  |
| Amortization of acquisition-related intangible assets |  |  | 136 |  |  |  | — |  |  |  | 136 |  |  |  | 34 |  |  |  | 170 |  |  |  | — |  |  |  | 170 |  |
| Supplier component remediation charge (adjustment), net |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (395 | ) |  |  | (395 | ) |  |  | — |  |  |  | (395 | ) |
| Acquisition/divestiture-related costs |  |  | 2 |  |  |  | 2 |  |  |  | 4 |  |  |  | 121 |  |  |  | 125 |  |  |  | — |  |  |  | 125 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 78 |  |  |  | 78 |  |  |  | — |  |  |  | 78 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (9 | ) |  |  | (9 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (450 | ) |
| Non-GAAP amount |  | $ | 6,251 |  |  | $ | 2,090 |  |  | $ | 8,341 |  |  | $ | 4,174 |  |  | $ | 4,167 |  |  | $ | 95 |  |  | $ | 3,452 |  |
| Less: SPVSS business (1) |  |  | (51 | ) |  |  | (9 | ) |  |  | (61 | ) |  |  | (59 | ) |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |
| Non-GAAP amount (excluding SPVSS business) |  | $ | 6,200 |  |  | $ | 2,081 |  |  | $ | 8,281 |  |  | $ | 4,115 |  |  | $ | 4,166 |  |  | $ | 95 |  |  | $ | 3,451 |  |
| % of revenue |  |  | 63.6 | % |  |  | 65.8 | % |  |  | 64.2 | % |  |  | 31.9 | % |  |  | 32.3 | % |  |  | 0.7 | % |  |  | 26.7 | % |

[0001193125-19-291002:8k_2_02:115]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-291002:8k_2_02:116]
| (1) | Reflects three months of operations for the SPVSS business. |

[0001193125-19-291002:8k_2_02:117]
12

[0001193125-19-291002:8k_2_02:118]
CISCO SYSTEMS, INC.

[0001193125-19-291002:8k_2_02:119]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-19-291002:8k_2_02:120]
EFFECTIVE TAX RATE

[0001193125-19-291002:8k_2_02:121]
(In
percentages)

[0001193125-19-291002:8k_2_02:122]
|  |  | Three Months Ended |  |
|  |  | October 26,2019 |  |  | October 27,2018 |  |
| GAAP effective tax rate |  |  | 20.6 | % |  |  | 9.2 | % |
| Total adjustments to GAAP provision for income taxes |  |  | (0.6 | )% |  |  | 9.8 | % |
| Non-GAAP effective tax rate |  |  | 20.0 | % |  |  | 19.0 | % |

[0001193125-19-291002:8k_2_02:123]
GAAP TO NON-GAAP GUIDANCE FOR Q2 FY 2020

[0001193125-19-291002:8k_2_02:124]
| Q2 FY 2020 |  | Gross MarginRate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (1) |
| GAAP |  | 63% - 64% |  | 27% - 28% |  | 19% |  | $0.61 - $0.67 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.0% |  | — |  | $0.06 - $0.07 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 1.0% |  | 2.0% |  | — |  | $0.04 - $0.06 |
| Significant asset impairments and restructurings |  | — |  | 0.5% |  | — |  | $0.00 - $0.01 |
| Income tax effect of non-GAAP adjustments |  |  |  |  |  | 1% |  |  |
| Non-GAAP |  | 64.5% - 65.5% |  | 32.5% - 33.5% |  | 20% |  | $0.75 - $0.77 |

[0001193125-19-291002:8k_2_02:125]
| (1) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-19-291002:8k_2_02:126]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and significant
tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-19-291002:8k_2_02:127]
13

[0001193125-19-291002:8k_2_02:128]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-19-291002:8k_2_02:129]
This release includes non-GAAP net income,
non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin,
non-GAAP effective tax rates, non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the
periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-19-291002:8k_2_02:130]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with
generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any
comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as
determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-19-291002:8k_2_02:131]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP
measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-19-291002:8k_2_02:132]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other contingencies, gains and losses on equity investments, the
income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial
results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be other items that
Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial
measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-19-291002:8k_2_02:133]
14

[0001193125-19-291002:8k_2_02:134]
Cisco divested its Service Provider Video Software Solutions business (SPVSS) during the second quarter of
fiscal 2019 on October 28, 2018. This release includes, where indicated, financial measures that exclude the SPVSS business. Cisco believes that the presentation of these measures provides useful information to investors and management
regarding financial and business trends relating to its financial condition and its historical and projected results of operations because the SPVSS business will not be part of Cisco on a go forward basis. Cisco’s management also uses the
financial measures excluding the SPVSS business in reviewing the financial results of Cisco.

[0001193125-19-291002:8k_2_02:135]
About Cisco

[0001193125-19-291002:8k_2_02:136]
Cisco (Nasdaq: CSCO) is the worldwide technology leader that has been making the Internet work since 1984. Our people, products and partners help society
securely connect and seize tomorrow’s digital opportunity today. Discover more at newsroom.cisco.com and follow us on Twitter at @Cisco.

[0001193125-19-291002:8k_2_02:137]
Copyright © 2019 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a
list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any
other company. This document is Cisco Public Information.

[0001193125-19-291002:8k_2_02:138]
RSS Feed for
Cisco: https://newsroom.cisco.com/rss-feeds
