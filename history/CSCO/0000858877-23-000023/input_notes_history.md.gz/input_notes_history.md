# CSCO note change history — 0000858877-23-000005 → 0000858877-23-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0000858877-23-000013:note_history:1]
|  | April 29,2023 |  | July 30,2022 |
| Less than 1 year | $ | 7,073 |  |  | $ | 9,954 |  |
| 1 to 3 years | 1,618 |  |  | 2,240 |  |
| 3 to 5 years | 368 |  |  | 770 |  |
| Total | $ | 9,059 |  |  | $ | 12,964 |  |
  (was, 2023-02-21, similarity 0.9753):
[0000858877-23-000005:note_history:1]
|  | January 28,2023 |  | July 30,2022 |
| Less than 1 year | $ | 8,651 |  |  | $ | 9,954 |  |
| 1 to 3 years | 1,693 |  |  | 2,240 |  |
| 3 to 5 years | 607 |  |  | 770 |  |
| Total | $ | 10,951 |  |  | $ | 12,964 |  |

- changed (2023-05-24):
[0000858877-23-000013:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 29, 2023 and July 30, 2022, the liability for these purchase commitments was $525 million and $313 million, respectively, and was included in other current liabilities.
  (was, 2023-02-21, similarity 0.6941):
[0000858877-23-000005:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 28, 2023 and July 30, 2022, the liability for these purchase commitments was $450 million and $313 million, respectively, and was included in other current liabilities.

- changed (2023-05-24):
[0000858877-23-000013:note_history:3]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2023 |  | April 30, 2022 |  | April 29, 2023 |  | April 30, 2022 |
| Compensation expense related to acquisitions | $ | 53 |  |  | $ | 56 |  |  | $ | 176 |  |  | $ | 220 |  |
  (was, 2023-02-21, similarity 0.7309):
[0000858877-23-000005:note_history:3]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2023 |  | January 29, 2022 |  | January 28, 2023 |  | January 29, 2022 |
| Compensation expense related to acquisitions | $ | 49 |  |  | $ | 75 |  |  | $ | 123 |  |  | $ | 164 |  |

- changed (2023-05-24):
[0000858877-23-000013:note_history:4]
As of April 29, 2023, we estimated that future cash compensation expense of up to $310 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2023-02-21, similarity 0.9778):
[0000858877-23-000005:note_history:4]
As of January 28, 2023, we estimated that future cash compensation expense of up to $338 million may be required to be recognized pursuant to the applicable business combination agreements.

- changed (2023-05-24):
[0000858877-23-000013:note_history:5]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion and $0.4 billion as of April 29, 2023 and July 30, 2022, respectively.
  (was, 2023-02-21, similarity 0.9129):
[0000858877-23-000005:note_history:5]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion and $0.4 billion as of January 28, 2023 and July 30, 2022, respectively.

- changed (2023-05-24):
[0000858877-23-000013:note_history:6]
|  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |
| Balance at beginning of period | $ | 333 |  |  | $ | 336 |  |
| Provisions for warranties issued | 285 |  |  | 320 |  |
| Adjustments for pre-existing warranties | 15 |  |  | 1 |  |
| Settlements | (321) |  |  | (322) |  |
| Balance at end of period | $ | 312 |  |  | $ | 335 |  |
  (was, 2023-02-21, similarity 0.9254):
[0000858877-23-000005:note_history:6]
|  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |
| Balance at beginning of period | $ | 333 |  |  | $ | 336 |  |
| Provisions for warranties issued | 188 |  |  | 218 |  |
| Adjustments for pre-existing warranties | 13 |  |  | 2 |  |
| Settlements | (218) |  |  | (222) |  |
| Balance at end of period | $ | 316 |  |  | $ | 334 |  |

- changed (2023-05-24):
[0000858877-23-000013:note_history:7]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $8.3 billion and $6.9 billion for the third quarter of fiscal 2023 and 2022, respectively, and $23.4 billion and $20.3 billion for the first nine months of fiscal 2023 and 2022, respectively. The balance of the channel partner financing subject to guarantees was $1.8 billion and $1.4 billion as of April 29, 2023 and July 30, 2022, respectively.
  (was, 2023-02-21, similarity 0.9688):
[0000858877-23-000005:note_history:7]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.5 billion and $6.8 billion for the second quarter of fiscal 2023 and 2022, respectively, and $15.1 billion and $13.4 billion for the first six months of fiscal 2023 and 2022, respectively. The balance of the channel partner financing subject to guarantees was $1.6 billion and $1.4 billion as of January 28, 2023 and July 30, 2022, respectively.

- changed (2023-05-24):
[0000858877-23-000013:note_history:8]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at April 29, 2023 and July 30, 2022, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2023-02-21, similarity 0.9817):
[0000858877-23-000005:note_history:8]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at January 28, 2023 and July 30, 2022, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2023-05-24):
[0000858877-23-000013:note_history:9]
|  | April 29,2023 |  | July 30,2022 |
| Maximum potential future payments | $ | 177 |  |  | $ | 188 |  |
| Deferred revenue | (40) |  |  | (9) |  |
| Total | $ | 137 |  |  | $ | 179 |  |
  (was, 2023-02-21, similarity 0.9744):
[0000858877-23-000005:note_history:9]
|  | January 28,2023 |  | July 30,2022 |
| Maximum potential future payments | $ | 180 |  |  | $ | 188 |  |
| Deferred revenue | (35) |  |  | (9) |  |
| Total | $ | 145 |  |  | $ | 179 |  |

- changed (2023-05-24):
[0000858877-23-000013:note_history:10]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $162 million for the alleged evasion of import and other taxes, $908 million for interest, and $401 million for various penalties, all determined using an exchange rate as of April 29, 2023.
  (was, 2023-02-21, similarity 0.995):
[0000858877-23-000005:note_history:10]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $159 million for the alleged evasion of import and other taxes, $873 million for interest, and $394 million for various penalties, all determined using an exchange rate as of January 28, 2023.

- changed (2023-05-24):
[0000858877-23-000013:note_history:11]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. The district court case went to trial on five asserted patents. Subsequently, on October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent and awarded $1.9 billion in damages and $14 million in pre-judgment interest, declined to issue an injunction but, instead, awarded Centripetal a royalty against future revenue for an initial three-year term at a 10% rate, with a minimum and maximum annual royalty of $168 million and $300 million, respectively, and for a second three-year term at a 5% rate, with a minimum and maximum annual royalty of $84 million and $150 million, respectively. We appealed and, on June 23, 2022, the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”) vacated the district court’s final judgment, remanded the case back to the district court to be assigned to a new judge and ordered the district court to conduct additional proceedings and the district court set a hearing to commence on June 22, 2023. On May 24, 2023, the Patent Trial and Appeal Board cancelled all claims of one of the Centripetal patents that is the subject of the hearing set for June 22, 2023. On August 9, 2022, Centripetal filed a petition for writ of certiorari in the U.S. Supreme Court challenging the Federal Circuit’s decision. The Supreme Court denied Centripetal’s petition on December 5, 2022.
  (was, 2023-02-21, similarity 0.8284):
[0000858877-23-000005:note_history:11]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. The district court case went to trial on five asserted patents. Subsequently, on October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent and awarded $1.9 billion in damages and $14 million in pre-judgment interest, declined to issue an injunction but, instead, awarded Centripetal a royalty against future revenue for an initial three-year term at a 10% rate, with a minimum and maximum annual royalty of $168 million and $300 million, respectively, and for a second three-year term at a 5% rate, with a minimum and maximum annual royalty of $84 million and $150 million, respectively. We appealed and, on June 23, 2022, the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”) vacated the district court’s final judgment, remanded the case back to the district court to be assigned to a new judge and ordered the district court to conduct additional proceedings and the district court set a hearing to commence on June 22, 2023. On August 9, 2022, Centripetal filed a petition for writ of certiorari in the U.S. Supreme Court challenging the Federal Circuit’s decision. The Supreme Court denied Centripetal’s petition on December 5, 2022.

- changed (2023-05-24):
[0000858877-23-000013:note_history:12]
On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents in the same family as those involved in the pending cases above. Ramot is asserting
  (was, 2023-02-21, similarity 0.7932):
[0000858877-23-000005:note_history:12]
On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents in the same family as those involved in the pending cases above. Ramot is asserting counterclaims for infringement of the same patents and seeks damages, including enhanced damages, and a royalty on future

- changed (2023-05-24):
[0000858877-23-000013:note_history:13]
counterclaims for infringement of the same patents and seeks damages, including enhanced damages, and a royalty on future sales. While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.
  (was, 2023-02-21, similarity 0.892):
[0000858877-23-000005:note_history:13]
sales. While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

- added (2023-05-24):
[0000858877-23-000013:note_history:14]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward (“Viasat 2019”). In May 2023, a judgment was entered against Cisco in Viasat 2019 for an amount that did not have a material effect on our Consolidated Financial Statements.

- added (2023-05-24):
[0000858877-23-000013:note_history:15]
On June 9, 2020, Viasat filed a third suit in SDSC alleging contract and trade secrets claims for sales of additional Acacia products (“Viasat 2020”). In October 2022, an amended complaint was filed in Viasat 2020 asserting the same claims but alleging additional information. We are unable to reasonably estimate the ultimate outcome of Viasat 2020 at this time due to uncertainties in the litigation processes. If we do not prevail, we believe that any relief ultimately assessed in Viasat 2020 will not have a material effect on our Consolidated Financial Statements.

- removed (2023-05-24):
[0000858877-23-000005:note_history:16]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward (“Viasat 2”). Viasat 2 is similar to a previous suit Viasat filed against Acacia and which resolved in July 2022 for an immaterial amount (“Viasat 1”). On June 9, 2020, Viasat filed a third suit in SDSC alleging contract and trade secrets claims for sales of additional Acacia products (“Viasat 3”, together with Viasat 2, the “Viasat Cases”). In October 2022, an amended complaint was filed in Viasat 3 asserting the same claims but alleging additional information.

- removed (2023-05-24):
[0000858877-23-000005:note_history:17]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court against Viasat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation (the “Massachusetts Action”). On April 5, 2018, Viasat counterclaimed with contract, trade secret, and unfair competition claims. Following resolution of Viasat 1, Acacia and Viasat jointly agreed to dismiss the Massachusetts Action in October 2022, thereby resolving the case.

- removed (2023-05-24):
[0000858877-23-000005:note_history:18]
We are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If we do not prevail, we believe that any relief ultimately assessed in any of the Viasat Cases would not have a material effect on our Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0000858877-23-000013:note_history:19]
We have prepared the accompanying financial data as of April 29, 2023 and for the third quarter and first nine months of fiscal 2023 and 2022, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 30, 2022 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 30, 2022.
  (was, 2023-02-21, similarity 0.9861):
[0000858877-23-000005:note_history:19]
We have prepared the accompanying financial data as of January 28, 2023 and for the second quarter and first six months of fiscal 2023 and 2022, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 30, 2022 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 30, 2022.

- changed (2023-05-24):
[0000858877-23-000013:note_history:20]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of April 29, 2023, the results of operations, the statements of comprehensive income and the statements of equity for the third quarter and first nine months of fiscal 2023 and 2022, and the statements of cash flows for the first nine months of fiscal 2023 and 2022, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2023 are not necessarily indicative of the operating results for the full fiscal year or any future periods.
  (was, 2023-02-21, similarity 0.9565):
[0000858877-23-000005:note_history:20]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of January 28, 2023, the results of operations, the statements of comprehensive income and the statements of equity for the second quarter and first six months of fiscal 2023 and 2022, and the statements of cash flows for the first six months of fiscal 2023 and 2022, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2023 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- changed (2023-05-24):
[0000858877-23-000013:note_history:21]
Our consolidated financial statements include our accounts and investments consolidated under the voting interest model. The noncontrolling interests attributed to these investments are not presented as a separate component in the equity section of the Consolidated Balance Sheets as these amounts are not material for any of the fiscal periods presented. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.
  (was, 2023-02-21, similarity 0.9637):
[0000858877-23-000005:note_history:21]
Our consolidated financial statements include our accounts and investments consolidated under the variable interest and voting models. The noncontrolling interests attributed to these investments are not presented as a separate component in the equity section of the Consolidated Balance Sheets as these amounts are not material for any of the fiscal periods presented. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0000858877-23-000013:note_history:22]
|  | April 29, 2023 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,731 |  |  | 4.26 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,731 |  |  |  |  | $ | 1,099 |  |  |  |
  (was, 2023-02-21, similarity 0.9773):
[0000858877-23-000005:note_history:22]
|  | January 28, 2023 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,250 |  |  | 2.44 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,250 |  |  |  |  | $ | 1,099 |  |  |  |

- changed (2023-05-24):
[0000858877-23-000013:note_history:23]
|  |  |  | April 29, 2023 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 5.75% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.15% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 8,500 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (70) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (36) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,394 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,731 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 6,663 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,394 |  |  |  |  | $ | 8,915 |  |  |  |
  (was, 2023-02-21, similarity 0.9849):
[0000858877-23-000005:note_history:23]
|  |  |  | January 28, 2023 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | 500 |  |  | 2.68% |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 5.28% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 5.65% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,000 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (71) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (42) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,887 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,250 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 7,637 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,887 |  |  |  |  | $ | 8,915 |  |  |  |

- changed (2023-05-24):
[0000858877-23-000013:note_history:24]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 29, 2023, we were in compliance with all debt covenants.
  (was, 2023-02-21, similarity 0.9863):
[0000858877-23-000005:note_history:24]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 28, 2023, we were in compliance with all debt covenants.

- changed (2023-05-24):
[0000858877-23-000013:note_history:25]
As of April 29, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2023-02-21, similarity 0.9701):
[0000858877-23-000005:note_history:25]
As of January 28, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2023-05-24):
[0000858877-23-000013:note_history:26]
| Fiscal Year | Amount |
| 2023 (remaining three months) | $ | — |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 8,500 |  |
  (was, 2023-02-21, similarity 0.9673):
[0000858877-23-000005:note_history:26]
| Fiscal Year | Amount |
| 2023 (remaining six months) | $ | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 9,000 |  |

- added (2023-05-24):
[0000858877-23-000013:note_history:27]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of April 29, 2023, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit

- added (2023-05-24):
[0000858877-23-000013:note_history:28]
agreement. On April 18, 2023, we entered into an amendment to the credit agreement to replace the LIBOR index with Term Secured Overnight Financing Rate (SOFR).

- changed (2023-05-24):
[0000858877-23-000013:note_history:29]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) Term SOFR (plus a 0.10% credit spread adjustment) or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) Term SOFR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.
  (was, 2023-02-21, similarity 0.8397):
[0000858877-23-000005:note_history:29]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of January 28, 2023, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0000858877-23-000013:note_history:30]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 29, 2023 and July 30, 2022 (in millions):
  (was, 2023-02-21, similarity 0.9716):
[0000858877-23-000005:note_history:30]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 28, 2023 and July 30, 2022 (in millions):

- changed (2023-05-24):
[0000858877-23-000013:note_history:31]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 29, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 360 |  |  | $ | (2) |  |  | $ | 1,125 |  |  | $ | (40) |  |  | $ | 1,485 |  |  | $ | (42) |  |
| U.S. government agency securities | 148 |  |  | (1) |  |  | 110 |  |  | (3) |  |  | 258 |  |  | (4) |  |
| Non-U.S. government and agency securities | 291 |  |  | — |  |  | — |  |  | — |  |  | 291 |  |  | — |  |
| Corporate debt securities | 1,387 |  |  | (14) |  |  | 4,869 |  |  | (261) |  |  | 6,256 |  |  | (275) |  |
| U.S. agency mortgage-backed securities | 343 |  |  | (5) |  |  | 1,514 |  |  | (203) |  |  | 1,857 |  |  | (208) |  |
| Commercial paper | 69 |  |  | — |  |  | — |  |  | — |  |  | 69 |  |  | — |  |
| Certificates of deposit | 5 |  |  | — |  |  | — |  |  | — |  |  | 5 |  |  | — |  |
| Total | $ | 2,603 |  |  | $ | (22) |  |  | $ | 7,618 |  |  | $ | (507) |  |  | $ | 10,221 |  |  | $ | (529) |  |
  (was, 2023-02-21, similarity 0.8343):
[0000858877-23-000005:note_history:31]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 28, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 470 |  |  | $ | (6) |  |  | $ | 1,086 |  |  | $ | (48) |  |  | $ | 1,556 |  |  | $ | (54) |  |
| U.S. government agency securities | 33 |  |  | — |  |  | 121 |  |  | (5) |  |  | 154 |  |  | (5) |  |
| Non-U.S. government and agency securities | 339 |  |  | (1) |  |  | — |  |  | — |  |  | 339 |  |  | (1) |  |
| Corporate debt securities | 2,770 |  |  | (94) |  |  | 3,333 |  |  | (219) |  |  | 6,103 |  |  | (313) |  |
| U.S. agency mortgage-backed securities | 305 |  |  | (12) |  |  | 1,440 |  |  | (176) |  |  | 1,745 |  |  | (188) |  |
| Commercial paper | 40 |  |  | — |  |  | — |  |  | — |  |  | 40 |  |  | — |  |
| Total | $ | 3,957 |  |  | $ | (113) |  |  | $ | 5,980 |  |  | $ | (448) |  |  | $ | 9,937 |  |  | $ | (561) |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-05-24):
[0000858877-23-000013:note_history:32]
| April 29, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,833 |  |  | $ | 9 |  |  | $ | (42) |  |  | $ | 2,800 |  |
| U.S. government agency securities | 365 |  |  | 1 |  |  | (4) |  |  | 362 |  |
| Non-U.S. government and agency securities | 352 |  |  | — |  |  | — |  |  | 352 |  |
| Corporate debt securities | 7,587 |  |  | 8 |  |  | (305) |  |  | 7,290 |  |
| U.S. agency mortgage-backed securities | 2,221 |  |  | 1 |  |  | (208) |  |  | 2,014 |  |
| Commercial paper | 1,595 |  |  | — |  |  | — |  |  | 1,595 |  |
| Certificates of deposit | 485 |  |  | — |  |  | — |  |  | 485 |  |
| Total | $ | 15,438 |  |  | $ | 19 |  |  | $ | (559) |  |  | $ | 14,898 |  |

- changed (2023-05-24):
[0000858877-23-000013:note_history:33]
Net unsettled investment purchases were $9 million and net unsettled investment sales were $70 million as of April 29, 2023 and July 30, 2022, respectively, and were included in other current assets and other current liabilities.
  (was, 2023-02-21, similarity 0.9725):
[0000858877-23-000005:note_history:33]
Net unsettled investment purchases were $15 million and net unsettled investment sales were $70 million as of January 28, 2023 and July 30, 2022, respectively, and were included in other current assets and other current liabilities.

- changed (2023-05-24):
[0000858877-23-000013:note_history:34]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2023 |  | April 30, 2022 |  | April 29, 2023 |  | April 30, 2022 |
| Gross realized gains | $ | 1 |  |  | $ | 8 |  |  | $ | 4 |  |  | $ | 27 |  |
| Gross realized losses | (7) |  |  | (6) |  |  | (19) |  |  | (9) |  |
| Total | $ | (6) |  |  | $ | 2 |  |  | $ | (15) |  |  | $ | 18 |  |
  (was, 2023-02-21, similarity 0.8231):
[0000858877-23-000005:note_history:34]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2023 |  | January 29, 2022 |  | January 28, 2023 |  | January 29, 2022 |
| Gross realized gains | $ | 3 |  |  | $ | 13 |  |  | $ | 3 |  |  | $ | 19 |  |
| Gross realized losses | (6) |  |  | (3) |  |  | (12) |  |  | (3) |  |
| Total | $ | (3) |  |  | $ | 10 |  |  | $ | (9) |  |  | $ | 16 |  |

- changed (2023-05-24):
[0000858877-23-000013:note_history:35]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 29, 2023 and July 30, 2022 (in millions):
  (was, 2023-02-21, similarity 0.9716):
[0000858877-23-000005:note_history:35]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 28, 2023 and July 30, 2022 (in millions):

- changed (2023-05-24):
[0000858877-23-000013:note_history:36]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 29, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 360 |  |  | $ | (2) |  |  | $ | 1,125 |  |  | $ | (40) |  |  | $ | 1,485 |  |  | $ | (42) |  |
| U.S. government agency securities | 148 |  |  | (1) |  |  | 110 |  |  | (3) |  |  | 258 |  |  | (4) |  |
| Non-U.S. government and agency securities | 291 |  |  | — |  |  | — |  |  | — |  |  | 291 |  |  | — |  |
| Corporate debt securities | 1,387 |  |  | (14) |  |  | 4,869 |  |  | (261) |  |  | 6,256 |  |  | (275) |  |
| U.S. agency mortgage-backed securities | 343 |  |  | (5) |  |  | 1,514 |  |  | (203) |  |  | 1,857 |  |  | (208) |  |
| Commercial paper | 69 |  |  | — |  |  | — |  |  | — |  |  | 69 |  |  | — |  |
| Certificates of deposit | 5 |  |  | — |  |  | — |  |  | — |  |  | 5 |  |  | — |  |
| Total | $ | 2,603 |  |  | $ | (22) |  |  | $ | 7,618 |  |  | $ | (507) |  |  | $ | 10,221 |  |  | $ | (529) |  |
  (was, 2023-02-21, similarity 0.8343):
[0000858877-23-000005:note_history:36]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 28, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 470 |  |  | $ | (6) |  |  | $ | 1,086 |  |  | $ | (48) |  |  | $ | 1,556 |  |  | $ | (54) |  |
| U.S. government agency securities | 33 |  |  | — |  |  | 121 |  |  | (5) |  |  | 154 |  |  | (5) |  |
| Non-U.S. government and agency securities | 339 |  |  | (1) |  |  | — |  |  | — |  |  | 339 |  |  | (1) |  |
| Corporate debt securities | 2,770 |  |  | (94) |  |  | 3,333 |  |  | (219) |  |  | 6,103 |  |  | (313) |  |
| U.S. agency mortgage-backed securities | 305 |  |  | (12) |  |  | 1,440 |  |  | (176) |  |  | 1,745 |  |  | (188) |  |
| Commercial paper | 40 |  |  | — |  |  | — |  |  | — |  |  | 40 |  |  | — |  |
| Total | $ | 3,957 |  |  | $ | (113) |  |  | $ | 5,980 |  |  | $ | (448) |  |  | $ | 9,937 |  |  | $ | (561) |  |

- changed (2023-05-24):
[0000858877-23-000013:note_history:37]
The following table summarizes the maturities of our available-for-sale debt investments as of April 29, 2023 (in millions):
  (was, 2023-02-21, similarity 0.9667):
[0000858877-23-000005:note_history:37]
The following table summarizes the maturities of our available-for-sale debt investments as of January 28, 2023 (in millions):

- changed (2023-05-24):
[0000858877-23-000013:note_history:38]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 5,821 |  |  | $ | 5,762 |  |
| After 1 year through 5 years | 7,340 |  |  | 7,067 |  |
| After 5 years through 10 years | 54 |  |  | 53 |  |
| After 10 years | 2 |  |  | 2 |  |
| Mortgage-backed securities with no single maturity | 2,221 |  |  | 2,014 |  |
| Total | $ | 15,438 |  |  | $ | 14,898 |  |
  (was, 2023-02-21, similarity 0.9443):
[0000858877-23-000005:note_history:38]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 4,806 |  |  | $ | 4,734 |  |
| After 1 year through 5 years | 6,491 |  |  | 6,170 |  |
| After 5 years through 10 years | 46 |  |  | 41 |  |
| Mortgage-backed securities with no single maturity | 2,013 |  |  | 1,827 |  |
| Total | $ | 13,356 |  |  | $ | 12,772 |  |

- changed (2023-05-24):
[0000858877-23-000013:note_history:39]
We held marketable equity securities of $346 million and $241 million as of April 29, 2023 and July 30, 2022, respectively. We recognized a net unrealized loss of $2 million and $11 million during the third quarter and first nine months of fiscal 2023, respectively, and a net unrealized loss of $19 million and $32 million during the corresponding periods of fiscal 2022, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $7 million and a net loss of $2 million for the third quarter and first nine months of fiscal 2023, respectively, and a net gain of $11 million and $28 million for the corresponding periods of fiscal 2022, respectively. We held equity interests in certain private equity funds of $0.9 billion and $1.1 billion as of April 29, 2023 and July 30, 2022, respectively, which are accounted for under the NAV practical expedient.
  (was, 2023-02-21, similarity 0.8939):
[0000858877-23-000005:note_history:39]
We held marketable equity securities of $280 million and $241 million as of January 28, 2023 and July 30, 2022, respectively. We recognized a net unrealized gain of $11 million and a net unrealized loss of $9 million during the second quarter and first six months of fiscal 2023, respectively, and a net unrealized loss of $18 million and $13 million during the corresponding periods of fiscal 2022, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $3 million and a net loss of $8 million for the second quarter and first six months of fiscal 2023, respectively, and a net gain of $14 million and $16 million for the corresponding periods of fiscal 2022, respectively. We held equity interests in certain private equity funds of $1.0 billion and $1.1 billion as of January 28, 2023 and July 30, 2022, respectively, which are accounted for under the NAV practical expedient.

- changed (2023-05-24):
[0000858877-23-000013:note_history:40]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 29, 2023, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2023-02-21, similarity 0.9893):
[0000858877-23-000005:note_history:40]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 28, 2023, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- changed (2023-05-24):
[0000858877-23-000013:note_history:41]
The carrying value of our investments in privately held companies was $1.8 billion and $1.9 billion as of April 29, 2023 and July 30, 2022, respectively. Of the total carrying value of our investments in privately held companies as of April 29, 2023, $1.0 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of April 29, 2023, we have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.
  (was, 2023-02-21, similarity 0.9629):
[0000858877-23-000005:note_history:41]
The carrying value of our investments in privately held companies was $1.8 billion and $1.9 billion as of January 28, 2023 and July 30, 2022, respectively. Of the total carrying value of our investments in privately held companies as of January 28, 2023, $1.1 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of January 28, 2023, we have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.

- removed (2023-05-24):
[0000858877-23-000005:note_history:42]
| January 28, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,050 |  |  | $ | 2 |  |  | $ | (54) |  |  | $ | 1,998 |  |
| U.S. government agency securities | 169 |  |  | — |  |  | (5) |  |  | 164 |  |
| Non-U.S. government and agency securities | 354 |  |  | — |  |  | (1) |  |  | 353 |  |
| Corporate debt securities | 7,480 |  |  | 5 |  |  | (345) |  |  | 7,140 |  |
| U.S. agency mortgage-backed securities | 2,013 |  |  | 2 |  |  | (188) |  |  | 1,827 |  |
| Commercial paper | 1,029 |  |  | — |  |  | — |  |  | 1,029 |  |
| Certificates of deposit | 261 |  |  | — |  |  | — |  |  | 261 |  |
| Total | $ | 13,356 |  |  | $ | 9 |  |  | $ | (593) |  |  | $ | 12,772 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0000858877-23-000013:note_history:43]
|  |  |  | April 29, 2023 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 5.75% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.15% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 8,500 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (70) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (36) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,394 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,731 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 6,663 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,394 |  |  |  |  | $ | 8,915 |  |  |  |
  (was, 2023-02-21, similarity 0.9849):
[0000858877-23-000005:note_history:43]
|  |  |  | January 28, 2023 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | 500 |  |  | 2.68% |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 5.28% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 5.65% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,000 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (71) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (42) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,887 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,250 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 7,637 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,887 |  |  |  |  | $ | 8,915 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0000858877-23-000013:note_history:44]
As of April 29, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2023-02-21, similarity 0.9701):
[0000858877-23-000005:note_history:44]
As of January 28, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2023-05-24):
[0000858877-23-000013:note_history:45]
| Fiscal Year | Amount |
| 2023 (remaining three months) | $ | — |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 8,500 |  |
  (was, 2023-02-21, similarity 0.9673):
[0000858877-23-000005:note_history:45]
| Fiscal Year | Amount |
| 2023 (remaining six months) | $ | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 9,000 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0000858877-23-000013:note_history:46]
|  | April 29, 2023 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,731 |  |  | 4.26 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,731 |  |  |  |  | $ | 1,099 |  |  |  |
  (was, 2023-02-21, similarity 0.9773):
[0000858877-23-000005:note_history:46]
|  | January 28, 2023 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,250 |  |  | 2.44 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,250 |  |  |  |  | $ | 1,099 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0000858877-23-000013:note_history:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |  | April 29, 2023 |  | April 30, 2022 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 7,550 |  |  | $ | 5,870 |  |  | $ | 20,980 |  |  | $ | 17,737 |  |
| Internet for the Future | 1,392 |  |  | 1,324 |  |  | 4,007 |  |  | 4,019 |  |
| Collaboration | 985 |  |  | 1,132 |  |  | 3,029 |  |  | 3,308 |  |
| End-to-End Security | 958 |  |  | 938 |  |  | 2,872 |  |  | 2,716 |  |
| Optimized Application Experiences | 204 |  |  | 183 |  |  | 597 |  |  | 544 |  |
| Other Products | 3 |  |  | 2 |  |  | 7 |  |  | 7 |  |
| Total Product | 11,092 |  |  | 9,448 |  |  | 31,492 |  |  | 28,330 |  |
| Services | 3,479 |  |  | 3,387 |  |  | 10,303 |  |  | 10,125 |  |
| Total | $ | 14,571 |  |  | $ | 12,835 |  |  | $ | 41,795 |  |  | $ | 38,455 |  |
  (was, 2023-02-21, similarity 0.9205):
[0000858877-23-000005:note_history:47]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |  | January 28, 2023 |  | January 29, 2022 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 6,746 |  |  | $ | 5,899 |  |  | $ | 13,430 |  |  | $ | 11,867 |  |
| Internet for the Future | 1,306 |  |  | 1,322 |  |  | 2,616 |  |  | 2,695 |  |
| Collaboration | 958 |  |  | 1,067 |  |  | 2,044 |  |  | 2,176 |  |
| End-to-End Security | 943 |  |  | 883 |  |  | 1,914 |  |  | 1,778 |  |
| Optimized Application Experiences | 199 |  |  | 180 |  |  | 393 |  |  | 361 |  |
| Other Products | 3 |  |  | 2 |  |  | 4 |  |  | 5 |  |
| Total Product | 10,155 |  |  | 9,353 |  |  | 20,400 |  |  | 18,882 |  |
| Services | 3,437 |  |  | 3,367 |  |  | 6,824 |  |  | 6,738 |  |
| Total | $ | 13,592 |  |  | $ | 12,720 |  |  | $ | 27,224 |  |  | $ | 25,620 |  |

- changed (2023-05-24):
[0000858877-23-000013:note_history:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |  | April 29,2023 |  | April 30,2022 |
| Revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 7,550 |  |  | $ | 5,870 |  |  | $ | 20,980 |  |  | $ | 17,737 |  |
| Internet for the Future | 1,392 |  |  | 1,324 |  |  | 4,007 |  |  | 4,019 |  |
| Collaboration | 985 |  |  | 1,132 |  |  | 3,029 |  |  | 3,308 |  |
| End-to-End Security | 958 |  |  | 938 |  |  | 2,872 |  |  | 2,716 |  |
| Optimized Application Experiences | 204 |  |  | 183 |  |  | 597 |  |  | 544 |  |
| Other Products | 3 |  |  | 2 |  |  | 7 |  |  | 7 |  |
| Total Product | 11,092 |  |  | 9,448 |  |  | 31,492 |  |  | 28,330 |  |
| Services | 3,479 |  |  | 3,387 |  |  | 10,303 |  |  | 10,125 |  |
| Total | $ | 14,571 |  |  | $ | 12,835 |  |  | $ | 41,795 |  |  | $ | 38,455 |  |
  (was, 2023-02-21, similarity 0.9222):
[0000858877-23-000005:note_history:48]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |  | January 28,2023 |  | January 29,2022 |
| Revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 6,746 |  |  | $ | 5,899 |  |  | $ | 13,430 |  |  | $ | 11,867 |  |
| Internet for the Future | 1,306 |  |  | 1,322 |  |  | 2,616 |  |  | 2,695 |  |
| Collaboration | 958 |  |  | 1,067 |  |  | 2,044 |  |  | 2,176 |  |
| End-to-End Security | 943 |  |  | 883 |  |  | 1,914 |  |  | 1,778 |  |
| Optimized Application Experiences | 199 |  |  | 180 |  |  | 393 |  |  | 361 |  |
| Other Products | 3 |  |  | 2 |  |  | 4 |  |  | 5 |  |
| Total Product | 10,155 |  |  | 9,353 |  |  | 20,400 |  |  | 18,882 |  |
| Services | 3,437 |  |  | 3,367 |  |  | 6,824 |  |  | 6,738 |  |
| Total | $ | 13,592 |  |  | $ | 12,720 |  |  | $ | 27,224 |  |  | $ | 25,620 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0000858877-23-000013:note_history:49]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 29, 2023 and July 30, 2022 was $38 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2023-02-21, similarity 0.9793):
[0000858877-23-000005:note_history:49]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 28, 2023 and July 30, 2022 was $40 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-24):
[0000858877-23-000013:note_history:50]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 29, 2023 and July 30, 2022 was $38 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2023-02-21, similarity 0.9793):
[0000858877-23-000005:note_history:50]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 28, 2023 and July 30, 2022 was $40 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2023-05-24):
[0000858877-23-000013:note_history:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |  | April 29, 2023 |  | April 30, 2022 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 7,550 |  |  | $ | 5,870 |  |  | $ | 20,980 |  |  | $ | 17,737 |  |
| Internet for the Future | 1,392 |  |  | 1,324 |  |  | 4,007 |  |  | 4,019 |  |
| Collaboration | 985 |  |  | 1,132 |  |  | 3,029 |  |  | 3,308 |  |
| End-to-End Security | 958 |  |  | 938 |  |  | 2,872 |  |  | 2,716 |  |
| Optimized Application Experiences | 204 |  |  | 183 |  |  | 597 |  |  | 544 |  |
| Other Products | 3 |  |  | 2 |  |  | 7 |  |  | 7 |  |
| Total Product | 11,092 |  |  | 9,448 |  |  | 31,492 |  |  | 28,330 |  |
| Services | 3,479 |  |  | 3,387 |  |  | 10,303 |  |  | 10,125 |  |
| Total | $ | 14,571 |  |  | $ | 12,835 |  |  | $ | 41,795 |  |  | $ | 38,455 |  |
  (was, 2023-02-21, similarity 0.9205):
[0000858877-23-000005:note_history:51]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |  | January 28, 2023 |  | January 29, 2022 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 6,746 |  |  | $ | 5,899 |  |  | $ | 13,430 |  |  | $ | 11,867 |  |
| Internet for the Future | 1,306 |  |  | 1,322 |  |  | 2,616 |  |  | 2,695 |  |
| Collaboration | 958 |  |  | 1,067 |  |  | 2,044 |  |  | 2,176 |  |
| End-to-End Security | 943 |  |  | 883 |  |  | 1,914 |  |  | 1,778 |  |
| Optimized Application Experiences | 199 |  |  | 180 |  |  | 393 |  |  | 361 |  |
| Other Products | 3 |  |  | 2 |  |  | 4 |  |  | 5 |  |
| Total Product | 10,155 |  |  | 9,353 |  |  | 20,400 |  |  | 18,882 |  |
| Services | 3,437 |  |  | 3,367 |  |  | 6,824 |  |  | 6,738 |  |
| Total | $ | 13,592 |  |  | $ | 12,720 |  |  | $ | 27,224 |  |  | $ | 25,620 |  |

- changed (2023-05-24):
[0000858877-23-000013:note_history:52]
Accounts receivable, net was $5.1 billion as of April 29, 2023 compared to $6.6 billion as of July 30, 2022, as reported on the Consolidated Balance Sheets.
  (was, 2023-02-21, similarity 0.9718):
[0000858877-23-000005:note_history:52]
Accounts receivable, net was $5.2 billion as of January 28, 2023 compared to $6.6 billion as of July 30, 2022, as reported on the Consolidated Balance Sheets.

- added (2023-05-24):
[0000858877-23-000013:note_history:53]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2023 |  | April 30, 2022 |  | April 29, 2023 |  | April 30, 2022 |
| Allowance for credit loss at beginning of period | $ | 86 |  |  | $ | 70 |  |  | $ | 83 |  |  | $ | 109 |  |
| Provisions (benefits) | 9 |  |  | 17 |  |  | 23 |  |  | 53 |  |
| Recoveries (write-offs), net | (12) |  |  | (9) |  |  | (23) |  |  | (75) |  |
| Foreign exchange and other | — |  |  | — |  |  | — |  |  | (9) |  |
| Allowance for credit loss at end of period | $ | 83 |  |  | $ | 78 |  |  | $ | 83 |  |  | $ | 78 |  |

- changed (2023-05-24):
[0000858877-23-000013:note_history:54]
|  | April 29,2023 |  | July 30,2022 |
| 1 to 4 | $ | 456 |  |  | $ | 414 |  |
| 5 to 6 | 933 |  |  | 814 |  |
| 7 and Higher | 71 |  |  | 158 |  |
| Total | $ | 1,460 |  |  | $ | 1,386 |  |
  (was, 2023-02-21, similarity 0.9726):
[0000858877-23-000005:note_history:54]
|  | January 28,2023 |  | July 30,2022 |
| 1 to 4 | $ | 355 |  |  | $ | 414 |  |
| 5 to 6 | 984 |  |  | 814 |  |
| 7 and Higher | 82 |  |  | 158 |  |
| Total | $ | 1,421 |  |  | $ | 1,386 |  |

- changed (2023-05-24):
[0000858877-23-000013:note_history:55]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, was $1.4 billion as of April 29, 2023 and $1.3 billion as of  July 30, 2022, and were included in other current assets and other assets.
  (was, 2023-02-21, similarity 0.9874):
[0000858877-23-000005:note_history:55]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, was $1.4 billion as of January 28, 2023 and $1.3 billion as of  July 30, 2022, and were included in other current assets and other assets.

- added (2023-05-24):
[0000858877-23-000013:note_history:56]
Contract liabilities consist of deferred revenue. Deferred revenue was $24.3 billion as of April 29, 2023 compared to $23.3 billion as of July 30, 2022. We recognized approximately $2.7 billion and $10.6 billion of revenue during the third quarter and first nine months of fiscal 2023, respectively, that was included in the deferred revenue balance at July 30, 2022. 
(c)Capitalized Contract Acquisition CostsWe capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $1.0 billion as of each of April 29, 2023 and July 30, 2022, and were included in other current assets and other assets. The amortization expense associated with these costs was $172 million and $549 million for the third quarter and first nine months of fiscal 2023, respectively, and $175 million and $492 million for the corresponding periods of fiscal 2022, respectively, and was included in sales and marketing expenses.

- removed (2023-05-24):
[0000858877-23-000005:note_history:57]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2023 |  | January 29, 2022 |  | January 28, 2023 |  | January 29, 2022 |
| Allowance for credit loss at beginning of period | $ | 88 |  |  | $ | 114 |  |  | $ | 83 |  |  | $ | 109 |  |
| Provisions (benefits) | 3 |  |  | 17 |  |  | 14 |  |  | 36 |  |
| Recoveries (write-offs), net | (5) |  |  | (52) |  |  | (11) |  |  | (66) |  |
| Foreign exchange and other | — |  |  | (9) |  |  | — |  |  | (9) |  |
| Allowance for credit loss at end of period | $ | 86 |  |  | $ | 70 |  |  | $ | 86 |  |  | $ | 70 |  |

- removed (2023-05-24):
[0000858877-23-000005:note_history:58]
Contract liabilities consist of deferred revenue. Deferred revenue was $23.9 billion as of January 28, 2023 compared to $23.3 billion as of July 30, 2022. We recognized approximately $3.4 billion and $7.9 billion of revenue during the second quarter and first six months of fiscal 2023 that was included in the deferred revenue balance at July 30, 2022. 
(c)Capitalized Contract Acquisition CostsWe capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $1.0 billion as of each of January 28, 2023 and July 30, 2022, and were included in other current assets and other assets. The amortization expense associated with these costs was $201 million and $377 million for the second quarter and first six months of fiscal 2023, respectively, and $147 million and $317 million for the corresponding periods of fiscal 2022, respectively, and was included in sales and marketing expenses.
