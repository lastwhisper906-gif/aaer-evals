# CSCO notes — 0000858877-23-000023


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000858877-23-000023:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to the 2023 Annual Meeting of Stockholders, to be held on December 6, 2023, are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-23-000023:notes:2]
Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2023 and fiscal 2022 were each 52-week fiscal years, and fiscal 2021 was a 53-week fiscal year. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-23-000023:notes:3]
Our consolidated financial statements include our accounts and investments consolidated under the voting interest model. The noncontrolling interests attributed to these investments are not presented as a separate component in the equity section of the Consolidated Balance Sheets as these amounts are not material for any of the fiscal periods presented. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-23-000023:notes:4]
Certain reclassifications have been made to the amounts for prior years in order to conform to the current year’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-23-000023:notes:5]
Summary of Significant Accounting Policies
(a) Cash and Cash Equivalents   We consider all highly liquid investments purchased with an original or remaining maturity of three months or less at the date of purchase to be cash equivalents. Cash and cash equivalents are maintained with various financial institutions.

[0000858877-23-000023:notes:6]
(b) Available-for-Sale Debt Investments   We classify our investments in fixed income securities as available-for-sale debt investments. Our available-for-sale debt investments primarily consist of U.S. government, U.S. government agency, non-U.S. government and agency, corporate debt, U.S. agency mortgage-backed securities, commercial paper and certificates of deposit. These available-for-sale debt investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of available-for-sale debt investments sold. These investments are recorded in the Consolidated Balance Sheets at fair value. Unrealized gains and losses on these investments are included as a separate component of accumulated other comprehensive income (loss) (AOCI), net of tax. We classify our investments as current based on the nature of the investments and their availability for use in current operations.

[0000858877-23-000023:notes:7]
(c) Equity Instruments   Our equity investments are accounted for as follows:

[0000858877-23-000023:notes:8]
•Marketable equity securities have readily determinable fair value (RDFV) that are measured and recorded at fair value through income.

[0000858877-23-000023:notes:9]
•Non-marketable equity securities do not have RDFV and are measured using a measurement alternative recorded at cost less any impairment, plus or minus changes resulting from qualifying observable price changes. For certain of these securities, we have elected to apply the net asset value (NAV) practical expedient. The NAV is the estimated fair value of these investments.

[0000858877-23-000023:notes:10]
•Equity method investments are securities we do not control, but are able to exert significant influence over the investee. These investments are measured at cost less any impairment, plus or minus our share of equity method investee income or loss.

[0000858877-23-000023:notes:11]
(d) Impairments of Investments   For our available-for-sale debt securities in an unrealized loss position, we determine whether a credit loss exists. In this assessment, among other factors, we consider the extent to which the fair value is less than the amortized cost, any changes to the rating of the security by a rating agency, and adverse conditions specifically related to the security. If factors indicate a credit loss exists, an allowance for credit loss is recorded to other income (loss), net, limited by the amount that the fair value is less than the amortized cost basis. The amount of fair value change relating to all other factors will be recognized in other comprehensive income (OCI).

[0000858877-23-000023:notes:12]
We hold non-marketable equity and other investments (“privately held investments”) which are included in other assets in the Consolidated Balance Sheets. We monitor these investments for impairments and make reductions in carrying values if we determine that an impairment charge is required based primarily on the financial condition and near-term prospects of these companies.

[0000858877-23-000023:notes:13]
(e) Inventories   Inventories are stated at the lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. We provide inventory write-downs based on excess and obsolete inventories determined primarily by future demand forecasts. The write-down is measured as the difference between the cost of the inventory and net realizable value based upon assumptions about future demand and charged to the provision for inventory, which is a component of cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In addition, we record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0000858877-23-000023:notes:14]
(f) Allowance for Accounts Receivable, Contract Assets and Financing Receivables   We estimate our allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, we determine collectibility by pooling our assets with similar characteristics.

[0000858877-23-000023:notes:15]
The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. Our internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality. Assets that do not share risk characteristics are evaluated on an individual basis. The allowances for credit losses are each measured by multiplying the exposure probability of default, the probability the asset will default within a given time frame, by the loss given default rate, the percentage of the asset not expected to be collected due to default, based on the pool of assets.

[0000858877-23-000023:notes:16]
Probability of default rates are published quarterly by third-party credit agencies. Adjustments to our internal credit risk ratings may take into account including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000858877-23-000023:notes:17]
(g) Financing Receivables and Guarantees   We provide financing arrangements, including loan receivables and lease receivables, for certain qualified end-user customers to build, maintain, and upgrade their networks. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services (including technical support and advanced services), and also may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables have terms of one year to three years on average. Lease receivables represent sales-type leases resulting from the sale of Cisco’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average.

[0000858877-23-000023:notes:18]
Outstanding financing receivables that are aged 31 days or more from the contractual payment date are considered past due. We do not accrue interest on financing receivables that are considered impaired and more than 120 days past due unless either the receivable has not been collected due to administrative reasons or the receivable is well secured and in the process of collection. Financing receivables may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain. After a financing receivable has been categorized as nonaccrual, interest will be recognized when cash is received. A financing receivable may be returned to accrual status after all of the customer’s delinquent balances of principal and interest have been settled, and the customer remains current for an appropriate period.

[0000858877-23-000023:notes:19]
We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive a payment for the receivables from the third party based on our standard payment terms. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Deferred revenue relating to these financing arrangements is recorded in accordance with revenue recognition policies or for the fair value of the financing guarantees.

[0000858877-23-000023:notes:20]
(h) Leases   We lease real estate, information technology (IT) and other equipment and vehicles. We also have arrangements with certain suppliers and contract manufacturers which includes the leasing of dedicated space and equipment costs. Our leases have the option to extend or terminate the lease when it is reasonably certain that we will exercise that option.

[0000858877-23-000023:notes:21]
As a lessee, we determine if an arrangement is a lease at commencement. Our ROU lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments related to the lease. Operating lease ROU assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. We use incremental borrowing rates based on information available at the commencement date to determine the present value of our lease payments. Certain of our lease agreements contain variable lease payments. Our variable lease payments can fluctuate depending on the level of activity or the cost of certain services where we have elected to

[0000858877-23-000023:notes:22]
combine lease and non-lease components. While these payments are not included as part of our lease liabilities, they are recognized as variable lease expense in the period they are incurred.

[0000858877-23-000023:notes:23]
We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. As a lessor, we determine if an arrangement is a lease at inception. We provide leasing arrangements for our equipment to certain qualified customers. Our lease portfolio primarily consists of sales-type leases. We allocate the consideration in a bundled contract with our customers based on relative standalone selling prices of our lease and non-lease components. The residual value on our leased equipment is determined at the inception of the lease based on an analysis of estimates of the value of equipment, market factors and historical customer behavior. Residual value estimates are reviewed on a periodic basis and other-than-temporary declines are expensed in the period they occur. Our leases generally provide an end-of-term option for the customer to extend the lease under mutually-agreed terms, return the leased equipment, or purchase the equipment for either the then-market value of the equipment or a pre-determined purchase price. If a customer chooses to terminate their lease prior to the original end of term date, the customer is required to pay all remaining lease payments in full.

[0000858877-23-000023:notes:24]
(i) Depreciation and Amortization   Property and equipment are stated at cost, less accumulated depreciation or amortization, whenever applicable. Depreciation and amortization expenses for property and equipment were approximately $0.7 billion, $0.8 billion, and $0.8 billion for fiscal 2023, 2022, and 2021, respectively. Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-23-000023:notes:25]
| Asset Category |  | Period |
| Buildings |  | 25 years |
| Building improvements |  | 10 years |
| Leasehold improvements |  | Shorter of remaining lease term or up to 10 years |
| Computer equipment and related software |  | 30 to 36 months |
| Production, engineering, and other equipment |  | Up to 5 years |
| Operating lease assets |  | Based on lease term |
| Furniture and fixtures |  | 5 years |

[0000858877-23-000023:notes:26]
(j) Business Combinations We allocate the fair value of the purchase consideration of our acquisitions to the tangible assets, liabilities, and intangible assets acquired, including in-process research and development (IPR&D), based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life. Acquisition-related expenses and related restructuring costs are recognized separately from the business combination and are expensed as incurred.

[0000858877-23-000023:notes:27]
(k) Goodwill and Purchased Intangible Assets   Goodwill is tested for impairment on an annual basis in the fourth fiscal quarter and, when specific circumstances dictate, between annual tests. When impaired, the carrying value of goodwill is written down to fair value. Identifying a potential impairment consists of comparing the fair value of a reporting unit with its carrying amount, including goodwill. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. See “Long-Lived Assets” for our policy regarding impairment testing of purchased intangible assets with finite lives. Purchased intangible assets with indefinite lives are assessed for potential impairment annually or when events or circumstances indicate that their carrying amounts might be impaired.

[0000858877-23-000023:notes:28]
(l) Long-Lived Assets   Long-lived assets that are held and used by us are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability of long-lived assets is based on an estimate of the undiscounted future cash flows resulting from the use of the asset and its eventual disposition. Measurement of an impairment loss for long-lived assets that management expects to hold and use is based on the difference between the fair value of the asset and its carrying value. Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0000858877-23-000023:notes:29]
(m) Fair Value   Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, we consider the principal or most advantageous market in which we would transact, and we also consider assumptions that market participants would use when pricing the asset or liability.

[0000858877-23-000023:notes:30]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. The standard establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement.

[0000858877-23-000023:notes:31]
The fair value hierarchy is as follows:

[0000858877-23-000023:notes:32]
Level 1 applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000858877-23-000023:notes:33]
Level 2 applies to assets or liabilities for which there are inputs other than quoted prices that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets); or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of assets or liabilities.

[0000858877-23-000023:notes:34]
Level 3 applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities. The fair values are determined based on model-based techniques such as discounted cash flow models using inputs that we could not corroborate with market data.

[0000858877-23-000023:notes:35]
(n) Derivative Instruments   We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.

[0000858877-23-000023:notes:36]
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.

[0000858877-23-000023:notes:37]
(o) Foreign Currency Translation   Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated to U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of AOCI. Income and expense accounts are translated at average exchange rates during the year. Remeasurement adjustments are recorded in other income (loss), net.

[0000858877-23-000023:notes:38]
(p) Concentrations of Risk   Cash and cash equivalents are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. We seek to mitigate our credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties.

[0000858877-23-000023:notes:39]
We perform ongoing credit evaluations of our customers and, with the exception of certain financing transactions, do not require collateral from our customers. We receive certain of our components from sole suppliers. Additionally, we rely on a limited number of contract manufacturers and suppliers to provide manufacturing services for our products. The inability of a contract manufacturer or supplier to fulfill our supply requirements could materially impact future operating results.

[0000858877-23-000023:notes:40]
(q) Revenue Recognition   We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses

[0000858877-23-000023:notes:41]
represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

[0000858877-23-000023:notes:42]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-23-000023:notes:43]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of July 29, 2023 and July 30, 2022 was $39 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-23-000023:notes:44]
Significant Judgments

[0000858877-23-000023:notes:45]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-23-000023:notes:46]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.

[0000858877-23-000023:notes:47]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license’s utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

[0000858877-23-000023:notes:48]
(r) Advertising Costs   We expense all advertising costs as incurred. Advertising costs included within sales and marketing expenses were approximately $205 million, $219 million, and $268 million for fiscal 2023, 2022, and 2021, respectively.

[0000858877-23-000023:notes:49]
(s) Share-Based Compensation Expense   We measure and recognize the compensation expense for all share-based awards made to employees and directors, including employee stock options, restricted stock units (RSUs), performance-based restricted stock units (PRSUs), and employee stock purchases related to the Employee Stock Purchase Plan (Employee Stock Purchase Rights) based on estimated fair values. Share-based compensation expense is reduced for forfeitures as they occur.

[0000858877-23-000023:notes:50]
(t) Software Development Costs   Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized. Costs incurred during the application development stage for internal-use software and cloud-based applications are capitalized. Such software development costs capitalized during the periods presented were not material.

[0000858877-23-000023:notes:51]
(u) Income Taxes   Income tax expense is based on pretax financial accounting income. Deferred tax assets and liabilities are recognized for the expected tax consequences of temporary differences between the tax bases of assets and liabilities and their reported amounts. Valuation allowances are recorded to reduce deferred tax assets to the amount that will more likely than not be realized.

[0000858877-23-000023:notes:52]
We account for uncertainty in income taxes using a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. We classify the liability for unrecognized tax benefits as current to the extent that we anticipate payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.

[0000858877-23-000023:notes:53]
(v) Computation of Net Income per Share   Basic net income per share is computed using the weighted-average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted-average number of common shares and dilutive potential common shares outstanding during the period. Diluted shares outstanding includes the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares.

[0000858877-23-000023:notes:54]
(w) Consolidation of Variable Interest Entities   Our approach in assessing the consolidation requirement for variable interest entities focuses on identifying which enterprise has the power to direct the activities that most significantly impact the variable interest entity’s economic performance and which enterprise has the obligation to absorb losses or the right to receive benefits from the variable interest entity. Should we conclude that we are the primary beneficiary of a variable interest entity, the assets, liabilities, and results of operations of the variable interest entity will be included in our Consolidated Financial Statements.

[0000858877-23-000023:notes:55]
(x) Use of Estimates   The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Estimates are used for the following, among others:

[0000858877-23-000023:notes:56]
▪Revenue recognition

[0000858877-23-000023:notes:57]
▪Allowances for accounts receivable, sales returns, and financing receivables

[0000858877-23-000023:notes:58]
▪Inventory valuation and liability for purchase commitments with contract manufacturers and suppliers

[0000858877-23-000023:notes:59]
▪Loss contingencies and product warranties

[0000858877-23-000023:notes:60]
▪Fair value measurements

[0000858877-23-000023:notes:61]
▪Goodwill and purchased intangible asset impairments

[0000858877-23-000023:notes:62]
▪Income taxes

[0000858877-23-000023:notes:63]
The actual results that we experience may differ materially from our estimates.

[0000858877-23-000023:notes:64]
(y) Recent Accounting Standards or Updates Not Yet Effective as of Fiscal Year End

[0000858877-23-000023:notes:65]
Reference Rate Reform   In March 2020, the Financial Accounting Standards Board issued an accounting standard update and subsequent amendments that provide optional expedients and exceptions to the current guidance on contract modification and hedging relationships to ease the financial reporting burden of the expected market transition from the London InterBank Offered Rate (LIBOR) and other interbank offered rates to alternative reference rates. This accounting standard update was effective upon issuance and may be applied prospectively through December 31, 2024. We adopted this accounting standard update in fiscal 2023 and it did not have a material impact on our Consolidated Financial Statements upon adoption.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-23-000023:notes:66]
Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-23-000023:notes:67]
Property and Equipment, Net

[0000858877-23-000023:notes:68]
|  |  | July 29, 2023 |  | July 30, 2022 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,229 |  |  | $ | 4,219 |  |
| Computer equipment and related software |  | 744 |  |  | 779 |  |
| Production, engineering, and other equipment |  | 4,611 |  |  | 4,647 |  |
| Operating lease assets |  | 135 |  |  | 185 |  |
| Furniture, fixtures and other |  | 339 |  |  | 335 |  |
| Total gross property and equipment |  | 10,058 |  |  | 10,165 |  |
| Less: accumulated depreciation and amortization |  | (7,973) |  |  | (8,168) |  |
| Total |  | $ | 2,085 |  |  | $ | 1,997 |  |


## us-gaap:DerivativesPolicyTextBlock

[0000858877-23-000023:notes:69]
(n) Derivative Instruments   We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We do, however, seek to mitigate such risks by limiting our counterparties to major financial institutions and requiring collateral in certain cases. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-23-000023:notes:70]
Revenue
(a)Disaggregation of Revenue

[0000858877-23-000023:notes:71]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category.

[0000858877-23-000023:notes:72]
The following table presents this disaggregation of revenue (in millions):

[0000858877-23-000023:notes:73]
| Years Ended | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Product revenue: |  |  |  |  |  |
| Secure, Agile Networks | $ | 29,105 |  |  | $ | 23,831 |  |  | $ | 22,725 |  |
| Internet for the Future | 5,306 |  |  | 5,276 |  |  | 4,511 |  |
| Collaboration | 4,052 |  |  | 4,472 |  |  | 4,727 |  |
| End-to-End Security | 3,859 |  |  | 3,699 |  |  | 3,382 |  |
| Optimized Application Experiences | 811 |  |  | 729 |  |  | 654 |  |
| Other Products | 9 |  |  | 11 |  |  | 15 |  |
| Total Product | 43,142 |  |  | 38,018 |  |  | 36,014 |  |
| Services | 13,856 |  |  | 13,539 |  |  | 13,804 |  |
| Total | $ | 56,998 |  |  | $ | 51,557 |  |  | $ | 49,818 |  |

[0000858877-23-000023:notes:74]
Amounts may not sum due to rounding. We have made certain reclassifications to the product revenue amounts for prior periods to conform to the current year presentation.

[0000858877-23-000023:notes:75]
Secure, Agile Networks consists of our core networking technologies of switching, enterprise routing, wireless, and compute products. These technologies consist of both hardware and software offerings, including software licenses and SaaS, that help our customers build networks, automate, orchestrate, integrate, and digitize data. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-23-000023:notes:76]
Internet for the Future consists of our routed optical networking, 5G, silicon, and optics solutions. These products consist primarily of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-23-000023:notes:77]
Collaboration consists of our Meetings, Collaboration Devices, Calling, Contact Center and CPaaS offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-23-000023:notes:78]
End-to-End Security consists of our Cloud and Application Security, Industrial Security, Network Security, and User and Device Security offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-23-000023:notes:79]
Optimized Application Experiences consists of our full stack observability and network assurance offerings. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated

[0000858877-23-000023:notes:80]
software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-23-000023:notes:81]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and advanced services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Advanced services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

[0000858877-23-000023:notes:82]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for all of our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.

[0000858877-23-000023:notes:83]
(b)Contract Balances

[0000858877-23-000023:notes:84]
Accounts Receivable

[0000858877-23-000023:notes:85]
Accounts receivable, net was $5.9 billion as of July 29, 2023 compared to $6.6 billion as of July 30, 2022, as reported on the Consolidated Balance Sheets.

[0000858877-23-000023:notes:86]
The allowances for credit loss for our accounts receivable are summarized as follows (in millions):

[0000858877-23-000023:notes:87]
|  |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Allowance for credit loss at beginning of fiscal year |  | $ | 83 |  |  | $ | 109 |  |  | $ | 143 |  |
| Provisions (benefits) |  | 39 |  |  | 64 |  |  | 21 |  |
| Recoveries (write-offs), net |  | (37) |  |  | (81) |  |  | (29) |  |
| Foreign exchange and other |  | — |  |  | (9) |  |  | (26) |  |
| Allowance for credit loss at end of fiscal year |  | $ | 85 |  |  | $ | 83 |  |  | $ | 109 |  |

[0000858877-23-000023:notes:88]
Contract Assets and Liabilities

[0000858877-23-000023:notes:89]
Gross contract assets by our internal risk ratings are summarized as follows (in millions):

[0000858877-23-000023:notes:90]
|  | July 29, 2023 |  | July 30, 2022 |
| 1 to 4 | $ | 672 |  |  | $ | 414 |  |
| 5 to 6 | 954 |  |  | 814 |  |
| 7 and Higher | 60 |  |  | 158 |  |
| Total | $ | 1,686 |  |  | $ | 1,386 |  |

[0000858877-23-000023:notes:91]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of July 29, 2023 and July 30, 2022, our contract assets for these unbilled receivables, net of allowances, were $1.6 billion and $1.3 billion, respectively, and were included in other current assets and other assets.

[0000858877-23-000023:notes:92]
Contract liabilities consist of deferred revenue. Deferred revenue was $25.6 billion as of July 29, 2023 compared to $23.3 billion as of July 30, 2022. We recognized approximately $12.7 billion of revenue during fiscal 2023 that was included in the deferred revenue balance at July 30, 2022.

[0000858877-23-000023:notes:93]
(c)Capitalized Contract Acquisition Costs

[0000858877-23-000023:notes:94]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $1.1 billion and $1.0 billion as of July 29, 2023 and July 30, 2022, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $723 million and $679 million for fiscal 2023 and 2022, respectively, and was included in sales and marketing expenses.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-23-000023:notes:95]
The following table presents revenue for groups of similar products and services (in millions):

[0000858877-23-000023:notes:96]
| Years Ended | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Revenue: |  |  |  |  |  |
| Secure, Agile Networks | $ | 29,105 |  |  | $ | 23,831 |  |  | $ | 22,725 |  |
| Internet for the Future | 5,306 |  |  | 5,276 |  |  | 4,511 |  |
| Collaboration | 4,052 |  |  | 4,472 |  |  | 4,727 |  |
| End-to-End Security | 3,859 |  |  | 3,699 |  |  | 3,382 |  |
| Optimized Application Experiences | 811 |  |  | 729 |  |  | 654 |  |
| Other Products | 9 |  |  | 11 |  |  | 15 |  |
| Total Product | 43,142 |  |  | 38,018 |  |  | 36,014 |  |
| Services | 13,856 |  |  | 13,539 |  |  | 13,804 |  |
| Total | $ | 56,998 |  |  | $ | 51,557 |  |  | $ | 49,818 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-23-000023:notes:97]
Acquisitions and Divestitures 
(a)Acquisition Summary

[0000858877-23-000023:notes:98]
We completed five acquisitions during fiscal 2023. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-23-000023:notes:99]
| Fiscal 2023 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions (five in total) | $ | 315 |  |  | $ | (18) |  |  | $ | 150 |  |  | $ | 183 |  |

[0000858877-23-000023:notes:100]
The total purchase consideration related to our acquisitions completed during fiscal 2023 consisted primarily of cash consideration. The total cash and cash equivalents acquired from these acquisitions was approximately $7 million.

[0000858877-23-000023:notes:101]
Fiscal 2022 Acquisitions

[0000858877-23-000023:notes:102]
Allocation of the purchase consideration for acquisitions completed in fiscal 2022 is summarized as follows (in millions):

[0000858877-23-000023:notes:103]
| Fiscal 2022 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions (three in total) | $ | 364 |  |  | $ | 12 |  |  | $ | 20 |  |  | $ | 332 |  |

[0000858877-23-000023:notes:104]
The total purchase consideration related to our acquisitions completed during fiscal 2022 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately  $7 million.

[0000858877-23-000023:notes:105]
Fiscal 2021 Acquisitions

[0000858877-23-000023:notes:106]
In fiscal 2021, we completed 13 acquisitions for total purchase consideration of $7.5 billion.

[0000858877-23-000023:notes:107]
(b)   Other Acquisition and Divestiture Information

[0000858877-23-000023:notes:108]
Total transaction costs related to acquisition and divestiture activities during fiscal 2023, 2022, and 2021 were $26 million, $50 million, and $46 million, respectively. These transaction costs were expensed as incurred in G&A expenses in the Consolidated Statements of Operations.

[0000858877-23-000023:notes:109]
The goodwill generated from acquisitions completed during fiscal 2023 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-23-000023:notes:110]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during fiscal 2023, 2022, and 2021 have not been presented because the effects of the acquisitions were not material to our financial results.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0000858877-23-000023:notes:111]
A summary of the allocation of the total purchase consideration is presented as follows (in millions):


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-23-000023:notes:112]
Goodwill and Purchased Intangible Assets 
(a)Goodwill

[0000858877-23-000023:notes:113]
The following tables present the goodwill allocated to our reportable segments as of July 29, 2023 and July 30, 2022, as well as the changes to goodwill during fiscal 2023 and 2022 (in millions):

[0000858877-23-000023:notes:114]
|  | Balance at July 30, 2022 |  | Acquisitions |  | Foreign Currency Translation and Other |  | Balance at July 29, 2023 |
| Americas | $ | 23,882 |  |  | $ | 123 |  |  | $ | 30 |  |  | $ | 24,035 |  |
| EMEA | 9,062 |  |  | 44 |  |  | 12 |  |  | 9,118 |  |
| APJC | 5,360 |  |  | 16 |  |  | 6 |  |  | 5,382 |  |
| Total | $ | 38,304 |  |  | $ | 183 |  |  | $ | 48 |  |  | $ | 38,535 |  |

[0000858877-23-000023:notes:115]
|  | Balance at July 31, 2021 |  | Acquisitions |  | Foreign Currency Translation and Other |  | Balance at July 30, 2022 |
| Americas | $ | 23,673 |  |  | $ | 222 |  |  | $ | (13) |  |  | $ | 23,882 |  |
| EMEA | 9,094 |  |  | 83 |  |  | (115) |  |  | 9,062 |  |
| APJC | 5,401 |  |  | 27 |  |  | (68) |  |  | 5,360 |  |
| Total | $ | 38,168 |  |  | $ | 332 |  |  | $ | (196) |  |  | $ | 38,304 |  |

[0000858877-23-000023:notes:116]
(b)Purchased Intangible Assets

[0000858877-23-000023:notes:117]
The following tables present details of our intangible assets acquired through acquisitions completed during fiscal 2023 and 2022 (in millions, except years):

[0000858877-23-000023:notes:118]
|  | FINITE LIVES | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | IPR&D |  |
| Fiscal 2023 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions (five in total) | 3.7 |  | $ | 138 |  |  | 1.8 |  | $ | 12 |  |  | $ | — |  |  | $ | 150 |  |

[0000858877-23-000023:notes:119]
|  | FINITE LIVES | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | IPR&D |  |
| Fiscal 2022 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions (three in total) | 2.7 |  | $ | 16 |  |  | 2.0 |  | $ | 4 |  |  | $ | — |  |  | $ | 20 |  |

[0000858877-23-000023:notes:120]
The following tables present details of our purchased intangible assets (in millions):

[0000858877-23-000023:notes:121]
| July 29, 2023 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 2,998 |  |  | $ | (1,691) |  |  | $ | 1,307 |  |
| Customer relationships |  | 1,228 |  |  | (905) |  |  | 323 |  |
| Other |  | 40 |  |  | (22) |  |  | 18 |  |
| Total purchased intangible assets with finite lives |  | 4,266 |  |  | (2,618) |  |  | 1,648 |  |
| In-process research and development, with indefinite lives |  | 170 |  |  | — |  |  | 170 |  |
| Total |  | $ | 4,436 |  |  | $ | (2,618) |  |  | $ | 1,818 |  |

[0000858877-23-000023:notes:122]
| July 30, 2022 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 2,631 |  |  | $ | (1,102) |  |  | $ | 1,529 |  |
| Customer relationships |  | 1,354 |  |  | (769) |  |  | 585 |  |
| Other |  | 41 |  |  | (16) |  |  | 25 |  |
| Total purchased intangible assets with finite lives |  | 4,026 |  |  | (1,887) |  |  | 2,139 |  |
| In-process research and development, with indefinite lives |  | 430 |  |  | — |  |  | 430 |  |
| Total |  | $ | 4,456 |  |  | $ | (1,887) |  |  | $ | 2,569 |  |

[0000858877-23-000023:notes:123]
Purchased intangible assets include intangible assets acquired through acquisitions as well as through direct purchases or licenses.

[0000858877-23-000023:notes:124]
The following table presents the amortization of purchased intangible assets, including impairment charges (in millions):

[0000858877-23-000023:notes:125]
| Years Ended |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 649 |  |  | $ | 749 |  |  | $ | 716 |  |
| Operating expenses |  | 282 |  |  | 328 |  |  | 215 |  |
| Total |  | $ | 931 |  |  | $ | 1,077 |  |  | $ | 931 |  |

[0000858877-23-000023:notes:126]
The estimated future amortization expense of purchased intangible assets with finite lives as of July 29, 2023 is as follows (in millions):

[0000858877-23-000023:notes:127]
| Fiscal Year | Amount |
| 2024 | $ | 875 |  |
| 2025 | $ | 502 |  |
| 2026 | $ | 154 |  |
| 2027 | $ | 78 |  |
| 2028 | $ | 39 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-23-000023:notes:128]
Restructuring and Other Charges
In the second quarter of fiscal 2023, we announced a restructuring plan (the “Fiscal 2023 Plan”), in order to rebalance the organization and enable further investment in key priority areas, of which approximately 5% of the global workforce would be impacted. The total pretax charges are estimated to be approximately $700 million. This rebalancing includes talent movement options and restructuring. Additionally, we have begun optimizing our real estate portfolio, aligned to the broader hybrid work strategy. In connection with the Fiscal 2023 Plan, we incurred charges of $535 million in fiscal 2023. These aggregate pretax charges will be primarily cash-based and will consist of severance and other one-time termination benefits, real estate-related charges, and other costs. We expect the plan to be substantially completed by the end of the first quarter of fiscal 2024.

[0000858877-23-000023:notes:129]
We initiated a restructuring plan in fiscal 2021 (the “Fiscal 2021 Plan”), which was completed in fiscal 2022. In connection with the Fiscal 2021 Plan, we incurred cumulative charges of $892 million. The aggregate pretax charges related to this plan were primarily cash-based and consist of severance and other one-time termination benefits, and other costs.

[0000858877-23-000023:notes:130]
The following table summarizes the activities related to the restructuring and other charges, as discussed above (in millions):

[0000858877-23-000023:notes:131]
|  |  | FISCAL 2023 PLAN |  | FISCAL 2021 AND PRIOR PLANS |  |  |
|  |  | Employee Severance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 25, 2020 |  | $ | — |  |  | $ | — |  |  | $ | 58 |  |  | $ | 14 |  |  | $ | 72 |  |
| Charges |  | — |  |  | — |  |  | 836 |  |  | 50 |  |  | 886 |  |
| Cash payments |  | — |  |  | — |  |  | (879) |  |  | (11) |  |  | (890) |  |
| Non-cash items |  | — |  |  | — |  |  | 1 |  |  | (35) |  |  | (34) |  |
| Liability as of July 31, 2021 |  | — |  |  | — |  |  | 16 |  |  | 18 |  |  | 34 |  |
| Charges |  | — |  |  | — |  |  | 9 |  |  | (3) |  |  | 6 |  |
| Cash payments |  | — |  |  | — |  |  | (23) |  |  | (2) |  |  | (25) |  |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (6) |  |  | (6) |  |
| Liability as of July 30, 2022 |  | — |  |  | — |  |  | 2 |  |  | 7 |  |  | 9 |  |
| Charges |  | 465 |  |  | 70 |  |  | — |  |  | (4) |  |  | 531 |  |
| Cash payments |  | (301) |  |  | (11) |  |  | (1) |  |  | (1) |  |  | (314) |  |
| Non-cash items |  | 2 |  |  | (15) |  |  | — |  |  | — |  |  | (13) |  |
| Liability as of July 29, 2023 |  | $ | 166 |  |  | $ | 44 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 213 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-23-000023:notes:132]
Balance Sheet and Other Details 
The following tables provide details of selected balance sheet and other items (in millions):

[0000858877-23-000023:notes:133]
Cash, Cash Equivalents, Restricted Cash and Restricted Cash Equivalents

[0000858877-23-000023:notes:134]
|  |  | July 29, 2023 |  | July 30, 2022 |
| Cash and cash equivalents |  | $ | 10,123 |  |  | $ | 7,079 |  |
| Restricted cash and restricted cash equivalents included in other current assets |  | 191 |  |  | — |  |
| Restricted cash and restricted cash equivalents included in other assets |  | 1,313 |  |  | 1,500 |  |
| Total |  | $ | 11,627 |  |  | $ | 8,579 |  |

[0000858877-23-000023:notes:135]
Our restricted cash and restricted cash equivalents are funds primarily related to contractual obligations with suppliers.

[0000858877-23-000023:notes:136]
Inventories

[0000858877-23-000023:notes:137]
|  |  | July 29, 2023 |  | July 30, 2022 |
| Raw materials |  | $ | 1,685 |  |  | $ | 1,601 |  |
| Work in process |  | 264 |  |  | 150 |  |
| Finished goods |  | 1,493 |  |  | 717 |  |
| Service-related spares |  | 186 |  |  | 90 |  |
| Demonstration systems |  | 16 |  |  | 10 |  |
| Total |  | $ | 3,644 |  |  | $ | 2,568 |  |

[0000858877-23-000023:notes:138]
Remaining Performance Obligations (RPO)

[0000858877-23-000023:notes:139]
|  |  | July 29, 2023 |  | July 30, 2022 |
| Product |  | $ | 15,802 |  |  | $ | 14,090 |  |
| Service |  | 19,066 |  |  | 17,449 |  |
| Total |  | $ | 34,868 |  |  | $ | 31,539 |  |
| Short-term RPO |  | $ | 17,910 |  |  | $ | 16,936 |  |
| Long-term RPO |  | 16,958 |  |  | 14,603 |  |
| Total |  | $ | 34,868 |  |  | $ | 31,539 |  |
| Amount to be recognized as revenue over the next 12 months |  | 51 | % |  | 54 | % |
| Deferred revenue |  | $ | 25,550 |  |  | $ | 23,264 |  |
| Unbilled contract revenue |  | 9,318 |  |  | 8,275 |  |
| Total |  | $ | 34,868 |  |  | $ | 31,539 |  |

[0000858877-23-000023:notes:140]
Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

[0000858877-23-000023:notes:141]
Deferred Revenue

[0000858877-23-000023:notes:142]
|  |  | July 29, 2023 |  | July 30, 2022 |
| Product |  | $ | 11,505 |  |  | $ | 10,427 |  |
| Service |  | 14,045 |  |  | 12,837 |  |
| Total |  | $ | 25,550 |  |  | $ | 23,264 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 13,908 |  |  | $ | 12,784 |  |
| Noncurrent |  | 11,642 |  |  | 10,480 |  |
| Total |  | $ | 25,550 |  |  | $ | 23,264 |  |

[0000858877-23-000023:notes:143]
Transition Tax Payable

[0000858877-23-000023:notes:144]
Our income tax payable associated with the one-time U.S. transition tax on accumulated earnings for foreign subsidiaries as a result of the Tax Act is as follows (in millions):

[0000858877-23-000023:notes:145]
|  |  | July 29, 2023 |  | July 30, 2022 |
| Current |  | $ | 1,364 |  |  | $ | 727 |  |
| Noncurrent |  | 4,092 |  |  | 5,456 |  |
| Total |  | $ | 5,456 |  |  | $ | 6,183 |  |


## us-gaap:OperatingLeasesOfLessorDisclosureTextBlock

[0000858877-23-000023:notes:146]
Leases
(a)Lessee Arrangements

[0000858877-23-000023:notes:147]
The following table presents our operating lease balances (in millions):

[0000858877-23-000023:notes:148]
|  | Balance Sheet Line Item |  | July 29, 2023 |  | July 30, 2022 |
| Operating lease right-of-use assets | Other assets |  | $ | 971 |  |  | $ | 1,003 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 313 |  |  | $ | 322 |  |
| Operating lease liabilities | Other long-term liabilities |  | 707 |  |  | 724 |  |
| Total operating lease liabilities |  |  | $ | 1,020 |  |  | $ | 1,046 |  |

[0000858877-23-000023:notes:149]
The components of our lease expenses were as follows (in millions):

[0000858877-23-000023:notes:150]
| Years Ended |  | July 29, 2023 |  | July 30, 2022 |
| Operating lease expense |  | $ | 425 |  |  | $ | 390 |  |
| Short-term lease expense |  | 65 |  |  | 66 |  |
| Variable lease expense |  | 242 |  |  | 173 |  |
| Total lease expense |  | $ | 732 |  |  | $ | 629 |  |

[0000858877-23-000023:notes:151]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-23-000023:notes:152]
| Years Ended |  | July 29, 2023 |  | July 30, 2022 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows |  | $ | 387 |  |  | $ | 408 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities |  | $ | 326 |  |  | $ | 331 |  |

[0000858877-23-000023:notes:153]
The weighted-average lease term was 4.6 years and 4.7 years as of July 29, 2023 and July 30, 2022, respectively. The weighted-average discount rate was 3.1% and 2.2% as of July 29, 2023 and July 30, 2022, respectively.

[0000858877-23-000023:notes:154]
The maturities of our operating leases (undiscounted) as of July 29, 2023 are as follows (in millions):

[0000858877-23-000023:notes:155]
| Fiscal Year | Amount |
| 2024 | $ | 341 |  |
| 2025 | 259 |  |
| 2026 | 167 |  |
| 2027 | 99 |  |
| 2028 | 73 |  |
| Thereafter | 177 |  |
| Total lease payments | 1,116 |  |
| Less interest | (96) |  |
| Total | $ | 1,020 |  |

[0000858877-23-000023:notes:156]
(b)Lessor Arrangements

[0000858877-23-000023:notes:157]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income for fiscal 2023 and 2022 was $51 million and $54 million, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-23-000023:notes:158]
Future minimum lease payments on our lease receivables as of July 29, 2023 are summarized as follows (in millions):

[0000858877-23-000023:notes:159]
| Fiscal Year | Amount |
| 2024 | $ | 371 |  |
| 2025 | 221 |  |
| 2026 | 167 |  |
| 2027 | 147 |  |
| 2028 | 100 |  |
| Thereafter | 9 |  |
| Total | 1,015 |  |
| Less: Present value of lease payments | 927 |  |
| Unearned income | $ | 88 |  |

[0000858877-23-000023:notes:160]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-23-000023:notes:161]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-23-000023:notes:162]
|  | July 29, 2023 |  | July 30, 2022 |
| Operating lease assets | $ | 135 |  |  | $ | 185 |  |
| Accumulated depreciation | (78) |  |  | (111) |  |
| Operating lease assets, net | $ | 57 |  |  | $ | 74 |  |

[0000858877-23-000023:notes:163]
Our operating lease income for fiscal 2023 and 2022 was $73 million and $107 million, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-23-000023:notes:164]
Minimum future rentals on noncancelable operating leases as of July 29, 2023 are summarized as follows (in millions):

[0000858877-23-000023:notes:165]
| Fiscal Year | Amount |
| 2024 | $ | 25 |  |
| 2025 | 12 |  |
| 2026 | 6 |  |
| Total | $ | 43 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-23-000023:notes:166]
Financing Receivables  
(a)Financing Receivables

[0000858877-23-000023:notes:167]
Financing receivables primarily consist of loan receivables and lease receivables. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services (including technical support and advanced services), and also may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables have terms of one year to three years on average. Lease receivables represent sales-type leases resulting from the sale of Cisco’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average.

[0000858877-23-000023:notes:168]
A summary of our financing receivables is presented as follows (in millions):

[0000858877-23-000023:notes:169]
| July 29, 2023 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,910 |  |  | $ | 1,015 |  |  | $ | 6,925 |  |
| Residual value | — |  |  | 70 |  |  | 70 |  |
| Unearned income | — |  |  | (88) |  |  | (88) |  |
| Allowance for credit loss | (53) |  |  | (19) |  |  | (72) |  |
| Total, net | $ | 5,857 |  |  | $ | 978 |  |  | $ | 6,835 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 2,988 |  |  | $ | 364 |  |  | $ | 3,352 |  |
| Noncurrent | 2,869 |  |  | 614 |  |  | 3,483 |  |
| Total, net | $ | 5,857 |  |  | $ | 978 |  |  | $ | 6,835 |  |

[0000858877-23-000023:notes:170]
| July 30, 2022 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 6,842 |  |  | $ | 1,176 |  |  | $ | 8,018 |  |
| Residual value | — |  |  | 76 |  |  | 76 |  |
| Unearned income | — |  |  | (54) |  |  | (54) |  |
| Allowance for credit loss | (103) |  |  | (23) |  |  | (126) |  |
| Total, net | $ | 6,739 |  |  | $ | 1,175 |  |  | $ | 7,914 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 3,327 |  |  | $ | 578 |  |  | $ | 3,905 |  |
| Noncurrent | 3,412 |  |  | 597 |  |  | 4,009 |  |
| Total, net | $ | 6,739 |  |  | $ | 1,175 |  |  | $ | 7,914 |  |

[0000858877-23-000023:notes:171]
(b)Credit Quality of Financing Receivables

[0000858877-23-000023:notes:172]
The tables below present our gross financing receivables, excluding residual value, less unearned income, categorized by our internal credit risk rating by period of origination (in millions):

[0000858877-23-000023:notes:173]
| July 29, 2023 |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | July 30, 2022 |  | July 29, 2023 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 10 |  |  | $ | 53 |  |  | $ | 251 |  |  | $ | 791 |  |  | $ | 1,077 |  |  | $ | 1,784 |  |  | $ | 3,966 |  |
| 5 to 6 | 3 |  |  | 14 |  |  | 131 |  |  | 287 |  |  | 465 |  |  | 936 |  |  | 1,836 |  |
| 7 and Higher | 1 |  |  | 7 |  |  | 15 |  |  | 17 |  |  | 29 |  |  | 39 |  |  | 108 |  |
| Total Loan Receivables | $ | 14 |  |  | $ | 74 |  |  | $ | 397 |  |  | $ | 1,095 |  |  | $ | 1,571 |  |  | $ | 2,759 |  |  | $ | 5,910 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 20 |  |  | $ | 57 |  |  | $ | 111 |  |  | $ | 84 |  |  | $ | 235 |  |  | $ | 509 |  |
| 5 to 6 | 2 |  |  | 13 |  |  | 44 |  |  | 58 |  |  | 87 |  |  | 191 |  |  | 395 |  |
| 7 and Higher | — |  |  | 1 |  |  | 2 |  |  | 4 |  |  | 5 |  |  | 11 |  |  | 23 |  |
| Total Lease Receivables | $ | 4 |  |  | $ | 34 |  |  | $ | 103 |  |  | $ | 173 |  |  | $ | 176 |  |  | $ | 437 |  |  | $ | 927 |  |
| Total | $ | 18 |  |  | $ | 108 |  |  | $ | 500 |  |  | $ | 1,268 |  |  | $ | 1,747 |  |  | $ | 3,196 |  |  | $ | 6,837 |  |

[0000858877-23-000023:notes:174]
| July 30, 2022 |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 28, 2018 |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | July 30, 2022 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 49 |  |  | $ | 173 |  |  | $ | 536 |  |  | $ | 1,458 |  |  | $ | 2,287 |  |  | $ | 4,505 |  |
| 5 to 6 | 1 |  |  | 17 |  |  | 115 |  |  | 345 |  |  | 709 |  |  | 1,030 |  |  | 2,217 |  |
| 7 and Higher | 1 |  |  | 1 |  |  | 22 |  |  | 45 |  |  | 39 |  |  | 12 |  |  | 120 |  |
| Total Loan Receivables | $ | 4 |  |  | $ | 67 |  |  | $ | 310 |  |  | $ | 926 |  |  | $ | 2,206 |  |  | $ | 3,329 |  |  | $ | 6,842 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 25 |  |  | $ | 74 |  |  | $ | 124 |  |  | $ | 176 |  |  | $ | 152 |  |  | $ | 553 |  |
| 5 to 6 | 1 |  |  | 10 |  |  | 67 |  |  | 146 |  |  | 165 |  |  | 151 |  |  | 540 |  |
| 7 and Higher | — |  |  | 1 |  |  | 4 |  |  | 12 |  |  | 2 |  |  | 10 |  |  | 29 |  |
| Total Lease Receivables | $ | 3 |  |  | $ | 36 |  |  | $ | 145 |  |  | $ | 282 |  |  | $ | 343 |  |  | $ | 313 |  |  | $ | 1,122 |  |
| Total | $ | 7 |  |  | $ | 103 |  |  | $ | 455 |  |  | $ | 1,208 |  |  | $ | 2,549 |  |  | $ | 3,642 |  |  | $ | 7,964 |  |

[0000858877-23-000023:notes:175]
The following tables present the aging analysis of gross receivables as of July 29, 2023 and July 30, 2022 (in millions):

[0000858877-23-000023:notes:176]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| July 29, 2023 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 47 |  |  | $ | 20 |  |  | $ | 37 |  |  | $ | 104 |  |  | $ | 5,806 |  |  | $ | 5,910 |  |  | $ | 17 |  |  | $ | 12 |  |  | $ | 12 |  |
| Lease receivables | 16 |  |  | 4 |  |  | 23 |  |  | 43 |  |  | 884 |  |  | 927 |  |  | 6 |  |  | 3 |  |  | 3 |  |
| Total | $ | 63 |  |  | $ | 24 |  |  | $ | 60 |  |  | $ | 147 |  |  | $ | 6,690 |  |  | $ | 6,837 |  |  | $ | 23 |  |  | $ | 15 |  |  | $ | 15 |  |

[0000858877-23-000023:notes:177]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| July 30, 2022 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 98 |  |  | $ | 62 |  |  | $ | 129 |  |  | $ | 289 |  |  | $ | 6,553 |  |  | $ | 6,842 |  |  | $ | 14 |  |  | $ | 60 |  |  | $ | 60 |  |
| Lease receivables | 8 |  |  | 6 |  |  | 26 |  |  | 40 |  |  | 1,082 |  |  | 1,122 |  |  | 7 |  |  | 11 |  |  | 11 |  |
| Total | $ | 106 |  |  | $ | 68 |  |  | $ | 155 |  |  | $ | 329 |  |  | $ | 7,635 |  |  | $ | 7,964 |  |  | $ | 21 |  |  | $ | 71 |  |  | $ | 71 |  |

[0000858877-23-000023:notes:178]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract.

[0000858877-23-000023:notes:179]
(c)Allowance for Credit Loss Rollforward

[0000858877-23-000023:notes:180]
The allowances for credit loss and the related financing receivables are summarized as follows (in millions):

[0000858877-23-000023:notes:181]
|  | CREDIT LOSS ALLOWANCES |
|  | LoanReceivables |  | LeaseReceivables |  | Total |
| Allowance for credit loss as of July 30, 2022 | $ | 103 |  |  | $ | 23 |  |  | $ | 126 |  |
| Provisions (benefits) | (7) |  |  | (1) |  |  | (8) |  |
| Recoveries (write-offs), net | (38) |  |  | (3) |  |  | (41) |  |
| Foreign exchange and other | (5) |  |  | — |  |  | (5) |  |
| Allowance for credit loss as of July 29, 2023 | $ | 53 |  |  | $ | 19 |  |  | $ | 72 |  |

[0000858877-23-000023:notes:182]
|  | CREDIT LOSS ALLOWANCES |
|  | LoanReceivables |  | LeaseReceivables |  | Total |
| Allowance for credit loss as of July 31, 2021 | $ | 89 |  |  | $ | 38 |  |  | $ | 127 |  |
| Provisions (benefits) | 4 |  |  | (13) |  |  | (9) |  |
| Recoveries (write-offs), net | — |  |  | (2) |  |  | (2) |  |
| Foreign exchange and other | 10 |  |  | — |  |  | 10 |  |
| Allowance for credit loss as of July 30, 2022 | $ | 103 |  |  | $ | 23 |  |  | $ | 126 |  |

[0000858877-23-000023:notes:183]
|  | CREDIT LOSS ALLOWANCES |
|  | LoanReceivables |  | LeaseReceivables |  | Total |
| Allowance for credit loss as of July 25, 2020 | $ | 90 |  |  | $ | 48 |  |  | $ | 138 |  |
| Provisions (benefits) | (17) |  |  | (10) |  |  | (27) |  |
| Recoveries (write-offs), net | (1) |  |  | (1) |  |  | (2) |  |
| Foreign exchange and other | 17 |  |  | 1 |  |  | 18 |  |
| Allowance for credit loss as of July 31, 2021 | $ | 89 |  |  | $ | 38 |  |  | $ | 127 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-23-000023:notes:184]
Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-23-000023:notes:185]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-23-000023:notes:186]
| July 29, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 3,587 |  |  | $ | 1 |  |  | $ | (62) |  |  | $ | 3,526 |  |
| U.S. government agency securities | 428 |  |  | — |  |  | (5) |  |  | 423 |  |
| Non-U.S. government and agency securities | 364 |  |  | — |  |  | (1) |  |  | 363 |  |
| Corporate debt securities | 7,238 |  |  | 3 |  |  | (327) |  |  | 6,914 |  |
| U.S. agency mortgage-backed securities | 2,421 |  |  | 14 |  |  | (230) |  |  | 2,205 |  |
| Commercial paper | 1,484 |  |  | — |  |  | — |  |  | 1,484 |  |
| Certificates of deposit | 677 |  |  | — |  |  | — |  |  | 677 |  |
| Total | $ | 16,199 |  |  | $ | 18 |  |  | $ | (625) |  |  | $ | 15,592 |  |

[0000858877-23-000023:notes:187]
| July 30, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,287 |  |  | $ | — |  |  | $ | (49) |  |  | $ | 1,238 |  |
| U.S. government agency securities | 142 |  |  | — |  |  | (4) |  |  | 138 |  |
| Non-U.S. government and agency securities | 272 |  |  | — |  |  | — |  |  | 272 |  |
| Corporate debt securities | 8,127 |  |  | 2 |  |  | (311) |  |  | 7,818 |  |
| U.S. agency mortgage-backed securities | 2,134 |  |  | — |  |  | (158) |  |  | 1,976 |  |
| Commercial paper | 255 |  |  | — |  |  | — |  |  | 255 |  |
| Certificates of deposit | 250 |  |  | — |  |  | — |  |  | 250 |  |
| Total | $ | 12,467 |  |  | $ | 2 |  |  | $ | (522) |  |  | $ | 11,947 |  |

[0000858877-23-000023:notes:188]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-23-000023:notes:189]
| Years Ended | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Gross realized gains | $ | 4 |  |  | $ | 27 |  |  | $ | 55 |  |
| Gross realized losses | (25) |  |  | (18) |  |  | (2) |  |
| Total | $ | (21) |  |  | $ | 9 |  |  | $ | 53 |  |

[0000858877-23-000023:notes:190]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at July 29, 2023 and July 30, 2022 (in millions):

[0000858877-23-000023:notes:191]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 2,394 |  |  | $ | (26) |  |  | $ | 931 |  |  | $ | (36) |  |  | $ | 3,325 |  |  | $ | (62) |  |
| U.S. government agency securities | 343 |  |  | (2) |  |  | 72 |  |  | (3) |  |  | 415 |  |  | (5) |  |
| Non-U.S. government and agency securities | 363 |  |  | (1) |  |  | — |  |  | — |  |  | 363 |  |  | (1) |  |
| Corporate debt securities | 1,736 |  |  | (22) |  |  | 4,315 |  |  | (275) |  |  | 6,051 |  |  | (297) |  |
| U.S. agency mortgage-backed securities | 658 |  |  | (13) |  |  | 1,438 |  |  | (217) |  |  | 2,096 |  |  | (230) |  |
| Commercial paper | 97 |  |  | — |  |  | — |  |  | — |  |  | 97 |  |  | — |  |
| Certificates of deposit | 2 |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |
| Total | $ | 5,593 |  |  | $ | (64) |  |  | $ | 6,756 |  |  | $ | (531) |  |  | $ | 12,349 |  |  | $ | (595) |  |

[0000858877-23-000023:notes:192]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 30, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,110 |  |  | $ | (44) |  |  | $ | 120 |  |  | $ | (5) |  |  | $ | 1,230 |  |  | $ | (49) |  |
| U.S. government agency securities | 114 |  |  | (2) |  |  | 24 |  |  | (2) |  |  | 138 |  |  | (4) |  |
| Non-U.S. government and agency securities | 264 |  |  | — |  |  | — |  |  | — |  |  | 264 |  |  | — |  |
| Corporate debt securities | 6,920 |  |  | (240) |  |  | 422 |  |  | (37) |  |  | 7,342 |  |  | (277) |  |
| U.S. agency mortgage-backed securities | 1,305 |  |  | (96) |  |  | 615 |  |  | (62) |  |  | 1,920 |  |  | (158) |  |
| Total | $ | 9,713 |  |  | $ | (382) |  |  | $ | 1,181 |  |  | $ | (106) |  |  | $ | 10,894 |  |  | $ | (488) |  |

[0000858877-23-000023:notes:193]
The following table summarizes the maturities of our available-for-sale debt investments as of July 29, 2023 (in millions):

[0000858877-23-000023:notes:194]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 5,510 |  |  | $ | 5,462 |  |
| After 1 year through 5 years | 8,197 |  |  | 7,856 |  |
| After 5 years through 10 years | 69 |  |  | 67 |  |
| After 10 years | 2 |  |  | 2 |  |
| Mortgage-backed securities with no single maturity | 2,421 |  |  | 2,205 |  |
| Total | $ | 16,199 |  |  | $ | 15,592 |  |

[0000858877-23-000023:notes:195]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-23-000023:notes:196]
(b)Summary of Equity Investments

[0000858877-23-000023:notes:197]
We held marketable equity securities of $431 million and $241 million as of July 29, 2023 and July 30, 2022, respectively. We recognized a net unrealized gain of $36 million during fiscal 2023 and a net unrealized loss of $38 million during fiscal 2022 on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $8 million and a net gain of $32 million for fiscal 2023 and 2022, respectively. We held equity interests in certain private equity funds of $0.9 billion and $1.1 billion as of July 29, 2023 and July 30, 2022, respectively, which are accounted for under the NAV practical expedient.

[0000858877-23-000023:notes:198]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of July 29, 2023, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
As of July 29, 2023, the carrying value of our investments in privately held companies was $1.8 billion. Of the total carrying value of our investments in privately held companies as of July 29, 2023, $1.0 billion of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-23-000023:notes:199]
Fair Value 
(a)Assets and Liabilities Measured at Fair Value on a Recurring Basis

[0000858877-23-000023:notes:200]
Assets and liabilities measured at fair value on a recurring basis were as follows (in millions):

[0000858877-23-000023:notes:201]
|  | JULY 29, 2023 |  | JULY 30, 2022 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 6,496 |  |  | $ | — |  |  | $ | 6,496 |  |  | $ | 3,930 |  |  | $ | — |  |  | $ | 3,930 |  |
| Commercial paper | — |  |  | 1,090 |  |  | 1,090 |  |  | — |  |  | 72 |  |  | 72 |  |
| Certificates of deposit | — |  |  | 47 |  |  | 47 |  |  | — |  |  | 32 |  |  | 32 |  |
| Corporate debt securities | — |  |  | 25 |  |  | 25 |  |  | — |  |  | 1 |  |  | 1 |  |
| U.S. government securities | — |  |  | — |  |  | — |  |  | — |  |  | 12 |  |  | 12 |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 3,526 |  |  | 3,526 |  |  | — |  |  | 1,238 |  |  | 1,238 |  |
| U.S. government agency securities | — |  |  | 423 |  |  | 423 |  |  | — |  |  | 138 |  |  | 138 |  |
| Non-U.S. government and agency securities | — |  |  | 363 |  |  | 363 |  |  | — |  |  | 272 |  |  | 272 |  |
| Corporate debt securities | — |  |  | 6,914 |  |  | 6,914 |  |  | — |  |  | 7,818 |  |  | 7,818 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,205 |  |  | 2,205 |  |  | — |  |  | 1,976 |  |  | 1,976 |  |
| Commercial paper | — |  |  | 1,484 |  |  | 1,484 |  |  | — |  |  | 255 |  |  | 255 |  |
| Certificates of deposit | — |  |  | 677 |  |  | 677 |  |  | — |  |  | 250 |  |  | 250 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 431 |  |  | — |  |  | 431 |  |  | 241 |  |  | — |  |  | 241 |  |
| Other current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 188 |  |  | — |  |  | 188 |  |  | — |  |  | — |  |  | — |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 1,313 |  |  | — |  |  | 1,313 |  |  | 1,500 |  |  | — |  |  | 1,500 |  |
| Derivative assets | — |  |  | 32 |  |  | 32 |  |  | — |  |  | 78 |  |  | 78 |  |
| Total | $ | 8,428 |  |  | $ | 16,786 |  |  | $ | 25,214 |  |  | $ | 5,671 |  |  | $ | 12,142 |  |  | $ | 17,813 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 75 |  |  | $ | 75 |  |  | $ | — |  |  | $ | 89 |  |  | $ | 89 |  |
| Total | $ | — |  |  | $ | 75 |  |  | $ | 75 |  |  | $ | — |  |  | $ | 89 |  |  | $ | 89 |  |

[0000858877-23-000023:notes:202]
(b)Assets Measured at Fair Value on a Nonrecurring Basis

[0000858877-23-000023:notes:203]
Our non-marketable equity securities using the measurement alternative are adjusted to fair value on a non-recurring basis. Adjustments are made when observable transactions for identical or similar investments of the same issuer occur, or due to impairment. These securities are classified as Level 3 in the fair value hierarchy because we estimate the value based on valuation methods using the observable transaction price at the transaction date and other unobservable inputs such as volatility, rights, and obligations of the securities we hold.

[0000858877-23-000023:notes:204]
(c)Other Fair Value Disclosures

[0000858877-23-000023:notes:205]
The fair value of our short-term loan receivables approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables as of July 29, 2023 and July 30, 2022 was $2.9 billion and $3.4 billion, respectively. The estimated fair value of our long-term loan receivables approximates their carrying value. We use unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables, and therefore they are categorized as Level 3.
As of July 29, 2023 and July 30, 2022, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of July 29, 2023, the fair value of our senior notes was $8.7 billion, with a carrying amount of $8.4 billion. This compares to a fair value of $9.7 billion and a carrying amount of $8.9 billion as of July 30, 2022. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2.


## us-gaap:DebtDisclosureTextBlock

[0000858877-23-000023:notes:206]
Borrowings 
(a)Short-Term Debt

[0000858877-23-000023:notes:207]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-23-000023:notes:208]
|  | July 29, 2023 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,733 |  |  | 4.45 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,733 |  |  |  |  | $ | 1,099 |  |  |  |

[0000858877-23-000023:notes:209]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-23-000023:notes:210]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-23-000023:notes:211]
(b)Long-Term Debt

[0000858877-23-000023:notes:212]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-23-000023:notes:213]
|  |  |  | July 29, 2023 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 6.08% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.38% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 8,500 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (68) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (41) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,391 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 1,733 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 6,658 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,391 |  |  |  |  | $ | 8,915 |  |  |  |

[0000858877-23-000023:notes:214]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $1.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on SOFR. The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-23-000023:notes:215]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of July 29, 2023, we were in compliance with all debt covenants.

[0000858877-23-000023:notes:216]
As of July 29, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-23-000023:notes:217]
| Fiscal Year | Amount |
| 2024 | $ | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 8,500 |  |

[0000858877-23-000023:notes:218]
(c)Credit Facility

[0000858877-23-000023:notes:219]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of July 29, 2023, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement. On April 18, 2023, we entered into an amendment to the credit agreement to replace the LIBOR index with Term SOFR.

[0000858877-23-000023:notes:220]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) Term SOFR (plus a 0.10% credit spread adjustment) or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) Term SOFR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-23-000023:notes:221]
Derivative Instruments 
(a)Summary of Derivative Instruments

[0000858877-23-000023:notes:222]
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We do, however, seek to mitigate such risks by limiting our counterparties to major financial institutions and requiring collateral in certain cases. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-23-000023:notes:223]
The fair values of our derivative instruments and the line items on the Consolidated Balance Sheets to which they were recorded are summarized as follows (in millions):

[0000858877-23-000023:notes:224]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | July 29, 2023 |  | July 30, 2022 |  | Balance Sheet Line Item |  | July 29, 2023 |  | July 30, 2022 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 22 |  |  | $ | 55 |  |  | Other current liabilities |  | $ | — |  |  | $ | — |  |
| Foreign currency derivatives | Other assets |  | 9 |  |  | 9 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 17 |  |  | — |  |
| Interest rate derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 24 |  |  | 10 |  |
| Total |  |  | 31 |  |  | 64 |  |  |  |  | 41 |  |  | 10 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 1 |  |  | 14 |  |  | Other current liabilities |  | 25 |  |  | 69 |  |
| Foreign currency derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 9 |  |  | 9 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | — |  |  | 1 |  |
| Total |  |  | 1 |  |  | 14 |  |  |  |  | 34 |  |  | 79 |  |
| Total |  |  | $ | 32 |  |  | $ | 78 |  |  |  |  | $ | 75 |  |  | $ | 89 |  |

[0000858877-23-000023:notes:225]
The following amounts were recorded on the Consolidated Balance Sheets related to cumulative basis adjustments for our fair value hedges (in millions):

[0000858877-23-000023:notes:226]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | July 29,2023 |  | July 30,2022 |  | July 29,2023 |  | July 30,2022 |
| Short-term debt |  | $ | (983) |  |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |
| Long-term debt |  | $ | (476) |  |  | $ | (1,487) |  |  | $ | 24 |  |  | $ | 10 |  |

[0000858877-23-000023:notes:227]
The effect of derivative instruments designated as fair value hedges, recognized in interest and other income (loss), net is summarized as follows (in millions):

[0000858877-23-000023:notes:228]
|  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
|  |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Interest rate derivatives: |  |  |  |  |  |  |
| Hedged items |  | $ | 31 |  |  | $ | 116 |  |  | $ | 65 |  |
| Derivatives designated as hedging instruments |  | (31) |  |  | (118) |  |  | (67) |  |
| Total |  | $ | — |  |  | $ | (2) |  |  | $ | (2) |  |

[0000858877-23-000023:notes:229]
The effect on the Consolidated Statements of Operations of derivative instruments not designated as hedges is summarized as follows (in millions):

[0000858877-23-000023:notes:230]
|  |  |  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | 1 |  |  | $ | (237) |  |  | $ | 2 |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | 58 |  |  | (92) |  |  | 157 |  |
| Equity derivatives |  | Other income (loss), net |  | 13 |  |  | 9 |  |  | 20 |  |
| Total |  |  |  | $ | 72 |  |  | $ | (320) |  |  | $ | 179 |  |

[0000858877-23-000023:notes:231]
The notional amounts of our outstanding derivatives are summarized as follows (in millions):

[0000858877-23-000023:notes:232]
|  | July 29, 2023 |  | July 30, 2022 |
| Foreign currency derivatives | $ | 5,419 |  |  | $ | 4,521 |  |
| Interest rate derivatives | 1,500 |  |  | 1,500 |  |
| Total return swaps—deferred compensation | 792 |  |  | 651 |  |
| Total | $ | 7,711 |  |  | $ | 6,672 |  |

[0000858877-23-000023:notes:233]
(b)Offsetting of Derivative Instruments

[0000858877-23-000023:notes:234]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty.

[0000858877-23-000023:notes:235]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral provided for was $40 million and $14 million as of July 29, 2023 and July 30, 2022, respectively.

[0000858877-23-000023:notes:236]
(c)Foreign Currency Exchange Risk

[0000858877-23-000023:notes:237]
We conduct business globally in numerous currencies. Therefore, we are exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, we enter into foreign currency contracts. We do not enter into such contracts for speculative purposes.

[0000858877-23-000023:notes:238]
We hedge forecasted foreign currency transactions related to certain revenues, operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The derivative instrument’s gain or loss is initially reported as a component of accumulated other comprehensive income (AOCI) and subsequently reclassified into earnings when the hedged exposure affects earnings.

[0000858877-23-000023:notes:239]
We enter into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, long-term customer financings and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of intercompany balances, other current assets, or liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-23-000023:notes:240]
We hedge certain net investments in our foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on our net investment in those foreign subsidiaries. These derivative instruments generally have maturities of up to six months.

[0000858877-23-000023:notes:241]
(d)Interest Rate Risk

[0000858877-23-000023:notes:242]
We hold interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2024 through 2025. Under these interest rate swaps, we receive fixed-rate interest payments and make interest payments based on SOFR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on SOFR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.

[0000858877-23-000023:notes:243]
(e)Equity Price Risk

[0000858877-23-000023:notes:244]
We hold marketable equity securities in our portfolio that are subject to price risk. To diversify our overall portfolio, we also hold equity derivatives that are not designated as accounting hedges. The change in the fair value of each of these investment types are included in other income (loss), net. 
We are also exposed to variability in compensation charges related to certain deferred compensation obligations to employees. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure and offset the related compensation expense.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-23-000023:notes:245]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-23-000023:notes:246]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-23-000023:notes:247]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-23-000023:notes:248]
| Commitments by Period | July 29,2023 |  | July 30,2022 |
| Less than 1 year | $ | 5,270 |  |  | $ | 9,954 |  |
| 1 to 3 years | 1,783 |  |  | 2,240 |  |
| 3 to 5 years | 200 |  |  | 770 |  |
| Total | $ | 7,253 |  |  | $ | 12,964 |  |

[0000858877-23-000023:notes:249]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 29, 2023 and July 30, 2022, the liability for these purchase commitments was $529 million and $313 million, respectively, and was included in other current liabilities.

[0000858877-23-000023:notes:250]
(b)Other Commitments

[0000858877-23-000023:notes:251]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-23-000023:notes:252]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-23-000023:notes:253]
|  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Compensation expense related to acquisitions | $ | 222 |  |  | $ | 271 |  |  | $ | 262 |  |

[0000858877-23-000023:notes:254]
As of July 29, 2023, we estimated that future cash compensation expense of up to $349 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-23-000023:notes:255]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion and $0.4 billion as of July 29, 2023 and July 30, 2022, respectively.

[0000858877-23-000023:notes:256]
(c)Product Warranties

[0000858877-23-000023:notes:257]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-23-000023:notes:258]
|  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Balance at beginning of fiscal year | $ | 333 |  |  | $ | 336 |  |  | $ | 331 |  |
| Provisions for warranties issued | 386 |  |  | 415 |  |  | 496 |  |
| Adjustments for pre-existing warranties | 18 |  |  | 3 |  |  | — |  |
| Settlements | (408) |  |  | (421) |  |  | (491) |  |
| Balance at end of fiscal year | $ | 329 |  |  | $ | 333 |  |  | $ | 336 |  |

[0000858877-23-000023:notes:259]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-23-000023:notes:260]
(d)Financing and Other Guarantees

[0000858877-23-000023:notes:261]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-23-000023:notes:262]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $32.1 billion, $27.9 billion, and $26.7 billion in fiscal 2023, 2022, and 2021, respectively. The balance of the channel partner financing subject to guarantees was $1.7 billion and $1.4 billion as of July 29, 2023 and July 30, 2022, respectively.

[0000858877-23-000023:notes:263]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at July 29, 2023 and July 30, 2022, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-23-000023:notes:264]
|  | July 29, 2023 |  | July 30, 2022 |
| Maximum potential future payments | $ | 159 |  |  | $ | 188 |  |
| Deferred revenue | (34) |  |  | (9) |  |
| Total | $ | 125 |  |  | $ | 179 |  |

[0000858877-23-000023:notes:265]
(e)Indemnifications

[0000858877-23-000023:notes:266]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-23-000023:notes:267]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-23-000023:notes:268]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-23-000023:notes:269]
(f)Legal Proceedings

[0000858877-23-000023:notes:270]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-23-000023:notes:271]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $171 million for the alleged evasion of import and other taxes, $974 million for interest, and $423 million for various penalties, all determined using an exchange rate as of July 29, 2023.

[0000858877-23-000023:notes:272]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-23-000023:notes:273]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. The district court case went to trial on five asserted patents. Subsequently, on October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent and awarded $1.9 billion in damages and $14 million in pre-judgment interest, declined to issue an injunction

[0000858877-23-000023:notes:274]
but, instead, awarded Centripetal a royalty against future revenue for an initial three-year term at a 10% rate, with a minimum and maximum annual royalty of $168 million and $300 million, respectively, and for a second three-year term at a 5% rate, with a minimum and maximum annual royalty of $84 million and $150 million, respectively. We appealed and, on June 23, 2022, the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”) vacated the district court’s final judgment, remanded the case back to the district court to be assigned to a new judge and ordered the district court to conduct additional proceedings. The district court held a hearing on these additional proceedings over three days beginning on June 22, 2023, and a decision is pending. Prior to the hearing, on May 24, 2023, the Patent Trial and Appeal Board cancelled all claims of one of the Centripetal patents that was the subject of the hearing. On August 9, 2022, Centripetal filed a petition for writ of certiorari in the U.S. Supreme Court challenging the Federal Circuit’s decision. The Supreme Court denied Centripetal’s petition on December 5, 2022.

[0000858877-23-000023:notes:275]
Between April 2020 and February 2022, Centripetal filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. On December 10, 2021, the German Court rejected Centripetal’s complaints on two patents, and Centripetal has appealed. A hearing for a Cisco nullity action in the Federal Patent Court in Germany on one of those two patents occurred on August 1, 2022, and we are waiting for the Court’s opinion. On December 21, 2021, the German Court stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. On May 17, 2022, Centripetal withdrew its complaint for infringement of the German utility model. The German Court conducted a hearing on the remaining two Centripetal complaints on November 22, 2022. The German Court found no infringement on one patent and stayed the decision in the final case pending a decision by the European Patent Office in a related opposition proceeding.

[0000858877-23-000023:notes:276]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement.

[0000858877-23-000023:notes:277]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of the litigations at this time. If we do not prevail in either litigation, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-23-000023:notes:278]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. We challenged the validity of all three patents in the U.S. Patent and Trademark Office (“PTO”) by way of ex parte reexamination proceedings and the pending District Court case has been stayed. On July 10, 2023, the PTO issued a reexamination certificate finding all amended claims patentable with respect to one asserted patent and reexamination proceedings for the other two asserted patents are still pending.

[0000858877-23-000023:notes:279]
On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) in the District of Delaware (“D. Del.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot asserted in the E.D. Tex. case and this case is also stayed pending the reexamination proceedings referenced above.

[0000858877-23-000023:notes:280]
On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents in the same family as those involved in the pending cases above. Ramot is asserting counterclaims for infringement of the same patents and seeks damages, including enhanced damages, and a royalty on future sales. While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-23-000023:notes:281]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward (“Viasat 2019”). In May 2023, a judgment was entered against Cisco in Viasat 2019 for an amount that did not have a material effect on our Consolidated Financial Statements. Acacia has filed an appeal with the California Court of Appeal and no hearing date has been set.

[0000858877-23-000023:notes:282]
On June 9, 2020, Viasat filed another suit in SDSC alleging contract and trade secret claims for sales of additional Acacia products (“Viasat 2020”). In October 2022, an amended complaint was filed in Viasat 2020 asserting the same claims but alleging additional information. A trial date has been set for January 26, 2024. We are unable to reasonably estimate the ultimate outcome of Viasat 2020 at this time due to uncertainties in the litigation processes. If we do not prevail, we believe that any relief ultimately assessed in Viasat 2020 will not have a material effect on our Consolidated Financial Statements.

[0000858877-23-000023:notes:283]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023 and those proceedings are ongoing.

[0000858877-23-000023:notes:284]
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. 
For additional information regarding intellectual property litigation, see “Part I, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-23-000023:notes:285]
Stockholders’ Equity 
(a)Stock Repurchase Program

[0000858877-23-000023:notes:286]
In September 2001, our Board of Directors authorized a stock repurchase program. As of July 29, 2023, the remaining authorized amount for stock repurchases under this program was approximately $10.9 billion with no termination date.

[0000858877-23-000023:notes:287]
A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-23-000023:notes:288]
| Years Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| July 29, 2023 |  | 88 |  |  | $ | 48.49 |  |  | $ | 4,271 |  |
| July 30, 2022 |  | 146 |  |  | $ | 52.82 |  |  | $ | 7,734 |  |
| July 31, 2021 |  | 64 |  |  | $ | 45.48 |  |  | $ | 2,902 |  |

[0000858877-23-000023:notes:289]
There were $48 million, $70 million and $25 million in stock repurchases that were pending settlement as of July 29, 2023, July 30, 2022 and July 31, 2021, respectively.

[0000858877-23-000023:notes:290]
The purchase price for the shares of our stock repurchased is reflected as a reduction to stockholders’ equity.

[0000858877-23-000023:notes:291]
We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings or an increase to accumulated deficit and (ii) a reduction of common stock and additional paid-in capital.

[0000858877-23-000023:notes:292]
(b)Dividends Declared

[0000858877-23-000023:notes:293]
On August 16, 2023, our Board of Directors declared a quarterly dividend of $0.39 per common share to be paid on October 25, 2023, to all stockholders of record as of the close of business on October 4, 2023. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-23-000023:notes:294]
(c)Preferred Stock

[0000858877-23-000023:notes:295]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock in one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights, if any, of such series, and any qualifications, limitations or restrictions thereof, of the shares of such series. As of July 29, 2023, we had not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-23-000023:notes:296]
Employee Benefit Plans  
(a)Employee Stock Incentive Plans

[0000858877-23-000023:notes:297]
We have one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with us. The number and frequency of share-based awards are based on competitive practices, our operating results, government regulations, and other factors. Our primary stock incentive plan is summarized as follows:

[0000858877-23-000023:notes:298]
The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions. Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. The 2005 Plan may be terminated by our Board of Directors at any time and for any reason, and is currently set to terminate at the 2030 Annual Meeting unless re-adopted or extended by our stockholders prior to or on such date.

[0000858877-23-000023:notes:299]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of July 29, 2023, 124 million shares were authorized for future grant under the 2005 Plan.

[0000858877-23-000023:notes:300]
(b)Employee Stock Purchase Plan

[0000858877-23-000023:notes:301]
We have an Employee Stock Purchase Plan under which eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. We issued 19 million, 18 million, and 17 million shares under the Employee Stock Purchase Plan in fiscal 2023, 2022, and 2021, respectively. As of July 29, 2023, 88 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-23-000023:notes:302]
(c)Summary of Share-Based Compensation Expense

[0000858877-23-000023:notes:303]
Share-based compensation expense consists primarily of expenses for RSUs, stock purchase rights, and stock options, granted to employees or assumed from acquisitions. The following table summarizes share-based compensation expense (in millions):

[0000858877-23-000023:notes:304]
| Years Ended | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Cost of sales—product | $ | 151 |  |  | $ | 112 |  |  | $ | 99 |  |
| Cost of sales—service | 245 |  |  | 199 |  |  | 176 |  |
| Share-based compensation expense in cost of sales | 396 |  |  | 311 |  |  | 275 |  |
| Research and development | 1,008 |  |  | 790 |  |  | 694 |  |
| Sales and marketing | 673 |  |  | 572 |  |  | 540 |  |
| General and administrative | 270 |  |  | 212 |  |  | 226 |  |
| Restructuring and other charges | 6 |  |  | 1 |  |  | 26 |  |
| Share-based compensation expense in operating expenses | 1,957 |  |  | 1,575 |  |  | 1,486 |  |
| Total share-based compensation expense | $ | 2,353 |  |  | $ | 1,886 |  |  | $ | 1,761 |  |
| Income tax benefit for share-based compensation | $ | 449 |  |  | $ | 457 |  |  | $ | 387 |  |

[0000858877-23-000023:notes:305]
As of July 29, 2023, the total compensation cost related to unvested share-based awards not yet recognized was $4.7 billion, which is expected to be recognized over approximately 2.2 years on a weighted-average basis.

[0000858877-23-000023:notes:306]
(d)Restricted Stock Unit Awards

[0000858877-23-000023:notes:307]
A summary of the restricted stock and stock unit activity, which includes time-based and performance-based or market-based RSUs, is as follows (in millions, except per-share amounts):

[0000858877-23-000023:notes:308]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 25, 2020 | 96 |  |  | $ | 42.03 |  |  |  |
| Granted and assumed | 51 |  |  | 41.89 |  |  |  |
| Vested | (39) |  |  | 39.63 |  |  | $ | 1,813 |  |
| Canceled/forfeited/other | (14) |  |  | 42.13 |  |  |  |
| UNVESTED BALANCE AT JULY 31, 2021 | 94 |  |  | 42.93 |  |  |  |
| Granted and assumed | 52 |  |  | 50.06 |  |  |  |
| Vested | (37) |  |  | 42.27 |  |  | $ | 1,979 |  |
| Canceled/forfeited/other | (12) |  |  | 45.63 |  |  |  |
| UNVESTED BALANCE AT JULY 30, 2022 | 97 |  |  | 46.67 |  |  |  |
| Granted and assumed | 72 |  |  | 42.08 |  |  |  |
| Vested | (39) |  |  | 46.69 |  |  | $ | 1,746 |  |
| Canceled/forfeited/other | (8) |  |  | 45.17 |  |  |  |
| UNVESTED BALANCE AT JULY 29, 2023 | 122 |  |  | $ | 44.04 |  |  |  |

[0000858877-23-000023:notes:309]
(e)Valuation of Employee Share-Based Awards

[0000858877-23-000023:notes:310]
Time-based restricted stock units and PRSUs that are based on our financial performance metrics or non-financial operating goals are valued using the market value of our common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, we estimated the fair value of the total shareholder return (TSR) component of the PRSUs using a Monte Carlo simulation model. The PRSUs granted during the fiscal years presented are contingent on the achievement of our financial performance metrics, our comparative market-based returns, or the achievement of financial and non-financial operating goals.

[0000858877-23-000023:notes:311]
The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-23-000023:notes:312]
|  | RESTRICTED STOCK UNITS |
| Years Ended | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Number of shares granted (in millions) | 70 |  |  | 50 |  |  | 48 |  |
| Grant date fair value per share | $ | 42.13 |  |  | $ | 49.68 |  |  | $ | 42.04 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 3.4 | % |  | 2.9 | % |  | 3.3 | % |
| Range of risk-free interest rates | 3.7% – 5.7% |  | 0.0% – 3.0% |  | 0.0% – 0.9% |

[0000858877-23-000023:notes:313]
|  | PERFORMANCE BASED RESTRICTED STOCK UNITS |
| Years Ended | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Number of shares granted (in millions) | 2 |  |  | 2 |  |  | 2 |  |
| Grant date fair value per share | $ | 40.44 |  |  | $ | 59.64 |  |  | $ | 37.91 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | N/A |  | 0.4 | % |  | 3.6 | % |
| Range of risk-free interest rates | N/A |  | 0.0% – 0.7% |  | 0.1% – 0.4% |

[0000858877-23-000023:notes:314]
The assumptions for the valuation of employee stock purchase rights are summarized as follows:

[0000858877-23-000023:notes:315]
|  | EMPLOYEE STOCK PURCHASE RIGHTS |
| Years Ended | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Weighted-average assumptions: |  |  |  |  |  |
| Expected volatility | 28.7 | % |  | 27.9 | % |  | 29.2 | % |
| Risk-free interest rate | 2.8 | % |  | 0.1 | % |  | 0.3 | % |
| Expected dividend | 3.6 | % |  | 3.2 | % |  | 3.2 | % |
| Expected life (in years) | 1.2 |  | 1.2 |  | 1.3 |
| Weighted-average estimated grant date fair value per share | $ | 12.40 |  |  | $ | 12.90 |  |  | $ | 12.46 |  |

[0000858877-23-000023:notes:316]
The valuation of employee stock purchase rights and the related assumptions are for the employee stock purchases made during the respective fiscal years.

[0000858877-23-000023:notes:317]
We used the implied volatility for traded options (with contract terms corresponding to the expected life of the employee stock purchase rights) on our stock as the expected volatility assumption required in the Black-Scholes model. The implied volatility is more representative of future stock price trends than historical volatility. The risk-free interest rate assumption is based upon observed interest rates appropriate for the term of our employee stock purchase rights. The dividend yield assumption is based on the history and expectation of dividend payouts at the grant date.

[0000858877-23-000023:notes:318]
(f)Employee 401(k) Plans

[0000858877-23-000023:notes:319]
We sponsor the Cisco Systems, Inc. 401(k) Plan (the “Plan”) to provide retirement benefits for our employees. As allowed under Section 401(k) of the Internal Revenue Code, the Plan provides for tax-deferred salary contributions and after-tax contributions for eligible employees. The Plan allows employees to contribute up to 75% of their annual eligible earnings to the Plan on a pretax and after-tax basis, including Roth contributions. Employee contributions are limited to a maximum annual amount as set periodically by the Internal Revenue Code. We match pretax and Roth employee contributions up to 100% of the first 4.5% of eligible earnings that are contributed by employees. Therefore, the maximum matching contribution that we may allocate to each participant’s account will not exceed $14,850 for the 2023 calendar year due to the $330,000 annual limit on eligible earnings imposed by the Internal Revenue Code. All matching contributions vest immediately. Our matching contributions to the Plan totaled $342 million, $306 million, and $290 million in fiscal 2023, 2022, and 2021, respectively.

[0000858877-23-000023:notes:320]
The Plan allows employees who meet the age requirements and reach the Plan contribution limits to make catch-up contributions (pretax or Roth) not to exceed the lesser of 75% of their annual eligible earnings or the limit set forth in the Internal Revenue Code. Catch-up contributions are not eligible for matching contributions. In addition, the Plan provides for discretionary profit-sharing contributions as determined by the Board of Directors. Such contributions to the Plan are allocated among eligible participants in the proportion of their salaries to the total salaries of all participants. There were no discretionary profit-sharing contributions made in fiscal 2023, 2022, and 2021.

[0000858877-23-000023:notes:321]
We also sponsor other 401(k) plans as a result of acquisitions of other companies. Our contributions to these plans were not material to Cisco on either an individual or aggregate basis for any of the fiscal years presented.

[0000858877-23-000023:notes:322]
(g)Deferred Compensation Plans
The Cisco Systems, Inc. Deferred Compensation Plan (the “Deferred Compensation Plan”), a nonqualified deferred compensation plan, became effective in 2007. As required by applicable law, participation in the Deferred Compensation Plan is limited to a select group of our management employees. Under the Deferred Compensation Plan, which is an unfunded and unsecured deferred compensation arrangement, a participant may elect to defer base salary, bonus, and/or commissions, pursuant to such rules as may be established by Cisco, up to the maximum percentages for each deferral election as described in the plan. We may also, at our discretion, make a matching contribution to the employee under the Deferred Compensation Plan. A matching contribution equal to 4.5% of eligible compensation in excess of the Internal Revenue Code limit for qualified plans for calendar year 2023 that is deferred by participants under the Deferred Compensation Plan (with a $1.5 million cap on eligible compensation) will be made to eligible participants’ accounts at the end of calendar year 2023. The total deferred compensation liability under the Deferred Compensation Plan, together with deferred compensation plans assumed from acquired companies, was approximately $910 million and $760 million as of July 29, 2023 and July 30, 2022, respectively, and was recorded primarily in other long-term liabilities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-23-000023:notes:323]
Comprehensive Income (Loss)  
The components of AOCI, net of tax, and the other comprehensive income (loss) are summarized as follows (in millions):

[0000858877-23-000023:notes:324]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 25, 2020 | $ | 315 |  |  | $ | (6) |  |  | $ | (828) |  |  | $ | (519) |  |
| Other comprehensive income (loss) before reclassifications | (141) |  |  | 20 |  |  | 229 |  |  | 108 |  |
| (Gains) losses reclassified out of AOCI | (53) |  |  | (14) |  |  | 3 |  |  | (64) |  |
| Tax benefit (expense) | 61 |  |  | (1) |  |  | (2) |  |  | 58 |  |
| BALANCE AT JULY 31, 2021 | 182 |  |  | (1) |  |  | (598) |  |  | (417) |  |
| Other comprehensive income (loss) before reclassifications | (731) |  |  | 87 |  |  | (647) |  |  | (1,291) |  |
| (Gains) losses reclassified out of AOCI | (9) |  |  | (29) |  |  | 2 |  |  | (36) |  |
| Tax benefit (expense) | 179 |  |  | (13) |  |  | (44) |  |  | 122 |  |
| BALANCE AT JULY 30, 2022 | (379) |  |  | 44 |  |  | (1,287) |  |  | (1,622) |  |
| Other comprehensive income (loss) before reclassifications | (113) |  |  | 29 |  |  | 116 |  |  | 32 |  |
| (Gains) losses reclassified out of AOCI | 21 |  |  | (63) |  |  | (1) |  |  | (43) |  |
| Tax benefit (expense) | 31 |  |  | 8 |  |  | 19 |  |  | 58 |  |
| BALANCE AT JULY 29, 2023 | $ | (440) |  |  | $ | 18 |  |  | $ | (1,153) |  |  | $ | (1,575) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-23-000023:notes:325]
Income Taxes
(a)Provision for Income Taxes

[0000858877-23-000023:notes:326]
The provision for income taxes consists of the following (in millions):

[0000858877-23-000023:notes:327]
| Years Ended | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Federal: |  |  |  |  |  |
| Current | $ | 3,754 |  |  | $ | 2,203 |  |  | $ | 1,959 |  |
| Deferred | (1,955) |  |  | (176) |  |  | (203) |  |
|  | 1,799 |  |  | 2,027 |  |  | 1,756 |  |
| State: |  |  |  |  |  |
| Current | 623 |  |  | 458 |  |  | 513 |  |
| Deferred | (175) |  |  | (156) |  |  | (46) |  |
|  | 448 |  |  | 302 |  |  | 467 |  |
| Foreign: |  |  |  |  |  |
| Current | 412 |  |  | 313 |  |  | 583 |  |
| Deferred | 46 |  |  | 23 |  |  | (135) |  |
|  | 458 |  |  | 336 |  |  | 448 |  |
| Total | $ | 2,705 |  |  | $ | 2,665 |  |  | $ | 2,671 |  |

[0000858877-23-000023:notes:328]
Income before provision for income taxes consists of the following (in millions):

[0000858877-23-000023:notes:329]
| Years Ended | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| United States | $ | 14,074 |  |  | $ | 13,550 |  |  | $ | 12,335 |  |
| International | 1,244 |  |  | 927 |  |  | 927 |  |
| Total | $ | 15,318 |  |  | $ | 14,477 |  |  | $ | 13,262 |  |

[0000858877-23-000023:notes:330]
The items accounting for the difference between income taxes computed at the federal statutory rate and the provision for income taxes consist of the following:

[0000858877-23-000023:notes:331]
| Years Ended | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Federal statutory rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 2.4 |  |  | 1.7 |  |  | 2.7 |  |
| Foreign income at other than U.S. rates | (0.1) |  |  | 0.8 |  |  | 1.5 |  |
| Tax credits | (0.3) |  |  | (1.6) |  |  | (1.4) |  |
| Foreign-derived intangible income deduction | (5.8) |  |  | (3.9) |  |  | (4.2) |  |
| Stock-based compensation | 1.1 |  |  | 0.3 |  |  | 0.6 |  |
| Other, net | (0.6) |  |  | 0.1 |  |  | (0.1) |  |
| Total | 17.7 | % |  | 18.4 | % |  | 20.1 | % |

[0000858877-23-000023:notes:332]
During fiscal 2023, we resolved certain items with the Internal Revenue Service (IRS) related to the audit of our federal income tax returns for the fiscal years ended July 26, 2014 through July 30, 2016. As a result of the resolution, we recognized a net benefit to the provision for income taxes of $145 million, which included a reduction of interest expense of $53 million.

[0000858877-23-000023:notes:333]
Foreign taxes associated with the repatriation of earnings of foreign subsidiaries were not provided on a cumulative total of $6.5 billion of undistributed earnings for certain foreign subsidiaries as of the end of fiscal 2023. We intend to reinvest these earnings indefinitely in such foreign subsidiaries. If these earnings were distributed in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, we could be subject to additional income and withholding taxes. The amount of potential unrecognized deferred income tax liability related to these earnings is approximately $681 million.

[0000858877-23-000023:notes:334]
Unrecognized Tax Benefits

[0000858877-23-000023:notes:335]
The aggregate changes in the balance of gross unrecognized tax benefits were as follows (in millions):

[0000858877-23-000023:notes:336]
| Years Ended | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Beginning balance | $ | 3,101 |  |  | $ | 3,106 |  |  | $ | 2,518 |  |
| Additions based on tax positions related to the current year | 159 |  |  | 157 |  |  | 224 |  |
| Additions for tax positions of prior years | 261 |  |  | 74 |  |  | 618 |  |
| Reductions for tax positions of prior years | (265) |  |  | (81) |  |  | (122) |  |
| Settlements | (1,063) |  |  | (69) |  |  | (93) |  |
| Lapse of statute of limitations | (56) |  |  | (86) |  |  | (39) |  |
| Ending balance | $ | 2,137 |  |  | $ | 3,101 |  |  | $ | 3,106 |  |

[0000858877-23-000023:notes:337]
As a result of resolving certain items related to the IRS audit of our federal tax income tax returns for the fiscal years ended July 26, 2014 through July 30, 2016, the amount of gross unrecognized tax benefits in fiscal 2023 was reduced by approximately $1.1 billion. We also reduced the amount of accrued interest by $69 million.

[0000858877-23-000023:notes:338]
As of July 29, 2023, $1.7 billion of the unrecognized tax benefits would affect the effective tax rate if realized. We recognized net interest expense of $27 million, $33 million and $74 million during fiscal 2023, 2022, and 2021, respectively. Our net penalty expense for fiscal 2023, 2022, and 2021 was not material. Our total accrual for interest and penalties was $523 million, $486 million, and $444 million as of the end of fiscal 2023, 2022, and 2021, respectively. We are no longer subject to U.S. federal income tax audit for returns covering tax years through fiscal 2013. We are no longer subject to foreign or state income tax audits for returns covering tax years through fiscal 2003 and fiscal 2008, respectively.

[0000858877-23-000023:notes:339]
We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters. We estimate that the unrecognized tax benefits at July 29, 2023 could be reduced by $350 million in the next 12 months.

[0000858877-23-000023:notes:340]
(b)Deferred Tax Assets and Liabilities

[0000858877-23-000023:notes:341]
The following table presents the breakdown for net deferred tax assets (in millions):

[0000858877-23-000023:notes:342]
|  | July 29, 2023 |  | July 30, 2022 |
| Deferred tax assets | $ | 6,576 |  |  | $ | 4,449 |  |
| Deferred tax liabilities | (62) |  |  | (55) |  |
| Total net deferred tax assets | $ | 6,514 |  |  | $ | 4,394 |  |

[0000858877-23-000023:notes:343]
The following table presents the components of the deferred tax assets and liabilities (in millions):

[0000858877-23-000023:notes:344]
|  | July 29, 2023 |  | July 30, 2022 |
| ASSETS |  |  |  |
| Allowance for accounts receivable and returns | $ | 81 |  |  | $ | 90 |  |
| Sales-type and direct-financing leases | 22 |  |  | 29 |  |
| Inventory write-downs and capitalization | 452 |  |  | 430 |  |
| Deferred foreign income | 218 |  |  | 210 |  |
| IPR&D and purchased intangible assets | 1,082 |  |  | 1,184 |  |
| Depreciation | 16 |  |  | 10 |  |
| Deferred revenue | 1,801 |  |  | 1,744 |  |
| Credits and net operating loss carryforwards | 1,218 |  |  | 1,336 |  |
| Share-based compensation expense | 198 |  |  | 138 |  |
| Accrued compensation | 328 |  |  | 333 |  |
| Lease liabilities | 246 |  |  | 248 |  |
| Capitalized research expenditures | 2,042 |  |  | 149 |  |
| Other | 484 |  |  | 439 |  |
| Gross deferred tax assets | 8,188 |  |  | 6,340 |  |
| Valuation allowance | (754) |  |  | (834) |  |
| Total deferred tax assets | 7,434 |  |  | 5,506 |  |
| LIABILITIES |  |  |  |
| Goodwill and purchased intangible assets | (602) |  |  | (767) |  |
| Unrealized gains on investments | — |  |  | (26) |  |
| ROU lease assets | (234) |  |  | (237) |  |
| Other | (84) |  |  | (82) |  |
| Total deferred tax liabilities | (920) |  |  | (1,112) |  |
| Total net deferred tax assets | $ | 6,514 |  |  | $ | 4,394 |  |

[0000858877-23-000023:notes:345]
The changes in the valuation allowance for deferred tax assets are summarized as follows (in millions):

[0000858877-23-000023:notes:346]
|  |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Balance at beginning of fiscal year |  | $ | 834 |  |  | $ | 771 |  |  | $ | 700 |  |
| Additions |  | 35 |  |  | 84 |  |  | 91 |  |
| Deductions |  | (18) |  |  | (10) |  |  | (5) |  |
| Write-offs |  | (93) |  |  | (12) |  |  | (16) |  |
| Foreign exchange and other |  | (4) |  |  | 1 |  |  | 1 |  |
| Balance at end of fiscal year |  | $ | 754 |  |  | $ | 834 |  |  | $ | 771 |  |

[0000858877-23-000023:notes:347]
As of July 29, 2023, our federal, state, and foreign net operating loss carryforwards before valuation allowance for income tax purposes were $320 million, $879 million, and $524 million, respectively. A significant amount of the net operating loss carryforwards relates to acquisitions and, as a result, is limited in the amount that can be recognized in any one year. If not utilized, the federal, state, and foreign net operating loss carryforwards will begin to expire in fiscal 2024. We have provided a valuation allowance of $82 million and $10 million for deferred tax assets related to foreign and state net operating losses respectively that are not expected to be realized.
As of July 29, 2023, our federal, state, and foreign tax credit carryforwards for income tax purposes before valuation allowance were approximately $5 million, $1.6 billion, and $2 million, respectively. The federal tax credit carryforwards will begin to expire in fiscal 2026. The majority of state and foreign tax credits can be carried forward indefinitely. We have provided a valuation allowance of $594 million for deferred tax assets related to state and foreign tax credits carryforwards that are not expected to be realized.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-23-000023:notes:348]
Segment Information and Major Customers 
(a)Revenue and Gross Margin by Segment

[0000858877-23-000023:notes:349]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-23-000023:notes:350]
Summarized financial information by segment for fiscal 2023, 2022, and 2021, based on our internal management system and as utilized by our Chief Operating Decision Maker (CODM), is as follows (in millions):

[0000858877-23-000023:notes:351]
| Years Ended | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Revenue: |  |  |  |  |  |
| Americas | $ | 33,447 |  |  | $ | 29,814 |  |  | $ | 29,161 |  |
| EMEA | 15,135 |  |  | 13,715 |  |  | 12,951 |  |
| APJC | 8,417 |  |  | 8,027 |  |  | 7,706 |  |
| Total | $ | 56,998 |  |  | $ | 51,557 |  |  | $ | 49,818 |  |
| Gross margin: |  |  |  |  |  |
| Americas | $ | 21,350 |  |  | $ | 19,117 |  |  | $ | 19,499 |  |
| EMEA | 10,016 |  |  | 8,969 |  |  | 8,466 |  |
| APJC | 5,424 |  |  | 5,241 |  |  | 4,949 |  |
| Segment total | 36,788 |  |  | 33,326 |  |  | 32,914 |  |
| Unallocated corporate items | (1,035) |  |  | (1,078) |  |  | (1,020) |  |
| Total | $ | 35,753 |  |  | $ | 32,248 |  |  | $ | 31,894 |  |

[0000858877-23-000023:notes:352]
Amounts may not sum due to rounding.

[0000858877-23-000023:notes:353]
Revenue in the United States was $29.9 billion, $26.7 billion, and $26.1 billion for fiscal 2023, 2022, and 2021, respectively.

[0000858877-23-000023:notes:354]
(b)Revenue for Groups of Similar Products and Services

[0000858877-23-000023:notes:355]
We design and sell IP-based networking and other products related to the communications and IT industry and provide services associated with these products and their use.

[0000858877-23-000023:notes:356]
Amounts may not sum due to rounding. We have made certain reclassifications to the amounts for prior fiscal years to conform to the current fiscal year's presentation.

[0000858877-23-000023:notes:357]
(c)Additional Segment Information

[0000858877-23-000023:notes:358]
No single customer accounted for 10% or more of revenue in fiscal 2023, 2022, and 2021.

[0000858877-23-000023:notes:359]
The majority of our assets as of July 29, 2023 and July 30, 2022 were attributable to our U.S. operations. Our long-lived assets are based on the physical location of the assets. The following table presents our long-lived assets, which consists of property and equipment, net and operating lease right-of-use assets information for geographic areas (in millions):

[0000858877-23-000023:notes:360]
|  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Long-lived assets: |  |  |  |  |  |
| United States | $ | 2,113 |  |  | $ | 2,004 |  |  | $ | 2,189 |  |
| International | 943 |  |  | 997 |  |  | 1,244 |  |
| Total | $ | 3,056 |  |  | $ | 3,001 |  |  | $ | 3,433 |  |


## us-gaap:EarningsPerShareTextBlock

[0000858877-23-000023:notes:361]
Net Income per Share 
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-23-000023:notes:362]
| Years Ended | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Net income | $ | 12,613 |  |  | $ | 11,812 |  |  | $ | 10,591 |  |
| Weighted-average shares—basic | 4,093 |  |  | 4,170 |  |  | 4,222 |  |
| Effect of dilutive potential common shares | 12 |  |  | 22 |  |  | 14 |  |
| Weighted-average shares—diluted | 4,105 |  |  | 4,192 |  |  | 4,236 |  |
| Net income per share—basic | $ | 3.08 |  |  | $ | 2.83 |  |  | $ | 2.51 |  |
| Net income per share—diluted | $ | 3.07 |  |  | $ | 2.82 |  |  | $ | 2.50 |  |
| Antidilutive employee share-based awards, excluded | 86 |  |  | 70 |  |  | 69 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000858877-23-000023:notes:363]
On June 13, 2023, Jeff Sharritts, Cisco’s Executive Vice President and Chief Customer and Partner Officer, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Mr. Sharritts’ trading plan provides for the sale of 146,825 gross shares (with any shares underlying performance-based equity awards being calculated at target), plus any related dividend-equivalent shares earned with respect to such shares and excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Mr. Sharritts’ trading plan is scheduled to terminate on June 21, 2024, subject to early termination for certain specified events set forth therein.
