# CSCO MD&A — 0000858877-23-000023


## mdna

[0000858877-23-000023:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000858877-23-000023:mdna:2]
Forward-Looking Statements

[0000858877-23-000023:mdna:3]
OVERVIEW

[0000858877-23-000023:mdna:4]
Cisco designs and sells a broad range of technologies that power the Internet. We are integrating our product portfolios across networking, security, collaboration, applications and the cloud to create highly secure, intelligent platforms for our customers’ digital businesses. These platforms are designed to help our customers manage more users, devices and things connecting to their networks. This will enable us to provide customers with a highly secure, intelligent platform for their digital business.

[0000858877-23-000023:mdna:5]
A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-23-000023:mdna:6]
|  | Three Months Ended |  | Years Ended |  |
|  | July 29, 2023 |  | July 30, 2022 |  | Variance |  | July 29, 2023 |  | July 30, 2022 |  | Variance |  |
| Revenue | $ | 15,203 |  |  | $ | 13,102 |  |  | 16 | % |  | $ | 56,998 |  |  | $ | 51,557 |  |  | 11 | % |  |
| Gross margin percentage | 64.1 | % |  | 61.3 | % |  | 2.8 |  | pts | 62.7 | % |  | 62.5 | % |  | 0.2 |  | pts |
| Research and development | $ | 1,953 |  |  | $ | 1,682 |  |  | 16 | % |  | $ | 7,551 |  |  | $ | 6,774 |  |  | 11 | % |  |
| Sales and marketing | $ | 2,579 |  |  | $ | 2,349 |  |  | 10 | % |  | $ | 9,880 |  |  | $ | 9,085 |  |  | 9 | % |  |
| General and administrative | $ | 690 |  |  | $ | 489 |  |  | 41 | % |  | $ | 2,478 |  |  | $ | 2,101 |  |  | 18 | % |  |
| Total R&D, sales and marketing, general and administrative | $ | 5,222 |  |  | $ | 4,520 |  |  | 16 | % |  | $ | 19,909 |  |  | $ | 17,960 |  |  | 11 | % |  |
| Total as a percentage of revenue | 34.3 | % |  | 34.5 | % |  | (0.2) |  | pts | 34.9 | % |  | 34.8 | % |  | 0.1 |  | pts |
| Restructuring and other charges included in operating expenses | $ | 203 |  |  | $ | (2) |  |  | NM |  | $ | 531 |  |  | $ | 6 |  |  | NM |  |
| Operating income as a percentage of revenue | 28.0 | % |  | 26.2 | % |  | 1.8 |  | pts | 26.4 | % |  | 27.1 | % |  | (0.7) |  | pts |
| Interest and other income (loss), net | $ | 218 |  |  | $ | (18) |  |  | NM |  | $ | 287 |  |  | $ | 508 |  |  | (44) | % |  |
| Income tax percentage | 11.5 | % |  | 17.6 | % |  | (6.1) |  | pts | 17.7 | % |  | 18.4 | % |  | (0.7) |  | pts |
| Net income | $ | 3,958 |  |  | $ | 2,815 |  |  | 41 | % |  | $ | 12,613 |  |  | $ | 11,812 |  |  | 7 | % |  |
| Net income as a percentage of revenue | 26.0 | % |  | 21.5 | % |  | 4.5 |  | pts | 22.1 | % |  | 22.9 | % |  | (0.8) |  | pts |
| Earnings per share—diluted | $ | 0.97 |  |  | $ | 0.68 |  |  | 43 | % |  | $ | 3.07 |  |  | $ | 2.82 |  |  | 9 | % |  |

[0000858877-23-000023:mdna:7]
Percentages may not recalculate due to rounding.

[0000858877-23-000023:mdna:8]
NM — Not meaningful

[0000858877-23-000023:mdna:9]
Fiscal 2023 Compared with Fiscal 2022

[0000858877-23-000023:mdna:10]
In fiscal 2023, we delivered strong results with growth in revenue and profitability. We remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformations. In past periods, we took multiple actions in order to mitigate component shortages and address supply constraints seen industry-wide. During fiscal 2023, we saw an overall improvement of supply constraints and, as a result, we were able to increase the delivery of products to our customers, which positively impacted product revenue. Further, we continued to make progress in the transition of our business model delivering increased software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-23-000023:mdna:11]
Total revenue increased by 11% compared with fiscal 2022. Within total revenue, product revenue increased by 13% and service revenue increased by 2%. In fiscal 2023, total software revenue was $17.0 billion across all product areas and service, an increase of 12%. Within total software revenue, subscription revenue increased 16%. Although product revenue increased, we saw a decline in product demand in fiscal 2023. We believe this was due to customers absorbing recently shipped products, adjusting to significant reductions in product lead times, and macroeconomic conditions.

[0000858877-23-000023:mdna:12]
Total gross margin increased by 0.2 percentage points. Product gross margin increased by 0.5 percentage points, largely driven by favorable pricing and favorable product mix partially offset by negative impacts from productivity. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 0.1 percentage points. Operating income as a percentage of revenue decreased by 0.7 percentage points driven primarily by restructuring and other charges of $531 million in fiscal 2023. Diluted earnings per share increased by 9%, driven by an increase of 7% in net income and a decrease in diluted share count of 87 million shares.

[0000858877-23-000023:mdna:13]
In terms of our geographic segments, revenue from the Americas increased by $3.6 billion, EMEA revenue increased by $1.4 billion and revenue in our APJC segment increased by $0.4 billion. We experienced product revenue growth across each of our customer markets. From a product category perspective, total product revenue increased 13% year over year, driven by growth in revenue in Secure, Agile Networks of 22%; Internet for the Future of 1%; End-to-End Security of 4% and Optimized Application Experiences of 11%; partially offset by a product revenue decline in Collaboration of 9%.

[0000858877-23-000023:mdna:14]
33

[0000858877-23-000023:mdna:15]
Fourth Quarter Snapshot

[0000858877-23-000023:mdna:16]
For the fourth quarter of fiscal 2023, as compared with the fourth quarter of fiscal 2022, total revenue increased by 16%. Within total revenue, product revenue increased by 20% and service revenue increased by 4%. With regard to our geographic segment performance, on a year-over-year basis, revenue in Americas increased by 21%, EMEA increased by 10% and APJC by 7%. From a product category perspective, we experienced product revenue growth in Secure, Agile Networks; Internet for the Future and Optimized Application Experiences; partially offset by a decline in Collaboration. Product revenue in End-to-End Security was flat. Total gross margin increased by 2.8 percentage points, driven by favorable pricing, favorable product mix and productivity benefits driven by lower freight and logistics costs, component and other costs. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 0.2 percentage points. Operating income as a percentage of revenue increased by 1.8 percentage points. Diluted earnings per share increased by 43%, driven by an increase in net income of 41% and a decrease in diluted share count of 44 million shares.

[0000858877-23-000023:mdna:17]
Strategy and Priorities

[0000858877-23-000023:mdna:18]
As our customers add billions of new connections to their enterprises, and as more applications move to a multicloud environment, the network becomes even more critical. Our customers are navigating change at an unprecedented pace. In this dynamic environment, we believe their priorities are to transform infrastructure, secure the enterprise, power hybrid work, reimagine applications, and drive toward sustainability.

[0000858877-23-000023:mdna:19]
Our strategy is to securely connect everything. We are committed to driving a trusted customer experience, through our innovation, solutions, choice, and people.

[0000858877-23-000023:mdna:20]
For a full discussion of our strategy and priorities, see “Item 1. Business.”

[0000858877-23-000023:mdna:21]
Other Key Financial Measures

[0000858877-23-000023:mdna:22]
The following is a summary of our other key financial measures for fiscal 2023 compared with fiscal 2022 (in millions):

[0000858877-23-000023:mdna:23]
|  |  | Fiscal 2023 |  | Fiscal 2022 |
| Cash and cash equivalents and investments |  | $26,146 |  | $19,267 |
| Cash provided by operating activities |  | $19,886 |  | $13,226 |
| Remaining performance obligations |  | $34,868 |  | $31,539 |
| Repurchases of common stock—stock repurchase program |  | $4,271 |  | $7,734 |
| Dividends paid |  | $6,302 |  | $6,224 |
| Inventories |  | $3,644 |  | $2,568 |

[0000858877-23-000023:mdna:24]
CRITICAL ACCOUNTING ESTIMATES

[0000858877-23-000023:mdna:25]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-23-000023:mdna:26]
Revenue Recognition

[0000858877-23-000023:mdna:27]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis.

[0000858877-23-000023:mdna:28]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-23-000023:mdna:29]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-23-000023:mdna:30]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable. If actual credits received by distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-23-000023:mdna:31]
See Note 3 to the Consolidated Financial Statements for more details.

[0000858877-23-000023:mdna:32]
Inventory Valuation and Liability for Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-23-000023:mdna:33]
Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and net realizable value, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At

[0000858877-23-000023:mdna:34]
the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-23-000023:mdna:35]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.

[0000858877-23-000023:mdna:36]
Our provision for inventory was $307 million, $102 million, and $116 million in fiscal 2023, 2022, and 2021, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $423 million, $227 million, and $76 million in fiscal 2023, 2022, and 2021, respectively. If there were to be a sudden and significant decrease in demand for our products, if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, or if supply constraints were to continue, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs, and the adequacy of our liability for purchase commitments. For further discussion around the Supply Constraints Impacts and Risks, see “—Results of Operations—Gross Margin—Supply Constraints Impacts and Risks” and “—Liquidity and Capital Resources—Inventory Supply Chain.”

[0000858877-23-000023:mdna:37]
Loss Contingencies

[0000858877-23-000023:mdna:38]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-23-000023:mdna:39]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-23-000023:mdna:40]
Goodwill and Purchased Intangible Asset Impairments

[0000858877-23-000023:mdna:41]
Our methodology for allocating the purchase price relating to purchase acquisitions is determined through established valuation techniques. Goodwill represents a residual value as of the acquisition date, which in most cases results in measuring goodwill as an excess of the purchase consideration transferred plus the fair value of any noncontrolling interest in the acquired company over the fair value of net assets acquired, including contingent consideration. We perform goodwill impairment tests on an annual basis in the fourth fiscal quarter and between annual tests in certain circumstances for each reporting unit. The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the new accounting guidance for the fair value measurement of nonfinancial assets.

[0000858877-23-000023:mdna:42]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in fiscal 2023, 2022, and 2021. For the annual impairment testing in fiscal 2023, the excess of the fair value over the carrying value for each of our reporting units was $61.3 billion for the Americas, $73.8 billion for EMEA, and $34.3 billion for APJC.

[0000858877-23-000023:mdna:43]
During the fourth quarter of fiscal 2023, we performed a sensitivity analysis for goodwill impairment with respect to each of our respective reporting units and determined that a hypothetical 10% decline in the fair value of each reporting unit would not result in an impairment of goodwill for any reporting unit.

[0000858877-23-000023:mdna:44]
The fair value of acquired technology and patents, as well as acquired technology under development, is determined at acquisition date primarily using the income approach, which discounts expected future cash flows to present value. The discount rates used in the present value calculations are typically derived from a weighted-average cost of capital analysis and then adjusted to reflect risks inherent in the development lifecycle as appropriate. We consider the pricing model for products related to these acquisitions to be standard within the high-technology communications industry, and the applicable discount rates represent the rates that market participants would use for valuation of such intangible assets.

[0000858877-23-000023:mdna:45]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured

[0000858877-23-000023:mdna:46]
by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. Our ongoing consideration of all the factors described previously could result in impairment charges in the future, which could adversely affect our net income.

[0000858877-23-000023:mdna:47]
Income Taxes

[0000858877-23-000023:mdna:48]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was 17.7%, 18.4%, and 20.1% in fiscal 2023, 2022, and 2021, respectively.

[0000858877-23-000023:mdna:49]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.

[0000858877-23-000023:mdna:50]
Significant judgment is also required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000858877-23-000023:mdna:51]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to foreign-derived intangible income deduction, global intangible low-tax income and base erosion and anti-abuse tax laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The OECD, an international association comprised of 38 countries, including the United States, has made changes and is contemplating additional changes to numerous long-standing tax principles. There can be no assurance that these changes and any contemplated changes if finalized, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries was subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the IRS and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-23-000023:mdna:52]
37

[0000858877-23-000023:mdna:53]
RESULTS OF OPERATIONS

[0000858877-23-000023:mdna:54]
A discussion regarding our financial condition and results of operations for fiscal 2023 compared to fiscal 2022 is presented below. A discussion regarding our financial condition and results of operations for fiscal 2022 compared to fiscal 2021 can be found under Item 7 in our Annual Report on Form 10-K for the fiscal year ended July 30, 2022, filed with the SEC on September 8, 2022.

[0000858877-23-000023:mdna:55]
Revenue

[0000858877-23-000023:mdna:56]
The following table presents the breakdown of revenue between product and service (in millions, except percentages):

[0000858877-23-000023:mdna:57]
|  |  | Years Ended |  | 2023 vs. 2022 |
|  |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 43,142 |  |  | $ | 38,018 |  |  | $ | 36,014 |  |  | $ | 5,124 |  |  | 13 | % |
| Percentage of revenue |  | 75.7 | % |  | 73.7 | % |  | 72.3 | % |  |  |  |  |
| Service |  | 13,856 |  |  | 13,539 |  |  | 13,804 |  |  | 317 |  |  | 2 | % |
| Percentage of revenue |  | 24.3 | % |  | 26.3 | % |  | 27.7 | % |  |  |  |  |
| Total |  | $ | 56,998 |  |  | $ | 51,557 |  |  | $ | 49,818 |  |  | $ | 5,441 |  |  | 11 | % |

[0000858877-23-000023:mdna:58]
We manage our business primarily on a geographic basis, organized into three geographic segments. Our revenue, which includes product and service for each segment, is summarized in the following table (in millions, except percentages):

[0000858877-23-000023:mdna:59]
|  |  | Years Ended |  | 2023 vs. 2022 |
|  |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 33,447 |  |  | $ | 29,814 |  |  | $ | 29,161 |  |  | $ | 3,633 |  |  | 12 | % |
| Percentage of revenue |  | 58.7 | % |  | 57.8 | % |  | 58.5 | % |  |  |  |  |
| EMEA |  | 15,135 |  |  | 13,715 |  |  | 12,951 |  |  | 1,420 |  |  | 10 | % |
| Percentage of revenue |  | 26.6 | % |  | 26.6 | % |  | 26.0 | % |  |  |  |  |
| APJC |  | 8,417 |  |  | 8,027 |  |  | 7,706 |  |  | 390 |  |  | 5 | % |
| Percentage of revenue |  | 14.8 | % |  | 15.6 | % |  | 15.5 | % |  |  |  |  |
| Total |  | $ | 56,998 |  |  | $ | 51,557 |  |  | $ | 49,818 |  |  | $ | 5,441 |  |  | 11 | % |

[0000858877-23-000023:mdna:60]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-23-000023:mdna:61]
Total revenue in fiscal 2023 increased by 11% compared with fiscal 2022. Product revenue increased by 13% and service revenue increased by 2%. Our total revenue reflected growth across each of our geographic segments.

[0000858877-23-000023:mdna:62]
In addition to the impact of macroeconomic factors, including the IT spending environment and the level of spending by government entities, revenue by segment in a particular period may be significantly impacted by the timing of revenue recognition for complex transactions with multiple performance obligations. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment.

[0000858877-23-000023:mdna:63]
Product Revenue by Segment

[0000858877-23-000023:mdna:64]
The following table presents the breakdown of product revenue by segment (in millions, except percentages):

[0000858877-23-000023:mdna:65]
|  |  | Years Ended |  | 2023 vs. 2022 |
|  |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 25,019 |  |  | $ | 21,620 |  |  | $ | 20,688 |  |  | $ | 3,399 |  |  | 16 | % |
| Percentage of product revenue |  | 58.0 | % |  | 56.9 | % |  | 57.5 | % |  |  |  |  |
| EMEA |  | 11,866 |  |  | 10,545 |  |  | 9,805 |  |  | 1,321 |  |  | 13 | % |
| Percentage of product revenue |  | 27.5 | % |  | 27.7 | % |  | 27.2 | % |  |  |  |  |
| APJC |  | 6,257 |  |  | 5,854 |  |  | 5,521 |  |  | 403 |  |  | 7 | % |
| Percentage of product revenue |  | 14.5 | % |  | 15.4 | % |  | 15.3 | % |  |  |  |  |
| Total |  | $ | 43,142 |  |  | $ | 38,018 |  |  | $ | 36,014 |  |  | $ | 5,124 |  |  | 13 | % |

[0000858877-23-000023:mdna:66]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-23-000023:mdna:67]
Americas

[0000858877-23-000023:mdna:68]
Product revenue in the Americas segment increased by 16%. The product revenue increase was driven by growth across all customer markets. From a country perspective, product revenue increased by 15% in the United States, 10% in Canada, 31% in Mexico and 25% in Brazil.

[0000858877-23-000023:mdna:69]
EMEA

[0000858877-23-000023:mdna:70]
The increase in product revenue in the EMEA segment of 13% was driven by growth in the public sector, enterprise and commercial markets, partially offset by a decline in the service provider market. From a country perspective, product revenue increased by 16% in Germany, 4% in the United Kingdom and 19% in France.

[0000858877-23-000023:mdna:71]
APJC

[0000858877-23-000023:mdna:72]
Product revenue in the APJC segment increased by 7%, driven by growth in the commercial and public sector markets, partially offset by a decline in the service provider market. Product revenue in the enterprise market was flat. From a country perspective, product revenue increased by 62% in India, 13% in Australia and 8% in China, partially offset by a decline of 6% in Japan.

[0000858877-23-000023:mdna:73]
Product Revenue by Category

[0000858877-23-000023:mdna:74]
In addition to the primary view on a geographic basis, we also prepare financial information related to product categories and customer markets for various purposes.

[0000858877-23-000023:mdna:75]
The following table presents product revenue by category (in millions, except percentages):

[0000858877-23-000023:mdna:76]
|  |  | Years Ended |  | 2023 vs. 2022 |
|  |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |
| Secure, Agile Networks |  | $ | 29,105 |  |  | $ | 23,831 |  |  | $ | 22,725 |  |  | $ | 5,274 |  |  | 22 | % |
| Internet for the Future |  | 5,306 |  |  | 5,276 |  |  | 4,511 |  |  | 30 |  |  | 1 | % |
| Collaboration |  | 4,052 |  |  | 4,472 |  |  | 4,727 |  |  | (420) |  |  | (9) | % |
| End-to-End Security |  | 3,859 |  |  | 3,699 |  |  | 3,382 |  |  | 160 |  |  | 4 | % |
| Optimized Application Experiences |  | 811 |  |  | 729 |  |  | 654 |  |  | 82 |  |  | 11 | % |
| Other Products |  | 9 |  |  | 11 |  |  | 15 |  |  | (2) |  |  | (15) | % |
| Total |  | $ | 43,142 |  |  | $ | 38,018 |  |  | $ | 36,014 |  |  | $ | 5,124 |  |  | 13 | % |

[0000858877-23-000023:mdna:77]
Amounts may not sum and percentages may not recalculate due to rounding. Amounts for prior fiscal years have been reclassified to conform to the current fiscal year’s presentation.

[0000858877-23-000023:mdna:78]
Secure, Agile Networks

[0000858877-23-000023:mdna:79]
The Secure, Agile Networks product category represents our core networking offerings related to switching, enterprise routing, wireless, and compute. Secure, Agile Networks revenue increased by 22%, or $5.3 billion, with growth across the portfolio except servers. Revenue grew in both campus switching and data center switching. This was primarily driven by strong growth in our Catalyst 9000 series, Nexus 9000 series and Meraki switching offerings. The increase in enterprise routing was primarily driven by growth in our Catalyst 8000 routers, SD-WAN and IoT routing offerings. Wireless had strong double-digit growth driven by our WiFi-6 products and Meraki offerings.

[0000858877-23-000023:mdna:80]
Internet for the Future

[0000858877-23-000023:mdna:81]
The Internet for the Future product category includes our routed optical networking, 5G, silicon and optics solutions. Revenue in our Internet for the Future product category increased by 1%, or $30 million, primarily driven by growth in our Core routing portfolio, including our Cisco 8000 series offerings. We also saw double-digit growth in the webscale provider market.

[0000858877-23-000023:mdna:82]
Collaboration

[0000858877-23-000023:mdna:83]
The Collaboration product category consists of our Meetings, Collaboration Devices, Calling, Contact Center and CPaaS offerings. Revenue in our Collaboration product category decreased 9%, or $420 million, primarily driven by declines in Collaboration Devices and Meetings, partially offset by growth in our Calling and Contact Center offerings.

[0000858877-23-000023:mdna:84]
End-to-End Security

[0000858877-23-000023:mdna:85]
Revenue in our End-to-End Security product category increased by 4%, or $160 million, primarily driven by growth in our Unified Threat Management offerings and Zero Trust portfolio.

[0000858877-23-000023:mdna:86]
Optimized Application Experiences

[0000858877-23-000023:mdna:87]
The Optimized Application Experiences product category consists of our full stack observability and network assurance offerings. Revenue in our Optimized Application Experiences product category increased 11%, or $82 million, driven by growth across the portfolio, including double-digit growth in our ThousandEyes offerings.

[0000858877-23-000023:mdna:88]
Service Revenue by Segment

[0000858877-23-000023:mdna:89]
The following table presents the breakdown of service revenue by segment (in millions, except percentages):

[0000858877-23-000023:mdna:90]
|  | Years Ended |  | 2023 vs. 2022 |
|  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |  | Variance in Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 8,427 |  |  | $ | 8,194 |  |  | $ | 8,472 |  |  | $ | 233 |  |  | 3 | % |
| Percentage of service revenue | 60.8 | % |  | 60.5 | % |  | 61.4 | % |  |  |  |  |
| EMEA | 3,269 |  |  | 3,171 |  |  | 3,146 |  |  | 98 |  |  | 3 | % |
| Percentage of service revenue | 23.6 | % |  | 23.4 | % |  | 22.8 | % |  |  |  |  |
| APJC | 2,160 |  |  | 2,173 |  |  | 2,186 |  |  | (13) |  |  | (1) | % |
| Percentage of service revenue | 15.6 | % |  | 16.0 | % |  | 15.8 | % |  |  |  |  |
| Total | $ | 13,856 |  |  | $ | 13,539 |  |  | $ | 13,804 |  |  | $ | 317 |  |  | 2 | % |

[0000858877-23-000023:mdna:91]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-23-000023:mdna:92]
Service revenue increased 2%, driven by growth in our solution support and maintenance business offerings, partially offset by declines in our advisory services and software support offerings. Service revenue increased in the Americas and EMEA segments, partially offset by a decline in the APJC segment.

[0000858877-23-000023:mdna:93]
Gross Margin

[0000858877-23-000023:mdna:94]
The following table presents the gross margin for products and services (in millions, except percentages):

[0000858877-23-000023:mdna:95]
|  | AMOUNT |  | PERCENTAGE |
| Years Ended | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 26,552 |  |  | $ | 23,204 |  |  | $ | 22,714 |  |  | 61.5 | % |  | 61.0 | % |  | 63.1 | % |
| Service | 9,201 |  |  | 9,044 |  |  | 9,180 |  |  | 66.4 | % |  | 66.8 | % |  | 66.5 | % |
| Total | $ | 35,753 |  |  | $ | 32,248 |  |  | $ | 31,894 |  |  | 62.7 | % |  | 62.5 | % |  | 64.0 | % |

[0000858877-23-000023:mdna:96]
Product Gross Margin

[0000858877-23-000023:mdna:97]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2022 to fiscal 2023:

[0000858877-23-000023:mdna:98]
|  |  | Product Gross Margin Percentage |
| Fiscal 2022 |  | 61.0 | % |
| Productivity (1) |  | (2.5) | % |
| Product pricing |  | 1.7 | % |
| Mix of products sold |  | 0.8 | % |
| Others |  | 0.5 | % |
| Fiscal 2023 |  | 61.5 | % |

[0000858877-23-000023:mdna:99]
(1) Productivity includes overall manufacturing-related costs, such as component costs, warranty expense, provision for inventory, freight, logistics, shipment volume, and other items not categorized elsewhere.

[0000858877-23-000023:mdna:100]
Product gross margin increased by 0.5 percentage points primarily driven by favorable pricing and product mix. The favorable pricing was primarily driven by price increases implemented during fiscal 2022 and were recognized as we ship our products. This was partially offset by negative impacts from productivity, largely driven by increased costs from component and other costs, partially offset by lower freight and logistics costs. We implemented the price increases to partially offset increases in commodity and other costs.

[0000858877-23-000023:mdna:101]
41

[0000858877-23-000023:mdna:102]
Supply Constraints Impacts and Risks

[0000858877-23-000023:mdna:103]
During fiscal 2023, we saw an overall improvement of supply constraints which have persisted industry-wide for multiple periods. In past periods, we took multiple actions in order to mitigate component shortages and address significant supply constraints. These supply constraints resulted in significant increased costs (i.e., component and other commodity costs, expedite fees, etc.) which had, and may continue to have, a negative impact on our product gross margin and resulted in extended lead times for us and our customers. The mitigating actions we took included: partnering with several of our key suppliers utilizing our volume purchasing ability and extending supply coverage, including, in certain cases, revising supplier arrangements; paying and committing to pay in the future significantly higher costs for certain components; modifying our product designs in order to leverage alternate suppliers, where possible; and continually optimizing our inventory build and customer delivery plans, among others. These mitigating actions have resulted in increased inventory balances, inventory purchase commitments, and inventory deposits and prepayments compared to prior fiscal years, which, in turn, has increased our supply chain exposure, which could result in negative impacts to our product gross margin in future periods, including material excess and obsolete charges, if product demand significantly decreases for a sustained duration or we are unable to continue to mitigate the remaining supply chain exposures. We believe these mitigating actions have helped us to optimize our access to critical components and meet customer demand for our products as a result of the component shortages and significant supply constraints we saw in past periods. While these mitigating actions have resulted in a decrease of our overall supply chain balances during fiscal 2023, these balances continue to be higher as compared to prior fiscal years.

[0000858877-23-000023:mdna:104]
Service Gross Margin

[0000858877-23-000023:mdna:105]
Our service gross margin percentage decreased by 0.4 percentage points primarily due to higher headcount-related and delivery costs, partially offset by higher sales volume and favorable mix of service offerings.

[0000858877-23-000023:mdna:106]
Our service gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-23-000023:mdna:107]
Gross Margin by Segment

[0000858877-23-000023:mdna:108]
The following table presents the total gross margin for each segment (in millions, except percentages):

[0000858877-23-000023:mdna:109]
|  |  | AMOUNT |  | PERCENTAGE |
| Years Ended |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 21,350 |  |  | $ | 19,117 |  |  | $ | 19,499 |  |  | 63.8 | % |  | 64.1 | % |  | 66.9 | % |
| EMEA |  | 10,016 |  |  | 8,969 |  |  | 8,466 |  |  | 66.2 | % |  | 65.4 | % |  | 65.4 | % |
| APJC |  | 5,424 |  |  | 5,241 |  |  | 4,949 |  |  | 64.4 | % |  | 65.3 | % |  | 64.2 | % |
| Segment total |  | 36,788 |  |  | 33,326 |  |  | 32,914 |  |  | 64.5 | % |  | 64.6 | % |  | 66.1 | % |
| Unallocated corporate items (1) |  | (1,035) |  |  | (1,078) |  |  | (1,020) |  |  |  |  |  |  |  |
| Total |  | $ | 35,753 |  |  | $ | 32,248 |  |  | $ | 31,894 |  |  | 62.7 | % |  | 62.5 | % |  | 64.0 | % |

[0000858877-23-000023:mdna:110]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-23-000023:mdna:111]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-23-000023:mdna:112]
We experienced a gross margin percentage decrease in our Americas segment due to negative impacts from productivity, partially offset by favorable pricing and favorable product mix.

[0000858877-23-000023:mdna:113]
Gross margin in our EMEA segment increased due to favorable pricing, and to a lesser extent, favorable product mix, partially offset by negative impacts from productivity.

[0000858877-23-000023:mdna:114]
The APJC segment gross margin percentage decrease was due to negative impacts from productivity and pricing erosion, partially offset by favorable product mix and higher service gross margin.

[0000858877-23-000023:mdna:115]
Research and Development (“R&D”), Sales and Marketing, and General and Administrative (“G&A”) Expenses

[0000858877-23-000023:mdna:116]
R&D, sales and marketing, and G&A expenses are summarized in the following table (in millions, except percentages):

[0000858877-23-000023:mdna:117]
|  |  | Years Ended |  | 2023 vs. 2022 |
|  |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |  | Variance in Dollars |  | Variance in Percent |
| Research and development |  | $ | 7,551 |  |  | $ | 6,774 |  |  | $ | 6,549 |  |  | $ | 777 |  |  | 11 | % |
| Percentage of revenue |  | 13.2 | % |  | 13.1 | % |  | 13.1 | % |  |  |  |  |
| Sales and marketing |  | 9,880 |  |  | 9,085 |  |  | 9,259 |  |  | 795 |  |  | 9 | % |
| Percentage of revenue |  | 17.3 | % |  | 17.6 | % |  | 18.6 | % |  |  |  |  |
| General and administrative |  | 2,478 |  |  | 2,101 |  |  | 2,152 |  |  | 377 |  |  | 18 | % |
| Percentage of revenue |  | 4.3 | % |  | 4.1 | % |  | 4.3 | % |  |  |  |  |
| Total |  | $ | 19,909 |  |  | $ | 17,960 |  |  | $ | 17,960 |  |  | $ | 1,949 |  |  | 11 | % |
| Percentage of revenue |  | 34.9 | % |  | 34.8 | % |  | 36.1 | % |  |  |  |  |

[0000858877-23-000023:mdna:118]
R&D Expenses

[0000858877-23-000023:mdna:119]
R&D expenses increased due to higher headcount-related expenses, higher share-based compensation expense and higher discretionary spending, partially offset by lower contracted services spending and lower acquisitions and divestitures related costs.

[0000858877-23-000023:mdna:120]
We continue to invest in R&D in order to bring a broad range of products to market in a timely fashion. If we believe that we are unable to enter a particular market in a timely manner with internally developed products, we may purchase or license technology from other businesses, or we may partner with or acquire businesses as an alternative to internal R&D.

[0000858877-23-000023:mdna:121]
Sales and Marketing Expenses

[0000858877-23-000023:mdna:122]
Sales and marketing expenses increased primarily due to higher headcount-related expenses, higher discretionary spending and higher share-based compensation expense, partially offset by the absence of certain non-recurring charges recognized due to the Russia and Ukraine war in fiscal 2022 and lower contracted services spending.

[0000858877-23-000023:mdna:123]
G&A Expenses

[0000858877-23-000023:mdna:124]
G&A expenses increased due to higher headcount-related expenses, higher discretionary spending and higher share-based compensation expense, partially offset by the absence of certain non-recurring charges recognized due to the Russia and Ukraine war in fiscal 2022 and lower acquisition and divestitures related costs.

[0000858877-23-000023:mdna:125]
Effect of Foreign Currency

[0000858877-23-000023:mdna:126]
In fiscal 2023, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $364 million, or 2.0%, compared with fiscal 2022.

[0000858877-23-000023:mdna:127]
Amortization of Purchased Intangible Assets

[0000858877-23-000023:mdna:128]
The following table presents the amortization of purchased intangible assets including impairment charges (in millions):

[0000858877-23-000023:mdna:129]
| Years Ended |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 649 |  |  | $ | 749 |  |  | $ | 716 |  |
| Operating expenses |  | 282 |  |  | 328 |  |  | 215 |  |
| Total |  | $ | 931 |  |  | $ | 1,077 |  |  | $ | 931 |  |

[0000858877-23-000023:mdna:130]
The decrease in amortization of purchased intangible assets was primarily due to certain purchased intangible assets that became fully amortized, partially offset by amortization of purchased intangibles from our recent acquisitions.

[0000858877-23-000023:mdna:131]
43

[0000858877-23-000023:mdna:132]
Restructuring and Other Charges

[0000858877-23-000023:mdna:133]
The following table presents restructuring and other charges (in millions):

[0000858877-23-000023:mdna:134]
| Years Ended |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Restructuring and other charges included in operating expenses |  | $ | 531 |  |  | $ | 6 |  |  | $ | 886 |  |

[0000858877-23-000023:mdna:135]
In the second quarter of fiscal 2023, we announced a restructuring plan in order to rebalance the organization and enable further investment in key priority areas, of which approximately 5% of the global workforce would be impacted. The total pretax charges are estimated to be approximately $700 million. In connection with this restructuring plan, we incurred charges of $535 million during fiscal 2023. We expect the plan to be substantially completed by the end of the first quarter of fiscal 2024. We expect to reinvest substantially all of the costs savings from this restructuring plan in our key priority areas. As a result, the overall cost savings from this restructuring plan are not expected to be material for future periods.

[0000858877-23-000023:mdna:136]
Operating Income

[0000858877-23-000023:mdna:137]
The following table presents our operating income and our operating income as a percentage of revenue (in millions, except percentages):

[0000858877-23-000023:mdna:138]
| Years Ended |  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Operating income |  | $ | 15,031 |  |  | $ | 13,969 |  |  | $ | 12,833 |  |
| Operating income as a percentage of revenue |  | 26.4 | % |  | 27.1 | % |  | 25.8 | % |

[0000858877-23-000023:mdna:139]
Operating income increased by 8%, and as a percentage of revenue operating income decreased by 0.7 percentage points. The increase in operating income was primarily due to a revenue increase and a gross margin percentage increase (driven by favorable pricing and favorable product mix, partially offset by negative impacts from productivity), partially offset by higher operating expenses. The decrease in operating income as a percentage of revenue was primarily due to an operating expenses percentage increase.

[0000858877-23-000023:mdna:140]
Interest and Other Income (Loss), Net

[0000858877-23-000023:mdna:141]
Interest Income (Expense), Net   The following table summarizes interest income and interest expense (in millions):

[0000858877-23-000023:mdna:142]
|  | Years Ended |  | 2023 vs. 2022 |
|  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |  | Variance in Dollars |
| Interest income | $ | 962 |  |  | $ | 476 |  |  | $ | 618 |  |  | $ | 486 |  |
| Interest expense | (427) |  |  | (360) |  |  | (434) |  |  | (67) |  |
| Interest income (expense), net | $ | 535 |  |  | $ | 116 |  |  | $ | 184 |  |  | $ | 419 |  |

[0000858877-23-000023:mdna:143]
Interest income increased driven by higher average balance of cash and available-for-sale debt investments and higher interest rates. The increase in interest expense was driven by higher interest rates, partially offset by a lower average debt balance.

[0000858877-23-000023:mdna:144]
Other Income (Loss), Net   The components of other income (loss), net, are summarized as follows (in millions):

[0000858877-23-000023:mdna:145]
|  | Years Ended |  | 2023 vs. 2022 |
|  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |
| Available-for-sale debt investments | $ | (21) |  |  | $ | 9 |  |  | $ | 53 |  |  | $ | (30) |  |
| Marketable equity investments | 37 |  |  | (38) |  |  | 6 |  |  | 75 |  |
| Privately held investments | (193) |  |  | 486 |  |  | 266 |  |  | (679) |  |
| Net gains (losses) on investments | (177) |  |  | 457 |  |  | 325 |  |  | (634) |  |
| Other gains (losses), net | (71) |  |  | (65) |  |  | (80) |  |  | (6) |  |
| Other income (loss), net | $ | (248) |  |  | $ | 392 |  |  | $ | 245 |  |  | $ | (640) |  |

[0000858877-23-000023:mdna:146]
The decrease in our other income (loss), net was primarily driven by realized and unrealized losses and impairment charges on our privately held investments and changes in net gains (losses) on our available-for-sale debt investments and marketable equity investments.

[0000858877-23-000023:mdna:147]
Provision for Income Taxes

[0000858877-23-000023:mdna:148]
The provision for income taxes resulted in an effective tax rate of 17.7% for fiscal 2023, compared with 18.4% for fiscal 2022. The net 0.7 percentage points decrease in the effective tax rate was primarily due to an increase in U.S. foreign-derived intangible income deduction benefit driven by the capitalization and amortization of R&D expenses effective for fiscal 2023 as required by the Tax Cuts and Jobs Act (“the Tax Act”) partially offset by a decrease in the U.S. federal research tax credit and stock compensation windfall benefit.

[0000858877-23-000023:mdna:149]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 21% and for further explanation of our provision for income taxes, see Note 18 to the Consolidated Financial Statements.

[0000858877-23-000023:mdna:150]
45

[0000858877-23-000023:mdna:151]
LIQUIDITY AND CAPITAL RESOURCES

[0000858877-23-000023:mdna:152]
The following sections discuss the effects of changes in our balance sheet, our capital allocation strategy including stock repurchase program and dividends, our contractual obligations, and certain other commitments and activities on our liquidity and capital resources.

[0000858877-23-000023:mdna:153]
Balance Sheet and Cash Flows

[0000858877-23-000023:mdna:154]
Cash and Cash Equivalents and Investments  The following table summarizes our cash and cash equivalents and investments (in millions):

[0000858877-23-000023:mdna:155]
|  | July 29, 2023 |  | July 30, 2022 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 10,123 |  |  | $ | 7,079 |  |  | $ | 3,044 |  |
| Available-for-sale debt investments | 15,592 |  |  | 11,947 |  |  | 3,645 |  |
| Marketable equity securities | 431 |  |  | 241 |  |  | 190 |  |
| Total | $ | 26,146 |  |  | $ | 19,267 |  |  | $ | 6,879 |  |

[0000858877-23-000023:mdna:156]
The net increase in cash and cash equivalents and investments from fiscal 2022 to fiscal 2023 was primarily driven by cash provided by operating activities of $19.9 billion. This source of cash was partially offset by cash returned to stockholders in the form of cash dividends of $6.3 billion and repurchases of common stock of $4.3 billion under the stock repurchase program, a net decrease in debt of $1.1 billion, capital expenditures of $0.8 billion and net cash paid for acquisitions and divestitures of $0.3 billion.

[0000858877-23-000023:mdna:157]
In February 2023, an IRS announcement related to the California floods (IR-2023-33) deferred our remaining fiscal 2023 U.S. federal income tax payment deadlines until October 2023. Beginning in fiscal 2023, we were required to capitalize and amortize R&D expenses as required by the Tax Act. This change would have resulted in significantly higher cash paid for income taxes during fiscal 2023 absent the payment deferral. As of July 29, 2023, we have deferred approximately $2.8 billion of federal tax payments. Our cash paid for income taxes for the first quarter of fiscal 2024 will significantly increase as a result of these deferred federal tax payments.

[0000858877-23-000023:mdna:158]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our available-for-sale debt investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-23-000023:mdna:159]
Securities Lending  We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of July 29, 2023 and July 30, 2022, we had no outstanding securities lending transactions.

[0000858877-23-000023:mdna:160]
Free Cash Flow and Capital Allocation  As part of our capital allocation strategy, we target to return a minimum of 50% of our free cash flow annually to our stockholders through cash dividends and repurchases of common stock.

[0000858877-23-000023:mdna:161]
We define free cash flow as net cash provided by operating activities less cash used to acquire property and equipment. The following table reconciles our net cash provided by operating activities to free cash flow (in millions):

[0000858877-23-000023:mdna:162]
| Years Ended | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |
| Net cash provided by operating activities | $ | 19,886 |  |  | $ | 13,226 |  |  | $ | 15,454 |  |
| Acquisition of property and equipment | (849) |  |  | (477) |  |  | (692) |  |
| Free cash flow | $ | 19,037 |  |  | $ | 12,749 |  |  | $ | 14,762 |  |

[0000858877-23-000023:mdna:163]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment

[0000858877-23-000023:mdna:164]
linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue and the timing and amount of tax and other payments. For additional discussion, see “Part I, Item 1A. Risk Factors” in this report.

[0000858877-23-000023:mdna:165]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to stockholders in the form of dividends and stock repurchases. We further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness. Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net cash provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-23-000023:mdna:166]
The following table summarizes the dividends paid and stock repurchases (in millions, except per-share amounts):

[0000858877-23-000023:mdna:167]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  | TOTAL |
| Years Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | Amount |
| July 29, 2023 |  | $ | 1.54 |  |  | $ | 6,302 |  |  | 88 |  |  | $ | 48.49 |  |  | $ | 4,271 |  |  | $ | 10,573 |  |
| July 30, 2022 |  | $ | 1.50 |  |  | $ | 6,224 |  |  | 146 |  |  | $ | 52.82 |  |  | $ | 7,734 |  |  | $ | 13,958 |  |
| July 31, 2021 |  | $ | 1.46 |  |  | $ | 6,163 |  |  | 64 |  |  | $ | 45.48 |  |  | $ | 2,902 |  |  | $ | 9,065 |  |

[0000858877-23-000023:mdna:168]
On August 16, 2023, our Board of Directors declared a quarterly dividend of $0.39 per common share to be paid on October 25, 2023, to all stockholders of record as of the close of business on October 4, 2023. Any future dividends are subject to the approval of our Board of Directors.

[0000858877-23-000023:mdna:169]
The remaining authorized amount for stock repurchases under this program is approximately $10.9 billion, with no termination date.

[0000858877-23-000023:mdna:170]
Accounts Receivable, Net  The following table summarizes our accounts receivable, net (in millions):

[0000858877-23-000023:mdna:171]
|  | July 29, 2023 |  | July 30, 2022 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,854 |  |  | $ | 6,622 |  |  | $ | (768) |  |

[0000858877-23-000023:mdna:172]
Our accounts receivable net, as of July 29, 2023 decreased by approximately 12% compared with the end of fiscal 2022, primarily due to timing and amount of product and service billings at the end of fiscal 2023 compared with the end of fiscal 2022.

[0000858877-23-000023:mdna:173]
Inventory Supply Chain  The following table summarizes our inventories and inventory purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-23-000023:mdna:174]
|  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |  | Variance vs. July 30, 2022 |  | Variance vs. July 31, 2021 |
| Inventories | $ | 3,644 |  |  | $ | 2,568 |  |  | $ | 1,559 |  |  | $ | 1,076 |  |  | $ | 2,085 |  |
| Inventory purchase commitments | $ | 7,253 |  |  | $ | 12,964 |  |  | $ | 10,254 |  |  | $ | (5,711) |  |  | $ | (3,001) |  |
| Inventory deposits and prepayments | $ | 1,109 |  |  | $ | 1,484 |  |  | $ | 162 |  |  | $ | (375) |  |  | $ | 947 |  |

[0000858877-23-000023:mdna:175]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-23-000023:mdna:176]
|  | July 29, 2023 |  | July 30, 2022 |  | July 31, 2021 |  | Variance vs. July 30, 2022 |  | Variance vs. July 31, 2021 |
| Less than 1 year | $ | 5,270 |  |  | $ | 9,954 |  |  | $ | 6,903 |  |  | $ | (4,684) |  |  | $ | (1,633) |  |
| 1 to 3 years | 1,783 |  |  | 2,240 |  |  | 1,806 |  |  | (457) |  |  | (23) |  |
| 3 to 5 years | 200 |  |  | 770 |  |  | 1,545 |  |  | (570) |  |  | (1,345) |  |
| Total | $ | 7,253 |  |  | $ | 12,964 |  |  | $ | 10,254 |  |  | $ | (5,711) |  |  | $ | (3,001) |  |

[0000858877-23-000023:mdna:177]
Inventory as of July 29, 2023 increased by 42% and inventory purchase commitments with contract manufacturers and suppliers decreased by 44% from our balances at the end of fiscal 2022. The combined decrease of 30% in our inventory and inventory purchase commitments as compared with the end of fiscal 2022 was primarily due to fulfillment of customer demand as overall supply constraints improved and our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitment levels.

[0000858877-23-000023:mdna:178]
We increased our balances in prior fiscal years in order to address significant supply constraints seen industry-wide. The increases were primarily due to arrangements to secure supply and pricing for certain product components and commitments with contract manufacturers to meet customer demand and to address extended lead times, as well as advance payments with suppliers to secure future supply, as a result of the supply constraints. As discussed, our risks of future material excess and obsolete inventory and related losses are further outlined in the Result of Operations—Product Gross Margin section.

[0000858877-23-000023:mdna:179]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity.

[0000858877-23-000023:mdna:180]
Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-23-000023:mdna:181]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of supply constraints, rapidly changing technology and customer requirements. We believe the amount of our inventory and inventory purchase commitments is appropriate for our current and expected customer demand and revenue levels.

[0000858877-23-000023:mdna:182]
Financing Receivables and Guarantees  The following table summarizes our financing receivables (in millions):

[0000858877-23-000023:mdna:183]
|  | July 29, 2023 |  | July 30, 2022 |  | Increase (Decrease) |
| Loan receivables, net | $ | 5,857 |  |  | $ | 6,739 |  |  | $ | (882) |  |
| Lease receivables, net | 978 |  |  | 1,175 |  |  | (197) |  |
| Total, net | $ | 6,835 |  |  | $ | 7,914 |  |  | $ | (1,079) |  |

[0000858877-23-000023:mdna:184]
Financing Receivables  Our financing arrangements include loans and leases. Our loan receivables include customer financing for purchases of our hardware, software and services (including technical support and advanced services), and also may include additional funds for other costs associated with network installation and integration of our products and services. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Financing receivables decreased by 14%.

[0000858877-23-000023:mdna:185]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, with payment terms generally ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-23-000023:mdna:186]
The volume of channel partner financing was $32.1 billion, $27.9 billion, and $26.7 billion in fiscal 2023, 2022, and 2021, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.7 billion and $1.4 billion as of July 29, 2023 and July 30, 2022, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of July 29, 2023,

[0000858877-23-000023:mdna:187]
the total maximum potential future payments related to these guarantees was approximately $159 million, of which approximately $34 million was recorded as deferred revenue.

[0000858877-23-000023:mdna:188]
Borrowings

[0000858877-23-000023:mdna:189]
Senior Notes  The following table summarizes the principal amount of our senior notes (in millions):

[0000858877-23-000023:mdna:190]
|  | Maturity Date |  | July 29, 2023 |  | July 30, 2022 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | — |  |  | $ | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 8,500 |  |  | $ | 9,000 |  |

[0000858877-23-000023:mdna:191]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of July 29, 2023.

[0000858877-23-000023:mdna:192]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of July 29, 2023 and $0.6 billion outstanding as of July 30, 2022.

[0000858877-23-000023:mdna:193]
Credit Facility  On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of July 29, 2023, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement. On April 18, 2023, we entered into an amendment to the credit agreement to replace the LIBOR index with Term Secured Overnight Financing Rate (SOFR).

[0000858877-23-000023:mdna:194]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) Term SOFR (plus a 0.10% credit spread adjustment) or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) Term SOFR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

[0000858877-23-000023:mdna:195]
Remaining Performance Obligations   The following table presents the breakdown of remaining performance obligations (in millions):

[0000858877-23-000023:mdna:196]
|  | July 29, 2023 |  | July 30, 2022 |  | Increase (Decrease) |
| Product | $ | 15,802 |  |  | $ | 14,090 |  |  | $ | 1,712 |  |
| Service | 19,066 |  |  | 17,449 |  |  | 1,617 |  |
| Total | $ | 34,868 |  |  | $ | 31,539 |  |  | $ | 3,329 |  |
| Short-term RPO | $ | 17,910 |  |  | $ | 16,936 |  |  | $ | 974 |  |
| Long-term RPO | 16,958 |  |  | 14,603 |  |  | 2,355 |  |
| Total | $ | 34,868 |  |  | $ | 31,539 |  |  | $ | 3,329 |  |

[0000858877-23-000023:mdna:197]
Total remaining performance obligations increased 11% in fiscal 2023. Remaining performance obligations for product increased 12% and remaining performance obligations for service increased 9%, compared to fiscal 2022. We expect approximately 51% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-23-000023:mdna:198]
Deferred Revenue   The following table presents the breakdown of deferred revenue (in millions):

[0000858877-23-000023:mdna:199]
|  | July 29, 2023 |  | July 30, 2022 |  | Increase (Decrease) |
| Product | $ | 11,505 |  |  | $ | 10,427 |  |  | $ | 1,078 |  |
| Service | 14,045 |  |  | 12,837 |  |  | 1,208 |  |
| Total | $ | 25,550 |  |  | $ | 23,264 |  |  | $ | 2,286 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 13,908 |  |  | $ | 12,784 |  |  | $ | 1,124 |  |
| Noncurrent | 11,642 |  |  | 10,480 |  |  | 1,162 |  |
| Total | $ | 25,550 |  |  | $ | 23,264 |  |  | $ | 2,286 |  |

[0000858877-23-000023:mdna:200]
Total deferred revenue increased 10% in fiscal 2023. The increase in deferred product revenue of 10% was primarily due to increased deferrals related to our recurring software offerings. The increase in deferred service revenue of 9% was driven by higher business volume and the impact of contract renewals, partially offset by amortization of deferred service revenue.

[0000858877-23-000023:mdna:201]
Contractual Obligations

[0000858877-23-000023:mdna:202]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. In addition, we plan for and measure our liquidity and capital resources through an annual budgeting process. The following table summarizes our contractual obligations at July 29, 2023 (in millions):

[0000858877-23-000023:mdna:203]
|  | PAYMENTS DUE BY PERIOD |
| July 29, 2023 | Total |  | Less than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than 5 Years |
| Operating leases | $ | 1,116 |  |  | $ | 341 |  |  | $ | 426 |  |  | $ | 172 |  |  | $ | 177 |  |
| Purchase commitments with contract manufacturers and suppliers | 7,253 |  |  | 5,270 |  |  | 1,783 |  |  | 200 |  |  | — |  |
| Other purchase obligations | 2,476 |  |  | 1,222 |  |  | 976 |  |  | 265 |  |  | 13 |  |
| Senior notes | 8,500 |  |  | 1,750 |  |  | 1,250 |  |  | 1,500 |  |  | 4,000 |  |
| Transition tax payable | 5,456 |  |  | 1,364 |  |  | 4,092 |  |  | — |  |  | — |  |
| Other long-term liabilities | 1,365 |  |  | — |  |  | 215 |  |  | 166 |  |  | 984 |  |
| Total by period | $ | 26,166 |  |  | $ | 9,947 |  |  | $ | 8,742 |  |  | $ | 2,303 |  |  | $ | 5,174 |  |
| Other long-term liabilities (uncertainty in the timing of future payments) | 1,726 |  |  |  |  |  |  |  |  |  |
| Total | $ | 27,892 |  |  |  |  |  |  |  |  |  |

[0000858877-23-000023:mdna:204]
Operating Leases  For more information on our operating leases, see Note 8 to the Consolidated Financial Statements.

[0000858877-23-000023:mdna:205]
Purchase Commitments with Contract Manufacturers and Suppliers  We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. See further discussion in “Inventory Supply Chain.”

[0000858877-23-000023:mdna:206]
Other Purchase Obligations  Other purchase obligations represent an estimate of all contractual obligations in the ordinary course of business, other than operating leases and commitments with contract manufacturers and suppliers, for which we have not received the goods or services. Purchase orders are not included in the preceding table as they typically represent our authorization to purchase rather than binding contractual purchase obligations.

[0000858877-23-000023:mdna:207]
Long-Term Debt  The amount of long-term debt in the preceding table represents the principal amount of the respective debt instruments. See Note 12 to the Consolidated Financial Statements.

[0000858877-23-000023:mdna:208]
Transition Tax Payable  Transition tax payable represents future cash tax payments associated with the one-time U.S. transition tax on accumulated earnings for foreign subsidiaries as a result of the Tax Act.

[0000858877-23-000023:mdna:209]
Other Long-Term Liabilities  Other long-term liabilities primarily include noncurrent income taxes payable, accrued liabilities for deferred compensation, deferred tax liabilities, and certain other long-term liabilities. Due to the uncertainty in the timing of future payments, our noncurrent income taxes payable of approximately $1.7 billion and deferred tax liabilities of $62 million were presented as one aggregated amount in the total column on a separate line in the preceding table. Noncurrent income taxes payable include uncertain tax positions. See Note 18 to the Consolidated Financial Statements.

[0000858877-23-000023:mdna:210]
Other Commitments

[0000858877-23-000023:mdna:211]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or the continued employment with us of certain employees of the acquired entities. See Note 14 to the Consolidated Financial Statements.

[0000858877-23-000023:mdna:212]
We also have certain funding commitments primarily related to our privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion and $0.4 billion as of July 29, 2023 and July 30, 2022, respectively.

[0000858877-23-000023:mdna:213]
In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of July 29, 2023 there were no material unconsolidated variable interest entities.

[0000858877-23-000023:mdna:214]
On an ongoing basis, we reassess our privately held investments and customer financings to determine if they are variable interest entities and if we would be regarded as the primary beneficiary pursuant to the applicable accounting guidance. As a result of this ongoing assessment, we may be required to make additional disclosures or consolidate these entities. Because we may not control these entities, we may not have the ability to influence these events.

[0000858877-23-000023:mdna:215]
We provide financing guarantees, which are generally for various third-party financing arrangements extended to our channel partners. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. See the previous discussion of these financing guarantees under “Financing Receivables and Guarantees.”

[0000858877-23-000023:mdna:216]
Liquidity and Capital Resource Requirements

[0000858877-23-000023:mdna:217]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs (including inventory and other supply related payments), capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. We expect increased payments related to inventory and other supply related payments through at least the next 12 months. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.
