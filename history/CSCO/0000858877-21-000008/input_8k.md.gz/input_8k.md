# CSCO 8-K — 0001193125-21-166614 filed 2021-05-19

## item codes, every 8-K on or before 2021-05-25

- 2021-05-19 0001193125-21-166614 — 2.02, 9.01
- 2021-05-14 0001193125-21-162081 — 1.01, 2.03, 9.01
- 2021-03-08 0001193125-21-073328 — 5.02
- 2021-02-25 0001193125-21-056977 — 5.02
- 2021-02-09 0001193125-21-034339 — 2.02, 9.01
- 2021-01-07 0001193125-21-004250 — 5.02
- 2020-12-17 0001193125-20-320092 — 5.02, 8.01
- 2020-12-11 0001193125-20-315999 — 5.02, 5.07, 9.01
- 2020-11-30 0001193125-20-305352 — 5.02
- 2020-11-13 0001193125-20-293020 — 5.02, 9.01
- 2020-11-12 0001193125-20-291658 — 2.02, 9.01
- 2020-10-09 0001193125-20-267248 — 5.03, 9.01
- 2020-09-23 0001193125-20-252356 — 8.01
- 2020-08-12 0001193125-20-217756 — 5.02
- 2020-08-12 0001193125-20-217658 — 2.02, 2.05, 9.01
- 2020-06-22 0001193125-20-175641 — 8.01
- 2020-05-13 0001193125-20-141598 — 2.02, 9.01
- 2020-03-13 0001193125-20-072960 — 5.02
- 2020-03-06 0001193125-20-065138 — 5.02
- 2020-02-12 0001193125-20-033208 — 2.02, 9.01
- 2020-01-27 0001193125-20-015453 — 5.02
- 2019-12-23 0001193125-19-322662 — 8.01
- 2019-12-12 0001193125-19-312796 — 8.01
- 2019-12-11 0001193125-19-311525 — 5.07
- 2019-12-04 0001193125-19-306229 — 8.01
- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2021-05-25

- none on or before 2021-05-25

## item 2.02 — earnings release, exhibit 99.1

[0001193125-21-166614:8k_2_02:1]
EX-99.1
2
d149159dex991.htm
EX-99.1

[0001193125-21-166614:8k_2_02:2]
EX-99.1

[0001193125-21-166614:8k_2_02:3]
Exhibit 99.1

[0001193125-21-166614:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-21-166614:8k_2_02:5]
CISCO REPORTS THIRD QUARTER EARNINGS

[0001193125-21-166614:8k_2_02:6]
News Summary:

[0001193125-21-166614:8k_2_02:7]
|  | • |  | Overall performance: $12.8 billion in revenue, up 7% year over year with broad-based strength across the business; GAAP EPS $0.68 and Non-GAAP EPS $0.83, each up 5% year over year |

[0001193125-21-166614:8k_2_02:8]
|  | • |  | 10% year-over-year total product order growth representing the strongest demand in nearly a decade |

[0001193125-21-166614:8k_2_02:9]
|  | • |  | Continued momentum in transforming business to software and subscriptions: 81% of software revenue sold as a subscription, up from 76% last quarter |

[0001193125-21-166614:8k_2_02:10]
|  | • |  | Q3 Results: |

[0001193125-21-166614:8k_2_02:11]
|  | • |  | Revenue: $12.8 billion |

[0001193125-21-166614:8k_2_02:12]
|  | • |  | Increase of 7% year over year |

[0001193125-21-166614:8k_2_02:13]
|  | • |  | Earnings per Share: GAAP: $0.68; Non-GAAP: $0.83 |

[0001193125-21-166614:8k_2_02:14]
|  | • |  | GAAP EPS increased 5% year over year |

[0001193125-21-166614:8k_2_02:15]
|  | • |  | Non-GAAP EPS increased 5% year over year |

[0001193125-21-166614:8k_2_02:16]
|  | • |  | Q4 Guidance: |

[0001193125-21-166614:8k_2_02:17]
|  | • |  | Revenue: 6% to 8% growth year over year |

[0001193125-21-166614:8k_2_02:18]
|  | • |  | Earnings per Share: GAAP: $0.64 to $0.69; Non-GAAP: $0.81 to $0.83 |

[0001193125-21-166614:8k_2_02:19]
SAN JOSE, Calif. — May 19, 2021 — Cisco today reported third quarter results for the period ended May 1, 2021.
Cisco reported third quarter revenue of $12.8 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.9 billion or $0.68 per share, and non-GAAP net income of
$3.5 billion or $0.83 per share.

[0001193125-21-166614:8k_2_02:20]
“Cisco had a great quarter with strong demand across the business,” said Chuck Robbins, chairman and CEO
of Cisco. “We are confident in our strategy and our ability to lead the next phase of the recovery as our customers accelerate their adoption of hybrid work, digital transformation, cloud, and continued strong uptake of our subscription-based
offerings.”

[0001193125-21-166614:8k_2_02:21]
“We executed well with strong product orders, and solid growth in revenue, net income, and EPS,” said Scott Herren, CFO of
Cisco. “Our investments in innovation and accelerated shift to more software offerings and subscriptions led to double-digit growth in deferred revenue, remaining performance obligations and higher levels of recurring revenue.”

[0001193125-21-166614:8k_2_02:22]
GAAP Results

[0001193125-21-166614:8k_2_02:23]
|  |  | Q3 FY 2021 |  |  | Q3 FY 2020 |  |  | Vs. Q3 FY 2020 |  |
| Revenue |  | $ | 12.8 billion |  |  | $ | 12.0 billion |  |  |  | 7 | % |
| Net Income |  | $ | 2.9 billion |  |  | $ | 2.8 billion |  |  |  | 3 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.68 |  |  | $ | 0.65 |  |  |  | 5 | % |

[0001193125-21-166614:8k_2_02:24]
Non-GAAP Results

[0001193125-21-166614:8k_2_02:25]
|  |  | Q3 FY 2021 |  |  | Q3 FY 2020 |  |  | Vs. Q3 FY 2020 |  |
| Net Income |  | $ | 3.5 billion |  |  | $ | 3.4 billion |  |  |  | 4 | % |
| EPS |  | $ | 0.83 |  |  | $ | 0.79 |  |  |  | 5 | % |

[0001193125-21-166614:8k_2_02:26]
The third quarter of fiscal 2021 had 14 weeks compared with 13 weeks in the third quarter of fiscal 2020.

[0001193125-21-166614:8k_2_02:27]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP basis are provided in the tables
located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-21-166614:8k_2_02:28]
1

[0001193125-21-166614:8k_2_02:29]
Financial Summary

[0001193125-21-166614:8k_2_02:30]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-21-166614:8k_2_02:31]
Q3 FY 2021 Highlights

[0001193125-21-166614:8k_2_02:32]
Revenue — Total
revenue was up 7% at $12.8 billion, with product revenue up 6% and service revenue up 8%. Revenue by geographic segment was: Americas up 2%, EMEA up 11%, and APJC up 19%. Product revenue performance was broad-based with growth in Security, up
13%, Infrastructure Platforms up 6%, and Applications up 5%.

[0001193125-21-166614:8k_2_02:33]
Gross Margin — On a GAAP basis, total gross margin, product gross
margin, and service gross margin were 63.9%, 62.6%, and 67.4%, respectively, as compared with 64.9%, 63.7%, and 67.7%, respectively, in the third quarter of fiscal 2020.

[0001193125-21-166614:8k_2_02:34]
On a non-GAAP basis, total gross margin, product gross margin, and service gross margin were 66.0%, 64.9%, and 68.7%,
respectively, as compared with 66.6%, 65.8%, and 68.9%, respectively, in the third quarter of fiscal 2020.

[0001193125-21-166614:8k_2_02:35]
Total gross margins by geographic segment
were: 66.5% for the Americas, 65.6% for EMEA and 64.7% for APJC.

[0001193125-21-166614:8k_2_02:36]
Operating Expenses — On a GAAP basis, operating expenses were
$4.7 billion, up 8%, and were 36.9% of revenue. Non-GAAP operating expenses were $4.1 billion, up 9%, and were 32.4% of revenue.

[0001193125-21-166614:8k_2_02:37]
Operating Income — GAAP operating income was $3.5 billion, up 1%, with GAAP operating margin of 27.1%.
Non-GAAP operating income was $4.3 billion, up 3%, with non-GAAP operating margin at 33.6%.

[0001193125-21-166614:8k_2_02:38]
Provision for Income Taxes — The GAAP tax provision rate was 20.3%. The non-GAAP tax provision rate
was 19.0%.

[0001193125-21-166614:8k_2_02:39]
Net Income and EPS — On a GAAP basis, net income was $2.9 billion, an increase of 3%, and EPS was $0.68, an increase
of 5%. On a non-GAAP basis, net income was $3.5 billion, an increase of 4%, and EPS was $0.83, an increase of 5%.

[0001193125-21-166614:8k_2_02:40]
Cash Flow from Operating Activities — $3.9 billion for the third quarter of fiscal 2021, a decrease of 8% compared with
$4.2 billion for the third quarter of fiscal 2020.

[0001193125-21-166614:8k_2_02:41]
Balance Sheet and Other Financial Highlights

[0001193125-21-166614:8k_2_02:42]
Cash and Cash Equivalents and Investments — $23.6 billion at the end of the third quarter of fiscal 2021, compared with
$29.4 billion at the end of fiscal 2020.

[0001193125-21-166614:8k_2_02:43]
Deferred Revenue — $20.9 billion, up 12% in total, with deferred product revenue up
20%. Deferred service revenue was up 7%.

[0001193125-21-166614:8k_2_02:44]
Remaining Performance Obligations — $28.1 billion at the end of the third
quarter of fiscal 2021, up 10%.

[0001193125-21-166614:8k_2_02:45]
Capital Allocation — In the third quarter of fiscal 2021, we returned $2.1 billion to
stockholders through share buybacks and dividends. We declared and paid a cash dividend of $0.37 per common share, or $1.6 billion, and repurchased approximately 10 million shares of common stock under our stock repurchase program at an
average price of $48.71 per share for an aggregate purchase price of $510 million. The remaining authorized amount for stock repurchases under the program is $8.7 billion with no termination date.

[0001193125-21-166614:8k_2_02:46]
Acquisitions

[0001193125-21-166614:8k_2_02:47]
In the third quarter of fiscal 2021, we
closed the following acquisitions:

[0001193125-21-166614:8k_2_02:48]
|  | • |  | Acacia Communications, Inc., a public fabless semiconductor company that develops, manufactures and sells high-speed coherent optical interconnect products that are designed to transform communications networks through improvements in performance, capacity and cost. |

[0001193125-21-166614:8k_2_02:49]
|  | • |  | IMImobile PLC, a United Kingdom-based publicly-traded cloud communications software and services company. |

[0001193125-21-166614:8k_2_02:50]
|  | • |  | Dashbase, Inc., an enterprise software company. |

[0001193125-21-166614:8k_2_02:51]
In the fourth quarter of fiscal 2021, we closed the acquisition of Slido s.r.o, a privately held company that provides an audience interaction platform.

[0001193125-21-166614:8k_2_02:52]
2

[0001193125-21-166614:8k_2_02:53]
Guidance for Q4 FY 2021

[0001193125-21-166614:8k_2_02:54]
Cisco expects to achieve the following results for the fourth quarter of fiscal 2021:

[0001193125-21-166614:8k_2_02:55]
| Q4 FY 2021 |  |  |
| Revenue |  | 6% - 8% growth Y/Y |
| Non-GAAP gross margin rate |  | 64% - 65% |
| Non-GAAP operating margin rate |  | 32% - 33% |
| Non-GAAP tax provision rate |  | 19% |
| Non-GAAP EPS |  | $0.81 - $0.83 |

[0001193125-21-166614:8k_2_02:56]
Cisco estimates that GAAP EPS will be $0.64 to $0.69 in the fourth quarter of fiscal 2021.

[0001193125-21-166614:8k_2_02:57]
A reconciliation between the Guidance for Q4 FY 2021 on a GAAP and non-GAAP basis is provided in the table entitled
“GAAP to non-GAAP Guidance for Q4 FY 2021” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-21-166614:8k_2_02:58]
Editor’s Notes:

[0001193125-21-166614:8k_2_02:59]
|  | • |  | Q3 fiscal year 2021 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, May 19, 2021 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-21-166614:8k_2_02:60]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, May 19, 2021 to 4:00 p.m. Pacific Time, May 26, 2021 at 1-866-461-2738 (United States) or 1-203-369-1354 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-21-166614:8k_2_02:61]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, May 19, 2021. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-21-166614:8k_2_02:62]
3

[0001193125-21-166614:8k_2_02:63]
CISCO SYSTEMS, INC.

[0001193125-21-166614:8k_2_02:64]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-21-166614:8k_2_02:65]
(In millions, except per-share amounts)

[0001193125-21-166614:8k_2_02:66]
(Unaudited)

[0001193125-21-166614:8k_2_02:67]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | May 1,2021 |  |  | April 25,2020 |  |  | May 1,2021 |  |  | April 25,2020 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,139 |  |  | $ | 8,597 |  |  | $ | 26,298 |  |  | $ | 27,146 |  |
| Service |  |  | 3,664 |  |  |  | 3,386 |  |  |  | 10,394 |  |  |  | 10,001 |  |
| Total revenue |  |  | 12,803 |  |  |  | 11,983 |  |  |  | 36,692 |  |  |  | 37,147 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,422 |  |  |  | 3,120 |  |  |  | 9,672 |  |  |  | 9,770 |  |
| Service |  |  | 1,196 |  |  |  | 1,092 |  |  |  | 3,470 |  |  |  | 3,378 |  |
| Total cost of sales |  |  | 4,618 |  |  |  | 4,212 |  |  |  | 13,142 |  |  |  | 13,148 |  |
| GROSS MARGIN |  |  | 8,185 |  |  |  | 7,771 |  |  |  | 23,550 |  |  |  | 23,999 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,697 |  |  |  | 1,546 |  |  |  | 4,836 |  |  |  | 4,782 |  |
| Sales and marketing |  |  | 2,317 |  |  |  | 2,192 |  |  |  | 6,811 |  |  |  | 6,951 |  |
| General and administrative |  |  | 603 |  |  |  | 457 |  |  |  | 1,631 |  |  |  | 1,431 |  |
| Amortization of purchased intangible assets |  |  | 61 |  |  |  | 34 |  |  |  | 136 |  |  |  | 108 |  |
| Restructuring and other charges |  |  | 42 |  |  |  | 128 |  |  |  | 878 |  |  |  | 354 |  |
| Total operating expenses |  |  | 4,720 |  |  |  | 4,357 |  |  |  | 14,292 |  |  |  | 13,626 |  |
| OPERATING INCOME |  |  | 3,465 |  |  |  | 3,414 |  |  |  | 9,258 |  |  |  | 10,373 |  |
| Interest income |  |  | 153 |  |  |  | 218 |  |  |  | 488 |  |  |  | 733 |  |
| Interest expense |  |  | (111 | ) |  |  | (130 | ) |  |  | (336 | ) |  |  | (466 | ) |
| Other income (loss), net |  |  | 84 |  |  |  | (58 | ) |  |  | 117 |  |  |  | 24 |  |
| Interest and other income (loss), net |  |  | 126 |  |  |  | 30 |  |  |  | 269 |  |  |  | 291 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,591 |  |  |  | 3,444 |  |  |  | 9,527 |  |  |  | 10,664 |  |
| Provision for income taxes |  |  | 728 |  |  |  | 670 |  |  |  | 1,945 |  |  |  | 2,086 |  |
| NET INCOME |  | $ | 2,863 |  |  | $ | 2,774 |  |  | $ | 7,582 |  |  | $ | 8,578 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.68 |  |  | $ | 0.66 |  |  | $ | 1.79 |  |  | $ | 2.02 |  |
| Diluted |  | $ | 0.68 |  |  | $ | 0.65 |  |  | $ | 1.79 |  |  | $ | 2.01 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,219 |  |  |  | 4,230 |  |  |  | 4,224 |  |  |  | 4,239 |  |
| Diluted |  |  | 4,238 |  |  |  | 4,243 |  |  |  | 4,237 |  |  |  | 4,258 |  |

[0001193125-21-166614:8k_2_02:68]
4

[0001193125-21-166614:8k_2_02:69]
CISCO SYSTEMS, INC.

[0001193125-21-166614:8k_2_02:70]
REVENUE BY SEGMENT

[0001193125-21-166614:8k_2_02:71]
(In
millions, except percentages)

[0001193125-21-166614:8k_2_02:72]
|  |  | May 1, 2021 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,262 |  |  |  | 2 | % |  | $ | 21,430 |  |  |  | (3 | )% |
| EMEA |  |  | 3,483 |  |  |  | 11 | % |  |  | 9,654 |  |  |  | 1 | % |
| APJC |  |  | 2,057 |  |  |  | 19 | % |  |  | 5,608 |  |  |  | 2 | % |
| Total |  | $ | 12,803 |  |  |  | 7 | % |  | $ | 36,692 |  |  |  | (1 | )% |

[0001193125-21-166614:8k_2_02:73]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-21-166614:8k_2_02:74]
CISCO SYSTEMS, INC.

[0001193125-21-166614:8k_2_02:75]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-21-166614:8k_2_02:76]
(In percentages)

[0001193125-21-166614:8k_2_02:77]
|  |  | May 1, 2021 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 66.5 | % |  |  | 67.1 | % |
| EMEA |  |  | 65.6 | % |  |  | 65.5 | % |
| APJC |  |  | 64.7 | % |  |  | 64.2 | % |

[0001193125-21-166614:8k_2_02:78]
CISCO SYSTEMS, INC.

[0001193125-21-166614:8k_2_02:79]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-21-166614:8k_2_02:80]
(In millions, except percentages)

[0001193125-21-166614:8k_2_02:81]
|  |  | May 1, 2021 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 6,832 |  |  |  | 6 | % |  | $ | 19,564 |  |  |  | (5 | )% |
| Applications |  |  | 1,426 |  |  |  | 5 | % |  |  | 4,160 |  |  |  | (1 | )% |
| Security |  |  | 876 |  |  |  | 13 | % |  |  | 2,559 |  |  |  | 9 | % |
| Other Products |  |  | 6 |  |  |  | (34 | )% |  |  | 15 |  |  |  | (44 | )% |
| Total Product |  |  | 9,139 |  |  |  | 6 | % |  |  | 26,298 |  |  |  | (3 | )% |
| Services |  |  | 3,664 |  |  |  | 8 | % |  |  | 10,394 |  |  |  | 4 | % |
| Total |  | $ | 12,803 |  |  |  | 7 | % |  | $ | 36,692 |  |  |  | (1 | )% |

[0001193125-21-166614:8k_2_02:82]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-21-166614:8k_2_02:83]
5

[0001193125-21-166614:8k_2_02:84]
CISCO SYSTEMS, INC.

[0001193125-21-166614:8k_2_02:85]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-21-166614:8k_2_02:86]
(In millions)

[0001193125-21-166614:8k_2_02:87]
(Unaudited)

[0001193125-21-166614:8k_2_02:88]
|  |  | May 1, 2021 |  |  | July 25, 2020 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 7,350 |  |  | $ | 11,809 |  |
| Investments |  |  | 16,229 |  |  |  | 17,610 |  |
| Accounts receivable, net of allowance for doubtful accounts of $110 at May 1, 2021 and $143 at July 25, 2020 |  |  | 4,425 |  |  |  | 5,472 |  |
| Inventories |  |  | 1,579 |  |  |  | 1,282 |  |
| Financing receivables, net |  |  | 4,648 |  |  |  | 5,051 |  |
| Other current assets |  |  | 2,829 |  |  |  | 2,349 |  |
| Total current assets |  |  | 37,060 |  |  |  | 43,573 |  |
| Property and equipment, net |  |  | 2,367 |  |  |  | 2,453 |  |
| Financing receivables, net |  |  | 5,068 |  |  |  | 5,714 |  |
| Goodwill |  |  | 37,690 |  |  |  | 33,806 |  |
| Purchased intangible assets, net |  |  | 3,716 |  |  |  | 1,576 |  |
| Deferred tax assets |  |  | 4,070 |  |  |  | 3,990 |  |
| Other assets |  |  | 3,925 |  |  |  | 3,741 |  |
| TOTAL ASSETS |  | $ | 93,896 |  |  | $ | 94,853 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 2,000 |  |  | $ | 3,005 |  |
| Accounts payable |  |  | 2,440 |  |  |  | 2,218 |  |
| Income taxes payable |  |  | 753 |  |  |  | 839 |  |
| Accrued compensation |  |  | 3,327 |  |  |  | 3,122 |  |
| Deferred revenue |  |  | 11,492 |  |  |  | 11,406 |  |
| Other current liabilities |  |  | 4,250 |  |  |  | 4,741 |  |
| Total current liabilities |  |  | 24,262 |  |  |  | 25,331 |  |
| Long-term debt |  |  | 9,532 |  |  |  | 11,578 |  |
| Income taxes payable |  |  | 8,247 |  |  |  | 8,837 |  |
| Deferred revenue |  |  | 9,397 |  |  |  | 9,040 |  |
| Other long-term liabilities |  |  | 2,253 |  |  |  | 2,147 |  |
| Total liabilities |  |  | 53,691 |  |  |  | 56,933 |  |
| Total equity |  |  | 40,205 |  |  |  | 37,920 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 93,896 |  |  | $ | 94,853 |  |

[0001193125-21-166614:8k_2_02:89]
6

[0001193125-21-166614:8k_2_02:90]
CISCO SYSTEMS, INC.

[0001193125-21-166614:8k_2_02:91]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-21-166614:8k_2_02:92]
(In millions)

[0001193125-21-166614:8k_2_02:93]
(Unaudited)

[0001193125-21-166614:8k_2_02:94]
|  |  | Nine Months Ended |  |
|  |  | May 1,2021 |  |  | April 25,2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 7,582 |  |  | $ | 8,578 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,373 |  |  |  | 1,364 |  |
| Share-based compensation expense |  |  | 1,337 |  |  |  | 1,170 |  |
| Provision (benefit) for receivables |  |  | (4 | ) |  |  | 60 |  |
| Deferred income taxes |  |  | (89 | ) |  |  | 103 |  |
| (Gains) losses on divestitures, investments and other, net |  |  | (201 | ) |  |  | (185 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,250 |  |  |  | 774 |  |
| Inventories |  |  | (260 | ) |  |  | 143 |  |
| Financing receivables |  |  | 1,160 |  |  |  | 380 |  |
| Other assets |  |  | (233 | ) |  |  | 145 |  |
| Accounts payable |  |  | 24 |  |  |  | 324 |  |
| Income taxes, net |  |  | (828 | ) |  |  | (700 | ) |
| Accrued compensation |  |  | 145 |  |  |  | (220 | ) |
| Deferred revenue |  |  | 263 |  |  |  | 333 |  |
| Other liabilities |  |  | (569 | ) |  |  | (645 | ) |
| Net cash provided by operating activities |  |  | 10,950 |  |  |  | 11,624 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (7,855 | ) |  |  | (6,880 | ) |
| Proceeds from sales of investments |  |  | 2,724 |  |  |  | 4,737 |  |
| Proceeds from maturities of investments |  |  | 6,445 |  |  |  | 5,708 |  |
| Acquisitions, net of cash and cash equivalents acquired and divestitures |  |  | (6,333 | ) |  |  | (237 | ) |
| Purchases of investments in privately held companies |  |  | (138 | ) |  |  | (143 | ) |
| Return of investments in privately held companies |  |  | 96 |  |  |  | 213 |  |
| Acquisition of property and equipment |  |  | (530 | ) |  |  | (562 | ) |
| Proceeds from sales of property and equipment |  |  | 14 |  |  |  | 175 |  |
| Other |  |  | (56 | ) |  |  | (10 | ) |
| Net cash (used in) provided by investing activities |  |  | (5,633 | ) |  |  | 3,001 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 307 |  |  |  | 335 |  |
| Repurchases of common stock—repurchase program |  |  | (2,096 | ) |  |  | (2,659 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (419 | ) |  |  | (519 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | — |  |  |  | (3,470 | ) |
| Repayments of debt |  |  | (3,000 | ) |  |  | (5,220 | ) |
| Dividends paid |  |  | (4,601 | ) |  |  | (4,491 | ) |
| Other |  |  | 39 |  |  |  | (3 | ) |
| Net cash used in financing activities |  |  | (9,770 | ) |  |  | (16,027 | ) |
| Net decrease in cash, cash equivalents, and restricted cash |  |  | (4,453 | ) |  |  | (1,402 | ) |
| Cash, cash equivalents, and restricted cash, beginning of period |  |  | 11,812 |  |  |  | 11,772 |  |
| Cash, cash equivalents, and restricted cash, end of period |  | $ | 7,359 |  |  | $ | 10,370 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 377 |  |  | $ | 519 |  |
| Cash paid for income taxes, net |  | $ | 2,862 |  |  | $ | 2,683 |  |

[0001193125-21-166614:8k_2_02:95]
7

[0001193125-21-166614:8k_2_02:96]
CISCO SYSTEMS, INC.

[0001193125-21-166614:8k_2_02:97]
DEFERRED REVENUE

[0001193125-21-166614:8k_2_02:98]
(In
millions)

[0001193125-21-166614:8k_2_02:99]
|  |  | May 1,2021 |  |  | January 23,2021 |  |  | April 25,2020 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,698 |  |  | $ | 8,332 |  |  | $ | 7,225 |  |
| Service |  |  | 12,191 |  |  |  | 12,514 |  |  |  | 11,423 |  |
| Total |  | $ | 20,889 |  |  | $ | 20,846 |  |  | $ | 18,648 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 11,492 |  |  | $ | 11,552 |  |  | $ | 10,710 |  |
| Noncurrent |  |  | 9,397 |  |  |  | 9,294 |  |  |  | 7,938 |  |
| Total |  | $ | 20,889 |  |  | $ | 20,846 |  |  | $ | 18,648 |  |

[0001193125-21-166614:8k_2_02:100]
CISCO SYSTEMS, INC.

[0001193125-21-166614:8k_2_02:101]
REMAINING PERFORMANCE OBLIGATIONS

[0001193125-21-166614:8k_2_02:102]
(In millions, except percentages)

[0001193125-21-166614:8k_2_02:103]
|  |  | May 1, 2021 |  |  | January 23, 2021 |  |  | April 25, 2020 |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Product |  | $ | 11,903 |  |  |  | 15 | % |  | $ | 11,666 |  |  |  | 17 | % |  | $ | 10,387 |  |  |  | 25 | % |
| Service |  |  | 16,235 |  |  |  | 7 | % |  |  | 16,512 |  |  |  | 10 | % |  |  | 15,141 |  |  |  | 3 | % |
| Total |  | $ | 28,138 |  |  |  | 10 | % |  | $ | 28,178 |  |  |  | 13 | % |  | $ | 25,528 |  |  |  | 11 | % |

[0001193125-21-166614:8k_2_02:104]
CISCO SYSTEMS, INC.

[0001193125-21-166614:8k_2_02:105]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-21-166614:8k_2_02:106]
(In millions, except per-share amounts)

[0001193125-21-166614:8k_2_02:107]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | PerShare |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| May 1, 2021 |  | $ | 0.37 |  |  | $ | 1,560 |  |  |  | 10 |  |  | $ | 48.71 |  |  | $ | 510 |  |  | $ | 2,070 |  |
| January 23, 2021 |  | $ | 0.36 |  |  | $ | 1,521 |  |  |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |  | $ | 2,322 |  |
| October 24, 2020 |  | $ | 0.36 |  |  | $ | 1,520 |  |  |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |  | $ | 2,320 |  |
| Fiscal 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 25, 2020 |  | $ | 0.36 |  |  | $ | 1,525 |  |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,525 |  |
| April 25, 2020 |  | $ | 0.36 |  |  | $ | 1,519 |  |  |  | 25 |  |  | $ | 39.71 |  |  | $ | 981 |  |  | $ | 2,500 |  |
| January 25, 2020 |  | $ | 0.35 |  |  | $ | 1,486 |  |  |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |  | $ | 2,356 |  |
| October 26, 2019 |  | $ | 0.35 |  |  | $ | 1,486 |  |  |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |  | $ | 2,254 |  |

[0001193125-21-166614:8k_2_02:108]
8

[0001193125-21-166614:8k_2_02:109]
CISCO SYSTEMS, INC.

[0001193125-21-166614:8k_2_02:110]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-166614:8k_2_02:111]
GAAP TO NON-GAAP NET INCOME

[0001193125-21-166614:8k_2_02:112]
(In millions)

[0001193125-21-166614:8k_2_02:113]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | May 1,2021 |  |  | April 25,2020 |  |  | May 1,2021 |  |  | April 25,2020 |  |
| GAAP net income |  | $ | 2,863 |  |  | $ | 2,774 |  |  | $ | 7,582 |  |  | $ | 8,578 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 75 |  |  |  | 60 |  |  |  | 208 |  |  |  | 176 |  |
| Amortization of acquisition-related intangible assets |  |  | 184 |  |  |  | 154 |  |  |  | 499 |  |  |  | 454 |  |
| Acquisition-related/divestiture costs |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |  |  | 3 |  |
| Legal and indemnification settlements/charges |  |  | — |  |  |  | — |  |  |  | 43 |  |  |  | 4 |  |
| Total adjustments to GAAP cost of sales |  |  | 260 |  |  |  | 215 |  |  |  | 753 |  |  |  | 637 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 383 |  |  |  | 322 |  |  |  | 1,103 |  |  |  | 975 |  |
| Amortization of acquisition-related intangible assets |  |  | 61 |  |  |  | 34 |  |  |  | 136 |  |  |  | 108 |  |
| Acquisition-related/divestiture costs |  |  | 86 |  |  |  | 66 |  |  |  | 179 |  |  |  | 191 |  |
| Significant asset impairments and restructurings |  |  | 42 |  |  |  | 128 |  |  |  | 878 |  |  |  | 354 |  |
| Total adjustments to GAAP operating expenses |  |  | 572 |  |  |  | 550 |  |  |  | 2,296 |  |  |  | 1,628 |  |
| Adjustments to interest and other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related/divestiture costs |  |  | 6 |  |  |  | — |  |  |  | 4 |  |  |  | — |  |
| (Gains) and losses on equity investments |  |  | (96 | ) |  |  | 1 |  |  |  | (131 | ) |  |  | (99 | ) |
| Total adjustments to GAAP interest and other income (loss), net |  |  | (90 | ) |  |  | 1 |  |  |  | (127 | ) |  |  | (99 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 742 |  |  |  | 766 |  |  |  | 2,922 |  |  |  | 2,166 |  |
| Income tax effect of non-GAAP adjustments |  |  | (95 | ) |  |  | (172 | ) |  |  | (503 | ) |  |  | (547 | ) |
| Significant tax matters |  |  | — |  |  |  | — |  |  |  | 83 |  |  |  | 67 |  |
| Total adjustments to GAAP provision for income taxes |  |  | (95 | ) |  |  | (172 | ) |  |  | (420 | ) |  |  | (480 | ) |
| Non-GAAP net income |  | $ | 3,510 |  |  | $ | 3,368 |  |  | $ | 10,084 |  |  | $ | 10,264 |  |

[0001193125-21-166614:8k_2_02:114]
9

[0001193125-21-166614:8k_2_02:115]
CISCO SYSTEMS, INC.

[0001193125-21-166614:8k_2_02:116]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-166614:8k_2_02:117]
GAAP TO NON-GAAP EPS

[0001193125-21-166614:8k_2_02:118]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | May 1,2021 |  |  | April 25,2020 |  |  | May 1,2021 |  |  | April 25,2020 |  |
| GAAP EPS |  | $ | 0.68 |  |  | $ | 0.65 |  |  | $ | 1.79 |  |  | $ | 2.01 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.11 |  |  |  | 0.09 |  |  |  | 0.31 |  |  |  | 0.27 |  |
| Amortization of acquisition-related intangible assets |  |  | 0.06 |  |  |  | 0.04 |  |  |  | 0.15 |  |  |  | 0.13 |  |
| Acquisition-related/divestiture costs |  |  | 0.02 |  |  |  | 0.02 |  |  |  | 0.04 |  |  |  | 0.05 |  |
| Legal and indemnification settlements/charges |  |  | — |  |  |  | — |  |  |  | 0.01 |  |  |  | — |  |
| Significant asset impairments and restructurings |  |  | 0.01 |  |  |  | 0.03 |  |  |  | 0.21 |  |  |  | 0.08 |  |
| (Gains) and losses on equity investments |  |  | (0.02 | ) |  |  | — |  |  |  | (0.03 | ) |  |  | (0.02 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.02 | ) |  |  | (0.04 | ) |  |  | (0.12 | ) |  |  | (0.13 | ) |
| Significant tax matters |  |  | — |  |  |  | — |  |  |  | 0.02 |  |  |  | 0.02 |  |
| Non-GAAP EPS |  | $ | 0.83 |  |  | $ | 0.79 |  |  | $ | 2.38 |  |  | $ | 2.41 |  |

[0001193125-21-166614:8k_2_02:119]
Amounts may not sum due to rounding.

[0001193125-21-166614:8k_2_02:120]
10

[0001193125-21-166614:8k_2_02:121]
CISCO SYSTEMS, INC.

[0001193125-21-166614:8k_2_02:122]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-166614:8k_2_02:123]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-21-166614:8k_2_02:124]
(In millions, except percentages)

[0001193125-21-166614:8k_2_02:125]
|  |  | Three Months Ended |  |
|  |  | May 1, 2021 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,717 |  |  | $ | 2,468 |  |  | $ | 8,185 |  |  | $ | 4,720 |  |  |  | 8 | % |  | $ | 3,465 |  |  |  | 1 | % |  | $ | 126 |  |  | $ | 2,863 |  |  |  | 3 | % |
| % of revenue |  |  | 62.6 | % |  |  | 67.4 | % |  |  | 63.9 | % |  |  | 36.9 | % |  |  |  |  |  |  | 27.1 | % |  |  |  |  |  |  | 1.0 | % |  |  | 22.4 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 26 |  |  |  | 49 |  |  |  | 75 |  |  |  | 383 |  |  |  |  |  |  |  | 458 |  |  |  |  |  |  |  | — |  |  |  | 458 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 184 |  |  |  | — |  |  |  | 184 |  |  |  | 61 |  |  |  |  |  |  |  | 245 |  |  |  |  |  |  |  | — |  |  |  | 245 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 86 |  |  |  |  |  |  |  | 87 |  |  |  |  |  |  |  | 6 |  |  |  | 93 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 42 |  |  |  |  |  |  |  | 42 |  |  |  |  |  |  |  | — |  |  |  | 42 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (96 | ) |  |  | (96 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (95 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 5,928 |  |  | $ | 2,517 |  |  | $ | 8,445 |  |  | $ | 4,148 |  |  |  | 9 | % |  | $ | 4,297 |  |  |  | 3 | % |  | $ | 36 |  |  | $ | 3,510 |  |  |  | 4 | % |
| % of revenue |  |  | 64.9 | % |  |  | 68.7 | % |  |  | 66.0 | % |  |  | 32.4 | % |  |  |  |  |  |  | 33.6 | % |  |  |  |  |  |  | 0.3 | % |  |  | 27.4 | % |  |  |  |  |

[0001193125-21-166614:8k_2_02:126]
|  |  | Three Months Ended |  |
|  |  | April 25, 2020 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 5,477 |  |  | $ | 2,294 |  |  | $ | 7,771 |  |  | $ | 4,357 |  |  | $ | 3,414 |  |  | $ | 30 |  |  | $ | 2,774 |  |
| % of revenue |  |  | 63.7 | % |  |  | 67.7 | % |  |  | 64.9 | % |  |  | 36.4 | % |  |  | 28.5 | % |  |  | 0.3 | % |  |  | 23.1 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 23 |  |  |  | 37 |  |  |  | 60 |  |  |  | 322 |  |  |  | 382 |  |  |  | — |  |  |  | 382 |  |
| Amortization of acquisition-related intangible assets |  |  | 154 |  |  |  | — |  |  |  | 154 |  |  |  | 34 |  |  |  | 188 |  |  |  | — |  |  |  | 188 |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 66 |  |  |  | 67 |  |  |  | — |  |  |  | 67 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 128 |  |  |  | 128 |  |  |  | — |  |  |  | 128 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (172 | ) |
| Non-GAAP amount |  | $ | 5,654 |  |  | $ | 2,332 |  |  | $ | 7,986 |  |  | $ | 3,807 |  |  | $ | 4,179 |  |  | $ | 31 |  |  | $ | 3,368 |  |
| % of revenue |  |  | 65.8 | % |  |  | 68.9 | % |  |  | 66.6 | % |  |  | 31.8 | % |  |  | 34.9 | % |  |  | 0.3 | % |  |  | 28.1 | % |

[0001193125-21-166614:8k_2_02:127]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-21-166614:8k_2_02:128]
11

[0001193125-21-166614:8k_2_02:129]
CISCO SYSTEMS, INC.

[0001193125-21-166614:8k_2_02:130]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-166614:8k_2_02:131]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-21-166614:8k_2_02:132]
(In millions, except percentages)

[0001193125-21-166614:8k_2_02:133]
|  |  | Nine Months Ended |  |
|  |  | May 1, 2021 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 16,626 |  |  | $ | 6,924 |  |  | $ | 23,550 |  |  | $ | 14,292 |  |  |  | 5 | % |  | $ | 9,258 |  |  |  | (11 | )% |  | $ | 269 |  |  | $ | 7,582 |  |  |  | (12 | )% |
| % of revenue |  |  | 63.2 | % |  |  | 66.6 | % |  |  | 64.2 | % |  |  | 39.0 | % |  |  |  |  |  |  | 25.2 | % |  |  |  |  |  |  | 0.7 | % |  |  | 20.7 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 75 |  |  |  | 133 |  |  |  | 208 |  |  |  | 1,103 |  |  |  |  |  |  |  | 1,311 |  |  |  |  |  |  |  | — |  |  |  | 1,311 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 499 |  |  |  | — |  |  |  | 499 |  |  |  | 136 |  |  |  |  |  |  |  | 635 |  |  |  |  |  |  |  | — |  |  |  | 635 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 2 |  |  |  | 1 |  |  |  | 3 |  |  |  | 179 |  |  |  |  |  |  |  | 182 |  |  |  |  |  |  |  | 4 |  |  |  | 186 |  |  |  |  |  |
| Legal and indemnification settlements/charges |  |  | 43 |  |  |  | — |  |  |  | 43 |  |  |  | — |  |  |  |  |  |  |  | 43 |  |  |  |  |  |  |  | — |  |  |  | 43 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 878 |  |  |  |  |  |  |  | 878 |  |  |  |  |  |  |  | — |  |  |  | 878 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (131 | ) |  |  | (131 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (420 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 17,245 |  |  | $ | 7,058 |  |  | $ | 24,303 |  |  | $ | 11,996 |  |  |  | — | % |  | $ | 12,307 |  |  |  | (3 | )% |  | $ | 142 |  |  | $ | 10,084 |  |  |  | (2 | )% |
| % of revenue |  |  | 65.6 | % |  |  | 67.9 | % |  |  | 66.2 | % |  |  | 32.7 | % |  |  |  |  |  |  | 33.5 | % |  |  |  |  |  |  | 0.4 | % |  |  | 27.5 | % |  |  |  |  |

[0001193125-21-166614:8k_2_02:134]
|  |  | Nine Months Ended |  |
|  |  | April 25, 2020 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interest andotherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 17,376 |  |  | $ | 6,623 |  |  | $ | 23,999 |  |  | $ | 13,626 |  |  | $ | 10,373 |  |  | $ | 291 |  |  | $ | 8,578 |  |
| % of revenue |  |  | 64.0 | % |  |  | 66.2 | % |  |  | 64.6 | % |  |  | 36.7 | % |  |  | 27.9 | % |  |  | 0.8 | % |  |  | 23.1 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 69 |  |  |  | 107 |  |  |  | 176 |  |  |  | 975 |  |  |  | 1,151 |  |  |  | — |  |  |  | 1,151 |  |
| Amortization of acquisition-related intangible assets |  |  | 454 |  |  |  | — |  |  |  | 454 |  |  |  | 108 |  |  |  | 562 |  |  |  | — |  |  |  | 562 |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 3 |  |  |  | 3 |  |  |  | 191 |  |  |  | 194 |  |  |  | — |  |  |  | 194 |  |
| Legal and indemnification settlements |  |  | 4 |  |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  | 4 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 354 |  |  |  | 354 |  |  |  | — |  |  |  | 354 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (99 | ) |  |  | (99 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (480 | ) |
| Non-GAAP amount |  | $ | 17,903 |  |  | $ | 6,733 |  |  | $ | 24,636 |  |  | $ | 11,998 |  |  | $ | 12,638 |  |  | $ | 192 |  |  | $ | 10,264 |  |
| % of revenue |  |  | 66.0 | % |  |  | 67.3 | % |  |  | 66.3 | % |  |  | 32.3 | % |  |  | 34.0 | % |  |  | 0.5 | % |  |  | 27.6 | % |

[0001193125-21-166614:8k_2_02:135]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-21-166614:8k_2_02:136]
CISCO SYSTEMS, INC.

[0001193125-21-166614:8k_2_02:137]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-166614:8k_2_02:138]
EFFECTIVE TAX RATE

[0001193125-21-166614:8k_2_02:139]
(In
percentages)

[0001193125-21-166614:8k_2_02:140]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | May 1,2021 |  |  | April 25,2020 |  |  | May 1,2021 |  |  | April 25,2020 |  |
| GAAP effective tax rate |  |  | 20.3 | % |  |  | 19.4 | % |  |  | 20.4 | % |  |  | 19.6 | % |
| Total adjustments to GAAP provision for income taxes |  |  | (1.3 | )% |  |  | 0.6 | % |  |  | (1.4 | )% |  |  | 0.4 | % |
| Non-GAAP effective tax rate |  |  | 19.0 | % |  |  | 20.0 | % |  |  | 19.0 | % |  |  | 20.0 | % |

[0001193125-21-166614:8k_2_02:141]
GAAP TO NON-GAAP GUIDANCE FOR Q4 FY 2021

[0001193125-21-166614:8k_2_02:142]
| Q4 FY 2021 |  | Gross Margin Rate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (1) |
| GAAP |  | 62% - 63% |  | 25.5% - 26.5% |  | 19% |  | $0.64 - $0.69 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.5% |  | — |  | $0.07 - $0.08 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 1.5% |  | 2.5% |  | — |  | $0.07 - $0.08 |
| Significant asset impairments and restructurings |  | — |  | 0.5% |  | — |  | $0.00 - $0.01 |
| Income tax effect of non-GAAP adjustments |  |  |  |  |  | — |  |  |
| Non-GAAP |  | 64% - 65% |  | 32% - 33% |  | 19% |  | $0.81 - $0.83 |

[0001193125-21-166614:8k_2_02:143]
| (1) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-21-166614:8k_2_02:144]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and significant
tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-21-166614:8k_2_02:145]
13

[0001193125-21-166614:8k_2_02:146]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-21-166614:8k_2_02:147]
This release includes non-GAAP net
income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin,
non-GAAP effective tax rates, non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the
periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-21-166614:8k_2_02:148]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with
generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any
comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as
determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-21-166614:8k_2_02:149]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP
measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-21-166614:8k_2_02:150]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other contingencies, gains and losses on equity investments, the
income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial
results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be other items that
Cisco may exclude for purposes of its internal budgeting process

[0001193125-21-166614:8k_2_02:151]
14

[0001193125-21-166614:8k_2_02:152]
and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures,
refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-21-166614:8k_2_02:153]
About
Cisco

[0001193125-21-166614:8k_2_02:154]
Cisco (Nasdaq: CSCO) is the worldwide leader in technology that powers the Internet. Cisco inspires new possibilities by reimagining
your applications, securing your data, transforming your infrastructure, and empowering your teams for a global and inclusive future. Discover more at newsroom.cisco.com and follow us on Twitter at @Cisco.

[0001193125-21-166614:8k_2_02:155]
Copyright © 2021 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are
trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their
respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-21-166614:8k_2_02:156]
RSS Feed for Cisco: https://newsroom.cisco.com/rss-feeds

[0001193125-21-166614:8k_2_02:157]
15
