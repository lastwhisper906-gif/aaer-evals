# CSCO notes — 0000858877-21-000008


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-21-000008:notes:1]
[same as prior period, unchanged from 0000858877-21-000004:notes:1]

[0000858877-21-000008:notes:2]
At our annual meeting of shareholders held on December 10, 2020, shareholders voted to approve changing our state of incorporation from California to Delaware. The reincorporation became effective January 25, 2021.

[0000858877-21-000008:notes:3]
We have prepared the accompanying financial data as of May 1, 2021 and for the third quarter and first nine months of fiscal 2021 and 2020, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 25, 2020 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 25, 2020.

[0000858877-21-000008:notes:4]
[same as prior period, unchanged from 0000858877-21-000004:notes:4]

[0000858877-21-000008:notes:5]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of May 1, 2021, the results of operations, the statements of comprehensive income (loss) and the statements of equity for the third quarter and first nine months of fiscal 2021 and 2020, and the statements of cash flows for the first nine months of fiscal 2021 and 2020, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2021 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-21-000008:notes:6]
[same as prior period, unchanged from 0000858877-21-000004:notes:6]

[0000858877-21-000008:notes:7]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-21-000008:notes:8]
[same as prior period, unchanged from 0000858877-21-000004:notes:8]

[0000858877-21-000008:notes:9]
[same as prior period, unchanged from 0000858877-21-000004:notes:9]

[0000858877-21-000008:notes:10]
[same as prior period, unchanged from 0000858877-21-000004:notes:10]

[0000858877-21-000008:notes:11]
[same as prior period, unchanged from 0000858877-21-000004:notes:11]

[0000858877-21-000008:notes:12]
[same as prior period, unchanged from 0000858877-21-000004:notes:12]

[0000858877-21-000008:notes:13]
[same as prior period, unchanged from 0000858877-21-000004:notes:13]

[0000858877-21-000008:notes:14]
[same as prior period, unchanged from 0000858877-21-000004:notes:14]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-21-000008:notes:15]
[same as prior period, unchanged from 0000858877-21-000004:notes:15]

[0000858877-21-000008:notes:16]
[same as prior period, unchanged from 0000858877-21-000004:notes:16]

[0000858877-21-000008:notes:17]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of May 1, 2021 and July 25, 2020 was $61 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-21-000008:notes:18]
[same as prior period, unchanged from 0000858877-21-000004:notes:18]

[0000858877-21-000008:notes:19]
[same as prior period, unchanged from 0000858877-21-000004:notes:19]

[0000858877-21-000008:notes:20]
[same as prior period, unchanged from 0000858877-21-000004:notes:20]

[0000858877-21-000008:notes:21]
[same as prior period, unchanged from 0000858877-21-000004:notes:21]

[0000858877-21-000008:notes:22]
[same as prior period, unchanged from 0000858877-21-000004:notes:22]

[0000858877-21-000008:notes:23]
[same as prior period, unchanged from 0000858877-21-000004:notes:23]

[0000858877-21-000008:notes:24]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,832 |  |  | $ | 6,447 |  |  | $ | 19,564 |  |  | $ | 20,566 |  |
| Applications | 1,426 |  |  | 1,363 |  |  | 4,160 |  |  | 4,211 |  |
| Security | 876 |  |  | 778 |  |  | 2,559 |  |  | 2,343 |  |
| Other Products | 6 |  |  | 9 |  |  | 15 |  |  | 27 |  |
| Total Product | 9,139 |  |  | 8,597 |  |  | 26,298 |  |  | 27,146 |  |
| Services | 3,664 |  |  | 3,386 |  |  | 10,394 |  |  | 10,001 |  |
| Total | $ | 12,803 |  |  | $ | 11,983 |  |  | $ | 36,692 |  |  | $ | 37,147 |  |

[0000858877-21-000008:notes:25]
[same as prior period, unchanged from 0000858877-21-000004:notes:25]

[0000858877-21-000008:notes:26]
[same as prior period, unchanged from 0000858877-21-000004:notes:26]

[0000858877-21-000008:notes:27]
[same as prior period, unchanged from 0000858877-21-000004:notes:27]

[0000858877-21-000008:notes:28]
[same as prior period, unchanged from 0000858877-21-000004:notes:28]

[0000858877-21-000008:notes:29]
[same as prior period, unchanged from 0000858877-21-000004:notes:29]

[0000858877-21-000008:notes:30]
[same as prior period, unchanged from 0000858877-21-000004:notes:30]

[0000858877-21-000008:notes:31]
[same as prior period, unchanged from 0000858877-21-000004:notes:31]

[0000858877-21-000008:notes:32]
[same as prior period, unchanged from 0000858877-21-000004:notes:32]

[0000858877-21-000008:notes:33]
[same as prior period, unchanged from 0000858877-21-000004:notes:33]

[0000858877-21-000008:notes:34]
Accounts receivable, net was $4.4 billion as of May 1, 2021 compared to $5.5 billion as of July 25, 2020, as reported on the Consolidated Balance Sheets.

[0000858877-21-000008:notes:35]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $1.3 billion and $1.2 billion as of May 1, 2021 and July 25, 2020, respectively, and were included in other current assets and other assets.

[0000858877-21-000008:notes:36]
[same as prior period, unchanged from 0000858877-21-000004:notes:36]

[0000858877-21-000008:notes:37]
|  | May 1,2021 |
| 1 to 4 | $ | 379 |  |
| 5 to 6 | 840 |  |
| 7 and Higher | 91 |  |
| Total | $ | 1,310 |  |

[0000858877-21-000008:notes:38]
Contract liabilities consist of deferred revenue. Deferred revenue was $20.9 billion as of May 1, 2021 compared to $20.4 billion as of July 25, 2020. We recognized approximately $2.6 billion and $9.5 billion of revenue during the third quarter and first nine months of fiscal 2021, respectively, that was included in the deferred revenue balance at July 25, 2020.

[0000858877-21-000008:notes:39]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $893 million and $732 million as of May 1, 2021 and July 25, 2020, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $134 million and $386 million for the third quarter and first nine months of fiscal 2021, respectively, and $118 million and $356 million for the corresponding periods of fiscal 2020, respectively, and was included in sales and marketing expenses.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-21-000008:notes:40]
[same as prior period, unchanged from 0000858877-21-000004:notes:40]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-21-000008:notes:41]
[same as prior period, unchanged from 0000858877-21-000004:notes:41]

[0000858877-21-000008:notes:42]
[same as prior period, unchanged from 0000858877-21-000004:notes:42]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-21-000008:notes:43]
Acquisitions and Divestitures
We completed eight acquisitions during the first nine months of fiscal 2021. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-21-000008:notes:44]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Acacia | $ | 4,983 |  |  | $ | 447 |  |  | $ | 2,160 |  |  | $ | 2,376 |  |
| Others | 1,739 |  |  | (101) |  |  | 567 |  |  | 1,273 |  |
| Total | $ | 6,722 |  |  | $ | 346 |  |  | $ | 2,727 |  |  | $ | 3,649 |  |

[0000858877-21-000008:notes:45]
On March 1, 2021, we completed our acquisition of Acacia Communications, Inc. (“Acacia”), a public fabless semiconductor company that develops, manufactures and sells high-speed coherent optical interconnect products that are designed to transform communications networks through improvements in performance, capacity and cost. Revenue from the Acacia acquisition has been included in our Infrastructure Platforms product category.

[0000858877-21-000008:notes:46]
The total purchase consideration related to our acquisitions completed during the first nine months of fiscal 2021 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $315 million. Total transaction costs related to acquisition and divestiture activities were $30 million and $13 million for the first nine months of fiscal 2021 and 2020, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-21-000008:notes:47]
The goodwill generated from acquisitions completed during the first nine months of fiscal 2021 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first nine months of fiscal 2021 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-21-000008:notes:48]
[same as prior period, unchanged from 0000858877-21-000004:notes:50]

[0000858877-21-000008:notes:49]
The following table presents the goodwill allocated to our reportable segments as of May 1, 2021 and during the first nine months of fiscal 2021 (in millions):

[0000858877-21-000008:notes:50]
|  | Balance at July 25, 2020 |  | Acquisitions & Divestitures |  | Foreign Currency Translation and Other |  | Balance at May 1, 2021 |
| Americas | $ | 21,304 |  |  | $ | 1,902 |  |  | $ | 157 |  |  | $ | 23,363 |  |
| EMEA | 8,040 |  |  | 869 |  |  | 59 |  |  | 8,968 |  |
| APJC | 4,462 |  |  | 863 |  |  | 34 |  |  | 5,359 |  |
| Total | $ | 33,806 |  |  | $ | 3,634 |  |  | $ | 250 |  |  | $ | 37,690 |  |

[0000858877-21-000008:notes:51]
[same as prior period, unchanged from 0000858877-21-000004:notes:53]

[0000858877-21-000008:notes:52]
The following table presents details of our intangible assets acquired through acquisitions completed during the first nine months of fiscal 2021 (in millions, except years):

[0000858877-21-000008:notes:53]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Acacia | 4.0 |  | $ | 1,290 |  |  | 4.0 |  | $ | 490 |  |  | 3.1 |  | $ | 35 |  |  | $ | 345 |  |  | $ | 2,160 |  |
| Others | 4.3 |  | 395 |  |  | 4.7 |  | 143 |  |  | 3.3 |  | 29 |  |  | — |  |  | 567 |  |
| Total |  |  | $ | 1,685 |  |  |  |  | $ | 633 |  |  |  |  | $ | 64 |  |  | $ | 345 |  |  | $ | 2,727 |  |

[0000858877-21-000008:notes:54]
[same as prior period, unchanged from 0000858877-21-000004:notes:56]

[0000858877-21-000008:notes:55]
| May 1, 2021 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,594 |  |  | $ | (1,348) |  |  | $ | 2,246 |  |
| Customer relationships |  | 1,364 |  |  | (460) |  |  | 904 |  |
| Other |  | 71 |  |  | (10) |  |  | 61 |  |
| Total purchased intangible assets with finite lives |  | 5,029 |  |  | (1,818) |  |  | 3,211 |  |
| In-process research and development, with indefinite lives |  | 505 |  |  | — |  |  | 505 |  |
| Total |  | $ | 5,534 |  |  | $ | (1,818) |  |  | $ | 3,716 |  |

[0000858877-21-000008:notes:56]
[same as prior period, unchanged from 0000858877-21-000004:notes:58]

[0000858877-21-000008:notes:57]
[same as prior period, unchanged from 0000858877-21-000004:notes:59]

[0000858877-21-000008:notes:58]
[same as prior period, unchanged from 0000858877-21-000004:notes:60]

[0000858877-21-000008:notes:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1, 2021 |  | April 25, 2020 |  | May 1, 2021 |  | April 25, 2020 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 187 |  |  | $ | 163 |  |  | $ | 513 |  |  | $ | 494 |  |
| Operating expenses | 61 |  |  | 34 |  |  | 136 |  |  | 108 |  |
| Total | $ | 248 |  |  | $ | 197 |  |  | $ | 649 |  |  | $ | 602 |  |

[0000858877-21-000008:notes:60]
The estimated future amortization expense of purchased intangible assets with finite lives as of May 1, 2021 is as follows (in millions):

[0000858877-21-000008:notes:61]
| Fiscal Year | Amount |
| 2021 (remaining three months) | $ | 288 |  |
| 2022 | $ | 986 |  |
| 2023 | $ | 829 |  |
| 2024 | $ | 705 |  |
| 2025 | $ | 355 |  |
| Thereafter | $ | 48 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-21-000008:notes:62]
Restructuring and Other Charges
We initiated a restructuring plan in the first quarter of fiscal 2021 (the “Fiscal 2021 Plan”), which includes a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $900 million. In connection with the Fiscal 2021 Plan, we incurred charges of $35 million and $869 million for the third quarter and first nine months of fiscal 2021, respectively.

[0000858877-21-000008:notes:63]
We initiated a restructuring plan in fiscal 2020 (the “Fiscal 2020 Plan”) in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $300 million. In connection with the Fiscal 2020 Plan, we have incurred cumulative charges of $264 million.

[0000858877-21-000008:notes:64]
[same as prior period, unchanged from 0000858877-21-000004:notes:66]

[0000858877-21-000008:notes:65]
[same as prior period, unchanged from 0000858877-21-000004:notes:67]

[0000858877-21-000008:notes:66]
|  |  | FISCAL 2020 AND PRIOR PLANS |  | FISCAL 2021 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 25, 2020 |  | $ | 58 |  |  | $ | 14 |  |  | $ | — |  |  | $ | — |  |  | $ | 72 |  |
| Charges |  | — |  |  | 9 |  |  | 828 |  |  | 41 |  |  | 878 |  |
| Cash payments |  | (58) |  |  | (5) |  |  | (801) |  |  | (4) |  |  | (868) |  |
| Non-cash items |  | — |  |  | (1) |  |  | — |  |  | (31) |  |  | (32) |  |
| Liability as of May 1, 2021 |  | $ | — |  |  | $ | 17 |  |  | $ | 27 |  |  | $ | 6 |  |  | $ | 50 |  |

[0000858877-21-000008:notes:67]
|  |  | FISCAL 2018 AND PRIOR PLANS |  | FISCAL 2020 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | Employee Severance |  | Other |  | Total |
| Liability as of July 27, 2019 |  | $ | 22 |  |  | $ | 11 |  |  | $ | — |  |  | $ | — |  |  | $ | 33 |  |
| Charges |  | 209 |  |  | 17 |  |  | 116 |  |  | 12 |  |  | 354 |  |
| Cash payments |  | (217) |  |  | (2) |  |  | (35) |  |  | (6) |  |  | (260) |  |
| Non-cash items |  | — |  |  | (23) |  |  | — |  |  | (6) |  |  | (29) |  |
| Liability as of April 25, 2020 |  | $ | 14 |  |  | $ | 3 |  |  | $ | 81 |  |  | $ | — |  |  | $ | 98 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-21-000008:notes:68]
[same as prior period, unchanged from 0000858877-21-000004:notes:70]

[0000858877-21-000008:notes:69]
|  |  | May 1,2021 |  | July 25,2020 |
| Cash and cash equivalents |  | $ | 7,350 |  |  | $ | 11,809 |  |
| Restricted cash included in other current assets |  | 6 |  |  | — |  |
| Restricted cash included in other assets |  | 3 |  |  | 3 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 7,359 |  |  | $ | 11,812 |  |

[0000858877-21-000008:notes:70]
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 723 |  |  | $ | 456 |  |
| Work in process |  | 37 |  |  | 25 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales |  | 73 |  |  | 59 |  |
| Manufactured finished goods |  | 546 |  |  | 542 |  |
| Total finished goods |  | 619 |  |  | 601 |  |
| Service-related spares |  | 188 |  |  | 184 |  |
| Demonstration systems |  | 12 |  |  | 16 |  |
| Total |  | $ | 1,579 |  |  | $ | 1,282 |  |

[0000858877-21-000008:notes:71]
Our provision for inventory was $91 million and $49 million for the first nine months of fiscal 2021 and 2020, respectively.

[0000858877-21-000008:notes:72]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,309 |  |  | $ | 4,252 |  |
| Computer equipment and related software |  | 867 |  |  | 875 |  |
| Production, engineering, and other equipment |  | 5,146 |  |  | 5,163 |  |
| Operating lease assets |  | 311 |  |  | 337 |  |
| Furniture, fixtures and other |  | 376 |  |  | 387 |  |
| Total gross property and equipment |  | 11,009 |  |  | 11,014 |  |
| Less: accumulated depreciation and amortization |  | (8,642) |  |  | (8,561) |  |
| Total |  | $ | 2,367 |  |  | $ | 2,453 |  |

[0000858877-21-000008:notes:73]
| Deferred revenue: |  |  |  |  |
| Product |  | $ | 8,698 |  |  | $ | 7,895 |  |
| Service |  | 12,191 |  |  | 12,551 |  |
| Total |  | $ | 20,889 |  |  | $ | 20,446 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 11,492 |  |  | $ | 11,406 |  |
| Noncurrent |  | 9,397 |  |  | 9,040 |  |
| Total |  | $ | 20,889 |  |  | $ | 20,446 |  |

[0000858877-21-000008:notes:74]
| Remaining Performance Obligations: |  |  |  |  |
| Product |  | $ | 11,903 |  |  | $ | 11,261 |  |
| Service |  | 16,235 |  |  | 17,093 |  |
| Total |  | $ | 28,138 |  |  | $ | 28,354 |  |

[0000858877-21-000008:notes:75]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of May 1, 2021, the aggregate amount of RPO was comprised of $20.9 billion of deferred revenue and $7.2 billion of unbilled contract revenue. We expect approximately 53% of this amount to be recognized as revenue over the next 12 months. As of July 25, 2020, the aggregate amount of RPO was comprised of $20.4 billion of deferred revenue and $7.9 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000858877-21-000008:notes:76]
Leases 
(a)Lessee Arrangements

[0000858877-21-000008:notes:77]
The following table presents our operating lease balances (in millions):

[0000858877-21-000008:notes:78]
|  | Balance Sheet Line Item |  | May 1, 2021 |  | July 25, 2020 |
| Operating lease right-of-use assets | Other assets |  | $ | 928 |  |  | $ | 921 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 335 |  |  | $ | 341 |  |
| Operating lease liabilities | Other long-term liabilities |  | 671 |  |  | 661 |  |
| Total operating lease liabilities |  |  | $ | 1,006 |  |  | $ | 1,002 |  |

[0000858877-21-000008:notes:79]
The components of our lease expenses were as follows (in millions):

[0000858877-21-000008:notes:80]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1, 2021 |  | April 25, 2020 |  | May 1, 2021 |  | April 25, 2020 |
| Operating lease expense | $ | 105 |  |  | $ | 101 |  |  | $ | 306 |  |  | $ | 315 |  |
| Short-term lease expense | 14 |  |  | 18 |  |  | 49 |  |  | 51 |  |
| Variable lease expense | 42 |  |  | 37 |  |  | 131 |  |  | 116 |  |
| Total lease expense | $ | 161 |  |  | $ | 156 |  |  | $ | 486 |  |  | $ | 482 |  |

[0000858877-21-000008:notes:81]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-21-000008:notes:82]
|  | Nine Months Ended |
|  | May 1, 2021 |  | April 25, 2020 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 306 |  |  | $ | 309 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 270 |  |  | $ | 120 |  |

[0000858877-21-000008:notes:83]
The weighted-average lease term was 4.1 years and 4.0 years as of May 1, 2021 and July 25, 2020, respectively. The weighted-average discount rate was 0.9% and 1.5% as of May 1, 2021 and July 25, 2020, respectively.

[0000858877-21-000008:notes:84]
The maturities of our operating leases (undiscounted) as of May 1, 2021 are as follows (in millions):

[0000858877-21-000008:notes:85]
| Fiscal Year | Amount |
| 2021 (remaining three months) | $ | 95 |  |
| 2022 | 321 |  |
| 2023 | 245 |  |
| 2024 | 161 |  |
| 2025 | 96 |  |
| Thereafter | 107 |  |
| Total lease payments | 1,025 |  |
| Less interest | (19) |  |
| Total | $ | 1,006 |  |

[0000858877-21-000008:notes:86]
(b)Lessor Arrangements

[0000858877-21-000008:notes:87]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income for the third quarter and first nine months of fiscal 2021 was $19 million and $59 million, respectively, and $23 million and $72 million for the corresponding periods of fiscal 2020, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-21-000008:notes:88]
Future minimum lease payments on our lease receivables as of May 1, 2021 are summarized as follows (in millions):

[0000858877-21-000008:notes:89]
| Fiscal Year | Amount |
| 2021 (remaining three months) | $ | 77 |  |
| 2022 | 727 |  |
| 2023 | 467 |  |
| 2024 | 272 |  |
| 2025 | 151 |  |
| Thereafter | 38 |  |
| Total | 1,732 |  |
| Less: Present value of lease payments | 1,642 |  |
| Unearned income | $ | 90 |  |

[0000858877-21-000008:notes:90]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-21-000008:notes:91]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-21-000008:notes:92]
|  | May 1, 2021 |  | July 25, 2020 |
| Operating lease assets | $ | 311 |  |  | $ | 337 |  |
| Accumulated depreciation | (187) |  |  | (198) |  |
| Operating lease assets, net | $ | 124 |  |  | $ | 139 |  |

[0000858877-21-000008:notes:93]
Our operating lease income for the third quarter and first nine months of fiscal 2021 was $36 million and $119 million, respectively, and $49 million and $143 million for the corresponding periods of fiscal 2020, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-21-000008:notes:94]
Minimum future rentals on noncancelable operating leases as of May 1, 2021 are summarized as follows (in millions):

[0000858877-21-000008:notes:95]
| Fiscal Year | Amount |
| 2021 (remaining three months) | $ | 23 |  |
| 2022 | 46 |  |
| 2023 | 23 |  |
| 2024 | 5 |  |
| Total | $ | 97 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-21-000008:notes:96]
[same as prior period, unchanged from 0000858877-21-000004:notes:98]

[0000858877-21-000008:notes:97]
[same as prior period, unchanged from 0000858877-21-000004:notes:99]

[0000858877-21-000008:notes:98]
[same as prior period, unchanged from 0000858877-21-000004:notes:100]

[0000858877-21-000008:notes:99]
| May 1, 2021 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 1,732 |  |  | $ | 5,638 |  |  | $ | 2,461 |  |  | $ | 9,831 |  |
| Residual value | 111 |  |  | — |  |  | — |  |  | 111 |  |
| Unearned income | (90) |  |  | — |  |  | — |  |  | (90) |  |
| Allowance for credit loss | (40) |  |  | (91) |  |  | (5) |  |  | (136) |  |
| Total, net | $ | 1,713 |  |  | $ | 5,547 |  |  | $ | 2,456 |  |  | $ | 9,716 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 783 |  |  | $ | 2,609 |  |  | $ | 1,256 |  |  | $ | 4,648 |  |
| Noncurrent | 930 |  |  | 2,938 |  |  | 1,200 |  |  | 5,068 |  |
| Total, net | $ | 1,713 |  |  | $ | 5,547 |  |  | $ | 2,456 |  |  | $ | 9,716 |  |

[0000858877-21-000008:notes:100]
[same as prior period, unchanged from 0000858877-21-000004:notes:102]

[0000858877-21-000008:notes:101]
[same as prior period, unchanged from 0000858877-21-000004:notes:103]

[0000858877-21-000008:notes:102]
Gross financing receivables(1) categorized by our internal credit risk rating by period of origination as of May 1, 2021 are summarized as follows (in millions):

[0000858877-21-000008:notes:103]
|  |  |  | Fiscal Year |  | Nine Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 29, 2017 |  | July 28, 2018 |  | July 27, 2019 |  | July 25, 2020 |  | May 1, 2021 |  | Total |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 5 |  |  | $ | 34 |  |  | $ | 126 |  |  | $ | 209 |  |  | $ | 292 |  |  | $ | 101 |  |  | $ | 767 |  |
| 5 to 6 | 7 |  |  | 29 |  |  | 92 |  |  | 227 |  |  | 324 |  |  | 154 |  |  | 833 |  |
| 7 and Higher | 1 |  |  | 2 |  |  | 4 |  |  | 11 |  |  | 20 |  |  | 4 |  |  | 42 |  |
| Total Lease Receivables | $ | 13 |  |  | $ | 65 |  |  | $ | 222 |  |  | $ | 447 |  |  | $ | 636 |  |  | $ | 259 |  |  | $ | 1,642 |  |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 7 |  |  | $ | 114 |  |  | $ | 321 |  |  | $ | 672 |  |  | $ | 1,134 |  |  | $ | 1,377 |  |  | $ | 3,625 |  |
| 5 to 6 | 3 |  |  | 33 |  |  | 112 |  |  | 270 |  |  | 596 |  |  | 855 |  |  | 1,869 |  |
| 7 and Higher | 1 |  |  | 3 |  |  | 6 |  |  | 57 |  |  | 49 |  |  | 28 |  |  | 144 |  |
| Total Loan Receivables | $ | 11 |  |  | $ | 150 |  |  | $ | 439 |  |  | $ | 999 |  |  | $ | 1,779 |  |  | $ | 2,260 |  |  | $ | 5,638 |  |
| Financed Service Contracts: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 1 |  |  | $ | 42 |  |  | $ | 33 |  |  | $ | 144 |  |  | $ | 316 |  |  | $ | 951 |  |  | $ | 1,487 |  |
| 5 to 6 | — |  |  | 13 |  |  | 37 |  |  | 151 |  |  | 349 |  |  | 400 |  |  | 950 |  |
| 7 and Higher | — |  |  | — |  |  | 1 |  |  | 9 |  |  | 10 |  |  | 4 |  |  | 24 |  |
| Total Financed Service Contracts | $ | 1 |  |  | $ | 55 |  |  | $ | 71 |  |  | $ | 304 |  |  | $ | 675 |  |  | $ | 1,355 |  |  | $ | 2,461 |  |
| Total | $ | 25 |  |  | $ | 270 |  |  | $ | 732 |  |  | $ | 1,750 |  |  | $ | 3,090 |  |  | $ | 3,874 |  |  | $ | 9,741 |  |

[0000858877-21-000008:notes:104]
(1) Lease receivables calculated as gross lease receivables, excluding residual value, less unearned income.

[0000858877-21-000008:notes:105]
The following table summarizes our gross receivables categorized by our internal credit risk rating as of July 25, 2020 and was not restated to reflect the impact of adoption of the accounting standards update on Credit Losses on Financial Instruments:

[0000858877-21-000008:notes:106]
[same as prior period, unchanged from 0000858877-21-000004:notes:108]

[0000858877-21-000008:notes:107]
The following tables present the aging analysis of gross receivables as of May 1, 2021 and July 25, 2020 (in millions):

[0000858877-21-000008:notes:108]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| May 1, 2021 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 23 |  |  | $ | 16 |  |  | $ | 47 |  |  | $ | 86 |  |  | $ | 1,556 |  |  | $ | 1,642 |  |  | $ | 13 |  |  | $ | 28 |  |  | $ | 28 |  |
| Loan receivables | 91 |  |  | 12 |  |  | 53 |  |  | 156 |  |  | 5,482 |  |  | 5,638 |  |  | 8 |  |  | 39 |  |  | 39 |  |
| Financed service contracts | 68 |  |  | 6 |  |  | 53 |  |  | 127 |  |  | 2,334 |  |  | 2,461 |  |  | 14 |  |  | 3 |  |  | 3 |  |
| Total | $ | 182 |  |  | $ | 34 |  |  | $ | 153 |  |  | $ | 369 |  |  | $ | 9,372 |  |  | $ | 9,741 |  |  | $ | 35 |  |  | $ | 70 |  |  | $ | 70 |  |

[0000858877-21-000008:notes:109]
[same as prior period, unchanged from 0000858877-21-000004:notes:111]

[0000858877-21-000008:notes:110]
[same as prior period, unchanged from 0000858877-21-000004:notes:112]

[0000858877-21-000008:notes:111]
[same as prior period, unchanged from 0000858877-21-000004:notes:113]

[0000858877-21-000008:notes:112]
[same as prior period, unchanged from 0000858877-21-000004:notes:114]

[0000858877-21-000008:notes:113]
[same as prior period, unchanged from 0000858877-21-000004:notes:115]

[0000858877-21-000008:notes:114]
| Three months ended May 1, 2021 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of January 23, 2021 | $ | 43 |  |  | $ | 96 |  |  | $ | 9 |  |  | $ | 148 |  |
| Provisions (benefits) | (2) |  |  | (4) |  |  | (4) |  |  | (10) |  |
| Recoveries (write-offs), net | (1) |  |  | (1) |  |  | — |  |  | (2) |  |
| Other | — |  |  | — |  |  | — |  |  | — |  |
| Allowance for credit loss as of May 1, 2021 | $ | 40 |  |  | $ | 91 |  |  | $ | 5 |  |  | $ | 136 |  |

[0000858877-21-000008:notes:115]
| Nine months ended May 1, 2021 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 25, 2020 | $ | 48 |  |  | $ | 81 |  |  | $ | 9 |  |  | $ | 138 |  |
| Provisions (benefits) | (9) |  |  | (7) |  |  | (3) |  |  | (19) |  |
| Recoveries (write-offs), net | (1) |  |  | (1) |  |  | — |  |  | (2) |  |
| Other | 2 |  |  | 18 |  |  | (1) |  |  | 19 |  |
| Allowance for credit loss as of May 1, 2021 | $ | 40 |  |  | $ | 91 |  |  | $ | 5 |  |  | $ | 136 |  |

[0000858877-21-000008:notes:116]
| Three months ended April 25, 2020 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of January 25, 2020 | $ | 42 |  |  | $ | 95 |  |  | $ | 8 |  |  | $ | 145 |  |
| Provisions (benefits) | (4) |  |  | (5) |  |  | (2) |  |  | (11) |  |
| Recoveries (write-offs), net | (1) |  |  | (1) |  |  | — |  |  | (2) |  |
| Foreign exchange and other | (1) |  |  | (3) |  |  | — |  |  | (4) |  |
| Allowance for credit loss as of April 25, 2020 | $ | 36 |  |  | $ | 86 |  |  | $ | 6 |  |  | $ | 128 |  |

[0000858877-21-000008:notes:117]
| Nine months ended April 25, 2020 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 27, 2019 | $ | 46 |  |  | $ | 71 |  |  | $ | 9 |  |  | $ | 126 |  |
| Provisions (benefits) | (8) |  |  | 37 |  |  | (2) |  |  | 27 |  |
| Recoveries (write-offs), net | (2) |  |  | (18) |  |  | — |  |  | (20) |  |
| Foreign exchange and other | — |  |  | (4) |  |  | (1) |  |  | (5) |  |
| Allowance for credit loss as of April 25, 2020 | $ | 36 |  |  | $ | 86 |  |  | $ | 6 |  |  | $ | 128 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-21-000008:notes:118]
Available-for-Sale Debt and Equity Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-21-000008:notes:119]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-21-000008:notes:120]
| May 1, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,881 |  |  | $ | 22 |  |  | $ | — |  |  | $ | 1,903 |  |
| U.S. government agency securities | 167 |  |  | — |  |  | — |  |  | 167 |  |
| Non-U.S. government and agency securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Corporate debt securities | 9,329 |  |  | 218 |  |  | (35) |  |  | 9,512 |  |
| U.S. agency mortgage-backed securities | 2,788 |  |  | 35 |  |  | (13) |  |  | 2,810 |  |
| Commercial paper | 1,333 |  |  | — |  |  | — |  |  | 1,333 |  |
| Certificates of deposit | 440 |  |  | — |  |  | — |  |  | 440 |  |
| Total (1) | $ | 15,941 |  |  | $ | 275 |  |  | $ | (48) |  |  | $ | 16,168 |  |

[0000858877-21-000008:notes:121]
| July 25, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 2,614 |  |  | $ | 71 |  |  | $ | — |  |  | $ | 2,685 |  |
| U.S. government agency securities | 110 |  |  | — |  |  | — |  |  | 110 |  |
| Corporate debt securities | 11,549 |  |  | 334 |  |  | (6) |  |  | 11,877 |  |
| U.S. agency mortgage-backed securities | 1,987 |  |  | 49 |  |  | (1) |  |  | 2,035 |  |
| Commercial paper | 727 |  |  | — |  |  | — |  |  | 727 |  |
| Certificates of deposit | 176 |  |  | — |  |  | — |  |  | 176 |  |
| Total | $ | 17,163 |  |  | $ | 454 |  |  | $ | (7) |  |  | $ | 17,610 |  |

[0000858877-21-000008:notes:122]
(1) Net unsettled investment sales were $262 million as of May 1, 2021 and were included in other current assets.

[0000858877-21-000008:notes:123]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-21-000008:notes:124]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1, 2021 |  | April 25, 2020 |  | May 1, 2021 |  | April 25, 2020 |
| Gross realized gains | $ | 24 |  |  | $ | 20 |  |  | $ | 48 |  |  | $ | 45 |  |
| Gross realized losses | (2) |  |  | (21) |  |  | (2) |  |  | (25) |  |
| Total | $ | 22 |  |  | $ | (1) |  |  | $ | 46 |  |  | $ | 20 |  |

[0000858877-21-000008:notes:125]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at May 1, 2021 and July 25, 2020 (in millions):

[0000858877-21-000008:notes:126]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| May 1, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 468 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 468 |  |  | $ | — |  |
| U.S. government agency securities | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |
| Corporate debt securities | 1,242 |  |  | (10) |  |  | 6 |  |  | — |  |  | 1,248 |  |  | (10) |  |
| U.S. agency mortgage-backed securities | 1,618 |  |  | (13) |  |  | — |  |  | — |  |  | 1,618 |  |  | (13) |  |
| Commercial paper | 46 |  |  | — |  |  | — |  |  | — |  |  | 46 |  |  | — |  |
| Certificates of deposit | 16 |  |  | — |  |  | — |  |  | — |  |  | 16 |  |  | — |  |
| Total | $ | 3,416 |  |  | $ | (23) |  |  | $ | 6 |  |  | $ | — |  |  | $ | 3,422 |  |  | $ | (23) |  |

[0000858877-21-000008:notes:127]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 25, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government agency securities | $ | 33 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 33 |  |  | $ | — |  |
| Corporate debt securities | 1,060 |  |  | (6) |  |  | 3 |  |  | — |  |  | 1,063 |  |  | (6) |  |
| U.S. agency mortgage-backed securities | 265 |  |  | (1) |  |  | — |  |  | — |  |  | 265 |  |  | (1) |  |
| Total | $ | 1,358 |  |  | $ | (7) |  |  | $ | 3 |  |  | $ | — |  |  | $ | 1,361 |  |  | $ | (7) |  |

[0000858877-21-000008:notes:128]
The following table summarizes the maturities of our available-for-sale debt investments as of May 1, 2021 (in millions):

[0000858877-21-000008:notes:129]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 5,608 |  |  | $ | 5,605 |  |
| After 1 year through 5 years | 6,296 |  |  | 6,428 |  |
| After 5 years through 10 years | 1,244 |  |  | 1,318 |  |
| After 10 years | 5 |  |  | 7 |  |
| Mortgage-backed securities with no single maturity | 2,788 |  |  | 2,810 |  |
| Total | $ | 15,941 |  |  | $ | 16,168 |  |

[0000858877-21-000008:notes:130]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-21-000008:notes:131]
(b)Summary of Equity Investments

[0000858877-21-000008:notes:132]
Our net unrealized gains recognized during the reporting period on our marketable securities still held as of May 1, 2021 was $3 million for each of the third quarter and first nine months of fiscal 2021. Our net adjustments to non-marketable equity securities measured using the measurement alternative was a net loss of $3 million and a net gain of $1 million for the third quarter and first nine months of fiscal 2021, respectively. These adjustments were net losses of $4 million and $1 million for the corresponding periods of fiscal 2020, respectively. We held equity interests in certain private equity funds of $0.8 billion and $0.7 billion as of May 1, 2021 and July 25, 2020, respectively, which are accounted for under the NAV practical expedient.

[0000858877-21-000008:notes:133]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of May 1, 2021, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-21-000008:notes:134]
The carrying value of our investments in privately held companies was $1.4 billion and $1.3 billion as of May 1, 2021 and July 25, 2020, respectively. 
Of the total carrying value of our investments in privately held companies as of May 1, 2021, $0.8 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of May 1, 2021, we have total funding commitments of $0.2 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-21-000008:notes:135]
Fair Value 
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, we consider the principal or most advantageous market in which we would transact, and we also consider assumptions that market participants would use when pricing the asset or liability.

[0000858877-21-000008:notes:136]
(a)Fair Value Hierarchy

[0000858877-21-000008:notes:137]
[same as prior period, unchanged from 0000858877-21-000004:notes:139]

[0000858877-21-000008:notes:138]
[same as prior period, unchanged from 0000858877-21-000004:notes:140]

[0000858877-21-000008:notes:139]
[same as prior period, unchanged from 0000858877-21-000004:notes:141]

[0000858877-21-000008:notes:140]
[same as prior period, unchanged from 0000858877-21-000004:notes:142]

[0000858877-21-000008:notes:141]
[same as prior period, unchanged from 0000858877-21-000004:notes:143]

[0000858877-21-000008:notes:142]
[same as prior period, unchanged from 0000858877-21-000004:notes:144]

[0000858877-21-000008:notes:143]
|  | MAY 1, 2021 |  | JULY 25, 2020 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,698 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,698 |  |  | $ | 10,024 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,024 |  |
| Corporate debt securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Commercial paper | — |  |  | 100 |  |  | — |  |  | 100 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 1,903 |  |  | — |  |  | 1,903 |  |  | — |  |  | 2,685 |  |  | — |  |  | 2,685 |  |
| U.S. government agency securities | — |  |  | 167 |  |  | — |  |  | 167 |  |  | — |  |  | 110 |  |  | — |  |  | 110 |  |
| Non-U.S. government and agency securities | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities | — |  |  | 9,512 |  |  | — |  |  | 9,512 |  |  | — |  |  | 11,877 |  |  | — |  |  | 11,877 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,810 |  |  | — |  |  | 2,810 |  |  | — |  |  | 2,035 |  |  | — |  |  | 2,035 |  |
| Commercial paper | — |  |  | 1,333 |  |  | — |  |  | 1,333 |  |  | — |  |  | 727 |  |  | — |  |  | 727 |  |
| Certificates of deposit | — |  |  | 440 |  |  | — |  |  | 440 |  |  | — |  |  | 176 |  |  | — |  |  | 176 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 61 |  |  | — |  |  | — |  |  | 61 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative assets | — |  |  | 134 |  |  | 6 |  |  | 140 |  |  | — |  |  | 190 |  |  | 1 |  |  | 191 |  |
| Total | $ | 4,759 |  |  | $ | 16,402 |  |  | $ | 6 |  |  | $ | 21,167 |  |  | $ | 10,024 |  |  | $ | 17,808 |  |  | $ | 1 |  |  | $ | 27,833 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 16 |  |  | $ | — |  |  | $ | 16 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Total | $ | — |  |  | $ | 16 |  |  | $ | — |  |  | $ | 16 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |

[0000858877-21-000008:notes:144]
Level 1 marketable securities are determined by using quoted prices in active markets for identical assets. Level 2 available-for-sale debt investments are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of these assets and liabilities. We use such pricing data as the primary input to make our assessments and determinations as to the ultimate valuation of our investment portfolio and have not made, during the periods presented, any material adjustments to such inputs. We are ultimately responsible for the financial statements and underlying estimates. Our derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs. We did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented. Level 3 assets include certain derivative instruments, the values of which are determined based on discounted cash flow models using inputs that we could not corroborate with market data.

[0000858877-21-000008:notes:145]
[same as prior period, unchanged from 0000858877-21-000004:notes:148]

[0000858877-21-000008:notes:146]
[same as prior period, unchanged from 0000858877-21-000004:notes:149]

[0000858877-21-000008:notes:147]
[same as prior period, unchanged from 0000858877-21-000004:notes:150]

[0000858877-21-000008:notes:148]
The fair value of our short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables and financed service contracts as of May 1, 2021 
and July 25, 2020 was $4.1 billion and $4.5 billion, respectively. The estimated fair value of our long-term loan receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.As of May 1, 2021, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of May 1, 2021, the fair value of our senior notes was $13.5 billion with a carrying amount of $11.5 billion. This compares to a fair value of $17.4 billion and a carrying amount of $14.6 billion as of July 25, 2020. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:DebtDisclosureTextBlock

[0000858877-21-000008:notes:149]
Borrowings 
(a)Short-Term Debt

[0000858877-21-000008:notes:150]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-21-000008:notes:151]
|  | May 1, 2021 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 2,000 |  |  | 1.90 | % |  | $ | 3,005 |  |  | 2.07 | % |

[0000858877-21-000008:notes:152]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of May 1, 2021 and July 25, 2020.

[0000858877-21-000008:notes:153]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-21-000008:notes:154]
(b)Long-Term Debt

[0000858877-21-000008:notes:155]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-21-000008:notes:156]
|  |  |  | May 1, 2021 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | — |  |  | — |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | — |  |  | — |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.15% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.00% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.31% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 11,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (81) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 113 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 11,532 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 2,000 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,532 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 11,532 |  |  |  |  | $ | 14,583 |  |  |  |

[0000858877-21-000008:notes:157]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $2.0 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (“LIBOR”). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-21-000008:notes:158]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of May 1, 2021, we were in compliance with all debt covenants.

[0000858877-21-000008:notes:159]
As of May 1, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-21-000008:notes:160]
| Fiscal Year | Amount |
| 2021 (remaining three months) | $ | — |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 11,500 |  |

[0000858877-21-000008:notes:161]
(c)Credit Facility

[0000858877-21-000008:notes:162]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. The credit agreement is structured as an amendment and restatement of our 364-day credit agreement, which would have terminated on May 14, 2021. As of May 1, 2021, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the 364-day credit facility.

[0000858877-21-000008:notes:163]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-21-000008:notes:164]
[same as prior period, unchanged from 0000858877-21-000004:notes:166]

[0000858877-21-000008:notes:165]
[same as prior period, unchanged from 0000858877-21-000004:notes:167]

[0000858877-21-000008:notes:166]
[same as prior period, unchanged from 0000858877-21-000004:notes:168]

[0000858877-21-000008:notes:167]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | May 1,2021 |  | July 25,2020 |  | Balance Sheet Line Item |  | May 1,2021 |  | July 25,2020 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 9 |  |  | $ | 7 |  |  | Other current liabilities |  | $ | 3 |  |  | $ | 2 |  |
| Foreign currency derivatives | Other assets |  | 3 |  |  | — |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other current assets |  | — |  |  | 6 |  |  | Other current liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other assets |  | 116 |  |  | 169 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 128 |  |  | 182 |  |  |  |  | 3 |  |  | 2 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 6 |  |  | 8 |  |  | Other current liabilities |  | 10 |  |  | 8 |  |
| Foreign currency derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 3 |  |  | — |  |
| Equity derivatives | Other assets |  | 6 |  |  | 1 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 12 |  |  | 9 |  |  |  |  | 13 |  |  | 8 |  |
| Total |  |  | $ | 140 |  |  | $ | 191 |  |  |  |  | $ | 16 |  |  | $ | 10 |  |

[0000858877-21-000008:notes:168]
[same as prior period, unchanged from 0000858877-21-000004:notes:170]

[0000858877-21-000008:notes:169]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | May 1,2021 |  | July 25,2020 |  | May 1,2021 |  | July 25,2020 |
| Short-term debt |  | $ | — |  |  | $ | (506) |  |  | $ | — |  |  | $ | (6) |  |
| Long-term debt |  | $ | (2,109) |  |  | $ | (2,159) |  |  | $ | (113) |  |  | $ | (165) |  |

[0000858877-21-000008:notes:170]
[same as prior period, unchanged from 0000858877-21-000004:notes:172]

[0000858877-21-000008:notes:171]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | May 1, 2021 |  | April 25, 2020 |  | May 1, 2021 |  | April 25, 2020 |
| Interest rate derivatives: |  |  |  |  |  |  |  |  |
| Hedged items |  | $ | 25 |  |  | $ | (87) |  |  | $ | 58 |  |  | $ | (101) |  |
| Derivatives designated as hedging instruments |  | (25) |  |  | 89 |  |  | (59) |  |  | 105 |  |
| Total |  | $ | — |  |  | $ | 2 |  |  | $ | (1) |  |  | $ | 4 |  |

[0000858877-21-000008:notes:172]
[same as prior period, unchanged from 0000858877-21-000004:notes:174]

[0000858877-21-000008:notes:173]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES) FOR THENINE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (12) |  |  | $ | (47) |  |  | $ | 35 |  |  | $ | (56) |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | 45 |  |  | (104) |  |  | 144 |  |  | (63) |  |
| Equity derivatives |  | Other income (loss), net |  | 5 |  |  | (6) |  |  | 19 |  |  | (1) |  |
| Total |  |  |  | $ | 38 |  |  | $ | (157) |  |  | $ | 198 |  |  | $ | (120) |  |

[0000858877-21-000008:notes:174]
[same as prior period, unchanged from 0000858877-21-000004:notes:176]

[0000858877-21-000008:notes:175]
|  | May 1,2021 |  | July 25,2020 |
| Foreign currency derivatives | $ | 4,054 |  |  | $ | 4,315 |  |
| Interest rate derivatives | 2,000 |  |  | 2,500 |  |
| Total return swaps—deferred compensation | 739 |  |  | 580 |  |
| Total | $ | 6,793 |  |  | $ | 7,395 |  |

[0000858877-21-000008:notes:176]
[same as prior period, unchanged from 0000858877-21-000004:notes:178]

[0000858877-21-000008:notes:177]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty. As of May 1, 2021 and July 25, 2020, the potential effects of these rights of set-off associated with the derivative contracts would be a reduction to both derivative assets and derivative liabilities of $16 million and $10 million, respectively.

[0000858877-21-000008:notes:178]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral received as of May 1, 2021 and July 25, 2020 was $115 million and $173 million, respectively. Including the effects of collateral, this results in a net derivative asset of $8 million as of each of May 1, 2021 and July 25, 2020.

[0000858877-21-000008:notes:179]
[same as prior period, unchanged from 0000858877-21-000004:notes:181]

[0000858877-21-000008:notes:180]
[same as prior period, unchanged from 0000858877-21-000004:notes:182]

[0000858877-21-000008:notes:181]
[same as prior period, unchanged from 0000858877-21-000004:notes:183]

[0000858877-21-000008:notes:182]
[same as prior period, unchanged from 0000858877-21-000004:notes:184]

[0000858877-21-000008:notes:183]
[same as prior period, unchanged from 0000858877-21-000004:notes:185]

[0000858877-21-000008:notes:184]
[same as prior period, unchanged from 0000858877-21-000004:notes:186]

[0000858877-21-000008:notes:185]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt  We hold interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2022 through 2025. Under these interest rate swaps, we receive fixed-rate interest payments and make interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.

[0000858877-21-000008:notes:186]
[same as prior period, unchanged from 0000858877-21-000004:notes:188]

[0000858877-21-000008:notes:187]
[same as prior period, unchanged from 0000858877-21-000004:notes:189]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-21-000008:notes:188]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-21-000008:notes:189]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-21-000008:notes:190]
The following table summarizes our purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-21-000008:notes:191]
| Commitments by Period | May 1,2021 |  | July 25,2020 |
| Less than 1 year | $ | 6,461 |  |  | $ | 3,994 |  |
| 1 to 3 years | 1,615 |  |  | 412 |  |
| 3 to 5 years | 1,733 |  |  | — |  |
| Total | $ | 9,809 |  |  | $ | 4,406 |  |

[0000858877-21-000008:notes:192]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of May 1, 2021 and July 25, 2020, the liability for these purchase commitments was $129 million and $141 million, respectively, and was included in other current liabilities. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $35 million and $131 million for the first nine months of fiscal 2021 and 2020, respectively.

[0000858877-21-000008:notes:193]
(b)Other Commitments

[0000858877-21-000008:notes:194]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-21-000008:notes:195]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-21-000008:notes:196]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1, 2021 |  | April 25, 2020 |  | May 1, 2021 |  | April 25, 2020 |
| Compensation expense related to acquisitions | $ | 66 |  |  | $ | 61 |  |  | $ | 182 |  |  | $ | 172 |  |

[0000858877-21-000008:notes:197]
As of May 1, 2021, we estimated that future cash compensation expense of up to $616 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-21-000008:notes:198]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.2 billion and $0.3 billion as of May 1, 2021 and July 25, 2020, respectively.

[0000858877-21-000008:notes:199]
(c)Product Warranties

[0000858877-21-000008:notes:200]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-21-000008:notes:201]
|  | Nine Months Ended |
|  | May 1,2021 |  | April 25,2020 |
| Balance at beginning of period | $ | 331 |  |  | $ | 342 |  |
| Provisions for warranties issued | 382 |  |  | 423 |  |
| Adjustments for pre-existing warranties | 1 |  |  | (5) |  |
| Settlements | (373) |  |  | (436) |  |
| Balance at end of period | $ | 341 |  |  | $ | 324 |  |

[0000858877-21-000008:notes:202]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-21-000008:notes:203]
(d)Financing and Other Guarantees

[0000858877-21-000008:notes:204]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-21-000008:notes:205]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. During fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.6 billion and $6.3 billion for the third quarter of fiscal 2021 and 2020, respectively, and was $19.5 billion and $20.5 billion for the first nine months of fiscal 2021 and 2020, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.1 billion as of May 1, 2021 and July 25, 2020, respectively.

[0000858877-21-000008:notes:206]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $1 million and $2 million for the third quarter of fiscal 2021 and 2020, respectively, and was $8 million for each of the first nine months of fiscal 2021 and 2020.

[0000858877-21-000008:notes:207]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at May 1, 2021 and July 25, 2020, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-21-000008:notes:208]
|  | May 1,2021 |  | July 25,2020 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 165 |  |  | $ | 198 |  |
| End user | 6 |  |  | 9 |  |
| Total | $ | 171 |  |  | $ | 207 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (16) |  |  | $ | (19) |  |
| End user | (6) |  |  | (9) |  |
| Total | $ | (22) |  |  | $ | (28) |  |
| Total | $ | 149 |  |  | $ | 179 |  |

[0000858877-21-000008:notes:209]
(e)Indemnifications

[0000858877-21-000008:notes:210]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-21-000008:notes:211]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations discussed in this section (e) due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these cases, and the unique facts and circumstances involved in each particular case and agreement. We are unable to reasonably estimate the ultimate outcome of the cases discussed below in this section (e), but we do not believe that any potential indemnity liability would be material, and historically, indemnity payments made by us have not had a material effect on our operating results, financial position, or cash flows.

[0000858877-21-000008:notes:212]
Charter Communications, Inc. (“Charter”), which acquired Time Warner Cable (“TWC”) in May 2016, sought indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Following a trial on March 3, 2017, the jury found that TWC willfully infringed five patents and awarded Sprint $140 million in damages, as well as pre- and post-judgment interest of approximately $10 million. After the judgment was affirmed on appeal, Charter reported that it paid the judgment in full. We resolved Charter’s indemnity claim effective February 4, 2021 for an amount that does not have a material effect on our financial position.

[0000858877-21-000008:notes:213]
We have been asked to indemnify certain of our service provider customers that have been subject to patent infringement claims asserted by ChanBond, LLC (“ChanBond”) in federal court in Delaware on September 21, 2015. ChanBond alleges that 13 service provider defendants, including among others, Comcast Corporation, Charter Communications, Inc. (“Charter”), Time Warner Cable, Inc. (subsequently acquired by Charter), Cox Communications, Inc. (“Cox”), and Cablevision Systems Corporation (subsequently acquired by Altice USA, Inc.), infringe three patents by providing high speed cable internet services to their customers utilizing cable modems and cable modem termination systems, consistent with the DOCSIS 3.0 standard, provided by us and other manufacturers generally used in combination with each other. ChanBond seeks monetary damages and injunctive relief against the service provider customers, although two of the asserted patents expire on June 19, 2021, and the third expires on September 17, 2021. The Court has set ChanBond’s case against Cox for trial on May 20, 2021. The other cases against the remaining service provider defendants have not yet been set for trial. We believe that the service provider defendants have strong non-infringement, invalidity and other defenses and that ChanBond will not be able to meet its burden required for injunctive relief.

[0000858877-21-000008:notes:214]
Verizon Communications Inc. has requested that we indemnify it and seven of its subsidiaries (collectively, “Verizon”) for a subset of the patent infringement claims asserted by Huawei Technologies Co. Ltd. (“Huawei”) in lawsuits filed against Verizon on February 5, 2020, in the United States District Court for the Eastern District of Texas (“E.D. Tex”) and the United States District Court for the Western District of Texas (“W.D. Tex”). In the E.D. Tex case, Huawei alleges infringement of four patents required to operate the G.709 standard adopted by the Telecommunication Standardization Sector of the International Telecommunications Union by using products supplied by us. Huawei seeks monetary damages. The E.D. Tex court has set a trial date for July 9, 2021. In the W.D. Tex case, Huawei alleges infringement of four patents, two patents involving Cisco

[0000858877-21-000008:notes:215]
Webex and Cisco video endpoints that allow content sharing in a video conference, and two patents involving Cisco routers that support Ethernet Flow Point functionality and/or specific network convergence functionalities. Huawei seeks monetary damages and injunctive relief in the W.D. Tex case. The W.D. Tex court has set a trial date for October 4, 2021. We believe that Verizon has strong defenses in the cases and that Huawei will not be able to meet its burden required for injunctive relief in the W.D. Tex case.

[0000858877-21-000008:notes:216]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-21-000008:notes:217]
(f)Legal Proceedings

[0000858877-21-000008:notes:218]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $149 million for the alleged evasion of import and other taxes, $735 million for interest, and $368 million for various penalties, all determined using an exchange rate as of May 1, 2021.

[0000858877-21-000008:notes:219]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-21-000008:notes:220]
China     We are investigating allegations of a self-enrichment scheme involving now-former employees in China. Some of those employees are also alleged to have made or directed payments from the funds they received to various third parties, including employees of state-owned enterprises. We voluntarily disclosed this investigation to the Department of Justice (“DOJ”) and Securities and Exchange Commission (“SEC”). We take such allegations very seriously and we are providing results of our investigation to the DOJ and SEC. While the outcome of our investigation is currently not determinable, we do not expect that it will have a material adverse effect on our consolidated financial position, results of operations, or cash flows.

[0000858877-21-000008:notes:221]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware (“D. Del.”), accusing our products and services in the area of network intrusion detection of infringing two patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. On May 12, 2016, a jury returned a verdict finding willful infringement. The jury awarded SRI damages of $24 million. On May 25, 2017, the district court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit (“Federal Circuit”) on various grounds, and after various proceedings, on July 12, 2019, the Federal Circuit vacated the enhanced damages award; vacated and remanded in part the willful infringement finding; vacated and remanded the attorneys’ fees award for further proceedings; and affirmed the district court’s other findings. On April 1, 2020, the district court issued a final judgment on the remanded issues, finding no evidence of willful infringement and reinstating the $8 million award of attorneys’ fees. SRI appealed the judgment of no willful infringement to the Federal Circuit on April 3, 2020, and Cisco filed a cross-appeal on the attorneys’ fees award on April 9, 2020. Cisco has paid SRI $28 million, representing the portion of the judgment that the Federal Circuit previously affirmed, plus interest and royalties on post-verdict sales. While the remaining proceedings may result in an additional loss, we do not expect it to be material.

[0000858877-21-000008:notes:222]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office (“PTO”) to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal appealed the PTAB’s findings of unpatentability to the Federal Circuit. The Federal Circuit affirmed the PTAB’s findings of unpatentability as to

[0000858877-21-000008:notes:223]
three of the patents on March 10, 2021, and affirmed the PTAB’s findings of unpatentability as to the remaining four patents on May 11, 2021.

[0000858877-21-000008:notes:224]
From May 6, 2020 to June 25, 2020, the district court conducted a bench trial by videoconference on the claims in the five patents not subject to the IPR Proceedings. On October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The district court awarded Centripetal $1.9 billion, comprised of $756 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $14 million. The district court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $168 million and a maximum annual royalty of $300 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $84 million and a maximum annual royalty of $150 million. We believe that the district court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We have appealed the district court’s judgment as to the four patents found valid and infringed to the Federal Circuit, and we believe that any relief ultimately awarded would not be material. On October 28, 2020, by agreement of the parties, the district court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment.

[0000858877-21-000008:notes:225]
On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. district court proceedings, one of which has been invalidated by the PTAB. We believe we have strong defenses. Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of the cases at this time.

[0000858877-21-000008:notes:226]
Finjan     On January 6, 2017, Finjan, Inc. (“Finjan”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, originally seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Finjan alleged that Cisco’s AMP and ThreatGrid products and the URL rewrite feature of Cisco’s ESA Outbreak Filter product infringe five patents. On May 24, 2021, we resolved all claims for an amount that does not have a material effect on our financial position.

[0000858877-21-000008:notes:227]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in E.D. Tex, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. As of November 27, 2020, the PTO preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings. On January 13, 2021, the court entered an order staying the case pending the conclusion of the ex parte reexamination proceedings. While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in court, we believe that any damages ultimately assessed would not be material.

[0000858877-21-000008:notes:228]
On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) (which we subsequently acquired) in D. Del, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot has asserted in its E.D. Tex case. We are currently assessing this case. Due to the early stage of the litigation as well as uncertainties in the litigation processes, we are unable, at this time, to reasonably estimate a potential range of loss, if any, or the ultimate outcome of this litigation.

[0000858877-21-000008:notes:229]
Monarch     On January 21, 2020, Monarch Networking Solutions LLC (“Monarch”) asserted patent infringement claims against us in E.D. Tex alleging that certain Cisco routers and firewalls infringe three U.S. patents. Monarch seeks damages, including enhanced damages for alleged willful infringement, and a running royalty on future sales. The E.D. Tex court set trial to begin on July 12, 2021. On May 13, 2020, Monarch filed a second action against us in W.D. Tex, alleging that two factor authentication functionality in Duo and Meraki MR and MX access point products infringe one U.S. patent. Monarch seeks damages, including enhanced damages for alleged willful infringement, and a running royalty on future sales. The W.D. Tex court set trial to begin on November 14, 2021. While we believe that we have strong non-infringement and invalidity arguments, and that Monarch’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court, we believe that any damages ultimately assessed would not be material.

[0000858877-21-000008:notes:230]
Viasat     On January 21, 2016, Viasat, Inc. (“Viasat”) filed suit against Acacia (which we subsequently acquired) in the California Superior Court for San Diego County (“SDSC”) seeking unpaid royalties for breach of contract and the implied

[0000858877-21-000008:notes:231]
covenant of good faith and fair dealing, and damages for trade secret misappropriation for certain products (“Viasat 1”). Acacia counterclaimed for patent and trade secret misappropriation, contract, and unfair competition claims. On July 17, 2019, the jury found for Viasat on its contract claims, and awarded Viasat $49 million for unpaid royalties through 2018. The jury further found that Acacia willfully misappropriated Viasat’s trade secrets and awarded Viasat $1. On Acacia’s counterclaims, the jury found for Acacia on its contract and trade secret claims and awarded Acacia $1. Both Acacia and Viasat have pending appeals to the California Court of Appeal. On November 6, 2019, Viasat filed a second suit in SDSC, alleging contract and trade secret claims for Acacia products sold from January 1, 2019 forward (“Viasat 2”). On February 28, 2020, the court stayed Viasat 2 pending the appeal in Viasat 1. On June 9, 2020, Viasat filed a third suit in SDSC (“Viasat 3”). In Viasat 3, Viasat alleges contract and trade secrets claims for sales of additional Acacia products. On August 11, 2020, the court stayed Viasat 3 pending the appeal in Viasat 1.

[0000858877-21-000008:notes:232]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court - Business Litigation Session against ViaSat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation. On April 5, 2018, ViaSat counterclaimed with contract, trade secret, and unfair competition claims (collectively, with Viasat 1, Viasat 2 and Viasat 3, the “Viasat Cases”). On December 13, 2018, the Massachusetts court entered an order staying the Massachusetts litigation, which has been extended to June 30, 2021.

[0000858877-21-000008:notes:233]
While we believe Acacia has strong defenses in each of the Viasat Cases, we are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If Acacia does not prevail, we believe that any relief ultimately assessed in any of the Viasat Cases would not be material.
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-21-000008:notes:234]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-21-000008:notes:235]
Stockholders’ Equity 
(a)Cash Dividends on Shares of Common Stock

[0000858877-21-000008:notes:236]
We declared and paid cash dividends of $0.37 and $0.36 per common share, or $1.6 billion and $1.5 billion, on our outstanding common stock for the third quarter of fiscal 2021 and 2020, respectively. We declared and paid cash dividends of $1.09 and $1.06 per common share, or $4.6 billion and $4.5 billion, on our outstanding common stock for the first nine months of fiscal 2021 and 2020, respectively.

[0000858877-21-000008:notes:237]
Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-21-000008:notes:238]
[same as prior period, unchanged from 0000858877-21-000004:notes:229]

[0000858877-21-000008:notes:239]
In September 2001, our Board of Directors authorized a stock repurchase program. As of May 1, 2021, the remaining authorized amount for stock repurchases under this program was approximately $8.7 billion with no termination date. A summary of the stock repurchase activity for fiscal 2021 and 2020 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-21-000008:notes:240]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2021 |  |  |  |  |  |  |
| May 1, 2021 |  | 10 |  |  | $ | 48.71 |  |  | $ | 510 |  |
| January 23, 2021 |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |
| October 24, 2020 |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |
| Fiscal 2020 |  |  |  |  |  |  |
| July 25, 2020 |  | — |  |  | $ | — |  |  | $ | — |  |
| April 25, 2020 |  | 25 |  |  | $ | 39.71 |  |  | $ | 981 |  |
| January 25, 2020 |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |
| October 26, 2019 |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |

[0000858877-21-000008:notes:241]
There were $15 million stock repurchases that were pending settlement as of May 1, 2021. There were no stock repurchases that were pending settlement as of July 25, 2020.

[0000858877-21-000008:notes:242]
The purchase price for the shares of our stock repurchased is reflected as a reduction to stockholders’ equity. We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings or an increase to accumulated deficit and (ii) a reduction of common stock and additional paid-in capital.

[0000858877-21-000008:notes:243]
[same as prior period, unchanged from 0000858877-21-000004:notes:234]

[0000858877-21-000008:notes:244]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock of one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights of such series, and any qualification, limitations or restrictions thereof, of the shares of such series. As of May 1, 2021, we had not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-21-000008:notes:245]
[same as prior period, unchanged from 0000858877-21-000004:notes:236]

[0000858877-21-000008:notes:246]
Stock Incentive Plan Program Description  We have one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with us. The number and frequency of share-based awards are based on competitive practices, our operating results, government regulations, and other factors. Our primary stock incentive plan is summarized as follows:

[0000858877-21-000008:notes:247]
2005 Plan    The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions. Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. As of May 1, 2021, the maximum number of shares issuable under the 2005 Plan over its term was 790 million shares. The 2005 Plan may be terminated by our Board of Directors at any time and for any reason, and is currently set to terminate at the 2030 Annual Meeting unless re-adopted or extended by our stockholders prior to or on such date.

[0000858877-21-000008:notes:248]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of May 1, 2021, 257 million shares were authorized for future grant under the 2005 Plan.

[0000858877-21-000008:notes:249]
[same as prior period, unchanged from 0000858877-21-000004:notes:240]

[0000858877-21-000008:notes:250]
We have an Employee Stock Purchase Plan under which 721 million shares of our common stock have been reserved for issuance as of May 1, 2021. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. No shares were issued under the Employee Stock Purchase Plan during each of the third quarters of fiscal 2021 and 2020. We issued 8 million and 9 million shares during the first nine months of fiscal 2021 and 2020, respectively. As of May 1, 2021, 133 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-21-000008:notes:251]
[same as prior period, unchanged from 0000858877-21-000004:notes:242]

[0000858877-21-000008:notes:252]
[same as prior period, unchanged from 0000858877-21-000004:notes:243]

[0000858877-21-000008:notes:253]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1, 2021 |  | April 25, 2020 |  | May 1, 2021 |  | April 25, 2020 |
| Cost of sales—product | $ | 26 |  |  | $ | 23 |  |  | $ | 75 |  |  | $ | 69 |  |
| Cost of sales—service | 49 |  |  | 37 |  |  | 133 |  |  | 107 |  |
| Share-based compensation expense in cost of sales | 75 |  |  | 60 |  |  | 208 |  |  | 176 |  |
| Research and development | 184 |  |  | 148 |  |  | 522 |  |  | 440 |  |
| Sales and marketing | 140 |  |  | 125 |  |  | 402 |  |  | 371 |  |
| General and administrative | 59 |  |  | 49 |  |  | 179 |  |  | 164 |  |
| Restructuring and other charges | 5 |  |  | 5 |  |  | 26 |  |  | 18 |  |
| Share-based compensation expense in operating expenses | 388 |  |  | 327 |  |  | 1,129 |  |  | 993 |  |
| Total share-based compensation expense | $ | 463 |  |  | $ | 387 |  |  | $ | 1,337 |  |  | $ | 1,169 |  |
| Income tax benefit for share-based compensation | $ | 88 |  |  | $ | 81 |  |  | $ | 264 |  |  | $ | 321 |  |

[0000858877-21-000008:notes:254]
As of May 1, 2021, the total compensation cost related to unvested share-based awards not yet recognized was $3.6 billion which is expected to be recognized over approximately 2.5 years on a weighted-average basis.

[0000858877-21-000008:notes:255]
[same as prior period, unchanged from 0000858877-21-000004:notes:246]

[0000858877-21-000008:notes:256]
[same as prior period, unchanged from 0000858877-21-000004:notes:247]

[0000858877-21-000008:notes:257]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| Unvested balance at July 27, 2019 | 100 |  |  | $ | 38.66 |  |  |  |
| Granted and assumed | 49 |  |  | 42.61 |  |  |  |
| Vested | (44) |  |  | 35.20 |  |  | $ | 2,045 |  |
| Canceled/forfeited/other | (9) |  |  | 40.45 |  |  |  |
| Unvested balance at July 25, 2020 | 96 |  |  | 42.03 |  |  |  |
| Granted and assumed | 35 |  |  | 38.39 |  |  |  |
| Vested | (27) |  |  | 39.65 |  |  | $ | 1,188 |  |
| Canceled/forfeited/other | (11) |  |  | 42.14 |  |  |  |
| Unvested balance at May 1, 2021 | 93 |  |  | $ | 41.34 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-21-000008:notes:258]
Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first nine months of fiscal 2021 and 2020 are summarized as follows (in millions):

[0000858877-21-000008:notes:259]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 25, 2020 | $ | 315 |  |  | $ | (6) |  |  | $ | (828) |  |  | $ | (519) |  |
| Other comprehensive income (loss) before reclassifications | (150) |  |  | 16 |  |  | 364 |  |  | 230 |  |
| (Gains) losses reclassified out of AOCI | (46) |  |  | (12) |  |  | 3 |  |  | (55) |  |
| Tax benefit (expense) | 59 |  |  | (2) |  |  | (1) |  |  | 56 |  |
| Balance at May 1, 2021 | $ | 178 |  |  | $ | (4) |  |  | $ | (462) |  |  | $ | (288) |  |

[0000858877-21-000008:notes:260]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 27, 2019 | $ | — |  |  | $ | (14) |  |  | $ | (778) |  |  | $ | (792) |  |
| Other comprehensive income (loss) before reclassifications | 169 |  |  | 14 |  |  | (472) |  |  | (289) |  |
| (Gains) losses reclassified out of AOCI | (20) |  |  | 1 |  |  | 2 |  |  | (17) |  |
| Tax benefit (expense) | (12) |  |  | (1) |  |  | 2 |  |  | (11) |  |
| Balance at April 25, 2020 | $ | 137 |  |  | $ | — |  |  | $ | (1,246) |  |  | $ | (1,109) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-21-000008:notes:261]
[same as prior period, unchanged from 0000858877-21-000004:notes:252]

[0000858877-21-000008:notes:262]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |
| Income before provision for income taxes | $ | 3,591 |  |  | $ | 3,444 |  |  | $ | 9,527 |  |  | $ | 10,664 |  |
| Provision for income taxes | $ | 728 |  |  | $ | 670 |  |  | $ | 1,945 |  |  | $ | 2,086 |  |
| Effective tax rate | 20.3 | % |  | 19.4 | % |  | 20.4 | % |  | 19.6 | % |

[0000858877-21-000008:notes:263]
As of May 1, 2021, we had $2.5 billion of unrecognized tax benefits, of which $2.1 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-21-000008:notes:264]
[same as prior period, unchanged from 0000858877-21-000004:notes:255]

[0000858877-21-000008:notes:265]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-21-000008:notes:266]
Summarized financial information by segment for the third quarter and first nine months of fiscal 2021 and 2020, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-21-000008:notes:267]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25, 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 7,262 |  |  | $ | 7,116 |  |  | $ | 21,430 |  |  | $ | 22,106 |  |
| EMEA | 3,483 |  |  | 3,136 |  |  | 9,654 |  |  | 9,553 |  |
| APJC | 2,057 |  |  | 1,730 |  |  | 5,608 |  |  | 5,489 |  |
| Total | $ | 12,803 |  |  | $ | 11,983 |  |  | $ | 36,692 |  |  | $ | 37,147 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,831 |  |  | $ | 4,828 |  |  | $ | 14,383 |  |  | $ | 14,836 |  |
| EMEA | 2,283 |  |  | 2,061 |  |  | 6,322 |  |  | 6,289 |  |
| APJC | 1,331 |  |  | 1,098 |  |  | 3,599 |  |  | 3,511 |  |
| Segment total | 8,445 |  |  | 7,986 |  |  | 24,303 |  |  | 24,636 |  |
| Unallocated corporate items | (260) |  |  | (215) |  |  | (753) |  |  | (637) |  |
| Total | $ | 8,185 |  |  | $ | 7,771 |  |  | $ | 23,550 |  |  | $ | 23,999 |  |

[0000858877-21-000008:notes:268]
[same as prior period, unchanged from 0000858877-21-000004:notes:259]

[0000858877-21-000008:notes:269]
Revenue in the United States was $6.4 billion and $6.3 billion for the third quarter of fiscal 2021 and 2020, respectively, and $19.1 billion and $19.7 billion for the first nine months of fiscal 2021 and 2020, respectively.

[0000858877-21-000008:notes:270]
[same as prior period, unchanged from 0000858877-21-000004:notes:261]

[0000858877-21-000008:notes:271]
We design and sell Internet Protocol (IP)-based networking and other products related to the communications and IT industry and provide services associated with these products and their use.


## us-gaap:EarningsPerShareTextBlock

[0000858877-21-000008:notes:272]
[same as prior period, unchanged from 0000858877-21-000004:notes:263]

[0000858877-21-000008:notes:273]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |
| Net income | $ | 2,863 |  |  | $ | 2,774 |  |  | $ | 7,582 |  |  | $ | 8,578 |  |
| Weighted-average shares—basic | 4,219 |  |  | 4,230 |  |  | 4,224 |  |  | 4,239 |  |
| Effect of dilutive potential common shares | 19 |  |  | 13 |  |  | 13 |  |  | 19 |  |
| Weighted-average shares—diluted | 4,238 |  |  | 4,243 |  |  | 4,237 |  |  | 4,258 |  |
| Net income per share—basic | $ | 0.68 |  |  | $ | 0.66 |  |  | $ | 1.79 |  |  | $ | 2.02 |  |
| Net income per share—diluted | $ | 0.68 |  |  | $ | 0.65 |  |  | $ | 1.79 |  |  | $ | 2.01 |  |
| Antidilutive employee share-based awards, excluded | 15 |  |  | 14 |  |  | 55 |  |  | 42 |  |

[0000858877-21-000008:notes:274]
Employee equity share options, unvested shares, and similar equity instruments granted and assumed by us are treated as potential common shares outstanding in computing diluted earnings per share. Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that has not yet been recognized are collectively assumed to be used to repurchase shares.
