# CSCO MD&A — 0000858877-21-000008


## mdna

[0000858877-21-000008:mdna:1]
[same as prior period, unchanged from 0000858877-21-000004:mdna:1]

[0000858877-21-000008:mdna:2]
[same as prior period, unchanged from 0000858877-21-000004:mdna:2]

[0000858877-21-000008:mdna:3]
[same as prior period, unchanged from 0000858877-21-000004:mdna:3]

[0000858877-21-000008:mdna:4]
[same as prior period, unchanged from 0000858877-21-000004:mdna:4]

[0000858877-21-000008:mdna:5]
[same as prior period, unchanged from 0000858877-21-000004:mdna:5]

[0000858877-21-000008:mdna:6]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | May 1,2021 |  | April 25,2020 |  | % Variance |  | May 1, 2021 |  | April 25, 2020 |  | % Variance |  |
| Revenue | $ | 12,803 |  |  | $ | 11,983 |  |  | 7 | % |  | $ | 36,692 |  |  | $ | 37,147 |  |  | (1) | % |  |
| Gross margin percentage | 63.9 | % |  | 64.9 | % |  | (1.0) |  | pts | 64.2 | % |  | 64.6 | % |  | (0.4) |  | pts |
| Research and development | $ | 1,697 |  |  | $ | 1,546 |  |  | 10 | % |  | $ | 4,836 |  |  | $ | 4,782 |  |  | 1 | % |  |
| Sales and marketing | $ | 2,317 |  |  | $ | 2,192 |  |  | 6 | % |  | $ | 6,811 |  |  | $ | 6,951 |  |  | (2) | % |  |
| General and administrative | $ | 603 |  |  | $ | 457 |  |  | 32 | % |  | $ | 1,631 |  |  | $ | 1,431 |  |  | 14 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,617 |  |  | $ | 4,195 |  |  | 10 | % |  | $ | 13,278 |  |  | $ | 13,164 |  |  | 1 | % |  |
| Total as a percentage of revenue | 36.1 | % |  | 35.0 | % |  | 1.1 |  | pts | 36.2 | % |  | 35.4 | % |  | 0.8 |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 61 |  |  | $ | 34 |  |  | 79 | % |  | $ | 136 |  |  | $ | 108 |  |  | 26 | % |  |
| Restructuring and other charges included in operating expenses | $ | 42 |  |  | $ | 128 |  |  | (67) | % |  | $ | 878 |  |  | $ | 354 |  |  | 148 | % |  |
| Operating income as a percentage of revenue | 27.1 | % |  | 28.5 | % |  | (1.4) |  | pts | 25.2 | % |  | 27.9 | % |  | (2.7) |  | pts |
| Interest and other income (loss), net | $ | 126 |  |  | $ | 30 |  |  | 320 | % |  | $ | 269 |  |  | $ | 291 |  |  | (8) | % |  |
| Income tax percentage | 20.3 | % |  | 19.4 | % |  | 0.9 |  | pts | 20.4 | % |  | 19.6 | % |  | 0.8 |  | pts |
| Net income | $ | 2,863 |  |  | $ | 2,774 |  |  | 3 | % |  | $ | 7,582 |  |  | $ | 8,578 |  |  | (12) | % |  |
| Net income as a percentage of revenue | 22.4 | % |  | 23.1 | % |  | (0.7) |  | pts | 20.7 | % |  | 23.1 | % |  | (2.4) |  | pts |
| Earnings per share—diluted | $ | 0.68 |  |  | $ | 0.65 |  |  | 5 | % |  | $ | 1.79 |  |  | $ | 2.01 |  |  | (11) | % |  |

[0000858877-21-000008:mdna:7]
[same as prior period, unchanged from 0000858877-21-000004:mdna:7]

[0000858877-21-000008:mdna:8]
[same as prior period, unchanged from 0000858877-21-000004:mdna:8]

[0000858877-21-000008:mdna:9]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:10]
In the third quarter of fiscal 2021, we had strong performance across the business and delivered solid revenue growth and earnings per share. As customers have accelerated their digitization and cloud investments in the wake of the COVID-19 pandemic, we have been focusing on executing and innovating to support and assist that transition. Total revenue increased by 7% compared with the third quarter of fiscal 2020. Our product revenue reflected growth in Infrastructure Platforms, Applications, and Security, and we continued to make progress in the transition of our business model to increased software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-21-000008:mdna:11]
Within total revenue, product revenue increased by 6% and service revenue increased by 8%. The third quarter of fiscal 2021 had 14 weeks, compared with 13 weeks in the third quarter of fiscal 2020, thus our results for the third quarter and first nine months of fiscal 2021 reflect an extra week compared with the corresponding periods of fiscal 2020. We estimate that the total additional revenue associated with the extra week was approximately 3% of revenue growth. In the third quarter of fiscal 2021, total software revenue was $3.8 billion across all product areas and service, an increase of 13%, with 81% of total software revenue sold as a subscription, reflecting a 7 percentage point increase from the third quarter of fiscal 2020. Total gross margin decreased by 1.0 percentage points. Product gross margin decreased by 1.1 percentage points, largely driven by ongoing costs related to supply chain constraints. The effect of pricing erosion was moderate, partially offset by favorable product mix. We are partnering with several of our key suppliers utilizing our volume purchasing and extending supply coverage, including revising supplier arrangements, to address supply chain challenges. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 1.1 percentage points due in large part to the impact of the extra week in the third quarter of fiscal 2021. The total impact associated with the extra week on our cost of sales and operating expenses was approximately $150 million (excluding the impact of share-based compensation expense). Operating income as a percentage of revenue decreased by 1.4 percentage points. Diluted earnings per share increased 5%, driven by a 3% increase in net income.

[0000858877-21-000008:mdna:12]
In terms of our geographic segments, revenue from the Americas increased $146 million, EMEA revenue increased by $347 million and APJC revenue increased by $327 million. The “BRICM” countries experienced product revenue growth of 22% in the aggregate, driven by an increase in product revenue across each of the BRICM countries with the exception of Mexico.

[0000858877-21-000008:mdna:13]
From a customer market standpoint, we experienced product revenue growth in the service provider, public sector and commercial markets, partially offset by a product revenue decline in the enterprise market. We are seeing improvement in business momentum in our customer markets, which we believe was related to an improving global macroeconomic environment.

[0000858877-21-000008:mdna:14]
From a product category perspective, the product revenue increase of 6% was driven by growth in revenue in Infrastructure Platforms of 6%, Applications of 5%, and Security of 13%.

[0000858877-21-000008:mdna:15]
[same as prior period, unchanged from 0000858877-21-000004:mdna:16]

[0000858877-21-000008:mdna:16]
[same as prior period, unchanged from 0000858877-21-000004:mdna:17]

[0000858877-21-000008:mdna:17]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:18]
Total revenue decreased 1%, with product revenue decreasing 3% and service revenue increasing 4%. Total gross margin decreased by 0.4 percentage points due to pricing erosion partially offset by favorable impacts from product mix. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively increased by 0.8 percentage points. Operating income as a percentage of revenue decreased by 2.7 percentage points. We incurred restructuring and other charges of $878 million in the first nine months of fiscal 2021, which resulted in a decrease of 12% in net income and a decrease of 11% in diluted earnings per share.

[0000858877-21-000008:mdna:19]
[same as prior period, unchanged from 0000858877-21-000004:mdna:20]

[0000858877-21-000008:mdna:20]
[same as prior period, unchanged from 0000858877-21-000004:mdna:21]

[0000858877-21-000008:mdna:21]
[same as prior period, unchanged from 0000858877-21-000004:mdna:22]

[0000858877-21-000008:mdna:22]
[same as prior period, unchanged from 0000858877-21-000004:mdna:23]

[0000858877-21-000008:mdna:23]
[same as prior period, unchanged from 0000858877-21-000004:mdna:24]

[0000858877-21-000008:mdna:24]
[same as prior period, unchanged from 0000858877-21-000004:mdna:25]

[0000858877-21-000008:mdna:25]
[same as prior period, unchanged from 0000858877-21-000004:mdna:26]

[0000858877-21-000008:mdna:26]
[same as prior period, unchanged from 0000858877-21-000004:mdna:27]

[0000858877-21-000008:mdna:27]
[same as prior period, unchanged from 0000858877-21-000004:mdna:28]

[0000858877-21-000008:mdna:28]
[same as prior period, unchanged from 0000858877-21-000004:mdna:29]

[0000858877-21-000008:mdna:29]
[same as prior period, unchanged from 0000858877-21-000004:mdna:30]

[0000858877-21-000008:mdna:30]
[same as prior period, unchanged from 0000858877-21-000004:mdna:31]

[0000858877-21-000008:mdna:31]
[same as prior period, unchanged from 0000858877-21-000004:mdna:52]

[0000858877-21-000008:mdna:32]
[same as prior period, unchanged from 0000858877-21-000004:mdna:32]

[0000858877-21-000008:mdna:33]
[same as prior period, unchanged from 0000858877-21-000004:mdna:33]

[0000858877-21-000008:mdna:34]
[same as prior period, unchanged from 0000858877-21-000004:mdna:34]

[0000858877-21-000008:mdna:35]
[same as prior period, unchanged from 0000858877-21-000004:mdna:35]

[0000858877-21-000008:mdna:36]
[same as prior period, unchanged from 0000858877-21-000004:mdna:36]

[0000858877-21-000008:mdna:37]
[same as prior period, unchanged from 0000858877-21-000004:mdna:37]

[0000858877-21-000008:mdna:38]
The following is a summary of our other key financial measures for the third quarter of fiscal 2021 (in millions):

[0000858877-21-000008:mdna:39]
|  |  | May 1,2021 |  | July 25,2020 |
| Cash and cash equivalents and investments |  | $ | 23,579 |  |  | $ | 29,419 |  |
| Deferred revenue |  | $ | 20,889 |  |  | $ | 20,446 |  |
| Inventories |  | $ | 1,579 |  |  | $ | 1,282 |  |

[0000858877-21-000008:mdna:40]
|  |  | Nine Months Ended |
|  |  | May 1,2021 |  | April 25,2020 |
| Cash provided by operating activities |  | $ | 10,950 |  |  | $ | 11,624 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 2,111 |  |  | $ | 2,619 |  |
| Dividends paid |  | $ | 4,601 |  |  | $ | 4,491 |  |

[0000858877-21-000008:mdna:41]
46

[0000858877-21-000008:mdna:42]
[same as prior period, unchanged from 0000858877-21-000004:mdna:41]

[0000858877-21-000008:mdna:43]
[same as prior period, unchanged from 0000858877-21-000004:mdna:42]

[0000858877-21-000008:mdna:44]
[same as prior period, unchanged from 0000858877-21-000004:mdna:43]

[0000858877-21-000008:mdna:45]
[same as prior period, unchanged from 0000858877-21-000004:mdna:44]

[0000858877-21-000008:mdna:46]
The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The COVID-19 pandemic did not have a material impact on our significant judgments, assumptions and estimates that are reflected in our results for the third quarter and first nine months of fiscal 2021. These estimates are listed in our Annual Report on Form 10-K for the year ending July 25, 2020, and include: goodwill and identified purchased intangible assets and income taxes, among other items. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues to develop, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-21-000008:mdna:47]
[same as prior period, unchanged from 0000858877-21-000004:mdna:46]

[0000858877-21-000008:mdna:48]
[same as prior period, unchanged from 0000858877-21-000004:mdna:47]

[0000858877-21-000008:mdna:49]
[same as prior period, unchanged from 0000858877-21-000004:mdna:48]

[0000858877-21-000008:mdna:50]
[same as prior period, unchanged from 0000858877-21-000004:mdna:49]

[0000858877-21-000008:mdna:51]
[same as prior period, unchanged from 0000858877-21-000004:mdna:50]

[0000858877-21-000008:mdna:52]
[same as prior period, unchanged from 0000858877-21-000004:mdna:51]

[0000858877-21-000008:mdna:53]
[same as prior period, unchanged from 0000858877-21-000004:mdna:53]

[0000858877-21-000008:mdna:54]
[same as prior period, unchanged from 0000858877-21-000004:mdna:54]

[0000858877-21-000008:mdna:55]
Loss Contingencies

[0000858877-21-000008:mdna:56]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-21-000008:mdna:57]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-21-000008:mdna:58]
[same as prior period, unchanged from 0000858877-21-000004:mdna:58]

[0000858877-21-000008:mdna:59]
[same as prior period, unchanged from 0000858877-21-000004:mdna:59]

[0000858877-21-000008:mdna:60]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first nine months of fiscal 2021 and 2020.

[0000858877-21-000008:mdna:61]
[same as prior period, unchanged from 0000858877-21-000004:mdna:61]

[0000858877-21-000008:mdna:62]
[same as prior period, unchanged from 0000858877-21-000004:mdna:62]

[0000858877-21-000008:mdna:63]
[same as prior period, unchanged from 0000858877-21-000004:mdna:63]

[0000858877-21-000008:mdna:64]
[same as prior period, unchanged from 0000858877-21-000004:mdna:64]

[0000858877-21-000008:mdna:65]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 20.3% and 19.4% in the third quarter of fiscal 2021 and 2020, respectively, and 20.4% and 19.6% in the first nine months of fiscal 2021 and 2020, respectively.

[0000858877-21-000008:mdna:66]
[same as prior period, unchanged from 0000858877-21-000004:mdna:66]

[0000858877-21-000008:mdna:67]
[same as prior period, unchanged from 0000858877-21-000004:mdna:87]

[0000858877-21-000008:mdna:68]
[same as prior period, unchanged from 0000858877-21-000004:mdna:67]

[0000858877-21-000008:mdna:69]
[same as prior period, unchanged from 0000858877-21-000004:mdna:68]

[0000858877-21-000008:mdna:70]
[same as prior period, unchanged from 0000858877-21-000004:mdna:69]

[0000858877-21-000008:mdna:71]
[same as prior period, unchanged from 0000858877-21-000004:mdna:70]

[0000858877-21-000008:mdna:72]
[same as prior period, unchanged from 0000858877-21-000004:mdna:71]

[0000858877-21-000008:mdna:73]
49

[0000858877-21-000008:mdna:74]
[same as prior period, unchanged from 0000858877-21-000004:mdna:73]

[0000858877-21-000008:mdna:75]
[same as prior period, unchanged from 0000858877-21-000004:mdna:74]

[0000858877-21-000008:mdna:76]
[same as prior period, unchanged from 0000858877-21-000004:mdna:75]

[0000858877-21-000008:mdna:77]
[same as prior period, unchanged from 0000858877-21-000004:mdna:76]

[0000858877-21-000008:mdna:78]
[same as prior period, unchanged from 0000858877-21-000004:mdna:77]

[0000858877-21-000008:mdna:79]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | May 1,2021 |  | April 25,2020 |  | Variancein Dollars |  | Variance in Percent |  | May 1, 2021 |  | April 25, 2020 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,139 |  |  | $ | 8,597 |  |  | $ | 542 |  |  | 6 | % |  | $ | 26,298 |  |  | $ | 27,146 |  |  | $ | (848) |  |  | (3) | % |
| Percentage of revenue |  | 71.4 | % |  | 71.7 | % |  |  |  |  |  | 71.7 | % |  | 73.1 | % |  |  |  |  |
| Service |  | 3,664 |  |  | 3,386 |  |  | 278 |  |  | 8 | % |  | 10,394 |  |  | 10,001 |  |  | 393 |  |  | 4 | % |
| Percentage of revenue |  | 28.6 | % |  | 28.3 | % |  |  |  |  |  | 28.3 | % |  | 26.9 | % |  |  |  |  |
| Total |  | $ | 12,803 |  |  | $ | 11,983 |  |  | $ | 820 |  |  | 7 | % |  | $ | 36,692 |  |  | $ | 37,147 |  |  | $ | (455) |  |  | (1) | % |

[0000858877-21-000008:mdna:80]
[same as prior period, unchanged from 0000858877-21-000004:mdna:79]

[0000858877-21-000008:mdna:81]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | May 1,2021 |  | April 25,2020 |  | Variancein Dollars |  | Variance in Percent |  | May 1, 2021 |  | April 25, 2020 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,262 |  |  | $ | 7,116 |  |  | $ | 146 |  |  | 2 | % |  | $ | 21,430 |  |  | $ | 22,106 |  |  | $ | (676) |  |  | (3) | % |
| Percentage of revenue |  | 56.7 | % |  | 59.4 | % |  |  |  |  |  | 58.4 | % |  | 59.5 | % |  |  |  |  |
| EMEA |  | 3,483 |  |  | 3,136 |  |  | 347 |  |  | 11 | % |  | 9,654 |  |  | 9,553 |  |  | 101 |  |  | 1 | % |
| Percentage of revenue |  | 27.2 | % |  | 26.2 | % |  |  |  |  |  | 26.3 | % |  | 25.7 | % |  |  |  |  |
| APJC |  | 2,057 |  |  | 1,730 |  |  | 327 |  |  | 19 | % |  | 5,608 |  |  | 5,489 |  |  | 119 |  |  | 2 | % |
| Percentage of revenue |  | 16.1 | % |  | 14.4 | % |  |  |  |  |  | 15.3 | % |  | 14.8 | % |  |  |  |  |
| Total |  | $ | 12,803 |  |  | $ | 11,983 |  |  | $ | 820 |  |  | 7 | % |  | $ | 36,692 |  |  | $ | 37,147 |  |  | $ | (455) |  |  | (1) | % |

[0000858877-21-000008:mdna:82]
[same as prior period, unchanged from 0000858877-21-000004:mdna:81]

[0000858877-21-000008:mdna:83]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:84]
Total revenue increased by 7%. Product revenue increased by 6% and service revenue increased by 8%. The third quarter of fiscal 2021 had 14 weeks, compared with 13 weeks in the third quarter of fiscal 2020, thus our results for the third quarter of fiscal 2021 reflect an extra week compared with the third quarter of fiscal 2020. We estimate that the total additional revenue associated with the extra week was approximately 3% of revenue growth. Our total revenue reflected growth across each of our geographic segments. Product revenue for the emerging countries of BRICM, in the aggregate, experienced product revenue growth of 22%, with increases in each of these countries with the exception of Mexico.

[0000858877-21-000008:mdna:85]
[same as prior period, unchanged from 0000858877-21-000004:mdna:84]

[0000858877-21-000008:mdna:86]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:87]
Total revenue decreased by 1%. Product revenue decreased by 3% and service revenue increased by 4%. Our total revenue reflected declines in Americas, partially offset by growth in EMEA and APJC. Product revenue for the emerging countries of BRICM, in the aggregate, experienced a 9% product revenue decline, with decreases in China, Brazil, Russia and Mexico, partially offset by an increase in India.

[0000858877-21-000008:mdna:88]
[same as prior period, unchanged from 0000858877-21-000004:mdna:88]

[0000858877-21-000008:mdna:89]
[same as prior period, unchanged from 0000858877-21-000004:mdna:89]

[0000858877-21-000008:mdna:90]
[same as prior period, unchanged from 0000858877-21-000004:mdna:90]

[0000858877-21-000008:mdna:91]
[same as prior period, unchanged from 0000858877-21-000004:mdna:91]

[0000858877-21-000008:mdna:92]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | May 1,2021 |  | April 25,2020 |  | Variancein Dollars |  | Variance in Percent |  | May 1,2021 |  | April 25,2020 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,014 |  |  | $ | 5,029 |  |  | $ | (15) |  |  | — | % |  | $ | 15,031 |  |  | $ | 15,871 |  |  | $ | (840) |  |  | (5) | % |
| Percentage of product revenue |  | 54.8 | % |  | 58.5 | % |  |  |  |  |  | 57.2 | % |  | 58.5 | % |  |  |  |  |
| EMEA |  | 2,647 |  |  | 2,357 |  |  | 290 |  |  | 12 | % |  | 7,295 |  |  | 7,308 |  |  | (13) |  |  | — | % |
| Percentage of product revenue |  | 29.0 | % |  | 27.4 | % |  |  |  |  |  | 27.7 | % |  | 26.9 | % |  |  |  |  |
| APJC |  | 1,478 |  |  | 1,211 |  |  | 267 |  |  | 22 | % |  | 3,972 |  |  | 3,967 |  |  | 5 |  |  | — | % |
| Percentage of product revenue |  | 16.2 | % |  | 14.1 | % |  |  |  |  |  | 15.1 | % |  | 14.6 | % |  |  |  |  |
| Total |  | $ | 9,139 |  |  | $ | 8,597 |  |  | $ | 542 |  |  | 6 | % |  | $ | 26,298 |  |  | $ | 27,146 |  |  | $ | (848) |  |  | (3) | % |

[0000858877-21-000008:mdna:93]
[same as prior period, unchanged from 0000858877-21-000004:mdna:93]

[0000858877-21-000008:mdna:94]
[same as prior period, unchanged from 0000858877-21-000004:mdna:94]

[0000858877-21-000008:mdna:95]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:96]
Product revenue in the Americas segment was flat, as the declines in the enterprise and commercial markets were offset by growth in the service provider and public sector markets. From a country perspective, product revenue decreased by 1% in the United States and 14% in Mexico, partially offset by a product revenue increase of 11% in Canada and 7% in Brazil.

[0000858877-21-000008:mdna:97]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:98]
The decrease in product revenue in the Americas segment was driven by declines in the enterprise, commercial and service provider markets. The decreases were partially offset by product revenue growth in the public sector market. From a country perspective, product revenue decreased in the United States, Canada, Brazil and Mexico by 5%, 2%, 18% and 18%, respectively.

[0000858877-21-000008:mdna:99]
[same as prior period, unchanged from 0000858877-21-000004:mdna:99]

[0000858877-21-000008:mdna:100]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:101]
Product revenue in the EMEA segment increased by 12%, with growth in all customer markets. Product revenue from emerging countries within EMEA increased by 4% and product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, increased by 15%. From a country perspective, product revenue increased by 11% in the United Kingdom, 8% in Germany and 4% in France.

[0000858877-21-000008:mdna:102]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:103]
Product revenue in the EMEA segment was flat, as declines in the commercial and enterprise markets were offset by growth in the service provider and public sector markets. Product revenue from emerging countries within EMEA decreased by 9% and product revenue for the remainder of the EMEA segment increased by 3%. From a country perspective, product revenue declined 2% in the United Kingdom and 3% in France, offset by growth in product revenue of 7% in Germany.

[0000858877-21-000008:mdna:104]
[same as prior period, unchanged from 0000858877-21-000004:mdna:104]

[0000858877-21-000008:mdna:105]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:106]
Product revenue in the APJC segment increased by 22%, driven by growth in all customer markets. From a country perspective, product revenue increased in Japan, India, Australia and China by 12%, 66%, 50% and 9%, respectively.

[0000858877-21-000008:mdna:107]
[same as prior period, unchanged from 0000858877-21-000004:mdna:107]

[0000858877-21-000008:mdna:108]
[same as prior period, unchanged from 0000858877-21-000004:mdna:108]

[0000858877-21-000008:mdna:109]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:110]
Product revenue in the APJC segment was flat, with growth in the public sector market offset by declines in the commercial, service provider and enterprise markets. From a country perspective, product revenue increased in Japan, India and Australia by 9%, 2%, and 6%, respectively, offset by a product revenue decrease of 11% in China.

[0000858877-21-000008:mdna:111]
[same as prior period, unchanged from 0000858877-21-000004:mdna:111]

[0000858877-21-000008:mdna:112]
In addition to the primary view on a geographic basis, we also prepare financial information related to product categories and customer markets for various purposes. We report our product revenue in the following categories: Infrastructure Platforms, Applications, Security, and Other Products.

[0000858877-21-000008:mdna:113]
[same as prior period, unchanged from 0000858877-21-000004:mdna:113]

[0000858877-21-000008:mdna:114]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | May 1,2021 |  | April 25,2020 |  | Variancein Dollars |  | Variance in Percent |  | May 1,2021 |  | April 25,2020 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 6,832 |  |  | $ | 6,447 |  |  | $ | 385 |  |  | 6 | % |  | $ | 19,564 |  |  | $ | 20,566 |  |  | $ | (1,002) |  |  | (5) | % |
| Applications |  | 1,426 |  |  | 1,363 |  |  | 63 |  |  | 5 | % |  | 4,160 |  |  | 4,211 |  |  | (51) |  |  | (1) | % |
| Security |  | 876 |  |  | 778 |  |  | 98 |  |  | 13 | % |  | 2,559 |  |  | 2,343 |  |  | 216 |  |  | 9 | % |
| Other Products |  | 6 |  |  | 9 |  |  | (3) |  |  | (34) | % |  | 15 |  |  | 27 |  |  | (12) |  |  | (44) | % |
| Total |  | $ | 9,139 |  |  | $ | 8,597 |  |  | $ | 542 |  |  | 6 | % |  | $ | 26,298 |  |  | $ | 27,146 |  |  | $ | (848) |  |  | (3) | % |

[0000858877-21-000008:mdna:115]
Amounts may not sum and percentages may not recalculate due to rounding. Prior period amounts have been reclassified to conform to the current period’s presentation.

[0000858877-21-000008:mdna:116]
[same as prior period, unchanged from 0000858877-21-000004:mdna:116]

[0000858877-21-000008:mdna:117]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:118]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center. Infrastructure Platforms revenue increased by 6%, or $385 million, with growth across the portfolio with the exception of data center. We experienced an increase in Switching revenue with growth in campus switching driven by an increase in sales of our intent-based networking Catalyst 9000 Series. This product revenue growth was partially offset by declines in data center switching. We experienced an increase in sales of routing products driven by growth in the service provider market. Wireless had strong growth driven by our WiFi6 products and Meraki offerings. Revenue from data center declined primarily driven by our server products.

[0000858877-21-000008:mdna:119]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:120]
Revenue from the Infrastructure Platforms product category decreased 5%, or $1.0 billion, with declines across the portfolio with the exception of wireless. Switching revenue declined in both campus switching and data center switching, although we saw revenue growth in our intent-based networking Catalyst 9000 Series and Nexus 9000 Series. The decrease in routing was driven by declines in the service provider and enterprise markets. We had solid growth in our wireless products driven by our WiFi6 products and Meraki offerings. Revenue from data center decreased driven primarily by our server products.

[0000858877-21-000008:mdna:121]
[same as prior period, unchanged from 0000858877-21-000004:mdna:121]

[0000858877-21-000008:mdna:122]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:123]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as the Internet of Things (IoT) and AppDynamics analytics software offerings. Revenue in our Applications product category increased by 5%, or $63 million, driven by double digit growth in Webex, growth in Unified Communications, IoT software offerings and AppDynamics, partially offset by declines in Cisco TelePresence.

[0000858877-21-000008:mdna:124]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:125]
Revenue in our Applications product category decreased by 1%, or $51 million, with declines in Unified Communications and Cisco Telepresence partially offset by double digit growth in Webex and IoT software offerings.

[0000858877-21-000008:mdna:126]
[same as prior period, unchanged from 0000858877-21-000004:mdna:126]

[0000858877-21-000008:mdna:127]
[same as prior period, unchanged from 0000858877-21-000004:mdna:127]

[0000858877-21-000008:mdna:128]
[same as prior period, unchanged from 0000858877-21-000004:mdna:128]

[0000858877-21-000008:mdna:129]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:130]
Revenue in our Security product category increased 13%, or $98 million, with growth across the portfolio. Our cloud security portfolio reflected strong double-digit growth and continued momentum with our Duo and Umbrella offerings.

[0000858877-21-000008:mdna:131]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:132]
Revenue in our Security product category increased by 9%, or $216 million, driven by growth across the portfolio. This product revenue increase reflects continued momentum with our Duo and Umbrella offerings.

[0000858877-21-000008:mdna:133]
[same as prior period, unchanged from 0000858877-21-000004:mdna:133]

[0000858877-21-000008:mdna:134]
[same as prior period, unchanged from 0000858877-21-000004:mdna:134]

[0000858877-21-000008:mdna:135]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | May 1,2021 |  | April 25,2020 |  | Variancein Dollars |  | Variance in Percent |  | May 1,2021 |  | April 25,2020 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,248 |  |  | $ | 2,088 |  |  | $ | 160 |  |  | 8 | % |  | $ | 6,399 |  |  | $ | 6,235 |  |  | $ | 164 |  |  | 3 | % |
| Percentage of service revenue |  | 61.4 | % |  | 61.7 | % |  |  |  |  |  | 61.6 | % |  | 62.3 | % |  |  |  |  |
| EMEA |  | 836 |  |  | 779 |  |  | 57 |  |  | 7 | % |  | 2,359 |  |  | 2,245 |  |  | 114 |  |  | 5 | % |
| Percentage of service revenue |  | 22.8 | % |  | 23.0 | % |  |  |  |  |  | 22.7 | % |  | 22.4 | % |  |  |  |  |
| APJC |  | 579 |  |  | 520 |  |  | 59 |  |  | 11 | % |  | 1,636 |  |  | 1,521 |  |  | 115 |  |  | 8 | % |
| Percentage of service revenue |  | 15.8 | % |  | 15.3 | % |  |  |  |  |  | 15.7 | % |  | 15.3 | % |  |  |  |  |
| Total |  | $ | 3,664 |  |  | $ | 3,386 |  |  | $ | 278 |  |  | 8 | % |  | $ | 10,394 |  |  | $ | 10,001 |  |  | $ | 393 |  |  | 4 | % |

[0000858877-21-000008:mdna:136]
[same as prior period, unchanged from 0000858877-21-000004:mdna:115]

[0000858877-21-000008:mdna:137]
Service revenue increased 8% in the third quarter of fiscal 2021 and increased 4% in the first nine months of fiscal 2021 compared to the corresponding periods of fiscal 2020. The increases in both periods were driven by revenue growth in our maintenance business and solution support offerings. Service revenue increased across all geographic segments. Service revenue benefited from the extra week in the third quarter of fiscal 2021.

[0000858877-21-000008:mdna:138]
[same as prior period, unchanged from 0000858877-21-000004:mdna:138]

[0000858877-21-000008:mdna:139]
[same as prior period, unchanged from 0000858877-21-000004:mdna:139]

[0000858877-21-000008:mdna:140]
[same as prior period, unchanged from 0000858877-21-000004:mdna:140]

[0000858877-21-000008:mdna:141]
[same as prior period, unchanged from 0000858877-21-000004:mdna:141]

[0000858877-21-000008:mdna:142]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,717 |  |  | $ | 5,477 |  |  | 62.6 | % |  | 63.7 | % |  | $ | 16,626 |  |  | $ | 17,376 |  |  | 63.2 | % |  | 64.0 | % |
| Service |  | 2,468 |  |  | 2,294 |  |  | 67.4 | % |  | 67.7 | % |  | 6,924 |  |  | 6,623 |  |  | 66.6 | % |  | 66.2 | % |
| Total |  | $ | 8,185 |  |  | $ | 7,771 |  |  | 63.9 | % |  | 64.9 | % |  | $ | 23,550 |  |  | $ | 23,999 |  |  | 64.2 | % |  | 64.6 | % |

[0000858877-21-000008:mdna:143]
[same as prior period, unchanged from 0000858877-21-000004:mdna:143]

[0000858877-21-000008:mdna:144]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the third quarter and first nine months of fiscal 2021, as compared with the corresponding periods in fiscal 2020:

[0000858877-21-000008:mdna:145]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Nine Months Ended |
| Fiscal 2020 |  | 63.7 | % |  | 64.0 | % |
| Productivity (1) |  | (0.1) | % |  | (0.1) | % |
| Product pricing |  | (1.6) | % |  | (1.5) | % |
| Mix of products sold |  | 0.8 | % |  | 1.2 | % |
| Legal and indemnification charge |  | — | % |  | (0.1) | % |
| Others |  | (0.2) | % |  | (0.3) | % |
| Fiscal 2021 |  | 62.6 | % |  | 63.2 | % |

[0000858877-21-000008:mdna:146]
[same as prior period, unchanged from 0000858877-21-000004:mdna:146]

[0000858877-21-000008:mdna:147]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:148]
Product gross margin decreased by 1.1 percentage points largely driven by ongoing costs related to supply chain constraints. The effect of pricing erosion was moderate, partially offset by favorable product mix. We also experienced pricing erosion that was driven by typical market factors and impacted each of our geographic segments. The favorable mix was driven by changes in the proportion of products sold from each of our product categories as compared to the corresponding period of fiscal 2020.

[0000858877-21-000008:mdna:149]
During the third quarter of 2021, we continued to manage through supply chain challenges seen industry wide due to component shortages, caused in part by the COVID-19 pandemic. These challenges resulted in increased costs (i.e. component costs, broker fees, expedited freight and overtime) which had a negative impact on product gross margin, and extended lead times to us and our customers. We are partnering with several of our key suppliers utilizing our volume purchasing and extending supply coverage, including revising supplier arrangements, to address supply chain challenges. We believe these actions will enable us to optimize our access to critical components, including semiconductors. We expect these supply chain challenges to continue through at least the end of calendar year 2021.

[0000858877-21-000008:mdna:150]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:151]
Product gross margin decreased by 0.8 percentage points driven by pricing erosion, partially offset by favorable impacts from product mix. In the first nine months of fiscal 2021, as a result of the COVID-19 pandemic, we incurred additional logistics costs, such as freight, which had a negative impact on product gross margin.

[0000858877-21-000008:mdna:152]
[same as prior period, unchanged from 0000858877-21-000004:mdna:152]

[0000858877-21-000008:mdna:153]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:154]
Our service gross margin percentage decreased by 0.3 percentage points primarily due to higher headcount-related and delivery costs, partially offset by higher sales volume and to a lesser extent, favorable mix of service offerings.

[0000858877-21-000008:mdna:155]
[same as prior period, unchanged from 0000858877-21-000004:mdna:198]

[0000858877-21-000008:mdna:156]
[same as prior period, unchanged from 0000858877-21-000004:mdna:156]

[0000858877-21-000008:mdna:157]
[same as prior period, unchanged from 0000858877-21-000004:mdna:157]

[0000858877-21-000008:mdna:158]
[same as prior period, unchanged from 0000858877-21-000004:mdna:155]

[0000858877-21-000008:mdna:159]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:160]
Service gross margin percentage increased by 0.4 percentage points due to higher sales volume and favorable mix of service offerings, partially offset by increased headcount-related and delivery costs.

[0000858877-21-000008:mdna:161]
[same as prior period, unchanged from 0000858877-21-000004:mdna:160]

[0000858877-21-000008:mdna:162]
[same as prior period, unchanged from 0000858877-21-000004:mdna:161]

[0000858877-21-000008:mdna:163]
|  | Three Months Ended |  | Nine Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,831 |  |  | $ | 4,828 |  |  | 66.5 | % |  | 67.8 | % |  | $ | 14,383 |  |  | $ | 14,836 |  |  | 67.1 | % |  | 67.1 | % |
| EMEA | 2,283 |  |  | 2,061 |  |  | 65.6 | % |  | 65.7 | % |  | 6,322 |  |  | 6,289 |  |  | 65.5 | % |  | 65.8 | % |
| APJC | 1,331 |  |  | 1,098 |  |  | 64.7 | % |  | 63.5 | % |  | 3,599 |  |  | 3,511 |  |  | 64.2 | % |  | 64.0 | % |
| Segment total | 8,445 |  |  | 7,986 |  |  | 66.0 | % |  | 66.6 | % |  | 24,303 |  |  | 24,636 |  |  | 66.2 | % |  | 66.3 | % |
| Unallocated corporate items (1) | (260) |  |  | (215) |  |  |  |  |  |  | (753) |  |  | (637) |  |  |  |  |  |
| Total | $ | 8,185 |  |  | $ | 7,771 |  |  | 63.9 | % |  | 64.9 | % |  | $ | 23,550 |  |  | $ | 23,999 |  |  | 64.2 | % |  | 64.6 | % |

[0000858877-21-000008:mdna:164]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-21-000008:mdna:165]
[same as prior period, unchanged from 0000858877-21-000004:mdna:136]

[0000858877-21-000008:mdna:166]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:167]
We experienced a gross margin percentage decrease in our Americas segment due to pricing erosion and negative impacts from productivity, partially offset by favorable impacts from product mix.

[0000858877-21-000008:mdna:168]
Gross margin in our EMEA segment decreased slightly due to pricing erosion, partially offset by favorable impacts from productivity improvements and product mix. Lower service gross margin also contributed to the decrease in the gross margin in this geographic segment.

[0000858877-21-000008:mdna:169]
The APJC segment gross margin percentage increase was due to favorable impacts from product mix, and to a lesser extent, productivity improvements, partially offset by pricing erosion. Higher service gross margin also contributed to the increase in the gross margin in this geographic segment.

[0000858877-21-000008:mdna:170]
[same as prior period, unchanged from 0000858877-21-000004:mdna:169]

[0000858877-21-000008:mdna:171]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:172]
Gross margin percentage in the Americas segment was flat, driven by favorable product mix, offset by pricing erosion.

[0000858877-21-000008:mdna:173]
[same as prior period, unchanged from 0000858877-21-000004:mdna:172]

[0000858877-21-000008:mdna:174]
The APJC segment gross margin percentage increase was driven by productivity improvements and favorable product mix, partially offset by pricing erosion.

[0000858877-21-000008:mdna:175]
[same as prior period, unchanged from 0000858877-21-000004:mdna:174]

[0000858877-21-000008:mdna:176]
[same as prior period, unchanged from 0000858877-21-000004:mdna:175]

[0000858877-21-000008:mdna:177]
[same as prior period, unchanged from 0000858877-21-000004:mdna:176]

[0000858877-21-000008:mdna:178]
[same as prior period, unchanged from 0000858877-21-000004:mdna:177]

[0000858877-21-000008:mdna:179]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1,2021 |  | April 25,2020 |  | Variancein Dollars |  | Variance in Percent |  | May 1,2021 |  | April 25,2020 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,697 |  |  | $ | 1,546 |  |  | $ | 151 |  |  | 10 | % |  | $ | 4,836 |  |  | $ | 4,782 |  |  | $ | 54 |  |  | 1 | % |
| Percentage of revenue | 13.3 | % |  | 12.9 | % |  |  |  |  |  | 13.2 | % |  | 12.9 | % |  |  |  |  |
| Sales and marketing | 2,317 |  |  | 2,192 |  |  | 125 |  |  | 6 | % |  | 6,811 |  |  | 6,951 |  |  | (140) |  |  | (2) | % |
| Percentage of revenue | 18.1 | % |  | 18.3 | % |  |  |  |  |  | 18.6 | % |  | 18.7 | % |  |  |  |  |
| General and administrative | 603 |  |  | 457 |  |  | 146 |  |  | 32 | % |  | 1,631 |  |  | 1,431 |  |  | 200 |  |  | 14 | % |
| Percentage of revenue | 4.7 | % |  | 3.8 | % |  |  |  |  |  | 4.4 | % |  | 3.9 | % |  |  |  |  |
| Total | $ | 4,617 |  |  | $ | 4,195 |  |  | $ | 422 |  |  | 10 | % |  | $ | 13,278 |  |  | $ | 13,164 |  |  | $ | 114 |  |  | 1 | % |
| Percentage of revenue | 36.1 | % |  | 35.0 | % |  |  |  |  |  | 36.2 | % |  | 35.4 | % |  |  |  |  |

[0000858877-21-000008:mdna:180]
Our third quarter of fiscal 2021 had an extra week compared with the corresponding period of fiscal 2020.

[0000858877-21-000008:mdna:181]
[same as prior period, unchanged from 0000858877-21-000004:mdna:179]

[0000858877-21-000008:mdna:182]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:183]
R&D expenses increased due to higher headcount-related expenses in large part to the impact of the extra week in the third quarter of fiscal 2021, higher share-based compensation expense and contracted services spending, partially offset by lower discretionary spending.

[0000858877-21-000008:mdna:184]
[same as prior period, unchanged from 0000858877-21-000004:mdna:182]

[0000858877-21-000008:mdna:185]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:186]
R&D expenses increased primarily due to higher headcount-related expenses, higher share-based compensation and contracted services spending, partially offset by lower discretionary spending. The extra week in the first nine months of fiscal 2021 contributed to the increase in headcount-related expenses.

[0000858877-21-000008:mdna:187]
[same as prior period, unchanged from 0000858877-21-000004:mdna:185]

[0000858877-21-000008:mdna:188]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:189]
Sales and marketing expenses increased due to higher headcount-related expenses and contracted services spending, partially offset by lower discretionary spending. The extra week in the third quarter of fiscal 2021 contributed to the increase in headcount-related expenses.

[0000858877-21-000008:mdna:190]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:191]
Sales and marketing expenses decreased primarily due to lower discretionary spending partially offset by higher headcount-related expenses and contracted services spending. The extra week in the first nine months of fiscal 2021 contributed to the increase in headcount-related expenses.

[0000858877-21-000008:mdna:192]
[same as prior period, unchanged from 0000858877-21-000004:mdna:190]

[0000858877-21-000008:mdna:193]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:194]
G&A expenses increased due to higher headcount-related expenses, higher contracted services spending, higher discretionary spending and the impact from the gain recognized on the sale of property in the third quarter of fiscal 2020. The extra week in the third quarter of fiscal 2021 contributed to the increase in headcount-related expenses.

[0000858877-21-000008:mdna:195]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:196]
G&A expenses increased due to the impact from the gain recognized on the sale of property in the first nine months of fiscal 2020 and higher headcount-related expenses. The extra week in the first nine months of fiscal 2021 contributed to the increase in headcount-related expenses.

[0000858877-21-000008:mdna:197]
[same as prior period, unchanged from 0000858877-21-000004:mdna:199]

[0000858877-21-000008:mdna:198]
[same as prior period, unchanged from 0000858877-21-000004:mdna:200]

[0000858877-21-000008:mdna:199]
[same as prior period, unchanged from 0000858877-21-000004:mdna:195]

[0000858877-21-000008:mdna:200]
In the third quarter of fiscal 2021, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $78 million, or 1.9%, compared with the third quarter of fiscal 2020.

[0000858877-21-000008:mdna:201]
In the first nine months of fiscal 2021, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $122 million, or 0.9%, compared with the first nine months of fiscal 2020.

[0000858877-21-000008:mdna:202]
[same as prior period, unchanged from 0000858877-21-000004:mdna:201]

[0000858877-21-000008:mdna:203]
[same as prior period, unchanged from 0000858877-21-000004:mdna:202]

[0000858877-21-000008:mdna:204]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 187 |  |  | $ | 163 |  |  | $ | 513 |  |  | $ | 494 |  |
| Operating expenses |  | 61 |  |  | 34 |  |  | 136 |  |  | 108 |  |
| Total |  | $ | 248 |  |  | $ | 197 |  |  | $ | 649 |  |  | $ | 602 |  |

[0000858877-21-000008:mdna:205]
For each of the third quarter and first nine months of fiscal 2021, the increase in amortization of purchased intangible assets was due largely to the amortization of purchased intangibles from our recent acquisitions.

[0000858877-21-000008:mdna:206]
[same as prior period, unchanged from 0000858877-21-000004:mdna:205]

[0000858877-21-000008:mdna:207]
In the first quarter of fiscal 2021, we initiated a restructuring plan, which includes a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $900 million. In connection with this restructuring plan, we incurred charges of $35 million and $869 million for the third quarter and first nine months of fiscal 2021, respectively. We expect the plan to be substantially completed in fiscal 2021 and estimate it will generate cost savings of approximately $1.0 billion on an annualized basis over the next few quarters.

[0000858877-21-000008:mdna:208]
We initiated a restructuring plan during fiscal 2020 in order to realign the organization and enable further investment in key priority areas. In connection with this restructuring plan, we have incurred cumulative charges of $264 million. We expect this restructuring plan to be substantially completed in fiscal 2021.

[0000858877-21-000008:mdna:209]
[same as prior period, unchanged from 0000858877-21-000004:mdna:208]

[0000858877-21-000008:mdna:210]
[same as prior period, unchanged from 0000858877-21-000004:mdna:209]

[0000858877-21-000008:mdna:211]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |
| Operating income |  | $ | 3,465 |  |  | $ | 3,414 |  |  | $ | 9,258 |  |  | $ | 10,373 |  |
| Operating income as a percentage of revenue |  | 27.1 | % |  | 28.5 | % |  | 25.2 | % |  | 27.9 | % |

[0000858877-21-000008:mdna:212]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:213]
Operating income increased by 1%, and operating income as a percentage of revenue decreased by 1.4 percentage points. These changes resulted primarily from a revenue increase, partially offset by a gross margin percentage decrease (driven by pricing erosion, partially offset by favorable product mix) and an increase in operating expenses.

[0000858877-21-000008:mdna:214]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:215]
Operating income decreased by 11%, and operating income as a percentage of revenue decreased by 2.7 percentage points. These changes resulted primarily from a revenue decrease, higher restructuring and other charges and a gross margin percentage decrease (driven by pricing erosion, partially offset by favorable product mix).

[0000858877-21-000008:mdna:216]
[same as prior period, unchanged from 0000858877-21-000004:mdna:248]

[0000858877-21-000008:mdna:217]
[same as prior period, unchanged from 0000858877-21-000004:mdna:215]

[0000858877-21-000008:mdna:218]
[same as prior period, unchanged from 0000858877-21-000004:mdna:216]

[0000858877-21-000008:mdna:219]
[same as prior period, unchanged from 0000858877-21-000004:mdna:217]

[0000858877-21-000008:mdna:220]
[same as prior period, unchanged from 0000858877-21-000004:mdna:218]

[0000858877-21-000008:mdna:221]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | May 1,2021 |  | April 25,2020 |  | Variancein Dollars |  | May 1,2021 |  | April 25,2020 |  | Variancein Dollars |
| Interest income |  | $ | 153 |  |  | $ | 218 |  |  | $ | (65) |  |  | $ | 488 |  |  | $ | 733 |  |  | $ | (245) |  |
| Interest expense |  | (111) |  |  | (130) |  |  | 19 |  |  | (336) |  |  | (466) |  |  | 130 |  |
| Interest income (expense), net |  | $ | 42 |  |  | $ | 88 |  |  | $ | (46) |  |  | $ | 152 |  |  | $ | 267 |  |  | $ | (115) |  |

[0000858877-21-000008:mdna:222]
For each of the third quarter and first nine months of fiscal 2021, the decrease in interest income was driven by both lower interest rates and lower average balances of cash and available-for-sale debt investments. The decrease in interest expense was driven by a lower average debt balance and the impact of lower effective interest rates.

[0000858877-21-000008:mdna:223]
[same as prior period, unchanged from 0000858877-21-000004:mdna:221]

[0000858877-21-000008:mdna:224]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | May 1,2021 |  | April 25,2020 |  | Variancein Dollars |  | May 1,2021 |  | April 25,2020 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | 22 |  |  | $ | (1) |  |  | $ | 23 |  |  | $ | 46 |  |  | $ | 20 |  |  | $ | 26 |  |
| Marketable equity investments |  | 2 |  |  | (6) |  |  | 8 |  |  | 1 |  |  | (6) |  |  | 7 |  |
| Non-marketable equity and other investments |  | 95 |  |  | 17 |  |  | 78 |  |  | 120 |  |  | 108 |  |  | 12 |  |
| Net gains (losses) on investments |  | 119 |  |  | 10 |  |  | 109 |  |  | 167 |  |  | 122 |  |  | 45 |  |
| Other gains (losses), net |  | (35) |  |  | (68) |  |  | 33 |  |  | (50) |  |  | (98) |  |  | 48 |  |
| Other income (loss), net |  | $ | 84 |  |  | $ | (58) |  |  | $ | 142 |  |  | $ | 117 |  |  | $ | 24 |  |  | $ | 93 |  |

[0000858877-21-000008:mdna:225]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:226]
The change in net gains (losses) on available-for-sale debt investments was primarily attributable to higher realized gains as a result of market conditions, and the timing of sales of these investments. The change in net gains (losses) on non-marketable equity and other investments was primarily due to higher net unrealized gains and higher net realized gains. The change in other gains (losses), net was driven by lower donation expense and favorable impacts from our equity derivatives, partially offset by unfavorable impacts from foreign exchange.

[0000858877-21-000008:mdna:227]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:228]
The change in net gains (losses) on available-for-sale debt investments was primarily attributable to higher realized gains as a result of market conditions, and the timing of sales of these investments. The change in net gains (losses) on non-marketable equity and other investments was primarily due to higher net unrealized gains and lower impairment charges, offset by lower net realized gains. The change in other gains (losses), net was primarily driven by lower donation expense and favorable impacts from our equity derivatives, partially offset by unfavorable impacts from foreign exchange.

[0000858877-21-000008:mdna:229]
[same as prior period, unchanged from 0000858877-21-000004:mdna:227]

[0000858877-21-000008:mdna:230]
Three Months Ended May 1, 2021 Compared with Three Months Ended April 25, 2020

[0000858877-21-000008:mdna:231]
The provision for income taxes resulted in an effective tax rate of 20.3% for the third quarter of fiscal 2021 compared with 19.4% for the third quarter of fiscal 2020. The increase in the effective tax rate was primarily due to a decrease in the tax benefit from foreign income taxed at other than U.S. rates in the third quarter of fiscal 2021 as compared to the third quarter of fiscal 2020.

[0000858877-21-000008:mdna:232]
Nine Months Ended May 1, 2021 Compared with Nine Months Ended April 25, 2020

[0000858877-21-000008:mdna:233]
The provision for income taxes resulted in an effective tax rate of 20.4% for the first nine months of fiscal 2021 compared with 19.6% for the first nine months of fiscal 2020. The increase in effective tax rate was primarily due to a decrease in the tax benefit from foreign income taxed at other than U.S. rates in fiscal 2021 as compared to fiscal 2020.

[0000858877-21-000008:mdna:234]
[same as prior period, unchanged from 0000858877-21-000004:mdna:234]

[0000858877-21-000008:mdna:235]
[same as prior period, unchanged from 0000858877-21-000004:mdna:235]

[0000858877-21-000008:mdna:236]
[same as prior period, unchanged from 0000858877-21-000004:mdna:230]

[0000858877-21-000008:mdna:237]
59

[0000858877-21-000008:mdna:238]
[same as prior period, unchanged from 0000858877-21-000004:mdna:249]

[0000858877-21-000008:mdna:239]
[same as prior period, unchanged from 0000858877-21-000004:mdna:250]

[0000858877-21-000008:mdna:240]
[same as prior period, unchanged from 0000858877-21-000004:mdna:236]

[0000858877-21-000008:mdna:241]
[same as prior period, unchanged from 0000858877-21-000004:mdna:237]

[0000858877-21-000008:mdna:242]
[same as prior period, unchanged from 0000858877-21-000004:mdna:238]

[0000858877-21-000008:mdna:243]
[same as prior period, unchanged from 0000858877-21-000004:mdna:239]

[0000858877-21-000008:mdna:244]
|  | May 1,2021 |  | July 25,2020 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 7,350 |  |  | $ | 11,809 |  |  | $ | (4,459) |  |
| Available-for-sale debt investments | 16,168 |  |  | 17,610 |  |  | (1,442) |  |
| Marketable equity securities | 61 |  |  | — |  |  | 61 |  |
| Total | $ | 23,579 |  |  | $ | 29,419 |  |  | $ | (5,840) |  |

[0000858877-21-000008:mdna:245]
The net decrease in cash and cash equivalents and investments in the first nine months of fiscal 2021 was driven by net cash paid for acquisitions and divestitures of $6.3 billion; cash returned to stockholders in the form of repurchases of common stock of $2.1 billion, and cash dividends of $4.6 billion; net decrease in debt of $3.0 billion and capital expenditures of $0.5 billion. These uses of cash were partially offset by cash provided by operating activities of $11.0 billion.

[0000858877-21-000008:mdna:246]
In addition to cash requirements in the normal course of business, we have approximately $0.7 billion of the U.S. transition tax on accumulated earnings for foreign subsidiaries that is payable in less than one year. Also, $2.0 billion of long-term debt outstanding at May 1, 2021 will mature within the next 12 months from the balance sheet date. See further discussion of liquidity under “Liquidity and Capital Resource Requirements” below.

[0000858877-21-000008:mdna:247]
[same as prior period, unchanged from 0000858877-21-000004:mdna:243]

[0000858877-21-000008:mdna:248]
[same as prior period, unchanged from 0000858877-21-000004:mdna:244]

[0000858877-21-000008:mdna:249]
Free Cash Flow and Capital Allocation   As part of our capital allocation strategy, we intend to return a minimum of 50% of our free cash flow annually to our stockholders through cash dividends and repurchases of common stock.

[0000858877-21-000008:mdna:250]
[same as prior period, unchanged from 0000858877-21-000004:mdna:246]

[0000858877-21-000008:mdna:251]
|  | Nine Months Ended |
|  | May 1,2021 |  | April 25,2020 |
| Net cash provided by operating activities | $ | 10,950 |  |  | $ | 11,624 |  |
| Acquisition of property and equipment | (530) |  |  | (562) |  |
| Free cash flow | $ | 10,420 |  |  | $ | 11,062 |  |

[0000858877-21-000008:mdna:252]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management,

[0000858877-21-000008:mdna:253]
[same as prior period, unchanged from 0000858877-21-000004:mdna:263]

[0000858877-21-000008:mdna:254]
[same as prior period, unchanged from 0000858877-21-000004:mdna:264]

[0000858877-21-000008:mdna:255]
deferred revenue, and the timing and amount of tax and other payments. For additional discussion, see “Part II, Item 1A. Risk Factors” in this report.

[0000858877-21-000008:mdna:256]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to stockholders in the form of dividends and stock repurchases. We further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness. Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net cash provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-21-000008:mdna:257]
[same as prior period, unchanged from 0000858877-21-000004:mdna:253]

[0000858877-21-000008:mdna:258]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |  |
| May 1, 2021 |  | $ | 0.37 |  |  | $ | 1,560 |  |  | 10 |  |  | $ | 48.71 |  |  | $ | 510 |  |  | $ | 2,070 |  |
| January 23, 2021 |  | $ | 0.36 |  |  | $ | 1,521 |  |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |  | $ | 2,322 |  |
| October 24, 2020 |  | $ | 0.36 |  |  | $ | 1,520 |  |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |  | $ | 2,320 |  |
| Fiscal 2020 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 25, 2020 |  | $ | 0.36 |  |  | $ | 1,525 |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,525 |  |
| April 25, 2020 |  | $ | 0.36 |  |  | $ | 1,519 |  |  | 25 |  |  | $ | 39.71 |  |  | $ | 981 |  |  | $ | 2,500 |  |
| January 25, 2020 |  | $ | 0.35 |  |  | $ | 1,486 |  |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |  | $ | 2,356 |  |
| October 26, 2019 |  | $ | 0.35 |  |  | $ | 1,486 |  |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |  | $ | 2,254 |  |

[0000858877-21-000008:mdna:259]
Any future dividends are subject to the approval of our Board of Directors.

[0000858877-21-000008:mdna:260]
The remaining authorized amount for stock repurchases under this program is approximately $8.7 billion, with no termination date.

[0000858877-21-000008:mdna:261]
[same as prior period, unchanged from 0000858877-21-000004:mdna:257]

[0000858877-21-000008:mdna:262]
|  | May 1,2021 |  | July 25,2020 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,425 |  |  | $ | 5,472 |  |  | $ | (1,047) |  |

[0000858877-21-000008:mdna:263]
Our accounts receivable net, as of May 1, 2021 decreased by approximately 19%, as compared with the end of fiscal 2020, primarily due to timing and amount of product and service billings in the third quarter of fiscal 2021 compared with the fourth quarter of fiscal 2020.

[0000858877-21-000008:mdna:264]
[same as prior period, unchanged from 0000858877-21-000004:mdna:260]

[0000858877-21-000008:mdna:265]
|  | May 1,2021 |  | July 25,2020 |  | Increase (Decrease) |
| Inventories | $ | 1,579 |  |  | $ | 1,282 |  |  | $ | 297 |  |

[0000858877-21-000008:mdna:266]
Inventory as of May 1, 2021 increased by 23% from our inventory balance at the end of fiscal 2020. The increase in inventory was primarily due to an increase in raw materials and higher deferred cost of sales.

[0000858877-21-000008:mdna:267]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory

[0000858877-21-000008:mdna:268]
61

[0000858877-21-000008:mdna:269]
[same as prior period, unchanged from 0000858877-21-000004:mdna:274]

[0000858877-21-000008:mdna:270]
[same as prior period, unchanged from 0000858877-21-000004:mdna:275]

[0000858877-21-000008:mdna:271]
based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity.

[0000858877-21-000008:mdna:272]
Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term supply and pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. We believe our inventory and purchase commitments are in line with our current demand forecasts. The following table summarizes our purchase commitments with contract manufacturers and suppliers as of the respective period ends (in millions):

[0000858877-21-000008:mdna:273]
| Commitments by Period | May 1,2021 |  | July 25,2020 |
| Less than 1 year | $ | 6,461 |  |  | $ | 3,994 |  |
| 1 to 3 years | 1,615 |  |  | 412 |  |
| 3 to 5 years | 1,733 |  |  | — |  |
| Total | $ | 9,809 |  |  | $ | 4,406 |  |

[0000858877-21-000008:mdna:274]
The increase in purchase commitments with contract manufacturers and suppliers compared with the end of fiscal 2020 was due to arrangements to secure long-term supply and pricing for certain product components for multi-year periods. We are partnering with several of our key suppliers utilizing our volume purchasing and extending supply coverage, including revising supplier arrangements, to address supply chain challenges.

[0000858877-21-000008:mdna:275]
[same as prior period, unchanged from 0000858877-21-000004:mdna:268]

[0000858877-21-000008:mdna:276]
[same as prior period, unchanged from 0000858877-21-000004:mdna:269]

[0000858877-21-000008:mdna:277]
|  | May 1,2021 |  | July 25,2020 |  | Increase (Decrease) |
| Lease receivables, net | $ | 1,713 |  |  | $ | 2,088 |  |  | $ | (375) |  |
| Loan receivables, net | 5,547 |  |  | 5,856 |  |  | (309) |  |
| Financed service contracts, net | 2,456 |  |  | 2,821 |  |  | (365) |  |
| Total, net | $ | 9,716 |  |  | $ | 10,765 |  |  | $ | (1,049) |  |

[0000858877-21-000008:mdna:278]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services. The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed. Financing receivables decreased by 10%, as compared with the end of fiscal 2020.

[0000858877-21-000008:mdna:279]
[same as prior period, unchanged from 0000858877-21-000004:mdna:272]

[0000858877-21-000008:mdna:280]
[same as prior period, unchanged from 0000858877-21-000004:mdna:284]

[0000858877-21-000008:mdna:281]
[same as prior period, unchanged from 0000858877-21-000004:mdna:285]

[0000858877-21-000008:mdna:282]
The volume of channel partner financing was $19.5 billion and $20.5 billion for the first nine months of fiscal 2021 and 2020, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.1 billion as of May 1, 2021 and July 25, 2020, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of May 1, 2021, the total maximum potential future payments related to these guarantees was approximately $171 million, of which approximately $22 million was recorded as deferred revenue.

[0000858877-21-000008:mdna:283]
[same as prior period, unchanged from 0000858877-21-000004:mdna:276]

[0000858877-21-000008:mdna:284]
[same as prior period, unchanged from 0000858877-21-000004:mdna:277]

[0000858877-21-000008:mdna:285]
|  | Maturity Date |  | May 1,2021 |  | July 25,2020 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | — |  |  | $ | 2,500 |  |
| 2.90% | March 4, 2021 |  | — |  |  | 500 |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 11,500 |  |  | $ | 14,500 |  |

[0000858877-21-000008:mdna:286]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of May 1, 2021.

[0000858877-21-000008:mdna:287]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of May 1, 2021 and July 25, 2020.

[0000858877-21-000008:mdna:288]
63

[0000858877-21-000008:mdna:289]
[same as prior period, unchanged from 0000858877-21-000004:mdna:303]

[0000858877-21-000008:mdna:290]
[same as prior period, unchanged from 0000858877-21-000004:mdna:304]

[0000858877-21-000008:mdna:291]
Credit Facility  On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. The credit agreement is structured as an amendment and restatement of our 364-day credit agreement, which would have terminated on May 14, 2021. As of May 1, 2021, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the 364-day credit facility. Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

[0000858877-21-000008:mdna:292]
64

[0000858877-21-000008:mdna:293]
CISCO SYSTEMS, INC.

[0000858877-21-000008:mdna:294]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-21-000008:mdna:295]
[same as prior period, unchanged from 0000858877-21-000004:mdna:282]

[0000858877-21-000008:mdna:296]
|  | May 1,2021 |  | July 25,2020 |  | Increase (Decrease) |
| Product | $ | 8,698 |  |  | $ | 7,895 |  |  | $ | 803 |  |
| Service | 12,191 |  |  | 12,551 |  |  | (360) |  |
| Total | $ | 20,889 |  |  | $ | 20,446 |  |  | $ | 443 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 11,492 |  |  | $ | 11,406 |  |  | $ | 86 |  |
| Noncurrent | 9,397 |  |  | 9,040 |  |  | 357 |  |
| Total | $ | 20,889 |  |  | $ | 20,446 |  |  | $ | 443 |  |

[0000858877-21-000008:mdna:297]
Deferred product revenue increased primarily due to increased deferrals related to our recurring software offerings. The decrease in deferred service revenue was driven by the impact of ongoing amortization of deferred service revenue.

[0000858877-21-000008:mdna:298]
[same as prior period, unchanged from 0000858877-21-000004:mdna:287]

[0000858877-21-000008:mdna:299]
|  | May 1,2021 |  | July 25,2020 |  | Increase (Decrease) |
| Product | $ | 11,903 |  |  | $ | 11,261 |  |  | $ | 642 |  |
| Service | 16,235 |  |  | 17,093 |  |  | (858) |  |
| Total | $ | 28,138 |  |  | $ | 28,354 |  |  | $ | (216) |  |

[0000858877-21-000008:mdna:300]
Total remaining performance obligations decreased 1% in the first nine months of fiscal 2021 compared to the end of fiscal 2020. Remaining performance obligations for product increased 6% compared to the end of fiscal 2020. Remaining performance obligations for service decreased 5%.

[0000858877-21-000008:mdna:301]
[same as prior period, unchanged from 0000858877-21-000004:mdna:290]

[0000858877-21-000008:mdna:302]
[same as prior period, unchanged from 0000858877-21-000004:mdna:291]

[0000858877-21-000008:mdna:303]
The income tax payable outstanding as of May 1, 2021 for the U.S. transition tax on accumulated earnings for foreign subsidiaries is $6.9 billion. Approximately $0.7 billion is payable in less than one year; $2.1 billion is payable between 1 to 3 years; and $4.1 billion is payable between 3 to 5 years.

[0000858877-21-000008:mdna:304]
[same as prior period, unchanged from 0000858877-21-000004:mdna:293]

[0000858877-21-000008:mdna:305]
[same as prior period, unchanged from 0000858877-21-000004:mdna:294]

[0000858877-21-000008:mdna:306]
[same as prior period, unchanged from 0000858877-21-000004:mdna:295]

[0000858877-21-000008:mdna:307]
We also have certain funding commitments primarily related to our non-marketable equity and other investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.2 billion and $0.3 billion as of May 1, 2021 and July 25, 2020, respectively.

[0000858877-21-000008:mdna:308]
[same as prior period, unchanged from 0000858877-21-000004:mdna:297]

[0000858877-21-000008:mdna:309]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have non-marketable equity and other investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our non-marketable equity and other investments and customer financings, and we have determined that as of May 1, 2021 there were no material unconsolidated variable interest entities.

[0000858877-21-000008:mdna:310]
[same as prior period, unchanged from 0000858877-21-000004:mdna:299]

[0000858877-21-000008:mdna:311]
CISCO SYSTEMS, INC.

[0000858877-21-000008:mdna:312]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-21-000008:mdna:313]
[same as prior period, unchanged from 0000858877-21-000004:mdna:300]

[0000858877-21-000008:mdna:314]
[same as prior period, unchanged from 0000858877-21-000004:mdna:301]

[0000858877-21-000008:mdna:315]
While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to increased disruption and volatility in capital markets and credit markets. The pandemic and resulting economic uncertainty could adversely affect our liquidity and capital resources in the future. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.

[0000858877-21-000008:mdna:316]
66
