# CSCO MD&A — 0000858877-22-000004


## mdna

[0000858877-22-000004:mdna:1]
[same as prior period, unchanged from 0000858877-21-000018:mdna:1]

[0000858877-22-000004:mdna:2]
[same as prior period, unchanged from 0000858877-21-000018:mdna:2]

[0000858877-22-000004:mdna:3]
[same as prior period, unchanged from 0000858877-21-000018:mdna:3]

[0000858877-22-000004:mdna:4]
[same as prior period, unchanged from 0000858877-21-000018:mdna:4]

[0000858877-22-000004:mdna:5]
[same as prior period, unchanged from 0000858877-21-000018:mdna:5]

[0000858877-22-000004:mdna:6]
|  | Three Months Ended |  |  | Six Months Ended |  |  |
|  | January 29,2022 |  | January 23,2021 |  | % Variance |  |  | January 29,2022 |  | January 23,2021 |  | % Variance |  |  |
| Revenue | $ | 12,720 |  |  | $ | 11,960 |  |  | 6 | % |  |  | $ | 25,620 |  |  | $ | 23,889 |  |  | 7 | % |  |  |
| Gross margin percentage | 63.3 | % |  | 65.1 | % |  | (1.8) |  | pts |  | 62.8 | % |  | 64.3 | % |  | (1.5) |  |  | pts |
| Research and development | $ | 1,670 |  |  | $ | 1,527 |  |  | 9 | % |  |  | $ | 3,384 |  |  | $ | 3,139 |  |  | 8 | % |  |  |
| Sales and marketing | $ | 2,266 |  |  | $ | 2,277 |  |  | — | % |  |  | $ | 4,527 |  |  | $ | 4,494 |  |  | 1 | % |  |  |
| General and administrative | $ | 544 |  |  | $ | 484 |  |  | 12 | % |  |  | $ | 1,095 |  |  | $ | 1,028 |  |  | 7 | % |  |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,480 |  |  | $ | 4,288 |  |  | 4 | % |  |  | $ | 9,006 |  |  | $ | 8,661 |  |  | 4 | % |  |  |
| Total as a percentage of revenue | 35.2 | % |  | 35.9 | % |  | (0.7) |  | pts |  | 35.2 | % |  | 36.3 | % |  | (1.1) |  |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 79 |  |  | $ | 39 |  |  | 103 | % |  |  | $ | 163 |  |  | $ | 75 |  |  | 117 | % |  |  |
| Restructuring and other charges included in operating expenses | $ | 3 |  |  | $ | 234 |  |  | (99) | % |  |  | $ | 8 |  |  | $ | 836 |  |  | (99) | % |  |  |
| Operating income as a percentage of revenue | 27.4 | % |  | 26.9 | % |  | 0.5 |  | pts |  | 27.0 | % |  | 24.2 | % |  | 2.8 |  |  | pts |
| Interest and other income (loss), net | $ | 116 |  |  | $ | 32 |  |  | 263 | % |  |  | $ | 335 |  |  | $ | 143 |  |  | 134 | % |  |  |
| Income tax percentage | 17.5 | % |  | 21.8 | % |  | (4.3) |  | pts |  | 18.0 | % |  | 20.5 | % |  | (2.5) |  |  | pts |
| Net income | $ | 2,973 |  |  | $ | 2,545 |  |  | 17 | % |  |  | $ | 5,953 |  |  | $ | 4,719 |  |  | 26 | % |  |  |
| Net income as a percentage of revenue | 23.4 | % |  | 21.3 | % |  | 2.1 |  | pts |  | 23.2 | % |  | 19.8 | % |  | 3.4 |  |  | pts |
| Earnings per share—diluted | $ | 0.71 |  |  | $ | 0.60 |  |  | 18 | % |  |  | $ | 1.41 |  |  | $ | 1.11 |  |  | 27 | % |  |  |

[0000858877-22-000004:mdna:7]
[same as prior period, unchanged from 0000858877-21-000018:mdna:7]

[0000858877-22-000004:mdna:8]
[same as prior period, unchanged from 0000858877-21-000018:mdna:8]

[0000858877-22-000004:mdna:9]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:10]
In the second quarter of fiscal 2022, we delivered solid revenue growth and strong profitability. As customers are defining their hybrid work strategy, we remain focused on executing and increasing our investments in our technologies to assist in that transition. Our business performed well in a highly dynamic, supply constrained and inflationary environment. Total revenue increased by 6% compared with the second quarter of fiscal 2021. Our product revenue reflected growth in Secure, Agile Networks; Internet for the Future; End-to-End Security; and Optimized Application Experiences; partially offset by a decline in Hybrid Work. While our revenue growth was solid, it was negatively impacted by supply constraints seen industry wide. We continue to manage these significant supply constraints due to component shortages and are taking multiple steps in order to mitigate the supply shortages and deliver products to our customers. We expect these supply constraints to continue through the second half of fiscal 2022. We continued to make progress in the transition of our business model delivering increased software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-22-000004:mdna:11]
Within total revenue, product revenue increased by 9% and service revenue decreased by 1%. In the second quarter of fiscal 2022, total software revenue was $3.8 billion across all product areas and service, an increase of 6%. Within total software revenue, subscription revenue increased 12%. Total gross margin decreased by 1.8 percentage points. Product gross margin decreased by 2.7 percentage points, largely driven by increased costs related to supply constraints. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 0.7 percentage points. Operating income as a percentage of revenue increased by 0.5 percentage points. Diluted earnings per share increased 18%, driven by a 17% increase in net income and a decrease in diluted share count of 29 million shares.

[0000858877-22-000004:mdna:12]
In terms of our geographic segments, revenue from the Americas increased $177 million, EMEA revenue increased by $357 million and APJC revenue increased by $226 million. The “BRICM” countries experienced product revenue growth of 7% in the aggregate, driven by an increase in product revenue across each of the BRICM countries except Brazil.

[0000858877-22-000004:mdna:13]
From a customer market standpoint, we experienced product revenue growth in the enterprise, commercial and service provider markets, partially offset by a product revenue decline in the public sector market. We continued to see improvement in business momentum in our customer markets.

[0000858877-22-000004:mdna:14]
From a product category perspective, the product revenue increase of 9% was driven by growth in revenue for Secure, Agile Networks of 7%; Internet for the Future of 42%; End-to-End Security of 7%; and Optimized Application Experiences of 12%; partially offset by a product revenue decline in Hybrid Work of 9%.

[0000858877-22-000004:mdna:15]
[same as prior period, unchanged from 0000858877-21-000018:mdna:51]

[0000858877-22-000004:mdna:16]
[same as prior period, unchanged from 0000858877-21-000018:mdna:15]

[0000858877-22-000004:mdna:17]
[same as prior period, unchanged from 0000858877-21-000018:mdna:16]

[0000858877-22-000004:mdna:18]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:19]
Total revenue increased 7%, with product revenue increasing 10% and service revenue was flat. Total gross margin decreased 1.5 percentage points due to increased costs related to supply constraints, and to a lesser extent, pricing erosion and unfavorable impacts from product mix. As a percentage of revenue, research, and development, sales and marketing, and general and administrative expenses collectively decreased by 1.1 percentage points. Operating income as a percentage of revenue increased by 2.8 percentage points. Diluted earnings per share increased 27%, driven by a 26% increase in net income, primarily driven by higher revenue and lower restructuring and other charges.

[0000858877-22-000004:mdna:20]
[same as prior period, unchanged from 0000858877-21-000018:mdna:17]

[0000858877-22-000004:mdna:21]
[same as prior period, unchanged from 0000858877-21-000018:mdna:18]

[0000858877-22-000004:mdna:22]
[same as prior period, unchanged from 0000858877-21-000018:mdna:19]

[0000858877-22-000004:mdna:23]
[same as prior period, unchanged from 0000858877-21-000018:mdna:20]

[0000858877-22-000004:mdna:24]
[same as prior period, unchanged from 0000858877-21-000018:mdna:21]

[0000858877-22-000004:mdna:25]
[same as prior period, unchanged from 0000858877-21-000018:mdna:22]

[0000858877-22-000004:mdna:26]
[same as prior period, unchanged from 0000858877-21-000018:mdna:23]

[0000858877-22-000004:mdna:27]
[same as prior period, unchanged from 0000858877-21-000018:mdna:24]

[0000858877-22-000004:mdna:28]
[same as prior period, unchanged from 0000858877-21-000018:mdna:25]

[0000858877-22-000004:mdna:29]
[same as prior period, unchanged from 0000858877-21-000018:mdna:26]

[0000858877-22-000004:mdna:30]
[same as prior period, unchanged from 0000858877-21-000018:mdna:27]

[0000858877-22-000004:mdna:31]
[same as prior period, unchanged from 0000858877-21-000018:mdna:28]

[0000858877-22-000004:mdna:32]
[same as prior period, unchanged from 0000858877-21-000018:mdna:29]

[0000858877-22-000004:mdna:33]
[same as prior period, unchanged from 0000858877-21-000018:mdna:31]

[0000858877-22-000004:mdna:34]
[same as prior period, unchanged from 0000858877-21-000018:mdna:32]

[0000858877-22-000004:mdna:35]
[same as prior period, unchanged from 0000858877-21-000018:mdna:33]

[0000858877-22-000004:mdna:36]
[same as prior period, unchanged from 0000858877-21-000018:mdna:34]

[0000858877-22-000004:mdna:37]
[same as prior period, unchanged from 0000858877-21-000018:mdna:35]

[0000858877-22-000004:mdna:38]
[same as prior period, unchanged from 0000858877-21-000018:mdna:36]

[0000858877-22-000004:mdna:39]
The following is a summary of our other key financial measures for the second quarter of fiscal 2022 (in millions):

[0000858877-22-000004:mdna:40]
|  |  | January 29,2022 |  | July 31,2021 |
| Cash and cash equivalents and investments |  | $ | 21,113 |  |  | $ | 24,518 |  |
| Remaining performance obligations |  | $ | 30,518 |  |  | $ | 30,893 |  |
| Inventories |  | $ | 2,059 |  |  | $ | 1,559 |  |

[0000858877-22-000004:mdna:41]
|  |  | Six Months Ended |
|  |  | January 29,2022 |  | January 23,2021 |
| Cash provided by operating activities |  | $ | 5,888 |  |  | $ | 7,070 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 5,080 |  |  | $ | 1,601 |  |
| Dividends paid |  | $ | 3,102 |  |  | $ | 3,041 |  |

[0000858877-22-000004:mdna:42]
[same as prior period, unchanged from 0000858877-21-000018:mdna:40]

[0000858877-22-000004:mdna:43]
[same as prior period, unchanged from 0000858877-21-000018:mdna:41]

[0000858877-22-000004:mdna:44]
[same as prior period, unchanged from 0000858877-21-000018:mdna:42]

[0000858877-22-000004:mdna:45]
[same as prior period, unchanged from 0000858877-21-000018:mdna:43]

[0000858877-22-000004:mdna:46]
The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The COVID-19 pandemic did not have a material impact on our significant judgments, assumptions and estimates that are reflected in our results for the second quarter and first six months of fiscal 2022. These estimates are listed in our Annual Report on Form 10-K for the year ending July 31, 2021, and include: goodwill and identified purchased intangible assets and income taxes, among other items. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-22-000004:mdna:47]
[same as prior period, unchanged from 0000858877-21-000018:mdna:45]

[0000858877-22-000004:mdna:48]
[same as prior period, unchanged from 0000858877-21-000018:mdna:46]

[0000858877-22-000004:mdna:49]
[same as prior period, unchanged from 0000858877-21-000018:mdna:47]

[0000858877-22-000004:mdna:50]
[same as prior period, unchanged from 0000858877-21-000018:mdna:48]

[0000858877-22-000004:mdna:51]
[same as prior period, unchanged from 0000858877-21-000018:mdna:49]

[0000858877-22-000004:mdna:52]
47

[0000858877-22-000004:mdna:53]
[same as prior period, unchanged from 0000858877-21-000018:mdna:52]

[0000858877-22-000004:mdna:54]
[same as prior period, unchanged from 0000858877-21-000018:mdna:53]

[0000858877-22-000004:mdna:55]
[same as prior period, unchanged from 0000858877-21-000018:mdna:50]

[0000858877-22-000004:mdna:56]
[same as prior period, unchanged from 0000858877-21-000018:mdna:54]

[0000858877-22-000004:mdna:57]
[same as prior period, unchanged from 0000858877-21-000018:mdna:55]

[0000858877-22-000004:mdna:58]
[same as prior period, unchanged from 0000858877-21-000018:mdna:56]

[0000858877-22-000004:mdna:59]
Our provision for inventory was $45 million and $65 million for the first six months of fiscal 2022 and 2021, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $80 million and $44 million for the first six months of fiscal 2022 and 2021, respectively. If there were to be a sudden and significant decrease in demand for our products, if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, or if supply constraints were to continue, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. We continue to manage through significant supply constraints seen industry wide due to component shortages caused, in part, by the COVID-19 pandemic. For further discussion around the Supply Constraints Impacts and Risks, see Result of Operations—Product Gross Margin and Liquidity and Capital Resources—Inventory Supply Chain.

[0000858877-22-000004:mdna:60]
Loss Contingencies

[0000858877-22-000004:mdna:61]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-22-000004:mdna:62]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-22-000004:mdna:63]
[same as prior period, unchanged from 0000858877-21-000018:mdna:61]

[0000858877-22-000004:mdna:64]
[same as prior period, unchanged from 0000858877-21-000018:mdna:62]

[0000858877-22-000004:mdna:65]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first six months of fiscal 2022 and 2021.

[0000858877-22-000004:mdna:66]
[same as prior period, unchanged from 0000858877-21-000018:mdna:64]

[0000858877-22-000004:mdna:67]
48

[0000858877-22-000004:mdna:68]
[same as prior period, unchanged from 0000858877-21-000018:mdna:66]

[0000858877-22-000004:mdna:69]
[same as prior period, unchanged from 0000858877-21-000018:mdna:67]

[0000858877-22-000004:mdna:70]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts.

[0000858877-22-000004:mdna:71]
[same as prior period, unchanged from 0000858877-21-000018:mdna:69]

[0000858877-22-000004:mdna:72]
[same as prior period, unchanged from 0000858877-21-000018:mdna:70]

[0000858877-22-000004:mdna:73]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 17.5% and 21.8% in the second quarter of fiscal 2022 and 2021, respectively, and 18.0% and 20.5% in the first six months of fiscal 2022 and 2021, respectively.

[0000858877-22-000004:mdna:74]
[same as prior period, unchanged from 0000858877-21-000018:mdna:72]

[0000858877-22-000004:mdna:75]
[same as prior period, unchanged from 0000858877-21-000018:mdna:73]

[0000858877-22-000004:mdna:76]
[same as prior period, unchanged from 0000858877-21-000018:mdna:74]

[0000858877-22-000004:mdna:77]
[same as prior period, unchanged from 0000858877-21-000018:mdna:76]

[0000858877-22-000004:mdna:78]
[same as prior period, unchanged from 0000858877-21-000018:mdna:77]

[0000858877-22-000004:mdna:79]
[same as prior period, unchanged from 0000858877-21-000018:mdna:78]

[0000858877-22-000004:mdna:80]
[same as prior period, unchanged from 0000858877-21-000018:mdna:79]

[0000858877-22-000004:mdna:81]
[same as prior period, unchanged from 0000858877-21-000018:mdna:80]

[0000858877-22-000004:mdna:82]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |  | Variance in Percent |  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,353 |  |  | $ | 8,572 |  |  | $ | 781 |  |  | 9 | % |  | $ | 18,882 |  |  | $ | 17,159 |  |  | $ | 1,723 |  |  | 10 | % |
| Percentage of revenue |  | 73.5 | % |  | 71.7 | % |  |  |  |  |  | 73.7 | % |  | 71.8 | % |  |  |  |  |
| Service |  | 3,367 |  |  | 3,388 |  |  | (21) |  |  | (1) | % |  | 6,738 |  |  | 6,730 |  |  | 8 |  |  | — | % |
| Percentage of revenue |  | 26.5 | % |  | 28.3 | % |  |  |  |  |  | 26.3 | % |  | 28.2 | % |  |  |  |  |
| Total |  | $ | 12,720 |  |  | $ | 11,960 |  |  | $ | 760 |  |  | 6 | % |  | $ | 25,620 |  |  | $ | 23,889 |  |  | $ | 1,731 |  |  | 7 | % |

[0000858877-22-000004:mdna:83]
[same as prior period, unchanged from 0000858877-21-000018:mdna:82]

[0000858877-22-000004:mdna:84]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |  | Variance in Percent |  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,146 |  |  | $ | 6,969 |  |  | $ | 177 |  |  | 3 | % |  | $ | 14,706 |  |  | $ | 14,168 |  |  | $ | 538 |  |  | 4 | % |
| Percentage of revenue |  | 56.2 | % |  | 58.3 | % |  |  |  |  |  | 57.4 | % |  | 59.3 | % |  |  |  |  |
| EMEA |  | 3,564 |  |  | 3,207 |  |  | 357 |  |  | 11 | % |  | 6,867 |  |  | 6,171 |  |  | 696 |  |  | 11 | % |
| Percentage of revenue |  | 28.0 | % |  | 26.8 | % |  |  |  |  |  | 26.8 | % |  | 25.8 | % |  |  |  |  |
| APJC |  | 2,010 |  |  | 1,784 |  |  | 226 |  |  | 13 | % |  | 4,046 |  |  | 3,551 |  |  | 495 |  |  | 14 | % |
| Percentage of revenue |  | 15.8 | % |  | 14.9 | % |  |  |  |  |  | 15.8 | % |  | 14.9 | % |  |  |  |  |
| Total |  | $ | 12,720 |  |  | $ | 11,960 |  |  | $ | 760 |  |  | 6 | % |  | $ | 25,620 |  |  | $ | 23,889 |  |  | $ | 1,731 |  |  | 7 | % |

[0000858877-22-000004:mdna:85]
[same as prior period, unchanged from 0000858877-21-000018:mdna:84]

[0000858877-22-000004:mdna:86]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:87]
Total revenue increased by 6%. Product revenue increased by 9% and service revenue decreased by 1%. Our total revenue reflected growth across each of our geographic segments. Product revenue for the emerging countries of BRICM, in the aggregate, experienced product revenue growth of 7%, with growth in each of these countries except Brazil.

[0000858877-22-000004:mdna:88]
[same as prior period, unchanged from 0000858877-21-000018:mdna:87]

[0000858877-22-000004:mdna:89]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:90]
Total revenue increased by 7%. Product revenue increased by 10% and service revenue was flat. Our total revenue reflected growth across each of our geographic segments. The emerging countries of BRICM, in the aggregate, experienced product revenue growth of 14%, with growth in each of these countries except Russia.

[0000858877-22-000004:mdna:91]
[same as prior period, unchanged from 0000858877-21-000018:mdna:88]

[0000858877-22-000004:mdna:92]
[same as prior period, unchanged from 0000858877-21-000018:mdna:89]

[0000858877-22-000004:mdna:93]
[same as prior period, unchanged from 0000858877-21-000018:mdna:90]

[0000858877-22-000004:mdna:94]
[same as prior period, unchanged from 0000858877-21-000018:mdna:91]

[0000858877-22-000004:mdna:95]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |  | Variance in Percent |  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,127 |  |  | $ | 4,888 |  |  | $ | 239 |  |  | 5 | % |  | $ | 10,649 |  |  | $ | 10,017 |  |  | $ | 632 |  |  | 6 | % |
| Percentage of product revenue |  | 54.8 | % |  | 57.1 | % |  |  |  |  |  | 56.4 | % |  | 58.4 | % |  |  |  |  |
| EMEA |  | 2,760 |  |  | 2,438 |  |  | 322 |  |  | 13 | % |  | 5,273 |  |  | 4,648 |  |  | 625 |  |  | 13 | % |
| Percentage of product revenue |  | 29.5 | % |  | 28.4 | % |  |  |  |  |  | 27.9 | % |  | 27.1 | % |  |  |  |  |
| APJC |  | 1,466 |  |  | 1,246 |  |  | 220 |  |  | 18 | % |  | 2,961 |  |  | 2,494 |  |  | 467 |  |  | 19 | % |
| Percentage of product revenue |  | 15.7 | % |  | 14.5 | % |  |  |  |  |  | 15.7 | % |  | 14.5 | % |  |  |  |  |
| Total |  | $ | 9,353 |  |  | $ | 8,572 |  |  | $ | 781 |  |  | 9 | % |  | $ | 18,882 |  |  | $ | 17,159 |  |  | $ | 1,723 |  |  | 10 | % |

[0000858877-22-000004:mdna:96]
[same as prior period, unchanged from 0000858877-21-000018:mdna:93]

[0000858877-22-000004:mdna:97]
[same as prior period, unchanged from 0000858877-21-000018:mdna:95]

[0000858877-22-000004:mdna:98]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:99]
Product revenue in the Americas segment increased by 5%, with growth in the service provider, enterprise and commercial markets, partially offset by a decline in the public sector market. From a country perspective, product revenue increased in the United States, Canada and Mexico by 6%, 1%, and 9%, respectively, partially offset by a decline in product revenue of 10% in Brazil.

[0000858877-22-000004:mdna:100]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:101]
Product revenue in the Americas segment increased by 6%, driven by growth in the service provider, enterprise, and commercial markets, partially offset by a decline in the public sector market. From a country perspective, product revenue increased in the United States, Canada, Mexico and Brazil by 7%, 10%, 10% and 7%, respectively.

[0000858877-22-000004:mdna:102]
[same as prior period, unchanged from 0000858877-21-000018:mdna:97]

[0000858877-22-000004:mdna:103]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:104]
Product revenue in the EMEA segment increased by 13%, with growth in all customer markets. Product revenue from emerging countries within EMEA increased by 37% and product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, increased by 8%. From a country perspective, product revenue increased by 3% in Germany and 33% in the United Kingdom, partially offset by a decline of 12% in France.

[0000858877-22-000004:mdna:105]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:106]
Product revenue in the EMEA segment increased by 13%, with growth in all customer markets. Product revenue from emerging countries within EMEA increased by 28% and product revenue for the remainder of the EMEA segment increased by 10%. From a country perspective, product revenue increased by 3% in Germany and 23% in the United Kingdom, partially offset by a decline of 3% in France.

[0000858877-22-000004:mdna:107]
[same as prior period, unchanged from 0000858877-21-000018:mdna:99]

[0000858877-22-000004:mdna:108]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:109]
Product revenue in the APJC segment increased by 18%, driven by growth in the enterprise, commercial and public sector markets, partially offset by a decline in the service provider market. From a country perspective, product revenue increased in Australia, India and China by 30%, 13% and 12%, respectively, partially offset by a decline of 1% in Japan.

[0000858877-22-000004:mdna:110]
[same as prior period, unchanged from 0000858877-21-000018:mdna:101]

[0000858877-22-000004:mdna:111]
[same as prior period, unchanged from 0000858877-21-000018:mdna:102]

[0000858877-22-000004:mdna:112]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:113]
Product revenue in the APJC segment increased by 19%, with growth across each of the customer markets. From a country perspective, product revenue increased in Australia, India and China by 32%, 27% and 16%, respectively, partially offset by a decline of 6% in Japan.

[0000858877-22-000004:mdna:114]
[same as prior period, unchanged from 0000858877-21-000018:mdna:103]

[0000858877-22-000004:mdna:115]
[same as prior period, unchanged from 0000858877-21-000018:mdna:104]

[0000858877-22-000004:mdna:116]
[same as prior period, unchanged from 0000858877-21-000018:mdna:105]

[0000858877-22-000004:mdna:117]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |  | Variance in Percent |  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Secure, Agile Networks |  | $ | 5,898 |  |  | $ | 5,489 |  |  | $ | 409 |  |  | 7 | % |  | $ | 11,866 |  |  | $ | 10,923 |  |  | $ | 943 |  |  | 9 | % |
| Hybrid Work |  | 1,067 |  |  | 1,167 |  |  | (100) |  |  | (9) | % |  | 2,176 |  |  | 2,360 |  |  | (184) |  |  | (8) | % |
| End-to-End Security |  | 883 |  |  | 822 |  |  | 61 |  |  | 7 | % |  | 1,778 |  |  | 1,684 |  |  | 94 |  |  | 6 | % |
| Internet for the Future |  | 1,322 |  |  | 931 |  |  | 391 |  |  | 42 | % |  | 2,697 |  |  | 1,872 |  |  | 825 |  |  | 44 | % |
| Optimized Application Experiences |  | 180 |  |  | 161 |  |  | 19 |  |  | 12 | % |  | 361 |  |  | 314 |  |  | 47 |  |  | 15 | % |
| Other Products |  | 2 |  |  | 3 |  |  | (1) |  |  | (28) | % |  | 5 |  |  | 6 |  |  | (1) |  |  | (10) | % |
| Total |  | $ | 9,353 |  |  | $ | 8,572 |  |  | $ | 781 |  |  | 9 | % |  | $ | 18,882 |  |  | $ | 17,159 |  |  | $ | 1,723 |  |  | 10 | % |

[0000858877-22-000004:mdna:118]
[same as prior period, unchanged from 0000858877-21-000018:mdna:107]

[0000858877-22-000004:mdna:119]
[same as prior period, unchanged from 0000858877-21-000018:mdna:109]

[0000858877-22-000004:mdna:120]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:121]
The Secure, Agile Networks product category represents our core networking offerings related to switching, enterprise routing, wireless, and compute. Secure, Agile Networks revenue increased by 7%, or $409 million, with growth across the portfolio except enterprise routing. Revenue grew in both campus switching and data center switching. This was primarily driven by strong growth in our Catalyst 9000 series, Nexus 9000 series and Meraki switching offerings. We experienced a decrease in sales of our enterprise routing products primarily driven by declines in our Access offerings partially offset by growth in our SD-WAN offerings. Wireless had strong double-digit growth driven by our WiFi-6 products and Meraki offerings. Revenue from compute grew primarily driven by our servers.

[0000858877-22-000004:mdna:122]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:123]
Revenue from the Secure, Agile Networks product category increased 9%, or $943 million, with growth across the portfolio except enterprise routing. Revenue grew in both campus switching and data center switching, primarily driven by growth in our Catalyst 9000 series, Nexus 9000 series and Meraki switching offerings. The decrease in enterprise routing was primarily driven by declines in our Access offerings, partially offset by growth in our Edge and SD-WAN offerings. Wireless had strong double-digit growth driven by our WiFi-6 products and Meraki offerings. Revenue from compute grew primarily driven by our servers.

[0000858877-22-000004:mdna:124]
[same as prior period, unchanged from 0000858877-21-000018:mdna:111]

[0000858877-22-000004:mdna:125]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:126]
The Hybrid Work product category includes our collaboration and contact center offerings. Revenue in our Hybrid Work product category decreased by 9%, or $100 million, driven by declines in our Collaboration Devices and Meetings offerings, partially offset by growth in our Communication Platform as a Service (CPaaS) offerings.

[0000858877-22-000004:mdna:127]
[same as prior period, unchanged from 0000858877-21-000018:mdna:120]

[0000858877-22-000004:mdna:128]
[same as prior period, unchanged from 0000858877-21-000018:mdna:121]

[0000858877-22-000004:mdna:129]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:130]
Revenue in our Hybrid Work product category decreased by 8%, or $184 million, with declines in our Collaboration Devices, Meetings, Calling and Contact Center offerings, partially offset by growth in our CPaaS offerings.

[0000858877-22-000004:mdna:131]
[same as prior period, unchanged from 0000858877-21-000018:mdna:113]

[0000858877-22-000004:mdna:132]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:133]
Revenue in our End-to-End Security product category increased 7%, or $61 million primarily driven by double-digit growth in our zero-trust portfolio driven by continued momentum with our Duo offerings. We also experienced growth in our cloud-based solutions, perpetual and security hardware offerings and Unified Threat Management offerings, partially offset by declines in our Network Security offerings.

[0000858877-22-000004:mdna:134]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:135]
Revenue in our End-to-End Security product category increased by 6%, or $94 million, driven by growth in our zero-trust portfolio, Unified Threat Management offerings and cloud-based solutions, partially offset by declines in our Network Security offerings.

[0000858877-22-000004:mdna:136]
[same as prior period, unchanged from 0000858877-21-000018:mdna:115]

[0000858877-22-000004:mdna:137]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:138]
The Internet for the Future product category includes our routed optical networking, public 5G, silicon and optics offerings. Revenue in our Internet for the Future product category increased by 42%, or $391 million, driven by the growth in the webscale provider market. This was primarily driven by strong growth in our Cisco 8000 portfolio and ASR 9000 series offerings. We also saw a benefit from our acquisition of Acacia in the third quarter of fiscal 2021.

[0000858877-22-000004:mdna:139]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:140]
Revenue in our Internet for the Future product category increased 44%, or $825 million, driven by growth in the webscale provider market. This was primarily driven by growth in our Cisco 8000 portfolio, NCS 5500 and ASR 9000 series offerings. We also saw a benefit from our acquisition of Acacia in the third quarter of fiscal 2021.

[0000858877-22-000004:mdna:141]
[same as prior period, unchanged from 0000858877-21-000018:mdna:117]

[0000858877-22-000004:mdna:142]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:143]
The Optimized Application Experiences product category includes our full stack observability and cloud-native platforms offerings. Revenue in our Optimized Application Experiences product category increased 12%, or $19 million, driven by growth in our ThousandEyes and Intersight offerings.

[0000858877-22-000004:mdna:144]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:145]
Revenue in our Optimized Application Experiences product category increased by 15%, or $47 million, driven by growth in our ThousandEyes and Intersight offerings.

[0000858877-22-000004:mdna:146]
[same as prior period, unchanged from 0000858877-21-000018:mdna:134]

[0000858877-22-000004:mdna:147]
[same as prior period, unchanged from 0000858877-21-000018:mdna:135]

[0000858877-22-000004:mdna:148]
[same as prior period, unchanged from 0000858877-21-000018:mdna:122]

[0000858877-22-000004:mdna:149]
[same as prior period, unchanged from 0000858877-21-000018:mdna:123]

[0000858877-22-000004:mdna:150]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |  | Variance in Percent |  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,019 |  |  | $ | 2,081 |  |  | $ | (62) |  |  | (3) | % |  | $ | 4,057 |  |  | $ | 4,151 |  |  | $ | (94) |  |  | (2) | % |
| Percentage of service revenue |  | 60.0 | % |  | 61.4 | % |  |  |  |  |  | 60.2 | % |  | 61.7 | % |  |  |  |  |
| EMEA |  | 804 |  |  | 769 |  |  | 35 |  |  | 5 | % |  | 1,594 |  |  | 1,523 |  |  | 71 |  |  | 5 | % |
| Percentage of service revenue |  | 23.9 | % |  | 22.7 | % |  |  |  |  |  | 23.7 | % |  | 22.6 | % |  |  |  |  |
| APJC |  | 544 |  |  | 538 |  |  | 6 |  |  | 1 | % |  | 1,086 |  |  | 1,057 |  |  | 29 |  |  | 3 | % |
| Percentage of service revenue |  | 16.1 | % |  | 15.9 | % |  |  |  |  |  | 16.1 | % |  | 15.7 | % |  |  |  |  |
| Total |  | $ | 3,367 |  |  | $ | 3,388 |  |  | $ | (21) |  |  | (1) | % |  | $ | 6,738 |  |  | $ | 6,730 |  |  | $ | 8 |  |  | — | % |

[0000858877-22-000004:mdna:151]
[same as prior period, unchanged from 0000858877-21-000018:mdna:125]

[0000858877-22-000004:mdna:152]
Service revenue decreased 1% in the second quarter of fiscal 2022 compared with the second quarter of fiscal 2021. This was driven by a decrease in advisory services and software support offerings, partially offset by an increase in solution support offerings. Service revenue was flat in the first six months of fiscal 2022 compared to the first six months of fiscal 2021 driven by revenue growth in our maintenance business and solution support offerings offset by declines in our advisory services and software support offerings. Service revenue increased in the EMEA and APJC segments, partially offset by lower revenue in the Americas segment for the second quarter and first six months of fiscal 2022.

[0000858877-22-000004:mdna:153]
[same as prior period, unchanged from 0000858877-21-000018:mdna:127]

[0000858877-22-000004:mdna:154]
[same as prior period, unchanged from 0000858877-21-000018:mdna:128]

[0000858877-22-000004:mdna:155]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,784 |  |  | $ | 5,528 |  |  | 61.8 | % |  | 64.5 | % |  | $ | 11,640 |  |  | $ | 10,909 |  |  | 61.6 | % |  | 63.6 | % |
| Service |  | 2,265 |  |  | 2,256 |  |  | 67.3 | % |  | 66.6 | % |  | 4,462 |  |  | 4,456 |  |  | 66.2 | % |  | 66.2 | % |
| Total |  | $ | 8,049 |  |  | $ | 7,784 |  |  | 63.3 | % |  | 65.1 | % |  | $ | 16,102 |  |  | $ | 15,365 |  |  | 62.8 | % |  | 64.3 | % |

[0000858877-22-000004:mdna:156]
[same as prior period, unchanged from 0000858877-21-000018:mdna:144]

[0000858877-22-000004:mdna:157]
[same as prior period, unchanged from 0000858877-21-000018:mdna:145]

[0000858877-22-000004:mdna:158]
[same as prior period, unchanged from 0000858877-21-000018:mdna:130]

[0000858877-22-000004:mdna:159]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the second quarter and first six months of fiscal 2022, as compared with the corresponding prior year periods:

[0000858877-22-000004:mdna:160]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Six Months Ended |
| Fiscal 2021 |  | 64.5 | % |  | 63.6 | % |
| Productivity (1) |  | (1.7) | % |  | (1.3) | % |
| Product pricing |  | (0.2) | % |  | (0.5) | % |
| Mix of products sold |  | (0.4) | % |  | (0.2) | % |
| Legal and indemnification charge |  | — | % |  | 0.3 | % |
| Others |  | (0.4) | % |  | (0.3) | % |
| Fiscal 2022 |  | 61.8 | % |  | 61.6 | % |

[0000858877-22-000004:mdna:161]
[same as prior period, unchanged from 0000858877-21-000018:mdna:133]

[0000858877-22-000004:mdna:162]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:163]
Product gross margin decreased by 2.7 percentage points primarily driven by lower productivity, largely driven by increased costs related to supply constraints from freight, expedites, and component costs. We also saw slight pricing erosion and unfavorable product mix. The unfavorable mix was driven by changes in the proportion of products sold from Internet for the Future, partially offset by favorable product mix in Secure, Agile Networks, as compared to the corresponding period of fiscal 2021.

[0000858877-22-000004:mdna:164]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:165]
Product gross margin decreased by 2.0 percentage points primarily driven by lower productivity, largely driven by increased costs related to supply chain constraints from freight, expedites, and component costs, pricing erosion and unfavorable impacts from product mix.

[0000858877-22-000004:mdna:166]
[same as prior period, unchanged from 0000858877-21-000018:mdna:138]

[0000858877-22-000004:mdna:167]
[same as prior period, unchanged from 0000858877-21-000018:mdna:139]

[0000858877-22-000004:mdna:168]
[same as prior period, unchanged from 0000858877-21-000018:mdna:140]

[0000858877-22-000004:mdna:169]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:170]
Our service gross margin percentage increased by 0.7 percentage points primarily due to lower delivery costs and favorable mix of service offerings, partially offset by lower sales volume.

[0000858877-22-000004:mdna:171]
Our service gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service

[0000858877-22-000004:mdna:172]
55

[0000858877-22-000004:mdna:173]
[same as prior period, unchanged from 0000858877-21-000018:mdna:159]

[0000858877-22-000004:mdna:174]
[same as prior period, unchanged from 0000858877-21-000018:mdna:160]

[0000858877-22-000004:mdna:175]
business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-22-000004:mdna:176]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:177]
Service gross margin was flat primarily due to favorable mix and lower delivery costs offset by higher headcount-related costs.

[0000858877-22-000004:mdna:178]
[same as prior period, unchanged from 0000858877-21-000018:mdna:146]

[0000858877-22-000004:mdna:179]
[same as prior period, unchanged from 0000858877-21-000018:mdna:147]

[0000858877-22-000004:mdna:180]
|  | Three Months Ended |  | Six Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,611 |  |  | $ | 4,705 |  |  | 64.5 | % |  | 67.5 | % |  | $ | 9,486 |  |  | $ | 9,552 |  |  | 64.5 | % |  | 67.4 | % |
| EMEA | 2,381 |  |  | 2,145 |  |  | 66.8 | % |  | 66.9 | % |  | 4,509 |  |  | 4,038 |  |  | 65.7 | % |  | 65.4 | % |
| APJC | 1,337 |  |  | 1,155 |  |  | 66.5 | % |  | 64.8 | % |  | 2,654 |  |  | 2,268 |  |  | 65.6 | % |  | 63.9 | % |
| Segment total | 8,328 |  |  | 8,005 |  |  | 65.5 | % |  | 66.9 | % |  | 16,649 |  |  | 15,858 |  |  | 65.0 | % |  | 66.4 | % |
| Unallocated corporate items (1) | (279) |  |  | (221) |  |  |  |  |  |  | (547) |  |  | (493) |  |  |  |  |  |
| Total | $ | 8,049 |  |  | $ | 7,784 |  |  | 63.3 | % |  | 65.1 | % |  | $ | 16,102 |  |  | $ | 15,365 |  |  | 62.8 | % |  | 64.3 | % |

[0000858877-22-000004:mdna:181]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-22-000004:mdna:182]
[same as prior period, unchanged from 0000858877-21-000018:mdna:150]

[0000858877-22-000004:mdna:183]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:184]
We experienced a gross margin percentage decrease in our Americas segment due to negative impacts from productivity, unfavorable impacts from product mix and pricing erosion.

[0000858877-22-000004:mdna:185]
Gross margin in our EMEA segment decreased slightly primarily due to lower productivity partially offset by higher service gross margin in this geographic segment.

[0000858877-22-000004:mdna:186]
The APJC segment gross margin percentage increase was due to favorable impacts from product mix and to a lesser degree, favorable pricing. Higher service gross margin also contributed to the increase in the gross margin in this geographic segment.

[0000858877-22-000004:mdna:187]
[same as prior period, unchanged from 0000858877-21-000018:mdna:155]

[0000858877-22-000004:mdna:188]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:189]
The Americas segment had a gross margin percentage decrease driven by negative impacts from productivity, pricing erosion and unfavorable product mix.

[0000858877-22-000004:mdna:190]
The gross margin percentage increase in our EMEA segment was primarily due to favorable product mix, partially offset by pricing erosion.

[0000858877-22-000004:mdna:191]
The APJC segment gross margin percentage increase was driven by favorable product mix, productivity improvements and favorable pricing.

[0000858877-22-000004:mdna:192]
[same as prior period, unchanged from 0000858877-21-000018:mdna:182]

[0000858877-22-000004:mdna:193]
[same as prior period, unchanged from 0000858877-21-000018:mdna:183]

[0000858877-22-000004:mdna:194]
[same as prior period, unchanged from 0000858877-21-000018:mdna:156]

[0000858877-22-000004:mdna:195]
[same as prior period, unchanged from 0000858877-21-000018:mdna:157]

[0000858877-22-000004:mdna:196]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |  | Variance in Percent |  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,670 |  |  | $ | 1,527 |  |  | $ | 143 |  |  | 9 | % |  | $ | 3,384 |  |  | $ | 3,139 |  |  | $ | 245 |  |  | 8 | % |
| Percentage of revenue | 13.1 | % |  | 12.8 | % |  |  |  |  |  | 13.2 | % |  | 13.1 | % |  |  |  |  |
| Sales and marketing | 2,266 |  |  | 2,277 |  |  | (11) |  |  | — | % |  | 4,527 |  |  | 4,494 |  |  | 33 |  |  | 1 | % |
| Percentage of revenue | 17.8 | % |  | 19.0 | % |  |  |  |  |  | 17.7 | % |  | 18.8 | % |  |  |  |  |
| General and administrative | 544 |  |  | 484 |  |  | 60 |  |  | 12 | % |  | 1,095 |  |  | 1,028 |  |  | 67 |  |  | 7 | % |
| Percentage of revenue | 4.3 | % |  | 4.0 | % |  |  |  |  |  | 4.3 | % |  | 4.3 | % |  |  |  |  |
| Total | $ | 4,480 |  |  | $ | 4,288 |  |  | $ | 192 |  |  | 4 | % |  | $ | 9,006 |  |  | $ | 8,661 |  |  | $ | 345 |  |  | 4 | % |
| Percentage of revenue | 35.2 | % |  | 35.9 | % |  |  |  |  |  | 35.2 | % |  | 36.3 | % |  |  |  |  |

[0000858877-22-000004:mdna:197]
[same as prior period, unchanged from 0000858877-21-000018:mdna:162]

[0000858877-22-000004:mdna:198]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:199]
R&D expenses increased due to higher headcount-related expenses, higher contracted services spending and higher share-based compensation expense, partially offset by lower discretionary spending.

[0000858877-22-000004:mdna:200]
[same as prior period, unchanged from 0000858877-21-000018:mdna:164]

[0000858877-22-000004:mdna:201]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:202]
R&D expenses increased primarily due to higher headcount-related expenses, higher contracted services spending, higher share-based compensation expense and higher acquisition-related costs, partially offset by lower discretionary spending.

[0000858877-22-000004:mdna:203]
[same as prior period, unchanged from 0000858877-21-000018:mdna:165]

[0000858877-22-000004:mdna:204]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:205]
Sales and marketing expenses decreased slightly due to lower headcount-related expenses and lower contracted services spending, partially offset by higher discretionary spending.

[0000858877-22-000004:mdna:206]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:207]
Sales and marketing expenses increased primarily due to higher discretionary spending.

[0000858877-22-000004:mdna:208]
[same as prior period, unchanged from 0000858877-21-000018:mdna:167]

[0000858877-22-000004:mdna:209]
For each of the second quarter and first six months of fiscal 2022, G&A expenses increased primarily due to higher acquisition and divestiture related costs.

[0000858877-22-000004:mdna:210]
[same as prior period, unchanged from 0000858877-21-000018:mdna:169]

[0000858877-22-000004:mdna:211]
In the second quarter of fiscal 2022, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $17 million, or 0.4%, compared with the second quarter of fiscal 2021.

[0000858877-22-000004:mdna:212]
In the first six months of fiscal 2022, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $1 million, compared with the first six months of fiscal 2021.

[0000858877-22-000004:mdna:213]
[same as prior period, unchanged from 0000858877-21-000018:mdna:195]

[0000858877-22-000004:mdna:214]
[same as prior period, unchanged from 0000858877-21-000018:mdna:196]

[0000858877-22-000004:mdna:215]
[same as prior period, unchanged from 0000858877-21-000018:mdna:171]

[0000858877-22-000004:mdna:216]
[same as prior period, unchanged from 0000858877-21-000018:mdna:172]

[0000858877-22-000004:mdna:217]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 201 |  |  | $ | 156 |  |  | $ | 403 |  |  | $ | 326 |  |
| Operating expenses |  | 79 |  |  | 39 |  |  | 163 |  |  | 75 |  |
| Total |  | $ | 280 |  |  | $ | 195 |  |  | $ | 566 |  |  | $ | 401 |  |

[0000858877-22-000004:mdna:218]
For each of the second quarter and first six months of fiscal 2022, the increase in amortization of purchased intangible assets was due largely to the amortization of purchased intangibles from our recent acquisitions.

[0000858877-22-000004:mdna:219]
[same as prior period, unchanged from 0000858877-21-000018:mdna:175]

[0000858877-22-000004:mdna:220]
We initiated a restructuring plan in fiscal 2021, which included a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas. The total pretax charges were estimated to be approximately $900 million. In connection with this restructuring plan, we have incurred cumulative charges of $894 million and completed this plan in fiscal 2022.

[0000858877-22-000004:mdna:221]
[same as prior period, unchanged from 0000858877-21-000018:mdna:177]

[0000858877-22-000004:mdna:222]
[same as prior period, unchanged from 0000858877-21-000018:mdna:178]

[0000858877-22-000004:mdna:223]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Operating income |  | $ | 3,487 |  |  | $ | 3,223 |  |  | $ | 6,925 |  |  | $ | 5,793 |  |
| Operating income as a percentage of revenue |  | 27.4 | % |  | 26.9 | % |  | 27.0 | % |  | 24.2 | % |

[0000858877-22-000004:mdna:224]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:225]
Operating income increased by 8%, and operating income as a percentage of revenue increased by 0.5 percentage points. These changes resulted primarily from a revenue increase and lower restructuring and other charges partially offset by a gross margin percentage decrease (driven primarily by lower productivity).

[0000858877-22-000004:mdna:226]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:227]
Operating income increased by 20%, and operating income as a percentage of revenue increased by 2.8 percentage points. These changes resulted primarily from a revenue increase and lower restructuring and other charges partially offset by a gross margin percentage decrease (driven by lower productivity, pricing erosion and unfavorable impacts from product mix).

[0000858877-22-000004:mdna:228]
[same as prior period, unchanged from 0000858877-21-000018:mdna:184]

[0000858877-22-000004:mdna:229]
[same as prior period, unchanged from 0000858877-21-000018:mdna:185]

[0000858877-22-000004:mdna:230]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |
| Interest income |  | $ | 111 |  |  | $ | 161 |  |  | $ | (50) |  |  | $ | 232 |  |  | $ | 335 |  |  | $ | (103) |  |
| Interest expense |  | (88) |  |  | (113) |  |  | 25 |  |  | (177) |  |  | (225) |  |  | 48 |  |
| Interest income (expense), net |  | $ | 23 |  |  | $ | 48 |  |  | $ | (25) |  |  | $ | 55 |  |  | $ | 110 |  |  | $ | (55) |  |

[0000858877-22-000004:mdna:231]
For each of the second quarter and first six months of fiscal 2022, the decrease in interest income was driven by lower interest rates and lower average balances of cash and available-for-sale debt investments. The decrease in interest expense was driven by a lower average debt balance.

[0000858877-22-000004:mdna:232]
[same as prior period, unchanged from 0000858877-21-000018:mdna:209]

[0000858877-22-000004:mdna:233]
[same as prior period, unchanged from 0000858877-21-000018:mdna:210]

[0000858877-22-000004:mdna:234]
[same as prior period, unchanged from 0000858877-21-000018:mdna:188]

[0000858877-22-000004:mdna:235]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |  | January 29,2022 |  | January 23,2021 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | 10 |  |  | $ | 9 |  |  | $ | 1 |  |  | $ | 16 |  |  | $ | 24 |  |  | $ | (8) |  |
| Marketable equity investments |  | (18) |  |  | — |  |  | (18) |  |  | (13) |  |  | (1) |  |  | (12) |  |
| Privately held investments |  | 121 |  |  | (17) |  |  | 138 |  |  | 326 |  |  | 25 |  |  | 301 |  |
| Net gains (losses) on investments |  | 113 |  |  | (8) |  |  | 121 |  |  | 329 |  |  | 48 |  |  | 281 |  |
| Other gains (losses), net |  | (20) |  |  | (8) |  |  | (12) |  |  | (49) |  |  | (15) |  |  | (34) |  |
| Other income (loss), net |  | $ | 93 |  |  | $ | (16) |  |  | $ | 109 |  |  | $ | 280 |  |  | $ | 33 |  |  | $ | 247 |  |

[0000858877-22-000004:mdna:236]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:237]
The change in net gains (losses) on marketable equity investments was attributable to market value fluctuations and the timing of recognition of gains and losses. The change in net gains (losses) on privately held investments was primarily due to higher net realized gains, higher net unrealized gains and lower impairment charges. The change in other gains (losses), net was primarily driven by impacts from our equity derivatives.

[0000858877-22-000004:mdna:238]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:239]
The change in net gains (losses) on available-for-sale debt investments was primarily attributable to lower realized gains as a result of market conditions, and the timing of sales of these investments. The change in net gains (losses) on marketable equity investments was attributable to market value fluctuations and the timing of recognition of gains and losses. The change in net gains (losses) on privately held investments was primarily due to higher net unrealized gains and higher net realized gains. The change in other gains (losses), net was primarily driven by higher donation expense and impacts from our equity derivatives.

[0000858877-22-000004:mdna:240]
[same as prior period, unchanged from 0000858877-21-000018:mdna:192]

[0000858877-22-000004:mdna:241]
Three Months Ended January 29, 2022 Compared with Three Months Ended January 23, 2021

[0000858877-22-000004:mdna:242]
The provision for income taxes resulted in an effective tax rate of 17.5% for the second quarter of fiscal 2022 compared with 21.8% for the second quarter of fiscal 2021. The decrease in the effective tax rate was primarily due to an increase in the tax benefit from share-based compensation windfall and a decrease in audit settlement expense in the second quarter of fiscal 2022 as compared to the second quarter of fiscal 2021.

[0000858877-22-000004:mdna:243]
Our effective tax rate will increase or decrease based upon the tax effect of the difference between the share-based compensation expenses and the benefits taken on our tax returns. We recognize excess tax benefits on a discrete basis and therefore anticipate the effective tax rate to vary from quarter to quarter depending on our share price in each period.

[0000858877-22-000004:mdna:244]
Six Months Ended January 29, 2022 Compared with Six Months Ended January 23, 2021

[0000858877-22-000004:mdna:245]
The provision for income taxes resulted in an effective tax rate of 18.0% for the first six months of fiscal 2022 compared with 20.5% for the first six months of fiscal 2021. The decrease in the effective tax rate was primarily due to an increase in the tax benefit from share-based compensation windfall and a decrease in audit settlement expense in fiscal 2022 as compared to fiscal 2021.

[0000858877-22-000004:mdna:246]
[same as prior period, unchanged from 0000858877-21-000018:mdna:220]

[0000858877-22-000004:mdna:247]
[same as prior period, unchanged from 0000858877-21-000018:mdna:221]

[0000858877-22-000004:mdna:248]
[same as prior period, unchanged from 0000858877-21-000018:mdna:197]

[0000858877-22-000004:mdna:249]
[same as prior period, unchanged from 0000858877-21-000018:mdna:198]

[0000858877-22-000004:mdna:250]
[same as prior period, unchanged from 0000858877-21-000018:mdna:199]

[0000858877-22-000004:mdna:251]
[same as prior period, unchanged from 0000858877-21-000018:mdna:200]

[0000858877-22-000004:mdna:252]
|  | January 29,2022 |  | July 31,2021 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 6,731 |  |  | $ | 9,175 |  |  | $ | (2,444) |  |
| Available-for-sale debt investments | 14,161 |  |  | 15,206 |  |  | (1,045) |  |
| Marketable equity securities | 221 |  |  | 137 |  |  | 84 |  |
| Total | $ | 21,113 |  |  | $ | 24,518 |  |  | $ | (3,405) |  |

[0000858877-22-000004:mdna:253]
The net decrease in cash and cash equivalents and investments in the first six months of fiscal 2022 was driven by cash returned to stockholders in the form of repurchases of common stock of $5.1 billion, cash dividends of $3.1 billion, a net decrease in debt of $2.0 billion, net cash paid for acquisitions and divestitures of $0.4 billion and capital expenditures of $0.2 billion. These uses of cash were partially offset by cash provided by operating activities of $5.9 billion and issuance of commercial paper of $2.0 billion.

[0000858877-22-000004:mdna:254]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our available-for-sale debt investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-22-000004:mdna:255]
[same as prior period, unchanged from 0000858877-21-000018:mdna:204]

[0000858877-22-000004:mdna:256]
[same as prior period, unchanged from 0000858877-21-000018:mdna:205]

[0000858877-22-000004:mdna:257]
[same as prior period, unchanged from 0000858877-21-000018:mdna:206]

[0000858877-22-000004:mdna:258]
|  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |
| Net cash provided by operating activities | $ | 5,888 |  |  | $ | 7,070 |  |
| Acquisition of property and equipment | (232) |  |  | (358) |  |
| Free cash flow | $ | 5,656 |  |  | $ | 6,712 |  |

[0000858877-22-000004:mdna:259]
[same as prior period, unchanged from 0000858877-21-000018:mdna:208]

[0000858877-22-000004:mdna:260]
60

[0000858877-22-000004:mdna:261]
[same as prior period, unchanged from 0000858877-21-000018:mdna:232]

[0000858877-22-000004:mdna:262]
[same as prior period, unchanged from 0000858877-21-000018:mdna:233]

[0000858877-22-000004:mdna:263]
[same as prior period, unchanged from 0000858877-21-000018:mdna:211]

[0000858877-22-000004:mdna:264]
[same as prior period, unchanged from 0000858877-21-000018:mdna:212]

[0000858877-22-000004:mdna:265]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| January 29, 2022 |  | $ | 0.37 |  |  | $ | 1,541 |  |  | 82 |  |  | $ | 58.36 |  |  | $ | 4,824 |  |  | $ | 6,365 |  |
| October 30, 2021 |  | $ | 0.37 |  |  | $ | 1,561 |  |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |  | $ | 1,817 |  |
| Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 31, 2021 |  | $ | 0.37 |  |  | $ | 1,562 |  |  | 15 |  |  | $ | 53.30 |  |  | $ | 791 |  |  | $ | 2,353 |  |
| May 1, 2021 |  | $ | 0.37 |  |  | $ | 1,560 |  |  | 10 |  |  | $ | 48.71 |  |  | $ | 510 |  |  | $ | 2,070 |  |
| January 23, 2021 |  | $ | 0.36 |  |  | $ | 1,521 |  |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |  | $ | 2,322 |  |
| October 24, 2020 |  | $ | 0.36 |  |  | $ | 1,520 |  |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |  | $ | 2,320 |  |

[0000858877-22-000004:mdna:266]
On February 16, 2022, our Board of Directors declared a quarterly dividend of $0.38 per common share to be paid on April 27, 2022 to all stockholders of record as of the close of business on April 6, 2022. Any future dividends are subject to the approval of our Board of Directors.

[0000858877-22-000004:mdna:267]
On February 16, 2022, our Board of Directors authorized a $15 billion increase to the stock repurchase program. The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $18 billion, with no termination date.

[0000858877-22-000004:mdna:268]
[same as prior period, unchanged from 0000858877-21-000018:mdna:216]

[0000858877-22-000004:mdna:269]
|  | January 29,2022 |  | July 31,2021 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 6,003 |  |  | $ | 5,766 |  |  | $ | 237 |  |

[0000858877-22-000004:mdna:270]
Our accounts receivable net, as of January 29, 2022 increased by approximately 4%, as compared with the end of fiscal 2021, primarily due to timing and amount of product and service billings in the second quarter of fiscal 2022 compared with the fourth quarter of fiscal 2021.

[0000858877-22-000004:mdna:271]
61

[0000858877-22-000004:mdna:272]
[same as prior period, unchanged from 0000858877-21-000018:mdna:242]

[0000858877-22-000004:mdna:273]
[same as prior period, unchanged from 0000858877-21-000018:mdna:243]

[0000858877-22-000004:mdna:274]
[same as prior period, unchanged from 0000858877-21-000018:mdna:222]

[0000858877-22-000004:mdna:275]
|  | January 29,2022 |  | July 31,2021 |  | July 25,2020 |  | Variance vs. July 31, 2021 |  | Variance vs. July 25, 2020 |
| Inventories | $ | 2,059 |  |  | $ | 1,559 |  |  | $ | 1,282 |  |  | $ | 500 |  |  | $ | 777 |  |
| Inventory purchase commitments | $ | 12,262 |  |  | $ | 10,254 |  |  | $ | 4,406 |  |  | $ | 2,008 |  |  | $ | 7,856 |  |
| Inventory deposits and prepayments | $ | 775 |  |  | $ | 162 |  |  | $ | 117 |  |  | $ | 613 |  |  | $ | 658 |  |

[0000858877-22-000004:mdna:276]
[same as prior period, unchanged from 0000858877-21-000018:mdna:224]

[0000858877-22-000004:mdna:277]
|  | January 29,2022 |  | July 31,2021 |  | July 25,2020 |  | Variance vs. July 31, 2021 |  | Variance vs.July 25, 2020 |
| Less than 1 year | $ | 9,224 |  |  | $ | 6,903 |  |  | $ | 3,994 |  |  | $ | 2,321 |  |  | $ | 5,230 |  |
| 1 to 3 years | 1,879 |  |  | 1,806 |  |  | 412 |  |  | 73 |  |  | 1,467 |  |
| 3 to 5 years | 1,159 |  |  | 1,545 |  |  | — |  |  | (386) |  |  | 1,159 |  |
| Total | $ | 12,262 |  |  | $ | 10,254 |  |  | $ | 4,406 |  |  | $ | 2,008 |  |  | $ | 7,856 |  |

[0000858877-22-000004:mdna:278]
Inventories and inventory purchase commitments increased as compared to the prior fiscal periods as we increased our balances in order to address significant supply constraints seen industry wide. Inventory as of January 29, 2022 increased by 32% and 61% from our inventory balances at the end of fiscal 2021 and fiscal 2020, respectively. Inventory purchase commitments with contract manufacturers and suppliers increased by 20% and 178% from our balances at the end of fiscal 2021 and fiscal 2020, respectively. These increases compared with the end of fiscal 2021 and fiscal 2020 were primarily due to arrangements to secure supply and pricing for certain product components and commitments with contract manufacturers to meet customer demand and to address extended lead times, as a result of the supply constraints. The increase in inventory deposits and prepayments from the end of fiscal 2021 and fiscal 2020 were primarily due to advance payments with suppliers to secure future supply. We have partnered with several of our key suppliers utilizing our volume purchasing and extending supply coverage, including revising supplier arrangements. Our inventory deposits and prepayments are to secure future supply with our contract manufacturers and suppliers. As discussed, our risks of future material excess and obsolete inventory and related losses are further outlined in the Result of Operations—Product Gross Margin section.

[0000858877-22-000004:mdna:279]
[same as prior period, unchanged from 0000858877-21-000018:mdna:227]

[0000858877-22-000004:mdna:280]
[same as prior period, unchanged from 0000858877-21-000018:mdna:228]

[0000858877-22-000004:mdna:281]
[same as prior period, unchanged from 0000858877-21-000018:mdna:229]

[0000858877-22-000004:mdna:282]
[same as prior period, unchanged from 0000858877-21-000018:mdna:230]

[0000858877-22-000004:mdna:283]
|  | January 29,2022 |  | July 31,2021 |  | Increase (Decrease) |
| Lease receivables, net | $ | 1,361 |  |  | $ | 1,697 |  |  | $ | (336) |  |
| Loan receivables, net | 4,514 |  |  | 5,117 |  |  | (603) |  |
| Financed service contracts, net | 2,146 |  |  | 2,450 |  |  | (304) |  |
| Total, net | $ | 8,021 |  |  | $ | 9,264 |  |  | $ | (1,243) |  |

[0000858877-22-000004:mdna:284]
[same as prior period, unchanged from 0000858877-21-000018:mdna:252]

[0000858877-22-000004:mdna:285]
[same as prior period, unchanged from 0000858877-21-000018:mdna:253]

[0000858877-22-000004:mdna:286]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services. The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed. Financing receivables decreased by 13%, as compared with the end of fiscal 2021.

[0000858877-22-000004:mdna:287]
[same as prior period, unchanged from 0000858877-21-000018:mdna:235]

[0000858877-22-000004:mdna:288]
The volume of channel partner financing was $13.4 billion and $12.8 billion for the first six months of fiscal 2022 and 2021, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.4 billion and $1.3 billion as of January 29, 2022 and July 31, 2021, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of January 29, 2022, the total maximum potential future payments related to these guarantees was approximately $166 million, of which approximately $9 million was recorded as deferred revenue.

[0000858877-22-000004:mdna:289]
[same as prior period, unchanged from 0000858877-21-000018:mdna:237]

[0000858877-22-000004:mdna:290]
[same as prior period, unchanged from 0000858877-21-000018:mdna:238]

[0000858877-22-000004:mdna:291]
|  | Maturity Date |  | January 29,2022 |  | July 31,2021 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | $ | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 9,500 |  |  | $ | 11,500 |  |

[0000858877-22-000004:mdna:292]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of January 29, 2022.

[0000858877-22-000004:mdna:293]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had $2.0 billion in commercial paper notes outstanding as of January 29, 2022 and no commercial paper notes outstanding as of July 31, 2021.

[0000858877-22-000004:mdna:294]
CISCO SYSTEMS, INC.

[0000858877-22-000004:mdna:295]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-22-000004:mdna:296]
Credit Facility  On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. The credit agreement is structured as an amendment and restatement of our 364-day credit agreement, which would have terminated on May 14, 2021. As of January 29, 2022, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.

[0000858877-22-000004:mdna:297]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

[0000858877-22-000004:mdna:298]
[same as prior period, unchanged from 0000858877-21-000018:mdna:246]

[0000858877-22-000004:mdna:299]
|  | January 29,2022 |  | July 31,2021 |  | Increase (Decrease) |
| Product | $ | 13,532 |  |  | $ | 13,270 |  |  | $ | 262 |  |
| Service | 16,986 |  |  | 17,623 |  |  | (637) |  |
| Total | $ | 30,518 |  |  | $ | 30,893 |  |  | $ | (375) |  |
| Current | $ | 16,310 |  |  | $ | 16,289 |  |  | $ | 21 |  |
| Noncurrent | 14,208 |  |  | 14,604 |  |  | (396) |  |
| Total | $ | 30,518 |  |  | $ | 30,893 |  |  | $ | (375) |  |

[0000858877-22-000004:mdna:300]
Total remaining performance obligations as of January 29, 2022 decreased 1% compared to the end of fiscal 2021. Remaining performance obligations for product increased 2% compared to the end of fiscal 2021. Remaining performance obligations for service decreased 4%. We expect approximately 53% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-22-000004:mdna:301]
[same as prior period, unchanged from 0000858877-21-000018:mdna:249]

[0000858877-22-000004:mdna:302]
|  | January 29,2022 |  | July 31,2021 |  | Increase (Decrease) |
| Product | $ | 9,767 |  |  | $ | 9,416 |  |  | $ | 351 |  |
| Service | 12,546 |  |  | 12,748 |  |  | (202) |  |
| Total | $ | 22,313 |  |  | $ | 22,164 |  |  | $ | 149 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 12,268 |  |  | $ | 12,148 |  |  | $ | 120 |  |
| Noncurrent | 10,045 |  |  | 10,016 |  |  | 29 |  |
| Total | $ | 22,313 |  |  | $ | 22,164 |  |  | $ | 149 |  |

[0000858877-22-000004:mdna:303]
[same as prior period, unchanged from 0000858877-21-000018:mdna:251]

[0000858877-22-000004:mdna:304]
CISCO SYSTEMS, INC.

[0000858877-22-000004:mdna:305]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-22-000004:mdna:306]
[same as prior period, unchanged from 0000858877-21-000018:mdna:254]

[0000858877-22-000004:mdna:307]
[same as prior period, unchanged from 0000858877-21-000018:mdna:255]

[0000858877-22-000004:mdna:308]
The income tax payable outstanding as of January 29, 2022 for the U.S. transition tax on accumulated earnings for foreign subsidiaries is $6.2 billion. Approximately $0.7 billion is payable in less than one year; $3.2 billion is payable between 1 to 3 years; and $2.3 billion is payable between 3 to 5 years.

[0000858877-22-000004:mdna:309]
[same as prior period, unchanged from 0000858877-21-000018:mdna:257]

[0000858877-22-000004:mdna:310]
[same as prior period, unchanged from 0000858877-21-000018:mdna:258]

[0000858877-22-000004:mdna:311]
[same as prior period, unchanged from 0000858877-21-000018:mdna:259]

[0000858877-22-000004:mdna:312]
We also have certain funding commitments primarily related to our privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.4 billion and $0.2 billion as of January 29, 2022 and July 31, 2021, respectively.

[0000858877-22-000004:mdna:313]
In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of January 29, 2022 there were no material unconsolidated variable interest entities.

[0000858877-22-000004:mdna:314]
[same as prior period, unchanged from 0000858877-21-000018:mdna:262]

[0000858877-22-000004:mdna:315]
[same as prior period, unchanged from 0000858877-21-000018:mdna:263]

[0000858877-22-000004:mdna:316]
[same as prior period, unchanged from 0000858877-21-000018:mdna:264]

[0000858877-22-000004:mdna:317]
[same as prior period, unchanged from 0000858877-21-000018:mdna:265]
