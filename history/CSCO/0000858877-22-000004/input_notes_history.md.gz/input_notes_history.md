# CSCO note change history — 0000858877-21-000018 → 0000858877-22-000004


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-02-22):
[0000858877-22-000004:note_history:1]
|  | January 29,2022 |  | July 31,2021 |
| Less than 1 year | $ | 9,224 |  |  | $ | 6,903 |  |
| 1 to 3 years | 1,879 |  |  | 1,806 |  |
| 3 to 5 years | 1,159 |  |  | 1,545 |  |
| Total | $ | 12,262 |  |  | $ | 10,254 |  |
  (was, 2021-11-23, similarity 0.9632):
[0000858877-21-000018:note_history:1]
|  | October 30,2021 |  | July 31,2021 |
| Less than 1 year | $ | 7,621 |  |  | $ | 6,903 |  |
| 1 to 3 years | 2,072 |  |  | 1,806 |  |
| 3 to 5 years | 1,359 |  |  | 1,545 |  |
| Total | $ | 11,052 |  |  | $ | 10,254 |  |

- changed (2022-02-22):
[0000858877-22-000004:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 29, 2022 and July 31, 2021, the liability for these purchase commitments was $199 million and $151 million, respectively, and was included in other current liabilities. For further discussion around the Supply Constraints Impacts and Risks, see Result of Operations—Product Gross Margin and Liquidity and Capital Resources—Inventory Supply Chain.
  (was, 2021-11-23, similarity 0.9874):
[0000858877-21-000018:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 30, 2021 and July 31, 2021, the liability for these purchase commitments was $179 million and $151 million, respectively, and was included in other current liabilities. For further discussion around the Supply Constraints Impacts and Risks, see Result of Operations—Product Gross Margin and Liquidity and Capital Resources—Inventory Supply Chain.

- changed (2022-02-22):
[0000858877-22-000004:note_history:3]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29, 2022 |  | January 23, 2021 |  | January 29, 2022 |  | January 23, 2021 |
| Compensation expense related to acquisitions | $ | 75 |  |  | $ | 59 |  |  | $ | 164 |  |  | $ | 116 |  |
  (was, 2021-11-23, similarity 0.6985):
[0000858877-21-000018:note_history:3]
|  | Three Months Ended |
|  | October 30, 2021 |  | October 24, 2020 |
| Compensation expense related to acquisitions | $ | 89 |  |  | $ | 57 |  |

- changed (2022-02-22):
[0000858877-22-000004:note_history:4]
As of January 29, 2022, we estimated that future cash compensation expense of up to $600 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2021-11-23, similarity 0.9669):
[0000858877-21-000018:note_history:4]
As of October 30, 2021, we estimated that future cash compensation expense of up to $673 million may be required to be recognized pursuant to the applicable business combination agreements.

- changed (2022-02-22):
[0000858877-22-000004:note_history:5]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.4 billion and $0.2 billion as of January 29, 2022 and July 31, 2021, respectively.
  (was, 2021-11-23, similarity 0.8652):
[0000858877-21-000018:note_history:5]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.2 billion as of each of October 30, 2021 and July 31, 2021.

- changed (2022-02-22):
[0000858877-22-000004:note_history:6]
|  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |
| Balance at beginning of period | $ | 336 |  |  | $ | 331 |  |
| Provisions for warranties issued | 218 |  |  | 247 |  |
| Adjustments for pre-existing warranties | 2 |  |  | 4 |  |
| Settlements | (222) |  |  | (249) |  |
| Balance at end of period | $ | 334 |  |  | $ | 333 |  |
  (was, 2021-11-23, similarity 0.9178):
[0000858877-21-000018:note_history:6]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |
| Balance at beginning of period | $ | 336 |  |  | $ | 331 |  |
| Provisions for warranties issued | 114 |  |  | 121 |  |
| Adjustments for pre-existing warranties | 2 |  |  | 1 |  |
| Settlements | (111) |  |  | (122) |  |
| Balance at end of period | $ | 341 |  |  | $ | 331 |  |

- changed (2022-02-22):
[0000858877-22-000004:note_history:7]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.8 billion and $6.7 billion for the second quarter of fiscal 2022 and 2021, respectively, and was $13.4 billion and $12.8 billion for the first six months of fiscal 2022 and 2021, respectively. The balance of the channel partner financing subject to guarantees was $1.4 billion and $1.3 billion as of January 29, 2022 and July 31, 2021, respectively.
  (was, 2021-11-23, similarity 0.868):
[0000858877-21-000018:note_history:7]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.6 billion and $6.1 billion for the first quarter of fiscal 2022 and 2021, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion as of each of October 30, 2021 and July 31, 2021.

- changed (2022-02-22):
[0000858877-22-000004:note_history:8]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $4 million and $3 million for the second quarter of fiscal 2022 and 2021, respectively, and was $6 million and $8 million for the first six months of fiscal 2022 and 2021, respectively.
  (was, 2021-11-23, similarity 0.8877):
[0000858877-21-000018:note_history:8]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $2 million and $5 million for the first quarter of fiscal 2022 and 2021, respectively.

- changed (2022-02-22):
[0000858877-22-000004:note_history:9]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 29, 2022 and July 31, 2021, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2021-11-23, similarity 0.9776):
[0000858877-21-000018:note_history:9]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 30, 2021 and July 31, 2021, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2022-02-22):
[0000858877-22-000004:note_history:10]
|  | January 29,2022 |  | July 31,2021 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 162 |  |  | $ | 155 |  |
| End user | 4 |  |  | 5 |  |
| Total | $ | 166 |  |  | $ | 160 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (5) |  |  | $ | (16) |  |
| End user | (4) |  |  | (5) |  |
| Total | $ | (9) |  |  | $ | (21) |  |
| Total | $ | 157 |  |  | $ | 139 |  |
  (was, 2021-11-23, similarity 0.9831):
[0000858877-21-000018:note_history:10]
|  | October 30,2021 |  | July 31,2021 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 197 |  |  | $ | 155 |  |
| End user | 4 |  |  | 5 |  |
| Total | $ | 201 |  |  | $ | 160 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (5) |  |  | $ | (16) |  |
| End user | (4) |  |  | (5) |  |
| Total | $ | (9) |  |  | $ | (21) |  |
| Total | $ | 192 |  |  | $ | 139 |  |

- changed (2022-02-22):
[0000858877-22-000004:note_history:11]
We were asked by seven of our customers to indemnify them in connection with patent infringement claims asserted against them by Estech Systems, Inc. (“Estech”) in the Eastern District of Texas (“E.D. Tex.”) court and the Western District of Texas court between April 24, 2020 and August 25, 2020. Estech alleged that the customer defendants infringe three patents generally related to IP telephony by using collaboration technology from us and other providers. Estech was seeking monetary damages from the customer defendants. Estech and the customer defendants resolved Estech’s claims, and we resolved the customer defendants’ indemnity claims for an amount that did not have a material effect on our Consolidated Financial Statements.
  (was, 2021-11-23, similarity 0.9905):
[0000858877-21-000018:note_history:11]
We were asked by seven of our customers to indemnify them in connection with patent infringement claims asserted against them by Estech Systems, Inc. (“Estech”) in the Eastern District of Texas (“E.D. Tex.”) court and the Western District of Texas  (“W.D. Tex.”) court between April 24, 2020 and August 25, 2020. Estech alleged that the customer defendants infringe three patents generally related to IP telephony by using collaboration technology from us and other providers. Estech was seeking monetary damages from the customer defendants. Estech and the customer defendants resolved Estech’s claims, and we resolved the customer defendants’ indemnity claims for an amount that did not have a material effect on our Consolidated Financial Statements.

- changed (2022-02-22):
[0000858877-22-000004:note_history:12]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $151 million for the alleged evasion of import and other taxes, $764 million for interest, and $373 million for various penalties, all determined using an exchange rate as of January 29, 2022.
  (was, 2021-11-23, similarity 0.9941):
[0000858877-21-000018:note_history:12]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $144 million for the alleged evasion of import and other taxes, $719 million for interest, and $355 million for various penalties, all determined using an exchange rate as of October 30, 2021.

- added (2022-02-22):
[0000858877-22-000004:note_history:13]
China     We have completed our investigation into allegations of a self-enrichment scheme involving now-former employees in China, and shared the results of the investigation with the Securities and Exchange Commission (“SEC”) and the Department of Justice (“DOJ”). Based on the investigation results, both the SEC and the DOJ have informed the Company that they do not plan to take any action against the Company in connection with these allegations.

- added (2022-02-22):
[0000858877-22-000004:note_history:14]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted claims against us in the U.S. District Court for the District of Delaware (“D. Del.”), accusing our products and services related to network intrusion detection of infringing two patents. After a trial, SRI obtained a verdict against us, and we appealed to the United States Court of Appeals for the Federal Circuit (“Federal Circuit”) which was ultimately unsuccessful. In resolution of this matter, we have paid SRI judgments, including attorneys’ fees and post-judgment royalties and interest, in the aggregate amount of approximately $60 million. The only remaining potential liability for this matter involves a small portion of post-judgment interest. The amounts that we paid to date and any potential additional interest we may have to pay involve amounts, individually or in the aggregate, that did not or will not, as applicable, have a material effect on our Consolidated Financial Statements.

- added (2022-02-22):
[0000858877-22-000004:note_history:15]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services (including our Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal U.S. patents. We thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office (“PTO”) to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal appealed the PTAB’s findings of unpatentability to the Federal Circuit. The Federal Circuit affirmed the PTAB’s findings of unpatentability as to three of the patents on March 10, 2021, and affirmed the PTAB’s findings of unpatentability as to the remaining four patents on May 11, 2021. On August 9, 2021, Centripetal filed a writ of certiorari seeking review of the Federal Circuit’s affirmance of several of the PTAB’s unpatentability findings, which the U.S. Supreme Court denied on October 4, 2021.

- changed (2022-02-22):
[0000858877-22-000004:note_history:16]
For the five asserted U.S. patents not subject to the IPR Proceedings, the district court conducted a bench trial by videoconference from May 6, 2020 to June 25, 2020. On October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The district court awarded Centripetal $1.9 billion, comprised of $756 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $14 million. The district court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $168 million and a maximum annual royalty of $300 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $84 million and a maximum annual royalty of $150 million. We believe that the district court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We have appealed the district court’s judgment as to the four patents found valid and infringed to the Federal Circuit. On October 28, 2020, by agreement of the parties, the district court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment.
  (was, 2021-11-23, similarity 0.875):
[0000858877-21-000018:note_history:16]
Centripetal $1.9 billion, comprised of $756 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $14 million. The district court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $168 million and a maximum annual royalty of $300 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $84 million and a maximum annual royalty of $150 million. We believe that the district court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We have appealed the district court’s judgment as to the four patents found valid and infringed to the Federal Circuit. On October 28, 2020, by agreement of the parties, the district court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment.

- changed (2022-02-22):
[0000858877-22-000004:note_history:17]
On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. district court proceedings, one of which has been invalidated by the PTAB. On June 22, 2021, Centripetal amended one of its complaints to assert one additional European patent and one additional German Utility Model patent. Centripetal seeks both injunctive relief and damages on these newly added patents.
  (was, 2021-11-23, similarity 0.9731):
[0000858877-21-000018:note_history:17]
On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. district court proceedings, one of which has been invalidated by the PTAB. On June 22, 2021, Centripetal amended one of its complaints to assert one additional European patent and one additional German Utility Model patent. Centripetal seeks both injunctive relief and damages on these newly added patents. We believe we have strong defenses.

- added (2022-02-22):
[0000858877-22-000004:note_history:18]
On December 10, 2021, the District Court of Dusseldorf issued its findings on two of the patents, rejecting Centripetal’s patent complaints. Centripetal has appealed. On December 21, 2021, the District Court of Dusseldorf stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. The proceedings on Centripetal’s amended complaint remain pending.

- added (2022-02-22):
[0000858877-22-000004:note_history:19]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court - Business Litigation Session against ViaSat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation. On April 5, 2018, ViaSat counterclaimed with contract, trade secret, and unfair competition claims (collectively, with Viasat 1, Viasat 2 and Viasat 3, the “Viasat Cases”). On December 13, 2018, the Massachusetts court entered an order staying the Massachusetts litigation, which has been extended to June 30, 2022.

- added (2022-02-22):
[0000858877-22-000004:note_history:20]
While we believe Acacia has strong defenses in each of the Viasat Cases, we are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If Acacia does not prevail, we believe that any relief ultimately assessed in any of the Viasat Cases would not have a material effect on our Consolidated Financial Statements.

- added (2022-02-22):
[0000858877-22-000004:note_history:21]
In addition, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the 
ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.

- removed (2022-02-22):
[0000858877-21-000018:note_history:22]
China     We are investigating allegations of a self-enrichment scheme involving now-former employees in China. Some of those employees are also alleged to have made or directed payments from the funds they received to various third parties, including employees of state-owned enterprises. We voluntarily disclosed this investigation to the Department of Justice (“DOJ”) and Securities and Exchange Commission (“SEC”). We take such allegations very seriously and we are providing results of our investigation to the DOJ and SEC. While the outcome of our investigation is currently not determinable, we do not expect that it will have a material adverse effect on our Consolidated Financial Statements.

- removed (2022-02-22):
[0000858877-21-000018:note_history:23]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted claims against us in the U.S. District Court for the District of Delaware (“D. Del.”), accusing our products and services in the area of network intrusion detection of infringing two patents. On May 12, 2016, a jury returned a verdict finding willful infringement. The jury awarded SRI damages of $24 million. On May 25, 2017, the district court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit (“Federal Circuit”), and on July 12, 2019, the Federal Circuit vacated the enhanced damages award; vacated and remanded in part the willful infringement finding; vacated and remanded the attorneys’ fees award for further proceedings; and affirmed the district court’s other findings. Cisco paid SRI $28 million, representing the portion of the judgment that the Federal Circuit affirmed, plus interest and royalties on post-verdict sales.

- removed (2022-02-22):
[0000858877-21-000018:note_history:24]
On April 1, 2020, the district court issued a final judgment on the remanded issues, finding no evidence of willful infringement and reinstating the $8 million award of attorneys’ fees. In a second round of appeals to the Federal Circuit in April 2020, SRI appealed the judgment of no willful infringement, and Cisco filed a cross-appeal on the attorneys’ fees award. On September 28, 2021, the Federal Circuit reversed the district court’s denial of SRI’s motion to reinstate the willfulness verdict, restored the district court’s award of enhanced damages, and affirmed the district court’s award of attorney fees. We intend to seek review of the Federal Circuit’s decision. While the remaining proceedings may result in an additional loss, we do not believe it would have a material effect on our Consolidated Financial Statements.

- removed (2022-02-22):
[0000858877-21-000018:note_history:25]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal U.S. patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (PTAB) of the United States Patent and Trademark Office (“PTO”) to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal appealed the PTAB’s findings of unpatentability to the Federal Circuit. The Federal Circuit affirmed the PTAB’s findings of unpatentability as to three of the patents on March 10, 2021, and affirmed the PTAB’s findings of unpatentability as to the remaining four patents on May 11, 2021. On August 9, 2021, Centripetal filed a writ of certiorari seeking review of the Federal Circuit’s affirmance of several of the PTAB’s unpatentability findings, which the U.S. Supreme Court denied on October 4, 2021.

- removed (2022-02-22):
[0000858877-21-000018:note_history:26]
For the five asserted U.S. patents not subject to the IPR Proceedings, the district court conducted a bench trial by videoconference from May 6, 2020 to June 25, 2020. On October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The district court awarded

- removed (2022-02-22):
[0000858877-21-000018:note_history:27]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court - Business Litigation Session against ViaSat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation. On April 5, 2018, ViaSat counterclaimed with contract, trade secret, and unfair competition claims (collectively, with Viasat 1, Viasat 2 and Viasat 3, the “Viasat Cases”). On December 13, 2018, the Massachusetts court entered an order staying the Massachusetts litigation, which has been extended to December 31, 2021.
While we believe Acacia has strong defenses in each of the Viasat Cases, we are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If Acacia does not prevail, we believe that any relief ultimately assessed in any of the Viasat Cases would not have a material effect on our Consolidated Financial Statements.In addition, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-02-22):
[0000858877-22-000004:note_history:28]
We have prepared the accompanying financial data as of January 29, 2022 and for the second quarter and first six months of fiscal 2022 and 2021, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 31, 2021 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021.
  (was, 2021-11-23, similarity 0.977):
[0000858877-21-000018:note_history:28]
We have prepared the accompanying financial data as of October 30, 2021 and for the first quarter of fiscal 2022 and 2021, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 31, 2021 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021.

- changed (2022-02-22):
[0000858877-22-000004:note_history:29]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.
  (was, 2021-11-23, similarity 0.9926):
[0000858877-21-000018:note_history:29]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues to develop, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

- added (2022-02-22):
[0000858877-22-000004:note_history:30]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of January 29, 2022, the results of operations, the statements of comprehensive income and the statements of equity for the second quarter and first six months of fiscal 2022 and 2021, and the statements of cash flows for the first six months of fiscal 2022 and 2021, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2022 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2022-02-22):
[0000858877-21-000018:note_history:31]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 30, 2021, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2022 and 2021, as applicable, have been made. The results of operations for the first quarter of fiscal 2022 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-02-22):
[0000858877-22-000004:note_history:32]
Acquired Revenue Contracts with Customers in Business Combination  In October 2021, the Financial Accounting Standards Board (FASB) issued an accounting standard update that requires companies to apply Accounting Standards Codification 606 to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination. We early adopted this accounting standard update beginning in the first quarter of fiscal 2022 and it did not have a material impact on our Consolidated Financial Statements. The ongoing impact of this standard will be fact dependent on the transactions within its scope.
  (was, 2021-11-23, similarity 0.9976):
[0000858877-21-000018:note_history:32]
Acquired Revenue Contracts with Customers in Business Combination  In October 2021, the Financial Accounting Standards Board (FASB) issued an accounting standard update that requires companies to apply Accounting Standards Codification 606 to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination. We early adopted this accounting standard update beginning in the first quarter of fiscal 2022 and did not have a material impact on our Consolidated Financial Statements. The ongoing impact of this standard will be fact dependent on the transactions within its scope.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-22):
[0000858877-22-000004:note_history:33]
|  | January 29, 2022 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 502 |  |  | 1.14 | % |  | $ | 2,508 |  |  | 1.75 | % |
| Commercial paper | 2,000 |  |  | 0.15 | % |  | — |  |  | — |  |
| Total short-term debt | $ | 2,502 |  |  |  |  | $ | 2,508 |  |  |  |
  (was, 2021-11-23, similarity 0.7329):
[0000858877-21-000018:note_history:33]
|  | October 30, 2021 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 506 |  |  | 1.13 | % |  | $ | 2,508 |  |  | 1.75 | % |

- changed (2022-02-22):
[0000858877-22-000004:note_history:34]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.
  (was, 2021-11-23, similarity 0.8554):
[0000858877-21-000018:note_history:34]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of October 30, 2021 and July 31, 2021.

- changed (2022-02-22):
[0000858877-22-000004:note_history:35]
|  |  |  | January 29, 2022 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.14% |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.00% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.31% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,500 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (77) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 48 |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 9,471 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 502 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,969 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 9,471 |  |  |  |  | $ | 11,526 |  |  |  |
  (was, 2021-11-23, similarity 0.9938):
[0000858877-21-000018:note_history:35]
|  |  |  | October 30, 2021 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.13% |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 0.97% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.29% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,500 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (78) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 80 |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 9,502 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 506 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,996 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 9,502 |  |  |  |  | $ | 11,526 |  |  |  |

- changed (2022-02-22):
[0000858877-22-000004:note_history:36]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $2.0 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.
  (was, 2021-11-23, similarity 0.9901):
[0000858877-21-000018:note_history:36]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $2.0 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (“LIBOR”). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

- changed (2022-02-22):
[0000858877-22-000004:note_history:37]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 29, 2022, we were in compliance with all debt covenants.
  (was, 2021-11-23, similarity 0.984):
[0000858877-21-000018:note_history:37]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 30, 2021, we were in compliance with all debt covenants.

- changed (2022-02-22):
[0000858877-22-000004:note_history:38]
As of January 29, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2021-11-23, similarity 0.9556):
[0000858877-21-000018:note_history:38]
As of October 30, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2022-02-22):
[0000858877-22-000004:note_history:39]
| Fiscal Year | Amount |
| 2022 (remaining six months) | $ | 500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 9,500 |  |
  (was, 2021-11-23, similarity 0.9836):
[0000858877-21-000018:note_history:39]
| Fiscal Year | Amount |
| 2022 (remaining nine months) | $ | 500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 9,500 |  |

- changed (2022-02-22):
[0000858877-22-000004:note_history:40]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. The credit agreement is structured as an amendment and restatement of our 364-day credit agreement, which would have terminated on May 14, 2021. As of January 29, 2022, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.
  (was, 2021-11-23, similarity 0.986):
[0000858877-21-000018:note_history:40]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. The credit agreement is structured as an amendment and restatement of our 364-day credit agreement, which would have terminated on May 14, 2021. As of October 30, 2021, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-22):
[0000858877-22-000004:note_history:41]
| January 29, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,702 |  |  | $ | 4 |  |  | $ | (19) |  |  | $ | 1,687 |  |
| U.S. government agency securities | 142 |  |  | — |  |  | (2) |  |  | 140 |  |
| Corporate debt securities | 9,008 |  |  | 82 |  |  | (102) |  |  | 8,988 |  |
| U.S. agency mortgage-backed securities | 2,569 |  |  | 10 |  |  | (56) |  |  | 2,523 |  |
| Commercial paper | 614 |  |  | — |  |  | — |  |  | 614 |  |
| Certificates of deposit | 209 |  |  | — |  |  | — |  |  | 209 |  |
| Total | $ | 14,244 |  |  | $ | 96 |  |  | $ | (179) |  |  | $ | 14,161 |  |
  (was, 2021-11-23, similarity 0.6232):
[0000858877-21-000018:note_history:41]
| October 30, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,032 |  |  | $ | 12 |  |  | $ | (9) |  |  | $ | 2,035 |  |
| U.S. government agency securities | 142 |  |  | — |  |  | — |  |  | 142 |  |
| Corporate debt securities | 9,114 |  |  | 156 |  |  | (50) |  |  | 9,220 |  |
| U.S. agency mortgage-backed securities | 2,790 |  |  | 24 |  |  | (21) |  |  | 2,793 |  |
| Commercial paper | 1,054 |  |  | — |  |  | — |  |  | 1,054 |  |
| Certificates of deposit | 269 |  |  | — |  |  | — |  |  | 269 |  |
| Total | $ | 15,401 |  |  | $ | 192 |  |  | $ | (80) |  |  | $ | 15,513 |  |

- changed (2022-02-22):
[0000858877-22-000004:note_history:42]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29, 2022 |  | January 23, 2021 |  | January 29, 2022 |  | January 23, 2021 |
| Gross realized gains | $ | 13 |  |  | $ | 9 |  |  | $ | 19 |  |  | $ | 24 |  |
| Gross realized losses | (3) |  |  | — |  |  | (3) |  |  | — |  |
| Total | $ | 10 |  |  | $ | 9 |  |  | $ | 16 |  |  | $ | 24 |  |
  (was, 2021-11-23, similarity 0.6947):
[0000858877-21-000018:note_history:42]
|  | Three Months Ended |
|  | October 30, 2021 |  | October 24, 2020 |
| Gross realized gains | $ | 6 |  |  | $ | 15 |  |
| Gross realized losses | — |  |  | — |  |
| Total | $ | 6 |  |  | $ | 15 |  |

- changed (2022-02-22):
[0000858877-22-000004:note_history:43]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 29, 2022 and July 31, 2021 (in millions):
  (was, 2021-11-23, similarity 0.967):
[0000858877-21-000018:note_history:43]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 30, 2021 and July 31, 2021 (in millions):

- added (2022-02-22):
[0000858877-22-000004:note_history:44]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 29, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,124 |  |  | $ | (19) |  |  | $ | 2 |  |  | $ | — |  |  | $ | 1,126 |  |  | $ | (19) |  |
| U.S. government agency securities | 125 |  |  | (1) |  |  | 15 |  |  | (1) |  |  | 140 |  |  | (2) |  |
| Corporate debt securities | 4,230 |  |  | (69) |  |  | 182 |  |  | (8) |  |  | 4,412 |  |  | (77) |  |
| U.S. agency mortgage-backed securities | 1,881 |  |  | (52) |  |  | 91 |  |  | (4) |  |  | 1,972 |  |  | (56) |  |
| Total | $ | 7,360 |  |  | $ | (141) |  |  | $ | 290 |  |  | $ | (13) |  |  | $ | 7,650 |  |  | $ | (154) |  |

- changed (2022-02-22):
[0000858877-22-000004:note_history:45]
The following table summarizes the maturities of our available-for-sale debt investments as of January 29, 2022 (in millions):
  (was, 2021-11-23, similarity 0.9504):
[0000858877-21-000018:note_history:45]
The following table summarizes the maturities of our available-for-sale debt investments as of October 30, 2021 (in millions):

- added (2022-02-22):
[0000858877-22-000004:note_history:46]
We recognized a net unrealized loss of $18 million and $13 million during the second quarter and first six months of fiscal 2022, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $14 million and $16 million for the second quarter and first six months of fiscal 2022, respectively. We held equity interests in certain private equity funds of $1.1 billion and $0.9 billion as of January 29, 2022 and July 31, 2021, respectively, which are accounted for under the NAV practical expedient.

- changed (2022-02-22):
[0000858877-22-000004:note_history:47]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 29, 2022, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2021-11-23, similarity 0.9875):
[0000858877-21-000018:note_history:47]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 30, 2021, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- changed (2022-02-22):
[0000858877-22-000004:note_history:48]
The carrying value of our investments in privately held companies was $1.8 billion and $1.5 billion as of January 29, 2022 and July 31, 2021, respectively. Of the total carrying value of our investments in privately held companies as of January 29, 2022, $1.1 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of January 29, 2022, we have total funding commitments of $0.4 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.
  (was, 2021-11-23, similarity 0.9589):
[0000858877-21-000018:note_history:48]
The carrying value of our investments in privately held companies was $1.7 billion and $1.5 billion as of October 30, 2021 and July 31, 2021, respectively. Of the total carrying value of our investments in privately held companies as of October 30, 2021, $1.0 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of October 30, 2021, we have total funding commitments of $0.2 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.

- removed (2022-02-22):
[0000858877-21-000018:note_history:49]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 30, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,341 |  |  | $ | (9) |  |  | $ | 2 |  |  | $ | — |  |  | $ | 1,343 |  |  | $ | (9) |  |
| U.S. government agency securities | 100 |  |  | — |  |  | — |  |  | — |  |  | 100 |  |  | — |  |
| Corporate debt securities | 3,204 |  |  | (24) |  |  | 27 |  |  | (1) |  |  | 3,231 |  |  | (25) |  |
| U.S. agency mortgage-backed securities | 1,937 |  |  | (20) |  |  | 52 |  |  | (1) |  |  | 1,989 |  |  | (21) |  |
| Commercial paper | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |  | — |  |
| Total | $ | 6,607 |  |  | $ | (53) |  |  | $ | 81 |  |  | $ | (2) |  |  | $ | 6,688 |  |  | $ | (55) |  |

- removed (2022-02-22):
[0000858877-21-000018:note_history:50]
We recognized a net unrealized gain of $5 million during the first quarter of fiscal 2022 on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $2 million for the first quarter of fiscal 2022. We held equity interests in certain private equity funds of $1.0 billion and $0.9 billion as of October 30, 2021 and July 31, 2021, respectively, which are accounted for under the NAV practical expedient.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-22):
[0000858877-22-000004:note_history:51]
|  |  |  | January 29, 2022 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.14% |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.00% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.31% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,500 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (77) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 48 |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 9,471 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 502 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,969 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 9,471 |  |  |  |  | $ | 11,526 |  |  |  |
  (was, 2021-11-23, similarity 0.9938):
[0000858877-21-000018:note_history:51]
|  |  |  | October 30, 2021 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.13% |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 0.97% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.29% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,500 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (78) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 80 |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 9,502 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 506 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,996 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 9,502 |  |  |  |  | $ | 11,526 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-22):
[0000858877-22-000004:note_history:52]
As of January 29, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2021-11-23, similarity 0.9556):
[0000858877-21-000018:note_history:52]
As of October 30, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2022-02-22):
[0000858877-22-000004:note_history:53]
| Fiscal Year | Amount |
| 2022 (remaining six months) | $ | 500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 9,500 |  |
  (was, 2021-11-23, similarity 0.9836):
[0000858877-21-000018:note_history:53]
| Fiscal Year | Amount |
| 2022 (remaining nine months) | $ | 500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 9,500 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-22):
[0000858877-22-000004:note_history:54]
|  | January 29, 2022 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 502 |  |  | 1.14 | % |  | $ | 2,508 |  |  | 1.75 | % |
| Commercial paper | 2,000 |  |  | 0.15 | % |  | — |  |  | — |  |
| Total short-term debt | $ | 2,502 |  |  |  |  | $ | 2,508 |  |  |  |
  (was, 2021-11-23, similarity 0.7329):
[0000858877-21-000018:note_history:54]
|  | October 30, 2021 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 506 |  |  | 1.13 | % |  | $ | 2,508 |  |  | 1.75 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-22):
[0000858877-22-000004:note_history:55]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,898 |  |  | $ | 5,489 |  |  | $ | 11,866 |  |  | $ | 10,923 |  |
| Hybrid Work | 1,067 |  |  | 1,167 |  |  | 2,176 |  |  | 2,360 |  |
| End-to-End Security | 883 |  |  | 822 |  |  | 1,778 |  |  | 1,684 |  |
| Internet for the Future | 1,322 |  |  | 931 |  |  | 2,697 |  |  | 1,872 |  |
| Optimized Application Experiences | 180 |  |  | 161 |  |  | 361 |  |  | 314 |  |
| Other Products | 2 |  |  | 3 |  |  | 5 |  |  | 6 |  |
| Total Product | 9,353 |  |  | 8,572 |  |  | 18,882 |  |  | 17,159 |  |
| Services | 3,367 |  |  | 3,388 |  |  | 6,738 |  |  | 6,730 |  |
| Total | $ | 12,720 |  |  | $ | 11,960 |  |  | $ | 25,620 |  |  | $ | 23,889 |  |
  (was, 2021-11-23, similarity 0.7493):
[0000858877-21-000018:note_history:55]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |
| Product revenue: |  |  |  |
| Secure, Agile Networks | $ | 5,967 |  |  | $ | 5,434 |  |
| Hybrid Work | 1,109 |  |  | 1,193 |  |
| End-to-End Security | 895 |  |  | 861 |  |
| Internet for the Future | 1,374 |  |  | 942 |  |
| Optimized Application Experiences | 181 |  |  | 153 |  |
| Other Products | 3 |  |  | 3 |  |
| Total Product | 9,529 |  |  | 8,587 |  |
| Services | 3,371 |  |  | 3,342 |  |
| Total | $ | 12,900 |  |  | $ | 11,929 |  |

- changed (2022-02-22):
[0000858877-22-000004:note_history:56]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,898 |  |  | $ | 5,489 |  |  | $ | 11,866 |  |  | $ | 10,923 |  |
| Hybrid Work | 1,067 |  |  | 1,167 |  |  | 2,176 |  |  | 2,360 |  |
| End-to-End Security | 883 |  |  | 822 |  |  | 1,778 |  |  | 1,684 |  |
| Internet for the Future | 1,322 |  |  | 931 |  |  | 2,697 |  |  | 1,872 |  |
| Optimized Application Experiences | 180 |  |  | 161 |  |  | 361 |  |  | 314 |  |
| Other Products | 2 |  |  | 3 |  |  | 5 |  |  | 6 |  |
| Total Product | 9,353 |  |  | 8,572 |  |  | 18,882 |  |  | 17,159 |  |
| Services | 3,367 |  |  | 3,388 |  |  | 6,738 |  |  | 6,730 |  |
| Total | $ | 12,720 |  |  | $ | 11,960 |  |  | $ | 25,620 |  |  | $ | 23,889 |  |
  (was, 2021-11-23, similarity 0.7454):
[0000858877-21-000018:note_history:56]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |
| Revenue: |  |  |  |
| Secure, Agile Networks | $ | 5,967 |  |  | $ | 5,434 |  |
| Hybrid Work | 1,109 |  |  | 1,193 |  |
| End-to-End Security | 895 |  |  | 861 |  |
| Internet for the Future | 1,374 |  |  | 942 |  |
| Optimized Application Experiences | 181 |  |  | 153 |  |
| Other Products | 3 |  |  | 3 |  |
| Total Product | 9,529 |  |  | 8,587 |  |
| Services | 3,371 |  |  | 3,342 |  |
| Total | $ | 12,900 |  |  | $ | 11,929 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-22):
[0000858877-22-000004:note_history:57]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 29, 2022 and July 31, 2021 was $46 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2021-11-23, similarity 0.9759):
[0000858877-21-000018:note_history:57]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 30, 2021 and July 31, 2021 was $49 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-22):
[0000858877-22-000004:note_history:58]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 29, 2022 and July 31, 2021 was $46 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2021-11-23, similarity 0.9759):
[0000858877-21-000018:note_history:58]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 30, 2021 and July 31, 2021 was $49 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2022-02-22):
[0000858877-22-000004:note_history:59]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,898 |  |  | $ | 5,489 |  |  | $ | 11,866 |  |  | $ | 10,923 |  |
| Hybrid Work | 1,067 |  |  | 1,167 |  |  | 2,176 |  |  | 2,360 |  |
| End-to-End Security | 883 |  |  | 822 |  |  | 1,778 |  |  | 1,684 |  |
| Internet for the Future | 1,322 |  |  | 931 |  |  | 2,697 |  |  | 1,872 |  |
| Optimized Application Experiences | 180 |  |  | 161 |  |  | 361 |  |  | 314 |  |
| Other Products | 2 |  |  | 3 |  |  | 5 |  |  | 6 |  |
| Total Product | 9,353 |  |  | 8,572 |  |  | 18,882 |  |  | 17,159 |  |
| Services | 3,367 |  |  | 3,388 |  |  | 6,738 |  |  | 6,730 |  |
| Total | $ | 12,720 |  |  | $ | 11,960 |  |  | $ | 25,620 |  |  | $ | 23,889 |  |
  (was, 2021-11-23, similarity 0.7493):
[0000858877-21-000018:note_history:59]
|  | Three Months Ended |
|  | October 30,2021 |  | October 24,2020 |
| Product revenue: |  |  |  |
| Secure, Agile Networks | $ | 5,967 |  |  | $ | 5,434 |  |
| Hybrid Work | 1,109 |  |  | 1,193 |  |
| End-to-End Security | 895 |  |  | 861 |  |
| Internet for the Future | 1,374 |  |  | 942 |  |
| Optimized Application Experiences | 181 |  |  | 153 |  |
| Other Products | 3 |  |  | 3 |  |
| Total Product | 9,529 |  |  | 8,587 |  |
| Services | 3,371 |  |  | 3,342 |  |
| Total | $ | 12,900 |  |  | $ | 11,929 |  |

- added (2022-02-22):
[0000858877-22-000004:note_history:60]
Accounts Receivable

- changed (2022-02-22):
[0000858877-22-000004:note_history:61]
Accounts receivable, net was $6.0 billion as of January 29, 2022 compared to $5.8 billion as of July 31, 2021, as reported on the Consolidated Balance Sheets.
  (was, 2021-11-23, similarity 0.958):
[0000858877-21-000018:note_history:61]
Accounts receivable, net was $5.3 billion as of October 30, 2021 compared to $5.8 billion as of July 31, 2021, as reported on the Consolidated Balance Sheets.

- added (2022-02-22):
[0000858877-22-000004:note_history:62]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29, 2022 |  | January 23, 2021 |  | January 29, 2022 |  | January 23, 2021 |
| Allowance for credit loss at beginning of period | $ | 114 |  |  | $ | 125 |  |  | $ | 109 |  |  | $ | 143 |  |
| Provisions (benefits) | 17 |  |  | (15) |  |  | 36 |  |  | (1) |  |
| Recoveries (write-offs), net | (52) |  |  | (8) |  |  | (66) |  |  | (14) |  |
| Foreign exchange and other | (9) |  |  | — |  |  | (9) |  |  | (26) |  |
| Allowance for credit loss at end of period | $ | 70 |  |  | $ | 102 |  |  | $ | 70 |  |  | $ | 102 |  |

- added (2022-02-22):
[0000858877-22-000004:note_history:63]
Contract Assets and Liabilities

- changed (2022-02-22):
[0000858877-22-000004:note_history:64]
|  | January 29,2022 |  | July 31,2021 |
| 1 to 4 | $ | 464 |  |  | $ | 521 |  |
| 5 to 6 | 825 |  |  | 770 |  |
| 7 and Higher | 164 |  |  | 166 |  |
| Total | $ | 1,453 |  |  | $ | 1,457 |  |
  (was, 2021-11-23, similarity 0.9592):
[0000858877-21-000018:note_history:64]
|  | October 30,2021 |  | July 31,2021 |
| 1 to 4 | $ | 445 |  |  | $ | 521 |  |
| 5 to 6 | 839 |  |  | 770 |  |
| 7 and Higher | 154 |  |  | 166 |  |
| Total | $ | 1,438 |  |  | $ | 1,457 |  |

- changed (2022-02-22):
[0000858877-22-000004:note_history:65]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, was $1.4 billion as of both January 29, 2022 and July 31, 2021, and were included in other current assets and other assets.
  (was, 2021-11-23, similarity 0.9444):
[0000858877-21-000018:note_history:65]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $1.4 billion as of each of October 30, 2021 and July 31, 2021, and were included in other current assets and other assets.

- changed (2022-02-22):
[0000858877-22-000004:note_history:66]
Contract liabilities consist of deferred revenue. Deferred revenue was $22.3 billion as of January 29, 2022 compared to $22.2 billion as of July 31, 2021. We recognized approximately $3.3 billion and $7.4 billion of revenue during the second quarter and first six months of fiscal 2022, respectively, that was included in the deferred revenue balance at July 31, 2021.
  (was, 2021-11-23, similarity 0.6581):
[0000858877-21-000018:note_history:66]
Contract liabilities consist of deferred revenue. Deferred revenue was $22.1 billion as of October 30, 2021 compared to $22.2 billion as of July 31, 2021. We recognized approximately $4.1 billion of revenue during the first quarter of fiscal 2022 that was included in the deferred revenue balance at July 31, 2021.

- added (2022-02-22):
[0000858877-22-000004:note_history:67]
(c)Capitalized Contract Acquisition Costs

- changed (2022-02-22):
[0000858877-22-000004:note_history:68]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $999 million and $967 million as of January 29, 2022 and July 31, 
2021, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $147 million and $317 million for the second quarter and first six months of fiscal 2022, respectively, and $129 million and $252 million for the corresponding periods of fiscal 2021, respectively, and was included in sales and marketing expenses.
  (was, 2021-11-23, similarity 0.7876):
[0000858877-21-000018:note_history:68]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $994 million and $967 million as of October 30, 2021 and July 31, 2021, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $187 million and $123 million for the first quarter of fiscal 2022 and 2021, respectively, and was included in sales and marketing expenses.

- removed (2022-02-22):
[0000858877-21-000018:note_history:69]
|  | Three Months Ended |
|  | October 30, 2021 |  | October 24, 2020 |
| Allowance for credit loss at beginning of period | $ | 109 |  |  | $ | 143 |  |
| Provisions (benefits) | 19 |  |  | 14 |  |
| Recoveries (write-offs), net | (14) |  |  | (6) |  |
| Foreign exchange and other | — |  |  | (26) |  |
| Allowance for credit loss at end of period | $ | 114 |  |  | $ | 125 |  |
