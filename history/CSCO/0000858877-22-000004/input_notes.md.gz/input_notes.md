# CSCO notes — 0000858877-22-000004


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-22-000004:notes:1]
[same as prior period, unchanged from 0000858877-21-000018:notes:1]

[0000858877-22-000004:notes:2]
We have prepared the accompanying financial data as of January 29, 2022 and for the second quarter and first six months of fiscal 2022 and 2021, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 31, 2021 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021.

[0000858877-22-000004:notes:3]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-22-000004:notes:4]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of January 29, 2022, the results of operations, the statements of comprehensive income and the statements of equity for the second quarter and first six months of fiscal 2022 and 2021, and the statements of cash flows for the first six months of fiscal 2022 and 2021, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2022 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-22-000004:notes:5]
[same as prior period, unchanged from 0000858877-21-000018:notes:5]

[0000858877-22-000004:notes:6]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-22-000004:notes:7]
[same as prior period, unchanged from 0000858877-21-000018:notes:7]

[0000858877-22-000004:notes:8]
Acquired Revenue Contracts with Customers in Business Combination  In October 2021, the Financial Accounting Standards Board (FASB) issued an accounting standard update that requires companies to apply Accounting Standards Codification 606 to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination. We early adopted this accounting standard update beginning in the first quarter of fiscal 2022 and it did not have a material impact on our Consolidated Financial Statements. The ongoing impact of this standard will be fact dependent on the transactions within its scope.

[0000858877-22-000004:notes:9]
[same as prior period, unchanged from 0000858877-21-000018:notes:9]

[0000858877-22-000004:notes:10]
[same as prior period, unchanged from 0000858877-21-000018:notes:10]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-22-000004:notes:11]
[same as prior period, unchanged from 0000858877-21-000018:notes:11]

[0000858877-22-000004:notes:12]
[same as prior period, unchanged from 0000858877-21-000018:notes:12]

[0000858877-22-000004:notes:13]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 29, 2022 and July 31, 2021 was $46 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-22-000004:notes:14]
[same as prior period, unchanged from 0000858877-21-000018:notes:14]

[0000858877-22-000004:notes:15]
[same as prior period, unchanged from 0000858877-21-000018:notes:15]

[0000858877-22-000004:notes:16]
[same as prior period, unchanged from 0000858877-21-000018:notes:16]

[0000858877-22-000004:notes:17]
[same as prior period, unchanged from 0000858877-21-000018:notes:17]

[0000858877-22-000004:notes:18]
[same as prior period, unchanged from 0000858877-21-000018:notes:18]

[0000858877-22-000004:notes:19]
[same as prior period, unchanged from 0000858877-21-000018:notes:19]

[0000858877-22-000004:notes:20]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,898 |  |  | $ | 5,489 |  |  | $ | 11,866 |  |  | $ | 10,923 |  |
| Hybrid Work | 1,067 |  |  | 1,167 |  |  | 2,176 |  |  | 2,360 |  |
| End-to-End Security | 883 |  |  | 822 |  |  | 1,778 |  |  | 1,684 |  |
| Internet for the Future | 1,322 |  |  | 931 |  |  | 2,697 |  |  | 1,872 |  |
| Optimized Application Experiences | 180 |  |  | 161 |  |  | 361 |  |  | 314 |  |
| Other Products | 2 |  |  | 3 |  |  | 5 |  |  | 6 |  |
| Total Product | 9,353 |  |  | 8,572 |  |  | 18,882 |  |  | 17,159 |  |
| Services | 3,367 |  |  | 3,388 |  |  | 6,738 |  |  | 6,730 |  |
| Total | $ | 12,720 |  |  | $ | 11,960 |  |  | $ | 25,620 |  |  | $ | 23,889 |  |

[0000858877-22-000004:notes:21]
[same as prior period, unchanged from 0000858877-21-000018:notes:21]

[0000858877-22-000004:notes:22]
[same as prior period, unchanged from 0000858877-21-000018:notes:22]

[0000858877-22-000004:notes:23]
[same as prior period, unchanged from 0000858877-21-000018:notes:23]

[0000858877-22-000004:notes:24]
[same as prior period, unchanged from 0000858877-21-000018:notes:24]

[0000858877-22-000004:notes:25]
[same as prior period, unchanged from 0000858877-21-000018:notes:25]

[0000858877-22-000004:notes:26]
[same as prior period, unchanged from 0000858877-21-000018:notes:26]

[0000858877-22-000004:notes:27]
[same as prior period, unchanged from 0000858877-21-000018:notes:27]

[0000858877-22-000004:notes:28]
[same as prior period, unchanged from 0000858877-21-000018:notes:28]

[0000858877-22-000004:notes:29]
[same as prior period, unchanged from 0000858877-21-000018:notes:29]

[0000858877-22-000004:notes:30]
Accounts Receivable

[0000858877-22-000004:notes:31]
Accounts receivable, net was $6.0 billion as of January 29, 2022 compared to $5.8 billion as of July 31, 2021, as reported on the Consolidated Balance Sheets.

[0000858877-22-000004:notes:32]
[same as prior period, unchanged from 0000858877-21-000018:notes:31]

[0000858877-22-000004:notes:33]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29, 2022 |  | January 23, 2021 |  | January 29, 2022 |  | January 23, 2021 |
| Allowance for credit loss at beginning of period | $ | 114 |  |  | $ | 125 |  |  | $ | 109 |  |  | $ | 143 |  |
| Provisions (benefits) | 17 |  |  | (15) |  |  | 36 |  |  | (1) |  |
| Recoveries (write-offs), net | (52) |  |  | (8) |  |  | (66) |  |  | (14) |  |
| Foreign exchange and other | (9) |  |  | — |  |  | (9) |  |  | (26) |  |
| Allowance for credit loss at end of period | $ | 70 |  |  | $ | 102 |  |  | $ | 70 |  |  | $ | 102 |  |

[0000858877-22-000004:notes:34]
Contract Assets and Liabilities

[0000858877-22-000004:notes:35]
[same as prior period, unchanged from 0000858877-21-000018:notes:34]

[0000858877-22-000004:notes:36]
|  | January 29,2022 |  | July 31,2021 |
| 1 to 4 | $ | 464 |  |  | $ | 521 |  |
| 5 to 6 | 825 |  |  | 770 |  |
| 7 and Higher | 164 |  |  | 166 |  |
| Total | $ | 1,453 |  |  | $ | 1,457 |  |

[0000858877-22-000004:notes:37]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, was $1.4 billion as of both January 29, 2022 and July 31, 2021, and were included in other current assets and other assets.

[0000858877-22-000004:notes:38]
Contract liabilities consist of deferred revenue. Deferred revenue was $22.3 billion as of January 29, 2022 compared to $22.2 billion as of July 31, 2021. We recognized approximately $3.3 billion and $7.4 billion of revenue during the second quarter and first six months of fiscal 2022, respectively, that was included in the deferred revenue balance at July 31, 2021.

[0000858877-22-000004:notes:39]
(c)Capitalized Contract Acquisition Costs

[0000858877-22-000004:notes:40]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $999 million and $967 million as of January 29, 2022 and July 31, 
2021, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $147 million and $317 million for the second quarter and first six months of fiscal 2022, respectively, and $129 million and $252 million for the corresponding periods of fiscal 2021, respectively, and was included in sales and marketing expenses.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-22-000004:notes:41]
[same as prior period, unchanged from 0000858877-21-000018:notes:38]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-22-000004:notes:42]
[same as prior period, unchanged from 0000858877-21-000018:notes:39]

[0000858877-22-000004:notes:43]
[same as prior period, unchanged from 0000858877-21-000018:notes:40]

[0000858877-22-000004:notes:44]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,898 |  |  | $ | 5,489 |  |  | $ | 11,866 |  |  | $ | 10,923 |  |
| Hybrid Work | 1,067 |  |  | 1,167 |  |  | 2,176 |  |  | 2,360 |  |
| End-to-End Security | 883 |  |  | 822 |  |  | 1,778 |  |  | 1,684 |  |
| Internet for the Future | 1,322 |  |  | 931 |  |  | 2,697 |  |  | 1,872 |  |
| Optimized Application Experiences | 180 |  |  | 161 |  |  | 361 |  |  | 314 |  |
| Other Products | 2 |  |  | 3 |  |  | 5 |  |  | 6 |  |
| Total Product | 9,353 |  |  | 8,572 |  |  | 18,882 |  |  | 17,159 |  |
| Services | 3,367 |  |  | 3,388 |  |  | 6,738 |  |  | 6,730 |  |
| Total | $ | 12,720 |  |  | $ | 11,960 |  |  | $ | 25,620 |  |  | $ | 23,889 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-22-000004:notes:45]
Acquisitions and Divestitures
We completed two acquisitions during the first six months of fiscal 2022. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-22-000004:notes:46]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions (two in total) | $ | 351 |  |  | $ | 8 |  |  | $ | 16 |  |  | $ | 327 |  |

[0000858877-22-000004:notes:47]
The total purchase consideration related to our acquisitions completed during the first six months of fiscal 2022 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $6 million. Total transaction costs related to acquisition and divestiture activities were $38 million and $10 million for the first six months of fiscal 2022 and 2021, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-22-000004:notes:48]
The goodwill generated from acquisitions completed during the first six months of fiscal 2022 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first six months of fiscal 2022 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-22-000004:notes:49]
[same as prior period, unchanged from 0000858877-21-000018:notes:46]

[0000858877-22-000004:notes:50]
The following table presents the goodwill allocated to our reportable segments as of January 29, 2022 and during the first six months of fiscal 2022 (in millions):

[0000858877-22-000004:notes:51]
|  | Balance at July 31, 2021 |  | Acquisitions & Divestitures |  | Other |  | Balance at January 29, 2022 |
| Americas | $ | 23,673 |  |  | $ | 219 |  |  | $ | 224 |  |  | $ | 24,116 |  |
| EMEA | 9,094 |  |  | 82 |  |  | (25) |  |  | 9,151 |  |
| APJC | 5,401 |  |  | 26 |  |  | (15) |  |  | 5,412 |  |
| Total | $ | 38,168 |  |  | $ | 327 |  |  | $ | 184 |  |  | $ | 38,679 |  |

[0000858877-22-000004:notes:52]
“Other” in the table above consists of purchase accounting adjustments as well as foreign currency translation.

[0000858877-22-000004:notes:53]
[same as prior period, unchanged from 0000858877-21-000018:notes:49]

[0000858877-22-000004:notes:54]
The following table presents details of our intangible assets acquired through acquisitions completed during the first six months of fiscal 2022 (in millions, except years):

[0000858877-22-000004:notes:55]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions (two in total) | 2.5 |  | $ | 12 |  |  | 2.0 |  | $ | 4 |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 16 |  |

[0000858877-22-000004:notes:56]
[same as prior period, unchanged from 0000858877-21-000018:notes:52]

[0000858877-22-000004:notes:57]
| January 29, 2022 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,240 |  |  | $ | (1,369) |  |  | $ | 1,871 |  |
| Customer relationships |  | 1,359 |  |  | (633) |  |  | 726 |  |
| Other |  | 70 |  |  | (33) |  |  | 37 |  |
| Total purchased intangible assets with finite lives |  | 4,669 |  |  | (2,035) |  |  | 2,634 |  |
| In-process research and development, with indefinite lives |  | 445 |  |  | — |  |  | 445 |  |
| Total |  | $ | 5,114 |  |  | $ | (2,035) |  |  | $ | 3,079 |  |

[0000858877-22-000004:notes:58]
[same as prior period, unchanged from 0000858877-21-000018:notes:54]

[0000858877-22-000004:notes:59]
[same as prior period, unchanged from 0000858877-21-000018:notes:55]

[0000858877-22-000004:notes:60]
[same as prior period, unchanged from 0000858877-21-000018:notes:56]

[0000858877-22-000004:notes:61]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29, 2022 |  | January 23, 2021 |  | January 29, 2022 |  | January 23, 2021 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 201 |  |  | $ | 156 |  |  | $ | 403 |  |  | $ | 326 |  |
| Operating expenses | 79 |  |  | 39 |  |  | 163 |  |  | 75 |  |
| Total | $ | 280 |  |  | $ | 195 |  |  | $ | 566 |  |  | $ | 401 |  |

[0000858877-22-000004:notes:62]
The estimated future amortization expense of purchased intangible assets with finite lives as of January 29, 2022 is as follows (in millions):

[0000858877-22-000004:notes:63]
| Fiscal Year | Amount |
| 2022 (remaining six months) | $ | 494 |  |
| 2023 | $ | 903 |  |
| 2024 | $ | 774 |  |
| 2025 | $ | 402 |  |
| 2026 | $ | 60 |  |
| Thereafter | $ | 1 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-22-000004:notes:64]
Restructuring and Other Charges
We initiated a restructuring plan in fiscal 2021 (the “Fiscal 2021 Plan”), which included a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas. The total pretax charges were estimated to be approximately $900 million. In connection with the Fiscal 2021 Plan, we have incurred cumulative charges of $894 million and completed this plan in fiscal 2022.

[0000858877-22-000004:notes:65]
We initiated a restructuring plan in fiscal 2020 (the “Fiscal 2020 Plan”) in order to realign the organization and enable further investment in key priority areas. In connection with the Fiscal 2020 Plan, we incurred cumulative charges of $255 million. We completed the Fiscal 2020 Plan in fiscal 2021.

[0000858877-22-000004:notes:66]
[same as prior period, unchanged from 0000858877-21-000018:notes:62]

[0000858877-22-000004:notes:67]
[same as prior period, unchanged from 0000858877-21-000018:notes:63]

[0000858877-22-000004:notes:68]
|  |  | FISCAL 2020 AND PRIOR PLANS |  | FISCAL 2021 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 31, 2021 |  | $ | — |  |  | $ | 10 |  |  | $ | 16 |  |  | $ | 8 |  |  | $ | 34 |  |
| Charges |  | — |  |  | (5) |  |  | 10 |  |  | 3 |  |  | 8 |  |
| Cash payments |  | — |  |  | (1) |  |  | (16) |  |  | — |  |  | (17) |  |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (5) |  |  | (5) |  |
| Liability as of January 29, 2022 |  | $ | — |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 6 |  |  | $ | 20 |  |

[0000858877-22-000004:notes:69]
|  |  | FISCAL 2020 AND PRIOR PLANS |  | FISCAL 2021 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | Employee Severance |  | Other |  | Total |
| Liability as of July 25, 2020 |  | $ | 58 |  |  | $ | 14 |  |  | $ | — |  |  | $ | — |  |  | $ | 72 |  |
| Charges |  | — |  |  | 2 |  |  | 804 |  |  | 30 |  |  | 836 |  |
| Cash payments |  | (58) |  |  | (3) |  |  | (703) |  |  | (3) |  |  | (767) |  |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (21) |  |  | (21) |  |
| Liability as of January 23, 2021 |  | $ | — |  |  | $ | 13 |  |  | $ | 101 |  |  | $ | 6 |  |  | $ | 120 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-22-000004:notes:70]
[same as prior period, unchanged from 0000858877-21-000018:notes:66]

[0000858877-22-000004:notes:71]
[same as prior period, unchanged from 0000858877-21-000018:notes:67]

[0000858877-22-000004:notes:72]
|  |  | January 29,2022 |  | July 31,2021 |
| Cash and cash equivalents |  | $ | 6,731 |  |  | $ | 9,175 |  |
| Restricted cash included in other current assets |  | 11 |  |  | 14 |  |
| Restricted cash included in other assets |  | 750 |  |  | 753 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 7,492 |  |  | $ | 9,942 |  |

[0000858877-22-000004:notes:73]
[same as prior period, unchanged from 0000858877-21-000018:notes:69]

[0000858877-22-000004:notes:74]
[same as prior period, unchanged from 0000858877-21-000018:notes:70]

[0000858877-22-000004:notes:75]
|  |  | January 29,2022 |  | July 31,2021 |
| Raw materials |  | $ | 1,284 |  |  | $ | 801 |  |
| Work in process |  | 50 |  |  | 54 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales |  | 80 |  |  | 97 |  |
| Manufactured finished goods |  | 522 |  |  | 422 |  |
| Total finished goods |  | 602 |  |  | 519 |  |
| Service-related spares |  | 116 |  |  | 174 |  |
| Demonstration systems |  | 7 |  |  | 11 |  |
| Total |  | $ | 2,059 |  |  | $ | 1,559 |  |

[0000858877-22-000004:notes:76]
[same as prior period, unchanged from 0000858877-21-000018:notes:72]

[0000858877-22-000004:notes:77]
|  |  | January 29,2022 |  | July 31,2021 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,293 |  |  | $ | 4,304 |  |
| Computer equipment and related software |  | 852 |  |  | 858 |  |
| Production, engineering, and other equipment |  | 4,879 |  |  | 5,106 |  |
| Operating lease assets |  | 245 |  |  | 273 |  |
| Furniture, fixtures and other |  | 353 |  |  | 377 |  |
| Total gross property and equipment |  | 10,622 |  |  | 10,918 |  |
| Less: accumulated depreciation and amortization |  | (8,482) |  |  | (8,580) |  |
| Total |  | $ | 2,140 |  |  | $ | 2,338 |  |

[0000858877-22-000004:notes:78]
[same as prior period, unchanged from 0000858877-21-000018:notes:74]

[0000858877-22-000004:notes:79]
|  |  | January 29,2022 |  | July 31,2021 |
| Product |  | $ | 13,532 |  |  | $ | 13,270 |  |
| Service |  | 16,986 |  |  | 17,623 |  |
| Total |  | $ | 30,518 |  |  | $ | 30,893 |  |
| Current |  | $ | 16,310 |  |  | $ | 16,289 |  |
| Noncurrent |  | 14,208 |  |  | 14,604 |  |
| Total |  | $ | 30,518 |  |  | $ | 30,893 |  |

[0000858877-22-000004:notes:80]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of January 29, 2022, the aggregate amount of RPO was comprised of $22.3 billion of deferred revenue and $8.2 billion of unbilled contract revenue. We expect approximately 53% of this amount to be recognized as revenue over the next 12 months. As of July 31, 2021, the aggregate amount of RPO was comprised of $22.2 billion of deferred revenue and $8.7 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

[0000858877-22-000004:notes:81]
[same as prior period, unchanged from 0000858877-21-000018:notes:77]

[0000858877-22-000004:notes:82]
|  |  | January 29,2022 |  | July 31,2021 |
| Product |  | $ | 9,767 |  |  | $ | 9,416 |  |
| Service |  | 12,546 |  |  | 12,748 |  |
| Total |  | $ | 22,313 |  |  | $ | 22,164 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 12,268 |  |  | $ | 12,148 |  |
| Noncurrent |  | 10,045 |  |  | 10,016 |  |
| Total |  | $ | 22,313 |  |  | $ | 22,164 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000858877-22-000004:notes:83]
Leases 
(a)Lessee Arrangements

[0000858877-22-000004:notes:84]
The following table presents our operating lease balances (in millions):

[0000858877-22-000004:notes:85]
|  | Balance Sheet Line Item |  | January 29, 2022 |  | July 31, 2021 |
| Operating lease right-of-use assets | Other assets |  | $ | 1,078 |  |  | $ | 1,095 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 376 |  |  | $ | 337 |  |
| Operating lease liabilities | Other long-term liabilities |  | 763 |  |  | 831 |  |
| Total operating lease liabilities |  |  | $ | 1,139 |  |  | $ | 1,168 |  |

[0000858877-22-000004:notes:86]
The components of our lease expenses were as follows (in millions):

[0000858877-22-000004:notes:87]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29, 2022 |  | January 23, 2021 |  | January 29, 2022 |  | January 23, 2021 |
| Operating lease expense | $ | 98 |  |  | $ | 103 |  |  | $ | 193 |  |  | $ | 201 |  |
| Short-term lease expense | 15 |  |  | 17 |  |  | 32 |  |  | 35 |  |
| Variable lease expense | 41 |  |  | 43 |  |  | 90 |  |  | 89 |  |
| Total lease expense | $ | 154 |  |  | $ | 163 |  |  | $ | 315 |  |  | $ | 325 |  |

[0000858877-22-000004:notes:88]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-22-000004:notes:89]
|  | Six Months Ended |
|  | January 29, 2022 |  | January 23, 2021 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 202 |  |  | $ | 201 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 178 |  |  | $ | 218 |  |

[0000858877-22-000004:notes:90]
The weighted-average lease term was 4.7 years and 5.2 years as of January 29, 2022 and July 31, 2021, respectively. The weighted-average discount rate was 1.7% as of each of January 29, 2022 and July 31, 2021.

[0000858877-22-000004:notes:91]
The maturities of our operating leases (undiscounted) as of January 29, 2022 are as follows (in millions):

[0000858877-22-000004:notes:92]
| Fiscal Year | Amount |
| 2022 (remaining six months) | $ | 196 |  |
| 2023 | 323 |  |
| 2024 | 234 |  |
| 2025 | 154 |  |
| 2026 | 85 |  |
| Thereafter | 217 |  |
| Total lease payments | 1,209 |  |
| Less interest | (70) |  |
| Total | $ | 1,139 |  |

[0000858877-22-000004:notes:93]
(b)Lessor Arrangements

[0000858877-22-000004:notes:94]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income for the second quarter and first six months of fiscal 2022 was $14 million and $29 million, respectively, and $19 million and $40 million for the corresponding periods of fiscal 2021, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-22-000004:notes:95]
Future minimum lease payments on our lease receivables as of January 29, 2022 are summarized as follows (in millions):

[0000858877-22-000004:notes:96]
| Fiscal Year | Amount |
| 2022 (remaining six months) | $ | 327 |  |
| 2023 | 502 |  |
| 2024 | 321 |  |
| 2025 | 144 |  |
| 2026 | 61 |  |
| Thereafter | 9 |  |
| Total | 1,364 |  |
| Less: Present value of lease payments | 1,300 |  |
| Unearned income | $ | 64 |  |

[0000858877-22-000004:notes:97]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-22-000004:notes:98]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-22-000004:notes:99]
|  | January 29, 2022 |  | July 31, 2021 |
| Operating lease assets | $ | 245 |  |  | $ | 273 |  |
| Accumulated depreciation | (148) |  |  | (165) |  |
| Operating lease assets, net | $ | 97 |  |  | $ | 108 |  |

[0000858877-22-000004:notes:100]
Our operating lease income for the second quarter and first six months of fiscal 2022 was $29 million and $61 million, respectively, and $40 million and $83 million for the corresponding periods of fiscal 2021, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-22-000004:notes:101]
Minimum future rentals on noncancelable operating leases as of January 29, 2022 are summarized as follows (in millions):

[0000858877-22-000004:notes:102]
| Fiscal Year | Amount |
| 2022 (remaining six months) | $ | 24 |  |
| 2023 | 30 |  |
| 2024 | 13 |  |
| 2025 | 2 |  |
| Total | $ | 69 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-22-000004:notes:103]
[same as prior period, unchanged from 0000858877-21-000018:notes:99]

[0000858877-22-000004:notes:104]
[same as prior period, unchanged from 0000858877-21-000018:notes:100]

[0000858877-22-000004:notes:105]
[same as prior period, unchanged from 0000858877-21-000018:notes:101]

[0000858877-22-000004:notes:106]
| January 29, 2022 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 1,364 |  |  | $ | 4,581 |  |  | $ | 2,149 |  |  | $ | 8,094 |  |
| Residual value | 88 |  |  | — |  |  | — |  |  | 88 |  |
| Unearned income | (64) |  |  | — |  |  | — |  |  | (64) |  |
| Allowance for credit loss | (27) |  |  | (67) |  |  | (3) |  |  | (97) |  |
| Total, net | $ | 1,361 |  |  | $ | 4,514 |  |  | $ | 2,146 |  |  | $ | 8,021 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 651 |  |  | $ | 2,218 |  |  | $ | 1,128 |  |  | $ | 3,997 |  |
| Noncurrent | 710 |  |  | 2,296 |  |  | 1,018 |  |  | 4,024 |  |
| Total, net | $ | 1,361 |  |  | $ | 4,514 |  |  | $ | 2,146 |  |  | $ | 8,021 |  |

[0000858877-22-000004:notes:107]
[same as prior period, unchanged from 0000858877-21-000018:notes:103]

[0000858877-22-000004:notes:108]
[same as prior period, unchanged from 0000858877-21-000018:notes:104]

[0000858877-22-000004:notes:109]
The tables below present our gross financing receivables, excluding residual value, less unearned income, categorized by our internal credit risk rating by period of origination (in millions):

[0000858877-22-000004:notes:110]
| January 29, 2022 |  |  | Fiscal Year |  | Six Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 28, 2018 |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | January 29, 2022 |  | Total |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 6 |  |  | $ | 51 |  |  | $ | 104 |  |  | $ | 171 |  |  | $ | 209 |  |  | $ | 125 |  |  | $ | 666 |  |
| 5 to 6 | 6 |  |  | 28 |  |  | 105 |  |  | 199 |  |  | 200 |  |  | 57 |  |  | 595 |  |
| 7 and Higher | 1 |  |  | 2 |  |  | 6 |  |  | 15 |  |  | 4 |  |  | 11 |  |  | 39 |  |
| Total Lease Receivables | $ | 13 |  |  | $ | 81 |  |  | $ | 215 |  |  | $ | 385 |  |  | $ | 413 |  |  | $ | 193 |  |  | $ | 1,300 |  |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 16 |  |  | $ | 85 |  |  | $ | 221 |  |  | $ | 665 |  |  | $ | 1,182 |  |  | $ | 660 |  |  | $ | 2,829 |  |
| 5 to 6 | 5 |  |  | 34 |  |  | 119 |  |  | 359 |  |  | 662 |  |  | 450 |  |  | 1,629 |  |
| 7 and Higher | 2 |  |  | 2 |  |  | 36 |  |  | 36 |  |  | 26 |  |  | 21 |  |  | 123 |  |
| Total Loan Receivables | $ | 23 |  |  | $ | 121 |  |  | $ | 376 |  |  | $ | 1,060 |  |  | $ | 1,870 |  |  | $ | 1,131 |  |  | $ | 4,581 |  |
| Financed Service Contracts: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 16 |  |  | $ | 65 |  |  | $ | 169 |  |  | $ | 740 |  |  | $ | 380 |  |  | $ | 1,372 |  |
| 5 to 6 | 1 |  |  | 15 |  |  | 76 |  |  | 184 |  |  | 337 |  |  | 149 |  |  | 762 |  |
| 7 and Higher | — |  |  | — |  |  | 3 |  |  | 6 |  |  | 3 |  |  | 3 |  |  | 15 |  |
| Total Financed Service Contracts | $ | 3 |  |  | $ | 31 |  |  | $ | 144 |  |  | $ | 359 |  |  | $ | 1,080 |  |  | $ | 532 |  |  | $ | 2,149 |  |
| Total | $ | 39 |  |  | $ | 233 |  |  | $ | 735 |  |  | $ | 1,804 |  |  | $ | 3,363 |  |  | $ | 1,856 |  |  | $ | 8,030 |  |

[0000858877-22-000004:notes:111]
| July 31, 2021 |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 29, 2017 |  | July 28, 2018 |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | Total |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 20 |  |  | $ | 100 |  |  | $ | 168 |  |  | $ | 282 |  |  | $ | 227 |  |  | $ | 799 |  |
| 5 to 6 | 1 |  |  | 17 |  |  | 65 |  |  | 187 |  |  | 285 |  |  | 231 |  |  | 786 |  |
| 7 and Higher | — |  |  | 2 |  |  | 6 |  |  | 12 |  |  | 23 |  |  | 4 |  |  | 47 |  |
| Total Lease Receivables | $ | 3 |  |  | $ | 39 |  |  | $ | 171 |  |  | $ | 367 |  |  | $ | 590 |  |  | $ | 462 |  |  | $ | 1,632 |  |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 4 |  |  | $ | 86 |  |  | $ | 134 |  |  | $ | 577 |  |  | $ | 990 |  |  | $ | 1,552 |  |  | $ | 3,343 |  |
| 5 to 6 | — |  |  | 19 |  |  | 75 |  |  | 202 |  |  | 505 |  |  | 925 |  |  | 1,726 |  |
| 7 and Higher | 1 |  |  | 2 |  |  | 4 |  |  | 50 |  |  | 43 |  |  | 34 |  |  | 134 |  |
| Total Loan Receivables | $ | 5 |  |  | $ | 107 |  |  | $ | 213 |  |  | $ | 829 |  |  | $ | 1,538 |  |  | $ | 2,511 |  |  | $ | 5,203 |  |
| Financed Service Contracts: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | — |  |  | $ | 38 |  |  | $ | 26 |  |  | $ | 106 |  |  | $ | 252 |  |  | $ | 1,053 |  |  | $ | 1,475 |  |
| 5 to 6 | — |  |  | 6 |  |  | 26 |  |  | 105 |  |  | 302 |  |  | 520 |  |  | 959 |  |
| 7 and Higher | — |  |  | — |  |  | 1 |  |  | 6 |  |  | 7 |  |  | 5 |  |  | 19 |  |
| Total Financed Service Contracts | $ | — |  |  | $ | 44 |  |  | $ | 53 |  |  | $ | 217 |  |  | $ | 561 |  |  | $ | 1,578 |  |  | $ | 2,453 |  |
| Total | $ | 8 |  |  | $ | 190 |  |  | $ | 437 |  |  | $ | 1,413 |  |  | $ | 2,689 |  |  | $ | 4,551 |  |  | $ | 9,288 |  |

[0000858877-22-000004:notes:112]
The following tables present the aging analysis of gross receivables as of January 29, 2022 and July 31, 2021 (in millions):

[0000858877-22-000004:notes:113]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| January 29, 2022 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 26 |  |  | $ | 15 |  |  | $ | 26 |  |  | $ | 67 |  |  | $ | 1,233 |  |  | $ | 1,300 |  |  | $ | 9 |  |  | $ | 19 |  |  | $ | 19 |  |
| Loan receivables | 66 |  |  | 12 |  |  | 42 |  |  | 120 |  |  | 4,461 |  |  | 4,581 |  |  | 8 |  |  | 25 |  |  | 25 |  |
| Financed service contracts | 16 |  |  | 6 |  |  | 10 |  |  | 32 |  |  | 2,117 |  |  | 2,149 |  |  | 4 |  |  | 2 |  |  | 2 |  |
| Total | $ | 108 |  |  | $ | 33 |  |  | $ | 78 |  |  | $ | 219 |  |  | $ | 7,811 |  |  | $ | 8,030 |  |  | $ | 21 |  |  | $ | 46 |  |  | $ | 46 |  |

[0000858877-22-000004:notes:114]
[same as prior period, unchanged from 0000858877-21-000018:notes:111]

[0000858877-22-000004:notes:115]
[same as prior period, unchanged from 0000858877-21-000018:notes:112]

[0000858877-22-000004:notes:116]
[same as prior period, unchanged from 0000858877-21-000018:notes:113]

[0000858877-22-000004:notes:117]
[same as prior period, unchanged from 0000858877-21-000018:notes:114]

[0000858877-22-000004:notes:118]
| Three months ended January 29, 2022 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of October 30, 2021 | $ | 33 |  |  | $ | 74 |  |  | $ | 2 |  |  | $ | 109 |  |
| Provisions (benefits) | (4) |  |  | (7) |  |  | 1 |  |  | (10) |  |
| Recoveries (write-offs), net | (2) |  |  | — |  |  | — |  |  | (2) |  |
| Allowance for credit loss as of January 29, 2022 | $ | 27 |  |  | $ | 67 |  |  | $ | 3 |  |  | $ | 97 |  |

[0000858877-22-000004:notes:119]
| Three Months Ended January 23, 2021 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of October 24, 2020 | $ | 46 |  |  | $ | 101 |  |  | $ | 7 |  |  | $ | 154 |  |
| Provisions (benefits) | (4) |  |  | (6) |  |  | 2 |  |  | (8) |  |
| Other | 1 |  |  | 1 |  |  | — |  |  | 2 |  |
| Allowance for credit loss as of January 23, 2021 | $ | 43 |  |  | $ | 96 |  |  | $ | 9 |  |  | $ | 148 |  |

[0000858877-22-000004:notes:120]
| Six months ended January 29, 2022 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 31, 2021 | $ | 38 |  |  | $ | 86 |  |  | $ | 3 |  |  | $ | 127 |  |
| Provisions (benefits) | (9) |  |  | (19) |  |  | — |  |  | (28) |  |
| Recoveries (write-offs), net | (2) |  |  | — |  |  | — |  |  | (2) |  |
| Allowance for credit loss as of January 29, 2022 | $ | 27 |  |  | $ | 67 |  |  | $ | 3 |  |  | $ | 97 |  |

[0000858877-22-000004:notes:121]
| Six months ended January 23, 2021 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 25, 2020 | $ | 48 |  |  | $ | 81 |  |  | $ | 9 |  |  | $ | 138 |  |
| Provisions (benefits) | (7) |  |  | (3) |  |  | 1 |  |  | (9) |  |
| Other | 2 |  |  | 18 |  |  | (1) |  |  | 19 |  |
| Allowance for credit loss as of January 23, 2021 | $ | 43 |  |  | $ | 96 |  |  | $ | 9 |  |  | $ | 148 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-22-000004:notes:122]
Available-for-Sale Debt and Equity Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-22-000004:notes:123]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-22-000004:notes:124]
| January 29, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,702 |  |  | $ | 4 |  |  | $ | (19) |  |  | $ | 1,687 |  |
| U.S. government agency securities | 142 |  |  | — |  |  | (2) |  |  | 140 |  |
| Corporate debt securities | 9,008 |  |  | 82 |  |  | (102) |  |  | 8,988 |  |
| U.S. agency mortgage-backed securities | 2,569 |  |  | 10 |  |  | (56) |  |  | 2,523 |  |
| Commercial paper | 614 |  |  | — |  |  | — |  |  | 614 |  |
| Certificates of deposit | 209 |  |  | — |  |  | — |  |  | 209 |  |
| Total | $ | 14,244 |  |  | $ | 96 |  |  | $ | (179) |  |  | $ | 14,161 |  |

[0000858877-22-000004:notes:125]
| July 31, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,773 |  |  | $ | 21 |  |  | $ | — |  |  | $ | 1,794 |  |
| U.S. government agency securities | 152 |  |  | — |  |  | — |  |  | 152 |  |
| Non-U.S. government and agency securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Corporate debt securities | 8,727 |  |  | 213 |  |  | (30) |  |  | 8,910 |  |
| U.S. agency mortgage-backed securities | 2,838 |  |  | 34 |  |  | (10) |  |  | 2,862 |  |
| Commercial paper | 1,190 |  |  | — |  |  | — |  |  | 1,190 |  |
| Certificates of deposit | 295 |  |  | — |  |  | — |  |  | 295 |  |
| Total | $ | 14,978 |  |  | $ | 268 |  |  | $ | (40) |  |  | $ | 15,206 |  |

[0000858877-22-000004:notes:126]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-22-000004:notes:127]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29, 2022 |  | January 23, 2021 |  | January 29, 2022 |  | January 23, 2021 |
| Gross realized gains | $ | 13 |  |  | $ | 9 |  |  | $ | 19 |  |  | $ | 24 |  |
| Gross realized losses | (3) |  |  | — |  |  | (3) |  |  | — |  |
| Total | $ | 10 |  |  | $ | 9 |  |  | $ | 16 |  |  | $ | 24 |  |

[0000858877-22-000004:notes:128]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 29, 2022 and July 31, 2021 (in millions):

[0000858877-22-000004:notes:129]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 29, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,124 |  |  | $ | (19) |  |  | $ | 2 |  |  | $ | — |  |  | $ | 1,126 |  |  | $ | (19) |  |
| U.S. government agency securities | 125 |  |  | (1) |  |  | 15 |  |  | (1) |  |  | 140 |  |  | (2) |  |
| Corporate debt securities | 4,230 |  |  | (69) |  |  | 182 |  |  | (8) |  |  | 4,412 |  |  | (77) |  |
| U.S. agency mortgage-backed securities | 1,881 |  |  | (52) |  |  | 91 |  |  | (4) |  |  | 1,972 |  |  | (56) |  |
| Total | $ | 7,360 |  |  | $ | (141) |  |  | $ | 290 |  |  | $ | (13) |  |  | $ | 7,650 |  |  | $ | (154) |  |

[0000858877-22-000004:notes:130]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 31, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 468 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 468 |  |  | $ | — |  |
| U.S. government agency securities | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |
| Corporate debt securities | 1,086 |  |  | (5) |  |  | 6 |  |  | — |  |  | 1,092 |  |  | (5) |  |
| U.S. agency mortgage-backed securities | 1,293 |  |  | (10) |  |  | 13 |  |  | — |  |  | 1,306 |  |  | (10) |  |
| Commercial paper | 37 |  |  | — |  |  | — |  |  | — |  |  | 37 |  |  | — |  |
| Total | $ | 2,910 |  |  | $ | (15) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 2,929 |  |  | $ | (15) |  |

[0000858877-22-000004:notes:131]
The following table summarizes the maturities of our available-for-sale debt investments as of January 29, 2022 (in millions):

[0000858877-22-000004:notes:132]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 3,512 |  |  | $ | 3,496 |  |
| After 1 year through 5 years | 7,999 |  |  | 7,969 |  |
| After 5 years through 10 years | 162 |  |  | 171 |  |
| After 10 years | 2 |  |  | 2 |  |
| Mortgage-backed securities with no single maturity | 2,569 |  |  | 2,523 |  |
| Total | $ | 14,244 |  |  | $ | 14,161 |  |

[0000858877-22-000004:notes:133]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-22-000004:notes:134]
(b)Summary of Equity Investments

[0000858877-22-000004:notes:135]
We recognized a net unrealized loss of $18 million and $13 million during the second quarter and first six months of fiscal 2022, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $14 million and $16 million for the second quarter and first six months of fiscal 2022, respectively. We held equity interests in certain private equity funds of $1.1 billion and $0.9 billion as of January 29, 2022 and July 31, 2021, respectively, which are accounted for under the NAV practical expedient.

[0000858877-22-000004:notes:136]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 29, 2022, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-22-000004:notes:137]
The carrying value of our investments in privately held companies was $1.8 billion and $1.5 billion as of January 29, 2022 and July 31, 2021, respectively. Of the total carrying value of our investments in privately held companies as of January 29, 2022, $1.1 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of January 29, 2022, we have total funding commitments of $0.4 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-22-000004:notes:138]
[same as prior period, unchanged from 0000858877-21-000018:notes:133]

[0000858877-22-000004:notes:139]
[same as prior period, unchanged from 0000858877-21-000018:notes:134]

[0000858877-22-000004:notes:140]
[same as prior period, unchanged from 0000858877-21-000018:notes:135]

[0000858877-22-000004:notes:141]
[same as prior period, unchanged from 0000858877-21-000018:notes:136]

[0000858877-22-000004:notes:142]
[same as prior period, unchanged from 0000858877-21-000018:notes:137]

[0000858877-22-000004:notes:143]
[same as prior period, unchanged from 0000858877-21-000018:notes:138]

[0000858877-22-000004:notes:144]
[same as prior period, unchanged from 0000858877-21-000018:notes:139]

[0000858877-22-000004:notes:145]
[same as prior period, unchanged from 0000858877-21-000018:notes:140]

[0000858877-22-000004:notes:146]
|  | JANUARY 29, 2022 |  | JULY 31, 2021 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 3,402 |  |  | $ | — |  |  | $ | 3,402 |  |  | $ | 5,694 |  |  | $ | — |  |  | $ | 5,694 |  |
| Commercial paper | — |  |  | 10 |  |  | 10 |  |  | — |  |  | 114 |  |  | 114 |  |
| U.S. government securities | — |  |  | — |  |  | — |  |  | — |  |  | 300 |  |  | 300 |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 1,687 |  |  | 1,687 |  |  | — |  |  | 1,794 |  |  | 1,794 |  |
| U.S. government agency securities | — |  |  | 140 |  |  | 140 |  |  | — |  |  | 152 |  |  | 152 |  |
| Corporate debt securities | — |  |  | 8,988 |  |  | 8,988 |  |  | — |  |  | 8,910 |  |  | 8,910 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,523 |  |  | 2,523 |  |  | — |  |  | 2,862 |  |  | 2,862 |  |
| Non-U.S. government and agency securities | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | 3 |  |
| Commercial paper | — |  |  | 614 |  |  | 614 |  |  | — |  |  | 1,190 |  |  | 1,190 |  |
| Certificates of deposit | — |  |  | 209 |  |  | 209 |  |  | — |  |  | 295 |  |  | 295 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 221 |  |  | — |  |  | 221 |  |  | 137 |  |  | — |  |  | 137 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 750 |  |  | — |  |  | 750 |  |  | 750 |  |  | — |  |  | 750 |  |
| Derivative assets | — |  |  | 77 |  |  | 77 |  |  | — |  |  | 126 |  |  | 126 |  |
| Total | $ | 4,373 |  |  | $ | 14,248 |  |  | $ | 18,621 |  |  | $ | 6,581 |  |  | $ | 15,746 |  |  | $ | 22,327 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 38 |  |  | $ | 38 |  |  | $ | — |  |  | $ | 20 |  |  | $ | 20 |  |
| Total | $ | — |  |  | $ | 38 |  |  | $ | 38 |  |  | $ | — |  |  | $ | 20 |  |  | $ | 20 |  |

[0000858877-22-000004:notes:147]
[same as prior period, unchanged from 0000858877-21-000018:notes:142]

[0000858877-22-000004:notes:148]
[same as prior period, unchanged from 0000858877-21-000018:notes:143]

[0000858877-22-000004:notes:149]
Our non-marketable equity securities using the measurement alternative are adjusted to fair value on a non-recurring basis. Adjustments are made when observable transactions for identical or similar investments of the same issuer occur, or due to impairment. These securities are classified as Level 3 in the fair value hierarchy because we estimate the value based on valuation methods using the observable transaction price at the transaction date and other unobservable inputs such as volatility, rights, and obligations of the securities we hold.

[0000858877-22-000004:notes:150]
[same as prior period, unchanged from 0000858877-21-000018:notes:146]

[0000858877-22-000004:notes:151]
The fair value of our short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables and financed service contracts as of January 29, 2022 and July 31, 2021 was $3.3 billion and $4.0 billion, respectively. The estimated fair value of our long-term loan receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.
As of January 29, 2022, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of January 29, 2022, the fair value of our senior notes was $11.1 billion with a carrying amount of $9.5 billion. This compares to a fair value of $13.7 billion and a carrying amount of $11.5 billion as of July 31, 2021. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:DebtDisclosureTextBlock

[0000858877-22-000004:notes:152]
Borrowings 
(a)Short-Term Debt

[0000858877-22-000004:notes:153]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-22-000004:notes:154]
|  | January 29, 2022 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 502 |  |  | 1.14 | % |  | $ | 2,508 |  |  | 1.75 | % |
| Commercial paper | 2,000 |  |  | 0.15 | % |  | — |  |  | — |  |
| Total short-term debt | $ | 2,502 |  |  |  |  | $ | 2,508 |  |  |  |

[0000858877-22-000004:notes:155]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-22-000004:notes:156]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-22-000004:notes:157]
(b)Long-Term Debt

[0000858877-22-000004:notes:158]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-22-000004:notes:159]
|  |  |  | January 29, 2022 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.14% |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.00% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.31% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,500 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (77) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 48 |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 9,471 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 502 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,969 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 9,471 |  |  |  |  | $ | 11,526 |  |  |  |

[0000858877-22-000004:notes:160]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $2.0 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-22-000004:notes:161]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 29, 2022, we were in compliance with all debt covenants.

[0000858877-22-000004:notes:162]
As of January 29, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-22-000004:notes:163]
| Fiscal Year | Amount |
| 2022 (remaining six months) | $ | 500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 9,500 |  |

[0000858877-22-000004:notes:164]
(c)Credit Facility

[0000858877-22-000004:notes:165]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. The credit agreement is structured as an amendment and restatement of our 364-day credit agreement, which would have terminated on May 14, 2021. As of January 29, 2022, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.

[0000858877-22-000004:notes:166]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-22-000004:notes:167]
[same as prior period, unchanged from 0000858877-21-000018:notes:163]

[0000858877-22-000004:notes:168]
[same as prior period, unchanged from 0000858877-21-000018:notes:164]

[0000858877-22-000004:notes:169]
[same as prior period, unchanged from 0000858877-21-000018:notes:165]

[0000858877-22-000004:notes:170]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | January 29,2022 |  | July 31,2021 |  | Balance Sheet Line Item |  | January 29,2022 |  | July 31,2021 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 24 |  |  | $ | 14 |  |  | Other current liabilities |  | $ | 1 |  |  | $ | 3 |  |
| Foreign currency derivatives | Other assets |  | 2 |  |  | 1 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other current assets |  | 3 |  |  | 9 |  |  | Other current liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other assets |  | 46 |  |  | 99 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 75 |  |  | 123 |  |  |  |  | 1 |  |  | 3 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 2 |  |  | 3 |  |  | Other current liabilities |  | 30 |  |  | 16 |  |
| Foreign currency derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 2 |  |  | 1 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 5 |  |  | — |  |
| Total |  |  | 2 |  |  | 3 |  |  |  |  | 37 |  |  | 17 |  |
| Total |  |  | $ | 77 |  |  | $ | 126 |  |  |  |  | $ | 38 |  |  | $ | 20 |  |

[0000858877-22-000004:notes:171]
[same as prior period, unchanged from 0000858877-21-000018:notes:167]

[0000858877-22-000004:notes:172]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | January 29,2022 |  | July 31,2021 |  | January 29,2022 |  | July 31,2021 |
| Short-term debt |  | $ | (502) |  |  | $ | (508) |  |  | $ | (3) |  |  | $ | (9) |  |
| Long-term debt |  | $ | (1,543) |  |  | $ | (1,594) |  |  | $ | (45) |  |  | $ | (97) |  |

[0000858877-22-000004:notes:173]
[same as prior period, unchanged from 0000858877-21-000018:notes:169]

[0000858877-22-000004:notes:174]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 29, 2022 |  | January 23, 2021 |  | January 29, 2022 |  | January 23, 2021 |
| Interest rate derivatives: |  |  |  |  |  |  |  |  |
| Hedged items |  | $ | 32 |  |  | $ | 14 |  |  | $ | 58 |  |  | $ | 33 |  |
| Derivatives designated as hedging instruments |  | (32) |  |  | (14) |  |  | (59) |  |  | (34) |  |
| Total |  | $ | — |  |  | $ | — |  |  | $ | (1) |  |  | $ | (1) |  |

[0000858877-22-000004:notes:175]
[same as prior period, unchanged from 0000858877-21-000018:notes:171]

[0000858877-22-000004:notes:176]
|  |  |  |  | GAINS (LOSSES) FOR THE THREE MONTHS ENDED |  | GAINS (LOSSES) FOR THE SIX MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (36) |  |  | $ | 33 |  |  | $ | (56) |  |  | $ | 47 |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | (41) |  |  | 76 |  |  | (20) |  |  | 99 |  |
| Equity derivatives |  | Other income (loss), net |  | (3) |  |  | 9 |  |  | 1 |  |  | 14 |  |
| Total |  |  |  | $ | (80) |  |  | $ | 118 |  |  | $ | (75) |  |  | $ | 160 |  |

[0000858877-22-000004:notes:177]
[same as prior period, unchanged from 0000858877-21-000018:notes:173]

[0000858877-22-000004:notes:178]
|  | January 29,2022 |  | July 31,2021 |
| Foreign currency derivatives | $ | 4,254 |  |  | $ | 4,139 |  |
| Interest rate derivatives | 2,000 |  |  | 2,000 |  |
| Total return swaps—deferred compensation | 728 |  |  | 730 |  |
| Total | $ | 6,982 |  |  | $ | 6,869 |  |

[0000858877-22-000004:notes:179]
[same as prior period, unchanged from 0000858877-21-000018:notes:175]

[0000858877-22-000004:notes:180]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty. As of January 29, 2022 and July 31, 2021, the potential effects of these rights of set-off associated with the derivative contracts would be a reduction to both derivative assets and derivative liabilities of $27 million and $17 million, respectively.

[0000858877-22-000004:notes:181]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral received as of January 29, 2022 and July 31, 2021 was $56 million and $109 million, respectively. Including the effects of collateral, this results in a net derivative liability of $16 million and $3 million as of January 29, 2022 and July 31, 2021, respectively.

[0000858877-22-000004:notes:182]
[same as prior period, unchanged from 0000858877-21-000018:notes:178]

[0000858877-22-000004:notes:183]
[same as prior period, unchanged from 0000858877-21-000018:notes:179]

[0000858877-22-000004:notes:184]
We hedge forecasted foreign currency transactions related to certain revenues, operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The derivative instrument’s gain or loss is initially reported as a component of accumulated other comprehensive income (AOCI) and subsequently reclassified into earnings when the hedged exposure affects earnings. During the periods presented, we did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-22-000004:notes:185]
[same as prior period, unchanged from 0000858877-21-000018:notes:181]

[0000858877-22-000004:notes:186]
[same as prior period, unchanged from 0000858877-21-000018:notes:182]

[0000858877-22-000004:notes:187]
[same as prior period, unchanged from 0000858877-21-000018:notes:183]

[0000858877-22-000004:notes:188]
[same as prior period, unchanged from 0000858877-21-000018:notes:184]

[0000858877-22-000004:notes:189]
[same as prior period, unchanged from 0000858877-21-000018:notes:185]

[0000858877-22-000004:notes:190]
[same as prior period, unchanged from 0000858877-21-000018:notes:186]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-22-000004:notes:191]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-22-000004:notes:192]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-22-000004:notes:193]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-22-000004:notes:194]
|  | January 29,2022 |  | July 31,2021 |
| Less than 1 year | $ | 9,224 |  |  | $ | 6,903 |  |
| 1 to 3 years | 1,879 |  |  | 1,806 |  |
| 3 to 5 years | 1,159 |  |  | 1,545 |  |
| Total | $ | 12,262 |  |  | $ | 10,254 |  |

[0000858877-22-000004:notes:195]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 29, 2022 and July 31, 2021, the liability for these purchase commitments was $199 million and $151 million, respectively, and was included in other current liabilities. For further discussion around the Supply Constraints Impacts and Risks, see Result of Operations—Product Gross Margin and Liquidity and Capital Resources—Inventory Supply Chain.

[0000858877-22-000004:notes:196]
(b)Other Commitments

[0000858877-22-000004:notes:197]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-22-000004:notes:198]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-22-000004:notes:199]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29, 2022 |  | January 23, 2021 |  | January 29, 2022 |  | January 23, 2021 |
| Compensation expense related to acquisitions | $ | 75 |  |  | $ | 59 |  |  | $ | 164 |  |  | $ | 116 |  |

[0000858877-22-000004:notes:200]
As of January 29, 2022, we estimated that future cash compensation expense of up to $600 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-22-000004:notes:201]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.4 billion and $0.2 billion as of January 29, 2022 and July 31, 2021, respectively.

[0000858877-22-000004:notes:202]
(c)Product Warranties

[0000858877-22-000004:notes:203]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-22-000004:notes:204]
|  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |
| Balance at beginning of period | $ | 336 |  |  | $ | 331 |  |
| Provisions for warranties issued | 218 |  |  | 247 |  |
| Adjustments for pre-existing warranties | 2 |  |  | 4 |  |
| Settlements | (222) |  |  | (249) |  |
| Balance at end of period | $ | 334 |  |  | $ | 333 |  |

[0000858877-22-000004:notes:205]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-22-000004:notes:206]
(d)Financing and Other Guarantees

[0000858877-22-000004:notes:207]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-22-000004:notes:208]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.8 billion and $6.7 billion for the second quarter of fiscal 2022 and 2021, respectively, and was $13.4 billion and $12.8 billion for the first six months of fiscal 2022 and 2021, respectively. The balance of the channel partner financing subject to guarantees was $1.4 billion and $1.3 billion as of January 29, 2022 and July 31, 2021, respectively.

[0000858877-22-000004:notes:209]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $4 million and $3 million for the second quarter of fiscal 2022 and 2021, respectively, and was $6 million and $8 million for the first six months of fiscal 2022 and 2021, respectively.

[0000858877-22-000004:notes:210]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 29, 2022 and July 31, 2021, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-22-000004:notes:211]
|  | January 29,2022 |  | July 31,2021 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 162 |  |  | $ | 155 |  |
| End user | 4 |  |  | 5 |  |
| Total | $ | 166 |  |  | $ | 160 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (5) |  |  | $ | (16) |  |
| End user | (4) |  |  | (5) |  |
| Total | $ | (9) |  |  | $ | (21) |  |
| Total | $ | 157 |  |  | $ | 139 |  |

[0000858877-22-000004:notes:212]
(e)Indemnifications

[0000858877-22-000004:notes:213]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-22-000004:notes:214]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations discussed in this section (e) due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these cases, and the unique facts and circumstances involved in each particular case and agreement. We are unable to reasonably estimate the ultimate outcome of the cases discussed below in this section (e), but we do not believe that any potential indemnity liability would be material, and historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-22-000004:notes:215]
We were asked by seven of our customers to indemnify them in connection with patent infringement claims asserted against them by Estech Systems, Inc. (“Estech”) in the Eastern District of Texas (“E.D. Tex.”) court and the Western District of Texas court between April 24, 2020 and August 25, 2020. Estech alleged that the customer defendants infringe three patents generally related to IP telephony by using collaboration technology from us and other providers. Estech was seeking monetary damages from the customer defendants. Estech and the customer defendants resolved Estech’s claims, and we resolved the customer defendants’ indemnity claims for an amount that did not have a material effect on our Consolidated Financial Statements.

[0000858877-22-000004:notes:216]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-22-000004:notes:217]
(f)Legal Proceedings

[0000858877-22-000004:notes:218]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $151 million for the alleged evasion of import and other taxes, $764 million for interest, and $373 million for various penalties, all determined using an exchange rate as of January 29, 2022.

[0000858877-22-000004:notes:219]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-22-000004:notes:220]
China     We have completed our investigation into allegations of a self-enrichment scheme involving now-former employees in China, and shared the results of the investigation with the Securities and Exchange Commission (“SEC”) and the Department of Justice (“DOJ”). Based on the investigation results, both the SEC and the DOJ have informed the Company that they do not plan to take any action against the Company in connection with these allegations.

[0000858877-22-000004:notes:221]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted claims against us in the U.S. District Court for the District of Delaware (“D. Del.”), accusing our products and services related to network intrusion detection of infringing two patents. After a trial, SRI obtained a verdict against us, and we appealed to the United States Court of Appeals for the Federal Circuit (“Federal Circuit”) which was ultimately unsuccessful. In resolution of this matter, we have paid SRI judgments, including attorneys’ fees and post-judgment royalties and interest, in the aggregate amount of approximately $60 million. The only remaining potential liability for this matter involves a small portion of post-judgment interest. The amounts that we paid to date and any potential additional interest we may have to pay involve amounts, individually or in the aggregate, that did not or will not, as applicable, have a material effect on our Consolidated Financial Statements.

[0000858877-22-000004:notes:222]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services (including our Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal U.S. patents. We thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office (“PTO”) to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal appealed the PTAB’s findings of unpatentability to the Federal Circuit. The Federal Circuit affirmed the PTAB’s findings of unpatentability as to three of the patents on March 10, 2021, and affirmed the PTAB’s findings of unpatentability as to the remaining four patents on May 11, 2021. On August 9, 2021, Centripetal filed a writ of certiorari seeking review of the Federal Circuit’s affirmance of several of the PTAB’s unpatentability findings, which the U.S. Supreme Court denied on October 4, 2021.

[0000858877-22-000004:notes:223]
For the five asserted U.S. patents not subject to the IPR Proceedings, the district court conducted a bench trial by videoconference from May 6, 2020 to June 25, 2020. On October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The district court awarded Centripetal $1.9 billion, comprised of $756 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $14 million. The district court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $168 million and a maximum annual royalty of $300 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $84 million and a maximum annual royalty of $150 million. We believe that the district court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We have appealed the district court’s judgment as to the four patents found valid and infringed to the Federal Circuit. On October 28, 2020, by agreement of the parties, the district court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment.

[0000858877-22-000004:notes:224]
On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. district court proceedings, one of which has been invalidated by the PTAB. On June 22, 2021, Centripetal amended one of its complaints to assert one additional European patent and one additional German Utility Model patent. Centripetal seeks both injunctive relief and damages on these newly added patents.

[0000858877-22-000004:notes:225]
On December 10, 2021, the District Court of Dusseldorf issued its findings on two of the patents, rejecting Centripetal’s patent complaints. Centripetal has appealed. On December 21, 2021, the District Court of Dusseldorf stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. The proceedings on Centripetal’s amended complaint remain pending.

[0000858877-22-000004:notes:226]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of either litigation at this time. If we do not prevail in either litigation, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-22-000004:notes:227]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in E.D. Tex., seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. As of November 27, 2020, the PTO preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings. On January 13, 2021, the court entered an order staying the case pending the conclusion of the ex parte reexamination proceedings (“Reexamination Proceedings”). While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in court, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-22-000004:notes:228]
On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) (which we subsequently acquired) in D. Del, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot has asserted in its E.D. Tex. case. On September 3, 2021, the court stayed the case pending the ultimate resolution of the Reexamination Proceedings. Due to the early stage of the litigation as well as uncertainties in the litigation processes, we are unable, at this time, to reasonably estimate a potential range of loss, if any, or the ultimate outcome of this litigation.

[0000858877-22-000004:notes:229]
Viasat     On January 21, 2016, Viasat, Inc. (“Viasat”) filed suit against Acacia (which we subsequently acquired) in the California Superior Court for San Diego County (“SDSC”) seeking unpaid royalties for breach of contract and the implied covenant of good faith and fair dealing, and damages for trade secret misappropriation for certain products (“Viasat 1”). Acacia counterclaimed for patent and trade secret misappropriation, contract, and unfair competition claims. On July 17, 2019, the jury found for Viasat on its contract claims, and awarded Viasat $49 million for unpaid royalties through 2018. The jury further found that Acacia willfully misappropriated Viasat’s trade secrets and awarded Viasat $1. On Acacia’s counterclaims, the jury found for Acacia on its contract and trade secret claims and awarded Acacia $1. Both Acacia and Viasat have pending appeals to the California Court of Appeal. On November 6, 2019, Viasat filed a second suit in SDSC, alleging contract and trade secret claims for Acacia products sold from January 1, 2019 forward (“Viasat 2”). On February 28, 2020, the court stayed Viasat 2 pending the appeal in Viasat 1. On June 9, 2020, Viasat filed a third suit in SDSC (“Viasat 3”). In Viasat 3, Viasat alleges contract and trade secrets claims for sales of additional Acacia products. On August 11, 2020, the court stayed Viasat 3 pending the appeal in Viasat 1.

[0000858877-22-000004:notes:230]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court - Business Litigation Session against ViaSat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation. On April 5, 2018, ViaSat counterclaimed with contract, trade secret, and unfair competition claims (collectively, with Viasat 1, Viasat 2 and Viasat 3, the “Viasat Cases”). On December 13, 2018, the Massachusetts court entered an order staying the Massachusetts litigation, which has been extended to June 30, 2022.

[0000858877-22-000004:notes:231]
While we believe Acacia has strong defenses in each of the Viasat Cases, we are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If Acacia does not prevail, we believe that any relief ultimately assessed in any of the Viasat Cases would not have a material effect on our Consolidated Financial Statements.

[0000858877-22-000004:notes:232]
In addition, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the 
ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-22-000004:notes:233]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-22-000004:notes:234]
[same as prior period, unchanged from 0000858877-21-000018:notes:229]

[0000858877-22-000004:notes:235]
We declared and paid cash dividends of $0.37 and $0.36 per common share, or $1.5 billion, on our outstanding common stock for each of the second quarters of fiscal 2022 and 2021. We declared and paid cash dividends of $0.74 and $0.72 per common share, or $3.1 billion and $3.0 billion, on our outstanding common stock for the first six months of fiscal 2022 and 2021, respectively.

[0000858877-22-000004:notes:236]
On February 16, 2022, our Board of Directors declared a quarterly dividend of $0.38 per common share to be paid on April 27, 2022 to all stockholders of record as of the close of business on April 6, 2022. Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-22-000004:notes:237]
[same as prior period, unchanged from 0000858877-21-000018:notes:232]

[0000858877-22-000004:notes:238]
In September 2001, our Board of Directors authorized a stock repurchase program. On February 16, 2022, our Board of Directors authorized a $15 billion increase to the stock repurchase program. The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $18 billion with no termination date. A summary of the stock repurchase activity for fiscal 2022 and 2021 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-22-000004:notes:239]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2022 |  |  |  |  |  |  |
| January 29, 2022 |  | 82 |  |  | $ | 58.36 |  |  | $ | 4,824 |  |
| October 30, 2021 |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |
| Fiscal 2021 |  |  |  |  |  |  |
| July 31, 2021 |  | 15 |  |  | $ | 53.30 |  |  | $ | 791 |  |
| May 1, 2021 |  | 10 |  |  | $ | 48.71 |  |  | $ | 510 |  |
| January 23, 2021 |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |
| October 24, 2020 |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |

[0000858877-22-000004:notes:240]
There were $25 million in stock repurchases that were pending settlement as of July 31, 2021.

[0000858877-22-000004:notes:241]
[same as prior period, unchanged from 0000858877-21-000018:notes:236]

[0000858877-22-000004:notes:242]
[same as prior period, unchanged from 0000858877-21-000018:notes:237]

[0000858877-22-000004:notes:243]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock of one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights of such series, and any qualification, limitations or restrictions thereof, of the shares of such series. As of January 29, 2022, we had not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-22-000004:notes:244]
[same as prior period, unchanged from 0000858877-21-000018:notes:239]

[0000858877-22-000004:notes:245]
We have one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with us. The number and frequency of share-based awards are based on competitive practices, our operating results, government regulations, and other factors. Our primary stock incentive plan is summarized as follows:

[0000858877-22-000004:notes:246]
The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions. Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. As of January 29, 2022, the maximum number of shares issuable under the 2005 Plan over its term was 790 million shares. The 2005 Plan may be terminated by our Board of Directors at any time and for any reason, and is currently set to terminate at the 2030 Annual Meeting unless re-adopted or extended by our stockholders prior to or on such date.

[0000858877-22-000004:notes:247]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of January 29, 2022, 216 million shares were authorized for future grant under the 2005 Plan.

[0000858877-22-000004:notes:248]
[same as prior period, unchanged from 0000858877-21-000018:notes:243]

[0000858877-22-000004:notes:249]
We have an Employee Stock Purchase Plan under which 721 million shares of our common stock have been reserved for issuance as of January 29, 2022. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. Under the Employee Stock Purchase Plan, we issued 8 million shares during the second quarter and first six months of fiscal 2022 and 8 million shares during the second quarter and first six months of fiscal 2021. As of January 29, 2022, 117 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-22-000004:notes:250]
[same as prior period, unchanged from 0000858877-21-000018:notes:245]

[0000858877-22-000004:notes:251]
[same as prior period, unchanged from 0000858877-21-000018:notes:246]

[0000858877-22-000004:notes:252]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29, 2022 |  | January 23, 2021 |  | January 29, 2022 |  | January 23, 2021 |
| Cost of sales—product | $ | 29 |  |  | $ | 25 |  |  | $ | 54 |  |  | $ | 49 |  |
| Cost of sales—service | 52 |  |  | 43 |  |  | 96 |  |  | 84 |  |
| Share-based compensation expense in cost of sales | 81 |  |  | 68 |  |  | 150 |  |  | 133 |  |
| Research and development | 205 |  |  | 171 |  |  | 386 |  |  | 338 |  |
| Sales and marketing | 142 |  |  | 128 |  |  | 282 |  |  | 262 |  |
| General and administrative | 49 |  |  | 59 |  |  | 111 |  |  | 120 |  |
| Restructuring and other charges | — |  |  | 10 |  |  | 1 |  |  | 21 |  |
| Share-based compensation expense in operating expenses | 396 |  |  | 368 |  |  | 780 |  |  | 741 |  |
| Total share-based compensation expense | $ | 477 |  |  | $ | 436 |  |  | $ | 930 |  |  | $ | 874 |  |
| Income tax benefit for share-based compensation | $ | 152 |  |  | $ | 95 |  |  | $ | 256 |  |  | $ | 176 |  |

[0000858877-22-000004:notes:253]
As of January 29, 2022, the total compensation cost related to unvested share-based awards not yet recognized was $4.4 billion which is expected to be recognized over approximately 2.8 years on a weighted-average basis.

[0000858877-22-000004:notes:254]
[same as prior period, unchanged from 0000858877-21-000018:notes:249]

[0000858877-22-000004:notes:255]
[same as prior period, unchanged from 0000858877-21-000018:notes:250]

[0000858877-22-000004:notes:256]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| Unvested balance at July 25, 2020 | 96 |  |  | $ | 42.03 |  |  |  |
| Granted and assumed | 51 |  |  | 41.89 |  |  |  |
| Vested | (39) |  |  | 39.63 |  |  | $ | 1,813 |  |
| Canceled/forfeited/other | (14) |  |  | 42.13 |  |  |  |
| Unvested balance at July 31, 2021 | 94 |  |  | 42.93 |  |  |  |
| Granted and assumed | 33 |  |  | 53.99 |  |  |  |
| Vested | (21) |  |  | 41.11 |  |  | $ | 1,183 |  |
| Canceled/forfeited/other | (7) |  |  | 44.62 |  |  |  |
| Unvested balance at January 29, 2022 | 99 |  |  | $ | 46.83 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-22-000004:notes:257]
Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first six months of fiscal 2022 and 2021 are summarized as follows (in millions):

[0000858877-22-000004:notes:258]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 31, 2021 | $ | 182 |  |  | $ | (1) |  |  | $ | (598) |  |  | $ | (417) |  |
| Other comprehensive income (loss) before reclassifications | (296) |  |  | 18 |  |  | (162) |  |  | (440) |  |
| (Gains) losses reclassified out of AOCI | (16) |  |  | (3) |  |  | 1 |  |  | (18) |  |
| Tax benefit (expense) | 80 |  |  | (3) |  |  | 9 |  |  | 86 |  |
| Balance at January 29, 2022 | $ | (50) |  |  | $ | 11 |  |  | $ | (750) |  |  | $ | (789) |  |

[0000858877-22-000004:notes:259]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 25, 2020 | $ | 315 |  |  | $ | (6) |  |  | $ | (828) |  |  | $ | (519) |  |
| Other comprehensive income (loss) before reclassifications | (35) |  |  | (5) |  |  | 345 |  |  | 305 |  |
| (Gains) losses reclassified out of AOCI | (24) |  |  | (5) |  |  | 2 |  |  | (27) |  |
| Tax benefit (expense) | 24 |  |  | 2 |  |  | (3) |  |  | 23 |  |
| Balance at January 23, 2021 | $ | 280 |  |  | $ | (14) |  |  | $ | (484) |  |  | $ | (218) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-22-000004:notes:260]
[same as prior period, unchanged from 0000858877-21-000018:notes:255]

[0000858877-22-000004:notes:261]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Income before provision for income taxes | $ | 3,603 |  |  | $ | 3,255 |  |  | $ | 7,260 |  |  | $ | 5,936 |  |
| Provision for income taxes | $ | 630 |  |  | $ | 710 |  |  | $ | 1,307 |  |  | $ | 1,217 |  |
| Effective tax rate | 17.5 | % |  | 21.8 | % |  | 18.0 | % |  | 20.5 | % |

[0000858877-22-000004:notes:262]
As of January 29, 2022, we had $3.1 billion of unrecognized tax benefits, of which $2.3 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-22-000004:notes:263]
[same as prior period, unchanged from 0000858877-21-000018:notes:258]

[0000858877-22-000004:notes:264]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-22-000004:notes:265]
Summarized financial information by segment for the second quarter and first six months of fiscal 2022 and 2021, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-22-000004:notes:266]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 7,146 |  |  | $ | 6,969 |  |  | $ | 14,706 |  |  | $ | 14,168 |  |
| EMEA | 3,564 |  |  | 3,207 |  |  | 6,867 |  |  | 6,171 |  |
| APJC | 2,010 |  |  | 1,784 |  |  | 4,046 |  |  | 3,551 |  |
| Total | $ | 12,720 |  |  | $ | 11,960 |  |  | $ | 25,620 |  |  | $ | 23,889 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,611 |  |  | $ | 4,705 |  |  | $ | 9,486 |  |  | $ | 9,552 |  |
| EMEA | 2,381 |  |  | 2,145 |  |  | 4,509 |  |  | 4,038 |  |
| APJC | 1,337 |  |  | 1,155 |  |  | 2,654 |  |  | 2,268 |  |
| Segment total | 8,328 |  |  | 8,005 |  |  | 16,649 |  |  | 15,858 |  |
| Unallocated corporate items | (279) |  |  | (221) |  |  | (547) |  |  | (493) |  |
| Total | $ | 8,049 |  |  | $ | 7,784 |  |  | $ | 16,102 |  |  | $ | 15,365 |  |

[0000858877-22-000004:notes:267]
[same as prior period, unchanged from 0000858877-21-000018:notes:262]

[0000858877-22-000004:notes:268]
Revenue in the United States was $6.4 billion and $6.2 billion for the second quarter of fiscal 2022 and 2021, respectively, and $13.2 billion and $12.7 billion for the first six months of fiscal 2022 and 2021, respectively.

[0000858877-22-000004:notes:269]
[same as prior period, unchanged from 0000858877-21-000018:notes:264]

[0000858877-22-000004:notes:270]
[same as prior period, unchanged from 0000858877-21-000018:notes:265]


## us-gaap:EarningsPerShareTextBlock

[0000858877-22-000004:notes:271]
[same as prior period, unchanged from 0000858877-21-000018:notes:266]

[0000858877-22-000004:notes:272]
|  | Three Months Ended |  | Six Months Ended |
|  | January 29,2022 |  | January 23,2021 |  | January 29,2022 |  | January 23,2021 |
| Net income | $ | 2,973 |  |  | $ | 2,545 |  |  | $ | 5,953 |  |  | $ | 4,719 |  |
| Weighted-average shares—basic | 4,183 |  |  | 4,223 |  |  | 4,201 |  |  | 4,227 |  |
| Effect of dilutive potential common shares | 22 |  |  | 11 |  |  | 21 |  |  | 12 |  |
| Weighted-average shares—diluted | 4,205 |  |  | 4,234 |  |  | 4,222 |  |  | 4,239 |  |
| Net income per share—basic | $ | 0.71 |  |  | $ | 0.60 |  |  | $ | 1.42 |  |  | $ | 1.12 |  |
| Net income per share—diluted | $ | 0.71 |  |  | $ | 0.60 |  |  | $ | 1.41 |  |  | $ | 1.11 |  |
| Antidilutive employee share-based awards, excluded | 11 |  |  | 49 |  |  | 41 |  |  | 56 |  |

[0000858877-22-000004:notes:273]
[same as prior period, unchanged from 0000858877-21-000018:notes:268]
