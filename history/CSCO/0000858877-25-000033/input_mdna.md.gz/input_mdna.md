# CSCO MD&A — 0000858877-25-000033


## mdna

[0000858877-25-000033:mdna:1]
[same as prior period, unchanged from 0000858877-25-000007:mdna:1]

[0000858877-25-000033:mdna:2]
[same as prior period, unchanged from 0000858877-25-000007:mdna:2]

[0000858877-25-000033:mdna:3]
[same as prior period, unchanged from 0000858877-25-000007:mdna:3]

[0000858877-25-000033:mdna:4]
[same as prior period, unchanged from 0000858877-25-000007:mdna:4]

[0000858877-25-000033:mdna:5]
[same as prior period, unchanged from 0000858877-25-000007:mdna:5]

[0000858877-25-000033:mdna:6]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | April 26,2025 |  | April 27,2024 |  | % Variance |  |  | April 26, 2025 |  | April 27, 2024 |  | % Variance |  |
| Revenue | $ | 14,149 |  |  | $ | 12,702 |  |  | 11 | % |  |  | $ | 41,981 |  |  | $ | 40,161 |  |  | 5 | % |  |
| Gross margin percentage | 65.6 | % |  | 65.1 | % |  | 0.5 |  | pts |  | 65.5 | % |  | 64.9 | % |  | 0.6 |  | pts |
| Research and development | $ | 2,335 |  |  | $ | 1,948 |  |  | 20 | % |  |  | $ | 6,920 |  |  | $ | 5,804 |  |  | 19 | % |  |
| Sales and marketing | $ | 2,724 |  |  | $ | 2,559 |  |  | 6 | % |  |  | $ | 8,148 |  |  | $ | 7,523 |  |  | 8 | % |  |
| General and administrative | $ | 739 |  |  | $ | 736 |  |  | — | % |  |  | $ | 2,286 |  |  | $ | 2,050 |  |  | 12 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 5,798 |  |  | $ | 5,243 |  |  | 11 | % |  |  | $ | 17,354 |  |  | $ | 15,377 |  |  | 13 | % |  |
| Total as a percentage of revenue | 41.0 | % |  | 41.3 | % |  | (0.3) |  | pts |  | 41.3 | % |  | 38.3 | % |  | 3.0 |  | pts |
| Restructuring and other charges included in operating expenses | $ | 34 |  |  | $ | 542 |  |  | (94) | % |  |  | $ | 709 |  |  | $ | 677 |  |  | 5 | % |  |
| Operating income as a percentage of revenue | 22.6 | % |  | 17.2 | % |  | 5.4 |  | pts |  | 20.7 | % |  | 23.8 | % |  | (3.1) |  | pts |
| Interest and other income (loss), net | $ | (255) |  |  | $ | 44 |  |  | NM |  |  | $ | (572) |  |  | $ | 275 |  |  | NM |  |
| Income tax percentage | 15.5 | % |  | 15.6 | % |  | (0.1) |  | pts |  | 5.8 | % |  | 17.1 | % |  | (11.3) |  | pts |
| Net income | $ | 2,491 |  |  | $ | 1,886 |  |  | 32 | % |  |  | $ | 7,630 |  |  | $ | 8,158 |  |  | (6) | % |  |
| Net income as a percentage of revenue | 17.6 | % |  | 14.8 | % |  | 2.8 |  | pts |  | 18.2 | % |  | 20.3 | % |  | (2.1) |  | pts |
| Earnings per share—diluted | $ | 0.62 |  |  | $ | 0.46 |  |  | 35 | % |  |  | $ | 1.91 |  |  | $ | 2.00 |  |  | (5) | % |  |

[0000858877-25-000033:mdna:7]
[same as prior period, unchanged from 0000858877-25-000007:mdna:7]

[0000858877-25-000033:mdna:8]
[same as prior period, unchanged from 0000858877-25-000007:mdna:8]

[0000858877-25-000033:mdna:9]
[same as prior period, unchanged from 0000858877-25-000007:mdna:16]

[0000858877-25-000033:mdna:10]
[same as prior period, unchanged from 0000858877-25-000007:mdna:9]

[0000858877-25-000033:mdna:11]
[same as prior period, unchanged from 0000858877-25-000007:mdna:10]

[0000858877-25-000033:mdna:12]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:13]
In the third quarter of fiscal 2025, we delivered strong revenue growth across all geographies and solid margins as we saw a positive demand environment. Total revenue increased by 11% compared with the third quarter of fiscal 2024. Our results for the third quarter of fiscal 2025 include a full quarter of Splunk's results compared to six weeks for the third quarter of fiscal 2024. Within total revenue, product revenue increased by 15% and services revenue increased by 3%. In the third quarter of fiscal 2025, total software revenue was $5.6 billion across all product areas and services, an increase of 25%, primarily driven by the contribution of Splunk. Total subscription revenue increased 15%, primarily driven by the contribution of Splunk.

[0000858877-25-000033:mdna:14]
Total gross margin increased by 0.5 percentage points. Product gross margin increased by 0.9 percentage points, primarily driven by benefits from productivity improvements and Splunk, partially offset by pricing erosion. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 0.3 percentage points. Operating income as a percentage of revenue increased by 5.4 percentage points primarily driven by lower restructuring and other charges and the gross margin improvement in the third quarter of fiscal 2025. Diluted earnings per share increased 35%, driven by an increase of 32% in net income and a decrease in diluted share count of 58 million shares.

[0000858877-25-000033:mdna:15]
In terms of our geographic segments, revenue from the Americas increased by $1.0 billion, EMEA revenue increased by $278 million and APJC revenue increased by $161 million. From a customer market standpoint, we experienced product revenue growth across all of our customer markets. From a product category perspective, the product revenue increase of 15% was driven by growth in Networking of 8%, Security of 54%, Observability of 24% and Collaboration of 4%. The product revenue growth in Security and Observability were each driven in large part by the contribution of Splunk.

[0000858877-25-000033:mdna:16]
We continue to operate in a highly competitive environment and the overall macroeconomic environment remains challenging and uncertain, especially with respect to tariffs and trade policy. Despite this uncertainty, we plan to continue to invest in key priority areas with the objective of driving profitable growth over the long term. We remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformations and on accelerating innovation across our portfolio. We believe that we are making progress on our strategic priorities.

[0000858877-25-000033:mdna:17]
[same as prior period, unchanged from 0000858877-25-000007:mdna:17]

[0000858877-25-000033:mdna:18]
[same as prior period, unchanged from 0000858877-25-000007:mdna:18]

[0000858877-25-000033:mdna:19]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:20]
Total revenue increased 5%, with product revenue and service revenue each increasing by 5%, driven by Splunk. Total gross margin increased 0.6 percentage points due to benefits from Splunk, productivity improvements, and favorable product mix, partially offset by pricing erosion. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 3.0 percentage points. Operating income as a percentage of revenue decreased by 3.1 percentage points primarily due to increases in cash compensation expenses from acquisitions, amortization of purchased intangible assets, and share-based compensation expense in the first nine months of fiscal 2025. Diluted earnings per share decreased 5%, driven by a decrease of 6% in net income, partially offset by a decrease in diluted share count of 67 million shares.

[0000858877-25-000033:mdna:21]
[same as prior period, unchanged from 0000858877-25-000007:mdna:21]

[0000858877-25-000033:mdna:22]
[same as prior period, unchanged from 0000858877-25-000007:mdna:22]

[0000858877-25-000033:mdna:23]
[same as prior period, unchanged from 0000858877-25-000007:mdna:23]

[0000858877-25-000033:mdna:24]
[same as prior period, unchanged from 0000858877-25-000007:mdna:24]

[0000858877-25-000033:mdna:25]
The following is a summary of our other key financial measures for the third quarter of fiscal 2025 (in millions):

[0000858877-25-000033:mdna:26]
|  |  | April 26,2025 |  | July 27,2024 |
| Cash and cash equivalents and investments |  | $ | 15,642 |  |  | $ | 17,854 |  |
| Remaining performance obligations |  | $ | 41,667 |  |  | $ | 41,048 |  |
| Inventories |  | $ | 2,832 |  |  | $ | 3,373 |  |
| Total debt |  | $ | 29,279 |  |  | $ | 30,962 |  |

[0000858877-25-000033:mdna:27]
|  |  | Nine Months Ended |
|  |  | April 26,2025 |  | April 27,2024 |
| Cash provided by operating activities |  | $ | 9,959 |  |  | $ | 7,150 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 4,743 |  |  | $ | 3,762 |  |
| Dividends paid |  | $ | 4,812 |  |  | $ | 4,778 |  |

[0000858877-25-000033:mdna:28]
[same as prior period, unchanged from 0000858877-25-000007:mdna:28]

[0000858877-25-000033:mdna:29]
[same as prior period, unchanged from 0000858877-25-000007:mdna:29]

[0000858877-25-000033:mdna:30]
[same as prior period, unchanged from 0000858877-25-000007:mdna:30]

[0000858877-25-000033:mdna:31]
[same as prior period, unchanged from 0000858877-25-000007:mdna:31]

[0000858877-25-000033:mdna:32]
[same as prior period, unchanged from 0000858877-25-000007:mdna:32]

[0000858877-25-000033:mdna:33]
[same as prior period, unchanged from 0000858877-25-000007:mdna:33]

[0000858877-25-000033:mdna:34]
[same as prior period, unchanged from 0000858877-25-000007:mdna:34]

[0000858877-25-000033:mdna:35]
[same as prior period, unchanged from 0000858877-25-000007:mdna:35]

[0000858877-25-000033:mdna:36]
[same as prior period, unchanged from 0000858877-25-000007:mdna:36]

[0000858877-25-000033:mdna:37]
[same as prior period, unchanged from 0000858877-25-000007:mdna:37]

[0000858877-25-000033:mdna:38]
[same as prior period, unchanged from 0000858877-25-000007:mdna:38]

[0000858877-25-000033:mdna:39]
[same as prior period, unchanged from 0000858877-25-000007:mdna:39]

[0000858877-25-000033:mdna:40]
[same as prior period, unchanged from 0000858877-25-000007:mdna:55]

[0000858877-25-000033:mdna:41]
[same as prior period, unchanged from 0000858877-25-000007:mdna:41]

[0000858877-25-000033:mdna:42]
[same as prior period, unchanged from 0000858877-25-000007:mdna:42]

[0000858877-25-000033:mdna:43]
[same as prior period, unchanged from 0000858877-25-000007:mdna:43]

[0000858877-25-000033:mdna:44]
Our provision for inventory was $593 million and $348 million for the first nine months of fiscal 2025 and 2024, respectively. The provision/benefit from the liability related to purchase commitments with contract manufacturers and suppliers was a benefit of $134 million and a provision of $213 million for the first nine months of fiscal 2025 and 2024, respectively. If there were to be a sudden and significant decrease in demand for our products, if there were a higher incidence of inventory obsolescence because of rapidly changing technology or customer requirements, or if supply constraints were to continue, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. For further discussion around the supply chain impacts and risks, see “—Results of Operations—Gross Margin—Supply Chain Impacts and Risks” and “—Liquidity and Capital Resources—Inventory Supply Chain.”

[0000858877-25-000033:mdna:45]
Loss Contingencies

[0000858877-25-000033:mdna:46]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-25-000033:mdna:47]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-25-000033:mdna:48]
[same as prior period, unchanged from 0000858877-25-000007:mdna:48]

[0000858877-25-000033:mdna:49]
[same as prior period, unchanged from 0000858877-25-000007:mdna:49]

[0000858877-25-000033:mdna:50]
[same as prior period, unchanged from 0000858877-25-000007:mdna:50]

[0000858877-25-000033:mdna:51]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first nine months of fiscal 2025 and 2024.

[0000858877-25-000033:mdna:52]
[same as prior period, unchanged from 0000858877-25-000007:mdna:52]

[0000858877-25-000033:mdna:53]
[same as prior period, unchanged from 0000858877-25-000007:mdna:53]

[0000858877-25-000033:mdna:54]
[same as prior period, unchanged from 0000858877-25-000007:mdna:54]

[0000858877-25-000033:mdna:55]
44

[0000858877-25-000033:mdna:56]
[same as prior period, unchanged from 0000858877-25-000007:mdna:56]

[0000858877-25-000033:mdna:57]
[same as prior period, unchanged from 0000858877-25-000007:mdna:57]

[0000858877-25-000033:mdna:58]
[same as prior period, unchanged from 0000858877-25-000007:mdna:58]

[0000858877-25-000033:mdna:59]
[same as prior period, unchanged from 0000858877-25-000007:mdna:59]

[0000858877-25-000033:mdna:60]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was 15.5% and 15.6% in the third quarter of fiscal 2025 and 2024, respectively and 5.8% and 17.1% in the first nine months of fiscal 2025 and 2024, respectively.

[0000858877-25-000033:mdna:61]
[same as prior period, unchanged from 0000858877-25-000007:mdna:61]

[0000858877-25-000033:mdna:62]
[same as prior period, unchanged from 0000858877-25-000007:mdna:62]

[0000858877-25-000033:mdna:63]
[same as prior period, unchanged from 0000858877-25-000007:mdna:63]

[0000858877-25-000033:mdna:64]
[same as prior period, unchanged from 0000858877-25-000007:mdna:64]

[0000858877-25-000033:mdna:65]
[same as prior period, unchanged from 0000858877-25-000007:mdna:65]

[0000858877-25-000033:mdna:66]
[same as prior period, unchanged from 0000858877-25-000007:mdna:66]

[0000858877-25-000033:mdna:67]
[same as prior period, unchanged from 0000858877-25-000007:mdna:67]

[0000858877-25-000033:mdna:68]
[same as prior period, unchanged from 0000858877-25-000007:mdna:68]

[0000858877-25-000033:mdna:69]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 26,2025 |  | April 27,2024 |  | Variancein Dollars |  | Variance in Percent |  | April 26, 2025 |  | April 27, 2024 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 10,374 |  |  | $ | 9,024 |  |  | $ | 1,350 |  |  | 15 | % |  | $ | 30,722 |  |  | $ | 29,395 |  |  | $ | 1,327 |  |  | 5 | % |
| Percentage of revenue |  | 73.3 | % |  | 71.0 | % |  |  |  |  |  | 73.2 | % |  | 73.2 | % |  |  |  |  |
| Services |  | 3,775 |  |  | 3,678 |  |  | 97 |  |  | 3 | % |  | 11,259 |  |  | 10,766 |  |  | 493 |  |  | 5 | % |
| Percentage of revenue |  | 26.7 | % |  | 29.0 | % |  |  |  |  |  | 26.8 | % |  | 26.8 | % |  |  |  |  |
| Total |  | $ | 14,149 |  |  | $ | 12,702 |  |  | $ | 1,447 |  |  | 11 | % |  | $ | 41,981 |  |  | $ | 40,161 |  |  | $ | 1,820 |  |  | 5 | % |

[0000858877-25-000033:mdna:70]
[same as prior period, unchanged from 0000858877-25-000007:mdna:70]

[0000858877-25-000033:mdna:71]
[same as prior period, unchanged from 0000858877-25-000007:mdna:72]

[0000858877-25-000033:mdna:72]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 26,2025 |  | April 27,2024 |  | Variancein Dollars |  | Variance in Percent |  | April 26,2025 |  | April 27,2024 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 8,380 |  |  | $ | 7,372 |  |  | $ | 1,008 |  |  | 14 | % |  | $ | 24,834 |  |  | $ | 23,904 |  |  | $ | 930 |  |  | 4 | % |
| Percentage of revenue |  | 59.2 | % |  | 58.1 | % |  |  |  |  |  | 59.2 | % |  | 59.5 | % |  |  |  |  |
| EMEA |  | 3,736 |  |  | 3,458 |  |  | 278 |  |  | 8 | % |  | 11,179 |  |  | 10,606 |  |  | 573 |  |  | 5 | % |
| Percentage of revenue |  | 26.4 | % |  | 27.2 | % |  |  |  |  |  | 26.6 | % |  | 26.4 | % |  |  |  |  |
| APJC |  | 2,034 |  |  | 1,873 |  |  | 161 |  |  | 9 | % |  | 5,968 |  |  | 5,652 |  |  | 316 |  |  | 6 | % |
| Percentage of revenue |  | 14.4 | % |  | 14.7 | % |  |  |  |  |  | 14.2 | % |  | 14.1 | % |  |  |  |  |
| Total |  | $ | 14,149 |  |  | $ | 12,702 |  |  | $ | 1,447 |  |  | 11 | % |  | $ | 41,981 |  |  | $ | 40,161 |  |  | $ | 1,820 |  |  | 5 | % |

[0000858877-25-000033:mdna:73]
[same as prior period, unchanged from 0000858877-25-000007:mdna:74]

[0000858877-25-000033:mdna:74]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:75]
Total revenue increased by 11%. Product revenue increased by 15% and services revenue increased by 3%. Our total revenue reflected growth across each of our geographic segments.

[0000858877-25-000033:mdna:76]
[same as prior period, unchanged from 0000858877-25-000007:mdna:77]

[0000858877-25-000033:mdna:77]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:78]
Total revenue increased by 5%, with product and services revenue each increasing by 5%, driven by Splunk. Our total revenue reflected growth across each of our geographic segments.

[0000858877-25-000033:mdna:79]
[same as prior period, unchanged from 0000858877-25-000007:mdna:81]

[0000858877-25-000033:mdna:80]
[same as prior period, unchanged from 0000858877-25-000007:mdna:82]

[0000858877-25-000033:mdna:81]
[same as prior period, unchanged from 0000858877-25-000007:mdna:83]

[0000858877-25-000033:mdna:82]
[same as prior period, unchanged from 0000858877-25-000007:mdna:84]

[0000858877-25-000033:mdna:83]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 26,2025 |  | April 27,2024 |  | Variancein Dollars |  | Variance in Percent |  | April 26,2025 |  | April 27,2024 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 6,125 |  |  | $ | 5,155 |  |  | $ | 970 |  |  | 19 | % |  | $ | 18,075 |  |  | $ | 17,352 |  |  | $ | 723 |  |  | 4 | % |
| Percentage of product revenue |  | 59.1 | % |  | 57.1 | % |  |  |  |  |  | 58.8 | % |  | 59.0 | % |  |  |  |  |
| EMEA |  | 2,805 |  |  | 2,580 |  |  | 225 |  |  | 9 | % |  | 8,417 |  |  | 8,058 |  |  | 359 |  |  | 4 | % |
| Percentage of product revenue |  | 27.0 | % |  | 28.6 | % |  |  |  |  |  | 27.4 | % |  | 27.4 | % |  |  |  |  |
| APJC |  | 1,444 |  |  | 1,289 |  |  | 155 |  |  | 12 | % |  | 4,230 |  |  | 3,985 |  |  | 245 |  |  | 6 | % |
| Percentage of product revenue |  | 13.9 | % |  | 14.3 | % |  |  |  |  |  | 13.8 | % |  | 13.6 | % |  |  |  |  |
| Total |  | $ | 10,374 |  |  | $ | 9,024 |  |  | $ | 1,350 |  |  | 15 | % |  | $ | 30,722 |  |  | $ | 29,395 |  |  | $ | 1,327 |  |  | 5 | % |

[0000858877-25-000033:mdna:84]
[same as prior period, unchanged from 0000858877-25-000007:mdna:86]

[0000858877-25-000033:mdna:85]
[same as prior period, unchanged from 0000858877-25-000007:mdna:87]

[0000858877-25-000033:mdna:86]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:87]
Product revenue in the Americas segment increased by 19%, with growth across each of our customer markets. From a country perspective, product revenue increased in the United States, Brazil, and Canada by 21%, 13%, and 1%, respectively, partially offset by a decline in Mexico of 7%.

[0000858877-25-000033:mdna:88]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:89]
Product revenue in the Americas segment increased by 4%, with growth in the enterprise market, partially offset by declines in the public sector and service provider and cloud markets. From a country perspective, product revenue increased in the United States, Canada, and Brazil by 5%, 4%, and 9%, respectively, partially offset by a decline in product revenue in Mexico of 17%.

[0000858877-25-000033:mdna:90]
[same as prior period, unchanged from 0000858877-25-000007:mdna:92]

[0000858877-25-000033:mdna:91]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:92]
Product revenue in the EMEA segment increased by 9%, with growth in the enterprise and public sector markets, partially offset by a decline in the service provider and cloud market. From a country perspective, product revenue increased in Saudi Arabia, the United Kingdom and Germany by 20%,  9% and 5%, respectively.

[0000858877-25-000033:mdna:93]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:94]
Product revenue in the EMEA segment increased by 4%, driven by growth in the public sector and enterprise markets, partially offset by a decline in the service provider and cloud market. From a country perspective, product revenue increased in the United Kingdom, France, and Germany by 10%, 7%, and 5%, respectively.

[0000858877-25-000033:mdna:95]
[same as prior period, unchanged from 0000858877-25-000007:mdna:97]

[0000858877-25-000033:mdna:96]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:97]
Product revenue in the APJC segment increased by 12%, with growth in the enterprise and service provider and cloud markets, partially offset by a slight decline in the public sector market. From a country perspective, product revenue increased in Japan, Australia, India and China by 9%, 24%, 2%, and 9%, respectively.

[0000858877-25-000033:mdna:98]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:99]
Product revenue in the APJC segment increased by 6%, with growth across each of our customer markets. From a country perspective, product revenue increased in Japan, Australia, India and China by 12%, 19%, 4%, and 8%, respectively.

[0000858877-25-000033:mdna:100]
[same as prior period, unchanged from 0000858877-25-000007:mdna:102]

[0000858877-25-000033:mdna:101]
[same as prior period, unchanged from 0000858877-25-000007:mdna:103]

[0000858877-25-000033:mdna:102]
[same as prior period, unchanged from 0000858877-25-000007:mdna:104]

[0000858877-25-000033:mdna:103]
[same as prior period, unchanged from 0000858877-25-000007:mdna:105]

[0000858877-25-000033:mdna:104]
[same as prior period, unchanged from 0000858877-25-000007:mdna:106]

[0000858877-25-000033:mdna:105]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 26,2025 |  | April 27,2024 |  | Variancein Dollars |  | Variance in Percent |  | April 26,2025 |  | April 27,2024 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking |  | $ | 7,068 |  |  | $ | 6,522 |  |  | $ | 546 |  |  | 8 | % |  | $ | 20,671 |  |  | $ | 22,425 |  |  | $ | (1,754) |  |  | (8) | % |
| Security |  | 2,013 |  |  | 1,304 |  |  | 709 |  |  | 54 | % |  | 6,142 |  |  | 3,288 |  |  | 2,854 |  |  | 87 | % |
| Collaboration |  | 1,031 |  |  | 987 |  |  | 44 |  |  | 4 | % |  | 3,112 |  |  | 3,093 |  |  | 19 |  |  | 1 | % |
| Observability |  | 261 |  |  | 211 |  |  | 50 |  |  | 24 | % |  | 796 |  |  | 589 |  |  | 207 |  |  | 35 | % |
| Total |  | $ | 10,374 |  |  | $ | 9,024 |  |  | $ | 1,350 |  |  | 15 | % |  | $ | 30,722 |  |  | $ | 29,395 |  |  | $ | 1,327 |  |  | 5 | % |

[0000858877-25-000033:mdna:106]
[same as prior period, unchanged from 0000858877-25-000007:mdna:108]

[0000858877-25-000033:mdna:107]
[same as prior period, unchanged from 0000858877-25-000007:mdna:109]

[0000858877-25-000033:mdna:108]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:109]
The Networking product category consists of our core networking technologies of switching, routing, wireless, and servers. Revenue from the Networking product category increased by 8%, or $546 million. We experienced double digit revenue growth in Switching and Enterprise Routing. We also experienced revenue growth in Internet Infrastructure and Wireless, partially offset by a revenue decline in Servers.

[0000858877-25-000033:mdna:110]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:111]
Revenue from the Networking product category decreased by 8%, or $1.8 billion. Revenue declined in Switching, as a result of a decline in campus switching, primarily driven by a decline in our Catalyst 9000 series offerings. We also experienced revenue declines in Servers, Internet Infrastructure, Enterprise Routing, and Wireless.

[0000858877-25-000033:mdna:112]
[same as prior period, unchanged from 0000858877-25-000007:mdna:114]

[0000858877-25-000033:mdna:113]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:114]
The Security product category consists of our Network Security, Identity and Access Management, SASE and Threat Intelligence, Detection, and Response offerings. Revenue in our Security product category increased by 54%, or $709 million, primarily driven by Threat Intelligence, Detection, and Response offerings, which includes the offerings from Splunk, and growth in our SASE offerings.

[0000858877-25-000033:mdna:115]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:116]
Revenue from the Security product category increased by 87%, or $2.9 billion, primarily driven by Threat Intelligence, Detection, and Response offerings, which includes the offerings from Splunk, and to a lesser extent, growth in our SASE and Network Security offerings.

[0000858877-25-000033:mdna:117]
[same as prior period, unchanged from 0000858877-25-000007:mdna:119]

[0000858877-25-000033:mdna:118]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:119]
The Collaboration product category consists of our Webex Suite, Collaboration Devices, Contact Center and CPaaS offerings. Revenue in our Collaboration product category increased by 4%, or $44 million, primarily driven by growth in our Collaboration Devices, CPaaS, and Webex Suite offerings.

[0000858877-25-000033:mdna:120]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:121]
Revenue from our Collaboration product category increased by 1%, or $19 million, primarily driven by revenue growth in our Collaboration Devices, CPaaS and Contact Center offerings, partially offset by a decline in our Webex Suite offerings.

[0000858877-25-000033:mdna:122]
[same as prior period, unchanged from 0000858877-25-000007:mdna:125]

[0000858877-25-000033:mdna:123]
[same as prior period, unchanged from 0000858877-25-000007:mdna:126]

[0000858877-25-000033:mdna:124]
[same as prior period, unchanged from 0000858877-25-000007:mdna:127]

[0000858877-25-000033:mdna:125]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:126]
The Observability product category consists of our network assurance, monitoring and analytics and observability suite offerings. Revenue in our Observability product category increased 24%, or $50 million, primarily driven by our Observability Suite offerings from Splunk and growth in our ThousandEyes network services offerings, partially offset by a decline in monitoring and analytics.

[0000858877-25-000033:mdna:127]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:128]
Revenue from the Observability product category increased by 35%, or $207 million, driven by primarily by our Observability Suite offerings from Splunk and growth in our ThousandEyes network services offerings, partially offset by a decline in monitoring and analytics.

[0000858877-25-000033:mdna:129]
[same as prior period, unchanged from 0000858877-25-000007:mdna:132]

[0000858877-25-000033:mdna:130]
[same as prior period, unchanged from 0000858877-25-000007:mdna:133]

[0000858877-25-000033:mdna:131]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 26,2025 |  | April 27,2024 |  | Variancein Dollars |  | Variance in Percent |  | April 26,2025 |  | April 27,2024 |  | Variance in Dollars |  | Variance in Percent |
| Services revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,254 |  |  | $ | 2,217 |  |  | $ | 37 |  |  | 2 | % |  | $ | 6,759 |  |  | $ | 6,552 |  |  | $ | 207 |  |  | 3 | % |
| Percentage of service revenue |  | 59.7 | % |  | 60.3 | % |  |  |  |  |  | 60.0 | % |  | 60.9 | % |  |  |  |  |
| EMEA |  | 931 |  |  | 878 |  |  | 53 |  |  | 6 | % |  | 2,762 |  |  | 2,548 |  |  | 214 |  |  | 8 | % |
| Percentage of service revenue |  | 24.7 | % |  | 23.9 | % |  |  |  |  |  | 24.5 | % |  | 23.7 | % |  |  |  |  |
| APJC |  | 590 |  |  | 584 |  |  | 6 |  |  | 1 | % |  | 1,738 |  |  | 1,667 |  |  | 71 |  |  | 4 | % |
| Percentage of service revenue |  | 15.6 | % |  | 15.8 | % |  |  |  |  |  | 15.5 | % |  | 15.4 | % |  |  |  |  |
| Total |  | $ | 3,775 |  |  | $ | 3,678 |  |  | $ | 97 |  |  | 3 | % |  | $ | 11,259 |  |  | $ | 10,766 |  |  | $ | 493 |  |  | 5 | % |

[0000858877-25-000033:mdna:132]
[same as prior period, unchanged from 0000858877-25-000007:mdna:135]

[0000858877-25-000033:mdna:133]
Services revenue increased 3% in the third quarter of fiscal 2025 compared with the third quarter of fiscal 2024, primarily driven by Splunk. Services revenue increased across all of our geographic segments for the third quarter of fiscal 2025.

[0000858877-25-000033:mdna:134]
Services revenue increased 5% in the first nine months of fiscal 2025 compared to the first nine months of fiscal 2024, primarily driven by Splunk and revenue growth in our solution support offerings, network support offerings and advisory services. Services revenue increased across each of our geographic segments.

[0000858877-25-000033:mdna:135]
[same as prior period, unchanged from 0000858877-25-000007:mdna:138]

[0000858877-25-000033:mdna:136]
[same as prior period, unchanged from 0000858877-25-000007:mdna:139]

[0000858877-25-000033:mdna:137]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 6,686 |  |  | $ | 5,729 |  |  | 64.4 | % |  | 63.5 | % |  | $ | 19,795 |  |  | $ | 18,700 |  |  | 64.4 | % |  | 63.6 | % |
| Services |  | 2,592 |  |  | 2,544 |  |  | 68.7 | % |  | 69.2 | % |  | 7,715 |  |  | 7,347 |  |  | 68.5 | % |  | 68.2 | % |
| Total |  | $ | 9,278 |  |  | $ | 8,273 |  |  | 65.6 | % |  | 65.1 | % |  | $ | 27,510 |  |  | $ | 26,047 |  |  | 65.5 | % |  | 64.9 | % |

[0000858877-25-000033:mdna:138]
[same as prior period, unchanged from 0000858877-25-000007:mdna:141]

[0000858877-25-000033:mdna:139]
[same as prior period, unchanged from 0000858877-25-000007:mdna:142]

[0000858877-25-000033:mdna:140]
[same as prior period, unchanged from 0000858877-25-000007:mdna:143]

[0000858877-25-000033:mdna:141]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the third quarter and first nine months of fiscal 2025, as compared with the corresponding prior year periods:

[0000858877-25-000033:mdna:142]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Nine Months Ended |
| Fiscal 2024 |  | 63.5 | % |  | 63.6 | % |
| Productivity (1) |  | 1.5 | % |  | 1.2 | % |
| Product pricing |  | (1.3) | % |  | (1.6) | % |
| Mix of products sold |  | 0.5 | % |  | 2.2 | % |
| Amortization of purchased intangible assets |  | 0.2 | % |  | (0.9) | % |
| Others |  | — | % |  | (0.1) | % |
| Fiscal 2025 |  | 64.4 | % |  | 64.4 | % |

[0000858877-25-000033:mdna:143]
[same as prior period, unchanged from 0000858877-25-000007:mdna:146]

[0000858877-25-000033:mdna:144]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:145]
Product gross margin increased by 0.9 percentage points primarily driven by benefits from productivity improvements and Splunk, partially offset by negative impacts from pricing.

[0000858877-25-000033:mdna:146]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:147]
Product gross margin increased by 0.8 percentage points primarily driven by benefits from Splunk, productivity improvements, and favorable product mix, partially offset by negative impacts from pricing and the amortization of purchased intangible assets primarily related to Splunk.

[0000858877-25-000033:mdna:148]
[same as prior period, unchanged from 0000858877-25-000007:mdna:151]

[0000858877-25-000033:mdna:149]
In past periods, we took multiple actions in order to mitigate component shortages and address significant supply constraints. These supply constraints resulted in the need to secure long-term supply and increased inventory supply chain balances compared to historical levels. This in turn has significantly increased our supply chain exposure, which has resulted in negative impacts to our product gross margin in recent periods and may result in further negative impacts in future periods. This exposure includes potential material excess and obsolete or other charges if product demand significantly decreases for a sustained duration, we are unable to generate demand for certain products planned for development, or we are unable to mitigate the remaining supply chain exposures. Additionally, while we are exposed to new and proposed tariffs and other trade policies, the extent of such exposure is uncertain but could be significant if the exposure remains and we are unable to mitigate it.

[0000858877-25-000033:mdna:150]
[same as prior period, unchanged from 0000858877-25-000007:mdna:153]

[0000858877-25-000033:mdna:151]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:152]
Our services gross margin percentage decreased by 0.5 percentage points primarily due to higher headcount-related costs, partially offset by increased volume and lower delivery costs.

[0000858877-25-000033:mdna:153]
[same as prior period, unchanged from 0000858877-25-000007:mdna:156]

[0000858877-25-000033:mdna:154]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:155]
Services gross margin percentage increased by 0.3 percentage points primarily due to higher sales volume and lower delivery costs, partially offset by higher headcount-related costs and an unfavorable mix of service offerings.

[0000858877-25-000033:mdna:156]
50

[0000858877-25-000033:mdna:157]
[same as prior period, unchanged from 0000858877-25-000007:mdna:159]

[0000858877-25-000033:mdna:158]
[same as prior period, unchanged from 0000858877-25-000007:mdna:160]

[0000858877-25-000033:mdna:159]
[same as prior period, unchanged from 0000858877-25-000007:mdna:161]

[0000858877-25-000033:mdna:160]
[same as prior period, unchanged from 0000858877-25-000007:mdna:162]

[0000858877-25-000033:mdna:161]
|  | Three Months Ended |  | Nine Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 5,676 |  |  | $ | 5,006 |  |  | 67.7 | % |  | 67.9 | % |  | $ | 16,960 |  |  | $ | 15,906 |  |  | 68.3 | % |  | 66.5 | % |
| EMEA | 2,659 |  |  | 2,406 |  |  | 71.2 | % |  | 69.6 | % |  | 7,931 |  |  | 7,324 |  |  | 70.9 | % |  | 69.1 | % |
| APJC | 1,367 |  |  | 1,262 |  |  | 67.2 | % |  | 67.4 | % |  | 4,016 |  |  | 3,816 |  |  | 67.3 | % |  | 67.5 | % |
| Segment total | 9,703 |  |  | 8,673 |  |  | 68.6 | % |  | 68.3 | % |  | 28,907 |  |  | 27,046 |  |  | 68.9 | % |  | 67.3 | % |
| Unallocated corporate items (1) | (425) |  |  | (400) |  |  |  |  |  |  | (1,397) |  |  | (999) |  |  |  |  |  |
| Total | $ | 9,278 |  |  | $ | 8,273 |  |  | 65.6 | % |  | 65.1 | % |  | $ | 27,510 |  |  | $ | 26,047 |  |  | 65.5 | % |  | 64.9 | % |

[0000858877-25-000033:mdna:162]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-25-000033:mdna:163]
[same as prior period, unchanged from 0000858877-25-000007:mdna:165]

[0000858877-25-000033:mdna:164]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:165]
We experienced a slight gross margin percentage decrease in our Americas segment due to pricing erosion and unfavorable product mix, partially offset by positive impacts from productivity improvements.

[0000858877-25-000033:mdna:166]
Gross margin percentage in our EMEA segment increased primarily due to productivity improvements and favorable product mix, partially offset by pricing erosion.

[0000858877-25-000033:mdna:167]
The slight decrease in the APJC segment gross margin percentage was primarily due to pricing erosion and lower services gross margin,  partially offset by positive impacts from favorable product mix and productivity improvements.

[0000858877-25-000033:mdna:168]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:169]
The Americas segment had a gross margin percentage increase driven by positive impacts from productivity improvements and favorable product mix, partially offset by pricing erosion.

[0000858877-25-000033:mdna:170]
The gross margin percentage increase in our EMEA segment was primarily due to positive impacts from favorable product mix and productivity improvements, partially offset by pricing erosion.

[0000858877-25-000033:mdna:171]
The APJC segment had a slight gross margin percentage decrease driven primarily by pricing erosion and lower services gross margin, partially offset by positive impacts from productivity improvements and favorable product mix.

[0000858877-25-000033:mdna:172]
[same as prior period, unchanged from 0000858877-25-000007:mdna:174]

[0000858877-25-000033:mdna:173]
[same as prior period, unchanged from 0000858877-25-000007:mdna:175]

[0000858877-25-000033:mdna:174]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |  | Variancein Dollars |  | Variance in Percent |  | April 26,2025 |  | April 27,2024 |  | Variance in Dollars |  | Variance in Percent |
| Research and development | $ | 2,335 |  |  | $ | 1,948 |  |  | $ | 387 |  |  | 20 | % |  | $ | 6,920 |  |  | $ | 5,804 |  |  | $ | 1,116 |  |  | 19 | % |
| Percentage of revenue | 16.5 | % |  | 15.3 | % |  |  |  |  |  | 16.5 | % |  | 14.5 | % |  |  |  |  |
| Sales and marketing | 2,724 |  |  | 2,559 |  |  | 165 |  |  | 6 | % |  | 8,148 |  |  | 7,523 |  |  | 625 |  |  | 8 | % |
| Percentage of revenue | 19.3 | % |  | 20.1 | % |  |  |  |  |  | 19.4 | % |  | 18.7 | % |  |  |  |  |
| General and administrative | 739 |  |  | 736 |  |  | 3 |  |  | — | % |  | 2,286 |  |  | 2,050 |  |  | 236 |  |  | 12 | % |
| Percentage of revenue | 5.2 | % |  | 5.8 | % |  |  |  |  |  | 5.4 | % |  | 5.1 | % |  |  |  |  |
| Total | $ | 5,798 |  |  | $ | 5,243 |  |  | $ | 555 |  |  | 11 | % |  | $ | 17,354 |  |  | $ | 15,377 |  |  | $ | 1,977 |  |  | 13 | % |
| Percentage of revenue | 41.0 | % |  | 41.3 | % |  |  |  |  |  | 41.3 | % |  | 38.3 | % |  |  |  |  |

[0000858877-25-000033:mdna:175]
[same as prior period, unchanged from 0000858877-25-000007:mdna:177]

[0000858877-25-000033:mdna:176]
[same as prior period, unchanged from 0000858877-25-000007:mdna:178]

[0000858877-25-000033:mdna:177]
[same as prior period, unchanged from 0000858877-25-000007:mdna:179]

[0000858877-25-000033:mdna:178]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:179]
R&D expenses increased primarily due to higher headcount-related expenses, higher share-based compensation expense, and higher cash compensation expenses from acquisitions.

[0000858877-25-000033:mdna:180]
[same as prior period, unchanged from 0000858877-25-000007:mdna:182]

[0000858877-25-000033:mdna:181]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:182]
R&D expenses increased primarily due to higher headcount-related expenses, higher cash compensation expenses from acquisitions, higher share-based compensation expense and higher discretionary spending.

[0000858877-25-000033:mdna:183]
[same as prior period, unchanged from 0000858877-25-000007:mdna:185]

[0000858877-25-000033:mdna:184]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:185]
Sales and marketing expenses increased primarily due to higher headcount-related expenses, higher discretionary spending, and higher cash compensation expenses from acquisitions, partially offset by lower contracted services spending.

[0000858877-25-000033:mdna:186]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:187]
Sales and marketing expenses increased primarily due to higher headcount-related expenses, higher cash compensation expenses from acquisitions, higher discretionary spending, and higher share-based compensation expense, partially offset by lower contracted services spending.

[0000858877-25-000033:mdna:188]
[same as prior period, unchanged from 0000858877-25-000007:mdna:190]

[0000858877-25-000033:mdna:189]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:190]
G&A expenses were flat primarily due to higher headcount-related expenses, higher discretionary spending, and higher share-based compensation expense, offset by lower acquisition-related costs and lower contracted services spending.

[0000858877-25-000033:mdna:191]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:192]
G&A expenses increased primarily due to higher headcount-related expenses, higher share-based compensation expense, and higher discretionary spending, partially offset by lower acquisition-related costs and lower contracted services spending.

[0000858877-25-000033:mdna:193]
[same as prior period, unchanged from 0000858877-25-000007:mdna:195]

[0000858877-25-000033:mdna:194]
In the third quarter of fiscal 2025, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $39 million, or 0.7%, compared with the third quarter of fiscal 2024.

[0000858877-25-000033:mdna:195]
In the first nine months of fiscal 2025, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $50 million, or 0.3%, compared with the first nine months of fiscal 2024.

[0000858877-25-000033:mdna:196]
[same as prior period, unchanged from 0000858877-25-000007:mdna:198]

[0000858877-25-000033:mdna:197]
[same as prior period, unchanged from 0000858877-25-000007:mdna:199]

[0000858877-25-000033:mdna:198]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 269 |  |  | $ | 254 |  |  | $ | 934 |  |  | $ | 620 |  |
| Operating expenses |  | 244 |  |  | 297 |  |  | 774 |  |  | 430 |  |
| Total |  | $ | 513 |  |  | $ | 551 |  |  | $ | 1,708 |  |  | $ | 1,050 |  |

[0000858877-25-000033:mdna:199]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:200]
The decrease in amortization of purchased intangible assets was primarily due to lower impairment charges related to purchased intangible assets for the current period. Impairment charges related to purchased intangible assets were $139 million for the third quarter of fiscal 2024.

[0000858877-25-000033:mdna:201]
[same as prior period, unchanged from 0000858877-25-000007:mdna:202]

[0000858877-25-000033:mdna:202]
[same as prior period, unchanged from 0000858877-25-000007:mdna:203]

[0000858877-25-000033:mdna:203]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:204]
The increase in amortization of purchased intangible assets was primarily due to the acquisition of Splunk and other recent acquisitions, partially offset by certain purchased intangible assets that became fully amortized and lower impairment charges in fiscal 2025. Impairment charges related to purchased intangible assets were $19 million for the first nine months of fiscal 2025 and $145 million for the first nine months of fiscal 2024. The impairment charges were as a result of declines in estimated fair values resulting from the reductions in or the elimination of expected future cash flows associated with certain in-process research and development and technology intangible assets.

[0000858877-25-000033:mdna:205]
[same as prior period, unchanged from 0000858877-25-000007:mdna:205]

[0000858877-25-000033:mdna:206]
In the first quarter of fiscal 2025, we announced a restructuring plan in order to allow us to invest in key growth opportunities and drive more efficiencies in our business. This restructuring plan is expected to impact approximately 7% of our global workforce with estimated pre-tax charges of approximately $1 billion. In connection with this restructuring plan, we incurred charges of $34 million and $709 million in the third quarter and first nine months of fiscal 2025. We expect this plan to be substantially completed by the end of the first quarter of fiscal 2026. We expect to reinvest substantially all of the cost savings from this restructuring plan in our key growth opportunities. As a result, the overall cost savings from this restructuring plan is not expected to be material for future periods.

[0000858877-25-000033:mdna:207]
In the third quarter of fiscal 2024, we initiated a restructuring plan in order to realign the organization and enable further investment in key priority areas. In connection with this restructuring plan, we incurred charges of $542 million in the third quarter and the first nine months of fiscal 2024. This plan was completed in fiscal 2024.

[0000858877-25-000033:mdna:208]
[same as prior period, unchanged from 0000858877-25-000007:mdna:208]

[0000858877-25-000033:mdna:209]
[same as prior period, unchanged from 0000858877-25-000007:mdna:209]

[0000858877-25-000033:mdna:210]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Operating income |  | $ | 3,202 |  |  | $ | 2,191 |  |  | $ | 8,673 |  |  | $ | 9,563 |  |
| Operating income as a percentage of revenue |  | 22.6 | % |  | 17.2 | % |  | 20.7 | % |  | 23.8 | % |

[0000858877-25-000033:mdna:211]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:212]
Operating income increased by 46%, and operating income as a percentage of revenue increased by 5.4 percentage points. These changes primarily resulted from a revenue increase, a higher gross margin percentage, and lower restructuring and other charges.

[0000858877-25-000033:mdna:213]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:214]
Operating income decreased by 9%, and operating income as a percentage of revenue decreased by 3.1 percentage points. These changes resulted primarily from higher cash compensation expenses from acquisitions, higher amortization of purchased intangible assets, and higher share-based compensation expense in the first nine months of fiscal 2025.

[0000858877-25-000033:mdna:215]
53

[0000858877-25-000033:mdna:216]
[same as prior period, unchanged from 0000858877-25-000007:mdna:219]

[0000858877-25-000033:mdna:217]
[same as prior period, unchanged from 0000858877-25-000007:mdna:220]

[0000858877-25-000033:mdna:218]
[same as prior period, unchanged from 0000858877-25-000007:mdna:215]

[0000858877-25-000033:mdna:219]
[same as prior period, unchanged from 0000858877-25-000007:mdna:216]

[0000858877-25-000033:mdna:220]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 26,2025 |  | April 27,2024 |  | Variancein Dollars |  | April 26,2025 |  | April 27,2024 |  | Variance in Dollars |
| Interest income |  | $ | 250 |  |  | $ | 411 |  |  | $ | (161) |  |  | $ | 774 |  |  | $ | 1,095 |  |  | $ | (321) |  |
| Interest expense |  | (403) |  |  | (357) |  |  | (46) |  |  | (1,225) |  |  | (588) |  |  | (637) |  |
| Interest income (expense), net |  | $ | (153) |  |  | $ | 54 |  |  | $ | (207) |  |  | $ | (451) |  |  | $ | 507 |  |  | $ | (958) |  |

[0000858877-25-000033:mdna:221]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:222]
The decrease in interest income was driven by a lower average balance of cash and available-for-sale debt investments and lower interest rates. The increase in interest expense was driven by higher interest expense from issuances of senior notes, partially offset by lower interest expense on commercial paper.

[0000858877-25-000033:mdna:223]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:224]
The decrease in interest income was driven by a lower average balance of cash and available-for-sale debt investments and lower interest rates. The increase in interest expense was primarily driven by issuances of senior notes and commercial paper.

[0000858877-25-000033:mdna:225]
[same as prior period, unchanged from 0000858877-25-000007:mdna:221]

[0000858877-25-000033:mdna:226]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 26,2025 |  | April 27,2024 |  | Variancein Dollars |  | April 26,2025 |  | April 27,2024 |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | (30) |  |  | $ | (14) |  |  | $ | (16) |  |  | $ | (75) |  |  | $ | (57) |  |  | $ | (18) |  |
| Marketable equity investments |  | (36) |  |  | 19 |  |  | (55) |  |  | 9 |  |  | 35 |  |  | (26) |  |
| Privately held investments |  | 10 |  |  | (8) |  |  | 18 |  |  | 57 |  |  | (163) |  |  | 220 |  |
| Net gains (losses) on investments |  | (56) |  |  | (3) |  |  | (53) |  |  | (9) |  |  | (185) |  |  | 176 |  |
| Other gains (losses), net |  | (46) |  |  | (7) |  |  | (39) |  |  | (112) |  |  | (47) |  |  | (65) |  |
| Other income (loss), net |  | $ | (102) |  |  | $ | (10) |  |  | $ | (92) |  |  | $ | (121) |  |  | $ | (232) |  |  | $ | 111 |  |

[0000858877-25-000033:mdna:227]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:228]
The change in our other income (loss), net was primarily driven by higher unrealized losses on marketable equity investments and unfavorable impacts from foreign exchange.

[0000858877-25-000033:mdna:229]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:230]
The change in our other income (loss), net was primarily driven by lower impairment charges and higher unrealized gains on our privately held investments, partially offset by lower gains on our marketable equity investments and unfavorable impacts from foreign exchange.

[0000858877-25-000033:mdna:231]
[same as prior period, unchanged from 0000858877-25-000007:mdna:227]

[0000858877-25-000033:mdna:232]
Three Months Ended April 26, 2025 Compared with Three Months Ended April 27, 2024

[0000858877-25-000033:mdna:233]
The provision for income taxes resulted in an effective tax rate of 15.5% for the third quarter of fiscal 2025, relatively unchanged compared with an effective tax rate of 15.6% for the third quarter of fiscal 2024.

[0000858877-25-000033:mdna:234]
Nine Months Ended April 26, 2025 Compared with Nine Months Ended April 27, 2024

[0000858877-25-000033:mdna:235]
The provision for income taxes resulted in an effective tax rate of 5.8% for the first nine months of fiscal 2025 compared with 17.1% for the first nine months of fiscal 2024. The decrease in the effective tax rate was primarily due to a $720 million benefit related to a U.S. Tax Court opinion issued during the first quarter of fiscal 2025 regarding the U.S. taxation of deemed foreign dividends in the transition year of the Tax Cuts and Jobs Act (our fiscal 2018).

[0000858877-25-000033:mdna:236]
54

[0000858877-25-000033:mdna:237]
[same as prior period, unchanged from 0000858877-25-000007:mdna:232]

[0000858877-25-000033:mdna:238]
[same as prior period, unchanged from 0000858877-25-000007:mdna:233]

[0000858877-25-000033:mdna:239]
[same as prior period, unchanged from 0000858877-25-000007:mdna:234]

[0000858877-25-000033:mdna:240]
[same as prior period, unchanged from 0000858877-25-000007:mdna:235]

[0000858877-25-000033:mdna:241]
[same as prior period, unchanged from 0000858877-25-000007:mdna:236]

[0000858877-25-000033:mdna:242]
[same as prior period, unchanged from 0000858877-25-000007:mdna:237]

[0000858877-25-000033:mdna:243]
|  | April 26,2025 |  | July 27,2024 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 8,161 |  |  | $ | 7,508 |  |  | $ | 653 |  |
| Available-for-sale debt investments | 7,194 |  |  | 9,865 |  |  | (2,671) |  |
| Marketable equity securities | 287 |  |  | 481 |  |  | (194) |  |
| Total | $ | 15,642 |  |  | $ | 17,854 |  |  | $ | (2,212) |  |

[0000858877-25-000033:mdna:244]
The net decrease in cash and cash equivalents and investments in the first nine months of fiscal 2025 was primarily driven by cash returned to stockholders in the form of cash dividends of $4.8 billion and repurchases of common stock of $4.7 billion, net repayments of short-term borrowing and debt of $1.6 billion, capital expenditures of $0.7 billion, and net cash paid for acquisitions and divestitures of $0.3 billion. These uses of cash were partially offset by net cash provided by operating activities of $10.0 billion.

[0000858877-25-000033:mdna:245]
[same as prior period, unchanged from 0000858877-25-000007:mdna:240]

[0000858877-25-000033:mdna:246]
Securities Lending   We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of April 26, 2025 and July 27, 2024, we had no outstanding securities lending transactions.

[0000858877-25-000033:mdna:247]
[same as prior period, unchanged from 0000858877-25-000007:mdna:242]

[0000858877-25-000033:mdna:248]
[same as prior period, unchanged from 0000858877-25-000007:mdna:243]

[0000858877-25-000033:mdna:249]
|  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |
| Net cash provided by operating activities | $ | 9,959 |  |  | $ | 7,150 |  |
| Acquisition of property and equipment | (688) |  |  | (472) |  |
| Free cash flow | $ | 9,271 |  |  | $ | 6,678 |  |

[0000858877-25-000033:mdna:250]
[same as prior period, unchanged from 0000858877-25-000007:mdna:245]

[0000858877-25-000033:mdna:251]
[same as prior period, unchanged from 0000858877-25-000007:mdna:246]

[0000858877-25-000033:mdna:252]
[same as prior period, unchanged from 0000858877-25-000007:mdna:247]

[0000858877-25-000033:mdna:253]
[same as prior period, unchanged from 0000858877-25-000007:mdna:248]

[0000858877-25-000033:mdna:254]
[same as prior period, unchanged from 0000858877-25-000007:mdna:249]

[0000858877-25-000033:mdna:255]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2025 |  |  |  |  |  |  |  |  |  |  |  |  |
| April 26, 2025 |  | $ | 0.41 |  |  | $ | 1,627 |  |  | 25 |  |  | $ | 59.78 |  |  | $ | 1,504 |  |  | $ | 3,131 |  |
| January 25, 2025 |  | $ | 0.40 |  |  | $ | 1,593 |  |  | 21 |  |  | $ | 58.58 |  |  | $ | 1,236 |  |  | $ | 2,829 |  |
| October 26, 2024 |  | $ | 0.40 |  |  | $ | 1,592 |  |  | 40 |  |  | $ | 49.56 |  |  | $ | 2,003 |  |  | $ | 3,595 |  |
| Fiscal 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 27, 2024 |  | $ | 0.40 |  |  | $ | 1,606 |  |  | 43 |  |  | $ | 46.80 |  |  | $ | 2,002 |  |  | $ | 3,608 |  |
| April 27, 2024 |  | $ | 0.40 |  |  | $ | 1,615 |  |  | 26 |  |  | $ | 49.22 |  |  | $ | 1,256 |  |  | $ | 2,871 |  |
| January 27, 2024 |  | $ | 0.39 |  |  | $ | 1,583 |  |  | 25 |  |  | $ | 49.54 |  |  | $ | 1,254 |  |  | $ | 2,837 |  |
| October 28, 2023 |  | $ | 0.39 |  |  | $ | 1,580 |  |  | 23 |  |  | $ | 54.53 |  |  | $ | 1,252 |  |  | $ | 2,832 |  |

[0000858877-25-000033:mdna:256]
On May 14, 2025, our Board of Directors declared a quarterly dividend of $0.41 per common share to be paid on July 23, 2025, to all stockholders of record as of the close of business on July 3, 2025. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-25-000033:mdna:257]
The remaining authorized amount for stock repurchases under this program is approximately $15.4 billion, with no termination date.

[0000858877-25-000033:mdna:258]
[same as prior period, unchanged from 0000858877-25-000007:mdna:253]

[0000858877-25-000033:mdna:259]
|  | April 26,2025 |  | July 27,2024 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,277 |  |  | $ | 6,685 |  |  | $ | (1,408) |  |

[0000858877-25-000033:mdna:260]
Our accounts receivable net, as of April 26, 2025 decreased by approximately 21%, as compared with the end of fiscal 2024, primarily due to timing and amount of product and service billings in the third quarter of fiscal 2025 compared with the fourth quarter of fiscal 2024.

[0000858877-25-000033:mdna:261]
[same as prior period, unchanged from 0000858877-25-000007:mdna:256]

[0000858877-25-000033:mdna:262]
[same as prior period, unchanged from 0000858877-25-000007:mdna:257]

[0000858877-25-000033:mdna:263]
[same as prior period, unchanged from 0000858877-25-000007:mdna:258]

[0000858877-25-000033:mdna:264]
|  | April 26,2025 |  | July 27,2024 |  | July 29,2023 |  | Variance vs. July 27, 2024 |  | Variance vs. July 29, 2023 |
| Inventories | $ | 2,832 |  |  | $ | 3,373 |  |  | $ | 3,644 |  |  | $ | (541) |  |  | $ | (812) |  |
| Inventory purchase commitments | $ | 6,345 |  |  | $ | 5,158 |  |  | $ | 7,253 |  |  | $ | 1,187 |  |  | $ | (908) |  |
| Inventory deposits and prepayments | $ | 1,101 |  |  | $ | 973 |  |  | $ | 1,109 |  |  | $ | 128 |  |  | $ | (8) |  |

[0000858877-25-000033:mdna:265]
[same as prior period, unchanged from 0000858877-25-000007:mdna:260]

[0000858877-25-000033:mdna:266]
|  | April 26,2025 |  | July 27,2024 |  | July 29,2023 |  | Variance vs. July 27, 2024 |  | Variance vs.July 29, 2023 |
| Less than 1 year | $ | 5,773 |  |  | $ | 3,952 |  |  | $ | 5,270 |  |  | $ | 1,821 |  |  | $ | 503 |  |
| 1 to 3 years | 509 |  |  | 1,085 |  |  | 1,783 |  |  | (576) |  |  | (1,274) |  |
| 3 to 5 years | 63 |  |  | 121 |  |  | 200 |  |  | (58) |  |  | (137) |  |
| Total | $ | 6,345 |  |  | $ | 5,158 |  |  | $ | 7,253 |  |  | $ | 1,187 |  |  | $ | (908) |  |

[0000858877-25-000033:mdna:267]
Inventory as of April 26, 2025 decreased by 16% and inventory purchase commitments with contract manufacturers and suppliers increased by 23% from our balances at the end of fiscal 2024. This increase was primarily related to commitments with contract manufacturers to meet customer demand. The combined increase in our inventory and inventory purchase commitments was 8% as compared with the end of fiscal 2024.

[0000858877-25-000033:mdna:268]
[same as prior period, unchanged from 0000858877-25-000007:mdna:263]

[0000858877-25-000033:mdna:269]
[same as prior period, unchanged from 0000858877-25-000007:mdna:264]

[0000858877-25-000033:mdna:270]
[same as prior period, unchanged from 0000858877-25-000007:mdna:265]

[0000858877-25-000033:mdna:271]
[same as prior period, unchanged from 0000858877-25-000007:mdna:266]

[0000858877-25-000033:mdna:272]
|  | April 26,2025 |  | July 27,2024 |  | Increase (Decrease) |
| Loan receivables, net | $ | 5,232 |  |  | $ | 5,808 |  |  | $ | (576) |  |
| Lease receivables, net | 973 |  |  | 906 |  |  | 67 |  |
| Total, net | $ | 6,205 |  |  | $ | 6,714 |  |  | $ | (509) |  |

[0000858877-25-000033:mdna:273]
Financing Receivables  Our financing arrangements include loans and leases. Our loan receivables include customer financing for purchases of our hardware, software and services (including technical support and advanced services), and also may include additional funds for other costs associated with network installation and integration of our products and services. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Financing receivables decreased by 8% as compared with the end of fiscal 2024.

[0000858877-25-000033:mdna:274]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and

[0000858877-25-000033:mdna:275]
57

[0000858877-25-000033:mdna:276]
[same as prior period, unchanged from 0000858877-25-000007:mdna:270]

[0000858877-25-000033:mdna:277]
[same as prior period, unchanged from 0000858877-25-000007:mdna:271]

[0000858877-25-000033:mdna:278]
loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, with payment terms generally ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-25-000033:mdna:279]
The volume of channel partner financing was $18.1 billion and $20.9 billion for the first nine months of fiscal 2025 and 2024, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.2 billion as of each of April 26, 2025 and July 27, 2024. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of April 26, 2025, the total maximum potential future payments related to these guarantees was approximately $116 million, of which approximately $10 million was recorded as deferred revenue.

[0000858877-25-000033:mdna:280]
[same as prior period, unchanged from 0000858877-25-000007:mdna:274]

[0000858877-25-000033:mdna:281]
[same as prior period, unchanged from 0000858877-25-000007:mdna:275]

[0000858877-25-000033:mdna:282]
|  | Maturity Date |  | April 26,2025 |  | July 27,2024 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | $ | 500 |  |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 1,000 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 2,000 |  |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | — |  |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 2,500 |  |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | — |  |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 2,500 |  |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | — |  |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 2,500 |  |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | — |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | February 24, 2055 |  | 750 |  |  | — |  |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 1,000 |  |
| Total |  |  | $ | 25,250 |  |  | $ | 20,250 |  |

[0000858877-25-000033:mdna:283]
In February 2025, we issued senior notes for an aggregate principal amount of $5.0 billion.

[0000858877-25-000033:mdna:284]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of April 26, 2025.

[0000858877-25-000033:mdna:285]
Commercial Paper  We have a short-term debt financing program in which up to $15.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had $4.2 billion and $10.9 billion in commercial paper notes outstanding as of April 26, 2025 and July 27, 2024, respectively.

[0000858877-25-000033:mdna:286]
[same as prior period, unchanged from 0000858877-25-000007:mdna:280]

[0000858877-25-000033:mdna:287]
[same as prior period, unchanged from 0000858877-25-000007:mdna:281]

[0000858877-25-000033:mdna:288]
Credit Facility  On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of April 26, 2025, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.

[0000858877-25-000033:mdna:289]
[same as prior period, unchanged from 0000858877-25-000007:mdna:282]

[0000858877-25-000033:mdna:290]
|  | April 26,2025 |  | July 27,2024 |  | Increase (Decrease) |
| Product | $ | 20,752 |  |  | $ | 20,055 |  |  | $ | 697 |  |
| Services | 20,915 |  |  | 20,993 |  |  | (78) |  |
| Total | $ | 41,667 |  |  | $ | 41,048 |  |  | $ | 619 |  |
| Short-term RPO | $ | 21,066 |  |  | $ | 20,882 |  |  | $ | 184 |  |
| Long-term RPO | 20,601 |  |  | 20,166 |  |  | 435 |  |
| Total | $ | 41,667 |  |  | $ | 41,048 |  |  | $ | 619 |  |

[0000858877-25-000033:mdna:291]
Total remaining performance obligations as of April 26, 2025 increased 2% compared to the end of fiscal 2024. Remaining performance obligations for product increased by 3% compared to the end of fiscal 2024. Remaining performance obligations for services were flat. We expect approximately 51% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-25-000033:mdna:292]
[same as prior period, unchanged from 0000858877-25-000007:mdna:285]

[0000858877-25-000033:mdna:293]
|  | April 26,2025 |  | July 27,2024 |  | Increase (Decrease) |
| Product | $ | 13,170 |  |  | $ | 13,219 |  |  | $ | (49) |  |
| Services | 14,821 |  |  | 15,256 |  |  | (435) |  |
| Total | $ | 27,991 |  |  | $ | 28,475 |  |  | $ | (484) |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 16,081 |  |  | $ | 16,249 |  |  | $ | (168) |  |
| Noncurrent | 11,910 |  |  | 12,226 |  |  | (316) |  |
| Total | $ | 27,991 |  |  | $ | 28,475 |  |  | $ | (484) |  |

[0000858877-25-000033:mdna:294]
Total deferred revenue decreased 2% compared to the end of fiscal 2024. Within total deferred revenue, deferred product revenue was flat and deferred services revenue decreased by 3%. The decrease in deferred services revenue was driven by lower business volume and ongoing amortization of deferred services revenue.

[0000858877-25-000033:mdna:295]
[same as prior period, unchanged from 0000858877-25-000007:mdna:288]

[0000858877-25-000033:mdna:296]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed herein. In addition, we plan for and measure our liquidity and capital resources through an annual budgeting process. Our contractual obligations consist of operating leases, purchase commitments with contract manufacturers and suppliers, other purchase obligations, long-term debt, the transition tax payable, and other long-term liabilities. Our contractual obligations were approximately $47 billion as of April 26, 2025, compared to approximately $38 billion as of July 27, 2024. For additional information on our contractual obligations see our Annual Report on Form 10-K for the fiscal year ended July 27, 2024.

[0000858877-25-000033:mdna:297]
[same as prior period, unchanged from 0000858877-25-000007:mdna:294]

[0000858877-25-000033:mdna:298]
[same as prior period, unchanged from 0000858877-25-000007:mdna:295]

[0000858877-25-000033:mdna:299]
We also have certain funding commitments primarily related to our privately held investments. The funding commitments were $0.3 billion and $0.2 billion as of April 26, 2025 and July 27, 2024, respectively.

[0000858877-25-000033:mdna:300]
[same as prior period, unchanged from 0000858877-25-000007:mdna:292]

[0000858877-25-000033:mdna:301]
[same as prior period, unchanged from 0000858877-25-000007:mdna:293]

[0000858877-25-000033:mdna:302]
In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of April 26, 2025 there were no material unconsolidated variable interest entities.

[0000858877-25-000033:mdna:303]
[same as prior period, unchanged from 0000858877-25-000007:mdna:298]

[0000858877-25-000033:mdna:304]
[same as prior period, unchanged from 0000858877-25-000007:mdna:299]

[0000858877-25-000033:mdna:305]
[same as prior period, unchanged from 0000858877-25-000007:mdna:300]

[0000858877-25-000033:mdna:306]
[same as prior period, unchanged from 0000858877-25-000007:mdna:301]
