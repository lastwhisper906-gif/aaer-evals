# CSCO notes — 0000858877-25-000033


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-25-000033:notes:1]
[same as prior period, unchanged from 0000858877-25-000007:notes:1]

[0000858877-25-000033:notes:2]
We have prepared the accompanying financial data as of April 26, 2025 and for the third quarter and first nine months of fiscal 2025 and 2024, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2024 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2024.

[0000858877-25-000033:notes:3]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of April 26, 2025, the results of operations, the statements of comprehensive income and the statements of equity for the third quarter and first nine months of fiscal 2025 and 2024, and the statements of cash flows for the first nine months of fiscal 2025 and 2024, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2025 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-25-000033:notes:4]
[same as prior period, unchanged from 0000858877-25-000007:notes:4]

[0000858877-25-000033:notes:5]
We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-25-000033:notes:6]
[same as prior period, unchanged from 0000858877-25-000007:notes:6]

[0000858877-25-000033:notes:7]
Segment Reporting  In November 2023, the Financial Accounting Standards Board (FASB) issued an accounting standard update that expands the disclosure requirements for reportable segments, primarily through enhanced disclosures around significant segment expenses. The accounting standard update will be effective for our fiscal 2025 Form 10-K on a retrospective basis, and early adoption is permitted. We are currently evaluating the impact of this accounting standard update on our segment disclosures.

[0000858877-25-000033:notes:8]
Improvements on Income Tax Disclosures  In December 2023, the FASB issued an accounting standard update expanding the requirements for disclosure of disaggregated information about the effective tax rate reconciliation and income taxes paid. The accounting standard update will be effective for our fiscal 2026 Form 10-K. We are currently evaluating the impact of this accounting standard update on our income tax disclosures.

[0000858877-25-000033:notes:9]
Disaggregation of Income Statement Expenses  In November 2024, the FASB issued an accounting standard update expanding the disclosure requirements about specific expense categories, primarily through disaggregated information on income statement line items. The accounting standard update will be effective for our fiscal 2028 Form 10-K, and early adoption is permitted. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-25-000033:notes:10]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers. Revenue from subscription offers includes revenue recognized over time as well as upfront.

[0000858877-25-000033:notes:11]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-25-000033:notes:12]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 26, 2025 and July 27, 2024 was $39 million and $37 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-25-000033:notes:13]
Significant Judgments

[0000858877-25-000033:notes:14]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-25-000033:notes:15]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and end customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.

[0000858877-25-000033:notes:16]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license’s utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

[0000858877-25-000033:notes:17]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and advanced services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Advanced services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

[0000858877-25-000033:notes:18]
[same as prior period, unchanged from 0000858877-25-000007:notes:42]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-25-000033:notes:19]
[same as prior period, unchanged from 0000858877-25-000007:notes:17]

[0000858877-25-000033:notes:20]
[same as prior period, unchanged from 0000858877-25-000007:notes:18]

[0000858877-25-000033:notes:21]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,068 |  |  | $ | 6,522 |  |  | $ | 20,671 |  |  | $ | 22,425 |  |
| Security | 2,013 |  |  | 1,304 |  |  | 6,142 |  |  | 3,288 |  |
| Collaboration | 1,031 |  |  | 987 |  |  | 3,112 |  |  | 3,093 |  |
| Observability | 261 |  |  | 211 |  |  | 796 |  |  | 589 |  |
| Total Product | 10,374 |  |  | 9,024 |  |  | 30,722 |  |  | 29,395 |  |
| Services | 3,775 |  |  | 3,678 |  |  | 11,259 |  |  | 10,766 |  |
| Total | $ | 14,149 |  |  | $ | 12,702 |  |  | $ | 41,981 |  |  | $ | 40,161 |  |

[0000858877-25-000033:notes:22]
[same as prior period, unchanged from 0000858877-25-000007:notes:20]

[0000858877-25-000033:notes:23]
[same as prior period, unchanged from 0000858877-25-000007:notes:21]

[0000858877-25-000033:notes:24]
[same as prior period, unchanged from 0000858877-25-000007:notes:22]

[0000858877-25-000033:notes:25]
[same as prior period, unchanged from 0000858877-25-000007:notes:23]

[0000858877-25-000033:notes:26]
[same as prior period, unchanged from 0000858877-25-000007:notes:24]

[0000858877-25-000033:notes:27]
[same as prior period, unchanged from 0000858877-25-000007:notes:26]

[0000858877-25-000033:notes:28]
[same as prior period, unchanged from 0000858877-25-000007:notes:27]

[0000858877-25-000033:notes:29]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Product | $ | 4,483 |  |  | $ | 3,510 |  |  | $ | 13,334 |  |  | $ | 9,827 |  |
| Services | 3,433 |  |  | 3,344 |  |  | 10,288 |  |  | 9,878 |  |
| Total | $ | 7,916 |  |  | $ | 6,854 |  |  | $ | 23,622 |  |  | $ | 19,705 |  |

[0000858877-25-000033:notes:30]
[same as prior period, unchanged from 0000858877-25-000007:notes:29]

[0000858877-25-000033:notes:31]
[same as prior period, unchanged from 0000858877-25-000007:notes:30]

[0000858877-25-000033:notes:32]
[same as prior period, unchanged from 0000858877-25-000007:notes:31]

[0000858877-25-000033:notes:33]
Accounts receivable, net was $5.3 billion as of April 26, 2025 compared to $6.7 billion as of July 27, 2024, as reported on the Consolidated Balance Sheets.

[0000858877-25-000033:notes:34]
[same as prior period, unchanged from 0000858877-25-000007:notes:33]

[0000858877-25-000033:notes:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Allowance for credit loss at beginning of period | $ | 80 |  |  | $ | 79 |  |  | $ | 87 |  |  | $ | 85 |  |
| Provisions | 13 |  |  | 10 |  |  | 25 |  |  | 21 |  |
| Write-offs, net of recoveries | (11) |  |  | (8) |  |  | (30) |  |  | (25) |  |
| Allowance for credit loss at end of period | $ | 82 |  |  | $ | 81 |  |  | $ | 82 |  |  | $ | 81 |  |

[0000858877-25-000033:notes:36]
[same as prior period, unchanged from 0000858877-25-000007:notes:35]

[0000858877-25-000033:notes:37]
[same as prior period, unchanged from 0000858877-25-000007:notes:36]

[0000858877-25-000033:notes:38]
|  | April 26,2025 |  | July 27,2024 |
| 1 to 4 | $ | 1,245 |  |  | $ | 1,266 |  |
| 5 to 6 | 1,762 |  |  | 1,456 |  |
| 7 and Higher | 70 |  |  | 72 |  |
| Total | $ | 3,077 |  |  | $ | 2,794 |  |

[0000858877-25-000033:notes:39]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $3.0 billion as of April 26, 2025 and $2.7 billion as of July 27, 2024, and were included in other current assets and other assets.

[0000858877-25-000033:notes:40]
Contract liabilities consist of deferred revenue. Deferred revenue was $28.0 billion as of April 26, 2025 compared to $28.5 billion as of July 27, 2024. We recognized approximately $3.6 billion and $13.3 billion of revenue during the third quarter and first nine months of fiscal 2025 that was included in the deferred revenue balance at July 27, 2024.

[0000858877-25-000033:notes:41]
[same as prior period, unchanged from 0000858877-25-000007:notes:40]

[0000858877-25-000033:notes:42]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to 
the period of benefit. Capitalized contract acquisition costs were $1.5 billion and $1.3 billion as of April 26, 2025 and July 27, 2024, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $272 million and $718 million for the third quarter and first nine months of fiscal 2025, respectively, and $201 million and $525 million for the corresponding periods of fiscal 2024, respectively, and was included in sales and marketing expenses.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-25-000033:notes:43]
[same as prior period, unchanged from 0000858877-25-000007:notes:43]

[0000858877-25-000033:notes:44]
[same as prior period, unchanged from 0000858877-25-000007:notes:44]

[0000858877-25-000033:notes:45]
[same as prior period, unchanged from 0000858877-25-000007:notes:45]

[0000858877-25-000033:notes:46]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,068 |  |  | $ | 6,522 |  |  | $ | 20,671 |  |  | $ | 22,425 |  |
| Security | 2,013 |  |  | 1,304 |  |  | 6,142 |  |  | 3,288 |  |
| Collaboration | 1,031 |  |  | 987 |  |  | 3,112 |  |  | 3,093 |  |
| Observability | 261 |  |  | 211 |  |  | 796 |  |  | 589 |  |
| Total Product | 10,374 |  |  | 9,024 |  |  | 30,722 |  |  | 29,395 |  |
| Services | 3,775 |  |  | 3,678 |  |  | 11,259 |  |  | 10,766 |  |
| Total | $ | 14,149 |  |  | $ | 12,702 |  |  | $ | 41,981 |  |  | $ | 40,161 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-25-000033:notes:47]
Acquisitions
A summary of the allocation of the total purchase consideration of our completed acquisitions during the first nine months of fiscal 2025 is presented as follows (in millions):

[0000858877-25-000033:notes:48]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions | $ | 293 |  |  | $ | (21) |  |  | $ | 121 |  |  | $ | 193 |  |

[0000858877-25-000033:notes:49]
The total purchase consideration related to our acquisitions completed during the first nine months of fiscal 2025 consisted primarily of cash consideration. The total cash and cash equivalents acquired from these acquisitions was approximately $15 million. Total transaction costs related to acquisition activities were $12 million and $102 million for the first nine months of fiscal 2025 and 2024, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-25-000033:notes:50]
[same as prior period, unchanged from 0000858877-25-000007:notes:50]

[0000858877-25-000033:notes:51]
The goodwill generated from these acquisitions completed during the first nine months of fiscal 2025 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-25-000033:notes:52]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first nine months of fiscal 2025 have not been presented because the effects of the acquisitions were not material to our financial results.

[0000858877-25-000033:notes:53]
[same as prior period, unchanged from 0000858877-25-000007:notes:53]

[0000858877-25-000033:notes:54]
[same as prior period, unchanged from 0000858877-25-000007:notes:54]

[0000858877-25-000033:notes:55]
[same as prior period, unchanged from 0000858877-25-000007:notes:55]

[0000858877-25-000033:notes:56]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Compensation expense related to acquisitions | $ | 216 |  |  | $ | 216 |  |  | $ | 735 |  |  | $ | 310 |  |

[0000858877-25-000033:notes:57]
As of April 26, 2025, we estimated that future cash compensation expense of up to $806 million may be required to be recognized pursuant to applicable acquisition agreements.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-25-000033:notes:58]
[same as prior period, unchanged from 0000858877-25-000007:notes:58]

[0000858877-25-000033:notes:59]
The following table presents the goodwill allocated to our reportable segments as of April 26, 2025 and changes to goodwill during the first nine months of fiscal 2025 (in millions):

[0000858877-25-000033:notes:60]
|  | Balance at July 27, 2024 |  | Acquisitions, net of Divestitures |  | Foreign Currency Translation and Other |  | Balance at April 26, 2025 |
| Americas | $ | 36,169 |  |  | $ | 121 |  |  | $ | 109 |  |  | $ | 36,399 |  |
| EMEA | 14,283 |  |  | 47 |  |  | 40 |  |  | 14,370 |  |
| APJC | 8,208 |  |  | 23 |  |  | 24 |  |  | 8,255 |  |
| Total | $ | 58,660 |  |  | $ | 191 |  |  | $ | 173 |  |  | $ | 59,024 |  |

[0000858877-25-000033:notes:61]
[same as prior period, unchanged from 0000858877-25-000007:notes:61]

[0000858877-25-000033:notes:62]
The following table presents details of our intangible assets acquired through acquisitions completed during the first nine months of fiscal 2025 (in millions, except years):

[0000858877-25-000033:notes:63]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | CUSTOMERRELATED |  | TECHNOLOGY |  | TRADE NAME |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions | 3.5 |  | $ | 16 |  |  | 3.8 |  | $ | 105 |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 121 |  |

[0000858877-25-000033:notes:64]
[same as prior period, unchanged from 0000858877-25-000007:notes:64]

[0000858877-25-000033:notes:65]
| April 26, 2025 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Customer related |  | $ | 6,371 |  |  | $ | (1,076) |  |  | $ | 5,295 |  |
| Technology |  | 5,347 |  |  | (1,485) |  |  | 3,862 |  |
| Trade name |  | 525 |  |  | (60) |  |  | 465 |  |
| Total purchased intangible assets with finite lives |  | 12,243 |  |  | (2,621) |  |  | 9,622 |  |
| In-process research and development, with indefinite lives |  | 21 |  |  | — |  |  | 21 |  |
| Total |  | $ | 12,264 |  |  | $ | (2,621) |  |  | $ | 9,643 |  |

[0000858877-25-000033:notes:66]
[same as prior period, unchanged from 0000858877-25-000007:notes:66]

[0000858877-25-000033:notes:67]
[same as prior period, unchanged from 0000858877-25-000007:notes:67]

[0000858877-25-000033:notes:68]
There were no impairment charges related to purchased intangible assets for the third quarter of fiscal 2025. Impairment charges related to purchased intangible assets were $19 million for the first nine months of fiscal 2025, and $139 million and $145 million for the third quarter and first nine months of fiscal 2024, respectively. The impairment charges were as a result of declines in estimated fair values resulting from the reductions in or the elimination of expected future cash flows associated with certain in-process research and development and technology intangible assets.

[0000858877-25-000033:notes:69]
[same as prior period, unchanged from 0000858877-25-000007:notes:69]

[0000858877-25-000033:notes:70]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 269 |  |  | $ | 254 |  |  | $ | 934 |  |  | $ | 620 |  |
| Operating expenses | 244 |  |  | 297 |  |  | 774 |  |  | 430 |  |
| Total | $ | 513 |  |  | $ | 551 |  |  | $ | 1,708 |  |  | $ | 1,050 |  |

[0000858877-25-000033:notes:71]
The estimated future amortization expense of purchased intangible assets with finite lives as of April 26, 2025 is as follows (in millions):

[0000858877-25-000033:notes:72]
| Fiscal Year | Amount |
| 2025 (remaining three months) | $ | 473 |  |
| 2026 | $ | 1,820 |  |
| 2027 | $ | 1,473 |  |
| 2028 | $ | 1,394 |  |
| 2029 | $ | 1,271 |  |
| Thereafter | $ | 3,191 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-25-000033:notes:73]
Restructuring and Other Charges
In the first quarter of fiscal 2025, we announced a restructuring plan (the “Fiscal 2025 Plan”), in order to allow us to invest in key growth opportunities and drive more efficiencies in our business, of which approximately 7% of our global workforce would be impacted with estimated pre-tax charges of up to $1 billion. In connection with the Fiscal 2025 Plan, we incurred charges of $34 million and $709 million for the third quarter and first nine months of fiscal 2025, respectively. These aggregate pre-tax charges are primarily cash-based and consist of severance and other one-time termination benefits, and other costs. We expect the Fiscal 2025 Plan to be substantially completed by the end of the first quarter of fiscal 2026.

[0000858877-25-000033:notes:74]
[same as prior period, unchanged from 0000858877-25-000007:notes:74]

[0000858877-25-000033:notes:75]
The following table summarizes the activities related to our restructuring liability, which was included in other current liabilities on our Consolidated Balance Sheets (in millions):

[0000858877-25-000033:notes:76]
|  |  | FISCAL 2025 PLAN |  | FISCAL 2024 PLAN |  |  |
|  |  | Employee Severance |  | Other |  | Employee Severance |  | Other |  | Total |
| Liability as of July 27, 2024 |  | $ | — |  |  | $ | — |  |  | $ | 201 |  |  | $ | 9 |  |  | $ | 210 |  |
| Charges |  | 581 |  |  | 128 |  |  | — |  |  | — |  |  | 709 |  |
| Cash payments |  | (534) |  |  | (5) |  |  | (159) |  |  | (5) |  |  | (703) |  |
| Non-cash and other |  | 32 |  |  | (71) |  |  | (19) |  |  | 1 |  |  | (57) |  |
| Liability as of April 26, 2025 |  | $ | 79 |  |  | $ | 52 |  |  | $ | 23 |  |  | $ | 5 |  |  | $ | 159 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-25-000033:notes:77]
[same as prior period, unchanged from 0000858877-25-000007:notes:77]

[0000858877-25-000033:notes:78]
[same as prior period, unchanged from 0000858877-25-000007:notes:78]

[0000858877-25-000033:notes:79]
|  |  | April 26,2025 |  | July 27,2024 |
| Cash and cash equivalents |  | $ | 8,161 |  |  | $ | 7,508 |  |
| Restricted cash and restricted cash equivalents included in other current assets |  | 755 |  |  | 765 |  |
| Restricted cash and restricted cash equivalents included in other assets |  | 2 |  |  | 569 |  |
| Total |  | $ | 8,918 |  |  | $ | 8,842 |  |

[0000858877-25-000033:notes:80]
[same as prior period, unchanged from 0000858877-25-000007:notes:80]

[0000858877-25-000033:notes:81]
[same as prior period, unchanged from 0000858877-25-000007:notes:81]

[0000858877-25-000033:notes:82]
|  |  | April 26,2025 |  | July 27,2024 |
| Raw materials |  | $ | 1,520 |  |  | $ | 2,039 |  |
| Work in process |  | 173 |  |  | 83 |  |
| Finished goods |  | 919 |  |  | 1,027 |  |
| Service-related spares |  | 214 |  |  | 216 |  |
| Demonstration systems |  | 6 |  |  | 8 |  |
| Total |  | $ | 2,832 |  |  | $ | 3,373 |  |

[0000858877-25-000033:notes:83]
[same as prior period, unchanged from 0000858877-25-000007:notes:83]

[0000858877-25-000033:notes:84]
|  |  | April 26,2025 |  | July 27,2024 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 3,996 |  |  | $ | 4,247 |  |
| Production, engineering, computer and other equipment and related software |  | 5,152 |  |  | 5,160 |  |
| Operating lease assets |  | 50 |  |  | 115 |  |
| Furniture, fixtures and other |  | 322 |  |  | 351 |  |
| Total gross property and equipment |  | 9,520 |  |  | 9,873 |  |
| Less: accumulated depreciation and amortization |  | (7,444) |  |  | (7,783) |  |
| Total |  | $ | 2,076 |  |  | $ | 2,090 |  |

[0000858877-25-000033:notes:85]
[same as prior period, unchanged from 0000858877-25-000007:notes:85]

[0000858877-25-000033:notes:86]
|  |  | April 26,2025 |  | July 27,2024 |
| Product |  | $ | 20,752 |  |  | $ | 20,055 |  |
| Services |  | 20,915 |  |  | 20,993 |  |
| Total |  | $ | 41,667 |  |  | $ | 41,048 |  |
| Short-term RPO |  | $ | 21,066 |  |  | $ | 20,882 |  |
| Long-term RPO |  | 20,601 |  |  | 20,166 |  |
| Total |  | $ | 41,667 |  |  | $ | 41,048 |  |
| Amount to be recognized as revenue over the next 12 months |  | 51 | % |  | 51 | % |
| Deferred revenue |  | $ | 27,991 |  |  | $ | 28,475 |  |
| Unbilled contract revenue |  | 13,676 |  |  | 12,573 |  |
| Total |  | $ | 41,667 |  |  | $ | 41,048 |  |

[0000858877-25-000033:notes:87]
[same as prior period, unchanged from 0000858877-25-000007:notes:87]

[0000858877-25-000033:notes:88]
[same as prior period, unchanged from 0000858877-25-000007:notes:88]

[0000858877-25-000033:notes:89]
|  |  | April 26,2025 |  | July 27,2024 |
| Product |  | $ | 13,170 |  |  | $ | 13,219 |  |
| Services |  | 14,821 |  |  | 15,256 |  |
| Total |  | $ | 27,991 |  |  | $ | 28,475 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 16,081 |  |  | $ | 16,249 |  |
| Noncurrent |  | 11,910 |  |  | 12,226 |  |
| Total |  | $ | 27,991 |  |  | $ | 28,475 |  |

[0000858877-25-000033:notes:90]
[same as prior period, unchanged from 0000858877-25-000007:notes:90]

[0000858877-25-000033:notes:91]
Our income tax payable associated with the one-time U.S. transition tax on accumulated earnings for foreign subsidiaries as a result of the Tax Cuts and Jobs Act is as follows:

[0000858877-25-000033:notes:92]
|  |  | April 26,2025 |  | July 27,2024 |
| Current |  | $ | 1,595 |  |  | $ | 1,819 |  |
| Noncurrent |  | — |  |  | 2,273 |  |
| Total |  | $ | 1,595 |  |  | $ | 4,092 |  |

[0000858877-25-000033:notes:93]
Our remaining transition tax payable as of April 26, 2025 has been reduced to reflect the transition tax benefit of the U.S. Tax Court opinion in Varian Medical Systems, Inc. v. Commissioner. See Note 18.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000858877-25-000033:notes:94]
Leases 
(a)Lessee Arrangements

[0000858877-25-000033:notes:95]
The following table presents our operating lease balances (in millions):

[0000858877-25-000033:notes:96]
|  | Balance Sheet Line Item |  | April 26, 2025 |  | July 27, 2024 |
| Operating lease right-of-use assets | Other assets |  | $ | 1,219 |  |  | 1,066 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 350 |  |  | $ | 364 |  |
| Operating lease liabilities | Other long-term liabilities |  | 1,114 |  |  | 906 |  |
| Total operating lease liabilities |  |  | $ | 1,464 |  |  | $ | 1,270 |  |

[0000858877-25-000033:notes:97]
The components of our lease expenses were as follows (in millions):

[0000858877-25-000033:notes:98]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Operating lease expense | $ | 115 |  |  | $ | 101 |  |  | $ | 378 |  |  | $ | 304 |  |
| Short-term lease expense | 18 |  |  | 19 |  |  | 52 |  |  | 55 |  |
| Variable lease expense | 47 |  |  | 43 |  |  | 140 |  |  | 149 |  |
| Total lease expense | $ | 180 |  |  | $ | 163 |  |  | $ | 570 |  |  | $ | 508 |  |

[0000858877-25-000033:notes:99]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-25-000033:notes:100]
|  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 345 |  |  | $ | 279 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 483 |  |  | $ | 307 |  |

[0000858877-25-000033:notes:101]
The weighted-average lease term was 5.5 years and 4.9 years as of April 26, 2025 and July 27, 2024, respectively. The weighted-average discount rate was 4.0% as of each of April 26, 2025 and July 27, 2024.

[0000858877-25-000033:notes:102]
The maturities of our operating leases (undiscounted) as of April 26, 2025 are as follows (in millions):

[0000858877-25-000033:notes:103]
| Fiscal Year | Amount |
| 2025 (remaining three months) | $ | 113 |  |
| 2026 | 382 |  |
| 2027 | 292 |  |
| 2028 | 217 |  |
| 2029 | 175 |  |
| Thereafter | 470 |  |
| Total lease payments | 1,649 |  |
| Less: interest | (185) |  |
| Total | $ | 1,464 |  |

[0000858877-25-000033:notes:104]
(b)Lessor Arrangements

[0000858877-25-000033:notes:105]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income was $16 million and $49 million for the third quarter and the first nine months of fiscal 2025, respectively, and $18 million and $48 million for the corresponding periods of fiscal 2024, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-25-000033:notes:106]
Future minimum lease payments on our lease receivables as of April 26, 2025 are summarized as follows (in millions):

[0000858877-25-000033:notes:107]
| Fiscal Year | Amount |
| 2025 (remaining three months) | $ | 126 |  |
| 2026 | 552 |  |
| 2027 | 239 |  |
| 2028 | 41 |  |
| 2029 | 43 |  |
| Thereafter | 24 |  |
| Total | 1,025 |  |
| Less: Present value of lease payments | (922) |  |
| Unearned income | $ | 103 |  |

[0000858877-25-000033:notes:108]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-25-000033:notes:109]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-25-000033:notes:110]
|  | April 26, 2025 |  | July 27, 2024 |
| Operating lease assets | $ | 50 |  |  | $ | 115 |  |
| Accumulated depreciation | (13) |  |  | (61) |  |
| Operating lease assets, net | $ | 37 |  |  | $ | 54 |  |

[0000858877-25-000033:notes:111]
Our operating lease income was $9 million and $29 million for the third quarter and first nine months of fiscal 2025, respectively, and $14 million and $45 million for the corresponding periods of fiscal 2024, respectively, and was included in product revenue in the Consolidated Statements of Operations.

[0000858877-25-000033:notes:112]
Minimum future rentals on noncancelable operating leases as of April 26, 2025 are summarized as follows (in millions):

[0000858877-25-000033:notes:113]
| Fiscal Year | Amount |
| 2025 (remaining three months) | $ | 5 |  |
| 2026 | 15 |  |
| 2027 | 7 |  |
| Total | $ | 27 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-25-000033:notes:114]
[same as prior period, unchanged from 0000858877-25-000007:notes:114]

[0000858877-25-000033:notes:115]
[same as prior period, unchanged from 0000858877-25-000007:notes:115]

[0000858877-25-000033:notes:116]
[same as prior period, unchanged from 0000858877-25-000007:notes:116]

[0000858877-25-000033:notes:117]
| April 26, 2025 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,276 |  |  | $ | 1,025 |  |  | $ | 6,301 |  |
| Residual value | — |  |  | 65 |  |  | 65 |  |
| Unearned income | — |  |  | (103) |  |  | (103) |  |
| Allowance for credit loss | (44) |  |  | (14) |  |  | (58) |  |
| Total, net | $ | 5,232 |  |  | $ | 973 |  |  | $ | 6,205 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 2,336 |  |  | $ | 622 |  |  | $ | 2,958 |  |
| Noncurrent | 2,896 |  |  | 351 |  |  | 3,247 |  |
| Total, net | $ | 5,232 |  |  | $ | 973 |  |  | $ | 6,205 |  |

[0000858877-25-000033:notes:118]
[same as prior period, unchanged from 0000858877-25-000007:notes:118]

[0000858877-25-000033:notes:119]
[same as prior period, unchanged from 0000858877-25-000007:notes:119]

[0000858877-25-000033:notes:120]
[same as prior period, unchanged from 0000858877-25-000007:notes:120]

[0000858877-25-000033:notes:121]
| April 26, 2025 |  |  | Fiscal Year |  | Nine Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 31, 2021 |  | July 30, 2022 |  | July 29, 2023 |  | July 27, 2024 |  | April 26, 2025 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 15 |  |  | $ | 121 |  |  | $ | 251 |  |  | $ | 462 |  |  | $ | 1,310 |  |  | $ | 1,138 |  |  | $ | 3,297 |  |
| 5 to 6 | 6 |  |  | 41 |  |  | 62 |  |  | 238 |  |  | 655 |  |  | 910 |  |  | 1,912 |  |
| 7 and Higher | 1 |  |  | 35 |  |  | 8 |  |  | 2 |  |  | 9 |  |  | 12 |  |  | 67 |  |
| Total Loan Receivables | $ | 22 |  |  | $ | 197 |  |  | $ | 321 |  |  | $ | 702 |  |  | $ | 1,974 |  |  | $ | 2,060 |  |  | $ | 5,276 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 1 |  |  | $ | 15 |  |  | $ | 31 |  |  | $ | 141 |  |  | $ | 224 |  |  | $ | 187 |  |  | $ | 599 |  |
| 5 to 6 | 1 |  |  | 9 |  |  | 28 |  |  | 79 |  |  | 116 |  |  | 79 |  |  | 312 |  |
| 7 and Higher | — |  |  | 1 |  |  | 1 |  |  | 3 |  |  | 6 |  |  | — |  |  | 11 |  |
| Total Lease Receivables | $ | 2 |  |  | $ | 25 |  |  | $ | 60 |  |  | $ | 223 |  |  | $ | 346 |  |  | $ | 266 |  |  | $ | 922 |  |
| Total | $ | 24 |  |  | $ | 222 |  |  | $ | 381 |  |  | $ | 925 |  |  | $ | 2,320 |  |  | $ | 2,326 |  |  | $ | 6,198 |  |

[0000858877-25-000033:notes:122]
[same as prior period, unchanged from 0000858877-25-000007:notes:122]

[0000858877-25-000033:notes:123]
The following tables present the aging analysis of gross receivables as of April 26, 2025 and July 27, 2024 (in millions):

[0000858877-25-000033:notes:124]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| April 26, 2025 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 30 |  |  | $ | 137 |  |  | $ | 18 |  |  | $ | 185 |  |  | $ | 5,091 |  |  | $ | 5,276 |  |  | $ | 8 |  |  | $ | 9 |  |  | $ | 9 |  |
| Lease receivables | 10 |  |  | 6 |  |  | 6 |  |  | 22 |  |  | 900 |  |  | 922 |  |  | 3 |  |  | 1 |  |  | 1 |  |
| Total | $ | 40 |  |  | $ | 143 |  |  | $ | 24 |  |  | $ | 207 |  |  | $ | 5,991 |  |  | $ | 6,198 |  |  | $ | 11 |  |  | $ | 10 |  |  | $ | 10 |  |

[0000858877-25-000033:notes:125]
[same as prior period, unchanged from 0000858877-25-000007:notes:125]

[0000858877-25-000033:notes:126]
[same as prior period, unchanged from 0000858877-25-000007:notes:126]

[0000858877-25-000033:notes:127]
[same as prior period, unchanged from 0000858877-25-000007:notes:127]

[0000858877-25-000033:notes:128]
[same as prior period, unchanged from 0000858877-25-000007:notes:128]

[0000858877-25-000033:notes:129]
| Three Months Ended April 26, 2025 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of January 25, 2025 | $ | 45 |  |  | $ | 14 |  |  | $ | 59 |  |
| Provisions (benefits) | (2) |  |  | (1) |  |  | (3) |  |
| Foreign exchange and other | 1 |  |  | 1 |  |  | 2 |  |
| Allowance for credit loss as of April 26, 2025 | $ | 44 |  |  | $ | 14 |  |  | $ | 58 |  |

[0000858877-25-000033:notes:130]
| Three Months Ended April 27, 2024 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of January 27, 2024 | $ | 53 |  |  | $ | 16 |  |  | $ | 69 |  |
| Provisions (benefits) | (3) |  |  | — |  |  | (3) |  |
| Recoveries (write-offs), net | — |  |  | (1) |  |  | (1) |  |
| Foreign exchange and other | (1) |  |  | — |  |  | (1) |  |
| Allowance for credit loss as of April 27, 2024 | $ | 49 |  |  | $ | 15 |  |  | $ | 64 |  |

[0000858877-25-000033:notes:131]
| Nine Months Ended April 26, 2025 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 27, 2024 | $ | 50 |  |  | $ | 15 |  |  | $ | 65 |  |
| Provisions (benefits) | (5) |  |  | (3) |  |  | (8) |  |
| Recoveries (write-offs), net | (3) |  |  | — |  |  | (3) |  |
| Foreign exchange and other | 2 |  |  | 2 |  |  | 4 |  |
| Allowance for credit loss as of April 26, 2025 | $ | 44 |  |  | $ | 14 |  |  | $ | 58 |  |

[0000858877-25-000033:notes:132]
| Nine Months Ended April 27, 2024 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 29, 2023 | $ | 53 |  |  | $ | 19 |  |  | $ | 72 |  |
| Provisions (benefits) | 1 |  |  | (3) |  |  | (2) |  |
| Recoveries (write-offs), net | (4) |  |  | (1) |  |  | (5) |  |
| Foreign exchange and other | (1) |  |  | — |  |  | (1) |  |
| Allowance for credit loss as of April 27, 2024 | $ | 49 |  |  | $ | 15 |  |  | $ | 64 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-25-000033:notes:133]
Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-25-000033:notes:134]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-25-000033:notes:135]
| April 26, 2025 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,079 |  |  | $ | 4 |  |  | $ | (15) |  |  | $ | 2,068 |  |
| U.S. government agency securities | 77 |  |  | — |  |  | — |  |  | 77 |  |
| Non-U.S. government and agency securities | 376 |  |  | 1 |  |  | — |  |  | 377 |  |
| Corporate debt securities | 3,206 |  |  | 7 |  |  | (75) |  |  | 3,138 |  |
| U.S. agency mortgage-backed securities | 556 |  |  | — |  |  | (66) |  |  | 490 |  |
| Commercial paper | 436 |  |  | — |  |  | — |  |  | 436 |  |
| Certificates of deposit | 608 |  |  | — |  |  | — |  |  | 608 |  |
| Total | $ | 7,338 |  |  | $ | 12 |  |  | $ | (156) |  |  | $ | 7,194 |  |

[0000858877-25-000033:notes:136]
| July 27, 2024 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,380 |  |  | $ | 1 |  |  | $ | (28) |  |  | $ | 2,353 |  |
| U.S. government agency securities | 223 |  |  | — |  |  | (2) |  |  | 221 |  |
| Non-U.S. government and agency securities | 370 |  |  | 1 |  |  | — |  |  | 371 |  |
| Corporate debt securities | 3,818 |  |  | 5 |  |  | (146) |  |  | 3,677 |  |
| U.S. agency mortgage-backed securities | 1,959 |  |  | — |  |  | (178) |  |  | 1,781 |  |
| Commercial paper | 1,023 |  |  | — |  |  | — |  |  | 1,023 |  |
| Certificates of deposit | 439 |  |  | — |  |  | — |  |  | 439 |  |
| Total | $ | 10,212 |  |  | $ | 7 |  |  | $ | (354) |  |  | $ | 9,865 |  |

[0000858877-25-000033:notes:137]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-25-000033:notes:138]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Gross realized gains | $ | 1 |  |  | $ | 2 |  |  | $ | 9 |  |  | $ | 7 |  |
| Gross realized losses | (31) |  |  | (16) |  |  | $ | (84) |  |  | $ | (64) |  |
| Total | $ | (30) |  |  | $ | (14) |  |  | $ | (75) |  |  | $ | (57) |  |

[0000858877-25-000033:notes:139]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 26, 2025 and July 27, 2024 (in millions):

[0000858877-25-000033:notes:140]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 26, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 970 |  |  | $ | (6) |  |  | $ | 313 |  |  | $ | (9) |  |  | $ | 1,283 |  |  | $ | (15) |  |
| U.S. government agency securities | 10 |  |  | — |  |  | 31 |  |  | — |  |  | 41 |  |  | — |  |
| Non-U.S. government and agency securities | 76 |  |  | — |  |  | — |  |  | — |  |  | 76 |  |  | — |  |
| Corporate debt securities | 319 |  |  | (1) |  |  | 1,917 |  |  | (48) |  |  | 2,236 |  |  | (49) |  |
| U.S. agency mortgage-backed securities | 6 |  |  | — |  |  | 482 |  |  | (66) |  |  | 488 |  |  | (66) |  |
| Total | $ | 1,381 |  |  | $ | (7) |  |  | $ | 2,743 |  |  | $ | (123) |  |  | $ | 4,124 |  |  | $ | (130) |  |

[0000858877-25-000033:notes:141]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 598 |  |  | $ | (2) |  |  | $ | 1,399 |  |  | $ | (26) |  |  | $ | 1,997 |  |  | $ | (28) |  |
| U.S. government agency securities | 89 |  |  | — |  |  | 109 |  |  | (2) |  |  | 198 |  |  | (2) |  |
| Non-U.S. government and agency securities | 17 |  |  | — |  |  | — |  |  | — |  |  | 17 |  |  | — |  |
| Corporate debt securities | 276 |  |  | (1) |  |  | 2,818 |  |  | (115) |  |  | 3,094 |  |  | (116) |  |
| U.S. agency mortgage-backed securities | 238 |  |  | (1) |  |  | 1,438 |  |  | (177) |  |  | 1,676 |  |  | (178) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 1,228 |  |  | $ | (4) |  |  | $ | 5,764 |  |  | $ | (320) |  |  | $ | 6,992 |  |  | $ | (324) |  |

[0000858877-25-000033:notes:142]
The following table summarizes the maturities of our available-for-sale debt investments as of April 26, 2025 (in millions):

[0000858877-25-000033:notes:143]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 3,160 |  |  | $ | 3,118 |  |
| After 1 year through 5 years | 3,622 |  |  | 3,586 |  |
| Mortgage-backed securities with no single maturity | 556 |  |  | 490 |  |
| Total | $ | 7,338 |  |  | $ | 7,194 |  |

[0000858877-25-000033:notes:144]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-25-000033:notes:145]
(b)Summary of Equity Investments

[0000858877-25-000033:notes:146]
We held marketable equity securities of $287 million and $481 million as of April 26, 2025 and July 27, 2024, respectively. We recognized a net unrealized loss of $35 million and $6 million during the third quarter and first nine months of fiscal 2025, respectively, and a net unrealized gain of $20 million and $40 million during the corresponding periods of fiscal 2024, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $2 million and $18 million for the third quarter and first nine months of fiscal 2025, respectively, and a net loss of $21 million and $155 million for the corresponding periods of fiscal 2024. We held equity interests in certain private equity funds of $0.7 billion and $0.8 billion as of April 26, 2025 and July 27, 2024, respectively, which are accounted for under the NAV practical expedient.

[0000858877-25-000033:notes:147]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 26, 2025, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-25-000033:notes:148]
The carrying value of our investments in privately held companies was $2.0 billion and $1.8 billion as of April 26, 2025 and July 27, 2024, respectively. Of the total carrying value of our investments in privately held companies as of April 26, 2025, $0.8 billion of such investments are considered to be in variable interest entities which are not required to be consolidated. As of April 26, 2025, we have total funding commitments of $0.3 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-25-000033:notes:149]
[same as prior period, unchanged from 0000858877-25-000007:notes:149]

[0000858877-25-000033:notes:150]
[same as prior period, unchanged from 0000858877-25-000007:notes:150]

[0000858877-25-000033:notes:151]
|  | APRIL 26, 2025 |  | JULY 27, 2024 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 5,356 |  |  | $ | — |  |  | $ | 5,356 |  |  | $ | 3,334 |  |  | $ | — |  |  | $ | 3,334 |  |
| Commercial paper | — |  |  | 444 |  |  | 444 |  |  | — |  |  | 468 |  |  | 468 |  |
| Corporate debt securities | — |  |  | 4 |  |  | 4 |  |  | — |  |  | 25 |  |  | 25 |  |
| Certificates of deposit | — |  |  | 20 |  |  | 20 |  |  | — |  |  | 14 |  |  | 14 |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 2,068 |  |  | 2,068 |  |  | — |  |  | 2,353 |  |  | 2,353 |  |
| U.S. government agency securities | — |  |  | 77 |  |  | 77 |  |  | — |  |  | 221 |  |  | 221 |  |
| Non-U.S. government and agency securities | — |  |  | 377 |  |  | 377 |  |  | — |  |  | 371 |  |  | 371 |  |
| Corporate debt securities | — |  |  | 3,138 |  |  | 3,138 |  |  | — |  |  | 3,677 |  |  | 3,677 |  |
| U.S. agency mortgage-backed securities | — |  |  | 490 |  |  | 490 |  |  | — |  |  | 1,781 |  |  | 1,781 |  |
| Commercial paper | — |  |  | 436 |  |  | 436 |  |  | — |  |  | 1,023 |  |  | 1,023 |  |
| Certificates of deposit | — |  |  | 608 |  |  | 608 |  |  | — |  |  | 439 |  |  | 439 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 287 |  |  | — |  |  | 287 |  |  | 481 |  |  | — |  |  | 481 |  |
| Other current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 750 |  |  | — |  |  | 750 |  |  | 750 |  |  | — |  |  | 750 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | — |  |  | — |  |  | — |  |  | 563 |  |  | — |  |  | 563 |  |
| Derivative assets | — |  |  | 48 |  |  | 48 |  |  | — |  |  | 64 |  |  | 64 |  |
| Total | $ | 6,393 |  |  | $ | 7,710 |  |  | $ | 14,103 |  |  | $ | 5,128 |  |  | $ | 10,436 |  |  | $ | 15,564 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 35 |  |  | $ | 35 |  |  | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |
| Total | $ | — |  |  | $ | 35 |  |  | $ | 35 |  |  | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |

[0000858877-25-000033:notes:152]
[same as prior period, unchanged from 0000858877-25-000007:notes:152]

[0000858877-25-000033:notes:153]
[same as prior period, unchanged from 0000858877-25-000007:notes:153]

[0000858877-25-000033:notes:154]
[same as prior period, unchanged from 0000858877-25-000007:notes:154]

[0000858877-25-000033:notes:155]
[same as prior period, unchanged from 0000858877-25-000007:notes:155]

[0000858877-25-000033:notes:156]
[same as prior period, unchanged from 0000858877-25-000007:notes:156]

[0000858877-25-000033:notes:157]
The fair value of our short-term loan receivables approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables was $2.9 billion and $2.7 billion as of April 26, 2025 and July 27, 2024, respectively. The estimated fair value of our long-term loan receivables approximates their carrying value. We use unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables, and therefore they are categorized as Level 3.
As of April 26, 2025, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of April 26, 2025, the fair value of our senior notes was $25.5 billion with a carrying amount of $25.1 billion. This compares to a fair value of $20.4 billion and a carrying amount of $20.1 billion as of July 27, 2024. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2.


## us-gaap:DebtDisclosureTextBlock

[0000858877-25-000033:notes:158]
Borrowings 
(a)Short-Term Debt

[0000858877-25-000033:notes:159]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-25-000033:notes:160]
|  | April 26, 2025 |  | July 27, 2024 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 2,247 |  |  | 4.48 | % |  | $ | 488 |  |  | 6.66 | % |
| Commercial paper | 4,174 |  |  | 4.49 | % |  | 10,853 |  |  | 5.43 | % |
| Current portion of other debt | 1 |  |  | 1.13 | % |  | — |  |  | — |  |
| Total | $ | 6,422 |  |  |  |  | $ | 11,341 |  |  |  |

[0000858877-25-000033:notes:161]
We have a short-term debt financing program of up to $15.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-25-000033:notes:162]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-25-000033:notes:163]
(b)Long-Term Debt

[0000858877-25-000033:notes:164]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-25-000033:notes:165]
|  |  |  | April 26, 2025 |  | July 27, 2024 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | 5.67% |  | $ | 500 |  |  | 6.66% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | 4.61% |  | — |  |  | — |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | 4.73% |  | — |  |  | — |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | 4.94% |  | — |  |  | — |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | 5.11% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.50% | February 24, 2055 |  | 750 |  |  | 5.49% |  | — |  |  | — |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 3 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 25,253 |  |  |  |  | 20,253 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (146) |  |  |  |  | (133) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (2) |  |  |  |  | (11) |  |  |  |
| Total |  |  | $ | 25,105 |  |  |  |  | $ | 20,109 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 2,248 |  |  |  |  | $ | 488 |  |  |  |
| Long-term debt |  |  | 22,857 |  |  |  |  | 19,621 |  |  |  |
| Total |  |  | $ | 25,105 |  |  |  |  | $ | 20,109 |  |  |  |

[0000858877-25-000033:notes:166]
In February 2025, we issued senior notes for an aggregate principal amount of $5.0 billion.

[0000858877-25-000033:notes:167]
We entered into an interest rate swap in a prior period with an aggregate notional amount of $0.5 billion designated as a fair value hedge of certain of our fixed-rate senior notes. This swap converts the fixed interest rate of the fixed-rate note to a floating interest rate based on Secured Overnight Financing Rate (SOFR). The gain and loss related to the change in the fair value of the interest rate swap substantially offsets the change in the fair value of the hedged portion of the underlying debt that is attributable to the change in market interest rates. For additional information, see Note 13.

[0000858877-25-000033:notes:168]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 26, 2025, we were in compliance with all debt covenants.

[0000858877-25-000033:notes:169]
As of April 26, 2025, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-25-000033:notes:170]
| Fiscal Year | Amount |
| 2025 (remaining three months) | $ | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | 1,000 |  |
| 2029 | 2,500 |  |
| Thereafter | 16,000 |  |
| Total | $ | 25,253 |  |

[0000858877-25-000033:notes:171]
(c)Credit Facility

[0000858877-25-000033:notes:172]
On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of April 26, 2025, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-25-000033:notes:173]
[same as prior period, unchanged from 0000858877-25-000007:notes:172]

[0000858877-25-000033:notes:174]
[same as prior period, unchanged from 0000858877-25-000007:notes:173]

[0000858877-25-000033:notes:175]
[same as prior period, unchanged from 0000858877-25-000007:notes:174]

[0000858877-25-000033:notes:176]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | April 26,2025 |  | July 27,2024 |  | Balance Sheet Line Item |  | April 26,2025 |  | July 27,2024 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 14 |  |  | $ | 47 |  |  | Other current liabilities |  | $ | 5 |  |  | $ | 1 |  |
| Foreign currency derivatives | Other assets |  | 1 |  |  | 15 |  |  | Other long-term liabilities |  | 14 |  |  | — |  |
| Interest rate derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 2 |  |  | 11 |  |
| Total |  |  | 15 |  |  | 62 |  |  |  |  | 21 |  |  | 12 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 19 |  |  | 2 |  |  | Other current liabilities |  | 13 |  |  | 47 |  |
| Foreign currency derivatives | Other assets |  | 14 |  |  | — |  |  | Other long-term liabilities |  | 1 |  |  | 15 |  |
| Total |  |  | 33 |  |  | 2 |  |  |  |  | 14 |  |  | 62 |  |
| Total |  |  | $ | 48 |  |  | $ | 64 |  |  |  |  | $ | 35 |  |  | $ | 74 |  |

[0000858877-25-000033:notes:177]
[same as prior period, unchanged from 0000858877-25-000007:notes:176]

[0000858877-25-000033:notes:178]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | April 26,2025 |  | July 27,2024 |  | April 26,2025 |  | July 27,2024 |
| Short-term debt |  | $ | (498) |  |  | $ | (488) |  |  | $ | 2 |  |  | $ | 11 |  |

[0000858877-25-000033:notes:179]
[same as prior period, unchanged from 0000858877-25-000007:notes:178]

[0000858877-25-000033:notes:180]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Interest rate derivatives: |  |  |  |  |  |  |  |  |
| Hedged items |  | $ | (2) |  |  | $ | (2) |  |  | $ | (9) |  |  | $ | (25) |  |
| Derivatives designated as hedging instruments |  | 2 |  |  | 2 |  |  | 9 |  |  | 25 |  |
| Total |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000858877-25-000033:notes:181]
[same as prior period, unchanged from 0000858877-25-000007:notes:180]

[0000858877-25-000033:notes:182]
|  |  |  |  | GAINS (LOSSES) FOR THE THREE MONTHS ENDED |  | GAINS (LOSSES) FOR THE NINE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | 163 |  |  | $ | (84) |  |  | $ | 68 |  |  | $ | (161) |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | (105) |  |  | 16 |  |  | (72) |  |  | 33 |  |
| Equity derivatives |  | Other income (loss), net |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Total |  |  |  | $ | 58 |  |  | $ | (68) |  |  | $ | (4) |  |  | $ | (127) |  |

[0000858877-25-000033:notes:183]
[same as prior period, unchanged from 0000858877-25-000007:notes:182]

[0000858877-25-000033:notes:184]
|  | April 26,2025 |  | July 27,2024 |
| Foreign currency derivatives | $ | 7,851 |  |  | $ | 7,434 |  |
| Interest rate derivatives | 500 |  |  | 500 |  |
| Total return swaps—deferred compensation | 947 |  |  | 985 |  |
| Total | $ | 9,298 |  |  | $ | 8,919 |  |

[0000858877-25-000033:notes:185]
[same as prior period, unchanged from 0000858877-25-000007:notes:184]

[0000858877-25-000033:notes:186]
[same as prior period, unchanged from 0000858877-25-000007:notes:185]

[0000858877-25-000033:notes:187]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral provided for was $1 million and $11 million as of April 26, 2025 and July 27, 2024, respectively.

[0000858877-25-000033:notes:188]
[same as prior period, unchanged from 0000858877-25-000007:notes:187]

[0000858877-25-000033:notes:189]
[same as prior period, unchanged from 0000858877-25-000007:notes:188]

[0000858877-25-000033:notes:190]
[same as prior period, unchanged from 0000858877-25-000007:notes:189]

[0000858877-25-000033:notes:191]
[same as prior period, unchanged from 0000858877-25-000007:notes:190]

[0000858877-25-000033:notes:192]
[same as prior period, unchanged from 0000858877-25-000007:notes:191]

[0000858877-25-000033:notes:193]
[same as prior period, unchanged from 0000858877-25-000007:notes:192]

[0000858877-25-000033:notes:194]
[same as prior period, unchanged from 0000858877-25-000007:notes:193]

[0000858877-25-000033:notes:195]
[same as prior period, unchanged from 0000858877-25-000007:notes:194]

[0000858877-25-000033:notes:196]
[same as prior period, unchanged from 0000858877-25-000007:notes:195]

[0000858877-25-000033:notes:197]
[same as prior period, unchanged from 0000858877-25-000007:notes:196]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-25-000033:notes:198]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-25-000033:notes:199]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments are directly with suppliers, and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-25-000033:notes:200]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-25-000033:notes:201]
|  | April 26,2025 |  | July 27,2024 |
| Less than 1 year | $ | 5,773 |  |  | $ | 3,952 |  |
| 1 to 3 years | 509 |  |  | 1,085 |  |
| 3 to 5 years | 63 |  |  | 121 |  |
| Total | $ | 6,345 |  |  | $ | 5,158 |  |

[0000858877-25-000033:notes:202]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 26, 2025 and July 27, 2024, the liability for these purchase commitments was $246 million and $498 million, respectively, and was included in other current liabilities.

[0000858877-25-000033:notes:203]
(b)Other Commitments

[0000858877-25-000033:notes:204]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.3 billion and $0.2 billion as of April 26, 2025 and July 27, 2024, respectively.

[0000858877-25-000033:notes:205]
(c)Product Warranties

[0000858877-25-000033:notes:206]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-25-000033:notes:207]
|  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |
| Balance at beginning of period | $ | 362 |  |  | $ | 329 |  |
| Provisions for warranties issued | 300 |  |  | 316 |  |
| Adjustments for pre-existing warranties | 40 |  |  | 20 |  |
| Settlements | (306) |  |  | (302) |  |
| Balance at end of period | $ | 396 |  |  | $ | 363 |  |

[0000858877-25-000033:notes:208]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-25-000033:notes:209]
(d)Financing and Other Guarantees

[0000858877-25-000033:notes:210]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-25-000033:notes:211]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $5.9 billion and $6.1 billion for the third quarter of fiscal 2025 and 2024, respectively, and $18.1 billion and $20.9 billion for the first nine months of fiscal 2025 and 2024, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion as of each of April 26, 2025 and July 27, 2024.

[0000858877-25-000033:notes:212]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at April 26, 2025 and July 27, 2024, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-25-000033:notes:213]
|  | April 26,2025 |  | July 27,2024 |
| Maximum potential future payments | $ | 116 |  |  | $ | 127 |  |
| Deferred revenue | (10) |  |  | (13) |  |
| Total | $ | 106 |  |  | $ | 114 |  |

[0000858877-25-000033:notes:214]
(e)Indemnifications

[0000858877-25-000033:notes:215]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-25-000033:notes:216]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-25-000033:notes:217]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-25-000033:notes:218]
(f)Legal Proceedings

[0000858877-25-000033:notes:219]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The remaining asserted claims by Brazilian federal tax authorities are for calendar years 2004 through 2007, and the remaining asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total remaining asserted claims by Brazilian state and federal tax authorities aggregate to $138 million for the alleged evasion of import and other taxes, $788 million for interest, and $282 million for various penalties, all determined using an exchange rate as of April 26, 2025.

[0000858877-25-000033:notes:220]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-25-000033:notes:221]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. After two bench trials and various administrative actions and appeals, we have been found either to not have infringed any of the patents or the patents have been invalidated. Centripetal appealed one of the invalidity decisions and we are awaiting the decision following the Federal Circuit hearing on that appeal on February 6, 2025. Centripetal’s appeal of the non-infringement judgment of the District Court is ongoing.

[0000858877-25-000033:notes:222]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringed three patents, one patent was invalidated, and the utility model was invalidated. The infringement action on the final patent is stayed due to an invalidity action heard on June 6, 2024 in the Federal Patent Court, in which all claims, aside from one auxiliary claim, were found invalid, and for which we are awaiting the entry of judgment from the Federal Patent Court. Centripetal’s appeals of two of the non-infringement findings remain pending and, on March 27, 2024, the Court of Appeals rejected Centripetal’s appeal of the third non-infringement finding.

[0000858877-25-000033:notes:223]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement. We have filed our response and defenses to the complaint and the case briefing is ongoing. While the Court has not set a final hearing date, we anticipate that it will occur in the third calendar quarter of 2026.

[0000858877-25-000033:notes:224]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of the litigations at this time. If we do not prevail in these litigations, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-25-000033:notes:225]
Ramot     On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents and those proceedings are ongoing. The Court set trial in the D. Del. cases for November 3, 2025.

[0000858877-25-000033:notes:226]
While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-25-000033:notes:227]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023. The Federal Circuit heard oral argument on October 11, 2024 and we are awaiting the decision.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-25-000033:notes:228]
Purchase Commitments with Contract Manufacturers and Suppliers We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments are directly with suppliers, and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-25-000033:notes:229]
[same as prior period, unchanged from 0000858877-25-000007:notes:228]

[0000858877-25-000033:notes:230]
In September 2001, our Board of Directors authorized a stock repurchase program. As of April 26, 2025, the remaining authorized amount for stock repurchases under this program was approximately $15.4 billion, with no termination date. The stock repurchase activity for fiscal 2025 and 2024 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-25-000033:notes:231]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2025 |  |  |  |  |  |  |
| April 26, 2025 |  | 25 |  |  | $ | 59.78 |  |  | $ | 1,504 |  |
| January 25, 2025 |  | 21 |  |  | $ | 58.58 |  |  | $ | 1,236 |  |
| October 26, 2024 |  | 40 |  |  | $ | 49.56 |  |  | $ | 2,003 |  |
| Fiscal 2024 |  |  |  |  |  |  |
| July 27, 2024 |  | 43 |  |  | $ | 46.80 |  |  | $ | 2,002 |  |
| April 27, 2024 |  | 26 |  |  | $ | 49.22 |  |  | $ | 1,256 |  |
| January 27, 2024 |  | 25 |  |  | $ | 49.54 |  |  | $ | 1,254 |  |
| October 28, 2023 |  | 23 |  |  | $ | 54.53 |  |  | $ | 1,252 |  |

[0000858877-25-000033:notes:232]
There were stock repurchases of $20 million and $25 million that were pending settlement April 26, 2025 and July 27, 2024, respectively.

[0000858877-25-000033:notes:233]
[same as prior period, unchanged from 0000858877-25-000007:notes:232]

[0000858877-25-000033:notes:234]
[same as prior period, unchanged from 0000858877-25-000007:notes:233]

[0000858877-25-000033:notes:235]
On May 14, 2025, our Board of Directors declared a quarterly dividend of $0.41 per common share to be paid on July 23, 2025, to all stockholders of record as of the close of business on July 3, 2025. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-25-000033:notes:236]
[same as prior period, unchanged from 0000858877-25-000007:notes:235]

[0000858877-25-000033:notes:237]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock in one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights, if any, of such series, and any qualifications, limitations or restrictions thereof, of the shares of such series. As of April 26, 2025, we have not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-25-000033:notes:238]
[same as prior period, unchanged from 0000858877-25-000007:notes:237]

[0000858877-25-000033:notes:239]
[same as prior period, unchanged from 0000858877-25-000007:notes:238]

[0000858877-25-000033:notes:240]
The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions. Time-based and performance-based RSUs generally vest over three years with certain awards containing retirement eligible provisions. Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and

[0000858877-25-000033:notes:241]
non-employee directors of Cisco are eligible to participate in the 2005 Plan. The 2005 Plan may be terminated by our Board of Directors at any time and for any reason, and is currently set to terminate at the 2030 Annual Meeting unless re-adopted or extended by our stockholders prior to or on such date.

[0000858877-25-000033:notes:242]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of April 26, 2025, 115 million shares were authorized for future grant under the 2005 Plan.

[0000858877-25-000033:notes:243]
[same as prior period, unchanged from 0000858877-25-000007:notes:241]

[0000858877-25-000033:notes:244]
We have an Employee Stock Purchase Plan under which eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. No shares were issued under the Employee Stock Purchase Plan during the third quarter of each of fiscal 2025 and 2024. We issued 8 million shares during the first nine months of fiscal 2025 and 10 million shares during the first nine months of fiscal 2024. As of April 26, 2025, 60 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-25-000033:notes:245]
[same as prior period, unchanged from 0000858877-25-000007:notes:243]

[0000858877-25-000033:notes:246]
Share-based compensation expense consists of expenses for RSUs and stock purchase rights, granted to employees or assumed from acquisitions. The following table summarizes share-based compensation expense and the income tax benefit for share-based compensation (in millions):

[0000858877-25-000033:notes:247]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Cost of sales—product | $ | 67 |  |  | $ | 57 |  |  | $ | 189 |  |  | $ | 157 |  |
| Cost of sales—services | 85 |  |  | 82 |  |  | 245 |  |  | 224 |  |
| Share-based compensation expense in cost of sales | 152 |  |  | 139 |  |  | 434 |  |  | 381 |  |
| Research and development | 422 |  |  | 349 |  |  | 1,189 |  |  | 967 |  |
| Sales and marketing | 235 |  |  | 221 |  |  | 676 |  |  | 628 |  |
| General and administrative | 121 |  |  | 95 |  |  | 357 |  |  | 282 |  |
| Restructuring and other charges | 15 |  |  | 7 |  |  | 37 |  |  | 16 |  |
| Share-based compensation expense in operating expenses | 793 |  |  | 672 |  |  | 2,259 |  |  | 1,893 |  |
| Total share-based compensation expense | $ | 945 |  |  | $ | 811 |  |  | $ | 2,693 |  |  | $ | 2,274 |  |
| Income tax benefit for share-based compensation | $ | 218 |  |  | $ | 179 |  |  | $ | 616 |  |  | $ | 524 |  |

[0000858877-25-000033:notes:248]
As of April 26, 2025, the total compensation cost related to unvested share-based awards not yet recognized was $4.4 billion which is expected to be recognized over approximately 1.7 years on a weighted-average basis.

[0000858877-25-000033:notes:249]
[same as prior period, unchanged from 0000858877-25-000007:notes:247]

[0000858877-25-000033:notes:250]
[same as prior period, unchanged from 0000858877-25-000007:notes:248]

[0000858877-25-000033:notes:251]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| Unvested balance at July 29, 2023 | 122 |  |  | $ | 44.04 |  |  |  |
| Granted and assumed | 63 |  |  | 48.97 |  |  |  |
| Vested | (58) |  |  | 43.46 |  |  | $ | 2,906 |  |
| Canceled/forfeited/other | (10) |  |  | 45.65 |  |  |  |
| Unvested balance at July 27, 2024 | 117 |  |  | $ | 46.86 |  |  |  |
| Granted and assumed | 53 |  |  | 53.69 |  |  |  |
| Vested | (52) |  |  | 47.38 |  |  | $ | 2,664 |  |
| Canceled/forfeited/other | (8) |  |  | 47.37 |  |  |  |
| Unvested balance at April 26, 2025 | 110 |  |  | $ | 49.87 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-25-000033:notes:252]
Accumulated Other Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first nine months of fiscal 2025 and 2024 are summarized as follows (in millions):

[0000858877-25-000033:notes:253]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 27, 2024 | $ | (241) |  |  | $ | 79 |  |  | $ | (1,268) |  |  | $ | (1,430) |  |
| Other comprehensive income (loss) before reclassifications | 126 |  |  | (5) |  |  | 188 |  |  | 309 |  |
| (Gains) losses reclassified out of AOCI | 75 |  |  | (39) |  |  | — |  |  | 36 |  |
| Tax benefit (expense) | (58) |  |  | 10 |  |  | — |  |  | (48) |  |
| Balance at April 26, 2025 | $ | (98) |  |  | $ | 45 |  |  | $ | (1,080) |  |  | $ | (1,133) |  |

[0000858877-25-000033:notes:254]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 29, 2023 | $ | (440) |  |  | $ | 18 |  |  | $ | (1,153) |  |  | $ | (1,575) |  |
| Other comprehensive income (loss) before reclassifications | 74 |  |  | 122 |  |  | (223) |  |  | (27) |  |
| (Gains) losses reclassified out of AOCI | 57 |  |  | (36) |  |  | (2) |  |  | 19 |  |
| Tax benefit (expense) | (26) |  |  | (20) |  |  | (1) |  |  | (47) |  |
| Balance at April 27, 2024 | $ | (335) |  |  | $ | 84 |  |  | $ | (1,379) |  |  | $ | (1,630) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-25-000033:notes:255]
[same as prior period, unchanged from 0000858877-25-000007:notes:253]

[0000858877-25-000033:notes:256]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Income before provision for income taxes | $ | 2,947 |  |  | $ | 2,235 |  |  | $ | 8,101 |  |  | $ | 9,838 |  |
| Provision for income taxes | $ | 456 |  |  | $ | 349 |  |  | $ | 471 |  |  | $ | 1,680 |  |
| Effective tax rate | 15.5 | % |  | 15.6 | % |  | 5.8 | % |  | 17.1 | % |

[0000858877-25-000033:notes:257]
As of April 26, 2025, we had $2.2 billion of unrecognized tax benefits, of which $1.6 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.

[0000858877-25-000033:notes:258]
[same as prior period, unchanged from 0000858877-25-000007:notes:256]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-25-000033:notes:259]
[same as prior period, unchanged from 0000858877-25-000007:notes:257]

[0000858877-25-000033:notes:260]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-25-000033:notes:261]
Summarized financial information by segment for the third quarter and first nine months of fiscal 2025 and 2024, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-25-000033:notes:262]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 8,380 |  |  | $ | 7,372 |  |  | $ | 24,834 |  |  | $ | 23,904 |  |
| EMEA | 3,736 |  |  | 3,458 |  |  | 11,179 |  |  | 10,606 |  |
| APJC | 2,034 |  |  | 1,873 |  |  | 5,968 |  |  | 5,652 |  |
| Total | $ | 14,149 |  |  | $ | 12,702 |  |  | $ | 41,981 |  |  | $ | 40,161 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 5,676 |  |  | $ | 5,006 |  |  | $ | 16,960 |  |  | $ | 15,906 |  |
| EMEA | 2,659 |  |  | 2,406 |  |  | 7,931 |  |  | 7,324 |  |
| APJC | 1,367 |  |  | 1,262 |  |  | 4,016 |  |  | 3,816 |  |
| Segment total | 9,703 |  |  | 8,673 |  |  | 28,907 |  |  | 27,046 |  |
| Unallocated corporate items | (425) |  |  | (400) |  |  | (1,397) |  |  | (999) |  |
| Total | $ | 9,278 |  |  | $ | 8,273 |  |  | $ | 27,510 |  |  | $ | 26,047 |  |

[0000858877-25-000033:notes:263]
Revenue in the United States was $7.6 billion and $6.6 billion for the third quarter of fiscal 2025 and 2024, respectively, and $22.4 billion and $21.4 billion for the first nine months of fiscal 2025 and 2024, respectively.

[0000858877-25-000033:notes:264]
[same as prior period, unchanged from 0000858877-25-000007:notes:262]

[0000858877-25-000033:notes:265]
[same as prior period, unchanged from 0000858877-25-000007:notes:263]


## us-gaap:EarningsPerShareTextBlock

[0000858877-25-000033:notes:266]
[same as prior period, unchanged from 0000858877-25-000007:notes:264]

[0000858877-25-000033:notes:267]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Net income | $ | 2,491 |  |  | $ | 1,886 |  |  | $ | 7,630 |  |  | $ | 8,158 |  |
| Weighted-average shares—basic | 3,972 |  |  | 4,042 |  |  | 3,981 |  |  | 4,051 |  |
| Effect of dilutive potential common shares | 30 |  |  | 18 |  |  | 23 |  |  | 20 |  |
| Weighted-average shares—diluted | 4,002 |  |  | 4,060 |  |  | 4,004 |  |  | 4,071 |  |
| Net income per share—basic | $ | 0.63 |  |  | $ | 0.47 |  |  | $ | 1.92 |  |  | $ | 2.01 |  |
| Net income per share—diluted | $ | 0.62 |  |  | $ | 0.46 |  |  | $ | 1.91 |  |  | $ | 2.00 |  |
| Antidilutive employee share-based awards, excluded | 11 |  |  | 11 |  |  | 61 |  |  | 58 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000858877-25-000033:notes:268]
On February 26, 2025, M. Victoria Wong, Cisco’s Senior Vice President and Chief Accounting Officer, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Ms. Wong’s trading plan provides for the sale of 37,238 gross shares (with any shares underlying performance-based equity awards being calculated at target), plus any related dividend-equivalent shares earned with respect to such shares and shares from purchases made pursuant to Cisco's employee stock purchase plan, and excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Ms. Wong’s trading plan is scheduled to terminate on March 20, 2026, subject to early termination for certain specified events set forth therein.

[0000858877-25-000033:notes:269]
On March 6, 2025, Charles H. Robbins, Cisco’s Chair and Chief Executive Officer, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Mr. Robbins’ trading plan provides for the sale of 1,003,688 gross shares (with any shares underlying performance-based equity awards being calculated at target), plus any related dividend-equivalent shares earned with respect to such shares and shares from purchases made pursuant to Cisco’s employee stock purchase plan, and excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Mr. Robbins’ trading plan is scheduled to terminate on March 20, 2026, subject to early termination for certain specified events set forth therein.

[0000858877-25-000033:notes:270]
On March 18, 2025, R. Scott Herren, Cisco’s Executive Vice President and Chief Financial Officer, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Mr. Herren’s trading plan provides for the sale of 450,992 gross shares (with any shares underlying performance-based equity awards being calculated at target), plus any related dividend-equivalent shares earned with respect to such shares and excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Mr. Herren’s trading plan is scheduled to terminate on March 20, 2026, subject to early termination for certain specified events set forth therein.

[0000858877-25-000033:notes:271]
On March 18, 2025, Thimaya Subaiya, Cisco’s Executive Vice President, Operations, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Mr. Subaiya’s trading plan provides for the sale of 158,190 gross shares (with any shares underlying performance-based equity awards being calculated at target), plus any related dividend-equivalent shares earned with respect to such shares and shares from purchases made pursuant to Cisco’s employee stock purchase plan, and excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Mr. Subaiya’s trading plan is scheduled to terminate on March 20, 2026, subject to early termination for certain specified events set forth therein.
