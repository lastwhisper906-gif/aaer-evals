# CSCO note change history — 0000858877-25-000007 → 0000858877-25-000033


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0000858877-25-000033:note_history:1]
|  | April 26,2025 |  | July 27,2024 |
| Less than 1 year | $ | 5,773 |  |  | $ | 3,952 |  |
| 1 to 3 years | 509 |  |  | 1,085 |  |
| 3 to 5 years | 63 |  |  | 121 |  |
| Total | $ | 6,345 |  |  | $ | 5,158 |  |
  (was, 2025-02-18, similarity 0.9753):
[0000858877-25-000007:note_history:1]
|  | January 25,2025 |  | July 27,2024 |
| Less than 1 year | $ | 5,054 |  |  | $ | 3,952 |  |
| 1 to 3 years | 681 |  |  | 1,085 |  |
| 3 to 5 years | 89 |  |  | 121 |  |
| Total | $ | 5,824 |  |  | $ | 5,158 |  |

- changed (2025-05-20):
[0000858877-25-000033:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 26, 2025 and July 27, 2024, the liability for these purchase commitments was $246 million and $498 million, respectively, and was included in other current liabilities.
  (was, 2025-02-18, similarity 0.6941):
[0000858877-25-000007:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 25, 2025 and July 27, 2024, the liability for these purchase commitments was $383 million and $498 million, respectively, and was included in other current liabilities.

- changed (2025-05-20):
[0000858877-25-000033:note_history:3]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.3 billion and $0.2 billion as of April 26, 2025 and July 27, 2024, respectively.
  (was, 2025-02-18, similarity 0.8732):
[0000858877-25-000007:note_history:3]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.2 billion as of each of January 25, 2025 and July 27, 2024.

- changed (2025-05-20):
[0000858877-25-000033:note_history:4]
|  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |
| Balance at beginning of period | $ | 362 |  |  | $ | 329 |  |
| Provisions for warranties issued | 300 |  |  | 316 |  |
| Adjustments for pre-existing warranties | 40 |  |  | 20 |  |
| Settlements | (306) |  |  | (302) |  |
| Balance at end of period | $ | 396 |  |  | $ | 363 |  |
  (was, 2025-02-18, similarity 0.9254):
[0000858877-25-000007:note_history:4]
|  | Six Months Ended |
|  | January 25,2025 |  | January 27,2024 |
| Balance at beginning of period | $ | 362 |  |  | $ | 329 |  |
| Provisions for warranties issued | 198 |  |  | 198 |  |
| Adjustments for pre-existing warranties | 37 |  |  | 5 |  |
| Settlements | (203) |  |  | (205) |  |
| Balance at end of period | $ | 394 |  |  | $ | 327 |  |

- changed (2025-05-20):
[0000858877-25-000033:note_history:5]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $5.9 billion and $6.1 billion for the third quarter of fiscal 2025 and 2024, respectively, and $18.1 billion and $20.9 billion for the first nine months of fiscal 2025 and 2024, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion as of each of April 26, 2025 and July 27, 2024.
  (was, 2025-02-18, similarity 0.9277):
[0000858877-25-000007:note_history:5]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.2 billion and $6.6 billion for the second quarter of fiscal 2025 and 2024, respectively, and $12.2 billion and $14.8 billion for the first six months of fiscal 2025 and 2024, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.2 billion as of January 25, 2025 and July 27, 2024, respectively.

- changed (2025-05-20):
[0000858877-25-000033:note_history:6]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at April 26, 2025 and July 27, 2024, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2025-02-18, similarity 0.9817):
[0000858877-25-000007:note_history:6]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at January 25, 2025 and July 27, 2024, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2025-05-20):
[0000858877-25-000033:note_history:7]
|  | April 26,2025 |  | July 27,2024 |
| Maximum potential future payments | $ | 116 |  |  | $ | 127 |  |
| Deferred revenue | (10) |  |  | (13) |  |
| Total | $ | 106 |  |  | $ | 114 |  |
  (was, 2025-02-18, similarity 0.9744):
[0000858877-25-000007:note_history:7]
|  | January 25,2025 |  | July 27,2024 |
| Maximum potential future payments | $ | 125 |  |  | $ | 127 |  |
| Deferred revenue | (13) |  |  | (13) |  |
| Total | $ | 112 |  |  | $ | 114 |  |

- changed (2025-05-20):
[0000858877-25-000033:note_history:8]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The remaining asserted claims by Brazilian federal tax authorities are for calendar years 2004 through 2007, and the remaining asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total remaining asserted claims by Brazilian state and federal tax authorities aggregate to $138 million for the alleged evasion of import and other taxes, $788 million for interest, and $282 million for various penalties, all determined using an exchange rate as of April 26, 2025.
  (was, 2025-02-18, similarity 0.9826):
[0000858877-25-000007:note_history:8]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $137 million for the alleged evasion of import and other taxes, $768 million for interest, and $276 million for various penalties, all determined using an exchange rate as of January 25, 2025.

- changed (2025-05-20):
[0000858877-25-000033:note_history:9]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023. The Federal Circuit heard oral argument on October 11, 2024 and we are awaiting the decision.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements.
  (was, 2025-02-18, similarity 0.9314):
[0000858877-25-000007:note_history:9]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023. The Federal Circuit heard oral argument on October 11, 2024 and we are awaiting the decision.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0000858877-25-000033:note_history:10]
We have prepared the accompanying financial data as of April 26, 2025 and for the third quarter and first nine months of fiscal 2025 and 2024, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2024 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2024.
  (was, 2025-02-18, similarity 0.9861):
[0000858877-25-000007:note_history:10]
We have prepared the accompanying financial data as of January 25, 2025 and for the second quarter and first six months of fiscal 2025 and 2024, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2024 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2024.

- changed (2025-05-20):
[0000858877-25-000033:note_history:11]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of April 26, 2025, the results of operations, the statements of comprehensive income and the statements of equity for the third quarter and first nine months of fiscal 2025 and 2024, and the statements of cash flows for the first nine months of fiscal 2025 and 2024, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2025 are not necessarily indicative of the operating results for the full fiscal year or any future periods.
  (was, 2025-02-18, similarity 0.9565):
[0000858877-25-000007:note_history:11]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of January 25, 2025, the results of operations, the statements of comprehensive income and the statements of equity for the second quarter and first six months of fiscal 2025 and 2024, and the statements of cash flows for the first six months of fiscal 2025 and 2024, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2025 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0000858877-25-000033:note_history:12]
|  | April 26, 2025 |  | July 27, 2024 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 2,247 |  |  | 4.48 | % |  | $ | 488 |  |  | 6.66 | % |
| Commercial paper | 4,174 |  |  | 4.49 | % |  | 10,853 |  |  | 5.43 | % |
| Current portion of other debt | 1 |  |  | 1.13 | % |  | — |  |  | — |  |
| Total | $ | 6,422 |  |  |  |  | $ | 11,341 |  |  |  |
  (was, 2025-02-18, similarity 0.9818):
[0000858877-25-000007:note_history:12]
|  | January 25, 2025 |  | July 27, 2024 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 496 |  |  | 5.66 | % |  | $ | 488 |  |  | 6.66 | % |
| Commercial paper | 10,916 |  |  | 4.75 | % |  | 10,853 |  |  | 5.43 | % |
| Current portion of other debt | 1 |  |  | 1.13 | % |  | — |  |  | — |  |
| Total | $ | 11,413 |  |  |  |  | $ | 11,341 |  |  |  |

- changed (2025-05-20):
[0000858877-25-000033:note_history:13]
|  |  |  | April 26, 2025 |  | July 27, 2024 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | 5.67% |  | $ | 500 |  |  | 6.66% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | 4.61% |  | — |  |  | — |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | 4.73% |  | — |  |  | — |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | 4.94% |  | — |  |  | — |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | 5.11% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.50% | February 24, 2055 |  | 750 |  |  | 5.49% |  | — |  |  | — |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 3 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 25,253 |  |  |  |  | 20,253 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (146) |  |  |  |  | (133) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (2) |  |  |  |  | (11) |  |  |  |
| Total |  |  | $ | 25,105 |  |  |  |  | $ | 20,109 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 2,248 |  |  |  |  | $ | 488 |  |  |  |
| Long-term debt |  |  | 22,857 |  |  |  |  | 19,621 |  |  |  |
| Total |  |  | $ | 25,105 |  |  |  |  | $ | 20,109 |  |  |  |
  (was, 2025-02-18, similarity 0.8479):
[0000858877-25-000007:note_history:13]
|  |  |  | January 25, 2025 |  | July 27, 2024 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | 5.66% |  | $ | 500 |  |  | 6.66% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 3 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 20,253 |  |  |  |  | 20,253 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (127) |  |  |  |  | (133) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (4) |  |  |  |  | (11) |  |  |  |
| Total |  |  | $ | 20,122 |  |  |  |  | $ | 20,109 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 497 |  |  |  |  | $ | 488 |  |  |  |
| Long-term debt |  |  | 19,625 |  |  |  |  | 19,621 |  |  |  |
| Total |  |  | $ | 20,122 |  |  |  |  | $ | 20,109 |  |  |  |

- added (2025-05-20):
[0000858877-25-000033:note_history:14]
In February 2025, we issued senior notes for an aggregate principal amount of $5.0 billion.

- changed (2025-05-20):
[0000858877-25-000033:note_history:15]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 26, 2025, we were in compliance with all debt covenants.
  (was, 2025-02-18, similarity 0.9859):
[0000858877-25-000007:note_history:15]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 25, 2025, we were in compliance with all debt covenants.

- changed (2025-05-20):
[0000858877-25-000033:note_history:16]
As of April 26, 2025, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2025-02-18, similarity 0.9701):
[0000858877-25-000007:note_history:16]
As of January 25, 2025, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2025-05-20):
[0000858877-25-000033:note_history:17]
| Fiscal Year | Amount |
| 2025 (remaining three months) | $ | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | 1,000 |  |
| 2029 | 2,500 |  |
| Thereafter | 16,000 |  |
| Total | $ | 25,253 |  |
  (was, 2025-02-18, similarity 0.9673):
[0000858877-25-000007:note_history:17]
| Fiscal Year | Amount |
| 2025 (remaining six months) | $ | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | — |  |
| 2029 | 2,500 |  |
| Thereafter | 12,000 |  |
| Total | $ | 20,253 |  |

- changed (2025-05-20):
[0000858877-25-000033:note_history:18]
On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of April 26, 2025, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.
  (was, 2025-02-18, similarity 0.9576):
[0000858877-25-000007:note_history:18]
On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of January 25, 2025, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0000858877-25-000033:note_history:19]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 26, 2025 and July 27, 2024 (in millions):
  (was, 2025-02-18, similarity 0.9716):
[0000858877-25-000007:note_history:19]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 25, 2025 and July 27, 2024 (in millions):

- changed (2025-05-20):
[0000858877-25-000033:note_history:20]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 26, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 970 |  |  | $ | (6) |  |  | $ | 313 |  |  | $ | (9) |  |  | $ | 1,283 |  |  | $ | (15) |  |
| U.S. government agency securities | 10 |  |  | — |  |  | 31 |  |  | — |  |  | 41 |  |  | — |  |
| Non-U.S. government and agency securities | 76 |  |  | — |  |  | — |  |  | — |  |  | 76 |  |  | — |  |
| Corporate debt securities | 319 |  |  | (1) |  |  | 1,917 |  |  | (48) |  |  | 2,236 |  |  | (49) |  |
| U.S. agency mortgage-backed securities | 6 |  |  | — |  |  | 482 |  |  | (66) |  |  | 488 |  |  | (66) |  |
| Total | $ | 1,381 |  |  | $ | (7) |  |  | $ | 2,743 |  |  | $ | (123) |  |  | $ | 4,124 |  |  | $ | (130) |  |
  (was, 2025-02-18, similarity 0.9027):
[0000858877-25-000007:note_history:20]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 25, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,431 |  |  | $ | (17) |  |  | $ | 387 |  |  | $ | (12) |  |  | $ | 1,818 |  |  | $ | (29) |  |
| U.S. government agency securities | 30 |  |  | — |  |  | 48 |  |  | (1) |  |  | 78 |  |  | (1) |  |
| Corporate debt securities | 281 |  |  | (2) |  |  | 2,193 |  |  | (63) |  |  | 2,474 |  |  | (65) |  |
| U.S. agency mortgage-backed securities | 8 |  |  | — |  |  | 728 |  |  | (111) |  |  | 736 |  |  | (111) |  |
| Total | $ | 1,750 |  |  | $ | (19) |  |  | $ | 3,356 |  |  | $ | (187) |  |  | $ | 5,106 |  |  | $ | (206) |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0000858877-25-000033:note_history:21]
| April 26, 2025 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,079 |  |  | $ | 4 |  |  | $ | (15) |  |  | $ | 2,068 |  |
| U.S. government agency securities | 77 |  |  | — |  |  | — |  |  | 77 |  |
| Non-U.S. government and agency securities | 376 |  |  | 1 |  |  | — |  |  | 377 |  |
| Corporate debt securities | 3,206 |  |  | 7 |  |  | (75) |  |  | 3,138 |  |
| U.S. agency mortgage-backed securities | 556 |  |  | — |  |  | (66) |  |  | 490 |  |
| Commercial paper | 436 |  |  | — |  |  | — |  |  | 436 |  |
| Certificates of deposit | 608 |  |  | — |  |  | — |  |  | 608 |  |
| Total | $ | 7,338 |  |  | $ | 12 |  |  | $ | (156) |  |  | $ | 7,194 |  |
  (was, 2025-02-18, similarity 0.6472):
[0000858877-25-000007:note_history:21]
| January 25, 2025 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,177 |  |  | $ | — |  |  | $ | (29) |  |  | $ | 2,148 |  |
| U.S. government agency securities | 112 |  |  | — |  |  | (1) |  |  | 111 |  |
| Non-U.S. government and agency securities | 363 |  |  | 1 |  |  | — |  |  | 364 |  |
| Corporate debt securities | 3,292 |  |  | 6 |  |  | (94) |  |  | 3,204 |  |
| U.S. agency mortgage-backed securities | 847 |  |  | — |  |  | (111) |  |  | 736 |  |
| Commercial paper | 732 |  |  | — |  |  | — |  |  | 732 |  |
| Certificates of deposit | 663 |  |  | — |  |  | — |  |  | 663 |  |
| Total | $ | 8,186 |  |  | $ | 7 |  |  | $ | (235) |  |  | $ | 7,958 |  |

- changed (2025-05-20):
[0000858877-25-000033:note_history:22]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Gross realized gains | $ | 1 |  |  | $ | 2 |  |  | $ | 9 |  |  | $ | 7 |  |
| Gross realized losses | (31) |  |  | (16) |  |  | $ | (84) |  |  | $ | (64) |  |
| Total | $ | (30) |  |  | $ | (14) |  |  | $ | (75) |  |  | $ | (57) |  |
  (was, 2025-02-18, similarity 0.8192):
[0000858877-25-000007:note_history:22]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2025 |  | January 27, 2024 |  | January 25, 2025 |  | January 27, 2024 |
| Gross realized gains | $ | — |  |  | $ | 5 |  |  | $ | 8 |  |  | $ | 5 |  |
| Gross realized losses | (20) |  |  | (28) |  |  | (53) |  |  | $ | (48) |  |
| Total | $ | (20) |  |  | $ | (23) |  |  | $ | (45) |  |  | $ | (43) |  |

- changed (2025-05-20):
[0000858877-25-000033:note_history:23]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 26, 2025 and July 27, 2024 (in millions):
  (was, 2025-02-18, similarity 0.9716):
[0000858877-25-000007:note_history:23]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 25, 2025 and July 27, 2024 (in millions):

- changed (2025-05-20):
[0000858877-25-000033:note_history:24]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 26, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 970 |  |  | $ | (6) |  |  | $ | 313 |  |  | $ | (9) |  |  | $ | 1,283 |  |  | $ | (15) |  |
| U.S. government agency securities | 10 |  |  | — |  |  | 31 |  |  | — |  |  | 41 |  |  | — |  |
| Non-U.S. government and agency securities | 76 |  |  | — |  |  | — |  |  | — |  |  | 76 |  |  | — |  |
| Corporate debt securities | 319 |  |  | (1) |  |  | 1,917 |  |  | (48) |  |  | 2,236 |  |  | (49) |  |
| U.S. agency mortgage-backed securities | 6 |  |  | — |  |  | 482 |  |  | (66) |  |  | 488 |  |  | (66) |  |
| Total | $ | 1,381 |  |  | $ | (7) |  |  | $ | 2,743 |  |  | $ | (123) |  |  | $ | 4,124 |  |  | $ | (130) |  |
  (was, 2025-02-18, similarity 0.9027):
[0000858877-25-000007:note_history:24]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 25, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,431 |  |  | $ | (17) |  |  | $ | 387 |  |  | $ | (12) |  |  | $ | 1,818 |  |  | $ | (29) |  |
| U.S. government agency securities | 30 |  |  | — |  |  | 48 |  |  | (1) |  |  | 78 |  |  | (1) |  |
| Corporate debt securities | 281 |  |  | (2) |  |  | 2,193 |  |  | (63) |  |  | 2,474 |  |  | (65) |  |
| U.S. agency mortgage-backed securities | 8 |  |  | — |  |  | 728 |  |  | (111) |  |  | 736 |  |  | (111) |  |
| Total | $ | 1,750 |  |  | $ | (19) |  |  | $ | 3,356 |  |  | $ | (187) |  |  | $ | 5,106 |  |  | $ | (206) |  |

- changed (2025-05-20):
[0000858877-25-000033:note_history:25]
The following table summarizes the maturities of our available-for-sale debt investments as of April 26, 2025 (in millions):
  (was, 2025-02-18, similarity 0.9667):
[0000858877-25-000007:note_history:25]
The following table summarizes the maturities of our available-for-sale debt investments as of January 25, 2025 (in millions):

- changed (2025-05-20):
[0000858877-25-000033:note_history:26]
We held marketable equity securities of $287 million and $481 million as of April 26, 2025 and July 27, 2024, respectively. We recognized a net unrealized loss of $35 million and $6 million during the third quarter and first nine months of fiscal 2025, respectively, and a net unrealized gain of $20 million and $40 million during the corresponding periods of fiscal 2024, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $2 million and $18 million for the third quarter and first nine months of fiscal 2025, respectively, and a net loss of $21 million and $155 million for the corresponding periods of fiscal 2024. We held equity interests in certain private equity funds of $0.7 billion and $0.8 billion as of April 26, 2025 and July 27, 2024, respectively, which are accounted for under the NAV practical expedient.
  (was, 2025-02-18, similarity 0.8867):
[0000858877-25-000007:note_history:26]
We held marketable equity securities of $339 million and $481 million as of January 25, 2025 and July 27, 2024, respectively. We recognized a net unrealized gain of $16 million and $36 million during the second quarter and first six months of fiscal 2025, respectively, and a net unrealized gain of $55 million and $17 million during the corresponding periods of fiscal 2024, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $8 million and $16 million for the second quarter and first six months of fiscal 2025, respectively, and a net loss of $134 million for each of the corresponding periods of fiscal 2024. We held equity interests in certain private equity funds of $0.7 billion and $0.8 billion as of January 25, 2025 and July 27, 2024, respectively, which are accounted for under the NAV practical expedient.

- changed (2025-05-20):
[0000858877-25-000033:note_history:27]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 26, 2025, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2025-02-18, similarity 0.9895):
[0000858877-25-000007:note_history:27]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 25, 2025, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- changed (2025-05-20):
[0000858877-25-000033:note_history:28]
The carrying value of our investments in privately held companies was $2.0 billion and $1.8 billion as of April 26, 2025 and July 27, 2024, respectively. Of the total carrying value of our investments in privately held companies as of April 26, 2025, $0.8 billion of such investments are considered to be in variable interest entities which are not required to be consolidated. As of April 26, 2025, we have total funding commitments of $0.3 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.
  (was, 2025-02-18, similarity 0.9567):
[0000858877-25-000007:note_history:28]
The carrying value of our investments in privately held companies was $1.9 billion and $1.8 billion as of January 25, 2025 and July 27, 2024, respectively. Of the total carrying value of our investments in privately held companies as of January 25, 2025, $0.8 billion of such investments are considered to be in variable interest entities which are not required to be consolidated. As of January 25, 2025, we have total funding commitments of $0.2 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0000858877-25-000033:note_history:29]
|  |  |  | April 26, 2025 |  | July 27, 2024 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | 5.67% |  | $ | 500 |  |  | 6.66% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | 4.61% |  | — |  |  | — |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | 4.73% |  | — |  |  | — |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | 4.94% |  | — |  |  | — |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | 5.11% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.50% | February 24, 2055 |  | 750 |  |  | 5.49% |  | — |  |  | — |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 3 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 25,253 |  |  |  |  | 20,253 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (146) |  |  |  |  | (133) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (2) |  |  |  |  | (11) |  |  |  |
| Total |  |  | $ | 25,105 |  |  |  |  | $ | 20,109 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 2,248 |  |  |  |  | $ | 488 |  |  |  |
| Long-term debt |  |  | 22,857 |  |  |  |  | 19,621 |  |  |  |
| Total |  |  | $ | 25,105 |  |  |  |  | $ | 20,109 |  |  |  |
  (was, 2025-02-18, similarity 0.8479):
[0000858877-25-000007:note_history:29]
|  |  |  | January 25, 2025 |  | July 27, 2024 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | 5.66% |  | $ | 500 |  |  | 6.66% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 3 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 20,253 |  |  |  |  | 20,253 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (127) |  |  |  |  | (133) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (4) |  |  |  |  | (11) |  |  |  |
| Total |  |  | $ | 20,122 |  |  |  |  | $ | 20,109 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 497 |  |  |  |  | $ | 488 |  |  |  |
| Long-term debt |  |  | 19,625 |  |  |  |  | 19,621 |  |  |  |
| Total |  |  | $ | 20,122 |  |  |  |  | $ | 20,109 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0000858877-25-000033:note_history:30]
As of April 26, 2025, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2025-02-18, similarity 0.9701):
[0000858877-25-000007:note_history:30]
As of January 25, 2025, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2025-05-20):
[0000858877-25-000033:note_history:31]
| Fiscal Year | Amount |
| 2025 (remaining three months) | $ | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | 1,000 |  |
| 2029 | 2,500 |  |
| Thereafter | 16,000 |  |
| Total | $ | 25,253 |  |
  (was, 2025-02-18, similarity 0.9673):
[0000858877-25-000007:note_history:31]
| Fiscal Year | Amount |
| 2025 (remaining six months) | $ | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | — |  |
| 2029 | 2,500 |  |
| Thereafter | 12,000 |  |
| Total | $ | 20,253 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0000858877-25-000033:note_history:32]
|  | April 26, 2025 |  | July 27, 2024 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 2,247 |  |  | 4.48 | % |  | $ | 488 |  |  | 6.66 | % |
| Commercial paper | 4,174 |  |  | 4.49 | % |  | 10,853 |  |  | 5.43 | % |
| Current portion of other debt | 1 |  |  | 1.13 | % |  | — |  |  | — |  |
| Total | $ | 6,422 |  |  |  |  | $ | 11,341 |  |  |  |
  (was, 2025-02-18, similarity 0.9818):
[0000858877-25-000007:note_history:32]
|  | January 25, 2025 |  | July 27, 2024 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 496 |  |  | 5.66 | % |  | $ | 488 |  |  | 6.66 | % |
| Commercial paper | 10,916 |  |  | 4.75 | % |  | 10,853 |  |  | 5.43 | % |
| Current portion of other debt | 1 |  |  | 1.13 | % |  | — |  |  | — |  |
| Total | $ | 11,413 |  |  |  |  | $ | 11,341 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0000858877-25-000033:note_history:33]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,068 |  |  | $ | 6,522 |  |  | $ | 20,671 |  |  | $ | 22,425 |  |
| Security | 2,013 |  |  | 1,304 |  |  | 6,142 |  |  | 3,288 |  |
| Collaboration | 1,031 |  |  | 987 |  |  | 3,112 |  |  | 3,093 |  |
| Observability | 261 |  |  | 211 |  |  | 796 |  |  | 589 |  |
| Total Product | 10,374 |  |  | 9,024 |  |  | 30,722 |  |  | 29,395 |  |
| Services | 3,775 |  |  | 3,678 |  |  | 11,259 |  |  | 10,766 |  |
| Total | $ | 14,149 |  |  | $ | 12,702 |  |  | $ | 41,981 |  |  | $ | 40,161 |  |
  (was, 2025-02-18, similarity 0.8993):
[0000858877-25-000007:note_history:33]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25,2025 |  | January 27,2024 |  | January 25,2025 |  | January 27,2024 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 6,850 |  |  | $ | 7,081 |  |  | $ | 13,603 |  |  | $ | 15,904 |  |
| Security | 2,111 |  |  | 973 |  |  | 4,129 |  |  | 1,984 |  |
| Collaboration | 996 |  |  | 989 |  |  | 2,081 |  |  | 2,106 |  |
| Observability | 277 |  |  | 188 |  |  | 535 |  |  | 378 |  |
| Total Product | 10,234 |  |  | 9,232 |  |  | 20,348 |  |  | 20,371 |  |
| Services | 3,757 |  |  | 3,559 |  |  | 7,484 |  |  | 7,088 |  |
| Total | $ | 13,991 |  |  | $ | 12,791 |  |  | $ | 27,832 |  |  | $ | 27,459 |  |

- changed (2025-05-20):
[0000858877-25-000033:note_history:34]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Product | $ | 4,483 |  |  | $ | 3,510 |  |  | $ | 13,334 |  |  | $ | 9,827 |  |
| Services | 3,433 |  |  | 3,344 |  |  | 10,288 |  |  | 9,878 |  |
| Total | $ | 7,916 |  |  | $ | 6,854 |  |  | $ | 23,622 |  |  | $ | 19,705 |  |
  (was, 2025-02-18, similarity 0.7977):
[0000858877-25-000007:note_history:34]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2025 |  | January 27, 2024 |  | January 25, 2025 |  | January 27, 2024 |
| Product | $ | 4,432 |  |  | $ | 3,110 |  |  | $ | 8,851 |  |  | $ | 6,317 |  |
| Services | 3,430 |  |  | 3,280 |  |  | 6,855 |  |  | 6,534 |  |
| Total | $ | 7,862 |  |  | $ | 6,390 |  |  | $ | 15,706 |  |  | $ | 12,851 |  |

- changed (2025-05-20):
[0000858877-25-000033:note_history:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,068 |  |  | $ | 6,522 |  |  | $ | 20,671 |  |  | $ | 22,425 |  |
| Security | 2,013 |  |  | 1,304 |  |  | 6,142 |  |  | 3,288 |  |
| Collaboration | 1,031 |  |  | 987 |  |  | 3,112 |  |  | 3,093 |  |
| Observability | 261 |  |  | 211 |  |  | 796 |  |  | 589 |  |
| Total Product | 10,374 |  |  | 9,024 |  |  | 30,722 |  |  | 29,395 |  |
| Services | 3,775 |  |  | 3,678 |  |  | 11,259 |  |  | 10,766 |  |
| Total | $ | 14,149 |  |  | $ | 12,702 |  |  | $ | 41,981 |  |  | $ | 40,161 |  |
  (was, 2025-02-18, similarity 0.8976):
[0000858877-25-000007:note_history:35]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25,2025 |  | January 27,2024 |  | January 25,2025 |  | January 27,2024 |
| Revenue: |  |  |  |  |  |  |  |
| Networking | $ | 6,850 |  |  | $ | 7,081 |  |  | $ | 13,603 |  |  | $ | 15,904 |  |
| Security | 2,111 |  |  | 973 |  |  | 4,129 |  |  | 1,984 |  |
| Collaboration | 996 |  |  | 989 |  |  | 2,081 |  |  | 2,106 |  |
| Observability | 277 |  |  | 188 |  |  | 535 |  |  | 378 |  |
| Total Product | 10,234 |  |  | 9,232 |  |  | 20,348 |  |  | 20,371 |  |
| Services | 3,757 |  |  | 3,559 |  |  | 7,484 |  |  | 7,088 |  |
| Total | $ | 13,991 |  |  | $ | 12,791 |  |  | $ | 27,832 |  |  | $ | 27,459 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0000858877-25-000033:note_history:36]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 26, 2025 and July 27, 2024 was $39 million and $37 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2025-02-18, similarity 0.9793):
[0000858877-25-000007:note_history:36]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 25, 2025 and July 27, 2024 was $42 million and $37 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0000858877-25-000033:note_history:37]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 26, 2025 and July 27, 2024 was $39 million and $37 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2025-02-18, similarity 0.9793):
[0000858877-25-000007:note_history:37]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 25, 2025 and July 27, 2024 was $42 million and $37 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2025-05-20):
[0000858877-25-000033:note_history:38]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,068 |  |  | $ | 6,522 |  |  | $ | 20,671 |  |  | $ | 22,425 |  |
| Security | 2,013 |  |  | 1,304 |  |  | 6,142 |  |  | 3,288 |  |
| Collaboration | 1,031 |  |  | 987 |  |  | 3,112 |  |  | 3,093 |  |
| Observability | 261 |  |  | 211 |  |  | 796 |  |  | 589 |  |
| Total Product | 10,374 |  |  | 9,024 |  |  | 30,722 |  |  | 29,395 |  |
| Services | 3,775 |  |  | 3,678 |  |  | 11,259 |  |  | 10,766 |  |
| Total | $ | 14,149 |  |  | $ | 12,702 |  |  | $ | 41,981 |  |  | $ | 40,161 |  |
  (was, 2025-02-18, similarity 0.8993):
[0000858877-25-000007:note_history:38]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25,2025 |  | January 27,2024 |  | January 25,2025 |  | January 27,2024 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 6,850 |  |  | $ | 7,081 |  |  | $ | 13,603 |  |  | $ | 15,904 |  |
| Security | 2,111 |  |  | 973 |  |  | 4,129 |  |  | 1,984 |  |
| Collaboration | 996 |  |  | 989 |  |  | 2,081 |  |  | 2,106 |  |
| Observability | 277 |  |  | 188 |  |  | 535 |  |  | 378 |  |
| Total Product | 10,234 |  |  | 9,232 |  |  | 20,348 |  |  | 20,371 |  |
| Services | 3,757 |  |  | 3,559 |  |  | 7,484 |  |  | 7,088 |  |
| Total | $ | 13,991 |  |  | $ | 12,791 |  |  | $ | 27,832 |  |  | $ | 27,459 |  |

- changed (2025-05-20):
[0000858877-25-000033:note_history:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Product | $ | 4,483 |  |  | $ | 3,510 |  |  | $ | 13,334 |  |  | $ | 9,827 |  |
| Services | 3,433 |  |  | 3,344 |  |  | 10,288 |  |  | 9,878 |  |
| Total | $ | 7,916 |  |  | $ | 6,854 |  |  | $ | 23,622 |  |  | $ | 19,705 |  |
  (was, 2025-02-18, similarity 0.7977):
[0000858877-25-000007:note_history:39]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2025 |  | January 27, 2024 |  | January 25, 2025 |  | January 27, 2024 |
| Product | $ | 4,432 |  |  | $ | 3,110 |  |  | $ | 8,851 |  |  | $ | 6,317 |  |
| Services | 3,430 |  |  | 3,280 |  |  | 6,855 |  |  | 6,534 |  |
| Total | $ | 7,862 |  |  | $ | 6,390 |  |  | $ | 15,706 |  |  | $ | 12,851 |  |

- changed (2025-05-20):
[0000858877-25-000033:note_history:40]
Accounts receivable, net was $5.3 billion as of April 26, 2025 compared to $6.7 billion as of July 27, 2024, as reported on the Consolidated Balance Sheets.
  (was, 2025-02-18, similarity 0.9718):
[0000858877-25-000007:note_history:40]
Accounts receivable, net was $5.7 billion as of January 25, 2025 compared to $6.7 billion as of July 27, 2024, as reported on the Consolidated Balance Sheets.

- added (2025-05-20):
[0000858877-25-000033:note_history:41]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Allowance for credit loss at beginning of period | $ | 80 |  |  | $ | 79 |  |  | $ | 87 |  |  | $ | 85 |  |
| Provisions | 13 |  |  | 10 |  |  | 25 |  |  | 21 |  |
| Write-offs, net of recoveries | (11) |  |  | (8) |  |  | (30) |  |  | (25) |  |
| Allowance for credit loss at end of period | $ | 82 |  |  | $ | 81 |  |  | $ | 82 |  |  | $ | 81 |  |

- changed (2025-05-20):
[0000858877-25-000033:note_history:42]
|  | April 26,2025 |  | July 27,2024 |
| 1 to 4 | $ | 1,245 |  |  | $ | 1,266 |  |
| 5 to 6 | 1,762 |  |  | 1,456 |  |
| 7 and Higher | 70 |  |  | 72 |  |
| Total | $ | 3,077 |  |  | $ | 2,794 |  |
  (was, 2025-02-18, similarity 0.9726):
[0000858877-25-000007:note_history:42]
|  | January 25,2025 |  | July 27,2024 |
| 1 to 4 | $ | 1,223 |  |  | $ | 1,266 |  |
| 5 to 6 | 1,659 |  |  | 1,456 |  |
| 7 and Higher | 82 |  |  | 72 |  |
| Total | $ | 2,964 |  |  | $ | 2,794 |  |

- changed (2025-05-20):
[0000858877-25-000033:note_history:43]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $3.0 billion as of April 26, 2025 and $2.7 billion as of July 27, 2024, and were included in other current assets and other assets.
  (was, 2025-02-18, similarity 0.9874):
[0000858877-25-000007:note_history:43]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $2.9 billion as of January 25, 2025 and $2.7 billion as of July 27, 2024, and were included in other current assets and other assets.

- changed (2025-05-20):
[0000858877-25-000033:note_history:44]
Contract liabilities consist of deferred revenue. Deferred revenue was $28.0 billion as of April 26, 2025 compared to $28.5 billion as of July 27, 2024. We recognized approximately $3.6 billion and $13.3 billion of revenue during the third quarter and first nine months of fiscal 2025 that was included in the deferred revenue balance at July 27, 2024.
  (was, 2025-02-18, similarity 0.7826):
[0000858877-25-000007:note_history:44]
Contract liabilities consist of deferred revenue. Deferred revenue was $27.8 billion as of January 25, 2025 compared to $28.5 billion as of July 27, 2024. We recognized approximately $4.4 billion and $9.7 billion of revenue during the second quarter and first six months of fiscal 2025 that was included in the deferred revenue balance at July 27, 2024.

- changed (2025-05-20):
[0000858877-25-000033:note_history:45]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to 
the period of benefit. Capitalized contract acquisition costs were $1.5 billion and $1.3 billion as of April 26, 2025 and July 27, 2024, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $272 million and $718 million for the third quarter and first nine months of fiscal 2025, respectively, and $201 million and $525 million for the corresponding periods of fiscal 2024, respectively, and was included in sales and marketing expenses.
  (was, 2025-02-18, similarity 0.9838):
[0000858877-25-000007:note_history:45]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to 
the period of benefit. Capitalized contract acquisition costs were $1.5 billion and $1.3 billion as of January 25, 2025 and July 27, 2024, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $238 million and $446 million for the second quarter and first six months of fiscal 2025, respectively, and $166 million and $324 million for the corresponding periods of fiscal 2024, respectively, and was included in sales and marketing expenses.

- removed (2025-05-20):
[0000858877-25-000007:note_history:46]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2025 |  | January 27, 2024 |  | January 25, 2025 |  | January 27, 2024 |
| Allowance for credit loss at beginning of period | $ | 78 |  |  | $ | 82 |  |  | $ | 87 |  |  | $ | 85 |  |
| Provisions (benefits) | 12 |  |  | 9 |  |  | 12 |  |  | 11 |  |
| Recoveries (write-offs), net | (10) |  |  | (12) |  |  | (19) |  |  | (17) |  |
| Allowance for credit loss at end of period | $ | 80 |  |  | $ | 79 |  |  | $ | 80 |  |  | $ | 79 |  |


## us-gaap:SubsequentEventsPolicyPolicyTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2025-05-20):
[0000858877-25-000033:note_history:47]
We have evaluated subsequent events through the date that the financial statements were issued.
