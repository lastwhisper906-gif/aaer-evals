# CSCO notes — 0000858877-25-000171


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-25-000171:notes:1]
Organization and Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2026 and fiscal 2025 are each 52-week fiscal years. The Consolidated Financial Statements include our accounts and those of our subsidiaries and those of our investments consolidated under the voting interest method. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-25-000171:notes:2]
We have prepared the accompanying financial data as of October 25, 2025 and for the first quarter of fiscal 2026 and 2025, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 26, 2025 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 26, 2025.

[0000858877-25-000171:notes:3]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of October 25, 2025, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2026 and 2025, as applicable, have been made. The results of operations for the first quarter of fiscal 2026 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-25-000171:notes:4]
[same as prior period, unchanged from 0000858877-25-000033:notes:6]

[0000858877-25-000171:notes:5]
[same as prior period, unchanged from 0000858877-25-000033:notes:8]

[0000858877-25-000171:notes:6]
Disaggregation of Income Statement Expenses  In November 2024, the FASB issued an accounting standard update expanding the disclosure requirements about specific expense categories, primarily through disaggregated information on income statement line items. The accounting standard update will be effective for our fiscal 2028 Form 10-K, and early adoption is permitted. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.
Targeted Improvements to the Accounting for Internal-Use Software  In September 2025, the FASB issued an accounting standard update to modernize the accounting for internal-use software costs and clarify the criteria for capitalization. The accounting standard update will be effective for our interim and annual reporting periods of fiscal 2029, with early adoption permitted. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-25-000171:notes:7]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to

[0000858877-25-000171:notes:8]
our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers. Revenue from subscription offers includes revenue recognized over time as well as upfront.

[0000858877-25-000171:notes:9]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes. An allowance for future sales returns is established based on historical trends in product return rates and the related provision is recorded as a reduction to revenue.

[0000858877-25-000171:notes:10]
[same as prior period, unchanged from 0000858877-25-000033:notes:13]

[0000858877-25-000171:notes:11]
[same as prior period, unchanged from 0000858877-25-000033:notes:14]

[0000858877-25-000171:notes:12]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and direct sale customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.

[0000858877-25-000171:notes:13]
[same as prior period, unchanged from 0000858877-25-000033:notes:16]

[0000858877-25-000171:notes:14]
[same as prior period, unchanged from 0000858877-25-000033:notes:17]

[0000858877-25-000171:notes:15]
[same as prior period, unchanged from 0000858877-25-000033:notes:18]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-25-000171:notes:16]
[same as prior period, unchanged from 0000858877-25-000033:notes:19]

[0000858877-25-000171:notes:17]
[same as prior period, unchanged from 0000858877-25-000033:notes:20]

[0000858877-25-000171:notes:18]
|  | Three Months Ended |
|  | October 25,2025 |  | October 26,2024 |
| Product revenue: |  |  |  |
| Networking | $ | 7,768 |  |  | $ | 6,753 |  |
| Security | 1,980 |  |  | 2,017 |  |
| Collaboration | 1,055 |  |  | 1,085 |  |
| Observability | 274 |  |  | 258 |  |
| Total Product | 11,077 |  |  | 10,114 |  |
| Services | 3,806 |  |  | 3,727 |  |
| Total revenue | $ | 14,883 |  |  | $ | 13,841 |  |

[0000858877-25-000171:notes:19]
[same as prior period, unchanged from 0000858877-25-000033:notes:22]

[0000858877-25-000171:notes:20]
[same as prior period, unchanged from 0000858877-25-000033:notes:23]

[0000858877-25-000171:notes:21]
[same as prior period, unchanged from 0000858877-25-000033:notes:24]

[0000858877-25-000171:notes:22]
[same as prior period, unchanged from 0000858877-25-000033:notes:25]

[0000858877-25-000171:notes:23]
[same as prior period, unchanged from 0000858877-25-000033:notes:26]

[0000858877-25-000171:notes:24]
[same as prior period, unchanged from 0000858877-25-000033:notes:27]

[0000858877-25-000171:notes:25]
[same as prior period, unchanged from 0000858877-25-000033:notes:28]

[0000858877-25-000171:notes:26]
|  | Three Months Ended |
|  | October 25, 2025 |  | October 26, 2024 |
| Product | $ | 4,500 |  |  | $ | 4,419 |  |
| Services | 3,500 |  |  | 3,425 |  |
| Total | $ | 8,000 |  |  | $ | 7,844 |  |

[0000858877-25-000171:notes:27]
[same as prior period, unchanged from 0000858877-25-000033:notes:30]

[0000858877-25-000171:notes:28]
[same as prior period, unchanged from 0000858877-25-000033:notes:31]

[0000858877-25-000171:notes:29]
[same as prior period, unchanged from 0000858877-25-000033:notes:32]

[0000858877-25-000171:notes:30]
Accounts receivable, net was $4.8 billion as of October 25, 2025 compared to $6.7 billion as of July 26, 2025, as reported on the Consolidated Balance Sheets.

[0000858877-25-000171:notes:31]
[same as prior period, unchanged from 0000858877-25-000033:notes:34]

[0000858877-25-000171:notes:32]
|  | Three Months Ended |
|  | October 25, 2025 |  | October 26, 2024 |
| Allowance for credit loss at beginning of period | $ | 69 |  |  | $ | 87 |  |
| Provisions | (4) |  |  | — |  |
| Write-offs, net of recoveries | (3) |  |  | (9) |  |
| Allowance for credit loss at end of period | $ | 62 |  |  | $ | 78 |  |

[0000858877-25-000171:notes:33]
[same as prior period, unchanged from 0000858877-25-000033:notes:36]

[0000858877-25-000171:notes:34]
[same as prior period, unchanged from 0000858877-25-000033:notes:37]

[0000858877-25-000171:notes:35]
|  | October 25,2025 |  | July 26,2025 |
| 1 to 4 | $ | 1,379 |  |  | $ | 1,358 |  |
| 5 to 6 | 2,001 |  |  | 1,868 |  |
| 7 and Higher | 75 |  |  | 73 |  |
| Total | $ | 3,455 |  |  | $ | 3,299 |  |

[0000858877-25-000171:notes:36]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $3.4 billion as of October 25, 2025 and $3.2 billion as of July 26, 2025, of which $1.8 billion and $1.7 billion, respectively, were included in other current assets, with remaining balances included in other assets.

[0000858877-25-000171:notes:37]
Contract liabilities consist of deferred revenue. Deferred revenue was $28.0 billion as of October 25, 2025 compared to $28.8 billion as of July 26, 2025. We recognized approximately $5.4 billion of revenue during the first quarter of fiscal 2026 that was included in the deferred revenue balance at July 26, 2025.

[0000858877-25-000171:notes:38]
[same as prior period, unchanged from 0000858877-25-000033:notes:41]

[0000858877-25-000171:notes:39]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to 
the period of benefit. Capitalized contract acquisition costs were $1.5 billion as of each of October 25, 2025 and July 26, 2025, and were included in other current assets and other assets. The amortization expense associated with these costs was $234 million and $208 million for the first quarter of fiscal 2026 and 2025, respectively, and was included in sales and marketing expenses.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-25-000171:notes:40]
[same as prior period, unchanged from 0000858877-25-000033:notes:43]

[0000858877-25-000171:notes:41]
[same as prior period, unchanged from 0000858877-25-000033:notes:44]

[0000858877-25-000171:notes:42]
[same as prior period, unchanged from 0000858877-25-000033:notes:45]

[0000858877-25-000171:notes:43]
|  | Three Months Ended |
|  | October 25,2025 |  | October 26,2024 |
| Revenue: |  |
| Networking | $ | 7,768 |  |  | $ | 6,753 |  |
| Security | 1,980 |  |  | 2,017 |  |
| Collaboration | 1,055 |  |  | 1,085 |  |
| Observability | 274 |  |  | 258 |  |
| Total Product | 11,077 |  |  | 10,114 |  |
| Services | 3,806 |  |  | 3,727 |  |
| Total | $ | 14,883 |  |  | $ | 13,841 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-25-000171:notes:44]
Acquisitions
Allocation of the total purchase consideration for an acquisition we completed during the first quarter of fiscal 2026 is summarized as follows (in millions):

[0000858877-25-000171:notes:45]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Allocation of purchase consideration | $ | 10 |  |  | $ | 1 |  |  | $ | 4 |  |  | $ | 5 |  |

[0000858877-25-000171:notes:46]
The total purchase consideration related to this acquisition consisted primarily of cash consideration. Total transaction costs related to acquisition activities were $3 million and $9 million for the first quarter of fiscal 2026 and 2025, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-25-000171:notes:47]
[same as prior period, unchanged from 0000858877-25-000033:notes:50]

[0000858877-25-000171:notes:48]
The goodwill generated from the acquisition completed during the first quarter of fiscal 2026 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-25-000171:notes:49]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisition completed during the first quarter of fiscal 2026 have not been presented because the effects of the acquisition was not material to our financial results.

[0000858877-25-000171:notes:50]
[same as prior period, unchanged from 0000858877-25-000033:notes:53]

[0000858877-25-000171:notes:51]
[same as prior period, unchanged from 0000858877-25-000033:notes:54]

[0000858877-25-000171:notes:52]
[same as prior period, unchanged from 0000858877-25-000033:notes:55]

[0000858877-25-000171:notes:53]
|  | Three Months Ended |
|  | October 25, 2025 |  | October 26, 2024 |
| Compensation expense related to acquisitions | $ | 110 |  |  | $ | 297 |  |

[0000858877-25-000171:notes:54]
As of October 25, 2025, we estimated that future cash compensation expense of up to $502 million may be required to be recognized pursuant to applicable acquisition agreements.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-25-000171:notes:55]
[same as prior period, unchanged from 0000858877-25-000033:notes:58]

[0000858877-25-000171:notes:56]
The following table presents the goodwill allocated to our reportable segments as of October 25, 2025 and changes to goodwill during the first quarter of fiscal 2026 (in millions):

[0000858877-25-000171:notes:57]
|  | Balance at July 26, 2025 |  | Acquisitions, net of Divestitures |  | Foreign Currency Translation and Other |  | Balance at October 25, 2025 |
| Americas | $ | 36,468 |  |  | $ | 3 |  |  | $ | (14) |  |  | $ | 36,457 |  |
| EMEA | 14,397 |  |  | 1 |  |  | (5) |  |  | 14,393 |  |
| APJC | 8,271 |  |  | 1 |  |  | (3) |  |  | 8,269 |  |
| Total | $ | 59,136 |  |  | $ | 5 |  |  | $ | (22) |  |  | $ | 59,119 |  |

[0000858877-25-000171:notes:58]
[same as prior period, unchanged from 0000858877-25-000033:notes:61]

[0000858877-25-000171:notes:59]
The following table presents details of our intangible assets acquired through acquisitions completed during the first quarter of fiscal 2026 (in millions, except years):

[0000858877-25-000171:notes:60]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | CUSTOMER RELATED |  | TECHNOLOGY |  | TRADE NAME |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total | — |  |  | $ | — |  |  | 3.0 |  | $ | 4 |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 4 |  |

[0000858877-25-000171:notes:61]
The following tables present details of our purchased intangible assets with finite lives (in millions):

[0000858877-25-000171:notes:62]
| October 25, 2025 |  | Gross |  | Accumulated Amortization |  | Net |
| Customer related |  | $ | 6,340 |  |  | $ | (1,488) |  |  | $ | 4,852 |  |
| Technology |  | 5,209 |  |  | (1,791) |  |  | 3,418 |  |
| Trade name |  | 526 |  |  | (83) |  |  | 443 |  |
| Total |  | $ | 12,075 |  |  | $ | (3,362) |  |  | $ | 8,713 |  |

[0000858877-25-000171:notes:63]
| July 26, 2025 |  | Gross |  | Accumulated Amortization |  | Net |
| Customer related |  | $ | 6,341 |  |  | $ | (1,268) |  |  | $ | 5,073 |  |
| Technology |  | 5,254 |  |  | (1,606) |  |  | 3,648 |  |
| Trade name |  | 526 |  |  | (72) |  |  | 454 |  |
| Total |  | $ | 12,121 |  |  | $ | (2,946) |  |  | $ | 9,175 |  |

[0000858877-25-000171:notes:64]
[same as prior period, unchanged from 0000858877-25-000033:notes:67]

[0000858877-25-000171:notes:65]
[same as prior period, unchanged from 0000858877-25-000033:notes:69]

[0000858877-25-000171:notes:66]
|  | Three Months Ended |
|  | October 25, 2025 |  | October 26, 2024 |
| Amortization of purchased intangible assets: |  |  |  |
| Cost of sales | $ | 240 |  |  | $ | 325 |  |
| Operating expenses | 231 |  |  | 265 |  |
| Total | $ | 471 |  |  | $ | 590 |  |

[0000858877-25-000171:notes:67]
The estimated future amortization expense of purchased intangible assets with finite lives as of October 25, 2025 is as follows (in millions):

[0000858877-25-000171:notes:68]
| Fiscal Year | Amount |
| 2026 (remaining nine months) | $ | 1,359 |  |
| 2027 | 1,481 |  |
| 2028 | 1,403 |  |
| 2029 | 1,277 |  |
| 2030 | 993 |  |
| Thereafter | 2,200 |  |
| Total | $ | 8,713 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-25-000171:notes:69]
Restructuring and Other Charges
In the first quarter of fiscal 2025, we announced a restructuring plan (the “Fiscal 2025 Plan”), in order to allow us to invest in key growth opportunities and drive more efficiencies in our business, of which approximately 7% of our global workforce would be impacted with estimated pre-tax charges of up to $1 billion. In connection with the Fiscal 2025 Plan, we incurred charges of $147 million in the first quarter of fiscal 2026, and the plan is expected to be completed in the second quarter of fiscal 2026. These aggregate pre-tax charges are primarily cash-based and consist of severance and other one-time termination benefits, and other costs.

[0000858877-25-000171:notes:70]
[same as prior period, unchanged from 0000858877-25-000033:notes:75]

[0000858877-25-000171:notes:71]
|  |  | FISCAL 2025 PLAN |  |  |
|  |  | Employee Severance |  | Other |  | Total |
| Liability as of July 26, 2025 |  | $ | 66 |  |  | $ | 46 |  |  | $ | 112 |  |
| Charges |  | 113 |  |  | 34 |  |  | 147 |  |
| Cash payments |  | (61) |  |  | (21) |  |  | (82) |  |
| Non-cash and other |  | (1) |  |  | (35) |  |  | (36) |  |
| Liability as of October 25, 2025 |  | $ | 117 |  |  | $ | 24 |  |  | $ | 141 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-25-000171:notes:72]
[same as prior period, unchanged from 0000858877-25-000033:notes:77]

[0000858877-25-000171:notes:73]
[same as prior period, unchanged from 0000858877-25-000033:notes:78]

[0000858877-25-000171:notes:74]
|  |  | October 25,2025 |  | July 26,2025 |
| Cash and cash equivalents |  | $ | 8,400 |  |  | $ | 8,346 |  |
| Restricted cash and restricted cash equivalents included in other current assets |  | 1 |  |  | 564 |  |
| Total |  | $ | 8,401 |  |  | $ | 8,910 |  |

[0000858877-25-000171:notes:75]
[same as prior period, unchanged from 0000858877-25-000033:notes:80]

[0000858877-25-000171:notes:76]
[same as prior period, unchanged from 0000858877-25-000033:notes:81]

[0000858877-25-000171:notes:77]
|  |  | October 25,2025 |  | July 26,2025 |
| Raw materials |  | $ | 1,758 |  |  | $ | 1,744 |  |
| Work in process |  | 411 |  |  | 261 |  |
| Finished goods |  | 985 |  |  | 933 |  |
| Service-related spares |  | 236 |  |  | 220 |  |
| Demonstration systems |  | 5 |  |  | 6 |  |
| Total |  | $ | 3,395 |  |  | $ | 3,164 |  |

[0000858877-25-000171:notes:78]
[same as prior period, unchanged from 0000858877-25-000033:notes:83]

[0000858877-25-000171:notes:79]
|  |  | October 25,2025 |  | July 26,2025 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,062 |  |  | $ | 4,045 |  |
| Production, engineering, computer and other equipment and related software |  | 5,232 |  |  | 5,178 |  |
| Operating lease assets |  | 49 |  |  | 51 |  |
| Furniture, fixtures and other |  | 318 |  |  | 316 |  |
| Total gross property and equipment |  | 9,661 |  |  | 9,590 |  |
| Less: accumulated depreciation and amortization |  | (7,413) |  |  | (7,477) |  |
| Total |  | $ | 2,248 |  |  | $ | 2,113 |  |

[0000858877-25-000171:notes:80]
[same as prior period, unchanged from 0000858877-25-000033:notes:85]

[0000858877-25-000171:notes:81]
|  |  | October 25,2025 |  | July 26,2025 |
| Product |  | $ | 21,904 |  |  | $ | 21,572 |  |
| Services |  | 20,969 |  |  | 21,961 |  |
| Total |  | $ | 42,873 |  |  | $ | 43,533 |  |
| Short-term RPO |  | $ | 20,971 |  |  | $ | 21,723 |  |
| Long-term RPO |  | 21,902 |  |  | 21,810 |  |
| Total |  | $ | 42,873 |  |  | $ | 43,533 |  |
| Amount to be recognized as revenue over the next 12 months |  | 49 | % |  | 50 | % |
| Deferred revenue |  | $ | 27,969 |  |  | $ | 28,779 |  |
| Unbilled contract revenue |  | 14,904 |  |  | 14,754 |  |
| Total |  | $ | 42,873 |  |  | $ | 43,533 |  |

[0000858877-25-000171:notes:82]
[same as prior period, unchanged from 0000858877-25-000033:notes:87]

[0000858877-25-000171:notes:83]
[same as prior period, unchanged from 0000858877-25-000033:notes:88]

[0000858877-25-000171:notes:84]
|  |  | October 25,2025 |  | July 26,2025 |
| Product |  | $ | 13,252 |  |  | $ | 13,490 |  |
| Services |  | 14,717 |  |  | 15,289 |  |
| Total |  | $ | 27,969 |  |  | $ | 28,779 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 15,801 |  |  | $ | 16,416 |  |
| Noncurrent |  | 12,168 |  |  | 12,363 |  |
| Total |  | $ | 27,969 |  |  | $ | 28,779 |  |

[0000858877-25-000171:notes:85]
Transition Tax Payable/Receivable

[0000858877-25-000171:notes:86]
Our income tax payable and receivable associated with the one-time U.S. transition tax on accumulated earnings for foreign subsidiaries as a result of the Tax Cuts and Jobs Act are as follows:

[0000858877-25-000171:notes:87]
|  |  | October 25,2025 |  | July 26,2025 |
| Current income taxes payable |  | $ | 2,273 |  |  | $ | 1,595 |  |
| Less: Noncurrent income tax receivable included in other assets |  | (678) |  |  | — |  |
| Net |  | $ | 1,595 |  |  | $ | 1,595 |  |

[0000858877-25-000171:notes:88]
The income tax receivable as of October 25, 2025 reflects the transition tax benefit of the U.S. Tax Court opinion in Varian Medical Systems, Inc. v. Commissioner. See Note 18.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000858877-25-000171:notes:89]
Leases 
(a)Lessee Arrangements

[0000858877-25-000171:notes:90]
The following table presents our operating lease balances (in millions):

[0000858877-25-000171:notes:91]
|  | Balance Sheet Line Item |  | October 25, 2025 |  | July 26, 2025 |
| Operating lease right-of-use assets | Other assets |  | $ | 1,303 |  |  | $ | 1,301 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 403 |  |  | $ | 375 |  |
| Operating lease liabilities | Other long-term liabilities |  | 1,145 |  |  | 1,175 |  |
| Total operating lease liabilities |  |  | $ | 1,548 |  |  | $ | 1,550 |  |

[0000858877-25-000171:notes:92]
The components of our lease expenses were as follows (in millions):

[0000858877-25-000171:notes:93]
|  | Three Months Ended |
|  | October 25, 2025 |  | October 26, 2024 |
| Operating lease expense | $ | 131 |  |  | $ | 114 |  |
| Short-term lease expense | 25 |  |  | 18 |  |
| Variable lease expense | 72 |  |  | 46 |  |
| Total lease expense | $ | 228 |  |  | $ | 178 |  |

[0000858877-25-000171:notes:94]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-25-000171:notes:95]
|  | Three Months Ended |
|  | October 25, 2025 |  | October 26, 2024 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 131 |  |  | $ | 114 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 123 |  |  | $ | 127 |  |

[0000858877-25-000171:notes:96]
The weighted-average lease term was 5.3 years and 5.7 years as of October 25, 2025 and July 26, 2025, respectively. The weighted-average discount rate was 3.9% and 4.1% as of October 25, 2025 and July 26, 2025, respectively.

[0000858877-25-000171:notes:97]
The maturities of our operating leases (undiscounted) as of October 25, 2025 are as follows (in millions):

[0000858877-25-000171:notes:98]
| Fiscal Year | Amount |
| 2026 (remaining nine months) | $ | 360 |  |
| 2027 | 346 |  |
| 2028 | 262 |  |
| 2029 | 209 |  |
| 2030 | 183 |  |
| Thereafter | 374 |  |
| Total lease payments | 1,734 |  |
| Less: interest | (186) |  |
| Total | $ | 1,548 |  |

[0000858877-25-000171:notes:99]
(b)Lessor Arrangements

[0000858877-25-000171:notes:100]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income was $16 million and $17 million for the first quarter of fiscal 2026 and 2025, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-25-000171:notes:101]
Future minimum lease payments on our lease receivables as of October 25, 2025 are summarized as follows (in millions):

[0000858877-25-000171:notes:102]
| Fiscal Year | Amount |
| 2026 (remaining nine months) | $ | 303 |  |
| 2027 | 346 |  |
| 2028 | 171 |  |
| 2029 | 180 |  |
| 2030 | 60 |  |
| Total | 1,060 |  |
| Less: Present value of lease payments | (962) |  |
| Unearned income | $ | 98 |  |

[0000858877-25-000171:notes:103]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.


## us-gaap:FinancingReceivablesTextBlock

[0000858877-25-000171:notes:104]
[same as prior period, unchanged from 0000858877-25-000033:notes:114]

[0000858877-25-000171:notes:105]
[same as prior period, unchanged from 0000858877-25-000033:notes:115]

[0000858877-25-000171:notes:106]
[same as prior period, unchanged from 0000858877-25-000033:notes:116]

[0000858877-25-000171:notes:107]
| October 25, 2025 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,826 |  |  | $ | 1,060 |  |  | $ | 6,886 |  |
| Residual value | — |  |  | 67 |  |  | 67 |  |
| Unearned income | — |  |  | (98) |  |  | (98) |  |
| Allowance for credit loss | (37) |  |  | (14) |  |  | (51) |  |
| Total, net | $ | 5,789 |  |  | $ | 1,015 |  |  | $ | 6,804 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 2,714 |  |  | $ | 371 |  |  | $ | 3,085 |  |
| Noncurrent | 3,075 |  |  | 644 |  |  | 3,719 |  |
| Total, net | $ | 5,789 |  |  | $ | 1,015 |  |  | $ | 6,804 |  |

[0000858877-25-000171:notes:108]
| July 26, 2025 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,628 |  |  | $ | 982 |  |  | $ | 6,610 |  |
| Residual value | — |  |  | 66 |  |  | 66 |  |
| Unearned income | — |  |  | (99) |  |  | (99) |  |
| Allowance for credit loss | (37) |  |  | (13) |  |  | (50) |  |
| Total, net | $ | 5,591 |  |  | $ | 936 |  |  | $ | 6,527 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 2,715 |  |  | $ | 346 |  |  | $ | 3,061 |  |
| Noncurrent | 2,876 |  |  | 590 |  |  | 3,466 |  |
| Total, net | $ | 5,591 |  |  | $ | 936 |  |  | $ | 6,527 |  |

[0000858877-25-000171:notes:109]
[same as prior period, unchanged from 0000858877-25-000033:notes:119]

[0000858877-25-000171:notes:110]
[same as prior period, unchanged from 0000858877-25-000033:notes:120]

[0000858877-25-000171:notes:111]
| October 25, 2025 |  |  | Fiscal Year |  | Three Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 30, 2022 |  | July 29, 2023 |  | July 27, 2024 |  | July 26, 2025 |  | October 25, 2025 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 58 |  |  | $ | 186 |  |  | $ | 306 |  |  | $ | 1,003 |  |  | $ | 1,361 |  |  | $ | 662 |  |  | $ | 3,576 |  |
| 5 to 6 | 38 |  |  | 36 |  |  | 131 |  |  | 466 |  |  | 1,137 |  |  | 400 |  |  | 2,208 |  |
| 7 and Higher | — |  |  | 6 |  |  | 7 |  |  | 4 |  |  | 22 |  |  | 3 |  |  | 42 |  |
| Total Loan Receivables | $ | 96 |  |  | $ | 228 |  |  | $ | 444 |  |  | $ | 1,473 |  |  | $ | 2,520 |  |  | $ | 1,065 |  |  | $ | 5,826 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 6 |  |  | $ | 21 |  |  | $ | 110 |  |  | $ | 194 |  |  | $ | 218 |  |  | $ | 35 |  |  | $ | 584 |  |
| 5 to 6 | 4 |  |  | 20 |  |  | 70 |  |  | 117 |  |  | 103 |  |  | 50 |  |  | 364 |  |
| 7 and Higher | — |  |  | 1 |  |  | 2 |  |  | 6 |  |  | 2 |  |  | 3 |  |  | 14 |  |
| Total Lease Receivables | $ | 10 |  |  | $ | 42 |  |  | $ | 182 |  |  | $ | 317 |  |  | $ | 323 |  |  | $ | 88 |  |  | $ | 962 |  |
| Total | $ | 106 |  |  | $ | 270 |  |  | $ | 626 |  |  | $ | 1,790 |  |  | $ | 2,843 |  |  | $ | 1,153 |  |  | $ | 6,788 |  |

[0000858877-25-000171:notes:112]
| July 26, 2025 |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 31, 2021 |  | July 30, 2022 |  | July 29, 2023 |  | July 27, 2024 |  | July 26, 2025 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 83 |  |  | $ | 236 |  |  | $ | 371 |  |  | $ | 1,258 |  |  | $ | 1,556 |  |  | $ | 3,506 |  |
| 5 to 6 | 2 |  |  | 56 |  |  | 53 |  |  | 167 |  |  | 561 |  |  | 1,248 |  |  | 2,087 |  |
| 7 and Higher | — |  |  | — |  |  | 6 |  |  | 9 |  |  | 4 |  |  | 16 |  |  | 35 |  |
| Total Loan Receivables | $ | 4 |  |  | $ | 139 |  |  | $ | 295 |  |  | $ | 547 |  |  | $ | 1,823 |  |  | $ | 2,820 |  |  | $ | 5,628 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | — |  |  | $ | 9 |  |  | $ | 23 |  |  | $ | 112 |  |  | $ | 187 |  |  | $ | 207 |  |  | $ | 538 |  |
| 5 to 6 | — |  |  | 6 |  |  | 25 |  |  | 77 |  |  | 120 |  |  | 103 |  |  | 331 |  |
| 7 and Higher | — |  |  | — |  |  | 1 |  |  | 3 |  |  | 8 |  |  | 2 |  |  | 14 |  |
| Total Lease Receivables | $ | — |  |  | $ | 15 |  |  | $ | 49 |  |  | $ | 192 |  |  | $ | 315 |  |  | $ | 312 |  |  | $ | 883 |  |
| Total | $ | 4 |  |  | $ | 154 |  |  | $ | 344 |  |  | $ | 739 |  |  | $ | 2,138 |  |  | $ | 3,132 |  |  | $ | 6,511 |  |

[0000858877-25-000171:notes:113]
The following tables present the aging analysis of gross receivables as of October 25, 2025 and July 26, 2025 (in millions):

[0000858877-25-000171:notes:114]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| October 25, 2025 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 46 |  |  | $ | 27 |  |  | $ | 31 |  |  | $ | 104 |  |  | $ | 5,722 |  |  | $ | 5,826 |  |  | $ | 8 |  |  | $ | 3 |  |  | $ | 3 |  |
| Lease receivables | 12 |  |  | 2 |  |  | 16 |  |  | 30 |  |  | 932 |  |  | 962 |  |  | 5 |  |  | 1 |  |  | 1 |  |
| Total | $ | 58 |  |  | $ | 29 |  |  | $ | 47 |  |  | $ | 134 |  |  | $ | 6,654 |  |  | $ | 6,788 |  |  | $ | 13 |  |  | $ | 4 |  |  | $ | 4 |  |

[0000858877-25-000171:notes:115]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| July 26, 2025 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 18 |  |  | $ | 18 |  |  | $ | 16 |  |  | $ | 52 |  |  | $ | 5,576 |  |  | $ | 5,628 |  |  | $ | 4 |  |  | $ | 5 |  |  | $ | 5 |  |
| Lease receivables | 7 |  |  | 3 |  |  | 6 |  |  | 16 |  |  | 867 |  |  | 883 |  |  | 4 |  |  | 1 |  |  | 1 |  |
| Total | $ | 25 |  |  | $ | 21 |  |  | $ | 22 |  |  | $ | 68 |  |  | $ | 6,443 |  |  | $ | 6,511 |  |  | $ | 8 |  |  | $ | 6 |  |  | $ | 6 |  |

[0000858877-25-000171:notes:116]
[same as prior period, unchanged from 0000858877-25-000033:notes:126]

[0000858877-25-000171:notes:117]
[same as prior period, unchanged from 0000858877-25-000033:notes:127]

[0000858877-25-000171:notes:118]
[same as prior period, unchanged from 0000858877-25-000033:notes:128]

[0000858877-25-000171:notes:119]
| Three Months Ended October 25, 2025 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 26, 2025 | $ | 37 |  |  | $ | 13 |  |  | $ | 50 |  |
| Provisions (benefits) | — |  |  | 1 |  |  | 1 |  |
| Allowance for credit loss as of October 25, 2025 | $ | 37 |  |  | $ | 14 |  |  | $ | 51 |  |

[0000858877-25-000171:notes:120]
| Three Months Ended October 26, 2024 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 27, 2024 | $ | 50 |  |  | $ | 15 |  |  | $ | 65 |  |
| Provisions (benefits) | (1) |  |  | — |  |  | (1) |  |
| Allowance for credit loss as of October 26, 2024 | $ | 49 |  |  | $ | 15 |  |  | $ | 64 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-25-000171:notes:121]
Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-25-000171:notes:122]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-25-000171:notes:123]
| October 25, 2025 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,637 |  |  | $ | 7 |  |  | $ | (4) |  |  | $ | 1,640 |  |
| U.S. government agency securities | 49 |  |  | — |  |  | — |  |  | 49 |  |
| Non-U.S. government and agency securities | 409 |  |  | 1 |  |  | — |  |  | 410 |  |
| Corporate debt securities | 2,979 |  |  | 14 |  |  | (44) |  |  | 2,949 |  |
| Mortgage- and asset-backed securities | 270 |  |  | — |  |  | (16) |  |  | 254 |  |
| Commercial paper | 884 |  |  | — |  |  | — |  |  | 884 |  |
| Certificates of deposit | 756 |  |  | — |  |  | — |  |  | 756 |  |
| Total | $ | 6,984 |  |  | $ | 22 |  |  | $ | (64) |  |  | $ | 6,942 |  |

[0000858877-25-000171:notes:124]
| July 26, 2025 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,971 |  |  | $ | 2 |  |  | $ | (12) |  |  | $ | 1,961 |  |
| U.S. government agency securities | 67 |  |  | — |  |  | — |  |  | 67 |  |
| Non-U.S. government and agency securities | 458 |  |  | — |  |  | — |  |  | 458 |  |
| Corporate debt securities | 3,138 |  |  | 13 |  |  | (61) |  |  | 3,090 |  |
| Mortgage- and asset-backed securities | 320 |  |  | — |  |  | (34) |  |  | 286 |  |
| Commercial paper | 950 |  |  | — |  |  | — |  |  | 950 |  |
| Certificates of deposit | 569 |  |  | — |  |  | — |  |  | 569 |  |
| Total | $ | 7,473 |  |  | $ | 15 |  |  | $ | (107) |  |  | $ | 7,381 |  |

[0000858877-25-000171:notes:125]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-25-000171:notes:126]
|  | Three Months Ended |
|  | October 25, 2025 |  | October 26, 2024 |
| Gross realized gains | $ | 10 |  |  | $ | 8 |  |
| Gross realized losses | (14) |  |  | (33) |  |
| Total | $ | (4) |  |  | $ | (25) |  |

[0000858877-25-000171:notes:127]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 25, 2025 and July 26, 2025 (in millions):

[0000858877-25-000171:notes:128]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 25, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | — |  |  | $ | — |  |  | $ | 436 |  |  | $ | (4) |  |  | $ | 436 |  |  | $ | (4) |  |
| U.S. government agency securities | 5 |  |  | — |  |  | — |  |  | — |  |  | 5 |  |  | — |  |
| Corporate debt securities | 63 |  |  | — |  |  | 1,583 |  |  | (18) |  |  | 1,646 |  |  | (18) |  |
| Mortgage- and asset-backed securities | 4 |  |  | — |  |  | 160 |  |  | (16) |  |  | 164 |  |  | (16) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 82 |  |  | $ | — |  |  | $ | 2,179 |  |  | $ | (38) |  |  | $ | 2,261 |  |  | $ | (38) |  |

[0000858877-25-000171:notes:129]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 26, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,076 |  |  | $ | (6) |  |  | $ | 302 |  |  | $ | (6) |  |  | $ | 1,378 |  |  | $ | (12) |  |
| U.S. government agency securities | 8 |  |  | — |  |  | 21 |  |  | — |  |  | 29 |  |  | — |  |
| Non-U.S. government and agency securities | 292 |  |  | — |  |  | — |  |  | — |  |  | 292 |  |  | — |  |
| Corporate debt securities | 106 |  |  | — |  |  | 1,800 |  |  | (35) |  |  | 1,906 |  |  | (35) |  |
| Mortgage- and asset-backed securities | 5 |  |  | — |  |  | 279 |  |  | (34) |  |  | 284 |  |  | (34) |  |
| Commercial paper | 30 |  |  | — |  |  | — |  |  | — |  |  | 30 |  |  | — |  |
| Total | $ | 1,517 |  |  | $ | (6) |  |  | $ | 2,402 |  |  | $ | (75) |  |  | $ | 3,919 |  |  | $ | (81) |  |

[0000858877-25-000171:notes:130]
The following table summarizes the maturities of our available-for-sale debt investments as of October 25, 2025 (in millions):

[0000858877-25-000171:notes:131]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 3,925 |  |  | $ | 3,883 |  |
| After 1 year through 5 years | 2,768 |  |  | 2,784 |  |
| After 5 years through 10 years | 21 |  |  | 21 |  |
| Mortgage- and asset-backed securities with no single maturity | 270 |  |  | 254 |  |
| Total | $ | 6,984 |  |  | $ | 6,942 |  |

[0000858877-25-000171:notes:132]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-25-000171:notes:133]
(b)Marketable Equity Securities

[0000858877-25-000171:notes:134]
We held marketable equity securities of $394 million and $383 million as of October 25, 2025 and July 26, 2025, respectively. We recognized net unrealized gains of $30 million and $25 million during the first quarter of fiscal 2026 and fiscal 2025, respectively, on our marketable securities still held as of the reporting date.

[0000858877-25-000171:notes:135]
(c)Investments in Privately Held Companies

[0000858877-25-000171:notes:136]
The carrying value of our investments in privately held companies was $2.1 billion and $1.9 billion as of October 25, 2025 and July 26, 2025, respectively. As of October 25, 2025, we have total funding commitments of $0.5 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.

[0000858877-25-000171:notes:137]
Investments in privately held companies measured using the measurement alternative had a carrying value of $0.7 billion and $0.6 billion as of October 25, 2025 and July 26, 2025, respectively. We have recorded cumulative adjustments to the carrying value of our investments in privately held companies measured using the measurement alternative as follows (in millions):

[0000858877-25-000171:notes:138]
|  | October 25, 2025 |  | July 26, 2025 |
| Cumulative upward adjustments | $ | 277 |  |  | $ | 195 |  |
| Cumulative downward adjustments, including impairments | (595) |  |  | (597) |  |
| Net adjustments | $ | (318) |  |  | $ | (402) |  |

[0000858877-25-000171:notes:139]
We held equity interests in certain private equity funds of $0.7 billion as of each of October 25, 2025 and July 26, 2025, which are accounted for under the NAV practical expedient.

[0000858877-25-000171:notes:140]
Of the total carrying value of our investments in privately held companies as of October 25, 2025, $0.8 billion of such investments are considered to be in variable interest entities which are unconsolidated.

[0000858877-25-000171:notes:141]
Certain of our investments in privately held companies are required to be consolidated under the voting interest entity model. The noncontrolling interest attributed to these investments was $206 million and $162 million as of October 25, 2025 and July 26, 2025, respectively, and is included in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interest attributed to these investments is not material for any of the periods presented and is included in other income (loss), net in the Consolidated Statements of Operations.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-25-000171:notes:142]
[same as prior period, unchanged from 0000858877-25-000033:notes:149]

[0000858877-25-000171:notes:143]
[same as prior period, unchanged from 0000858877-25-000033:notes:150]

[0000858877-25-000171:notes:144]
|  | OCTOBER 25, 2025 |  | JULY 26, 2025 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 6,082 |  |  | $ | — |  |  | $ | 6,082 |  |  | $ | 5,885 |  |  | $ | — |  |  | $ | 5,885 |  |
| Commercial paper | — |  |  | 149 |  |  | 149 |  |  | — |  |  | 336 |  |  | 336 |  |
| Corporate debt securities | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 1,640 |  |  | 1,640 |  |  | — |  |  | 1,961 |  |  | 1,961 |  |
| U.S. government agency securities | — |  |  | 49 |  |  | 49 |  |  | — |  |  | 67 |  |  | 67 |  |
| Non-U.S. government and agency securities | — |  |  | 410 |  |  | 410 |  |  | — |  |  | 458 |  |  | 458 |  |
| Corporate debt securities | — |  |  | 2,949 |  |  | 2,949 |  |  | — |  |  | 3,090 |  |  | 3,090 |  |
| Mortgage- and asset-backed securities | — |  |  | 254 |  |  | 254 |  |  | — |  |  | 286 |  |  | 286 |  |
| Commercial paper | — |  |  | 884 |  |  | 884 |  |  | — |  |  | 950 |  |  | 950 |  |
| Certificates of deposit | — |  |  | 756 |  |  | 756 |  |  | — |  |  | 569 |  |  | 569 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 394 |  |  | — |  |  | 394 |  |  | 383 |  |  | — |  |  | 383 |  |
| Other current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | — |  |  | — |  |  | — |  |  | 563 |  |  | — |  |  | 563 |  |
| Derivative assets | — |  |  | 55 |  |  | 55 |  |  | — |  |  | 32 |  |  | 32 |  |
| Total | $ | 6,476 |  |  | $ | 7,146 |  |  | $ | 13,622 |  |  | $ | 6,831 |  |  | $ | 7,750 |  |  | $ | 14,581 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 58 |  |  | $ | 58 |  |  | $ | — |  |  | $ | 31 |  |  | $ | 31 |  |
| Total | $ | — |  |  | $ | 58 |  |  | $ | 58 |  |  | $ | — |  |  | $ | 31 |  |  | $ | 31 |  |

[0000858877-25-000171:notes:145]
[same as prior period, unchanged from 0000858877-25-000033:notes:152]

[0000858877-25-000171:notes:146]
[same as prior period, unchanged from 0000858877-25-000033:notes:153]

[0000858877-25-000171:notes:147]
[same as prior period, unchanged from 0000858877-25-000033:notes:154]

[0000858877-25-000171:notes:148]
[same as prior period, unchanged from 0000858877-25-000033:notes:156]

[0000858877-25-000171:notes:149]
The fair value of our short-term loan receivables approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables was $3.1 billion and $2.9 billion as of October 25, 2025 and July 26, 2025, respectively. The estimated fair value of our long-term loan receivables approximates their carrying value. We use unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables, and therefore they are categorized as Level 3.
As of October 25, 2025, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of October 25, 2025, the fair value of our senior notes was $25.5 billion, with a carrying amount of $24.6 billion. This compares to a fair value of $25.0 billion and a carrying amount of $24.6 billion as of July 26, 2025. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2.


## us-gaap:DebtDisclosureTextBlock

[0000858877-25-000171:notes:150]
Borrowings 
(a)Short-Term Debt

[0000858877-25-000171:notes:151]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-25-000171:notes:152]
|  | October 25, 2025 |  | July 26, 2025 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 3,249 |  |  | 3.41 | % |  | $ | 1,749 |  |  | 4.15 | % |
| Commercial paper | 3,476 |  |  | 4.09 | % |  | 3,482 |  |  | 4.37 | % |
| Current portion of other debt | — |  |  | — |  |  | 1 |  |  | 1.13 | % |
| Total | $ | 6,725 |  |  |  |  | $ | 5,232 |  |  |  |

[0000858877-25-000171:notes:153]
We have a short-term debt financing program of up to $15.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-25-000171:notes:154]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-25-000171:notes:155]
(b)Long-Term Debt

[0000858877-25-000171:notes:156]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-25-000171:notes:157]
|  |  |  | October 25, 2025 |  | July 26, 2025 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.90% | February 26, 2026 |  | $ | 1,000 |  |  | 5.00% |  | $ | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | 4.61% |  | 1,000 |  |  | 4.61% |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | 4.73% |  | 1,000 |  |  | 4.73% |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | 4.94% |  | 1,000 |  |  | 4.94% |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | 5.11% |  | 1,250 |  |  | 5.11% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.50% | February 24, 2055 |  | 750 |  |  | 5.49% |  | 750 |  |  | 5.49% |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 2 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 24,752 |  |  |  |  | 24,753 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (139) |  |  |  |  | (142) |  |  |  |
| Total |  |  | $ | 24,613 |  |  |  |  | $ | 24,611 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,249 |  |  |  |  | $ | 1,750 |  |  |  |
| Long-term debt |  |  | 21,364 |  |  |  |  | 22,861 |  |  |  |
| Total |  |  | $ | 24,613 |  |  |  |  | $ | 24,611 |  |  |  |

[0000858877-25-000171:notes:158]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 25, 2025, we were in compliance with all debt covenants.

[0000858877-25-000171:notes:159]
As of October 25, 2025, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-25-000171:notes:160]
| Fiscal Year | Amount |
| 2026 (remaining nine months) | $ | 1,750 |  |
| 2027 | 3,502 |  |
| 2028 | 1,000 |  |
| 2029 | 2,500 |  |
| 2030 | 1,000 |  |
| Thereafter | 15,000 |  |
| Total | $ | 24,752 |  |

[0000858877-25-000171:notes:161]
(c)Credit Facility

[0000858877-25-000171:notes:162]
On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of October 25, 2025, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-25-000171:notes:163]
[same as prior period, unchanged from 0000858877-25-000033:notes:173]

[0000858877-25-000171:notes:164]
[same as prior period, unchanged from 0000858877-25-000033:notes:174]

[0000858877-25-000171:notes:165]
[same as prior period, unchanged from 0000858877-25-000033:notes:175]

[0000858877-25-000171:notes:166]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | October 25,2025 |  | July 26,2025 |  | Balance Sheet Line Item |  | October 25,2025 |  | July 26,2025 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 27 |  |  | $ | 17 |  |  | Other current liabilities |  | $ | 1 |  |  | $ | 2 |  |
| Foreign currency derivatives | Other assets |  | 27 |  |  | 10 |  |  | Other long-term liabilities |  | — |  |  | 2 |  |
| Total |  |  | 54 |  |  | 27 |  |  |  |  | 1 |  |  | 4 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 1 |  |  | 3 |  |  | Other current liabilities |  | 30 |  |  | 17 |  |
| Foreign currency derivatives | Other assets |  | — |  |  | 2 |  |  | Other long-term liabilities |  | 27 |  |  | 10 |  |
| Total |  |  | 1 |  |  | 5 |  |  |  |  | 57 |  |  | 27 |  |
| Total |  |  | $ | 55 |  |  | $ | 32 |  |  |  |  | $ | 58 |  |  | $ | 31 |  |

[0000858877-25-000171:notes:167]
[same as prior period, unchanged from 0000858877-25-000033:notes:181]

[0000858877-25-000171:notes:168]
|  |  |  |  | GAINS (LOSSES) FOR THE THREE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | October 25,2025 |  | October 26,2024 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (46) |  |  | $ | (32) |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | 54 |  |  | 22 |  |
| Total |  |  |  | $ | 8 |  |  | $ | (10) |  |

[0000858877-25-000171:notes:169]
[same as prior period, unchanged from 0000858877-25-000033:notes:183]

[0000858877-25-000171:notes:170]
|  | October 25,2025 |  | July 26,2025 |
| Foreign currency derivatives | $ | 8,006 |  |  | $ | 8,978 |  |
| Total return swaps—deferred compensation | 1,195 |  |  | 1,087 |  |
| Total | $ | 9,201 |  |  | $ | 10,065 |  |

[0000858877-25-000171:notes:171]
[same as prior period, unchanged from 0000858877-25-000033:notes:185]

[0000858877-25-000171:notes:172]
[same as prior period, unchanged from 0000858877-25-000033:notes:186]

[0000858877-25-000171:notes:173]
[same as prior period, unchanged from 0000858877-25-000033:notes:188]

[0000858877-25-000171:notes:174]
[same as prior period, unchanged from 0000858877-25-000033:notes:189]

[0000858877-25-000171:notes:175]
[same as prior period, unchanged from 0000858877-25-000033:notes:190]

[0000858877-25-000171:notes:176]
[same as prior period, unchanged from 0000858877-25-000033:notes:191]

[0000858877-25-000171:notes:177]
[same as prior period, unchanged from 0000858877-25-000033:notes:192]

[0000858877-25-000171:notes:178]
[same as prior period, unchanged from 0000858877-25-000033:notes:193]

[0000858877-25-000171:notes:179]
[same as prior period, unchanged from 0000858877-25-000033:notes:195]

[0000858877-25-000171:notes:180]
(e)Equity Price Risk 
We are exposed to variability in compensation charges related to certain deferred compensation obligations to employees and directors. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure and offset the related compensation expense.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-25-000171:notes:181]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-25-000171:notes:182]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments are directly with suppliers, and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-25-000171:notes:183]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-25-000171:notes:184]
|  | October 25,2025 |  | July 26,2025 |
| Less than 1 year | $ | 7,879 |  |  | $ | 7,202 |  |
| 1 to 3 years | 396 |  |  | 320 |  |
| 3 to 5 years | 46 |  |  | 77 |  |
| Total | $ | 8,321 |  |  | $ | 7,599 |  |

[0000858877-25-000171:notes:185]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 25, 2025 and July 26, 2025, the liability for these purchase commitments was $185 million and $206 million, respectively, and was included in other current liabilities.

[0000858877-25-000171:notes:186]
(b)Other Commitments

[0000858877-25-000171:notes:187]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.5 billion and $0.3 billion as of October 25, 2025 and July 26, 2025, respectively.

[0000858877-25-000171:notes:188]
(c)Product Warranties

[0000858877-25-000171:notes:189]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-25-000171:notes:190]
|  | Three Months Ended |
|  | October 25,2025 |  | October 26,2024 |
| Balance at beginning of period | $ | 399 |  |  | $ | 362 |  |
| Provisions for warranties issued | 104 |  |  | 105 |  |
| Adjustments for pre-existing warranties | — |  |  | 1 |  |
| Settlements | (111) |  |  | (111) |  |
| Balance at end of period | $ | 392 |  |  | $ | 357 |  |

[0000858877-25-000171:notes:191]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-25-000171:notes:192]
(d)Financing and Other Guarantees

[0000858877-25-000171:notes:193]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-25-000171:notes:194]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.7 billion and $6.0 billion for the first quarter of fiscal 2026 and 2025, respectively. The balance of the channel partner financing subject to guarantees was $1.5 billion and $1.3 billion as of October 25, 2025 and July 26, 2025, respectively.

[0000858877-25-000171:notes:195]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at October 25, 2025 and July 26, 2025, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-25-000171:notes:196]
|  | October 25,2025 |  | July 26,2025 |
| Maximum potential future payments | $ | 134 |  |  | $ | 123 |  |
| Deferred revenue | (17) |  |  | (13) |  |
| Total | $ | 117 |  |  | $ | 110 |  |

[0000858877-25-000171:notes:197]
(e)Indemnifications

[0000858877-25-000171:notes:198]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-25-000171:notes:199]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of

[0000858877-25-000171:notes:200]
cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-25-000171:notes:201]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-25-000171:notes:202]
(f)Legal Proceedings

[0000858877-25-000171:notes:203]
Brazil  Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The remaining asserted claims by Brazilian federal tax authorities are for calendar years 2004 through 2007, and the remaining asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total remaining asserted claims by Brazilian state and federal tax authorities aggregate to $145 million for the alleged evasion of import and other taxes, $851 million for interest, and $298 million for various penalties, all determined using an exchange rate as of October 25, 2025.

[0000858877-25-000171:notes:204]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-25-000171:notes:205]
Centripetal  On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. After two bench trials and various administrative actions and appeals, we have been found either to not have infringed any of the patents or the patents have been invalidated. Centripetal appealed one of the Patent Trial and Appeal Board’s (“PTAB”) invalidity decisions and on October 22, 2025, the Federal Circuit vacated the decision and remanded the case to the PTAB for further consideration. Centripetal’s appeal of the non-infringement judgment of the District Court is ongoing.

[0000858877-25-000171:notes:206]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringed three patents, one patent was invalidated, and the utility model was invalidated. The infringement action on the final patent is stayed due to an invalidity action heard on June 6, 2024 in the Federal Patent Court, in which all claims, aside from one auxiliary claim, were found invalid, and for which we are awaiting a decision on appeal from the German Federal Court of Justice. Centripetal’s appeals of two of the non-infringement findings remain pending and, on March 27, 2024, the Court of Appeals rejected Centripetal’s appeal of the third non-infringement finding. In an appellate decision on December 11, 2024, the German Federal Court of Justice revoked one of the two patents for which Centripetal appealed the finding of non-infringement, rendering moot the noninfringement appeal of that patent.

[0000858877-25-000171:notes:207]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement. We have filed our response and defenses to the complaint and the case briefing is ongoing. While the Court has not set a final hearing date, we anticipate that it will occur in the third calendar quarter of 2026.

[0000858877-25-000171:notes:208]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of the litigations at this time. If we do not prevail in these litigations, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-25-000171:notes:209]
Ramot  On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D.

[0000858877-25-000171:notes:210]
Del. on other Ramot patents and those proceedings are ongoing. The Court rescheduled the trial date in the D. Del. cases for December 1, 2025.

[0000858877-25-000171:notes:211]
While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-25-000171:notes:212]
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-25-000171:notes:213]
Purchase Commitments with Contract Manufacturers and Suppliers We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments are directly with suppliers, and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-25-000171:notes:214]
[same as prior period, unchanged from 0000858877-25-000033:notes:229]

[0000858877-25-000171:notes:215]
In September 2001, our Board of Directors authorized a stock repurchase program. As of October 25, 2025, the remaining authorized amount for stock repurchases under this program was approximately $12.2 billion, with no termination date. The stock repurchase activity for fiscal 2026 and 2025 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-25-000171:notes:216]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2026 |  |  |  |  |  |  |
| October 25, 2025 |  | 29 |  |  | $ | 68.28 |  |  | $ | 2,001 |  |
| Fiscal 2025 |  |  |  |  |  |  |
| July 26, 2025 |  | 19 |  |  | $ | 64.65 |  |  | $ | 1,252 |  |
| April 26, 2025 |  | 25 |  |  | $ | 59.78 |  |  | $ | 1,504 |  |
| January 25, 2025 |  | 21 |  |  | $ | 58.58 |  |  | $ | 1,236 |  |
| October 26, 2024 |  | 40 |  |  | $ | 49.56 |  |  | $ | 2,003 |  |

[0000858877-25-000171:notes:217]
There were stock repurchases of $29 million and $20 million that were pending settlement October 25, 2025 and July 26, 2025, respectively.

[0000858877-25-000171:notes:218]
[same as prior period, unchanged from 0000858877-25-000033:notes:233]

[0000858877-25-000171:notes:219]
[same as prior period, unchanged from 0000858877-25-000033:notes:234]

[0000858877-25-000171:notes:220]
On November 12, 2025, our Board of Directors declared a quarterly dividend of $0.41 per common share to be paid on January 21, 2026, to all stockholders of record as of the close of business on January 2, 2026. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-25-000171:notes:221]
[same as prior period, unchanged from 0000858877-25-000033:notes:236]

[0000858877-25-000171:notes:222]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock in one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights, if any, of such series, and any qualifications, limitations or restrictions thereof, of the shares of such series. As of October 25, 2025, we have not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-25-000171:notes:223]
[same as prior period, unchanged from 0000858877-25-000033:notes:238]

[0000858877-25-000171:notes:224]
[same as prior period, unchanged from 0000858877-25-000033:notes:239]

[0000858877-25-000171:notes:225]
The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions. Time-based and performance-based RSUs generally vest over three years with certain awards containing retirement eligible provisions. Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. The 2005 Plan may be terminated by our Board of Directors at any time and for any reason, and is currently set to terminate at the 2030 Annual Meeting unless re-adopted or extended by our stockholders prior to or on such date.

[0000858877-25-000171:notes:226]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of October 25, 2025, 90 million shares were authorized for future grant under the 2005 Plan.

[0000858877-25-000171:notes:227]
[same as prior period, unchanged from 0000858877-25-000033:notes:243]

[0000858877-25-000171:notes:228]
We have an Employee Stock Purchase Plan under which eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. No shares were issued under the Employee Stock Purchase Plan during the first quarter of each of fiscal 2026 and 2025. As of October 25, 2025, 50 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-25-000171:notes:229]
[same as prior period, unchanged from 0000858877-25-000033:notes:245]

[0000858877-25-000171:notes:230]
[same as prior period, unchanged from 0000858877-25-000033:notes:246]

[0000858877-25-000171:notes:231]
|  | Three Months Ended |  |  |
|  | October 25, 2025 |  | October 26, 2024 |  |  |  |  |
| Cost of sales—product | $ | 68 |  |  | $ | 57 |  |  |  |  |  |
| Cost of sales—services | 82 |  |  | 74 |  |  |  |  |  |
| Share-based compensation expense in cost of sales | 150 |  |  | 131 |  |  |  |  |  |
| Research and development | 484 |  |  | 354 |  |  |  |  |  |
| Sales and marketing | 269 |  |  | 210 |  |  |  |  |  |
| General and administrative | 131 |  |  | 115 |  |  |  |  |  |
| Restructuring and other charges | 21 |  |  | 17 |  |  |  |  |  |
| Share-based compensation expense in operating expenses | 905 |  |  | 696 |  |  |  |  |  |
| Total share-based compensation expense | $ | 1,055 |  |  | $ | 827 |  |  |  |  |  |
| Income tax benefit for share-based compensation | $ | 241 |  |  | $ | 174 |  |  |  |  |  |

[0000858877-25-000171:notes:232]
As of October 25, 2025, the total compensation cost related to unvested share-based awards not yet recognized was $4.2 billion which is expected to be recognized over approximately 1.9 years on a weighted-average basis.

[0000858877-25-000171:notes:233]
[same as prior period, unchanged from 0000858877-25-000033:notes:249]

[0000858877-25-000171:notes:234]
[same as prior period, unchanged from 0000858877-25-000033:notes:250]

[0000858877-25-000171:notes:235]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| Unvested balance at July 27, 2024 | 117 |  |  | $ | 46.86 |  |  |  |
| Granted and assumed | 70 |  |  | 55.73 |  |  |  |
| Vested | (65) |  |  | 46.95 |  |  | $ | 3,707 |  |
| Canceled/forfeited/other | (9) |  |  | 48.04 |  |  |  |
| Unvested balance at July 26, 2025 | 113 |  |  | 52.26 |  |  |  |
| Granted and assumed | 11 |  |  | 64.74 |  |  |  |
| Vested | (12) |  |  | 46.35 |  |  | $ | 851 |  |
| Canceled/forfeited/other | 4 |  |  | 48.91 |  |  |  |
| Unvested balance at October 25, 2025 | 116 |  |  | $ | 53.91 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-25-000171:notes:236]
Accumulated Other Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first quarter of fiscal 2026 and 2025 are summarized as follows (in millions):

[0000858877-25-000171:notes:237]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 26, 2025 | $ | (57) |  |  | $ | 65 |  |  | $ | (962) |  |  | $ | (954) |  |
| Other comprehensive income (loss) before reclassifications | 48 |  |  | 42 |  |  | (41) |  |  | 49 |  |
| (Gains) losses reclassified out of AOCI | 4 |  |  | (9) |  |  | — |  |  | (5) |  |
| Tax benefit (expense) | (11) |  |  | (8) |  |  | (1) |  |  | (20) |  |
| Balance at October 25, 2025 | $ | (16) |  |  | $ | 90 |  |  | $ | (1,004) |  |  | $ | (930) |  |

[0000858877-25-000171:notes:238]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 27, 2024 | $ | (241) |  |  | $ | 79 |  |  | $ | (1,268) |  |  | $ | (1,430) |  |
| Other comprehensive income (loss) before reclassifications | 71 |  |  | 9 |  |  | (19) |  |  | 61 |  |
| (Gains) losses reclassified out of AOCI | 25 |  |  | (9) |  |  | — |  |  | 16 |  |
| Tax benefit (expense) | (23) |  |  | — |  |  | — |  |  | (23) |  |
| Balance at October 26, 2024 | $ | (168) |  |  | $ | 79 |  |  | $ | (1,287) |  |  | $ | (1,376) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-25-000171:notes:239]
[same as prior period, unchanged from 0000858877-25-000033:notes:255]

[0000858877-25-000171:notes:240]
|  | Three Months Ended |
|  | October 25,2025 |  | October 26,2024 |
| Income before provision for (benefit from) income taxes | $ | 3,391 |  |  | $ | 2,267 |  |
| Provision for (benefit from) income taxes | 531 |  |  | (444) |  |
| Effective tax rate | 15.7 | % |  | (19.6) | % |

[0000858877-25-000171:notes:241]
As of October 25, 2025, we had $2.3 billion of unrecognized tax benefits, of which $1.6 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.

[0000858877-25-000171:notes:242]
[same as prior period, unchanged from 0000858877-25-000033:notes:258]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-25-000171:notes:243]
[same as prior period, unchanged from 0000858877-25-000033:notes:259]

[0000858877-25-000171:notes:244]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our chief executive officer is the chief operating decision maker (CODM). The CODM reviews certain financial information for each segment, to evaluate performance and allocate resources by comparing actual performance to our annual targets. Performance of each segment is measured based on segment revenue and segment gross margin. Sales are attributed to a segment based on the location of the customer.

[0000858877-25-000171:notes:245]
We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because the CODM does not include this information in our measurement of performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the cost of sales and gross margin for each segment because the CODM does not include this information in the measurement of the performance of our operating segments.

[0000858877-25-000171:notes:246]
The following summarizes our revenue and gross margin by segment and the significant expenses by each segment (in millions):

[0000858877-25-000171:notes:247]
|  | Three Months Ended |
|  | October 25,2025 |  | October 26,2024 |
| Revenue: |  |  |  |
| Americas | $ | 8,989 |  |  | $ | 8,252 |  |
| EMEA | 3,784 |  |  | 3,588 |  |
| APJC | 2,111 |  |  | 2,001 |  |
| Total | $ | 14,883 |  |  | $ | 13,841 |  |
| Gross margin: |  |  |  |
| Americas | $ | 6,001 |  |  | $ | 5,740 |  |
| EMEA | 2,722 |  |  | 2,522 |  |
| APJC | 1,413 |  |  | 1,328 |  |
| Segment total | 10,136 |  |  | 9,590 |  |
| Unallocated corporate items | (391) |  |  | (469) |  |
| Total | $ | 9,745 |  |  | $ | 9,121 |  |
| Supplemental information about our significant expenses: |  |  |  |
| Americas: |  |  |  |
| Cost of sales — product | $ | 2,349 |  |  | $ | 1,877 |  |
| Cost of sales — services | 639 |  |  | 635 |  |
| Segment total | $ | 2,988 |  |  | $ | 2,512 |  |
| EMEA: |  |  |  |
| Cost of sales — product | $ | 768 |  |  | $ | 778 |  |
| Cost of sales — services | 294 |  |  | 288 |  |
| Segment total | $ | 1,062 |  |  | $ | 1,066 |  |
| APJC: |  |  |  |
| Cost of sales — product | $ | 514 |  |  | $ | 490 |  |
| Cost of sales — services | 184 |  |  | 183 |  |
| Segment total | $ | 698 |  |  | $ | 673 |  |

[0000858877-25-000171:notes:248]
Revenue in the United States was $8.1 billion and $7.4 billion for the first quarter of fiscal 2026 and 2025, respectively.

[0000858877-25-000171:notes:249]
[same as prior period, unchanged from 0000858877-25-000033:notes:264]

[0000858877-25-000171:notes:250]
We design and sell IP-based networking and other products related to the communications and IT industry and provide services associated with these products and their use.


## us-gaap:EarningsPerShareTextBlock

[0000858877-25-000171:notes:251]
[same as prior period, unchanged from 0000858877-25-000033:notes:266]

[0000858877-25-000171:notes:252]
|  | Three Months Ended |
|  | October 25,2025 |  | October 26,2024 |
| Net income | $ | 2,860 |  |  | $ | 2,711 |  |
| Weighted-average shares—basic | 3,956 |  |  | 3,990 |  |
| Effect of dilutive potential common shares | 37 |  |  | 23 |  |
| Weighted-average shares—diluted | 3,993 |  |  | 4,013 |  |
| Net income per share—basic | $ | 0.72 |  |  | $ | 0.68 |  |
| Net income per share—diluted | $ | 0.72 |  |  | $ | 0.68 |  |
| Antidilutive employee share-based awards, excluded | — |  |  | 13 |  |
