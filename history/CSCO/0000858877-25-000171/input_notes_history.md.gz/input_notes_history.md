# CSCO note change history — 0000858877-25-000033 → 0000858877-25-000171


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-11-18):
[0000858877-25-000171:note_history:1]
|  | October 25,2025 |  | July 26,2025 |
| Less than 1 year | $ | 7,879 |  |  | $ | 7,202 |  |
| 1 to 3 years | 396 |  |  | 320 |  |
| 3 to 5 years | 46 |  |  | 77 |  |
| Total | $ | 8,321 |  |  | $ | 7,599 |  |
  (was, 2025-05-20, similarity 0.9691):
[0000858877-25-000033:note_history:1]
|  | April 26,2025 |  | July 27,2024 |
| Less than 1 year | $ | 5,773 |  |  | $ | 3,952 |  |
| 1 to 3 years | 509 |  |  | 1,085 |  |
| 3 to 5 years | 63 |  |  | 121 |  |
| Total | $ | 6,345 |  |  | $ | 5,158 |  |

- changed (2025-11-18):
[0000858877-25-000171:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 25, 2025 and July 26, 2025, the liability for these purchase commitments was $185 million and $206 million, respectively, and was included in other current liabilities.
  (was, 2025-05-20, similarity 0.984):
[0000858877-25-000033:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 26, 2025 and July 27, 2024, the liability for these purchase commitments was $246 million and $498 million, respectively, and was included in other current liabilities.

- changed (2025-11-18):
[0000858877-25-000171:note_history:3]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.5 billion and $0.3 billion as of October 25, 2025 and July 26, 2025, respectively.
  (was, 2025-05-20, similarity 0.9734):
[0000858877-25-000033:note_history:3]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.3 billion and $0.2 billion as of April 26, 2025 and July 27, 2024, respectively.

- changed (2025-11-18):
[0000858877-25-000171:note_history:4]
|  | Three Months Ended |
|  | October 25,2025 |  | October 26,2024 |
| Balance at beginning of period | $ | 399 |  |  | $ | 362 |  |
| Provisions for warranties issued | 104 |  |  | 105 |  |
| Adjustments for pre-existing warranties | — |  |  | 1 |  |
| Settlements | (111) |  |  | (111) |  |
| Balance at end of period | $ | 392 |  |  | $ | 357 |  |
  (was, 2025-05-20, similarity 0.8595):
[0000858877-25-000033:note_history:4]
|  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |
| Balance at beginning of period | $ | 362 |  |  | $ | 329 |  |
| Provisions for warranties issued | 300 |  |  | 316 |  |
| Adjustments for pre-existing warranties | 40 |  |  | 20 |  |
| Settlements | (306) |  |  | (302) |  |
| Balance at end of period | $ | 396 |  |  | $ | 363 |  |

- changed (2025-11-18):
[0000858877-25-000171:note_history:5]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.7 billion and $6.0 billion for the first quarter of fiscal 2026 and 2025, respectively. The balance of the channel partner financing subject to guarantees was $1.5 billion and $1.3 billion as of October 25, 2025 and July 26, 2025, respectively.
  (was, 2025-05-20, similarity 0.885):
[0000858877-25-000033:note_history:5]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $5.9 billion and $6.1 billion for the third quarter of fiscal 2025 and 2024, respectively, and $18.1 billion and $20.9 billion for the first nine months of fiscal 2025 and 2024, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion as of each of April 26, 2025 and July 27, 2024.

- changed (2025-11-18):
[0000858877-25-000171:note_history:6]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at October 25, 2025 and July 26, 2025, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2025-05-20, similarity 0.9817):
[0000858877-25-000033:note_history:6]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at April 26, 2025 and July 27, 2024, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2025-11-18):
[0000858877-25-000171:note_history:7]
|  | October 25,2025 |  | July 26,2025 |
| Maximum potential future payments | $ | 134 |  |  | $ | 123 |  |
| Deferred revenue | (17) |  |  | (13) |  |
| Total | $ | 117 |  |  | $ | 110 |  |
  (was, 2025-05-20, similarity 0.9679):
[0000858877-25-000033:note_history:7]
|  | April 26,2025 |  | July 27,2024 |
| Maximum potential future payments | $ | 116 |  |  | $ | 127 |  |
| Deferred revenue | (10) |  |  | (13) |  |
| Total | $ | 106 |  |  | $ | 114 |  |

- changed (2025-11-18):
[0000858877-25-000171:note_history:8]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of
  (was, 2025-05-20, similarity 0.7049):
[0000858877-25-000033:note_history:8]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

- added (2025-11-18):
[0000858877-25-000171:note_history:9]
cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

- changed (2025-11-18):
[0000858877-25-000171:note_history:10]
Brazil  Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The remaining asserted claims by Brazilian federal tax authorities are for calendar years 2004 through 2007, and the remaining asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total remaining asserted claims by Brazilian state and federal tax authorities aggregate to $145 million for the alleged evasion of import and other taxes, $851 million for interest, and $298 million for various penalties, all determined using an exchange rate as of October 25, 2025.
  (was, 2025-05-20, similarity 0.9951):
[0000858877-25-000033:note_history:10]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The remaining asserted claims by Brazilian federal tax authorities are for calendar years 2004 through 2007, and the remaining asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total remaining asserted claims by Brazilian state and federal tax authorities aggregate to $138 million for the alleged evasion of import and other taxes, $788 million for interest, and $282 million for various penalties, all determined using an exchange rate as of April 26, 2025.

- changed (2025-11-18):
[0000858877-25-000171:note_history:11]
Centripetal  On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. After two bench trials and various administrative actions and appeals, we have been found either to not have infringed any of the patents or the patents have been invalidated. Centripetal appealed one of the Patent Trial and Appeal Board’s (“PTAB”) invalidity decisions and on October 22, 2025, the Federal Circuit vacated the decision and remanded the case to the PTAB for further consideration. Centripetal’s appeal of the non-infringement judgment of the District Court is ongoing.
  (was, 2025-05-20, similarity 0.6837):
[0000858877-25-000033:note_history:11]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. After two bench trials and various administrative actions and appeals, we have been found either to not have infringed any of the patents or the patents have been invalidated. Centripetal appealed one of the invalidity decisions and we are awaiting the decision following the Federal Circuit hearing on that appeal on February 6, 2025. Centripetal’s appeal of the non-infringement judgment of the District Court is ongoing.

- changed (2025-11-18):
[0000858877-25-000171:note_history:12]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringed three patents, one patent was invalidated, and the utility model was invalidated. The infringement action on the final patent is stayed due to an invalidity action heard on June 6, 2024 in the Federal Patent Court, in which all claims, aside from one auxiliary claim, were found invalid, and for which we are awaiting a decision on appeal from the German Federal Court of Justice. Centripetal’s appeals of two of the non-infringement findings remain pending and, on March 27, 2024, the Court of Appeals rejected Centripetal’s appeal of the third non-infringement finding. In an appellate decision on December 11, 2024, the German Federal Court of Justice revoked one of the two patents for which Centripetal appealed the finding of non-infringement, rendering moot the noninfringement appeal of that patent.
  (was, 2025-05-20, similarity 0.8282):
[0000858877-25-000033:note_history:12]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringed three patents, one patent was invalidated, and the utility model was invalidated. The infringement action on the final patent is stayed due to an invalidity action heard on June 6, 2024 in the Federal Patent Court, in which all claims, aside from one auxiliary claim, were found invalid, and for which we are awaiting the entry of judgment from the Federal Patent Court. Centripetal’s appeals of two of the non-infringement findings remain pending and, on March 27, 2024, the Court of Appeals rejected Centripetal’s appeal of the third non-infringement finding.

- changed (2025-11-18):
[0000858877-25-000171:note_history:13]
Ramot  On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D.
  (was, 2025-05-20, similarity 0.9235):
[0000858877-25-000033:note_history:13]
Ramot     On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents and those proceedings are ongoing. The Court set trial in the D. Del. cases for November 3, 2025.

- added (2025-11-18):
[0000858877-25-000171:note_history:14]
Del. on other Ramot patents and those proceedings are ongoing. The Court rescheduled the trial date in the D. Del. cases for December 1, 2025.

- added (2025-11-18):
[0000858877-25-000171:note_history:15]
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements.

- removed (2025-11-18):
[0000858877-25-000033:note_history:16]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023. The Federal Circuit heard oral argument on October 11, 2024 and we are awaiting the decision.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-11-18):
[0000858877-25-000171:note_history:17]
Organization and Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2026 and fiscal 2025 are each 52-week fiscal years. The Consolidated Financial Statements include our accounts and those of our subsidiaries and those of our investments consolidated under the voting interest method. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).
  (was, 2025-05-20, similarity 0.9418):
[0000858877-25-000033:note_history:17]
Organization and Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2025 and fiscal 2024 are each 52-week fiscal years. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

- changed (2025-11-18):
[0000858877-25-000171:note_history:18]
We have prepared the accompanying financial data as of October 25, 2025 and for the first quarter of fiscal 2026 and 2025, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 26, 2025 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 26, 2025.
  (was, 2025-05-20, similarity 0.9779):
[0000858877-25-000033:note_history:18]
We have prepared the accompanying financial data as of April 26, 2025 and for the third quarter and first nine months of fiscal 2025 and 2024, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2024 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2024.

- added (2025-11-18):
[0000858877-25-000171:note_history:19]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of October 25, 2025, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2026 and 2025, as applicable, have been made. The results of operations for the first quarter of fiscal 2026 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2025-11-18):
[0000858877-25-000033:note_history:20]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of April 26, 2025, the results of operations, the statements of comprehensive income and the statements of equity for the third quarter and first nine months of fiscal 2025 and 2024, and the statements of cash flows for the first nine months of fiscal 2025 and 2024, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2025 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2025-11-18):
[0000858877-25-000033:note_history:21]
Our consolidated financial statements include our accounts and investments consolidated under the voting interest model. The noncontrolling interests attributed to these investments are not presented as a separate component in the equity section of the Consolidated Balance Sheets as these amounts are not material for any of the fiscal periods presented. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

- removed (2025-11-18):
[0000858877-25-000033:note_history:22]
We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-11-18):
[0000858877-25-000171:note_history:23]
Disaggregation of Income Statement Expenses  In November 2024, the FASB issued an accounting standard update expanding the disclosure requirements about specific expense categories, primarily through disaggregated information on income statement line items. The accounting standard update will be effective for our fiscal 2028 Form 10-K, and early adoption is permitted. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.
Targeted Improvements to the Accounting for Internal-Use Software  In September 2025, the FASB issued an accounting standard update to modernize the accounting for internal-use software costs and clarify the criteria for capitalization. The accounting standard update will be effective for our interim and annual reporting periods of fiscal 2029, with early adoption permitted. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.
  (was, 2025-05-20, similarity 0.663):
[0000858877-25-000033:note_history:23]
Disaggregation of Income Statement Expenses  In November 2024, the FASB issued an accounting standard update expanding the disclosure requirements about specific expense categories, primarily through disaggregated information on income statement line items. The accounting standard update will be effective for our fiscal 2028 Form 10-K, and early adoption is permitted. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.

- removed (2025-11-18):
[0000858877-25-000033:note_history:24]
Segment Reporting  In November 2023, the Financial Accounting Standards Board (FASB) issued an accounting standard update that expands the disclosure requirements for reportable segments, primarily through enhanced disclosures around significant segment expenses. The accounting standard update will be effective for our fiscal 2025 Form 10-K on a retrospective basis, and early adoption is permitted. We are currently evaluating the impact of this accounting standard update on our segment disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-18):
[0000858877-25-000171:note_history:25]
|  | October 25, 2025 |  | July 26, 2025 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 3,249 |  |  | 3.41 | % |  | $ | 1,749 |  |  | 4.15 | % |
| Commercial paper | 3,476 |  |  | 4.09 | % |  | 3,482 |  |  | 4.37 | % |
| Current portion of other debt | — |  |  | — |  |  | 1 |  |  | 1.13 | % |
| Total | $ | 6,725 |  |  |  |  | $ | 5,232 |  |  |  |
  (was, 2025-05-20, similarity 0.9273):
[0000858877-25-000033:note_history:25]
|  | April 26, 2025 |  | July 27, 2024 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 2,247 |  |  | 4.48 | % |  | $ | 488 |  |  | 6.66 | % |
| Commercial paper | 4,174 |  |  | 4.49 | % |  | 10,853 |  |  | 5.43 | % |
| Current portion of other debt | 1 |  |  | 1.13 | % |  | — |  |  | — |  |
| Total | $ | 6,422 |  |  |  |  | $ | 11,341 |  |  |  |

- changed (2025-11-18):
[0000858877-25-000171:note_history:26]
|  |  |  | October 25, 2025 |  | July 26, 2025 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.90% | February 26, 2026 |  | $ | 1,000 |  |  | 5.00% |  | $ | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | 4.61% |  | 1,000 |  |  | 4.61% |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | 4.73% |  | 1,000 |  |  | 4.73% |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | 4.94% |  | 1,000 |  |  | 4.94% |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | 5.11% |  | 1,250 |  |  | 5.11% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.50% | February 24, 2055 |  | 750 |  |  | 5.49% |  | 750 |  |  | 5.49% |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 2 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 24,752 |  |  |  |  | 24,753 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (139) |  |  |  |  | (142) |  |  |  |
| Total |  |  | $ | 24,613 |  |  |  |  | $ | 24,611 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,249 |  |  |  |  | $ | 1,750 |  |  |  |
| Long-term debt |  |  | 21,364 |  |  |  |  | 22,861 |  |  |  |
| Total |  |  | $ | 24,613 |  |  |  |  | $ | 24,611 |  |  |  |
  (was, 2025-05-20, similarity 0.7266):
[0000858877-25-000033:note_history:26]
|  |  |  | April 26, 2025 |  | July 27, 2024 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | 5.67% |  | $ | 500 |  |  | 6.66% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | 4.61% |  | — |  |  | — |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | 4.73% |  | — |  |  | — |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | 4.94% |  | — |  |  | — |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | 5.11% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.50% | February 24, 2055 |  | 750 |  |  | 5.49% |  | — |  |  | — |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 3 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 25,253 |  |  |  |  | 20,253 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (146) |  |  |  |  | (133) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (2) |  |  |  |  | (11) |  |  |  |
| Total |  |  | $ | 25,105 |  |  |  |  | $ | 20,109 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 2,248 |  |  |  |  | $ | 488 |  |  |  |
| Long-term debt |  |  | 22,857 |  |  |  |  | 19,621 |  |  |  |
| Total |  |  | $ | 25,105 |  |  |  |  | $ | 20,109 |  |  |  |

- changed (2025-11-18):
[0000858877-25-000171:note_history:27]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 25, 2025, we were in compliance with all debt covenants.
  (was, 2025-05-20, similarity 0.9859):
[0000858877-25-000033:note_history:27]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 26, 2025, we were in compliance with all debt covenants.

- changed (2025-11-18):
[0000858877-25-000171:note_history:28]
As of October 25, 2025, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2025-05-20, similarity 0.9627):
[0000858877-25-000033:note_history:28]
As of April 26, 2025, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2025-11-18):
[0000858877-25-000171:note_history:29]
| Fiscal Year | Amount |
| 2026 (remaining nine months) | $ | 1,750 |  |
| 2027 | 3,502 |  |
| 2028 | 1,000 |  |
| 2029 | 2,500 |  |
| 2030 | 1,000 |  |
| Thereafter | 15,000 |  |
| Total | $ | 24,752 |  |
  (was, 2025-05-20, similarity 0.9772):
[0000858877-25-000033:note_history:29]
| Fiscal Year | Amount |
| 2025 (remaining three months) | $ | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | 1,000 |  |
| 2029 | 2,500 |  |
| Thereafter | 16,000 |  |
| Total | $ | 25,253 |  |

- changed (2025-11-18):
[0000858877-25-000171:note_history:30]
On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of October 25, 2025, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.
  (was, 2025-05-20, similarity 0.8676):
[0000858877-25-000033:note_history:30]
On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of April 26, 2025, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.

- removed (2025-11-18):
[0000858877-25-000033:note_history:31]
In February 2025, we issued senior notes for an aggregate principal amount of $5.0 billion.

- removed (2025-11-18):
[0000858877-25-000033:note_history:32]
We entered into an interest rate swap in a prior period with an aggregate notional amount of $0.5 billion designated as a fair value hedge of certain of our fixed-rate senior notes. This swap converts the fixed interest rate of the fixed-rate note to a floating interest rate based on Secured Overnight Financing Rate (SOFR). The gain and loss related to the change in the fair value of the interest rate swap substantially offsets the change in the fair value of the hedged portion of the underlying debt that is attributable to the change in market interest rates. For additional information, see Note 13.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-18):
[0000858877-25-000171:note_history:33]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 25, 2025 and July 26, 2025 (in millions):
  (was, 2025-05-20, similarity 0.9716):
[0000858877-25-000033:note_history:33]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 26, 2025 and July 27, 2024 (in millions):

- added (2025-11-18):
[0000858877-25-000171:note_history:34]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 25, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | — |  |  | $ | — |  |  | $ | 436 |  |  | $ | (4) |  |  | $ | 436 |  |  | $ | (4) |  |
| U.S. government agency securities | 5 |  |  | — |  |  | — |  |  | — |  |  | 5 |  |  | — |  |
| Corporate debt securities | 63 |  |  | — |  |  | 1,583 |  |  | (18) |  |  | 1,646 |  |  | (18) |  |
| Mortgage- and asset-backed securities | 4 |  |  | — |  |  | 160 |  |  | (16) |  |  | 164 |  |  | (16) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 82 |  |  | $ | — |  |  | $ | 2,179 |  |  | $ | (38) |  |  | $ | 2,261 |  |  | $ | (38) |  |

- changed (2025-11-18):
[0000858877-25-000171:note_history:35]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 26, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,076 |  |  | $ | (6) |  |  | $ | 302 |  |  | $ | (6) |  |  | $ | 1,378 |  |  | $ | (12) |  |
| U.S. government agency securities | 8 |  |  | — |  |  | 21 |  |  | — |  |  | 29 |  |  | — |  |
| Non-U.S. government and agency securities | 292 |  |  | — |  |  | — |  |  | — |  |  | 292 |  |  | — |  |
| Corporate debt securities | 106 |  |  | — |  |  | 1,800 |  |  | (35) |  |  | 1,906 |  |  | (35) |  |
| Mortgage- and asset-backed securities | 5 |  |  | — |  |  | 279 |  |  | (34) |  |  | 284 |  |  | (34) |  |
| Commercial paper | 30 |  |  | — |  |  | — |  |  | — |  |  | 30 |  |  | — |  |
| Total | $ | 1,517 |  |  | $ | (6) |  |  | $ | 2,402 |  |  | $ | (75) |  |  | $ | 3,919 |  |  | $ | (81) |  |
  (was, 2025-05-20, similarity 0.7638):
[0000858877-25-000033:note_history:35]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 598 |  |  | $ | (2) |  |  | $ | 1,399 |  |  | $ | (26) |  |  | $ | 1,997 |  |  | $ | (28) |  |
| U.S. government agency securities | 89 |  |  | — |  |  | 109 |  |  | (2) |  |  | 198 |  |  | (2) |  |
| Non-U.S. government and agency securities | 17 |  |  | — |  |  | — |  |  | — |  |  | 17 |  |  | — |  |
| Corporate debt securities | 276 |  |  | (1) |  |  | 2,818 |  |  | (115) |  |  | 3,094 |  |  | (116) |  |
| U.S. agency mortgage-backed securities | 238 |  |  | (1) |  |  | 1,438 |  |  | (177) |  |  | 1,676 |  |  | (178) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 1,228 |  |  | $ | (4) |  |  | $ | 5,764 |  |  | $ | (320) |  |  | $ | 6,992 |  |  | $ | (324) |  |

- removed (2025-11-18):
[0000858877-25-000033:note_history:36]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 26, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 970 |  |  | $ | (6) |  |  | $ | 313 |  |  | $ | (9) |  |  | $ | 1,283 |  |  | $ | (15) |  |
| U.S. government agency securities | 10 |  |  | — |  |  | 31 |  |  | — |  |  | 41 |  |  | — |  |
| Non-U.S. government and agency securities | 76 |  |  | — |  |  | — |  |  | — |  |  | 76 |  |  | — |  |
| Corporate debt securities | 319 |  |  | (1) |  |  | 1,917 |  |  | (48) |  |  | 2,236 |  |  | (49) |  |
| U.S. agency mortgage-backed securities | 6 |  |  | — |  |  | 482 |  |  | (66) |  |  | 488 |  |  | (66) |  |
| Total | $ | 1,381 |  |  | $ | (7) |  |  | $ | 2,743 |  |  | $ | (123) |  |  | $ | 4,124 |  |  | $ | (130) |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-11-18):
[0000858877-25-000171:note_history:37]
| October 25, 2025 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,637 |  |  | $ | 7 |  |  | $ | (4) |  |  | $ | 1,640 |  |
| U.S. government agency securities | 49 |  |  | — |  |  | — |  |  | 49 |  |
| Non-U.S. government and agency securities | 409 |  |  | 1 |  |  | — |  |  | 410 |  |
| Corporate debt securities | 2,979 |  |  | 14 |  |  | (44) |  |  | 2,949 |  |
| Mortgage- and asset-backed securities | 270 |  |  | — |  |  | (16) |  |  | 254 |  |
| Commercial paper | 884 |  |  | — |  |  | — |  |  | 884 |  |
| Certificates of deposit | 756 |  |  | — |  |  | — |  |  | 756 |  |
| Total | $ | 6,984 |  |  | $ | 22 |  |  | $ | (64) |  |  | $ | 6,942 |  |

- changed (2025-11-18):
[0000858877-25-000171:note_history:38]
| July 26, 2025 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,971 |  |  | $ | 2 |  |  | $ | (12) |  |  | $ | 1,961 |  |
| U.S. government agency securities | 67 |  |  | — |  |  | — |  |  | 67 |  |
| Non-U.S. government and agency securities | 458 |  |  | — |  |  | — |  |  | 458 |  |
| Corporate debt securities | 3,138 |  |  | 13 |  |  | (61) |  |  | 3,090 |  |
| Mortgage- and asset-backed securities | 320 |  |  | — |  |  | (34) |  |  | 286 |  |
| Commercial paper | 950 |  |  | — |  |  | — |  |  | 950 |  |
| Certificates of deposit | 569 |  |  | — |  |  | — |  |  | 569 |  |
| Total | $ | 7,473 |  |  | $ | 15 |  |  | $ | (107) |  |  | $ | 7,381 |  |
  (was, 2025-05-20, similarity 0.751):
[0000858877-25-000033:note_history:38]
| July 27, 2024 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,380 |  |  | $ | 1 |  |  | $ | (28) |  |  | $ | 2,353 |  |
| U.S. government agency securities | 223 |  |  | — |  |  | (2) |  |  | 221 |  |
| Non-U.S. government and agency securities | 370 |  |  | 1 |  |  | — |  |  | 371 |  |
| Corporate debt securities | 3,818 |  |  | 5 |  |  | (146) |  |  | 3,677 |  |
| U.S. agency mortgage-backed securities | 1,959 |  |  | — |  |  | (178) |  |  | 1,781 |  |
| Commercial paper | 1,023 |  |  | — |  |  | — |  |  | 1,023 |  |
| Certificates of deposit | 439 |  |  | — |  |  | — |  |  | 439 |  |
| Total | $ | 10,212 |  |  | $ | 7 |  |  | $ | (354) |  |  | $ | 9,865 |  |

- added (2025-11-18):
[0000858877-25-000171:note_history:39]
|  | Three Months Ended |
|  | October 25, 2025 |  | October 26, 2024 |
| Gross realized gains | $ | 10 |  |  | $ | 8 |  |
| Gross realized losses | (14) |  |  | (33) |  |
| Total | $ | (4) |  |  | $ | (25) |  |

- changed (2025-11-18):
[0000858877-25-000171:note_history:40]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 25, 2025 and July 26, 2025 (in millions):
  (was, 2025-05-20, similarity 0.9716):
[0000858877-25-000033:note_history:40]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 26, 2025 and July 27, 2024 (in millions):

- added (2025-11-18):
[0000858877-25-000171:note_history:41]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 25, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | — |  |  | $ | — |  |  | $ | 436 |  |  | $ | (4) |  |  | $ | 436 |  |  | $ | (4) |  |
| U.S. government agency securities | 5 |  |  | — |  |  | — |  |  | — |  |  | 5 |  |  | — |  |
| Corporate debt securities | 63 |  |  | — |  |  | 1,583 |  |  | (18) |  |  | 1,646 |  |  | (18) |  |
| Mortgage- and asset-backed securities | 4 |  |  | — |  |  | 160 |  |  | (16) |  |  | 164 |  |  | (16) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 82 |  |  | $ | — |  |  | $ | 2,179 |  |  | $ | (38) |  |  | $ | 2,261 |  |  | $ | (38) |  |

- changed (2025-11-18):
[0000858877-25-000171:note_history:42]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 26, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,076 |  |  | $ | (6) |  |  | $ | 302 |  |  | $ | (6) |  |  | $ | 1,378 |  |  | $ | (12) |  |
| U.S. government agency securities | 8 |  |  | — |  |  | 21 |  |  | — |  |  | 29 |  |  | — |  |
| Non-U.S. government and agency securities | 292 |  |  | — |  |  | — |  |  | — |  |  | 292 |  |  | — |  |
| Corporate debt securities | 106 |  |  | — |  |  | 1,800 |  |  | (35) |  |  | 1,906 |  |  | (35) |  |
| Mortgage- and asset-backed securities | 5 |  |  | — |  |  | 279 |  |  | (34) |  |  | 284 |  |  | (34) |  |
| Commercial paper | 30 |  |  | — |  |  | — |  |  | — |  |  | 30 |  |  | — |  |
| Total | $ | 1,517 |  |  | $ | (6) |  |  | $ | 2,402 |  |  | $ | (75) |  |  | $ | 3,919 |  |  | $ | (81) |  |
  (was, 2025-05-20, similarity 0.7638):
[0000858877-25-000033:note_history:42]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 598 |  |  | $ | (2) |  |  | $ | 1,399 |  |  | $ | (26) |  |  | $ | 1,997 |  |  | $ | (28) |  |
| U.S. government agency securities | 89 |  |  | — |  |  | 109 |  |  | (2) |  |  | 198 |  |  | (2) |  |
| Non-U.S. government and agency securities | 17 |  |  | — |  |  | — |  |  | — |  |  | 17 |  |  | — |  |
| Corporate debt securities | 276 |  |  | (1) |  |  | 2,818 |  |  | (115) |  |  | 3,094 |  |  | (116) |  |
| U.S. agency mortgage-backed securities | 238 |  |  | (1) |  |  | 1,438 |  |  | (177) |  |  | 1,676 |  |  | (178) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 1,228 |  |  | $ | (4) |  |  | $ | 5,764 |  |  | $ | (320) |  |  | $ | 6,992 |  |  | $ | (324) |  |

- changed (2025-11-18):
[0000858877-25-000171:note_history:43]
The following table summarizes the maturities of our available-for-sale debt investments as of October 25, 2025 (in millions):
  (was, 2025-05-20, similarity 0.9583):
[0000858877-25-000033:note_history:43]
The following table summarizes the maturities of our available-for-sale debt investments as of April 26, 2025 (in millions):

- changed (2025-11-18):
[0000858877-25-000171:note_history:44]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 3,925 |  |  | $ | 3,883 |  |
| After 1 year through 5 years | 2,768 |  |  | 2,784 |  |
| After 5 years through 10 years | 21 |  |  | 21 |  |
| Mortgage- and asset-backed securities with no single maturity | 270 |  |  | 254 |  |
| Total | $ | 6,984 |  |  | $ | 6,942 |  |
  (was, 2025-05-20, similarity 0.8832):
[0000858877-25-000033:note_history:44]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 3,160 |  |  | $ | 3,118 |  |
| After 1 year through 5 years | 3,622 |  |  | 3,586 |  |
| Mortgage-backed securities with no single maturity | 556 |  |  | 490 |  |
| Total | $ | 7,338 |  |  | $ | 7,194 |  |

- added (2025-11-18):
[0000858877-25-000171:note_history:45]
(b)Marketable Equity Securities

- added (2025-11-18):
[0000858877-25-000171:note_history:46]
We held marketable equity securities of $394 million and $383 million as of October 25, 2025 and July 26, 2025, respectively. We recognized net unrealized gains of $30 million and $25 million during the first quarter of fiscal 2026 and fiscal 2025, respectively, on our marketable securities still held as of the reporting date.

- added (2025-11-18):
[0000858877-25-000171:note_history:47]
(c)Investments in Privately Held Companies

- added (2025-11-18):
[0000858877-25-000171:note_history:48]
The carrying value of our investments in privately held companies was $2.1 billion and $1.9 billion as of October 25, 2025 and July 26, 2025, respectively. As of October 25, 2025, we have total funding commitments of $0.5 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.

- added (2025-11-18):
[0000858877-25-000171:note_history:49]
Investments in privately held companies measured using the measurement alternative had a carrying value of $0.7 billion and $0.6 billion as of October 25, 2025 and July 26, 2025, respectively. We have recorded cumulative adjustments to the carrying value of our investments in privately held companies measured using the measurement alternative as follows (in millions):

- added (2025-11-18):
[0000858877-25-000171:note_history:50]
|  | October 25, 2025 |  | July 26, 2025 |
| Cumulative upward adjustments | $ | 277 |  |  | $ | 195 |  |
| Cumulative downward adjustments, including impairments | (595) |  |  | (597) |  |
| Net adjustments | $ | (318) |  |  | $ | (402) |  |

- added (2025-11-18):
[0000858877-25-000171:note_history:51]
We held equity interests in certain private equity funds of $0.7 billion as of each of October 25, 2025 and July 26, 2025, which are accounted for under the NAV practical expedient.

- added (2025-11-18):
[0000858877-25-000171:note_history:52]
Of the total carrying value of our investments in privately held companies as of October 25, 2025, $0.8 billion of such investments are considered to be in variable interest entities which are unconsolidated.

- added (2025-11-18):
[0000858877-25-000171:note_history:53]
Certain of our investments in privately held companies are required to be consolidated under the voting interest entity model. The noncontrolling interest attributed to these investments was $206 million and $162 million as of October 25, 2025 and July 26, 2025, respectively, and is included in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interest attributed to these investments is not material for any of the periods presented and is included in other income (loss), net in the Consolidated Statements of Operations.

- removed (2025-11-18):
[0000858877-25-000033:note_history:54]
| April 26, 2025 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,079 |  |  | $ | 4 |  |  | $ | (15) |  |  | $ | 2,068 |  |
| U.S. government agency securities | 77 |  |  | — |  |  | — |  |  | 77 |  |
| Non-U.S. government and agency securities | 376 |  |  | 1 |  |  | — |  |  | 377 |  |
| Corporate debt securities | 3,206 |  |  | 7 |  |  | (75) |  |  | 3,138 |  |
| U.S. agency mortgage-backed securities | 556 |  |  | — |  |  | (66) |  |  | 490 |  |
| Commercial paper | 436 |  |  | — |  |  | — |  |  | 436 |  |
| Certificates of deposit | 608 |  |  | — |  |  | — |  |  | 608 |  |
| Total | $ | 7,338 |  |  | $ | 12 |  |  | $ | (156) |  |  | $ | 7,194 |  |

- removed (2025-11-18):
[0000858877-25-000033:note_history:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Gross realized gains | $ | 1 |  |  | $ | 2 |  |  | $ | 9 |  |  | $ | 7 |  |
| Gross realized losses | (31) |  |  | (16) |  |  | $ | (84) |  |  | $ | (64) |  |
| Total | $ | (30) |  |  | $ | (14) |  |  | $ | (75) |  |  | $ | (57) |  |

- removed (2025-11-18):
[0000858877-25-000033:note_history:56]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 26, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 970 |  |  | $ | (6) |  |  | $ | 313 |  |  | $ | (9) |  |  | $ | 1,283 |  |  | $ | (15) |  |
| U.S. government agency securities | 10 |  |  | — |  |  | 31 |  |  | — |  |  | 41 |  |  | — |  |
| Non-U.S. government and agency securities | 76 |  |  | — |  |  | — |  |  | — |  |  | 76 |  |  | — |  |
| Corporate debt securities | 319 |  |  | (1) |  |  | 1,917 |  |  | (48) |  |  | 2,236 |  |  | (49) |  |
| U.S. agency mortgage-backed securities | 6 |  |  | — |  |  | 482 |  |  | (66) |  |  | 488 |  |  | (66) |  |
| Total | $ | 1,381 |  |  | $ | (7) |  |  | $ | 2,743 |  |  | $ | (123) |  |  | $ | 4,124 |  |  | $ | (130) |  |

- removed (2025-11-18):
[0000858877-25-000033:note_history:57]
(b)Summary of Equity Investments

- removed (2025-11-18):
[0000858877-25-000033:note_history:58]
We held marketable equity securities of $287 million and $481 million as of April 26, 2025 and July 27, 2024, respectively. We recognized a net unrealized loss of $35 million and $6 million during the third quarter and first nine months of fiscal 2025, respectively, and a net unrealized gain of $20 million and $40 million during the corresponding periods of fiscal 2024, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $2 million and $18 million for the third quarter and first nine months of fiscal 2025, respectively, and a net loss of $21 million and $155 million for the corresponding periods of fiscal 2024. We held equity interests in certain private equity funds of $0.7 billion and $0.8 billion as of April 26, 2025 and July 27, 2024, respectively, which are accounted for under the NAV practical expedient.

- removed (2025-11-18):
[0000858877-25-000033:note_history:59]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 26, 2025, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- removed (2025-11-18):
[0000858877-25-000033:note_history:60]
The carrying value of our investments in privately held companies was $2.0 billion and $1.8 billion as of April 26, 2025 and July 27, 2024, respectively. Of the total carrying value of our investments in privately held companies as of April 26, 2025, $0.8 billion of such investments are considered to be in variable interest entities which are not required to be consolidated. As of April 26, 2025, we have total funding commitments of $0.3 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-18):
[0000858877-25-000171:note_history:61]
|  |  |  | October 25, 2025 |  | July 26, 2025 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.90% | February 26, 2026 |  | $ | 1,000 |  |  | 5.00% |  | $ | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | 4.61% |  | 1,000 |  |  | 4.61% |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | 4.73% |  | 1,000 |  |  | 4.73% |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | 4.94% |  | 1,000 |  |  | 4.94% |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | 5.11% |  | 1,250 |  |  | 5.11% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.50% | February 24, 2055 |  | 750 |  |  | 5.49% |  | 750 |  |  | 5.49% |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 2 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 24,752 |  |  |  |  | 24,753 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (139) |  |  |  |  | (142) |  |  |  |
| Total |  |  | $ | 24,613 |  |  |  |  | $ | 24,611 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,249 |  |  |  |  | $ | 1,750 |  |  |  |
| Long-term debt |  |  | 21,364 |  |  |  |  | 22,861 |  |  |  |
| Total |  |  | $ | 24,613 |  |  |  |  | $ | 24,611 |  |  |  |
  (was, 2025-05-20, similarity 0.7266):
[0000858877-25-000033:note_history:61]
|  |  |  | April 26, 2025 |  | July 27, 2024 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 3.50% | June 15, 2025 |  | $ | 500 |  |  | 5.67% |  | $ | 500 |  |  | 6.66% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | 4.61% |  | — |  |  | — |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | 4.73% |  | — |  |  | — |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | 4.94% |  | — |  |  | — |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | 5.11% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.50% | February 24, 2055 |  | 750 |  |  | 5.49% |  | — |  |  | — |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 3 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 25,253 |  |  |  |  | 20,253 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (146) |  |  |  |  | (133) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (2) |  |  |  |  | (11) |  |  |  |
| Total |  |  | $ | 25,105 |  |  |  |  | $ | 20,109 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 2,248 |  |  |  |  | $ | 488 |  |  |  |
| Long-term debt |  |  | 22,857 |  |  |  |  | 19,621 |  |  |  |
| Total |  |  | $ | 25,105 |  |  |  |  | $ | 20,109 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-18):
[0000858877-25-000171:note_history:62]
As of October 25, 2025, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2025-05-20, similarity 0.9627):
[0000858877-25-000033:note_history:62]
As of April 26, 2025, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2025-11-18):
[0000858877-25-000171:note_history:63]
| Fiscal Year | Amount |
| 2026 (remaining nine months) | $ | 1,750 |  |
| 2027 | 3,502 |  |
| 2028 | 1,000 |  |
| 2029 | 2,500 |  |
| 2030 | 1,000 |  |
| Thereafter | 15,000 |  |
| Total | $ | 24,752 |  |
  (was, 2025-05-20, similarity 0.9772):
[0000858877-25-000033:note_history:63]
| Fiscal Year | Amount |
| 2025 (remaining three months) | $ | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | 1,000 |  |
| 2029 | 2,500 |  |
| Thereafter | 16,000 |  |
| Total | $ | 25,253 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-18):
[0000858877-25-000171:note_history:64]
|  | October 25, 2025 |  | July 26, 2025 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 3,249 |  |  | 3.41 | % |  | $ | 1,749 |  |  | 4.15 | % |
| Commercial paper | 3,476 |  |  | 4.09 | % |  | 3,482 |  |  | 4.37 | % |
| Current portion of other debt | — |  |  | — |  |  | 1 |  |  | 1.13 | % |
| Total | $ | 6,725 |  |  |  |  | $ | 5,232 |  |  |  |
  (was, 2025-05-20, similarity 0.9273):
[0000858877-25-000033:note_history:64]
|  | April 26, 2025 |  | July 27, 2024 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior notes | $ | 2,247 |  |  | 4.48 | % |  | $ | 488 |  |  | 6.66 | % |
| Commercial paper | 4,174 |  |  | 4.49 | % |  | 10,853 |  |  | 5.43 | % |
| Current portion of other debt | 1 |  |  | 1.13 | % |  | — |  |  | — |  |
| Total | $ | 6,422 |  |  |  |  | $ | 11,341 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-18):
[0000858877-25-000171:note_history:65]
|  | Three Months Ended |
|  | October 25,2025 |  | October 26,2024 |
| Product revenue: |  |  |  |
| Networking | $ | 7,768 |  |  | $ | 6,753 |  |
| Security | 1,980 |  |  | 2,017 |  |
| Collaboration | 1,055 |  |  | 1,085 |  |
| Observability | 274 |  |  | 258 |  |
| Total Product | 11,077 |  |  | 10,114 |  |
| Services | 3,806 |  |  | 3,727 |  |
| Total revenue | $ | 14,883 |  |  | $ | 13,841 |  |
  (was, 2025-05-20, similarity 0.631):
[0000858877-25-000033:note_history:65]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,068 |  |  | $ | 6,522 |  |  | $ | 20,671 |  |  | $ | 22,425 |  |
| Security | 2,013 |  |  | 1,304 |  |  | 6,142 |  |  | 3,288 |  |
| Collaboration | 1,031 |  |  | 987 |  |  | 3,112 |  |  | 3,093 |  |
| Observability | 261 |  |  | 211 |  |  | 796 |  |  | 589 |  |
| Total Product | 10,374 |  |  | 9,024 |  |  | 30,722 |  |  | 29,395 |  |
| Services | 3,775 |  |  | 3,678 |  |  | 11,259 |  |  | 10,766 |  |
| Total | $ | 14,149 |  |  | $ | 12,702 |  |  | $ | 41,981 |  |  | $ | 40,161 |  |

- added (2025-11-18):
[0000858877-25-000171:note_history:66]
|  | Three Months Ended |
|  | October 25, 2025 |  | October 26, 2024 |
| Product | $ | 4,500 |  |  | $ | 4,419 |  |
| Services | 3,500 |  |  | 3,425 |  |
| Total | $ | 8,000 |  |  | $ | 7,844 |  |

- changed (2025-11-18):
[0000858877-25-000171:note_history:67]
|  | Three Months Ended |
|  | October 25,2025 |  | October 26,2024 |
| Revenue: |  |
| Networking | $ | 7,768 |  |  | $ | 6,753 |  |
| Security | 1,980 |  |  | 2,017 |  |
| Collaboration | 1,055 |  |  | 1,085 |  |
| Observability | 274 |  |  | 258 |  |
| Total Product | 11,077 |  |  | 10,114 |  |
| Services | 3,806 |  |  | 3,727 |  |
| Total | $ | 14,883 |  |  | $ | 13,841 |  |
  (was, 2025-05-20, similarity 0.6227):
[0000858877-25-000033:note_history:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,068 |  |  | $ | 6,522 |  |  | $ | 20,671 |  |  | $ | 22,425 |  |
| Security | 2,013 |  |  | 1,304 |  |  | 6,142 |  |  | 3,288 |  |
| Collaboration | 1,031 |  |  | 987 |  |  | 3,112 |  |  | 3,093 |  |
| Observability | 261 |  |  | 211 |  |  | 796 |  |  | 589 |  |
| Total Product | 10,374 |  |  | 9,024 |  |  | 30,722 |  |  | 29,395 |  |
| Services | 3,775 |  |  | 3,678 |  |  | 11,259 |  |  | 10,766 |  |
| Total | $ | 14,149 |  |  | $ | 12,702 |  |  | $ | 41,981 |  |  | $ | 40,161 |  |

- removed (2025-11-18):
[0000858877-25-000033:note_history:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Product | $ | 4,483 |  |  | $ | 3,510 |  |  | $ | 13,334 |  |  | $ | 9,827 |  |
| Services | 3,433 |  |  | 3,344 |  |  | 10,288 |  |  | 9,878 |  |
| Total | $ | 7,916 |  |  | $ | 6,854 |  |  | $ | 23,622 |  |  | $ | 19,705 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-18):
[0000858877-25-000171:note_history:69]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to
  (was, 2025-05-20, similarity 0.9037):
[0000858877-25-000033:note_history:69]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers. Revenue from subscription offers includes revenue recognized over time as well as upfront.

- added (2025-11-18):
[0000858877-25-000171:note_history:70]
our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers. Revenue from subscription offers includes revenue recognized over time as well as upfront.

- changed (2025-11-18):
[0000858877-25-000171:note_history:71]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes. An allowance for future sales returns is established based on historical trends in product return rates and the related provision is recorded as a reduction to revenue.
  (was, 2025-05-20, similarity 0.9469):
[0000858877-25-000033:note_history:71]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

- changed (2025-11-18):
[0000858877-25-000171:note_history:72]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and direct sale customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.
  (was, 2025-05-20, similarity 0.9918):
[0000858877-25-000033:note_history:72]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and end customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.

- removed (2025-11-18):
[0000858877-25-000033:note_history:73]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 26, 2025 and July 27, 2024 was $39 million and $37 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-18):
[0000858877-25-000171:note_history:74]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to
  (was, 2025-05-20, similarity 0.9037):
[0000858877-25-000033:note_history:74]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers. Revenue from subscription offers includes revenue recognized over time as well as upfront.

- added (2025-11-18):
[0000858877-25-000171:note_history:75]
our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers. Revenue from subscription offers includes revenue recognized over time as well as upfront.

- changed (2025-11-18):
[0000858877-25-000171:note_history:76]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes. An allowance for future sales returns is established based on historical trends in product return rates and the related provision is recorded as a reduction to revenue.
  (was, 2025-05-20, similarity 0.9469):
[0000858877-25-000033:note_history:76]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

- changed (2025-11-18):
[0000858877-25-000171:note_history:77]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and direct sale customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.
  (was, 2025-05-20, similarity 0.9918):
[0000858877-25-000033:note_history:77]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and end customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.

- changed (2025-11-18):
[0000858877-25-000171:note_history:78]
|  | Three Months Ended |
|  | October 25,2025 |  | October 26,2024 |
| Product revenue: |  |  |  |
| Networking | $ | 7,768 |  |  | $ | 6,753 |  |
| Security | 1,980 |  |  | 2,017 |  |
| Collaboration | 1,055 |  |  | 1,085 |  |
| Observability | 274 |  |  | 258 |  |
| Total Product | 11,077 |  |  | 10,114 |  |
| Services | 3,806 |  |  | 3,727 |  |
| Total revenue | $ | 14,883 |  |  | $ | 13,841 |  |
  (was, 2025-05-20, similarity 0.631):
[0000858877-25-000033:note_history:78]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26,2025 |  | April 27,2024 |  | April 26,2025 |  | April 27,2024 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,068 |  |  | $ | 6,522 |  |  | $ | 20,671 |  |  | $ | 22,425 |  |
| Security | 2,013 |  |  | 1,304 |  |  | 6,142 |  |  | 3,288 |  |
| Collaboration | 1,031 |  |  | 987 |  |  | 3,112 |  |  | 3,093 |  |
| Observability | 261 |  |  | 211 |  |  | 796 |  |  | 589 |  |
| Total Product | 10,374 |  |  | 9,024 |  |  | 30,722 |  |  | 29,395 |  |
| Services | 3,775 |  |  | 3,678 |  |  | 11,259 |  |  | 10,766 |  |
| Total | $ | 14,149 |  |  | $ | 12,702 |  |  | $ | 41,981 |  |  | $ | 40,161 |  |

- changed (2025-11-18):
[0000858877-25-000171:note_history:79]
|  | Three Months Ended |
|  | October 25, 2025 |  | October 26, 2024 |
| Product | $ | 4,500 |  |  | $ | 4,419 |  |
| Services | 3,500 |  |  | 3,425 |  |
| Total | $ | 8,000 |  |  | $ | 7,844 |  |
  (was, 2025-05-20, similarity 0.6554):
[0000858877-25-000033:note_history:79]
|  | April 26,2025 |  | July 27,2024 |
| 1 to 4 | $ | 1,245 |  |  | $ | 1,266 |  |
| 5 to 6 | 1,762 |  |  | 1,456 |  |
| 7 and Higher | 70 |  |  | 72 |  |
| Total | $ | 3,077 |  |  | $ | 2,794 |  |

- changed (2025-11-18):
[0000858877-25-000171:note_history:80]
Accounts receivable, net was $4.8 billion as of October 25, 2025 compared to $6.7 billion as of July 26, 2025, as reported on the Consolidated Balance Sheets.
  (was, 2025-05-20, similarity 0.9648):
[0000858877-25-000033:note_history:80]
Accounts receivable, net was $5.3 billion as of April 26, 2025 compared to $6.7 billion as of July 27, 2024, as reported on the Consolidated Balance Sheets.

- added (2025-11-18):
[0000858877-25-000171:note_history:81]
|  | Three Months Ended |
|  | October 25, 2025 |  | October 26, 2024 |
| Allowance for credit loss at beginning of period | $ | 69 |  |  | $ | 87 |  |
| Provisions | (4) |  |  | — |  |
| Write-offs, net of recoveries | (3) |  |  | (9) |  |
| Allowance for credit loss at end of period | $ | 62 |  |  | $ | 78 |  |

- added (2025-11-18):
[0000858877-25-000171:note_history:82]
|  | October 25,2025 |  | July 26,2025 |
| 1 to 4 | $ | 1,379 |  |  | $ | 1,358 |  |
| 5 to 6 | 2,001 |  |  | 1,868 |  |
| 7 and Higher | 75 |  |  | 73 |  |
| Total | $ | 3,455 |  |  | $ | 3,299 |  |

- changed (2025-11-18):
[0000858877-25-000171:note_history:83]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $3.4 billion as of October 25, 2025 and $3.2 billion as of July 26, 2025, of which $1.8 billion and $1.7 billion, respectively, were included in other current assets, with remaining balances included in other assets.
  (was, 2025-05-20, similarity 0.8251):
[0000858877-25-000033:note_history:83]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $3.0 billion as of April 26, 2025 and $2.7 billion as of July 27, 2024, and were included in other current assets and other assets.

- changed (2025-11-18):
[0000858877-25-000171:note_history:84]
Contract liabilities consist of deferred revenue. Deferred revenue was $28.0 billion as of October 25, 2025 compared to $28.8 billion as of July 26, 2025. We recognized approximately $5.4 billion of revenue during the first quarter of fiscal 2026 that was included in the deferred revenue balance at July 26, 2025.
  (was, 2025-05-20, similarity 0.9028):
[0000858877-25-000033:note_history:84]
Contract liabilities consist of deferred revenue. Deferred revenue was $28.0 billion as of April 26, 2025 compared to $28.5 billion as of July 27, 2024. We recognized approximately $3.6 billion and $13.3 billion of revenue during the third quarter and first nine months of fiscal 2025 that was included in the deferred revenue balance at July 27, 2024.

- changed (2025-11-18):
[0000858877-25-000171:note_history:85]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to 
the period of benefit. Capitalized contract acquisition costs were $1.5 billion as of each of October 25, 2025 and July 26, 2025, and were included in other current assets and other assets. The amortization expense associated with these costs was $234 million and $208 million for the first quarter of fiscal 2026 and 2025, respectively, and was included in sales and marketing expenses.
  (was, 2025-05-20, similarity 0.6733):
[0000858877-25-000033:note_history:85]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to 
the period of benefit. Capitalized contract acquisition costs were $1.5 billion and $1.3 billion as of April 26, 2025 and July 27, 2024, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $272 million and $718 million for the third quarter and first nine months of fiscal 2025, respectively, and $201 million and $525 million for the corresponding periods of fiscal 2024, respectively, and was included in sales and marketing expenses.

- removed (2025-11-18):
[0000858877-25-000033:note_history:86]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 26, 2025 and July 27, 2024 was $39 million and $37 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- removed (2025-11-18):
[0000858877-25-000033:note_history:87]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Product | $ | 4,483 |  |  | $ | 3,510 |  |  | $ | 13,334 |  |  | $ | 9,827 |  |
| Services | 3,433 |  |  | 3,344 |  |  | 10,288 |  |  | 9,878 |  |
| Total | $ | 7,916 |  |  | $ | 6,854 |  |  | $ | 23,622 |  |  | $ | 19,705 |  |

- removed (2025-11-18):
[0000858877-25-000033:note_history:88]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2025 |  | April 27, 2024 |  | April 26, 2025 |  | April 27, 2024 |
| Allowance for credit loss at beginning of period | $ | 80 |  |  | $ | 79 |  |  | $ | 87 |  |  | $ | 85 |  |
| Provisions | 13 |  |  | 10 |  |  | 25 |  |  | 21 |  |
| Write-offs, net of recoveries | (11) |  |  | (8) |  |  | (30) |  |  | (25) |  |
| Allowance for credit loss at end of period | $ | 82 |  |  | $ | 81 |  |  | $ | 82 |  |  | $ | 81 |  |


## us-gaap:SubsequentEventsPolicyPolicyTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2025-11-18):
[0000858877-25-000033:note_history:89]
We have evaluated subsequent events through the date that the financial statements were issued.
