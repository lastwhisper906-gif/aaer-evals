# CSCO 8-K — 0001193125-25-277624 filed 2025-11-12

## item codes, every 8-K on or before 2025-11-18

- 2025-11-12 0001193125-25-277624 — 2.02, 9.01
- 2025-10-17 0000858877-25-000145 — 5.02
- 2025-08-25 0000858877-25-000103 — 5.03, 9.01
- 2025-08-13 0001193125-25-179820 — 2.02, 9.01
- 2025-06-09 0000858877-25-000046 — 5.02
- 2025-05-14 0001193125-25-119864 — 2.02, 9.01
- 2025-05-14 0000858877-25-000021 — 5.02
- 2025-05-13 0000858877-25-000014 — 5.02
- 2025-02-27 0000858877-25-000009 — 5.02 — amendment of 0000858877-25-000004
- 2025-02-24 0001193125-25-033389 — 1.01, 2.03, 9.01
- 2025-02-12 0001193125-25-025114 — 2.02, 9.01
- 2025-02-12 0000858877-25-000004 — 5.02
- 2024-12-11 0000858877-24-000039 — 5.07
- 2024-11-13 0001193125-24-257224 — 2.02, 9.01
- 2024-10-11 0001193125-24-236734 — 5.02
- 2024-08-14 0001193125-24-200636 — 2.02, 2.05, 9.01
- 2024-07-19 0000858877-24-000012 — 5.02
- 2024-06-14 0000858877-24-000010 — 5.02
- 2024-05-15 0001193125-24-139371 — 2.02, 5.02, 9.01
- 2024-03-18 0001193125-24-070175 — 2.01, 7.01, 9.01
- 2024-02-26 0001193125-24-046231 — 1.01, 2.03, 9.01
- 2024-02-14 0001193125-24-036201 — 2.02, 2.05, 9.01
- 2024-02-08 0001193125-24-028353 — 1.01, 2.03, 8.01, 9.01
- 2023-12-08 0001193125-23-291721 — 5.02, 5.07, 9.01
- 2023-11-15 0001193125-23-277891 — 2.02, 9.01
- 2023-10-10 0000858877-23-000025 — 5.02
- 2023-09-25 0001193125-23-240975 — 7.01
- 2023-09-21 0001193125-23-239165 — 1.01, 7.01, 8.01, 9.01
- 2023-08-16 0001193125-23-214316 — 2.02, 9.01
- 2023-07-19 0000858877-23-000016 — 5.02
- 2023-05-17 0001193125-23-147021 — 2.02, 9.01
- 2023-03-10 0000858877-23-000009 — 5.03, 9.01
- 2023-02-21 0000858877-23-000006 — 5.02
- 2023-02-15 0001193125-23-040212 — 2.02, 9.01
- 2022-12-16 0000858877-22-000029 — 8.01
- 2022-12-09 0000858877-22-000027 — 5.07
- 2022-11-16 0001628280-22-030151 — 5.02
- 2022-11-16 0001193125-22-286782 — 2.02, 2.05, 9.01
- 2022-10-04 0000858877-22-000018 — 1.01, 1.02, 9.01
- 2022-09-15 0000858877-22-000015 — 8.01
- 2022-08-24 0001193125-22-228572 — 5.02
- 2022-08-17 0001193125-22-223250 — 2.02, 9.01
- 2022-06-17 0001193125-22-176552 — 8.01
- 2022-05-18 0001193125-22-154039 — 2.02, 9.01
- 2022-03-28 0001193125-22-086807 — 8.01
- 2022-02-16 0001193125-22-044372 — 2.02, 9.01
- 2022-02-11 0001193125-22-037227 — 5.02
- 2022-01-31 0001193125-22-023458 — 5.02
- 2021-12-17 0001193125-21-361182 — 8.01
- 2021-12-14 0001193125-21-356837 — 5.07, 8.01
- 2021-11-17 0001193125-21-332467 — 2.02, 9.01
- 2021-09-27 0001193125-21-284199 — 8.01
- 2021-08-18 0001193125-21-250360 — 2.02, 9.01
- 2021-06-29 0001193125-21-203324 — 8.01
- 2021-05-19 0001193125-21-166614 — 2.02, 9.01
- 2021-05-14 0001193125-21-162081 — 1.01, 2.03, 9.01
- 2021-03-08 0001193125-21-073328 — 5.02
- 2021-02-25 0001193125-21-056977 — 5.02
- 2021-02-09 0001193125-21-034339 — 2.02, 9.01
- 2021-01-07 0001193125-21-004250 — 5.02
- 2020-12-17 0001193125-20-320092 — 5.02, 8.01
- 2020-12-11 0001193125-20-315999 — 5.02, 5.07, 9.01
- 2020-11-30 0001193125-20-305352 — 5.02
- 2020-11-13 0001193125-20-293020 — 5.02, 9.01
- 2020-11-12 0001193125-20-291658 — 2.02, 9.01
- 2020-10-09 0001193125-20-267248 — 5.03, 9.01
- 2020-09-23 0001193125-20-252356 — 8.01
- 2020-08-12 0001193125-20-217756 — 5.02
- 2020-08-12 0001193125-20-217658 — 2.02, 2.05, 9.01
- 2020-06-22 0001193125-20-175641 — 8.01
- 2020-05-13 0001193125-20-141598 — 2.02, 9.01
- 2020-03-13 0001193125-20-072960 — 5.02
- 2020-03-06 0001193125-20-065138 — 5.02
- 2020-02-12 0001193125-20-033208 — 2.02, 9.01
- 2020-01-27 0001193125-20-015453 — 5.02
- 2019-12-23 0001193125-19-322662 — 8.01
- 2019-12-12 0001193125-19-312796 — 8.01
- 2019-12-11 0001193125-19-311525 — 5.07
- 2019-12-04 0001193125-19-306229 — 8.01
- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2025-11-18

- none on or before 2025-11-18

## item 2.02 — earnings release, exhibit 99.1

[0001193125-25-277624:8k_2_02:1]
EX-99.1
2
d484663dex991.htm
EX-99.1

[0001193125-25-277624:8k_2_02:2]
EX-99.1

[0001193125-25-277624:8k_2_02:3]
Exhibit 99.1

[0001193125-25-277624:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Sami Badri |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 (469) 420-4834 |
| rojenkin@cisco.com |  |  |  | sambadri@cisco.com |

[0001193125-25-277624:8k_2_02:5]
CISCO REPORTS FIRST QUARTER EARNINGS

[0001193125-25-277624:8k_2_02:6]
News Summary:

[0001193125-25-277624:8k_2_02:7]
|  | • |  | Strong top and bottom-line growth, exceeding our guidance and delivering continued operating leverage |

[0001193125-25-277624:8k_2_02:8]
|  | • |  | Revenue of $14.9 billion, up 8% year over year; GAAP EPS of $0.72, up 6% year over year; and Non-GAAP EPS of $1.00, up 10% year over year, above the high end of our guidance ranges and demonstrating solid operating leverage |

[0001193125-25-277624:8k_2_02:9]
|  | • |  | GAAP gross margin of 65.5% and Non-GAAP gross margin of 68.1%; GAAP operating margin of 22.6% and Non-GAAP operating margin of 34.4%, both above the high end of our guidance ranges |

[0001193125-25-277624:8k_2_02:10]
|  | • |  | Growth in product orders across all geographies and customer markets, demonstrating strong demand for Cisco’s technologies |

[0001193125-25-277624:8k_2_02:11]
|  | • |  | Product orders up 13% year over year, with double-digit growth in Networking product orders for the fifth consecutive quarter |

[0001193125-25-277624:8k_2_02:12]
|  | • |  | AI Infrastructure orders taken from hyperscaler customers totaled $1.3 billion, reflecting a significant acceleration in growth |

[0001193125-25-277624:8k_2_02:13]
|  | • |  | Major multi-year, multi-billion-dollar campus networking refresh cycle underway |

[0001193125-25-277624:8k_2_02:14]
|  | • |  | All technologies within campus networking (switching, routing, wireless and IoT) saw accelerated order growth in Q1 |

[0001193125-25-277624:8k_2_02:15]
|  | • |  | All next-generation solutions including smart switches, secure routers and WiFi 7 products are ramping faster than prior product launches |

[0001193125-25-277624:8k_2_02:16]
| • |  | Q1 FY 2026 Results: |

[0001193125-25-277624:8k_2_02:17]
|  | • |  | Revenue: $14.9 billion |

[0001193125-25-277624:8k_2_02:18]
|  | • |  | Increase of 8% year over year |

[0001193125-25-277624:8k_2_02:19]
|  | • |  | Earnings per Share: GAAP: $0.72; Non-GAAP: $1.00 |

[0001193125-25-277624:8k_2_02:20]
|  | • |  | GAAP EPS increased 6% year over year |

[0001193125-25-277624:8k_2_02:21]
|  | • |  | Non-GAAP EPS increased 10% year over year |

[0001193125-25-277624:8k_2_02:22]
| • |  | Q2 FY 2026 Guidance (1): |

[0001193125-25-277624:8k_2_02:23]
|  | • |  | Revenue: $15.0 billion to $15.2 billion |

[0001193125-25-277624:8k_2_02:24]
|  | • |  | Earnings per Share: GAAP: $0.69 to $0.74; Non-GAAP: $1.01 to $1.03 |

[0001193125-25-277624:8k_2_02:25]
| • |  | FY 2026 Guidance (1): |

[0001193125-25-277624:8k_2_02:26]
|  | • |  | Revenue: $60.2 billion to $61.0 billion |

[0001193125-25-277624:8k_2_02:27]
|  | • |  | Earnings per Share: GAAP: $2.87 to $2.98; Non-GAAP: $4.08 to $4.14 |

[0001193125-25-277624:8k_2_02:28]
(1) Margin and EPS guidance includes the estimated impact of tariffs based on
current trade policy.

[0001193125-25-277624:8k_2_02:29]
SAN JOSE, Calif. — November 12, 2025 — Cisco today reported first quarter results for the
period ended October 25, 2025. Cisco reported first quarter revenue of $14.9 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.9 billion or $0.72 per share, and
non-GAAP net income of $4.0 billion or $1.00 per share.

[0001193125-25-277624:8k_2_02:30]
“We had a solid start to fiscal 2026, and
Cisco is on track to deliver our strongest year yet,” said Chuck Robbins, chair and CEO of Cisco. “The widespread demand for our technologies highlights the critical role of secure networking and the value of our portfolio as customers
move quickly to unlock the potential of AI.”

[0001193125-25-277624:8k_2_02:31]
“We delivered a strong quarter, with top and bottom-line performance exceeding our guidance, as
well as solid margins and operating cash flow,” said Mark Patterson, CFO of Cisco. “Our relevance in AI continues to build and we have a multi-year, multi-billion-dollar campus refresh opportunity starting to ramp, with strong demand for
our refreshed networking products. Looking ahead, you can expect a continued focus on profitable growth, capital returns, and strategic investments to capture the significant opportunities ahead.”

[0001193125-25-277624:8k_2_02:32]
GAAP Results

[0001193125-25-277624:8k_2_02:33]
|  |  | Q1 FY 2026 |  | Q1 FY 2025 |  | Vs. Q1 FY 2025 |
| Revenue |  | $14.9 billion |  | $13.8 billion |  | 8% |
| Net Income |  | $2.9 billion |  | $2.7 billion |  | 5% |
| Diluted Earnings per Share (EPS) |  | $0.72 |  | $0.68 |  | 6% |

[0001193125-25-277624:8k_2_02:34]
Non-GAAP Results

[0001193125-25-277624:8k_2_02:35]
|  |  | Q1 FY 2026 |  | Q1 FY 2025 |  | Vs. Q1 FY 2025 |
| Net Income |  | $4.0 billion |  | $3.7 billion |  | 9% |
| EPS |  | $1.00 |  | $0.91 |  | 10% |

[0001193125-25-277624:8k_2_02:36]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-25-277624:8k_2_02:37]
Cisco Declares Quarterly Dividend

[0001193125-25-277624:8k_2_02:38]
Cisco has declared a
quarterly dividend of $0.41 per common share to be paid on January 21, 2026, to all stockholders of record as of the close of business on January 2, 2026. Future dividends will be subject to Board approval.

[0001193125-25-277624:8k_2_02:39]
2

[0001193125-25-277624:8k_2_02:40]
Financial Summary

[0001193125-25-277624:8k_2_02:41]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-25-277624:8k_2_02:42]
Q1 FY 2026 Highlights

[0001193125-25-277624:8k_2_02:43]
Revenue —
Total revenue was $14.9 billion, up 8%, with product revenue up 10% and services revenue up 2%.

[0001193125-25-277624:8k_2_02:44]
Revenue by geographic segment
was: Americas up 9%, EMEA up 5%, and APJC up 5%. Product revenue performance reflected growth in Networking up 15% and Observability up 6%. Security was down 2% and Collaboration was down 3%.

[0001193125-25-277624:8k_2_02:45]
Gross Margin — On a GAAP basis, total gross margin, product gross margin, and services gross margin were 65.5%, 64.5%, and 68.4%,
respectively, as compared with 65.9%, 65.1%, and 68.0%, respectively, in the first quarter of fiscal 2025.

[0001193125-25-277624:8k_2_02:46]
On a non-GAAP basis, total gross margin, product gross margin, and services gross margin were 68.1%, 67.2%, and 70.7%, respectively, as compared with 69.3%, 68.9%, and 70.3%, respectively, in the first quarter of fiscal
2025.

[0001193125-25-277624:8k_2_02:47]
Total gross margins by geographic segment were: 66.8% for the Americas, 71.9% for EMEA and 66.9% for APJC.

[0001193125-25-277624:8k_2_02:48]
Operating Expenses — On a GAAP basis, operating expenses were $6.4 billion, down 6% year over year, and were 42.9% of revenue.
Non-GAAP operating expenses were $5.0 billion, up 3%, and were 33.7% of revenue.

[0001193125-25-277624:8k_2_02:49]
Operating Income — GAAP operating income was $3.4 billion, up 43%, with GAAP operating margin of 22.6%. Non-GAAP operating income was $5.1 billion, up 8%, with non-GAAP operating margin at 34.4%.

[0001193125-25-277624:8k_2_02:50]
Provision for Income Taxes — The GAAP tax provision rate was 15.7%. The non-GAAP tax provision
rate was 19.0%.

[0001193125-25-277624:8k_2_02:51]
Net Income and EPS — On a GAAP basis, net income was $2.9 billion, an increase of 5%, and EPS was
$0.72, an increase of 6%. On a non-GAAP basis, net income was $4.0 billion, an increase of 9%, and EPS was $1.00, an increase of 10%.

[0001193125-25-277624:8k_2_02:52]
Cash Flow from Operating Activities — $3.2 billion for the first quarter of fiscal 2026, a decrease of 12%, compared with
$3.7 billion for the first quarter of fiscal 2025.

[0001193125-25-277624:8k_2_02:53]
Balance Sheet and Other Financial Highlights

[0001193125-25-277624:8k_2_02:54]
Cash and Cash Equivalents and Investments — $15.7 billion at the end of the first quarter of fiscal 2026, compared with
$16.1 billion at the end of fiscal 2025.

[0001193125-25-277624:8k_2_02:55]
Remaining Performance Obligations (RPO) —
$42.9 billion, up 7% in total. Product RPO was up 10%, of which long-term RPO was $11.8 billion, up 13%. Services RPO was up 4%.

[0001193125-25-277624:8k_2_02:56]
Deferred Revenue — $28.0 billion, up 2% in total, with deferred product revenue up 2% and deferred services revenue up 1%.

[0001193125-25-277624:8k_2_02:57]
Capital Allocation — In the first quarter of fiscal 2026, we returned $3.6 billion to stockholders through share
buybacks and dividends. We declared and paid a cash dividend of $0.41 per common share, or $1.6 billion, and repurchased approximately 29 million shares of common stock under our stock repurchase program at an average price of $68.28 per
share for an aggregate purchase price of $2.0 billion. The remaining authorized amount for stock repurchases under the program is $12.2 billion with no termination date.

[0001193125-25-277624:8k_2_02:58]
Acquisitions

[0001193125-25-277624:8k_2_02:59]
In the first quarter of fiscal 2026, we
closed the acquisition of Aura Asset Intelligence, an asset and risk intelligence (ARI) solution created by Discovered Intelligence, a privately held company based in Toronto, Canada.

[0001193125-25-277624:8k_2_02:60]
3

[0001193125-25-277624:8k_2_02:61]
Guidance

[0001193125-25-277624:8k_2_02:62]
Cisco estimates the following results for the second quarter of fiscal 2026:

[0001193125-25-277624:8k_2_02:63]
| Q2 FY 2026 |  |  |
| Revenue |  | $15.0 billion - $15.2 billion |
| Non-GAAP gross margin |  | 67.5% - 68.5% |
| Non-GAAP operating margin |  | 33.5% - 34.5% |
| Non-GAAP EPS |  | $1.01 - $1.03 |

[0001193125-25-277624:8k_2_02:64]
Margin and EPS guidance includes the estimated impact of tariffs based on current trade policy.

[0001193125-25-277624:8k_2_02:65]
Cisco estimates that GAAP EPS will be $0.69 to $0.74 for the second quarter of fiscal 2026.

[0001193125-25-277624:8k_2_02:66]
Cisco estimates the following results for fiscal 2026:

[0001193125-25-277624:8k_2_02:67]
| FY 2026 |  |  |
| Revenue |  | $60.2 billion - $61.0 billion |
| Non-GAAP EPS |  | $4.08 - $4.14 |

[0001193125-25-277624:8k_2_02:68]
Margin and EPS guidance includes the estimated impact of tariffs based on current trade policy.

[0001193125-25-277624:8k_2_02:69]
Cisco estimates that GAAP EPS will be $2.87 to $2.98 for fiscal 2026.

[0001193125-25-277624:8k_2_02:70]
Our Q2 FY 2026 guidance assumes an effective tax provision rate of approximately 16% for GAAP and approximately 19% for
non-GAAP results. Our FY 2026 guidance assumes an effective tax provision rate of approximately 17% for GAAP and approximately 19% for non-GAAP results.

[0001193125-25-277624:8k_2_02:71]
A reconciliation between the guidance on a GAAP and non-GAAP basis is provided in the tables entitled “GAAP to non-GAAP Guidance” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-25-277624:8k_2_02:72]
Editor’s Notes:

[0001193125-25-277624:8k_2_02:73]
|  | • |  | Q1 fiscal year 2026 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, November 12, 2025 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-25-277624:8k_2_02:74]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, November 12, 2025 to 10:00 p.m. Pacific Time, November 18, 2025 at 1-800-839-2232 (United States) or 1-203-369-3662 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-25-277624:8k_2_02:75]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, November 12, 2025. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-25-277624:8k_2_02:76]
4

[0001193125-25-277624:8k_2_02:77]
CISCO SYSTEMS, INC.

[0001193125-25-277624:8k_2_02:78]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-25-277624:8k_2_02:79]
(In millions, except per-share amounts)

[0001193125-25-277624:8k_2_02:80]
(Unaudited)

[0001193125-25-277624:8k_2_02:81]
|  |  | Three Months Ended |  |
|  |  | October 25,2025 |  |  | October 26,2024 |  |
| REVENUE: |  |  |  |  |  |  |  |  |
| Product |  | $ | 11,077 |  |  | $ | 10,114 |  |
| Services |  |  | 3,806 |  |  |  | 3,727 |  |
| Total revenue |  |  | 14,883 |  |  |  | 13,841 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |
| Product |  |  | 3,934 |  |  |  | 3,526 |  |
| Services |  |  | 1,204 |  |  |  | 1,194 |  |
| Total cost of sales |  |  | 5,138 |  |  |  | 4,720 |  |
| GROSS MARGIN |  |  | 9,745 |  |  |  | 9,121 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 2,400 |  |  |  | 2,286 |  |
| Sales and marketing |  |  | 2,871 |  |  |  | 2,752 |  |
| General and administrative |  |  | 733 |  |  |  | 795 |  |
| Amortization of purchased intangible assets |  |  | 231 |  |  |  | 265 |  |
| Restructuring and other charges |  |  | 147 |  |  |  | 665 |  |
| Total operating expenses |  |  | 6,382 |  |  |  | 6,763 |  |
| OPERATING INCOME |  |  | 3,363 |  |  |  | 2,358 |  |
| Interest income |  |  | 222 |  |  |  | 286 |  |
| Interest expense |  |  | (350 | ) |  |  | (418 | ) |
| Other income (loss), net |  |  | 156 |  |  |  | 41 |  |
| Interest and other income (loss), net |  |  | 28 |  |  |  | (91 | ) |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,391 |  |  |  | 2,267 |  |
| Provision for (benefit from) income taxes |  |  | 531 |  |  |  | (444 | ) |
| NET INCOME |  | $ | 2,860 |  |  | $ | 2,711 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.72 |  |  | $ | 0.68 |  |
| Diluted |  | $ | 0.72 |  |  | $ | 0.68 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |
| Basic |  |  | 3,956 |  |  |  | 3,990 |  |
| Diluted |  |  | 3,993 |  |  |  | 4,013 |  |

[0001193125-25-277624:8k_2_02:82]
5

[0001193125-25-277624:8k_2_02:83]
CISCO SYSTEMS, INC.

[0001193125-25-277624:8k_2_02:84]
REVENUE BY SEGMENT

[0001193125-25-277624:8k_2_02:85]
(In
millions, except percentages)

[0001193125-25-277624:8k_2_02:86]
|  |  | Three Months Ended |  |
|  |  | October 25, 2025 |  |
|  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 8,989 |  |  |  | 9% |  |
| EMEA |  |  | 3,784 |  |  |  | 5% |  |
| APJC |  |  | 2,111 |  |  |  | 5% |  |
| Total |  | $ | 14,883 |  |  |  | 8% |  |

[0001193125-25-277624:8k_2_02:87]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-25-277624:8k_2_02:88]
CISCO SYSTEMS, INC.

[0001193125-25-277624:8k_2_02:89]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-25-277624:8k_2_02:90]
(In percentages)

[0001193125-25-277624:8k_2_02:91]
|  |  | Three Months Ended |  |
|  |  | October 25, 2025 |  |
| Gross Margin Percentage: |  |  |  |  |
| Americas |  |  | 66.8% |  |
| EMEA |  |  | 71.9% |  |
| APJC |  |  | 66.9% |  |

[0001193125-25-277624:8k_2_02:92]
CISCO SYSTEMS, INC.

[0001193125-25-277624:8k_2_02:93]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-25-277624:8k_2_02:94]
(In millions, except percentages)

[0001193125-25-277624:8k_2_02:95]
|  |  | Three Months Ended |  |
|  |  | October 25, 2025 |  |
|  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Networking |  | $ | 7,768 |  |  |  | 15% |  |
| Security |  |  | 1,980 |  |  |  | (2)% |  |
| Collaboration |  |  | 1,055 |  |  |  | (3)% |  |
| Observability |  |  | 274 |  |  |  | 6% |  |
| Total Product |  |  | 11,077 |  |  |  | 10% |  |
| Services |  |  | 3,806 |  |  |  | 2% |  |
| Total |  | $ | 14,883 |  |  |  | 8% |  |

[0001193125-25-277624:8k_2_02:96]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-25-277624:8k_2_02:97]
6

[0001193125-25-277624:8k_2_02:98]
CISCO SYSTEMS, INC.

[0001193125-25-277624:8k_2_02:99]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-25-277624:8k_2_02:100]
(In millions)

[0001193125-25-277624:8k_2_02:101]
(Unaudited)

[0001193125-25-277624:8k_2_02:102]
|  |  | October 25,2025 |  |  | July 26,2025 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 8,400 |  |  | $ | 8,346 |  |
| Investments |  |  | 7,336 |  |  |  | 7,764 |  |
| Accounts receivable, net of allowance of $62 at October 25, 2025 and $69 at July 26, 2025 |  |  | 4,827 |  |  |  | 6,701 |  |
| Inventories |  |  | 3,395 |  |  |  | 3,164 |  |
| Financing receivables, net |  |  | 3,085 |  |  |  | 3,061 |  |
| Other current assets |  |  | 5,833 |  |  |  | 5,950 |  |
| Total current assets |  |  | 32,876 |  |  |  | 34,986 |  |
| Property and equipment, net |  |  | 2,248 |  |  |  | 2,113 |  |
| Financing receivables, net |  |  | 3,719 |  |  |  | 3,466 |  |
| Goodwill |  |  | 59,119 |  |  |  | 59,136 |  |
| Purchased intangible assets, net |  |  | 8,713 |  |  |  | 9,175 |  |
| Deferred tax assets |  |  | 7,314 |  |  |  | 7,356 |  |
| Other assets |  |  | 7,113 |  |  |  | 6,059 |  |
| TOTAL ASSETS |  | $ | 121,102 |  |  | $ | 122,291 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 6,725 |  |  | $ | 5,232 |  |
| Accounts payable |  |  | 2,418 |  |  |  | 2,528 |  |
| Income taxes payable |  |  | 2,471 |  |  |  | 1,857 |  |
| Accrued compensation |  |  | 3,064 |  |  |  | 3,611 |  |
| Deferred revenue |  |  | 15,801 |  |  |  | 16,416 |  |
| Other current liabilities |  |  | 4,972 |  |  |  | 5,420 |  |
| Total current liabilities |  |  | 35,451 |  |  |  | 35,064 |  |
| Long-term debt |  |  | 21,364 |  |  |  | 22,861 |  |
| Income taxes payable |  |  | 2,172 |  |  |  | 2,165 |  |
| Deferred revenue |  |  | 12,168 |  |  |  | 12,363 |  |
| Other long-term liabilities |  |  | 3,074 |  |  |  | 2,995 |  |
| Total liabilities |  |  | 74,229 |  |  |  | 75,448 |  |
| Total equity |  |  | 46,873 |  |  |  | 46,843 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 121,102 |  |  | $ | 122,291 |  |

[0001193125-25-277624:8k_2_02:103]
7

[0001193125-25-277624:8k_2_02:104]
CISCO SYSTEMS, INC.

[0001193125-25-277624:8k_2_02:105]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-25-277624:8k_2_02:106]
(In millions)

[0001193125-25-277624:8k_2_02:107]
(Unaudited)

[0001193125-25-277624:8k_2_02:108]
|  |  | Three Months Ended |  |
|  |  | October 25,2025 |  |  | October 26,2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 2,860 |  |  | $ | 2,711 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 606 |  |  |  | 789 |  |
| Share-based compensation expense |  |  | 1,055 |  |  |  | 827 |  |
| Provision for (benefit from) receivables |  |  | (3 | ) |  |  | (1 | ) |
| Deferred income taxes |  |  | 25 |  |  |  | (281 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (178 | ) |  |  | (60 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,857 |  |  |  | 2,227 |  |
| Inventories |  |  | (234 | ) |  |  | 229 |  |
| Financing receivables |  |  | (312 | ) |  |  | 173 |  |
| Other assets |  |  | (592 | ) |  |  | (190 | ) |
| Accounts payable |  |  | (108 | ) |  |  | (269 | ) |
| Income taxes, net |  |  | (128 | ) |  |  | (806 | ) |
| Accrued compensation |  |  | (539 | ) |  |  | (754 | ) |
| Deferred revenue |  |  | (723 | ) |  |  | (971 | ) |
| Other liabilities |  |  | (374 | ) |  |  | 37 |  |
| Net cash provided by operating activities |  |  | 3,212 |  |  |  | 3,661 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (1,984 | ) |  |  | (1,775 | ) |
| Proceeds from sales of investments |  |  | 1,269 |  |  |  | 1,490 |  |
| Proceeds from maturities of investments |  |  | 1,222 |  |  |  | 1,164 |  |
| Acquisitions, net of cash and cash equivalents acquired and divestitures |  |  | (7 | ) |  |  | (217 | ) |
| Purchases of investments in privately held companies |  |  | (18 | ) |  |  | (42 | ) |
| Return of investments in privately held companies |  |  | 19 |  |  |  | 77 |  |
| Acquisition of property and equipment |  |  | (323 | ) |  |  | (217 | ) |
| Other |  |  | (22 | ) |  |  | (1 | ) |
| Net cash provided by investing activities |  |  | 156 |  |  |  | 479 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Repurchases of common stock - repurchase program |  |  | (1,992 | ) |  |  | (2,003 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (284 | ) |  |  | (165 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | 1,260 |  |  |  | 68 |  |
| Issuances of debt |  |  | 1,559 |  |  |  | 5,732 |  |
| Repayments of debt |  |  | (2,788 | ) |  |  | (4,821 | ) |
| Dividends paid |  |  | (1,617 | ) |  |  | (1,592 | ) |
| Other |  |  | (1 | ) |  |  | (3 | ) |
| Net cash used in financing activities |  |  | (3,863 | ) |  |  | (2,784 | ) |
| Effect of foreign currency exchange rate changes on cash, cash equivalents, restricted cash and restricted cash equivalents |  |  | (14 | ) |  |  | 10 |  |
| Net increase (decrease) in cash, cash equivalents, restricted cash and restricted cash equivalents |  |  | (509 | ) |  |  | 1,366 |  |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, beginning of period |  |  | 8,910 |  |  |  | 8,842 |  |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, end of period |  | $ | 8,401 |  |  | $ | 10,208 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 616 |  |  | $ | 545 |  |
| Cash paid for income taxes, net |  | $ | 634 |  |  | $ | 643 |  |

[0001193125-25-277624:8k_2_02:109]
8

[0001193125-25-277624:8k_2_02:110]
CISCO SYSTEMS, INC.

[0001193125-25-277624:8k_2_02:111]
REMAINING PERFORMANCE OBLIGATIONS

[0001193125-25-277624:8k_2_02:112]
(In millions, except percentages)

[0001193125-25-277624:8k_2_02:113]
|  |  | October 25, 2025 |  |  | July 26, 2025 |  |  | October 26, 2024 |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Product (1) |  | $ | 21,904 |  |  |  | 10 | % |  | $ | 21,572 |  |  |  | 8 | % |  | $ | 19,882 |  |  |  | 24 | % |
| Services |  |  | 20,969 |  |  |  | 4 | % |  |  | 21,961 |  |  |  | 5 | % |  |  | 20,108 |  |  |  | 7 | % |
| Total |  | $ | 42,873 |  |  |  | 7 | % |  | $ | 43,533 |  |  |  | 6 | % |  | $ | 39,990 |  |  |  | 15 | % |

[0001193125-25-277624:8k_2_02:114]
(1) As of the end of the first quarter of fiscal 2026, long-term product
RPO was $11.8B, up 13% year over year.

[0001193125-25-277624:8k_2_02:115]
CISCO SYSTEMS, INC.

[0001193125-25-277624:8k_2_02:116]
DEFERRED REVENUE

[0001193125-25-277624:8k_2_02:117]
(In
millions)

[0001193125-25-277624:8k_2_02:118]
|  |  | October 25,2025 |  |  | July 26,2025 |  |  | October 26,2024 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 13,252 |  |  | $ | 13,490 |  |  | $ | 12,941 |  |
| Services |  |  | 14,717 |  |  |  | 15,289 |  |  |  | 14,561 |  |
| Total |  | $ | 27,969 |  |  | $ | 28,779 |  |  | $ | 27,502 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 15,801 |  |  | $ | 16,416 |  |  | $ | 15,615 |  |
| Noncurrent |  |  | 12,168 |  |  |  | 12,363 |  |  |  | 11,887 |  |
| Total |  | $ | 27,969 |  |  | $ | 28,779 |  |  | $ | 27,502 |  |

[0001193125-25-277624:8k_2_02:119]
CISCO SYSTEMS, INC.

[0001193125-25-277624:8k_2_02:120]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-25-277624:8k_2_02:121]
(In millions, except per-share amounts)

[0001193125-25-277624:8k_2_02:122]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | PerShare |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2026 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| October 25, 2025 |  | $ | 0.41 |  |  | $ | 1,617 |  |  |  | 29 |  |  | $ | 68.28 |  |  | $ | 2,001 |  |  | $ | 3,618 |  |
| Fiscal 2025 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 26, 2025 |  | $ | 0.41 |  |  | $ | 1,625 |  |  |  | 19 |  |  | $ | 64.65 |  |  | $ | 1,252 |  |  | $ | 2,877 |  |
| April 26, 2025 |  | $ | 0.41 |  |  | $ | 1,627 |  |  |  | 25 |  |  | $ | 59.78 |  |  | $ | 1,504 |  |  | $ | 3,131 |  |
| January 25, 2025 |  | $ | 0.40 |  |  | $ | 1,593 |  |  |  | 21 |  |  | $ | 58.58 |  |  | $ | 1,236 |  |  | $ | 2,829 |  |
| October 26, 2024 |  | $ | 0.40 |  |  | $ | 1,592 |  |  |  | 40 |  |  | $ | 49.56 |  |  | $ | 2,003 |  |  | $ | 3,595 |  |

[0001193125-25-277624:8k_2_02:123]
9

[0001193125-25-277624:8k_2_02:124]
CISCO SYSTEMS, INC.

[0001193125-25-277624:8k_2_02:125]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-25-277624:8k_2_02:126]
GAAP TO NON-GAAP NET INCOME

[0001193125-25-277624:8k_2_02:127]
(In millions)

[0001193125-25-277624:8k_2_02:128]
|  |  | Three Months Ended |  |
|  |  | October 25,2025 |  |  | October 26,2024 |  |
| GAAP net income |  | $ | 2,860 |  |  | $ | 2,711 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 150 |  |  |  | 131 |  |
| Amortization of acquisition-related intangible assets |  |  | 233 |  |  |  | 319 |  |
| Acquisition/divestiture-related costs |  |  | 8 |  |  |  | 19 |  |
| Total adjustments to GAAP cost of sales |  |  | 391 |  |  |  | 469 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 884 |  |  |  | 679 |  |
| Amortization of acquisition-related intangible assets |  |  | 231 |  |  |  | 265 |  |
| Acquisition/divestiture-related costs |  |  | 103 |  |  |  | 285 |  |
| Significant asset impairments and restructurings |  |  | 147 |  |  |  | 665 |  |
| Total adjustments to GAAP operating expenses |  |  | 1,365 |  |  |  | 1,894 |  |
| Adjustments to interest and other income (loss), net: |  |  |  |  |  |  |  |  |
| (Gains) and losses on investments |  |  | (195 | ) |  |  | (98 | ) |
| Total adjustments to GAAP interest and other income (loss), net |  |  | (195 | ) |  |  | (98 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 1,561 |  |  |  | 2,265 |  |
| Income tax effect of non-GAAP adjustments |  |  | (337 | ) |  |  | (476 | ) |
| Significant tax matters |  |  | (73 | ) |  |  | (829 | ) |
| Total adjustments to GAAP provision for income taxes |  |  | (410 | ) |  |  | (1,305 | ) |
| Non-GAAP net income |  | $ | 4,011 |  |  | $ | 3,671 |  |

[0001193125-25-277624:8k_2_02:129]
10

[0001193125-25-277624:8k_2_02:130]
CISCO SYSTEMS, INC.

[0001193125-25-277624:8k_2_02:131]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-25-277624:8k_2_02:132]
GAAP TO NON-GAAP EPS

[0001193125-25-277624:8k_2_02:133]
|  |  | Three Months Ended |  |
|  |  | October 25,2025 |  |  | October 26,2024 |  |
| GAAP EPS |  | $ | 0.72 |  |  | $ | 0.68 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.26 |  |  |  | 0.20 |  |
| Amortization of acquisition-related intangible assets |  |  | 0.12 |  |  |  | 0.15 |  |
| Acquisition/divestiture-related costs |  |  | 0.03 |  |  |  | 0.08 |  |
| Significant asset impairments and restructurings |  |  | 0.04 |  |  |  | 0.17 |  |
| (Gains) and losses on investments |  |  | (0.05 | ) |  |  | (0.02 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.08 | ) |  |  | (0.12 | ) |
| Significant tax matters |  |  | (0.02 | ) |  |  | (0.21 | ) |
| Non-GAAP EPS |  | $ | 1.00 |  |  | $ | 0.91 |  |

[0001193125-25-277624:8k_2_02:134]
Amounts may not sum due to rounding.

[0001193125-25-277624:8k_2_02:135]
CISCO SYSTEMS, INC.

[0001193125-25-277624:8k_2_02:136]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-25-277624:8k_2_02:137]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND

[0001193125-25-277624:8k_2_02:138]
NET INCOME

[0001193125-25-277624:8k_2_02:139]
(In millions,
except percentages)

[0001193125-25-277624:8k_2_02:140]
|  |  | Three Months Ended |  |
|  |  | October 25, 2025 |  |
|  |  | ProductGrossMargin |  |  | ServicesGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 7,143 |  |  | $ | 2,602 |  |  | $ | 9,745 |  |  | $ | 6,382 |  |  |  | (6 | )% |  | $ | 3,363 |  |  |  | 43 | % |  | $ | 28 |  |  | $ | 2,860 |  |  |  | 5 | % |
| % of revenue |  |  | 64.5 | % |  |  | 68.4 | % |  |  | 65.5 | % |  |  | 42.9 | % |  |  |  |  |  |  | 22.6 | % |  |  |  |  |  |  | 0.2 | % |  |  | 19.2 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 68 |  |  |  | 82 |  |  |  | 150 |  |  |  | 884 |  |  |  |  |  |  |  | 1,034 |  |  |  |  |  |  |  | — |  |  |  | 1,034 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 233 |  |  |  | — |  |  |  | 233 |  |  |  | 231 |  |  |  |  |  |  |  | 464 |  |  |  |  |  |  |  | — |  |  |  | 464 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 2 |  |  |  | 6 |  |  |  | 8 |  |  |  | 103 |  |  |  |  |  |  |  | 111 |  |  |  |  |  |  |  | — |  |  |  | 111 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 147 |  |  |  |  |  |  |  | 147 |  |  |  |  |  |  |  | — |  |  |  | 147 |  |  |  |  |  |
| (Gains) and losses on investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (195 | ) |  |  | (195 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (410 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 7,446 |  |  | $ | 2,690 |  |  | $ | 10,136 |  |  | $ | 5,017 |  |  |  | 3 | % |  | $ | 5,119 |  |  |  | 8 | % |  | $ | (167 | ) |  | $ | 4,011 |  |  |  | 9 | % |
| % of revenue |  |  | 67.2 | % |  |  | 70.7 | % |  |  | 68.1 | % |  |  | 33.7 | % |  |  |  |  |  |  | 34.4 | % |  |  |  |  |  |  | (1.1 | )% |  |  | 27.0 | % |  |  |  |  |

[0001193125-25-277624:8k_2_02:141]
|  |  | Three Months Ended |  |
|  |  | October 26, 2024 |  |
|  |  | ProductGrossMargin |  |  | ServicesGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |
| GAAP amount |  | $ | 6,588 |  |  | $ | 2,533 |  |  | $ | 9,121 |  |  | $ | 6,763 |  |  | $ | 2,358 |  |  | $ | (91 | ) |  | $ | 2,711 |  |
| % of revenue |  |  | 65.1 | % |  |  | 68.0 | % |  |  | 65.9 | % |  |  | 48.9 | % |  |  | 17.0 | % |  |  | (0.7 | )% |  |  | 19.6 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 57 |  |  |  | 74 |  |  |  | 131 |  |  |  | 679 |  |  |  | 810 |  |  |  | — |  |  |  | 810 |  |
| Amortization of acquisition-related intangible assets |  |  | 319 |  |  |  | — |  |  |  | 319 |  |  |  | 265 |  |  |  | 584 |  |  |  | — |  |  |  | 584 |  |
| Acquisition/divestiture-related costs |  |  | 5 |  |  |  | 14 |  |  |  | 19 |  |  |  | 285 |  |  |  | 304 |  |  |  | — |  |  |  | 304 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 665 |  |  |  | 665 |  |  |  | — |  |  |  | 665 |  |
| (Gains) and losses on investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (98 | ) |  |  | (98 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,305 | ) |
| Non-GAAP amount |  | $ | 6,969 |  |  | $ | 2,621 |  |  | $ | 9,590 |  |  | $ | 4,869 |  |  | $ | 4,721 |  |  | $ | (189 | ) |  | $ | 3,671 |  |
| % of revenue |  |  | 68.9 | % |  |  | 70.3 | % |  |  | 69.3 | % |  |  | 35.2 | % |  |  | 34.1 | % |  |  | (1.4 | )% |  |  | 26.5 | % |

[0001193125-25-277624:8k_2_02:142]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-25-277624:8k_2_02:143]
12

[0001193125-25-277624:8k_2_02:144]
CISCO SYSTEMS, INC.

[0001193125-25-277624:8k_2_02:145]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-25-277624:8k_2_02:146]
EFFECTIVE TAX RATE

[0001193125-25-277624:8k_2_02:147]
(In
percentages)

[0001193125-25-277624:8k_2_02:148]
|  |  | Three Months Ended |  |
|  |  | October 25,2025 |  |  | October 26,2024 |  |
| GAAP effective tax rate |  |  | 15.7 | % |  |  | (19.6 | )% |
| Total adjustments to GAAP provision for income taxes |  |  | 3.3 | % |  |  | 38.6 | % |
| Non-GAAP effective tax rate |  |  | 19.0 | % |  |  | 19.0 | % |

[0001193125-25-277624:8k_2_02:149]
GAAP TO NON-GAAP GUIDANCE

[0001193125-25-277624:8k_2_02:150]
| Q2 FY 2026 |  | Gross MarginRate |  | Operating MarginRate |  | Earnings perShare (1) |
| GAAP |  | 65% - 66% |  | 22.5% - 23.5% |  | $0.69 - $0.74 |
| Estimated adjustments for: |  |  |  |  |  |  |
| Share-based compensation expense |  | 1.0% |  | 7.0% |  | $0.18 - $0.19 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 1.5% |  | 3.5% |  | $0.11 - $0.12 |
| Significant asset impairments and restructurings |  | — |  | 0.5% |  | $0.00 - $0.01 |
| Non-GAAP |  | 67.5% - 68.5% |  | 33.5% - 34.5% |  | $1.01 - $1.03 |

[0001193125-25-277624:8k_2_02:151]
| FY 2026 |  | Earnings perShare (1) |  |
| GAAP |  | $ | 2.87 - $2.98 |  |
| Estimated adjustments for: |  |  |  |  |
| Share-based compensation expense |  | $ | 0.75 - $0.77 |  |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | $ | 0.43 - $0.45 |  |
| Significant asset impairments and restructurings |  | $ | 0.03 - $0.04 |  |
| (Gains) and losses on investments |  |  | ($0.03) |  |
| Significant tax matters |  |  | ($0.02) |  |
| Non-GAAP |  | $ | 4.08 - $4.14 |  |

[0001193125-25-277624:8k_2_02:152]
|  | (1) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-25-277624:8k_2_02:153]
Margin and EPS guidance includes the estimated impact of tariffs based on current trade policy.

[0001193125-25-277624:8k_2_02:154]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, significant asset impairments and
restructurings, significant litigation settlements and other contingencies, gains and losses on investments, significant tax matters, or other items, which may or may not be significant.

[0001193125-25-277624:8k_2_02:155]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-25-277624:8k_2_02:156]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax rates,
non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross
margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-25-277624:8k_2_02:157]
These
non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles (GAAP) and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used
to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-25-277624:8k_2_02:158]
14

[0001193125-25-277624:8k_2_02:159]
Cisco believes that the presentation of non-GAAP measures when shown
in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-25-277624:8k_2_02:160]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, acquisition/divestiture-related costs, significant asset impairments and restructurings, significant litigation settlements and other contingencies, gains and losses on investments, the income
tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial results
of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be other items that Cisco may
exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures,
refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-25-277624:8k_2_02:161]
About
Cisco

[0001193125-25-277624:8k_2_02:162]
Cisco (NASDAQ: CSCO) is the worldwide technology leader that is revolutionizing the way organizations connect and protect in the AI era. For
more than 40 years, Cisco has securely connected the world. With its industry leading AI-powered solutions and services, Cisco enables its customers, partners and communities to unlock innovation, enhance
productivity and strengthen digital resilience. With purpose at its core, Cisco remains committed to creating a more connected and inclusive future for all. Discover more on The Newsroom and follow us on X at @Cisco.

[0001193125-25-277624:8k_2_02:163]
Copyright © 2025 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are
trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their
respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-25-277624:8k_2_02:164]
RSS Feed for Cisco: https://newsroom.cisco.com/rss-feeds

[0001193125-25-277624:8k_2_02:165]
15
