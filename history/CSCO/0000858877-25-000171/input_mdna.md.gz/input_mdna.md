# CSCO MD&A — 0000858877-25-000171


## mdna

[0000858877-25-000171:mdna:1]
[same as prior period, unchanged from 0000858877-25-000033:mdna:1]

[0000858877-25-000171:mdna:2]
[same as prior period, unchanged from 0000858877-25-000033:mdna:2]

[0000858877-25-000171:mdna:3]
[same as prior period, unchanged from 0000858877-25-000033:mdna:3]

[0000858877-25-000171:mdna:4]
Cisco designs and sells a broad range of technologies that help to power, secure, and draw insights from the Internet. We are incorporating artificial intelligence (AI) into our product portfolios across networking, security, collaboration and observability as well as integrating our products more tightly together. We are simplifying how our technology is delivered, managed and optimized and helping customers maximize the business value of their technology investments.

[0000858877-25-000171:mdna:5]
[same as prior period, unchanged from 0000858877-25-000033:mdna:5]

[0000858877-25-000171:mdna:6]
|  | Three Months Ended |  |
|  | October 25,2025 |  | October 26,2024 |  | % Variance |  |
| Revenue | $ | 14,883 |  |  | $ | 13,841 |  |  | 8 | % |  |
| Gross margin percentage | 65.5 | % |  | 65.9 | % |  | (0.4) |  | pts |
| Research and development | $ | 2,400 |  |  | $ | 2,286 |  |  | 5 | % |  |
| Sales and marketing | $ | 2,871 |  |  | $ | 2,752 |  |  | 4 | % |  |
| General and administrative | $ | 733 |  |  | $ | 795 |  |  | (8) | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 6,004 |  |  | $ | 5,833 |  |  | 3 | % |  |
| Total as a percentage of revenue | 40.3 | % |  | 42.1 | % |  | (1.8) |  | pts |
| Operating income as a percentage of revenue | 22.6 | % |  | 17.0 | % |  | 5.6 |  | pts |
| Interest and other income (loss), net | $ | 28 |  |  | $ | (91) |  |  | NM |  |
| Income tax percentage | 15.7 | % |  | (19.6) | % |  | 35.3 |  | pts |
| Net income | $ | 2,860 |  |  | $ | 2,711 |  |  | 5 | % |  |
| Net income as a percentage of revenue | 19.2 | % |  | 19.6 | % |  | (0.4) |  | pts |
| Earnings per share—diluted | $ | 0.72 |  |  | $ | 0.68 |  |  | 6 | % |  |

[0000858877-25-000171:mdna:7]
[same as prior period, unchanged from 0000858877-25-000033:mdna:7]

[0000858877-25-000171:mdna:8]
[same as prior period, unchanged from 0000858877-25-000033:mdna:8]

[0000858877-25-000171:mdna:9]
35

[0000858877-25-000171:mdna:10]
[same as prior period, unchanged from 0000858877-25-000033:mdna:10]

[0000858877-25-000171:mdna:11]
[same as prior period, unchanged from 0000858877-25-000033:mdna:11]

[0000858877-25-000171:mdna:12]
Three Months Ended October 25, 2025 Compared with Three Months Ended October 26, 2024

[0000858877-25-000171:mdna:13]
In the first quarter of fiscal 2026, we delivered strong revenue growth across all geographies and solid margins as we saw a positive demand environment. Total revenue increased by 8% compared with the first quarter of fiscal 2025, driven by revenue from Networking, particularly within our AI Infrastructure and Campus Networking solutions. Within total revenue, product revenue increased by 10% and services revenue increased by 2%. In the first quarter of fiscal 2026, total software revenue was $5.7 billion across all product areas and services, an increase of 3%. Total subscription revenue increased 2%.

[0000858877-25-000171:mdna:14]
Total gross margin decreased by 0.4 percentage points. Product gross margin decreased by 0.6 percentage points, primarily driven by negative impacts from product mix and pricing, partially offset by productivity improvements and lower amortization of purchased intangible assets. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 1.8 percentage points. Operating income as a percentage of revenue increased by 5.6 percentage points primarily driven by lower restructuring and other charges and revenue growth in the first quarter of fiscal 2026. Diluted earnings per share increased 6%, driven by the revenue growth and operating margin improvement, partially offset by the income tax benefit of $720 million we had in the first quarter of fiscal 2025.

[0000858877-25-000171:mdna:15]
In terms of our geographic segments, revenue from the Americas increased by $0.7 billion, EMEA revenue increased by $0.2 billion and APJC revenue increased by $0.1 billion. From a customer market standpoint, we experienced product revenue growth across all of our customer markets. From a product category perspective, the product revenue increase of 10% was driven by growth in Networking of 15% and Observability of 6%, partially offset by declines in Collaboration of 3% and Security of 2%.

[0000858877-25-000171:mdna:16]
We continue to operate in a highly competitive environment, and one that is complex especially with respect to tariffs and trade policy. We plan to continue to invest in key priority areas with the objective of driving profitable growth over the long term. We remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformations and on accelerating innovation across our portfolio. We believe that we are making progress on our strategic priorities.

[0000858877-25-000171:mdna:17]
[same as prior period, unchanged from 0000858877-25-000033:mdna:21]

[0000858877-25-000171:mdna:18]
In today’s digital-first world, businesses and organizations globally are deploying technology to pursue their strategic objectives, from accelerating growth to enhancing operational efficiency and fostering innovation. Our strategy is to securely connect everything to make those desired outcomes possible.

[0000858877-25-000171:mdna:19]
For additional discussion of our strategy and priorities, see Item 1. Business in our Annual Report on Form 10-K for the fiscal year ended July 26, 2025.

[0000858877-25-000171:mdna:20]
[same as prior period, unchanged from 0000858877-25-000033:mdna:24]

[0000858877-25-000171:mdna:21]
The following is a summary of our other key financial measures for the first quarter of fiscal 2026 (in millions):

[0000858877-25-000171:mdna:22]
|  |  | October 25,2025 |  | July 26,2025 |
| Cash and cash equivalents and investments |  | $ | 15,736 |  |  | $ | 16,110 |  |
| Remaining performance obligations |  | $ | 42,873 |  |  | $ | 43,533 |  |
| Inventories |  | $ | 3,395 |  |  | $ | 3,164 |  |
| Total debt |  | $ | 28,089 |  |  | $ | 28,093 |  |

[0000858877-25-000171:mdna:23]
|  |  | Three Months Ended |
|  |  | October 25,2025 |  | October 26,2024 |
| Cash provided by operating activities |  | $ | 3,212 |  |  | $ | 3,661 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 2,001 |  |  | $ | 2,003 |  |
| Dividends paid |  | $ | 1,617 |  |  | $ | 1,592 |  |

[0000858877-25-000171:mdna:24]
[same as prior period, unchanged from 0000858877-25-000033:mdna:17]

[0000858877-25-000171:mdna:25]
[same as prior period, unchanged from 0000858877-25-000033:mdna:18]

[0000858877-25-000171:mdna:26]
[same as prior period, unchanged from 0000858877-25-000033:mdna:30]

[0000858877-25-000171:mdna:27]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements in our Annual Report on Form 10-K for the fiscal year ended July 26, 2025, as updated as applicable in Note 2 to the Consolidated Financial Statements herein, describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-25-000171:mdna:28]
[same as prior period, unchanged from 0000858877-25-000033:mdna:32]

[0000858877-25-000171:mdna:29]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations, resulting in contracts that may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis.

[0000858877-25-000171:mdna:30]
[same as prior period, unchanged from 0000858877-25-000033:mdna:34]

[0000858877-25-000171:mdna:31]
[same as prior period, unchanged from 0000858877-25-000033:mdna:35]

[0000858877-25-000171:mdna:32]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers that we sell to directly. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable. If actual credits received by customers under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-25-000171:mdna:33]
[same as prior period, unchanged from 0000858877-25-000033:mdna:37]

[0000858877-25-000171:mdna:34]
[same as prior period, unchanged from 0000858877-25-000033:mdna:38]

[0000858877-25-000171:mdna:35]
Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and net realizable value, based upon assumptions about future demand, and are charged to the provision for inventory. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-25-000171:mdna:36]
[same as prior period, unchanged from 0000858877-25-000033:mdna:28]

[0000858877-25-000171:mdna:37]
[same as prior period, unchanged from 0000858877-25-000033:mdna:29]

[0000858877-25-000171:mdna:38]
We record a provision for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. Both provisions are a component of cost of sales.

[0000858877-25-000171:mdna:39]
Our total provisions for inventory and the liability related to purchase commitments with contract manufacturers and suppliers were $63 million and $201 million for the first quarter of fiscal 2026 and 2025, respectively. If there were to be a sudden and significant decrease in demand for our products, or a higher incidence of inventory obsolescence because of rapidly changing technology or customer requirements, then we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. For further discussion around the supply chain impacts and risks, see “—Results of Operations—Gross Margin—Supply Chain Impacts and Risks” and “—Liquidity and Capital Resources—Inventory Supply Chain.”

[0000858877-25-000171:mdna:40]
Loss Contingencies

[0000858877-25-000171:mdna:41]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-25-000171:mdna:42]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-25-000171:mdna:43]
[same as prior period, unchanged from 0000858877-25-000033:mdna:48]

[0000858877-25-000171:mdna:44]
[same as prior period, unchanged from 0000858877-25-000033:mdna:49]

[0000858877-25-000171:mdna:45]
[same as prior period, unchanged from 0000858877-25-000033:mdna:50]

[0000858877-25-000171:mdna:46]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first quarter of fiscal 2026 and 2025.

[0000858877-25-000171:mdna:47]
[same as prior period, unchanged from 0000858877-25-000033:mdna:52]

[0000858877-25-000171:mdna:48]
[same as prior period, unchanged from 0000858877-25-000033:mdna:53]

[0000858877-25-000171:mdna:49]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset group to the future undiscounted cash flows the asset group is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business

[0000858877-25-000171:mdna:50]
[same as prior period, unchanged from 0000858877-25-000033:mdna:41]

[0000858877-25-000171:mdna:51]
[same as prior period, unchanged from 0000858877-25-000033:mdna:42]

[0000858877-25-000171:mdna:52]
strategy and our internal forecasts. Our ongoing consideration of all the factors described previously could result in impairment charges in the future, which could adversely affect our net income.

[0000858877-25-000171:mdna:53]
[same as prior period, unchanged from 0000858877-25-000033:mdna:59]

[0000858877-25-000171:mdna:54]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was a tax provision of 15.7% and a benefit of 19.6% in the first quarter of fiscal 2026 and 2025, respectively.

[0000858877-25-000171:mdna:55]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves due to changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, and the related net interest and penalties.

[0000858877-25-000171:mdna:56]
[same as prior period, unchanged from 0000858877-25-000033:mdna:62]

[0000858877-25-000171:mdna:57]
[same as prior period, unchanged from 0000858877-25-000033:mdna:63]

[0000858877-25-000171:mdna:58]
[same as prior period, unchanged from 0000858877-25-000033:mdna:56]

[0000858877-25-000171:mdna:59]
[same as prior period, unchanged from 0000858877-25-000033:mdna:57]

[0000858877-25-000171:mdna:60]
[same as prior period, unchanged from 0000858877-25-000033:mdna:66]

[0000858877-25-000171:mdna:61]
[same as prior period, unchanged from 0000858877-25-000033:mdna:67]

[0000858877-25-000171:mdna:62]
[same as prior period, unchanged from 0000858877-25-000033:mdna:68]

[0000858877-25-000171:mdna:63]
|  |  | Three Months Ended |
|  |  | October 25,2025 |  | October 26,2024 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 11,077 |  |  | $ | 10,114 |  |  | $ | 963 |  |  | 10 | % |
| Percentage of revenue |  | 74.4 | % |  | 73.1 | % |  |  |  |  |
| Services |  | 3,806 |  |  | 3,727 |  |  | 79 |  |  | 2 | % |
| Percentage of revenue |  | 25.6 | % |  | 26.9 | % |  |  |  |  |
| Total |  | $ | 14,883 |  |  | $ | 13,841 |  |  | $ | 1,042 |  |  | 8 | % |

[0000858877-25-000171:mdna:64]
[same as prior period, unchanged from 0000858877-25-000033:mdna:70]

[0000858877-25-000171:mdna:65]
[same as prior period, unchanged from 0000858877-25-000033:mdna:71]

[0000858877-25-000171:mdna:66]
|  |  | Three Months Ended |  |  |
|  |  | October 25,2025 |  | October 26,2024 |  | Variancein Dollars |  | Variance in Percent |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 8,989 |  |  | $ | 8,252 |  |  | $ | 737 |  |  | 9 | % |  |  |  |  |  |  |  |  |
| Percentage of revenue |  | 60.4 | % |  | 59.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| EMEA |  | 3,784 |  |  | 3,588 |  |  | 196 |  |  | 5 | % |  |  |  |  |  |  |  |  |
| Percentage of revenue |  | 25.4 | % |  | 25.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| APJC |  | 2,111 |  |  | 2,001 |  |  | 110 |  |  | 5 | % |  |  |  |  |  |  |  |  |
| Percentage of revenue |  | 14.2 | % |  | 14.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 14,883 |  |  | $ | 13,841 |  |  | $ | 1,042 |  |  | 8 | % |  |  |  |  |  |  |  |  |

[0000858877-25-000171:mdna:67]
[same as prior period, unchanged from 0000858877-25-000033:mdna:73]

[0000858877-25-000171:mdna:68]
Three Months Ended October 25, 2025 Compared with Three Months Ended October 26, 2024

[0000858877-25-000171:mdna:69]
Total revenue increased by 8%. Product revenue increased by 10% and services revenue increased by 2%. Our total revenue reflected growth across each of our geographic segments.

[0000858877-25-000171:mdna:70]
[same as prior period, unchanged from 0000858877-25-000033:mdna:76]

[0000858877-25-000171:mdna:71]
[same as prior period, unchanged from 0000858877-25-000033:mdna:9]

[0000858877-25-000171:mdna:72]
[same as prior period, unchanged from 0000858877-25-000033:mdna:64]

[0000858877-25-000171:mdna:73]
[same as prior period, unchanged from 0000858877-25-000033:mdna:65]

[0000858877-25-000171:mdna:74]
[same as prior period, unchanged from 0000858877-25-000033:mdna:81]

[0000858877-25-000171:mdna:75]
[same as prior period, unchanged from 0000858877-25-000033:mdna:82]

[0000858877-25-000171:mdna:76]
|  |  | Three Months Ended |
|  |  | October 25,2025 |  | October 26,2024 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 6,706 |  |  | $ | 6,002 |  |  | $ | 704 |  |  | 12 | % |
| Percentage of product revenue |  | 60.5 | % |  | 59.3 | % |  |  |  |  |
| EMEA |  | 2,846 |  |  | 2,686 |  |  | 160 |  |  | 6 | % |
| Percentage of product revenue |  | 25.7 | % |  | 26.6 | % |  |  |  |  |
| APJC |  | 1,525 |  |  | 1,426 |  |  | 99 |  |  | 7 | % |
| Percentage of product revenue |  | 13.8 | % |  | 14.1 | % |  |  |  |  |
| Total |  | $ | 11,077 |  |  | $ | 10,114 |  |  | $ | 963 |  |  | 10 | % |

[0000858877-25-000171:mdna:77]
[same as prior period, unchanged from 0000858877-25-000033:mdna:84]

[0000858877-25-000171:mdna:78]
Three Months Ended October 25, 2025 Compared with Three Months Ended October 26, 2024

[0000858877-25-000171:mdna:79]
[same as prior period, unchanged from 0000858877-25-000033:mdna:85]

[0000858877-25-000171:mdna:80]
Product revenue in the Americas segment increased by 12%, with growth across each of our customer markets, led by the Service Provider and Cloud customer market which was largely driven by revenue from our AI Infrastructure solutions. From a country perspective, product revenue increased in the United States and Mexico by 13% and 25%, respectively, partially offset by declines in Brazil and Canada of 28% and 3%, respectively.

[0000858877-25-000171:mdna:81]
[same as prior period, unchanged from 0000858877-25-000033:mdna:90]

[0000858877-25-000171:mdna:82]
Product revenue in the EMEA segment increased by 6%, with growth across each of our customer markets. From a country perspective, product revenue increased in the Netherlands, United Kingdom and Saudi Arabia by 35%, 6% and 9%, respectively.

[0000858877-25-000171:mdna:83]
[same as prior period, unchanged from 0000858877-25-000033:mdna:95]

[0000858877-25-000171:mdna:84]
Product revenue in the APJC segment increased by 7%, with growth across each of our customer markets. From a country perspective, product revenue increased in Japan, Singapore and China by 12%, 50%, and 15%, respectively, partially offset by a decline in Australia of 11%.

[0000858877-25-000171:mdna:85]
41

[0000858877-25-000171:mdna:86]
[same as prior period, unchanged from 0000858877-25-000033:mdna:79]

[0000858877-25-000171:mdna:87]
[same as prior period, unchanged from 0000858877-25-000033:mdna:80]

[0000858877-25-000171:mdna:88]
[same as prior period, unchanged from 0000858877-25-000033:mdna:102]

[0000858877-25-000171:mdna:89]
[same as prior period, unchanged from 0000858877-25-000033:mdna:103]

[0000858877-25-000171:mdna:90]
[same as prior period, unchanged from 0000858877-25-000033:mdna:104]

[0000858877-25-000171:mdna:91]
|  |  | Three Months Ended |
|  |  | October 25,2025 |  | October 26,2024 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue |  |  |  |  |  |  |  |  |
| Networking |  | $ | 7,768 |  |  | $ | 6,753 |  |  | $ | 1,015 |  |  | 15 | % |
| Security |  | 1,980 |  |  | 2,017 |  |  | (37) |  |  | (2) | % |
| Collaboration |  | 1,055 |  |  | 1,085 |  |  | (30) |  |  | (3) | % |
| Observability |  | 274 |  |  | 258 |  |  | 16 |  |  | 6 | % |
| Total |  | $ | 11,077 |  |  | $ | 10,114 |  |  | $ | 963 |  |  | 10 | % |

[0000858877-25-000171:mdna:92]
[same as prior period, unchanged from 0000858877-25-000033:mdna:106]

[0000858877-25-000171:mdna:93]
Three Months Ended October 25, 2025 Compared with Three Months Ended October 26, 2024

[0000858877-25-000171:mdna:94]
[same as prior period, unchanged from 0000858877-25-000033:mdna:107]

[0000858877-25-000171:mdna:95]
The Networking product category consists of our core networking technologies of switching, routing, wireless, and servers. Revenue from the Networking product category increased by 15%, or $1.0 billion. The increase was primarily driven by double digit revenue growth in Service Provider Routing, particularly within our AI Infrastructure solutions, Data Center Switching, and Enterprise Routing. We also experienced revenue growth in Campus Switching.

[0000858877-25-000171:mdna:96]
[same as prior period, unchanged from 0000858877-25-000033:mdna:112]

[0000858877-25-000171:mdna:97]
The Security product category consists of our Network Security, Identity and Access Management, SASE and Threat Intelligence, Detection, and Response offerings. Revenue in our Security product category decreased by 2%, or $37 million. The decline was driven in part due to a change in how our customers consumed Splunk offerings, shifting from fewer on-premise deals to more cloud subscriptions. We also experienced a revenue decline in our prior generation products. These declines were partially offset by growth in Secure Firewall, Duo, and SASE offerings.

[0000858877-25-000171:mdna:98]
[same as prior period, unchanged from 0000858877-25-000033:mdna:117]

[0000858877-25-000171:mdna:99]
The Collaboration product category consists of our Webex Suite, Collaboration Devices, Contact Center and CPaaS offerings. Revenue in our Collaboration product category decreased by 3%, or $30 million, primarily driven by declines in our Devices and Webex Suite offerings.

[0000858877-25-000171:mdna:100]
[same as prior period, unchanged from 0000858877-25-000033:mdna:124]

[0000858877-25-000171:mdna:101]
The Observability product category consists of our network assurance, monitoring and analytics and observability suite offerings. Revenue in our Observability product category increased by 6%, or $16 million, primarily driven by growth in ThousandEyes.

[0000858877-25-000171:mdna:102]
[same as prior period, unchanged from 0000858877-25-000033:mdna:100]

[0000858877-25-000171:mdna:103]
[same as prior period, unchanged from 0000858877-25-000033:mdna:101]

[0000858877-25-000171:mdna:104]
[same as prior period, unchanged from 0000858877-25-000033:mdna:129]

[0000858877-25-000171:mdna:105]
[same as prior period, unchanged from 0000858877-25-000033:mdna:130]

[0000858877-25-000171:mdna:106]
|  |  | Three Months Ended |
|  |  | October 25,2025 |  | October 26,2024 |  | Variancein Dollars |  | Variance in Percent |
| Services revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,283 |  |  | $ | 2,249 |  |  | $ | 34 |  |  | 2 | % |
| Percentage of service revenue |  | 60.0 | % |  | 60.3 | % |  |  |  |  |
| EMEA |  | 938 |  |  | 903 |  |  | 35 |  |  | 4 | % |
| Percentage of service revenue |  | 24.6 | % |  | 24.2 | % |  |  |  |  |
| APJC |  | 586 |  |  | 575 |  |  | 11 |  |  | 2 | % |
| Percentage of service revenue |  | 15.4 | % |  | 15.5 | % |  |  |  |  |
| Total |  | $ | 3,806 |  |  | $ | 3,727 |  |  | $ | 79 |  |  | 2 | % |

[0000858877-25-000171:mdna:107]
[same as prior period, unchanged from 0000858877-25-000033:mdna:132]

[0000858877-25-000171:mdna:108]
Services revenue increased 2% in the first quarter of fiscal 2026 compared with the first quarter of fiscal 2025, with the growth driven by higher revenue from professional and support services. Services revenue increased across all of our geographic segments for the first quarter of fiscal 2026.

[0000858877-25-000171:mdna:109]
[same as prior period, unchanged from 0000858877-25-000033:mdna:135]

[0000858877-25-000171:mdna:110]
[same as prior period, unchanged from 0000858877-25-000033:mdna:136]

[0000858877-25-000171:mdna:111]
|  |  | Three Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |
|  |  | October 25,2025 |  | October 26,2024 |  | October 25,2025 |  | October 26,2024 |
| Gross margin: |  |  |  |  |  |  |  |  |
| Product |  | $ | 7,143 |  |  | $ | 6,588 |  |  | 64.5 | % |  | 65.1 | % |
| Services |  | 2,602 |  |  | 2,533 |  |  | 68.4 | % |  | 68.0 | % |
| Total |  | $ | 9,745 |  |  | $ | 9,121 |  |  | 65.5 | % |  | 65.9 | % |

[0000858877-25-000171:mdna:112]
[same as prior period, unchanged from 0000858877-25-000033:mdna:140]

[0000858877-25-000171:mdna:113]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the first quarter of fiscal 2026, as compared with the corresponding prior year period:

[0000858877-25-000171:mdna:114]
|  |  | Product Gross Margin Percentage |
| Fiscal 2025 |  | 65.1 | % |
| Productivity (1) |  | 1.7 | % |
| Product pricing |  | (1.1) | % |
| Mix of products sold |  | (2.2) | % |
| Amortization of purchased intangible assets |  | 1.1 | % |
| Others |  | (0.1) | % |
| Fiscal 2026 |  | 64.5 | % |

[0000858877-25-000171:mdna:115]
(1) Productivity includes overall manufacturing-related costs, such as component costs, warranty expense, provisions for inventory and the liability related to the purchase commitments with contract manufacturers and suppliers, freight, logistics, shipment volume, and other items not categorized elsewhere.

[0000858877-25-000171:mdna:116]
[same as prior period, unchanged from 0000858877-25-000033:mdna:122]

[0000858877-25-000171:mdna:117]
[same as prior period, unchanged from 0000858877-25-000033:mdna:123]

[0000858877-25-000171:mdna:118]
Three Months Ended October 25, 2025 Compared with Three Months Ended October 26, 2024

[0000858877-25-000171:mdna:119]
Product gross margin decreased by 0.6 percentage points primarily driven by negative impacts from product mix and pricing, partially offset by productivity improvements and lower amortization of purchased intangible assets.

[0000858877-25-000171:mdna:120]
[same as prior period, unchanged from 0000858877-25-000033:mdna:148]

[0000858877-25-000171:mdna:121]
We regularly enter into purchase commitments with contract manufacturers and suppliers and in recent periods have increased such commitments related to manufacturing Cisco Silicon One and other products to meet demand from hyperscalers and other customers. We expect to continue entering into these additional purchase commitments in fiscal 2026. These purchase commitments have in turn significantly increased our supply chain exposure. This exposure includes potential material excess and obsolete or other charges if product demand significantly decreases for a sustained duration, we are unable to generate demand for certain products, or we are otherwise unable to mitigate this exposure. Additionally, while we are exposed to new and proposed tariffs and other trade policies, the extent of such exposure is uncertain but could be significant if the exposure remains and we are unable to mitigate it.

[0000858877-25-000171:mdna:122]
[same as prior period, unchanged from 0000858877-25-000033:mdna:150]

[0000858877-25-000171:mdna:123]
Three Months Ended October 25, 2025 Compared with Three Months Ended October 26, 2024

[0000858877-25-000171:mdna:124]
Our services gross margin percentage increased by 0.4 percentage points primarily due to cost efficiencies.

[0000858877-25-000171:mdna:125]
[same as prior period, unchanged from 0000858877-25-000033:mdna:153]

[0000858877-25-000171:mdna:126]
[same as prior period, unchanged from 0000858877-25-000033:mdna:159]

[0000858877-25-000171:mdna:127]
[same as prior period, unchanged from 0000858877-25-000033:mdna:160]

[0000858877-25-000171:mdna:128]
|  | Three Months Ended |
|  | AMOUNT |  | PERCENTAGE |
|  | October 25,2025 |  | October 26,2024 |  | October 25,2025 |  | October 26,2024 |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 6,001 |  |  | $ | 5,740 |  |  | 66.8 | % |  | 69.6 | % |
| EMEA | 2,722 |  |  | 2,522 |  |  | 71.9 | % |  | 70.3 | % |
| APJC | 1,413 |  |  | 1,328 |  |  | 66.9 | % |  | 66.4 | % |
| Segment total | 10,136 |  |  | 9,590 |  |  | 68.1 | % |  | 69.3 | % |
| Unallocated corporate items (1) | (391) |  |  | (469) |  |  |  |  |  |
| Total | $ | 9,745 |  |  | $ | 9,121 |  |  | 65.5 | % |  | 65.9 | % |

[0000858877-25-000171:mdna:129]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-25-000171:mdna:130]
[same as prior period, unchanged from 0000858877-25-000033:mdna:163]

[0000858877-25-000171:mdna:131]
Three Months Ended October 25, 2025 Compared with Three Months Ended October 26, 2024

[0000858877-25-000171:mdna:132]
We experienced a gross margin percentage decrease in our Americas segment due to negative impacts from product mix and pricing, partially offset by positive impacts from productivity improvements.

[0000858877-25-000171:mdna:133]
Gross margin percentage in our EMEA segment increased primarily due to productivity improvements, partially offset by negative impacts from pricing and product mix.

[0000858877-25-000171:mdna:134]
The increase in the APJC segment gross margin percentage was primarily due to productivity improvements, partially offset by negative impacts from pricing and product mix.

[0000858877-25-000171:mdna:135]
[same as prior period, unchanged from 0000858877-25-000033:mdna:138]

[0000858877-25-000171:mdna:136]
[same as prior period, unchanged from 0000858877-25-000033:mdna:139]

[0000858877-25-000171:mdna:137]
[same as prior period, unchanged from 0000858877-25-000033:mdna:172]

[0000858877-25-000171:mdna:138]
[same as prior period, unchanged from 0000858877-25-000033:mdna:173]

[0000858877-25-000171:mdna:139]
|  | Three Months Ended |
|  | October 25,2025 |  | October 26,2024 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 2,400 |  |  | $ | 2,286 |  |  | $ | 114 |  |  | 5 | % |
| Percentage of revenue | 16.1 | % |  | 16.5 | % |  |  |  |  |
| Sales and marketing | 2,871 |  |  | 2,752 |  |  | 119 |  |  | 4 | % |
| Percentage of revenue | 19.3 | % |  | 19.9 | % |  |  |  |  |
| General and administrative | 733 |  |  | 795 |  |  | (62) |  |  | (8) | % |
| Percentage of revenue | 4.9 | % |  | 5.7 | % |  |  |  |  |
| Total | $ | 6,004 |  |  | $ | 5,833 |  |  | $ | 171 |  |  | 3 | % |
| Percentage of revenue | 40.3 | % |  | 42.1 | % |  |  |  |  |

[0000858877-25-000171:mdna:140]
Three Months Ended October 25, 2025 Compared with Three Months Ended October 26, 2024

[0000858877-25-000171:mdna:141]
[same as prior period, unchanged from 0000858877-25-000033:mdna:177]

[0000858877-25-000171:mdna:142]
R&D expenses increased primarily due to higher headcount-related expenses reflecting our investments in AI and higher share-based compensation expense, partially offset by lower acquisition-related costs.

[0000858877-25-000171:mdna:143]
[same as prior period, unchanged from 0000858877-25-000033:mdna:183]

[0000858877-25-000171:mdna:144]
Sales and marketing expenses increased primarily due to higher share-based compensation expense, higher contracted services spending, higher headcount-related expenses, and higher discretionary spending.

[0000858877-25-000171:mdna:145]
[same as prior period, unchanged from 0000858877-25-000033:mdna:188]

[0000858877-25-000171:mdna:146]
G&A expenses decreased primarily due to lower acquisition-related costs and lower headcount-related expenses.

[0000858877-25-000171:mdna:147]
[same as prior period, unchanged from 0000858877-25-000033:mdna:193]

[0000858877-25-000171:mdna:148]
In the first quarter of fiscal 2026, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $36 million, or 0.6%, compared with the first quarter of fiscal 2025.

[0000858877-25-000171:mdna:149]
[same as prior period, unchanged from 0000858877-25-000033:mdna:196]

[0000858877-25-000171:mdna:150]
[same as prior period, unchanged from 0000858877-25-000033:mdna:197]

[0000858877-25-000171:mdna:151]
|  |  | Three Months Ended |
|  |  | October 25,2025 |  | October 26,2024 |
| Amortization of purchased intangible assets: |  |  |  |  |
| Cost of sales |  | $ | 240 |  |  | $ | 325 |  |
| Operating expenses |  | 231 |  |  | 265 |  |
| Total |  | $ | 471 |  |  | $ | 590 |  |

[0000858877-25-000171:mdna:152]
For the first quarter of fiscal 2026, the decrease in amortization of purchased intangible assets was primarily due to certain purchased intangible assets that became fully amortized.

[0000858877-25-000171:mdna:153]
[same as prior period, unchanged from 0000858877-25-000033:mdna:205]

[0000858877-25-000171:mdna:154]
In the first quarter of fiscal 2025, we announced a restructuring plan in order to allow us to invest in key growth opportunities and drive more efficiencies in our business. This restructuring plan is expected to impact approximately 7% of our global workforce with estimated pre-tax charges of approximately $1 billion. In connection with this restructuring plan, we incurred charges of $147 million in the first quarter of fiscal 2026. We expect this plan to be completed by the end of the second quarter of fiscal 2026.

[0000858877-25-000171:mdna:155]
[same as prior period, unchanged from 0000858877-25-000033:mdna:157]

[0000858877-25-000171:mdna:156]
[same as prior period, unchanged from 0000858877-25-000033:mdna:158]

[0000858877-25-000171:mdna:157]
[same as prior period, unchanged from 0000858877-25-000033:mdna:208]

[0000858877-25-000171:mdna:158]
[same as prior period, unchanged from 0000858877-25-000033:mdna:209]

[0000858877-25-000171:mdna:159]
|  |  | Three Months Ended |
|  |  | October 25,2025 |  | October 26,2024 |
| Operating income |  | $ | 3,363 |  |  | $ | 2,358 |  |
| Operating income as a percentage of revenue |  | 22.6 | % |  | 17.0 | % |

[0000858877-25-000171:mdna:160]
Three Months Ended October 25, 2025 Compared with Three Months Ended October 26, 2024

[0000858877-25-000171:mdna:161]
Operating income increased by 43%, and operating income as a percentage of revenue increased by 5.6 percentage points. These changes primarily resulted from lower restructuring and other charges and revenue growth in the first quarter of fiscal 2026.

[0000858877-25-000171:mdna:162]
[same as prior period, unchanged from 0000858877-25-000033:mdna:218]

[0000858877-25-000171:mdna:163]
[same as prior period, unchanged from 0000858877-25-000033:mdna:219]

[0000858877-25-000171:mdna:164]
|  |  | Three Months Ended |
|  |  | October 25,2025 |  | October 26,2024 |  | Variancein Dollars |
| Interest income |  | $ | 222 |  |  | $ | 286 |  |  | $ | (64) |  |
| Interest expense |  | (350) |  |  | (418) |  |  | 68 |  |
| Interest income (expense), net |  | $ | (128) |  |  | $ | (132) |  |  | $ | 4 |  |

[0000858877-25-000171:mdna:165]
Three Months Ended October 25, 2025 Compared with Three Months Ended October 26, 2024

[0000858877-25-000171:mdna:166]
The decrease in interest income was driven by a lower average balance of cash and available-for-sale debt investments and lower interest rates. The decrease in interest expense was driven by a lower average balance of debt outstanding and lower effective interest rate on commercial paper during the period.

[0000858877-25-000171:mdna:167]
[same as prior period, unchanged from 0000858877-25-000033:mdna:225]

[0000858877-25-000171:mdna:168]
|  |  | Three Months Ended |
|  |  | October 25,2025 |  | October 26,2024 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | (4) |  |  | $ | (25) |  |  | $ | 21 |  |
| Marketable equity investments |  | 31 |  |  | 24 |  |  | 7 |  |
| Privately held investments |  | 163 |  |  | 74 |  |  | 89 |  |
| Net gains (losses) on investments |  | 190 |  |  | 73 |  |  | 117 |  |
| Other gains (losses), net |  | (34) |  |  | (32) |  |  | (2) |  |
| Other income (loss), net |  | $ | 156 |  |  | $ | 41 |  |  | $ | 115 |  |

[0000858877-25-000171:mdna:169]
Three Months Ended October 25, 2025 Compared with Three Months Ended October 26, 2024

[0000858877-25-000171:mdna:170]
The change in our other income (loss), net was primarily driven by higher unrealized gains on privately held investments.

[0000858877-25-000171:mdna:171]
Provision for (Benefit from) Income Taxes

[0000858877-25-000171:mdna:172]
Three Months Ended October 25, 2025 Compared with Three Months Ended October 26, 2024

[0000858877-25-000171:mdna:173]
The provision for (benefit from) income taxes resulted in an effective tax rate of 15.7% for the first quarter of fiscal 2026, compared with an effective tax rate of (19.6)% for the first quarter of fiscal 2025. The increase in the effective tax rate was primarily due to a $720 million tax benefit related to the U.S. Tax Court opinion issued during the first quarter of fiscal 2025 regarding the U.S. taxation of deemed foreign dividends in the transition year of the Tax Cut and Job Act (“Tax Act”) (our fiscal 2018).

[0000858877-25-000171:mdna:174]
46

[0000858877-25-000171:mdna:175]
[same as prior period, unchanged from 0000858877-25-000033:mdna:175]

[0000858877-25-000171:mdna:176]
[same as prior period, unchanged from 0000858877-25-000033:mdna:176]

[0000858877-25-000171:mdna:177]
[same as prior period, unchanged from 0000858877-25-000033:mdna:239]

[0000858877-25-000171:mdna:178]
[same as prior period, unchanged from 0000858877-25-000033:mdna:240]

[0000858877-25-000171:mdna:179]
[same as prior period, unchanged from 0000858877-25-000033:mdna:241]

[0000858877-25-000171:mdna:180]
[same as prior period, unchanged from 0000858877-25-000033:mdna:242]

[0000858877-25-000171:mdna:181]
|  | October 25,2025 |  | July 26,2025 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 8,400 |  |  | $ | 8,346 |  |  | $ | 54 |  |
| Available-for-sale debt investments | 6,942 |  |  | 7,381 |  |  | (439) |  |
| Marketable equity securities | 394 |  |  | 383 |  |  | 11 |  |
| Total | $ | 15,736 |  |  | $ | 16,110 |  |  | $ | (374) |  |

[0000858877-25-000171:mdna:182]
The net decrease in cash and cash equivalents and investments in the first quarter of fiscal 2026 was primarily driven by cash returned to stockholders in the form of cash dividends of $1.6 billion and repurchases of common stock of $2.0 billion, and capital expenditures of $0.3 billion. These uses of cash were partially offset by net cash provided by operating activities of $3.2 billion and the release to us of approximately $0.6 billion of restricted cash previously held in escrow.

[0000858877-25-000171:mdna:183]
[same as prior period, unchanged from 0000858877-25-000033:mdna:245]

[0000858877-25-000171:mdna:184]
Securities Lending   We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 25, 2025 and July 26, 2025, we had no outstanding securities lending transactions.

[0000858877-25-000171:mdna:185]
[same as prior period, unchanged from 0000858877-25-000033:mdna:247]

[0000858877-25-000171:mdna:186]
[same as prior period, unchanged from 0000858877-25-000033:mdna:248]

[0000858877-25-000171:mdna:187]
|  | Three Months Ended |
|  | October 25,2025 |  | October 26,2024 |
| Net cash provided by operating activities | $ | 3,212 |  |  | $ | 3,661 |  |
| Acquisition of property and equipment | (323) |  |  | (217) |  |
| Free cash flow | $ | 2,889 |  |  | $ | 3,444 |  |

[0000858877-25-000171:mdna:188]
[same as prior period, unchanged from 0000858877-25-000033:mdna:250]

[0000858877-25-000171:mdna:189]
[same as prior period, unchanged from 0000858877-25-000033:mdna:201]

[0000858877-25-000171:mdna:190]
[same as prior period, unchanged from 0000858877-25-000033:mdna:202]

[0000858877-25-000171:mdna:191]
[same as prior period, unchanged from 0000858877-25-000033:mdna:253]

[0000858877-25-000171:mdna:192]
[same as prior period, unchanged from 0000858877-25-000033:mdna:254]

[0000858877-25-000171:mdna:193]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2026 |  |  |  |  |  |  |  |  |  |  |  |  |
| October 25, 2025 |  | $ | 0.41 |  |  | $ | 1,617 |  |  | 29 |  |  | $ | 68.28 |  |  | $ | 2,001 |  |  | $ | 3,618 |  |
| Fiscal 2025 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 26, 2025 |  | $ | 0.41 |  |  | $ | 1,625 |  |  | 19 |  |  | $ | 64.65 |  |  | $ | 1,252 |  |  | $ | 2,877 |  |
| April 26, 2025 |  | $ | 0.41 |  |  | $ | 1,627 |  |  | 25 |  |  | $ | 59.78 |  |  | $ | 1,504 |  |  | $ | 3,131 |  |
| January 25, 2025 |  | $ | 0.40 |  |  | $ | 1,593 |  |  | 21 |  |  | $ | 58.58 |  |  | $ | 1,236 |  |  | $ | 2,829 |  |
| October 26, 2024 |  | $ | 0.40 |  |  | $ | 1,592 |  |  | 40 |  |  | $ | 49.56 |  |  | $ | 2,003 |  |  | $ | 3,595 |  |

[0000858877-25-000171:mdna:194]
On November 12, 2025, our Board of Directors declared a quarterly dividend of $0.41 per common share to be paid on January 21, 2026, to all stockholders of record as of the close of business on January 2, 2026. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-25-000171:mdna:195]
The remaining authorized amount for stock repurchases under this program is approximately $12.2 billion, with no termination date.

[0000858877-25-000171:mdna:196]
[same as prior period, unchanged from 0000858877-25-000033:mdna:258]

[0000858877-25-000171:mdna:197]
|  | October 25,2025 |  | July 26,2025 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,827 |  |  | $ | 6,701 |  |  | $ | (1,874) |  |

[0000858877-25-000171:mdna:198]
Our accounts receivable net, as of October 25, 2025 decreased by approximately 28%, as compared with the end of fiscal 2025, primarily due to timing and amount of product and service billings in the first quarter of fiscal 2026 compared with the fourth quarter of fiscal 2025.

[0000858877-25-000171:mdna:199]
[same as prior period, unchanged from 0000858877-25-000033:mdna:216]

[0000858877-25-000171:mdna:200]
[same as prior period, unchanged from 0000858877-25-000033:mdna:217]

[0000858877-25-000171:mdna:201]
Inventory Supply Chain  The following table summarizes our inventories and balances with contract manufacturers and suppliers (in millions):

[0000858877-25-000171:mdna:202]
|  | October 25,2025 |  | July 26,2025 |  | Variance vs. July 26, 2025 |
| Inventories | $ | 3,395 |  |  | $ | 3,164 |  |  | $ | 231 |  |
| Inventory purchase commitments | $ | 8,321 |  |  | $ | 7,599 |  |  | $ | 722 |  |
| Inventory deposits and prepayments | $ | 1,023 |  |  | $ | 825 |  |  | $ | 198 |  |

[0000858877-25-000171:mdna:203]
[same as prior period, unchanged from 0000858877-25-000033:mdna:265]

[0000858877-25-000171:mdna:204]
|  | October 25,2025 |  | July 26,2025 |  | Variance vs. July 26, 2025 |
| Less than 1 year | $ | 7,879 |  |  | $ | 7,202 |  |  | $ | 677 |  |
| 1 to 3 years | 396 |  |  | 320 |  |  | 76 |  |
| 3 to 5 years | 46 |  |  | 77 |  |  | (31) |  |
| Total | $ | 8,321 |  |  | $ | 7,599 |  |  | $ | 722 |  |

[0000858877-25-000171:mdna:205]
Inventory as of October 25, 2025 increased by 7% and inventory purchase commitments with contract manufacturers and suppliers increased by 10% from our balances at the end of fiscal 2025. The combined increase of 9% in our inventory and inventory purchase commitments as compared with the end of fiscal 2025 was primarily related to commitments with contract manufacturers and suppliers related to manufacturing Cisco Silicon One and other products to meet the demand from hyperscalers and other customers. We expect our inventory balances may increase in future quarters as we work to fulfill this demand.

[0000858877-25-000171:mdna:206]
In recent periods, we have increased our levels of inventory and purchase commitments with contract manufacturers and suppliers primarily related to Cisco Silicon One. The increases were primarily due to arrangements to secure supply and pricing for certain product components and commitments with contract manufacturers to meet customer demand and help manage lead times. Our risks of future material excess and obsolete inventory and related losses are further outlined in the Result of Operations—Product Gross Margin section.

[0000858877-25-000171:mdna:207]
[same as prior period, unchanged from 0000858877-25-000033:mdna:268]

[0000858877-25-000171:mdna:208]
[same as prior period, unchanged from 0000858877-25-000033:mdna:269]

[0000858877-25-000171:mdna:209]
[same as prior period, unchanged from 0000858877-25-000033:mdna:270]

[0000858877-25-000171:mdna:210]
[same as prior period, unchanged from 0000858877-25-000033:mdna:271]

[0000858877-25-000171:mdna:211]
|  | October 25,2025 |  | July 26,2025 |  | Increase (Decrease) |
| Loan receivables, net | $ | 5,789 |  |  | $ | 5,591 |  |  | $ | 198 |  |
| Lease receivables, net | 1,015 |  |  | 936 |  |  | 79 |  |
| Total, net | $ | 6,804 |  |  | $ | 6,527 |  |  | $ | 277 |  |

[0000858877-25-000171:mdna:212]
[same as prior period, unchanged from 0000858877-25-000033:mdna:237]

[0000858877-25-000171:mdna:213]
[same as prior period, unchanged from 0000858877-25-000033:mdna:238]

[0000858877-25-000171:mdna:214]
Financing Receivables  Our financing arrangements include loans and leases. Our loan receivables include customer financing for purchases of our hardware, software and services (including technical support and advanced services), and also may include additional funds for other costs associated with network installation and integration of our products and services. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Financing receivables increased by 4% as compared with the end of fiscal 2025.

[0000858877-25-000171:mdna:215]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, with payment terms generally ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-25-000171:mdna:216]
The volume of channel partner financing was $6.7 billion and $6.0 billion for the first quarter of fiscal 2026 and 2025, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.5 billion and $1.3 billion as of October 25, 2025 and July 26, 2025, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of October 25, 2025, the total maximum potential future payments related to these guarantees was approximately $134 million, of which approximately $17 million was recorded as deferred revenue.

[0000858877-25-000171:mdna:217]
[same as prior period, unchanged from 0000858877-25-000033:mdna:280]

[0000858877-25-000171:mdna:218]
[same as prior period, unchanged from 0000858877-25-000033:mdna:281]

[0000858877-25-000171:mdna:219]
|  | Maturity Date |  | October 25,2025 |  | July 26,2025 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 4.90% | February 26, 2026 |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 2,000 |  |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | 1,000 |  |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 2,500 |  |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | 1,000 |  |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 2,500 |  |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | 1,000 |  |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 2,500 |  |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | 1,250 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | February 24, 2055 |  | 750 |  |  | 750 |  |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 1,000 |  |
| Total |  |  | $ | 24,750 |  |  | $ | 24,750 |  |

[0000858877-25-000171:mdna:220]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of October 25, 2025.

[0000858877-25-000171:mdna:221]
[same as prior period, unchanged from 0000858877-25-000033:mdna:251]

[0000858877-25-000171:mdna:222]
[same as prior period, unchanged from 0000858877-25-000033:mdna:252]

[0000858877-25-000171:mdna:223]
Commercial Paper  We have a short-term debt financing program in which up to $15.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had $3.5 billion in commercial paper notes outstanding as of each of October 25, 2025 and July 26, 2025.

[0000858877-25-000171:mdna:224]
Credit Facility  On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of October 25, 2025, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.

[0000858877-25-000171:mdna:225]
[same as prior period, unchanged from 0000858877-25-000033:mdna:289]

[0000858877-25-000171:mdna:226]
|  | October 25,2025 |  | July 26,2025 |  | Increase (Decrease) |
| Product | $ | 21,904 |  |  | $ | 21,572 |  |  | $ | 332 |  |
| Services | 20,969 |  |  | 21,961 |  |  | (992) |  |
| Total | $ | 42,873 |  |  | $ | 43,533 |  |  | $ | (660) |  |
| Short-term RPO | $ | 20,971 |  |  | $ | 21,723 |  |  | $ | (752) |  |
| Long-term RPO | 21,902 |  |  | 21,810 |  |  | 92 |  |
| Total | $ | 42,873 |  |  | $ | 43,533 |  |  | $ | (660) |  |

[0000858877-25-000171:mdna:227]
Total remaining performance obligations as of October 25, 2025 decreased 2% compared to the end of fiscal 2025. Remaining performance obligations for product increased by 2% compared to the end of fiscal 2025, of which long-term product RPO was $11.8 billion, up 3%. Remaining performance obligations for services decreased 5%.

[0000858877-25-000171:mdna:228]
[same as prior period, unchanged from 0000858877-25-000033:mdna:292]

[0000858877-25-000171:mdna:229]
|  | October 25,2025 |  | July 26,2025 |  | Increase (Decrease) |
| Product | $ | 13,252 |  |  | $ | 13,490 |  |  | $ | (238) |  |
| Services | 14,717 |  |  | 15,289 |  |  | (572) |  |
| Total | $ | 27,969 |  |  | $ | 28,779 |  |  | $ | (810) |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 15,801 |  |  | $ | 16,416 |  |  | $ | (615) |  |
| Noncurrent | 12,168 |  |  | 12,363 |  |  | (195) |  |
| Total | $ | 27,969 |  |  | $ | 28,779 |  |  | $ | (810) |  |

[0000858877-25-000171:mdna:230]
Total deferred revenue decreased 3% compared to the end of fiscal 2025. Within total deferred revenue, deferred product revenue decreased by 2% and deferred services revenue decreased by 4%. The decrease in deferred services revenue was driven by lower business volume and ongoing amortization of deferred services revenue.

[0000858877-25-000171:mdna:231]
[same as prior period, unchanged from 0000858877-25-000033:mdna:261]

[0000858877-25-000171:mdna:232]
[same as prior period, unchanged from 0000858877-25-000033:mdna:262]

[0000858877-25-000171:mdna:233]
[same as prior period, unchanged from 0000858877-25-000033:mdna:295]

[0000858877-25-000171:mdna:234]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed herein. In addition, we plan for and measure our liquidity and capital resources through an annual budgeting process. Our contractual obligations consist of operating leases, purchase commitments with contract manufacturers and suppliers, other purchase obligations, long-term debt, the transition tax payable, and other long-term liabilities. For additional information on our contractual obligations see our Annual Report on Form 10-K for the fiscal year ended July 26, 2025.

[0000858877-25-000171:mdna:235]
Transition Tax Payable

[0000858877-25-000171:mdna:236]
The income tax payable outstanding as of October 25, 2025 for the U.S. transition tax on accumulated earnings for foreign subsidiaries was $2.3 billion and is payable in the second quarter of fiscal 2026.

[0000858877-25-000171:mdna:237]
[same as prior period, unchanged from 0000858877-25-000033:mdna:297]

[0000858877-25-000171:mdna:238]
[same as prior period, unchanged from 0000858877-25-000033:mdna:298]

[0000858877-25-000171:mdna:239]
Of the total carrying value of our investments in privately held companies as of October 25, 2025, $0.8 billion of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $0.5 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments. See Note 10 to the Consolidated Financial Statements.

[0000858877-25-000171:mdna:240]
[same as prior period, unchanged from 0000858877-25-000033:mdna:304]

[0000858877-25-000171:mdna:241]
[same as prior period, unchanged from 0000858877-25-000033:mdna:305]

[0000858877-25-000171:mdna:242]
[same as prior period, unchanged from 0000858877-25-000033:mdna:306]
