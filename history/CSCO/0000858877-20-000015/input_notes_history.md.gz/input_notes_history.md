# CSCO note change history — 0000858877-20-000006 → 0000858877-20-000015


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-11-17):
[0000858877-20-000015:note_history:1]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers
  (was, 2020-05-18, similarity 0.7904):
[0000858877-20-000006:note_history:1]
| (a) | Purchase Commitments with Contract Manufacturers and Suppliers |

- changed (2020-11-17):
[0000858877-20-000015:note_history:2]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of October 24, 2020 and July 25, 2020, we had total purchase commitments for inventory of $4.2 billion and $4.4 billion, respectively.
  (was, 2020-05-18, similarity 0.9946):
[0000858877-20-000006:note_history:2]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of April 25, 2020 and July 27, 2019, we had total purchase commitments for inventory of $5.1 billion and $5.0 billion, respectively.

- changed (2020-11-17):
[0000858877-20-000015:note_history:3]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 24, 2020 and July 25, 2020, the liability for these purchase commitments was $157 million and $141 million, respectively, and was included in other current liabilities. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $32 million and $29 million for the first quarter of fiscal 2021 and 2020, respectively.
  (was, 2020-05-18, similarity 0.7856):
[0000858877-20-000006:note_history:3]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 25, 2020 and July 27, 2019, the liability for these purchase commitments was $131 million and $129 million, respectively, and was included in other current liabilities.

- changed (2020-11-17):
[0000858877-20-000015:note_history:4]
(b)Other Commitments
  (was, 2020-05-18, similarity 0.8511):
[0000858877-20-000006:note_history:4]
| (b) | Other Commitments |

- changed (2020-11-17):
[0000858877-20-000015:note_history:5]
|  | Three Months Ended |
|  | October 24, 2020 |  | October 26, 2019 |
| Compensation expense related to acquisitions | $ | 57 |  |  | $ | 61 |  |
  (was, 2020-05-18, similarity 0.7134):
[0000858877-20-000006:note_history:5]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Compensation expense related to acquisitions | $ | 61 |  |  | $ | 76 |  |  | $ | 172 |  |  | $ | 251 |  |

- changed (2020-11-17):
[0000858877-20-000015:note_history:6]
As of October 24, 2020, we estimated that future cash compensation expense of up to $495 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2020-05-18, similarity 0.9722):
[0000858877-20-000006:note_history:6]
As of April 25, 2020, we estimated that future cash compensation expense of up to $292 million may be required to be recognized pursuant to the applicable business combination agreements.

- changed (2020-11-17):
[0000858877-20-000015:note_history:7]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.3 billion as of each of October 24, 2020 and July 25, 2020.
  (was, 2020-05-18, similarity 0.8842):
[0000858877-20-000006:note_history:7]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $344 million and $326 million as of April 25, 2020 and July 27, 2019, respectively.

- changed (2020-11-17):
[0000858877-20-000015:note_history:8]
(c)Product Warranties
  (was, 2020-05-18, similarity 0.8571):
[0000858877-20-000006:note_history:8]
| (c) | Product Warranties |

- changed (2020-11-17):
[0000858877-20-000015:note_history:9]
|  | Three Months Ended |
|  | October 24,2020 |  | October 26,2019 |
| Balance at beginning of period | $ | 331 |  |  | $ | 342 |  |
| Provisions for warranties issued | 121 |  |  | 140 |  |
| Adjustments for pre-existing warranties | 1 |  |  | (3) |  |
| Settlements | (122) |  |  | (149) |  |
| Balance at end of period | $ | 331 |  |  | $ | 330 |  |
  (was, 2020-05-18, similarity 0.7075):
[0000858877-20-000006:note_history:9]
|  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |
| Balance at beginning of period | $ | 342 |  |  | $ | 359 |  |
| Provisions for warranties issued | 423 |  |  | 447 |  |
| Adjustments for pre-existing warranties | (5 | ) |  | (6 | ) |
| Settlements | (436 | ) |  | (449 | ) |
| Acquisitions and divestitures | — |  |  | (2 | ) |
| Balance at end of period | $ | 324 |  |  | $ | 349 |  |

- changed (2020-11-17):
[0000858877-20-000015:note_history:10]
(d)Financing and Other Guarantees
  (was, 2020-05-18, similarity 0.9041):
[0000858877-20-000006:note_history:10]
| (d) | Financing and Other Guarantees |

- added (2020-11-17):
[0000858877-20-000015:note_history:11]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. During fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.1 billion and $7.6 billion for the first quarter of fiscal 2021 and 2020, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.1 billion as of October 24, 2020 and July 25, 2020, respectively.

- changed (2020-11-17):
[0000858877-20-000015:note_history:12]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $5 million for each of the first quarters of fiscal 2021 and 2020.
  (was, 2020-05-18, similarity 0.7838):
[0000858877-20-000006:note_history:12]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $2 million and $1 million for the third quarter of fiscal 2020 and 2019, respectively, and was $8 million and $11 million for the first nine months of fiscal 2020 and 2019, respectively.

- changed (2020-11-17):
[0000858877-20-000015:note_history:13]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 24, 2020 and July 25, 2020, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2020-05-18, similarity 0.9807):
[0000858877-20-000006:note_history:13]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 25, 2020 and July 27, 2019, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2020-11-17):
[0000858877-20-000015:note_history:14]
|  | October 24,2020 |  | July 25,2020 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 193 |  |  | $ | 198 |  |
| End user | 8 |  |  | 9 |  |
| Total | $ | 201 |  |  | $ | 207 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (25) |  |  | $ | (19) |  |
| End user | (8) |  |  | (9) |  |
| Total | $ | (33) |  |  | $ | (28) |  |
| Total | $ | 168 |  |  | $ | 179 |  |
  (was, 2020-05-18, similarity 0.785):
[0000858877-20-000006:note_history:14]
|  | April 25, 2020 |  | July 27, 2019 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 203 |  |  | $ | 197 |  |
| End user | 12 |  |  | 21 |  |
| Total | $ | 215 |  |  | $ | 218 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (59 | ) |  | $ | (62 | ) |
| End user | (11 | ) |  | (15 | ) |
| Total | $ | (70 | ) |  | $ | (77 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 145 |  |  | $ | 141 |  |

- changed (2020-11-17):
[0000858877-20-000015:note_history:15]
(e)Indemnifications
  (was, 2020-05-18, similarity 0.8444):
[0000858877-20-000006:note_history:15]
| (e) | Indemnifications |

- changed (2020-11-17):
[0000858877-20-000015:note_history:16]
We also have been asked to indemnify certain of our service provider customers that have been subject to patent infringement claims asserted by Chanbond, LLC (“Chanbond”) in the United States District Court for the District of Delaware on September 21, 2015. Chanbond alleges that 13 service provider companies, including among others, Comcast Corporation, Charter Communications, Inc. (“Charter”), Time Warner Cable, Inc. (subsequently acquired by Charter), Cox Communications, Inc. (“Cox”), and Cablevision Systems Corporation, infringe three patents by providing high speed cable internet services to their customers utilizing cable modems and cable modem termination systems, consistent with the DOCSIS 3.0 standard, provided by us and other manufacturers generally used in combination with each other. Chanbond seeks monetary damages. On October
  (was, 2020-05-18, similarity 0.6895):
[0000858877-20-000006:note_history:16]
We also have been asked to indemnify certain of our service provider customers that have been subject to patent infringement claims asserted by Chanbond, LLC (“Chanbond”) in the United States District Court for the District of Delaware on September 21, 2015. Chanbond alleges that 13 service provider companies, including among others, Comcast Corporation (“Comcast”), Charter Communications, Inc. (“Charter”), Time Warner Cable, Inc. (“TWC”) (subsequently acquired by Charter), Cox Communications, Inc. (“Cox”), and Cablevision Systems Corporation (“Cablevision”), infringe three patents by providing high speed cable internet services to their customers utilizing cable modems and cable modem termination systems, consistent with the DOCSIS 3.0 standard, provided by us and other manufacturers generally used in combination with each other. Chanbond seeks monetary damages. Chanbond's case against Cox is currently set for a jury trial starting on August 18, 2020, and the other cases against the remaining service provider defendants have not yet been set for trial. We believe that the service provider defendants have strong non-infringement, invalidity and other defenses. Due to uncertainties surrounding the litigation processes, we are unable to reasonably estimate the ultimate outcome of the cases at this time, but should Chanbond prevail in its cases against the service provider defendants, we do not believe that any potential indemnity liability would be material.

- added (2020-11-17):
[0000858877-20-000015:note_history:17]
13, 2020, the Court set Chanbond’s case against Cox for trial on May 17, 2021. The other cases against the remaining service provider defendants have not yet been set for trial. We believe that the service provider defendants have strong non-infringement, invalidity and other defenses. Due to uncertainties surrounding the litigation processes, we are unable to reasonably estimate the ultimate outcome of the cases at this time, but should Chanbond prevail in its cases against the service provider defendants, we do not believe that any potential indemnity liability would be material.

- changed (2020-11-17):
[0000858877-20-000015:note_history:18]
It is not possible to determine the maximum potential amount under these indemnification agreements due to uncertainties in the litigation process, coordination with other suppliers and the defendants in these cases, and the unique facts and circumstances involved in each particular agreement. Historically, payments made by us under these agreements have not had a material effect on our operating results, financial position, or cash flows.
  (was, 2020-05-18, similarity 0.8193):
[0000858877-20-000006:note_history:18]
It is not possible to determine the maximum potential amount under these indemnification agreements due to our limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by us under these agreements have not had a material effect on our operating results, financial position, or cash flows.

- changed (2020-11-17):
[0000858877-20-000015:note_history:19]
(f)Legal Proceedings
  (was, 2020-05-18, similarity 0.8511):
[0000858877-20-000006:note_history:19]
| (f) | Legal Proceedings |

- changed (2020-11-17):
[0000858877-20-000015:note_history:20]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $0.1 billion for the alleged evasion of import and other taxes, $0.7 billion for interest, and $0.4 billion for various penalties, all determined using an exchange rate as of October 24, 2020.
  (was, 2020-05-18, similarity 0.7556):
[0000858877-20-000006:note_history:20]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

- changed (2020-11-17):
[0000858877-20-000015:note_history:21]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.
  (was, 2020-05-18, similarity 0.9922):
[0000858877-20-000006:note_history:21]
We have completed a thorough review of the matters and believe the remaining asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

- added (2020-11-17):
[0000858877-20-000015:note_history:22]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal has appealed the PTAB’s findings of unpatentability to the United States Court of Appeals for the Federal Circuit. Starting on May 6, 2020 and concluding on June 25, 2020, the District Court conducted a bench trial by videoconference on the claims in the five patents not subject to the IPR Proceedings, including claims in three for which the PTAB declined to institute IPR Proceedings. Centripetal

- added (2020-11-17):
[0000858877-20-000015:note_history:23]
sought damages, enhanced damages for willful infringement, and broad injunctive relief. On October 5, 2020, the District Court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The Court awarded Centripetal $1.9 billion, comprised of $755.8 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $13.7 million. The Court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $167.7 million and a maximum annual royalty of $300.1 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $83.9 million and a maximum annual royalty of $150.0 million. We believe that the District Court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We intend to appeal the District Court’s judgment as to the four patents found valid and infringed to the United States Court of Appeals for the Federal Circuit, and we believe that any relief ultimately awarded would not be material. On October 28, 2020, by agreement of the parties, the District Court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment. On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. District Court proceedings, one of which has been invalidated by the PTAB. We are currently assessing the cases filed in Germany and we believe we have strong defenses. Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of the cases at this time.

- changed (2020-11-17):
[0000858877-20-000015:note_history:24]
Finjan     On January 6, 2017, Finjan, Inc. (“Finjan”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Finjan alleges that Cisco’s AMP and ThreatGrid products and the URL rewrite feature of Cisco’s ESA Outbreak Filter product infringe five patents, four of which have expired. Finjan has conceded that they are not entitled to any pre-suit damages, accordingly it seeks approximately three weeks of damages for the alleged infringement of the 8,677,494 and 6,154,844 patents, approximately ten months of damages for the 6,804,780 patent, approximately three years of damages for the 7,647,633 patent, and approximately three-and-a-half years of past damages for the 8,141,154 patent and an ongoing royalty until its expiration on December 12, 2025. The case is currently set for jury trial starting January 11, 2021. While we believe that we have strong non-infringement arguments, that the patents are invalid, that Finjan’s damages theories are not supported by prevailing law and that Finjan will not be able to meet its burden required for injunctive relief, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.
  (was, 2020-05-18, similarity 0.8255):
[0000858877-20-000006:note_history:24]
Finjan     On January 6, 2017, Finjan, Inc. (“Finjan”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Finjan alleges that Cisco’s AMP and ThreatGrid products and the URL rewrite feature of Cisco’s ESA Outbreak Filter product infringe five patents, four of which have expired. Finjan has conceded that they are not entitled to any pre-suit damages, accordingly it seeks approximately three weeks of damages for the alleged infringement of the 8,677,494 and 6,154,844 patents, approximately ten months of damages for the 6,804,780 patent, approximately three years of damages for the 7,647,633 patent, and approximately three-and-a-half years of past damages for the 8,141,154 patent and an ongoing royalty until its expiration on December 12, 2025. The case is currently set for jury trial starting June 22, 2020. While we believe that we have strong non-infringement arguments, that the patents are invalid, that Finjan’s damages theories are not supported by prevailing law and that Finjan will not be able to meet its burden required for injunctive relief, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.

- added (2020-11-17):
[0000858877-20-000015:note_history:25]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three U.S. patents. The case is currently set for a jury trial starting December 4, 2020. While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.

- removed (2020-11-17):
[0000858877-20-000006:note_history:26]
Commitments and Contingencies

- removed (2020-11-17):
[0000858877-20-000006:note_history:27]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. At the end of the third quarter of fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic environment. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.3 billion and $7.2 billion for the third quarter of fiscal 2020 and 2019, respectively, and was $20.5 billion and $21.7 billion for the first nine months of fiscal 2020 and 2019, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.4 billion as of April 25, 2020 and July 27, 2019, respectively.

- removed (2020-11-17):
[0000858877-20-000006:note_history:28]
During the second quarter of fiscal 2020, $0.8 billion of penalty and interest asserted by the Brazilian federal tax authorities against our Brazilian subsidiary on the theory of joint liability was dismissed on its merits. The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total remaining asserted claims by Brazilian state and federal tax authorities aggregate to $0.1 billion for the alleged evasion of import and other taxes, $0.7 billion for interest, and $0.4 billion for various penalties, all determined using an exchange rate as of April 25, 2020.

- removed (2020-11-17):
[0000858877-20-000006:note_history:29]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Centripetal alleges that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has thus far issued Final Written Decisions for five patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and a portion of the claims of a sixth patent have been found unpatentable. The District Court set a bench trial by videoconference, which started on May 6, 2020, on the claims in the five patents not subject to the IPR Proceedings, including claims in three for which the PTAB declined to institute Inter Partes Review. While we believe that we have strong non-infringement defenses and that the patents are invalid, as well as other arguments and defenses, if we do not prevail in the District Court, we believe that Centripetal will not be able to meet its burden required for injunctive relief and that any final damages ultimately assessed would not be material. On May 4, 2020, Centripetal instituted an action in the District Court of Dusseldorf in Germany against Cisco Systems GmbH asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two patents Centripetal has asserted against us in the U.S. District Court proceedings, one of which has been invalidated by the PTAB. We are currently assessing the case filed in Germany. Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of this litigation at this time.

- removed (2020-11-17):
[0000858877-20-000006:note_history:30]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the District Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path’s claims against us and cancelling a trial which had been set for March 12, 2018. Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit, and, on January 23, 2019, the District Court summarily affirmed the finding of non-infringement. On August 23, 2019, Straight Path filed a petition with the United States Supreme Court challenging the constitutionality of the Federal Circuit’s rule allowing summary affirmance, which was denied on November 18, 2019.

- removed (2020-11-17):
[0000858877-20-000006:note_history:31]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the District Court consolidated the cases alleging infringement of the ‘327 Patent. Oyster's cases against some of the defendants were resolved. The District Court vacated the November 4, 2018 trial date set for Oyster's claims against Cisco and one other remaining defendant, pending resolution of Oyster’s December 6, 2018 appeal of the District Court's summary judgment ruling dismissing certain of Oyster’s claims. On May 8, 2020, the Federal Circuit affirmed the District Court’s summary judgment ruling. While we

- removed (2020-11-17):
[0000858877-20-000006:note_history:32]
believe that the District Court's summary judgment ruling will continue to be upheld if subject to further challenge and we have strong defenses for Oyster's remaining claims, if Oyster seeks further review of the District Court's summary judgment ruling and it is reversed and the dismissed claims are remanded, and if we do not prevail in the District Court on those claims and Oyster's remaining claims in a subsequent trial, we believe damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, we are unable to reasonably estimate the ultimate outcome of this litigation at this time.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-11-17):
[0000858877-20-000015:note_history:33]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.
  (was, 2020-05-18, similarity 0.8244):
[0000858877-20-000006:note_history:33]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-11-17):
[0000858877-20-000015:note_history:34]
Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2021 is a 53-week fiscal year and fiscal 2020 was a 52-week fiscal year. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).
  (was, 2020-05-18, similarity 0.927):
[0000858877-20-000006:note_history:34]
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2020 and fiscal 2019 are each 52-week fiscal years. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

- changed (2020-11-17):
[0000858877-20-000015:note_history:35]
We have prepared the accompanying financial data as of October 24, 2020 and for the first quarter of fiscal 2021 and 2020, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 25, 2020 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 25, 2020.
  (was, 2020-05-18, similarity 0.978):
[0000858877-20-000006:note_history:35]
We have prepared the accompanying financial data as of April 25, 2020 and for the third quarter and first nine months of fiscal 2020 and 2019, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2019 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2019.

- added (2020-11-17):
[0000858877-20-000015:note_history:36]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 24, 2020, the results of operations, the statements of comprehensive income (loss), the statements of cash flows and the statements of equity for the first quarter of fiscal 2021 and 2020, as applicable, have been made. The results of operations for the first quarter of fiscal 2021 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2020-11-17):
[0000858877-20-000006:note_history:37]
Basis of Presentation

- removed (2020-11-17):
[0000858877-20-000006:note_history:38]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of April 25, 2020, the results of operations, the statements of comprehensive income (loss) and the statements of equity for the third quarter and first nine months of fiscal 2020 and 2019; and the statements of cash flows for the first nine months of fiscal 2020 and 2019, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2020 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-11-17):
[0000858877-20-000015:note_history:39]
Recent Accounting Pronouncements
(a)New Accounting Updates Recently Adopted
  (was, 2020-05-18, similarity 0.6935):
[0000858877-20-000006:note_history:39]
| (a) | New Accounting Updates Recently Adopted |

- added (2020-11-17):
[0000858877-20-000015:note_history:40]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. We adopted this standard at the beginning of our first quarter of fiscal 2021, applied it at the beginning of the period of adoption and did not restate prior periods. The standard primarily impacts our financial assets measured at amortized cost and available-for-sale debt securities. The standard did not have a material impact on our consolidated financial statements upon adoption.

- added (2020-11-17):
[0000858877-20-000015:note_history:41]
Our significant accounting policies have been updated as a result of adopting this standard are as follows:

- added (2020-11-17):
[0000858877-20-000015:note_history:42]
Allowance for Accounts Receivable, Contract Assets and Financing Receivables     We estimate our allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, we determine collectibility by pooling our assets with similar characteristics.

- added (2020-11-17):
[0000858877-20-000015:note_history:43]
The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. Our internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality. Our assets within each internal credit risk rating share similar risk characteristics and therefore are assessed as one portfolio segment for credit loss. Assets that do not share risk characteristics are evaluated on an individual basis. The allowances for credit losses are each measured by multiplying the exposure probability of default, the probability the asset will default within a given time frame, by the loss given default rate, the percentage of the asset not expected to be collected due to default, based on the pool of assets.

- added (2020-11-17):
[0000858877-20-000015:note_history:44]
Probability of default rates are published quarterly by third-party credit agencies. Adjustments to our internal credit risk ratings may take into account including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

- added (2020-11-17):
[0000858877-20-000015:note_history:45]
Available-for-Sale Debt Investments     For our available-for-sale debt securities in an unrealized loss position, we determine whether a credit loss exists. In this assessment, we consider the extent to which the fair value is less than the amortized cost, any changes to the rating of the security by a rating agency, and adverse conditions specifically related to the security, among other factors. If factors indicate a credit loss exists, an allowance for credit loss is recorded to other income (loss), net, limited by the amount that the fair value is less than the amortized cost basis. The amount of fair value change relating to all other factors will be recognized in other comprehensive income (OCI).

- removed (2020-11-17):
[0000858877-20-000006:note_history:46]
Recent Accounting Pronouncements

- removed (2020-11-17):
[0000858877-20-000006:note_history:47]
Leases  In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Codification (ASC) 842, Leases, a new standard requiring lessees to recognize operating and finance lease liabilities on the balance sheet, as well as corresponding right-of-use (ROU) assets. This standard also made some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, new disclosures are required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. ASC 842 requires adoption using the modified retrospective approach, with the option of applying the requirements of the standard either i) retrospectively to each prior comparative reporting period presented, or ii) retrospectively at the beginning of the period of adoption. We adopted this standard at the beginning of our first quarter of fiscal 2020 and applied it at the beginning of the period of adoption and did not restate prior periods. We adopted ASC 842 on July 28, 2019 which resulted in the recognition of $1.2 billion of operating lease ROU assets included in other assets and $1.2 billion of operating lease liabilities included in other current liabilities and other long-term liabilities. There were no transition adjustments recorded from the adoption of ASC 842 as a lessor.

- removed (2020-11-17):
[0000858877-20-000006:note_history:48]
We have elected to apply the package of practical expedients permitted under the transition guidance within ASC 842 which does not require reassessment of initial direct costs, classification of a lease and definition of a lease. We also elected additional practical

- removed (2020-11-17):
[0000858877-20-000006:note_history:49]
expedients which resulted in: i) allowing us not to reassess the accounting treatment for existing or expired land easements in transition; ii) combining lease and non-lease components and iii) not recording leases with an initial term of less than 12 months on our Consolidated Balance Sheet.

- removed (2020-11-17):
[0000858877-20-000006:note_history:50]
As a lessee, we determine if an arrangement is a lease at commencement. Our ROU lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments related to the lease. Operating lease ROU assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. We use incremental borrowing rates based on information available at the commencement date to determine the present value of our lease payments.

- removed (2020-11-17):
[0000858877-20-000006:note_history:51]
As a lessor, we determine if an arrangement is a lease at inception. We provide leasing arrangements for our equipment to certain qualified customers. Our lease portfolio primarily consists of sales-type leases. We allocate the consideration in a bundled contract with our customers based on relative standalone selling prices of our lease and non-lease components. The residual value on our leased equipment is determined at the inception of the lease based on an analysis of estimates of the value of equipment, market factors and historical customer behavior. Residual value estimates are reviewed on a periodic basis and other-than-temporary declines are expensed in the period they occur. Our leases generally provide an end-of-term option for the customer to extend the lease under mutually-agreed terms, return the leased equipment, or purchase the equipment for either the then-market value of the equipment or a pre-determined purchase price. If a customer chooses to terminate their lease prior to the original end of term date, the customer is required to pay all remaining lease payments in full.

- removed (2020-11-17):
[0000858877-20-000006:note_history:52]
For additional information, see Note 8.

- removed (2020-11-17):
[0000858877-20-000006:note_history:53]
| (b) | Recent Accounting Standards or Updates Not Yet Effective |

- removed (2020-11-17):
[0000858877-20-000006:note_history:54]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2021 on a modified retrospective basis. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-17):
[0000858877-20-000015:note_history:55]
Borrowings 
(a)Short-Term Debt
  (was, 2020-05-18, similarity 0.7037):
[0000858877-20-000006:note_history:55]
| (a) | Short-Term Debt |

- changed (2020-11-17):
[0000858877-20-000015:note_history:56]
|  | October 24, 2020 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 5,002 |  |  | 2.00 | % |  | $ | 3,005 |  |  | 2.07 | % |
  (was, 2020-05-18, similarity 0.7317):
[0000858877-20-000006:note_history:56]
|  | April 25, 2020 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,506 |  |  | 2.32 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 4,506 |  |  |  |  | $ | 10,191 |  |  |  |

- changed (2020-11-17):
[0000858877-20-000015:note_history:57]
(b)Long-Term Debt
  (was, 2020-05-18, similarity 0.8293):
[0000858877-20-000006:note_history:57]
| (b) | Long-Term Debt |

- changed (2020-11-17):
[0000858877-20-000015:note_history:58]
|  |  |  | October 24, 2020 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | 2,500 |  |  | 2.30% |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.91% |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.19% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.03% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.35% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 14,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (86) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 152 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 14,566 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 5,002 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,564 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 14,566 |  |  |  |  | $ | 14,583 |  |  |  |
  (was, 2020-05-18, similarity 0.8786):
[0000858877-20-000006:note_history:58]
|  |  |  | April 25, 2020 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | — |  |  | — |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.76% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.85% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.87% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.01% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 16,000 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (90 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 174 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 16,084 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,506 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 11,578 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 16,084 |  |  |  |  | $ | 20,473 |  |  |  |

- changed (2020-11-17):
[0000858877-20-000015:note_history:59]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $2.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (“LIBOR”). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.
  (was, 2020-05-18, similarity 0.9959):
[0000858877-20-000006:note_history:59]
We entered into interest rate swaps in prior periods with an aggregate notional amount of $2.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (“LIBOR”). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

- changed (2020-11-17):
[0000858877-20-000015:note_history:60]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 24, 2020, we were in compliance with all debt covenants.
  (was, 2020-05-18, similarity 0.9863):
[0000858877-20-000006:note_history:60]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 25, 2020, we were in compliance with all debt covenants.

- changed (2020-11-17):
[0000858877-20-000015:note_history:61]
As of October 24, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2020-05-18, similarity 0.9627):
[0000858877-20-000006:note_history:61]
As of April 25, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2020-11-17):
[0000858877-20-000015:note_history:62]
| Fiscal Year | Amount |
| 2021 (remaining nine months) | $ | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 14,500 |  |
  (was, 2020-05-18, similarity 0.9772):
[0000858877-20-000006:note_history:62]
| Fiscal Year | Amount |
| 2020 (remaining three months) | $ | 1,500 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 16,000 |  |

- changed (2020-11-17):
[0000858877-20-000015:note_history:63]
(c)Credit Facility
  (was, 2020-05-18, similarity 0.8372):
[0000858877-20-000006:note_history:63]
| (c) | Credit Facility |

- changed (2020-11-17):
[0000858877-20-000015:note_history:64]
On May 15, 2020, we entered into a 364-day credit agreement with certain institutional lenders that provides for a $2.75 billion unsecured revolving credit facility that is scheduled to expire on May 14, 2021. The credit agreement is structured as an amendment and restatement of our five-year credit facility which would have terminated on May 15, 2020, the end of its five-year term. As of October 24, 2020, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility. 
Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than 0.25%. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.
  (was, 2020-05-18, similarity 0.9075):
[0000858877-20-000006:note_history:64]
On May 15, 2020, we entered into a 364-day credit agreement with certain institutional lenders that provides for a $2.75 billion unsecured revolving credit facility that is scheduled to expire on May 14, 2021. The credit agreement is structured as an amendment and restatement of our five-year credit facility which would have terminated on May 15, 2020, the end of its five-year term. As of April 25, 2020, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the five-year credit facility. 
Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than 0.25%. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

- removed (2020-11-17):
[0000858877-20-000006:note_history:65]
Borrowings


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-17):
[0000858877-20-000015:note_history:66]
Available-for-Sale Debt and Equity Investments
(a)Summary of Available-for-Sale Debt Investments
  (was, 2020-05-18, similarity 0.6579):
[0000858877-20-000006:note_history:66]
| (a) | Summary of Available-for-Sale Debt Investments |

- added (2020-11-17):
[0000858877-20-000015:note_history:67]
| October 24, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,656 |  |  | $ | 61 |  |  | $ | — |  |  | $ | 2,717 |  |
| U.S. government agency securities | 178 |  |  | — |  |  | — |  |  | 178 |  |
| Corporate debt securities | 11,266 |  |  | 298 |  |  | (27) |  |  | 11,537 |  |
| U.S. agency mortgage-backed securities | 2,494 |  |  | 41 |  |  | (6) |  |  | 2,529 |  |
| Commercial paper | 1,712 |  |  | — |  |  | — |  |  | 1,712 |  |
| Certificates of deposit | 517 |  |  | — |  |  | — |  |  | 517 |  |
| Total (1) | $ | 18,823 |  |  | $ | 400 |  |  | $ | (33) |  |  | $ | 19,190 |  |

- changed (2020-11-17):
[0000858877-20-000015:note_history:68]
| July 25, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 2,614 |  |  | $ | 71 |  |  | $ | — |  |  | $ | 2,685 |  |
| U.S. government agency securities | 110 |  |  | — |  |  | — |  |  | 110 |  |
| Corporate debt securities | 11,549 |  |  | 334 |  |  | (6) |  |  | 11,877 |  |
| U.S. agency mortgage-backed securities | 1,987 |  |  | 49 |  |  | (1) |  |  | 2,035 |  |
| Commercial paper | 727 |  |  | — |  |  | — |  |  | 727 |  |
| Certificates of deposit | 176 |  |  | — |  |  | — |  |  | 176 |  |
| Total | $ | 17,163 |  |  | $ | 454 |  |  | $ | (7) |  |  | $ | 17,610 |  |
  (was, 2020-05-18, similarity 0.7217):
[0000858877-20-000006:note_history:68]
| July 27, 2019 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 808 |  |  | $ | 1 |  |  | $ | (1 | ) |  | $ | 808 |  |
| U.S. government agency securities | 169 |  |  | — |  |  | — |  |  | 169 |  |
| Corporate debt securities | 19,188 |  |  | 103 |  |  | (29 | ) |  | 19,262 |  |
| U.S. agency mortgage-backed securities | 1,425 |  |  | 7 |  |  | (11 | ) |  | 1,421 |  |
| Total | $ | 21,590 |  |  | $ | 111 |  |  | $ | (41 | ) |  | $ | 21,660 |  |

- changed (2020-11-17):
[0000858877-20-000015:note_history:69]
(1) Net unsettled investment sales were $57 million as of October 24, 2020 and were included in other current assets.
  (was, 2020-05-18, similarity 0.9545):
[0000858877-20-000006:note_history:69]
(1) Net unsettled investment sales were $12 million as of April 25, 2020 and were included in other current assets.

- added (2020-11-17):
[0000858877-20-000015:note_history:70]
|  | Three Months Ended |
|  | October 24, 2020 |  | October 26, 2019 |
| Gross realized gains | $ | 15 |  |  | $ | 12 |  |
| Gross realized losses | — |  |  | (2) |  |
| Total | $ | 15 |  |  | $ | 10 |  |

- changed (2020-11-17):
[0000858877-20-000015:note_history:71]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 24, 2020 and July 25, 2020 (in millions):
  (was, 2020-05-18, similarity 0.9716):
[0000858877-20-000006:note_history:71]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 25, 2020 and July 27, 2019 (in millions):

- added (2020-11-17):
[0000858877-20-000015:note_history:72]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 24, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 144 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 144 |  |  | $ | — |  |
| U.S. government agency securities | 65 |  |  | — |  |  | — |  |  | — |  |  | 65 |  |  | — |  |
| Corporate debt securities | 1,008 |  |  | (2) |  |  | — |  |  | — |  |  | 1,008 |  |  | (2) |  |
| U.S. agency mortgage-backed securities | 1,076 |  |  | (6) |  |  | — |  |  | — |  |  | 1,076 |  |  | (6) |  |
| Certificates of deposit | 15 |  |  | — |  |  | — |  |  | — |  |  | 15 |  |  | — |  |
| Total | $ | 2,308 |  |  | $ | (8) |  |  | $ | — |  |  | $ | — |  |  | $ | 2,308 |  |  | $ | (8) |  |

- changed (2020-11-17):
[0000858877-20-000015:note_history:73]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 25, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government agency securities | $ | 33 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 33 |  |  | $ | — |  |
| Corporate debt securities | 1,060 |  |  | (6) |  |  | 3 |  |  | — |  |  | 1,063 |  |  | (6) |  |
| U.S. agency mortgage-backed securities | 265 |  |  | (1) |  |  | — |  |  | — |  |  | 265 |  |  | (1) |  |
| Total | $ | 1,358 |  |  | $ | (7) |  |  | $ | 3 |  |  | $ | — |  |  | $ | 1,361 |  |  | $ | (7) |  |
  (was, 2020-05-18, similarity 0.6323):
[0000858877-20-000006:note_history:73]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2019 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 204 |  |  | $ | — |  |  | $ | 488 |  |  | $ | (1 | ) |  | $ | 692 |  |  | $ | (1 | ) |
| U.S. government agency securities | — |  |  | — |  |  | 169 |  |  | — |  |  | 169 |  |  | — |  |
| Corporate debt securities | 2,362 |  |  | (4 | ) |  | 5,271 |  |  | (25 | ) |  | 7,633 |  |  | (29 | ) |
| U.S. agency mortgage-backed securities | 123 |  |  | — |  |  | 847 |  |  | (11 | ) |  | 970 |  |  | (11 | ) |
| Total | $ | 2,689 |  |  | $ | (4 | ) |  | $ | 6,775 |  |  | $ | (37 | ) |  | $ | 9,464 |  |  | $ | (41 | ) |

- changed (2020-11-17):
[0000858877-20-000015:note_history:74]
The following table summarizes the maturities of our available-for-sale debt investments as of October 24, 2020 (in millions):
  (was, 2020-05-18, similarity 0.9583):
[0000858877-20-000006:note_history:74]
The following table summarizes the maturities of our available-for-sale debt investments as of April 25, 2020 (in millions):

- changed (2020-11-17):
[0000858877-20-000015:note_history:75]
(b)Summary of Equity Investments
  (was, 2020-05-18, similarity 0.9014):
[0000858877-20-000006:note_history:75]
| (b) | Summary of Equity Investments |

- added (2020-11-17):
[0000858877-20-000015:note_history:76]
Our net adjustments to non-marketable equity securities measured using the measurement alternative was a net gain of $1 million and a net loss of $1 million for the first quarter of fiscal 2021 and 2020, respectively. We held equity interests in certain private equity funds of $0.7 billion as of each of October 24, 2020 and July 25, 2020, which are accounted for under the NAV practical expedient.

- changed (2020-11-17):
[0000858877-20-000015:note_history:77]
(c)Variable Interest Entities
  (was, 2020-05-18, similarity 0.8923):
[0000858877-20-000006:note_history:77]
| (c) | Variable Interest Entities |

- changed (2020-11-17):
[0000858877-20-000015:note_history:78]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 24, 2020, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2020-05-18, similarity 0.7929):
[0000858877-20-000006:note_history:78]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 25, 2020, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- added (2020-11-17):
[0000858877-20-000015:note_history:79]
The carrying value of our investments in privately held companies was $1.4 billion and $1.3 billion as of October 24, 2020 and July 25, 2020, respectively.

- added (2020-11-17):
[0000858877-20-000015:note_history:80]
Of the total carrying value of our investments in privately held companies as of October 24, 2020, $0.7 billion of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $0.3 billion related to these privately held investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these privately held investments.

- removed (2020-11-17):
[0000858877-20-000006:note_history:81]
Available-for-Sale Debt Investments and Equity Investments

- removed (2020-11-17):
[0000858877-20-000006:note_history:82]
The following table summarizes our available-for-sale debt investments and equity investments (in millions):

- removed (2020-11-17):
[0000858877-20-000006:note_history:83]
|  | April 25, 2020 |  | July 27, 2019 |
| Available-for-sale debt investments | $ | 18,208 |  |  | $ | 21,660 |  |
| Marketable equity securities | — |  |  | 3 |  |
| Total investments | 18,208 |  |  | 21,663 |  |
| Non-marketable equity securities included in other assets | 1,186 |  |  | 1,113 |  |
| Equity method investments included in other assets | 68 |  |  | 87 |  |
| Total | $ | 19,462 |  |  | $ | 22,863 |  |

- removed (2020-11-17):
[0000858877-20-000006:note_history:84]
| April 25, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 2,527 |  |  | $ | 83 |  |  | $ | — |  |  | $ | 2,610 |  |
| U.S. government agency securities | 54 |  |  | — |  |  | — |  |  | 54 |  |
| Corporate debt securities | 12,291 |  |  | 172 |  |  | (86 | ) |  | 12,377 |  |
| U.S. agency mortgage-backed securities | 1,617 |  |  | 50 |  |  | — |  |  | 1,667 |  |
| Commercial paper | 1,272 |  |  | — |  |  | — |  |  | 1,272 |  |
| Certificates of deposit | 228 |  |  | — |  |  | — |  |  | 228 |  |
| Total (1) | $ | 17,989 |  |  | $ | 305 |  |  | $ | (86 | ) |  | $ | 18,208 |  |

- removed (2020-11-17):
[0000858877-20-000006:note_history:85]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Gross realized gains | $ | 20 |  |  | $ | 7 |  |  | $ | 45 |  |  | $ | 10 |  |
| Gross realized losses | (21 | ) |  | (14 | ) |  | (25 | ) |  | (28 | ) |
| Total | $ | (1 | ) |  | $ | (7 | ) |  | $ | 20 |  |  | $ | (18 | ) |

- removed (2020-11-17):
[0000858877-20-000006:note_history:86]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 25, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 26 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |
| U.S. government agency securities | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Corporate debt securities | 3,529 |  |  | (86 | ) |  | 23 |  |  | — |  |  | 3,552 |  |  | (86 | ) |
| U.S. agency mortgage-backed securities | 19 |  |  | — |  |  | — |  |  | — |  |  | 19 |  |  | — |  |
| Commercial paper | 1,013 |  |  | — |  |  | — |  |  | — |  |  | 1,013 |  |  | — |  |
| Certificates of deposit | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 4,607 |  |  | $ | (86 | ) |  | $ | 23 |  |  | $ | — |  |  | $ | 4,630 |  |  | $ | (86 | ) |

- removed (2020-11-17):
[0000858877-20-000006:note_history:87]
For available-for-sale debt investments that were in an unrealized loss position as of April 25, 2020, we have determined that no other-than-temporary impairments were required to be recognized.

- removed (2020-11-17):
[0000858877-20-000006:note_history:88]
Gains and losses recognized on our marketable and non-marketable equity securities are summarized below (in millions):

- removed (2020-11-17):
[0000858877-20-000006:note_history:89]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Net gains and losses recognized during the period on equity investments | $ | (7 | ) |  | $ | 3 |  |  | $ | 71 |  |  | $ | 78 |  |
| Less: Net gains and losses recognized on equity investments sold | 3 |  |  | (44 | ) |  | (71 | ) |  | (51 | ) |
| Net unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | (4 | ) |  | $ | (41 | ) |  | $ | — |  |  | $ | 27 |  |

- removed (2020-11-17):
[0000858877-20-000006:note_history:90]
We recorded adjustments to the carrying value of our non-marketable equity securities measured using the measurement alternative as follows (in millions):

- removed (2020-11-17):
[0000858877-20-000006:note_history:91]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |  |  |  |  |  |  |
| Upward adjustments | $ | 9 |  |  | $ | 9 |  |  | $ | 20 |  |  | $ | 25 |  |
| Downward adjustments, including impairments | (13 | ) |  | (4 | ) |  | (21 | ) |  | (22 | ) |
| Net adjustments | $ | (4 | ) |  | $ | 5 |  |  | $ | (1 | ) |  | $ | 3 |  |

- removed (2020-11-17):
[0000858877-20-000006:note_history:92]
As of April 25, 2020 and July 27, 2019, we held equity interests in certain private equity funds of $0.7 billion and $0.6 billion, respectively, which are accounted for under the NAV practical expedient.

- removed (2020-11-17):
[0000858877-20-000006:note_history:93]
As of April 25, 2020, the carrying value of investments in privately held companies was $1.3 billion. $691 million of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $344 million related to these privately held investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these privately held investments.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-17):
[0000858877-20-000015:note_history:94]
|  |  |  | October 24, 2020 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | 2,500 |  |  | 2.30% |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.91% |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.19% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.03% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.35% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 14,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (86) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 152 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 14,566 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 5,002 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,564 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 14,566 |  |  |  |  | $ | 14,583 |  |  |  |
  (was, 2020-05-18, similarity 0.8786):
[0000858877-20-000006:note_history:94]
|  |  |  | April 25, 2020 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | — |  |  | — |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.76% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.85% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.87% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.01% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 16,000 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (90 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 174 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 16,084 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,506 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 11,578 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 16,084 |  |  |  |  | $ | 20,473 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-17):
[0000858877-20-000015:note_history:95]
As of October 24, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2020-05-18, similarity 0.9627):
[0000858877-20-000006:note_history:95]
As of April 25, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2020-11-17):
[0000858877-20-000015:note_history:96]
| Fiscal Year | Amount |
| 2021 (remaining nine months) | $ | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 14,500 |  |
  (was, 2020-05-18, similarity 0.9772):
[0000858877-20-000006:note_history:96]
| Fiscal Year | Amount |
| 2020 (remaining three months) | $ | 1,500 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 16,000 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-17):
[0000858877-20-000015:note_history:97]
|  | October 24, 2020 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 5,002 |  |  | 2.00 | % |  | $ | 3,005 |  |  | 2.07 | % |
  (was, 2020-05-18, similarity 0.7317):
[0000858877-20-000006:note_history:97]
|  | April 25, 2020 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,506 |  |  | 2.32 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 4,506 |  |  |  |  | $ | 10,191 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-11-17):
[0000858877-20-000015:note_history:98]
|  | Three Months Ended |
|  | October 24,2020 |  | October 26,2019 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 6,341 |  |  | $ | 7,553 |  |
| Applications | 1,380 |  |  | 1,499 |  |
| Security | 861 |  |  | 816 |  |
| Other Products | 5 |  |  | 11 |  |
| Total Product | 8,587 |  |  | 9,878 |  |
| Services | 3,342 |  |  | 3,281 |  |
| Total | $ | 11,929 |  |  | $ | 13,159 |  |

- added (2020-11-17):
[0000858877-20-000015:note_history:99]
|  | Three Months Ended |
|  | October 24,2020 |  | October 26,2019 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 6,341 |  |  | $ | 7,553 |  |
| Applications | 1,380 |  |  | 1,499 |  |
| Security | 861 |  |  | 816 |  |
| Other Products | 5 |  |  | 11 |  |
| Total Product | 8,587 |  |  | 9,878 |  |
| Services | 3,342 |  |  | 3,281 |  |
| Total | $ | 11,929 |  |  | $ | 13,159 |  |

- removed (2020-11-17):
[0000858877-20-000006:note_history:100]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,429 |  |  | $ | 7,523 |  |  | $ | 20,496 |  |  | $ | 22,247 |  |
| Applications | 1,363 |  |  | 1,431 |  |  | 4,211 |  |  | 4,315 |  |
| Security | 776 |  |  | 729 |  |  | 2,340 |  |  | 2,083 |  |
| Other Products | 28 |  |  | 39 |  |  | 100 |  |  | 239 |  |
| Total Product | 8,597 |  |  | 9,722 |  |  | 27,146 |  |  | 28,885 |  |
| Services | 3,386 |  |  | 3,236 |  |  | 10,001 |  |  | 9,591 |  |
| Total (1) | $ | 11,983 |  |  | $ | 12,958 |  |  | $ | 37,147 |  |  | $ | 38,476 |  |

- removed (2020-11-17):
[0000858877-20-000006:note_history:101]
Amounts may not sum due to rounding.

- removed (2020-11-17):
[0000858877-20-000006:note_history:102]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (“SPVSS”) business. Total revenue includes SPVSS business revenue of $168 million for the first nine months of fiscal 2019.

- removed (2020-11-17):
[0000858877-20-000006:note_history:103]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,429 |  |  | $ | 7,523 |  |  | $ | 20,496 |  |  | $ | 22,247 |  |
| Applications | 1,363 |  |  | 1,431 |  |  | 4,211 |  |  | 4,315 |  |
| Security | 776 |  |  | 729 |  |  | 2,340 |  |  | 2,083 |  |
| Other Products | 28 |  |  | 39 |  |  | 100 |  |  | 239 |  |
| Total Product | 8,597 |  |  | 9,722 |  |  | 27,146 |  |  | 28,885 |  |
| Services | 3,386 |  |  | 3,236 |  |  | 10,001 |  |  | 9,591 |  |
| Total (1) | $ | 11,983 |  |  | $ | 12,958 |  |  | $ | 37,147 |  |  | $ | 38,476 |  |

- removed (2020-11-17):
[0000858877-20-000006:note_history:104]
Amounts may not sum due to rounding.

- removed (2020-11-17):
[0000858877-20-000006:note_history:105]
(1) Includes SPVSS business revenue of $168 million for the first nine months of fiscal 2019.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-11-17):
[0000858877-20-000015:note_history:106]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 24, 2020 and July 25, 2020 was $81 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2020-11-17):
[0000858877-20-000015:note_history:107]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.
  (was, 2020-05-18, similarity 0.7606):
[0000858877-20-000006:note_history:107]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or

- changed (2020-11-17):
[0000858877-20-000015:note_history:108]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.
  (was, 2020-05-18, similarity 0.9734):
[0000858877-20-000006:note_history:108]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

- changed (2020-11-17):
[0000858877-20-000015:note_history:109]
Applications consists of offerings that utilize the core networking and data center platforms to provide their functions. The products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon
  (was, 2020-05-18, similarity 0.7842):
[0000858877-20-000006:note_history:109]
Applications consists of offerings that utilize the core networking and data center platforms to provide their functions. The products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2020-11-17):
[0000858877-20-000015:note_history:110]
transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2020-11-17):
[0000858877-20-000006:note_history:111]
service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-11-17):
[0000858877-20-000015:note_history:112]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

- added (2020-11-17):
[0000858877-20-000015:note_history:113]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 24, 2020 and July 25, 2020 was $81 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2020-11-17):
[0000858877-20-000015:note_history:114]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.
  (was, 2020-05-18, similarity 0.7606):
[0000858877-20-000006:note_history:114]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or

- changed (2020-11-17):
[0000858877-20-000015:note_history:115]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.
  (was, 2020-05-18, similarity 0.9734):
[0000858877-20-000006:note_history:115]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

- changed (2020-11-17):
[0000858877-20-000015:note_history:116]
(a)Disaggregation of Revenue
  (was, 2020-05-18, similarity 0.8889):
[0000858877-20-000006:note_history:116]
| (a) | Disaggregation of Revenue |

- added (2020-11-17):
[0000858877-20-000015:note_history:117]
|  | Three Months Ended |
|  | October 24,2020 |  | October 26,2019 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 6,341 |  |  | $ | 7,553 |  |
| Applications | 1,380 |  |  | 1,499 |  |
| Security | 861 |  |  | 816 |  |
| Other Products | 5 |  |  | 11 |  |
| Total Product | 8,587 |  |  | 9,878 |  |
| Services | 3,342 |  |  | 3,281 |  |
| Total | $ | 11,929 |  |  | $ | 13,159 |  |

- added (2020-11-17):
[0000858877-20-000015:note_history:118]
Amounts may not sum due to rounding. We have made certain reclassifications to the product revenue amounts for prior period to conform to the current year presentation.

- changed (2020-11-17):
[0000858877-20-000015:note_history:119]
Applications consists of offerings that utilize the core networking and data center platforms to provide their functions. The products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon
  (was, 2020-05-18, similarity 0.7842):
[0000858877-20-000006:note_history:119]
Applications consists of offerings that utilize the core networking and data center platforms to provide their functions. The products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2020-11-17):
[0000858877-20-000015:note_history:120]
transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- changed (2020-11-17):
[0000858877-20-000015:note_history:121]
(b)Contract Balances
  (was, 2020-05-18, similarity 0.8511):
[0000858877-20-000006:note_history:121]
| (b) | Contract Balances |

- changed (2020-11-17):
[0000858877-20-000015:note_history:122]
Accounts receivable, net was $4.0 billion as of October 24, 2020 compared to $5.5 billion as of July 25, 2020, as reported on the Consolidated Balance Sheet.
  (was, 2020-05-18, similarity 0.9645):
[0000858877-20-000006:note_history:122]
Accounts receivable, net was $4.6 billion as of April 25, 2020 compared to $5.5 billion as of July 27, 2019, as reported on the Consolidated Balance Sheet.

- changed (2020-11-17):
[0000858877-20-000015:note_history:123]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $1.2 billion as of October 24, 2020 and July 25, 2020, and were included in other current assets and other assets.
  (was, 2020-05-18, similarity 0.7468):
[0000858877-20-000006:note_history:123]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of April 25, 2020 and July 27, 2019, our contract assets for these unbilled receivables were $1.1 billion and $860 million, respectively, and were included in other current assets and other assets.

- added (2020-11-17):
[0000858877-20-000015:note_history:124]
Gross contract assets by our internal risk ratings are summarized as follows (in millions):

- added (2020-11-17):
[0000858877-20-000015:note_history:125]
|  | October 24,2020 |
| 1 to 4 | $ | 442 |  |
| 5 to 6 | 737 |  |
| 7 and Higher | 119 |  |
| Total | $ | 1,298 |  |

- changed (2020-11-17):
[0000858877-20-000015:note_history:126]
Contract liabilities consist of deferred revenue. Deferred revenue was $20.5 billion as of October 24, 2020 compared to $20.4 billion as of July 25, 2020. We recognized approximately $3.9 billion of revenue during the first quarter of fiscal 2021, that was included in the deferred revenue balance at July 25, 2020.
  (was, 2020-05-18, similarity 0.847):
[0000858877-20-000006:note_history:126]
Contract liabilities consist of deferred revenue. Deferred revenue was $18.6 billion as of April 25, 2020 compared to $18.5 billion as of July 27, 2019. We recognized approximately $2.3 billion and $8.9 billion of revenue during the third quarter and first nine months of fiscal 2020, respectively, that was included in the deferred revenue balance at July 27, 2019.

- added (2020-11-17):
[0000858877-20-000015:note_history:127]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $771 million and $732 million as of October 24, 2020 and July 25, 2020, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $123 million and $116 million for the first quarter of fiscal 2021 and 2020, respectively, and was included in sales and marketing expenses.

- removed (2020-11-17):
[0000858877-20-000006:note_history:128]
Revenue

- removed (2020-11-17):
[0000858877-20-000006:note_history:129]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

- removed (2020-11-17):
[0000858877-20-000006:note_history:130]
service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

- removed (2020-11-17):
[0000858877-20-000006:note_history:131]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,429 |  |  | $ | 7,523 |  |  | $ | 20,496 |  |  | $ | 22,247 |  |
| Applications | 1,363 |  |  | 1,431 |  |  | 4,211 |  |  | 4,315 |  |
| Security | 776 |  |  | 729 |  |  | 2,340 |  |  | 2,083 |  |
| Other Products | 28 |  |  | 39 |  |  | 100 |  |  | 239 |  |
| Total Product | 8,597 |  |  | 9,722 |  |  | 27,146 |  |  | 28,885 |  |
| Services | 3,386 |  |  | 3,236 |  |  | 10,001 |  |  | 9,591 |  |
| Total (1) | $ | 11,983 |  |  | $ | 12,958 |  |  | $ | 37,147 |  |  | $ | 38,476 |  |

- removed (2020-11-17):
[0000858877-20-000006:note_history:132]
Amounts may not sum due to rounding.

- removed (2020-11-17):
[0000858877-20-000006:note_history:133]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (“SPVSS”) business. Total revenue includes SPVSS business revenue of $168 million for the first nine months of fiscal 2019.

- removed (2020-11-17):
[0000858877-20-000006:note_history:134]
| (c) | Remaining Performance Obligations |

- removed (2020-11-17):
[0000858877-20-000006:note_history:135]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of April 25, 2020, the aggregate amount of RPO was $25.5 billion, comprised of $18.6 billion of deferred revenue and $6.9 billion of unbilled contract revenue. We expect approximately 56% of this amount to be recognized as revenue over the next year. As of July 27, 2019, the aggregate amount of RPO was $25.3 billion, comprised of $18.5 billion of deferred revenue and $6.8 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

- removed (2020-11-17):
[0000858877-20-000006:note_history:136]
| (d) | Capitalized Contract Acquisition Costs |

- removed (2020-11-17):
[0000858877-20-000006:note_history:137]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $703 million and $750 million as of April 25, 2020 and July 27, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $118 million and $356 million for the third quarter and first nine months of fiscal 2020, respectively, and $124 million and $349 million for the corresponding periods of fiscal 2019, respectively, and was included in sales and marketing expenses.
