# CSCO 10-Q controls and the auditor's report


## item_4_controls

[0000858877-20-000015:item_4_controls:1]
| Item 4. | Controls and Procedures |

[0000858877-20-000015:item_4_controls:2]
Evaluation of disclosure controls and procedures. Based on our management’s evaluation (with the participation of our principal executive officer and principal financial officer), as of the end of the period covered by this report, our principal executive officer and principal financial officer have concluded that our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended, (the “Exchange Act”)) are effective to ensure that information required to be disclosed by us in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in Securities and Exchange Commission rules and forms and is accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000858877-20-000015:item_4_controls:3]
Changes in internal control over financial reporting. There was no change in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during our first quarter of fiscal 2021 that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.
