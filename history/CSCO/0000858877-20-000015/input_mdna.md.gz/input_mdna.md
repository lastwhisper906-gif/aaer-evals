# CSCO MD&A — 0000858877-20-000015


## mdna

[0000858877-20-000015:mdna:1]
[same as prior period, unchanged from 0000858877-20-000006:mdna:1]

[0000858877-20-000015:mdna:2]
[same as prior period, unchanged from 0000858877-20-000006:mdna:2]

[0000858877-20-000015:mdna:3]
[same as prior period, unchanged from 0000858877-20-000006:mdna:3]

[0000858877-20-000015:mdna:4]
Cisco designs and sells a broad range of technologies that have been powering the Internet since 1984. We are integrating intent-based technologies across networking, security, collaboration, applications and the cloud. These technologies are designed to help our customers manage more users, devices and things connecting to their networks. This will enable us to provide customers with a highly secure, intelligent platform for their digital business.

[0000858877-20-000015:mdna:5]
[same as prior period, unchanged from 0000858877-20-000006:mdna:5]

[0000858877-20-000015:mdna:6]
|  | Three Months Ended |  |
|  | October 24,2020 |  | October 26,2019 |  | % Variance |  |
| Revenue | $ | 11,929 |  |  | $ | 13,159 |  |  | (9) | % |  |
| Gross margin percentage | 63.6 | % |  | 64.3 | % |  | (0.7) |  | pts |
| Research and development | $ | 1,612 |  |  | $ | 1,666 |  |  | (3) | % |  |
| Sales and marketing | $ | 2,217 |  |  | $ | 2,480 |  |  | (11) | % |  |
| General and administrative | $ | 544 |  |  | $ | 519 |  |  | 5 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,373 |  |  | $ | 4,665 |  |  | (6) | % |  |
| Total as a percentage of revenue | 36.7 | % |  | 35.5 | % |  | 1.2 |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 36 |  |  | $ | 36 |  |  | — | % |  |
| Restructuring and other charges included in operating expenses | $ | 602 |  |  | $ | 184 |  |  | 227 | % |  |
| Operating income as a percentage of revenue | 21.5 | % |  | 27.2 | % |  | (5.7) |  | pts |
| Interest and other income (loss), net | $ | 111 |  |  | $ | 107 |  |  | 4 | % |  |
| Income tax percentage | 18.9 | % |  | 20.6 | % |  | (1.7) |  | pts |
| Net income | $ | 2,174 |  |  | $ | 2,926 |  |  | (26) | % |  |
| Net income as a percentage of revenue | 18.2 | % |  | 22.2 | % |  | (4.0) |  | pts |
| Earnings per share—diluted | $ | 0.51 |  |  | $ | 0.68 |  |  | (25) | % |  |

[0000858877-20-000015:mdna:7]
[same as prior period, unchanged from 0000858877-20-000006:mdna:8]

[0000858877-20-000015:mdna:8]
[same as prior period, unchanged from 0000858877-20-000006:mdna:9]

[0000858877-20-000015:mdna:9]
Three Months Ended October 24, 2020 Compared with Three Months Ended October 26, 2019

[0000858877-20-000015:mdna:10]
In the first quarter of fiscal 2021, we delivered solid margins in a challenging environment with the COVID-19 pandemic. Total revenue decreased by 9% compared with the first quarter of fiscal 2020. Our product revenue declined in Infrastructure Platforms and Applications, partially offset by growth in Security, and we continued to make progress in the transition of our business model to increased software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment. We continued to experience broad-based weakening in the global macroeconomic environment during the quarter which impacted our commercial and enterprise markets. We also experienced continuing weakness in the service provider market and emerging countries, and we expect ongoing uncertainty in these markets. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-20-000015:mdna:11]
Within total revenue, product revenue decreased by 13% and service revenue increased by 2%. Total gross margin decreased by 0.7 percentage points, driven by unfavorable impacts from pricing and to a lesser extent, productivity, offset by favorable product mix. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 1.2 percentage points. Operating income as a percentage of revenue decreased by 5.7 percentage points. We incurred restructuring and other charges of $602 million in the first quarter of fiscal 2021. Diluted earnings per share decreased by 25%, driven by a 26% decrease in net income and a decrease in diluted share count of 29 million shares.

[0000858877-20-000015:mdna:12]
In terms of our geographic segments, revenue from the Americas decreased $779 million, driven in large part by a product revenue decline in the United States. EMEA revenue decreased by $319 million and APJC revenue decreased by $132 million. The “BRICM” countries experienced a product revenue decline of 29% in the aggregate, driven by decreased product revenue across each of the BRICM countries.

[0000858877-20-000015:mdna:13]
From a customer market standpoint, we experienced product revenue declines across all customer segments, with the most significant declines in the commercial and enterprise markets. During the first quarter of fiscal 2021, we continued to see a revenue decline in the commercial and enterprise markets, which we believe was significantly related to weakness in the global macroeconomic environment.

[0000858877-20-000015:mdna:14]
From a product category perspective, the product revenue decrease of 13% was driven by declines in revenue in Infrastructure Platforms of 16% and Applications of 8%. These declines were partially offset by a product revenue increase in Security of 6%.

[0000858877-20-000015:mdna:15]
[same as prior period, unchanged from 0000858877-20-000006:mdna:10]

[0000858877-20-000015:mdna:16]
[same as prior period, unchanged from 0000858877-20-000006:mdna:11]

[0000858877-20-000015:mdna:17]
[same as prior period, unchanged from 0000858877-20-000006:mdna:12]

[0000858877-20-000015:mdna:18]
•Most of our global workforce working from home.

[0000858877-20-000015:mdna:19]
•Seamless transition to work from home with a long-standing flexible work policy, and we build the technologies that allow organizations to stay connected, secure and productive.

[0000858877-20-000015:mdna:20]
•For the remainder who must be in the office to perform their roles, we are focused on their health and safety, and are taking all of the necessary precautions.

[0000858877-20-000015:mdna:21]
[same as prior period, unchanged from 0000858877-20-000006:mdna:16]

[0000858877-20-000015:mdna:22]
•Provided a variety of free offers and trials for our Webex and security technologies as they dramatically shifted entire workforces to be remote.

[0000858877-20-000015:mdna:23]
[same as prior period, unchanged from 0000858877-20-000006:mdna:19]

[0000858877-20-000015:mdna:24]
•Committed significant funds to support both global and local pandemic response efforts.

[0000858877-20-000015:mdna:25]
•Providing technology and financial support for non-profits, first responders, and governments.

[0000858877-20-000015:mdna:26]
•Donating personal protective equipment to hospital workers including N95 masks and face shields 3D-printed by Cisco volunteers around the world.

[0000858877-20-000015:mdna:27]
[same as prior period, unchanged from 0000858877-20-000006:mdna:29]

[0000858877-20-000015:mdna:28]
[same as prior period, unchanged from 0000858877-20-000006:mdna:30]

[0000858877-20-000015:mdna:29]
[same as prior period, unchanged from 0000858877-20-000006:mdna:33]

[0000858877-20-000015:mdna:30]
As our customers add billions of new connections to their enterprises, and as more applications move to a multicloud environment, the network becomes even more critical. Our customers are navigating change at an unprecedented pace and our mission is to inspire new possibilities for them by helping transform their infrastructure, expand applications and analytics, address their security needs, and empower their teams. We believe that our customers are looking for intent-based networks that provide meaningful business value through automation, security, and analytics across private, hybrid, and multicloud environments. Our vision is to deliver highly secure, software-defined, automated and intelligent platforms for our customers.

[0000858877-20-000015:mdna:31]
For additional discussion of our strategy and priorities, see Item 1. Business in our Annual Report on Form 10-K for the year ended July 25, 2020.

[0000858877-20-000015:mdna:32]
[same as prior period, unchanged from 0000858877-20-000006:mdna:36]

[0000858877-20-000015:mdna:33]
The following is a summary of our other key financial measures for the first quarter of fiscal 2021 (in millions):

[0000858877-20-000015:mdna:34]
|  |  | October 24,2020 |  | July 25,2020 |
| Cash and cash equivalents and investments |  | $ | 30,012 |  |  | $ | 29,419 |  |
| Deferred revenue |  | $ | 20,473 |  |  | $ | 20,446 |  |
| Inventories |  | $ | 1,303 |  |  | $ | 1,282 |  |

[0000858877-20-000015:mdna:35]
|  |  | Three Months Ended |
|  |  | October 24,2020 |  | October 26,2019 |
| Cash provided by operating activities |  | $ | 4,096 |  |  | $ | 3,587 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 800 |  |  | $ | 768 |  |
| Dividends paid |  | $ | 1,520 |  |  | $ | 1,486 |  |

[0000858877-20-000015:mdna:36]
[same as prior period, unchanged from 0000858877-20-000006:mdna:40]

[0000858877-20-000015:mdna:37]
[same as prior period, unchanged from 0000858877-20-000006:mdna:41]

[0000858877-20-000015:mdna:38]
[same as prior period, unchanged from 0000858877-20-000006:mdna:42]

[0000858877-20-000015:mdna:39]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements in our Annual Report on Form 10-K for the year ended July 25, 2020, as updated as applicable in Note 2 to the Consolidated Financial Statements herein, describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-20-000015:mdna:40]
The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The COVID-19 pandemic did not have a material impact on our significant judgments, assumptions and estimates that are reflected in our results for the first quarter of fiscal 2021. These estimates are listed in our Annual Report on Form 10-K for the year ending July 25, 2020, and include: goodwill and identified purchased intangible assets and income taxes, among other items. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues to develop, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-20-000015:mdna:41]
[same as prior period, unchanged from 0000858877-20-000006:mdna:45]

[0000858877-20-000015:mdna:42]
[same as prior period, unchanged from 0000858877-20-000006:mdna:46]

[0000858877-20-000015:mdna:43]
[same as prior period, unchanged from 0000858877-20-000006:mdna:47]

[0000858877-20-000015:mdna:44]
[same as prior period, unchanged from 0000858877-20-000006:mdna:48]

[0000858877-20-000015:mdna:45]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable. If actual credits received by distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-20-000015:mdna:46]
[same as prior period, unchanged from 0000858877-20-000006:mdna:50]

[0000858877-20-000015:mdna:47]
42

[0000858877-20-000015:mdna:48]
[same as prior period, unchanged from 0000858877-20-000006:mdna:52]

[0000858877-20-000015:mdna:49]
[same as prior period, unchanged from 0000858877-20-000006:mdna:53]

[0000858877-20-000015:mdna:50]
Loss Contingencies

[0000858877-20-000015:mdna:51]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-20-000015:mdna:52]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-20-000015:mdna:53]
[same as prior period, unchanged from 0000858877-20-000006:mdna:77]

[0000858877-20-000015:mdna:54]
[same as prior period, unchanged from 0000858877-20-000006:mdna:78]

[0000858877-20-000015:mdna:55]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first quarters of fiscal 2021 and 2020.

[0000858877-20-000015:mdna:56]
[same as prior period, unchanged from 0000858877-20-000006:mdna:82]

[0000858877-20-000015:mdna:57]
[same as prior period, unchanged from 0000858877-20-000006:mdna:83]

[0000858877-20-000015:mdna:58]
[same as prior period, unchanged from 0000858877-20-000006:mdna:84]

[0000858877-20-000015:mdna:59]
[same as prior period, unchanged from 0000858877-20-000006:mdna:85]

[0000858877-20-000015:mdna:60]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 18.9% and 20.6% in the first quarter of fiscal 2021 and 2020, respectively.

[0000858877-20-000015:mdna:61]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the

[0000858877-20-000015:mdna:62]
[same as prior period, unchanged from 0000858877-20-000006:mdna:66]

[0000858877-20-000015:mdna:63]
[same as prior period, unchanged from 0000858877-20-000006:mdna:67]

[0000858877-20-000015:mdna:64]
final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.

[0000858877-20-000015:mdna:65]
[same as prior period, unchanged from 0000858877-20-000006:mdna:88]

[0000858877-20-000015:mdna:66]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to foreign-derived intangible income deduction, global intangible low-tax income and base erosion and anti-abuse tax laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 37 countries, including the United States, has made changes to numerous long-standing tax principles. There can be no assurance that these changes, once adopted by countries, will not have an adverse impact on our provision for income taxes. Further, as a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries was subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-20-000015:mdna:67]
44

[0000858877-20-000015:mdna:68]
[same as prior period, unchanged from 0000858877-20-000006:mdna:80]

[0000858877-20-000015:mdna:69]
[same as prior period, unchanged from 0000858877-20-000006:mdna:81]

[0000858877-20-000015:mdna:70]
[same as prior period, unchanged from 0000858877-20-000006:mdna:93]

[0000858877-20-000015:mdna:71]
[same as prior period, unchanged from 0000858877-20-000006:mdna:94]

[0000858877-20-000015:mdna:72]
[same as prior period, unchanged from 0000858877-20-000006:mdna:95]

[0000858877-20-000015:mdna:73]
|  |  | Three Months Ended |
|  |  | October 24,2020 |  | October 26,2019 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,587 |  |  | $ | 9,878 |  |  | $ | (1,291) |  |  | (13) | % |
| Percentage of revenue |  | 72.0 | % |  | 75.1 | % |  |  |  |  |
| Service |  | 3,342 |  |  | 3,281 |  |  | 61 |  |  | 2 | % |
| Percentage of revenue |  | 28.0 | % |  | 24.9 | % |  |  |  |  |
| Total |  | $ | 11,929 |  |  | $ | 13,159 |  |  | $ | (1,230) |  |  | (9) | % |

[0000858877-20-000015:mdna:74]
[same as prior period, unchanged from 0000858877-20-000006:mdna:97]

[0000858877-20-000015:mdna:75]
|  |  | Three Months Ended |
|  |  | October 24,2020 |  | October 26,2019 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,198 |  |  | $ | 7,977 |  |  | $ | (779) |  |  | (10) | % |
| Percentage of revenue |  | 60.4 | % |  | 60.7 | % |  |  |  |  |
| EMEA |  | 2,964 |  |  | 3,283 |  |  | (319) |  |  | (10) | % |
| Percentage of revenue |  | 24.8 | % |  | 24.9 | % |  |  |  |  |
| APJC |  | 1,767 |  |  | 1,899 |  |  | (132) |  |  | (7) | % |
| Percentage of revenue |  | 14.8 | % |  | 14.4 | % |  |  |  |  |
| Total |  | $ | 11,929 |  |  | $ | 13,159 |  |  | $ | (1,230) |  |  | (9) | % |

[0000858877-20-000015:mdna:76]
[same as prior period, unchanged from 0000858877-20-000006:mdna:99]

[0000858877-20-000015:mdna:77]
Three Months Ended October 24, 2020 Compared with Three Months Ended October 26, 2019

[0000858877-20-000015:mdna:78]
Total revenue decreased by 9%. Product revenue decreased by 13% and service revenue increased by 2%. Our total revenue reflected declines across each of our geographic segments. Product revenue for the emerging countries of BRICM, in the aggregate, experienced a 29% product revenue decline, with decreases in each of these countries.

[0000858877-20-000015:mdna:79]
[same as prior period, unchanged from 0000858877-20-000006:mdna:102]

[0000858877-20-000015:mdna:80]
45

[0000858877-20-000015:mdna:81]
[same as prior period, unchanged from 0000858877-20-000006:mdna:91]

[0000858877-20-000015:mdna:82]
[same as prior period, unchanged from 0000858877-20-000006:mdna:92]

[0000858877-20-000015:mdna:83]
[same as prior period, unchanged from 0000858877-20-000006:mdna:107]

[0000858877-20-000015:mdna:84]
[same as prior period, unchanged from 0000858877-20-000006:mdna:108]

[0000858877-20-000015:mdna:85]
|  |  | Three Months Ended |
|  |  | October 24,2020 |  | October 26,2019 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,129 |  |  | $ | 5,907 |  |  | $ | (778) |  |  | (13) | % |
| Percentage of product revenue |  | 59.8 | % |  | 59.8 | % |  |  |  |  |
| EMEA |  | 2,210 |  |  | 2,557 |  |  | (347) |  |  | (14) | % |
| Percentage of product revenue |  | 25.7 | % |  | 25.9 | % |  |  |  |  |
| APJC |  | 1,248 |  |  | 1,413 |  |  | (165) |  |  | (12) | % |
| Percentage of product revenue |  | 14.5 | % |  | 14.3 | % |  |  |  |  |
| Total |  | $ | 8,587 |  |  | $ | 9,878 |  |  | $ | (1,291) |  |  | (13) | % |

[0000858877-20-000015:mdna:86]
[same as prior period, unchanged from 0000858877-20-000006:mdna:110]

[0000858877-20-000015:mdna:87]
Three Months Ended October 24, 2020 Compared with Three Months Ended October 26, 2019

[0000858877-20-000015:mdna:88]
[same as prior period, unchanged from 0000858877-20-000006:mdna:112]

[0000858877-20-000015:mdna:89]
Product revenue in the Americas segment decreased by 13%. The product revenue decrease was across all of our customer segments. From a country perspective, product revenue decreased by 12% in the United States, 24% in Canada, 23% in Mexico and 41% in Brazil.

[0000858877-20-000015:mdna:90]
[same as prior period, unchanged from 0000858877-20-000006:mdna:117]

[0000858877-20-000015:mdna:91]
Product revenue in the EMEA segment decreased by 14%, with declines across all of our customer segments. Product revenue from emerging countries within EMEA decreased by 16% and product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, decreased by 13%. From a country perspective, product revenue decreased by 5% in Germany, 12% in United Kingdom and 17% in France.

[0000858877-20-000015:mdna:92]
[same as prior period, unchanged from 0000858877-20-000006:mdna:122]

[0000858877-20-000015:mdna:93]
Product revenue in the APJC segment decreased by 12%, driven by declines across all customer segments. From a country perspective, product revenue decreased in Australia, China and India by 15%, 28%, and 36%, respectively, partially offset by a product revenue increase in Japan of 13%.

[0000858877-20-000015:mdna:94]
[same as prior period, unchanged from 0000858877-20-000006:mdna:130]

[0000858877-20-000015:mdna:95]
[same as prior period, unchanged from 0000858877-20-000006:mdna:131]

[0000858877-20-000015:mdna:96]
[same as prior period, unchanged from 0000858877-20-000006:mdna:132]

[0000858877-20-000015:mdna:97]
|  |  | Three Months Ended |
|  |  | October 24,2020 |  | October 26,2019 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 6,341 |  |  | $ | 7,553 |  |  | $ | (1,212) |  |  | (16) | % |
| Applications |  | 1,380 |  |  | 1,499 |  |  | (119) |  |  | (8) | % |
| Security |  | 861 |  |  | 816 |  |  | 45 |  |  | 6 | % |
| Other Products |  | 5 |  |  | 11 |  |  | (6) |  |  | (56) | % |
| Total |  | $ | 8,587 |  |  | $ | 9,878 |  |  | $ | (1,291) |  |  | (13) | % |

[0000858877-20-000015:mdna:98]
[same as prior period, unchanged from 0000858877-20-000006:mdna:134]

[0000858877-20-000015:mdna:99]
[same as prior period, unchanged from 0000858877-20-000006:mdna:105]

[0000858877-20-000015:mdna:100]
[same as prior period, unchanged from 0000858877-20-000006:mdna:106]

[0000858877-20-000015:mdna:101]
Three Months Ended October 24, 2020 Compared with Three Months Ended October 26, 2019

[0000858877-20-000015:mdna:102]
[same as prior period, unchanged from 0000858877-20-000006:mdna:136]

[0000858877-20-000015:mdna:103]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center. Infrastructure Platforms revenue decreased by 16%, or $1.2 billion. This was the product area most impacted by the COVID-19 pandemic environment. Switching revenue declined in both campus switching and data center switching, although we had revenue growth in our intent-based networking Catalyst 9000 Series. We experienced a decrease in sales of routing products, with declines primarily in the service provider and enterprise markets. We experienced a revenue decline from wireless products, although we saw revenue growth in our WiFi6 products. Revenue from data center declined primarily driven by our servers products.

[0000858877-20-000015:mdna:104]
[same as prior period, unchanged from 0000858877-20-000006:mdna:141]

[0000858877-20-000015:mdna:105]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as the Internet of Things (IoT) and AppDynamics analytics software offerings. Revenue in our Applications product category decreased by 8%, or $119 million, with a decline in Unified Communications and Cisco TelePresence partially offset by growth in Webex.

[0000858877-20-000015:mdna:106]
[same as prior period, unchanged from 0000858877-20-000006:mdna:149]

[0000858877-20-000015:mdna:107]
Revenue in our Security product category increased 6%, or $45 million. Our cloud security portfolio reflected strong double-digit growth and continued momentum with our Duo and Umbrella offerings.

[0000858877-20-000015:mdna:108]
[same as prior period, unchanged from 0000858877-20-000006:mdna:156]

[0000858877-20-000015:mdna:109]
[same as prior period, unchanged from 0000858877-20-000006:mdna:157]

[0000858877-20-000015:mdna:110]
|  |  | Three Months Ended |
|  |  | October 24,2020 |  | October 26,2019 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,070 |  |  | $ | 2,070 |  |  | $ | — |  |  | — | % |
| Percentage of service revenue |  | 61.9 | % |  | 63.1 | % |  |  |  |  |
| EMEA |  | 754 |  |  | 726 |  |  | 28 |  |  | 4 | % |
| Percentage of service revenue |  | 22.6 | % |  | 22.1 | % |  |  |  |  |
| APJC |  | 519 |  |  | 486 |  |  | 33 |  |  | 7 | % |
| Percentage of service revenue |  | 15.5 | % |  | 14.8 | % |  |  |  |  |
| Total |  | $ | 3,342 |  |  | $ | 3,281 |  |  | $ | 61 |  |  | 2 | % |

[0000858877-20-000015:mdna:111]
[same as prior period, unchanged from 0000858877-20-000006:mdna:159]

[0000858877-20-000015:mdna:112]
Service revenue increased 2% in the first quarter of fiscal 2021, driven by an increase in software and solution support offerings. Service revenue increased in the EMEA and APJC segments. Service revenue was flat in the Americas segment.

[0000858877-20-000015:mdna:113]
[same as prior period, unchanged from 0000858877-20-000006:mdna:126]

[0000858877-20-000015:mdna:114]
[same as prior period, unchanged from 0000858877-20-000006:mdna:127]

[0000858877-20-000015:mdna:115]
[same as prior period, unchanged from 0000858877-20-000006:mdna:163]

[0000858877-20-000015:mdna:116]
[same as prior period, unchanged from 0000858877-20-000006:mdna:164]

[0000858877-20-000015:mdna:117]
|  |  | Three Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |
|  |  | October 24,2020 |  | October 26,2019 |  | October 24,2020 |  | October 26,2019 |
| Gross margin: |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,381 |  |  | $ | 6,354 |  |  | 62.7 | % |  | 64.3 | % |
| Service |  | 2,200 |  |  | 2,110 |  |  | 65.8 | % |  | 64.3 | % |
| Total |  | $ | 7,581 |  |  | $ | 8,464 |  |  | 63.6 | % |  | 64.3 | % |

[0000858877-20-000015:mdna:118]
[same as prior period, unchanged from 0000858877-20-000006:mdna:166]

[0000858877-20-000015:mdna:119]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the first quarter of fiscal 2021 as compared with the corresponding prior year period:

[0000858877-20-000015:mdna:120]
|  |  | Product Gross Margin Percentage |
| Fiscal 2020 |  | 64.3 | % |
| Productivity (1) |  | (0.3) | % |
| Product pricing |  | (1.8) | % |
| Mix of products sold |  | 1.4 | % |
| Legal and indemnification charge |  | (0.5) | % |
| Others |  | (0.4) | % |
| Fiscal 2021 |  | 62.7 | % |

[0000858877-20-000015:mdna:121]
[same as prior period, unchanged from 0000858877-20-000006:mdna:169]

[0000858877-20-000015:mdna:122]
Three Months Ended October 24, 2020 Compared with Three Months Ended October 26, 2019

[0000858877-20-000015:mdna:123]
Product gross margin decreased by 1.6 percentage points driven by unfavorable impacts from product pricing and to a lesser extent, productivity, partially offset by favorable product mix. In the first quarter of fiscal 2021, as a result of the COVID-19 pandemic, we continued to incur additional logistics costs, such as freight which had a negative impact on product gross margin. The negative pricing impact was driven by typical market factors and impacted each of our geographic segments. The favorable product mix impact was driven by impacts from each of our product categories.

[0000858877-20-000015:mdna:124]
[same as prior period, unchanged from 0000858877-20-000006:mdna:175]

[0000858877-20-000015:mdna:125]
Three Months Ended October 24, 2020 Compared with Three Months Ended October 26, 2019

[0000858877-20-000015:mdna:126]
Our service gross margin percentage increased by 1.5 percentage points primarily due to higher sales volume, lower headcount-related and delivery costs and a favorable mix of service offerings.

[0000858877-20-000015:mdna:127]
[same as prior period, unchanged from 0000858877-20-000006:mdna:178]

[0000858877-20-000015:mdna:128]
[same as prior period, unchanged from 0000858877-20-000006:mdna:145]

[0000858877-20-000015:mdna:129]
[same as prior period, unchanged from 0000858877-20-000006:mdna:146]

[0000858877-20-000015:mdna:130]
[same as prior period, unchanged from 0000858877-20-000006:mdna:183]

[0000858877-20-000015:mdna:131]
[same as prior period, unchanged from 0000858877-20-000006:mdna:184]

[0000858877-20-000015:mdna:132]
|  | Three Months Ended |
|  | AMOUNT |  | PERCENTAGE |
|  | October 24,2020 |  | October 26,2019 |  | October 24,2020 |  | October 26,2019 |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,847 |  |  | $ | 5,316 |  |  | 67.3 | % |  | 66.6 | % |
| EMEA | 1,894 |  |  | 2,166 |  |  | 63.9 | % |  | 66.0 | % |
| APJC | 1,113 |  |  | 1,194 |  |  | 63.0 | % |  | 62.9 | % |
| Segment total | 7,853 |  |  | 8,676 |  |  | 65.8 | % |  | 65.9 | % |
| Unallocated corporate items (1) | (272) |  |  | (212) |  |  |  |  |  |
| Total | $ | 7,581 |  |  | $ | 8,464 |  |  | 63.6 | % |  | 64.3 | % |

[0000858877-20-000015:mdna:133]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-20-000015:mdna:134]
[same as prior period, unchanged from 0000858877-20-000006:mdna:187]

[0000858877-20-000015:mdna:135]
Three Months Ended October 24, 2020 Compared with Three Months Ended October 26, 2019

[0000858877-20-000015:mdna:136]
We experienced a gross margin percentage increase in our Americas segment due to favorable impacts from product mix, partially offset by unfavorable impacts from pricing and productivity. Higher service gross margin also contributed to the increase in the gross margin in the Americas segment.

[0000858877-20-000015:mdna:137]
Gross margin in our EMEA segment decreased due to negative impacts from pricing and productivity, partially offset by favorable product mix.

[0000858877-20-000015:mdna:138]
The APJC segment gross margin percentage increase was due to favorable impacts from productivity improvements and to a lesser extent, from product mix, partially offset by negative impacts from pricing. Higher service gross margin also contributed to the increase in the gross margin in this geographic segment.

[0000858877-20-000015:mdna:139]
[same as prior period, unchanged from 0000858877-20-000006:mdna:192]

[0000858877-20-000015:mdna:140]
[same as prior period, unchanged from 0000858877-20-000006:mdna:199]

[0000858877-20-000015:mdna:141]
[same as prior period, unchanged from 0000858877-20-000006:mdna:200]

[0000858877-20-000015:mdna:142]
|  | Three Months Ended |
|  | October 24,2020 |  | October 26,2019 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,612 |  |  | $ | 1,666 |  |  | $ | (54) |  |  | (3) | % |
| Percentage of revenue | 13.5 | % |  | 12.7 | % |  |  |  |  |
| Sales and marketing | 2,217 |  |  | 2,480 |  |  | (263) |  |  | (11) | % |
| Percentage of revenue | 18.6 | % |  | 18.8 | % |  |  |  |  |
| General and administrative | 544 |  |  | 519 |  |  | 25 |  |  | 5 | % |
| Percentage of revenue | 4.6 | % |  | 3.9 | % |  |  |  |  |
| Total | $ | 4,373 |  |  | $ | 4,665 |  |  | $ | (292) |  |  | (6) | % |
| Percentage of revenue | 36.7 | % |  | 35.5 | % |  |  |  |  |

[0000858877-20-000015:mdna:143]
[same as prior period, unchanged from 0000858877-20-000006:mdna:90]

[0000858877-20-000015:mdna:144]
[same as prior period, unchanged from 0000858877-20-000006:mdna:161]

[0000858877-20-000015:mdna:145]
[same as prior period, unchanged from 0000858877-20-000006:mdna:162]

[0000858877-20-000015:mdna:146]
Three Months Ended October 24, 2020 Compared with Three Months Ended October 26, 2019

[0000858877-20-000015:mdna:147]
[same as prior period, unchanged from 0000858877-20-000006:mdna:202]

[0000858877-20-000015:mdna:148]
R&D expenses decreased due to lower discretionary spending and lower headcount-related expenses, partially offset by higher contracted services spending.

[0000858877-20-000015:mdna:149]
[same as prior period, unchanged from 0000858877-20-000006:mdna:205]

[0000858877-20-000015:mdna:150]
[same as prior period, unchanged from 0000858877-20-000006:mdna:208]

[0000858877-20-000015:mdna:151]
Sales and marketing expenses decreased primarily due to lower discretionary spending and lower headcount-related expenses, partially offset by higher contracted services spending.

[0000858877-20-000015:mdna:152]
[same as prior period, unchanged from 0000858877-20-000006:mdna:213]

[0000858877-20-000015:mdna:153]
G&A expenses increased due to higher contracted services spending, partially offset by lower discretionary spending and lower headcount-related expenses.

[0000858877-20-000015:mdna:154]
[same as prior period, unchanged from 0000858877-20-000006:mdna:218]

[0000858877-20-000015:mdna:155]
In the first quarter of fiscal 2021, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $15 million, or 0.3%, compared with the first quarter of fiscal 2020.

[0000858877-20-000015:mdna:156]
[same as prior period, unchanged from 0000858877-20-000006:mdna:223]

[0000858877-20-000015:mdna:157]
[same as prior period, unchanged from 0000858877-20-000006:mdna:224]

[0000858877-20-000015:mdna:158]
|  |  | Three Months Ended |
|  |  | October 24,2020 |  | October 26,2019 |
| Amortization of purchased intangible assets: |  |  |  |  |
| Cost of sales |  | $ | 170 |  |  | $ | 166 |  |
| Operating expenses |  | 36 |  |  | 36 |  |
| Total |  | $ | 206 |  |  | $ | 202 |  |

[0000858877-20-000015:mdna:159]
Three Months Ended October 24, 2020 Compared with Three Months Ended October 26, 2019

[0000858877-20-000015:mdna:160]
The increase in amortization of purchased intangible assets in the first quarter of fiscal 2021 was due largely to the amortization of purchased intangibles from our recent acquisitions.

[0000858877-20-000015:mdna:161]
[same as prior period, unchanged from 0000858877-20-000006:mdna:230]

[0000858877-20-000015:mdna:162]
In the first quarter of fiscal 2021, we initiated a restructuring plan, which includes a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $900 million. In connection with this restructuring plan, we incurred charges of $602 million for the first quarter of fiscal 2021. We expect the plan to be substantially completed in fiscal 2021 and estimate it will generate cost savings of approximately $1.0 billion on an annualized basis over the next few quarters.

[0000858877-20-000015:mdna:163]
We initiated a restructuring plan during fiscal 2020 in order to realign the organization and enable further investment in key priority areas. In connection with this restructuring plan, we have incurred cumulative charges of $255 million. We expect this restructuring plan to be substantially completed in fiscal 2021.

[0000858877-20-000015:mdna:164]
[same as prior period, unchanged from 0000858877-20-000006:mdna:179]

[0000858877-20-000015:mdna:165]
[same as prior period, unchanged from 0000858877-20-000006:mdna:180]

[0000858877-20-000015:mdna:166]
[same as prior period, unchanged from 0000858877-20-000006:mdna:235]

[0000858877-20-000015:mdna:167]
[same as prior period, unchanged from 0000858877-20-000006:mdna:236]

[0000858877-20-000015:mdna:168]
|  |  | Three Months Ended |
|  |  | October 24,2020 |  | October 26,2019 |
| Operating income |  | $ | 2,570 |  |  | $ | 3,579 |  |
| Operating income as a percentage of revenue |  | 21.5 | % |  | 27.2 | % |

[0000858877-20-000015:mdna:169]
Three Months Ended October 24, 2020 Compared with Three Months Ended October 26, 2019

[0000858877-20-000015:mdna:170]
Operating income decreased by 28%, and as a percentage of revenue operating income decreased by 5.7 percentage points. These changes resulted primarily from a revenue decrease, higher restructuring and other charges and by a gross margin percentage decrease (driven by unfavorable impacts from pricing and to a lesser extent, productivity, offset by favorable product mix).

[0000858877-20-000015:mdna:171]
[same as prior period, unchanged from 0000858877-20-000006:mdna:244]

[0000858877-20-000015:mdna:172]
[same as prior period, unchanged from 0000858877-20-000006:mdna:245]

[0000858877-20-000015:mdna:173]
|  |  | Three Months Ended |
|  |  | October 24,2020 |  | October 26,2019 |  | Variancein Dollars |
| Interest income |  | $ | 174 |  |  | $ | 273 |  |  | $ | (99) |  |
| Interest expense |  | (112) |  |  | (178) |  |  | 66 |  |
| Interest income (expense), net |  | $ | 62 |  |  | $ | 95 |  |  | $ | (33) |  |

[0000858877-20-000015:mdna:174]
Three Months Ended October 24, 2020 Compared with Three Months Ended October 26, 2019

[0000858877-20-000015:mdna:175]
Interest income decreased driven by a lower average balance of cash and available-for-sale debt investments and lower interest rates. The decrease in interest expense was driven by a lower average debt balance and the impact of lower effective interest rates.

[0000858877-20-000015:mdna:176]
[same as prior period, unchanged from 0000858877-20-000006:mdna:248]

[0000858877-20-000015:mdna:177]
|  |  | Three Months Ended |
|  |  | October 24,2020 |  | October 26,2019 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | 15 |  |  | $ | 10 |  |  | $ | 5 |  |
| Marketable equity investments |  | (1) |  |  | — |  |  | (1) |  |
| Non-marketable equity and other investments |  | 42 |  |  | 10 |  |  | 32 |  |
| Net gains (losses) on investments |  | 56 |  |  | 20 |  |  | 36 |  |
| Other gains (losses), net |  | (7) |  |  | (8) |  |  | 1 |  |
| Other income (loss), net |  | $ | 49 |  |  | $ | 12 |  |  | $ | 37 |  |

[0000858877-20-000015:mdna:178]
Three Months Ended October 24, 2020 Compared with Three Months Ended October 26, 2019

[0000858877-20-000015:mdna:179]
The total change in net gains (losses) on available-for-sale debt investments was primarily attributable to higher realized gains as a result of market conditions, and the timing of sales of these investments. The change in net gains (losses) on non-marketable equity and other investments was primarily due to higher net unrealized gains and lower impairment charges, offset by lower net realized gains.

[0000858877-20-000015:mdna:180]
[same as prior period, unchanged from 0000858877-20-000006:mdna:197]

[0000858877-20-000015:mdna:181]
[same as prior period, unchanged from 0000858877-20-000006:mdna:198]

[0000858877-20-000015:mdna:182]
[same as prior period, unchanged from 0000858877-20-000006:mdna:254]

[0000858877-20-000015:mdna:183]
Three Months Ended October 24, 2020 Compared with Three Months Ended October 26, 2019

[0000858877-20-000015:mdna:184]
The provision for income taxes resulted in an effective tax rate of 18.9% for the first quarter of fiscal 2021 compared with 20.6% for the first quarter of fiscal 2020. The decrease in the effective tax rate was primarily due to an increase in foreign derived intangible income deduction offset by a decrease in tax benefits from foreign income taxed at other than U.S. rates in fiscal 2021 as compared to fiscal 2020.

[0000858877-20-000015:mdna:185]
[same as prior period, unchanged from 0000858877-20-000006:mdna:257]

[0000858877-20-000015:mdna:186]
[same as prior period, unchanged from 0000858877-20-000006:mdna:221]

[0000858877-20-000015:mdna:187]
[same as prior period, unchanged from 0000858877-20-000006:mdna:222]

[0000858877-20-000015:mdna:188]
[same as prior period, unchanged from 0000858877-20-000006:mdna:266]

[0000858877-20-000015:mdna:189]
[same as prior period, unchanged from 0000858877-20-000006:mdna:267]

[0000858877-20-000015:mdna:190]
[same as prior period, unchanged from 0000858877-20-000006:mdna:268]

[0000858877-20-000015:mdna:191]
[same as prior period, unchanged from 0000858877-20-000006:mdna:269]

[0000858877-20-000015:mdna:192]
|  | October 24,2020 |  | July 25,2020 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 10,822 |  |  | $ | 11,809 |  |  | $ | (987) |  |
| Available-for-sale debt investments | 19,190 |  |  | 17,610 |  |  | 1,580 |  |
| Total | $ | 30,012 |  |  | $ | 29,419 |  |  | $ | 593 |  |

[0000858877-20-000015:mdna:193]
The net increase in cash and cash equivalents and investments in the first quarter of fiscal 2021 was primarily driven by cash provided by operating activities of $4.1 billion. This source of cash was partially offset by cash returned to shareholders in the form of repurchases of common stock of $0.8 billion and cash dividends of $1.5 billion; net cash paid for acquisitions and divestitures of $0.8 billion and capital expenditures of $0.2 billion.

[0000858877-20-000015:mdna:194]
In addition to cash requirements in the normal course of business, on July 9, 2019 we announced our intent to acquire Acacia for a net purchase consideration of approximately $2.6 billion in cash. Additionally, approximately $0.7 billion of the U.S. transition tax on accumulated earnings for foreign subsidiaries is payable in less than one year. Also, $5.0 billion of long-term debt outstanding at October 24, 2020 will mature within the next 12 months from the balance sheet date. See further discussion of liquidity under “Liquidity and Capital Resource Requirements” below.

[0000858877-20-000015:mdna:195]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our available-for-sale debt investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position is critical at this time of uncertainty due to the COVID-19 pandemic and allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-20-000015:mdna:196]
[same as prior period, unchanged from 0000858877-20-000006:mdna:274]

[0000858877-20-000015:mdna:197]
[same as prior period, unchanged from 0000858877-20-000006:mdna:275]

[0000858877-20-000015:mdna:198]
[same as prior period, unchanged from 0000858877-20-000006:mdna:276]

[0000858877-20-000015:mdna:199]
|  | Three Months Ended |
|  | October 24,2020 |  | October 26,2019 |
| Net cash provided by operating activities | $ | 4,096 |  |  | $ | 3,587 |  |
| Acquisition of property and equipment | (171) |  |  | (202) |  |
| Free cash flow | $ | 3,925 |  |  | $ | 3,385 |  |

[0000858877-20-000015:mdna:200]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue, and the timing and amount of tax and other payments. For additional discussion, see “Part II, Item 1A. Risk Factors” in this report.

[0000858877-20-000015:mdna:201]
[same as prior period, unchanged from 0000858877-20-000006:mdna:242]

[0000858877-20-000015:mdna:202]
[same as prior period, unchanged from 0000858877-20-000006:mdna:243]

[0000858877-20-000015:mdna:203]
[same as prior period, unchanged from 0000858877-20-000006:mdna:282]

[0000858877-20-000015:mdna:204]
[same as prior period, unchanged from 0000858877-20-000006:mdna:283]

[0000858877-20-000015:mdna:205]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |  |
| October 24, 2020 |  | $ | 0.36 |  |  | $ | 1,520 |  |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |  | $ | 2,320 |  |
| Fiscal 2020 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 25, 2020 |  | $ | 0.36 |  |  | $ | 1,525 |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,525 |  |
| April 25, 2020 |  | $ | 0.36 |  |  | $ | 1,519 |  |  | 25 |  |  | $ | 39.71 |  |  | $ | 981 |  |  | $ | 2,500 |  |
| January 25, 2020 |  | $ | 0.35 |  |  | $ | 1,486 |  |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |  | $ | 2,356 |  |
| October 26, 2019 |  | $ | 0.35 |  |  | $ | 1,486 |  |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |  | $ | 2,254 |  |

[0000858877-20-000015:mdna:206]
[same as prior period, unchanged from 0000858877-20-000006:mdna:285]

[0000858877-20-000015:mdna:207]
The remaining authorized amount for stock repurchases under this program is approximately $10.0 billion, with no termination date.

[0000858877-20-000015:mdna:208]
Accounts Receivable, Net  The following table summarizes our accounts receivable, net (in millions):

[0000858877-20-000015:mdna:209]
|  | October 24,2020 |  | July 25,2020 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 3,980 |  |  | $ | 5,472 |  |  | $ | (1,492) |  |

[0000858877-20-000015:mdna:210]
Our accounts receivable net, as of October 24, 2020 decreased by approximately 27%, as compared with the end of fiscal 2020, primarily due to timing and amount of product and service billings in the first quarter of fiscal 2021 compared with the fourth quarter of fiscal 2020.

[0000858877-20-000015:mdna:211]
[same as prior period, unchanged from 0000858877-20-000006:mdna:290]

[0000858877-20-000015:mdna:212]
|  | October 24,2020 |  | July 25,2020 |  | Increase (Decrease) |
| Inventories | $ | 1,303 |  |  | $ | 1,282 |  |  | $ | 21 |  |
| Purchase commitments with contract manufacturers and suppliers | $ | 4,189 |  |  | $ | 4,406 |  |  | $ | (217) |  |

[0000858877-20-000015:mdna:213]
Inventory as of October 24, 2020 increased by 2% from our inventory balance at the end of fiscal 2020. The increase in inventory was primarily due to an increase in finished goods, partially offset by a decrease in raw materials. Purchase commitments with contract manufacturers and suppliers decreased 5% compared to the end of fiscal 2020. On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers decreased 3% compared with the end of fiscal 2020. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-20-000015:mdna:214]
[same as prior period, unchanged from 0000858877-20-000006:mdna:295]

[0000858877-20-000015:mdna:215]
[same as prior period, unchanged from 0000858877-20-000006:mdna:259]

[0000858877-20-000015:mdna:216]
[same as prior period, unchanged from 0000858877-20-000006:mdna:260]

[0000858877-20-000015:mdna:217]
[same as prior period, unchanged from 0000858877-20-000006:mdna:296]

[0000858877-20-000015:mdna:218]
[same as prior period, unchanged from 0000858877-20-000006:mdna:297]

[0000858877-20-000015:mdna:219]
[same as prior period, unchanged from 0000858877-20-000006:mdna:298]

[0000858877-20-000015:mdna:220]
|  | October 24,2020 |  | July 25,2020 |  | Increase (Decrease) |
| Lease receivables, net | $ | 2,031 |  |  | $ | 2,088 |  |  | $ | (57) |  |
| Loan receivables, net | 5,853 |  |  | 5,856 |  |  | (3) |  |
| Financed service contracts, net | 2,737 |  |  | 2,821 |  |  | (84) |  |
| Total, net | $ | 10,621 |  |  | $ | 10,765 |  |  | $ | (144) |  |

[0000858877-20-000015:mdna:221]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services. The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed. Financing receivables decreased by 1%.

[0000858877-20-000015:mdna:222]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements to customers provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, with payment terms generally ranging from 60 to 90 days. During fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-20-000015:mdna:223]
The volume of channel partner financing was $6.1 billion and $7.6 billion for the first quarter of fiscal 2021 and 2020, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.1 billion as of October 24, 2020 and July 25, 2020, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of October 24, 2020, the total maximum potential future payments related to these guarantees was approximately $201 million, of which approximately $33 million was recorded as deferred revenue.

[0000858877-20-000015:mdna:224]
[same as prior period, unchanged from 0000858877-20-000006:mdna:264]

[0000858877-20-000015:mdna:225]
[same as prior period, unchanged from 0000858877-20-000006:mdna:265]

[0000858877-20-000015:mdna:226]
[same as prior period, unchanged from 0000858877-20-000006:mdna:306]

[0000858877-20-000015:mdna:227]
[same as prior period, unchanged from 0000858877-20-000006:mdna:307]

[0000858877-20-000015:mdna:228]
|  | Maturity Date |  | October 24,2020 |  | July 25,2020 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | 2,500 |  |  | $ | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 14,500 |  |  | $ | 14,500 |  |

[0000858877-20-000015:mdna:229]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of October 24, 2020.

[0000858877-20-000015:mdna:230]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of October 24, 2020 and July 25, 2020.

[0000858877-20-000015:mdna:231]
Credit Facility  On May 15, 2020, we entered into a 364-day credit agreement with certain institutional lenders that provides for a $2.75 billion unsecured revolving credit facility that is scheduled to expire on May 14, 2021. The credit agreement is structured as an amendment and restatement of our five-year credit facility which would have terminated on May 15, 2020, the end of its five-year term. As of October 24, 2020, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than 0.25%. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion. This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

[0000858877-20-000015:mdna:232]
[same as prior period, unchanged from 0000858877-20-000006:mdna:314]

[0000858877-20-000015:mdna:233]
|  | October 24,2020 |  | July 25,2020 |  | Increase (Decrease) |
| Product | $ | 8,139 |  |  | $ | 7,895 |  |  | $ | 244 |  |
| Service | 12,334 |  |  | 12,551 |  |  | (217) |  |
| Total | $ | 20,473 |  |  | $ | 20,446 |  |  | $ | 27 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 11,271 |  |  | $ | 11,406 |  |  | $ | (135) |  |
| Noncurrent | 9,202 |  |  | 9,040 |  |  | 162 |  |
| Total | $ | 20,473 |  |  | $ | 20,446 |  |  | $ | 27 |  |

[0000858877-20-000015:mdna:234]
56

[0000858877-20-000015:mdna:235]
[same as prior period, unchanged from 0000858877-20-000006:mdna:279]

[0000858877-20-000015:mdna:236]
[same as prior period, unchanged from 0000858877-20-000006:mdna:280]

[0000858877-20-000015:mdna:237]
[same as prior period, unchanged from 0000858877-20-000006:mdna:316]

[0000858877-20-000015:mdna:238]
Remaining Performance Obligations   The following table presents the breakdown of remaining performance obligations (in millions):

[0000858877-20-000015:mdna:239]
|  | October 24,2020 |  | July 25,2020 |  | Increase (Decrease) |
| Product | $ | 11,340 |  |  | $ | 11,261 |  |  | $ | 79 |  |
| Service | 16,129 |  |  | 17,093 |  |  | (964) |  |
| Total | $ | 27,469 |  |  | $ | 28,354 |  |  | $ | (885) |  |

[0000858877-20-000015:mdna:240]
Total remaining performance obligations decreased 3% in the first quarter of fiscal 2021 compared to the end of fiscal 2020. Remaining performance obligations for product increased 1% compared to the end of fiscal 2020. Remaining performance obligations for service decreased 6%.

[0000858877-20-000015:mdna:241]
[same as prior period, unchanged from 0000858877-20-000006:mdna:317]

[0000858877-20-000015:mdna:242]
[same as prior period, unchanged from 0000858877-20-000006:mdna:318]

[0000858877-20-000015:mdna:243]
The income tax payable outstanding as of October 24, 2020 for the U.S. transition tax on accumulated earnings for foreign subsidiaries is $7.6 billion. Approximately $0.7 billion is payable in less than one year; $1.4 billion is payable between 1 to 3 years; $3.2 billion is payable between 3 to 5 years; and the remaining $2.3 billion is payable in more than 5 years.

[0000858877-20-000015:mdna:244]
For our Contractual Obligations see our Annual Report on Form 10-K for the year ended July 25, 2020.

[0000858877-20-000015:mdna:245]
[same as prior period, unchanged from 0000858877-20-000006:mdna:321]

[0000858877-20-000015:mdna:246]
[same as prior period, unchanged from 0000858877-20-000006:mdna:322]

[0000858877-20-000015:mdna:247]
We also have certain funding commitments primarily related to our non-marketable equity and other investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.3 billion as of each of October 24, 2020 and July 25, 2020.

[0000858877-20-000015:mdna:248]
[same as prior period, unchanged from 0000858877-20-000006:mdna:324]

[0000858877-20-000015:mdna:249]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have non-marketable equity and other investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our non-marketable equity and other investments and customer financings, and we have determined that as of October 24, 2020 there were no material unconsolidated variable interest entities.

[0000858877-20-000015:mdna:250]
[same as prior period, unchanged from 0000858877-20-000006:mdna:326]

[0000858877-20-000015:mdna:251]
[same as prior period, unchanged from 0000858877-20-000006:mdna:327]

[0000858877-20-000015:mdna:252]
[same as prior period, unchanged from 0000858877-20-000006:mdna:328]

[0000858877-20-000015:mdna:253]
While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to increased disruption and volatility in capital markets and credit markets. The pandemic and resulting economic uncertainty could adversely affect our liquidity and capital resources in the future. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions,

[0000858877-20-000015:mdna:254]
[same as prior period, unchanged from 0000858877-20-000006:mdna:293]

[0000858877-20-000015:mdna:255]
[same as prior period, unchanged from 0000858877-20-000006:mdna:294]

[0000858877-20-000015:mdna:256]
arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.

[0000858877-20-000015:mdna:257]
[same as prior period, unchanged from 0000858877-20-000006:mdna:258]
