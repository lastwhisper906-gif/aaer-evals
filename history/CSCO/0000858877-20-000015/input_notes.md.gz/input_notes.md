# CSCO notes — 0000858877-20-000015


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-20-000015:notes:1]
Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2021 is a 53-week fiscal year and fiscal 2020 was a 52-week fiscal year. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-20-000015:notes:2]
We have prepared the accompanying financial data as of October 24, 2020 and for the first quarter of fiscal 2021 and 2020, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 25, 2020 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 25, 2020.

[0000858877-20-000015:notes:3]
[same as prior period, unchanged from 0000858877-20-000006:notes:4]

[0000858877-20-000015:notes:4]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 24, 2020, the results of operations, the statements of comprehensive income (loss), the statements of cash flows and the statements of equity for the first quarter of fiscal 2021 and 2020, as applicable, have been made. The results of operations for the first quarter of fiscal 2021 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-20-000015:notes:5]
[same as prior period, unchanged from 0000858877-20-000006:notes:6]

[0000858877-20-000015:notes:6]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-20-000015:notes:7]
Recent Accounting Pronouncements
(a)New Accounting Updates Recently Adopted

[0000858877-20-000015:notes:8]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. We adopted this standard at the beginning of our first quarter of fiscal 2021, applied it at the beginning of the period of adoption and did not restate prior periods. The standard primarily impacts our financial assets measured at amortized cost and available-for-sale debt securities. The standard did not have a material impact on our consolidated financial statements upon adoption.

[0000858877-20-000015:notes:9]
Our significant accounting policies have been updated as a result of adopting this standard are as follows:

[0000858877-20-000015:notes:10]
Allowance for Accounts Receivable, Contract Assets and Financing Receivables     We estimate our allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, we determine collectibility by pooling our assets with similar characteristics.

[0000858877-20-000015:notes:11]
The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. Our internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality. Our assets within each internal credit risk rating share similar risk characteristics and therefore are assessed as one portfolio segment for credit loss. Assets that do not share risk characteristics are evaluated on an individual basis. The allowances for credit losses are each measured by multiplying the exposure probability of default, the probability the asset will default within a given time frame, by the loss given default rate, the percentage of the asset not expected to be collected due to default, based on the pool of assets.

[0000858877-20-000015:notes:12]
Probability of default rates are published quarterly by third-party credit agencies. Adjustments to our internal credit risk ratings may take into account including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000858877-20-000015:notes:13]
Available-for-Sale Debt Investments     For our available-for-sale debt securities in an unrealized loss position, we determine whether a credit loss exists. In this assessment, we consider the extent to which the fair value is less than the amortized cost, any changes to the rating of the security by a rating agency, and adverse conditions specifically related to the security, among other factors. If factors indicate a credit loss exists, an allowance for credit loss is recorded to other income (loss), net, limited by the amount that the fair value is less than the amortized cost basis. The amount of fair value change relating to all other factors will be recognized in other comprehensive income (OCI).


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-20-000015:notes:14]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

[0000858877-20-000015:notes:15]
[same as prior period, unchanged from 0000858877-20-000006:notes:20]

[0000858877-20-000015:notes:16]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 24, 2020 and July 25, 2020 was $81 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-20-000015:notes:17]
[same as prior period, unchanged from 0000858877-20-000006:notes:21]

[0000858877-20-000015:notes:18]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-20-000015:notes:19]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

[0000858877-20-000015:notes:20]
[same as prior period, unchanged from 0000858877-20-000006:notes:25]

[0000858877-20-000015:notes:21]
(a)Disaggregation of Revenue

[0000858877-20-000015:notes:22]
[same as prior period, unchanged from 0000858877-20-000006:notes:27]

[0000858877-20-000015:notes:23]
|  | Three Months Ended |
|  | October 24,2020 |  | October 26,2019 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 6,341 |  |  | $ | 7,553 |  |
| Applications | 1,380 |  |  | 1,499 |  |
| Security | 861 |  |  | 816 |  |
| Other Products | 5 |  |  | 11 |  |
| Total Product | 8,587 |  |  | 9,878 |  |
| Services | 3,342 |  |  | 3,281 |  |
| Total | $ | 11,929 |  |  | $ | 13,159 |  |

[0000858877-20-000015:notes:24]
Amounts may not sum due to rounding. We have made certain reclassifications to the product revenue amounts for prior period to conform to the current year presentation.

[0000858877-20-000015:notes:25]
[same as prior period, unchanged from 0000858877-20-000006:notes:31]

[0000858877-20-000015:notes:26]
Applications consists of offerings that utilize the core networking and data center platforms to provide their functions. The products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon

[0000858877-20-000015:notes:27]
transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-20-000015:notes:28]
[same as prior period, unchanged from 0000858877-20-000006:notes:33]

[0000858877-20-000015:notes:29]
[same as prior period, unchanged from 0000858877-20-000006:notes:34]

[0000858877-20-000015:notes:30]
[same as prior period, unchanged from 0000858877-20-000006:notes:35]

[0000858877-20-000015:notes:31]
[same as prior period, unchanged from 0000858877-20-000006:notes:36]

[0000858877-20-000015:notes:32]
(b)Contract Balances

[0000858877-20-000015:notes:33]
Accounts receivable, net was $4.0 billion as of October 24, 2020 compared to $5.5 billion as of July 25, 2020, as reported on the Consolidated Balance Sheet.

[0000858877-20-000015:notes:34]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $1.2 billion as of October 24, 2020 and July 25, 2020, and were included in other current assets and other assets.

[0000858877-20-000015:notes:35]
Gross contract assets by our internal risk ratings are summarized as follows (in millions):

[0000858877-20-000015:notes:36]
|  | October 24,2020 |
| 1 to 4 | $ | 442 |  |
| 5 to 6 | 737 |  |
| 7 and Higher | 119 |  |
| Total | $ | 1,298 |  |

[0000858877-20-000015:notes:37]
Contract liabilities consist of deferred revenue. Deferred revenue was $20.5 billion as of October 24, 2020 compared to $20.4 billion as of July 25, 2020. We recognized approximately $3.9 billion of revenue during the first quarter of fiscal 2021, that was included in the deferred revenue balance at July 25, 2020.

[0000858877-20-000015:notes:38]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $771 million and $732 million as of October 24, 2020 and July 25, 2020, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $123 million and $116 million for the first quarter of fiscal 2021 and 2020, respectively, and was included in sales and marketing expenses.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-20-000015:notes:39]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-20-000015:notes:40]
[same as prior period, unchanged from 0000858877-20-000006:notes:45]

[0000858877-20-000015:notes:41]
[same as prior period, unchanged from 0000858877-20-000006:notes:46]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-20-000015:notes:42]
Acquisitions and Divestitures
We completed three acquisitions during the first quarter of fiscal 2021. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-20-000015:notes:43]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions (three in total) | $ | 878 |  |  | $ | 2 |  |  | $ | 210 |  |  | $ | 666 |  |

[0000858877-20-000015:notes:44]
The total purchase consideration related to our acquisitions completed during the first quarter of fiscal 2021 consisted of cash consideration. The total cash and cash equivalents acquired from these acquisitions was approximately $34 million. Total transaction costs related to acquisition and divestiture activities were $4 million and $5 million for the first quarter of fiscal 2021 and 2020, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-20-000015:notes:45]
The goodwill generated from acquisitions completed during the first quarter of fiscal 2021 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-20-000015:notes:46]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first quarter of fiscal 2021 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.

[0000858877-20-000015:notes:47]
Pending Acquisition of Acacia Communications  On July 9, 2019, we announced our intent to acquire Acacia Communications, Inc. (“Acacia”), a public fabless semiconductor company that develops, manufactures and sells high-speed coherent optical interconnect products that are designed to transform communications networks through improvements in performance, capacity and cost.

[0000858877-20-000015:notes:48]
Under the terms of the agreement, we have agreed to pay total consideration of approximately $2.6 billion, net of cash and marketable securities, to acquire Acacia. The acquisition is expected to close during the first half of fiscal 2021, subject to customary closing conditions and regulatory approvals. Upon close of the acquisition, revenue from Acacia will be included in our Infrastructure Platforms product category.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-20-000015:notes:49]
Goodwill and Purchased Intangible Assets 
(a)Goodwill

[0000858877-20-000015:notes:50]
The following table presents the goodwill allocated to our reportable segments as of October 24, 2020 and during the first quarter of fiscal 2021 (in millions):

[0000858877-20-000015:notes:51]
|  | Balance at July 25, 2020 |  | Acquisitions |  | Foreign Currency Translation and Other |  | Balance at October 24, 2020 |
| Americas | $ | 21,304 |  |  | $ | 393 |  |  | $ | 40 |  |  | $ | 21,737 |  |
| EMEA | 8,040 |  |  | 183 |  |  | 15 |  |  | 8,238 |  |
| APJC | 4,462 |  |  | 90 |  |  | 8 |  |  | 4,560 |  |
| Total | $ | 33,806 |  |  | $ | 666 |  |  | $ | 63 |  |  | $ | 34,535 |  |

[0000858877-20-000015:notes:52]
(b)Purchased Intangible Assets

[0000858877-20-000015:notes:53]
The following table presents details of our intangible assets acquired through acquisitions completed during the first quarter of fiscal 2021 (in millions, except years):

[0000858877-20-000015:notes:54]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions (three in total) | 3.9 |  | $ | 162 |  |  | 4.0 |  | $ | 42 |  |  | 2.0 |  | $ | 6 |  |  | — |  |  | $ | 210 |  |

[0000858877-20-000015:notes:55]
[same as prior period, unchanged from 0000858877-20-000006:notes:64]

[0000858877-20-000015:notes:56]
| October 24, 2020 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,086 |  |  | $ | (2,104) |  |  | $ | 982 |  |
| Customer relationships |  | 797 |  |  | (393) |  |  | 404 |  |
| Other |  | 14 |  |  | (5) |  |  | 9 |  |
| Total purchased intangible assets with finite lives |  | 3,897 |  |  | (2,502) |  |  | 1,395 |  |
| In-process research and development, with indefinite lives |  | 186 |  |  | — |  |  | 186 |  |
| Total |  | $ | 4,083 |  |  | $ | (2,502) |  |  | $ | 1,581 |  |

[0000858877-20-000015:notes:57]
| July 25, 2020 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,298 |  |  | $ | (2,336) |  |  | $ | 962 |  |
| Customer relationships |  | 760 |  |  | (365) |  |  | 395 |  |
| Other |  | 26 |  |  | (20) |  |  | 6 |  |
| Total purchased intangible assets with finite lives |  | 4,084 |  |  | (2,721) |  |  | 1,363 |  |
| In-process research and development, with indefinite lives |  | 213 |  |  | — |  |  | 213 |  |
| Total |  | $ | 4,297 |  |  | $ | (2,721) |  |  | $ | 1,576 |  |

[0000858877-20-000015:notes:58]
[same as prior period, unchanged from 0000858877-20-000006:notes:67]

[0000858877-20-000015:notes:59]
[same as prior period, unchanged from 0000858877-20-000006:notes:68]

[0000858877-20-000015:notes:60]
|  | Three Months Ended |
|  | October 24, 2020 |  | October 26, 2019 |
| Amortization of purchased intangible assets: |  |  |  |
| Cost of sales | $ | 170 |  |  | $ | 166 |  |
| Operating expenses | 36 |  |  | 36 |  |
| Total | $ | 206 |  |  | $ | 202 |  |

[0000858877-20-000015:notes:61]
The estimated future amortization expense of purchased intangible assets with finite lives as of October 24, 2020 is as follows (in millions):

[0000858877-20-000015:notes:62]
| Fiscal Year | Amount |
| 2021 (remaining nine months) | $ | 487 |  |
| 2022 | $ | 431 |  |
| 2023 | $ | 286 |  |
| 2024 | $ | 170 |  |
| 2025 | $ | 15 |  |
| Thereafter | $ | 6 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-20-000015:notes:63]
Restructuring and Other Charges
We initiated a restructuring plan in the first quarter of fiscal 2021 (the “Fiscal 2021 Plan”), which includes a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $900 million. In connection with the Fiscal 2021 Plan, we incurred charges of $602 million for the first quarter of fiscal 2021.

[0000858877-20-000015:notes:64]
We initiated a restructuring plan in fiscal 2020 (the “Fiscal 2020 Plan”) in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $300 million. In connection with the Fiscal 2020 Plan, we have incurred cumulative charges of $255 million.

[0000858877-20-000015:notes:65]
The aggregate pretax charges related to these plans are primarily cash-based and consist of severance and other one-time termination benefits, and other costs. We expect to substantially complete both plans in fiscal 2021.

[0000858877-20-000015:notes:66]
[same as prior period, unchanged from 0000858877-20-000006:notes:75]

[0000858877-20-000015:notes:67]
|  |  | FISCAL 2020 AND PRIOR PLANS |  | FISCAL 2021 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 25, 2020 |  | $ | 58 |  |  | $ | 14 |  |  | $ | — |  |  | $ | — |  |  | $ | 72 |  |
| Charges |  | — |  |  | — |  |  | 590 |  |  | 12 |  |  | 602 |  |
| Cash payments |  | (58) |  |  | — |  |  | (272) |  |  | — |  |  | (330) |  |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (11) |  |  | (11) |  |
| Liability as of October 24, 2020 |  | $ | — |  |  | $ | 14 |  |  | $ | 318 |  |  | $ | 1 |  |  | $ | 333 |  |

[0000858877-20-000015:notes:68]
|  |  | FISCAL 2018 AND PRIOR PLANS |  |  |
|  |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 27, 2019 |  | $ | 22 |  |  | $ | 11 |  |  | $ | 33 |  |
| Charges |  | 175 |  |  | 9 |  |  | 184 |  |
| Cash payments |  | (154) |  |  | (1) |  |  | (155) |  |
| Non-cash items |  | — |  |  | (15) |  |  | (15) |  |
| Liability as of October 26, 2019 |  | $ | 43 |  |  | $ | 4 |  |  | $ | 47 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-20-000015:notes:69]
Balance Sheet and Other Details 
The following tables provide details of selected balance sheet and other items (in millions):

[0000858877-20-000015:notes:70]
|  |  | October 24,2020 |  | July 25,2020 |
| Cash and cash equivalents |  | $ | 10,822 |  |  | $ | 11,809 |  |
| Restricted cash included in other current assets |  | 3 |  |  | — |  |
| Restricted cash included in other assets |  | — |  |  | 3 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 10,825 |  |  | $ | 11,812 |  |

[0000858877-20-000015:notes:71]
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 380 |  |  | $ | 456 |  |
| Work in process |  | 19 |  |  | 25 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales |  | 54 |  |  | 59 |  |
| Manufactured finished goods |  | 646 |  |  | 542 |  |
| Total finished goods |  | 700 |  |  | 601 |  |
| Service-related spares |  | 191 |  |  | 184 |  |
| Demonstration systems |  | 13 |  |  | 16 |  |
| Total |  | $ | 1,303 |  |  | $ | 1,282 |  |

[0000858877-20-000015:notes:72]
Our provision for inventory was $29 million and $18 million for the first quarter of fiscal 2021 and 2020, respectively.

[0000858877-20-000015:notes:73]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,273 |  |  | $ | 4,252 |  |
| Computer equipment and related software |  | 872 |  |  | 875 |  |
| Production, engineering, and other equipment |  | 5,157 |  |  | 5,163 |  |
| Operating lease assets |  | 338 |  |  | 337 |  |
| Furniture, fixtures and other |  | 385 |  |  | 387 |  |
| Total gross property and equipment |  | 11,025 |  |  | 11,014 |  |
| Less: accumulated depreciation and amortization |  | (8,613) |  |  | (8,561) |  |
| Total |  | $ | 2,412 |  |  | $ | 2,453 |  |

[0000858877-20-000015:notes:74]
| Deferred revenue: |  |  |  |  |
| Product |  | $ | 8,139 |  |  | $ | 7,895 |  |
| Service |  | 12,334 |  |  | 12,551 |  |
| Total |  | $ | 20,473 |  |  | $ | 20,446 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 11,271 |  |  | $ | 11,406 |  |
| Noncurrent |  | 9,202 |  |  | 9,040 |  |
| Total |  | $ | 20,473 |  |  | $ | 20,446 |  |

[0000858877-20-000015:notes:75]
| Remaining Performance Obligations: |  |  |  |  |
| Product |  | $ | 11,340 |  |  | $ | 11,261 |  |
| Service |  | 16,129 |  |  | 17,093 |  |
| Total |  | $ | 27,469 |  |  | $ | 28,354 |  |

[0000858877-20-000015:notes:76]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of October 24, 2020, the aggregate amount of RPO was comprised of $20.5 billion of deferred revenue and $7.0 billion of unbilled contract revenue. We expect approximately 53% of this amount of be recognized as revenue over the next year. As of July 25, 2020, the aggregate amount of RPO was comprised of $20.4 billion of deferred revenue and $7.9 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000858877-20-000015:notes:77]
Leases 
(a)Lessee Arrangements

[0000858877-20-000015:notes:78]
The following table presents our operating lease balances (in millions):

[0000858877-20-000015:notes:79]
|  | Balance Sheet Line Item |  | October 24, 2020 |  | July 25, 2020 |
| Operating lease right-of-use assets | Other assets |  | $ | 953 |  |  | $ | 921 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 332 |  |  | $ | 341 |  |
| Operating lease liabilities | Other long-term liabilities |  | 695 |  |  | 661 |  |
| Total operating lease liabilities |  |  | $ | 1,027 |  |  | $ | 1,002 |  |

[0000858877-20-000015:notes:80]
The components of our lease expenses were as follows (in millions):

[0000858877-20-000015:notes:81]
|  | Three Months Ended |
|  | October 24, 2020 |  | October 26, 2019 |
| Operating lease expense | $ | 98 |  |  | $ | 113 |  |
| Short-term lease expense | 18 |  |  | 17 |  |
| Variable lease expense | 46 |  |  | 40 |  |
| Total lease expense | $ | 162 |  |  | $ | 170 |  |

[0000858877-20-000015:notes:82]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-20-000015:notes:83]
|  | Three Months Ended |
|  | October 24, 2020 |  | October 26, 2019 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 105 |  |  | $ | 104 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 115 |  |  | $ | 48 |  |

[0000858877-20-000015:notes:84]
The weighted-average lease term was 4.2 years as of each of October 24, 2020 and October 26, 2019. The weighted-average discount rate was 1.3% and 1.9% as of October 24, 2020 and October 26, 2019, respectively.

[0000858877-20-000015:notes:85]
The maturities of our operating leases (undiscounted) as of October 24, 2020 are as follows (in millions):

[0000858877-20-000015:notes:86]
| Fiscal Year | Amount |
| 2021 (remaining nine months) | $ | 272 |  |
| 2022 | 269 |  |
| 2023 | 211 |  |
| 2024 | 136 |  |
| 2025 | 81 |  |
| Thereafter | 87 |  |
| Total lease payments | 1,056 |  |
| Less interest | (29) |  |
| Total | $ | 1,027 |  |

[0000858877-20-000015:notes:87]
(b)Lessor Arrangements

[0000858877-20-000015:notes:88]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income was $21 million and $26 million for the first quarter of fiscal 2021 and 2020, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-20-000015:notes:89]
Future minimum lease payments on our lease receivables as of October 24, 2020 are summarized as follows (in millions):

[0000858877-20-000015:notes:90]
| Fiscal Year | Amount |
| 2021 (remaining nine months) | $ | 670 |  |
| 2022 | 664 |  |
| 2023 | 418 |  |
| 2024 | 202 |  |
| 2025 | 109 |  |
| Total | 2,063 |  |
| Less: Present value of lease payments | 1,958 |  |
| Unearned income | $ | 105 |  |

[0000858877-20-000015:notes:91]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-20-000015:notes:92]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by Cisco and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-20-000015:notes:93]
|  | October 24, 2020 |  | July 25, 2020 |
| Operating lease assets | $ | 338 |  |  | $ | 337 |  |
| Accumulated depreciation | (200) |  |  | (198) |  |
| Operating lease assets, net | $ | 138 |  |  | $ | 139 |  |

[0000858877-20-000015:notes:94]
Our operating lease income was $43 million and $44 million for the first quarter of fiscal 2021 and 2020, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-20-000015:notes:95]
Minimum future rentals on noncancelable operating leases as of October 24, 2020 are summarized as follows (in millions):

[0000858877-20-000015:notes:96]
| Fiscal Year | Amount |
| 2021 (remaining nine months) | $ | 58 |  |
| 2022 | 33 |  |
| 2023 | 12 |  |
| 2024 | 1 |  |
| Total | $ | 104 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-20-000015:notes:97]
Financing Receivables 
(a)Financing Receivables

[0000858877-20-000015:notes:98]
[same as prior period, unchanged from 0000858877-20-000006:notes:111]

[0000858877-20-000015:notes:99]
[same as prior period, unchanged from 0000858877-20-000006:notes:112]

[0000858877-20-000015:notes:100]
| October 24, 2020 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,063 |  |  | $ | 5,954 |  |  | $ | 2,744 |  |  | $ | 10,761 |  |
| Residual value | 119 |  |  | — |  |  | — |  |  | 119 |  |
| Unearned income | (105) |  |  | — |  |  | — |  |  | (105) |  |
| Allowance for credit loss | (46) |  |  | (101) |  |  | (7) |  |  | (154) |  |
| Total, net | $ | 2,031 |  |  | $ | 5,853 |  |  | $ | 2,737 |  |  | $ | 10,621 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 936 |  |  | $ | 2,733 |  |  | $ | 1,436 |  |  | $ | 5,105 |  |
| Noncurrent | 1,095 |  |  | 3,120 |  |  | 1,301 |  |  | 5,516 |  |
| Total, net | $ | 2,031 |  |  | $ | 5,853 |  |  | $ | 2,737 |  |  | $ | 10,621 |  |

[0000858877-20-000015:notes:101]
| July 25, 2020 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,127 |  |  | $ | 5,937 |  |  | $ | 2,830 |  |  | $ | 10,894 |  |
| Residual value | 123 |  |  | — |  |  | — |  |  | 123 |  |
| Unearned income | (114) |  |  | — |  |  | — |  |  | (114) |  |
| Allowance for credit loss | (48) |  |  | (81) |  |  | (9) |  |  | (138) |  |
| Total, net | $ | 2,088 |  |  | $ | 5,856 |  |  | $ | 2,821 |  |  | $ | 10,765 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 918 |  |  | $ | 2,692 |  |  | $ | 1,441 |  |  | $ | 5,051 |  |
| Noncurrent | 1,170 |  |  | 3,164 |  |  | 1,380 |  |  | 5,714 |  |
| Total, net | $ | 2,088 |  |  | $ | 5,856 |  |  | $ | 2,821 |  |  | $ | 10,765 |  |

[0000858877-20-000015:notes:102]
(b)Credit Quality of Financing Receivables

[0000858877-20-000015:notes:103]
Gross financing receivables(1) categorized by our internal credit risk rating by period of origination as of October 24, 2020 are summarized as follows (in millions):

[0000858877-20-000015:notes:104]
|  |  |  | Fiscal Year |  | Three Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 29, 2017 |  | July 28, 2018 |  | July 27, 2019 |  | July 25, 2020 |  | October 24, 2020 |  | Total |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 17 |  |  | $ | 60 |  |  | $ | 166 |  |  | $ | 263 |  |  | $ | 389 |  |  | $ | 25 |  |  | $ | 920 |  |
| 5 to 6 | 17 |  |  | 65 |  |  | 151 |  |  | 300 |  |  | 389 |  |  | 54 |  |  | 976 |  |
| 7 and Higher | 4 |  |  | 3 |  |  | 9 |  |  | 21 |  |  | 21 |  |  | 4 |  |  | 62 |  |
| Total Lease Receivables | $ | 38 |  |  | $ | 128 |  |  | $ | 326 |  |  | $ | 584 |  |  | $ | 799 |  |  | $ | 83 |  |  | $ | 1,958 |  |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 30 |  |  | $ | 170 |  |  | $ | 458 |  |  | $ | 858 |  |  | $ | 1,430 |  |  | $ | 793 |  |  | $ | 3,739 |  |
| 5 to 6 | 16 |  |  | 87 |  |  | 174 |  |  | 456 |  |  | 887 |  |  | 441 |  |  | 2,061 |  |
| 7 and Higher | 3 |  |  | 3 |  |  | 9 |  |  | 72 |  |  | 62 |  |  | 5 |  |  | 154 |  |
| Total Loan Receivables | $ | 49 |  |  | $ | 260 |  |  | $ | 641 |  |  | $ | 1,386 |  |  | $ | 2,379 |  |  | $ | 1,239 |  |  | $ | 5,954 |  |
| Financed Service Contracts: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 4 |  |  | $ | 56 |  |  | $ | 88 |  |  | $ | 246 |  |  | $ | 555 |  |  | $ | 634 |  |  | $ | 1,583 |  |
| 5 to 6 | 2 |  |  | 36 |  |  | 73 |  |  | 285 |  |  | 465 |  |  | 267 |  |  | 1,128 |  |
| 7 and Higher | — |  |  | — |  |  | 3 |  |  | 16 |  |  | 13 |  |  | 1 |  |  | 33 |  |
| Total Financed Service Contracts | $ | 6 |  |  | $ | 92 |  |  | $ | 164 |  |  | $ | 547 |  |  | $ | 1,033 |  |  | $ | 902 |  |  | $ | 2,744 |  |

[0000858877-20-000015:notes:105]
(1) Lease receivables calculated as gross lease receivables, excluding residual value, less unearned income

[0000858877-20-000015:notes:106]
The following table summarizes our gross receivables categorized by our internal credit risk rating as of July 25, 2020 and was not restated to reflect the impact of adoption of the accounting standards update on Credit Losses on Financial Instruments:

[0000858877-20-000015:notes:107]
|  | INTERNAL CREDIT RISK RATING |
| July 25, 2020 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 992 |  |  | $ | 952 |  |  | $ | 69 |  |  | $ | 2,013 |  |
| Loan receivables | 3,808 |  |  | 1,961 |  |  | 168 |  |  | 5,937 |  |
| Financed service contracts | 1,645 |  |  | 1,153 |  |  | 32 |  |  | 2,830 |  |
| Total | $ | 6,445 |  |  | $ | 4,066 |  |  | $ | 269 |  |  | $ | 10,780 |  |

[0000858877-20-000015:notes:108]
The following tables present the aging analysis of gross receivables as of October 24, 2020 and July 25, 2020 (in millions):

[0000858877-20-000015:notes:109]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| October 24, 2020 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 45 |  |  | $ | 21 |  |  | $ | 103 |  |  | $ | 169 |  |  | $ | 1,789 |  |  | $ | 1,958 |  |  | $ | 4 |  |  | $ | 39 |  |  | $ | 39 |  |
| Loan receivables | 113 |  |  | 32 |  |  | 80 |  |  | 225 |  |  | 5,729 |  |  | 5,954 |  |  | 10 |  |  | 54 |  |  | 54 |  |
| Financed service contracts | 77 |  |  | 34 |  |  | 182 |  |  | 293 |  |  | 2,451 |  |  | 2,744 |  |  | 33 |  |  | 4 |  |  | 4 |  |
| Total | $ | 235 |  |  | $ | 87 |  |  | $ | 365 |  |  | $ | 687 |  |  | $ | 9,969 |  |  | $ | 10,656 |  |  | $ | 47 |  |  | $ | 97 |  |  | $ | 97 |  |

[0000858877-20-000015:notes:110]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 25, 2020 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 29 |  |  | $ | 47 |  |  | $ | 48 |  |  | $ | 124 |  |  | $ | 1,889 |  |  | $ | 2,013 |  |  | $ | 43 |  |  | $ | 43 |  |
| Loan receivables | 129 |  |  | 78 |  |  | 78 |  |  | 285 |  |  | 5,652 |  |  | 5,937 |  |  | 65 |  |  | 65 |  |
| Financed service contracts | 69 |  |  | 75 |  |  | 124 |  |  | 268 |  |  | 2,562 |  |  | 2,830 |  |  | 4 |  |  | 4 |  |
| Total | $ | 227 |  |  | $ | 200 |  |  | $ | 250 |  |  | $ | 677 |  |  | $ | 10,103 |  |  | $ | 10,780 |  |  | $ | 112 |  |  | $ | 112 |  |

[0000858877-20-000015:notes:111]
[same as prior period, unchanged from 0000858877-20-000006:notes:124]

[0000858877-20-000015:notes:112]
As of July 25, 2020, we had financing receivables of $67 million, net of unbilled or current receivables, that were greater than 120 days plus past due but remained on accrual status as they are well secured and in the process of collection.

[0000858877-20-000015:notes:113]
(c)Allowance for Credit Loss Rollforward

[0000858877-20-000015:notes:114]
[same as prior period, unchanged from 0000858877-20-000006:notes:127]

[0000858877-20-000015:notes:115]
| Three months ended October 24, 2020 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 25, 2020 | $ | 48 |  |  | $ | 81 |  |  | $ | 9 |  |  | $ | 138 |  |
| Provisions (benefits) | (3) |  |  | 3 |  |  | (1) |  |  | (1) |  |
| Other | 1 |  |  | 17 |  |  | (1) |  |  | 17 |  |
| Allowance for credit loss as of October 24, 2020 | $ | 46 |  |  | $ | 101 |  |  | $ | 7 |  |  | $ | 154 |  |

[0000858877-20-000015:notes:116]
| Three months ended October 26, 2019 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 27, 2019 | $ | 46 |  |  | $ | 71 |  |  | $ | 9 |  |  | $ | 126 |  |
| Provisions (benefits) | (3) |  |  | 27 |  |  | — |  |  | 24 |  |
| Recoveries (write-offs), net | — |  |  | (16) |  |  | — |  |  | (16) |  |
| Foreign exchange and other | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Allowance for credit loss as of October 26, 2019 | $ | 43 |  |  | $ | 81 |  |  | $ | 9 |  |  | $ | 133 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-20-000015:notes:117]
Available-for-Sale Debt and Equity Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-20-000015:notes:118]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-20-000015:notes:119]
| October 24, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,656 |  |  | $ | 61 |  |  | $ | — |  |  | $ | 2,717 |  |
| U.S. government agency securities | 178 |  |  | — |  |  | — |  |  | 178 |  |
| Corporate debt securities | 11,266 |  |  | 298 |  |  | (27) |  |  | 11,537 |  |
| U.S. agency mortgage-backed securities | 2,494 |  |  | 41 |  |  | (6) |  |  | 2,529 |  |
| Commercial paper | 1,712 |  |  | — |  |  | — |  |  | 1,712 |  |
| Certificates of deposit | 517 |  |  | — |  |  | — |  |  | 517 |  |
| Total (1) | $ | 18,823 |  |  | $ | 400 |  |  | $ | (33) |  |  | $ | 19,190 |  |

[0000858877-20-000015:notes:120]
| July 25, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 2,614 |  |  | $ | 71 |  |  | $ | — |  |  | $ | 2,685 |  |
| U.S. government agency securities | 110 |  |  | — |  |  | — |  |  | 110 |  |
| Corporate debt securities | 11,549 |  |  | 334 |  |  | (6) |  |  | 11,877 |  |
| U.S. agency mortgage-backed securities | 1,987 |  |  | 49 |  |  | (1) |  |  | 2,035 |  |
| Commercial paper | 727 |  |  | — |  |  | — |  |  | 727 |  |
| Certificates of deposit | 176 |  |  | — |  |  | — |  |  | 176 |  |
| Total | $ | 17,163 |  |  | $ | 454 |  |  | $ | (7) |  |  | $ | 17,610 |  |

[0000858877-20-000015:notes:121]
(1) Net unsettled investment sales were $57 million as of October 24, 2020 and were included in other current assets.

[0000858877-20-000015:notes:122]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-20-000015:notes:123]
|  | Three Months Ended |
|  | October 24, 2020 |  | October 26, 2019 |
| Gross realized gains | $ | 15 |  |  | $ | 12 |  |
| Gross realized losses | — |  |  | (2) |  |
| Total | $ | 15 |  |  | $ | 10 |  |

[0000858877-20-000015:notes:124]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 24, 2020 and July 25, 2020 (in millions):

[0000858877-20-000015:notes:125]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 24, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 144 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 144 |  |  | $ | — |  |
| U.S. government agency securities | 65 |  |  | — |  |  | — |  |  | — |  |  | 65 |  |  | — |  |
| Corporate debt securities | 1,008 |  |  | (2) |  |  | — |  |  | — |  |  | 1,008 |  |  | (2) |  |
| U.S. agency mortgage-backed securities | 1,076 |  |  | (6) |  |  | — |  |  | — |  |  | 1,076 |  |  | (6) |  |
| Certificates of deposit | 15 |  |  | — |  |  | — |  |  | — |  |  | 15 |  |  | — |  |
| Total | $ | 2,308 |  |  | $ | (8) |  |  | $ | — |  |  | $ | — |  |  | $ | 2,308 |  |  | $ | (8) |  |

[0000858877-20-000015:notes:126]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 25, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government agency securities | $ | 33 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 33 |  |  | $ | — |  |
| Corporate debt securities | 1,060 |  |  | (6) |  |  | 3 |  |  | — |  |  | 1,063 |  |  | (6) |  |
| U.S. agency mortgage-backed securities | 265 |  |  | (1) |  |  | — |  |  | — |  |  | 265 |  |  | (1) |  |
| Total | $ | 1,358 |  |  | $ | (7) |  |  | $ | 3 |  |  | $ | — |  |  | $ | 1,361 |  |  | $ | (7) |  |

[0000858877-20-000015:notes:127]
The following table summarizes the maturities of our available-for-sale debt investments as of October 24, 2020 (in millions):

[0000858877-20-000015:notes:128]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 7,480 |  |  | $ | 7,490 |  |
| After 1 year through 5 years | 6,897 |  |  | 7,052 |  |
| After 5 years through 10 years | 1,943 |  |  | 2,109 |  |
| After 10 years | 9 |  |  | 10 |  |
| Mortgage-backed securities with no single maturity | 2,494 |  |  | 2,529 |  |
| Total | $ | 18,823 |  |  | $ | 19,190 |  |

[0000858877-20-000015:notes:129]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-20-000015:notes:130]
(b)Summary of Equity Investments

[0000858877-20-000015:notes:131]
Our net adjustments to non-marketable equity securities measured using the measurement alternative was a net gain of $1 million and a net loss of $1 million for the first quarter of fiscal 2021 and 2020, respectively. We held equity interests in certain private equity funds of $0.7 billion as of each of October 24, 2020 and July 25, 2020, which are accounted for under the NAV practical expedient.

[0000858877-20-000015:notes:132]
(c)Variable Interest Entities

[0000858877-20-000015:notes:133]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 24, 2020, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-20-000015:notes:134]
The carrying value of our investments in privately held companies was $1.4 billion and $1.3 billion as of October 24, 2020 and July 25, 2020, respectively.

[0000858877-20-000015:notes:135]
Of the total carrying value of our investments in privately held companies as of October 24, 2020, $0.7 billion of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $0.3 billion related to these privately held investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-20-000015:notes:136]
Fair Value Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, we consider the principal or most advantageous market in which we would transact, and we also consider assumptions that market participants would use when pricing the asset or liability.
(a)Fair Value Hierarchy

[0000858877-20-000015:notes:137]
[same as prior period, unchanged from 0000858877-20-000006:notes:163]

[0000858877-20-000015:notes:138]
[same as prior period, unchanged from 0000858877-20-000006:notes:164]

[0000858877-20-000015:notes:139]
[same as prior period, unchanged from 0000858877-20-000006:notes:165]

[0000858877-20-000015:notes:140]
[same as prior period, unchanged from 0000858877-20-000006:notes:166]

[0000858877-20-000015:notes:141]
(b)Assets and Liabilities Measured at Fair Value on a Recurring Basis

[0000858877-20-000015:notes:142]
[same as prior period, unchanged from 0000858877-20-000006:notes:168]

[0000858877-20-000015:notes:143]
|  | OCTOBER 24, 2020 |  | JULY 25, 2020 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 8,634 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,634 |  |  | $ | 10,024 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,024 |  |
| Corporate debt securities | — |  |  | 4 |  |  | — |  |  | 4 |  |  | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Commercial paper | — |  |  | 120 |  |  | — |  |  | 120 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 2,717 |  |  | — |  |  | 2,717 |  |  | — |  |  | 2,685 |  |  | — |  |  | 2,685 |  |
| U.S. government agency securities | — |  |  | 178 |  |  | — |  |  | 178 |  |  | — |  |  | 110 |  |  | — |  |  | 110 |  |
| Corporate debt securities | — |  |  | 11,537 |  |  | — |  |  | 11,537 |  |  | — |  |  | 11,877 |  |  | — |  |  | 11,877 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,529 |  |  | — |  |  | 2,529 |  |  | — |  |  | 2,035 |  |  | — |  |  | 2,035 |  |
| Commercial paper | — |  |  | 1,712 |  |  | — |  |  | 1,712 |  |  | — |  |  | 727 |  |  | — |  |  | 727 |  |
| Certificates of deposit | — |  |  | 517 |  |  | — |  |  | 517 |  |  | — |  |  | 176 |  |  | — |  |  | 176 |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative assets | — |  |  | 179 |  |  | 3 |  |  | 182 |  |  | — |  |  | 190 |  |  | 1 |  |  | 191 |  |
| Total | $ | 8,634 |  |  | $ | 19,493 |  |  | $ | 3 |  |  | $ | 28,130 |  |  | $ | 10,024 |  |  | $ | 17,808 |  |  | $ | 1 |  |  | $ | 27,833 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Total | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |

[0000858877-20-000015:notes:144]
Level 1 marketable securities are determined by using quoted prices in active markets for identical assets. Level 2 available-for-sale debt investments are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of these assets and liabilities. We use such pricing data as the primary input to make our assessments and determinations as to the ultimate valuation of our investment portfolio and have not made, during the periods presented, any material adjustments to such inputs. We are ultimately responsible for the financial statements and underlying estimates. Our derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models

[0000858877-20-000015:notes:145]
that use observable market inputs. We did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented. Level 3 assets include certain derivative instruments, the values of which are determined based on discounted cash flow models using inputs that we could not corroborate with market data.

[0000858877-20-000015:notes:146]
(c)Assets Measured at Fair Value on a Nonrecurring Basis

[0000858877-20-000015:notes:147]
[same as prior period, unchanged from 0000858877-20-000006:notes:172]

[0000858877-20-000015:notes:148]
[same as prior period, unchanged from 0000858877-20-000006:notes:175]

[0000858877-20-000015:notes:149]
The fair value of our short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables and financed service contracts as of October 24, 2020 and July 25, 2020 was $4.4 billion and $4.5 billion, respectively. The estimated fair value of our long-term loan receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.
As of October 24, 2020, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of October 24, 2020, the fair value of our senior notes was $17.0 billion with a carrying amount of $14.6 billion. This compares to a fair value of $17.4 billion and a carrying amount of $14.6 billion as of July 25, 2020. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:DebtDisclosureTextBlock

[0000858877-20-000015:notes:150]
Borrowings 
(a)Short-Term Debt

[0000858877-20-000015:notes:151]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-20-000015:notes:152]
|  | October 24, 2020 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 5,002 |  |  | 2.00 | % |  | $ | 3,005 |  |  | 2.07 | % |

[0000858877-20-000015:notes:153]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-20-000015:notes:154]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-20-000015:notes:155]
(b)Long-Term Debt

[0000858877-20-000015:notes:156]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-20-000015:notes:157]
|  |  |  | October 24, 2020 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | 2,500 |  |  | 2.30% |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.91% |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.19% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.03% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.35% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 14,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (86) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 152 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 14,566 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 5,002 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,564 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 14,566 |  |  |  |  | $ | 14,583 |  |  |  |

[0000858877-20-000015:notes:158]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $2.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (“LIBOR”). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-20-000015:notes:159]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 24, 2020, we were in compliance with all debt covenants.

[0000858877-20-000015:notes:160]
As of October 24, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-20-000015:notes:161]
| Fiscal Year | Amount |
| 2021 (remaining nine months) | $ | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 14,500 |  |

[0000858877-20-000015:notes:162]
(c)Credit Facility

[0000858877-20-000015:notes:163]
On May 15, 2020, we entered into a 364-day credit agreement with certain institutional lenders that provides for a $2.75 billion unsecured revolving credit facility that is scheduled to expire on May 14, 2021. The credit agreement is structured as an amendment and restatement of our five-year credit facility which would have terminated on May 15, 2020, the end of its five-year term. As of October 24, 2020, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility. 
Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than 0.25%. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-20-000015:notes:164]
Derivative Instruments 
(a)Summary of Derivative Instruments

[0000858877-20-000015:notes:165]
[same as prior period, unchanged from 0000858877-20-000006:notes:194]

[0000858877-20-000015:notes:166]
[same as prior period, unchanged from 0000858877-20-000006:notes:195]

[0000858877-20-000015:notes:167]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | October 24,2020 |  | July 25,2020 |  | Balance Sheet Line Item |  | October 24,2020 |  | July 25,2020 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 11 |  |  | $ | 7 |  |  | Other current liabilities |  | $ | 10 |  |  | $ | 2 |  |
| Interest rate derivatives | Other current assets |  | 4 |  |  | 6 |  |  | Other current liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other assets |  | 151 |  |  | 169 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 166 |  |  | 182 |  |  |  |  | 10 |  |  | 2 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 13 |  |  | 8 |  |  | Other current liabilities |  | 11 |  |  | 8 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 1 |  |  | — |  |
| Equity derivatives | Other assets |  | 3 |  |  | 1 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 16 |  |  | 9 |  |  |  |  | 12 |  |  | 8 |  |
| Total |  |  | $ | 182 |  |  | $ | 191 |  |  |  |  | $ | 22 |  |  | $ | 10 |  |

[0000858877-20-000015:notes:168]
[same as prior period, unchanged from 0000858877-20-000006:notes:197]

[0000858877-20-000015:notes:169]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | October 24,2020 |  | July 25,2020 |  | October 24,2020 |  | July 25,2020 |
| Short-term debt |  | $ | (504) |  |  | $ | (506) |  |  | $ | (4) |  |  | $ | (6) |  |
| Long-term debt |  | $ | (2,143) |  |  | $ | (2,159) |  |  | $ | (148) |  |  | $ | (165) |  |

[0000858877-20-000015:notes:170]
The effect of derivative instruments designated as fair value hedges, recognized in interest and other income (loss), net is summarized as follows (in millions):

[0000858877-20-000015:notes:171]
|  |  | Three Months Ended |
|  |  | October 24, 2020 |  | October 26, 2019 |
| Interest rate derivatives: |  |  |  |  |
| Hedged items |  | $ | 19 |  |  | $ | (21) |  |
| Derivatives designated as hedging instruments |  | (20) |  |  | 22 |  |
| Total |  | $ | (1) |  |  | $ | 1 |  |

[0000858877-20-000015:notes:172]
[same as prior period, unchanged from 0000858877-20-000006:notes:203]

[0000858877-20-000015:notes:173]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | October 24,2020 |  | October 26,2019 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | 14 |  |  | $ | (7) |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | 23 |  |  | — |  |
| Equity derivatives |  | Other income (loss), net |  | 5 |  |  | 2 |  |
| Total |  |  |  | $ | 42 |  |  | $ | (5) |  |

[0000858877-20-000015:notes:174]
[same as prior period, unchanged from 0000858877-20-000006:notes:205]

[0000858877-20-000015:notes:175]
|  | October 24,2020 |  | July 25,2020 |
| Foreign currency derivatives | $ | 4,338 |  |  | $ | 4,315 |  |
| Interest rate derivatives | 2,500 |  |  | 2,500 |  |
| Total return swaps—deferred compensation | 621 |  |  | 580 |  |
| Total | $ | 7,459 |  |  | $ | 7,395 |  |

[0000858877-20-000015:notes:176]
(b)Offsetting of Derivative Instruments

[0000858877-20-000015:notes:177]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty. As of October 24, 2020 and July 25, 2020, the potential effects of these rights of set-off associated with the derivative contracts would be a reduction to both derivative assets and derivative liabilities of $20 million and $10 million, respectively.

[0000858877-20-000015:notes:178]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral received as of October 24, 2020 and July 25, 2020 was $157 million and $173 million, respectively. Including the effects of collateral, this results in a net derivative asset of $3 million and $8 million as of October 24, 2020 and July 25, 2020, respectively.

[0000858877-20-000015:notes:179]
(c)Foreign Currency Exchange Risk

[0000858877-20-000015:notes:180]
[same as prior period, unchanged from 0000858877-20-000006:notes:211]

[0000858877-20-000015:notes:181]
[same as prior period, unchanged from 0000858877-20-000006:notes:212]

[0000858877-20-000015:notes:182]
We enter into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, including long-term customer financings and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of intercompany balances, other current assets, or liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-20-000015:notes:183]
[same as prior period, unchanged from 0000858877-20-000006:notes:214]

[0000858877-20-000015:notes:184]
(d)Interest Rate Risk

[0000858877-20-000015:notes:185]
[same as prior period, unchanged from 0000858877-20-000006:notes:216]

[0000858877-20-000015:notes:186]
(e)Equity Price Risk

[0000858877-20-000015:notes:187]
[same as prior period, unchanged from 0000858877-20-000006:notes:218]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-20-000015:notes:188]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-20-000015:notes:189]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of October 24, 2020 and July 25, 2020, we had total purchase commitments for inventory of $4.2 billion and $4.4 billion, respectively.

[0000858877-20-000015:notes:190]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 24, 2020 and July 25, 2020, the liability for these purchase commitments was $157 million and $141 million, respectively, and was included in other current liabilities. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $32 million and $29 million for the first quarter of fiscal 2021 and 2020, respectively.

[0000858877-20-000015:notes:191]
(b)Other Commitments

[0000858877-20-000015:notes:192]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-20-000015:notes:193]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-20-000015:notes:194]
|  | Three Months Ended |
|  | October 24, 2020 |  | October 26, 2019 |
| Compensation expense related to acquisitions | $ | 57 |  |  | $ | 61 |  |

[0000858877-20-000015:notes:195]
As of October 24, 2020, we estimated that future cash compensation expense of up to $495 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-20-000015:notes:196]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.3 billion as of each of October 24, 2020 and July 25, 2020.

[0000858877-20-000015:notes:197]
(c)Product Warranties

[0000858877-20-000015:notes:198]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-20-000015:notes:199]
|  | Three Months Ended |
|  | October 24,2020 |  | October 26,2019 |
| Balance at beginning of period | $ | 331 |  |  | $ | 342 |  |
| Provisions for warranties issued | 121 |  |  | 140 |  |
| Adjustments for pre-existing warranties | 1 |  |  | (3) |  |
| Settlements | (122) |  |  | (149) |  |
| Balance at end of period | $ | 331 |  |  | $ | 330 |  |

[0000858877-20-000015:notes:200]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-20-000015:notes:201]
(d)Financing and Other Guarantees

[0000858877-20-000015:notes:202]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-20-000015:notes:203]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. During fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.1 billion and $7.6 billion for the first quarter of fiscal 2021 and 2020, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.1 billion as of October 24, 2020 and July 25, 2020, respectively.

[0000858877-20-000015:notes:204]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $5 million for each of the first quarters of fiscal 2021 and 2020.

[0000858877-20-000015:notes:205]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 24, 2020 and July 25, 2020, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-20-000015:notes:206]
|  | October 24,2020 |  | July 25,2020 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 193 |  |  | $ | 198 |  |
| End user | 8 |  |  | 9 |  |
| Total | $ | 201 |  |  | $ | 207 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (25) |  |  | $ | (19) |  |
| End user | (8) |  |  | (9) |  |
| Total | $ | (33) |  |  | $ | (28) |  |
| Total | $ | 168 |  |  | $ | 179 |  |

[0000858877-20-000015:notes:207]
(e)Indemnifications

[0000858877-20-000015:notes:208]
In the normal course of business, we indemnify other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-20-000015:notes:209]
Charter Communications, Inc. (“Charter”), which acquired Time Warner Cable (“TWC”) in May 2016, is seeking indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Sprint sought monetary damages, alleging that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. The Court awarded Sprint pre and post judgment interest of approximately $10 million and denied TWC’s post-trial motions and appeals. Charter reported that it paid the judgment in full. At this time, we are working with Charter to calculate the correct amount of indemnification. We do not believe that our indemnity obligations under our agreement will be material.

[0000858877-20-000015:notes:210]
We also have been asked to indemnify certain of our service provider customers that have been subject to patent infringement claims asserted by Chanbond, LLC (“Chanbond”) in the United States District Court for the District of Delaware on September 21, 2015. Chanbond alleges that 13 service provider companies, including among others, Comcast Corporation, Charter Communications, Inc. (“Charter”), Time Warner Cable, Inc. (subsequently acquired by Charter), Cox Communications, Inc. (“Cox”), and Cablevision Systems Corporation, infringe three patents by providing high speed cable internet services to their customers utilizing cable modems and cable modem termination systems, consistent with the DOCSIS 3.0 standard, provided by us and other manufacturers generally used in combination with each other. Chanbond seeks monetary damages. On October

[0000858877-20-000015:notes:211]
13, 2020, the Court set Chanbond’s case against Cox for trial on May 17, 2021. The other cases against the remaining service provider defendants have not yet been set for trial. We believe that the service provider defendants have strong non-infringement, invalidity and other defenses. Due to uncertainties surrounding the litigation processes, we are unable to reasonably estimate the ultimate outcome of the cases at this time, but should Chanbond prevail in its cases against the service provider defendants, we do not believe that any potential indemnity liability would be material.

[0000858877-20-000015:notes:212]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-20-000015:notes:213]
It is not possible to determine the maximum potential amount under these indemnification agreements due to uncertainties in the litigation process, coordination with other suppliers and the defendants in these cases, and the unique facts and circumstances involved in each particular agreement. Historically, payments made by us under these agreements have not had a material effect on our operating results, financial position, or cash flows.

[0000858877-20-000015:notes:214]
(f)Legal Proceedings

[0000858877-20-000015:notes:215]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $0.1 billion for the alleged evasion of import and other taxes, $0.7 billion for interest, and $0.4 billion for various penalties, all determined using an exchange rate as of October 24, 2020.

[0000858877-20-000015:notes:216]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-20-000015:notes:217]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial started on May 2, 2016, and, on May 12, 2016, the jury returned a verdict finding willful infringement. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the District Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit on various grounds, and after various proceedings, on July 12, 2019, the Federal Circuit vacated the enhanced damages award; vacated and remanded in part the willful infringement finding; vacated and remanded the attorneys’ fees award for further proceedings; and affirmed the District Court’s other findings. On April 1, 2020, the District Court issued a final judgment on the remanded issues, finding no evidence of willful infringement and reinstating the $8 million award of attorneys’ fees. SRI appealed the judgment of no willful infringement to the Federal Circuit on April 3, 2020, and Cisco filed a cross-appeal on the attorneys’ fees award on April 9, 2020. Cisco has paid SRI $28.1 million, representing the portion of the judgment that the Federal Circuit previously affirmed, plus interest and royalties on post-verdict sales. While the remaining proceedings may result in an additional loss, we do not expect it to be material.

[0000858877-20-000015:notes:218]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal has appealed the PTAB’s findings of unpatentability to the United States Court of Appeals for the Federal Circuit. Starting on May 6, 2020 and concluding on June 25, 2020, the District Court conducted a bench trial by videoconference on the claims in the five patents not subject to the IPR Proceedings, including claims in three for which the PTAB declined to institute IPR Proceedings. Centripetal

[0000858877-20-000015:notes:219]
sought damages, enhanced damages for willful infringement, and broad injunctive relief. On October 5, 2020, the District Court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The Court awarded Centripetal $1.9 billion, comprised of $755.8 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $13.7 million. The Court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $167.7 million and a maximum annual royalty of $300.1 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $83.9 million and a maximum annual royalty of $150.0 million. We believe that the District Court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We intend to appeal the District Court’s judgment as to the four patents found valid and infringed to the United States Court of Appeals for the Federal Circuit, and we believe that any relief ultimately awarded would not be material. On October 28, 2020, by agreement of the parties, the District Court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment. On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. District Court proceedings, one of which has been invalidated by the PTAB. We are currently assessing the cases filed in Germany and we believe we have strong defenses. Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of the cases at this time.

[0000858877-20-000015:notes:220]
Finjan     On January 6, 2017, Finjan, Inc. (“Finjan”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Finjan alleges that Cisco’s AMP and ThreatGrid products and the URL rewrite feature of Cisco’s ESA Outbreak Filter product infringe five patents, four of which have expired. Finjan has conceded that they are not entitled to any pre-suit damages, accordingly it seeks approximately three weeks of damages for the alleged infringement of the 8,677,494 and 6,154,844 patents, approximately ten months of damages for the 6,804,780 patent, approximately three years of damages for the 7,647,633 patent, and approximately three-and-a-half years of past damages for the 8,141,154 patent and an ongoing royalty until its expiration on December 12, 2025. The case is currently set for jury trial starting January 11, 2021. While we believe that we have strong non-infringement arguments, that the patents are invalid, that Finjan’s damages theories are not supported by prevailing law and that Finjan will not be able to meet its burden required for injunctive relief, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.

[0000858877-20-000015:notes:221]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three U.S. patents. The case is currently set for a jury trial starting December 4, 2020. While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-20-000015:notes:222]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-20-000015:notes:223]
Shareholders’ Equity 
(a)Cash Dividends on Shares of Common Stock

[0000858877-20-000015:notes:224]
We declared and paid cash dividends of $0.36 and $0.35 per common share, or $1.5 billion, on our outstanding common stock for each of the first quarters of fiscal 2021 and 2020.

[0000858877-20-000015:notes:225]
Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-20-000015:notes:226]
(b)Stock Repurchase Program

[0000858877-20-000015:notes:227]
In September 2001, our Board of Directors authorized a stock repurchase program. As of October 24, 2020, the remaining authorized amount for stock repurchases under this program was approximately $10.0 billion with no termination date. A summary of the stock repurchase activity for the first quarter of fiscal 2021 and fiscal 2020 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-20-000015:notes:228]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2021 |  |  |  |  |  |  |
| October 24, 2020 |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |
| Fiscal 2020 |  |  |  |  |  |  |
| July 25, 2020 |  | — |  |  | $ | — |  |  | $ | — |  |
| April 25, 2020 |  | 25 |  |  | $ | 39.71 |  |  | $ | 981 |  |
| January 25, 2020 |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |
| October 26, 2019 |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |

[0000858877-20-000015:notes:229]
There were no stock repurchases that were pending settlement as of October 24, 2020 and July 25, 2020.

[0000858877-20-000015:notes:230]
The purchase price for the shares of our stock repurchased is reflected as a reduction to shareholders’ equity. We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings or an increase to accumulated deficit and (ii) a reduction of common stock and additional paid-in capital.

[0000858877-20-000015:notes:231]
[same as prior period, unchanged from 0000858877-20-000006:notes:264]

[0000858877-20-000015:notes:232]
[same as prior period, unchanged from 0000858877-20-000006:notes:265]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-20-000015:notes:233]
Employee Benefit Plans  
(a)Employee Stock Incentive Plans

[0000858877-20-000015:notes:234]
Stock Incentive Plan Program Description    As of October 24, 2020, we had one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with Cisco. The number and frequency of share-based awards are based on competitive practices, operating results of Cisco, government regulations, and other factors. Our primary stock incentive plan is summarized as follows:

[0000858877-20-000015:notes:235]
2005 Plan    The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions.  Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. As of October 24, 2020, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares. The 2005 Plan may be terminated by the Board of Directors at any time and for any reason, and is currently set to terminate at the 2021 Annual Meeting unless re-adopted or extended by the shareholders prior to or on such date.

[0000858877-20-000015:notes:236]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. For restricted stock units that were awarded with vesting contingent upon the achievement of future financial performance or market-based metrics, the maximum awards that can be achieved upon full vesting of such awards. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share

[0000858877-20-000015:notes:237]
ratio described above, will become available again for issuance under the 2005 Plan. As of October 24, 2020, 175 million shares were authorized for future grant under the 2005 Plan.

[0000858877-20-000015:notes:238]
(b)Employee Stock Purchase Plan

[0000858877-20-000015:notes:239]
We have an Employee Stock Purchase Plan under which 721.4 million shares of our common stock have been reserved for issuance as of October 24, 2020. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. No shares were issued under the Employee Stock Purchase Plan during each of the first quarters of fiscal 2021 and 2020. As of October 24, 2020, 141 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-20-000015:notes:240]
(c)Summary of Share-Based Compensation Expense

[0000858877-20-000015:notes:241]
[same as prior period, unchanged from 0000858877-20-000006:notes:274]

[0000858877-20-000015:notes:242]
|  | Three Months Ended |
|  | October 24, 2020 |  | October 26, 2019 |
| Cost of sales—product | $ | 24 |  |  | $ | 23 |  |
| Cost of sales—service | 41 |  |  | 34 |  |
| Share-based compensation expense in cost of sales | 65 |  |  | 57 |  |
| Research and development | 167 |  |  | 146 |  |
| Sales and marketing | 134 |  |  | 127 |  |
| General and administrative | 61 |  |  | 60 |  |
| Restructuring and other charges | 11 |  |  | 8 |  |
| Share-based compensation expense in operating expenses | 373 |  |  | 341 |  |
| Total share-based compensation expense | $ | 438 |  |  | $ | 398 |  |
| Income tax benefit for share-based compensation | $ | 81 |  |  | $ | 131 |  |

[0000858877-20-000015:notes:243]
As of October 24, 2020, the total compensation cost related to unvested share-based awards not yet recognized was $3.6 billion which is expected to be recognized over approximately 2.9 years on a weighted-average basis.

[0000858877-20-000015:notes:244]
(d)Restricted Stock and Stock Unit Awards

[0000858877-20-000015:notes:245]
[same as prior period, unchanged from 0000858877-20-000006:notes:278]

[0000858877-20-000015:notes:246]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 27, 2019 | 100 |  |  | $ | 38.66 |  |  |  |
| Granted | 49 |  |  | 42.61 |  |  |  |
| Vested | (44) |  |  | 35.20 |  |  | $ | 2,045 |  |
| Canceled/forfeited/other | (9) |  |  | 40.45 |  |  |  |
| UNVESTED BALANCE AT JULY 25, 2020 | 96 |  |  | 42.03 |  |  |  |
| Granted | 10 |  |  | 37.16 |  |  |  |
| Vested | (6) |  |  | 39.95 |  |  | $ | 264 |  |
| Canceled/forfeited/other | (4) |  |  | 39.17 |  |  |  |
| UNVESTED BALANCE AT OCTOBER 24, 2020 | 96 |  |  | $ | 41.77 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-20-000015:notes:247]
Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first quarter of fiscal 2021 and 2020 are summarized as follows (in millions):

[0000858877-20-000015:notes:248]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 25, 2020 | $ | 315 |  |  | $ | (6) |  |  | $ | (828) |  |  | $ | (519) |  |
| Other comprehensive income (loss) before reclassifications | (41) |  |  | (2) |  |  | 110 |  |  | 67 |  |
| (Gains) losses reclassified out of AOCI | (15) |  |  | (2) |  |  | — |  |  | (17) |  |
| Tax benefit (expense) | 22 |  |  | 1 |  |  | (1) |  |  | 22 |  |
| BALANCE AT OCTOBER 24, 2020 | $ | 281 |  |  | $ | (9) |  |  | $ | (719) |  |  | $ | (447) |  |

[0000858877-20-000015:notes:249]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 27, 2019 | $ | — |  |  | $ | (14) |  |  | $ | (778) |  |  | $ | (792) |  |
| Other comprehensive income (loss) before reclassifications | 87 |  |  | (1) |  |  | (92) |  |  | (6) |  |
| (Gains) losses reclassified out of AOCI | (10) |  |  | — |  |  | 1 |  |  | (9) |  |
| Tax benefit (expense) | (9) |  |  | 1 |  |  | — |  |  | (8) |  |
| BALANCE AT OCTOBER 26, 2019 | $ | 68 |  |  | $ | (14) |  |  | $ | (869) |  |  | $ | (815) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-20-000015:notes:250]
Income Taxes
The following table provides details of income taxes (in millions, except percentages):

[0000858877-20-000015:notes:251]
|  | Three Months Ended |
|  | October 24,2020 |  | October 26,2019 |
| Income before provision for income taxes | $ | 2,681 |  |  | $ | 3,686 |  |
| Provision for income taxes | $ | 507 |  |  | $ | 760 |  |
| Effective tax rate | 18.9 | % |  | 20.6 | % |

[0000858877-20-000015:notes:252]
As of October 24, 2020, we had $2.5 billion of unrecognized tax benefits, of which $2.2 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-20-000015:notes:253]
Segment Information and Major Customers 
(a)Revenue and Gross Margin by Segment

[0000858877-20-000015:notes:254]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-20-000015:notes:255]
Summarized financial information by segment for the first quarter of fiscal 2021 and 2020, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-20-000015:notes:256]
|  | Three Months Ended |
|  | October 24,2020 |  | October 26,2019 |
| Revenue: |  |  |  |
| Americas | $ | 7,198 |  |  | $ | 7,977 |  |
| EMEA | 2,964 |  |  | 3,283 |  |
| APJC | 1,767 |  |  | 1,899 |  |
| Total | $ | 11,929 |  |  | $ | 13,159 |  |
| Gross margin: |  |  |  |
| Americas | $ | 4,847 |  |  | $ | 5,316 |  |
| EMEA | 1,894 |  |  | 2,166 |  |
| APJC | 1,113 |  |  | 1,194 |  |
| Segment total | 7,853 |  |  | 8,676 |  |
| Unallocated corporate items | (272) |  |  | (212) |  |
| Total | $ | 7,581 |  |  | $ | 8,464 |  |

[0000858877-20-000015:notes:257]
[same as prior period, unchanged from 0000858877-20-000006:notes:296]

[0000858877-20-000015:notes:258]
Revenue in the United States was $6.5 billion and $7.1 billion for the first quarter of fiscal 2021 and 2020, respectively.

[0000858877-20-000015:notes:259]
(b)Revenue for Groups of Similar Products and Services

[0000858877-20-000015:notes:260]
[same as prior period, unchanged from 0000858877-20-000006:notes:299]


## us-gaap:EarningsPerShareTextBlock

[0000858877-20-000015:notes:261]
Net Income per Share
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-20-000015:notes:262]
|  | Three Months Ended |
|  | October 24,2020 |  | October 26,2019 |
| Net income | $ | 2,174 |  |  | $ | 2,926 |  |
| Weighted-average shares—basic | 4,230 |  |  | 4,246 |  |
| Effect of dilutive potential common shares | 14 |  |  | 27 |  |
| Weighted-average shares—diluted | 4,244 |  |  | 4,273 |  |
| Net income per share—basic | $ | 0.51 |  |  | $ | 0.69 |  |
| Net income per share—diluted | $ | 0.51 |  |  | $ | 0.68 |  |
| Antidilutive employee share-based awards, excluded | 35 |  |  | 11 |  |

[0000858877-20-000015:notes:263]
[same as prior period, unchanged from 0000858877-20-000006:notes:303]
