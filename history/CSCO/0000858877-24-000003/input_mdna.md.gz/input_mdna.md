# CSCO MD&A — 0000858877-24-000003


## mdna

[0000858877-24-000003:mdna:1]
[same as prior period, unchanged from 0000858877-23-000031:mdna:1]

[0000858877-24-000003:mdna:2]
[same as prior period, unchanged from 0000858877-23-000031:mdna:2]

[0000858877-24-000003:mdna:3]
[same as prior period, unchanged from 0000858877-23-000031:mdna:3]

[0000858877-24-000003:mdna:4]
[same as prior period, unchanged from 0000858877-23-000031:mdna:4]

[0000858877-24-000003:mdna:5]
[same as prior period, unchanged from 0000858877-23-000031:mdna:5]

[0000858877-24-000003:mdna:6]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | January 27,2024 |  | January 28,2023 |  | % Variance |  |  | January 27, 2024 |  | January 28, 2023 |  | % Variance |  |
| Revenue | $ | 12,791 |  |  | $ | 13,592 |  |  | (6) | % |  |  | $ | 27,459 |  |  | $ | 27,224 |  |  | 1 | % |  |
| Gross margin percentage | 64.2 | % |  | 62.0 | % |  | 2.2 |  | pts |  | 64.7 | % |  | 61.6 | % |  | 3.1 |  | pts |
| Research and development | $ | 1,943 |  |  | $ | 1,855 |  |  | 5 | % |  |  | $ | 3,856 |  |  | $ | 3,636 |  |  | 6 | % |  |
| Sales and marketing | $ | 2,458 |  |  | $ | 2,384 |  |  | 3 | % |  |  | $ | 4,964 |  |  | $ | 4,775 |  |  | 4 | % |  |
| General and administrative | $ | 642 |  |  | $ | 582 |  |  | 10 | % |  |  | $ | 1,314 |  |  | $ | 1,147 |  |  | 15 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 5,043 |  |  | $ | 4,821 |  |  | 5 | % |  |  | $ | 10,134 |  |  | $ | 9,558 |  |  | 6 | % |  |
| Total as a percentage of revenue | 39.4 | % |  | 35.5 | % |  | 3.9 |  | pts |  | 36.9 | % |  | 35.1 | % |  | 1.8 |  | pts |
| Restructuring and other charges included in operating expenses | $ | 12 |  |  | $ | 243 |  |  | (95) | % |  |  | $ | 135 |  |  | $ | 241 |  |  | (44) | % |  |
| Operating income as a percentage of revenue | 24.2 | % |  | 24.2 | % |  | — |  | pts |  | 26.8 | % |  | 25.1 | % |  | 1.7 |  | pts |
| Interest and other income (loss), net | $ | 65 |  |  | $ | 123 |  |  | (47) | % |  |  | $ | 231 |  |  | $ | 58 |  |  | NM |  |
| Income tax percentage | 16.7 | % |  | 18.8 | % |  | (2.1) |  | pts |  | 17.5 | % |  | 21.0 | % |  | (3.5) |  | pts |
| Net income | $ | 2,634 |  |  | $ | 2,773 |  |  | (5) | % |  |  | $ | 6,272 |  |  | $ | 5,443 |  |  | 15 | % |  |
| Net income as a percentage of revenue | 20.6 | % |  | 20.4 | % |  | 0.2 |  | pts |  | 22.8 | % |  | 20.0 | % |  | 2.8 |  | pts |
| Earnings per share—diluted | $ | 0.65 |  |  | $ | 0.67 |  |  | (3) | % |  |  | $ | 1.54 |  |  | $ | 1.32 |  |  | 17 | % |  |

[0000858877-24-000003:mdna:7]
[same as prior period, unchanged from 0000858877-23-000031:mdna:7]

[0000858877-24-000003:mdna:8]
[same as prior period, unchanged from 0000858877-23-000031:mdna:8]

[0000858877-24-000003:mdna:9]
[same as prior period, unchanged from 0000858877-23-000031:mdna:9]

[0000858877-24-000003:mdna:10]
[same as prior period, unchanged from 0000858877-23-000031:mdna:10]

[0000858877-24-000003:mdna:11]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:12]
Total revenue decreased by 6% compared with the second quarter of fiscal 2023. Within total revenue, product revenue decreased by 9% and service revenue increased by 4%. In the second quarter of fiscal 2024, total software revenue was flat at $4.2 billion across all product areas and service. Within total software revenue, subscription revenue increased 5%.

[0000858877-24-000003:mdna:13]
In the second quarter of fiscal 2024, we saw customers more closely scrutinizing spend given the high level of uncertainty in the macroeconomic environment. Additionally, our customers and third-party resellers are continuing to implement elevated levels of product shipments from recent quarters, which we believe contributed to the decline in product demand. For the product categories in which we can measure customer inventory absorption, we are seeing steady progress. However, we believe we are an additional one to two quarters away from full implementation of product shipments, which is longer than we initially expected. We saw this dynamic primarily with our service provider and cloud customers and enterprise customers. We believe these impacts on product demand may continue through at least the end of fiscal 2024.

[0000858877-24-000003:mdna:14]
Total gross margin increased by 2.2 percentage points. Product gross margin increased by 2.5 percentage points, largely driven by productivity improvements and favorable product mix, partially offset by pricing erosion. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 3.9 percentage points. Operating income as a percentage of revenue was flat driven by higher product gross margin offset by higher operating expenses in the second quarter of fiscal 2024. Diluted earnings per share decreased 3%, driven by a decrease of 5% in net income, partially offset by a decrease in diluted share count of 43 million shares.

[0000858877-24-000003:mdna:15]
In terms of our geographic segments, revenue from the Americas decreased by $315 million, EMEA revenue decreased by $244 million and APJC revenue decreased by $241 million. From a customer market standpoint, we experienced product revenue declines in the enterprise and service provider and cloud markets, partially offset by growth in the public sector market. From a product category perspective, the product revenue decrease of 9% was driven by a decline in revenue in Networking of 12%. This decline was partially offset by product revenue growth in Security of 3%, Collaboration of 3% and Observability of 16%.

[0000858877-24-000003:mdna:16]
We remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformations. Further, we continued to make progress in the transition of our business model by delivering increased software subscription revenue. We remain focused on accelerating innovation across our portfolio, and we believe that we are making progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment. While the overall environment remains uncertain, we continue to invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-24-000003:mdna:17]
[same as prior period, unchanged from 0000858877-23-000031:mdna:18]

[0000858877-24-000003:mdna:18]
[same as prior period, unchanged from 0000858877-23-000031:mdna:19]

[0000858877-24-000003:mdna:19]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:20]
Total revenue increased 1%, with product revenue flat and service revenue increasing 4%. Total gross margin increased 3.1 percentage points due to productivity improvements, favorable product mix and favorable pricing. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 1.8 percentage points. Operating income as a percentage of revenue increased by 1.7 percentage points. We incurred restructuring and other charges of $135 million in the first six months of fiscal 2024. Diluted earnings per share increased 17%, driven by an increase of 15% in net income, partially offset by a decrease in diluted share count of 36 million shares.

[0000858877-24-000003:mdna:21]
[same as prior period, unchanged from 0000858877-23-000031:mdna:20]

[0000858877-24-000003:mdna:22]
[same as prior period, unchanged from 0000858877-23-000031:mdna:21]

[0000858877-24-000003:mdna:23]
[same as prior period, unchanged from 0000858877-23-000031:mdna:22]

[0000858877-24-000003:mdna:24]
[same as prior period, unchanged from 0000858877-23-000031:mdna:23]

[0000858877-24-000003:mdna:25]
The following is a summary of our other key financial measures for the second quarter of fiscal 2024 (in millions):

[0000858877-24-000003:mdna:26]
|  |  | January 27,2024 |  | July 29,2023 |
| Cash and cash equivalents and investments |  | $ | 25,671 |  |  | $ | 26,146 |  |
| Remaining performance obligations |  | $ | 35,656 |  |  | $ | 34,868 |  |
| Inventories |  | $ | 3,209 |  |  | $ | 3,644 |  |

[0000858877-24-000003:mdna:27]
|  |  | Six Months Ended |
|  |  | January 27,2024 |  | January 28,2023 |
| Cash provided by operating activities |  | $ | 3,179 |  |  | $ | 8,701 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 2,506 |  |  | $ | 1,758 |  |
| Dividends paid |  | $ | 3,163 |  |  | $ | 3,120 |  |

[0000858877-24-000003:mdna:28]
[same as prior period, unchanged from 0000858877-23-000031:mdna:27]

[0000858877-24-000003:mdna:29]
[same as prior period, unchanged from 0000858877-23-000031:mdna:28]

[0000858877-24-000003:mdna:30]
[same as prior period, unchanged from 0000858877-23-000031:mdna:29]

[0000858877-24-000003:mdna:31]
[same as prior period, unchanged from 0000858877-23-000031:mdna:30]

[0000858877-24-000003:mdna:32]
[same as prior period, unchanged from 0000858877-23-000031:mdna:31]

[0000858877-24-000003:mdna:33]
[same as prior period, unchanged from 0000858877-23-000031:mdna:32]

[0000858877-24-000003:mdna:34]
[same as prior period, unchanged from 0000858877-23-000031:mdna:33]

[0000858877-24-000003:mdna:35]
[same as prior period, unchanged from 0000858877-23-000031:mdna:34]

[0000858877-24-000003:mdna:36]
[same as prior period, unchanged from 0000858877-23-000031:mdna:35]

[0000858877-24-000003:mdna:37]
[same as prior period, unchanged from 0000858877-23-000031:mdna:36]

[0000858877-24-000003:mdna:38]
[same as prior period, unchanged from 0000858877-23-000031:mdna:37]

[0000858877-24-000003:mdna:39]
[same as prior period, unchanged from 0000858877-23-000031:mdna:38]

[0000858877-24-000003:mdna:40]
[same as prior period, unchanged from 0000858877-23-000031:mdna:39]

[0000858877-24-000003:mdna:41]
[same as prior period, unchanged from 0000858877-23-000031:mdna:40]

[0000858877-24-000003:mdna:42]
[same as prior period, unchanged from 0000858877-23-000031:mdna:41]

[0000858877-24-000003:mdna:43]
Our provision for inventory was $258 million and $92 million for the first six months of fiscal 2024 and 2023, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $128 million and $199 million for the first six months of fiscal 2024 and 2023, respectively. If there were to be a sudden and significant decrease in demand for our products, if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, or if supply constraints were to continue, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. For further discussion around the Supply Constraints Impacts and Risks, see “—Results of Operations—Gross Margin—Supply Constraints Impacts and Risks” and “—Liquidity and Capital Resources—Inventory Supply Chain.”

[0000858877-24-000003:mdna:44]
Loss Contingencies

[0000858877-24-000003:mdna:45]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-24-000003:mdna:46]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-24-000003:mdna:47]
[same as prior period, unchanged from 0000858877-23-000031:mdna:46]

[0000858877-24-000003:mdna:48]
[same as prior period, unchanged from 0000858877-23-000031:mdna:47]

[0000858877-24-000003:mdna:49]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first six months of fiscal 2024 and 2023.

[0000858877-24-000003:mdna:50]
[same as prior period, unchanged from 0000858877-23-000031:mdna:49]

[0000858877-24-000003:mdna:51]
[same as prior period, unchanged from 0000858877-23-000031:mdna:50]

[0000858877-24-000003:mdna:52]
43

[0000858877-24-000003:mdna:53]
[same as prior period, unchanged from 0000858877-23-000031:mdna:51]

[0000858877-24-000003:mdna:54]
[same as prior period, unchanged from 0000858877-23-000031:mdna:52]

[0000858877-24-000003:mdna:55]
[same as prior period, unchanged from 0000858877-23-000031:mdna:53]

[0000858877-24-000003:mdna:56]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was 16.7% and 18.8% in the second quarter of fiscal 2024 and 2023, respectively, and 17.5% and 21.0% in the first six months of fiscal 2024 and 2023, respectively.

[0000858877-24-000003:mdna:57]
[same as prior period, unchanged from 0000858877-23-000031:mdna:55]

[0000858877-24-000003:mdna:58]
[same as prior period, unchanged from 0000858877-23-000031:mdna:56]

[0000858877-24-000003:mdna:59]
[same as prior period, unchanged from 0000858877-23-000031:mdna:57]

[0000858877-24-000003:mdna:60]
[same as prior period, unchanged from 0000858877-23-000031:mdna:58]

[0000858877-24-000003:mdna:61]
[same as prior period, unchanged from 0000858877-23-000031:mdna:59]

[0000858877-24-000003:mdna:62]
[same as prior period, unchanged from 0000858877-23-000031:mdna:60]

[0000858877-24-000003:mdna:63]
[same as prior period, unchanged from 0000858877-23-000031:mdna:61]

[0000858877-24-000003:mdna:64]
[same as prior period, unchanged from 0000858877-23-000031:mdna:62]

[0000858877-24-000003:mdna:65]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27,2024 |  | January 28,2023 |  | Variancein Dollars |  | Variance in Percent |  | January 27, 2024 |  | January 28, 2023 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,232 |  |  | $ | 10,155 |  |  | $ | (923) |  |  | (9) | % |  | $ | 20,371 |  |  | $ | 20,400 |  |  | $ | (29) |  |  | — | % |
| Percentage of revenue |  | 72.2 | % |  | 74.7 | % |  |  |  |  |  | 74.2 | % |  | 74.9 | % |  |  |  |  |
| Service |  | 3,559 |  |  | 3,437 |  |  | 122 |  |  | 4 | % |  | 7,088 |  |  | 6,824 |  |  | 264 |  |  | 4 | % |
| Percentage of revenue |  | 27.8 | % |  | 25.3 | % |  |  |  |  |  | 25.8 | % |  | 25.1 | % |  |  |  |  |
| Total |  | $ | 12,791 |  |  | $ | 13,592 |  |  | $ | (801) |  |  | (6) | % |  | $ | 27,459 |  |  | $ | 27,224 |  |  | $ | 235 |  |  | 1 | % |

[0000858877-24-000003:mdna:66]
[same as prior period, unchanged from 0000858877-23-000031:mdna:64]

[0000858877-24-000003:mdna:67]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27,2024 |  | January 28,2023 |  | Variancein Dollars |  | Variance in Percent |  | January 27,2024 |  | January 28,2023 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,510 |  |  | $ | 7,825 |  |  | $ | (315) |  |  | (4) | % |  | $ | 16,532 |  |  | $ | 15,738 |  |  | $ | 794 |  |  | 5 | % |
| Percentage of revenue |  | 58.7 | % |  | 57.6 | % |  |  |  |  |  | 60.2 | % |  | 57.8 | % |  |  |  |  |
| EMEA |  | 3,484 |  |  | 3,728 |  |  | (244) |  |  | (7) | % |  | 7,148 |  |  | 7,404 |  |  | (256) |  |  | (3) | % |
| Percentage of revenue |  | 27.2 | % |  | 27.4 | % |  |  |  |  |  | 26.0 | % |  | 27.2 | % |  |  |  |  |
| APJC |  | 1,798 |  |  | 2,039 |  |  | (241) |  |  | (12) | % |  | 3,779 |  |  | 4,082 |  |  | (303) |  |  | (7) | % |
| Percentage of revenue |  | 14.1 | % |  | 15.0 | % |  |  |  |  |  | 13.8 | % |  | 15.0 | % |  |  |  |  |
| Total |  | $ | 12,791 |  |  | $ | 13,592 |  |  | $ | (801) |  |  | (6) | % |  | $ | 27,459 |  |  | $ | 27,224 |  |  | $ | 235 |  |  | 1 | % |

[0000858877-24-000003:mdna:68]
[same as prior period, unchanged from 0000858877-23-000031:mdna:66]

[0000858877-24-000003:mdna:69]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:70]
Total revenue decreased by 6%. Product revenue decreased by 9% and service revenue increased by 4%. Our total revenue reflected declines across each of our geographic segments.

[0000858877-24-000003:mdna:71]
[same as prior period, unchanged from 0000858877-23-000031:mdna:69]

[0000858877-24-000003:mdna:72]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:73]
Total revenue increased by 1%. Product revenue was flat and service revenue increased by 4%. Our total revenue reflected growth in the Americas segment, partially offset by declines in the EMEA and APJC segments.

[0000858877-24-000003:mdna:74]
[same as prior period, unchanged from 0000858877-23-000031:mdna:70]

[0000858877-24-000003:mdna:75]
[same as prior period, unchanged from 0000858877-23-000031:mdna:71]

[0000858877-24-000003:mdna:76]
[same as prior period, unchanged from 0000858877-23-000031:mdna:72]

[0000858877-24-000003:mdna:77]
[same as prior period, unchanged from 0000858877-23-000031:mdna:73]

[0000858877-24-000003:mdna:78]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27,2024 |  | January 28,2023 |  | Variancein Dollars |  | Variance in Percent |  | January 27,2024 |  | January 28,2023 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,346 |  |  | $ | 5,728 |  |  | $ | (382) |  |  | (7) | % |  | $ | 12,197 |  |  | $ | 11,574 |  |  | $ | 623 |  |  | 5 | % |
| Percentage of product revenue |  | 57.9 | % |  | 56.4 | % |  |  |  |  |  | 59.9 | % |  | 56.8 | % |  |  |  |  |
| EMEA |  | 2,638 |  |  | 2,917 |  |  | (279) |  |  | (10) | % |  | 5,478 |  |  | 5,803 |  |  | (325) |  |  | (6) | % |
| Percentage of product revenue |  | 28.6 | % |  | 28.7 | % |  |  |  |  |  | 26.9 | % |  | 28.4 | % |  |  |  |  |
| APJC |  | 1,248 |  |  | 1,510 |  |  | (262) |  |  | (17) | % |  | 2,696 |  |  | 3,023 |  |  | (327) |  |  | (11) | % |
| Percentage of product revenue |  | 13.5 | % |  | 14.9 | % |  |  |  |  |  | 13.2 | % |  | 14.8 | % |  |  |  |  |
| Total |  | $ | 9,232 |  |  | $ | 10,155 |  |  | $ | (923) |  |  | (9) | % |  | $ | 20,371 |  |  | $ | 20,400 |  |  | $ | (29) |  |  | — | % |

[0000858877-24-000003:mdna:79]
[same as prior period, unchanged from 0000858877-23-000031:mdna:75]

[0000858877-24-000003:mdna:80]
[same as prior period, unchanged from 0000858877-23-000031:mdna:77]

[0000858877-24-000003:mdna:81]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:82]
Product revenue in the Americas segment decreased by 7%, with declines in the service provider and cloud and enterprise markets, partially offset by growth in the public sector market. From a country perspective, product revenue decreased in the United States, Canada and Brazil by 6%, 14% and 14%, respectively, partially offset by growth in product revenue in Mexico of 6%.

[0000858877-24-000003:mdna:83]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:84]
Product revenue in the Americas segment increased by 5%, with growth in the public sector market, partially offset by a decline in the service provider and cloud market. Product revenue in the enterprise market was flat. From a country perspective, product revenue increased in the United States and Mexico by 6% and 5%, respectively, partially offset by declines in product revenue in Canada and Brazil of 7% and 3%, respectively.

[0000858877-24-000003:mdna:85]
[same as prior period, unchanged from 0000858877-23-000031:mdna:79]

[0000858877-24-000003:mdna:86]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:87]
Product revenue in the EMEA segment decreased by 10%, driven by declines in the enterprise and service provider and cloud markets, partially offset by growth in the public sector market. From a country perspective, product revenue decreased in Germany, the United Kingdom and France by 20%, 13% and 8%, respectively.

[0000858877-24-000003:mdna:88]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:89]
Product revenue in the EMEA segment decreased by 6%, driven by declines in the enterprise and service provider and cloud markets, partially offset by growth in the public sector market. From a country perspective, product revenue decreased in Germany, the United Kingdom and France by 10%, 9% and 14%, respectively.

[0000858877-24-000003:mdna:90]
[same as prior period, unchanged from 0000858877-23-000031:mdna:81]

[0000858877-24-000003:mdna:91]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:92]
Product revenue in the APJC segment decreased by 17%, with declines across each of the customer markets. From a country perspective, product revenue decreased in Japan, Australia, India and China by 19%, 7%, 27% and 39%, respectively.

[0000858877-24-000003:mdna:93]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:94]
Product revenue in the APJC segment decreased by 11%, with declines across each of the customer markets. From a country perspective, product revenue decreased in Japan, Australia, India and China by 16%, 6%, 7% and 39%, respectively.

[0000858877-24-000003:mdna:95]
[same as prior period, unchanged from 0000858877-23-000031:mdna:83]

[0000858877-24-000003:mdna:96]
[same as prior period, unchanged from 0000858877-23-000031:mdna:84]

[0000858877-24-000003:mdna:97]
[same as prior period, unchanged from 0000858877-23-000031:mdna:85]

[0000858877-24-000003:mdna:98]
[same as prior period, unchanged from 0000858877-23-000031:mdna:86]

[0000858877-24-000003:mdna:99]
[same as prior period, unchanged from 0000858877-23-000031:mdna:87]

[0000858877-24-000003:mdna:100]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27,2024 |  | January 28,2023 |  | Variancein Dollars |  | Variance in Percent |  | January 27, 2024 |  | January 28, 2023 |  | Variance in Dollars |  | Variance in Percent |
| Product Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking |  | $ | 7,081 |  |  | $ | 8,092 |  |  | $ | (1,011) |  |  | (12) | % |  | $ | 15,904 |  |  | $ | 16,123 |  |  | $ | (219) |  |  | (1) | % |
| Security |  | 973 |  |  | 943 |  |  | 30 |  |  | 3 | % |  | 1,984 |  |  | 1,914 |  |  | 70 |  |  | 4 | % |
| Collaboration |  | 989 |  |  | 958 |  |  | 31 |  |  | 3 | % |  | 2,106 |  |  | 2,044 |  |  | 62 |  |  | 3 | % |
| Observability |  | 188 |  |  | 162 |  |  | 26 |  |  | 16 | % |  | 378 |  |  | 319 |  |  | 59 |  |  | 18 | % |
| Total |  | $ | 9,232 |  |  | $ | 10,155 |  |  | $ | (923) |  |  | (9) | % |  | $ | 20,371 |  |  | $ | 20,400 |  |  | $ | (29) |  |  | — | % |

[0000858877-24-000003:mdna:101]
[same as prior period, unchanged from 0000858877-23-000031:mdna:89]

[0000858877-24-000003:mdna:102]
[same as prior period, unchanged from 0000858877-23-000031:mdna:91]

[0000858877-24-000003:mdna:103]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:104]
The Networking product category represents our core networking technologies of switching, routing, wireless, 5G, silicon, optics solutions and compute products. Revenue from the Networking product category decreased by 12%, or $1.0 billion. Revenue declined in both campus switching and data center switching, as well as in wireless and routed optical networking. The revenue declines in the Networking product category were primarily in the enterprise and service provider and cloud markets.

[0000858877-24-000003:mdna:105]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:106]
Revenue from the Networking product category decreased by 1%, or $219 million. Revenue grew in both campus switching and data center switching, primarily driven by growth in our Catalyst 9000 series and Nexus 9000 series offerings. We experienced a revenue decline in enterprise routing, although we saw revenue growth in our SD-WAN offerings. The decrease in wireless was primarily driven by our WiFi-6 products and Meraki offerings. We also saw a revenue decline in routed optical networking, although we saw revenue growth in our Cisco 8000 series offerings.

[0000858877-24-000003:mdna:107]
[same as prior period, unchanged from 0000858877-23-000031:mdna:93]

[0000858877-24-000003:mdna:108]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:109]
The Security product category consists of our Cloud and Application Security, Industrial Security, Network Security, and User and Device Security offerings. Revenue in our Security product category increased by 3%, or $30 million, primarily driven by double-digit growth in our Zero Trust offerings.

[0000858877-24-000003:mdna:110]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:111]
Revenue from the Security product category increased by 4%, or $70 million, primarily driven by growth in our Zero Trust and Threat Intelligence, Detection and Response offerings.

[0000858877-24-000003:mdna:112]
[same as prior period, unchanged from 0000858877-23-000031:mdna:95]

[0000858877-24-000003:mdna:113]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:114]
The Collaboration product category consists of our Meetings, Collaboration Devices, Calling, Contact Center and CPaaS offerings. Revenue in our Collaboration product category increased by 3%, or $31 million, primarily driven by growth in our Collaboration Devices and Calling offerings, partially offset by a decline in Meetings.

[0000858877-24-000003:mdna:115]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:116]
Revenue from our Collaboration product category increased by 3%, or $62 million, primarily driven by growth in Calling and Collaboration Devices, partially offset by a decline in Meetings.

[0000858877-24-000003:mdna:117]
[same as prior period, unchanged from 0000858877-23-000031:mdna:99]

[0000858877-24-000003:mdna:118]
[same as prior period, unchanged from 0000858877-23-000031:mdna:100]

[0000858877-24-000003:mdna:119]
[same as prior period, unchanged from 0000858877-23-000031:mdna:97]

[0000858877-24-000003:mdna:120]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:121]
The Observability product category consists of our full stack observability offerings. Revenue in our Observability product category increased 16%, or $26 million, driven by growth across the portfolio, including double-digit growth in our ThousandEyes offerings.

[0000858877-24-000003:mdna:122]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:123]
Revenue from the Observability product category increased by 18%, or $59 million, driven by primarily driven by growth in our ThousandEyes offerings.

[0000858877-24-000003:mdna:124]
[same as prior period, unchanged from 0000858877-23-000031:mdna:101]

[0000858877-24-000003:mdna:125]
[same as prior period, unchanged from 0000858877-23-000031:mdna:102]

[0000858877-24-000003:mdna:126]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27,2024 |  | January 28,2023 |  | Variancein Dollars |  | Variance in Percent |  | January 27, 2024 |  | January 28, 2023 |  | Variance in Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,164 |  |  | $ | 2,097 |  |  | $ | 67 |  |  | 3 | % |  | $ | 4,335 |  |  | $ | 4,164 |  |  | $ | 171 |  |  | 4 | % |
| Percentage of service revenue |  | 60.8 | % |  | 61.0 | % |  |  |  |  |  | 61.2 | % |  | 61.0 | % |  |  |  |  |
| EMEA |  | 846 |  |  | 812 |  |  | 34 |  |  | 4 | % |  | 1,670 |  |  | 1,601 |  |  | 69 |  |  | 4 | % |
| Percentage of service revenue |  | 23.8 | % |  | 23.6 | % |  |  |  |  |  | 23.6 | % |  | 23.5 | % |  |  |  |  |
| APJC |  | 550 |  |  | 529 |  |  | 21 |  |  | 4 | % |  | 1,084 |  |  | 1,059 |  |  | 25 |  |  | 2 | % |
| Percentage of service revenue |  | 15.4 | % |  | 15.4 | % |  |  |  |  |  | 15.2 | % |  | 15.5 | % |  |  |  |  |
| Total |  | $ | 3,559 |  |  | $ | 3,437 |  |  | $ | 122 |  |  | 4 | % |  | $ | 7,088 |  |  | $ | 6,824 |  |  | $ | 264 |  |  | 4 | % |

[0000858877-24-000003:mdna:127]
[same as prior period, unchanged from 0000858877-23-000031:mdna:104]

[0000858877-24-000003:mdna:128]
Service revenue increased 4% in the second quarter of fiscal 2024 compared with the second quarter of fiscal 2023, primarily driven by revenue growth in our solution support and advisory services, partially offset by declines in our software support offerings. Service revenue increased across each of our geographic segments for the second quarter of fiscal 2024.

[0000858877-24-000003:mdna:129]
Service revenue increased 4% in the first six months of fiscal 2024 compared to the first six months of fiscal 2023, primarily driven by revenue growth in our solution support offerings, advisory services and maintenance business, partially offset by declines in our software support offerings. Service revenue increased across each of our geographic segments.

[0000858877-24-000003:mdna:130]
[same as prior period, unchanged from 0000858877-23-000031:mdna:106]

[0000858877-24-000003:mdna:131]
[same as prior period, unchanged from 0000858877-23-000031:mdna:107]

[0000858877-24-000003:mdna:132]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,789 |  |  | $ | 6,117 |  |  | 62.7 | % |  | 60.2 | % |  | $ | 12,971 |  |  | $ | 12,183 |  |  | 63.7 | % |  | 59.7 | % |
| Service |  | 2,428 |  |  | 2,310 |  |  | 68.2 | % |  | 67.2 | % |  | 4,803 |  |  | 4,590 |  |  | 67.8 | % |  | 67.3 | % |
| Total |  | $ | 8,217 |  |  | $ | 8,427 |  |  | 64.2 | % |  | 62.0 | % |  | $ | 17,774 |  |  | $ | 16,773 |  |  | 64.7 | % |  | 61.6 | % |

[0000858877-24-000003:mdna:133]
[same as prior period, unchanged from 0000858877-23-000031:mdna:115]

[0000858877-24-000003:mdna:134]
[same as prior period, unchanged from 0000858877-23-000031:mdna:116]

[0000858877-24-000003:mdna:135]
[same as prior period, unchanged from 0000858877-23-000031:mdna:109]

[0000858877-24-000003:mdna:136]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the second quarter and first six months of fiscal 2024, as compared with the corresponding prior year periods:

[0000858877-24-000003:mdna:137]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Six Months Ended |
| Fiscal 2023 |  | 60.2 | % |  | 59.7 | % |
| Productivity (1) |  | 2.6 | % |  | 2.7 | % |
| Product pricing |  | (0.5) | % |  | 0.6 | % |
| Mix of products sold |  | 1.0 | % |  | 1.1 | % |
| Others |  | (0.6) | % |  | (0.4) | % |
| Fiscal 2024 |  | 62.7 | % |  | 63.7 | % |

[0000858877-24-000003:mdna:138]
[same as prior period, unchanged from 0000858877-23-000031:mdna:112]

[0000858877-24-000003:mdna:139]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:140]
Product gross margin increased by 2.5 percentage points primarily driven by productivity improvements, largely driven by lower freight, logistics and components costs, and favorable product mix. These impacts were partially offset by pricing erosion.

[0000858877-24-000003:mdna:141]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:142]
Product gross margin increased by 4.0 percentage points primarily driven by productivity improvements, largely driven by lower freight, logistics and components costs, favorable product mix and favorable pricing.

[0000858877-24-000003:mdna:143]
[same as prior period, unchanged from 0000858877-23-000031:mdna:117]

[0000858877-24-000003:mdna:144]
In past periods, we took multiple actions in order to mitigate component shortages and address significant supply constraints. Additionally, these supply constraints resulted in significant increased costs (i.e., component and other commodity costs, expedite fees, etc.) which had a negative impact on our product gross margin and resulted in extended lead times for us and our customers. The mitigating actions we took included: partnering with several of our key suppliers utilizing our volume purchasing ability and extending supply coverage, including, in certain cases, revising supplier arrangements; paying and committing to pay in the future significantly higher costs for certain components; modifying our product designs in order to leverage alternate suppliers, where possible; and continually optimizing our inventory build and customer delivery plans, among others. These mitigating actions have resulted in increased inventory supply chain balances compared to historical levels. This in turn has increased our supply chain exposure, which could result in negative impacts to our product gross margin in future periods, including material excess and obsolete charges, if product demand significantly decreases for a sustained duration or we are unable to continue to mitigate the remaining supply chain exposures. We believe these mitigating actions have helped us to optimize our access to critical components and meet customer demand for our products as a result of the component shortages and significant supply constraints we saw in past periods. While we have seen a decrease in our overall inventory supply chain balances in recent periods, these balances continue to be higher as compared to historical levels.

[0000858877-24-000003:mdna:145]
[same as prior period, unchanged from 0000858877-23-000031:mdna:119]

[0000858877-24-000003:mdna:146]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:147]
Our service gross margin percentage increased by 1.0 percentage points primarily due to higher sales volume and lower delivery costs, partially offset by higher headcount-related costs and unfavorable mix of service offerings.

[0000858877-24-000003:mdna:148]
[same as prior period, unchanged from 0000858877-23-000031:mdna:121]

[0000858877-24-000003:mdna:149]
[same as prior period, unchanged from 0000858877-23-000031:mdna:131]

[0000858877-24-000003:mdna:150]
[same as prior period, unchanged from 0000858877-23-000031:mdna:132]

[0000858877-24-000003:mdna:151]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:152]
Service gross margin increased by 0.5 percentage points primarily due to higher sales volume and lower delivery costs, partially offset by higher headcount-related costs and unfavorable mix of service offerings.

[0000858877-24-000003:mdna:153]
[same as prior period, unchanged from 0000858877-23-000031:mdna:122]

[0000858877-24-000003:mdna:154]
[same as prior period, unchanged from 0000858877-23-000031:mdna:123]

[0000858877-24-000003:mdna:155]
|  | Three Months Ended |  | Six Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,932 |  |  | $ | 4,920 |  |  | 65.7 | % |  | 62.9 | % |  | $ | 10,901 |  |  | $ | 9,904 |  |  | 65.9 | % |  | 62.9 | % |
| EMEA | 2,373 |  |  | 2,469 |  |  | 68.1 | % |  | 66.2 | % |  | 4,919 |  |  | 4,795 |  |  | 68.8 | % |  | 64.8 | % |
| APJC | 1,226 |  |  | 1,298 |  |  | 68.2 | % |  | 63.6 | % |  | 2,554 |  |  | 2,571 |  |  | 67.6 | % |  | 63.0 | % |
| Segment total | 8,532 |  |  | 8,687 |  |  | 66.7 | % |  | 63.9 | % |  | 18,373 |  |  | 17,269 |  |  | 66.9 | % |  | 63.4 | % |
| Unallocated corporate items (1) | (315) |  |  | (260) |  |  |  |  |  |  | (599) |  |  | (496) |  |  |  |  |  |
| Total | $ | 8,217 |  |  | $ | 8,427 |  |  | 64.2 | % |  | 62.0 | % |  | $ | 17,774 |  |  | $ | 16,773 |  |  | 64.7 | % |  | 61.6 | % |

[0000858877-24-000003:mdna:156]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-24-000003:mdna:157]
[same as prior period, unchanged from 0000858877-23-000031:mdna:126]

[0000858877-24-000003:mdna:158]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:159]
We experienced a gross margin percentage increase in our Americas segment due to positive impacts from productivity improvements, favorable product mix and higher service gross margin, slightly offset by pricing erosion.

[0000858877-24-000003:mdna:160]
Gross margin percentage in our EMEA segment increased primarily due to positive impacts from productivity improvements, and, to a lesser extent, favorable product mix, partially offset by pricing erosion.

[0000858877-24-000003:mdna:161]
The APJC segment gross margin percentage increase was primarily due to positive impacts from productivity improvements and favorable product mix, partially offset by pricing erosion and lower service gross margin.

[0000858877-24-000003:mdna:162]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:163]
The Americas segment had a gross margin percentage increase driven by positive impacts from productivity improvements, favorable pricing and, to a lesser extent, favorable product mix.

[0000858877-24-000003:mdna:164]
The gross margin percentage increase in our EMEA segment was primarily due to positive impacts from productivity improvements and favorable product mix, partially offset by pricing erosion.

[0000858877-24-000003:mdna:165]
The APJC segment gross margin percentage increase was driven by positive impacts from productivity improvements and favorable product mix, partially offset by pricing erosion.

[0000858877-24-000003:mdna:166]
[same as prior period, unchanged from 0000858877-23-000031:mdna:151]

[0000858877-24-000003:mdna:167]
[same as prior period, unchanged from 0000858877-23-000031:mdna:152]

[0000858877-24-000003:mdna:168]
[same as prior period, unchanged from 0000858877-23-000031:mdna:134]

[0000858877-24-000003:mdna:169]
[same as prior period, unchanged from 0000858877-23-000031:mdna:135]

[0000858877-24-000003:mdna:170]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |  | Variancein Dollars |  | Variance in Percent |  | January 27, 2024 |  | January 28, 2023 |  | Variance in Dollars |  | Variance in Percent |
| Research and development | $ | 1,943 |  |  | $ | 1,855 |  |  | $ | 88 |  |  | 5 | % |  | $ | 3,856 |  |  | $ | 3,636 |  |  | $ | 220 |  |  | 6 | % |
| Percentage of revenue | 15.2 | % |  | 13.6 | % |  |  |  |  |  | 14.0 | % |  | 13.4 | % |  |  |  |  |
| Sales and marketing | 2,458 |  |  | 2,384 |  |  | 74 |  |  | 3 | % |  | 4,964 |  |  | 4,775 |  |  | 189 |  |  | 4 | % |
| Percentage of revenue | 19.2 | % |  | 17.5 | % |  |  |  |  |  | 18.1 | % |  | 17.5 | % |  |  |  |  |
| General and administrative | 642 |  |  | 582 |  |  | 60 |  |  | 10 | % |  | 1,314 |  |  | 1,147 |  |  | 167 |  |  | 15 | % |
| Percentage of revenue | 5.0 | % |  | 4.3 | % |  |  |  |  |  | 4.8 | % |  | 4.2 | % |  |  |  |  |
| Total | $ | 5,043 |  |  | $ | 4,821 |  |  | $ | 222 |  |  | 5 | % |  | $ | 10,134 |  |  | $ | 9,558 |  |  | $ | 576 |  |  | 6 | % |
| Percentage of revenue | 39.4 | % |  | 35.5 | % |  |  |  |  |  | 36.9 | % |  | 35.1 | % |  |  |  |  |

[0000858877-24-000003:mdna:171]
[same as prior period, unchanged from 0000858877-23-000031:mdna:138]

[0000858877-24-000003:mdna:172]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:173]
R&D expenses increased due to higher share-based compensation expense and higher discretionary spending, partially offset by lower headcount-related expenses and lower contracted services spending.

[0000858877-24-000003:mdna:174]
[same as prior period, unchanged from 0000858877-23-000031:mdna:140]

[0000858877-24-000003:mdna:175]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:176]
R&D expenses increased due to higher share-based compensation expense, higher discretionary spending and higher headcount-related expenses, partially offset by lower contracted services spending.

[0000858877-24-000003:mdna:177]
[same as prior period, unchanged from 0000858877-23-000031:mdna:141]

[0000858877-24-000003:mdna:178]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:179]
Sales and marketing expenses increased primarily due to higher share-based compensation expense, higher discretionary spending and higher headcount-related expenses, partially offset by lower contracted services spending.

[0000858877-24-000003:mdna:180]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:181]
Sales and marketing expenses increased primarily due to higher share-based compensation expense, higher discretionary spending and higher headcount-related expenses, partially offset by lower contracted services spending.

[0000858877-24-000003:mdna:182]
[same as prior period, unchanged from 0000858877-23-000031:mdna:143]

[0000858877-24-000003:mdna:183]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:184]
G&A expenses increased due to higher share-based compensation expense, higher discretionary spending, higher acquisition and divestitures related costs, higher headcount-related expenses, and higher contracted services spending.

[0000858877-24-000003:mdna:185]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:186]
G&A expenses increased due to higher share-based compensation expense, higher discretionary spending, higher acquisition and divestitures related costs, higher headcount-related expenses, and higher contracted services spending.

[0000858877-24-000003:mdna:187]
[same as prior period, unchanged from 0000858877-23-000031:mdna:145]

[0000858877-24-000003:mdna:188]
In the second quarter of fiscal 2024, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $23 million, or 0.5%, compared with the second quarter of fiscal 2023.

[0000858877-24-000003:mdna:189]
In the first six months of fiscal 2024, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $49 million, or 0.5%, compared with the first six months of fiscal 2023.

[0000858877-24-000003:mdna:190]
[same as prior period, unchanged from 0000858877-23-000031:mdna:173]

[0000858877-24-000003:mdna:191]
[same as prior period, unchanged from 0000858877-23-000031:mdna:166]

[0000858877-24-000003:mdna:192]
[same as prior period, unchanged from 0000858877-23-000031:mdna:167]

[0000858877-24-000003:mdna:193]
[same as prior period, unchanged from 0000858877-23-000031:mdna:147]

[0000858877-24-000003:mdna:194]
[same as prior period, unchanged from 0000858877-23-000031:mdna:148]

[0000858877-24-000003:mdna:195]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 180 |  |  | $ | 158 |  |  | $ | 366 |  |  | $ | 316 |  |
| Operating expenses |  | 66 |  |  | 71 |  |  | 133 |  |  | 142 |  |
| Total |  | $ | 246 |  |  | $ | 229 |  |  | $ | 499 |  |  | $ | 458 |  |

[0000858877-24-000003:mdna:196]
For each of the second quarter and first six months of fiscal 2024, the increase in amortization of purchased intangible assets was primarily due to amortization of purchased intangibles from our recent acquisitions, partially offset by certain purchased intangible assets that became fully amortized.

[0000858877-24-000003:mdna:197]
[same as prior period, unchanged from 0000858877-23-000031:mdna:153]

[0000858877-24-000003:mdna:198]
In the third quarter of fiscal 2024, we initiated a restructuring plan in order to realign the organization and enable further investment in key priority areas. This restructuring plan will impact approximately 5% of our global workforce. The total pretax charges are estimated to be approximately $800 million. We expect this plan to be substantially completed during the first half of fiscal 2025. We expect to reinvest substantially all of the cost savings from this restructuring plan in our key priority areas. As a result, the overall cost savings from this restructuring plan are not expected to be material for future periods.

[0000858877-24-000003:mdna:199]
In the second quarter of fiscal 2023, we announced a restructuring plan in order to rebalance the organization and enable further investment in key priority areas. In connection with this restructuring plan, we incurred charges of $12 million and $135 million in the second quarter and first six months of fiscal 2024 and have incurred cumulative charges of $670 million to date. We completed this restructuring plan in the second quarter of fiscal 2024. We expect to reinvest substantially all of the cost savings from this restructuring plan in our key priority areas. As a result, the overall cost savings from this restructuring plan are not expected to be material for future periods.

[0000858877-24-000003:mdna:200]
[same as prior period, unchanged from 0000858877-23-000031:mdna:155]

[0000858877-24-000003:mdna:201]
[same as prior period, unchanged from 0000858877-23-000031:mdna:156]

[0000858877-24-000003:mdna:202]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Operating income |  | $ | 3,096 |  |  | $ | 3,292 |  |  | $ | 7,372 |  |  | $ | 6,832 |  |
| Operating income as a percentage of revenue |  | 24.2 | % |  | 24.2 | % |  | 26.8 | % |  | 25.1 | % |

[0000858877-24-000003:mdna:203]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:204]
Operating income decreased by 6%, and operating income as a percentage of revenue was flat. These changes resulted primarily from a revenue decrease partially offset by a gross margin percentage increase (driven by productivity improvements and favorable product mix, partially offset by pricing erosion).

[0000858877-24-000003:mdna:205]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:206]
Operating income increased by 8%, and operating income as a percentage of revenue increased by 1.7 percentage points. These changes resulted primarily from a revenue increase and gross margin percentage increase (driven by productivity improvements, favorable product mix and favorable pricing), partially offset by higher operating expenses.

[0000858877-24-000003:mdna:207]
[same as prior period, unchanged from 0000858877-23-000031:mdna:174]

[0000858877-24-000003:mdna:208]
[same as prior period, unchanged from 0000858877-23-000031:mdna:175]

[0000858877-24-000003:mdna:209]
[same as prior period, unchanged from 0000858877-23-000031:mdna:160]

[0000858877-24-000003:mdna:210]
[same as prior period, unchanged from 0000858877-23-000031:mdna:161]

[0000858877-24-000003:mdna:211]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27,2024 |  | January 28,2023 |  | Variancein Dollars |  | January 27, 2024 |  | January 28, 2023 |  | Variance in Dollars |
| Interest income |  | $ | 324 |  |  | $ | 219 |  |  | $ | 105 |  |  | $ | 684 |  |  | $ | 388 |  |  | $ | 296 |  |
| Interest expense |  | (120) |  |  | (107) |  |  | (13) |  |  | (231) |  |  | (207) |  |  | (24) |  |
| Interest income (expense), net |  | $ | 204 |  |  | $ | 112 |  |  | $ | 92 |  |  | $ | 453 |  |  | $ | 181 |  |  | $ | 272 |  |

[0000858877-24-000003:mdna:212]
For each of the second quarter and first six months of fiscal 2024, the increase in interest income was driven by higher average balance of cash and available-for-sale debt investments and higher interest rates. The increase in interest expense was primarily driven by higher interest rates and issuance of commercial paper notes, partially offset by a lower average long-term debt balance.

[0000858877-24-000003:mdna:213]
[same as prior period, unchanged from 0000858877-23-000031:mdna:164]

[0000858877-24-000003:mdna:214]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27,2024 |  | January 28,2023 |  | Variancein Dollars |  | January 27, 2024 |  | January 28, 2023 |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | (23) |  |  | $ | (3) |  |  | $ | (20) |  |  | $ | (43) |  |  | $ | (9) |  |  | $ | (34) |  |
| Marketable equity investments |  | 62 |  |  | 19 |  |  | 43 |  |  | 16 |  |  | (2) |  |  | 18 |  |
| Privately held investments |  | (150) |  |  | 19 |  |  | (169) |  |  | (155) |  |  | (73) |  |  | (82) |  |
| Net gains (losses) on investments |  | (111) |  |  | 35 |  |  | (146) |  |  | (182) |  |  | (84) |  |  | (98) |  |
| Other gains (losses), net |  | (28) |  |  | (24) |  |  | (4) |  |  | (40) |  |  | (39) |  |  | (1) |  |
| Other income (loss), net |  | $ | (139) |  |  | $ | 11 |  |  | $ | (150) |  |  | $ | (222) |  |  | $ | (123) |  |  | $ | (99) |  |

[0000858877-24-000003:mdna:215]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:216]
The change in our other income (loss), net was primarily driven by impairment charges on our privately held investments and changes in net gains (losses) on available-for-sale debt investments and marketable equity investments.

[0000858877-24-000003:mdna:217]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:218]
The change in our other income (loss), net was primarily driven by impairment charges on our privately held investments, lower realized losses on our privately held investments, and changes in net gain (losses) on available-for-sale debt investments and marketable equity investments.

[0000858877-24-000003:mdna:219]
[same as prior period, unchanged from 0000858877-23-000031:mdna:170]

[0000858877-24-000003:mdna:220]
Three Months Ended January 27, 2024 Compared with Three Months Ended January 28, 2023

[0000858877-24-000003:mdna:221]
The provision for income taxes resulted in an effective tax rate of 16.7% for the second quarter of fiscal 2024 compared with 18.8% for the second quarter of fiscal 2023. The decrease in the effective tax rate was primarily due to an increase in share-based compensation windfall benefit and an increase in the benefit from income taxed at other than U.S. rates, partially offset by a decrease in foreign derived intangible income deduction benefit.

[0000858877-24-000003:mdna:222]
Six Months Ended January 27, 2024 Compared with Six Months Ended January 28, 2023

[0000858877-24-000003:mdna:223]
The provision for income taxes resulted in an effective tax rate of 17.5% for the first six months of fiscal 2024 compared with 21.0% for the first six months of fiscal 2023. The decrease in the effective tax rate was primarily due to an increase in the benefit from income taxed at other than U.S. rates and a decrease in net discrete tax expenses, partially offset by a decrease in foreign derived intangible income deduction benefit.

[0000858877-24-000003:mdna:224]
[same as prior period, unchanged from 0000858877-23-000031:mdna:188]

[0000858877-24-000003:mdna:225]
[same as prior period, unchanged from 0000858877-23-000031:mdna:189]

[0000858877-24-000003:mdna:226]
[same as prior period, unchanged from 0000858877-23-000031:mdna:176]

[0000858877-24-000003:mdna:227]
[same as prior period, unchanged from 0000858877-23-000031:mdna:177]

[0000858877-24-000003:mdna:228]
[same as prior period, unchanged from 0000858877-23-000031:mdna:178]

[0000858877-24-000003:mdna:229]
[same as prior period, unchanged from 0000858877-23-000031:mdna:179]

[0000858877-24-000003:mdna:230]
|  | January 27,2024 |  | July 29,2023 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 13,715 |  |  | $ | 10,123 |  |  | $ | 3,592 |  |
| Available-for-sale debt investments | 11,530 |  |  | 15,592 |  |  | (4,062) |  |
| Marketable equity securities | 426 |  |  | 431 |  |  | (5) |  |
| Total | $ | 25,671 |  |  | $ | 26,146 |  |  | $ | (475) |  |

[0000858877-24-000003:mdna:231]
The net decrease in cash and cash equivalents and investments in the first six months of fiscal 2024 was primarily driven by cash returned to stockholders in the form of cash dividends of $3.2 billion and repurchases of common stock of $2.5 billion, net cash paid for acquisitions and divestitures of $0.9 billion, a net decrease of debt of $0.8 billion and capital expenditures of $0.3 billion. These uses of cash were partially offset by issuance of commercial paper notes, net of $3.9 billion and net cash provided by operating activities of $3.2 billion. The net cash provided by operating activities for the first six months of fiscal 2024 includes the fiscal 2023 federal tax payment of $2.8 billion that was deferred by the IRS as a result of the California floods and the U.S. transition tax payment of $1.4 billion.

[0000858877-24-000003:mdna:232]
[same as prior period, unchanged from 0000858877-23-000031:mdna:182]

[0000858877-24-000003:mdna:233]
[same as prior period, unchanged from 0000858877-23-000031:mdna:183]

[0000858877-24-000003:mdna:234]
Securities Lending   We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 27, 2024 and July 29, 2023, we had no outstanding securities lending transactions.

[0000858877-24-000003:mdna:235]
[same as prior period, unchanged from 0000858877-23-000031:mdna:185]

[0000858877-24-000003:mdna:236]
[same as prior period, unchanged from 0000858877-23-000031:mdna:186]

[0000858877-24-000003:mdna:237]
|  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |
| Net cash provided by operating activities | $ | 3,179 |  |  | $ | 8,701 |  |
| Acquisition of property and equipment | (304) |  |  | (346) |  |
| Free cash flow | $ | 2,875 |  |  | $ | 8,355 |  |

[0000858877-24-000003:mdna:238]
[same as prior period, unchanged from 0000858877-23-000031:mdna:199]

[0000858877-24-000003:mdna:239]
[same as prior period, unchanged from 0000858877-23-000031:mdna:200]

[0000858877-24-000003:mdna:240]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue, and the timing and amount of tax and other payments. For additional discussion, see “Part II, Item 1A. Risk Factors” in this report.

[0000858877-24-000003:mdna:241]
[same as prior period, unchanged from 0000858877-23-000031:mdna:191]

[0000858877-24-000003:mdna:242]
[same as prior period, unchanged from 0000858877-23-000031:mdna:192]

[0000858877-24-000003:mdna:243]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| January 27, 2024 |  | $ | 0.39 |  |  | $ | 1,583 |  |  | 25 |  |  | $ | 49.54 |  |  | $ | 1,254 |  |  | $ | 2,837 |  |
| October 28, 2023 |  | $ | 0.39 |  |  | $ | 1,580 |  |  | 23 |  |  | $ | 54.53 |  |  | $ | 1,252 |  |  | $ | 2,832 |  |
| Fiscal 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 29, 2023 |  | $ | 0.39 |  |  | $ | 1,589 |  |  | 25 |  |  | $ | 50.49 |  |  | $ | 1,254 |  |  | $ | 2,843 |  |
| April 29, 2023 |  | $ | 0.39 |  |  | $ | 1,593 |  |  | 25 |  |  | $ | 49.45 |  |  | $ | 1,259 |  |  | $ | 2,852 |  |
| January 28, 2023 |  | $ | 0.38 |  |  | $ | 1,560 |  |  | 26 |  |  | $ | 47.72 |  |  | $ | 1,256 |  |  | $ | 2,816 |  |
| October 29, 2022 |  | $ | 0.38 |  |  | $ | 1,560 |  |  | 12 |  |  | $ | 43.76 |  |  | $ | 502 |  |  | $ | 2,062 |  |

[0000858877-24-000003:mdna:244]
On February 14, 2024, our Board of Directors declared a quarterly dividend of $0.40 per common share to be paid on April 24, 2024, to all stockholders of record as of the close of business on April 4, 2024. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-24-000003:mdna:245]
The remaining authorized amount for stock repurchases under this program is approximately $8.4 billion, with no termination date.

[0000858877-24-000003:mdna:246]
[same as prior period, unchanged from 0000858877-23-000031:mdna:196]

[0000858877-24-000003:mdna:247]
|  | January 27,2024 |  | July 29,2023 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,884 |  |  | $ | 5,854 |  |  | $ | (970) |  |

[0000858877-24-000003:mdna:248]
Our accounts receivable net, as of January 27, 2024 decreased by approximately 17%, as compared with the end of fiscal 2023, primarily due to timing and amount of product and service billings in the second quarter of fiscal 2024 compared with the fourth quarter of fiscal 2023.

[0000858877-24-000003:mdna:249]
[same as prior period, unchanged from 0000858877-23-000031:mdna:213]

[0000858877-24-000003:mdna:250]
[same as prior period, unchanged from 0000858877-23-000031:mdna:214]

[0000858877-24-000003:mdna:251]
[same as prior period, unchanged from 0000858877-23-000031:mdna:201]

[0000858877-24-000003:mdna:252]
|  | January 27,2024 |  | July 29,2023 |  | July 30,2022 |  | Variance vs. July 29, 2023 |  | Variance vs. July 30, 2022 |
| Inventories | $ | 3,209 |  |  | $ | 3,644 |  |  | $ | 2,568 |  |  | $ | (435) |  |  | $ | 641 |  |
| Inventory purchase commitments | $ | 6,193 |  |  | $ | 7,253 |  |  | $ | 12,964 |  |  | $ | (1,060) |  |  | $ | (6,771) |  |
| Inventory deposits and prepayments | $ | 1,160 |  |  | $ | 1,109 |  |  | $ | 1,484 |  |  | $ | 51 |  |  | $ | (324) |  |

[0000858877-24-000003:mdna:253]
[same as prior period, unchanged from 0000858877-23-000031:mdna:203]

[0000858877-24-000003:mdna:254]
|  | January 27,2024 |  | July 29,2023 |  | July 30,2022 |  | Variance vs. July 29, 2023 |  | Variance vs.July 30, 2022 |
| Less than 1 year | $ | 4,711 |  |  | $ | 5,270 |  |  | $ | 9,954 |  |  | $ | (559) |  |  | $ | (5,243) |  |
| 1 to 3 years | 1,456 |  |  | 1,783 |  |  | 2,240 |  |  | (327) |  |  | (784) |  |
| 3 to 5 years | 26 |  |  | 200 |  |  | 770 |  |  | (174) |  |  | (744) |  |
| Total | $ | 6,193 |  |  | $ | 7,253 |  |  | $ | 12,964 |  |  | $ | (1,060) |  |  | $ | (6,771) |  |

[0000858877-24-000003:mdna:255]
Inventory as of January 27, 2024 decreased by 12% and inventory purchase commitments with contract manufacturers and suppliers decreased by 15% from our balances at the end of fiscal 2023. The combined decrease of 14% in our inventory and inventory purchase commitments as compared with the end of fiscal 2023 was primarily due to fulfillment of customer demand as overall supply constraints improved and our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitment levels.

[0000858877-24-000003:mdna:256]
We began increasing our inventory supply chain balances starting in fiscal 2021 in order to address significant supply constraints seen industry-wide. The increases were primarily due to arrangements to secure supply and pricing for certain product components and commitments with contract manufacturers to meet customer demand and to address extended lead times, as well as advance payments with suppliers to secure future supply, as a result of the supply constraints. As discussed, our risks of future material excess and obsolete inventory and related losses are further outlined in the Result of Operations—Product Gross Margin section.

[0000858877-24-000003:mdna:257]
[same as prior period, unchanged from 0000858877-23-000031:mdna:207]

[0000858877-24-000003:mdna:258]
[same as prior period, unchanged from 0000858877-23-000031:mdna:208]

[0000858877-24-000003:mdna:259]
[same as prior period, unchanged from 0000858877-23-000031:mdna:209]

[0000858877-24-000003:mdna:260]
[same as prior period, unchanged from 0000858877-23-000031:mdna:210]

[0000858877-24-000003:mdna:261]
|  | January 27,2024 |  | July 29,2023 |  | Increase (Decrease) |
| Loan receivables, net | $ | 5,797 |  |  | $ | 5,857 |  |  | $ | (60) |  |
| Lease receivables, net | 1,043 |  |  | 978 |  |  | 65 |  |
| Total, net | $ | 6,840 |  |  | $ | 6,835 |  |  | $ | 5 |  |

[0000858877-24-000003:mdna:262]
[same as prior period, unchanged from 0000858877-23-000031:mdna:225]

[0000858877-24-000003:mdna:263]
[same as prior period, unchanged from 0000858877-23-000031:mdna:226]

[0000858877-24-000003:mdna:264]
Financing Receivables  Our financing arrangements include loans and leases. Our loan receivables include customer financing for purchases of our hardware, software and services (including technical support and advanced services), and also may include additional funds for other costs associated with network installation and integration of our products and services. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Financing receivables was flat as compared with the end of fiscal 2023.

[0000858877-24-000003:mdna:265]
[same as prior period, unchanged from 0000858877-23-000031:mdna:216]

[0000858877-24-000003:mdna:266]
The volume of channel partner financing was $14.8 billion and $15.1 billion for the first six months of fiscal 2024 and 2023, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.7 billion as of January 27, 2024 and July 29, 2023, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of January 27, 2024, the total maximum potential future payments related to these guarantees was approximately $138 million, of which approximately $23 million was recorded as deferred revenue.

[0000858877-24-000003:mdna:267]
[same as prior period, unchanged from 0000858877-23-000031:mdna:218]

[0000858877-24-000003:mdna:268]
[same as prior period, unchanged from 0000858877-23-000031:mdna:219]

[0000858877-24-000003:mdna:269]
|  | Maturity Date |  | January 27,2024 |  | July 29,2023 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | $ | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 7,750 |  |  | $ | 8,500 |  |

[0000858877-24-000003:mdna:270]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of January 27, 2024.

[0000858877-24-000003:mdna:271]
Commercial Paper  Effective February 6, 2024, we increased our borrowing capacity under our commercial paper program from $10.0 billion to $15.0 billion. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had $3.9 billion and no commercial paper notes outstanding as of January 27, 2024 and July 29, 2023, respectively. As of February 19, 2024, we had approximately $6.9 billion of commercial paper notes outstanding.

[0000858877-24-000003:mdna:272]
Credit Facility  On May 13, 2021, we entered into a 5-year $3.0 billion unsecured revolving credit agreement, as amended on April 18, 2023. On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of January 27, 2024, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.

[0000858877-24-000003:mdna:273]
[same as prior period, unchanged from 0000858877-23-000031:mdna:238]

[0000858877-24-000003:mdna:274]
[same as prior period, unchanged from 0000858877-23-000031:mdna:239]

[0000858877-24-000003:mdna:275]
[same as prior period, unchanged from 0000858877-23-000031:mdna:228]

[0000858877-24-000003:mdna:276]
|  | January 27,2024 |  | July 29,2023 |  | Increase (Decrease) |
| Product | $ | 16,249 |  |  | $ | 15,802 |  |  | $ | 447 |  |
| Service | 19,407 |  |  | 19,066 |  |  | 341 |  |
| Total | $ | 35,656 |  |  | $ | 34,868 |  |  | $ | 788 |  |
| Short-term RPO | $ | 17,930 |  |  | $ | 17,910 |  |  | $ | 20 |  |
| Long-term RPO | 17,726 |  |  | 16,958 |  |  | 768 |  |
| Total | $ | 35,656 |  |  | $ | 34,868 |  |  | $ | 788 |  |

[0000858877-24-000003:mdna:277]
Total remaining performance obligations as of January 27, 2024 increased 2% compared to the end of fiscal 2023. Remaining performance obligations for product increased by 3% compared to the end of fiscal 2023. Remaining performance obligations for service increased by 2%. We expect approximately 50% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-24-000003:mdna:278]
[same as prior period, unchanged from 0000858877-23-000031:mdna:231]

[0000858877-24-000003:mdna:279]
|  | January 27,2024 |  | July 29,2023 |  | Increase (Decrease) |
| Product | $ | 11,640 |  |  | $ | 11,505 |  |  | $ | 135 |  |
| Service | 14,131 |  |  | 14,045 |  |  | 86 |  |
| Total | $ | 25,771 |  |  | $ | 25,550 |  |  | $ | 221 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 14,011 |  |  | $ | 13,908 |  |  | $ | 103 |  |
| Noncurrent | 11,760 |  |  | 11,642 |  |  | 118 |  |
| Total | $ | 25,771 |  |  | $ | 25,550 |  |  | $ | 221 |  |

[0000858877-24-000003:mdna:280]
Total deferred revenue increased 1% compared to the end of fiscal 2023. The increase in deferred product revenue of 1% was primarily due to increased deferrals related to our recurring software offerings. The increase in deferred service revenue of 1% was driven by the impact of contract renewals, partially offset by ongoing amortization of deferred service revenue.

[0000858877-24-000003:mdna:281]
[same as prior period, unchanged from 0000858877-23-000031:mdna:234]

[0000858877-24-000003:mdna:282]
[same as prior period, unchanged from 0000858877-23-000031:mdna:235]

[0000858877-24-000003:mdna:283]
The income tax payable outstanding as of January 27, 2024 for the U.S. transition tax on accumulated earnings for foreign subsidiaries was $4.1 billion. Approximately $1.8 billion is payable in fiscal 2025 and $2.3 billion is payable in fiscal 2026.

[0000858877-24-000003:mdna:284]
[same as prior period, unchanged from 0000858877-23-000031:mdna:237]

[0000858877-24-000003:mdna:285]
58

[0000858877-24-000003:mdna:286]
CISCO SYSTEMS, INC.

[0000858877-24-000003:mdna:287]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000003:mdna:288]
[same as prior period, unchanged from 0000858877-23-000031:mdna:240]

[0000858877-24-000003:mdna:289]
[same as prior period, unchanged from 0000858877-23-000031:mdna:241]

[0000858877-24-000003:mdna:290]
We also have certain funding commitments primarily related to our privately held investments. The funding commitments were $0.2 billion and $0.3 billion as of January 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000003:mdna:291]
In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of January 27, 2024 there were no material unconsolidated variable interest entities.

[0000858877-24-000003:mdna:292]
[same as prior period, unchanged from 0000858877-23-000031:mdna:244]

[0000858877-24-000003:mdna:293]
[same as prior period, unchanged from 0000858877-23-000031:mdna:245]

[0000858877-24-000003:mdna:294]
[same as prior period, unchanged from 0000858877-23-000031:mdna:246]

[0000858877-24-000003:mdna:295]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs (including inventory and other supply related payments), capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. We recently announced our intent to acquire Splunk. Under the terms of the agreement, we have agreed to pay $157 per share in cash, representing approximately $28 billion in equity value. We anticipate this transaction will be financed with a combination of cash and debt. The acquisition is expected to close late in the first quarter or early in the second quarter of calendar year 2024, subject to regulatory approval and other customary closing conditions. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.

[0000858877-24-000003:mdna:296]
59
