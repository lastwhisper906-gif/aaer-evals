# CSCO note change history — 0000858877-23-000031 → 0000858877-24-000003


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-02-20):
[0000858877-24-000003:note_history:1]
|  | January 27,2024 |  | July 29,2023 |
| Less than 1 year | $ | 4,711 |  |  | $ | 5,270 |  |
| 1 to 3 years | 1,456 |  |  | 1,783 |  |
| 3 to 5 years | 26 |  |  | 200 |  |
| Total | $ | 6,193 |  |  | $ | 7,253 |  |
  (was, 2023-11-21, similarity 0.9632):
[0000858877-23-000031:note_history:1]
|  | October 28,2023 |  | July 29,2023 |
| Less than 1 year | $ | 4,731 |  |  | $ | 5,270 |  |
| 1 to 3 years | 1,646 |  |  | 1,783 |  |
| 3 to 5 years | 127 |  |  | 200 |  |
| Total | $ | 6,504 |  |  | $ | 7,253 |  |

- changed (2024-02-20):
[0000858877-24-000003:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 27, 2024 and July 29, 2023, the liability for these purchase commitments was $538 million and $529 million, respectively, and was included in other current liabilities.
  (was, 2023-11-21, similarity 0.9576):
[0000858877-23-000031:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 28, 2023 and July 29, 2023, the liability for these purchase commitments was $510 million and $529 million, respectively, and was included in other current liabilities.

- changed (2024-02-20):
[0000858877-24-000003:note_history:3]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2024 |  | January 28, 2023 |  | January 27, 2024 |  | January 28, 2023 |
| Compensation expense related to acquisitions | $ | 45 |  |  | $ | 49 |  |  | $ | 94 |  |  | $ | 123 |  |
  (was, 2023-11-21, similarity 0.6985):
[0000858877-23-000031:note_history:3]
|  | Three Months Ended |
|  | October 28, 2023 |  | October 29, 2022 |
| Compensation expense related to acquisitions | $ | 49 |  |  | $ | 74 |  |

- changed (2024-02-20):
[0000858877-24-000003:note_history:4]
As of January 27, 2024, we estimated that future cash compensation expense of up to $397 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2023-11-21, similarity 0.9669):
[0000858877-23-000031:note_history:4]
As of October 28, 2023, we estimated that future cash compensation expense of up to $437 million may be required to be recognized pursuant to the applicable business combination agreements.

- added (2024-02-20):
[0000858877-24-000003:note_history:5]
We also have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.2 billion and $0.3 billion as of January 27, 2024 and July 29, 2023, respectively.

- changed (2024-02-20):
[0000858877-24-000003:note_history:6]
|  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |
| Balance at beginning of period | $ | 329 |  |  | $ | 333 |  |
| Provisions for warranties issued | 198 |  |  | 188 |  |
| Adjustments for pre-existing warranties | 5 |  |  | 13 |  |
| Settlements | (205) |  |  | (218) |  |
| Balance at end of period | $ | 327 |  |  | $ | 316 |  |
  (was, 2023-11-21, similarity 0.9178):
[0000858877-23-000031:note_history:6]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |
| Balance at beginning of period | $ | 329 |  |  | $ | 333 |  |
| Provisions for warranties issued | 98 |  |  | 97 |  |
| Adjustments for pre-existing warranties | 3 |  |  | 1 |  |
| Settlements | (100) |  |  | (108) |  |
| Balance at end of period | $ | 330 |  |  | $ | 323 |  |

- changed (2024-02-20):
[0000858877-24-000003:note_history:7]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.6 billion and $7.5 billion for the second quarter of fiscal 2024 and 2023, respectively, and $14.8 billion and $15.1 billion for the first six months of fiscal 2024 and 2023, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.7 billion as of January 27, 2024 and July 29, 2023, respectively.
  (was, 2023-11-21, similarity 0.9193):
[0000858877-23-000031:note_history:7]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $8.2 billion and $7.6 billion for the first quarter of fiscal 2024 and 2023, respectively. The balance of the channel partner financing subject to guarantees was $1.5 billion and $1.7 billion as of October 28, 2023 and July 29, 2023, respectively.

- changed (2024-02-20):
[0000858877-24-000003:note_history:8]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at January 27, 2024 and July 29, 2023, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2023-11-21, similarity 0.9787):
[0000858877-23-000031:note_history:8]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at October 28, 2023 and July 29, 2023, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2024-02-20):
[0000858877-24-000003:note_history:9]
|  | January 27,2024 |  | July 29,2023 |
| Maximum potential future payments | $ | 138 |  |  | $ | 159 |  |
| Deferred revenue | (23) |  |  | (34) |  |
| Total | $ | 115 |  |  | $ | 125 |  |
  (was, 2023-11-21, similarity 0.9618):
[0000858877-23-000031:note_history:9]
|  | October 28,2023 |  | July 29,2023 |
| Maximum potential future payments | $ | 142 |  |  | $ | 159 |  |
| Deferred revenue | (29) |  |  | (34) |  |
| Total | $ | 113 |  |  | $ | 125 |  |

- changed (2024-02-20):
[0000858877-24-000003:note_history:10]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $165 million for the alleged evasion of import and other taxes, $929 million for interest, and $373 million for various penalties, all determined using an exchange rate as of January 27, 2024.
  (was, 2023-11-21, similarity 0.9941):
[0000858877-23-000031:note_history:10]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $162 million for the alleged evasion of import and other taxes, $943 million for interest, and $402 million for various penalties, all determined using an exchange rate as of October 28, 2023.

- added (2024-02-20):
[0000858877-24-000003:note_history:11]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. After two bench trials and various administrative actions and appeals, we have been found either to not have infringed any of the patents or the patents have been invalidated. There is an appeal of one of the invalidity decisions and we expect a further appeal by Centripetal.

- added (2024-02-20):
[0000858877-24-000003:note_history:12]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringe three patents, one patent was invalidated, the utility model was invalidated, and the infringement action on the final patent is stayed due to a pending invalidity action. There are appeals pending and the next proceeding is expected in the second half of fiscal 2024.

- changed (2024-02-20):
[0000858877-24-000003:note_history:13]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement. We have filed our response and defenses to the complaint and the next proceedings are expected in the second half of fiscal 2024.
  (was, 2023-11-21, similarity 0.8507):
[0000858877-23-000031:note_history:13]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement.

- added (2024-02-20):
[0000858877-24-000003:note_history:14]
Ramot     On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the

- added (2024-02-20):
[0000858877-24-000003:note_history:15]
validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents. The next proceedings are expected in the first half of fiscal 2025.

- changed (2024-02-20):
[0000858877-24-000003:note_history:16]
While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.
  (was, 2023-11-21, similarity 0.732):
[0000858877-23-000031:note_history:16]
On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents in the same family as those involved in the pending cases above. Ramot is asserting counterclaims for infringement of the same patents and seeks damages, including enhanced damages, and a royalty on future sales. While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

- changed (2024-02-20):
[0000858877-24-000003:note_history:17]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023 and the next proceedings are expected in the second half of fiscal 2024.
  (was, 2023-11-21, similarity 0.7049):
[0000858877-23-000031:note_history:17]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023 and those proceedings are ongoing.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.

- added (2024-02-20):
[0000858877-24-000003:note_history:18]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward. On June 9, 2020, Viasat filed another suit in SDSC alleging contract and trade secret claims for sales of additional Acacia products. Both matters have been formally dismissed and resolved through a settlement for an amount that did not have a material effect on our Consolidated Financial Statements.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.

- removed (2024-02-20):
[0000858877-23-000031:note_history:19]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion as of each of October 28, 2023 and July 29, 2023.

- removed (2024-02-20):
[0000858877-23-000031:note_history:20]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. The district court case went to trial on five asserted patents. Subsequently, on October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent and awarded $1.9 billion in damages and $14 million in pre-judgment interest, declined to issue an injunction but, instead, awarded Centripetal a royalty against future revenue for an initial three-year term at a 10% rate, with a minimum and maximum annual royalty of $168 million and $300 million, respectively, and for a second three-year term at a 5% rate, with a minimum and maximum annual royalty of $84 million and $150 million, respectively. We appealed and, on June 23, 2022, the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”) vacated the district court’s final judgment, remanded the case back to the district court to be assigned to a new judge and ordered the district court to conduct additional proceedings. The district court held a hearing on these additional proceedings over three days beginning on June 22, 2023, and a decision is pending. Prior to the hearing, on May 24, 2023, the Patent Trial and Appeal Board cancelled all claims of one of the Centripetal patents that was the subject of the hearing. On August 9, 2022, Centripetal filed a petition for writ of certiorari in the U.S. Supreme Court challenging the Federal Circuit’s decision. The Supreme Court denied Centripetal’s petition on December 5, 2022.

- removed (2024-02-20):
[0000858877-23-000031:note_history:21]
Between April 2020 and February 2022, Centripetal filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. On December 10, 2021, the German Court rejected Centripetal’s complaints on two patents, and Centripetal has appealed. A hearing for a Cisco nullity action in the Federal Patent Court in Germany on one of those two patents occurred on August 1, 2022, and we are waiting for the Court’s opinion. On December 21, 2021, the German Court stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. On May 17, 2022, Centripetal withdrew its complaint for infringement of the German utility model. The German Court conducted a hearing on the remaining two Centripetal complaints on November 22, 2022. The German Court found no infringement on one patent and stayed the decision in the final case pending a decision by the European Patent Office in a related opposition proceeding.

- removed (2024-02-20):
[0000858877-23-000031:note_history:22]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. We challenged the validity of all three patents in the U.S. Patent and Trademark Office (“PTO”) by way of ex parte reexamination proceedings and the pending District Court case has been stayed. On July 6, 2023, the PTO issued a reexamination certificate for one of the three patents. On August 29, 2023, Cisco filed a second ex parte reexamination request against that same patent.

- removed (2024-02-20):
[0000858877-23-000031:note_history:23]
On October 30, 2023, the PTO issued a reexamination certificate for a second of the three patents. The third asserted patent remains the subject of a pending reexamination proceeding.

- removed (2024-02-20):
[0000858877-23-000031:note_history:24]
On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) in the District of Delaware (“D. Del.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot asserted in the E.D. Tex. case and this case is also stayed pending the reexamination proceedings referenced above.

- removed (2024-02-20):
[0000858877-23-000031:note_history:25]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward (“Viasat 2019”). In May 2023, a judgment was entered against Cisco in Viasat 2019 for an amount that did not have a material effect on our Consolidated Financial Statements. Acacia filed an appeal with the California Court of Appeal.

- removed (2024-02-20):
[0000858877-23-000031:note_history:26]
On June 9, 2020, Viasat filed another suit in SDSC alleging contract and trade secret claims for sales of additional Acacia products (“Viasat 2020”). In October 2022, an amended complaint was filed in Viasat 2020 asserting the same claims but alleging additional information. The parties have since resolved both the Viasat 2019 appeal and Viasat 2020, with dismissals entered in each matter in October 2023. The amounts paid by us to resolve these matters did not have a material effect on our Consolidated Financial Statements.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-02-20):
[0000858877-24-000003:note_history:27]
Purchase Commitments with Contract Manufacturers and Suppliers We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.
  (was, 2023-11-21, similarity 0.9743):
[0000858877-23-000031:note_history:27]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-02-20):
[0000858877-24-000003:note_history:28]
We have prepared the accompanying financial data as of January 27, 2024 and for the second quarter and first six months of fiscal 2024 and 2023, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 29, 2023 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 29, 2023.
  (was, 2023-11-21, similarity 0.977):
[0000858877-23-000031:note_history:28]
We have prepared the accompanying financial data as of October 28, 2023 and for the first quarter of fiscal 2024 and 2023, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 29, 2023 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 29, 2023.

- added (2024-02-20):
[0000858877-24-000003:note_history:29]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of January 27, 2024, the results of operations, the statements of comprehensive income and the statements of equity for the second quarter and first six months of fiscal 2024 and 2023, and the statements of cash flows for the first six months of fiscal 2024 and 2023, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2024 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2024-02-20):
[0000858877-23-000031:note_history:30]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of October 28, 2023, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2024 and 2023, as applicable, have been made. The results of operations for the first quarter of fiscal 2024 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-02-20):
[0000858877-24-000003:note_history:31]
Recent Accounting Pronouncements
(a)Recent Accounting Standards or Updates Not Yet Effective

- added (2024-02-20):
[0000858877-24-000003:note_history:32]
Segment Reporting     In November 2023, the Financial Accounting Standards Board (FASB) issued an accounting standard update that expands the disclosure requirements for reportable segments, primarily through enhanced disclosures around significant segment expenses. The accounting standard update will be effective for our fiscal 2025 Form 10-K on a retrospective basis, and early adoption is permitted. We are currently evaluating the impact of this accounting standard update on our segment disclosures.

- added (2024-02-20):
[0000858877-24-000003:note_history:33]
Improvements on Income Tax Disclosures     In December 2023, the FASB issued an accounting standard update expanding the requirements for disclosure of disaggregated information about the effective tax rate reconciliation and income taxes paid. The accounting standard update will be effective for our fiscal 2026 Form 10-K. We are currently evaluating the impact of this accounting standard update on our income tax disclosures.

- removed (2024-02-20):
[0000858877-23-000031:note_history:34]
Recent Accounting PronouncementsThere have been no recent accounting pronouncements issued that we believe will have a material impact on our Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-20):
[0000858877-24-000003:note_history:35]
|  | January 27, 2024 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 997 |  |  | 6.35 | % |  | $ | 1,733 |  |  | 4.45 | % |
| Commercial paper | 3,939 |  |  | 5.39 | % |  | — |  |  | — | % |
| Total | $ | 4,936 |  |  |  |  | $ | 1,733 |  |  |  |
  (was, 2023-11-21, similarity 0.7563):
[0000858877-23-000031:note_history:35]
|  | October 28, 2023 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 990 |  |  | 6.33 | % |  | $ | 1,733 |  |  | 4.45 | % |

- added (2024-02-20):
[0000858877-24-000003:note_history:36]
Effective February 6, 2024, we increased our borrowing capacity under our existing commercial paper program from $10.0 billion to $15.0 billion. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. As of February 19, 2024, we had approximately $6.9 billion of commercial paper notes outstanding.

- changed (2024-02-20):
[0000858877-24-000003:note_history:37]
|  |  |  | January 27, 2024 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 6.35% |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.66% |  | 500 |  |  | 6.38% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 7,750 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (66) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (18) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 7,666 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 997 |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 6,669 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 7,666 |  |  |  |  | $ | 8,391 |  |  |  |
  (was, 2023-11-21, similarity 0.9928):
[0000858877-23-000031:note_history:37]
|  |  |  | October 28, 2023 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 6.33% |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.63% |  | 500 |  |  | 6.38% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 7,750 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (68) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (32) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 7,650 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 990 |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 6,660 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 7,650 |  |  |  |  | $ | 8,391 |  |  |  |

- changed (2024-02-20):
[0000858877-24-000003:note_history:38]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 27, 2024, we were in compliance with all debt covenants.
  (was, 2023-11-21, similarity 0.984):
[0000858877-23-000031:note_history:38]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 28, 2023, we were in compliance with all debt covenants.

- changed (2024-02-20):
[0000858877-24-000003:note_history:39]
As of January 27, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2023-11-21, similarity 0.9556):
[0000858877-23-000031:note_history:39]
As of October 28, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2024-02-20):
[0000858877-24-000003:note_history:40]
| Fiscal Year | Amount |
| 2024 (remaining six months) | $ | 1,000 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 7,750 |  |
  (was, 2023-11-21, similarity 0.9822):
[0000858877-23-000031:note_history:40]
| Fiscal Year | Amount |
| 2024 (remaining nine months) | $ | 1,000 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 7,750 |  |

- added (2024-02-20):
[0000858877-24-000003:note_history:41]
On May 13, 2021, we entered into a 5-year $3.0 billion unsecured revolving credit agreement, as amended on April 18, 2023. On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of January 27, 2024, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.

- removed (2024-02-20):
[0000858877-23-000031:note_history:42]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

- removed (2024-02-20):
[0000858877-23-000031:note_history:43]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of October 28, 2023, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement. On April 18, 2023, we entered into an amendment to the credit agreement to replace the LIBOR index with Term SOFR.
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) Term SOFR (plus a 0.10% credit spread adjustment) or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) Term SOFR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-20):
[0000858877-24-000003:note_history:44]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 27, 2024 and July 29, 2023 (in millions):
  (was, 2023-11-21, similarity 0.967):
[0000858877-23-000031:note_history:44]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 28, 2023 and July 29, 2023 (in millions):

- added (2024-02-20):
[0000858877-24-000003:note_history:45]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,145 |  |  | $ | (9) |  |  | $ | 550 |  |  | $ | (25) |  |  | $ | 1,695 |  |  | $ | (34) |  |
| U.S. government agency securities | 224 |  |  | — |  |  | 39 |  |  | (2) |  |  | 263 |  |  | (2) |  |
| Non-U.S. government and agency securities | 200 |  |  | — |  |  | — |  |  | — |  |  | 200 |  |  | — |  |
| Corporate debt securities | 557 |  |  | (2) |  |  | 3,527 |  |  | (178) |  |  | 4,084 |  |  | (180) |  |
| U.S. agency mortgage-backed securities | 415 |  |  | (6) |  |  | 1,320 |  |  | (191) |  |  | 1,735 |  |  | (197) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 2,551 |  |  | $ | (17) |  |  | $ | 5,436 |  |  | $ | (396) |  |  | $ | 7,987 |  |  | $ | (413) |  |

- removed (2024-02-20):
[0000858877-23-000031:note_history:46]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 28, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,844 |  |  | $ | (38) |  |  | $ | 680 |  |  | $ | (34) |  |  | $ | 2,524 |  |  | $ | (72) |  |
| U.S. government agency securities | 377 |  |  | (3) |  |  | 38 |  |  | (3) |  |  | 415 |  |  | (6) |  |
| Non-U.S. government and agency securities | 324 |  |  | — |  |  | — |  |  | — |  |  | 324 |  |  | — |  |
| Corporate debt securities | 1,679 |  |  | (29) |  |  | 4,275 |  |  | (304) |  |  | 5,954 |  |  | (333) |  |
| U.S. agency mortgage-backed securities | 798 |  |  | (45) |  |  | 1,315 |  |  | (273) |  |  | 2,113 |  |  | (318) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Certificates of deposit | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 5,042 |  |  | $ | (115) |  |  | $ | 6,308 |  |  | $ | (614) |  |  | $ | 11,350 |  |  | $ | (729) |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-20):
[0000858877-24-000003:note_history:47]
| January 27, 2024 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,428 |  |  | $ | 3 |  |  | $ | (34) |  |  | $ | 2,397 |  |
| U.S. government agency securities | 354 |  |  | — |  |  | (2) |  |  | 352 |  |
| Non-U.S. government and agency securities | 364 |  |  | — |  |  | — |  |  | 364 |  |
| Corporate debt securities | 5,343 |  |  | 7 |  |  | (210) |  |  | 5,140 |  |
| U.S. agency mortgage-backed securities | 2,127 |  |  | 1 |  |  | (197) |  |  | 1,931 |  |
| Commercial paper | 828 |  |  | — |  |  | — |  |  | 828 |  |
| Certificates of deposit | 518 |  |  | — |  |  | — |  |  | 518 |  |
| Total | $ | 11,962 |  |  | $ | 11 |  |  | $ | (443) |  |  | $ | 11,530 |  |
  (was, 2023-11-21, similarity 0.9859):
[0000858877-23-000031:note_history:47]
| October 28, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,596 |  |  | $ | — |  |  | $ | (72) |  |  | $ | 2,524 |  |
| U.S. government agency securities | 421 |  |  | — |  |  | (6) |  |  | 415 |  |
| Non-U.S. government and agency securities | 351 |  |  | — |  |  | — |  |  | 351 |  |
| Corporate debt securities | 6,862 |  |  | 1 |  |  | (363) |  |  | 6,500 |  |
| U.S. agency mortgage-backed securities | 2,431 |  |  | — |  |  | (318) |  |  | 2,113 |  |
| Commercial paper | 943 |  |  | — |  |  | — |  |  | 943 |  |
| Certificates of deposit | 666 |  |  | — |  |  | — |  |  | 666 |  |
| Total | $ | 14,270 |  |  | $ | 1 |  |  | $ | (759) |  |  | $ | 13,512 |  |

- changed (2024-02-20):
[0000858877-24-000003:note_history:48]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2024 |  | January 28, 2023 |  | January 27, 2024 |  | January 28, 2023 |
| Gross realized gains | $ | 5 |  |  | $ | 3 |  |  | $ | 5 |  |  | $ | 3 |  |
| Gross realized losses | (28) |  |  | (6) |  |  | (48) |  |  | (12) |  |
| Total | $ | (23) |  |  | $ | (3) |  |  | $ | (43) |  |  | $ | (9) |  |
  (was, 2023-11-21, similarity 0.6909):
[0000858877-23-000031:note_history:48]
|  | Three Months Ended |
|  | October 28, 2023 |  | October 29, 2022 |
| Gross realized gains | $ | — |  |  | $ | — |  |
| Gross realized losses | (20) |  |  | (6) |  |
| Total | $ | (20) |  |  | $ | (6) |  |

- changed (2024-02-20):
[0000858877-24-000003:note_history:49]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 27, 2024 and July 29, 2023 (in millions):
  (was, 2023-11-21, similarity 0.967):
[0000858877-23-000031:note_history:49]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 28, 2023 and July 29, 2023 (in millions):

- added (2024-02-20):
[0000858877-24-000003:note_history:50]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,145 |  |  | $ | (9) |  |  | $ | 550 |  |  | $ | (25) |  |  | $ | 1,695 |  |  | $ | (34) |  |
| U.S. government agency securities | 224 |  |  | — |  |  | 39 |  |  | (2) |  |  | 263 |  |  | (2) |  |
| Non-U.S. government and agency securities | 200 |  |  | — |  |  | — |  |  | — |  |  | 200 |  |  | — |  |
| Corporate debt securities | 557 |  |  | (2) |  |  | 3,527 |  |  | (178) |  |  | 4,084 |  |  | (180) |  |
| U.S. agency mortgage-backed securities | 415 |  |  | (6) |  |  | 1,320 |  |  | (191) |  |  | 1,735 |  |  | (197) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 2,551 |  |  | $ | (17) |  |  | $ | 5,436 |  |  | $ | (396) |  |  | $ | 7,987 |  |  | $ | (413) |  |

- changed (2024-02-20):
[0000858877-24-000003:note_history:51]
The following table summarizes the maturities of our available-for-sale debt investments as of January 27, 2024 (in millions):
  (was, 2023-11-21, similarity 0.9504):
[0000858877-23-000031:note_history:51]
The following table summarizes the maturities of our available-for-sale debt investments as of October 28, 2023 (in millions):

- changed (2024-02-20):
[0000858877-24-000003:note_history:52]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 3,686 |  |  | $ | 3,642 |  |
| After 1 year through 5 years | 6,149 |  |  | 5,957 |  |
| Mortgage-backed securities with no single maturity | 2,127 |  |  | 1,931 |  |
| Total | $ | 11,962 |  |  | $ | 11,530 |  |
  (was, 2023-11-21, similarity 0.8479):
[0000858877-23-000031:note_history:52]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 4,201 |  |  | $ | 4,152 |  |
| After 1 year through 5 years | 7,627 |  |  | 7,236 |  |
| After 5 years through 10 years | 9 |  |  | 9 |  |
| After 10 years | 2 |  |  | 2 |  |
| Mortgage-backed securities with no single maturity | 2,431 |  |  | 2,113 |  |
| Total | $ | 14,270 |  |  | $ | 13,512 |  |

- added (2024-02-20):
[0000858877-24-000003:note_history:53]
We held marketable equity securities of $426 million and $431 million as of January 27, 2024 and July 29, 2023, respectively. We recognized a net unrealized gain of $55 million and $17 million during the second quarter and first six months of fiscal 2024, respectively, and a net unrealized gain of $11 million and a net unrealized loss of $9 million during the corresponding periods of fiscal 2023, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $134 million for the second quarter and first six months of fiscal 2024, and a net gain of $3 million and a net loss of $8 million for the corresponding periods of fiscal 2023, respectively. We held equity interests in certain private equity funds of $0.8 billion and $0.9 billion as of January 27, 2024 and July 29, 2023, respectively, which are accounted for under the NAV practical expedient.

- changed (2024-02-20):
[0000858877-24-000003:note_history:54]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 27, 2024, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2023-11-21, similarity 0.9878):
[0000858877-23-000031:note_history:54]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 28, 2023, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- added (2024-02-20):
[0000858877-24-000003:note_history:55]
The carrying value of our investments in privately held companies was $1.6 billion and $1.8 billion as of January 27, 2024 and July 29, 2023, respectively. Of the total carrying value of our investments in privately held companies as of January 27, 2024, $0.9 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of January 27, 2024, we have total funding commitments of $0.2 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.

- removed (2024-02-20):
[0000858877-23-000031:note_history:56]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 28, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,844 |  |  | $ | (38) |  |  | $ | 680 |  |  | $ | (34) |  |  | $ | 2,524 |  |  | $ | (72) |  |
| U.S. government agency securities | 377 |  |  | (3) |  |  | 38 |  |  | (3) |  |  | 415 |  |  | (6) |  |
| Non-U.S. government and agency securities | 324 |  |  | — |  |  | — |  |  | — |  |  | 324 |  |  | — |  |
| Corporate debt securities | 1,679 |  |  | (29) |  |  | 4,275 |  |  | (304) |  |  | 5,954 |  |  | (333) |  |
| U.S. agency mortgage-backed securities | 798 |  |  | (45) |  |  | 1,315 |  |  | (273) |  |  | 2,113 |  |  | (318) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Certificates of deposit | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 5,042 |  |  | $ | (115) |  |  | $ | 6,308 |  |  | $ | (614) |  |  | $ | 11,350 |  |  | $ | (729) |  |

- removed (2024-02-20):
[0000858877-23-000031:note_history:57]
We held marketable equity securities of $409 million and $431 million as of October 28, 2023 and July 29, 2023, respectively. We recognized a net unrealized loss of $42 million and $20 million during the first quarter of fiscal 2024 and 2023, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $12 million for the first quarter of fiscal 2023. These adjustments were not material for the first quarter of fiscal 2024. We held equity interests in certain private equity funds of $0.9 billion as of each of October 28, 2023 and July 29, 2023, which are accounted for under the NAV practical expedient.

- removed (2024-02-20):
[0000858877-23-000031:note_history:58]
The carrying value of our investments in privately held companies was $1.8 billion as of each of October 28, 2023 and July 29, 2023. Of the total carrying value of our investments in privately held companies as of October 28, 2023, $0.9 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of October 28, 2023, we have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-20):
[0000858877-24-000003:note_history:59]
|  |  |  | January 27, 2024 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 6.35% |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.66% |  | 500 |  |  | 6.38% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 7,750 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (66) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (18) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 7,666 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 997 |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 6,669 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 7,666 |  |  |  |  | $ | 8,391 |  |  |  |
  (was, 2023-11-21, similarity 0.9928):
[0000858877-23-000031:note_history:59]
|  |  |  | October 28, 2023 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 6.33% |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.63% |  | 500 |  |  | 6.38% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 7,750 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (68) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (32) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 7,650 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 990 |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 6,660 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 7,650 |  |  |  |  | $ | 8,391 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-20):
[0000858877-24-000003:note_history:60]
As of January 27, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2023-11-21, similarity 0.9556):
[0000858877-23-000031:note_history:60]
As of October 28, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2024-02-20):
[0000858877-24-000003:note_history:61]
| Fiscal Year | Amount |
| 2024 (remaining six months) | $ | 1,000 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 7,750 |  |
  (was, 2023-11-21, similarity 0.9822):
[0000858877-23-000031:note_history:61]
| Fiscal Year | Amount |
| 2024 (remaining nine months) | $ | 1,000 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 7,750 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-20):
[0000858877-24-000003:note_history:62]
|  | January 27, 2024 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 997 |  |  | 6.35 | % |  | $ | 1,733 |  |  | 4.45 | % |
| Commercial paper | 3,939 |  |  | 5.39 | % |  | — |  |  | — | % |
| Total | $ | 4,936 |  |  |  |  | $ | 1,733 |  |  |  |
  (was, 2023-11-21, similarity 0.7563):
[0000858877-23-000031:note_history:62]
|  | October 28, 2023 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 990 |  |  | 6.33 | % |  | $ | 1,733 |  |  | 4.45 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-20):
[0000858877-24-000003:note_history:63]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,081 |  |  | $ | 8,092 |  |  | $ | 15,904 |  |  | $ | 16,123 |  |
| Security | 973 |  |  | 943 |  |  | 1,984 |  |  | 1,914 |  |
| Collaboration | 989 |  |  | 958 |  |  | 2,106 |  |  | 2,044 |  |
| Observability | 188 |  |  | 162 |  |  | 378 |  |  | 319 |  |
| Total Product | 9,232 |  |  | 10,155 |  |  | 20,371 |  |  | 20,400 |  |
| Services | 3,559 |  |  | 3,437 |  |  | 7,088 |  |  | 6,824 |  |
| Total | $ | 12,791 |  |  | $ | 13,592 |  |  | 27,459 |  |  | 27,224 |  |
  (was, 2023-11-21, similarity 0.6795):
[0000858877-23-000031:note_history:63]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |
| Product revenue: |  |  |  |
| Networking | $ | 8,822 |  |  | $ | 8,031 |  |
| Security | 1,010 |  |  | 971 |  |
| Collaboration | 1,117 |  |  | 1,086 |  |
| Observability | 190 |  |  | 157 |  |
| Total Product | 11,139 |  |  | 10,245 |  |
| Services | 3,529 |  |  | 3,387 |  |
| Total | $ | 14,668 |  |  | $ | 13,632 |  |

- added (2024-02-20):
[0000858877-24-000003:note_history:64]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,081 |  |  | $ | 8,092 |  |  | $ | 15,904 |  |  | $ | 16,123 |  |
| Security | 973 |  |  | 943 |  |  | 1,984 |  |  | 1,914 |  |
| Collaboration | 989 |  |  | 958 |  |  | 2,106 |  |  | 2,044 |  |
| Observability | 188 |  |  | 162 |  |  | 378 |  |  | 319 |  |
| Total Product | 9,232 |  |  | 10,155 |  |  | 20,371 |  |  | 20,400 |  |
| Services | 3,559 |  |  | 3,437 |  |  | 7,088 |  |  | 6,824 |  |
| Total | $ | 12,791 |  |  | $ | 13,592 |  |  | $ | 27,459 |  |  | $ | 27,224 |  |

- removed (2024-02-20):
[0000858877-23-000031:note_history:65]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |
| Revenue: |  |  |  |
| Networking | $ | 8,822 |  |  | $ | 8,031 |  |
| Security | 1,010 |  |  | 971 |  |
| Collaboration | 1,117 |  |  | 1,086 |  |
| Observability | 190 |  |  | 157 |  |
| Total Product | 11,139 |  |  | 10,245 |  |
| Services | 3,529 |  |  | 3,387 |  |
| Total | $ | 14,668 |  |  | $ | 13,632 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-02-20):
[0000858877-24-000003:note_history:66]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

- changed (2024-02-20):
[0000858877-24-000003:note_history:67]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.
  (was, 2023-11-21, similarity 0.7331):
[0000858877-23-000031:note_history:67]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized

- changed (2024-02-20):
[0000858877-24-000003:note_history:68]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 27, 2024 and July 29, 2023 was $36 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2023-11-21, similarity 0.9759):
[0000858877-23-000031:note_history:68]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 28, 2023 and July 29, 2023 was $37 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- removed (2024-02-20):
[0000858877-23-000031:note_history:69]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

- removed (2024-02-20):
[0000858877-23-000031:note_history:70]
upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-20):
[0000858877-24-000003:note_history:71]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.
  (was, 2023-11-21, similarity 0.7331):
[0000858877-23-000031:note_history:71]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized

- changed (2024-02-20):
[0000858877-24-000003:note_history:72]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 27, 2024 and July 29, 2023 was $36 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2023-11-21, similarity 0.9759):
[0000858877-23-000031:note_history:72]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 28, 2023 and July 29, 2023 was $37 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2024-02-20):
[0000858877-24-000003:note_history:73]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,081 |  |  | $ | 8,092 |  |  | $ | 15,904 |  |  | $ | 16,123 |  |
| Security | 973 |  |  | 943 |  |  | 1,984 |  |  | 1,914 |  |
| Collaboration | 989 |  |  | 958 |  |  | 2,106 |  |  | 2,044 |  |
| Observability | 188 |  |  | 162 |  |  | 378 |  |  | 319 |  |
| Total Product | 9,232 |  |  | 10,155 |  |  | 20,371 |  |  | 20,400 |  |
| Services | 3,559 |  |  | 3,437 |  |  | 7,088 |  |  | 6,824 |  |
| Total | $ | 12,791 |  |  | $ | 13,592 |  |  | 27,459 |  |  | 27,224 |  |
  (was, 2023-11-21, similarity 0.6795):
[0000858877-23-000031:note_history:73]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |
| Product revenue: |  |  |  |
| Networking | $ | 8,822 |  |  | $ | 8,031 |  |
| Security | 1,010 |  |  | 971 |  |
| Collaboration | 1,117 |  |  | 1,086 |  |
| Observability | 190 |  |  | 157 |  |
| Total Product | 11,139 |  |  | 10,245 |  |
| Services | 3,529 |  |  | 3,387 |  |
| Total | $ | 14,668 |  |  | $ | 13,632 |  |

- changed (2024-02-20):
[0000858877-24-000003:note_history:74]
Accounts receivable, net was $4.9 billion as of January 27, 2024 compared to $5.9 billion as of July 29, 2023, as reported on the Consolidated Balance Sheets.
  (was, 2023-11-21, similarity 0.958):
[0000858877-23-000031:note_history:74]
Accounts receivable, net was $4.8 billion as of October 28, 2023 compared to $5.9 billion as of July 29, 2023, as reported on the Consolidated Balance Sheets.

- changed (2024-02-20):
[0000858877-24-000003:note_history:75]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2024 |  | January 28, 2023 |  | January 27, 2024 |  | January 28, 2023 |
| Allowance for credit loss at beginning of period | $ | 82 |  |  | $ | 88 |  |  | $ | 85 |  |  | $ | 83 |  |
| Provisions (benefits) | 9 |  |  | 3 |  |  | 11 |  |  | 14 |  |
| Recoveries (write-offs), net | (12) |  |  | (5) |  |  | (17) |  |  | (11) |  |
| Allowance for credit loss at end of period | $ | 79 |  |  | $ | 86 |  |  | $ | 79 |  |  | $ | 86 |  |
  (was, 2023-11-21, similarity 0.7414):
[0000858877-23-000031:note_history:75]
|  | Three Months Ended |
|  | October 28, 2023 |  | October 29, 2022 |
| Allowance for credit loss at beginning of period | $ | 85 |  |  | $ | 83 |  |
| Provisions (benefits) | 2 |  |  | 11 |  |
| Recoveries (write-offs), net | (5) |  |  | (6) |  |
| Allowance for credit loss at end of period | $ | 82 |  |  | $ | 88 |  |

- changed (2024-02-20):
[0000858877-24-000003:note_history:76]
|  | January 27,2024 |  | July 29,2023 |
| 1 to 4 | $ | 693 |  |  | $ | 672 |  |
| 5 to 6 | 1,042 |  |  | 954 |  |
| 7 and Higher | 62 |  |  | 60 |  |
| Total | $ | 1,797 |  |  | $ | 1,686 |  |
  (was, 2023-11-21, similarity 0.9592):
[0000858877-23-000031:note_history:76]
|  | October 28,2023 |  | July 29,2023 |
| 1 to 4 | $ | 650 |  |  | $ | 672 |  |
| 5 to 6 | 1,015 |  |  | 954 |  |
| 7 and Higher | 68 |  |  | 60 |  |
| Total | $ | 1,733 |  |  | $ | 1,686 |  |

- changed (2024-02-20):
[0000858877-24-000003:note_history:77]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $1.8 billion as of January 27, 2024 and $1.6 billion as of July 29, 2023, and were included in other current assets and other assets.
  (was, 2023-11-21, similarity 0.8939):
[0000858877-23-000031:note_history:77]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of October 28, 2023 and July 29, 2023, our contract assets for these unbilled receivables, net of allowances, were $1.7 billion and $1.6 billion, respectively, and were included in other current assets and other assets.

- changed (2024-02-20):
[0000858877-24-000003:note_history:78]
Contract liabilities consist of deferred revenue. Deferred revenue was $25.8 billion as of January 27, 2024 compared to $25.6 billion as of July 29, 2023. We recognized approximately $3.8 billion and $8.4 billion of revenue during the second quarter and first six months of fiscal 2024 that was included in the deferred revenue balance at July 29, 2023.
  (was, 2023-11-21, similarity 0.8013):
[0000858877-23-000031:note_history:78]
Contract liabilities consist of deferred revenue. Deferred revenue was $25.7 billion as of October 28, 2023 compared to $25.6 billion as of July 29, 2023. We recognized approximately $4.7 billion of revenue during the first quarter of fiscal 2024 that was included in the deferred revenue balance at July 29, 2023.

- changed (2024-02-20):
[0000858877-24-000003:note_history:79]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Capitalized contract acquisition costs were $1.2 billion and $1.1 billion as of January 27, 2024 and July 29, 2023, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $166 million and $324 million for the second quarter and first six months fiscal 2024, respectively, and $201 million and $377 million for the corresponding periods of fiscal 2023, respectively, and was included in sales and marketing expenses.
  (was, 2023-11-21, similarity 0.8732):
[0000858877-23-000031:note_history:79]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Capitalized contract acquisition costs were $1.2 billion and $1.1 billion as of October 28, 2023 and July 29, 2023, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $158 million and $176 million for the first quarter of fiscal 2024 and 2023, respectively, and was included in sales and marketing expenses.

- removed (2024-02-20):
[0000858877-23-000031:note_history:80]
upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.
