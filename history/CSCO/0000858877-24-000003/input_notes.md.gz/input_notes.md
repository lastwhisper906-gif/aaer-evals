# CSCO notes — 0000858877-24-000003


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-24-000003:notes:1]
[same as prior period, unchanged from 0000858877-23-000031:notes:1]

[0000858877-24-000003:notes:2]
We have prepared the accompanying financial data as of January 27, 2024 and for the second quarter and first six months of fiscal 2024 and 2023, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 29, 2023 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 29, 2023.

[0000858877-24-000003:notes:3]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of January 27, 2024, the results of operations, the statements of comprehensive income and the statements of equity for the second quarter and first six months of fiscal 2024 and 2023, and the statements of cash flows for the first six months of fiscal 2024 and 2023, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2024 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-24-000003:notes:4]
[same as prior period, unchanged from 0000858877-23-000031:notes:4]

[0000858877-24-000003:notes:5]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-24-000003:notes:6]
Recent Accounting Pronouncements
(a)Recent Accounting Standards or Updates Not Yet Effective

[0000858877-24-000003:notes:7]
Segment Reporting     In November 2023, the Financial Accounting Standards Board (FASB) issued an accounting standard update that expands the disclosure requirements for reportable segments, primarily through enhanced disclosures around significant segment expenses. The accounting standard update will be effective for our fiscal 2025 Form 10-K on a retrospective basis, and early adoption is permitted. We are currently evaluating the impact of this accounting standard update on our segment disclosures.

[0000858877-24-000003:notes:8]
Improvements on Income Tax Disclosures     In December 2023, the FASB issued an accounting standard update expanding the requirements for disclosure of disaggregated information about the effective tax rate reconciliation and income taxes paid. The accounting standard update will be effective for our fiscal 2026 Form 10-K. We are currently evaluating the impact of this accounting standard update on our income tax disclosures.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-24-000003:notes:9]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

[0000858877-24-000003:notes:10]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-24-000003:notes:11]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 27, 2024 and July 29, 2023 was $36 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-24-000003:notes:12]
Significant Judgments

[0000858877-24-000003:notes:13]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-24-000003:notes:14]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.

[0000858877-24-000003:notes:15]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license’s utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

[0000858877-24-000003:notes:16]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and advanced services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Advanced services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

[0000858877-24-000003:notes:17]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for all of our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-24-000003:notes:18]
[same as prior period, unchanged from 0000858877-23-000031:notes:15]

[0000858877-24-000003:notes:19]
[same as prior period, unchanged from 0000858877-23-000031:notes:16]

[0000858877-24-000003:notes:20]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,081 |  |  | $ | 8,092 |  |  | $ | 15,904 |  |  | $ | 16,123 |  |
| Security | 973 |  |  | 943 |  |  | 1,984 |  |  | 1,914 |  |
| Collaboration | 989 |  |  | 958 |  |  | 2,106 |  |  | 2,044 |  |
| Observability | 188 |  |  | 162 |  |  | 378 |  |  | 319 |  |
| Total Product | 9,232 |  |  | 10,155 |  |  | 20,371 |  |  | 20,400 |  |
| Services | 3,559 |  |  | 3,437 |  |  | 7,088 |  |  | 6,824 |  |
| Total | $ | 12,791 |  |  | $ | 13,592 |  |  | 27,459 |  |  | 27,224 |  |

[0000858877-24-000003:notes:21]
[same as prior period, unchanged from 0000858877-23-000031:notes:18]

[0000858877-24-000003:notes:22]
[same as prior period, unchanged from 0000858877-23-000031:notes:19]

[0000858877-24-000003:notes:23]
[same as prior period, unchanged from 0000858877-23-000031:notes:20]

[0000858877-24-000003:notes:24]
[same as prior period, unchanged from 0000858877-23-000031:notes:21]

[0000858877-24-000003:notes:25]
[same as prior period, unchanged from 0000858877-23-000031:notes:22]

[0000858877-24-000003:notes:26]
[same as prior period, unchanged from 0000858877-23-000031:notes:25]

[0000858877-24-000003:notes:27]
[same as prior period, unchanged from 0000858877-23-000031:notes:26]

[0000858877-24-000003:notes:28]
Accounts receivable, net was $4.9 billion as of January 27, 2024 compared to $5.9 billion as of July 29, 2023, as reported on the Consolidated Balance Sheets.

[0000858877-24-000003:notes:29]
[same as prior period, unchanged from 0000858877-23-000031:notes:28]

[0000858877-24-000003:notes:30]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2024 |  | January 28, 2023 |  | January 27, 2024 |  | January 28, 2023 |
| Allowance for credit loss at beginning of period | $ | 82 |  |  | $ | 88 |  |  | $ | 85 |  |  | $ | 83 |  |
| Provisions (benefits) | 9 |  |  | 3 |  |  | 11 |  |  | 14 |  |
| Recoveries (write-offs), net | (12) |  |  | (5) |  |  | (17) |  |  | (11) |  |
| Allowance for credit loss at end of period | $ | 79 |  |  | $ | 86 |  |  | $ | 79 |  |  | $ | 86 |  |

[0000858877-24-000003:notes:31]
[same as prior period, unchanged from 0000858877-23-000031:notes:30]

[0000858877-24-000003:notes:32]
[same as prior period, unchanged from 0000858877-23-000031:notes:31]

[0000858877-24-000003:notes:33]
|  | January 27,2024 |  | July 29,2023 |
| 1 to 4 | $ | 693 |  |  | $ | 672 |  |
| 5 to 6 | 1,042 |  |  | 954 |  |
| 7 and Higher | 62 |  |  | 60 |  |
| Total | $ | 1,797 |  |  | $ | 1,686 |  |

[0000858877-24-000003:notes:34]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $1.8 billion as of January 27, 2024 and $1.6 billion as of July 29, 2023, and were included in other current assets and other assets.

[0000858877-24-000003:notes:35]
Contract liabilities consist of deferred revenue. Deferred revenue was $25.8 billion as of January 27, 2024 compared to $25.6 billion as of July 29, 2023. We recognized approximately $3.8 billion and $8.4 billion of revenue during the second quarter and first six months of fiscal 2024 that was included in the deferred revenue balance at July 29, 2023.

[0000858877-24-000003:notes:36]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Capitalized contract acquisition costs were $1.2 billion and $1.1 billion as of January 27, 2024 and July 29, 2023, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $166 million and $324 million for the second quarter and first six months fiscal 2024, respectively, and $201 million and $377 million for the corresponding periods of fiscal 2023, respectively, and was included in sales and marketing expenses.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-24-000003:notes:37]
[same as prior period, unchanged from 0000858877-23-000031:notes:37]

[0000858877-24-000003:notes:38]
[same as prior period, unchanged from 0000858877-23-000031:notes:38]

[0000858877-24-000003:notes:39]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,081 |  |  | $ | 8,092 |  |  | $ | 15,904 |  |  | $ | 16,123 |  |
| Security | 973 |  |  | 943 |  |  | 1,984 |  |  | 1,914 |  |
| Collaboration | 989 |  |  | 958 |  |  | 2,106 |  |  | 2,044 |  |
| Observability | 188 |  |  | 162 |  |  | 378 |  |  | 319 |  |
| Total Product | 9,232 |  |  | 10,155 |  |  | 20,371 |  |  | 20,400 |  |
| Services | 3,559 |  |  | 3,437 |  |  | 7,088 |  |  | 6,824 |  |
| Total | $ | 12,791 |  |  | $ | 13,592 |  |  | $ | 27,459 |  |  | $ | 27,224 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-24-000003:notes:40]
Acquisitions and Divestitures
A summary of the allocation of the total purchase consideration of our completed acquisitions during the first six months of fiscal 2024 is presented as follows (in millions):

[0000858877-24-000003:notes:41]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions | $ | 896 |  |  | $ | (50) |  |  | $ | 354 |  |  | $ | 592 |  |

[0000858877-24-000003:notes:42]
The total purchase consideration related to our acquisitions completed during the first six months of fiscal 2024 consisted primarily of cash consideration. The total cash and cash equivalents acquired from these acquisitions was approximately $17 million. Total transaction costs related to acquisition and divestiture activities were $51 million and $3 million for the first six months of fiscal 2024 and 2023, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-24-000003:notes:43]
[same as prior period, unchanged from 0000858877-23-000031:notes:43]

[0000858877-24-000003:notes:44]
The goodwill generated from acquisitions completed during the first six months of fiscal 2024 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-24-000003:notes:45]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first six months of fiscal 2024 have not been presented because the effects of the acquisitions were not material to our financial results.

[0000858877-24-000003:notes:46]
Intent to Acquire Splunk     On September 21, 2023, we announced our intent to acquire Splunk Inc. (“Splunk”), a public cybersecurity and observability company. Under the terms of the agreement, we have agreed to pay $157 per share in cash, representing approximately $28 billion in equity value. The acquisition is expected to close late in the first quarter or early in the second quarter of calendar year 2024, subject to regulatory approval and other customary closing conditions. We anticipate this transaction will be financed with a combination of cash and debt.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-24-000003:notes:47]
[same as prior period, unchanged from 0000858877-23-000031:notes:46]

[0000858877-24-000003:notes:48]
The following table presents the goodwill allocated to our reportable segments as of January 27, 2024 and during the first six months of fiscal 2024 (in millions):

[0000858877-24-000003:notes:49]
|  | Balance at July 29, 2023 |  | Acquisitions |  | Foreign Currency Translation and Other |  | Balance at January 27, 2024 |
| Americas | $ | 24,035 |  |  | $ | 367 |  |  | $ | (25) |  |  | $ | 24,377 |  |
| EMEA | 9,118 |  |  | 121 |  |  | (10) |  |  | 9,229 |  |
| APJC | 5,382 |  |  | 104 |  |  | (5) |  |  | 5,481 |  |
| Total | $ | 38,535 |  |  | $ | 592 |  |  | $ | (40) |  |  | $ | 39,087 |  |

[0000858877-24-000003:notes:50]
[same as prior period, unchanged from 0000858877-23-000031:notes:49]

[0000858877-24-000003:notes:51]
The following table presents details of our intangible assets acquired through acquisitions completed during the first six months of fiscal 2024 (in millions, except years):

[0000858877-24-000003:notes:52]
[same as prior period, unchanged from 0000858877-23-000031:notes:51]

[0000858877-24-000003:notes:53]
[same as prior period, unchanged from 0000858877-23-000031:notes:52]

[0000858877-24-000003:notes:54]
| January 27, 2024 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,020 |  |  | $ | (1,791) |  |  | $ | 1,229 |  |
| Customer relationships |  | 963 |  |  | (709) |  |  | 254 |  |
| Other |  | 42 |  |  | (27) |  |  | 15 |  |
| Total purchased intangible assets with finite lives |  | 4,025 |  |  | (2,527) |  |  | 1,498 |  |
| In-process research and development, with indefinite lives |  | 180 |  |  | — |  |  | 180 |  |
| Total |  | $ | 4,205 |  |  | $ | (2,527) |  |  | $ | 1,678 |  |

[0000858877-24-000003:notes:55]
[same as prior period, unchanged from 0000858877-23-000031:notes:54]

[0000858877-24-000003:notes:56]
[same as prior period, unchanged from 0000858877-23-000031:notes:55]

[0000858877-24-000003:notes:57]
[same as prior period, unchanged from 0000858877-23-000031:notes:56]

[0000858877-24-000003:notes:58]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2024 |  | January 28, 2023 |  | January 27, 2024 |  | January 28, 2023 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 180 |  |  | $ | 158 |  |  | $ | 366 |  |  | $ | 316 |  |
| Operating expenses | 66 |  |  | 71 |  |  | 133 |  |  | 142 |  |
| Total | $ | 246 |  |  | $ | 229 |  |  | $ | 499 |  |  | $ | 458 |  |

[0000858877-24-000003:notes:59]
The estimated future amortization expense of purchased intangible assets with finite lives as of January 27, 2024 is as follows (in millions):

[0000858877-24-000003:notes:60]
| Fiscal Year | Amount |
| 2024 (remaining six months) | $ | 440 |  |
| 2025 | $ | 576 |  |
| 2026 | $ | 228 |  |
| 2027 | $ | 143 |  |
| 2028 | $ | 100 |  |
| Thereafter | $ | 11 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-24-000003:notes:61]
Restructuring and Other Charges
In the third quarter of fiscal 2024, we initiated a restructuring plan (the “Fiscal 2024 Plan”) in order to realign the organization and enable further investment in key priority areas. The Fiscal 2024 Plan will impact approximately 5% of our global workforce, with estimated pretax charges of approximately $800 million. These aggregate pretax charges will be primarily cash-based and consist of severance and other one-time termination benefits and other costs. We expect this plan to be substantially completed during the first half of fiscal 2025.

[0000858877-24-000003:notes:62]
In the second quarter of fiscal 2023, we announced a restructuring plan (the “Fiscal 2023 Plan”) in order to rebalance the organization and enable further investment in key priority areas. In connection with the Fiscal 2023 Plan, we incurred charges of $12 million and $135 million for the second quarter and first six months of fiscal 2024, respectively. We incurred charges of $243 million for the second quarter and first six months of fiscal 2023. Total cumulative charges of $670 million have been recognized to date. These aggregate pretax charges were primarily cash-based and consist of severance and other one-time termination benefits, real estate-related charges, and other costs. We completed the Fiscal 2023 Plan in the second quarter of fiscal 2024.

[0000858877-24-000003:notes:63]
[same as prior period, unchanged from 0000858877-23-000031:notes:61]

[0000858877-24-000003:notes:64]
|  |  | FISCAL 2023 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 29, 2023 |  | $ | 166 |  |  | $ | 44 |  |  | $ | 210 |  |
| Charges |  | 104 |  |  | 31 |  |  | 135 |  |
| Cash payments |  | (222) |  |  | (8) |  |  | (230) |  |
| Non-cash items |  | — |  |  | (15) |  |  | (15) |  |
| Liability as of January 27, 2024 |  | $ | 48 |  |  | $ | 52 |  |  | $ | 100 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-24-000003:notes:65]
[same as prior period, unchanged from 0000858877-23-000031:notes:63]

[0000858877-24-000003:notes:66]
[same as prior period, unchanged from 0000858877-23-000031:notes:64]

[0000858877-24-000003:notes:67]
|  |  | January 27,2024 |  | July 29,2023 |
| Cash and cash equivalents |  | $ | 13,715 |  |  | $ | 10,123 |  |
| Restricted cash and restricted cash equivalents included in other current assets |  | 565 |  |  | 191 |  |
| Restricted cash and restricted cash equivalents included in other assets |  | 938 |  |  | 1,313 |  |
| Total |  | $ | 15,218 |  |  | $ | 11,627 |  |

[0000858877-24-000003:notes:68]
[same as prior period, unchanged from 0000858877-23-000031:notes:66]

[0000858877-24-000003:notes:69]
[same as prior period, unchanged from 0000858877-23-000031:notes:67]

[0000858877-24-000003:notes:70]
|  |  | January 27,2024 |  | July 29,2023 |
| Raw materials |  | $ | 1,784 |  |  | $ | 1,685 |  |
| Work in process |  | 165 |  |  | 264 |  |
| Finished goods |  | 1,047 |  |  | 1,493 |  |
| Service-related spares |  | 200 |  |  | 186 |  |
| Demonstration systems |  | 13 |  |  | 16 |  |
| Total |  | $ | 3,209 |  |  | $ | 3,644 |  |

[0000858877-24-000003:notes:71]
[same as prior period, unchanged from 0000858877-23-000031:notes:69]

[0000858877-24-000003:notes:72]
|  |  | January 27,2024 |  | July 29,2023 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,214 |  |  | $ | 4,229 |  |
| Computer equipment and related software |  | 691 |  |  | 744 |  |
| Production, engineering, and other equipment |  | 4,466 |  |  | 4,611 |  |
| Operating lease assets |  | 125 |  |  | 135 |  |
| Furniture, fixtures and other |  | 339 |  |  | 339 |  |
| Total gross property and equipment |  | 9,835 |  |  | 10,058 |  |
| Less: accumulated depreciation and amortization |  | (7,830) |  |  | (7,973) |  |
| Total |  | $ | 2,005 |  |  | $ | 2,085 |  |

[0000858877-24-000003:notes:73]
[same as prior period, unchanged from 0000858877-23-000031:notes:71]

[0000858877-24-000003:notes:74]
|  |  | January 27,2024 |  | July 29,2023 |
| Product |  | $ | 16,249 |  |  | $ | 15,802 |  |
| Service |  | 19,407 |  |  | 19,066 |  |
| Total |  | $ | 35,656 |  |  | $ | 34,868 |  |
| Short-term RPO |  | $ | 17,930 |  |  | $ | 17,910 |  |
| Long-term RPO |  | 17,726 |  |  | 16,958 |  |
| Total |  | $ | 35,656 |  |  | $ | 34,868 |  |
| Amount to be recognized as revenue over the next 12 months |  | 50 | % |  | 51 | % |
| Deferred revenue |  | $ | 25,771 |  |  | $ | 25,550 |  |
| Unbilled contract revenue |  | 9,885 |  |  | 9,318 |  |
| Total |  | $ | 35,656 |  |  | $ | 34,868 |  |

[0000858877-24-000003:notes:75]
[same as prior period, unchanged from 0000858877-23-000031:notes:73]

[0000858877-24-000003:notes:76]
[same as prior period, unchanged from 0000858877-23-000031:notes:74]

[0000858877-24-000003:notes:77]
|  |  | January 27,2024 |  | July 29,2023 |
| Product |  | $ | 11,640 |  |  | $ | 11,505 |  |
| Service |  | 14,131 |  |  | 14,045 |  |
| Total |  | $ | 25,771 |  |  | $ | 25,550 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 14,011 |  |  | $ | 13,908 |  |
| Noncurrent |  | 11,760 |  |  | 11,642 |  |
| Total |  | $ | 25,771 |  |  | $ | 25,550 |  |

[0000858877-24-000003:notes:78]
[same as prior period, unchanged from 0000858877-23-000031:notes:76]

[0000858877-24-000003:notes:79]
[same as prior period, unchanged from 0000858877-23-000031:notes:77]

[0000858877-24-000003:notes:80]
|  |  | January 27,2024 |  | July 29,2023 |
| Current |  | $ | 1,819 |  |  | $ | 1,364 |  |
| Noncurrent |  | 2,273 |  |  | 4,092 |  |
| Total |  | $ | 4,092 |  |  | $ | 5,456 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000858877-24-000003:notes:81]
Leases 
(a)Lessee Arrangements

[0000858877-24-000003:notes:82]
The following table presents our operating lease balances (in millions):

[0000858877-24-000003:notes:83]
|  | Balance Sheet Line Item |  | January 27, 2024 |  | July 29, 2023 |
| Operating lease right-of-use assets | Other assets |  | $ | 978 |  |  | $ | 971 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 330 |  |  | $ | 313 |  |
| Operating lease liabilities | Other long-term liabilities |  | 703 |  |  | 707 |  |
| Total operating lease liabilities |  |  | $ | 1,033 |  |  | $ | 1,020 |  |

[0000858877-24-000003:notes:84]
The components of our lease expenses were as follows (in millions):

[0000858877-24-000003:notes:85]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2024 |  | January 28, 2023 |  | January 27, 2024 |  | January 28, 2023 |
| Operating lease expense | $ | 103 |  |  | $ | 98 |  |  | $ | 203 |  |  | $ | 194 |  |
| Short-term lease expense | 25 |  |  | 17 |  |  | 36 |  |  | 34 |  |
| Variable lease expense | 50 |  |  | 63 |  |  | 106 |  |  | 121 |  |
| Total lease expense | $ | 178 |  |  | $ | 178 |  |  | $ | 345 |  |  | $ | 349 |  |

[0000858877-24-000003:notes:86]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-24-000003:notes:87]
|  | Six Months Ended |
|  | January 27, 2024 |  | January 28, 2023 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 178 |  |  | $ | 192 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 182 |  |  | $ | 149 |  |

[0000858877-24-000003:notes:88]
The weighted-average lease term was 4.6 years as of each of January 27, 2024 and July 29, 2023. The weighted-average discount rate was 3.7% and 3.1% as of January 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000003:notes:89]
The maturities of our operating leases (undiscounted) as of January 27, 2024 are as follows (in millions):

[0000858877-24-000003:notes:90]
| Fiscal Year | Amount |
| 2024 (remaining six months) | $ | 183 |  |
| 2025 | 303 |  |
| 2026 | 206 |  |
| 2027 | 129 |  |
| 2028 | 94 |  |
| Thereafter | 231 |  |
| Total lease payments | 1,146 |  |
| Less interest | (113) |  |
| Total | $ | 1,033 |  |

[0000858877-24-000003:notes:91]
(b)Lessor Arrangements

[0000858877-24-000003:notes:92]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income was $16 million and $30 million for the second quarter and the first six months of fiscal 2024, respectively, and $12 million and $24 million for the corresponding periods of fiscal 2023, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-24-000003:notes:93]
Future minimum lease payments on our lease receivables as of January 27, 2024 are summarized as follows (in millions):

[0000858877-24-000003:notes:94]
| Fiscal Year | Amount |
| 2024 (remaining six months) | $ | 401 |  |
| 2025 | 369 |  |
| 2026 | 125 |  |
| 2027 | 91 |  |
| 2028 | 68 |  |
| Thereafter | 45 |  |
| Total | 1,099 |  |
| Less: Present value of lease payments | (989) |  |
| Unearned income | $ | 110 |  |

[0000858877-24-000003:notes:95]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-24-000003:notes:96]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-24-000003:notes:97]
|  | January 27, 2024 |  | July 29, 2023 |
| Operating lease assets | $ | 125 |  |  | $ | 135 |  |
| Accumulated depreciation | (72) |  |  | (78) |  |
| Operating lease assets, net | $ | 53 |  |  | $ | 57 |  |

[0000858877-24-000003:notes:98]
Our operating lease income was $15 million and $31 million for the second quarter and first six months of fiscal 2024, respectively, and $18 million and $39 million for the corresponding periods of fiscal 2023, respectively, and was included in product revenue in the Consolidated Statements of Operations.

[0000858877-24-000003:notes:99]
Minimum future rentals on noncancelable operating leases as of January 27, 2024 are summarized as follows (in millions):

[0000858877-24-000003:notes:100]
| Fiscal Year | Amount |
| 2024 (remaining six months) | $ | 12 |  |
| 2025 | 16 |  |
| 2026 | 9 |  |
| 2027 | 1 |  |
| Total | $ | 38 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-24-000003:notes:101]
[same as prior period, unchanged from 0000858877-23-000031:notes:99]

[0000858877-24-000003:notes:102]
[same as prior period, unchanged from 0000858877-23-000031:notes:100]

[0000858877-24-000003:notes:103]
[same as prior period, unchanged from 0000858877-23-000031:notes:101]

[0000858877-24-000003:notes:104]
| January 27, 2024 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,850 |  |  | $ | 1,099 |  |  | $ | 6,949 |  |
| Residual value | — |  |  | 70 |  |  | 70 |  |
| Unearned income | — |  |  | (110) |  |  | (110) |  |
| Allowance for credit loss | (53) |  |  | (16) |  |  | (69) |  |
| Total, net | $ | 5,797 |  |  | $ | 1,043 |  |  | $ | 6,840 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 3,066 |  |  | $ | 410 |  |  | $ | 3,476 |  |
| Noncurrent | 2,731 |  |  | 633 |  |  | 3,364 |  |
| Total, net | $ | 5,797 |  |  | $ | 1,043 |  |  | $ | 6,840 |  |

[0000858877-24-000003:notes:105]
[same as prior period, unchanged from 0000858877-23-000031:notes:103]

[0000858877-24-000003:notes:106]
[same as prior period, unchanged from 0000858877-23-000031:notes:104]

[0000858877-24-000003:notes:107]
[same as prior period, unchanged from 0000858877-23-000031:notes:105]

[0000858877-24-000003:notes:108]
| January 27, 2024 |  |  | Fiscal Year |  | Six Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 25, 2020 |  | July 31, 2021 |  | July 30, 2022 |  | July 29, 2023 |  | January 27, 2024 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 24 |  |  | $ | 164 |  |  | $ | 552 |  |  | $ | 783 |  |  | $ | 1,243 |  |  | $ | 1,008 |  |  | $ | 3,774 |  |
| 5 to 6 | 6 |  |  | 67 |  |  | 169 |  |  | 256 |  |  | 629 |  |  | 821 |  |  | 1,948 |  |
| 7 and Higher | 4 |  |  | 4 |  |  | 12 |  |  | 87 |  |  | 18 |  |  | 3 |  |  | 128 |  |
| Total Loan Receivables | $ | 34 |  |  | $ | 235 |  |  | $ | 733 |  |  | $ | 1,126 |  |  | $ | 1,890 |  |  | $ | 1,832 |  |  | $ | 5,850 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 6 |  |  | $ | 31 |  |  | $ | 71 |  |  | $ | 71 |  |  | $ | 224 |  |  | $ | 215 |  |  | $ | 618 |  |
| 5 to 6 | 4 |  |  | 28 |  |  | 41 |  |  | 71 |  |  | 158 |  |  | 53 |  |  | 355 |  |
| 7 and Higher | 1 |  |  | 1 |  |  | 2 |  |  | 4 |  |  | 5 |  |  | 3 |  |  | 16 |  |
| Total Lease Receivables | $ | 11 |  |  | $ | 60 |  |  | $ | 114 |  |  | $ | 146 |  |  | $ | 387 |  |  | $ | 271 |  |  | $ | 989 |  |
| Total | $ | 45 |  |  | $ | 295 |  |  | $ | 847 |  |  | $ | 1,272 |  |  | $ | 2,277 |  |  | $ | 2,103 |  |  | $ | 6,839 |  |

[0000858877-24-000003:notes:109]
[same as prior period, unchanged from 0000858877-23-000031:notes:107]

[0000858877-24-000003:notes:110]
The following tables present the aging analysis of gross receivables as of January 27, 2024 and July 29, 2023 (in millions):

[0000858877-24-000003:notes:111]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| January 27, 2024 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 55 |  |  | $ | 32 |  |  | $ | 74 |  |  | $ | 161 |  |  | $ | 5,689 |  |  | $ | 5,850 |  |  | $ | 23 |  |  | $ | 8 |  |  | $ | 8 |  |
| Lease receivables | 19 |  |  | 8 |  |  | 21 |  |  | 48 |  |  | 941 |  |  | 989 |  |  | 11 |  |  | 2 |  |  | 2 |  |
| Total | $ | 74 |  |  | $ | 40 |  |  | $ | 95 |  |  | $ | 209 |  |  | $ | 6,630 |  |  | $ | 6,839 |  |  | $ | 34 |  |  | $ | 10 |  |  | $ | 10 |  |

[0000858877-24-000003:notes:112]
[same as prior period, unchanged from 0000858877-23-000031:notes:110]

[0000858877-24-000003:notes:113]
[same as prior period, unchanged from 0000858877-23-000031:notes:111]

[0000858877-24-000003:notes:114]
[same as prior period, unchanged from 0000858877-23-000031:notes:112]

[0000858877-24-000003:notes:115]
[same as prior period, unchanged from 0000858877-23-000031:notes:113]

[0000858877-24-000003:notes:116]
| Three Months Ended January 27, 2024 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of October 28, 2023 | $ | 58 |  |  | $ | 16 |  |  | $ | 74 |  |
| Provisions (benefits) | (1) |  |  | — |  |  | (1) |  |
| Recoveries (write-offs), net | (4) |  |  | — |  |  | (4) |  |
| Allowance for credit loss as of January 27, 2024 | $ | 53 |  |  | $ | 16 |  |  | $ | 69 |  |

[0000858877-24-000003:notes:117]
| Three Months Ended January 28, 2023 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of October 29, 2022 | $ | 101 |  |  | $ | 19 |  |  | $ | 120 |  |
| Provisions (benefits) | (3) |  |  | (1) |  |  | (4) |  |
| Other | (4) |  |  | 1 |  |  | (3) |  |
| Allowance for credit loss as of January 28, 2023 | $ | 94 |  |  | $ | 19 |  |  | $ | 113 |  |

[0000858877-24-000003:notes:118]
| Six Months Ended January 27, 2024 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 29, 2023 | $ | 53 |  |  | $ | 19 |  |  | $ | 72 |  |
| Provisions (benefits) | 4 |  |  | (3) |  |  | 1 |  |
| Recoveries (write-offs), net | (4) |  |  | — |  |  | (4) |  |
| Allowance for credit loss as of January 27, 2024 | $ | 53 |  |  | $ | 16 |  |  | $ | 69 |  |

[0000858877-24-000003:notes:119]
| Six Months Ended January 28, 2023 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 30, 2022 | $ | 103 |  |  | $ | 23 |  |  | $ | 126 |  |
| Provisions (benefits) | (4) |  |  | (4) |  |  | (8) |  |
| Other | (5) |  |  | — |  |  | (5) |  |
| Allowance for credit loss as of January 28, 2023 | $ | 94 |  |  | $ | 19 |  |  | $ | 113 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-24-000003:notes:120]
Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-24-000003:notes:121]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-24-000003:notes:122]
| January 27, 2024 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,428 |  |  | $ | 3 |  |  | $ | (34) |  |  | $ | 2,397 |  |
| U.S. government agency securities | 354 |  |  | — |  |  | (2) |  |  | 352 |  |
| Non-U.S. government and agency securities | 364 |  |  | — |  |  | — |  |  | 364 |  |
| Corporate debt securities | 5,343 |  |  | 7 |  |  | (210) |  |  | 5,140 |  |
| U.S. agency mortgage-backed securities | 2,127 |  |  | 1 |  |  | (197) |  |  | 1,931 |  |
| Commercial paper | 828 |  |  | — |  |  | — |  |  | 828 |  |
| Certificates of deposit | 518 |  |  | — |  |  | — |  |  | 518 |  |
| Total | $ | 11,962 |  |  | $ | 11 |  |  | $ | (443) |  |  | $ | 11,530 |  |

[0000858877-24-000003:notes:123]
| July 29, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 3,587 |  |  | $ | 1 |  |  | $ | (62) |  |  | $ | 3,526 |  |
| U.S. government agency securities | 428 |  |  | — |  |  | (5) |  |  | 423 |  |
| Non-U.S. government and agency securities | 364 |  |  | — |  |  | (1) |  |  | 363 |  |
| Corporate debt securities | 7,238 |  |  | 3 |  |  | (327) |  |  | 6,914 |  |
| U.S. agency mortgage-backed securities | 2,421 |  |  | 14 |  |  | (230) |  |  | 2,205 |  |
| Commercial paper | 1,484 |  |  | — |  |  | — |  |  | 1,484 |  |
| Certificates of deposit | 677 |  |  | — |  |  | — |  |  | 677 |  |
| Total | $ | 16,199 |  |  | $ | 18 |  |  | $ | (625) |  |  | $ | 15,592 |  |

[0000858877-24-000003:notes:124]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-24-000003:notes:125]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2024 |  | January 28, 2023 |  | January 27, 2024 |  | January 28, 2023 |
| Gross realized gains | $ | 5 |  |  | $ | 3 |  |  | $ | 5 |  |  | $ | 3 |  |
| Gross realized losses | (28) |  |  | (6) |  |  | (48) |  |  | (12) |  |
| Total | $ | (23) |  |  | $ | (3) |  |  | $ | (43) |  |  | $ | (9) |  |

[0000858877-24-000003:notes:126]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 27, 2024 and July 29, 2023 (in millions):

[0000858877-24-000003:notes:127]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,145 |  |  | $ | (9) |  |  | $ | 550 |  |  | $ | (25) |  |  | $ | 1,695 |  |  | $ | (34) |  |
| U.S. government agency securities | 224 |  |  | — |  |  | 39 |  |  | (2) |  |  | 263 |  |  | (2) |  |
| Non-U.S. government and agency securities | 200 |  |  | — |  |  | — |  |  | — |  |  | 200 |  |  | — |  |
| Corporate debt securities | 557 |  |  | (2) |  |  | 3,527 |  |  | (178) |  |  | 4,084 |  |  | (180) |  |
| U.S. agency mortgage-backed securities | 415 |  |  | (6) |  |  | 1,320 |  |  | (191) |  |  | 1,735 |  |  | (197) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 2,551 |  |  | $ | (17) |  |  | $ | 5,436 |  |  | $ | (396) |  |  | $ | 7,987 |  |  | $ | (413) |  |

[0000858877-24-000003:notes:128]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 2,394 |  |  | $ | (26) |  |  | $ | 931 |  |  | $ | (36) |  |  | $ | 3,325 |  |  | $ | (62) |  |
| U.S. government agency securities | 343 |  |  | (2) |  |  | 72 |  |  | (3) |  |  | 415 |  |  | (5) |  |
| Non-U.S. government and agency securities | 363 |  |  | (1) |  |  | — |  |  | — |  |  | 363 |  |  | (1) |  |
| Corporate debt securities | 1,736 |  |  | (22) |  |  | 4,315 |  |  | (275) |  |  | 6,051 |  |  | (297) |  |
| U.S. agency mortgage-backed securities | 658 |  |  | (13) |  |  | 1,438 |  |  | (217) |  |  | 2,096 |  |  | (230) |  |
| Commercial paper | 97 |  |  | — |  |  | — |  |  | — |  |  | 97 |  |  | — |  |
| Certificates of deposit | 2 |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |
| Total | $ | 5,593 |  |  | $ | (64) |  |  | $ | 6,756 |  |  | $ | (531) |  |  | $ | 12,349 |  |  | $ | (595) |  |

[0000858877-24-000003:notes:129]
The following table summarizes the maturities of our available-for-sale debt investments as of January 27, 2024 (in millions):

[0000858877-24-000003:notes:130]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 3,686 |  |  | $ | 3,642 |  |
| After 1 year through 5 years | 6,149 |  |  | 5,957 |  |
| Mortgage-backed securities with no single maturity | 2,127 |  |  | 1,931 |  |
| Total | $ | 11,962 |  |  | $ | 11,530 |  |

[0000858877-24-000003:notes:131]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-24-000003:notes:132]
(b)Summary of Equity Investments

[0000858877-24-000003:notes:133]
We held marketable equity securities of $426 million and $431 million as of January 27, 2024 and July 29, 2023, respectively. We recognized a net unrealized gain of $55 million and $17 million during the second quarter and first six months of fiscal 2024, respectively, and a net unrealized gain of $11 million and a net unrealized loss of $9 million during the corresponding periods of fiscal 2023, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $134 million for the second quarter and first six months of fiscal 2024, and a net gain of $3 million and a net loss of $8 million for the corresponding periods of fiscal 2023, respectively. We held equity interests in certain private equity funds of $0.8 billion and $0.9 billion as of January 27, 2024 and July 29, 2023, respectively, which are accounted for under the NAV practical expedient.

[0000858877-24-000003:notes:134]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 27, 2024, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-24-000003:notes:135]
The carrying value of our investments in privately held companies was $1.6 billion and $1.8 billion as of January 27, 2024 and July 29, 2023, respectively. Of the total carrying value of our investments in privately held companies as of January 27, 2024, $0.9 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of January 27, 2024, we have total funding commitments of $0.2 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-24-000003:notes:136]
[same as prior period, unchanged from 0000858877-23-000031:notes:132]

[0000858877-24-000003:notes:137]
[same as prior period, unchanged from 0000858877-23-000031:notes:133]

[0000858877-24-000003:notes:138]
|  | JANUARY 27, 2024 |  | JULY 29, 2023 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 10,103 |  |  | $ | — |  |  | $ | 10,103 |  |  | $ | 6,496 |  |  | $ | — |  |  | $ | 6,496 |  |
| Commercial paper | — |  |  | 1,023 |  |  | 1,023 |  |  | — |  |  | 1,090 |  |  | 1,090 |  |
| Certificates of deposit | — |  |  | 2 |  |  | 2 |  |  | — |  |  | 47 |  |  | 47 |  |
| Corporate debt securities | — |  |  | 30 |  |  | 30 |  |  | — |  |  | 25 |  |  | 25 |  |
| Non-U.S. government and agency securities | — |  |  | 7 |  |  | 7 |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 2,397 |  |  | 2,397 |  |  | — |  |  | 3,526 |  |  | 3,526 |  |
| U.S. government agency securities | — |  |  | 352 |  |  | 352 |  |  | — |  |  | 423 |  |  | 423 |  |
| Non-U.S. government and agency securities | — |  |  | 364 |  |  | 364 |  |  | — |  |  | 363 |  |  | 363 |  |
| Corporate debt securities | — |  |  | 5,140 |  |  | 5,140 |  |  | — |  |  | 6,914 |  |  | 6,914 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,931 |  |  | 1,931 |  |  | — |  |  | 2,205 |  |  | 2,205 |  |
| Commercial paper | — |  |  | 828 |  |  | 828 |  |  | — |  |  | 1,484 |  |  | 1,484 |  |
| Certificates of deposit | — |  |  | 518 |  |  | 518 |  |  | — |  |  | 677 |  |  | 677 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 426 |  |  | — |  |  | 426 |  |  | 431 |  |  | — |  |  | 431 |  |
| Other current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 563 |  |  | — |  |  | 563 |  |  | 188 |  |  | — |  |  | 188 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 938 |  |  | — |  |  | 938 |  |  | 1,313 |  |  | — |  |  | 1,313 |  |
| Derivative assets | — |  |  | 50 |  |  | 50 |  |  | — |  |  | 32 |  |  | 32 |  |
| Total | $ | 12,030 |  |  | $ | 12,642 |  |  | $ | 24,672 |  |  | $ | 8,428 |  |  | $ | 16,786 |  |  | $ | 25,214 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 70 |  |  | $ | 70 |  |  | $ | — |  |  | $ | 75 |  |  | $ | 75 |  |
| Total | $ | — |  |  | $ | 70 |  |  | $ | 70 |  |  | $ | — |  |  | $ | 75 |  |  | $ | 75 |  |

[0000858877-24-000003:notes:139]
[same as prior period, unchanged from 0000858877-23-000031:notes:135]

[0000858877-24-000003:notes:140]
[same as prior period, unchanged from 0000858877-23-000031:notes:136]

[0000858877-24-000003:notes:141]
[same as prior period, unchanged from 0000858877-23-000031:notes:137]

[0000858877-24-000003:notes:142]
[same as prior period, unchanged from 0000858877-23-000031:notes:138]

[0000858877-24-000003:notes:143]
The fair value of our short-term loan receivables approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables as of January 27, 2024 and July 29, 2023 was $2.7 billion and $2.9 billion, respectively. The estimated fair value of our long-term loan receivables approximates their carrying value. We use unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables, and therefore they are categorized as Level 3.
As of January 27, 2024, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of January 27, 2024, the fair value of our senior notes was $7.9 billion with a carrying amount of $7.7 billion. This compares to a fair value of $8.7 billion and a carrying amount of $8.4 billion as of July 29, 2023. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2.


## us-gaap:DebtDisclosureTextBlock

[0000858877-24-000003:notes:144]
Borrowings 
(a)Short-Term Debt

[0000858877-24-000003:notes:145]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-24-000003:notes:146]
|  | January 27, 2024 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 997 |  |  | 6.35 | % |  | $ | 1,733 |  |  | 4.45 | % |
| Commercial paper | 3,939 |  |  | 5.39 | % |  | — |  |  | — | % |
| Total | $ | 4,936 |  |  |  |  | $ | 1,733 |  |  |  |

[0000858877-24-000003:notes:147]
Effective February 6, 2024, we increased our borrowing capacity under our existing commercial paper program from $10.0 billion to $15.0 billion. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. As of February 19, 2024, we had approximately $6.9 billion of commercial paper notes outstanding.

[0000858877-24-000003:notes:148]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-24-000003:notes:149]
(b)Long-Term Debt

[0000858877-24-000003:notes:150]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-24-000003:notes:151]
|  |  |  | January 27, 2024 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 6.35% |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.66% |  | 500 |  |  | 6.38% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 7,750 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (66) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (18) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 7,666 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 997 |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 6,669 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 7,666 |  |  |  |  | $ | 8,391 |  |  |  |

[0000858877-24-000003:notes:152]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $1.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on Secured Overnight Financing Rate (SOFR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-24-000003:notes:153]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 27, 2024, we were in compliance with all debt covenants.

[0000858877-24-000003:notes:154]
As of January 27, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-24-000003:notes:155]
| Fiscal Year | Amount |
| 2024 (remaining six months) | $ | 1,000 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 7,750 |  |

[0000858877-24-000003:notes:156]
(c)Credit Facility

[0000858877-24-000003:notes:157]
On May 13, 2021, we entered into a 5-year $3.0 billion unsecured revolving credit agreement, as amended on April 18, 2023. On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of January 27, 2024, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-24-000003:notes:158]
[same as prior period, unchanged from 0000858877-23-000031:notes:154]

[0000858877-24-000003:notes:159]
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risks by limiting our counterparties to major financial institutions and requiring collateral in certain cases. In addition, the potential risk of loss with any one counterparty resulting from credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-24-000003:notes:160]
[same as prior period, unchanged from 0000858877-23-000031:notes:156]

[0000858877-24-000003:notes:161]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | January 27,2024 |  | July 29,2023 |  | Balance Sheet Line Item |  | January 27,2024 |  | July 29,2023 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 35 |  |  | $ | 22 |  |  | Other current liabilities |  | $ | 2 |  |  | $ | — |  |
| Foreign currency derivatives | Other assets |  | 13 |  |  | 9 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 3 |  |  | 17 |  |
| Interest rate derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 15 |  |  | 24 |  |
| Total |  |  | 48 |  |  | 31 |  |  |  |  | 20 |  |  | 41 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 2 |  |  | 1 |  |  | Other current liabilities |  | 37 |  |  | 25 |  |
| Foreign currency derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 13 |  |  | 9 |  |
| Total |  |  | 2 |  |  | 1 |  |  |  |  | 50 |  |  | 34 |  |
| Total |  |  | $ | 50 |  |  | $ | 32 |  |  |  |  | $ | 70 |  |  | $ | 75 |  |

[0000858877-24-000003:notes:162]
[same as prior period, unchanged from 0000858877-23-000031:notes:158]

[0000858877-24-000003:notes:163]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | January 27,2024 |  | July 29,2023 |  | January 27,2024 |  | July 29,2023 |
| Short-term debt |  | $ | (997) |  |  | $ | (983) |  |  | $ | 3 |  |  | $ | 17 |  |
| Long-term debt |  | $ | (485) |  |  | $ | (476) |  |  | $ | 15 |  |  | $ | 24 |  |

[0000858877-24-000003:notes:164]
[same as prior period, unchanged from 0000858877-23-000031:notes:160]

[0000858877-24-000003:notes:165]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 27, 2024 |  | January 28, 2023 |  | January 27, 2024 |  | January 28, 2023 |
| Interest rate derivatives: |  |  |  |  |  |  |  |  |
| Hedged items |  | $ | (14) |  |  | $ | (7) |  |  | $ | (23) |  |  | $ | 32 |  |
| Derivatives designated as hedging instruments |  | 14 |  |  | 7 |  |  | 23 |  |  | (32) |  |
| Total |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000858877-24-000003:notes:166]
[same as prior period, unchanged from 0000858877-23-000031:notes:162]

[0000858877-24-000003:notes:167]
|  |  |  |  | GAINS (LOSSES) FOR THE THREE MONTHS ENDED |  | GAINS (LOSSES) FOR THE SIX MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | 53 |  |  | $ | 140 |  |  | $ | (77) |  |  | $ | 68 |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | 93 |  |  | 44 |  |  | 16 |  |  | 19 |  |
| Equity derivatives |  | Other income (loss), net |  | — |  |  | 5 |  |  | 2 |  |  | 4 |  |
| Total |  |  |  | $ | 146 |  |  | $ | 189 |  |  | $ | (59) |  |  | $ | 91 |  |

[0000858877-24-000003:notes:168]
[same as prior period, unchanged from 0000858877-23-000031:notes:164]

[0000858877-24-000003:notes:169]
|  | January 27,2024 |  | July 29,2023 |
| Foreign currency derivatives | $ | 6,207 |  |  | $ | 5,419 |  |
| Interest rate derivatives | 1,500 |  |  | 1,500 |  |
| Total return swaps—deferred compensation | 879 |  |  | 792 |  |
| Total | $ | 8,586 |  |  | $ | 7,711 |  |

[0000858877-24-000003:notes:170]
[same as prior period, unchanged from 0000858877-23-000031:notes:166]

[0000858877-24-000003:notes:171]
[same as prior period, unchanged from 0000858877-23-000031:notes:167]

[0000858877-24-000003:notes:172]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral provided for was $13 million and $40 million as of January 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000003:notes:173]
[same as prior period, unchanged from 0000858877-23-000031:notes:169]

[0000858877-24-000003:notes:174]
[same as prior period, unchanged from 0000858877-23-000031:notes:170]

[0000858877-24-000003:notes:175]
[same as prior period, unchanged from 0000858877-23-000031:notes:171]

[0000858877-24-000003:notes:176]
We enter into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, long-term customer financings and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of monetary assets and liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-24-000003:notes:177]
[same as prior period, unchanged from 0000858877-23-000031:notes:173]

[0000858877-24-000003:notes:178]
[same as prior period, unchanged from 0000858877-23-000031:notes:174]

[0000858877-24-000003:notes:179]
[same as prior period, unchanged from 0000858877-23-000031:notes:175]

[0000858877-24-000003:notes:180]
[same as prior period, unchanged from 0000858877-23-000031:notes:176]

[0000858877-24-000003:notes:181]
[same as prior period, unchanged from 0000858877-23-000031:notes:177]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-24-000003:notes:182]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-24-000003:notes:183]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-24-000003:notes:184]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-24-000003:notes:185]
|  | January 27,2024 |  | July 29,2023 |
| Less than 1 year | $ | 4,711 |  |  | $ | 5,270 |  |
| 1 to 3 years | 1,456 |  |  | 1,783 |  |
| 3 to 5 years | 26 |  |  | 200 |  |
| Total | $ | 6,193 |  |  | $ | 7,253 |  |

[0000858877-24-000003:notes:186]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 27, 2024 and July 29, 2023, the liability for these purchase commitments was $538 million and $529 million, respectively, and was included in other current liabilities.

[0000858877-24-000003:notes:187]
(b)Other Commitments

[0000858877-24-000003:notes:188]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-24-000003:notes:189]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-24-000003:notes:190]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2024 |  | January 28, 2023 |  | January 27, 2024 |  | January 28, 2023 |
| Compensation expense related to acquisitions | $ | 45 |  |  | $ | 49 |  |  | $ | 94 |  |  | $ | 123 |  |

[0000858877-24-000003:notes:191]
As of January 27, 2024, we estimated that future cash compensation expense of up to $397 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-24-000003:notes:192]
We also have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.2 billion and $0.3 billion as of January 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000003:notes:193]
(c)Product Warranties

[0000858877-24-000003:notes:194]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-24-000003:notes:195]
|  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |
| Balance at beginning of period | $ | 329 |  |  | $ | 333 |  |
| Provisions for warranties issued | 198 |  |  | 188 |  |
| Adjustments for pre-existing warranties | 5 |  |  | 13 |  |
| Settlements | (205) |  |  | (218) |  |
| Balance at end of period | $ | 327 |  |  | $ | 316 |  |

[0000858877-24-000003:notes:196]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-24-000003:notes:197]
(d)Financing and Other Guarantees

[0000858877-24-000003:notes:198]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-24-000003:notes:199]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.6 billion and $7.5 billion for the second quarter of fiscal 2024 and 2023, respectively, and $14.8 billion and $15.1 billion for the first six months of fiscal 2024 and 2023, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.7 billion as of January 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000003:notes:200]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at January 27, 2024 and July 29, 2023, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-24-000003:notes:201]
|  | January 27,2024 |  | July 29,2023 |
| Maximum potential future payments | $ | 138 |  |  | $ | 159 |  |
| Deferred revenue | (23) |  |  | (34) |  |
| Total | $ | 115 |  |  | $ | 125 |  |

[0000858877-24-000003:notes:202]
(e)Indemnifications

[0000858877-24-000003:notes:203]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-24-000003:notes:204]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-24-000003:notes:205]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-24-000003:notes:206]
(f)Legal Proceedings

[0000858877-24-000003:notes:207]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $165 million for the alleged evasion of import and other taxes, $929 million for interest, and $373 million for various penalties, all determined using an exchange rate as of January 27, 2024.

[0000858877-24-000003:notes:208]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-24-000003:notes:209]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. After two bench trials and various administrative actions and appeals, we have been found either to not have infringed any of the patents or the patents have been invalidated. There is an appeal of one of the invalidity decisions and we expect a further appeal by Centripetal.

[0000858877-24-000003:notes:210]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringe three patents, one patent was invalidated, the utility model was invalidated, and the infringement action on the final patent is stayed due to a pending invalidity action. There are appeals pending and the next proceeding is expected in the second half of fiscal 2024.

[0000858877-24-000003:notes:211]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement. We have filed our response and defenses to the complaint and the next proceedings are expected in the second half of fiscal 2024.

[0000858877-24-000003:notes:212]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of the litigations at this time. If we do not prevail in these litigations, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-24-000003:notes:213]
Ramot     On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the

[0000858877-24-000003:notes:214]
validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents. The next proceedings are expected in the first half of fiscal 2025.

[0000858877-24-000003:notes:215]
While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-24-000003:notes:216]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023 and the next proceedings are expected in the second half of fiscal 2024.

[0000858877-24-000003:notes:217]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward. On June 9, 2020, Viasat filed another suit in SDSC alleging contract and trade secret claims for sales of additional Acacia products. Both matters have been formally dismissed and resolved through a settlement for an amount that did not have a material effect on our Consolidated Financial Statements.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-24-000003:notes:218]
Purchase Commitments with Contract Manufacturers and Suppliers We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-24-000003:notes:219]
[same as prior period, unchanged from 0000858877-23-000031:notes:217]

[0000858877-24-000003:notes:220]
In September 2001, our Board of Directors authorized a stock repurchase program. As of January 27, 2024, the remaining authorized amount for stock repurchases under this program was approximately $8.4 billion with no termination date. The stock repurchase activity for fiscal 2024 and 2023 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-24-000003:notes:221]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2024 |  |  |  |  |  |  |
| January 27, 2024 |  | 25 |  |  | $ | 49.54 |  |  | $ | 1,254 |  |
| October 28, 2023 |  | 23 |  |  | $ | 54.53 |  |  | $ | 1,252 |  |
| Fiscal 2023 |  |  |  |  |  |  |
| July 29, 2023 |  | 25 |  |  | $ | 50.49 |  |  | $ | 1,254 |  |
| April 29, 2023 |  | 25 |  |  | $ | 49.45 |  |  | $ | 1,259 |  |
| January 28, 2023 |  | 26 |  |  | $ | 47.72 |  |  | $ | 1,256 |  |
| October 29, 2022 |  | 12 |  |  | $ | 43.76 |  |  | $ | 502 |  |

[0000858877-24-000003:notes:222]
There were stock repurchases of $50 million and $48 million that were pending settlement as of January 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000003:notes:223]
[same as prior period, unchanged from 0000858877-23-000031:notes:221]

[0000858877-24-000003:notes:224]
[same as prior period, unchanged from 0000858877-23-000031:notes:222]

[0000858877-24-000003:notes:225]
On February 14, 2024, our Board of Directors declared a quarterly dividend of $0.40 per common share to be paid on April 24, 2024, to all stockholders of record as of the close of business on April 4, 2024. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-24-000003:notes:226]
[same as prior period, unchanged from 0000858877-23-000031:notes:224]

[0000858877-24-000003:notes:227]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock in one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights, if any, of such series, and any qualifications, limitations or restrictions thereof, of the shares of such series. As of January 27, 2024, we had not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-24-000003:notes:228]
[same as prior period, unchanged from 0000858877-23-000031:notes:226]

[0000858877-24-000003:notes:229]
[same as prior period, unchanged from 0000858877-23-000031:notes:227]

[0000858877-24-000003:notes:230]
[same as prior period, unchanged from 0000858877-23-000031:notes:228]

[0000858877-24-000003:notes:231]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of January 27, 2024, 156 million shares were authorized for future grant under the 2005 Plan.

[0000858877-24-000003:notes:232]
[same as prior period, unchanged from 0000858877-23-000031:notes:231]

[0000858877-24-000003:notes:233]
We have an Employee Stock Purchase Plan under which eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. Under the Employee Stock Purchase Plan, we issued 10 million shares during the second quarter and first six months of fiscal 2024 and 9 million shares during the second quarter and first six months of fiscal 2023. As of January 27, 2024, 78 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-24-000003:notes:234]
[same as prior period, unchanged from 0000858877-23-000031:notes:233]

[0000858877-24-000003:notes:235]
Share-based compensation expense consists primarily of expenses for RSUs and stock purchase rights, granted to employees or assumed from acquisitions. The following table summarizes share-based compensation expense (in millions):

[0000858877-24-000003:notes:236]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2024 |  | January 28, 2023 |  | January 27, 2024 |  | January 28, 2023 |
| Cost of sales—product | $ | 58 |  |  | $ | 40 |  |  | $ | 100 |  |  | $ | 71 |  |
| Cost of sales—service | 81 |  |  | 66 |  |  | 142 |  |  | 116 |  |
| Share-based compensation expense in cost of sales | 139 |  |  | 106 |  |  | 242 |  |  | 187 |  |
| Research and development | 344 |  |  | 261 |  |  | 618 |  |  | 465 |  |
| Sales and marketing | 221 |  |  | 166 |  |  | 407 |  |  | 319 |  |
| General and administrative | 97 |  |  | 71 |  |  | 187 |  |  | 129 |  |
| Restructuring and other charges | 1 |  |  | (3) |  |  | 9 |  |  | (3) |  |
| Share-based compensation expense in operating expenses | 663 |  |  | 495 |  |  | 1,221 |  |  | 910 |  |
| Total share-based compensation expense | $ | 802 |  |  | $ | 601 |  |  | $ | 1,463 |  |  | $ | 1,097 |  |
| Income tax benefit for share-based compensation | $ | 202 |  |  | $ | 109 |  |  | $ | 345 |  |  | $ | 208 |  |

[0000858877-24-000003:notes:237]
As of January 27, 2024, the total compensation cost related to unvested share-based awards not yet recognized was $5.4 billion which is expected to be recognized over approximately 2.2 years on a weighted-average basis.

[0000858877-24-000003:notes:238]
[same as prior period, unchanged from 0000858877-23-000031:notes:237]

[0000858877-24-000003:notes:239]
[same as prior period, unchanged from 0000858877-23-000031:notes:238]

[0000858877-24-000003:notes:240]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| Unvested balance at July 30, 2022 | 97 |  |  | $ | 46.67 |  |  |  |
| Granted and assumed | 72 |  |  | 42.08 |  |  |  |
| Vested | (39) |  |  | 46.69 |  |  | $ | 1,746 |  |
| Canceled/forfeited/other | (8) |  |  | 45.17 |  |  |  |
| Unvested balance at July 29, 2023 | 122 |  |  | $ | 44.04 |  |  |  |
| Granted and assumed | 48 |  |  | 50.58 |  |  |  |
| Vested | (34) |  |  | 42.87 |  |  | $ | 1,733 |  |
| Canceled/forfeited/other | (4) |  |  | 44.50 |  |  |  |
| Unvested balance at January 27, 2024 | 132 |  |  | $ | 46.69 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-24-000003:notes:241]
Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first six months of fiscal 2024 and 2023 are summarized as follows (in millions):

[0000858877-24-000003:notes:242]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 29, 2023 | $ | (440) |  |  | $ | 18 |  |  | $ | (1,153) |  |  | $ | (1,575) |  |
| Other comprehensive income (loss) before reclassifications | 132 |  |  | 39 |  |  | (81) |  |  | 90 |  |
| (Gains) losses reclassified out of AOCI | 43 |  |  | (23) |  |  | (2) |  |  | 18 |  |
| Tax benefit (expense) | (42) |  |  | (4) |  |  | 1 |  |  | (45) |  |
| Balance at January 27, 2024 | $ | (307) |  |  | $ | 30 |  |  | $ | (1,235) |  |  | $ | (1,512) |  |

[0000858877-24-000003:notes:243]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 30, 2022 | $ | (379) |  |  | $ | 44 |  |  | $ | (1,287) |  |  | $ | (1,622) |  |
| Other comprehensive income (loss) before reclassifications | (76) |  |  | (12) |  |  | 106 |  |  | 18 |  |
| (Gains) losses reclassified out of AOCI | 9 |  |  | (37) |  |  | (1) |  |  | (29) |  |
| Tax benefit (expense) | 11 |  |  | 12 |  |  | 24 |  |  | 47 |  |
| Balance at January 28, 2023 | $ | (435) |  |  | $ | 7 |  |  | $ | (1,158) |  |  | $ | (1,586) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-24-000003:notes:244]
[same as prior period, unchanged from 0000858877-23-000031:notes:243]

[0000858877-24-000003:notes:245]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Income before provision for income taxes | $ | 3,161 |  |  | $ | 3,415 |  |  | $ | 7,603 |  |  | $ | 6,890 |  |
| Provision for income taxes | $ | 527 |  |  | $ | 642 |  |  | $ | 1,331 |  |  | $ | 1,447 |  |
| Effective tax rate | 16.7 | % |  | 18.8 | % |  | 17.5 | % |  | 21.0 | % |

[0000858877-24-000003:notes:246]
As of January 27, 2024, we had $2.0 billion of unrecognized tax benefits, of which $1.6 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-24-000003:notes:247]
[same as prior period, unchanged from 0000858877-23-000031:notes:246]

[0000858877-24-000003:notes:248]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-24-000003:notes:249]
Summarized financial information by segment for the second quarter and first six months of fiscal 2024 and 2023, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-24-000003:notes:250]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 7,510 |  |  | $ | 7,825 |  |  | $ | 16,532 |  |  | $ | 15,738 |  |
| EMEA | 3,484 |  |  | 3,728 |  |  | 7,148 |  |  | 7,404 |  |
| APJC | 1,798 |  |  | 2,039 |  |  | 3,779 |  |  | 4,082 |  |
| Total | $ | 12,791 |  |  | $ | 13,592 |  |  | $ | 27,459 |  |  | $ | 27,224 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,932 |  |  | $ | 4,920 |  |  | $ | 10,901 |  |  | $ | 9,904 |  |
| EMEA | 2,373 |  |  | 2,469 |  |  | 4,919 |  |  | 4,795 |  |
| APJC | 1,226 |  |  | 1,298 |  |  | 2,554 |  |  | 2,571 |  |
| Segment total | 8,532 |  |  | 8,687 |  |  | 18,373 |  |  | 17,269 |  |
| Unallocated corporate items | (315) |  |  | (260) |  |  | (599) |  |  | (496) |  |
| Total | $ | 8,217 |  |  | $ | 8,427 |  |  | $ | 17,774 |  |  | $ | 16,773 |  |

[0000858877-24-000003:notes:251]
Revenue in the United States was $6.7 billion and $7.0 billion for the second quarter of fiscal 2024 and 2023, respectively and $14.9 billion and $14.0 billion for the first six months of fiscal 2024 and 2023, respectively.

[0000858877-24-000003:notes:252]
[same as prior period, unchanged from 0000858877-23-000031:notes:251]

[0000858877-24-000003:notes:253]
[same as prior period, unchanged from 0000858877-23-000031:notes:252]


## us-gaap:EarningsPerShareTextBlock

[0000858877-24-000003:notes:254]
[same as prior period, unchanged from 0000858877-23-000031:notes:253]

[0000858877-24-000003:notes:255]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Net income | $ | 2,634 |  |  | $ | 2,773 |  |  | $ | 6,272 |  |  | $ | 5,443 |  |
| Weighted-average shares—basic | 4,055 |  |  | 4,103 |  |  | 4,056 |  |  | 4,105 |  |
| Effect of dilutive potential common shares | 18 |  |  | 13 |  |  | 23 |  |  | 10 |  |
| Weighted-average shares—diluted | 4,073 |  |  | 4,116 |  |  | 4,079 |  |  | 4,115 |  |
| Net income per share—basic | $ | 0.65 |  |  | $ | 0.68 |  |  | $ | 1.55 |  |  | $ | 1.33 |  |
| Net income per share—diluted | $ | 0.65 |  |  | $ | 0.67 |  |  | $ | 1.54 |  |  | $ | 1.32 |  |
| Antidilutive employee share-based awards, excluded | 58 |  |  | 17 |  |  | 56 |  |  | 91 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000858877-24-000003:notes:256]
On December 5, 2023, Deborah L. Stahlkopf, Cisco’s Executive Vice President and Chief Legal Officer, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Ms. Stahlkopf’s trading plan provides for the sale of 174,717 gross shares (with any shares underlying performance-based equity awards being calculated at target), plus any related dividend-equivalent shares earned with respect to such shares and excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Ms. Stahlkopf’s trading plan is scheduled to terminate on December 20, 2024, subject to early termination for certain specified events set forth therein.
