# CSCO notes — 0000858877-21-000013


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000858877-21-000013:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to the 2021 Annual Meeting of Stockholders, to be held on December 13, 2021, are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-21-000013:notes:2]
Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2021 was a 53-week fiscal year, and each of fiscal 2020 and fiscal 2019 were 52-week fiscal years. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-21-000013:notes:3]
At our annual meeting of shareholders held on December 10, 2020, shareholders voted to approve changing our state of incorporation from California to Delaware. The reincorporation became effective January 25, 2021.

[0000858877-21-000013:notes:4]
Our consolidated financial statements include our accounts and entities consolidated under the variable interest and voting models. The noncontrolling interests attributed to these investments, if any, are presented as a separate component from our equity in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-21-000013:notes:5]
Certain reclassifications have been made to the amounts for prior years in order to conform to the current year’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-21-000013:notes:6]
Summary of Significant Accounting Policies
(a) Cash and Cash Equivalents   We consider all highly liquid investments purchased with an original or remaining maturity of three months or less at the date of purchase to be cash equivalents. Cash and cash equivalents are maintained with various financial institutions.

[0000858877-21-000013:notes:7]
(b) Available-for-Sale Debt Investments   We classify our investments in fixed income securities as available-for-sale debt investments. Our available-for-sale debt investments primarily consist of U.S. government, U.S. government agency, corporate debt, and U.S. agency mortgage-backed securities. These available-for-sale debt investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of available-for-sale debt investments sold. These investments are recorded in the Consolidated Balance Sheets at fair value. Unrealized gains and losses on these investments are included as a separate component of accumulated other comprehensive income (AOCI), net of tax. We classify our investments as current based on the nature of the investments and their availability for use in current operations.

[0000858877-21-000013:notes:8]
(c) Equity Instruments   Our equity investments are accounted for as follows:

[0000858877-21-000013:notes:9]
•Marketable equity securities have readily determinable fair value (RDFV) that are measured and recorded at fair value through income.

[0000858877-21-000013:notes:10]
•Non-marketable equity securities do not have RDFV and are measured using a measurement alternative recorded at cost less any impairment, plus or minus changes resulting from qualifying observable price changes. For certain of these securities, we have elected to apply the net asset value (NAV) practical expedient. The NAV is the estimated fair value of these investments.

[0000858877-21-000013:notes:11]
•Equity method investments are securities we do not control, but are able to exert significant influence over the investee. These investments are measured at cost less any impairment, plus or minus our share of equity method investee income or loss.

[0000858877-21-000013:notes:12]
(d) Impairments of Investments   For our available-for-sale debt securities in an unrealized loss position, we determine whether a credit loss exists. In this assessment, among other factors, we consider the extent to which the fair value is less than the amortized cost, any changes to the rating of the security by a rating agency, and adverse conditions specifically related to the security. If factors indicate a credit loss exists, an allowance for credit loss is recorded to other income (loss), net, limited by the amount that the fair value is less than the amortized cost basis. The amount of fair value change relating to all other factors will be recognized in other comprehensive income (OCI).

[0000858877-21-000013:notes:13]
We hold non-marketable equity and other investments (“privately held investments”) which are included in other assets in the Consolidated Balance Sheets. We monitor these investments for impairments and make reductions in carrying values if we determine that an impairment charge is required based primarily on the financial condition and near-term prospects of these companies.

[0000858877-21-000013:notes:14]
(e) Inventories   Inventories are stated at the lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. We provide inventory write-downs based on excess and obsolete inventories determined primarily by future demand forecasts. The write-down is measured as the difference between the cost of the inventory and market based upon assumptions about future demand and charged to the provision for inventory, which is a component of cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In addition, we record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0000858877-21-000013:notes:15]
(f) Allowance for Accounts Receivable, Contract Assets and Financing Receivables   We estimate our allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, we determine collectibility by pooling our assets with similar characteristics.

[0000858877-21-000013:notes:16]
The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. Our internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality. Our assets within each internal credit risk rating share similar risk characteristics and therefore are assessed as one portfolio segment for credit loss. Assets that do not share risk characteristics are evaluated on an individual basis. The allowances for credit losses are each measured by multiplying the exposure probability of default, the probability the asset will default within a given time frame, by the loss given default rate, the percentage of the asset not expected to be collected due to default, based on the pool of assets.

[0000858877-21-000013:notes:17]
Probability of default rates are published quarterly by third-party credit agencies. Adjustments to our internal credit risk ratings may take into account including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000858877-21-000013:notes:18]
(g) Financing Receivables and Guarantees   We provide financing arrangements, including leases, financed service contracts, and loans, for certain qualified end-user customers to build, maintain, and upgrade their networks. Lease receivables primarily represent sales-type and direct-financing leases. Leases have on average a four-year term and are usually collateralized by a security interest in the underlying assets. Loan receivables include customers financing purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. Loan receivables have terms of three years on average. Financed service contracts typically have terms of one year to three years and primarily relate to technical support services.

[0000858877-21-000013:notes:19]
Outstanding financing receivables that are aged 31 days or more from the contractual payment date are considered past due. We do not accrue interest on financing receivables that are considered impaired or more than 120 days past due unless either the receivable has not been collected due to administrative reasons or the receivable is well secured and in the process of collection. Financing receivables may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain. After a financing receivable has been categorized as nonaccrual, interest will be recognized when cash is received. A financing receivable may be returned to accrual status after all of the customer’s delinquent balances of principal and interest have been settled, and the customer remains current for an appropriate period.

[0000858877-21-000013:notes:20]
We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive a payment for the receivables from the third party based on our standard payment terms. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Deferred revenue relating to these financing arrangements is recorded in accordance with revenue recognition policies or for the fair value of the financing guarantees.

[0000858877-21-000013:notes:21]
(h) Leases   We lease real estate, information technology (IT) and other equipment and vehicles. We also have arrangements with certain suppliers and contract manufacturers which includes the leasing of dedicated space and equipment costs. Our leases have the option to extend or terminate the lease when it is reasonably certain that we will exercise that option.

[0000858877-21-000013:notes:22]
As a lessee, we determine if an arrangement is a lease at commencement. Our ROU lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments related to the lease. Operating lease ROU assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. We use incremental borrowing rates based on information available at the commencement date to determine the present value of our lease payments. Certain of our lease agreements contain variable lease payments. Our variable lease payments can fluctuate depending on the level of activity or the cost of certain services where we have elected to combine lease and non-lease components. While these payments are not included as part of our lease liabilities, they are recognized as variable lease expense in the period they are incurred.

[0000858877-21-000013:notes:23]
We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. As a lessor, we determine if an arrangement is a lease at inception. We provide leasing arrangements for our equipment to certain qualified customers. Our lease portfolio primarily consists of sales-type leases. We allocate the consideration in a bundled contract with our customers based on relative standalone selling prices of our lease and non-lease components. The residual value on our leased equipment is determined at the inception of the lease based on an analysis of estimates of the value of equipment, market factors and historical customer behavior. Residual value estimates are reviewed on a periodic basis and other-than-temporary declines are expensed in the period they occur. Our leases generally provide an end-of-term option for the customer to extend the lease under mutually-agreed terms, return the leased equipment, or purchase the equipment for either the then-market value of the equipment or a pre-determined purchase price. If a customer chooses to terminate their lease prior to the original end of term date, the customer is required to pay all remaining lease payments in full.

[0000858877-21-000013:notes:24]
We adopted Accounting Standards Codification (ASC) 842 at the beginning of fiscal 2020 and applied it at the beginning of the period of adoption and did not restate prior periods. For additional information, see Note 8.

[0000858877-21-000013:notes:25]
(i) Depreciation and Amortization   Property and equipment are stated at cost, less accumulated depreciation or amortization, whenever applicable. Depreciation and amortization expenses for property and equipment were approximately $0.8 billion, $0.9 billion, and $1.0 billion for fiscal 2021, 2020, and 2019, respectively. Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-21-000013:notes:26]
| Asset Category |  | Period |
| Buildings |  | 25 years |
| Building improvements |  | 10 years |
| Leasehold improvements |  | Shorter of remaining lease term or up to 10 years |
| Computer equipment and related software |  | 30 to 36 months |
| Production, engineering, and other equipment |  | Up to 5 years |
| Operating lease assets |  | Based on lease term |
| Furniture and fixtures |  | 5 years |

[0000858877-21-000013:notes:27]
(j) Business Combinations We allocate the fair value of the purchase consideration of our acquisitions to the tangible assets, liabilities, and intangible assets acquired, including in-process research and development (IPR&D), based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life. Acquisition-related expenses and related restructuring costs are recognized separately from the business combination and are expensed as incurred.

[0000858877-21-000013:notes:28]
(k) Goodwill and Purchased Intangible Assets   Goodwill is tested for impairment on an annual basis in the fourth fiscal quarter and, when specific circumstances dictate, between annual tests. When impaired, the carrying value of goodwill is written down to fair value. Identifying a potential impairment consists of comparing the fair value of a reporting unit with its carrying amount, including goodwill. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. See “Long-Lived Assets” for our policy regarding impairment testing of purchased intangible assets with finite lives. Purchased intangible assets with indefinite lives are assessed for potential impairment annually or when events or circumstances indicate that their carrying amounts might be impaired.

[0000858877-21-000013:notes:29]
(l) Long-Lived Assets   Long-lived assets that are held and used by us are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability of long-lived assets is based on an estimate of the undiscounted future cash flows resulting from the use of the asset and its eventual disposition. Measurement of an impairment loss for long-lived assets that management expects to hold and use is

[0000858877-21-000013:notes:30]
based on the difference between the fair value of the asset and its carrying value. Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0000858877-21-000013:notes:31]
(m) Fair Value   Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, we consider the principal or most advantageous market in which we would transact, and we also consider assumptions that market participants would use when pricing the asset or liability.

[0000858877-21-000013:notes:32]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. The standard establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement.

[0000858877-21-000013:notes:33]
The fair value hierarchy is as follows:

[0000858877-21-000013:notes:34]
Level 1 applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000858877-21-000013:notes:35]
Level 2 applies to assets or liabilities for which there are inputs other than quoted prices that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets); or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of assets or liabilities.

[0000858877-21-000013:notes:36]
Level 3 applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities. The fair values are determined based on model-based techniques such as discounted cash flow models using inputs that we could not corroborate with market data.

[0000858877-21-000013:notes:37]
(n) Derivative Instruments   We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.

[0000858877-21-000013:notes:38]
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.

[0000858877-21-000013:notes:39]
(o) Foreign Currency Translation   Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated to U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of AOCI. Income and expense accounts are translated at average exchange rates during the year. Remeasurement adjustments are recorded in other income (loss), net. The effect of foreign currency exchange rates on cash and cash equivalents was not material for any of the fiscal years presented.

[0000858877-21-000013:notes:40]
(p) Concentrations of Risk   Cash and cash equivalents are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. We seek to mitigate our credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties.

[0000858877-21-000013:notes:41]
We perform ongoing credit evaluations of our customers and, with the exception of certain financing transactions, do not require collateral from our customers. We receive certain of our components from sole suppliers. Additionally, we rely on a limited number of contract manufacturers and suppliers to provide manufacturing services for our products. The inability of a contract manufacturer or supplier to fulfill our supply requirements could materially impact future operating results.

[0000858877-21-000013:notes:42]
(q) Revenue Recognition   We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

[0000858877-21-000013:notes:43]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-21-000013:notes:44]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of July 31, 2021 and July 25, 2020 was $55 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-21-000013:notes:45]
Significant Judgments

[0000858877-21-000013:notes:46]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-21-000013:notes:47]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

[0000858877-21-000013:notes:48]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license's utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

[0000858877-21-000013:notes:49]
We adopted ASC 606 at the beginning of fiscal 2019 using the modified retrospective method to those contracts that were not completed as of July 28, 2018. For the additional information, see Note 3.

[0000858877-21-000013:notes:50]
(r) Advertising Costs   We expense all advertising costs as incurred. Advertising costs included within sales and marketing expenses were approximately $268 million, $187 million, and $204 million for fiscal 2021, 2020, and 2019, respectively.

[0000858877-21-000013:notes:51]
(s) Share-Based Compensation Expense   We measure and recognize the compensation expense for all share-based awards made to employees and directors, including employee stock options, restricted stock units (RSUs), performance-based restricted stock units (PRSUs), and employee stock purchases related to the Employee Stock Purchase Plan (Employee Stock Purchase Rights) based on estimated fair values. The fair value of employee stock options is estimated on the date of grant using a lattice-binomial option-pricing model (Lattice-Binomial Model) or the Black-Scholes model, and for employee stock purchase rights we estimate the fair value using the Black-Scholes model. The fair value for time-based stock awards and stock awards that are contingent upon the achievement of financial performance metrics is based on the grant date share price reduced by the present value of the expected dividend yield prior to vesting. The fair value of market-based stock awards is estimated using an option-pricing model on the date of grant. Share-based compensation expense is reduced for forfeitures.

[0000858877-21-000013:notes:52]
(t) Software Development Costs   Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.

[0000858877-21-000013:notes:53]
(u) Income Taxes   Income tax expense is based on pretax financial accounting income. Deferred tax assets and liabilities are recognized for the expected tax consequences of temporary differences between the tax bases of assets and liabilities and their reported amounts. Valuation allowances are recorded to reduce deferred tax assets to the amount that will more likely than not be realized.

[0000858877-21-000013:notes:54]
We account for uncertainty in income taxes using a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. We classify the liability for unrecognized tax benefits as current to the extent that we anticipate payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.

[0000858877-21-000013:notes:55]
(v) Computation of Net Income per Share   Basic net income per share is computed using the weighted-average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted-average number of common shares and dilutive potential common shares outstanding during the period. Diluted shares outstanding includes the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares.

[0000858877-21-000013:notes:56]
(w) Consolidation of Variable Interest Entities  Our approach in assessing the consolidation requirement for variable interest entities focuses on identifying which enterprise has the power to direct the activities that most significantly impact the variable interest entity’s economic performance and which enterprise has the obligation to absorb losses or the right to receive benefits from the variable interest entity. Should we conclude that we are the primary beneficiary of a variable interest entity, the assets, liabilities, and results of operations of the variable interest entity will be included in our Consolidated Financial Statements.

[0000858877-21-000013:notes:57]
(x) Use of Estimates   The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Estimates are used for the following, among others:

[0000858877-21-000013:notes:58]
▪Revenue recognition

[0000858877-21-000013:notes:59]
▪Allowances for accounts receivable, sales returns, and financing receivables

[0000858877-21-000013:notes:60]
▪Inventory valuation and liability for purchase commitments with contract manufacturers and suppliers

[0000858877-21-000013:notes:61]
▪Loss contingencies and product warranties

[0000858877-21-000013:notes:62]
▪Fair value measurements

[0000858877-21-000013:notes:63]
▪Goodwill and purchased intangible asset impairments

[0000858877-21-000013:notes:64]
▪Income taxes

[0000858877-21-000013:notes:65]
The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The actual results experienced by us may differ materially from our estimates. As the COVID-19 pandemic continues, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-21-000013:notes:66]
(y) New Accounting Updates Recently Adopted

[0000858877-21-000013:notes:67]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. We adopted this standard at the beginning of our first quarter of fiscal 2021, applied it at the beginning of the period of adoption and did not restate prior periods. The standard primarily impacts our financial assets measured at amortized cost and available-for-sale debt securities. The standard did not have a material impact on our consolidated financial statements upon adoption.

[0000858877-21-000013:notes:68]
(z) Recent Accounting Standards or Updates Not Yet Effective as of Fiscal Year End

[0000858877-21-000013:notes:69]
Reference Rate Reform  In March 2020, the FASB issued an accounting standard update and subsequent amendments that provide optional expedients and exceptions to the current guidance on contract modification and hedging relationships to ease the financial reporting burden of the expected market transition from the London InterBank Offered Rate (LIBOR) and other interbank offered rates to alternative reference rates. This accounting standard update was effective upon issuance and may be applied prospectively through December 31, 2022. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-21-000013:notes:70]
Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-21-000013:notes:71]
Property and Equipment, Net

[0000858877-21-000013:notes:72]
|  |  | July 31, 2021 |  | July 25, 2020 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,304 |  |  | $ | 4,252 |  |
| Computer equipment and related software |  | 858 |  |  | 875 |  |
| Production, engineering, and other equipment |  | 5,106 |  |  | 5,163 |  |
| Operating lease assets |  | 273 |  |  | 337 |  |
| Furniture, fixtures and other |  | 377 |  |  | 387 |  |
| Total gross property and equipment |  | 10,918 |  |  | 11,014 |  |
| Less: accumulated depreciation and amortization |  | (8,580) |  |  | (8,561) |  |
| Total |  | $ | 2,338 |  |  | $ | 2,453 |  |


## us-gaap:DerivativesPolicyTextBlock

[0000858877-21-000013:notes:73]
(n) Derivative Instruments   We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We do, however, seek to mitigate such risks by limiting our counterparties to major financial institutions and requiring collateral in certain cases. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000858877-21-000013:notes:74]
(v) Computation of Net Income per Share   Basic net income per share is computed using the weighted-average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted-average number of common shares and dilutive potential common shares outstanding during the period. Diluted shares outstanding includes the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares.Employee equity share options, unvested shares, and similar equity instruments granted and assumed by us are treated as potential common shares outstanding in computing diluted earnings per share. Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that has not yet been recognized are collectively assumed to be used to repurchase shares.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-21-000013:notes:75]
Revenue
(a)Disaggregation of Revenue

[0000858877-21-000013:notes:76]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category.

[0000858877-21-000013:notes:77]
The following table presents this disaggregation of revenue (in millions):

[0000858877-21-000013:notes:78]
| Years Ended | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Revenue: |  |  |  |  |  |
| Infrastructure Platforms | $ | 27,109 |  |  | $ | 27,219 |  |  | $ | 30,184 |  |
| Applications | 5,504 |  |  | 5,568 |  |  | 5,803 |  |
| Security | 3,382 |  |  | 3,158 |  |  | 2,822 |  |
| Other Products | 19 |  |  | 33 |  |  | 196 |  |
| Total Product | 36,014 |  |  | 35,978 |  |  | 39,005 |  |
| Services | 13,804 |  |  | 13,323 |  |  | 12,899 |  |
| Total (1) | $ | 49,818 |  |  | $ | 49,301 |  |  | $ | 51,904 |  |

[0000858877-21-000013:notes:79]
Amounts may not sum due to rounding. We have made certain reclassifications to the product revenue amounts for prior years to conform to the current year’s presentation.

[0000858877-21-000013:notes:80]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (SPVSS) business. Total revenue includes SPVSS business revenue of $168 million for fiscal 2019.

[0000858877-21-000013:notes:81]
Infrastructure Platforms consist of our core networking technologies of switching, routing, wireless, and data center products that are designed to work together to deliver networking capabilities and transport and/or store data. These technologies consist of both hardware and software offerings, including software licenses and software-as-a-service (SaaS), that help our customers build networks, automate, orchestrate, integrate, and digitize data. We are shifting and expanding more of our business to software and subscriptions across our core networking portfolio. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-21-000013:notes:82]
Applications consists of offerings that utilize the core networking and data center platforms to provide their functions. The products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-21-000013:notes:83]
Security primarily includes our network security, cloud and email security, identity and access management, advanced threat protection, and unified threat management products. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers' network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-21-000013:notes:84]
Other Products primarily includes our emerging technologies products. These products include both hardware and software licenses. Our offerings in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control.

[0000858877-21-000013:notes:85]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and advanced services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Advanced services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

[0000858877-21-000013:notes:86]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for all of our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.

[0000858877-21-000013:notes:87]
(b)Contract Balances

[0000858877-21-000013:notes:88]
Accounts receivable, net was $5.8 billion as of July 31, 2021 compared to $5.5 billion as of July 25, 2020, as reported on the Consolidated Balance Sheets.

[0000858877-21-000013:notes:89]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of July 31, 2021 and July 25, 2020, our contract assets for these unbilled receivables, net of allowances, were $1.4 billion and $1.2 billion, respectively, and were included in other current assets and other assets.

[0000858877-21-000013:notes:90]
Gross contract assets by our internal risk ratings are summarized as follows (in millions):

[0000858877-21-000013:notes:91]
|  | July 31, 2021 |
| 1 to 4 | $ | 521 |  |
| 5 to 6 | 770 |  |
| 7 and Higher | 166 |  |
| Total | $ | 1,457 |  |

[0000858877-21-000013:notes:92]
Contract liabilities consist of deferred revenue. Deferred revenue was $22.2 billion as of July 31, 2021 compared to $20.4 billion as of July 25, 2020. We recognized approximately $11.3 billion of revenue during fiscal 2021 that was included in the deferred revenue balance at July 25, 2020.

[0000858877-21-000013:notes:93]
(c)Capitalized Contract Acquisition Costs

[0000858877-21-000013:notes:94]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $967 million and $732 million as of July 31, 2021 and July 25, 2020, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $532 million and $477 million for fiscal 2021 and 2020, respectively, and was included in sales and marketing expenses.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-21-000013:notes:95]
The following table presents revenue for groups of similar products and services (in millions):

[0000858877-21-000013:notes:96]
(1) Includes SPVSS business revenue of $168 million for fiscal 2019.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-21-000013:notes:97]
Acquisitions and Divestitures 
(a)Acquisition Summary

[0000858877-21-000013:notes:98]
We completed 13 acquisitions during fiscal 2021. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-21-000013:notes:99]
| Fiscal 2021 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Acacia | $ | 4,983 |  |  | $ | 442 |  |  | $ | 2,160 |  |  | $ | 2,381 |  |
| Others | 2,472 |  |  | (130) |  |  | 754 |  |  | 1,848 |  |
| Total | $ | 7,455 |  |  | $ | 312 |  |  | $ | 2,914 |  |  | $ | 4,229 |  |

[0000858877-21-000013:notes:100]
On March 1, 2021, we completed our acquisition of Acacia Communications, Inc. (“Acacia”), a public fabless semiconductor company that develops, manufactures and sells high-speed coherent optical interconnect products that are designed to transform communications networks through improvements in performance, capacity and cost. Revenue from the Acacia acquisition has been included in our Infrastructure Platforms product category.

[0000858877-21-000013:notes:101]
The total purchase consideration related to our acquisitions completed during fiscal 2021 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $338 million.

[0000858877-21-000013:notes:102]
Fiscal 2020 Acquisitions

[0000858877-21-000013:notes:103]
Allocation of the purchase consideration for acquisitions completed in fiscal 2020 is summarized as follows (in millions):

[0000858877-21-000013:notes:104]
| Fiscal 2020 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions (six in total) | $ | 359 |  |  | $ | (11) |  |  | $ | 172 |  |  | $ | 198 |  |

[0000858877-21-000013:notes:105]
The total purchase consideration related to our acquisitions completed during fiscal 2020 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $23 million.

[0000858877-21-000013:notes:106]
Fiscal 2019 Acquisitions

[0000858877-21-000013:notes:107]
In fiscal 2019, we completed five acquisitions for total purchase consideration of $2.7 billion.

[0000858877-21-000013:notes:108]
(b)   Other Acquisition and Divestiture Information

[0000858877-21-000013:notes:109]
Total transaction costs related to our acquisition and divestiture activities during fiscal 2021, 2020, and 2019 were $46 million, $21 million, and $21 million, respectively. These transaction costs were expensed as incurred in G&A expenses in the Consolidated Statements of Operations.

[0000858877-21-000013:notes:110]
The goodwill generated from our acquisitions completed during fiscal 2021 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-21-000013:notes:111]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during fiscal 2021, 2020, and 2019 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0000858877-21-000013:notes:112]
A summary of the allocation of the total purchase consideration is presented as follows (in millions):


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-21-000013:notes:113]
Goodwill and Purchased Intangible Assets 
(a)Goodwill

[0000858877-21-000013:notes:114]
The following tables present the goodwill allocated to our reportable segments as of July 31, 2021 and July 25, 2020, as well as the changes to goodwill during fiscal 2021 and 2020 (in millions):

[0000858877-21-000013:notes:115]
|  | Balance at July 25, 2020 |  | Acquisitions & Divestitures |  | Foreign Currency Translation and Other |  | Balance at July 31, 2021 |
| Americas | $ | 21,304 |  |  | $ | 2,275 |  |  | $ | 94 |  |  | $ | 23,673 |  |
| EMEA | 8,040 |  |  | 1,019 |  |  | 35 |  |  | 9,094 |  |
| APJC | 4,462 |  |  | 920 |  |  | 19 |  |  | 5,401 |  |
| Total | $ | 33,806 |  |  | $ | 4,214 |  |  | $ | 148 |  |  | $ | 38,168 |  |

[0000858877-21-000013:notes:116]
|  | Balance at July 27, 2019 |  | Acquisitions |  | Foreign Currency Translation and Other |  | Balance at July 25, 2020 |
| Americas | $ | 21,120 |  |  | $ | 132 |  |  | $ | 52 |  |  | $ | 21,304 |  |
| EMEA | 7,977 |  |  | 44 |  |  | 19 |  |  | 8,040 |  |
| APJC | 4,432 |  |  | 22 |  |  | 8 |  |  | 4,462 |  |
| Total | $ | 33,529 |  |  | $ | 198 |  |  | $ | 79 |  |  | $ | 33,806 |  |

[0000858877-21-000013:notes:117]
(b)Purchased Intangible Assets

[0000858877-21-000013:notes:118]
The following tables present details of our intangible assets acquired through acquisitions completed during fiscal 2021 and 2020 (in millions, except years):

[0000858877-21-000013:notes:119]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2021 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Acacia | 4.0 |  | $ | 1,290 |  |  | 4.0 |  | $ | 490 |  |  | 3.1 |  | $ | 35 |  |  | $ | 345 |  |  | $ | 2,160 |  |
| Others | 4.3 |  | 545 |  |  | 4.6 |  | 174 |  |  | 2.9 |  | 35 |  |  | — |  |  | 754 |  |
| Total |  |  | $ | 1,835 |  |  |  |  | $ | 664 |  |  |  |  | $ | 70 |  |  | $ | 345 |  |  | $ | 2,914 |  |

[0000858877-21-000013:notes:120]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2020 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions (six in total) | 4.8 |  | $ | 161 |  |  | 4.2 |  | $ | 10 |  |  | 1.5 |  | $ | 1 |  |  | $ | — |  |  | $ | 172 |  |

[0000858877-21-000013:notes:121]
The following tables present details of our purchased intangible assets (in millions):

[0000858877-21-000013:notes:122]
| July 31, 2021 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,629 |  |  | $ | (1,437) |  |  | $ | 2,192 |  |
| Customer relationships |  | 1,387 |  |  | (523) |  |  | 864 |  |
| Other |  | 71 |  |  | (13) |  |  | 58 |  |
| Total purchased intangible assets with finite lives |  | 5,087 |  |  | (1,973) |  |  | 3,114 |  |
| In-process research and development, with indefinite lives |  | 505 |  |  | — |  |  | 505 |  |
| Total |  | $ | 5,592 |  |  | $ | (1,973) |  |  | $ | 3,619 |  |

[0000858877-21-000013:notes:123]
| July 25, 2020 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,298 |  |  | $ | (2,336) |  |  | $ | 962 |  |
| Customer relationships |  | 760 |  |  | (365) |  |  | 395 |  |
| Other |  | 26 |  |  | (20) |  |  | 6 |  |
| Total purchased intangible assets with finite lives |  | 4,084 |  |  | (2,721) |  |  | 1,363 |  |
| In-process research and development, with indefinite lives |  | 213 |  |  | — |  |  | 213 |  |
| Total |  | $ | 4,297 |  |  | $ | (2,721) |  |  | $ | 1,576 |  |

[0000858877-21-000013:notes:124]
Purchased intangible assets include intangible assets acquired through acquisitions as well as through direct purchases or licenses.

[0000858877-21-000013:notes:125]
The following table presents the amortization of purchased intangible assets, including impairment charges (in millions):

[0000858877-21-000013:notes:126]
| Years Ended |  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 716 |  |  | $ | 659 |  |  | $ | 624 |  |
| Operating expenses |  | 215 |  |  | 141 |  |  | 150 |  |
| Total |  | $ | 931 |  |  | $ | 800 |  |  | $ | 774 |  |

[0000858877-21-000013:notes:127]
The estimated future amortization expense of purchased intangible assets with finite lives as of July 31, 2021 is as follows (in millions):

[0000858877-21-000013:notes:128]
| Fiscal Year | Amount |
| 2022 | $ | 1,037 |  |
| 2023 | $ | 873 |  |
| 2024 | $ | 749 |  |
| 2025 | $ | 396 |  |
| 2026 | $ | 55 |  |
| Thereafter | $ | 4 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-21-000013:notes:129]
Restructuring and Other Charges
We initiated a restructuring plan during fiscal 2021 (the “Fiscal 2021 Plan”), which included a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas with estimated pretax charges of approximately $900 million. In connection with the Fiscal 2021 Plan, we incurred charges of $881 million during fiscal 2021. We substantially completed the Fiscal 2021 Plan in fiscal 2021 and do not expect any remaining charges related to this plan to be material.

[0000858877-21-000013:notes:130]
We initiated a restructuring plan during fiscal 2020 (the “Fiscal 2020 Plan”) in order to realign the organization and enable further investment in key priority areas, with estimated pretax charges of approximately $300 million. In connection with the Fiscal 2020 Plan, we incurred cumulative charges of $260 million. We completed the Fiscal 2020 Plan in fiscal 2021.

[0000858877-21-000013:notes:131]
In prior years, we initiated restructuring plans in order to realign our organization and enable further investment in key priority areas. The aggregate pretax charges related to these plans are primarily cash-based and consist of severance and other one-time termination benefits, and other costs.

[0000858877-21-000013:notes:132]
The following table summarizes the activities related to the restructuring and other charges, as discussed above (in millions):

[0000858877-21-000013:notes:133]
|  |  | FISCAL 2020 AND PRIOR PLANS |  | FISCAL 2021 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 28, 2018 |  | $ | 60 |  |  | $ | 13 |  |  | $ | — |  |  | $ | — |  |  | $ | 73 |  |
| Charges |  | 252 |  |  | 70 |  |  | — |  |  | — |  |  | 322 |  |
| Cash payments |  | (289) |  |  | (10) |  |  | — |  |  | — |  |  | (299) |  |
| Non-cash items |  | (1) |  |  | (62) |  |  | — |  |  | — |  |  | (63) |  |
| Liability as of July 27, 2019 |  | 22 |  |  | 11 |  |  | — |  |  | — |  |  | 33 |  |
| Charges |  | 353 |  |  | 128 |  |  | — |  |  | — |  |  | 481 |  |
| Cash payments |  | (317) |  |  | (10) |  |  | — |  |  | — |  |  | (327) |  |
| Non-cash items |  | — |  |  | (115) |  |  | — |  |  | — |  |  | (115) |  |
| Liability as of July 25, 2020 |  | 58 |  |  | 14 |  |  | — |  |  | — |  |  | 72 |  |
| Charges |  | — |  |  | 5 |  |  | 836 |  |  | 45 |  |  | 886 |  |
| Cash payments |  | (58) |  |  | (6) |  |  | (821) |  |  | (5) |  |  | (890) |  |
| Non-cash items |  | — |  |  | (3) |  |  | 1 |  |  | (32) |  |  | (34) |  |
| Liability as of July 31, 2021 |  | $ | — |  |  | $ | 10 |  |  | $ | 16 |  |  | $ | 8 |  |  | $ | 34 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-21-000013:notes:134]
Balance Sheet and Other Details 
The following tables provide details of selected balance sheet and other items (in millions):

[0000858877-21-000013:notes:135]
Cash, Cash Equivalents, and Restricted Cash

[0000858877-21-000013:notes:136]
|  |  | July 31, 2021 |  | July 25, 2020 |
| Cash and cash equivalents |  | $ | 9,175 |  |  | $ | 11,809 |  |
| Restricted cash included in other current assets |  | 14 |  |  | — |  |
| Restricted cash included in other assets |  | 753 |  |  | 3 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 9,942 |  |  | $ | 11,812 |  |

[0000858877-21-000013:notes:137]
Our restricted cash balances are funds primarily related to contractual obligations with suppliers.

[0000858877-21-000013:notes:138]
Inventories

[0000858877-21-000013:notes:139]
|  |  | July 31, 2021 |  | July 25, 2020 |
| Raw materials |  | $ | 801 |  |  | $ | 456 |  |
| Work in process |  | 54 |  |  | 25 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales |  | 97 |  |  | 59 |  |
| Manufactured finished goods |  | 422 |  |  | 542 |  |
| Total finished goods |  | 519 |  |  | 601 |  |
| Service-related spares |  | 174 |  |  | 184 |  |
| Demonstration systems |  | 11 |  |  | 16 |  |
| Total |  | $ | 1,559 |  |  | $ | 1,282 |  |

[0000858877-21-000013:notes:140]
Our provision for inventory was $116 million, $74 million, and $77 million in fiscal 2021, 2020, and 2019, respectively.

[0000858877-21-000013:notes:141]
Remaining Performance Obligations

[0000858877-21-000013:notes:142]
|  |  | July 31, 2021 |  | July 25, 2020 |
| Product |  | $ | 13,270 |  |  | $ | 11,261 |  |
| Service |  | 17,623 |  |  | 17,093 |  |
| Total |  | $ | 30,893 |  |  | $ | 28,354 |  |

[0000858877-21-000013:notes:143]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of July 31, 2021, the aggregate amount of RPO was comprised of $22.2 billion of deferred revenue and $8.7 billion of unbilled contract revenue. We expect approximately 53% of this amount to be recognized as revenue over the next 12 months. As of July 25, 2020, the aggregate amount of RPO was comprised of $20.4 billion of deferred revenue and $7.9 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

[0000858877-21-000013:notes:144]
Deferred Revenue

[0000858877-21-000013:notes:145]
|  |  | July 31, 2021 |  | July 25, 2020 |
| Product |  | $ | 9,416 |  |  | $ | 7,895 |  |
| Service |  | 12,748 |  |  | 12,551 |  |
| Total |  | $ | 22,164 |  |  | $ | 20,446 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 12,148 |  |  | $ | 11,406 |  |
| Noncurrent |  | 10,016 |  |  | 9,040 |  |
| Total |  | $ | 22,164 |  |  | $ | 20,446 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000858877-21-000013:notes:146]
Leases
(a)Lessee Arrangements

[0000858877-21-000013:notes:147]
The following table presents our operating lease balances (in millions):

[0000858877-21-000013:notes:148]
|  | Balance Sheet Line Item |  | July 31, 2021 |  | July 25, 2020 |
| Operating lease right-of-use assets | Other assets |  | $ | 1,095 |  |  | $ | 921 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 337 |  |  | $ | 341 |  |
| Operating lease liabilities | Other long-term liabilities |  | 831 |  |  | 661 |  |
| Total operating lease liabilities |  |  | $ | 1,168 |  |  | $ | 1,002 |  |

[0000858877-21-000013:notes:149]
The components of our lease expenses were as follows (in millions):

[0000858877-21-000013:notes:150]
| Years Ended |  | July 31, 2021 |  | July 25, 2020 |
| Operating lease expense |  | $ | 399 |  |  | $ | 428 |  |
| Short-term lease expense |  | 65 |  |  | 69 |  |
| Variable lease expense |  | 173 |  |  | 157 |  |
| Total lease expense |  | $ | 637 |  |  | $ | 654 |  |

[0000858877-21-000013:notes:151]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-21-000013:notes:152]
| Years Ended |  | July 31, 2021 |  | July 25, 2020 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows |  | $ | 407 |  |  | $ | 413 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities |  | $ | 536 |  |  | $ | 197 |  |

[0000858877-21-000013:notes:153]
The weighted-average lease term was 5.2 years and 4.0 years as of July 31, 2021 and July 25, 2020, respectively. The weighted-average discount rate was 1.7% and 1.5% as of July 31, 2021 and July 25, 2020, respectively.

[0000858877-21-000013:notes:154]
The maturities of our operating leases (undiscounted) as of July 31, 2021 are as follows (in millions):

[0000858877-21-000013:notes:155]
| Fiscal Year | Amount |
| 2022 | $ | 355 |  |
| 2023 | 279 |  |
| 2024 | 195 |  |
| 2025 | 127 |  |
| 2026 | 70 |  |
| Thereafter | 219 |  |
| Total lease payments | 1,245 |  |
| Less interest | (77) |  |
| Total | $ | 1,168 |  |

[0000858877-21-000013:notes:156]
(b)Lessor Arrangements

[0000858877-21-000013:notes:157]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income for fiscal 2021 and 2020 was $75 million and $94 million, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-21-000013:notes:158]
Future minimum lease payments on our lease receivables as of July 31, 2021 are summarized as follows (in millions):

[0000858877-21-000013:notes:159]
| Fiscal Year | Amount |
| 2022 | $ | 682 |  |
| 2023 | 556 |  |
| 2024 | 286 |  |
| 2025 | 144 |  |
| 2026 | 41 |  |
| Thereafter | 1 |  |
| Total | 1,710 |  |
| Less: Present value of lease payments | 1,632 |  |
| Unearned income | $ | 78 |  |

[0000858877-21-000013:notes:160]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-21-000013:notes:161]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-21-000013:notes:162]
|  | July 31, 2021 |  | July 25, 2020 |
| Operating lease assets | $ | 273 |  |  | $ | 337 |  |
| Accumulated depreciation | (165) |  |  | (198) |  |
| Operating lease assets, net | $ | 108 |  |  | $ | 139 |  |

[0000858877-21-000013:notes:163]
Our operating lease income for fiscal 2021 and 2020 was $151 million and $190 million, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-21-000013:notes:164]
Minimum future rentals on noncancelable operating leases as of July 31, 2021 are summarized as follows (in millions):

[0000858877-21-000013:notes:165]
| Fiscal Year | Amount |
| 2022 | $ | 49 |  |
| 2023 | 24 |  |
| 2024 | 6 |  |
| 2025 | 1 |  |
| Total | $ | 80 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-21-000013:notes:166]
Financing Receivables  
(a)Financing Receivables

[0000858877-21-000013:notes:167]
Financing receivables primarily consist of lease receivables, loan receivables, and financed service contracts. Lease receivables represent sales-type leases resulting from the sale of Cisco's and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services, which may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables have terms of three years on average. Financed service contracts include financing receivables related to technical support and advanced services. Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one year to three years.

[0000858877-21-000013:notes:168]
A summary of our financing receivables is presented as follows (in millions):

[0000858877-21-000013:notes:169]
| July 31, 2021 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 1,710 |  |  | $ | 5,203 |  |  | $ | 2,453 |  |  | $ | 9,366 |  |
| Residual value | 103 |  |  | — |  |  | — |  |  | 103 |  |
| Unearned income | (78) |  |  | — |  |  | — |  |  | (78) |  |
| Allowance for credit loss | (38) |  |  | (86) |  |  | (3) |  |  | (127) |  |
| Total, net | $ | 1,697 |  |  | $ | 5,117 |  |  | $ | 2,450 |  |  | $ | 9,264 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 780 |  |  | $ | 2,372 |  |  | $ | 1,228 |  |  | $ | 4,380 |  |
| Noncurrent | 917 |  |  | 2,745 |  |  | 1,222 |  |  | 4,884 |  |
| Total, net | $ | 1,697 |  |  | $ | 5,117 |  |  | $ | 2,450 |  |  | $ | 9,264 |  |

[0000858877-21-000013:notes:170]
| July 25, 2020 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,127 |  |  | $ | 5,937 |  |  | $ | 2,830 |  |  | $ | 10,894 |  |
| Residual value | 123 |  |  | — |  |  | — |  |  | 123 |  |
| Unearned income | (114) |  |  | — |  |  | — |  |  | (114) |  |
| Allowance for credit loss | (48) |  |  | (81) |  |  | (9) |  |  | (138) |  |
| Total, net | $ | 2,088 |  |  | $ | 5,856 |  |  | $ | 2,821 |  |  | $ | 10,765 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 918 |  |  | $ | 2,692 |  |  | $ | 1,441 |  |  | $ | 5,051 |  |
| Noncurrent | 1,170 |  |  | 3,164 |  |  | 1,380 |  |  | 5,714 |  |
| Total, net | $ | 2,088 |  |  | $ | 5,856 |  |  | $ | 2,821 |  |  | $ | 10,765 |  |

[0000858877-21-000013:notes:171]
(b)Credit Quality of Financing Receivables

[0000858877-21-000013:notes:172]
Gross financing receivables(1) categorized by our internal credit risk rating by period of origination as of July 31, 2021 are summarized as follows (in millions):

[0000858877-21-000013:notes:173]
|  |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 29, 2017 |  | July 28, 2018 |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | Total |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 20 |  |  | $ | 100 |  |  | $ | 168 |  |  | $ | 282 |  |  | $ | 227 |  |  | $ | 799 |  |
| 5 to 6 | 1 |  |  | 17 |  |  | 65 |  |  | 187 |  |  | 285 |  |  | 231 |  |  | 786 |  |
| 7 and Higher | — |  |  | 2 |  |  | 6 |  |  | 12 |  |  | 23 |  |  | 4 |  |  | 47 |  |
| Total Lease Receivables | $ | 3 |  |  | $ | 39 |  |  | $ | 171 |  |  | $ | 367 |  |  | $ | 590 |  |  | $ | 462 |  |  | $ | 1,632 |  |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 4 |  |  | $ | 86 |  |  | $ | 134 |  |  | $ | 577 |  |  | $ | 990 |  |  | $ | 1,552 |  |  | $ | 3,343 |  |
| 5 to 6 | — |  |  | 19 |  |  | 75 |  |  | 202 |  |  | 505 |  |  | 925 |  |  | 1,726 |  |
| 7 and Higher | 1 |  |  | 2 |  |  | 4 |  |  | 50 |  |  | 43 |  |  | 34 |  |  | 134 |  |
| Total Loan Receivables | $ | 5 |  |  | $ | 107 |  |  | $ | 213 |  |  | $ | 829 |  |  | $ | 1,538 |  |  | $ | 2,511 |  |  | $ | 5,203 |  |
| Financed Service Contracts: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | — |  |  | $ | 38 |  |  | $ | 26 |  |  | $ | 106 |  |  | $ | 252 |  |  | $ | 1,053 |  |  | $ | 1,475 |  |
| 5 to 6 | — |  |  | 6 |  |  | 26 |  |  | 105 |  |  | 302 |  |  | 520 |  |  | 959 |  |
| 7 and Higher | — |  |  | — |  |  | 1 |  |  | 6 |  |  | 7 |  |  | 5 |  |  | 19 |  |
| Total Financed Service Contracts | $ | — |  |  | $ | 44 |  |  | $ | 53 |  |  | $ | 217 |  |  | $ | 561 |  |  | $ | 1,578 |  |  | $ | 2,453 |  |
| Total | $ | 8 |  |  | $ | 190 |  |  | $ | 437 |  |  | $ | 1,413 |  |  | $ | 2,689 |  |  | $ | 4,551 |  |  | $ | 9,288 |  |

[0000858877-21-000013:notes:174]
(1) Lease receivables calculated as gross lease receivables, excluding residual value, less unearned income.

[0000858877-21-000013:notes:175]
The following table summarizes our gross receivables categorized by our internal credit risk rating as of July 25, 2020 and was not restated to reflect the impact of adoption of the accounting standards update on Credit Losses on Financial Instruments:

[0000858877-21-000013:notes:176]
|  | INTERNAL CREDIT RISK RATING |
| July 25, 2020 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 992 |  |  | $ | 952 |  |  | $ | 69 |  |  | $ | 2,013 |  |
| Loan receivables | 3,808 |  |  | 1,961 |  |  | 168 |  |  | 5,937 |  |
| Financed service contracts | 1,645 |  |  | 1,153 |  |  | 32 |  |  | 2,830 |  |
| Total | $ | 6,445 |  |  | $ | 4,066 |  |  | $ | 269 |  |  | $ | 10,780 |  |

[0000858877-21-000013:notes:177]
The following tables present the aging analysis of gross receivables as of July 31, 2021 and July 25, 2020 (in millions):

[0000858877-21-000013:notes:178]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| July 31, 2021 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 21 |  |  | $ | 17 |  |  | $ | 29 |  |  | $ | 67 |  |  | $ | 1,565 |  |  | $ | 1,632 |  |  | $ | 1 |  |  | $ | 33 |  |  | $ | 26 |  |
| Loan receivables | 71 |  |  | 17 |  |  | 35 |  |  | 123 |  |  | 5,080 |  |  | 5,203 |  |  | 4 |  |  | 33 |  |  | 33 |  |
| Financed service contracts | 18 |  |  | 13 |  |  | 18 |  |  | 49 |  |  | 2,404 |  |  | 2,453 |  |  | 3 |  |  | 3 |  |  | 3 |  |
| Total | $ | 110 |  |  | $ | 47 |  |  | $ | 82 |  |  | $ | 239 |  |  | $ | 9,049 |  |  | $ | 9,288 |  |  | $ | 8 |  |  | $ | 69 |  |  | $ | 62 |  |

[0000858877-21-000013:notes:179]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 25, 2020 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 29 |  |  | $ | 47 |  |  | $ | 48 |  |  | $ | 124 |  |  | $ | 1,889 |  |  | $ | 2,013 |  |  | $ | 43 |  |  | $ | 43 |  |
| Loan receivables | 129 |  |  | 78 |  |  | 78 |  |  | 285 |  |  | 5,652 |  |  | 5,937 |  |  | 65 |  |  | 65 |  |
| Financed service contracts | 69 |  |  | 75 |  |  | 124 |  |  | 268 |  |  | 2,562 |  |  | 2,830 |  |  | 4 |  |  | 4 |  |
| Total | $ | 227 |  |  | $ | 200 |  |  | $ | 250 |  |  | $ | 677 |  |  | $ | 10,103 |  |  | $ | 10,780 |  |  | $ | 112 |  |  | $ | 112 |  |

[0000858877-21-000013:notes:180]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract.

[0000858877-21-000013:notes:181]
As of July 25, 2020, we had financing receivables of $67 million, net of unbilled or current receivables, that were greater than 120 days plus past due but remained on accrual status as they are well secured and in the process of collection.

[0000858877-21-000013:notes:182]
(c)Allowance for Credit Loss Rollforward

[0000858877-21-000013:notes:183]
The allowances for credit loss and the related financing receivables are summarized as follows (in millions):

[0000858877-21-000013:notes:184]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 25, 2020 | $ | 48 |  |  | $ | 81 |  |  | $ | 9 |  |  | $ | 138 |  |
| Provisions (benefits) | (10) |  |  | (12) |  |  | (5) |  |  | (27) |  |
| Recoveries (write-offs), net | (1) |  |  | (1) |  |  | — |  |  | (2) |  |
| Foreign exchange and other | 1 |  |  | 18 |  |  | (1) |  |  | 18 |  |
| Allowance for credit loss as of July 31, 2021 | $ | 38 |  |  | $ | 86 |  |  | $ | 3 |  |  | $ | 127 |  |

[0000858877-21-000013:notes:185]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 27, 2019 | $ | 46 |  |  | $ | 71 |  |  | $ | 9 |  |  | $ | 126 |  |
| Provisions (benefits) | 5 |  |  | 32 |  |  | 1 |  |  | 38 |  |
| Recoveries (write-offs), net | (3) |  |  | (19) |  |  | — |  |  | (22) |  |
| Foreign exchange and other | — |  |  | (3) |  |  | (1) |  |  | (4) |  |
| Allowance for credit loss as of July 25, 2020 | $ | 48 |  |  | $ | 81 |  |  | $ | 9 |  |  | $ | 138 |  |

[0000858877-21-000013:notes:186]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 28, 2018 | $ | 135 |  |  | $ | 60 |  |  | $ | 10 |  |  | $ | 205 |  |
| Provisions (benefits) | (54) |  |  | 11 |  |  | 27 |  |  | (16) |  |
| Recoveries (write-offs), net | (14) |  |  | — |  |  | (28) |  |  | (42) |  |
| Foreign exchange and other | (21) |  |  | — |  |  | — |  |  | (21) |  |
| Allowance for credit loss as of July 27, 2019 | $ | 46 |  |  | $ | 71 |  |  | $ | 9 |  |  | $ | 126 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-21-000013:notes:187]
Available-for-Sale Debt and Equity Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-21-000013:notes:188]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-21-000013:notes:189]
| July 31, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,773 |  |  | $ | 21 |  |  | $ | — |  |  | $ | 1,794 |  |
| U.S. government agency securities | 152 |  |  | — |  |  | — |  |  | 152 |  |
| Non-U.S. government and agency securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Corporate debt securities | 8,727 |  |  | 213 |  |  | (30) |  |  | 8,910 |  |
| U.S. agency mortgage-backed securities | 2,838 |  |  | 34 |  |  | (10) |  |  | 2,862 |  |
| Commercial paper | 1,190 |  |  | — |  |  | — |  |  | 1,190 |  |
| Certificates of deposit | 295 |  |  | — |  |  | — |  |  | 295 |  |
| Total | $ | 14,978 |  |  | $ | 268 |  |  | $ | (40) |  |  | $ | 15,206 |  |

[0000858877-21-000013:notes:190]
| July 25, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 2,614 |  |  | $ | 71 |  |  | $ | — |  |  | $ | 2,685 |  |
| U.S. government agency securities | 110 |  |  | — |  |  | — |  |  | 110 |  |
| Corporate debt securities | 11,549 |  |  | 334 |  |  | (6) |  |  | 11,877 |  |
| U.S. agency mortgage-backed securities | 1,987 |  |  | 49 |  |  | (1) |  |  | 2,035 |  |
| Commercial paper | 727 |  |  | — |  |  | — |  |  | 727 |  |
| Certificates of deposit | 176 |  |  | — |  |  | — |  |  | 176 |  |
| Total | $ | 17,163 |  |  | $ | 454 |  |  | $ | (7) |  |  | $ | 17,610 |  |

[0000858877-21-000013:notes:191]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-21-000013:notes:192]
| Years Ended | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Gross realized gains | $ | 55 |  |  | $ | 70 |  |  | $ | 17 |  |
| Gross realized losses | (2) |  |  | (28) |  |  | (30) |  |
| Total | $ | 53 |  |  | $ | 42 |  |  | $ | (13) |  |

[0000858877-21-000013:notes:193]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at July 31, 2021 and July 25, 2020 (in millions):

[0000858877-21-000013:notes:194]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 31, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 468 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 468 |  |  | $ | — |  |
| U.S. government agency securities | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |
| Corporate debt securities | 1,086 |  |  | (5) |  |  | 6 |  |  | — |  |  | 1,092 |  |  | (5) |  |
| U.S. agency mortgage-backed securities | 1,293 |  |  | (10) |  |  | 13 |  |  | — |  |  | 1,306 |  |  | (10) |  |
| Commercial paper | 37 |  |  | — |  |  | — |  |  | — |  |  | 37 |  |  | — |  |
| Total | $ | 2,910 |  |  | $ | (15) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 2,929 |  |  | $ | (15) |  |

[0000858877-21-000013:notes:195]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 25, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government agency securities | $ | 33 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 33 |  |  | $ | — |  |
| Corporate debt securities | 1,060 |  |  | (6) |  |  | 3 |  |  | — |  |  | 1,063 |  |  | (6) |  |
| U.S. agency mortgage-backed securities | 265 |  |  | (1) |  |  | — |  |  | — |  |  | 265 |  |  | (1) |  |
| Total | $ | 1,358 |  |  | $ | (7) |  |  | $ | 3 |  |  | $ | — |  |  | $ | 1,361 |  |  | $ | (7) |  |

[0000858877-21-000013:notes:196]
The following table summarizes the maturities of our available-for-sale debt investments as of July 31, 2021 (in millions):

[0000858877-21-000013:notes:197]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 4,981 |  |  | $ | 4,976 |  |
| After 1 year through 5 years | 6,517 |  |  | 6,677 |  |
| After 5 years through 10 years | 637 |  |  | 685 |  |
| After 10 years | 5 |  |  | 6 |  |
| Mortgage-backed securities with no single maturity | 2,838 |  |  | 2,862 |  |
| Total | $ | 14,978 |  |  | $ | 15,206 |  |

[0000858877-21-000013:notes:198]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-21-000013:notes:199]
(b)Summary of Equity Investments

[0000858877-21-000013:notes:200]
We recognized a net unrealized gain during fiscal 2021 on our marketable securities still held as of the reporting date of $8 million. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $39 million and a net loss of $13 million for fiscal 2021 and 2020, respectively. We held equity interests in certain private equity funds of $0.9 billion and $0.7 billion as of July 31, 2021 and July 25, 2020, respectively, which are accounted for under the NAV practical expedient.

[0000858877-21-000013:notes:201]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of July 31, 2021, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
As of July 31, 2021, the carrying value of our investments in privately held companies was $1.5 billion. Of the total carrying value of our investments in privately held companies as of July 31, 2021, $0.9 billion of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $0.2 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-21-000013:notes:202]
Fair Value 
(a)Assets and Liabilities Measured at Fair Value on a Recurring Basis

[0000858877-21-000013:notes:203]
Assets and liabilities measured at fair value on a recurring basis were as follows (in millions):

[0000858877-21-000013:notes:204]
|  | JULY 31, 2021 |  | JULY 25, 2020 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 5,694 |  |  | $ | — |  |  | $ | 5,694 |  |  | $ | 9,687 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,687 |  |
| Commercial paper | — |  |  | 114 |  |  | 114 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government securities | — |  |  | 300 |  |  | 300 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities | — |  |  | — |  |  | — |  |  | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 1,794 |  |  | 1,794 |  |  | — |  |  | 2,685 |  |  | — |  |  | 2,685 |  |
| U.S. government agency securities | — |  |  | 152 |  |  | 152 |  |  | — |  |  | 110 |  |  | — |  |  | 110 |  |
| Corporate debt securities | — |  |  | 8,910 |  |  | 8,910 |  |  | — |  |  | 11,877 |  |  | — |  |  | 11,877 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,862 |  |  | 2,862 |  |  | — |  |  | 2,035 |  |  | — |  |  | 2,035 |  |
| Non-U.S. government agency securities | — |  |  | 3 |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Commercial paper | — |  |  | 1,190 |  |  | 1,190 |  |  | — |  |  | 727 |  |  | — |  |  | 727 |  |
| Certificates of deposit | — |  |  | 295 |  |  | 295 |  |  | — |  |  | 176 |  |  | — |  |  | 176 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 137 |  |  | — |  |  | 137 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 750 |  |  | — |  |  | 750 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Derivative assets | — |  |  | 126 |  |  | 126 |  |  | — |  |  | 190 |  |  | 1 |  |  | 191 |  |
| Total | $ | 6,581 |  |  | $ | 15,746 |  |  | $ | 22,327 |  |  | $ | 9,687 |  |  | $ | 17,808 |  |  | $ | 1 |  |  | $ | 27,496 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 20 |  |  | $ | 20 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Total | $ | — |  |  | $ | 20 |  |  | $ | 20 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |

[0000858877-21-000013:notes:205]
Level 1 marketable securities are determined by using quoted prices in active markets for identical assets. Level 2 available-for-sale debt investments are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. Our derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs. We did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented. Level 3 assets include certain derivative instruments, the values of which are determined based on discounted cash flow models using inputs that we could not corroborate with market data.

[0000858877-21-000013:notes:206]
(b)Assets Measured at Fair Value on a Nonrecurring Basis

[0000858877-21-000013:notes:207]
The carrying value of our non-marketable equity securities measured using the measurement alternative recorded to fair value on a non-recurring basis is adjusted for observable transactions for identical or similar investments of the same issuer or impairment. These securities are classified as Level 3 in the fair value hierarchy because we estimate the value based on valuation methods using the observable transaction price at the transaction date and other unobservable inputs such as volatility, rights, and obligations of the securities we hold.

[0000858877-21-000013:notes:208]
(c)Other Fair Value Disclosures

[0000858877-21-000013:notes:209]
The fair value of our short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables and financed service contracts as of July 31, 2021 and July 25, 2020 was $4.0 billion and $4.5 billion, respectively. The estimated fair value of our long-term loan 
receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.As of July 31, 2021 and July 25, 2020, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of July 31, 2021, the fair value of our senior notes was $13.7 billion, with a carrying amount of $11.5 billion. This compares to a fair value of $17.4 billion and a carrying amount of $14.6 billion as of July 25, 2020. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:DebtDisclosureTextBlock

[0000858877-21-000013:notes:210]
Borrowings 
(a)Short-Term Debt

[0000858877-21-000013:notes:211]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-21-000013:notes:212]
|  | July 31, 2021 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 2,508 |  |  | 1.75 | % |  | $ | 3,005 |  |  | 2.07 | % |

[0000858877-21-000013:notes:213]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of July 31, 2021 and July 25, 2020.

[0000858877-21-000013:notes:214]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-21-000013:notes:215]
(b)Long-Term Debt

[0000858877-21-000013:notes:216]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-21-000013:notes:217]
|  |  |  | July 31, 2021 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | — |  |  | — |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | — |  |  | — |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.13% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.00% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.29% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 11,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (80) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 106 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 11,526 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 2,508 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,018 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 11,526 |  |  |  |  | $ | 14,583 |  |  |  |

[0000858877-21-000013:notes:218]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $2.0 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-21-000013:notes:219]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of July 31, 2021, we were in compliance with all debt covenants.

[0000858877-21-000013:notes:220]
As of July 31, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-21-000013:notes:221]
| Fiscal Year | Amount |
| 2022 | $ | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 11,500 |  |

[0000858877-21-000013:notes:222]
Our $2.0 billion senior fixed-rate notes with a maturity date of September 20, 2021 were redeemed on August 20, 2021, pursuant to our par call redemption option. The redemption price was equal to 100% of the principal amount plus any accrued and unpaid interest to, but excluding, August 20, 2021.

[0000858877-21-000013:notes:223]
(c)Credit Facility

[0000858877-21-000013:notes:224]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. The credit agreement is structured as an amendment and restatement of our 364-day credit agreement, which would have terminated on May 14, 2021. As of July 31, 2021, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.

[0000858877-21-000013:notes:225]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-21-000013:notes:226]
Derivative Instruments 
(a)Summary of Derivative Instruments

[0000858877-21-000013:notes:227]
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We do, however, seek to mitigate such risks by limiting our counterparties to major financial institutions and requiring collateral in certain cases. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-21-000013:notes:228]
The fair values of our derivative instruments and the line items on the Consolidated Balance Sheets to which they were recorded are summarized as follows (in millions):

[0000858877-21-000013:notes:229]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | July 31, 2021 |  | July 25, 2020 |  | Balance Sheet Line Item |  | July 31, 2021 |  | July 25, 2020 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 14 |  |  | $ | 7 |  |  | Other current liabilities |  | $ | 3 |  |  | $ | 2 |  |
| Foreign currency derivatives | Other assets |  | 1 |  |  | — |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other current assets |  | 9 |  |  | 6 |  |  | Other current liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other assets |  | 99 |  |  | 169 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 123 |  |  | 182 |  |  |  |  | 3 |  |  | 2 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 3 |  |  | 8 |  |  | Other current liabilities |  | 16 |  |  | 8 |  |
| Foreign currency derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 1 |  |  | — |  |
| Equity derivatives | Other assets |  | — |  |  | 1 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 3 |  |  | 9 |  |  |  |  | 17 |  |  | 8 |  |
| Total |  |  | $ | 126 |  |  | $ | 191 |  |  |  |  | $ | 20 |  |  | $ | 10 |  |

[0000858877-21-000013:notes:230]
The following amounts were recorded on the Consolidated Balance Sheets related to cumulative basis adjustments for our fair value hedges (in millions):

[0000858877-21-000013:notes:231]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | July 31,2021 |  | July 25,2020 |  | July 31,2021 |  | July 25,2020 |
| Short-term debt |  | $ | (508) |  |  | $ | (506) |  |  | $ | (9) |  |  | $ | (6) |  |
| Long-term debt |  | $ | (1,594) |  |  | $ | (2,159) |  |  | $ | (97) |  |  | $ | (165) |  |

[0000858877-21-000013:notes:232]
The effect of derivative instruments designated as fair value hedges, recognized in interest and other income (loss), net is summarized as follows (in millions):

[0000858877-21-000013:notes:233]
|  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
|  |  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Interest rate derivatives: |  |  |  |  |  |  |
| Hedged items |  | $ | 65 |  |  | $ | (98) |  |  | $ | (138) |  |
| Derivatives designated as hedging instruments |  | (67) |  |  | 101 |  |  | 145 |  |
| Total |  | $ | (2) |  |  | $ | 3 |  |  | $ | 7 |  |

[0000858877-21-000013:notes:234]
The effect on the Consolidated Statements of Operations of derivative instruments not designated as hedges is summarized as follows (in millions):

[0000858877-21-000013:notes:235]
|  |  |  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | 2 |  |  | $ | (5) |  |  | $ | (60) |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | 157 |  |  | 15 |  |  | 5 |  |
| Equity derivatives |  | Other income (loss), net |  | 20 |  |  | 9 |  |  | 3 |  |
| Total |  |  |  | $ | 179 |  |  | $ | 19 |  |  | $ | (52) |  |

[0000858877-21-000013:notes:236]
The notional amounts of our outstanding derivatives are summarized as follows (in millions):

[0000858877-21-000013:notes:237]
|  | July 31, 2021 |  | July 25, 2020 |
| Foreign currency derivatives | $ | 4,139 |  |  | $ | 4,315 |  |
| Interest rate derivatives | 2,000 |  |  | 2,500 |  |
| Total return swaps—deferred compensation | 730 |  |  | 580 |  |
| Total | $ | 6,869 |  |  | $ | 7,395 |  |

[0000858877-21-000013:notes:238]
(b)Offsetting of Derivative Instruments

[0000858877-21-000013:notes:239]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty. As of July 31, 2021 and July 25, 2020, the potential effects of these rights of set-off associated with the derivative contracts would be a reduction to both derivative assets and derivative liabilities of $17 million and $10 million, respectively.

[0000858877-21-000013:notes:240]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral received as of July 31, 2021 and July 25, 2020 was $109 million and $173 million, respectively. Including the effects of collateral, this results in a net derivative liability of $3 million and a net derivative asset of $8 million as of July 31, 2021 and July 25, 2020, respectively.

[0000858877-21-000013:notes:241]
(c)Foreign Currency Exchange Risk

[0000858877-21-000013:notes:242]
We conduct business globally in numerous currencies. Therefore, we are exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, we enter into foreign currency contracts. We do not enter into such contracts for speculative purposes.

[0000858877-21-000013:notes:243]
We hedge forecasted foreign currency transactions related to certain revenues, operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The derivative instrument’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. During the fiscal years presented, we did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-21-000013:notes:244]
We enter into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, long-term customer financings and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of intercompany balances, other current assets, or liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-21-000013:notes:245]
We hedge certain net investments in our foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on our net investment in those foreign subsidiaries. These derivative instruments generally have maturities of up to six months.

[0000858877-21-000013:notes:246]
(d)Interest Rate Risk

[0000858877-21-000013:notes:247]
We hold interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2022 through 2025. Under these interest rate swaps, we receive fixed-rate interest payments and make interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.

[0000858877-21-000013:notes:248]
(e)Equity Price Risk

[0000858877-21-000013:notes:249]
We hold marketable equity securities in our portfolio that are subject to price risk. To diversify our overall portfolio, we also hold equity derivatives that are not designated as accounting hedges. The change in the fair value of each of these investment types are included in other income (loss), net. 
We are also exposed to variability in compensation charges related to certain deferred compensation obligations to employees. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure and offset the related compensation expense.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-21-000013:notes:250]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-21-000013:notes:251]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-21-000013:notes:252]
The following table summarizes our purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-21-000013:notes:253]
| Commitments by Period | July 31,2021 |  | July 25,2020 |
| Less than 1 year | $ | 6,903 |  |  | $ | 3,994 |  |
| 1 to 3 years | 1,806 |  |  | 412 |  |
| 3 to 5 years | 1,545 |  |  | — |  |
| Total | $ | 10,254 |  |  | $ | 4,406 |  |

[0000858877-21-000013:notes:254]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 31, 2021 and July 25, 2020, the liability for these purchase commitments was $151 million and $141 million, respectively, and was included in other current liabilities. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $76 million, $139 million, and $95 million in fiscal 2021, 2020, and 2019, respectively.

[0000858877-21-000013:notes:255]
(b)Other Commitments

[0000858877-21-000013:notes:256]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-21-000013:notes:257]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-21-000013:notes:258]
|  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Compensation expense related to acquisitions | $ | 262 |  |  | $ | 214 |  |  | $ | 313 |  |

[0000858877-21-000013:notes:259]
As of July 31, 2021, we estimated that future cash compensation expense of up to $719 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-21-000013:notes:260]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.2 billion and $0.3 billion as of July 31, 2021 and July 25, 2020, respectively.

[0000858877-21-000013:notes:261]
(c)Product Warranties

[0000858877-21-000013:notes:262]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-21-000013:notes:263]
|  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Balance at beginning of fiscal year | $ | 331 |  |  | $ | 342 |  |  | $ | 359 |  |
| Provisions for warranties issued | 496 |  |  | 561 |  |  | 600 |  |
| Adjustments for pre-existing warranties | — |  |  | (8) |  |  | (12) |  |
| Settlements | (491) |  |  | (564) |  |  | (603) |  |
| Acquisitions and divestitures | — |  |  | — |  |  | (2) |  |
| Balance at end of fiscal year | $ | 336 |  |  | $ | 331 |  |  | $ | 342 |  |

[0000858877-21-000013:notes:264]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-21-000013:notes:265]
(d)Financing and Other Guarantees

[0000858877-21-000013:notes:266]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-21-000013:notes:267]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $26.7 billion, $26.9 billion, and $29.6 billion in fiscal 2021, 2020, and 2019, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.1 billion as of July 31, 2021 and July 25, 2020, respectively.

[0000858877-21-000013:notes:268]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $10 million, $9 million, and $14 million in fiscal 2021, 2020, and 2019, respectively.

[0000858877-21-000013:notes:269]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at July 31, 2021 and July 25, 2020, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-21-000013:notes:270]
|  | July 31, 2021 |  | July 25, 2020 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 155 |  |  | $ | 198 |  |
| End user | 5 |  |  | 9 |  |
| Total | $ | 160 |  |  | $ | 207 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (16) |  |  | $ | (19) |  |
| End user | (5) |  |  | (9) |  |
| Total | $ | (21) |  |  | $ | (28) |  |
| Total | $ | 139 |  |  | $ | 179 |  |

[0000858877-21-000013:notes:271]
(e)Indemnifications

[0000858877-21-000013:notes:272]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-21-000013:notes:273]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations discussed in this section (e) due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these cases, and the unique facts and circumstances involved in each particular case and agreement. We are unable to reasonably estimate the ultimate outcome of the cases discussed below in this section (e), but we do not believe that any potential indemnity liability would be material, and historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-21-000013:notes:274]
We were asked to indemnify certain of our service provider customers that were subject to patent infringement claims asserted by ChanBond, LLC (“ChanBond”) in federal court in Delaware on September 21, 2015. All of the service provider customer defendants entered into an agreement to resolve ChanBond’s claims. We resolved the service providers’ indemnity claims, effective July 7, 2021, for an amount that did not have a material effect on our Consolidated Financial Statements.

[0000858877-21-000013:notes:275]
Verizon Communications Inc. requested that we indemnify it and seven of its subsidiaries (collectively, “Verizon”) for a subset of the patent infringement claims asserted by Huawei Technologies Co. Ltd. (“Huawei”) in lawsuits filed against Verizon on February 5, 2020, in the United States District Court for the Eastern District of Texas (“E.D. Tex”) and the United States District Court for the Western District of Texas (“W.D. Tex”). Huawei and Verizon reached a confidential settlement agreement and Huawei dismissed both the E.D. Tex and W.D. Tex cases. Verizon indicated that they no longer are seeking indemnity contribution from us.

[0000858877-21-000013:notes:276]
We have been asked by seven of our customers to indemnify them in connection with patent infringement claims asserted against them by Estech Systems, Inc. (“Estech”) in the E.D. Tex and W.D. Tex courts between April 24, 2020 and August 25, 2020. Estech alleges that the customer defendants infringe three patents generally related to IP telephony by using collaboration technology from us and other providers. Estech is seeking monetary damages from the customer defendants. The first E.D. Tex case against one of the customer defendants is scheduled for trial on October 4, 2021, and the W.D. Tex cases are set for trial on December 7, 2021 and April 1, 2022. We believe the customer defendants have strong defenses and do not believe our indemnity obligations, if any, would have a material effect on our Consolidated Financial Statements.

[0000858877-21-000013:notes:277]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-21-000013:notes:278]
(f)Legal Proceedings

[0000858877-21-000013:notes:279]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-21-000013:notes:280]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $155 million for the alleged evasion of import and other taxes, $771 million for interest, and $384 million for various penalties, all determined using an exchange rate as of July 31, 2021.

[0000858877-21-000013:notes:281]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-21-000013:notes:282]
China     We are investigating allegations of a self-enrichment scheme involving now-former employees in China. Some of those employees are also alleged to have made or directed payments from the funds they received to various third parties, including employees of state-owned enterprises. We voluntarily disclosed this investigation to the Department of Justice (“DOJ”) and Securities and Exchange Commission (“SEC”). We take such allegations very seriously and we are providing results of our investigation to the DOJ and SEC. While the outcome of our investigation is currently not determinable, we do not expect that it will have a material adverse effect on our Consolidated Financial Statements.

[0000858877-21-000013:notes:283]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware (“D. Del.”), accusing our products and services in the area of network intrusion detection of infringing two patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. On May 12, 2016, a jury returned a verdict finding willful infringement. The jury awarded SRI damages of $24 million. On May 25, 2017, the district court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit (“Federal Circuit”), and on July 12, 2019, the Federal Circuit vacated the enhanced

[0000858877-21-000013:notes:284]
damages award; vacated and remanded in part the willful infringement finding; vacated and remanded the attorneys’ fees award for further proceedings; and affirmed the district court’s other findings. On April 1, 2020, the district court issued a final judgment on the remanded issues, finding no evidence of willful infringement and reinstating the $8 million award of attorneys’ fees. SRI appealed the judgment of no willful infringement to the Federal Circuit on April 3, 2020, and Cisco filed a cross-appeal on the attorneys’ fees award on April 9, 2020. Cisco has paid SRI $28 million, representing the portion of the judgment that the Federal Circuit previously affirmed, plus interest and royalties on post-verdict sales. While the remaining proceedings may result in an additional loss, we do not believe it would have a material effect on our Consolidated Financial Statements.

[0000858877-21-000013:notes:285]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal U.S. patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office (“PTO”) to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal appealed the PTAB’s findings of unpatentability to the Federal Circuit. The Federal Circuit affirmed the PTAB’s findings of unpatentability as to three of the patents on March 10, 2021, and affirmed the PTAB’s findings of unpatentability as to the remaining four patents on May 11, 2021. On August 9, 2021, Centripetal filed a writ of certiorari seeking the U.S. Supreme Court’s review of the Federal Circuit’s affirmance of several of the PTAB’s unpatentability findings.

[0000858877-21-000013:notes:286]
For the five asserted U.S. patents not subject to the IPR Proceedings, the district court conducted a bench trial by videoconference from May 6, 2020 to June 25, 2020. On October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The district court awarded Centripetal $1.9 billion, comprised of $756 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $14 million. The district court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $168 million and a maximum annual royalty of $300 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $84 million and a maximum annual royalty of $150 million. We believe that the district court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We have appealed the district court’s judgment as to the four patents found valid and infringed to the Federal Circuit. On October 28, 2020, by agreement of the parties, the district court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment.

[0000858877-21-000013:notes:287]
On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. district court proceedings, one of which has been invalidated by the PTAB. On June 22, 2021, Centripetal amended one of its complaints to assert one additional European patent and one additional German Utility Model patent. Centripetal seeks both injunctive relief and damages on these newly added patents. We believe we have strong defenses.

[0000858877-21-000013:notes:288]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of either litigation at this time. If we do not prevail in either litigation, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-21-000013:notes:289]
Finjan     On January 6, 2017, Finjan, Inc. (“Finjan”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California. On May 24, 2021, we resolved Finjan’s claims for an amount that did not have a material effect on our Consolidated Financial Statements.

[0000858877-21-000013:notes:290]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in E.D. Tex, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. As of November 27, 2020, the PTO preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings. On January 13, 2021, the court entered an order staying the case pending the conclusion of the ex parte reexamination proceedings (“Reexamination Proceedings”). While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in court, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-21-000013:notes:291]
On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) (which we subsequently acquired) in D. Del, seeking damages, including enhanced damages for allegations of willful infringement, and a

[0000858877-21-000013:notes:292]
running royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot has asserted in its E.D. Tex case. On September 3, 2021, the court stayed the case pending the ultimate resolution of the Reexamination Proceedings. Due to the early stage of the litigation as well as uncertainties in the litigation processes, we are unable, at this time, to reasonably estimate a potential range of loss, if any, or the ultimate outcome of this litigation.

[0000858877-21-000013:notes:293]
Monarch     On January 21, 2020, Monarch Networking Solutions LLC (“Monarch”) asserted patent infringement claims against us in E.D. Tex alleging that certain Cisco routers and firewalls infringe three U.S. patents. On May 13, 2020, Monarch filed a second action against us in W.D. Tex, alleging that two factor authentication functionality in Duo and Meraki MR and MX access point products infringe one U.S. patent. On June 24, 2021, we resolved Monarch’s claims in both E.D. Tex and W.D. Tex for an amount that did not have a material effect on our Consolidated Financial Statements.

[0000858877-21-000013:notes:294]
Viasat     On January 21, 2016, Viasat, Inc. (“Viasat”) filed suit against Acacia (which we subsequently acquired) in the California Superior Court for San Diego County (“SDSC”) seeking unpaid royalties for breach of contract and the implied covenant of good faith and fair dealing, and damages for trade secret misappropriation for certain products (“Viasat 1”). Acacia counterclaimed for patent and trade secret misappropriation, contract, and unfair competition claims. On July 17, 2019, the jury found for Viasat on its contract claims, and awarded Viasat $49 million for unpaid royalties through 2018. The jury further found that Acacia willfully misappropriated Viasat’s trade secrets and awarded Viasat $1. On Acacia’s counterclaims, the jury found for Acacia on its contract and trade secret claims and awarded Acacia $1. Both Acacia and Viasat have pending appeals to the California Court of Appeal. On November 6, 2019, Viasat filed a second suit in SDSC, alleging contract and trade secret claims for Acacia products sold from January 1, 2019 forward (“Viasat 2”). On February 28, 2020, the court stayed Viasat 2 pending the appeal in Viasat 1. On June 9, 2020, Viasat filed a third suit in SDSC (“Viasat 3”). In Viasat 3, Viasat alleges contract and trade secrets claims for sales of additional Acacia products. On August 11, 2020, the court stayed Viasat 3 pending the appeal in Viasat 1.

[0000858877-21-000013:notes:295]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court - Business Litigation Session against ViaSat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation. On April 5, 2018, ViaSat counterclaimed with contract, trade secret, and unfair competition claims (collectively, with Viasat 1, Viasat 2 and Viasat 3, the “Viasat Cases”). On December 13, 2018, the Massachusetts court entered an order staying the Massachusetts litigation, which has been extended to December 31, 2021.

[0000858877-21-000013:notes:296]
While we believe Acacia has strong defenses in each of the Viasat Cases, we are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If Acacia does not prevail, we believe that any relief ultimately assessed in any of the Viasat Cases would not have a material effect on our Consolidated Financial Statements.

[0000858877-21-000013:notes:297]
In addition, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. 
For additional information regarding intellectual property litigation, see “Part I, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-21-000013:notes:298]
Stockholders’ Equity 
(a)Cash Dividends on Shares of Common Stock

[0000858877-21-000013:notes:299]
We declared and paid cash dividends of $1.46, $1.42 and $1.36 per common share, or $6.2 billion during fiscal 2021 and $6.0 billion, on our outstanding common stock during each of fiscal 2020 and 2019.

[0000858877-21-000013:notes:300]
Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-21-000013:notes:301]
(b)Stock Repurchase Program

[0000858877-21-000013:notes:302]
In September 2001, our Board of Directors authorized a stock repurchase program. As of July 31, 2021, the remaining authorized amount for stock repurchases under this program was approximately $7.9 billion with no termination date.

[0000858877-21-000013:notes:303]
A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-21-000013:notes:304]
| Years Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| July 31, 2021 |  | 64 |  |  | $ | 45.48 |  |  | $ | 2,902 |  |
| July 25, 2020 |  | 59 |  |  | $ | 44.36 |  |  | $ | 2,619 |  |
| July 27, 2019 |  | 418 |  |  | $ | 49.22 |  |  | $ | 20,577 |  |

[0000858877-21-000013:notes:305]
There was $25 million in stock repurchases that were pending settlement as of July 31, 2021. There was no stock repurchases pending settlement as of July 25, 2020. There was $40 million in stock repurchases that were pending settlement as of July 27, 2019.

[0000858877-21-000013:notes:306]
The purchase price for the shares of our stock repurchased is reflected as a reduction to stockholders’ equity.

[0000858877-21-000013:notes:307]
We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings or an increase to accumulated deficit and (ii) a reduction of common stock and additional paid-in capital.

[0000858877-21-000013:notes:308]
(c)Preferred Stock

[0000858877-21-000013:notes:309]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock of one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights of such series, and any qualification, limitations or restrictions thereof, of the shares of such series. As of July 31, 2021, we had not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-21-000013:notes:310]
Employee Benefit Plans  
(a)Employee Stock Incentive Plans

[0000858877-21-000013:notes:311]
Stock Incentive Plan Program Description    We have one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with us. The number and frequency of share-based awards are based on competitive practices, our operating results, government regulations, and other factors. Our primary stock incentive plan is summarized as follows:

[0000858877-21-000013:notes:312]
2005 Plan    The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions. Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. As of July 31, 2021, the maximum number of shares issuable under the 2005 Plan over its term was 790 million shares. The 2005 Plan may be terminated by our Board of Directors at any time and for any reason, and is currently set to terminate at the 2030 Annual Meeting unless re-adopted or extended by our stockholders prior to or on such date.

[0000858877-21-000013:notes:313]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or

[0000858877-21-000013:notes:314]
terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of July 31, 2021, 245 million shares were authorized for future grant under the 2005 Plan.

[0000858877-21-000013:notes:315]
(b)Employee Stock Purchase Plan

[0000858877-21-000013:notes:316]
We have an Employee Stock Purchase Plan under which 721 million shares of our common stock have been reserved for issuance as of July 31, 2021. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. We issued 17 million, 18 million, and 19 million shares under the Employee Stock Purchase Plan in fiscal 2021, 2020, and 2019, respectively. As of July 31, 2021, 125 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-21-000013:notes:317]
(c)Summary of Share-Based Compensation Expense

[0000858877-21-000013:notes:318]
Share-based compensation expense consists primarily of expenses for RSUs, stock purchase rights, and stock options, granted to employees or assumed from acquisitions. The following table summarizes share-based compensation expense (in millions):

[0000858877-21-000013:notes:319]
| Years Ended | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Cost of sales—product | $ | 99 |  |  | $ | 93 |  |  | $ | 90 |  |
| Cost of sales—service | 176 |  |  | 144 |  |  | 130 |  |
| Share-based compensation expense in cost of sales | 275 |  |  | 237 |  |  | 220 |  |
| Research and development | 694 |  |  | 592 |  |  | 540 |  |
| Sales and marketing | 540 |  |  | 500 |  |  | 519 |  |
| General and administrative | 226 |  |  | 215 |  |  | 250 |  |
| Restructuring and other charges | 26 |  |  | 25 |  |  | 62 |  |
| Share-based compensation expense in operating expenses | 1,486 |  |  | 1,332 |  |  | 1,371 |  |
| Total share-based compensation expense | $ | 1,761 |  |  | $ | 1,569 |  |  | $ | 1,591 |  |
| Income tax benefit for share-based compensation | $ | 387 |  |  | $ | 452 |  |  | $ | 542 |  |

[0000858877-21-000013:notes:320]
As of July 31, 2021, the total compensation cost related to unvested share-based awards not yet recognized was $3.8 billion, which is expected to be recognized over approximately 2.7 years on a weighted-average basis.

[0000858877-21-000013:notes:321]
(d)Restricted Stock Unit Awards

[0000858877-21-000013:notes:322]
A summary of the restricted stock and stock unit activity, which includes time-based and performance-based or market-based RSUs, is as follows (in millions, except per-share amounts):

[0000858877-21-000013:notes:323]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 28, 2018 | 119 |  |  | $ | 30.56 |  |  |  |
| Granted | 45 |  |  | 47.71 |  |  |  |
| Vested | (50) |  |  | 29.25 |  |  | $ | 2,446 |  |
| Canceled/forfeited/other | (14) |  |  | 32.01 |  |  |  |
| UNVESTED BALANCE AT JULY 27, 2019 | 100 |  |  | 38.66 |  |  |  |
| Granted and assumed | 49 |  |  | 42.61 |  |  |  |
| Vested | (44) |  |  | 35.20 |  |  | $ | 2,045 |  |
| Canceled/forfeited/other | (9) |  |  | 40.45 |  |  |  |
| UNVESTED BALANCE AT JULY 25, 2020 | 96 |  |  | 42.03 |  |  |  |
| Granted and assumed | 51 |  |  | 41.89 |  |  |  |
| Vested | (39) |  |  | 39.63 |  |  | $ | 1,813 |  |
| Canceled/forfeited/other | (14) |  |  | 42.13 |  |  |  |
| UNVESTED BALANCE AT JULY 31, 2021 | 94 |  |  | $ | 42.93 |  |  |  |

[0000858877-21-000013:notes:324]
(e)Valuation of Employee Share-Based Awards

[0000858877-21-000013:notes:325]
Time-based restricted stock units and PRSUs that are based on our financial performance metrics or non-financial operating goals are valued using the market value of our common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, we estimated the fair value of the total shareholder return (TSR) component of the PRSUs using a Monte Carlo simulation model. The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-21-000013:notes:326]
|  | RESTRICTED STOCK UNITS |
| Years Ended | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Number of shares granted (in millions) | 48 |  |  | 47 |  |  | 43 |  |
| Grant date fair value per share | $ | 42.04 |  |  | $ | 42.68 |  |  | $ | 47.75 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 3.3 | % |  | 3.1 | % |  | 2.7 | % |
| Range of risk-free interest rates | 0.0% – 0.9% |  | 0.0% – 2.0% |  | 0.0% – 2.9% |

[0000858877-21-000013:notes:327]
|  | PERFORMANCE BASED RESTRICTED STOCK UNITS |
| Years Ended | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Number of shares granted (in millions) | 2 |  |  | 2 |  |  | 2 |  |
| Grant date fair value per share | $ | 37.91 |  |  | $ | 41.91 |  |  | $ | 47.00 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 3.6 | % |  | 2.8 | % |  | 2.8 | % |
| Range of risk-free interest rates | 0.1% – 0.4% |  | 1.7% – 2.0% |  | 2.1% – 3.0% |

[0000858877-21-000013:notes:328]
The PRSUs granted during the fiscal years presented are contingent on the achievement of our financial performance metrics, our comparative market-based returns, or the achievement of financial and non-financial operating goals. For the awards based on financial performance metrics or comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period. Generally, the remaining 50% of the PRSUs are earned based on our TSR measured against the benchmark TSR of a peer group over the same period. Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of our financial performance metrics or our comparative market-based returns, and 0% to 100% of the target shares granted contingent on the achievement of non-financial operating goals.

[0000858877-21-000013:notes:329]
The assumptions for the valuation of employee stock purchase rights are summarized as follows:

[0000858877-21-000013:notes:330]
|  | EMPLOYEE STOCK PURCHASE RIGHTS |
| Years Ended | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Weighted-average assumptions: |  |  |  |  |  |
| Expected volatility | 29.2 | % |  | 22.2 | % |  | 20.4 | % |
| Risk-free interest rate | 0.3 | % |  | 1.8 | % |  | 1.9 | % |
| Expected dividend | 3.2 | % |  | 3.0 | % |  | 3.0 | % |
| Expected life (in years) | 1.3 |  | 1.3 |  | 1.3 |
| Weighted-average estimated grant date fair value per share | $ | 12.46 |  |  | $ | 10.20 |  |  | $ | 9.06 |  |

[0000858877-21-000013:notes:331]
The valuation of employee stock purchase rights and the related assumptions are for the employee stock purchases made during the respective fiscal years.

[0000858877-21-000013:notes:332]
We used third-party analyses to assist in developing the assumptions used in our Black-Scholes model. We are responsible for determining the assumptions used in estimating the fair value of our share-based payment awards.

[0000858877-21-000013:notes:333]
We used the implied volatility for traded options (with contract terms corresponding to the expected life of the employee stock purchase rights) on our stock as the expected volatility assumption required in the Black-Scholes model. The implied volatility is more representative of future stock price trends than historical volatility. The risk-free interest rate assumption is based upon observed interest rates appropriate for the term of our employee stock purchase rights. The dividend yield assumption is based on the history and expectation of dividend payouts at the grant date.

[0000858877-21-000013:notes:334]
(f)Employee 401(k) Plans

[0000858877-21-000013:notes:335]
We sponsor the Cisco Systems, Inc. 401(k) Plan (the “Plan”) to provide retirement benefits for our employees. As allowed under Section 401(k) of the Internal Revenue Code, the Plan provides for tax-deferred salary contributions and after-tax contributions for eligible employees. The Plan allows employees to contribute up to 75% of their annual eligible earnings to the Plan on a pretax and after-tax basis, including Roth contributions. Employee contributions are limited to a maximum annual amount as set periodically by the Internal Revenue Code. We match pretax and Roth employee contributions up to 100% of the first 4.5% of eligible earnings that are contributed by employees. Therefore, the maximum matching contribution that we may allocate to each participant’s account will not exceed $13,050 for the 2021 calendar year due to the $290,000 annual limit on eligible earnings imposed by the Internal Revenue Code. All matching contributions vest immediately. Our matching contributions to the Plan totaled $290 million, $295 million, and $283 million in fiscal 2021, 2020, and 2019, respectively.

[0000858877-21-000013:notes:336]
The Plan allows employees who meet the age requirements and reach the Plan contribution limits to make catch-up contributions (pretax or Roth) not to exceed the lesser of 75% of their annual eligible earnings or the limit set forth in the Internal Revenue Code. Catch-up contributions are not eligible for matching contributions. In addition, the Plan provides for discretionary profit-sharing contributions as determined by the Board of Directors. Such contributions to the Plan are allocated among eligible participants in the proportion of their salaries to the total salaries of all participants. There were no discretionary profit-sharing contributions made in fiscal 2021, 2020, and 2019.

[0000858877-21-000013:notes:337]
We also sponsor other 401(k) plans as a result of acquisitions of other companies. Our contributions to these plans were not material to Cisco on either an individual or aggregate basis for any of the fiscal years presented.

[0000858877-21-000013:notes:338]
(g)Deferred Compensation Plans
The Cisco Systems, Inc. Deferred Compensation Plan (the “Deferred Compensation Plan”), a nonqualified deferred compensation plan, became effective in 2007. As required by applicable law, participation in the Deferred Compensation Plan is limited to a select group of our management employees. Under the Deferred Compensation Plan, which is an unfunded and unsecured deferred compensation arrangement, a participant may elect to defer base salary, bonus, and/or commissions, pursuant to such rules as may be established by Cisco, up to the maximum percentages for each deferral election as described in the plan. We may also, at our discretion, make a matching contribution to the employee under the Deferred Compensation Plan. A matching contribution equal to 4.5% of eligible compensation in excess of the Internal Revenue Code limit for qualified plans for calendar year 2021 that is deferred by participants under the Deferred Compensation Plan (with a $1.5 million cap on eligible compensation) will be made to eligible participants’ accounts at the end of calendar year 2021. The total deferred compensation liability under the Deferred Compensation Plan, together with deferred compensation plans assumed from acquired companies, was approximately $845 million and $704 million as of July 31, 2021 and July 25, 2020, respectively, and was recorded primarily in other long-term liabilities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-21-000013:notes:339]
Comprehensive Income (Loss)  
The components of AOCI, net of tax, and the other comprehensive income (loss) are summarized as follows (in millions):

[0000858877-21-000013:notes:340]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains and Losses |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 28, 2018 | $ | (310) |  |  | $ | (11) |  |  | $ | (528) |  |  | $ | (849) |  |
| Other comprehensive income (loss) before reclassifications | 560 |  |  | — |  |  | (267) |  |  | 293 |  |
| (Gains) losses reclassified out of AOCI | 13 |  |  | (3) |  |  | 2 |  |  | 12 |  |
| Tax benefit (expense) | (95) |  |  | — |  |  | 15 |  |  | (80) |  |
| Total change for the period | 478 |  |  | (3) |  |  | (250) |  |  | 225 |  |
| Effect of adoption of accounting standard | (168) |  |  | — |  |  | — |  |  | (168) |  |
| BALANCE AT JULY 27, 2019 | — |  |  | (14) |  |  | (778) |  |  | (792) |  |
| Other comprehensive income (loss) before reclassifications | 420 |  |  | 7 |  |  | (51) |  |  | 376 |  |
| (Gains) losses reclassified out of AOCI | (42) |  |  | 1 |  |  | 6 |  |  | (35) |  |
| Tax benefit (expense) | (63) |  |  | — |  |  | (5) |  |  | (68) |  |
| BALANCE AT JULY 25, 2020 | 315 |  |  | (6) |  |  | (828) |  |  | (519) |  |
| Other comprehensive income (loss) before reclassifications | (141) |  |  | 20 |  |  | 229 |  |  | 108 |  |
| (Gains) losses reclassified out of AOCI | (53) |  |  | (14) |  |  | 3 |  |  | (64) |  |
| Tax benefit (expense) | 61 |  |  | (1) |  |  | (2) |  |  | 58 |  |
| BALANCE AT JULY 31, 2021 | $ | 182 |  |  | $ | (1) |  |  | $ | (598) |  |  | $ | (417) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-21-000013:notes:341]
Income Taxes
(a)Provision for Income Taxes

[0000858877-21-000013:notes:342]
The provision for income taxes consists of the following (in millions):

[0000858877-21-000013:notes:343]
| Years Ended | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Federal: |  |  |  |  |  |
| Current | $ | 1,959 |  |  | $ | 1,101 |  |  | $ | 1,760 |  |
| Deferred | (203) |  |  | (374) |  |  | (84) |  |
|  | 1,756 |  |  | 727 |  |  | 1,676 |  |
| State: |  |  |  |  |  |
| Current | 513 |  |  | 264 |  |  | 302 |  |
| Deferred | (46) |  |  | 287 |  |  | (2) |  |
|  | 467 |  |  | 551 |  |  | 300 |  |
| Foreign: |  |  |  |  |  |
| Current | 583 |  |  | 1,429 |  |  | 1,238 |  |
| Deferred | (135) |  |  | 49 |  |  | (264) |  |
|  | 448 |  |  | 1,478 |  |  | 974 |  |
| Total | $ | 2,671 |  |  | $ | 2,756 |  |  | $ | 2,950 |  |

[0000858877-21-000013:notes:344]
Income before provision for income taxes consists of the following (in millions):

[0000858877-21-000013:notes:345]
| Years Ended | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| United States | $ | 12,335 |  |  | $ | 7,534 |  |  | $ | 7,611 |  |
| International | 927 |  |  | 6,436 |  |  | 6,960 |  |
| Total | $ | 13,262 |  |  | $ | 13,970 |  |  | $ | 14,571 |  |

[0000858877-21-000013:notes:346]
The items accounting for the difference between income taxes computed at the federal statutory rate and the provision for income taxes consist of the following:

[0000858877-21-000013:notes:347]
| Years Ended | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Federal statutory rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 2.7 |  |  | 3.5 |  |  | 2.0 |  |
| Foreign income at other than U.S. rates | 1.5 |  |  | (1.5) |  |  | (4.5) |  |
| Tax credits | (1.4) |  |  | (0.9) |  |  | (1.7) |  |
| Foreign-derived intangible income deduction | (4.2) |  |  | (2.6) |  |  | (1.3) |  |
| Stock-based compensation | 0.6 |  |  | (0.1) |  |  | (0.6) |  |
| Impact of the Tax Act | — |  |  | — |  |  | 6.1 |  |
| Other, net | (0.1) |  |  | 0.3 |  |  | (0.8) |  |
| Total | 20.1 | % |  | 19.7 | % |  | 20.2 | % |

[0000858877-21-000013:notes:348]
During fiscal 2019, we recorded an $872 million charge related to the Tax Act. This charge was the reversal of the previously recorded benefit associated with the U.S. taxation of deemed foreign dividends recorded in fiscal 2018 because of a retroactive final U.S. Treasury regulation issued during fiscal 2019.

[0000858877-21-000013:notes:349]
During fiscal 2020, the Internal Revenue Service (IRS) and Cisco settled all outstanding items related to the audit of our federal income tax returns for the fiscal year ended July 30, 2011 through July 27, 2013. As a result of the settlement, we recognized a net benefit to the provision for income taxes of $102 million, net of a reduction in interest expense of $4 million.

[0000858877-21-000013:notes:350]
Foreign taxes associated with the repatriation of earnings of foreign subsidiaries were not provided on a cumulative total of $6.5 billion of undistributed earnings for certain foreign subsidiaries as of the end of fiscal 2021. We intend to reinvest these earnings indefinitely in such foreign subsidiaries. If these earnings were distributed in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, we could be subject to additional income and withholding taxes. The amount of potential unrecognized deferred income tax liability related to these earnings is approximately $681 million.

[0000858877-21-000013:notes:351]
As a result of certain employment and capital investment actions, our income in certain foreign countries was subject to reduced tax rates. The tax incentives expired at the end of fiscal 2019. As of the end of fiscal 2019, the gross income tax benefits attributable to tax incentives were estimated to be $0.3 billion ($0.08 per diluted share). The gross income tax benefits were partially offset by accruals of U.S. income taxes on foreign earnings.

[0000858877-21-000013:notes:352]
Unrecognized Tax Benefits

[0000858877-21-000013:notes:353]
The aggregate changes in the balance of gross unrecognized tax benefits were as follows (in millions):

[0000858877-21-000013:notes:354]
| Years Ended | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Beginning balance | $ | 2,518 |  |  | $ | 1,925 |  |  | $ | 2,000 |  |
| Additions based on tax positions related to the current year | 224 |  |  | 188 |  |  | 185 |  |
| Additions for tax positions of prior years | 618 |  |  | 554 |  |  | 84 |  |
| Reductions for tax positions of prior years | (122) |  |  | (136) |  |  | (283) |  |
| Settlements | (93) |  |  | (4) |  |  | (38) |  |
| Lapse of statute of limitations | (39) |  |  | (9) |  |  | (23) |  |
| Ending balance | $ | 3,106 |  |  | $ | 2,518 |  |  | $ | 1,925 |  |

[0000858877-21-000013:notes:355]
As of July 31, 2021, $2.3 billion of the unrecognized tax benefits would affect the effective tax rate if realized. During fiscal 2021, we recognized $74 million of net interest expense and increased our unrecognized tax benefits for prior year tax positions by $618 million to reflect expected settlement positions in on-going U.S. federal, state, and foreign income tax return examinations. We recognized net interest expense of $104 million during fiscal 2020 and $30 million during fiscal 2019. Our net penalty expense for fiscal 2021, 2020, and 2019 was not material. Our total accrual for interest and penalties was $444 million, $340 million, and $220 million as of the end of fiscal 2021, 2020, and 2019, respectively. We are no longer subject to U.S. federal income tax audit for returns covering tax years through fiscal 2013. We are no longer subject to foreign or state income tax audits for returns covering tax years through fiscal 2003 and fiscal 2008, respectively.

[0000858877-21-000013:notes:356]
We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters. We estimate that the unrecognized tax benefits at July 31, 2021 could be reduced by $800 million in the next 12 months.

[0000858877-21-000013:notes:357]
(b)Deferred Tax Assets and Liabilities

[0000858877-21-000013:notes:358]
The following table presents the breakdown for net deferred tax assets (in millions):

[0000858877-21-000013:notes:359]
|  | July 31, 2021 |  | July 25, 2020 |
| Deferred tax assets | $ | 4,360 |  |  | $ | 3,990 |  |
| Deferred tax liabilities | (134) |  |  | (81) |  |
| Total net deferred tax assets | $ | 4,226 |  |  | $ | 3,909 |  |

[0000858877-21-000013:notes:360]
The following table presents the components of the deferred tax assets and liabilities (in millions):

[0000858877-21-000013:notes:361]
|  | July 31, 2021 |  | July 25, 2020 |
| ASSETS |  |  |  |
| Allowance for accounts receivable and returns | $ | 68 |  |  | $ | 110 |  |
| Sales-type and direct-financing leases | 157 |  |  | 179 |  |
| Inventory write-downs and capitalization | 392 |  |  | 350 |  |
| Deferred foreign income | 164 |  |  | 253 |  |
| IPR&D and purchased intangible assets | 1,195 |  |  | 1,289 |  |
| Deferred revenue | 1,526 |  |  | 1,182 |  |
| Credits and net operating loss carryforwards | 1,264 |  |  | 1,105 |  |
| Share-based compensation expense | 123 |  |  | 135 |  |
| Accrued compensation | 333 |  |  | 353 |  |
| Lease liabilities | 277 |  |  | 240 |  |
| Capitalized research expenditures | 303 |  |  | 223 |  |
| Other | 454 |  |  | 348 |  |
| Gross deferred tax assets | 6,256 |  |  | 5,767 |  |
| Valuation allowance | (771) |  |  | (700) |  |
| Total deferred tax assets | 5,485 |  |  | 5,067 |  |
| LIABILITIES |  |  |  |
| Goodwill and purchased intangible assets | (686) |  |  | (577) |  |
| Depreciation | (164) |  |  | (179) |  |
| Unrealized gains on investments | (112) |  |  | (119) |  |
| ROU lease assets | (260) |  |  | (222) |  |
| Other | (37) |  |  | (61) |  |
| Total deferred tax liabilities | (1,259) |  |  | (1,158) |  |
| Total net deferred tax assets | $ | 4,226 |  |  | $ | 3,909 |  |

[0000858877-21-000013:notes:362]
As of July 31, 2021, our federal, state, and foreign net operating loss carryforwards for income tax purposes were $540 million, $1.1 billion, and $617 million, respectively. A significant amount of the net operating loss carryforwards relates to acquisitions and, as a result, is limited in the amount that can be recognized in any one year. If not utilized, the federal, state, and foreign net operating loss carryforwards will begin to expire in fiscal 2022. We have provided a valuation allowance of $104 million for deferred tax assets related to foreign net operating losses that are not expected to be realized.
As of July 31, 2021, our federal, state, and foreign tax credit carryforwards for income tax purposes were approximately $31 million, $1.4 billion, and $7 million, respectively. The federal tax credit carryforwards will begin to expire in fiscal 2023. The majority of state and foreign tax credits can be carried forward indefinitely. We have provided a valuation allowance of $595 million for deferred tax assets related to state and foreign tax credits carryforwards that are not expected to be realized.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-21-000013:notes:363]
Segment Information and Major Customers 
(a)Revenue and Gross Margin by Segment

[0000858877-21-000013:notes:364]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-21-000013:notes:365]
Summarized financial information by segment for fiscal 2021, 2020, and 2019, based on our internal management system and as utilized by our Chief Operating Decision Maker (CODM), is as follows (in millions):

[0000858877-21-000013:notes:366]
| Years Ended | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Revenue: |  |  |  |  |  |
| Americas | $ | 29,161 |  |  | $ | 29,291 |  |  | $ | 30,927 |  |
| EMEA | 12,951 |  |  | 12,659 |  |  | 13,100 |  |
| APJC | 7,706 |  |  | 7,352 |  |  | 7,877 |  |
| Total | $ | 49,818 |  |  | $ | 49,301 |  |  | $ | 51,904 |  |
| Gross margin: |  |  |  |  |  |
| Americas | $ | 19,499 |  |  | $ | 19,547 |  |  | $ | 20,338 |  |
| EMEA | 8,466 |  |  | 8,304 |  |  | 8,457 |  |
| APJC | 4,949 |  |  | 4,688 |  |  | 4,683 |  |
| Segment total | 32,914 |  |  | 32,538 |  |  | 33,479 |  |
| Unallocated corporate items | (1,020) |  |  | (855) |  |  | (813) |  |
| Total | $ | 31,894 |  |  | $ | 31,683 |  |  | $ | 32,666 |  |

[0000858877-21-000013:notes:367]
Amounts may not sum due to rounding.

[0000858877-21-000013:notes:368]
Revenue in the United States was $26.1 billion, $26.1 billion, and $27.4 billion for fiscal 2021, 2020, and 2019, respectively.

[0000858877-21-000013:notes:369]
(b)Revenue for Groups of Similar Products and Services

[0000858877-21-000013:notes:370]
We design and sell IP-based networking and other products related to the communications and IT industry and provide services associated with these products and their use.

[0000858877-21-000013:notes:371]
(c)Additional Segment Information

[0000858877-21-000013:notes:372]
The majority of our assets as of July 31, 2021 and July 25, 2020 were attributable to our U.S. operations. In fiscal 2021, 2020, and 2019, no single customer accounted for 10% or more of revenue.

[0000858877-21-000013:notes:373]
Our long-lived assets are based on the physical location of the assets. The following table presents our long-lived assets, which consists of property and equipment, net and operating lease right-of-use assets information for geographic areas (in millions):

[0000858877-21-000013:notes:374]
|  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Long-lived assets: |  |  |  |  |  |
| United States | $ | 2,189 |  |  | $ | 2,328 |  |  | $ | 2,266 |  |
| International | 1,244 |  |  | 1,046 |  |  | 523 |  |
| Total | $ | 3,433 |  |  | $ | 3,374 |  |  | $ | 2,789 |  |


## us-gaap:EarningsPerShareTextBlock

[0000858877-21-000013:notes:375]
Net Income per Share 
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-21-000013:notes:376]
| Years Ended | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Net income | $ | 10,591 |  |  | $ | 11,214 |  |  | $ | 11,621 |  |
| Weighted-average shares—basic | 4,222 |  |  | 4,236 |  |  | 4,419 |  |
| Effect of dilutive potential common shares | 14 |  |  | 18 |  |  | 34 |  |
| Weighted-average shares—diluted | 4,236 |  |  | 4,254 |  |  | 4,453 |  |
| Net income per share—basic | $ | 2.51 |  |  | $ | 2.65 |  |  | $ | 2.63 |  |
| Net income per share—diluted | $ | 2.50 |  |  | $ | 2.64 |  |  | $ | 2.61 |  |
| Antidilutive employee share-based awards, excluded | 69 |  |  | 76 |  |  | 55 |  |

[0000858877-21-000013:notes:377]
Employee equity share options, unvested shares, and similar equity instruments granted and assumed by us are treated as potential common shares outstanding in computing diluted earnings per share. Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that has not yet been recognized are collectively assumed to be used to repurchase shares.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000858877-21-000013:notes:378]
SCHEDULE II

[0000858877-21-000013:notes:379]
VALUATION AND QUALIFYING ACCOUNTS

[0000858877-21-000013:notes:380]
(in millions)

[0000858877-21-000013:notes:381]
|  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Allowance for Accounts Receivable: |  |  |  |  |  |
| Balance at beginning of fiscal year | $ | 143 |  |  | $ | 136 |  |  | $ | 129 |  |
| Provisions (benefits) | 21 |  |  | 55 |  |  | 56 |  |
| Recoveries (write-offs), net | (29) |  |  | (48) |  |  | (50) |  |
| Foreign exchange and other | (26) |  |  | — |  |  | 1 |  |
| Balance at end of fiscal year | $ | 109 |  |  | $ | 143 |  |  | $ | 136 |  |
| Allowance for Financing Receivables: |  |  |  |  |  |
| Balance at beginning of fiscal year | $ | 138 |  |  | $ | 126 |  |  | $ | 205 |  |
| Provisions (benefits) | (27) |  |  | 38 |  |  | (16) |  |
| Recoveries (write-offs), net | (2) |  |  | (22) |  |  | (42) |  |
| Foreign exchange and other | 18 |  |  | (4) |  |  | (21) |  |
| Balance at end of fiscal year | $ | 127 |  |  | $ | 138 |  |  | $ | 126 |  |
| Deferred Tax Asset Valuation Allowance: |  |  |  |  |  |
| Balance at beginning of fiscal year | $ | 700 |  |  | $ | 457 |  |  | $ | 374 |  |
| Additions | 91 |  |  | 279 |  |  | 112 |  |
| Deductions | (5) |  |  | (29) |  |  | (20) |  |
| Write-offs | (16) |  |  | (7) |  |  | (8) |  |
| Foreign exchange and other | 1 |  |  | — |  |  | (1) |  |
| Balance at end of fiscal year | $ | 771 |  |  | $ | 700 |  |  | $ | 457 |  |
