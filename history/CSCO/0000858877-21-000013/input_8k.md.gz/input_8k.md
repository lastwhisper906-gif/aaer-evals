# CSCO 8-K — 0001193125-21-250360 filed 2021-08-18

## item codes, every 8-K on or before 2021-09-09

- 2021-08-18 0001193125-21-250360 — 2.02, 9.01
- 2021-06-29 0001193125-21-203324 — 8.01
- 2021-05-19 0001193125-21-166614 — 2.02, 9.01
- 2021-05-14 0001193125-21-162081 — 1.01, 2.03, 9.01
- 2021-03-08 0001193125-21-073328 — 5.02
- 2021-02-25 0001193125-21-056977 — 5.02
- 2021-02-09 0001193125-21-034339 — 2.02, 9.01
- 2021-01-07 0001193125-21-004250 — 5.02
- 2020-12-17 0001193125-20-320092 — 5.02, 8.01
- 2020-12-11 0001193125-20-315999 — 5.02, 5.07, 9.01
- 2020-11-30 0001193125-20-305352 — 5.02
- 2020-11-13 0001193125-20-293020 — 5.02, 9.01
- 2020-11-12 0001193125-20-291658 — 2.02, 9.01
- 2020-10-09 0001193125-20-267248 — 5.03, 9.01
- 2020-09-23 0001193125-20-252356 — 8.01
- 2020-08-12 0001193125-20-217756 — 5.02
- 2020-08-12 0001193125-20-217658 — 2.02, 2.05, 9.01
- 2020-06-22 0001193125-20-175641 — 8.01
- 2020-05-13 0001193125-20-141598 — 2.02, 9.01
- 2020-03-13 0001193125-20-072960 — 5.02
- 2020-03-06 0001193125-20-065138 — 5.02
- 2020-02-12 0001193125-20-033208 — 2.02, 9.01
- 2020-01-27 0001193125-20-015453 — 5.02
- 2019-12-23 0001193125-19-322662 — 8.01
- 2019-12-12 0001193125-19-312796 — 8.01
- 2019-12-11 0001193125-19-311525 — 5.07
- 2019-12-04 0001193125-19-306229 — 8.01
- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2021-09-09

- none on or before 2021-09-09

## item 2.02 — earnings release, exhibit 99.1

[0001193125-21-250360:8k_2_02:1]
EX-99.1
2
d198426dex991.htm
EX-99.1

[0001193125-21-250360:8k_2_02:2]
EX-99.1

[0001193125-21-250360:8k_2_02:3]
Exhibit 99.1

[0001193125-21-250360:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-21-250360:8k_2_02:5]
CISCO REPORTS FOURTH QUARTER AND FISCAL YEAR 2021 EARNINGS

[0001193125-21-250360:8k_2_02:6]
News Summary:

[0001193125-21-250360:8k_2_02:7]
|  | • |  | Cisco ended fiscal 2021 strong with Q4 performance of $13.1 billion in revenue (up 8% year over year) and fiscal year revenue of $49.8 billion |

[0001193125-21-250360:8k_2_02:8]
|  | • |  | Double digit order growth across all customer markets and geographies, including product order growth of 31% - strongest year-over-year growth in over a decade |

[0001193125-21-250360:8k_2_02:9]
|  | • |  | Continued momentum in transforming our business delivering more software and subscriptions - achieved $4 billion in software revenue in Q4 (an increase of 6% with subscription revenue up 9% year over year) and $15 billion for the year (an increase of 7% with subscription revenue up 15% year over year) |

[0001193125-21-250360:8k_2_02:10]
|  | • |  | Q4 Results: |

[0001193125-21-250360:8k_2_02:11]
|  | • |  | Revenue: $13.1 billion |

[0001193125-21-250360:8k_2_02:12]
|  | • |  | Increase of 8% year over year |

[0001193125-21-250360:8k_2_02:13]
|  | • |  | Earnings per Share: GAAP: $0.71; Non-GAAP: $0.84 |

[0001193125-21-250360:8k_2_02:14]
|  | • |  | GAAP EPS increased 15% year over year |

[0001193125-21-250360:8k_2_02:15]
|  | • |  | Non-GAAP EPS increased 5% year over year |

[0001193125-21-250360:8k_2_02:16]
|  | • |  | FY 2021 Results: |

[0001193125-21-250360:8k_2_02:17]
|  | • |  | Revenue: $49.8 billion |

[0001193125-21-250360:8k_2_02:18]
|  | • |  | Increase of 1% year over year |

[0001193125-21-250360:8k_2_02:19]
|  | • |  | Earnings per Share: GAAP: $2.50; Non-GAAP: $3.22 |

[0001193125-21-250360:8k_2_02:20]
|  | • |  | GAAP EPS decreased 5% year over year |

[0001193125-21-250360:8k_2_02:21]
|  | • |  | Non-GAAP EPS was flat year over year |

[0001193125-21-250360:8k_2_02:22]
|  | • |  | Q1 Guidance: |

[0001193125-21-250360:8k_2_02:23]
|  | • |  | Revenue: 7.5% to 9.5% growth year over year |

[0001193125-21-250360:8k_2_02:24]
|  | • |  | Earnings per Share: GAAP: $0.61 to $0.66; Non-GAAP: $0.79 to $0.81 |

[0001193125-21-250360:8k_2_02:25]
|  | • |  | FY 2022 Guidance: |

[0001193125-21-250360:8k_2_02:26]
|  | • |  | Revenue: 5% to 7% growth year over year |

[0001193125-21-250360:8k_2_02:27]
|  | • |  | Earnings per Share: GAAP: $2.72 to $2.84; Non-GAAP: $3.38 to $3.45 |

[0001193125-21-250360:8k_2_02:28]
SAN JOSE, Calif. — August 18, 2021 — Cisco today reported fourth quarter and fiscal year results for the period ended
July 31, 2021. Cisco reported fourth quarter revenue of $13.1 billion, net income on a generally accepted accounting principles (GAAP) basis of $3.0 billion or $0.71 per share, and non-GAAP net
income of $3.6 billion or $0.84 per share.

[0001193125-21-250360:8k_2_02:29]
“We continue to see great momentum in our business as customers are looking to modernize their
organizations for agility and resiliency,” said Chuck Robbins, Chair and CEO of Cisco. “The demand for Cisco technology is strong with our Q4 performance marking the highest product order growth in over a decade. With the power of our
portfolio, we are well positioned to help our customers accelerate their digital transformation and thrive in a hybrid world.”

[0001193125-21-250360:8k_2_02:30]
“We executed
exceptionally well delivering strong results across revenue, non-GAAP net income, non-GAAP EPS and record operating cash flow,” said Scott Herren, CFO of Cisco.
“Our performance reflects the impact of our investments in high growth opportunities resulting in our strong product order growth. As we continue to drive our business model transformation to more recurring revenue, we now have built up over
$30 billion in remaining performance obligations.”

[0001193125-21-250360:8k_2_02:31]
1

[0001193125-21-250360:8k_2_02:32]
Q4 GAAP Results

[0001193125-21-250360:8k_2_02:33]
|  |  | Q4 FY 2021 |  |  | Q4 FY 2020 |  |  | Vs. Q4 FY 2020 |  |
| Revenue |  | $ | 13.1 billion |  |  | $ | 12.2 billion |  |  |  | 8 | % |
| Net Income |  | $ | 3.0 billion |  |  | $ | 2.6 billion |  |  |  | 14 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.71 |  |  | $ | 0.62 |  |  |  | 15 | % |

[0001193125-21-250360:8k_2_02:34]
Q4 Non-GAAP Results

[0001193125-21-250360:8k_2_02:35]
|  |  | Q4 FY 2021 |  |  | Q4 FY 2020 |  |  | Vs. Q4 FY 2020 |  |
| Net Income |  | $ | 3.6 billion |  |  | $ | 3.4 billion |  |  |  | 5 | % |
| EPS |  | $ | 0.84 |  |  | $ | 0.80 |  |  |  | 5 | % |

[0001193125-21-250360:8k_2_02:36]
Fiscal Year GAAP Results

[0001193125-21-250360:8k_2_02:37]
|  |  | FY 2021 |  |  | FY 2020 |  |  | Vs. FY 2020 |  |
| Revenue |  | $ | 49.8 billion |  |  | $ | 49.3 billion |  |  |  | 1 | % |
| Net Income |  | $ | 10.6 billion |  |  | $ | 11.2 billion |  |  |  | (6 | )% |
| EPS |  | $ | 2.50 |  |  | $ | 2.64 |  |  |  | (5 | )% |

[0001193125-21-250360:8k_2_02:38]
Fiscal Year Non-GAAP Results

[0001193125-21-250360:8k_2_02:39]
|  |  | FY 2021 |  |  | FY 2020 |  |  | Vs. FY 2020 |  |
| Net Income |  | $ | 13.6 billion |  |  | $ | 13.7 billion |  |  |  | — | % |
| EPS |  | $ | 3.22 |  |  | $ | 3.21 |  |  |  | — | % |

[0001193125-21-250360:8k_2_02:40]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-21-250360:8k_2_02:41]
2

[0001193125-21-250360:8k_2_02:42]
Financial Summary

[0001193125-21-250360:8k_2_02:43]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-21-250360:8k_2_02:44]
Q4 FY 2021 Highlights

[0001193125-21-250360:8k_2_02:45]
Revenue —
Total revenue was $13.1 billion, up 8%, with product revenue up 10% and service revenue up 3%. Revenue by geographic segment was: Americas up 8%, EMEA up 6%, and APJC up 13%. Product revenue was led by growth in Infrastructure
Platforms, up 13% and Security, up 1%. Applications was down 1%.

[0001193125-21-250360:8k_2_02:46]
Gross Margin — On a GAAP basis, total gross margin, product
gross margin, and service gross margin were 63.6%, 62.7%, and 66.2%, respectively, as compared with 63.2%, 61.2%, and 68.7%, respectively, in the fourth quarter of fiscal 2020.

[0001193125-21-250360:8k_2_02:47]
On a non-GAAP basis, total gross margin, product gross margin, and service gross margin were 65.6%, 65.0%, and 67.4%,
respectively, as compared with 65.0%, 63.2%, and 69.8%, respectively, in the fourth quarter of fiscal 2020.

[0001193125-21-250360:8k_2_02:48]
Total gross margins by geographic segment
were: 66.2% for the Americas, 65.0% for EMEA and 64.4% for APJC.

[0001193125-21-250360:8k_2_02:49]
Operating Expenses — On a GAAP basis, operating expenses were
$4.8 billion, up 8%, and were 36.3% of revenue. Non-GAAP operating expenses were $4.2 billion, up 8%, and were 32.1% of revenue.

[0001193125-21-250360:8k_2_02:50]
Operating Income — GAAP operating income was $3.6 billion, up 10%, with GAAP operating margin of 27.2%.
Non-GAAP operating income was $4.4 billion, up 10%, with non-GAAP operating margin at 33.5%.

[0001193125-21-250360:8k_2_02:51]
Provision for Income Taxes — The GAAP tax provision rate was 19.4%. The non-GAAP tax provision rate
was 19.3%.

[0001193125-21-250360:8k_2_02:52]
Net Income and EPS — On a GAAP basis, net income was $3.0 billion, an increase of 14%, and EPS was $0.71, an increase
of 15%. On a non-GAAP basis, net income was $3.6 billion, an increase of 5%, and EPS was $0.84, an increase of 5%.

[0001193125-21-250360:8k_2_02:53]
Cash Flow from Operating Activities — $4.5 billion for the fourth quarter of fiscal 2021, an increase of 18% compared with
$3.8 billion for the fourth quarter of fiscal 2020.

[0001193125-21-250360:8k_2_02:54]
FY 2021 Highlights

[0001193125-21-250360:8k_2_02:55]
Revenue — Total revenue was $49.8 billion, an increase of 1%.

[0001193125-21-250360:8k_2_02:56]
Net Income and EPS — On a GAAP basis, net income was $10.6 billion, a decrease of 6%, and EPS was $2.50, a decrease of 5%. On a non-GAAP basis, net income was $13.6 billion, flat compared to fiscal 2020, and EPS was flat at $3.22.

[0001193125-21-250360:8k_2_02:57]
Cash
Flow from Operating Activities — $15.5 billion for fiscal 2021, flat compared with fiscal 2020.

[0001193125-21-250360:8k_2_02:58]
3

[0001193125-21-250360:8k_2_02:59]
Balance Sheet and Other Financial Highlights

[0001193125-21-250360:8k_2_02:60]
Cash and Cash Equivalents and Investments — $24.5 billion at the end of the fourth quarter of fiscal 2021, compared with
$23.6 billion at the end of the third quarter of fiscal 2021, and compared with $29.4 billion at the end of fiscal 2020.

[0001193125-21-250360:8k_2_02:61]
Remaining
Performance Obligations — $30.9 billion, up 9% in total. Product remaining performance obligations were up 18% and service remaining performance obligations were up 3%.

[0001193125-21-250360:8k_2_02:62]
Deferred Revenue — $22.2 billion, up 8% in total, with deferred product revenue up 19%. Deferred service revenue was up 2%.

[0001193125-21-250360:8k_2_02:63]
Capital Allocation — In the fourth quarter of fiscal 2021, we returned $2.4 billion to stockholders through share buybacks and
dividends. We declared and paid a cash dividend of $0.37 per common share, or $1.6 billion, and repurchased approximately 15 million shares of common stock under our stock repurchase program at an average price of $53.30 per share for an
aggregate purchase price of $791 million. The remaining authorized amount for stock repurchases under the program is $7.9 billion with no termination date.

[0001193125-21-250360:8k_2_02:64]
Acquisitions

[0001193125-21-250360:8k_2_02:65]
In the fourth quarter of fiscal 2021, we
closed the following acquisitions:

[0001193125-21-250360:8k_2_02:66]
|  | • |  | Slido s.r.o., a privately held company that provides an audience interaction platform. |

[0001193125-21-250360:8k_2_02:67]
|  | • |  | Sedonasys Systems Ltd., a privately held company which offers products that enable multi-vendor, multi-domain automation, and software-defined networking. |

[0001193125-21-250360:8k_2_02:68]
|  | • |  | Kenna Security, Inc., a privately held cybersecurity company that provides risk-based vulnerability management technology which enables organizations to work cross-functionally to rapidly identify, prioritize and remediate cyber risks. |

[0001193125-21-250360:8k_2_02:69]
|  | • |  | Involvio LLC, a privately held company that offers a suite of education-focused products that help colleges and universities improve student experience, engagement, and retention. |

[0001193125-21-250360:8k_2_02:70]
|  | • |  | Socio Labs, Inc., a privately held company that offers a modern event technology platform designed to power the hybrid events of the future. |

[0001193125-21-250360:8k_2_02:71]
4

[0001193125-21-250360:8k_2_02:72]
Guidance

[0001193125-21-250360:8k_2_02:73]
Cisco expects to achieve the following results for the first quarter of fiscal 2022:

[0001193125-21-250360:8k_2_02:74]
| Q1 FY 2022 |  |  |
| Revenue |  | 7.5% to 9.5% growth Y/Y |
| Non-GAAP gross margin rate |  | 63.5% - 64.5% |
| Non-GAAP operating margin rate |  | 31.5% - 32.5% |
| Non-GAAP EPS |  | $0.79 - $0.81 |

[0001193125-21-250360:8k_2_02:75]
Cisco estimates that GAAP EPS will be $0.61 to $0.66 for the first quarter of fiscal 2022.

[0001193125-21-250360:8k_2_02:76]
Cisco expects to achieve the following results for fiscal 2022:

[0001193125-21-250360:8k_2_02:77]
| FY 2022 |  |  |
| Revenue |  | 5% to 7% growth Y/Y |
| Non-GAAP EPS |  | $3.38 - $3.45 |

[0001193125-21-250360:8k_2_02:78]
Cisco estimates that GAAP EPS will be $2.72 to $2.84 for fiscal 2022.

[0001193125-21-250360:8k_2_02:79]
Our Q1 FY 2022 and FY 2022 guidance assumes an effective tax provision rate of 19% for GAAP and non-GAAP results.

[0001193125-21-250360:8k_2_02:80]
A reconciliation between the Guidance on a GAAP and non-GAAP basis is provided in the tables entitled “GAAP to non-GAAP Guidance” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-21-250360:8k_2_02:81]
Editor’s Notes:

[0001193125-21-250360:8k_2_02:82]
|  | • |  | Q4 fiscal year 2021 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, August 18, 2021 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-21-250360:8k_2_02:83]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, August 18, 2021 to 4:00 p.m. Pacific Time, August 25, 2021 at 1-800-388-4923 (United States) or 1-203-369-3800 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-21-250360:8k_2_02:84]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, August 18, 2021. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-21-250360:8k_2_02:85]
5

[0001193125-21-250360:8k_2_02:86]
CISCO SYSTEMS, INC.

[0001193125-21-250360:8k_2_02:87]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-21-250360:8k_2_02:88]
(In millions, except per-share amounts)

[0001193125-21-250360:8k_2_02:89]
(Unaudited)

[0001193125-21-250360:8k_2_02:90]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 31,2021 |  |  | July 25,2020 |  |  | July 31,2021 |  |  | July 25,2020 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,716 |  |  | $ | 8,832 |  |  | $ | 36,014 |  |  | $ | 35,978 |  |
| Service |  |  | 3,410 |  |  |  | 3,322 |  |  |  | 13,804 |  |  |  | 13,323 |  |
| Total revenue |  |  | 13,126 |  |  |  | 12,154 |  |  |  | 49,818 |  |  |  | 49,301 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,628 |  |  |  | 3,429 |  |  |  | 13,300 |  |  |  | 13,199 |  |
| Service |  |  | 1,154 |  |  |  | 1,041 |  |  |  | 4,624 |  |  |  | 4,419 |  |
| Total cost of sales |  |  | 4,782 |  |  |  | 4,470 |  |  |  | 17,924 |  |  |  | 17,618 |  |
| GROSS MARGIN |  |  | 8,344 |  |  |  | 7,684 |  |  |  | 31,894 |  |  |  | 31,683 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,713 |  |  |  | 1,565 |  |  |  | 6,549 |  |  |  | 6,347 |  |
| Sales and marketing |  |  | 2,448 |  |  |  | 2,218 |  |  |  | 9,259 |  |  |  | 9,169 |  |
| General and administrative |  |  | 521 |  |  |  | 494 |  |  |  | 2,152 |  |  |  | 1,925 |  |
| Amortization of purchased intangible assets |  |  | 79 |  |  |  | 33 |  |  |  | 215 |  |  |  | 141 |  |
| Restructuring and other charges |  |  | 8 |  |  |  | 127 |  |  |  | 886 |  |  |  | 481 |  |
| Total operating expenses |  |  | 4,769 |  |  |  | 4,437 |  |  |  | 19,061 |  |  |  | 18,063 |  |
| OPERATING INCOME |  |  | 3,575 |  |  |  | 3,247 |  |  |  | 12,833 |  |  |  | 13,620 |  |
| Interest income |  |  | 130 |  |  |  | 187 |  |  |  | 618 |  |  |  | 920 |  |
| Interest expense |  |  | (98 | ) |  |  | (119 | ) |  |  | (434 | ) |  |  | (585 | ) |
| Other income (loss), net |  |  | 128 |  |  |  | (9 | ) |  |  | 245 |  |  |  | 15 |  |
| Interest and other income (loss), net |  |  | 160 |  |  |  | 59 |  |  |  | 429 |  |  |  | 350 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,735 |  |  |  | 3,306 |  |  |  | 13,262 |  |  |  | 13,970 |  |
| Provision for income taxes |  |  | 726 |  |  |  | 670 |  |  |  | 2,671 |  |  |  | 2,756 |  |
| NET INCOME |  | $ | 3,009 |  |  | $ | 2,636 |  |  | $ | 10,591 |  |  | $ | 11,214 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.71 |  |  | $ | 0.62 |  |  | $ | 2.51 |  |  | $ | 2.65 |  |
| Diluted |  | $ | 0.71 |  |  | $ | 0.62 |  |  | $ | 2.50 |  |  | $ | 2.64 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,216 |  |  |  | 4,227 |  |  |  | 4,222 |  |  |  | 4,236 |  |
| Diluted |  |  | 4,238 |  |  |  | 4,244 |  |  |  | 4,236 |  |  |  | 4,254 |  |

[0001193125-21-250360:8k_2_02:91]
6

[0001193125-21-250360:8k_2_02:92]
CISCO SYSTEMS, INC.

[0001193125-21-250360:8k_2_02:93]
REVENUE BY SEGMENT

[0001193125-21-250360:8k_2_02:94]
(In
millions, except percentages)

[0001193125-21-250360:8k_2_02:95]
|  |  | July 31, 2021 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,731 |  |  |  | 8 | % |  | $ | 29,161 |  |  |  | — | % |
| EMEA |  |  | 3,297 |  |  |  | 6 | % |  |  | 12,951 |  |  |  | 2 | % |
| APJC |  |  | 2,098 |  |  |  | 13 | % |  |  | 7,706 |  |  |  | 5 | % |
| Total |  | $ | 13,126 |  |  |  | 8 | % |  | $ | 49,818 |  |  |  | 1 | % |

[0001193125-21-250360:8k_2_02:96]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-21-250360:8k_2_02:97]
CISCO SYSTEMS, INC.

[0001193125-21-250360:8k_2_02:98]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-21-250360:8k_2_02:99]
(In percentages)

[0001193125-21-250360:8k_2_02:100]
|  |  | July 31, 2021 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 66.2 | % |  |  | 66.9 | % |
| EMEA |  |  | 65.0 | % |  |  | 65.4 | % |
| APJC |  |  | 64.4 | % |  |  | 64.2 | % |

[0001193125-21-250360:8k_2_02:101]
CISCO SYSTEMS, INC.

[0001193125-21-250360:8k_2_02:102]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-21-250360:8k_2_02:103]
(In millions, except percentages)

[0001193125-21-250360:8k_2_02:104]
|  |  | July 31, 2021 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,546 |  |  |  | 13 | % |  | $ | 27,109 |  |  |  | — | % |
| Applications |  |  | 1,344 |  |  |  | (1 | )% |  |  | 5,504 |  |  |  | (1 | )% |
| Security |  |  | 823 |  |  |  | 1 | % |  |  | 3,382 |  |  |  | 7 | % |
| Other Products |  |  | 4 |  |  |  | (42 | )% |  |  | 19 |  |  |  | (43 | )% |
| Total Product |  |  | 9,716 |  |  |  | 10 | % |  |  | 36,014 |  |  |  | — | % |
| Services |  |  | 3,410 |  |  |  | 3 | % |  |  | 13,804 |  |  |  | 4 | % |
| Total |  | $ | 13,126 |  |  |  | 8 | % |  | $ | 49,818 |  |  |  | 1 | % |

[0001193125-21-250360:8k_2_02:105]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-21-250360:8k_2_02:106]
7

[0001193125-21-250360:8k_2_02:107]
CISCO SYSTEMS, INC.

[0001193125-21-250360:8k_2_02:108]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-21-250360:8k_2_02:109]
(In millions)

[0001193125-21-250360:8k_2_02:110]
(Unaudited)

[0001193125-21-250360:8k_2_02:111]
|  |  | July 31,2021 |  |  | July 25,2020 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,175 |  |  | $ | 11,809 |  |
| Investments |  |  | 15,343 |  |  |  | 17,610 |  |
| Accounts receivable, net of allowance for doubtful accounts of $109 at July 31, 2021 and $143 at July 25, 2020 |  |  | 5,766 |  |  |  | 5,472 |  |
| Inventories |  |  | 1,559 |  |  |  | 1,282 |  |
| Financing receivables, net |  |  | 4,380 |  |  |  | 5,051 |  |
| Other current assets |  |  | 2,889 |  |  |  | 2,349 |  |
| Total current assets |  |  | 39,112 |  |  |  | 43,573 |  |
| Property and equipment, net |  |  | 2,338 |  |  |  | 2,453 |  |
| Financing receivables, net |  |  | 4,884 |  |  |  | 5,714 |  |
| Goodwill |  |  | 38,168 |  |  |  | 33,806 |  |
| Purchased intangible assets, net |  |  | 3,619 |  |  |  | 1,576 |  |
| Deferred tax assets |  |  | 4,360 |  |  |  | 3,990 |  |
| Other assets |  |  | 5,016 |  |  |  | 3,741 |  |
| TOTAL ASSETS |  | $ | 97,497 |  |  | $ | 94,853 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 2,508 |  |  | $ | 3,005 |  |
| Accounts payable |  |  | 2,362 |  |  |  | 2,218 |  |
| Income taxes payable |  |  | 801 |  |  |  | 839 |  |
| Accrued compensation |  |  | 3,818 |  |  |  | 3,122 |  |
| Deferred revenue |  |  | 12,148 |  |  |  | 11,406 |  |
| Other current liabilities |  |  | 4,620 |  |  |  | 4,741 |  |
| Total current liabilities |  |  | 26,257 |  |  |  | 25,331 |  |
| Long-term debt |  |  | 9,018 |  |  |  | 11,578 |  |
| Income taxes payable |  |  | 8,538 |  |  |  | 8,837 |  |
| Deferred revenue |  |  | 10,016 |  |  |  | 9,040 |  |
| Other long-term liabilities |  |  | 2,393 |  |  |  | 2,147 |  |
| Total liabilities |  |  | 56,222 |  |  |  | 56,933 |  |
| Total equity |  |  | 41,275 |  |  |  | 37,920 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 97,497 |  |  | $ | 94,853 |  |

[0001193125-21-250360:8k_2_02:112]
8

[0001193125-21-250360:8k_2_02:113]
CISCO SYSTEMS, INC.

[0001193125-21-250360:8k_2_02:114]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-21-250360:8k_2_02:115]
(In millions)

[0001193125-21-250360:8k_2_02:116]
(Unaudited)

[0001193125-21-250360:8k_2_02:117]
|  |  | Fiscal Year Ended |  |
|  |  | July 31,2021 |  |  | July 25,2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,591 |  |  | $ | 11,214 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,862 |  |  |  | 1,808 |  |
| Share-based compensation expense |  |  | 1,761 |  |  |  | 1,569 |  |
| Provision (benefit) for receivables |  |  | (6 | ) |  |  | 93 |  |
| Deferred income taxes |  |  | (384 | ) |  |  | (38 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (354 | ) |  |  | (138 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (107 | ) |  |  | (107 | ) |
| Inventories |  |  | (244 | ) |  |  | 84 |  |
| Financing receivables |  |  | 1,577 |  |  |  | (797 | ) |
| Other assets |  |  | (797 | ) |  |  | 96 |  |
| Accounts payable |  |  | (53 | ) |  |  | 141 |  |
| Income taxes, net |  |  | (549 | ) |  |  | (322 | ) |
| Accrued compensation |  |  | 643 |  |  |  | (78 | ) |
| Deferred revenue |  |  | 1,560 |  |  |  | 2,011 |  |
| Other liabilities |  |  | (46 | ) |  |  | (110 | ) |
| Net cash provided by operating activities |  |  | 15,454 |  |  |  | 15,426 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (9,328 | ) |  |  | (9,212 | ) |
| Proceeds from sales of investments |  |  | 3,373 |  |  |  | 5,631 |  |
| Proceeds from maturities of investments |  |  | 8,409 |  |  |  | 7,975 |  |
| Acquisitions, net of cash and cash equivalents acquired and divestitures |  |  | (7,038 | ) |  |  | (327 | ) |
| Purchases of investments in privately held companies |  |  | (175 | ) |  |  | (190 | ) |
| Return of investments in privately held companies |  |  | 194 |  |  |  | 224 |  |
| Acquisition of property and equipment |  |  | (692 | ) |  |  | (770 | ) |
| Proceeds from sales of property and equipment |  |  | 28 |  |  |  | 179 |  |
| Other |  |  | (56 | ) |  |  | (10 | ) |
| Net cash (used in) provided by investing activities |  |  | (5,285 | ) |  |  | 3,500 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 643 |  |  |  | 655 |  |
| Repurchases of common stock - repurchase program |  |  | (2,877 | ) |  |  | (2,659 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (636 | ) |  |  | (727 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | (5 | ) |  |  | (3,470 | ) |
| Repayments of debt |  |  | (3,000 | ) |  |  | (6,720 | ) |
| Dividends paid |  |  | (6,163 | ) |  |  | (6,016 | ) |
| Other |  |  | (1 | ) |  |  | 51 |  |
| Net cash used in financing activities |  |  | (12,039 | ) |  |  | (18,886 | ) |
| Net increase (decrease) in cash, cash equivalents, and restricted cash |  |  | (1,870 | ) |  |  | 40 |  |
| Cash, cash equivalents, and restricted cash, beginning of fiscal year |  |  | 11,812 |  |  |  | 11,772 |  |
| Cash, cash equivalents, and restricted cash, end of fiscal year |  | $ | 9,942 |  |  | $ | 11,812 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 438 |  |  | $ | 603 |  |
| Cash paid for income taxes, net |  | $ | 3,604 |  |  | $ | 3,116 |  |

[0001193125-21-250360:8k_2_02:118]
9

[0001193125-21-250360:8k_2_02:119]
CISCO SYSTEMS, INC.

[0001193125-21-250360:8k_2_02:120]
REMAINING PERFORMANCE OBLIGATIONS

[0001193125-21-250360:8k_2_02:121]
(In millions, except percentages)

[0001193125-21-250360:8k_2_02:122]
|  |  | July 31, 2021 |  |  | May 1, 2021 |  |  | July 25, 2020 |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Product |  | $ | 13,270 |  |  |  | 18 | % |  | $ | 11,903 |  |  |  | 15 | % |  | $ | 11,261 |  |  |  | 17 | % |
| Service |  |  | 17,623 |  |  |  | 3 | % |  |  | 16,235 |  |  |  | 7 | % |  |  | 17,093 |  |  |  | 9 | % |
| Total |  | $ | 30,893 |  |  |  | 9 | % |  | $ | 28,138 |  |  |  | 10 | % |  | $ | 28,354 |  |  |  | 12 | % |

[0001193125-21-250360:8k_2_02:123]
CISCO SYSTEMS, INC.

[0001193125-21-250360:8k_2_02:124]
DEFERRED REVENUE

[0001193125-21-250360:8k_2_02:125]
(In
millions)

[0001193125-21-250360:8k_2_02:126]
|  |  | July 31,2021 |  |  | May 1,2021 |  |  | July 25,2020 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,416 |  |  | $ | 8,698 |  |  | $ | 7,895 |  |
| Service |  |  | 12,748 |  |  |  | 12,191 |  |  |  | 12,551 |  |
| Total |  | $ | 22,164 |  |  | $ | 20,889 |  |  | $ | 20,446 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 12,148 |  |  | $ | 11,492 |  |  | $ | 11,406 |  |
| Noncurrent |  |  | 10,016 |  |  |  | 9,397 |  |  |  | 9,040 |  |
| Total |  | $ | 22,164 |  |  | $ | 20,889 |  |  | $ | 20,446 |  |

[0001193125-21-250360:8k_2_02:127]
CISCO SYSTEMS, INC.

[0001193125-21-250360:8k_2_02:128]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-21-250360:8k_2_02:129]
(In millions, except per-share amounts)

[0001193125-21-250360:8k_2_02:130]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | PerShare |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 31, 2021 |  | $ | 0.37 |  |  | $ | 1,562 |  |  |  | 15 |  |  | $ | 53.30 |  |  | $ | 791 |  |  | $ | 2,353 |  |
| May 1, 2021 |  | $ | 0.37 |  |  | $ | 1,560 |  |  |  | 10 |  |  | $ | 48.71 |  |  | $ | 510 |  |  | $ | 2,070 |  |
| January 23, 2021 |  | $ | 0.36 |  |  | $ | 1,521 |  |  |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |  | $ | 2,322 |  |
| October 24, 2020 |  | $ | 0.36 |  |  | $ | 1,520 |  |  |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |  | $ | 2,320 |  |
| Fiscal 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 25, 2020 |  | $ | 0.36 |  |  | $ | 1,525 |  |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,525 |  |
| April 25, 2020 |  | $ | 0.36 |  |  | $ | 1,519 |  |  |  | 25 |  |  | $ | 39.71 |  |  | $ | 981 |  |  | $ | 2,500 |  |
| January 25, 2020 |  | $ | 0.35 |  |  | $ | 1,486 |  |  |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |  | $ | 2,356 |  |
| October 26, 2019 |  | $ | 0.35 |  |  | $ | 1,486 |  |  |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |  | $ | 2,254 |  |

[0001193125-21-250360:8k_2_02:131]
10

[0001193125-21-250360:8k_2_02:132]
CISCO SYSTEMS, INC.

[0001193125-21-250360:8k_2_02:133]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-250360:8k_2_02:134]
GAAP TO NON-GAAP NET INCOME

[0001193125-21-250360:8k_2_02:135]
(In millions)

[0001193125-21-250360:8k_2_02:136]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 31,2021 |  |  | July 25,2020 |  |  | July 31,2021 |  |  | July 25,2020 |  |
| GAAP net income |  | $ | 3,009 |  |  | $ | 2,636 |  |  | $ | 10,591 |  |  | $ | 11,214 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 67 |  |  |  | 61 |  |  |  | 275 |  |  |  | 237 |  |
| Amortization of acquisition-related intangible assets |  |  | 199 |  |  |  | 157 |  |  |  | 698 |  |  |  | 611 |  |
| Acquisition-related/divestiture costs |  |  | 1 |  |  |  | — |  |  |  | 4 |  |  |  | 3 |  |
| Legal and indemnification settlements/charges |  |  | — |  |  |  | — |  |  |  | 43 |  |  |  | 4 |  |
| Total adjustments to GAAP cost of sales |  |  | 267 |  |  |  | 218 |  |  |  | 1,020 |  |  |  | 855 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 357 |  |  |  | 332 |  |  |  | 1,460 |  |  |  | 1,307 |  |
| Amortization of acquisition-related intangible assets |  |  | 79 |  |  |  | 33 |  |  |  | 215 |  |  |  | 141 |  |
| Acquisition-related/divestiture costs |  |  | 109 |  |  |  | 55 |  |  |  | 288 |  |  |  | 246 |  |
| Significant asset impairments and restructurings |  |  | 8 |  |  |  | 127 |  |  |  | 886 |  |  |  | 481 |  |
| Total adjustments to GAAP operating expenses |  |  | 553 |  |  |  | 547 |  |  |  | 2,849 |  |  |  | 2,175 |  |
| Adjustments to interest and other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | — |  |  |  | 4 |  |  |  | — |  |
| (Gains) and losses on equity investments |  |  | (154 | ) |  |  | 2 |  |  |  | (285 | ) |  |  | (97 | ) |
| Total adjustments to GAAP interest and other income (loss), net |  |  | (154 | ) |  |  | 2 |  |  |  | (281 | ) |  |  | (97 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 666 |  |  |  | 767 |  |  |  | 3,588 |  |  |  | 2,933 |  |
| Income tax effect of non-GAAP adjustments |  |  | (199 | ) |  |  | (175 | ) |  |  | (702 | ) |  |  | (722 | ) |
| Significant tax matters |  |  | 76 |  |  |  | 166 |  |  |  | 159 |  |  |  | 233 |  |
| Total adjustments to GAAP provision for income taxes |  |  | (123 | ) |  |  | (9 | ) |  |  | (543 | ) |  |  | (489 | ) |
| Non-GAAP net income |  | $ | 3,552 |  |  | $ | 3,394 |  |  | $ | 13,636 |  |  | $ | 13,658 |  |

[0001193125-21-250360:8k_2_02:137]
11

[0001193125-21-250360:8k_2_02:138]
CISCO SYSTEMS, INC.

[0001193125-21-250360:8k_2_02:139]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-250360:8k_2_02:140]
GAAP TO NON-GAAP EPS

[0001193125-21-250360:8k_2_02:141]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 31,2021 |  |  | July 25,2020 |  |  | July 31,2021 |  |  | July 25,2020 |  |
| GAAP EPS |  | $ | 0.71 |  |  | $ | 0.62 |  |  | $ | 2.50 |  |  | $ | 2.64 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.10 |  |  |  | 0.09 |  |  |  | 0.41 |  |  |  | 0.36 |  |
| Amortization of acquisition-related intangible assets |  |  | 0.07 |  |  |  | 0.04 |  |  |  | 0.22 |  |  |  | 0.18 |  |
| Acquisition-related/divestiture costs |  |  | 0.03 |  |  |  | 0.01 |  |  |  | 0.07 |  |  |  | 0.06 |  |
| Legal and indemnification settlements/charges |  |  | — |  |  |  | — |  |  |  | 0.01 |  |  |  | — |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | 0.03 |  |  |  | 0.21 |  |  |  | 0.11 |  |
| (Gains) and losses on equity investments |  |  | (0.04 | ) |  |  | — |  |  |  | (0.07 | ) |  |  | (0.02 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.05 | ) |  |  | (0.04 | ) |  |  | (0.17 | ) |  |  | (0.17 | ) |
| Significant tax matters |  |  | 0.02 |  |  |  | 0.04 |  |  |  | 0.04 |  |  |  | 0.05 |  |
| Non-GAAP EPS |  | $ | 0.84 |  |  | $ | 0.80 |  |  | $ | 3.22 |  |  | $ | 3.21 |  |

[0001193125-21-250360:8k_2_02:142]
Amounts may not sum due to rounding.

[0001193125-21-250360:8k_2_02:143]
12

[0001193125-21-250360:8k_2_02:144]
CISCO SYSTEMS, INC.

[0001193125-21-250360:8k_2_02:145]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-250360:8k_2_02:146]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-21-250360:8k_2_02:147]
(In millions, except percentages)

[0001193125-21-250360:8k_2_02:148]
|  |  | Three Months Ended |  |
|  |  | July 31, 2021 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 6,088 |  |  | $ | 2,256 |  |  | $ | 8,344 |  |  | $ | 4,769 |  |  |  | 8 | % |  | $ | 3,575 |  |  |  | 10 | % |  | $ | 160 |  |  | $ | 3,009 |  |  |  | 14 | % |
| % of revenue |  |  | 62.7 | % |  |  | 66.2 | % |  |  | 63.6 | % |  |  | 36.3 | % |  |  |  |  |  |  | 27.2 | % |  |  |  |  |  |  | 1.2 | % |  |  | 22.9 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 24 |  |  |  | 43 |  |  |  | 67 |  |  |  | 357 |  |  |  |  |  |  |  | 424 |  |  |  |  |  |  |  | — |  |  |  | 424 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 199 |  |  |  | — |  |  |  | 199 |  |  |  | 79 |  |  |  |  |  |  |  | 278 |  |  |  |  |  |  |  | — |  |  |  | 278 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 109 |  |  |  |  |  |  |  | 110 |  |  |  |  |  |  |  | — |  |  |  | 110 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 8 |  |  |  |  |  |  |  | 8 |  |  |  |  |  |  |  | — |  |  |  | 8 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (154 | ) |  |  | (154 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (123 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 6,312 |  |  | $ | 2,299 |  |  | $ | 8,611 |  |  | $ | 4,216 |  |  |  | 8 | % |  | $ | 4,395 |  |  |  | 10 | % |  | $ | 6 |  |  | $ | 3,552 |  |  |  | 5 | % |
| % of revenue |  |  | 65.0 | % |  |  | 67.4 | % |  |  | 65.6 | % |  |  | 32.1 | % |  |  |  |  |  |  | 33.5 | % |  |  |  |  |  |  | — | % |  |  | 27.1 | % |  |  |  |  |

[0001193125-21-250360:8k_2_02:149]
|  |  | Three Months Ended |  |
|  |  | July 25, 2020 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 5,403 |  |  | $ | 2,281 |  |  | $ | 7,684 |  |  | $ | 4,437 |  |  | $ | 3,247 |  |  | $ | 59 |  |  | $ | 2,636 |  |
| % of revenue |  |  | 61.2 | % |  |  | 68.7 | % |  |  | 63.2 | % |  |  | 36.5 | % |  |  | 26.7 | % |  |  | 0.5 | % |  |  | 21.7 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 24 |  |  |  | 37 |  |  |  | 61 |  |  |  | 332 |  |  |  | 393 |  |  |  | — |  |  |  | 393 |  |
| Amortization of acquisition-related intangible assets |  |  | 157 |  |  |  | — |  |  |  | 157 |  |  |  | 33 |  |  |  | 190 |  |  |  | — |  |  |  | 190 |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 55 |  |  |  | 55 |  |  |  | — |  |  |  | 55 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 127 |  |  |  | 127 |  |  |  | — |  |  |  | 127 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | 2 |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (9 | ) |
| Non-GAAP amount |  | $ | 5,584 |  |  | $ | 2,318 |  |  | $ | 7,902 |  |  | $ | 3,890 |  |  | $ | 4,012 |  |  | $ | 61 |  |  | $ | 3,394 |  |
| % of revenue |  |  | 63.2 | % |  |  | 69.8 | % |  |  | 65.0 | % |  |  | 32.0 | % |  |  | 33.0 | % |  |  | 0.5 | % |  |  | 27.9 | % |

[0001193125-21-250360:8k_2_02:150]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-21-250360:8k_2_02:151]
13

[0001193125-21-250360:8k_2_02:152]
CISCO SYSTEMS, INC.

[0001193125-21-250360:8k_2_02:153]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-250360:8k_2_02:154]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-21-250360:8k_2_02:155]
(In millions, except percentages)

[0001193125-21-250360:8k_2_02:156]
|  |  | Fiscal Year Ended |  |
|  |  | July 31, 2021 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 22,714 |  |  | $ | 9,180 |  |  | $ | 31,894 |  |  | $ | 19,061 |  |  |  | 6 | % |  | $ | 12,833 |  |  |  | (6 | )% |  | $ | 429 |  |  | $ | 10,591 |  |  |  | (6 | )% |
| % of revenue |  |  | 63.1 | % |  |  | 66.5 | % |  |  | 64.0 | % |  |  | 38.3 | % |  |  |  |  |  |  | 25.8 | % |  |  |  |  |  |  | 0.9 | % |  |  | 21.3 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 99 |  |  |  | 176 |  |  |  | 275 |  |  |  | 1,460 |  |  |  |  |  |  |  | 1,735 |  |  |  |  |  |  |  | — |  |  |  | 1,735 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 698 |  |  |  | — |  |  |  | 698 |  |  |  | 215 |  |  |  |  |  |  |  | 913 |  |  |  |  |  |  |  | — |  |  |  | 913 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 3 |  |  |  | 1 |  |  |  | 4 |  |  |  | 288 |  |  |  |  |  |  |  | 292 |  |  |  |  |  |  |  | 4 |  |  |  | 296 |  |  |  |  |  |
| Legal and indemnification settlements/charges |  |  | 43 |  |  |  | — |  |  |  | 43 |  |  |  | — |  |  |  |  |  |  |  | 43 |  |  |  |  |  |  |  | — |  |  |  | 43 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 886 |  |  |  |  |  |  |  | 886 |  |  |  |  |  |  |  | — |  |  |  | 886 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (285 | ) |  |  | (285 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (543 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 23,557 |  |  | $ | 9,357 |  |  | $ | 32,914 |  |  | $ | 16,212 |  |  |  | 2 | % |  | $ | 16,702 |  |  |  | — | % |  | $ | 148 |  |  | $ | 13,636 |  |  |  | — | % |
| % of revenue |  |  | 65.4 | % |  |  | 67.8 | % |  |  | 66.1 | % |  |  | 32.5 | % |  |  |  |  |  |  | 33.5 | % |  |  |  |  |  |  | 0.3 | % |  |  | 27.4 | % |  |  |  |  |

[0001193125-21-250360:8k_2_02:157]
|  |  | Fiscal Year Ended |  |
|  |  | July 25, 2020 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interest andotherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 22,779 |  |  | $ | 8,904 |  |  | $ | 31,683 |  |  | $ | 18,063 |  |  | $ | 13,620 |  |  | $ | 350 |  |  | $ | 11,214 |  |
| % of revenue |  |  | 63.3 | % |  |  | 66.8 | % |  |  | 64.3 | % |  |  | 36.6 | % |  |  | 27.6 | % |  |  | 0.7 | % |  |  | 22.7 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 93 |  |  |  | 144 |  |  |  | 237 |  |  |  | 1,307 |  |  |  | 1,544 |  |  |  | — |  |  |  | 1,544 |  |
| Amortization of acquisition-related intangible assets |  |  | 611 |  |  |  | — |  |  |  | 611 |  |  |  | 141 |  |  |  | 752 |  |  |  | — |  |  |  | 752 |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 3 |  |  |  | 3 |  |  |  | 246 |  |  |  | 249 |  |  |  | — |  |  |  | 249 |  |
| Legal and indemnification settlements |  |  | 4 |  |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  | 4 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 481 |  |  |  | 481 |  |  |  | — |  |  |  | 481 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (97 | ) |  |  | (97 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (489 | ) |
| Non-GAAP amount |  | $ | 23,487 |  |  | $ | 9,051 |  |  | $ | 32,538 |  |  | $ | 15,888 |  |  | $ | 16,650 |  |  | $ | 253 |  |  | $ | 13,658 |  |
| % of revenue |  |  | 65.3 | % |  |  | 67.9 | % |  |  | 66.0 | % |  |  | 32.2 | % |  |  | 33.8 | % |  |  | 0.5 | % |  |  | 27.7 | % |

[0001193125-21-250360:8k_2_02:158]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-21-250360:8k_2_02:159]
14

[0001193125-21-250360:8k_2_02:160]
CISCO SYSTEMS, INC.

[0001193125-21-250360:8k_2_02:161]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-21-250360:8k_2_02:162]
EFFECTIVE TAX RATE

[0001193125-21-250360:8k_2_02:163]
(In
percentages)

[0001193125-21-250360:8k_2_02:164]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 31,2021 |  |  | July 25,2020 |  |  | July 31,2021 |  |  | July 25,2020 |  |
| GAAP effective tax rate |  |  | 19.4 | % |  |  | 20.3 | % |  |  | 20.1 | % |  |  | 19.7 | % |
| Total adjustments to GAAP provision for income taxes |  |  | (0.1 | )% |  |  | (3.6 | )% |  |  | (1.0 | )% |  |  | (0.5 | )% |
| Non-GAAP effective tax rate |  |  | 19.3 | % |  |  | 16.7 | % |  |  | 19.1 | % |  |  | 19.2 | % |

[0001193125-21-250360:8k_2_02:165]
GAAP TO NON-GAAP GUIDANCE

[0001193125-21-250360:8k_2_02:166]
| Q1 FY 2022 |  | Gross Margin Rate |  | Operating MarginRate |  | Earnings perShare (1) |
| GAAP |  | 61.5% - 62.5% |  | 25% - 26% |  | $0.61 - $0.66 |
| Estimated adjustments for: |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.5% |  | $0.08 - $0.09 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 1.5% |  | 3.0% |  | $0.07 - $0.08 |
| Significant asset impairments and restructurings |  | — |  | — |  | $0.00 - $0.01 |
| Non-GAAP |  | 63.5% - 64.5% |  | 31.5% - 32.5% |  | $0.79 - $0.81 |

[0001193125-21-250360:8k_2_02:167]
| FY 2022 |  | Earnings perShare (1) |  |
| GAAP |  | $ | 2.72 - $2.84 |  |
| Estimated adjustments for: |  |  |  |  |
| Share-based compensation expense |  | $ | 0.35 - $0.37 |  |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | $ | 0.26 - $0.28 |  |
| Significant asset impairments and restructurings |  | $ | 0.00 - $0.01 |  |
| Non-GAAP |  | $ | 3.38 - $3.45 |  |

[0001193125-21-250360:8k_2_02:168]
| (1) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-21-250360:8k_2_02:169]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and significant
tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-21-250360:8k_2_02:170]
15

[0001193125-21-250360:8k_2_02:171]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-21-250360:8k_2_02:172]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax rates,
non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross
margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-21-250360:8k_2_02:173]
These
non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles and may be different from
non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes
that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should
only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-21-250360:8k_2_02:174]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition
and its historical and projected results of operations.

[0001193125-21-250360:8k_2_02:175]
For its internal budgeting process, Cisco’s management uses financial statements that do not
include, when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other
contingencies, gains and losses on equity investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the
corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time
to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-21-250360:8k_2_02:176]
16

[0001193125-21-250360:8k_2_02:177]
About Cisco

[0001193125-21-250360:8k_2_02:178]
Cisco (Nasdaq: CSCO) is the worldwide leader in technology that powers the Internet. Cisco inspires new possibilities by reimagining your
applications, securing your data, transforming your infrastructure, and empowering your teams for a global and inclusive future. Discover more at newsroom.cisco.com and follow us on Twitter at @Cisco.

[0001193125-21-250360:8k_2_02:179]
Copyright © 2021 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are
trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their
respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-21-250360:8k_2_02:180]
RSS Feed for Cisco: https://newsroom.cisco.com/rss-feeds

[0001193125-21-250360:8k_2_02:181]
17
