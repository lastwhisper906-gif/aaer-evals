# CSCO MD&A — 0000858877-21-000013


## mdna

[0000858877-21-000013:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000858877-21-000013:mdna:2]
Forward-Looking Statements

[0000858877-21-000013:mdna:3]
OVERVIEW

[0000858877-21-000013:mdna:4]
Cisco designs and sells a broad range of technologies that power the Internet. We are integrating our platforms across networking, security, collaboration, applications and the cloud. These platforms are designed to help our customers manage more users, devices and things connecting to their networks. This will enable us to provide customers with a highly secure, intelligent platform for their digital business.

[0000858877-21-000013:mdna:5]
A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-21-000013:mdna:6]
|  | Three Months Ended |  | Years Ended |  |
|  | July 31, 2021 |  | July 25, 2020 |  | Variance |  | July 31, 2021 |  | July 25, 2020 |  | Variance |  |
| Revenue | $ | 13,126 |  |  | $ | 12,154 |  |  | 8 | % |  | $ | 49,818 |  |  | $ | 49,301 |  |  | 1 | % |  |
| Gross margin percentage | 63.6 | % |  | 63.2 | % |  | 0.4 |  | pts | 64.0 | % |  | 64.3 | % |  | (0.3) |  | pts |
| Research and development | $ | 1,713 |  |  | $ | 1,565 |  |  | 9 | % |  | $ | 6,549 |  |  | $ | 6,347 |  |  | 3 | % |  |
| Sales and marketing | $ | 2,448 |  |  | $ | 2,218 |  |  | 10 | % |  | $ | 9,259 |  |  | $ | 9,169 |  |  | 1 | % |  |
| General and administrative | $ | 521 |  |  | $ | 494 |  |  | 5 | % |  | $ | 2,152 |  |  | $ | 1,925 |  |  | 12 | % |  |
| Total R&D, sales and marketing, general and administrative | $ | 4,682 |  |  | $ | 4,277 |  |  | 9 | % |  | $ | 17,960 |  |  | $ | 17,441 |  |  | 3 | % |  |
| Total as a percentage of revenue | 35.7 | % |  | 35.2 | % |  | 0.5 |  | pts | 36.1 | % |  | 35.4 | % |  | 0.7 |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 79 |  |  | $ | 33 |  |  | 139 | % |  | $ | 215 |  |  | $ | 141 |  |  | 52 | % |  |
| Restructuring and other charges included in operating expenses | $ | 8 |  |  | $ | 127 |  |  | (94) | % |  | $ | 886 |  |  | $ | 481 |  |  | 84 | % |  |
| Operating income as a percentage of revenue | 27.2 | % |  | 26.7 | % |  | 0.5 |  | pts | 25.8 | % |  | 27.6 | % |  | (1.8) |  | pts |
| Interest and other income (loss), net | $ | 160 |  |  | $ | 59 |  |  | 171 | % |  | $ | 429 |  |  | $ | 350 |  |  | 23 | % |  |
| Income tax percentage | 19.4 | % |  | 20.3 | % |  | (0.9) |  | pts | 20.1 | % |  | 19.7 | % |  | 0.4 |  | pts |
| Net income | $ | 3,009 |  |  | $ | 2,636 |  |  | 14 | % |  | $ | 10,591 |  |  | $ | 11,214 |  |  | (6) | % |  |
| Net income as a percentage of revenue | 22.9 | % |  | 21.7 | % |  | 1.2 |  | pts | 21.3 | % |  | 22.7 | % |  | (1.4) |  | pts |
| Earnings per share—diluted | $ | 0.71 |  |  | $ | 0.62 |  |  | 15 | % |  | $ | 2.50 |  |  | $ | 2.64 |  |  | (5) | % |  |

[0000858877-21-000013:mdna:7]
Fiscal 2021 Compared with Fiscal 2020

[0000858877-21-000013:mdna:8]
In fiscal 2021, we delivered growth in revenue in a very challenging environment. As customers have accelerated their digitization and cloud investments stemming from the COVID-19 pandemic, we focused on executing and innovating to support and assist that transition. In the second half of fiscal 2021, we began to see customers prepare for office re-openings and hybrid work by increasing investments in their technologies. Total revenue increased by 1% compared with fiscal 2020. Our product revenue reflected growth in Security, partially offset by declines in Applications. Infrastructure Platforms was flat. We continued to make progress in the transition of our business model delivering increased software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-21-000013:mdna:9]
Within total revenue, product revenue was flat and service revenue increased by 4%. Fiscal 2021 had 53 weeks, compared with 52 weeks in fiscal 2020, thus our results for fiscal 2021 reflect an extra week compared with fiscal 2020. We estimate that a majority of our revenue increase was attributable to the extra week. In fiscal 2021, total software revenue was $15.0 billion across all product areas and service, an increase of 7%. Within total software revenue, subscription revenue increased 15%. Total gross margin decreased by 0.3 percentage points. Product gross margin decreased by 0.2 percentage points, due to lower productivity benefits largely driven by ongoing costs related to supply chain constraints. The effect of pricing erosion was moderate. We have partnered with several of our key suppliers utilizing our volume purchasing and extending supply coverage, including revising supplier arrangements, to address supply chain challenges. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 0.7 percentage points. The total impact associated with the extra week on our cost of sales and operating expenses was approximately $150 million (excluding the impact of share-based compensation expense). Operating income as a percentage of revenue decreased by 1.8 percentage points. We incurred restructuring and other charges of $886 million, which resulted in a decrease of 6% in net income and a decrease of 5% in diluted earnings per share.

[0000858877-21-000013:mdna:10]
In terms of our geographic segments, revenue from the Americas decreased by $0.1 billion, EMEA revenue increased by $0.3 billion and revenue in our APJC segment increased by $0.4 billion. The “BRICM” countries experienced a product revenue decline of 6% in the aggregate, driven by a decrease in product revenue across each of the BRICM countries with the exception of India.

[0000858877-21-000013:mdna:11]
From a customer market standpoint, we experienced product revenue growth in the public sector and service provider markets partially offset by declines in the enterprise and commercial markets. As fiscal 2021 progressed, we saw improvement in business momentum in our customer markets, which we believe was related to an improving global macroeconomic environment.

[0000858877-21-000013:mdna:12]
From a product category perspective, total product revenue was flat year over year, driven by growth in revenue in Security of 7%, offset by a product revenue decline in Applications of 1%. Infrastructure Platforms was flat.

[0000858877-21-000013:mdna:13]
Fourth Quarter Snapshot

[0000858877-21-000013:mdna:14]
For the fourth quarter of fiscal 2021, as compared with the fourth quarter of fiscal 2020, total revenue increased by 8%. Within total revenue, product revenue increased by 10% and service revenue increased by 3%. With regard to our geographic segment performance, on a year-over-year basis, revenue in the Americas, EMEA and APJC increased by 8%, 6% and 13%, respectively. From a product category perspective, we experienced product revenue growth in Infrastructure Platforms and Security, offset by declines in Applications. Total gross margin increased by 0.4 percentage points, driven by productivity benefits, and to a lesser extent, favorable product mix, partially offset by pricing erosion. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively increased by 0.5 percentage points. Operating income as a percentage of revenue increased by 0.5 percentage points. Net income increased by 14% and diluted earnings per share increased by 15%.

[0000858877-21-000013:mdna:15]
COVID-19 Pandemic Response Summary

[0000858877-21-000013:mdna:16]
During this extraordinary time, our priority has been supporting our employees, customers, partners and communities, while positioning Cisco for the future. The pandemic has driven organizations across the globe to digitize their operations and support remote workforces at a faster speed and greater scale than ever before. We remain focused on providing the technology and solutions our customers need to accelerate their digital organizations. The actions we have taken and are taking include:

[0000858877-21-000013:mdna:17]
Employees

[0000858877-21-000013:mdna:18]
•Most of our global workforce is working from home.

[0000858877-21-000013:mdna:19]
•Seamless transition to work from home with a long-standing flexible work policy, and we build the technologies that allow organizations to stay connected, secure and productive.

[0000858877-21-000013:mdna:20]
•For the remainder who must be in the office to perform their roles, we are focused on their health and safety, and are taking all of the necessary precautions.

[0000858877-21-000013:mdna:21]
Customer and Partners

[0000858877-21-000013:mdna:22]
•Provided a variety of free offers and trials for our Webex and security technologies as they dramatically shifted entire workforces to be remote.

[0000858877-21-000013:mdna:23]
Communities

[0000858877-21-000013:mdna:24]
•Committed significant funds to support both global and local pandemic response efforts.

[0000858877-21-000013:mdna:25]
•Provided technology and financial support for non-profits, first responders, and governments.

[0000858877-21-000013:mdna:26]
•Donated personal protective equipment to hospital workers including N95 masks and face shields 3D-printed by Cisco volunteers around the world.

[0000858877-21-000013:mdna:27]
We are moving towards a hybrid work model, giving our employees the flexibility to work offsite or at onsite Cisco locations.

[0000858877-21-000013:mdna:28]
Strategy and Priorities

[0000858877-21-000013:mdna:29]
As our customers add billions of new connections to their enterprises, and as more applications move to a multicloud environment, the network becomes even more critical. Our customers are navigating change at an unprecedented pace and our mission is to shape the future of the Internet by inspiring new possibilities for them by helping transform their infrastructure, expand applications and analytics, address their security needs, and empower their teams. We believe that our customers are looking for outcomes that are data-driven and provide meaningful business value through automation, security, and analytics across private, hybrid, and multicloud environments. Our strategy is to help our customers connect, secure, and automate in order to accelerate their digital agility in a cloud-first world.

[0000858877-21-000013:mdna:30]
For a full discussion of our strategy and priorities, see “Item 1. Business.”

[0000858877-21-000013:mdna:31]
Other Key Financial Measures

[0000858877-21-000013:mdna:32]
The following is a summary of our other key financial measures for fiscal 2021 compared with fiscal 2020 (in millions):

[0000858877-21-000013:mdna:33]
|  |  | Fiscal 2021 |  | Fiscal 2020 |
| Cash and cash equivalents and investments |  | $24,518 |  | $29,419 |
| Cash provided by operating activities |  | $15,454 |  | $15,426 |
| Deferred revenue |  | $22,164 |  | $20,446 |
| Repurchases of common stock—stock repurchase program |  | $2,902 |  | $2,619 |
| Dividends paid |  | $6,163 |  | $6,016 |
| Inventories |  | $1,559 |  | $1,282 |

[0000858877-21-000013:mdna:34]
CRITICAL ACCOUNTING ESTIMATES

[0000858877-21-000013:mdna:35]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-21-000013:mdna:36]
The inputs into certain of our judgments, assumptions and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The COVID-19 pandemic did not have a material impact on our significant judgments, assumptions and estimates that are reflected in our results for fiscal 2021. These estimates include: goodwill and identified purchased intangible assets and income taxes, among other items. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-21-000013:mdna:37]
Revenue Recognition

[0000858877-21-000013:mdna:38]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis.

[0000858877-21-000013:mdna:39]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-21-000013:mdna:40]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-21-000013:mdna:41]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable. If actual credits received by distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-21-000013:mdna:42]
See Note 3 to the Consolidated Financial Statements for more details.

[0000858877-21-000013:mdna:43]
33

[0000858877-21-000013:mdna:44]
Loss Contingencies

[0000858877-21-000013:mdna:45]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-21-000013:mdna:46]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-21-000013:mdna:47]
Goodwill and Purchased Intangible Asset Impairments

[0000858877-21-000013:mdna:48]
Our methodology for allocating the purchase price relating to purchase acquisitions is determined through established valuation techniques. Goodwill represents a residual value as of the acquisition date, which in most cases results in measuring goodwill as an excess of the purchase consideration transferred plus the fair value of any noncontrolling interest in the acquired company over the fair value of net assets acquired, including contingent consideration. We perform goodwill impairment tests on an annual basis in the fourth fiscal quarter and between annual tests in certain circumstances for each reporting unit. The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the new accounting guidance for the fair value measurement of nonfinancial assets.

[0000858877-21-000013:mdna:49]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in fiscal 2021, 2020, and 2019. For the annual impairment testing in fiscal 2021, the excess of the fair value over the carrying value for each of our reporting units was $80.3 billion for the Americas, $73.0 billion for EMEA, and $33.2 billion for APJC.

[0000858877-21-000013:mdna:50]
During the fourth quarter of fiscal 2021, we performed a sensitivity analysis for goodwill impairment with respect to each of our respective reporting units and determined that a hypothetical 10% decline in the fair value of each reporting unit would not result in an impairment of goodwill for any reporting unit.

[0000858877-21-000013:mdna:51]
The fair value of acquired technology and patents, as well as acquired technology under development, is determined at acquisition date primarily using the income approach, which discounts expected future cash flows to present value. The discount rates used in the present value calculations are typically derived from a weighted-average cost of capital analysis and then adjusted to reflect risks inherent in the development lifecycle as appropriate. We consider the pricing model for products related to these acquisitions to be standard within the high-technology communications industry, and the applicable discount rates represent the rates that market participants would use for valuation of such intangible assets.

[0000858877-21-000013:mdna:52]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. Our ongoing consideration of all the factors described previously could result in impairment charges in the future, which could adversely affect our net income.

[0000858877-21-000013:mdna:53]
Income Taxes

[0000858877-21-000013:mdna:54]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 20.1%, 19.7%, and 20.2% in fiscal 2021, 2020, and 2019, respectively.

[0000858877-21-000013:mdna:55]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.

[0000858877-21-000013:mdna:56]
Significant judgment is also required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000858877-21-000013:mdna:57]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to foreign-derived intangible income deduction, global intangible low-tax income and base erosion and anti-abuse tax laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 38 countries, including the United States, has made changes and is contemplating additional changes to numerous long-standing tax principles. There can be no assurance that these changes and any contemplated changes if finalized, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries was subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-21-000013:mdna:58]
35

[0000858877-21-000013:mdna:59]
RESULTS OF OPERATIONS

[0000858877-21-000013:mdna:60]
A discussion regarding our financial condition and results of operations for fiscal 2021 compared to fiscal 2020 is presented below. A discussion regarding our financial condition and results of operations for fiscal 2020 compared to fiscal 2019 can be found under Item 7 in our Annual Report on Form 10-K for the fiscal year ended July 25, 2020, filed with the SEC on September 3, 2020.

[0000858877-21-000013:mdna:61]
Revenue

[0000858877-21-000013:mdna:62]
The following table presents the breakdown of revenue between product and service (in millions, except percentages):

[0000858877-21-000013:mdna:63]
|  |  | Years Ended |  | 2021 vs. 2020 |
|  |  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 36,014 |  |  | $ | 35,978 |  |  | $ | 39,005 |  |  | $ | 36 |  |  | — | % |
| Percentage of revenue |  | 72.3 | % |  | 73.0 | % |  | 75.1 | % |  |  |  |  |
| Service |  | 13,804 |  |  | 13,323 |  |  | 12,899 |  |  | 481 |  |  | 4 | % |
| Percentage of revenue |  | 27.7 | % |  | 27.0 | % |  | 24.9 | % |  |  |  |  |
| Total |  | $ | 49,818 |  |  | $ | 49,301 |  |  | $ | 51,904 |  |  | $ | 517 |  |  | 1 | % |

[0000858877-21-000013:mdna:64]
We manage our business primarily on a geographic basis, organized into three geographic segments. Our revenue, which includes product and service for each segment, is summarized in the following table (in millions, except percentages):

[0000858877-21-000013:mdna:65]
|  |  | Years Ended |  | 2021 vs. 2020 |
|  |  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 29,161 |  |  | $ | 29,291 |  |  | $ | 30,927 |  |  | $ | (130) |  |  | — | % |
| Percentage of revenue |  | 58.5 | % |  | 59.4 | % |  | 59.6 | % |  |  |  |  |
| EMEA |  | 12,951 |  |  | 12,659 |  |  | 13,100 |  |  | 292 |  |  | 2 | % |
| Percentage of revenue |  | 26.0 | % |  | 25.7 | % |  | 25.2 | % |  |  |  |  |
| APJC |  | 7,706 |  |  | 7,352 |  |  | 7,877 |  |  | 354 |  |  | 5 | % |
| Percentage of revenue |  | 15.5 | % |  | 14.9 | % |  | 15.2 | % |  |  |  |  |
| Total |  | $ | 49,818 |  |  | $ | 49,301 |  |  | $ | 51,904 |  |  | $ | 517 |  |  | 1 | % |

[0000858877-21-000013:mdna:66]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-21-000013:mdna:67]
Total revenue in fiscal 2021 increased by 1% compared with fiscal 2020. Product revenue was flat and service revenue increased by 4%. Our total revenue reflected growth in EMEA and APJC. Americas was flat. Product revenue for the emerging countries of BRICM, in the aggregate, experienced a 6% product revenue decline, with decreases in each of these countries with the exception of India.

[0000858877-21-000013:mdna:68]
In addition to the impact of macroeconomic factors, including the IT spending environment and the level of spending by government entities, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple performance obligations; the mix of financing arrangements provided to channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment.

[0000858877-21-000013:mdna:69]
36

[0000858877-21-000013:mdna:70]
Product Revenue by Segment

[0000858877-21-000013:mdna:71]
The following table presents the breakdown of product revenue by segment (in millions, except percentages):

[0000858877-21-000013:mdna:72]
|  |  | Years Ended |  | 2021 vs. 2020 |
|  |  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 20,688 |  |  | $ | 21,006 |  |  | $ | 22,754 |  |  | $ | (318) |  |  | (2) | % |
| Percentage of product revenue |  | 57.5 | % |  | 58.4 | % |  | 58.3 | % |  |  |  |  |
| EMEA |  | 9,805 |  |  | 9,647 |  |  | 10,246 |  |  | 158 |  |  | 2 | % |
| Percentage of product revenue |  | 27.2 | % |  | 26.8 | % |  | 26.3 | % |  |  |  |  |
| APJC |  | 5,521 |  |  | 5,326 |  |  | 6,005 |  |  | 195 |  |  | 4 | % |
| Percentage of product revenue |  | 15.3 | % |  | 14.8 | % |  | 15.4 | % |  |  |  |  |
| Total |  | $ | 36,014 |  |  | $ | 35,978 |  |  | $ | 39,005 |  |  | $ | 36 |  |  | — | % |

[0000858877-21-000013:mdna:73]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-21-000013:mdna:74]
Americas

[0000858877-21-000013:mdna:75]
Product revenue in the Americas segment decreased by 2%. The product revenue decrease was driven by declines in the enterprise and commercial markets, partially offset by growth in the public sector and service provider markets. From a country perspective, product revenue decreased by 1% in the United States, 18% in Mexico, and 9% in Brazil, partially offset by a product revenue increase of 4% in Canada.

[0000858877-21-000013:mdna:76]
EMEA

[0000858877-21-000013:mdna:77]
The increase in product revenue in the EMEA segment of 2% was driven by growth in the service provider and public sector markets, partially offset by declines in the commercial and enterprise markets. Product revenue from emerging countries within EMEA decreased by 7%, and product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, increased by 4%. From a country perspective, product revenue increased by 4% in Germany, partially offset by declines in the United Kingdom and France by 1% and 2%, respectively.

[0000858877-21-000013:mdna:78]
APJC

[0000858877-21-000013:mdna:79]
Product revenue in the APJC segment increased by 4%, driven by growth in the public sector, service provider and enterprise markets, partially offset by declines in the commercial market. From a country perspective, product revenue increased in Japan, Australia and India by 11%, 6% and 3%, respectively, partially offset by a decline of 4% in China.

[0000858877-21-000013:mdna:80]
37

[0000858877-21-000013:mdna:81]
Product Revenue by Category

[0000858877-21-000013:mdna:82]
In addition to the primary view on a geographic basis, we also prepare financial information related to product categories and customer markets for various purposes. We report our product revenue in the following categories: Infrastructure Platforms, Applications, Security, and Other Products.

[0000858877-21-000013:mdna:83]
The following table presents product revenue by category (in millions, except percentages):

[0000858877-21-000013:mdna:84]
|  |  | Years Ended |  | 2021 vs. 2020 |
|  |  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 27,109 |  |  | $ | 27,219 |  |  | $ | 30,184 |  |  | $ | (110) |  |  | — | % |
| Applications |  | 5,504 |  |  | 5,568 |  |  | 5,803 |  |  | (64) |  |  | (1) | % |
| Security |  | 3,382 |  |  | 3,158 |  |  | 2,822 |  |  | 224 |  |  | 7 | % |
| Other Products |  | 19 |  |  | 33 |  |  | 196 |  |  | (14) |  |  | (43) | % |
| Total |  | $ | 36,014 |  |  | $ | 35,978 |  |  | $ | 39,005 |  |  | $ | 36 |  |  | — | % |

[0000858877-21-000013:mdna:85]
Amounts may not sum and percentages may not recalculate due to rounding. Prior period amounts have been reclassified to conform to the current period’s presentation.

[0000858877-21-000013:mdna:86]
Infrastructure Platforms

[0000858877-21-000013:mdna:87]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center. Infrastructure Platforms revenue was flat compared to fiscal 2020, with growth in routing and wireless, offset by declines in switching and data center. This was the product area most impacted by the COVID-19 pandemic environment in the first half of fiscal 2021. Switching revenue declined in both campus switching and data center switching, although we had strong revenue growth in our Catalyst 9000 Series, Meraki switching offerings and Nexus 9000 Series. We experienced an increase in sales of routing products, with growth primarily in the service provider market. Wireless had strong growth driven by our Meraki and WiFi-6 products. Revenue from data center declined driven by continued market contraction impacting primarily our servers products.

[0000858877-21-000013:mdna:88]
Applications

[0000858877-21-000013:mdna:89]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as IoT and AppDynamics analytics software offerings. Revenue in our Applications product category decreased by 1%, or $64 million, with a decline in Unified Communications and Cisco TelePresence partially offset by double digit growth in IoT software offerings and growth in Webex.

[0000858877-21-000013:mdna:90]
Security

[0000858877-21-000013:mdna:91]
Revenue in our Security product category increased 7%, or $224 million. Revenue from our cloud security portfolio reflected strong double-digit growth and continued momentum with our Duo and Umbrella offerings.

[0000858877-21-000013:mdna:92]
Service Revenue by Segment

[0000858877-21-000013:mdna:93]
The following table presents the breakdown of service revenue by segment (in millions, except percentages):

[0000858877-21-000013:mdna:94]
|  | Years Ended |  | 2021 vs. 2020 |
|  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 8,472 |  |  | $ | 8,285 |  |  | $ | 8,173 |  |  | $ | 187 |  |  | 2 | % |
| Percentage of service revenue | 61.4 | % |  | 62.2 | % |  | 63.4 | % |  |  |  |  |
| EMEA | 3,146 |  |  | 3,012 |  |  | 2,854 |  |  | 134 |  |  | 4 | % |
| Percentage of service revenue | 22.8 | % |  | 22.6 | % |  | 22.1 | % |  |  |  |  |
| APJC | 2,186 |  |  | 2,026 |  |  | 1,872 |  |  | 160 |  |  | 8 | % |
| Percentage of service revenue | 15.8 | % |  | 15.2 | % |  | 14.5 | % |  |  |  |  |
| Total | $ | 13,804 |  |  | $ | 13,323 |  |  | $ | 12,899 |  |  | $ | 481 |  |  | 4 | % |

[0000858877-21-000013:mdna:95]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-21-000013:mdna:96]
Service revenue increased 4%, driven by growth in our maintenance business and solution support offerings. Service revenue increased across all geographic segments. Service revenue benefited from the extra week in fiscal 2021.

[0000858877-21-000013:mdna:97]
Gross Margin

[0000858877-21-000013:mdna:98]
The following table presents the gross margin for products and services (in millions, except percentages):

[0000858877-21-000013:mdna:99]
|  | AMOUNT |  | PERCENTAGE |
| Years Ended | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 22,714 |  |  | $ | 22,779 |  |  | $ | 24,142 |  |  | 63.1 | % |  | 63.3 | % |  | 61.9 | % |
| Service | 9,180 |  |  | 8,904 |  |  | 8,524 |  |  | 66.5 | % |  | 66.8 | % |  | 66.1 | % |
| Total | $ | 31,894 |  |  | $ | 31,683 |  |  | $ | 32,666 |  |  | 64.0 | % |  | 64.3 | % |  | 62.9 | % |

[0000858877-21-000013:mdna:100]
Product Gross Margin

[0000858877-21-000013:mdna:101]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2020 to fiscal 2021:

[0000858877-21-000013:mdna:102]
|  |  | Product Gross Margin Percentage |
| Fiscal 2020 |  | 63.3 | % |
| Productivity (1) |  | 0.8 | % |
| Product pricing |  | (1.2) | % |
| Mix of products sold |  | 0.6 | % |
| Legal and indemnification charge |  | (0.1) | % |
| Others |  | (0.3) | % |
| Fiscal 2021 |  | 63.1 | % |

[0000858877-21-000013:mdna:103]
(1) Productivity includes overall manufacturing-related costs, such as component costs, warranty expense, provision for inventory, freight, logistics, shipment volume, and other items not categorized elsewhere.

[0000858877-21-000013:mdna:104]
Product gross margin decreased by 0.2 percentage points driven by pricing erosion, partially offset by favorable product mix and lower productivity benefits. The effect of pricing erosion was moderate driven by typical market factors and impacted each of our geographic segments. Productivity improvements were adversely impacted by ongoing costs related to supply chain constraints. The favorable mix was driven by changes in the proportion of products sold from each of our product categories.

[0000858877-21-000013:mdna:105]
During fiscal 2021, we continued to manage through supply chain challenges seen industry wide due to component shortages, caused in part by the COVID-19 pandemic. These challenges resulted in increased costs (i.e. component costs, broker fees,

[0000858877-21-000013:mdna:106]
expedited freight and overtime) which had a negative impact on product gross margin, and extended lead times to us and our customers. We have partnered with several of our key suppliers utilizing our volume purchasing and extending supply coverage, including revising supplier arrangements, to address supply chain challenges. We believe these actions will enable us to optimize our access to critical components, including semiconductors. We expect these supply chain challenges to continue through at least the first half of fiscal 2022 and potentially into the second half of fiscal 2022.

[0000858877-21-000013:mdna:107]
Productivity improvements were driven by memory cost savings and other cost reductions including value engineering efforts (e.g. component redesign, board configuration, test processes and transformation processes) and continued operational efficiency in manufacturing operations.

[0000858877-21-000013:mdna:108]
Service Gross Margin

[0000858877-21-000013:mdna:109]
Our service gross margin percentage decreased by 0.3 percentage points primarily due to higher headcount-related and delivery costs, partially offset by higher sales volume and to a lesser extent, favorable mix of service offerings.

[0000858877-21-000013:mdna:110]
Our service gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-21-000013:mdna:111]
Gross Margin by Segment

[0000858877-21-000013:mdna:112]
The following table presents the total gross margin for each segment (in millions, except percentages):

[0000858877-21-000013:mdna:113]
|  |  | AMOUNT |  | PERCENTAGE |
| Years Ended |  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 19,499 |  |  | $ | 19,547 |  |  | $ | 20,338 |  |  | 66.9 | % |  | 66.7 | % |  | 65.8 | % |
| EMEA |  | 8,466 |  |  | 8,304 |  |  | 8,457 |  |  | 65.4 | % |  | 65.6 | % |  | 64.6 | % |
| APJC |  | 4,949 |  |  | 4,688 |  |  | 4,683 |  |  | 64.2 | % |  | 63.8 | % |  | 59.5 | % |
| Segment total |  | 32,914 |  |  | 32,538 |  |  | 33,479 |  |  | 66.1 | % |  | 66.0 | % |  | 64.5 | % |
| Unallocated corporate items (1) |  | (1,020) |  |  | (855) |  |  | (813) |  |  |  |  |  |  |  |
| Total |  | $ | 31,894 |  |  | $ | 31,683 |  |  | $ | 32,666 |  |  | 64.0 | % |  | 64.3 | % |  | 62.9 | % |

[0000858877-21-000013:mdna:114]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-21-000013:mdna:115]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-21-000013:mdna:116]
We experienced a gross margin percentage increase in our Americas segment due to favorable product mix and productivity improvements, partially offset by pricing erosion.

[0000858877-21-000013:mdna:117]
Gross margin in our EMEA segment decreased due to pricing erosion, partially offset by productivity improvements and, to a lesser extent, favorable product mix. Lower service gross margin also contributed to the decrease in the gross margin in this geographic segment.

[0000858877-21-000013:mdna:118]
The APJC segment gross margin percentage increase was due to productivity improvements and favorable product mix, partially offset by pricing erosion.

[0000858877-21-000013:mdna:119]
The gross margin percentage for a particular segment may fluctuate, and period-to-period changes in such percentages may or may not be indicative of a trend for that segment.

[0000858877-21-000013:mdna:120]
Research and Development (“R&D”), Sales and Marketing, and General and Administrative (“G&A”) Expenses

[0000858877-21-000013:mdna:121]
R&D, sales and marketing, and G&A expenses are summarized in the following table (in millions, except percentages):

[0000858877-21-000013:mdna:122]
|  |  | Years Ended |  | 2021 vs. 2020 |
|  |  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Research and development |  | $ | 6,549 |  |  | $ | 6,347 |  |  | $ | 6,577 |  |  | $ | 202 |  |  | 3 | % |
| Percentage of revenue |  | 13.1 | % |  | 12.9 | % |  | 12.7 | % |  |  |  |  |
| Sales and marketing |  | 9,259 |  |  | 9,169 |  |  | 9,571 |  |  | 90 |  |  | 1 | % |
| Percentage of revenue |  | 18.6 | % |  | 18.6 | % |  | 18.4 | % |  |  |  |  |
| General and administrative |  | 2,152 |  |  | 1,925 |  |  | 1,827 |  |  | 227 |  |  | 12 | % |
| Percentage of revenue |  | 4.3 | % |  | 3.9 | % |  | 3.5 | % |  |  |  |  |
| Total |  | $ | 17,960 |  |  | $ | 17,441 |  |  | $ | 17,975 |  |  | $ | 519 |  |  | 3 | % |
| Percentage of revenue |  | 36.1 | % |  | 35.4 | % |  | 34.6 | % |  |  |  |  |

[0000858877-21-000013:mdna:123]
Fiscal 2021 had an extra week compared to fiscal 2020. The extra week in fiscal 2021 contributed to the increase in headcount-related expenses in our R&D, sales and marketing, and G&A expenses.

[0000858877-21-000013:mdna:124]
R&D Expenses

[0000858877-21-000013:mdna:125]
R&D expenses increased due to higher headcount-related expenses, higher share-based compensation expense, higher acquisition-related costs and higher contracted services spending, partially offset by lower discretionary spending.

[0000858877-21-000013:mdna:126]
We continue to invest in R&D in order to bring a broad range of products to market in a timely fashion. If we believe that we are unable to enter a particular market in a timely manner with internally developed products, we may purchase or license technology from other businesses, or we may partner with or acquire businesses as an alternative to internal R&D.

[0000858877-21-000013:mdna:127]
Sales and Marketing Expenses

[0000858877-21-000013:mdna:128]
Sales and marketing expenses increased primarily due to higher headcount-related expenses, higher contracted services spending and higher share-based compensation expense, partially offset by lower discretionary spending.

[0000858877-21-000013:mdna:129]
G&A Expenses

[0000858877-21-000013:mdna:130]
G&A expenses increased due to the impact from the gain recognized on the sale of property in fiscal 2020 and higher headcount-related expenses.

[0000858877-21-000013:mdna:131]
Effect of Foreign Currency

[0000858877-21-000013:mdna:132]
In fiscal 2021, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $214 million, or 1.2%, compared with fiscal 2020.

[0000858877-21-000013:mdna:133]
Amortization of Purchased Intangible Assets

[0000858877-21-000013:mdna:134]
The following table presents the amortization of purchased intangible assets (in millions):

[0000858877-21-000013:mdna:135]
| Years Ended |  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 716 |  |  | $ | 659 |  |  | $ | 624 |  |
| Operating expenses |  | 215 |  |  | 141 |  |  | 150 |  |
| Total |  | $ | 931 |  |  | $ | 800 |  |  | $ | 774 |  |

[0000858877-21-000013:mdna:136]
The increase in amortization of purchased intangible assets was due largely to the amortization of purchased intangibles from our recent acquisitions.

[0000858877-21-000013:mdna:137]
Restructuring and Other Charges

[0000858877-21-000013:mdna:138]
The following table presents restructuring and other charges (in millions):

[0000858877-21-000013:mdna:139]
| Years Ended |  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Restructuring and other charges included in operating expenses |  | $ | 886 |  |  | $ | 481 |  |  | $ | 322 |  |

[0000858877-21-000013:mdna:140]
In the first quarter of fiscal 2021, we initiated a restructuring plan, which included a voluntary early retirement program, in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $900 million. In connection with this restructuring plan, we incurred charges of $881 million during fiscal 2021. We substantially completed the Fiscal 2021 Plan in fiscal 2021 and do not expect any remaining charges related to this plan to be material. We estimate the Fiscal 2021 Plan will generate cost savings of approximately $1.0 billion on an annualized basis.

[0000858877-21-000013:mdna:141]
We incurred total restructuring and other charges of $886 million in fiscal 2021. We incurred charges of $881 million related to the restructuring plan initiated during fiscal 2021 and the remainder of which was related to the restructuring plan announced during fiscal 2020.

[0000858877-21-000013:mdna:142]
Operating Income

[0000858877-21-000013:mdna:143]
The following table presents our operating income and our operating income as a percentage of revenue (in millions, except percentages):

[0000858877-21-000013:mdna:144]
| Years Ended |  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Operating income |  | $ | 12,833 |  |  | $ | 13,620 |  |  | $ | 14,219 |  |
| Operating income as a percentage of revenue |  | 25.8 | % |  | 27.6 | % |  | 27.4 | % |

[0000858877-21-000013:mdna:145]
Operating income decreased by 6%, and as a percentage of revenue operating income decreased by 1.8 percentage points. These changes resulted primarily from: higher restructuring and other charges and a gross margin percentage decrease (driven by pricing erosion, partially offset by productivity improvements and product mix), partially offset by a revenue increase.

[0000858877-21-000013:mdna:146]
Interest and Other Income (Loss), Net

[0000858877-21-000013:mdna:147]
Interest Income (Expense), Net   The following table summarizes interest income and interest expense (in millions):

[0000858877-21-000013:mdna:148]
|  | Years Ended |  | 2021 vs. 2020 |
|  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |  | Variance in Dollars |
| Interest income | $ | 618 |  |  | $ | 920 |  |  | $ | 1,308 |  |  | $ | (302) |  |
| Interest expense | (434) |  |  | (585) |  |  | (859) |  |  | 151 |  |
| Interest income (expense), net | $ | 184 |  |  | $ | 335 |  |  | $ | 449 |  |  | $ | (151) |  |

[0000858877-21-000013:mdna:149]
Interest income decreased driven by lower interest rates and lower average balances of cash and available-for-sale debt investments. The decrease in interest expense was driven by a lower average debt balance and the impact of lower effective interest rates.

[0000858877-21-000013:mdna:150]
42

[0000858877-21-000013:mdna:151]
Other Income (Loss), Net   The components of other income (loss), net, are summarized as follows (in millions):

[0000858877-21-000013:mdna:152]
|  | Years Ended |  | 2021 vs. 2020 |
|  | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |
| Available-for-sale debt investments | $ | 53 |  |  | $ | 42 |  |  | $ | (13) |  |  | $ | 11 |  |
| Marketable equity investments | 6 |  |  | (5) |  |  | (3) |  |  | 11 |  |
| Privately held investments | 266 |  |  | 95 |  |  | 6 |  |  | 171 |  |
| Net gains (losses) on investments | 325 |  |  | 132 |  |  | (10) |  |  | 193 |  |
| Other gains (losses), net | (80) |  |  | (117) |  |  | (87) |  |  | 37 |  |
| Other income (loss), net | $ | 245 |  |  | $ | 15 |  |  | $ | (97) |  |  | $ | 230 |  |

[0000858877-21-000013:mdna:153]
The change in net gains (losses) on available-for-sale debt investments was primarily attributable to higher realized gains as a result of market conditions, and the timing of sales of these investments. The change in net gains (losses) on marketable equity investments was attributable to market value fluctuations and the timing of recognition of gains and losses. The change in net gains (losses) on privately held investments was primarily due to higher net unrealized gains and lower impairment charges, partially offset by lower realized gains. The change in other gains (losses), net was primarily driven by lower donation expense and favorable impacts from our equity derivatives, partially offset by unfavorable impacts from foreign exchange.

[0000858877-21-000013:mdna:154]
Provision for Income Taxes

[0000858877-21-000013:mdna:155]
The provision for income taxes resulted in an effective tax rate of 20.1% for fiscal 2021, compared with 19.7% for fiscal 2020. The net 0.4 percentage points increase in the effective tax rate was primarily due to a decrease in the tax benefit from foreign income taxed at other than U.S. rates, offset by an increase in foreign-derived intangible income deduction and a decrease in state taxes.

[0000858877-21-000013:mdna:156]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 21% and for further explanation of our provision for income taxes, see Note 18 to the Consolidated Financial Statements.

[0000858877-21-000013:mdna:157]
43

[0000858877-21-000013:mdna:158]
LIQUIDITY AND CAPITAL RESOURCES

[0000858877-21-000013:mdna:159]
The following sections discuss the effects of changes in our balance sheet, our capital allocation strategy including stock repurchase program and dividends, our contractual obligations, and certain other commitments and activities on our liquidity and capital resources.

[0000858877-21-000013:mdna:160]
Balance Sheet and Cash Flows

[0000858877-21-000013:mdna:161]
Cash and Cash Equivalents and Investments  The following table summarizes our cash and cash equivalents and investments (in millions):

[0000858877-21-000013:mdna:162]
|  | July 31, 2021 |  | July 25, 2020 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 9,175 |  |  | $ | 11,809 |  |  | $ | (2,634) |  |
| Available-for-sale debt investments | 15,206 |  |  | 17,610 |  |  | (2,404) |  |
| Marketable equity securities | 137 |  |  | — |  |  | 137 |  |
| Total | $ | 24,518 |  |  | $ | 29,419 |  |  | $ | (4,901) |  |

[0000858877-21-000013:mdna:163]
The net decrease in cash and cash equivalents and investments from fiscal 2020 to fiscal 2021 was primarily driven by net cash paid for acquisitions and divestitures of $7.0 billion, cash returned to stockholders in the form of repurchases of common stock of $2.9 billion under the stock repurchase program and cash dividends of $6.2 billion, net decrease in debt of $3.0 billion, net increase in restricted cash of $0.8 billion, and capital expenditures of $0.7 billion. These uses of cash were partially offset by cash provided by operating activities of $15.5 billion.

[0000858877-21-000013:mdna:164]
In addition to cash requirements in the normal course of business, we have approximately $0.7 billion of the U.S. transition tax on accumulated earnings for foreign subsidiaries and $2.5 billion of long-term debt outstanding at July 31, 2021 that will mature within the next 12 months from the balance sheet date. See further discussion of liquidity and future payments under “Contractual Obligations” and “Liquidity and Capital Resource Requirements” below.

[0000858877-21-000013:mdna:165]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our available-for-sale debt investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position is critical at this time of uncertainty due to the COVID-19 pandemic and allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-21-000013:mdna:166]
Securities Lending  We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented.

[0000858877-21-000013:mdna:167]
Free Cash Flow and Capital Allocation  As part of our capital allocation strategy, we intend to return a minimum of 50% of our free cash flow annually to our stockholders through cash dividends and repurchases of common stock.

[0000858877-21-000013:mdna:168]
We define free cash flow as net cash provided by operating activities less cash used to acquire property and equipment. The following table reconciles our net cash provided by operating activities to free cash flow (in millions):

[0000858877-21-000013:mdna:169]
| Years Ended | July 31, 2021 |  | July 25, 2020 |  | July 27, 2019 |
| Net cash provided by operating activities | $ | 15,454 |  |  | $ | 15,426 |  |  | $ | 15,831 |  |
| Acquisition of property and equipment | (692) |  |  | (770) |  |  | (909) |  |
| Free cash flow | $ | 14,762 |  |  | $ | 14,656 |  |  | $ | 14,922 |  |

[0000858877-21-000013:mdna:170]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue and the timing and amount of tax and other payments. For additional discussion, see “Part I, Item 1A. Risk Factors” in this report.

[0000858877-21-000013:mdna:171]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to stockholders in the form of dividends and stock repurchases. We further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness. Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net cash provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-21-000013:mdna:172]
The following table summarizes the dividends paid and stock repurchases (in millions, except per-share amounts):

[0000858877-21-000013:mdna:173]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  | TOTAL |
| Years Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | Amount |
| July 31, 2021 |  | $ | 1.46 |  |  | $ | 6,163 |  |  | 64 |  |  | $ | 45.48 |  |  | $ | 2,902 |  |  | $ | 9,065 |  |
| July 25, 2020 |  | $ | 1.42 |  |  | $ | 6,016 |  |  | 59 |  |  | $ | 44.36 |  |  | $ | 2,619 |  |  | $ | 8,635 |  |
| July 27, 2019 |  | $ | 1.36 |  |  | $ | 5,979 |  |  | 418 |  |  | $ | 49.22 |  |  | $ | 20,577 |  |  | $ | 26,556 |  |

[0000858877-21-000013:mdna:174]
Any future dividends are subject to the approval of our Board of Directors.

[0000858877-21-000013:mdna:175]
The remaining authorized amount for stock repurchases under this program is approximately $7.9 billion, with no termination date.

[0000858877-21-000013:mdna:176]
Accounts Receivable, Net  The following table summarizes our accounts receivable, net (in millions):

[0000858877-21-000013:mdna:177]
|  | July 31, 2021 |  | July 25, 2020 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,766 |  |  | $ | 5,472 |  |  | $ | 294 |  |

[0000858877-21-000013:mdna:178]
Our accounts receivable net, as of July 31, 2021 increased by approximately 5% compared with the end of fiscal 2020.

[0000858877-21-000013:mdna:179]
Inventory Supply Chain  The following table summarizes our inventories (in millions):

[0000858877-21-000013:mdna:180]
|  | July 31, 2021 |  | July 25, 2020 |  | Increase (Decrease) |
| Inventories | $ | 1,559 |  |  | $ | 1,282 |  |  | $ | 277 |  |

[0000858877-21-000013:mdna:181]
Inventory as of July 31, 2021 increased by 22% from our inventory balance at the end of fiscal 2020. The increase in inventory was primarily due to an increase in raw materials, partially offset by a decrease in finished goods.

[0000858877-21-000013:mdna:182]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity.

[0000858877-21-000013:mdna:183]
Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term supply and pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. We believe our inventory and purchase commitments are in line with our current demand forecasts.

[0000858877-21-000013:mdna:184]
The following table summarizes our purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-21-000013:mdna:185]
| Commitments by Period | July 31, 2021 |  | July 25, 2020 |
| Less than 1 year | $ | 6,903 |  |  | $ | 3,994 |  |
| 1 to 3 years | 1,806 |  |  | 412 |  |
| 3 to 5 years | 1,545 |  |  | — |  |
| Total | $ | 10,254 |  |  | $ | 4,406 |  |

[0000858877-21-000013:mdna:186]
The increase in purchase commitments with contract manufacturers and suppliers compared with the end of fiscal 2020 was due to arrangements to secure long-term supply and pricing for certain product components for multi-year periods. We have partnered with several of our key suppliers utilizing our volume purchasing and extending supply coverage, including revising supplier arrangements, to address supply chain challenges.

[0000858877-21-000013:mdna:187]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of rapidly changing technology and customer requirements. We believe the amount of our inventory and purchase commitments is appropriate for our revenue levels.

[0000858877-21-000013:mdna:188]
Financing Receivables and Guarantees  The following table summarizes our financing receivables (in millions):

[0000858877-21-000013:mdna:189]
|  | July 31, 2021 |  | July 25, 2020 |  | Increase (Decrease) |
| Lease receivables, net | $ | 1,697 |  |  | $ | 2,088 |  |  | $ | (391) |  |
| Loan receivables, net | 5,117 |  |  | 5,856 |  |  | (739) |  |
| Financed service contracts, net | 2,450 |  |  | 2,821 |  |  | (371) |  |
| Total, net | $ | 9,264 |  |  | $ | 10,765 |  |  | $ | (1,501) |  |

[0000858877-21-000013:mdna:190]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services. The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed. Financing receivables decreased by 14%.

[0000858877-21-000013:mdna:191]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements to customers provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, with payment terms generally ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-21-000013:mdna:192]
The volume of channel partner financing was $26.7 billion, $26.9 billion, and $29.6 billion in fiscal 2021, 2020, and 2019, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.1 billion as of July 31, 2021 and July 25, 2020, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of July 31, 2021, the total maximum potential future payments related to these guarantees was approximately $160 million, of which approximately $21 million was recorded as deferred revenue.

[0000858877-21-000013:mdna:193]
Borrowings

[0000858877-21-000013:mdna:194]
Senior Notes  The following table summarizes the principal amount of our senior notes (in millions):

[0000858877-21-000013:mdna:195]
|  | Maturity Date |  | July 31, 2021 |  | July 25, 2020 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | — |  |  | $ | 2,500 |  |
| 2.90% | March 4, 2021 |  | — |  |  | 500 |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 11,500 |  |  | $ | 14,500 |  |

[0000858877-21-000013:mdna:196]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of July 31, 2021.

[0000858877-21-000013:mdna:197]
Our $2.0 billion senior fixed-rate notes with a maturity date of September 20, 2021 were redeemed on August 20, 2021, pursuant to our par call redemption option. The redemption price was equal to 100% of the principal amount plus any accrued and unpaid interest to, but excluding, August 20, 2021.

[0000858877-21-000013:mdna:198]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of July 31, 2021 and July 25, 2020.

[0000858877-21-000013:mdna:199]
Credit Facility  On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. The credit agreement is structured as an amendment and restatement of our 364-day credit agreement which would have terminated on May 14, 2021. As of July 31, 2021, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement. Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

[0000858877-21-000013:mdna:200]
Remaining Performance Obligations   The following table presents the breakdown of remaining performance obligations (in millions):

[0000858877-21-000013:mdna:201]
|  | July 31, 2021 |  | July 25, 2020 |  | Increase (Decrease) |
| Product | $ | 13,270 |  |  | $ | 11,261 |  |  | $ | 2,009 |  |
| Service | 17,623 |  |  | 17,093 |  |  | 530 |  |
| Total | $ | 30,893 |  |  | $ | 28,354 |  |  | $ | 2,539 |  |

[0000858877-21-000013:mdna:202]
Total remaining performance obligations increased 9% in fiscal 2021. Remaining performance obligations for product and service increased 18% and 3%, respectively, compared to fiscal 2020.

[0000858877-21-000013:mdna:203]
Deferred Revenue   The following table presents the breakdown of deferred revenue (in millions):

[0000858877-21-000013:mdna:204]
|  | July 31, 2021 |  | July 25, 2020 |  | Increase (Decrease) |
| Product | $ | 9,416 |  |  | $ | 7,895 |  |  | $ | 1,521 |  |
| Service | 12,748 |  |  | 12,551 |  |  | 197 |  |
| Total | $ | 22,164 |  |  | $ | 20,446 |  |  | $ | 1,718 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 12,148 |  |  | $ | 11,406 |  |  | $ | 742 |  |
| Noncurrent | 10,016 |  |  | 9,040 |  |  | 976 |  |
| Total | $ | 22,164 |  |  | $ | 20,446 |  |  | $ | 1,718 |  |

[0000858877-21-000013:mdna:205]
Total deferred revenue increased 8% in fiscal 2021. The increase in deferred product revenue of 19% was primarily due to increased deferrals related to our recurring software offerings. The increase in deferred service revenue was driven by the impact of contract renewals, partially offset by amortization of deferred service revenue.

[0000858877-21-000013:mdna:206]
Contractual Obligations

[0000858877-21-000013:mdna:207]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. In addition, we plan for and measure our liquidity and capital resources through an annual budgeting process. The following table summarizes our contractual obligations at July 31, 2021 (in millions):

[0000858877-21-000013:mdna:208]
|  | PAYMENTS DUE BY PERIOD |
| July 31, 2021 | Total |  | Less than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than 5 Years |
| Operating leases | $ | 1,245 |  |  | $ | 355 |  |  | $ | 474 |  |  | $ | 197 |  |  | $ | 219 |  |
| Purchase commitments with contract manufacturers and suppliers | 10,254 |  |  | 6,903 |  |  | 1,806 |  |  | 1,545 |  |  | — |  |
| Other purchase obligations | 1,074 |  |  | 584 |  |  | 336 |  |  | 96 |  |  | 58 |  |
| Senior notes | 11,500 |  |  | 2,500 |  |  | 2,250 |  |  | 1,250 |  |  | 5,500 |  |
| Transition tax payable | 6,910 |  |  | 727 |  |  | 2,091 |  |  | 4,092 |  |  | — |  |
| Other long-term liabilities | 1,428 |  |  | — |  |  | 291 |  |  | 160 |  |  | 977 |  |
| Total by period | $ | 32,411 |  |  | $ | 11,069 |  |  | $ | 7,248 |  |  | $ | 7,340 |  |  | $ | 6,754 |  |
| Other long-term liabilities (uncertainty in the timing of future payments) | 2,490 |  |  |  |  |  |  |  |  |  |
| Total | $ | 34,901 |  |  |  |  |  |  |  |  |  |

[0000858877-21-000013:mdna:209]
Operating Leases  For more information on our operating leases, see Note 8 to the Consolidated Financial Statements.

[0000858877-21-000013:mdna:210]
Purchase Commitments with Contract Manufacturers and Suppliers  We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. A significant portion of our reported estimated purchase

[0000858877-21-000013:mdna:211]
commitments arising from these agreements are firm, noncancelable, and unconditional commitments. We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. See further discussion in “Inventory Supply Chain.”

[0000858877-21-000013:mdna:212]
Other Purchase Obligations  Other purchase obligations represent an estimate of all contractual obligations in the ordinary course of business, other than operating leases and commitments with contract manufacturers and suppliers, for which we have not received the goods or services. Purchase orders are not included in the preceding table as they typically represent our authorization to purchase rather than binding contractual purchase obligations.

[0000858877-21-000013:mdna:213]
Long-Term Debt  The amount of long-term debt in the preceding table represents the principal amount of the respective debt instruments. See Note 12 to the Consolidated Financial Statements.

[0000858877-21-000013:mdna:214]
Transition Tax Payable  Transition tax payable represents future cash tax payments associated with the one-time U.S. transition tax on accumulated earnings of foreign subsidiaries as a result of the Tax Cuts and Jobs Act (“the Tax Act”). See Note 18 to the Consolidated Financial Statements.

[0000858877-21-000013:mdna:215]
Other Long-Term Liabilities  Other long-term liabilities primarily include noncurrent income taxes payable, accrued liabilities for deferred compensation, deferred tax liabilities, and certain other long-term liabilities. Due to the uncertainty in the timing of future payments, our noncurrent income taxes payable of approximately $2.4 billion and deferred tax liabilities of $134 million were presented as one aggregated amount in the total column on a separate line in the preceding table. Noncurrent income taxes payable include uncertain tax positions. See Note 18 to the Consolidated Financial Statements.

[0000858877-21-000013:mdna:216]
Other Commitments

[0000858877-21-000013:mdna:217]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or the continued employment with us of certain employees of the acquired entities. See Note 14 to the Consolidated Financial Statements.

[0000858877-21-000013:mdna:218]
We also have certain funding commitments primarily related to our privately held investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.2 billion and $0.3 billion as of July 31, 2021 and July 25, 2020, respectively.

[0000858877-21-000013:mdna:219]
Off-Balance Sheet Arrangements

[0000858877-21-000013:mdna:220]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of July 31, 2021 there were no material unconsolidated variable interest entities.

[0000858877-21-000013:mdna:221]
On an ongoing basis, we reassess our privately held investments and customer financings to determine if they are variable interest entities and if we would be regarded as the primary beneficiary pursuant to the applicable accounting guidance. As a result of this ongoing assessment, we may be required to make additional disclosures or consolidate these entities. Because we may not control these entities, we may not have the ability to influence these events.

[0000858877-21-000013:mdna:222]
We provide financing guarantees, which are generally for various third-party financing arrangements extended to our channel partners and end-user customers. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. See the previous discussion of these financing guarantees under “Financing Receivables and Guarantees.”

[0000858877-21-000013:mdna:223]
Liquidity and Capital Resource Requirements

[0000858877-21-000013:mdna:224]
While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to increased disruption and volatility in capital markets and credit markets. The pandemic and resulting economic uncertainty could adversely affect our liquidity and capital resources in the future. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.
