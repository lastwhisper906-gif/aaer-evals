# CSCO note change history — 0000858877-21-000004 → 0000858877-21-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-05-25):
[0000858877-21-000008:note_history:1]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.
  (was, 2021-02-16, similarity 0.9361):
[0000858877-21-000004:note_history:1]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of January 23, 2021 and July 25, 2020, we had total purchase commitments for inventory of $4.6 billion and $4.4 billion, respectively.

- added (2021-05-25):
[0000858877-21-000008:note_history:2]
The following table summarizes our purchase commitments with contract manufacturers and suppliers (in millions):

- added (2021-05-25):
[0000858877-21-000008:note_history:3]
| Commitments by Period | May 1,2021 |  | July 25,2020 |
| Less than 1 year | $ | 6,461 |  |  | $ | 3,994 |  |
| 1 to 3 years | 1,615 |  |  | 412 |  |
| 3 to 5 years | 1,733 |  |  | — |  |
| Total | $ | 9,809 |  |  | $ | 4,406 |  |

- changed (2021-05-25):
[0000858877-21-000008:note_history:4]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of May 1, 2021 and July 25, 2020, the liability for these purchase commitments was $129 million and $141 million, respectively, and was included in other current liabilities. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $35 million and $131 million for the first nine months of fiscal 2021 and 2020, respectively.
  (was, 2021-02-16, similarity 0.9692):
[0000858877-21-000004:note_history:4]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 23, 2021 and July 25, 2020, the liability for these purchase commitments was $152 million and $141 million, respectively, and was included in other current liabilities. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $44 million and $67 million for the first six months of fiscal 2021 and 2020, respectively.

- changed (2021-05-25):
[0000858877-21-000008:note_history:5]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1, 2021 |  | April 25, 2020 |  | May 1, 2021 |  | April 25, 2020 |
| Compensation expense related to acquisitions | $ | 66 |  |  | $ | 61 |  |  | $ | 182 |  |  | $ | 172 |  |
  (was, 2021-02-16, similarity 0.7382):
[0000858877-21-000004:note_history:5]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2021 |  | January 25, 2020 |  | January 23, 2021 |  | January 25, 2020 |
| Compensation expense related to acquisitions | $ | 59 |  |  | $ | 50 |  |  | $ | 116 |  |  | $ | 111 |  |

- changed (2021-05-25):
[0000858877-21-000008:note_history:6]
As of May 1, 2021, we estimated that future cash compensation expense of up to $616 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2021-02-16, similarity 0.9832):
[0000858877-21-000004:note_history:6]
As of January 23, 2021, we estimated that future cash compensation expense of up to $452 million may be required to be recognized pursuant to the applicable business combination agreements.

- changed (2021-05-25):
[0000858877-21-000008:note_history:7]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.2 billion and $0.3 billion as of May 1, 2021 and July 25, 2020, respectively.
  (was, 2021-02-16, similarity 0.917):
[0000858877-21-000004:note_history:7]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $0.3 billion as of each of January 23, 2021 and July 25, 2020.

- changed (2021-05-25):
[0000858877-21-000008:note_history:8]
|  | Nine Months Ended |
|  | May 1,2021 |  | April 25,2020 |
| Balance at beginning of period | $ | 331 |  |  | $ | 342 |  |
| Provisions for warranties issued | 382 |  |  | 423 |  |
| Adjustments for pre-existing warranties | 1 |  |  | (5) |  |
| Settlements | (373) |  |  | (436) |  |
| Balance at end of period | $ | 341 |  |  | $ | 324 |  |
  (was, 2021-02-16, similarity 0.9554):
[0000858877-21-000004:note_history:8]
|  | Six Months Ended |
|  | January 23,2021 |  | January 25,2020 |
| Balance at beginning of period | $ | 331 |  |  | $ | 342 |  |
| Provisions for warranties issued | 247 |  |  | 283 |  |
| Adjustments for pre-existing warranties | 4 |  |  | (3) |  |
| Settlements | (249) |  |  | (291) |  |
| Balance at end of period | $ | 333 |  |  | $ | 331 |  |

- changed (2021-05-25):
[0000858877-21-000008:note_history:9]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. During fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.6 billion and $6.3 billion for the third quarter of fiscal 2021 and 2020, respectively, and was $19.5 billion and $20.5 billion for the first nine months of fiscal 2021 and 2020, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.1 billion as of May 1, 2021 and July 25, 2020, respectively.
  (was, 2021-02-16, similarity 0.9752):
[0000858877-21-000004:note_history:9]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. During fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.7 billion and $6.6 billion for the second quarter of fiscal 2021 and 2020, respectively, and was $12.8 billion and $14.2 billion for the first six months of fiscal 2021 and 2020, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.1 billion as of January 23, 2021 and July 25, 2020, respectively.

- changed (2021-05-25):
[0000858877-21-000008:note_history:10]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $1 million and $2 million for the third quarter of fiscal 2021 and 2020, respectively, and was $8 million for each of the first nine months of fiscal 2021 and 2020.
  (was, 2021-02-16, similarity 0.8662):
[0000858877-21-000004:note_history:10]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $3 million and $1 million for the second quarter of fiscal 2021 and 2020, respectively, and was $8 million and $6 million for the first six months of fiscal 2021 and 2020, respectively.

- changed (2021-05-25):
[0000858877-21-000008:note_history:11]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at May 1, 2021 and July 25, 2020, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2021-02-16, similarity 0.9871):
[0000858877-21-000004:note_history:11]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 23, 2021 and July 25, 2020, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2021-05-25):
[0000858877-21-000008:note_history:12]
|  | May 1,2021 |  | July 25,2020 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 165 |  |  | $ | 198 |  |
| End user | 6 |  |  | 9 |  |
| Total | $ | 171 |  |  | $ | 207 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (16) |  |  | $ | (19) |  |
| End user | (6) |  |  | (9) |  |
| Total | $ | (22) |  |  | $ | (28) |  |
| Total | $ | 149 |  |  | $ | 179 |  |
  (was, 2021-02-16, similarity 0.9903):
[0000858877-21-000004:note_history:12]
|  | January 23,2021 |  | July 25,2020 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 205 |  |  | $ | 198 |  |
| End user | 8 |  |  | 9 |  |
| Total | $ | 213 |  |  | $ | 207 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (19) |  |  | $ | (19) |  |
| End user | (8) |  |  | (9) |  |
| Total | $ | (27) |  |  | $ | (28) |  |
| Total | $ | 186 |  |  | $ | 179 |  |

- added (2021-05-25):
[0000858877-21-000008:note_history:13]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

- added (2021-05-25):
[0000858877-21-000008:note_history:14]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations discussed in this section (e) due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these cases, and the unique facts and circumstances involved in each particular case and agreement. We are unable to reasonably estimate the ultimate outcome of the cases discussed below in this section (e), but we do not believe that any potential indemnity liability would be material, and historically, indemnity payments made by us have not had a material effect on our operating results, financial position, or cash flows.

- changed (2021-05-25):
[0000858877-21-000008:note_history:15]
Charter Communications, Inc. (“Charter”), which acquired Time Warner Cable (“TWC”) in May 2016, sought indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Following a trial on March 3, 2017, the jury found that TWC willfully infringed five patents and awarded Sprint $140 million in damages, as well as pre- and post-judgment interest of approximately $10 million. After the judgment was affirmed on appeal, Charter reported that it paid the judgment in full. We resolved Charter’s indemnity claim effective February 4, 2021 for an amount that does not have a material effect on our financial position.
  (was, 2021-02-16, similarity 0.7281):
[0000858877-21-000004:note_history:15]
Charter Communications, Inc. (“Charter”), which acquired Time Warner Cable (“TWC”) in May 2016, is seeking indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Sprint sought monetary damages, alleging that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. The Court awarded Sprint pre- and post-judgment interest of approximately $10 million and denied TWC’s post-trial motions and appeals. Charter reported that it paid the judgment in full. We resolved Charter’s indemnity claim effective February 4, 2021 for an amount that does not have a material effect on our financial position.

- added (2021-05-25):
[0000858877-21-000008:note_history:16]
We have been asked to indemnify certain of our service provider customers that have been subject to patent infringement claims asserted by ChanBond, LLC (“ChanBond”) in federal court in Delaware on September 21, 2015. ChanBond alleges that 13 service provider defendants, including among others, Comcast Corporation, Charter Communications, Inc. (“Charter”), Time Warner Cable, Inc. (subsequently acquired by Charter), Cox Communications, Inc. (“Cox”), and Cablevision Systems Corporation (subsequently acquired by Altice USA, Inc.), infringe three patents by providing high speed cable internet services to their customers utilizing cable modems and cable modem termination systems, consistent with the DOCSIS 3.0 standard, provided by us and other manufacturers generally used in combination with each other. ChanBond seeks monetary damages and injunctive relief against the service provider customers, although two of the asserted patents expire on June 19, 2021, and the third expires on September 17, 2021. The Court has set ChanBond’s case against Cox for trial on May 20, 2021. The other cases against the remaining service provider defendants have not yet been set for trial. We believe that the service provider defendants have strong non-infringement, invalidity and other defenses and that ChanBond will not be able to meet its burden required for injunctive relief.

- added (2021-05-25):
[0000858877-21-000008:note_history:17]
Verizon Communications Inc. has requested that we indemnify it and seven of its subsidiaries (collectively, “Verizon”) for a subset of the patent infringement claims asserted by Huawei Technologies Co. Ltd. (“Huawei”) in lawsuits filed against Verizon on February 5, 2020, in the United States District Court for the Eastern District of Texas (“E.D. Tex”) and the United States District Court for the Western District of Texas (“W.D. Tex”). In the E.D. Tex case, Huawei alleges infringement of four patents required to operate the G.709 standard adopted by the Telecommunication Standardization Sector of the International Telecommunications Union by using products supplied by us. Huawei seeks monetary damages. The E.D. Tex court has set a trial date for July 9, 2021. In the W.D. Tex case, Huawei alleges infringement of four patents, two patents involving Cisco

- added (2021-05-25):
[0000858877-21-000008:note_history:18]
Webex and Cisco video endpoints that allow content sharing in a video conference, and two patents involving Cisco routers that support Ethernet Flow Point functionality and/or specific network convergence functionalities. Huawei seeks monetary damages and injunctive relief in the W.D. Tex case. The W.D. Tex court has set a trial date for October 4, 2021. We believe that Verizon has strong defenses in the cases and that Huawei will not be able to meet its burden required for injunctive relief in the W.D. Tex case.

- changed (2021-05-25):
[0000858877-21-000008:note_history:19]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $149 million for the alleged evasion of import and other taxes, $735 million for interest, and $368 million for various penalties, all determined using an exchange rate as of May 1, 2021.
  (was, 2021-02-16, similarity 0.9966):
[0000858877-21-000004:note_history:19]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $148 million for the alleged evasion of import and other taxes, $728 million for interest, and $366 million for various penalties, all determined using an exchange rate as of January 23, 2021.

- changed (2021-05-25):
[0000858877-21-000008:note_history:20]
China     We are investigating allegations of a self-enrichment scheme involving now-former employees in China. Some of those employees are also alleged to have made or directed payments from the funds they received to various third parties, including employees of state-owned enterprises. We voluntarily disclosed this investigation to the Department of Justice (“DOJ”) and Securities and Exchange Commission (“SEC”). We take such allegations very seriously and we are providing results of our investigation to the DOJ and SEC. While the outcome of our investigation is currently not determinable, we do not expect that it will have a material adverse effect on our consolidated financial position, results of operations, or cash flows.
  (was, 2021-02-16, similarity 0.9777):
[0000858877-21-000004:note_history:20]
China     The Company is investigating allegations of a self-enrichment scheme involving now-former employees in China.  Some of those employees are also alleged to have made or directed payments from the funds they received to various third parties, including employees of state-owned enterprises. The Company voluntarily disclosed this investigation to the Department of Justice (“DOJ”) and Securities and Exchange Commission (“SEC”). We take such allegations very seriously and we are providing results of our investigation to the DOJ and SEC. While the outcome of our investigation is currently not determinable, we do not expect that it will have a material adverse effect on our consolidated financial position, results of operations, or cash flows.

- changed (2021-05-25):
[0000858877-21-000008:note_history:21]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware (“D. Del.”), accusing our products and services in the area of network intrusion detection of infringing two patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. On May 12, 2016, a jury returned a verdict finding willful infringement. The jury awarded SRI damages of $24 million. On May 25, 2017, the district court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit (“Federal Circuit”) on various grounds, and after various proceedings, on July 12, 2019, the Federal Circuit vacated the enhanced damages award; vacated and remanded in part the willful infringement finding; vacated and remanded the attorneys’ fees award for further proceedings; and affirmed the district court’s other findings. On April 1, 2020, the district court issued a final judgment on the remanded issues, finding no evidence of willful infringement and reinstating the $8 million award of attorneys’ fees. SRI appealed the judgment of no willful infringement to the Federal Circuit on April 3, 2020, and Cisco filed a cross-appeal on the attorneys’ fees award on April 9, 2020. Cisco has paid SRI $28 million, representing the portion of the judgment that the Federal Circuit previously affirmed, plus interest and royalties on post-verdict sales. While the remaining proceedings may result in an additional loss, we do not expect it to be material.
  (was, 2021-02-16, similarity 0.6466):
[0000858877-21-000004:note_history:21]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial started on May 2, 2016, and, on May 12, 2016, the jury returned a verdict finding willful infringement. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the District Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit on various grounds, and after various proceedings, on July 12, 2019, the Federal Circuit vacated the enhanced damages award; vacated and remanded in part the willful infringement finding; vacated and remanded the attorneys’ fees award for further proceedings; and affirmed the District Court’s other findings. On April 1, 2020, the District Court issued a final judgment on the remanded issues, finding no evidence of willful infringement and reinstating the $8 million award of attorneys’ fees. SRI appealed the judgment of no willful infringement to the Federal Circuit on April 3, 2020, and Cisco filed a cross-appeal on the attorneys’ fees award on April 9, 2020. Cisco has paid SRI $28.1 million, representing the portion of the judgment that the Federal Circuit previously affirmed, plus interest and royalties on post-verdict sales. While the remaining proceedings may result in an additional loss, we do not expect it to be material.

- added (2021-05-25):
[0000858877-21-000008:note_history:22]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office (“PTO”) to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal appealed the PTAB’s findings of unpatentability to the Federal Circuit. The Federal Circuit affirmed the PTAB’s findings of unpatentability as to

- added (2021-05-25):
[0000858877-21-000008:note_history:23]
three of the patents on March 10, 2021, and affirmed the PTAB’s findings of unpatentability as to the remaining four patents on May 11, 2021.

- added (2021-05-25):
[0000858877-21-000008:note_history:24]
From May 6, 2020 to June 25, 2020, the district court conducted a bench trial by videoconference on the claims in the five patents not subject to the IPR Proceedings. On October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The district court awarded Centripetal $1.9 billion, comprised of $756 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $14 million. The district court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $168 million and a maximum annual royalty of $300 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $84 million and a maximum annual royalty of $150 million. We believe that the district court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We have appealed the district court’s judgment as to the four patents found valid and infringed to the Federal Circuit, and we believe that any relief ultimately awarded would not be material. On October 28, 2020, by agreement of the parties, the district court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment.

- added (2021-05-25):
[0000858877-21-000008:note_history:25]
On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. district court proceedings, one of which has been invalidated by the PTAB. We believe we have strong defenses. Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of the cases at this time.

- added (2021-05-25):
[0000858877-21-000008:note_history:26]
Finjan     On January 6, 2017, Finjan, Inc. (“Finjan”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, originally seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Finjan alleged that Cisco’s AMP and ThreatGrid products and the URL rewrite feature of Cisco’s ESA Outbreak Filter product infringe five patents. On May 24, 2021, we resolved all claims for an amount that does not have a material effect on our financial position.

- changed (2021-05-25):
[0000858877-21-000008:note_history:27]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in E.D. Tex, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. As of November 27, 2020, the PTO preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings. On January 13, 2021, the court entered an order staying the case pending the conclusion of the ex parte reexamination proceedings. While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in court, we believe that any damages ultimately assessed would not be material.
  (was, 2021-02-16, similarity 0.9475):
[0000858877-21-000004:note_history:27]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three U.S. patents. As of November 27, 2020, the U.S. Patent & Trademark Office preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings. On January 13, 2021, the Court entered an order staying the case pending the conclusion of the ex parte reexamination proceedings. While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.

- added (2021-05-25):
[0000858877-21-000008:note_history:28]
On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) (which we subsequently acquired) in D. Del, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot has asserted in its E.D. Tex case. We are currently assessing this case. Due to the early stage of the litigation as well as uncertainties in the litigation processes, we are unable, at this time, to reasonably estimate a potential range of loss, if any, or the ultimate outcome of this litigation.

- added (2021-05-25):
[0000858877-21-000008:note_history:29]
Monarch     On January 21, 2020, Monarch Networking Solutions LLC (“Monarch”) asserted patent infringement claims against us in E.D. Tex alleging that certain Cisco routers and firewalls infringe three U.S. patents. Monarch seeks damages, including enhanced damages for alleged willful infringement, and a running royalty on future sales. The E.D. Tex court set trial to begin on July 12, 2021. On May 13, 2020, Monarch filed a second action against us in W.D. Tex, alleging that two factor authentication functionality in Duo and Meraki MR and MX access point products infringe one U.S. patent. Monarch seeks damages, including enhanced damages for alleged willful infringement, and a running royalty on future sales. The W.D. Tex court set trial to begin on November 14, 2021. While we believe that we have strong non-infringement and invalidity arguments, and that Monarch’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court, we believe that any damages ultimately assessed would not be material.

- added (2021-05-25):
[0000858877-21-000008:note_history:30]
Viasat     On January 21, 2016, Viasat, Inc. (“Viasat”) filed suit against Acacia (which we subsequently acquired) in the California Superior Court for San Diego County (“SDSC”) seeking unpaid royalties for breach of contract and the implied

- added (2021-05-25):
[0000858877-21-000008:note_history:31]
covenant of good faith and fair dealing, and damages for trade secret misappropriation for certain products (“Viasat 1”). Acacia counterclaimed for patent and trade secret misappropriation, contract, and unfair competition claims. On July 17, 2019, the jury found for Viasat on its contract claims, and awarded Viasat $49 million for unpaid royalties through 2018. The jury further found that Acacia willfully misappropriated Viasat’s trade secrets and awarded Viasat $1. On Acacia’s counterclaims, the jury found for Acacia on its contract and trade secret claims and awarded Acacia $1. Both Acacia and Viasat have pending appeals to the California Court of Appeal. On November 6, 2019, Viasat filed a second suit in SDSC, alleging contract and trade secret claims for Acacia products sold from January 1, 2019 forward (“Viasat 2”). On February 28, 2020, the court stayed Viasat 2 pending the appeal in Viasat 1. On June 9, 2020, Viasat filed a third suit in SDSC (“Viasat 3”). In Viasat 3, Viasat alleges contract and trade secrets claims for sales of additional Acacia products. On August 11, 2020, the court stayed Viasat 3 pending the appeal in Viasat 1.

- added (2021-05-25):
[0000858877-21-000008:note_history:32]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court - Business Litigation Session against ViaSat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation. On April 5, 2018, ViaSat counterclaimed with contract, trade secret, and unfair competition claims (collectively, with Viasat 1, Viasat 2 and Viasat 3, the “Viasat Cases”). On December 13, 2018, the Massachusetts court entered an order staying the Massachusetts litigation, which has been extended to June 30, 2021.

- changed (2021-05-25):
[0000858877-21-000008:note_history:33]
While we believe Acacia has strong defenses in each of the Viasat Cases, we are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If Acacia does not prevail, we believe that any relief ultimately assessed in any of the Viasat Cases would not be material.
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.
  (was, 2021-02-16, similarity 0.7725):
[0000858877-21-000004:note_history:33]
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of 
operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.

- removed (2021-05-25):
[0000858877-21-000004:note_history:34]
In the normal course of business, we indemnify other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

- removed (2021-05-25):
[0000858877-21-000004:note_history:35]
We also have been asked to indemnify certain of our service provider customers that have been subject to patent infringement claims asserted by Chanbond, LLC (“Chanbond”) in the United States District Court for the District of Delaware on September 21, 2015. Chanbond alleges that 13 service provider companies, including among others, Comcast Corporation, Charter Communications, Inc. (“Charter”), Time Warner Cable, Inc. (subsequently acquired by Charter), Cox Communications, Inc. (“Cox”), and Cablevision Systems Corporation, infringe three patents by providing high speed cable internet services to their customers utilizing cable modems and cable modem termination systems, consistent with the DOCSIS 3.0 standard, provided

- removed (2021-05-25):
[0000858877-21-000004:note_history:36]
by us and other manufacturers generally used in combination with each other. Chanbond seeks monetary damages and injunctive relief against the service provider customers, although two of the asserted patents expire on June 19, 2021, and the third expires on September 17, 2021. On October 13, 2020, the Court set Chanbond’s case against Cox for trial on May 17, 2021. The other cases against the remaining service provider defendants have not yet been set for trial. We believe that the service provider defendants have strong non-infringement, invalidity and other defenses and that Chanbond will not be able to meet its burden required for injunctive relief. Due to uncertainties surrounding the litigation processes, we are unable to reasonably estimate the ultimate outcome of the cases at this time, but should Chanbond prevail in its cases against the service provider defendants, we do not believe that any potential indemnity liability would be material.

- removed (2021-05-25):
[0000858877-21-000004:note_history:37]
It is not possible to determine the maximum potential amount under these indemnification agreements due to uncertainties in the litigation process, coordination with other suppliers and the defendants in these cases, and the unique facts and circumstances involved in each particular agreement. Historically, payments made by us under these agreements have not had a material effect on our operating results, financial position, or cash flows.

- removed (2021-05-25):
[0000858877-21-000004:note_history:38]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. Centripetal has appealed the PTAB’s findings of unpatentability to the United States Court of Appeals for the Federal Circuit. Starting on May 6, 2020 and concluding on June 25, 2020, the District Court conducted a bench trial by videoconference on the claims in the five patents not subject to the IPR Proceedings, including claims in three for which the PTAB declined to institute IPR Proceedings. Centripetal sought damages, enhanced damages for willful infringement, and broad injunctive relief. On October 5, 2020, the District Court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The Court awarded Centripetal $1.9 billion, comprised of $755.8 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $13.7 million. The Court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $167.7 million and a maximum annual royalty of $300.1 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $83.9 million and a maximum annual royalty of $150.0 million. We believe that the District Court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We intend to appeal the District Court’s judgment when it becomes final as to the four patents found valid and infringed to the United States Court of Appeals for the Federal Circuit, and we believe that any relief ultimately awarded would not be material. On October 28, 2020, by agreement of the parties, the District Court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment. On April 29, 2020 and April 30, 2020, Centripetal submitted complaints in the District Court of Dusseldorf in Germany against Cisco Systems GmbH and Cisco Systems, Inc., asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. District Court proceedings, one of which has been invalidated by the PTAB. We believe we have strong defenses. Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of the cases at this time.

- removed (2021-05-25):
[0000858877-21-000004:note_history:39]
Finjan     On January 6, 2017, Finjan, Inc. (“Finjan”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, originally seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Finjan alleges that Cisco’s AMP and ThreatGrid products and the URL rewrite feature of Cisco’s ESA Outbreak Filter product infringe five patents, four of which have now expired such that no injunctive relief is available on those patents. Finjan has conceded that they are not entitled to any pre-suit damages, accordingly it seeks approximately three weeks of damages for the alleged infringement of the 8,677,494 and 6,154,844 patents, approximately ten months of damages for the 6,804,780 patent, approximately three years of damages for the 7,647,633 patent, and approximately three-and-a-half years of past damages for the 8,141,154 patent and an ongoing royalty (instead of injunctive relief) until its expiration on December 12, 2025. The case is currently set for jury trial starting June 4, 2021. While we believe that we have strong non-infringement arguments, that the patents are invalid, that Finjan’s damages theories are not supported by prevailing law and that Finjan will not be able to meet its burden required for injunctive relief, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-05-25):
[0000858877-21-000008:note_history:40]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.
  (was, 2021-02-16, similarity 0.9954):
[0000858877-21-000004:note_history:40]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-05-25):
[0000858877-21-000008:note_history:41]
At our annual meeting of shareholders held on December 10, 2020, shareholders voted to approve changing our state of incorporation from California to Delaware. The reincorporation became effective January 25, 2021.

- changed (2021-05-25):
[0000858877-21-000008:note_history:42]
We have prepared the accompanying financial data as of May 1, 2021 and for the third quarter and first nine months of fiscal 2021 and 2020, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 25, 2020 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 25, 2020.
  (was, 2021-02-16, similarity 0.9881):
[0000858877-21-000004:note_history:42]
We have prepared the accompanying financial data as of January 23, 2021 and for the second quarter and first six months of fiscal 2021 and 2020, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 25, 2020 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 25, 2020.

- changed (2021-05-25):
[0000858877-21-000008:note_history:43]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of May 1, 2021, the results of operations, the statements of comprehensive income (loss) and the statements of equity for the third quarter and first nine months of fiscal 2021 and 2020, and the statements of cash flows for the first nine months of fiscal 2021 and 2020, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2021 are not necessarily indicative of the operating results for the full fiscal year or any future periods.
  (was, 2021-02-16, similarity 0.9605):
[0000858877-21-000004:note_history:43]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 23, 2021, the results of operations, the statements of comprehensive income (loss) and the statements of equity for the second quarter and first six months of fiscal 2021 and 2020, and the statements of cash flows for the first six months of fiscal 2021 and 2020, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2021 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2021-05-25):
[0000858877-21-000004:note_history:44]
At our annual meeting of shareholders held on December 10, 2020, shareholders voted to approve changing the state of incorporation from California to Delaware. The reincorporation became effective January 25, 2021.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-25):
[0000858877-21-000008:note_history:45]
|  | May 1, 2021 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 2,000 |  |  | 1.90 | % |  | $ | 3,005 |  |  | 2.07 | % |
  (was, 2021-02-16, similarity 0.9824):
[0000858877-21-000004:note_history:45]
|  | January 23, 2021 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 5,000 |  |  | 2.00 | % |  | $ | 3,005 |  |  | 2.07 | % |

- changed (2021-05-25):
[0000858877-21-000008:note_history:46]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of May 1, 2021 and July 25, 2020.
  (was, 2021-02-16, similarity 0.8625):
[0000858877-21-000004:note_history:46]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

- changed (2021-05-25):
[0000858877-21-000008:note_history:47]
|  |  |  | May 1, 2021 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | — |  |  | — |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | — |  |  | — |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.15% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.00% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.31% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 11,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (81) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 113 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 11,532 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 2,000 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,532 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 11,532 |  |  |  |  | $ | 14,583 |  |  |  |
  (was, 2021-02-16, similarity 0.9812):
[0000858877-21-000004:note_history:47]
|  |  |  | January 23, 2021 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | 2,500 |  |  | 2.30% |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.92% |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.17% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.04% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.33% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 14,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (84) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 138 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 14,554 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 5,000 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,554 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 14,554 |  |  |  |  | $ | 14,583 |  |  |  |

- changed (2021-05-25):
[0000858877-21-000008:note_history:48]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of May 1, 2021, we were in compliance with all debt covenants.
  (was, 2021-02-16, similarity 0.9908):
[0000858877-21-000004:note_history:48]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 23, 2021, we were in compliance with all debt covenants.

- changed (2021-05-25):
[0000858877-21-000008:note_history:49]
As of May 1, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2021-02-16, similarity 0.9774):
[0000858877-21-000004:note_history:49]
As of January 23, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2021-05-25):
[0000858877-21-000008:note_history:50]
| Fiscal Year | Amount |
| 2021 (remaining three months) | $ | — |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 11,500 |  |
  (was, 2021-02-16, similarity 0.9673):
[0000858877-21-000004:note_history:50]
| Fiscal Year | Amount |
| 2021 (remaining six months) | $ | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 14,500 |  |

- added (2021-05-25):
[0000858877-21-000008:note_history:51]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. The credit agreement is structured as an amendment and restatement of our 364-day credit agreement, which would have terminated on May 14, 2021. As of May 1, 2021, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the 364-day credit facility.

- added (2021-05-25):
[0000858877-21-000008:note_history:52]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

- removed (2021-05-25):
[0000858877-21-000004:note_history:53]
On May 15, 2020, we entered into a 364-day credit agreement with certain institutional lenders that provides for a $2.75 billion unsecured revolving credit facility that is scheduled to expire on May 14, 2021. On January 25, 2021, we entered into an amendment to the credit facility to obtain consent of the lenders to our reincorporation to Delaware. The credit agreement is structured as an amendment and restatement of our five-year credit facility which would have terminated on May 15, 2020, the end of its five-year term. As of January 23, 2021, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility. 
Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than 0.25%. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-25):
[0000858877-21-000008:note_history:54]
| May 1, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,881 |  |  | $ | 22 |  |  | $ | — |  |  | $ | 1,903 |  |
| U.S. government agency securities | 167 |  |  | — |  |  | — |  |  | 167 |  |
| Non-U.S. government and agency securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Corporate debt securities | 9,329 |  |  | 218 |  |  | (35) |  |  | 9,512 |  |
| U.S. agency mortgage-backed securities | 2,788 |  |  | 35 |  |  | (13) |  |  | 2,810 |  |
| Commercial paper | 1,333 |  |  | — |  |  | — |  |  | 1,333 |  |
| Certificates of deposit | 440 |  |  | — |  |  | — |  |  | 440 |  |
| Total (1) | $ | 15,941 |  |  | $ | 275 |  |  | $ | (48) |  |  | $ | 16,168 |  |
  (was, 2021-02-16, similarity 0.6198):
[0000858877-21-000004:note_history:54]
| January 23, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,613 |  |  | $ | 50 |  |  | $ | — |  |  | $ | 2,663 |  |
| U.S. government agency securities | 168 |  |  | — |  |  | — |  |  | 168 |  |
| Corporate debt securities | 10,516 |  |  | 296 |  |  | (26) |  |  | 10,786 |  |
| U.S. agency mortgage-backed securities | 2,796 |  |  | 47 |  |  | (3) |  |  | 2,840 |  |
| Commercial paper | 1,730 |  |  | — |  |  | — |  |  | 1,730 |  |
| Certificates of deposit | 603 |  |  | — |  |  | — |  |  | 603 |  |
| Total (1) | $ | 18,426 |  |  | $ | 393 |  |  | $ | (29) |  |  | $ | 18,790 |  |

- changed (2021-05-25):
[0000858877-21-000008:note_history:55]
(1) Net unsettled investment sales were $262 million as of May 1, 2021 and were included in other current assets.
  (was, 2021-02-16, similarity 0.9725):
[0000858877-21-000004:note_history:55]
(1) Net unsettled investment sales were $39 million as of January 23, 2021 and were included in other current assets.

- added (2021-05-25):
[0000858877-21-000008:note_history:56]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1, 2021 |  | April 25, 2020 |  | May 1, 2021 |  | April 25, 2020 |
| Gross realized gains | $ | 24 |  |  | $ | 20 |  |  | $ | 48 |  |  | $ | 45 |  |
| Gross realized losses | (2) |  |  | (21) |  |  | (2) |  |  | (25) |  |
| Total | $ | 22 |  |  | $ | (1) |  |  | $ | 46 |  |  | $ | 20 |  |

- changed (2021-05-25):
[0000858877-21-000008:note_history:57]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at May 1, 2021 and July 25, 2020 (in millions):
  (was, 2021-02-16, similarity 0.981):
[0000858877-21-000004:note_history:57]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 23, 2021 and July 25, 2020 (in millions):

- added (2021-05-25):
[0000858877-21-000008:note_history:58]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| May 1, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 468 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 468 |  |  | $ | — |  |
| U.S. government agency securities | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |
| Corporate debt securities | 1,242 |  |  | (10) |  |  | 6 |  |  | — |  |  | 1,248 |  |  | (10) |  |
| U.S. agency mortgage-backed securities | 1,618 |  |  | (13) |  |  | — |  |  | — |  |  | 1,618 |  |  | (13) |  |
| Commercial paper | 46 |  |  | — |  |  | — |  |  | — |  |  | 46 |  |  | — |  |
| Certificates of deposit | 16 |  |  | — |  |  | — |  |  | — |  |  | 16 |  |  | — |  |
| Total | $ | 3,416 |  |  | $ | (23) |  |  | $ | 6 |  |  | $ | — |  |  | $ | 3,422 |  |  | $ | (23) |  |

- changed (2021-05-25):
[0000858877-21-000008:note_history:59]
The following table summarizes the maturities of our available-for-sale debt investments as of May 1, 2021 (in millions):
  (was, 2021-02-16, similarity 0.9748):
[0000858877-21-000004:note_history:59]
The following table summarizes the maturities of our available-for-sale debt investments as of January 23, 2021 (in millions):

- added (2021-05-25):
[0000858877-21-000008:note_history:60]
Our net unrealized gains recognized during the reporting period on our marketable securities still held as of May 1, 2021 was $3 million for each of the third quarter and first nine months of fiscal 2021. Our net adjustments to non-marketable equity securities measured using the measurement alternative was a net loss of $3 million and a net gain of $1 million for the third quarter and first nine months of fiscal 2021, respectively. These adjustments were net losses of $4 million and $1 million for the corresponding periods of fiscal 2020, respectively. We held equity interests in certain private equity funds of $0.8 billion and $0.7 billion as of May 1, 2021 and July 25, 2020, respectively, which are accounted for under the NAV practical expedient.

- changed (2021-05-25):
[0000858877-21-000008:note_history:61]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of May 1, 2021, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2021-02-16, similarity 0.9932):
[0000858877-21-000004:note_history:61]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 23, 2021, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- added (2021-05-25):
[0000858877-21-000008:note_history:62]
The carrying value of our investments in privately held companies was $1.4 billion and $1.3 billion as of May 1, 2021 and July 25, 2020, respectively. 
Of the total carrying value of our investments in privately held companies as of May 1, 2021, $0.8 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of May 1, 2021, we have total funding commitments of $0.2 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to privately held investments.

- removed (2021-05-25):
[0000858877-21-000004:note_history:63]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2021 |  | January 25, 2020 |  | January 23, 2021 |  | January 25, 2020 |
| Gross realized gains | $ | 9 |  |  | $ | 13 |  |  | $ | 24 |  |  | $ | 25 |  |
| Gross realized losses | — |  |  | (2) |  |  | — |  |  | (4) |  |
| Total | $ | 9 |  |  | $ | 11 |  |  | $ | 24 |  |  | $ | 21 |  |

- removed (2021-05-25):
[0000858877-21-000004:note_history:64]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 23, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 109 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 109 |  |  | $ | — |  |
| U.S. government agency securities | 36 |  |  | — |  |  | — |  |  | — |  |  | 36 |  |  | — |  |
| Corporate debt securities | 663 |  |  | (1) |  |  | — |  |  | — |  |  | 663 |  |  | (1) |  |
| U.S. agency mortgage-backed securities | 698 |  |  | (3) |  |  | — |  |  | — |  |  | 698 |  |  | (3) |  |
| Certificates of deposit | 15 |  |  | — |  |  | — |  |  | — |  |  | 15 |  |  | — |  |
| Total | $ | 1,521 |  |  | $ | (4) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,521 |  |  | $ | (4) |  |

- removed (2021-05-25):
[0000858877-21-000004:note_history:65]
Our net unrealized gains recognized during the reporting period on our marketable and non-marketable equity securities still held as of January 23, 2021 was $4 million for each of the second quarter and first six months of fiscal 2021, and a net gain of $3 million for the corresponding periods of fiscal 2020. Our net adjustments to non-marketable equity securities measured using the measurement alternative was a net gain of $3 million and $4 million for the second quarter and first six months of fiscal 2021, respectively. These adjustments were net gains of $3 million for each of the corresponding periods of fiscal 2020. We held equity interests in certain private equity funds of $0.7 billion as of each of January 23, 2021 and July 25, 2020, which are accounted for under the NAV practical expedient.

- removed (2021-05-25):
[0000858877-21-000004:note_history:66]
The carrying value of our investments in privately held companies was $1.3 billion as of each of January 23, 2021 and July 25, 2020.

- removed (2021-05-25):
[0000858877-21-000004:note_history:67]
Of the total carrying value of our investments in privately held companies as of January 23, 2021, $0.7 billion of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to privately held investments.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-25):
[0000858877-21-000008:note_history:68]
|  |  |  | May 1, 2021 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | — |  |  | — |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | — |  |  | — |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.15% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.00% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.31% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 11,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (81) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 113 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 11,532 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 2,000 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,532 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 11,532 |  |  |  |  | $ | 14,583 |  |  |  |
  (was, 2021-02-16, similarity 0.9812):
[0000858877-21-000004:note_history:68]
|  |  |  | January 23, 2021 |  | July 25, 2020 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | February 28, 2021 |  | $ | 2,500 |  |  | 2.30% |  | $ | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.92% |  | 500 |  |  | 0.94% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.17% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.04% |  | 1,000 |  |  | 1.06% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.33% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 14,500 |  |  |  |  | 14,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (84) |  |  |  |  | (88) |  |  |  |
| Hedge accounting fair value adjustments |  |  | 138 |  |  |  |  | 171 |  |  |  |
| Total |  |  | $ | 14,554 |  |  |  |  | $ | 14,583 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 5,000 |  |  |  |  | $ | 3,005 |  |  |  |
| Long-term debt |  |  | 9,554 |  |  |  |  | 11,578 |  |  |  |
| Total |  |  | $ | 14,554 |  |  |  |  | $ | 14,583 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-25):
[0000858877-21-000008:note_history:69]
As of May 1, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2021-02-16, similarity 0.9774):
[0000858877-21-000004:note_history:69]
As of January 23, 2021, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2021-05-25):
[0000858877-21-000008:note_history:70]
| Fiscal Year | Amount |
| 2021 (remaining three months) | $ | — |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 11,500 |  |
  (was, 2021-02-16, similarity 0.9673):
[0000858877-21-000004:note_history:70]
| Fiscal Year | Amount |
| 2021 (remaining six months) | $ | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| Thereafter | 6,250 |  |
| Total | $ | 14,500 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-25):
[0000858877-21-000008:note_history:71]
|  | May 1, 2021 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 2,000 |  |  | 1.90 | % |  | $ | 3,005 |  |  | 2.07 | % |
  (was, 2021-02-16, similarity 0.9824):
[0000858877-21-000004:note_history:71]
|  | January 23, 2021 |  | July 25, 2020 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 5,000 |  |  | 2.00 | % |  | $ | 3,005 |  |  | 2.07 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-25):
[0000858877-21-000008:note_history:72]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,832 |  |  | $ | 6,447 |  |  | $ | 19,564 |  |  | $ | 20,566 |  |
| Applications | 1,426 |  |  | 1,363 |  |  | 4,160 |  |  | 4,211 |  |
| Security | 876 |  |  | 778 |  |  | 2,559 |  |  | 2,343 |  |
| Other Products | 6 |  |  | 9 |  |  | 15 |  |  | 27 |  |
| Total Product | 9,139 |  |  | 8,597 |  |  | 26,298 |  |  | 27,146 |  |
| Services | 3,664 |  |  | 3,386 |  |  | 10,394 |  |  | 10,001 |  |
| Total | $ | 12,803 |  |  | $ | 11,983 |  |  | $ | 36,692 |  |  | $ | 37,147 |  |
  (was, 2021-02-16, similarity 0.9372):
[0000858877-21-000004:note_history:72]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,391 |  |  | $ | 6,567 |  |  | $ | 12,732 |  |  | $ | 14,120 |  |
| Applications | 1,354 |  |  | 1,349 |  |  | 2,734 |  |  | 2,847 |  |
| Security | 822 |  |  | 749 |  |  | 1,684 |  |  | 1,565 |  |
| Other Products | 4 |  |  | 7 |  |  | 9 |  |  | 17 |  |
| Total Product | 8,572 |  |  | 8,671 |  |  | 17,159 |  |  | 18,549 |  |
| Services | 3,388 |  |  | 3,334 |  |  | 6,730 |  |  | 6,615 |  |
| Total | $ | 11,960 |  |  | $ | 12,005 |  |  | $ | 23,889 |  |  | $ | 25,164 |  |

- changed (2021-05-25):
[0000858877-21-000008:note_history:73]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,832 |  |  | $ | 6,447 |  |  | $ | 19,564 |  |  | $ | 20,566 |  |
| Applications | 1,426 |  |  | 1,363 |  |  | 4,160 |  |  | 4,211 |  |
| Security | 876 |  |  | 778 |  |  | 2,559 |  |  | 2,343 |  |
| Other Products | 6 |  |  | 9 |  |  | 15 |  |  | 27 |  |
| Total Product | 9,139 |  |  | 8,597 |  |  | 26,298 |  |  | 27,146 |  |
| Services | 3,664 |  |  | 3,386 |  |  | 10,394 |  |  | 10,001 |  |
| Total | $ | 12,803 |  |  | $ | 11,983 |  |  | $ | 36,692 |  |  | $ | 37,147 |  |
  (was, 2021-02-16, similarity 0.9372):
[0000858877-21-000004:note_history:73]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,391 |  |  | $ | 6,567 |  |  | $ | 12,732 |  |  | $ | 14,120 |  |
| Applications | 1,354 |  |  | 1,349 |  |  | 2,734 |  |  | 2,847 |  |
| Security | 822 |  |  | 749 |  |  | 1,684 |  |  | 1,565 |  |
| Other Products | 4 |  |  | 7 |  |  | 9 |  |  | 17 |  |
| Total Product | 8,572 |  |  | 8,671 |  |  | 17,159 |  |  | 18,549 |  |
| Services | 3,388 |  |  | 3,334 |  |  | 6,730 |  |  | 6,615 |  |
| Total | $ | 11,960 |  |  | $ | 12,005 |  |  | $ | 23,889 |  |  | $ | 25,164 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-25):
[0000858877-21-000008:note_history:74]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of May 1, 2021 and July 25, 2020 was $61 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2021-02-16, similarity 0.9862):
[0000858877-21-000004:note_history:74]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 23, 2021 and July 25, 2020 was $73 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-25):
[0000858877-21-000008:note_history:75]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of May 1, 2021 and July 25, 2020 was $61 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2021-02-16, similarity 0.9862):
[0000858877-21-000004:note_history:75]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 23, 2021 and July 25, 2020 was $73 million and $79 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2021-05-25):
[0000858877-21-000008:note_history:76]
|  | Three Months Ended |  | Nine Months Ended |
|  | May 1,2021 |  | April 25,2020 |  | May 1,2021 |  | April 25,2020 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,832 |  |  | $ | 6,447 |  |  | $ | 19,564 |  |  | $ | 20,566 |  |
| Applications | 1,426 |  |  | 1,363 |  |  | 4,160 |  |  | 4,211 |  |
| Security | 876 |  |  | 778 |  |  | 2,559 |  |  | 2,343 |  |
| Other Products | 6 |  |  | 9 |  |  | 15 |  |  | 27 |  |
| Total Product | 9,139 |  |  | 8,597 |  |  | 26,298 |  |  | 27,146 |  |
| Services | 3,664 |  |  | 3,386 |  |  | 10,394 |  |  | 10,001 |  |
| Total | $ | 12,803 |  |  | $ | 11,983 |  |  | $ | 36,692 |  |  | $ | 37,147 |  |
  (was, 2021-02-16, similarity 0.9372):
[0000858877-21-000004:note_history:76]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23,2021 |  | January 25,2020 |  | January 23,2021 |  | January 25,2020 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,391 |  |  | $ | 6,567 |  |  | $ | 12,732 |  |  | $ | 14,120 |  |
| Applications | 1,354 |  |  | 1,349 |  |  | 2,734 |  |  | 2,847 |  |
| Security | 822 |  |  | 749 |  |  | 1,684 |  |  | 1,565 |  |
| Other Products | 4 |  |  | 7 |  |  | 9 |  |  | 17 |  |
| Total Product | 8,572 |  |  | 8,671 |  |  | 17,159 |  |  | 18,549 |  |
| Services | 3,388 |  |  | 3,334 |  |  | 6,730 |  |  | 6,615 |  |
| Total | $ | 11,960 |  |  | $ | 12,005 |  |  | $ | 23,889 |  |  | $ | 25,164 |  |

- changed (2021-05-25):
[0000858877-21-000008:note_history:77]
Accounts receivable, net was $4.4 billion as of May 1, 2021 compared to $5.5 billion as of July 25, 2020, as reported on the Consolidated Balance Sheets.
  (was, 2021-02-16, similarity 0.9787):
[0000858877-21-000004:note_history:77]
Accounts receivable, net was $4.3 billion as of January 23, 2021 compared to $5.5 billion as of July 25, 2020, as reported on the Consolidated Balance Sheets.

- changed (2021-05-25):
[0000858877-21-000008:note_history:78]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $1.3 billion and $1.2 billion as of May 1, 2021 and July 25, 2020, respectively, and were included in other current assets and other assets.
  (was, 2021-02-16, similarity 0.9918):
[0000858877-21-000004:note_history:78]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $1.3 billion and $1.2 billion as of January 23, 2021 and July 25, 2020, respectively, and were included in other current assets and other assets.

- changed (2021-05-25):
[0000858877-21-000008:note_history:79]
|  | May 1,2021 |
| 1 to 4 | $ | 379 |  |
| 5 to 6 | 840 |  |
| 7 and Higher | 91 |  |
| Total | $ | 1,310 |  |
  (was, 2021-02-16, similarity 0.9681):
[0000858877-21-000004:note_history:79]
|  | January 23,2021 |
| 1 to 4 | $ | 426 |  |
| 5 to 6 | 783 |  |
| 7 and Higher | 98 |  |
| Total | $ | 1,307 |  |

- changed (2021-05-25):
[0000858877-21-000008:note_history:80]
Contract liabilities consist of deferred revenue. Deferred revenue was $20.9 billion as of May 1, 2021 compared to $20.4 billion as of July 25, 2020. We recognized approximately $2.6 billion and $9.5 billion of revenue during the third quarter and first nine months of fiscal 2021, respectively, that was included in the deferred revenue balance at July 25, 2020.
  (was, 2021-02-16, similarity 0.7552):
[0000858877-21-000004:note_history:80]
Contract liabilities consist of deferred revenue. Deferred revenue was $20.8 billion as of January 23, 2021 compared to $20.4 billion as of July 25, 2020. We recognized approximately $3.0 billion and $6.9 billion of revenue during the second quarter and first six months of fiscal 2021, respectively, that was included in the deferred revenue balance at July 25, 2020.

- changed (2021-05-25):
[0000858877-21-000008:note_history:81]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $893 million and $732 million as of May 1, 2021 and July 25, 2020, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $134 million and $386 million for the third quarter and first nine months of fiscal 2021, respectively, and $118 million and $356 million for the corresponding periods of fiscal 2020, respectively, and was included in sales and marketing expenses.
  (was, 2021-02-16, similarity 0.9866):
[0000858877-21-000004:note_history:81]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $817 million and $732 million as of January 23, 2021 and July 25, 2020, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $129 million and $252 million for the second quarter and first six months of fiscal 2021, respectively, and $122 million and $238 million for the corresponding periods of fiscal 2020, respectively, and was included in sales and marketing expenses.
