# CSCO notes — 0000858877-18-000015


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-18-000015:notes:1]
[same as prior period, unchanged from 0000858877-18-000007:notes:1]

[0000858877-18-000015:notes:2]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Compensation expense related to acquisitions | $ | 109 |  |  | $ | 42 |  |


## csco:IncometaxprovisionTableTextBlock

[0000858877-18-000015:notes:3]
[same as prior period, unchanged from 0000858877-18-000007:notes:3]

[0000858877-18-000015:notes:4]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Income before provision for income taxes | $ | 3,909 |  |  | $ | 2,962 |  |
| Provision for income taxes | $ | 360 |  |  | $ | 568 |  |
| Effective tax rate | 9.2 | % |  | 19.2 | % |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-18-000015:notes:5]
[same as prior period, unchanged from 0000858877-18-000007:notes:5]

[0000858877-18-000015:notes:6]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 7,642 |  |  | $ | 6,980 |  |
| Applications | 1,419 |  |  | 1,203 |  |
| Security | 651 |  |  | 585 |  |
| Other Products | 178 |  |  | 286 |  |
| Total Product | 9,890 |  |  | 9,054 |  |
| Services | 3,182 |  |  | 3,082 |  |
| Total | $ | 13,072 |  |  | $ | 12,136 |  |


## csco:ScheduleOfCommonStockRepurchasedTextBlock

[0000858877-18-000015:notes:7]
[same as prior period, unchanged from 0000858877-18-000007:notes:7]

[0000858877-18-000015:notes:8]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2019 |  |  |  |  |  |  |
| October 27, 2018 |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |
| Fiscal 2018 |  |  |  |  |  |  |
| July 28, 2018 |  | 138 |  |  | $ | 43.58 |  |  | $ | 6,015 |  |
| April 28, 2018 |  | 140 |  |  | $ | 42.83 |  |  | $ | 6,015 |  |
| January 27, 2018 |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |
| October 28, 2017 |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-18-000015:notes:9]
[same as prior period, unchanged from 0000858877-18-000007:notes:9]

[0000858877-18-000015:notes:10]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE THREE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | October 27, 2018 |  | October 28, 2017 |  | October 27, 2018 |  | October 28, 2017 |
| Interest rate derivatives |  | Interest expense |  | $ | (9 | ) |  | $ | (46 | ) |  | $ | 9 |  |  | $ | 46 |  |
| Equity derivatives |  | Other income (loss), net |  | — |  |  | (14 | ) |  | — |  |  | 14 |  |
| Total |  |  |  | $ | (9 | ) |  | $ | (60 | ) |  | $ | 9 |  |  | $ | 60 |  |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-18-000015:notes:11]
[same as prior period, unchanged from 0000858877-18-000007:notes:12]

[0000858877-18-000015:notes:12]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Amortization of purchased intangible assets: |  |  |  |
| Cost of sales | $ | 151 |  |  | $ | 154 |  |
| Operating expenses | 34 |  |  | 61 |  |
| Total | $ | 185 |  |  | $ | 215 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-18-000015:notes:13]
The following table presents details of our intangible assets acquired through acquisitions completed during the first quarter of fiscal 2019 (in millions, except years):

[0000858877-18-000015:notes:14]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Duo | 5.0 |  | $ | 153 |  |  | 5.0 |  |  | $ | 94 |  |  | 2.5 |  |  | $ | 18 |  |  | $ | 77 |  |  | $ | 342 |  |
| Others (one in total) | 5.0 |  | 8 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| Total |  |  | $ | 161 |  |  |  |  | $ | 94 |  |  |  |  | $ | 18 |  |  | $ | 77 |  |  | $ | 350 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-18-000015:notes:15]
The following tables present details of our purchased intangible assets (in millions):

[0000858877-18-000015:notes:16]
| October 27, 2018 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,847 |  |  | $ | (2,013 | ) |  | $ | 1,834 |  |
| Customer relationships |  | 1,629 |  |  | (965 | ) |  | 664 |  |
| Other |  | 80 |  |  | (42 | ) |  | 38 |  |
| Total purchased intangible assets with finite lives |  | 5,556 |  |  | (3,020 | ) |  | 2,536 |  |
| In-process research and development, with indefinite lives |  | 180 |  |  | — |  |  | 180 |  |
| Total |  | $ | 5,736 |  |  | $ | (3,020 | ) |  | $ | 2,716 |  |

[0000858877-18-000015:notes:17]
| July 28, 2018 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,711 |  |  | $ | (1,888 | ) |  | $ | 1,823 |  |
| Customer relationships |  | 1,538 |  |  | (937 | ) |  | 601 |  |
| Other |  | 63 |  |  | (38 | ) |  | 25 |  |
| Total purchased intangible assets with finite lives |  | 5,312 |  |  | (2,863 | ) |  | 2,449 |  |
| In-process research and development, with indefinite lives |  | 103 |  |  | — |  |  | 103 |  |
| Total |  | $ | 5,415 |  |  | $ | (2,863 | ) |  | $ | 2,552 |  |


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-18-000015:notes:18]
[same as prior period, unchanged from 0000858877-18-000007:notes:19]

[0000858877-18-000015:notes:19]
[same as prior period, unchanged from 0000858877-18-000007:notes:20]

[0000858877-18-000015:notes:20]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-18-000015:notes:21]
Summarized financial information by segment for the first quarter of fiscal 2019 and fiscal 2018, based on our internal management system and as utilized by our Chief Operating Decision Maker ("CODM"), is as follows (in millions):

[0000858877-18-000015:notes:22]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Revenue: |  |  |  |
| Americas | $ | 7,751 |  |  | $ | 7,350 |  |
| EMEA | 3,224 |  |  | 2,909 |  |
| APJC | 2,096 |  |  | 1,877 |  |
| Total | $ | 13,072 |  |  | $ | 12,136 |  |
| Gross margin: |  |  |  |
| Americas | $ | 5,070 |  |  | $ | 4,722 |  |
| EMEA | 2,070 |  |  | 1,839 |  |
| APJC | 1,200 |  |  | 1,165 |  |
| Segment total | 8,341 |  |  | 7,726 |  |
| Unallocated corporate items | (195 | ) |  | (299 | ) |
| Total | $ | 8,146 |  |  | $ | 7,427 |  |

[0000858877-18-000015:notes:23]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-18-000015:notes:24]
Revenue in the United States was $6.9 billion and $6.5 billion for the first quarter of fiscal 2019 and fiscal 2018, respectively.

[0000858877-18-000015:notes:25]
[same as prior period, unchanged from 0000858877-18-000007:notes:25]

[0000858877-18-000015:notes:26]
We design, manufacture, and sell Internet Protocol (IP)-based networking and other products related to the communications and information technology (IT) industry and provide services associated with these products and their use.

[0000858877-18-000015:notes:27]
[same as prior period, unchanged from 0000858877-18-000007:notes:27]

[0000858877-18-000015:notes:28]
The majority of our assets was attributable to our U.S. operations as of each of October 27, 2018 and July 28, 2018.

[0000858877-18-000015:notes:29]
[same as prior period, unchanged from 0000858877-18-000007:notes:29]

[0000858877-18-000015:notes:30]
|  | October 27, 2018 |  | July 28, 2018 |
| Property and equipment, net: |  |  |  |
| United States | $ | 2,421 |  |  | $ | 2,487 |  |
| International | 535 |  |  | 519 |  |
| Total | $ | 2,956 |  |  | $ | 3,006 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-18-000015:notes:31]
[same as prior period, unchanged from 0000858877-18-000007:notes:31]

[0000858877-18-000015:notes:32]
| Three months ended October 27, 2018 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 28, 2018 | $ | 135 |  |  | $ | 60 |  |  | $ | 10 |  |  | $ | 205 |  |
| Provisions (benefits) | (3 | ) |  | — |  |  | (2 | ) |  | (5 | ) |
| Foreign exchange and other | (1 | ) |  | — |  |  | — |  |  | (1 | ) |
| Allowance for credit loss as of October 27, 2018 | $ | 131 |  |  | $ | 60 |  |  | $ | 8 |  |  | $ | 199 |  |

[0000858877-18-000015:notes:33]
| Three months ended October 28, 2017 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 29, 2017 | $ | 162 |  |  | $ | 103 |  |  | $ | 30 |  |  | $ | 295 |  |
| Provisions | (2 | ) |  | 2 |  |  | (6 | ) |  | (6 | ) |
| Foreign exchange and other | — |  |  | 1 |  |  | (1 | ) |  | — |  |
| Allowance for credit loss as of October 28, 2017 | $ | 160 |  |  | $ | 106 |  |  | $ | 23 |  |  | $ | 289 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000858877-18-000015:notes:34]
The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-18-000015:notes:35]
We have prepared the accompanying financial data as of October 27, 2018 and for the three months ended October 27, 2018 and October 28, 2017, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 28, 2018 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 28, 2018.

[0000858877-18-000015:notes:36]
We consolidate our investments in certain variable interest entities (VIEs) where we are the  primary beneficiary. The noncontrolling interests attributed to these investments, if any, are presented as a separate component from our equity in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interests  are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-18-000015:notes:37]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 27, 2018; the results of operations and the statements of comprehensive income (loss) for the three months ended October 27, 2018 and October 28, 2017; the statements of cash flows and equity for the three months ended October 27, 2018 and October 28, 2017, as applicable, have been made. The results of operations for the three months ended October 27, 2018 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-18-000015:notes:38]
[same as prior period, unchanged from 0000858877-18-000007:notes:40]

[0000858877-18-000015:notes:39]
We completed two acquisitions during the first quarter of fiscal 2019. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-18-000015:notes:40]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Duo | $ | 2,025 |  |  | $ | (57 | ) |  | $ | 342 |  |  | $ | 1,740 |  |
| Other (one acquisition) | 34 |  |  | 3 |  |  | 8 |  |  | 23 |  |
| Total | $ | 2,059 |  |  | $ | (54 | ) |  | $ | 350 |  |  | $ | 1,763 |  |

[0000858877-18-000015:notes:41]
On September 28, 2018, we completed our acquisition of privately held Duo Security, Inc. ("Duo"), a leading provider of unified access security and multi-factor authentication delivered through the cloud. Revenue from the Duo acquisition has been included in our Security product category.

[0000858877-18-000015:notes:42]
The total purchase consideration related to acquisitions completed during the first quarter of fiscal 2019 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $82 million. Total transaction costs related to acquisition and divestiture activities were $10 million and $9 million for the first quarter of fiscal 2019 and fiscal 2018, respectively. These transaction costs were expensed as incurred in general and administrative expenses ("G&A") in the Consolidated Statements of Operations. We recognized a gain of $3 million and $46 million during the first quarter of 2019 and fiscal 2018, respectively, in connection with step acquisitions. The gains were recognized in other income (loss), net in the Consolidated Statement of Operations.

[0000858877-18-000015:notes:43]
The purchase price allocation for acquisitions completed during recent periods is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information that existed as of the acquisition date but at that time was unknown to us may become known to us during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date. Adjustments in the purchase price allocation may require a recasting of the amounts allocated to goodwill retroactive to the period in which the acquisition occurred.

[0000858877-18-000015:notes:44]
The goodwill generated from acquisitions completed during the first quarter of fiscal 2019 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-18-000015:notes:45]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first quarter of fiscal 2019 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.

[0000858877-18-000015:notes:46]
Divestiture of Service Provider Video Software Solutions     On May 1, 2018, we announced a definitive agreement to sell our Service Provider Video Software Solutions ("SPVSS") business. As of October 27, 2018, this business had tangible assets of approximately $165 million (primarily comprised of accounts receivables, inventories and various other current and long-term assets) and net intangible assets and goodwill (based on relative fair value) of $330 million. In addition, the business had total liabilities of approximately $290 million (primarily comprised of deferred revenue and various other current and long-term liabilities). These assets and liabilities were held for sale and were not presented separately as the amounts were not material to the Consolidated Balance Sheet. We closed the sale of this business on October 28, 2018 and the value is preliminary and subject to revision as information is finalized. We expect to have an immaterial financial statement impact from this transaction.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-18-000015:notes:47]
Commitments and Contingencies

[0000858877-18-000015:notes:48]
| (a) | Operating Leases |

[0000858877-18-000015:notes:49]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, Germany, India, Israel, Japan, Mexico, Poland and the United Kingdom. We also lease equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of October 27, 2018 are as follows (in millions):

[0000858877-18-000015:notes:50]
| Fiscal Year | Amount |
| 2019 (remaining nine months) | $ | 312 |  |
| 2020 | 323 |  |
| 2021 | 220 |  |
| 2022 | 152 |  |
| 2023 | 102 |  |
| Thereafter | 116 |  |
| Total | $ | 1,225 |  |

[0000858877-18-000015:notes:51]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-18-000015:notes:52]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-18-000015:notes:53]
The following table summarizes our purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-18-000015:notes:54]
| Commitments by Period | October 27, 2018 |  | July 28, 2018 |
| Less than 1 year | $ | 5,500 |  |  | $ | 5,407 |  |
| 1 to 3 years | 704 |  |  | 710 |  |
| 3 to 5 years | 270 |  |  | 360 |  |
| Total | $ | 6,474 |  |  | $ | 6,477 |  |

[0000858877-18-000015:notes:55]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 27, 2018 and July 28, 2018, the liability for these purchase commitments was $150 million and $159 million, respectively, and was included in other current liabilities.

[0000858877-18-000015:notes:56]
| (c) | Other Commitments |

[0000858877-18-000015:notes:57]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-18-000015:notes:58]
As of October 27, 2018, we estimated that future cash compensation expense of up to $585 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-18-000015:notes:59]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $378 million and $223 million as of October 27, 2018 and July 28, 2018, respectively.

[0000858877-18-000015:notes:60]
| (d) | Product Warranties |

[0000858877-18-000015:notes:61]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-18-000015:notes:62]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Balance at beginning of period | $ | 359 |  |  | $ | 407 |  |
| Provisions for warranties issued | 156 |  |  | 148 |  |
| Adjustments for pre-existing warranties | (3 | ) |  | (12 | ) |
| Settlements | (145 | ) |  | (149 | ) |
| Balance at end of period | $ | 367 |  |  | $ | 394 |  |

[0000858877-18-000015:notes:63]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-18-000015:notes:64]
| (e) | Financing and Other Guarantees |

[0000858877-18-000015:notes:65]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-18-000015:notes:66]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.2 billion and $6.7 billion for the first quarter of fiscal 2019 and fiscal 2018, respectively. The balance of the channel partner financing subject to guarantees was $931 million and $953 million as of October 27, 2018 and July 28, 2018, respectively.

[0000858877-18-000015:notes:67]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $3 million and $14 million for the first quarter of fiscal 2019 and fiscal 2018, respectively.

[0000858877-18-000015:notes:68]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 27, 2018 and July 28, 2018, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-18-000015:notes:69]
|  | October 27, 2018 |  | July 28, 2018 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 307 |  |  | $ | 277 |  |
| End user | 28 |  |  | 31 |  |
| Total | $ | 335 |  |  | $ | 308 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (72 | ) |  | $ | (94 | ) |
| End user | (26 | ) |  | (28 | ) |
| Total | $ | (98 | ) |  | $ | (122 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 237 |  |  | $ | 186 |  |

[0000858877-18-000015:notes:70]
Other Guarantees   Our other guarantee arrangements as of October 27, 2018 and July 28, 2018 that were subject to recognition and disclosure requirements were not material.

[0000858877-18-000015:notes:71]
| (f) | Indemnifications |

[0000858877-18-000015:notes:72]
In the normal course of business, we indemnify other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-18-000015:notes:73]
We have been asked to indemnify Time Warner Cable (“TWC”) for patent infringement claims asserted against it by Sprint Communications Company, L.P. (“Sprint”) in federal court in Kansas. Sprint alleges that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied TWC's post-trial motions. TWC has appealed to the U.S. Court of Appeals for the Federal Circuit. We believe that TWC continues to have strong non-infringement and invalidity defenses and arguments and/or that Sprint’s damages claims are inconsistent with prevailing law. Due to the uncertainty surrounding the litigation process, we are unable to reasonably estimate the ultimate outcome of the TWC litigation at this time. Should Sprint prevail in litigation, or TWC agree to a settlement, we, in accordance with our agreements, may have an obligation to indemnify TWC for damages, mediation awards, or settlement amounts arising from its use of our products. At this time, we do not anticipate that our obligations regarding the final outcome would be material.

[0000858877-18-000015:notes:74]
During the first quarter of fiscal 2018, we recorded legal and indemnification settlement charges of $122 million to product cost of sales related to these and other matters.

[0000858877-18-000015:notes:75]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-18-000015:notes:76]
It is not possible to determine the maximum potential amount under these indemnification agreements due to our limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by us under these agreements have not had a material effect on our operating results, financial position, or cash flows.

[0000858877-18-000015:notes:77]
| (g) | Legal Proceedings |

[0000858877-18-000015:notes:78]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of our former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-18-000015:notes:79]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $221 million for the alleged evasion of import and other taxes, $1.4 billion for interest, and $1.0 billion for various penalties, all determined using an exchange rate as of October 27, 2018. We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-18-000015:notes:80]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and, on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We have appealed to the United States Court of Appeals for the Federal Circuit on various grounds. We believe we have strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, we do not expect it to be material.

[0000858877-18-000015:notes:81]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against us and cancelling a trial which had been set for March 12, 2018. On January 16, 2018, Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit.

[0000858877-18-000015:notes:82]
Arista Networks, Inc.     As reported in our Form 10-K for the fiscal year ended July 28, 2018 we received a payment of $400 million from Arista Networks, Inc. ("Arista") in connection with the settlement of litigation. The payment was recognized in general and administrative expenses in our first quarter of fiscal 2019.

[0000858877-18-000015:notes:83]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the court consolidated the cases alleging infringement of the ‘327 Patent. Oyster's cases against some of the defendants were resolved. The court vacated the November 4, 2018 trial date set for Oyster's claims against Cisco and one other remaining defendant, pending resolution of Oyster's appeal of the court's summary judgment ruling dismissing certain of Oyster's claims. While we believe that we have strong non-infringement arguments and that the patent is invalid, if we do not prevail in the District Court, we believe damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, we are unable to reasonably estimate the ultimate outcome of this litigation at this time. However, we do not anticipate that any final outcome of the dispute would be material.

[0000858877-18-000015:notes:84]
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-18-000015:notes:85]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-18-000015:notes:86]
[same as prior period, unchanged from 0000858877-18-000007:notes:98]

[0000858877-18-000015:notes:87]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, for the first quarter of fiscal 2019 and fiscal 2018 are summarized as follows (in millions):

[0000858877-18-000015:notes:88]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 28, 2018 | $ | (310 | ) |  | $ | (11 | ) |  | $ | (528 | ) |  | $ | (849 | ) |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (8 | ) |  | (4 | ) |  | (207 | ) |  | (219 | ) |
| (Gains) losses reclassified out of AOCI | 6 |  |  | — |  |  | (1 | ) |  | 5 |  |
| Tax benefit (expense) | 13 |  |  | 1 |  |  | (1 | ) |  | 13 |  |
| Total change for the period | 11 |  |  | (3 | ) |  | (209 | ) |  | (201 | ) |
| Effect of adoption of accounting standards | (168 | ) |  | — |  |  | — |  |  | (168 | ) |
| BALANCE AT OCTOBER 27, 2018 | $ | (467 | ) |  | $ | (14 | ) |  | $ | (737 | ) |  | $ | (1,218 | ) |

[0000858877-18-000015:notes:89]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 29, 2017 | $ | 373 |  |  | $ | 32 |  |  | $ | (359 | ) |  | $ | 46 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 18 |  |  | 8 |  |  | 18 |  |  | 44 |  |
| (Gains) losses reclassified out of AOCI | (33 | ) |  | (13 | ) |  | 1 |  |  | (45 | ) |
| Tax benefit (expense) | (13 | ) |  | 1 |  |  | (2 | ) |  | (14 | ) |
| Total change for the period | (28 | ) |  | (4 | ) |  | 17 |  |  | (15 | ) |
| BALANCE AT OCTOBER 28, 2017 | $ | 345 |  |  | $ | 28 |  |  | $ | (342 | ) |  | $ | 31 |  |

[0000858877-18-000015:notes:90]
[same as prior period, unchanged from 0000858877-18-000007:notes:102]

[0000858877-18-000015:notes:91]
|  |  | Three Months Ended |  |  |
|  |  | October 27, 2018 |  | October 28, 2017 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains and losses on available-for-sale investments |  | $ | (6 | ) |  | $ | 33 |  |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |
| Foreign currency derivatives |  | (1 | ) |  | 10 |  |  | Operating expenses |
| Foreign currency derivatives |  | 1 |  |  | — |  |  | Revenue—service |
| Foreign currency derivatives |  | — |  |  | 3 |  |  | Cost of sales—service |
|  |  | — |  |  | 13 |  |  |  |
| Cumulative translation adjustment and actuarial gains and losses |  | — |  |  | (1 | ) |  | Operating expenses |
| Cumulative translation adjustment and actuarial gains and losses |  | 1 |  |  | — |  |  | Other income (loss), net |
| Total amounts reclassified out of AOCI |  | $ | (5 | ) |  | $ | 45 |  |  |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000858877-18-000015:notes:92]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 11,062 |  |  | $ | 11,431 |  |
| Product |  | 5,752 |  |  | 8,254 |  |
| Total |  | $ | 16,814 |  |  | $ | 19,685 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,637 |  |  | $ | 11,490 |  |
| Noncurrent |  | 7,177 |  |  | 8,195 |  |
| Total |  | $ | 16,814 |  |  | $ | 19,685 |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-18-000015:notes:93]
Borrowings

[0000858877-18-000015:notes:94]
| (a) | Short-Term Debt |

[0000858877-18-000015:notes:95]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-18-000015:notes:96]
|  | October 27, 2018 |  | July 28, 2018 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 7,241 |  |  | 3.06 | % |  | $ | 5,238 |  |  | 3.46 | % |

[0000858877-18-000015:notes:97]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of October 27, 2018 and July 28, 2018.

[0000858877-18-000015:notes:98]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-18-000015:notes:99]
| (b) | Long-Term Debt |

[0000858877-18-000015:notes:100]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-18-000015:notes:101]
|  |  |  | October 27, 2018 |  | July 28, 2018 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | $ | 500 |  |  | 2.88% |  | $ | 500 |  |  | 2.86% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.72% |  | 500 |  |  | 2.71% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.22% |  | 2,000 |  |  | 5.17% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.87% |  | 1,750 |  |  | 2.71% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.68% |  | 2,500 |  |  | 4.52% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 3.05% |  | 500 |  |  | 2.86% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 3.32% |  | 500 |  |  | 3.11% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 3.17% |  | 1,000 |  |  | 2.98% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.48% |  | 500 |  |  | 3.27% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 25,750 |  |  |  |  | 25,750 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (112 | ) |  |  |  | (116 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (74 | ) |  |  |  | (65 | ) |  |  |
| Total |  |  | $ | 25,564 |  |  |  |  | $ | 25,569 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 7,241 |  |  |  |  | $ | 5,238 |  |  |  |
| Long-term debt |  |  | 18,323 |  |  |  |  | 20,331 |  |  |  |
| Total |  |  | $ | 25,564 |  |  |  |  | $ | 25,569 |  |  |  |

[0000858877-18-000015:notes:102]
We entered into interest rate swaps in prior periods with an aggregate notional amount of $6.75 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate ("LIBOR"). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 12.

[0000858877-18-000015:notes:103]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 27, 2018, we were in compliance with all debt covenants.

[0000858877-18-000015:notes:104]
As of October 27, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-18-000015:notes:105]
| Fiscal Year | Amount |
| 2019 (remaining nine months) | $ | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| Thereafter | 8,500 |  |
| Total | $ | 25,750 |  |

[0000858877-18-000015:notes:106]
| (c) | Credit Facility |

[0000858877-18-000015:notes:107]
On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.

[0000858877-18-000015:notes:108]
This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of October 27, 2018, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under this credit facility.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-18-000015:notes:109]
[same as prior period, unchanged from 0000858877-18-000007:notes:121]

[0000858877-18-000015:notes:110]
[same as prior period, unchanged from 0000858877-18-000007:notes:122]

[0000858877-18-000015:notes:111]
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We do, however, seek to mitigate such risks by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-18-000015:notes:112]
The fair values of our derivative instruments and the line items on the Consolidated Balance Sheets to which they were recorded are summarized as follows (in millions):

[0000858877-18-000015:notes:113]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | October 27, 2018 |  | July 28, 2018 |  | Balance Sheet Line Item |  | October 27, 2018 |  | July 28, 2018 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 4 |  |  | $ | 1 |  |  | Other current liabilities |  | $ | 6 |  |  | $ | — |  |
| Interest rate derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 7 |  |  | 10 |  |
| Interest rate derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 74 |  |  | 62 |  |
| Total |  |  | 4 |  |  | 1 |  |  |  |  | 87 |  |  | 72 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 1 |  |  | 1 |  |  | Other current liabilities |  | 4 |  |  | 2 |  |
| Total return swaps—deferred compensation | Other current assets |  | 1 |  |  | — |  |  | Other current liabilities |  | — |  |  | — |  |
| Total |  |  | 2 |  |  | 1 |  |  |  |  | 4 |  |  | 2 |  |
| Total |  |  | $ | 6 |  |  | $ | 2 |  |  |  |  | $ | 91 |  |  | $ | 74 |  |

[0000858877-18-000015:notes:114]
The effects of our cash flow and net investment hedging instruments on other comprehensive income (OCI) and the Consolidated Statements of Operations are summarized as follows (in millions):

[0000858877-18-000015:notes:115]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE THREE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THETHREE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | October 27, 2018 |  | October 28, 2017 |  | Line Item in Statements of Operations |  | October 27, 2018 |  | October 28, 2017 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (4 | ) |  | $ | 8 |  |  | Revenue — service |  | $ | 1 |  |  | $ | — |  |
|  |  |  |  |  |  | Operating expenses |  | (1 | ) |  | 10 |  |
|  |  |  |  |  |  | Cost of sales — service |  | — |  |  | 3 |  |
| Total |  | $ | (4 | ) |  | $ | 8 |  |  |  |  | $ | — |  |  | $ | 13 |  |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 4 |  |  | $ | (5 | ) |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-18-000015:notes:116]
As of October 27, 2018, we estimate that approximately $3 million of net derivative losses related to our cash flow hedges included in accumulated other comprehensive income (AOCI) will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-18-000015:notes:117]
[same as prior period, unchanged from 0000858877-18-000007:notes:130]

[0000858877-18-000015:notes:118]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | October 27, 2018 |  | October 28, 2017 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (27 | ) |  | $ | 7 |  |
| Total return swaps—deferred compensation |  | Operating expenses |  | (24 | ) |  | 15 |  |
|  |  | Cost of sales — product |  | (1 | ) |  | — |  |
|  |  | Cost of sales — service |  | (1 | ) |  | 1 |  |
|  |  | Other income (loss), net |  | (4 | ) |  | (2 | ) |
| Equity derivatives |  | Other income (loss), net |  | 1 |  |  | 1 |  |
| Total |  |  |  | $ | (56 | ) |  | $ | 22 |  |

[0000858877-18-000015:notes:119]
The notional amounts of our outstanding derivatives are summarized as follows (in millions):

[0000858877-18-000015:notes:120]
|  | October 27, 2018 |  | July 28, 2018 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 796 |  |  | $ | 147 |  |
| Interest rate derivatives | 6,750 |  |  | 6,750 |  |
| Net investment hedging instruments | 246 |  |  | 250 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,170 |  |  | 2,298 |  |
| Total return swaps—deferred compensation | 564 |  |  | 566 |  |
| Total | $ | 10,526 |  |  | $ | 10,011 |  |

[0000858877-18-000015:notes:121]
[same as prior period, unchanged from 0000858877-18-000007:notes:134]

[0000858877-18-000015:notes:122]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty. To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Information related to these offsetting arrangements is summarized as follows (in millions):

[0000858877-18-000015:notes:123]
|  | October 27, 2018 |
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEETS |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETSBUT WITH LEGAL RIGHTS TO OFFSET |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 6 |  |  | $ | — |  |  | $ | 6 |  |  | $ | (5 | ) |  | $ | — |  |  | $ | 1 |  |
| Derivatives liabilities | $ | 91 |  |  | $ | — |  |  | $ | 91 |  |  | $ | (5 | ) |  | $ | (70 | ) |  | $ | 16 |  |

[0000858877-18-000015:notes:124]
|  | July 28, 2018 |
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEETS |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETSBUT WITH LEGAL RIGHTS TO OFFSET |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |
| Derivatives liabilities | $ | 74 |  |  | $ | — |  |  | $ | 74 |  |  | $ | (2 | ) |  | $ | (53 | ) |  | $ | 19 |  |

[0000858877-18-000015:notes:125]
[same as prior period, unchanged from 0000858877-18-000007:notes:138]

[0000858877-18-000015:notes:126]
We conduct business globally in numerous currencies. Therefore, we are exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, we enter into foreign currency contracts. We do not enter into such contracts for speculative purposes.

[0000858877-18-000015:notes:127]
We hedge forecasted foreign currency transactions related to certain revenues, operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. We assess effectiveness based on changes in total fair value of the derivatives. The effective portion of the derivative instrument’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion, if any, of the gain or loss is reported in earnings immediately. During the periods presented, we did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-18-000015:notes:128]
We enter into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, including long-term customer financings, investments, and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of intercompany balances or other current assets, investments, or liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-18-000015:notes:129]
We hedge certain net investments in our foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on our net investment in those foreign subsidiaries. These derivative instruments generally have maturities of up to six months.

[0000858877-18-000015:notes:130]
[same as prior period, unchanged from 0000858877-18-000007:notes:143]

[0000858877-18-000015:notes:131]
Interest Rate Derivatives, Investments   Our primary objective for holding available-for-sale debt investments is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, we may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of October 27, 2018 and July 28, 2018, we did not have any outstanding interest rate derivatives related to our available-for-sale debt investments.

[0000858877-18-000015:notes:132]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt  In the first quarter of fiscal 2019, we did not enter into any interest rate swaps. In prior fiscal years, we entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2019 through 2025. Under these interest rate swaps, we receive fixed-rate interest payments and make interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps was reflected in other current liabilities and other long-term liabilities.

[0000858877-18-000015:notes:133]
[same as prior period, unchanged from 0000858877-18-000007:notes:146]

[0000858877-18-000015:notes:134]
We may hold equity securities for strategic purposes or to diversify our overall investment portfolio. The marketable equity securities in our portfolio are subject to price risk. To manage our exposure to changes in the fair value of certain equity securities, we have periodically entered into equity derivatives that are designated as fair value hedges. The changes in the value of the hedging instruments are included in other income (loss), net, and offset the change in the fair value of the underlying hedged investment. In addition, we periodically enter into equity derivatives that are not designated as accounting hedges. The changes in the fair value of these derivatives are also included in other income (loss), net.

[0000858877-18-000015:notes:135]
We are also exposed to variability in compensation charges related to certain deferred compensation obligations to employees. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure.

[0000858877-18-000015:notes:136]
[same as prior period, unchanged from 0000858877-18-000007:notes:149]

[0000858877-18-000015:notes:137]
[same as prior period, unchanged from 0000858877-18-000007:notes:150]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-18-000015:notes:138]
The following table presents this disaggregation of revenue (in millions):


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-18-000015:notes:139]
[same as prior period, unchanged from 0000858877-18-000007:notes:151]

[0000858877-18-000015:notes:140]
[same as prior period, unchanged from 0000858877-18-000007:notes:152]

[0000858877-18-000015:notes:141]
Stock Incentive Plan Program Description    As of October 27, 2018, we had one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with Cisco.  The number and frequency of share-based awards are based on competitive practices, operating results of Cisco, government regulations, and other factors. Our primary stock incentive plan is summarized as follows:

[0000858877-18-000015:notes:142]
2005 Plan    As of October 27, 2018, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus shares from certain previous plans that are forfeited or are terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan. In addition, starting November 19, 2013, shares withheld by Cisco from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-18-000015:notes:143]
Pursuant to an amendment approved by our shareholders on November 12, 2009, the number of shares available for issuance under the 2005 Plan is reduced by 1.5 shares for each share awarded as a stock grant or a stock unit, and any shares underlying awards outstanding from certain previous plans that expire unexercised at the end of their maximum terms become available for reissuance under the 2005 Plan. The 2005 Plan permits the granting of stock options, restricted stock, and restricted stock units ("RSUs"), the vesting of which may be performance-based or market-based along with the requisite service requirement, and stock appreciation rights to employees (including employee directors and officers), consultants of Cisco and its subsidiaries and affiliates, and non-employee directors of Cisco.  Stock options and stock appreciation rights granted under the 2005 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date. The expiration date for stock options and stock appreciation rights shall be no later than 10 years from the grant date.

[0000858877-18-000015:notes:144]
The stock options will generally become exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively. Time-based stock grants and time-based RSUs will generally vest over a four year term. The majority of the performance-based and market-based RSUs vests at the end of the three-year requisite service period or earlier if the award recipient meets certain retirement eligibility conditions. Certain performance-based RSUs, that are based on the achievement of financial and/or non-financial operating goals, typically vest upon the achievement of milestones (and may require subsequent service periods), with overall vesting of the shares underlying the award ranging from six months to three years. The Compensation and Management Development Committee of our Board of Directors has the discretion to use different vesting schedules. Stock appreciation rights may be awarded in combination with stock options or stock grants, and such awards shall provide that the stock appreciation rights will not be exercisable unless the related stock options or stock grants are forfeited. Stock grants may be awarded in combination with non-statutory stock options, and such awards may provide that the stock grants will be forfeited in the event that the related non-statutory stock options are exercised.

[0000858877-18-000015:notes:145]
[same as prior period, unchanged from 0000858877-18-000007:notes:157]

[0000858877-18-000015:notes:146]
We have an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 621 million shares of our common stock have been reserved for issuance as of October 27, 2018. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of our stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period.  The Purchase Plan is scheduled to terminate on January 3, 2020. No shares were issued under the Purchase Plan during each of the first quarter of fiscal 2019 and fiscal 2018. As of October 27, 2018, 78 million shares were available for issuance under the Purchase Plan.

[0000858877-18-000015:notes:147]
[same as prior period, unchanged from 0000858877-18-000007:notes:159]

[0000858877-18-000015:notes:148]
[same as prior period, unchanged from 0000858877-18-000007:notes:160]

[0000858877-18-000015:notes:149]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Cost of sales—product | $ | 23 |  |  | $ | 23 |  |
| Cost of sales—service | 33 |  |  | 34 |  |
| Share-based compensation expense in cost of sales | 56 |  |  | 57 |  |
| Research and development | 130 |  |  | 136 |  |
| Sales and marketing | 137 |  |  | 135 |  |
| General and administrative | 62 |  |  | 64 |  |
| Restructuring and other charges | 23 |  |  | 6 |  |
| Share-based compensation expense in operating expenses | 352 |  |  | 341 |  |
| Total share-based compensation expense | $ | 408 |  |  | $ | 398 |  |
| Income tax benefit for share-based compensation | $ | 165 |  |  | $ | 175 |  |

[0000858877-18-000015:notes:150]
As of October 27, 2018, the total compensation cost related to unvested share-based awards not yet recognized was $3.0 billion which is expected to be recognized over approximately 2.6 years on a weighted-average basis.

[0000858877-18-000015:notes:151]
[same as prior period, unchanged from 0000858877-18-000007:notes:163]

[0000858877-18-000015:notes:152]
[same as prior period, unchanged from 0000858877-18-000007:notes:164]

[0000858877-18-000015:notes:153]
|  | Share-Based Awards Available for Grant |
| BALANCE AT JULY 29, 2017 | 272 |  |
| Restricted stock, stock units, and other share-based awards granted | (70 | ) |
| Share-based awards canceled/forfeited/expired | 18 |  |
| Shares withheld for taxes and not issued | 25 |  |
| BALANCE AT JULY 28, 2018 | 245 |  |
| Restricted stock, stock units, and other share-based awards granted | (12 | ) |
| Share-based awards canceled/forfeited/expired | 5 |  |
| Shares withheld for taxes and not issued | 9 |  |
| Other | 1 |  |
| BALANCE AT OCTOBER 27, 2018 | 248 |  |

[0000858877-18-000015:notes:154]
For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. For restricted stock units that were awarded with vesting contingent upon the achievement of future financial performance or market-based metrics, the maximum awards that can be achieved upon full vesting of such awards were reflected in the preceding table.

[0000858877-18-000015:notes:155]
[same as prior period, unchanged from 0000858877-18-000007:notes:167]

[0000858877-18-000015:notes:156]
[same as prior period, unchanged from 0000858877-18-000007:notes:168]

[0000858877-18-000015:notes:157]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 29, 2017 | 141 |  |  | $ | 26.94 |  |  |  |
| Granted | 46 |  |  | 35.62 |  |  |  |
| Assumed from acquisitions | 1 |  |  | 28.26 |  |  |  |
| Vested | (53 | ) |  | 26.02 |  |  | $ | 1,909 |  |
| Canceled/forfeited/other | (16 | ) |  | 28.37 |  |  |  |
| UNVESTED BALANCE AT JULY 28, 2018 | 119 |  |  | 30.56 |  |  |  |
| Granted | 8 |  |  | 45.05 |  |  |  |
| Vested | (19 | ) |  | 25.92 |  |  | $ | 883 |  |
| Canceled/forfeited/other | (4 | ) |  | 30.33 |  |  |  |
| UNVESTED BALANCE AT OCTOBER 27, 2018 | 104 |  |  | $ | 32.48 |  |  |  |

[0000858877-18-000015:notes:158]
[same as prior period, unchanged from 0000858877-18-000007:notes:170]

[0000858877-18-000015:notes:159]
[same as prior period, unchanged from 0000858877-18-000007:notes:171]

[0000858877-18-000015:notes:160]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 29, 2017 | 12 |  |  | $ | 6.15 |  |
| Assumed from acquisitions | 3 |  |  | 8.20 |  |
| Exercised | (8 | ) |  | 5.77 |  |
| Canceled/forfeited/expired | (1 | ) |  | 8.75 |  |
| BALANCE AT JULY 28, 2018 | 6 |  |  | 7.18 |  |
| Exercised | (1 | ) |  | 6.50 |  |
| BALANCE AT OCTOBER 27, 2018 | 5 |  |  | $ | 7.29 |  |

[0000858877-18-000015:notes:161]
The following table summarizes significant ranges of outstanding and exercisable stock options as of October 27, 2018 (in millions, except years and share prices):

[0000858877-18-000015:notes:162]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 35.00 |  | 5 |  |  | 5.8 |  | $ | 7.29 |  |  | $ | 195 |  |  | 4 |  |  | $ | 7.06 |  |  | $ | 140 |  |

[0000858877-18-000015:notes:163]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on our closing stock price of $44.25 as of October 26, 2018. The total number of in-the-money stock options exercisable as of October 27, 2018 was 4 million. As of July 28, 2018, 4 million outstanding stock options were exercisable and the weighted-average exercise price was $6.84.

[0000858877-18-000015:notes:164]
[same as prior period, unchanged from 0000858877-18-000007:notes:176]

[0000858877-18-000015:notes:165]
Time-based restricted stock units and performance-based restricted stock units ("PRSUs") that are based on our financial performance metrics or non-financial operating goals are valued using the market value of our common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, we estimated the fair value of the total shareholder return ("TSR") component of the PRSUs using a Monte Carlo simulation model. The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-18-000015:notes:166]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE BASEDRESTRICTED STOCK UNITS |
| Three Months Ended | October 27, 2018 |  | October 28, 2017 |  | October 27, 2018 |  | October 28, 2017 |
| Number of shares granted (in millions) | 6 |  |  | 7 |  |  | 2 |  |  | 3 |  |
| Grant date fair value per share | $ | 44.32 |  |  | $ | 29.81 |  |  | $ | 47.00 |  |  | $ | 31.31 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 2.8 | % |  | 3.6 | % |  | 2.8 | % |  | 3.6 | % |
| Range of risk-free interest rates | 2.1% – 2.9% |  |  | 1.0% – 1.9% |  |  | 2.1% – 3.0% |  |  | 1.0%-1.6% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 13.0% – 65.2% |  |  | 13.2%-81.0% |  |

[0000858877-18-000015:notes:167]
The PRSUs granted during the periods presented are contingent on the achievement of our financial performance metrics, our comparative market-based returns, or the achievement of financial and non-financial operating goals. For the awards based on financial performance metrics or comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period. Generally, the remaining 50% of the PRSUs are earned based on our TSR measured against the benchmark TSR of a peer group over the same period. Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of our financial performance metrics or our comparative market-based returns and 0% to 100% of the target shares granted contingent on the achievement of non-financial operating goals.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000858877-18-000015:notes:168]
Employee equity share options, unvested shares, and similar equity instruments granted and assumed by Cisco are treated as potential common shares outstanding in computing diluted earnings per share. Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that has not yet recognized are collectively assumed to be used to repurchase shares.


## us-gaap:EarningsPerShareTextBlock

[0000858877-18-000015:notes:169]
Net Income per Share

[0000858877-18-000015:notes:170]
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-18-000015:notes:171]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Net income | $ | 3,549 |  |  | $ | 2,394 |  |
| Weighted-average shares—basic | 4,565 |  |  | 4,959 |  |
| Effect of dilutive potential common shares | 49 |  |  | 35 |  |
| Weighted-average shares—diluted | 4,614 |  |  | 4,994 |  |
| Net income per share—basic | $ | 0.78 |  |  | $ | 0.48 |  |
| Net income per share—diluted | $ | 0.77 |  |  | $ | 0.48 |  |
| Antidilutive employee share-based awards, excluded | 9 |  |  | 15 |  |


## us-gaap:EquitySecuritiesWithoutReadilyDeterminableFairValueTableTextBlock

[0000858877-18-000015:notes:172]
We recorded adjustments to the carrying value of our non-marketable equity securities measured using the measurement alternative in the first quarter of fiscal 2019 as follows (in millions):

[0000858877-18-000015:notes:173]
|  | Three Months Ended |
|  | October 27, 2018 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |
| Upward adjustments | $ | 10 |  |
| Downward adjustments, including impairments | (16 | ) |
| Net downward adjustments | $ | (6 | ) |

[0000858877-18-000015:notes:174]
Gains and losses recognized on our marketable and non-marketable equity securities for the first quarter of fiscal 2019 are summarized below (in millions):

[0000858877-18-000015:notes:175]
|  | Three Months Ended |
|  | October 27, 2018 |
| Net gains and losses recognized during the period on equity investments | $ | 8 |  |
| Less: Net gains and losses recognized on equity investments sold | (12 | ) |
| Unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | (4 | ) |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-18-000015:notes:176]
The following table presents gains and losses on assets that were measured at fair value on a nonrecurring basis (in millions):

[0000858877-18-000015:notes:177]
|  | TOTAL GAINS (LOSSES) FOR THE THREE MONTHS ENDED |
|  | October 27, 2018 |  | October 28, 2017 |
| Non-marketable equity securities | $ | (6 | ) |  | $ | (21 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-18-000015:notes:178]
[same as prior period, unchanged from 0000858877-18-000007:notes:188]

[0000858877-18-000015:notes:179]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, we consider the principal or most advantageous market in which we would transact, and we also consider assumptions that market participants would use when pricing the asset or liability.

[0000858877-18-000015:notes:180]
[same as prior period, unchanged from 0000858877-18-000007:notes:190]

[0000858877-18-000015:notes:181]
[same as prior period, unchanged from 0000858877-18-000007:notes:191]

[0000858877-18-000015:notes:182]
[same as prior period, unchanged from 0000858877-18-000007:notes:192]

[0000858877-18-000015:notes:183]
[same as prior period, unchanged from 0000858877-18-000007:notes:193]

[0000858877-18-000015:notes:184]
[same as prior period, unchanged from 0000858877-18-000007:notes:194]

[0000858877-18-000015:notes:185]
[same as prior period, unchanged from 0000858877-18-000007:notes:195]

[0000858877-18-000015:notes:186]
Assets and liabilities measured at fair value on a recurring basis were as follows (in millions):

[0000858877-18-000015:notes:187]
|  | OCTOBER 27, 2018FAIR VALUE MEASUREMENTS |  | JULY 28, 2018FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 6,332 |  |  | $ | — |  |  | $ | 6,332 |  |  | $ | 6,890 |  |  | $ | — |  |  | $ | 6,890 |  |
| Commercial paper | — |  |  | 210 |  |  | 210 |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposit | — |  |  | 20 |  |  | 20 |  |  | — |  |  | — |  |  | — |  |
| Repurchase agreements | — |  |  | 16 |  |  | 16 |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 5,754 |  |  | 5,754 |  |  | — |  |  | 7,275 |  |  | 7,275 |  |
| U.S. government agency securities | — |  |  | 430 |  |  | 430 |  |  | — |  |  | 727 |  |  | 727 |  |
| Non-U.S. government and agency securities | — |  |  | 153 |  |  | 153 |  |  | — |  |  | 208 |  |  | 208 |  |
| Corporate debt securities | — |  |  | 26,031 |  |  | 26,031 |  |  | — |  |  | 27,364 |  |  | 27,364 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,421 |  |  | 1,421 |  |  | — |  |  | 1,435 |  |  | 1,435 |  |
| Commercial paper | — |  |  | 309 |  |  | 309 |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposit | — |  |  | 85 |  |  | 85 |  |  | — |  |  | — |  |  | — |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | — |  |  | — |  |  | — |  |  | 605 |  |  | — |  |  | 605 |  |
| Derivative assets | — |  |  | 6 |  |  | 6 |  |  | — |  |  | 2 |  |  | 2 |  |
| Total | $ | 6,332 |  |  | $ | 34,435 |  |  | $ | 40,767 |  |  | $ | 7,495 |  |  | $ | 37,011 |  |  | $ | 44,506 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 91 |  |  | $ | 91 |  |  | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |
| Total | $ | — |  |  | $ | 91 |  |  | $ | 91 |  |  | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |

[0000858877-18-000015:notes:188]
Level 1 marketable equity securities are determined by using quoted prices in active markets for identical assets. Level 2 available-for-sale debt investments are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of these assets and liabilities. We use such pricing data as the primary input to make our assessments and determinations as to the ultimate valuation of our investment portfolio and have not made, during the periods presented, any material adjustments to such inputs. We are ultimately responsible for the financial statements and underlying estimates. Our derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs. We did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.

[0000858877-18-000015:notes:189]
[same as prior period, unchanged from 0000858877-18-000007:notes:200]

[0000858877-18-000015:notes:190]
These assets were measured at fair value due to events or circumstances we identified as having significant impact on their fair value during the respective periods. The carrying value of our non-marketable equity securities recorded to fair value on a non-recurring basis is adjusted for observable transactions for identical or similar investments of the same issuer or impairment. These securities are classified as Level 3 in the fair value hierarchy because we estimate the value based on valuation methods using the observable transaction price at the transaction date and other unobservable inputs such as volatility, rights, and obligations of the securities we hold.

[0000858877-18-000015:notes:191]
[same as prior period, unchanged from 0000858877-18-000007:notes:205]

[0000858877-18-000015:notes:192]
The fair value of short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of long-term loan receivables and financed service contracts as of October 27, 2018 and July 28, 2018 was $3.4 billion and $3.6 billion, respectively. The estimated fair value of long-term loan receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-18-000015:notes:193]
As of October 27, 2018, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of October 27, 2018, the fair value of our senior notes and other long-term debt was $26.2 billion with a carrying amount of $25.6 billion. This compares to a fair value of $26.4 billion and a carrying amount of $25.6 billion as of July 28, 2018. The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-18-000015:notes:194]
Gross receivables, excluding residual value, less unearned income categorized by our internal credit risk rating as of October 27, 2018 and July 28, 2018 are summarized as follows (in millions):

[0000858877-18-000015:notes:195]
|  | INTERNAL CREDIT RISK RATING |
| October 27, 2018 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,238 |  |  | $ | 1,084 |  |  | $ | 49 |  |  | $ | 2,371 |  |
| Loan receivables | 3,122 |  |  | 1,744 |  |  | 58 |  |  | 4,924 |  |
| Financed service contracts | 1,454 |  |  | 768 |  |  | 18 |  |  | 2,240 |  |
| Total | $ | 5,814 |  |  | $ | 3,596 |  |  | $ | 125 |  |  | $ | 9,535 |  |

[0000858877-18-000015:notes:196]
|  | INTERNAL CREDIT RISK RATING |
| July 28, 2018 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,294 |  |  | $ | 1,199 |  |  | $ | 54 |  |  | $ | 2,547 |  |
| Loan receivables | 3,184 |  |  | 1,752 |  |  | 63 |  |  | 4,999 |  |
| Financed service contracts | 1,468 |  |  | 835 |  |  | 23 |  |  | 2,326 |  |
| Total | $ | 5,946 |  |  | $ | 3,786 |  |  | $ | 140 |  |  | $ | 9,872 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-18-000015:notes:197]
[same as prior period, unchanged from 0000858877-18-000007:notes:212]

[0000858877-18-000015:notes:198]
[same as prior period, unchanged from 0000858877-18-000007:notes:213]

[0000858877-18-000015:notes:199]
Financing receivables primarily consist of lease receivables, loan receivables, and financed service contracts. Lease receivables represent sales-type and direct-financing leases resulting from the sale of Cisco’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services, which may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables generally have terms of up to three years. Financed service contracts include financing receivables related to technical support and advanced services. Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one to three years.

[0000858877-18-000015:notes:200]
A summary of our financing receivables is presented as follows (in millions):

[0000858877-18-000015:notes:201]
| October 27, 2018 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,511 |  |  | $ | 4,924 |  |  | $ | 2,240 |  |  | $ | 9,675 |  |
| Residual value | 159 |  |  | — |  |  | — |  |  | 159 |  |
| Unearned income | (140 | ) |  | — |  |  | — |  |  | (140 | ) |
| Allowance for credit loss | (131 | ) |  | (60 | ) |  | (8 | ) |  | (199 | ) |
| Total, net | $ | 2,399 |  |  | $ | 4,864 |  |  | $ | 2,232 |  |  | $ | 9,495 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,143 |  |  | $ | 2,422 |  |  | $ | 1,286 |  |  | $ | 4,851 |  |
| Noncurrent | 1,256 |  |  | 2,442 |  |  | 946 |  |  | 4,644 |  |
| Total, net | $ | 2,399 |  |  | $ | 4,864 |  |  | $ | 2,232 |  |  | $ | 9,495 |  |

[0000858877-18-000015:notes:202]
| July 28, 2018 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,688 |  |  | $ | 4,999 |  |  | $ | 2,326 |  |  | $ | 10,013 |  |
| Residual value | 164 |  |  | — |  |  | — |  |  | 164 |  |
| Unearned income | (141 | ) |  | — |  |  | — |  |  | (141 | ) |
| Allowance for credit loss | (135 | ) |  | (60 | ) |  | (10 | ) |  | (205 | ) |
| Total, net | $ | 2,576 |  |  | $ | 4,939 |  |  | $ | 2,316 |  |  | $ | 9,831 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,249 |  |  | $ | 2,376 |  |  | $ | 1,324 |  |  | $ | 4,949 |  |
| Noncurrent | 1,327 |  |  | 2,563 |  |  | 992 |  |  | 4,882 |  |
| Total, net | $ | 2,576 |  |  | $ | 4,939 |  |  | $ | 2,316 |  |  | $ | 9,831 |  |

[0000858877-18-000015:notes:203]
Future minimum lease payments to Cisco on lease receivables as of October 27, 2018 are summarized as follows (in millions):

[0000858877-18-000015:notes:204]
| Fiscal Year | Amount |
| 2019 (remaining nine months) | $ | 1,105 |  |
| 2020 | 614 |  |
| 2021 | 478 |  |
| 2022 | 231 |  |
| 2023 | 78 |  |
| Thereafter | 5 |  |
| Total | $ | 2,511 |  |

[0000858877-18-000015:notes:205]
[same as prior period, unchanged from 0000858877-18-000007:notes:220]

[0000858877-18-000015:notes:206]
[same as prior period, unchanged from 0000858877-18-000007:notes:221]

[0000858877-18-000015:notes:207]
We determine the adequacy of our allowance for credit loss by assessing the risks and losses inherent in our financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by us to our customers, which consist of the following: lease receivables, loan receivables, and financed service contracts.

[0000858877-18-000015:notes:208]
Our internal credit risk ratings of 1 through 4 correspond to investment-grade ratings, while credit risk ratings of 5 and 6 correspond to non-investment grade ratings. Credit risk ratings of 7 and higher correspond to substandard ratings.

[0000858877-18-000015:notes:209]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of October 27, 2018 and July 28, 2018 (in millions):

[0000858877-18-000015:notes:210]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| October 27, 2018 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 79 |  |  | $ | 27 |  |  | $ | 121 |  |  | $ | 227 |  |  | $ | 2,144 |  |  | $ | 2,371 |  |  | $ | 5 |  |  | $ | 5 |  |
| Loan receivables | 123 |  |  | 85 |  |  | 348 |  |  | 556 |  |  | 4,368 |  |  | 4,924 |  |  | 29 |  |  | 29 |  |
| Financed service contracts | 102 |  |  | 147 |  |  | 262 |  |  | 511 |  |  | 1,729 |  |  | 2,240 |  |  | 3 |  |  | 3 |  |
| Total | $ | 304 |  |  | $ | 259 |  |  | $ | 731 |  |  | $ | 1,294 |  |  | $ | 8,241 |  |  | $ | 9,535 |  |  | $ | 37 |  |  | $ | 37 |  |

[0000858877-18-000015:notes:211]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 28, 2018 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 72 |  |  | $ | 27 |  |  | $ | 155 |  |  | $ | 254 |  |  | $ | 2,293 |  |  | $ | 2,547 |  |  | $ | 9 |  |  | $ | 9 |  |
| Loan receivables | 104 |  |  | 55 |  |  | 252 |  |  | 411 |  |  | 4,588 |  |  | 4,999 |  |  | 30 |  |  | 30 |  |
| Financed service contracts | 138 |  |  | 78 |  |  | 304 |  |  | 520 |  |  | 1,806 |  |  | 2,326 |  |  | 3 |  |  | 3 |  |
| Total | $ | 314 |  |  | $ | 160 |  |  | $ | 711 |  |  | $ | 1,185 |  |  | $ | 8,687 |  |  | $ | 9,872 |  |  | $ | 42 |  |  | $ | 42 |  |

[0000858877-18-000015:notes:212]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract. The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $474 million and $503 million as of October 27, 2018 and July 28, 2018, respectively.

[0000858877-18-000015:notes:213]
As of October 27, 2018, we had financing receivables of $234 million, net of unbilled or current receivables, that were in the category of 91 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $182 million as of July 28, 2018.

[0000858877-18-000015:notes:214]
[same as prior period, unchanged from 0000858877-18-000007:notes:230]

[0000858877-18-000015:notes:215]
We assess the allowance for credit loss related to financing receivables on either an individual or a collective basis. We consider various factors in evaluating lease and loan receivables and the earned portion of financed service contracts for possible impairment on an individual basis. These factors include our historical experience, credit quality and age of the receivable balances, and economic conditions that may affect a customer’s ability to pay. When the evaluation indicates that it is probable that all amounts due pursuant to the contractual terms of the financing agreement, including scheduled interest payments, are unable to be collected, the financing receivable is considered impaired. All such outstanding amounts, including any accrued interest, will be assessed and fully reserved at the customer level. Our internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality financing receivables.

[0000858877-18-000015:notes:216]
Typically, we also consider receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. These balances, as of October 27, 2018 and July 28, 2018, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-18-000015:notes:217]
We evaluate the remainder of our financing receivables portfolio for impairment on a collective basis and record an allowance for credit loss at the portfolio segment level. When evaluating the financing receivables on a collective basis, we use expected default frequency rates published by a major third-party credit-rating agency as well as our own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk, and correlation.

[0000858877-18-000015:notes:218]
[same as prior period, unchanged from 0000858877-18-000007:notes:234]

[0000858877-18-000015:notes:219]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-18-000015:notes:220]
|  | October 27, 2018 |  | July 28, 2018 |
| Operating lease assets | $ | 475 |  |  | $ | 356 |  |
| Accumulated depreciation | (333 | ) |  | (238 | ) |
| Operating lease assets, net | $ | 142 |  |  | $ | 118 |  |

[0000858877-18-000015:notes:221]
Minimum future rentals on noncancelable operating leases as of October 27, 2018 are summarized as follows (in millions):

[0000858877-18-000015:notes:222]
| Fiscal Year | Amount |
| 2019 (remaining nine months) | $ | 125 |  |
| 2020 | 108 |  |
| 2021 | 44 |  |
| 2022 | 3 |  |
| Thereafter | 1 |  |
| Total | $ | 281 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-18-000015:notes:223]
[same as prior period, unchanged from 0000858877-18-000007:notes:239]

[0000858877-18-000015:notes:224]
[same as prior period, unchanged from 0000858877-18-000007:notes:240]

[0000858877-18-000015:notes:225]
The following table presents the goodwill allocated to our reportable segments as of October 27, 2018 and during the first quarter of fiscal 2019 (in millions):

[0000858877-18-000015:notes:226]
|  | Balance at |  |  |  |  |  | Balance at |
|  | July 28, 2018 |  | Acquisitions |  | Other |  | October 27, 2018 |
| Americas | $ | 19,998 |  |  | $ | 1,073 |  |  | $ | (53 | ) |  | $ | 21,018 |  |
| EMEA | 7,529 |  |  | 491 |  |  | (19 | ) |  | 8,001 |  |
| APJC | 4,179 |  |  | 199 |  |  | (11 | ) |  | 4,367 |  |
| Total | $ | 31,706 |  |  | $ | 1,763 |  |  | $ | (83 | ) |  | $ | 33,386 |  |

[0000858877-18-000015:notes:227]
“Other” in the table above primarily consists of foreign currency translation as well as immaterial purchase accounting adjustments.

[0000858877-18-000015:notes:228]
[same as prior period, unchanged from 0000858877-18-000007:notes:244]

[0000858877-18-000015:notes:229]
[same as prior period, unchanged from 0000858877-18-000007:notes:245]

[0000858877-18-000015:notes:230]
There were no impairment charges related to purchased intangible assets for the first quarter of fiscal 2019 and fiscal 2018, respectively. Impairment charges are primarily a result of declines in estimated fair values of certain purchased intangible assets resulting from the reduction or elimination of expected future cash flows associated with certain of our technology and in-process research and development (IPR&D) intangible assets.

[0000858877-18-000015:notes:231]
The estimated future amortization expense of purchased intangible assets with finite lives as of October 27, 2018 is as follows (in millions):

[0000858877-18-000015:notes:232]
| Fiscal Year | Amount |
| 2019 (remaining nine months) | $ | 577 |  |
| 2020 | $ | 726 |  |
| 2021 | $ | 530 |  |
| 2022 | $ | 274 |  |
| 2023 | $ | 133 |  |
| Thereafter | $ | 45 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-18-000015:notes:233]
[same as prior period, unchanged from 0000858877-18-000007:notes:249]

[0000858877-18-000015:notes:234]
The effective tax rate for the first quarter of fiscal 2019 includes a $152 million tax benefit relating to indirect effects from the adoption of ASC 606 at the beginning of our first quarter of fiscal 2019.

[0000858877-18-000015:notes:235]
On December 22, 2017, the Tax Cuts and Jobs Act (the "Tax Act") was enacted. The Tax Act significantly revises the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (“federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries. The enactment of the Tax Act resulted in us recording a provisional tax expense of $10.4 billion in fiscal 2018.

[0000858877-18-000015:notes:236]
In December 2017, the Securities and Exchange Commission staff issued Staff Accounting Bulletin No. 118, which addresses how a company recognizes provisional estimates when a company does not have the necessary information available, prepared or analyzed (including computations) in reasonable detail to complete its accounting for the effect of the changes in the Tax Act. The measurement period ends when a company has obtained, prepared, and analyzed the information necessary to finalize its accounting, but cannot extend beyond one year. The final impact of the Tax Act may differ from the above provisional estimates due to changes in interpretations of the Tax Act, any legislative action to address questions that arise because of the Tax Act, by changes in accounting standard for income taxes and related interpretations in response to the Tax Act, and any updates or changes to estimates used in the provisional amounts. We have determined that the $8.1 billion of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries, the $1.2 billion of foreign withholding tax, and the $1.1 billion of tax expense for DTA re-measurement were each provisional amounts and reasonable estimates as of October 27, 2018. Estimates used in the provisional amounts include: the anticipated reversal pattern of the gross DTAs; and earnings, cash positions, foreign taxes and withholding taxes attributable to foreign subsidiaries. The provisional tax expense related to the U.S. transition tax on accumulated earnings in foreign subsidiaries includes an $863 million benefit related to the U.S. taxation of deemed foreign dividends in the transition fiscal year. This benefit may be reduced or eliminated in future legislation. If such legislation is enacted, we will record the impact of the legislation in the quarter of enactment.

[0000858877-18-000015:notes:237]
The Tax Act includes a Global Intangible Low-Taxed Income ("GILTI") provision that imposes U.S. tax on certain foreign subsidiary income in the year it is earned. Our accounting policy is to treat tax on GILTI as a current period cost included in tax expense in the year incurred.

[0000858877-18-000015:notes:238]
As of October 27, 2018, we had $1.9 billion of unrecognized tax benefit, of which $1.7 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.  We estimate that the unrecognized tax benefits at October 27, 2018 could be reduced by approximately $200 million in the next 12 months.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-18-000015:notes:239]
The following table summarizes the maturities of our available-for-sale debt investments as of October 27, 2018 (in millions):

[0000858877-18-000015:notes:240]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 12,283 |  |  | $ | 12,243 |  |
| After 1 year through 5 years | 19,248 |  |  | 18,922 |  |
| After 5 years through 10 years | 1,662 |  |  | 1,581 |  |
| After 10 years | 15 |  |  | 16 |  |
| Mortgage-backed securities with no single maturity | 1,481 |  |  | 1,421 |  |
| Total | $ | 34,689 |  |  | $ | 34,183 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-18-000015:notes:241]
Available-for-Sale Debt Investments and Equity Investments

[0000858877-18-000015:notes:242]
The following table summarizes our available-for-sale debt investments and equity investments (in millions):

[0000858877-18-000015:notes:243]
|  | October 27, 2018 |  | July 28, 2018 |
| Available-for-sale debt investments | $ | 34,183 |  |  | $ | 37,009 |  |
| Marketable equity securities | — |  |  | 605 |  |
| Total investments | 34,183 |  |  | 37,614 |  |
| Non-marketable equity securities included in other assets | 1,125 |  |  | 978 |  |
| Equity method investments included in other assets | 115 |  |  | 118 |  |
| Total | $ | 35,423 |  |  | $ | 38,710 |  |

[0000858877-18-000015:notes:244]
| (a) | Summary of Available-for-Sale Debt Investments |

[0000858877-18-000015:notes:245]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-18-000015:notes:246]
| October 27, 2018 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 5,783 |  |  | $ | — |  |  | $ | (29 | ) |  | $ | 5,754 |  |
| U.S. government agency securities | 434 |  |  | — |  |  | (4 | ) |  | 430 |  |
| Non-U.S. government and agency securities | 153 |  |  | — |  |  | — |  |  | 153 |  |
| Corporate debt securities | 26,444 |  |  | 33 |  |  | (446 | ) |  | 26,031 |  |
| U.S. agency mortgage-backed securities | 1,481 |  |  | — |  |  | (60 | ) |  | 1,421 |  |
| Commercial paper | 309 |  |  | — |  |  | — |  |  | 309 |  |
| Certificates of deposit | 85 |  |  | — |  |  | — |  |  | 85 |  |
| Total (1) | $ | 34,689 |  |  | $ | 33 |  |  | $ | (539 | ) |  | $ | 34,183 |  |

[0000858877-18-000015:notes:247]
| July 28, 2018 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 7,318 |  |  | $ | — |  |  | $ | (43 | ) |  | $ | 7,275 |  |
| U.S. government agency securities | 732 |  |  | — |  |  | (5 | ) |  | 727 |  |
| Non-U.S. government and agency securities | 209 |  |  | — |  |  | (1 | ) |  | 208 |  |
| Corporate debt securities | 27,765 |  |  | 44 |  |  | (445 | ) |  | 27,364 |  |
| U.S. agency mortgage-backed securities | 1,488 |  |  | — |  |  | (53 | ) |  | 1,435 |  |
| Total (1) | $ | 37,512 |  |  | $ | 44 |  |  | $ | (547 | ) |  | $ | 37,009 |  |

[0000858877-18-000015:notes:248]
(1) Net unsettled investment purchases were $1 million and net unsettled investment sales were $1.5 billion as of October 27, 2018 and July 28, 2018, respectively and were included in other current assets and other current liabilities.

[0000858877-18-000015:notes:249]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-18-000015:notes:250]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-18-000015:notes:251]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Gross realized gains | $ | 2 |  |  | $ | 8 |  |
| Gross realized losses | (8 | ) |  | (4 | ) |
| Total | $ | (6 | ) |  | $ | 4 |  |

[0000858877-18-000015:notes:252]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 27, 2018 and July 28, 2018 (in millions):

[0000858877-18-000015:notes:253]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 27, 2018 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 516 |  |  | $ | (3 | ) |  | $ | 5,231 |  |  | $ | (26 | ) |  | $ | 5,747 |  |  | $ | (29 | ) |
| U.S. government agency securities | 4 |  |  | — |  |  | 427 |  |  | (4 | ) |  | 431 |  |  | (4 | ) |
| Non-U.S. government and agency securities | — |  |  | — |  |  | 153 |  |  | — |  |  | 153 |  |  | — |  |
| Corporate debt securities | 13,483 |  |  | (257 | ) |  | 6,738 |  |  | (189 | ) |  | 20,221 |  |  | (446 | ) |
| U.S. agency mortgage-backed securities | 456 |  |  | (12 | ) |  | 947 |  |  | (48 | ) |  | 1,403 |  |  | (60 | ) |
| Total | $ | 14,459 |  |  | $ | (272 | ) |  | $ | 13,496 |  |  | $ | (267 | ) |  | $ | 27,955 |  |  | $ | (539 | ) |

[0000858877-18-000015:notes:254]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 28, 2018 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 2,966 |  |  | $ | (20 | ) |  | $ | 4,303 |  |  | $ | (23 | ) |  | $ | 7,269 |  |  | $ | (43 | ) |
| U.S. government agency securities | 206 |  |  | (2 | ) |  | 521 |  |  | (3 | ) |  | 727 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 105 |  |  | (1 | ) |  | 103 |  |  | — |  |  | 208 |  |  | (1 | ) |
| Corporate debt securities | 16,990 |  |  | (344 | ) |  | 3,511 |  |  | (101 | ) |  | 20,501 |  |  | (445 | ) |
| U.S. agency mortgage-backed securities | 826 |  |  | (24 | ) |  | 581 |  |  | (29 | ) |  | 1,407 |  |  | (53 | ) |
| Total | $ | 21,093 |  |  | $ | (391 | ) |  | $ | 9,019 |  |  | $ | (156 | ) |  | $ | 30,112 |  |  | $ | (547 | ) |

[0000858877-18-000015:notes:255]
During the first quarter of fiscal 2019 and fiscal 2018, respectively, we did not recognize any impairment charges on our available-for-sale debt investments. For available-for-sale debt investments that were in an unrealized loss position as of October 27, 2018, we have determined that no other-than-temporary impairments were required to be recognized.

[0000858877-18-000015:notes:256]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-18-000015:notes:257]
| (b) | Summary of Equity Investments |

[0000858877-18-000015:notes:258]
| (c) | Securities Lending |

[0000858877-18-000015:notes:259]
We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending was $0.5 billion as of each of the first quarters of fiscal 2019 and fiscal 2018, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 27, 2018 and July 28, 2018, we had no outstanding securities lending transactions.

[0000858877-18-000015:notes:260]
| (d) | Variable Interest Entities |

[0000858877-18-000015:notes:261]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 27, 2018, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-18-000015:notes:262]
As of October 27, 2018, the carrying value of our non-marketable equity securities was $1.2 billion, of which $670 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, we have additional funding commitments of $204 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these variable interest entities.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000858877-18-000015:notes:263]
New Accounting Updates Recently Adopted

[0000858877-18-000015:notes:264]
Revenue Recognition  In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers, a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP on revenue recognition and eliminated industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. It also requires increased disclosures including the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

[0000858877-18-000015:notes:265]
ASC 606 allows two methods of adoption: i) retrospectively to each prior period presented (“full retrospective method”), or ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective method"). At the beginning of the first quarter of fiscal 2019, we adopted ASC 606 using the modified retrospective method to those contracts that were not completed as of July 28, 2018. Refer to Opening Balance Adjustments below for the impact of adoption on our Consolidated Financial Statements.

[0000858877-18-000015:notes:266]
We have implemented new accounting policies, systems, processes, and internal controls necessary to support the requirements of ASC 606.

[0000858877-18-000015:notes:267]
ASC 606 primarily impacts our revenue recognition for software arrangements and sales to two-tier distributors. In both areas, the new standard accelerates the recognition of revenue.

[0000858877-18-000015:notes:268]
The table below details the timing of when revenue was typically recognized under the prior revenue standard compared to the timing of when revenue is typically recognized under ASC 606 for these major areas:

[0000858877-18-000015:notes:269]
|  |  | Prior Revenue Standard |  | ASC 606 |
| Software arrangements: |  |  |  |  |
| Perpetual software licenses |  | Upfront |  | Upfront |
| Term software licenses |  | Ratable |  | Upfront |
| Security software licenses |  | Ratable |  | Ratable |
| Enterprise license agreements (software licenses) |  | Ratable |  | Upfront |
| Software support (maintenance) |  | Ratable |  | Ratable |
| Software-as-a-service |  | Ratable |  | Ratable |
| Two-tier distribution |  | Sell-Through |  | Sell-In |

[0000858877-18-000015:notes:270]
In addition to the above revenue recognition timing impacts, ASC 606 requires incremental contract acquisition costs (such as sales commissions) for customer contracts to be capitalized and amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the assets relates.

[0000858877-18-000015:notes:271]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

[0000858877-18-000015:notes:272]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or once delivery and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-18-000015:notes:273]
Significant Judgments

[0000858877-18-000015:notes:274]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-18-000015:notes:275]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes various rebate, cooperative marketing, and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

[0000858877-18-000015:notes:276]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license's utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a distinct performance obligation satisfied over the contract term.

[0000858877-18-000015:notes:277]
For the additional disclosures required as part of ASC 606 see Note 3.

[0000858877-18-000015:notes:278]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The most significant impact of this accounting standard update is that it requires the remeasurement of investments not accounted for under the equity method to be recorded at fair value through the Consolidated Statement of Operations at the end of each reporting period. The application of this accounting standard update increases the variability of other income (loss), net.

[0000858877-18-000015:notes:279]
Our equity investments are accounted for as follows:

[0000858877-18-000015:notes:280]
| • | Marketable equity securities have readily determinable fair value (RDFV) that are measured and recorded at fair value. |

[0000858877-18-000015:notes:281]
| • | Non-marketable equity securities do not have RDFV and are measured using a measurement alternative recorded at cost less any impairment, plus or minus changes resulting from qualifying observable price changes. For certain of these securities, we have elected to apply the net asset value (NAV) practical expedient. The NAV is the estimated fair value of these investments. |

[0000858877-18-000015:notes:282]
| • | Equity method investments are securities we do not control, but are able to exert significant influence over the investee. These investments are measured at cost less any impairment, plus or minus our share of equity method investee income or loss. |

[0000858877-18-000015:notes:283]
We adopted this accounting standard update beginning the first quarter of fiscal 2019. The standard was adopted using the modified retrospective method for our marketable equity securities and non-marketable equity securities measured using the NAV practical expedient. For our non-marketable equity securities measured using the measurement alternative, we applied the prospective method. Refer to Opening Balance Adjustments below for the impact of adoption on our Consolidated Balance Sheet.

[0000858877-18-000015:notes:284]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a modified retrospective basis. The ongoing impact of this standard will be facts and circumstances dependent on any transactions within its scope. Refer to Opening Balance Adjustments below for the impact of adoption on our Consolidated Balance Sheet.

[0000858877-18-000015:notes:285]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a retrospective basis. The application of this accounting standard update did not have an impact on our Consolidated Statements of Cash Flows.

[0000858877-18-000015:notes:286]
Restricted Cash in Statement of Cash Flows  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented. The application of this accounting standard update did not have a material impact on our Consolidated Statements of Cash Flows. Prior period information has been retrospectively adjusted due to the adoption of ASU 2016-18, Statement of Cash Flows, Restricted Cash in the beginning of the first quarter of fiscal 2019.

[0000858877-18-000015:notes:287]
Simplifying the Test for Goodwill Impairment  In January 2017, the FASB issued an accounting standard update that removes Step

[0000858877-18-000015:notes:288]
2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. We early adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a prospective basis. The application of this accounting standard update did not have a material impact on our Consolidated Financial Statements.

[0000858877-18-000015:notes:289]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be fact dependent, but we expect that some transactions that were previously accounted for as business combinations or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.

[0000858877-18-000015:notes:290]
Opening Balance Adjustments

[0000858877-18-000015:notes:291]
The following table summarizes the cumulative effect of the changes made to the Consolidated Balance Sheet for the adoption of ASC 606, ASU 2016-01, Financial Instruments, and ASU 2016-16, Intra-Entity Transfers of Assets Other than Inventory (in millions):

[0000858877-18-000015:notes:292]
| Line Item in Consolidated Balance Sheet: |  | Balance at July 28, 2018 |  | New Revenue Recognition Standard |  | New Financial Instruments Standard |  | New Intra-Entity Transfers Standard |  | Adjusted Balance at July 29, 2018 |
| ASSETS |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 5,554 |  |  | $ | (104 | ) | (1) | $ | — |  |  | $ | — |  |  | $ | 5,450 |  |
| Inventories |  | $ | 1,846 |  |  | $ | (302 | ) | (2) | $ | — |  |  | $ | — |  |  | $ | 1,544 |  |
| Other current assets (includes capitalized contract acquisition costs) |  | $ | 2,940 |  |  | $ | 371 |  | (3), (4) | $ | — |  |  | $ | (25 | ) | (3) | $ | 3,286 |  |
| Deferred tax assets |  | $ | 3,219 |  |  | $ | (624 | ) | (3) | $ | (15 | ) | (3) | $ | 1,415 |  | (8) | $ | 3,995 |  |
| Other assets (includes capitalized contract acquisition costs) |  | $ | 1,582 |  |  | $ | 327 |  | (4) | $ | 136 |  | (7) | $ | (91 | ) | (3) | $ | 1,954 |  |
| TOTAL ASSETS |  | $ | 108,784 |  |  | $ | (332 | ) |  | $ | 121 |  |  | $ | 1,299 |  |  | $ | 109,872 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |  |  |
| Income taxes payable |  | $ | 1,004 |  |  | $ | — |  |  | $ | — |  |  | $ | 11 |  | (3) | $ | 1,015 |  |
| Deferred revenue — current |  | $ | 11,490 |  |  | $ | (1,702 | ) | (5) | $ | — |  |  | $ | — |  |  | $ | 9,788 |  |
| Other current liabilities |  | $ | 4,413 |  |  | $ | 33 |  | (6) | $ | — |  |  | $ | — |  |  | $ | 4,446 |  |
| Deferred revenue — non-current |  | $ | 8,195 |  |  | $ | (1,081 | ) | (5) | $ | — |  |  | $ | — |  |  | $ | 7,114 |  |
| Other long-term liabilities |  | $ | 1,434 |  |  | $ | 85 |  | (3) | $ | 13 |  | (3) | $ | — |  |  | $ | 1,532 |  |
| Retained earnings |  | $ | 1,233 |  |  | $ | 2,333 |  | (10) | $ | 283 |  | (10) | $ | 1,281 |  | (10) | $ | 5,130 |  |
| Accumulated other comprehensive income (loss) |  | $ | (849 | ) |  | $ | — |  |  | $ | (175 | ) | (9) | $ | 7 |  | (3) | $ | (1,017 | ) |
| TOTAL LIABILITIES AND EQUITY |  | $ | 108,784 |  |  | $ | (332 | ) |  | $ | 121 |  |  | $ | 1,299 |  |  | $ | 109,872 |  |

[0000858877-18-000015:notes:293]
(1) Primarily represents the decrease to accounts receivable related to the change in recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis

[0000858877-18-000015:notes:294]
(2) Primarily represents the reduction of inventory for the change from recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis

[0000858877-18-000015:notes:295]
(3) Includes the impacts to deferred tax assets, liabilities and other income tax balances

[0000858877-18-000015:notes:296]
(4) Primarily represents capitalized contract acquisition costs (e.g. commissions)

[0000858877-18-000015:notes:297]
(5) Primarily represents deferred revenue adjusted to retained earnings primarily due to the change in revenue recognition for certain software arrangements from ratable to upfront, recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis. Of this total $2.8 billion adjustment, $2.6 billion related to product deferred revenue, of which $1.3 billion relates to our recurring software and subscription offers, $0.6 billion relates to two-tier distribution, and the remainder relates to non-recurring software and other adjustments.

[0000858877-18-000015:notes:298]
(6) Primarily represents the reclassification of accounts receivable contra balances to other current liabilities, adjustments to rebate liabilities for the change from recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis, and reclassifications from other current liabilities for amounts that are not contract liabilities under ASC 606

[0000858877-18-000015:notes:299]
(7) Represents the adjustment due to the remeasurement of non-marketable equity investments at fair value

[0000858877-18-000015:notes:300]
(8) Primarily represents the change in net deferred tax assets related to unrecognized income tax effects of intra-entity asset transfers

[0000858877-18-000015:notes:301]
(9) Represents the reclassification of net unrealized gains from accumulated other comprehensive income (loss) to retained earnings

[0000858877-18-000015:notes:302]
(10) Retained earnings impact from the adjustments noted above

[0000858877-18-000015:notes:303]
Impact of ASC 606 Adoption

[0000858877-18-000015:notes:304]
The application of ASC 606 increased our total revenue by $276 million in the first quarter of fiscal 2019. The application of ASC 606 did not have a material impact to either our cost of sales or our operating expenses in the first quarter of fiscal 2019. We recognized a $152 million benefit to our provision for income taxes relating to indirect effects from the adoption of ASC 606 in the first quarter of fiscal 2019. For additional information regarding ASC 606, see Note 3 to the Consolidated Financial Statements.

[0000858877-18-000015:notes:305]
In connection with the adoption of ASC 606, we recorded a transition adjustment to increase retained earnings by $2.3 billion. See above for the transition impact of ASC 606 by balance sheet line item. As of October 27, 2018, the balance sheet changes attributable to ASC 606 related to accounts receivable, inventories, and deferred revenue were not materially different than the impacts upon adoption. In connection with the adoption of ASC 606, we established contract assets for unbilled receivables. As of October 27, 2018, we had total contract assets of $447 million of which, $270 million was recorded in other current assets and $177 million was recorded in other assets. As of October 27, 2018, we had total capitalized contract acquisition costs of $673 million, of which $380 million was recorded in other current assets and $293 million was recorded in other assets. The adoption of ASC 606 did not have any impact on net cash provided by operating activities.

[0000858877-18-000015:notes:306]
| (b) | Recent Accounting Standards or Updates Not Yet Effective |

[0000858877-18-000015:notes:307]
Leases  In February 2016, the FASB issued an accounting standard update and subsequent amendments related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2020 and early adoption is permitted. We expect to adopt this accounting standard update on a modified retrospective basis in the first quarter of fiscal 2020, and we are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.

[0000858877-18-000015:notes:308]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2021 and early adoption in fiscal 2020 is permitted. We expect to adopt this accounting standard update on a modified retrospective basis in the first quarter of fiscal 2021, and we are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-18-000015:notes:309]
[same as prior period, unchanged from 0000858877-18-000007:notes:306]

[0000858877-18-000015:notes:310]
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2019 and fiscal 2018 are each 52-week fiscal years. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-18-000015:notes:311]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-18-000015:notes:312]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,707 |  |  | $ | 4,710 |  |
| Computer equipment and related software |  | 1,037 |  |  | 1,085 |  |
| Production, engineering, and other equipment |  | 5,712 |  |  | 5,734 |  |
| Operating lease assets |  | 475 |  |  | 356 |  |
| Furniture and fixtures |  | 363 |  |  | 358 |  |
| Total gross property and equipment |  | 12,294 |  |  | 12,243 |  |
| Less: accumulated depreciation and amortization |  | (9,338 | ) |  | (9,237 | ) |
| Total |  | $ | 2,956 |  |  | $ | 3,006 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-18-000015:notes:313]
[same as prior period, unchanged from 0000858877-18-000007:notes:310]

[0000858877-18-000015:notes:314]
We initiated a restructuring plan during fiscal 2018 (the "Fiscal 2018 Plan") in order to realign the organization and enable further investment in key priority areas with estimated pretax charges of approximately $300 million. In the first quarter of fiscal 2019, we expanded the restructuring plan to include an additional $300 million of estimated additional pretax charges. In connection with the Fiscal 2018 Plan, we have incurred cumulative charges of $186 million. These aggregate pretax charges are primarily cash-based and consist of employee severance and other one-time termination benefits, and other associated costs. We expect the Fiscal 2018 Plan to be substantially completed in fiscal 2019.

[0000858877-18-000015:notes:315]
We announced a restructuring plan in August 2016 (the "Fiscal 2017 Plan"), in order to reinvest in our key priority areas. In connection with the Fiscal 2017 Plan, we incurred cumulative charges of approximately $1.0 billion, which were primarily cash-based and consisted of employee severance and other one-time termination benefits, and other associated costs. We completed the Fiscal 2017 Plan in fiscal 2018.

[0000858877-18-000015:notes:316]
[same as prior period, unchanged from 0000858877-18-000007:notes:313]

[0000858877-18-000015:notes:317]
|  |  | FISCAL 2017 AND PRIOR PLANS |  | FISCAL 2018 PLAN |  |  |
|  |  | Employee Severance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 28, 2018 |  | $ | 41 |  |  | $ | 13 |  |  | $ | 19 |  |  | $ | — |  |  | $ | 73 |  |
| Charges |  | — |  |  | — |  |  | 54 |  |  | 24 |  |  | 78 |  |
| Cash payments |  | (10 | ) |  | (1 | ) |  | (52 | ) |  | (1 | ) |  | (64 | ) |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (23 | ) |  | (23 | ) |
| Liability as of October 27, 2018 |  | $ | 31 |  |  | $ | 12 |  |  | $ | 21 |  |  | $ | — |  |  | $ | 64 |  |

[0000858877-18-000015:notes:318]
|  |  | FISCAL 2017 AND PRIOR PLANS |  |  |
|  |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 29, 2017 |  | $ | 74 |  |  | $ | 43 |  |  | $ | 117 |  |
| Charges |  | 145 |  |  | 7 |  |  | 152 |  |
| Cash payments |  | (79 | ) |  | (16 | ) |  | (95 | ) |
| Non-cash items |  | — |  |  | (6 | ) |  | (6 | ) |
| Liability as of October 28, 2017 |  | $ | 140 |  |  | $ | 28 |  |  | $ | 168 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-18-000015:notes:319]
Revenue

[0000858877-18-000015:notes:320]
| (a) | Disaggregation of Revenue |

[0000858877-18-000015:notes:321]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. The following table presents this disaggregation of revenue (in millions):

[0000858877-18-000015:notes:322]
Amounts may not sum due to rounding.

[0000858877-18-000015:notes:323]
Infrastructure Platforms consist of our core networking technologies of switching, routing, data center products, and wireless that are designed to work together to deliver networking capabilities and transport and/or store data. These technologies consist of both hardware and software offerings, including software licenses and software-as-a-service (SaaS), that help our customers build networks, automate, orchestrate, integrate, and digitize data. We are shifting and expanding more of our business to software and subscriptions across our core networking portfolio. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-18-000015:notes:324]
Applications consists of offerings that utilize the core networking and data center platforms to provide their functions. The products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-18-000015:notes:325]
Security primarily includes our unified threat management, advanced threat security, and web security products. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers' network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-18-000015:notes:326]
Other Products primarily include our Service Provider Video Software Solutions, cloud and system management products. On May 1, 2018, we announced a definitive agreement to sell the SPVSS business. The sale was closed on October 28, 2018. These products include both hardware and software licenses. Our offerings in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control.

[0000858877-18-000015:notes:327]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and advanced services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Advanced services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

[0000858877-18-000015:notes:328]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for all of our hardware, software and service offerings. Refer to Note 8 for additional information. For these arrangements, cash is typically received over time.

[0000858877-18-000015:notes:329]
| (b) | Contract Balances |

[0000858877-18-000015:notes:330]
Accounts receivable, net was $4.5 billion as of October 27, 2018 compared to $5.6 billion as of July 28, 2018, as reported on the Consolidated Balance Sheet.

[0000858877-18-000015:notes:331]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of October 27, 2018 and July 29, 2018, our contract assets for these unbilled receivables were $447 million and $122 million, respectively, and were included in other current assets and other assets.

[0000858877-18-000015:notes:332]
Contract liabilities consist of deferred revenue. Deferred revenue was $16.8 billion as of October 27, 2018 compared to $19.7 billion as of July 28, 2018. In connection with the adoption of ASC 606, we recorded an adjustment to retained earnings to reduce deferred revenue by $2.8 billion. We recognized approximately $3.4 billion of revenue during the first quarter of fiscal 2019 that was included in the deferred revenue balance at July 29, 2018.

[0000858877-18-000015:notes:333]
| (c) | Remaining Performance Obligations |

[0000858877-18-000015:notes:334]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of October 27, 2018, the aggregate amount of RPO was $22.3 billion, comprised of $16.8 billion of deferred revenue and $5.5 billion of unbilled contract revenue. We expect approximately 55% of this amount to be recognized as revenue over the next year. Unbilled contract revenue represents non-cancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

[0000858877-18-000015:notes:335]
| (d) | Capitalized Contract Acquisition Costs |

[0000858877-18-000015:notes:336]
In connection with the adoption of ASC 606, we began to capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $673 million and $644 million as of October 27, 2018 and July 29, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $112 million for the first quarter of fiscal 2019 and was included in sales and marketing expenses.


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0000858877-18-000015:notes:337]
The following tables provide details of selected balance sheet items (in millions):

[0000858877-18-000015:notes:338]
|  |  | October 27, 2018 |  | July 28, 2018 |
| Cash and cash equivalents |  | $ | 8,410 |  |  | $ | 8,934 |  |
| Restricted cash included in other current assets |  | 32 |  |  | 32 |  |
| Restricted cash included in other assets |  | 44 |  |  | 27 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 8,486 |  |  | $ | 8,993 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000858877-18-000015:notes:339]
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 421 |  |  | $ | 423 |  |
| Work in Process |  | — |  |  | — |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales and distributor inventory |  | 116 |  |  | 443 |  |
| Manufactured finished goods |  | 758 |  |  | 689 |  |
| Total finished goods |  | 874 |  |  | 1,132 |  |
| Service-related spares |  | 248 |  |  | 258 |  |
| Demonstration systems |  | 29 |  |  | 33 |  |
| Total |  | $ | 1,572 |  |  | $ | 1,846 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-18-000015:notes:340]
[same as prior period, unchanged from 0000858877-18-000007:notes:319]

[0000858877-18-000015:notes:341]
[same as prior period, unchanged from 0000858877-18-000007:notes:320]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-18-000015:notes:342]
[same as prior period, unchanged from 0000858877-18-000007:notes:321]

[0000858877-18-000015:notes:343]
[same as prior period, unchanged from 0000858877-18-000007:notes:322]

[0000858877-18-000015:notes:344]
We declared and paid cash dividends of $0.33 and $0.29 per common share, or $1.5 billion and $1.4 billion, on our outstanding common stock for the first quarter of fiscal 2019 and fiscal 2018, respectively.

[0000858877-18-000015:notes:345]
Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-18-000015:notes:346]
[same as prior period, unchanged from 0000858877-18-000007:notes:325]

[0000858877-18-000015:notes:347]
In September 2001, our Board of Directors authorized a stock repurchase program. On February 14, 2018, our Board of Directors authorized a $25 billion increase to the stock repurchase program. As of October 27, 2018, the remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $14.0 billion, with no termination date.  A summary of the stock repurchase activity for fiscal year 2018 and 2017 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-18-000015:notes:348]
There were $130 million and $180 million of stock repurchases that were pending settlement as of October 27, 2018 and July 28, 2018, respectively.

[0000858877-18-000015:notes:349]
The purchase price for the shares of our stock repurchased is reflected as a reduction to shareholders’ equity. We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings and (ii) a reduction of common stock and additional paid-in capital.

[0000858877-18-000015:notes:350]
[same as prior period, unchanged from 0000858877-18-000007:notes:329]

[0000858877-18-000015:notes:351]
We repurchased approximately 7 million and 11 million shares, or $318 million and $342 million, of common stock in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units for each of the first quarter of fiscal 2019 and fiscal 2018, respectively.

[0000858877-18-000015:notes:352]
[same as prior period, unchanged from 0000858877-18-000007:notes:331]

[0000858877-18-000015:notes:353]
Under the terms of our Articles of Incorporation, the Board of Directors may determine the rights, preferences, and terms of our authorized but unissued shares of preferred stock.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-18-000015:notes:354]
[same as prior period, unchanged from 0000858877-18-000007:notes:333]
