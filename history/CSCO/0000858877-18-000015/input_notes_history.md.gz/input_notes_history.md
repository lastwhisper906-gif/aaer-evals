# CSCO note change history — 0000858877-18-000007 → 0000858877-18-000015


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2018-11-20):
[0000858877-18-000015:note_history:1]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, Germany, India, Israel, Japan, Mexico, Poland and the United Kingdom. We also lease equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of October 27, 2018 are as follows (in millions):

- changed (2018-11-20):
[0000858877-18-000015:note_history:2]
| Fiscal Year | Amount |
| 2019 (remaining nine months) | $ | 312 |  |
| 2020 | 323 |  |
| 2021 | 220 |  |
| 2022 | 152 |  |
| 2023 | 102 |  |
| Thereafter | 116 |  |
| Total | $ | 1,225 |  |
  (was, 2018-05-22, similarity 0.9772):
[0000858877-18-000007:note_history:2]
| Fiscal Year | Amount |
| 2018 (remaining three months) | $ | 110 |  |
| 2019 | 343 |  |
| 2020 | 251 |  |
| 2021 | 164 |  |
| 2022 | 131 |  |
| Thereafter | 194 |  |
| Total | $ | 1,193 |  |

- added (2018-11-20):
[0000858877-18-000015:note_history:3]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

- changed (2018-11-20):
[0000858877-18-000015:note_history:4]
The following table summarizes our purchase commitments with contract manufacturers and suppliers (in millions):
  (was, 2018-05-22, similarity 0.824):
[0000858877-18-000007:note_history:4]
The following table summarizes the Company's purchase commitments with contract manufacturers and suppliers as of the respective period ends (in millions):

- changed (2018-11-20):
[0000858877-18-000015:note_history:5]
| Commitments by Period | October 27, 2018 |  | July 28, 2018 |
| Less than 1 year | $ | 5,500 |  |  | $ | 5,407 |  |
| 1 to 3 years | 704 |  |  | 710 |  |
| 3 to 5 years | 270 |  |  | 360 |  |
| Total | $ | 6,474 |  |  | $ | 6,477 |  |
  (was, 2018-05-22, similarity 0.9681):
[0000858877-18-000007:note_history:5]
| Commitments by Period | April 28, 2018 |  | July 29, 2017 |
| Less than 1 year | $ | 5,077 |  |  | $ | 4,620 |  |
| 1 to 3 years | 700 |  |  | 20 |  |
| 3 to 5 years | 450 |  |  | — |  |
| Total | $ | 6,227 |  |  | $ | 4,640 |  |

- added (2018-11-20):
[0000858877-18-000015:note_history:6]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 27, 2018 and July 28, 2018, the liability for these purchase commitments was $150 million and $159 million, respectively, and was included in other current liabilities.

- added (2018-11-20):
[0000858877-18-000015:note_history:7]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

- changed (2018-11-20):
[0000858877-18-000015:note_history:8]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Compensation expense related to acquisitions | $ | 109 |  |  | $ | 42 |  |
  (was, 2018-05-22, similarity 0.7134):
[0000858877-18-000007:note_history:8]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Compensation expense related to acquisitions | $ | 53 |  |  | $ | 36 |  |  | $ | 141 |  |  | $ | 173 |  |

- changed (2018-11-20):
[0000858877-18-000015:note_history:9]
As of October 27, 2018, we estimated that future cash compensation expense of up to $585 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2018-05-22, similarity 0.9431):
[0000858877-18-000007:note_history:9]
As of April 28, 2018, the Company estimated that future cash compensation expense of up to $370 million may be required to be recognized pursuant to the applicable business combination agreements.

- added (2018-11-20):
[0000858877-18-000015:note_history:10]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $378 million and $223 million as of October 27, 2018 and July 28, 2018, respectively.

- changed (2018-11-20):
[0000858877-18-000015:note_history:11]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Balance at beginning of period | $ | 359 |  |  | $ | 407 |  |
| Provisions for warranties issued | 156 |  |  | 148 |  |
| Adjustments for pre-existing warranties | (3 | ) |  | (12 | ) |
| Settlements | (145 | ) |  | (149 | ) |
| Balance at end of period | $ | 367 |  |  | $ | 394 |  |
  (was, 2018-05-22, similarity 0.7943):
[0000858877-18-000007:note_history:11]
|  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |
| Balance at beginning of period | $ | 407 |  |  | $ | 414 |  |
| Provisions for warranty issued | 431 |  |  | 528 |  |
| Adjustments for pre-existing warranties | (32 | ) |  | (17 | ) |
| Settlements | (441 | ) |  | (511 | ) |
| Balance at end of period | $ | 365 |  |  | $ | 414 |  |

- added (2018-11-20):
[0000858877-18-000015:note_history:12]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

- added (2018-11-20):
[0000858877-18-000015:note_history:13]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

- changed (2018-11-20):
[0000858877-18-000015:note_history:14]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.2 billion and $6.7 billion for the first quarter of fiscal 2019 and fiscal 2018, respectively. The balance of the channel partner financing subject to guarantees was $931 million and $953 million as of October 27, 2018 and July 28, 2018, respectively.
  (was, 2018-05-22, similarity 0.6737):
[0000858877-18-000007:note_history:14]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $7.1 billion and $6.6 billion for the three months ended April 28, 2018 and April 29, 2017, respectively, and was $20.7 billion and $19.7 billion for the nine months ended April 28, 2018 and April 29, 2017, respectively. The balance of the channel partner financing subject to guarantees was $1.0 billion as of each of April 28, 2018 and July 29, 2017.

- added (2018-11-20):
[0000858877-18-000015:note_history:15]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $3 million and $14 million for the first quarter of fiscal 2019 and fiscal 2018, respectively.

- changed (2018-11-20):
[0000858877-18-000015:note_history:16]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 27, 2018 and July 28, 2018, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2018-05-22, similarity 0.9807):
[0000858877-18-000007:note_history:16]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 28, 2018 and July 29, 2017, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2018-11-20):
[0000858877-18-000015:note_history:17]
|  | October 27, 2018 |  | July 28, 2018 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 307 |  |  | $ | 277 |  |
| End user | 28 |  |  | 31 |  |
| Total | $ | 335 |  |  | $ | 308 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (72 | ) |  | $ | (94 | ) |
| End user | (26 | ) |  | (28 | ) |
| Total | $ | (98 | ) |  | $ | (122 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 237 |  |  | $ | 186 |  |
  (was, 2018-05-22, similarity 0.9885):
[0000858877-18-000007:note_history:17]
|  | April 28, 2018 |  | July 29, 2017 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 262 |  |  | $ | 240 |  |
| End user | 41 |  |  | 74 |  |
| Total | $ | 303 |  |  | $ | 314 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (90 | ) |  | $ | (82 | ) |
| End user | (32 | ) |  | (52 | ) |
| Total | $ | (122 | ) |  | $ | (134 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 181 |  |  | $ | 180 |  |

- changed (2018-11-20):
[0000858877-18-000015:note_history:18]
Other Guarantees   Our other guarantee arrangements as of October 27, 2018 and July 28, 2018 that were subject to recognition and disclosure requirements were not material.
  (was, 2018-05-22, similarity 0.9268):
[0000858877-18-000007:note_history:18]
Other Guarantees   The Company’s other guarantee arrangements as of April 28, 2018 and July 29, 2017 that were subject to recognition and disclosure requirements were not material.

- changed (2018-11-20):
[0000858877-18-000015:note_history:19]
| (f) | Indemnifications |
  (was, 2018-05-22, similarity 0.9615):
[0000858877-18-000007:note_history:19]
| (g) | Indemnifications |

- added (2018-11-20):
[0000858877-18-000015:note_history:20]
In the normal course of business, we indemnify other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

- added (2018-11-20):
[0000858877-18-000015:note_history:21]
We have been asked to indemnify Time Warner Cable (“TWC”) for patent infringement claims asserted against it by Sprint Communications Company, L.P. (“Sprint”) in federal court in Kansas. Sprint alleges that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied TWC's post-trial motions. TWC has appealed to the U.S. Court of Appeals for the Federal Circuit. We believe that TWC continues to have strong non-infringement and invalidity defenses and arguments and/or that Sprint’s damages claims are inconsistent with prevailing law. Due to the uncertainty surrounding the litigation process, we are unable to reasonably estimate the ultimate outcome of the TWC litigation at this time. Should Sprint prevail in litigation, or TWC agree to a settlement, we, in accordance with our agreements, may have an obligation to indemnify TWC for damages, mediation awards, or settlement amounts arising from its use of our products. At this time, we do not anticipate that our obligations regarding the final outcome would be material.

- added (2018-11-20):
[0000858877-18-000015:note_history:22]
During the first quarter of fiscal 2018, we recorded legal and indemnification settlement charges of $122 million to product cost of sales related to these and other matters.

- changed (2018-11-20):
[0000858877-18-000015:note_history:23]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.
  (was, 2018-05-22, similarity 0.6287):
[0000858877-18-000007:note_history:23]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

- changed (2018-11-20):
[0000858877-18-000015:note_history:24]
It is not possible to determine the maximum potential amount under these indemnification agreements due to our limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by us under these agreements have not had a material effect on our operating results, financial position, or cash flows.
  (was, 2018-05-22, similarity 0.944):
[0000858877-18-000007:note_history:24]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

- changed (2018-11-20):
[0000858877-18-000015:note_history:25]
| (g) | Legal Proceedings |
  (was, 2018-05-22, similarity 0.963):
[0000858877-18-000007:note_history:25]
| (h) | Legal Proceedings |

- changed (2018-11-20):
[0000858877-18-000015:note_history:26]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of our former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.
  (was, 2018-05-22, similarity 0.9135):
[0000858877-18-000007:note_history:26]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

- added (2018-11-20):
[0000858877-18-000015:note_history:27]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $221 million for the alleged evasion of import and other taxes, $1.4 billion for interest, and $1.0 billion for various penalties, all determined using an exchange rate as of October 27, 2018. We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

- added (2018-11-20):
[0000858877-18-000015:note_history:28]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and, on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We have appealed to the United States Court of Appeals for the Federal Circuit on various grounds. We believe we have strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, we do not expect it to be material.

- changed (2018-11-20):
[0000858877-18-000015:note_history:29]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against us and cancelling a trial which had been set for March 12, 2018. On January 16, 2018, Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit.
  (was, 2018-05-22, similarity 0.9636):
[0000858877-18-000007:note_history:29]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against the Company in the U.S. District Court for the Northern District of California, accusing the Company’s 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted the Company's motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against the Company and cancelling a trial which had been set for March 12, 2018. On January 16, 2018, Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit.

- added (2018-11-20):
[0000858877-18-000015:note_history:30]
Arista Networks, Inc.     As reported in our Form 10-K for the fiscal year ended July 28, 2018 we received a payment of $400 million from Arista Networks, Inc. ("Arista") in connection with the settlement of litigation. The payment was recognized in general and administrative expenses in our first quarter of fiscal 2019.

- added (2018-11-20):
[0000858877-18-000015:note_history:31]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the court consolidated the cases alleging infringement of the ‘327 Patent. Oyster's cases against some of the defendants were resolved. The court vacated the November 4, 2018 trial date set for Oyster's claims against Cisco and one other remaining defendant, pending resolution of Oyster's appeal of the court's summary judgment ruling dismissing certain of Oyster's claims. While we believe that we have strong non-infringement arguments and that the patent is invalid, if we do not prevail in the District Court, we believe damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, we are unable to reasonably estimate the ultimate outcome of this litigation at this time. However, we do not anticipate that any final outcome of the dispute would be material.

- added (2018-11-20):
[0000858877-18-000015:note_history:32]
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.

- removed (2018-11-20):
[0000858877-18-000007:note_history:33]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, Germany, India, Israel, Japan, Mexico, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 28, 2018 are as follows (in millions):

- removed (2018-11-20):
[0000858877-18-000007:note_history:34]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.

- removed (2018-11-20):
[0000858877-18-000007:note_history:35]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of April 28, 2018 and July 29, 2017, the liability for these purchase commitments was $163 million and $162 million, respectively, and was included in other current liabilities.

- removed (2018-11-20):
[0000858877-18-000007:note_history:36]
In connection with the Company’s acquisitions, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

- removed (2018-11-20):
[0000858877-18-000007:note_history:37]
Insieme Networks, Inc.    In fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. This investment included $100 million of funding and a license to certain of the Company’s technology. During fiscal 2014, the Company acquired the remaining interests in Insieme, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which were determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $436 million during the nine months ended April 29, 2017. The Company recorded compensation expense of $9 million and $41 million during the three and nine months ended April 29, 2017, respectively, related to these milestone payments. The Company does not expect a material amount of future compensation expense or further milestone payments related to this acquisition.

- removed (2018-11-20):
[0000858877-18-000007:note_history:38]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $212 million and $216 million as of April 28, 2018 and July 29, 2017, respectively.

- removed (2018-11-20):
[0000858877-18-000007:note_history:39]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

- removed (2018-11-20):
[0000858877-18-000007:note_history:40]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

- removed (2018-11-20):
[0000858877-18-000007:note_history:41]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $3 million and $10 million for the three months ended April 28, 2018 and April 29, 2017, respectively, and was $29 million and $47 million for the nine months ended April 28, 2018 and April 29, 2017, respectively.

- removed (2018-11-20):
[0000858877-18-000007:note_history:42]
| (f) | Supplier Component Remediation Liabilities |

- removed (2018-11-20):
[0000858877-18-000007:note_history:43]
In fiscal 2014, the Company recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. The Company performs regular assessments of the sufficiency of this liability and reduced the amount by $74 million and $164 million in fiscal 2016 and fiscal 2015, respectively based on updated analyses. During the second quarter of fiscal 2017, the Company further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. In addition, during the second quarter of fiscal 2017, the Company recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of the Company’s products. The liabilities related to the supplier component remediation matters as of April 28, 2018 and July 29, 2017 were $98 million and $174 million, respectively.

- removed (2018-11-20):
[0000858877-18-000007:note_history:44]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

- removed (2018-11-20):
[0000858877-18-000007:note_history:45]
The Company has been asked to indemnify certain of the Company’s service provider customers that have been subject to patent infringement claims asserted by Sprint Communications Company, L.P. in federal court in Kansas and Delaware. Sprint alleges that the service provider customers infringed Sprint’s patents by offering VoIP telephone services utilizing products provided by the Company generally in combination with those of other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017 against Time Warner Inc., a jury in Kansas found that Time Warner Cable willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied Time Warner Cable's post-trial motions. Time Warner Cable has appealed. On October 16, 2017, Sprint and Comcast Cable Communications, LLC reached resolution of the claims in Sprint's lawsuit against Comcast and, on October 19, 2017, the Kansas court dismissed Sprint's lawsuit. On December 6, 2017, Sprint and Cox Communications, Inc. reached resolution of the claims in Sprint's lawsuit against Cox, and the Delaware court dismissed Sprint's lawsuit against Cox on December 7, 2017.

- removed (2018-11-20):
[0000858877-18-000007:note_history:46]
The Company believes that Time Warner Cable continues to have strong non-infringement and invalidity defenses and arguments and/or that Sprint’s damages claims are inconsistent with prevailing law at trial and/or on appeal. Due to the uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the ultimate outcome of the Time Warner Cable litigation at this time. Should Sprint prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify Time Warner Cable for damages, mediation awards, or settlement amounts arising from its use of Cisco products.

- removed (2018-11-20):
[0000858877-18-000007:note_history:47]
On January 15, 2016, Huawei Technologies Co. Ltd. (“Huawei”) filed four patent infringement actions against T-Mobile US, Inc. and T-Mobile USA, Inc. (collectively, “T-Mobile”) in federal court in the Eastern District of Texas. Huawei alleged that T-Mobile’s use of 3GPP standards to implement its 3G and 4G cellular networks infringed 12 patents. Huawei's infringement allegations for some of the patents were based on T-Mobile's use of products provided by the Company in combination with those of other manufacturers. T-Mobile requested indemnity by the Company with respect to portions of the network that use the Company's equipment. On December 22, 2017, the Eastern District of Texas court dismissed Huawei's four lawsuits after the parties reached settlement, and T-Mobile's indemnity request was subsequently resolved.

- removed (2018-11-20):
[0000858877-18-000007:note_history:48]
For the nine months ended April 28, 2018, the Company recorded legal and indemnification settlement charges of $127 million to product cost of sales in relation to these matters. At this time, the Company does not anticipate that its obligations regarding the final outcome of the above matters would be material.

- removed (2018-11-20):
[0000858877-18-000007:note_history:49]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $234 million for the alleged evasion of import and other taxes, $1.5 billion for interest, and $1.1 billion for various penalties, all determined using an exchange rate as of April 28, 2018. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

- removed (2018-11-20):
[0000858877-18-000007:note_history:50]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against the Company in the U.S. District Court for the District of Delaware, accusing the Company's products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. The Company has appealed to the United States Court of Appeals for the Federal Circuit on various grounds. The Company believes it has strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, the Company does not expect it to be material.

- removed (2018-11-20):
[0000858877-18-000007:note_history:51]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, the Company petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art. On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that the Company would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. On June 28, 2016, in light of the PTAB’s decision to review the patent’s validity, the district court issued an order staying the district court case pending the final written decision from the PTAB. On February 22, 2017, following a hearing, the PTAB issued its Final Written Decision that the patent’s claims are unpatentable. SSL appealed this decision to the Court of Appeals for the Federal Circuit and, on May 7, 2018, the Federal Circuit summarily affirmed the PTAB's decision of unpatentability.

- removed (2018-11-20):
[0000858877-18-000007:note_history:52]
DXC Technology     On August 21, 2015, the Company and Cisco Systems Capital Corporation (“Cisco Capital”) filed an action in Santa Clara County Superior Court for declaratory judgment and breach of contract against HP Inc. (“HP”) regarding a services agreement for management services of a third party’s network. HP had prepaid the service agreement through a financing arrangement with Cisco Capital, and had terminated its agreement with the Company. Pursuant to the terms of the service agreement with HP, the Company determined the credit HP was entitled to receive under the agreement for certain prepaid amounts. HP disputed the Company’s credit calculation and contended that the Company owes a larger credit to HP than the Company had calculated. In December 2015, the Company filed an amended complaint which dropped the breach of contract claim in light of HP’s continuing payments to Cisco Capital under the financing arrangement. On January 19, 2016, HP Inc. filed a counterclaim for breach of contract simultaneously with its answer to the amended complaint. DXC Technology Corporation (“DXC”) reported that it is the party in interest in this matter pursuant to the Separation and Distribution Agreement between the then Hewlett-Packard Co. and Hewlett Packard Enterprise Company (“HPE") and the subsequent Separation and Distribution Agreement between HPE and DXC. On January 8, 2018, the court continued the trial date from March 12, 2018 to June 11, 2018. The Company is unable to reasonably estimate the ultimate outcome of this litigation due to uncertainty surrounding the litigation process. However, the Company does not anticipate that its obligation, if any, regarding the final outcome of the dispute would be material.

- removed (2018-11-20):
[0000858877-18-000007:note_history:53]
Arista Networks, Inc.     On February 24, 2016, Arista Networks, Inc. (“Arista”) filed a complaint against the Company in the U.S. District Court for the Northern District of California asserting monopolization claims in violation of Section 2 of the Sherman Act and an unfair competition claim under California Bus. and Prof. Code § 17200. On October 31, 2017, Arista filed an amended complaint for Sherman Act monopolization and § 17200 claims, alleging an anticompetitive scheme comprising the Company's copyright infringement action against Arista (which was based on Arista’s copying of the Company's copyright-protected user interfaces) and communications related to that litigation. Arista seeks injunctive relief, lost profits, enhanced damages, and restitution. A jury trial is scheduled for August 6, 2018.  The Company believes it has strong arguments that its conduct was lawful, legally protected, and not anticompetitive, as well as strong defenses to defeat Arista’s claims. However, due to uncertainty surrounding litigation processes, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. However, the Company does not anticipate that any final outcome of the dispute would be material.

- removed (2018-11-20):
[0000858877-18-000007:note_history:54]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against the Company in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the court consolidated the cases alleging infringement of the ‘327 Patent. The court set a trial date of June 4, 2018 for the cases against Infinera, Alcatel-Lucent, the Company and Huawei. While the Company believes that it has strong non-infringement arguments and that the patent is invalid, if the Company does not prevail in the District Court, the Company believes damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. However, the Company does not anticipate that any final outcome of the dispute would be material.

- removed (2018-11-20):
[0000858877-18-000007:note_history:55]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2018-11-20):
[0000858877-18-000015:note_history:56]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.

- added (2018-11-20):
[0000858877-18-000015:note_history:57]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

- removed (2018-11-20):
[0000858877-18-000007:note_history:58]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory.

- removed (2018-11-20):
[0000858877-18-000007:note_history:59]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-20):
[0000858877-18-000015:note_history:60]
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2019 and fiscal 2018 are each 52-week fiscal years. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).
  (was, 2018-05-22, similarity 0.8942):
[0000858877-18-000007:note_history:60]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2018 and fiscal 2017 are each 52-week fiscal years. The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated. The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

- changed (2018-11-20):
[0000858877-18-000015:note_history:61]
We have prepared the accompanying financial data as of October 27, 2018 and for the three months ended October 27, 2018 and October 28, 2017, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 28, 2018 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 28, 2018.
  (was, 2018-05-22, similarity 0.8938):
[0000858877-18-000007:note_history:61]
The accompanying financial data as of April 28, 2018 and for the three and nine months ended April 28, 2018 and April 29, 2017 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 29, 2017 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 29, 2017.

- added (2018-11-20):
[0000858877-18-000015:note_history:62]
We consolidate our investments in certain variable interest entities (VIEs) where we are the  primary beneficiary. The noncontrolling interests attributed to these investments, if any, are presented as a separate component from our equity in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interests  are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

- added (2018-11-20):
[0000858877-18-000015:note_history:63]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 27, 2018; the results of operations and the statements of comprehensive income (loss) for the three months ended October 27, 2018 and October 28, 2017; the statements of cash flows and equity for the three months ended October 27, 2018 and October 28, 2017, as applicable, have been made. The results of operations for the three months ended October 27, 2018 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- changed (2018-11-20):
[0000858877-18-000015:note_history:64]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  We have evaluated subsequent events through the date that the financial statements were issued.
  (was, 2018-05-22, similarity 0.6217):
[0000858877-18-000007:note_history:64]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  The Company has evaluated subsequent events through the date that the financial statements were issued.

- removed (2018-11-20):
[0000858877-18-000007:note_history:65]
The Company consolidates its investments in a venture fund managed by SOFTBANK Corp. and its affiliates (“SOFTBANK”) as this is a variable interest entity and the Company is the primary beneficiary. The noncontrolling interests attributed to SOFTBANK are presented as a separate component from the Company’s equity in the equity section of the Consolidated Balance Sheets. SOFTBANK’s share of the earnings in the venture fund are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

- removed (2018-11-20):
[0000858877-18-000007:note_history:66]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of April 28, 2018; the results of operations and the statements of comprehensive income (loss) for the three and nine months ended April 28, 2018 and April 29, 2017; the statements of cash flows and equity for the nine months ended April 28, 2018 and April 29, 2017, as applicable, have been made. The results of operations for the three and nine months ended April 28, 2018 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-20):
[0000858877-18-000015:note_history:67]
Revenue Recognition  In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers, a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP on revenue recognition and eliminated industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. It also requires increased disclosures including the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.
  (was, 2018-05-22, similarity 0.6825):
[0000858877-18-000007:note_history:67]
Revenue Recognition  In May 2014, the FASB issued a new accounting standard related to revenue recognition. The new standard will supersede nearly all U.S. GAAP on revenue recognition and eliminate industry-specific guidance. The underlying principle of the new standard is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. It also requires increased disclosures including the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

- changed (2018-11-20):
[0000858877-18-000015:note_history:68]
ASC 606 allows two methods of adoption: i) retrospectively to each prior period presented (“full retrospective method”), or ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective method"). At the beginning of the first quarter of fiscal 2019, we adopted ASC 606 using the modified retrospective method to those contracts that were not completed as of July 28, 2018. Refer to Opening Balance Adjustments below for the impact of adoption on our Consolidated Financial Statements.
  (was, 2018-05-22, similarity 0.6524):
[0000858877-18-000007:note_history:68]
The standard allows two methods of adoption: i) retrospectively to each prior period presented (“full retrospective method”), or ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective method"). Cisco will adopt the new standard using the modified retrospective method at the beginning of its first quarter of fiscal 2019.

- added (2018-11-20):
[0000858877-18-000015:note_history:69]
We have implemented new accounting policies, systems, processes, and internal controls necessary to support the requirements of ASC 606.

- added (2018-11-20):
[0000858877-18-000015:note_history:70]
ASC 606 primarily impacts our revenue recognition for software arrangements and sales to two-tier distributors. In both areas, the new standard accelerates the recognition of revenue.

- added (2018-11-20):
[0000858877-18-000015:note_history:71]
The table below details the timing of when revenue was typically recognized under the prior revenue standard compared to the timing of when revenue is typically recognized under ASC 606 for these major areas:

- changed (2018-11-20):
[0000858877-18-000015:note_history:72]
|  |  | Prior Revenue Standard |  | ASC 606 |
| Software arrangements: |  |  |  |  |
| Perpetual software licenses |  | Upfront |  | Upfront |
| Term software licenses |  | Ratable |  | Upfront |
| Security software licenses |  | Ratable |  | Ratable |
| Enterprise license agreements (software licenses) |  | Ratable |  | Upfront |
| Software support (maintenance) |  | Ratable |  | Ratable |
| Software-as-a-service |  | Ratable |  | Ratable |
| Two-tier distribution |  | Sell-Through |  | Sell-In |
  (was, 2018-05-22, similarity 0.8232):
[0000858877-18-000007:note_history:72]
|  |  | Current Revenue Standard |  | New Revenue Standard |
| Software arrangements: |  |  |  |  |
| Perpetual software licenses |  | Upfront |  | Upfront |
| Term software licenses |  | Ratable |  | Upfront |
| Security software licenses |  | Ratable |  | Ratable |
| Enterprise license agreements |  | Ratable |  | Upfront |
| Software support services |  | Ratable |  | Ratable |
| Software-as-a-service |  | Ratable |  | Ratable |
| Two-tier distribution |  | Sell-Through |  | Sell-In |

- changed (2018-11-20):
[0000858877-18-000015:note_history:73]
In addition to the above revenue recognition timing impacts, ASC 606 requires incremental contract acquisition costs (such as sales commissions) for customer contracts to be capitalized and amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the assets relates.
  (was, 2018-05-22, similarity 0.6362):
[0000858877-18-000007:note_history:73]
In addition to the above revenue recognition timing impacts, the new standard will require incremental contract acquisition costs (such as sales commissions) for customer contracts to be capitalized and amortized over the contract period. Currently, these costs are expensed as incurred.

- added (2018-11-20):
[0000858877-18-000015:note_history:74]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

- added (2018-11-20):
[0000858877-18-000015:note_history:75]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or once delivery and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

- added (2018-11-20):
[0000858877-18-000015:note_history:76]
Significant Judgments

- added (2018-11-20):
[0000858877-18-000015:note_history:77]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

- added (2018-11-20):
[0000858877-18-000015:note_history:78]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes various rebate, cooperative marketing, and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

- added (2018-11-20):
[0000858877-18-000015:note_history:79]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license's utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a distinct performance obligation satisfied over the contract term.

- added (2018-11-20):
[0000858877-18-000015:note_history:80]
For the additional disclosures required as part of ASC 606 see Note 3.

- added (2018-11-20):
[0000858877-18-000015:note_history:81]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The most significant impact of this accounting standard update is that it requires the remeasurement of investments not accounted for under the equity method to be recorded at fair value through the Consolidated Statement of Operations at the end of each reporting period. The application of this accounting standard update increases the variability of other income (loss), net.

- added (2018-11-20):
[0000858877-18-000015:note_history:82]
Our equity investments are accounted for as follows:

- added (2018-11-20):
[0000858877-18-000015:note_history:83]
| • | Marketable equity securities have readily determinable fair value (RDFV) that are measured and recorded at fair value. |

- added (2018-11-20):
[0000858877-18-000015:note_history:84]
| • | Non-marketable equity securities do not have RDFV and are measured using a measurement alternative recorded at cost less any impairment, plus or minus changes resulting from qualifying observable price changes. For certain of these securities, we have elected to apply the net asset value (NAV) practical expedient. The NAV is the estimated fair value of these investments. |

- added (2018-11-20):
[0000858877-18-000015:note_history:85]
| • | Equity method investments are securities we do not control, but are able to exert significant influence over the investee. These investments are measured at cost less any impairment, plus or minus our share of equity method investee income or loss. |

- added (2018-11-20):
[0000858877-18-000015:note_history:86]
We adopted this accounting standard update beginning the first quarter of fiscal 2019. The standard was adopted using the modified retrospective method for our marketable equity securities and non-marketable equity securities measured using the NAV practical expedient. For our non-marketable equity securities measured using the measurement alternative, we applied the prospective method. Refer to Opening Balance Adjustments below for the impact of adoption on our Consolidated Balance Sheet.

- changed (2018-11-20):
[0000858877-18-000015:note_history:87]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a modified retrospective basis. The ongoing impact of this standard will be facts and circumstances dependent on any transactions within its scope. Refer to Opening Balance Adjustments below for the impact of adoption on our Consolidated Balance Sheet.
  (was, 2018-05-22, similarity 0.6435):
[0000858877-18-000007:note_history:87]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. Cisco currently estimates a net increase of approximately $1.3 billion to net deferred tax assets and retained earnings upon adoption of the standard related to the unrecognized income tax effects of asset transfers that occurred prior to the adoption date. The ongoing impact of this standard will be facts and circumstances dependent on any transactions within its scope.

- changed (2018-11-20):
[0000858877-18-000015:note_history:88]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a retrospective basis. The application of this accounting standard update did not have an impact on our Consolidated Statements of Cash Flows.
  (was, 2018-05-22, similarity 0.6813):
[0000858877-18-000007:note_history:88]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Statements of Cash Flows.

- changed (2018-11-20):
[0000858877-18-000015:note_history:89]
Restricted Cash in Statement of Cash Flows  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented. The application of this accounting standard update did not have a material impact on our Consolidated Statements of Cash Flows. Prior period information has been retrospectively adjusted due to the adoption of ASU 2016-18, Statement of Cash Flows, Restricted Cash in the beginning of the first quarter of fiscal 2019.
  (was, 2018-05-22, similarity 0.6584):
[0000858877-18-000007:note_history:89]
Restricted Cash in Statement of Cash Flow  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented, and early adoption is permitted. Cisco does not expect that this accounting standard update will have a material impact on its Consolidated Statements of Cash Flows.

- added (2018-11-20):
[0000858877-18-000015:note_history:90]
Simplifying the Test for Goodwill Impairment  In January 2017, the FASB issued an accounting standard update that removes Step

- added (2018-11-20):
[0000858877-18-000015:note_history:91]
2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. We early adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a prospective basis. The application of this accounting standard update did not have a material impact on our Consolidated Financial Statements.

- added (2018-11-20):
[0000858877-18-000015:note_history:92]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. We adopted this accounting standard update beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be fact dependent, but we expect that some transactions that were previously accounted for as business combinations or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.

- added (2018-11-20):
[0000858877-18-000015:note_history:93]
Opening Balance Adjustments

- added (2018-11-20):
[0000858877-18-000015:note_history:94]
The following table summarizes the cumulative effect of the changes made to the Consolidated Balance Sheet for the adoption of ASC 606, ASU 2016-01, Financial Instruments, and ASU 2016-16, Intra-Entity Transfers of Assets Other than Inventory (in millions):

- added (2018-11-20):
[0000858877-18-000015:note_history:95]
| Line Item in Consolidated Balance Sheet: |  | Balance at July 28, 2018 |  | New Revenue Recognition Standard |  | New Financial Instruments Standard |  | New Intra-Entity Transfers Standard |  | Adjusted Balance at July 29, 2018 |
| ASSETS |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 5,554 |  |  | $ | (104 | ) | (1) | $ | — |  |  | $ | — |  |  | $ | 5,450 |  |
| Inventories |  | $ | 1,846 |  |  | $ | (302 | ) | (2) | $ | — |  |  | $ | — |  |  | $ | 1,544 |  |
| Other current assets (includes capitalized contract acquisition costs) |  | $ | 2,940 |  |  | $ | 371 |  | (3), (4) | $ | — |  |  | $ | (25 | ) | (3) | $ | 3,286 |  |
| Deferred tax assets |  | $ | 3,219 |  |  | $ | (624 | ) | (3) | $ | (15 | ) | (3) | $ | 1,415 |  | (8) | $ | 3,995 |  |
| Other assets (includes capitalized contract acquisition costs) |  | $ | 1,582 |  |  | $ | 327 |  | (4) | $ | 136 |  | (7) | $ | (91 | ) | (3) | $ | 1,954 |  |
| TOTAL ASSETS |  | $ | 108,784 |  |  | $ | (332 | ) |  | $ | 121 |  |  | $ | 1,299 |  |  | $ | 109,872 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |  |  |
| Income taxes payable |  | $ | 1,004 |  |  | $ | — |  |  | $ | — |  |  | $ | 11 |  | (3) | $ | 1,015 |  |
| Deferred revenue — current |  | $ | 11,490 |  |  | $ | (1,702 | ) | (5) | $ | — |  |  | $ | — |  |  | $ | 9,788 |  |
| Other current liabilities |  | $ | 4,413 |  |  | $ | 33 |  | (6) | $ | — |  |  | $ | — |  |  | $ | 4,446 |  |
| Deferred revenue — non-current |  | $ | 8,195 |  |  | $ | (1,081 | ) | (5) | $ | — |  |  | $ | — |  |  | $ | 7,114 |  |
| Other long-term liabilities |  | $ | 1,434 |  |  | $ | 85 |  | (3) | $ | 13 |  | (3) | $ | — |  |  | $ | 1,532 |  |
| Retained earnings |  | $ | 1,233 |  |  | $ | 2,333 |  | (10) | $ | 283 |  | (10) | $ | 1,281 |  | (10) | $ | 5,130 |  |
| Accumulated other comprehensive income (loss) |  | $ | (849 | ) |  | $ | — |  |  | $ | (175 | ) | (9) | $ | 7 |  | (3) | $ | (1,017 | ) |
| TOTAL LIABILITIES AND EQUITY |  | $ | 108,784 |  |  | $ | (332 | ) |  | $ | 121 |  |  | $ | 1,299 |  |  | $ | 109,872 |  |

- added (2018-11-20):
[0000858877-18-000015:note_history:96]
(1) Primarily represents the decrease to accounts receivable related to the change in recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis

- added (2018-11-20):
[0000858877-18-000015:note_history:97]
(2) Primarily represents the reduction of inventory for the change from recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis

- added (2018-11-20):
[0000858877-18-000015:note_history:98]
(3) Includes the impacts to deferred tax assets, liabilities and other income tax balances

- added (2018-11-20):
[0000858877-18-000015:note_history:99]
(4) Primarily represents capitalized contract acquisition costs (e.g. commissions)

- added (2018-11-20):
[0000858877-18-000015:note_history:100]
(5) Primarily represents deferred revenue adjusted to retained earnings primarily due to the change in revenue recognition for certain software arrangements from ratable to upfront, recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis. Of this total $2.8 billion adjustment, $2.6 billion related to product deferred revenue, of which $1.3 billion relates to our recurring software and subscription offers, $0.6 billion relates to two-tier distribution, and the remainder relates to non-recurring software and other adjustments.

- added (2018-11-20):
[0000858877-18-000015:note_history:101]
(6) Primarily represents the reclassification of accounts receivable contra balances to other current liabilities, adjustments to rebate liabilities for the change from recognizing revenue on sales to two-tier distributors from a sell-through to a sell-in basis, and reclassifications from other current liabilities for amounts that are not contract liabilities under ASC 606

- added (2018-11-20):
[0000858877-18-000015:note_history:102]
(7) Represents the adjustment due to the remeasurement of non-marketable equity investments at fair value

- added (2018-11-20):
[0000858877-18-000015:note_history:103]
(8) Primarily represents the change in net deferred tax assets related to unrecognized income tax effects of intra-entity asset transfers

- added (2018-11-20):
[0000858877-18-000015:note_history:104]
(9) Represents the reclassification of net unrealized gains from accumulated other comprehensive income (loss) to retained earnings

- added (2018-11-20):
[0000858877-18-000015:note_history:105]
(10) Retained earnings impact from the adjustments noted above

- added (2018-11-20):
[0000858877-18-000015:note_history:106]
Impact of ASC 606 Adoption

- added (2018-11-20):
[0000858877-18-000015:note_history:107]
The application of ASC 606 increased our total revenue by $276 million in the first quarter of fiscal 2019. The application of ASC 606 did not have a material impact to either our cost of sales or our operating expenses in the first quarter of fiscal 2019. We recognized a $152 million benefit to our provision for income taxes relating to indirect effects from the adoption of ASC 606 in the first quarter of fiscal 2019. For additional information regarding ASC 606, see Note 3 to the Consolidated Financial Statements.

- added (2018-11-20):
[0000858877-18-000015:note_history:108]
In connection with the adoption of ASC 606, we recorded a transition adjustment to increase retained earnings by $2.3 billion. See above for the transition impact of ASC 606 by balance sheet line item. As of October 27, 2018, the balance sheet changes attributable to ASC 606 related to accounts receivable, inventories, and deferred revenue were not materially different than the impacts upon adoption. In connection with the adoption of ASC 606, we established contract assets for unbilled receivables. As of October 27, 2018, we had total contract assets of $447 million of which, $270 million was recorded in other current assets and $177 million was recorded in other assets. As of October 27, 2018, we had total capitalized contract acquisition costs of $673 million, of which $380 million was recorded in other current assets and $293 million was recorded in other assets. The adoption of ASC 606 did not have any impact on net cash provided by operating activities.

- changed (2018-11-20):
[0000858877-18-000015:note_history:109]
| (b) | Recent Accounting Standards or Updates Not Yet Effective |
  (was, 2018-05-22, similarity 0.8859):
[0000858877-18-000007:note_history:109]
| (b) | Recent Accounting Standards or Updates Not Yet Effective as of Period End |

- changed (2018-11-20):
[0000858877-18-000015:note_history:110]
Leases  In February 2016, the FASB issued an accounting standard update and subsequent amendments related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2020 and early adoption is permitted. We expect to adopt this accounting standard update on a modified retrospective basis in the first quarter of fiscal 2020, and we are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.
  (was, 2018-05-22, similarity 0.8208):
[0000858877-18-000007:note_history:110]
Leases  In February 2016, the FASB issued an accounting standard update and subsequent amendments related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2020 on a modified retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- changed (2018-11-20):
[0000858877-18-000015:note_history:111]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2021 and early adoption in fiscal 2020 is permitted. We expect to adopt this accounting standard update on a modified retrospective basis in the first quarter of fiscal 2021, and we are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.
  (was, 2018-05-22, similarity 0.774):
[0000858877-18-000007:note_history:111]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2021 on a modified retrospective basis, and early adoption in fiscal 2020 is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- removed (2018-11-20):
[0000858877-18-000007:note_history:112]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. Cisco adopted this accounting standard update beginning the first quarter of fiscal 2018 on a prospective basis. This resulted in an overall decrease in the effective tax rate for the nine months ended April 28, 2018 due to recognition of excess tax benefits from share-based compensation. The application of this accounting standard update did not have a material impact on the Company's Consolidated Financial Statements.

- removed (2018-11-20):
[0000858877-18-000007:note_history:113]
Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income  In February 2018, the FASB issued an accounting standard update that allows companies to reclassify from accumulated other comprehensive income ("AOCI") to retained earnings stranded tax effects resulting from the enactment of the Tax Cuts and Jobs Act (the "Tax Act"). The guidance is effective January 1, 2019 with early adoption permitted. Cisco early adopted this accounting standard update in the third quarter of fiscal 2018 and elected not to reclassify prior periods. Adoption of this standard resulted in a decrease of $45 million to retained earnings due to the reclassification from AOCI to retained earnings.

- removed (2018-11-20):
[0000858877-18-000007:note_history:114]
Cisco is on schedule in establishing new accounting policies, implementing systems and processes (including more extensive use of estimates), and internal controls necessary to support the requirements of the new standard. Cisco has completed its preliminary assessment of the financial statement impact of the new standard, as discussed below, and will continue to update that assessment as more information becomes available.

- removed (2018-11-20):
[0000858877-18-000007:note_history:115]
The new standard will primarily impact Cisco’s revenue recognition for software arrangements and sales to two-tier distributors. In both areas, the new standard will accelerate the recognition of revenue. The table below details the timing of when revenue is typically recognized under the current revenue standard compared to the timing of when revenue will typically be recognized under the New Revenue Standard for these major areas:

- removed (2018-11-20):
[0000858877-18-000007:note_history:116]
Cisco expects that the new standard will not have a material impact on total revenue in the year of adoption based on two factors: i) revenue will be accelerated consistent with the changes in timing as indicated in the preceding table, largely offset by ii) the reduction of revenue from software arrangements where revenue was previously deferred in prior periods and recognized ratably over time as required under the current standard. This preliminary assessment is based on the types and number of revenue arrangements currently in place. The exact impact of the new standard will be dependent on facts and circumstances at adoption and could vary from quarter to quarter.

- removed (2018-11-20):
[0000858877-18-000007:note_history:117]
Cisco will be required to record cumulative effect adjustments to retained earnings (net of tax) upon adopting the new standard at the beginning of fiscal 2019. The most significant of these adjustments will be to reduce product deferred revenue and increase retained earnings at the date of adoption to reflect revenue that would have been already recognized under the new standard related to existing arrangements. There will also be an adjustment to increase accounts receivable and reduce inventories related to the changes in revenue recognition on sales to two-tier distributors. Lastly, an adjustment will be recorded to establish an asset and increase retained earnings related to the requirement to capitalize incremental contract acquisition costs for customer contracts.

- removed (2018-11-20):
[0000858877-18-000007:note_history:118]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019, and early adoption is permitted. The most significant impact of this accounting standard update for Cisco is that it will require the remeasurement of investments that are not accounted for under the equity method at fair value at the end of each reporting period with the changes recorded to the income statement. While Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements, Cisco expects that this accounting standard update will increase the variability of other income (loss), net.

- removed (2018-11-20):
[0000858877-18-000007:note_history:119]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be fact dependent, but Cisco expects that some transactions that were previously accounted for as business combinations or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.

- removed (2018-11-20):
[0000858877-18-000007:note_history:120]
Simplifying the Test for Goodwill Impairment  In January 2017, the FASB issued an accounting standard update that removes Step 2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2021 on a prospective basis, and early adoption is permitted. Cisco does not expect that this accounting standard update will impact its Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-20):
[0000858877-18-000015:note_history:121]
The following table summarizes our short-term debt (in millions, except percentages):
  (was, 2018-05-22, similarity 0.9222):
[0000858877-18-000007:note_history:121]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

- changed (2018-11-20):
[0000858877-18-000015:note_history:122]
|  | October 27, 2018 |  | July 28, 2018 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 7,241 |  |  | 3.06 | % |  | $ | 5,238 |  |  | 3.46 | % |
  (was, 2018-05-22, similarity 0.7285):
[0000858877-18-000007:note_history:122]
|  | April 28, 2018 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 7,736 |  |  | 2.91 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | — |  |  | — | % |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 7,736 |  |  |  |  | $ | 7,992 |  |  |  |

- changed (2018-11-20):
[0000858877-18-000015:note_history:123]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of October 27, 2018 and July 28, 2018.
  (was, 2018-05-22, similarity 0.7638):
[0000858877-18-000007:note_history:123]
The Company has a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes.

- changed (2018-11-20):
[0000858877-18-000015:note_history:124]
The following table summarizes our long-term debt (in millions, except percentages):
  (was, 2018-05-22, similarity 0.9213):
[0000858877-18-000007:note_history:124]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

- changed (2018-11-20):
[0000858877-18-000015:note_history:125]
|  |  |  | October 27, 2018 |  | July 28, 2018 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | $ | 500 |  |  | 2.88% |  | $ | 500 |  |  | 2.86% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.72% |  | 500 |  |  | 2.71% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.22% |  | 2,000 |  |  | 5.17% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.87% |  | 1,750 |  |  | 2.71% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.68% |  | 2,500 |  |  | 4.52% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 3.05% |  | 500 |  |  | 2.86% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 3.32% |  | 500 |  |  | 3.11% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 3.17% |  | 1,000 |  |  | 2.98% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.48% |  | 500 |  |  | 3.27% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 25,750 |  |  |  |  | 25,750 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (112 | ) |  |  |  | (116 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (74 | ) |  |  |  | (65 | ) |  |  |
| Total |  |  | $ | 25,564 |  |  |  |  | $ | 25,569 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 7,241 |  |  |  |  | $ | 5,238 |  |  |  |
| Long-term debt |  |  | 18,323 |  |  |  |  | 20,331 |  |  |  |
| Total |  |  | $ | 25,564 |  |  |  |  | $ | 25,569 |  |  |  |
  (was, 2018-05-22, similarity 0.9202):
[0000858877-18-000007:note_history:125]
|  |  |  | April 28, 2018 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | — |  |  | — |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 2.50% |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 2.57% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.58% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | — |  |  | — |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.12% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.50% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.38% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.66% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.94% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.78% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.10% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 28,250 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (119 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (59 | ) |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 28,072 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 7,736 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 20,336 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 28,072 |  |  |  |  | $ | 30,472 |  |  |  |

- changed (2018-11-20):
[0000858877-18-000015:note_history:126]
We entered into interest rate swaps in prior periods with an aggregate notional amount of $6.75 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate ("LIBOR"). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 12.
  (was, 2018-05-22, similarity 0.9844):
[0000858877-18-000007:note_history:126]
The Company entered into interest rate swaps in prior periods with an aggregate notional amount of $6.75 billion designated as fair value hedges of certain of its fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate ("LIBOR"). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 11.

- changed (2018-11-20):
[0000858877-18-000015:note_history:127]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 27, 2018, we were in compliance with all debt covenants.
  (was, 2018-05-22, similarity 0.8303):
[0000858877-18-000007:note_history:127]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 28, 2018, the Company was in compliance with all debt covenants.

- changed (2018-11-20):
[0000858877-18-000015:note_history:128]
As of October 27, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2018-05-22, similarity 0.9627):
[0000858877-18-000007:note_history:128]
As of April 28, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2018-11-20):
[0000858877-18-000015:note_history:129]
| Fiscal Year | Amount |
| 2019 (remaining nine months) | $ | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| Thereafter | 8,500 |  |
| Total | $ | 25,750 |  |
  (was, 2018-05-22, similarity 0.9772):
[0000858877-18-000007:note_history:129]
| Fiscal Year | Amount |
| 2018 (remaining three months) | $ | 2,500 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 28,250 |  |

- changed (2018-11-20):
[0000858877-18-000015:note_history:130]
On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.
  (was, 2018-05-22, similarity 0.9818):
[0000858877-18-000007:note_history:130]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.

- added (2018-11-20):
[0000858877-18-000015:note_history:131]
This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of October 27, 2018, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under this credit facility.

- removed (2018-11-20):
[0000858877-18-000007:note_history:132]
This credit agreement requires that the Company comply with certain covenants, including that the Company maintains an interest coverage ratio as defined in the agreement. As of April 28, 2018, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under this credit facility.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-11-20):
[0000858877-18-000015:note_history:133]
Available-for-Sale Debt Investments and Equity Investments

- changed (2018-11-20):
[0000858877-18-000015:note_history:134]
The following table summarizes our available-for-sale debt investments and equity investments (in millions):
  (was, 2018-05-22, similarity 0.7677):
[0000858877-18-000007:note_history:134]
The following tables summarize the Company’s available-for-sale investments (in millions):

- added (2018-11-20):
[0000858877-18-000015:note_history:135]
|  | October 27, 2018 |  | July 28, 2018 |
| Available-for-sale debt investments | $ | 34,183 |  |  | $ | 37,009 |  |
| Marketable equity securities | — |  |  | 605 |  |
| Total investments | 34,183 |  |  | 37,614 |  |
| Non-marketable equity securities included in other assets | 1,125 |  |  | 978 |  |
| Equity method investments included in other assets | 115 |  |  | 118 |  |
| Total | $ | 35,423 |  |  | $ | 38,710 |  |

- changed (2018-11-20):
[0000858877-18-000015:note_history:136]
| (a) | Summary of Available-for-Sale Debt Investments |
  (was, 2018-05-22, similarity 0.9533):
[0000858877-18-000007:note_history:136]
| (a) | Summary of Available-for-Sale Investments |

- changed (2018-11-20):
[0000858877-18-000015:note_history:137]
The following tables summarize our available-for-sale debt investments (in millions):
  (was, 2018-05-22, similarity 0.6787):
[0000858877-18-000007:note_history:137]
The following table presents the gross realized gains and gross realized losses related to available-for-sale investments (in millions):

- changed (2018-11-20):
[0000858877-18-000015:note_history:138]
| October 27, 2018 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 5,783 |  |  | $ | — |  |  | $ | (29 | ) |  | $ | 5,754 |  |
| U.S. government agency securities | 434 |  |  | — |  |  | (4 | ) |  | 430 |  |
| Non-U.S. government and agency securities | 153 |  |  | — |  |  | — |  |  | 153 |  |
| Corporate debt securities | 26,444 |  |  | 33 |  |  | (446 | ) |  | 26,031 |  |
| U.S. agency mortgage-backed securities | 1,481 |  |  | — |  |  | (60 | ) |  | 1,421 |  |
| Commercial paper | 309 |  |  | — |  |  | — |  |  | 309 |  |
| Certificates of deposit | 85 |  |  | — |  |  | — |  |  | 85 |  |
| Total (1) | $ | 34,689 |  |  | $ | 33 |  |  | $ | (539 | ) |  | $ | 34,183 |  |
  (was, 2018-05-22, similarity 0.8607):
[0000858877-18-000007:note_history:138]
| April 28, 2018 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 13,672 |  |  | $ | — |  |  | $ | (141 | ) |  | $ | 13,531 |  |
| U.S. government agency securities | 1,166 |  |  | — |  |  | (10 | ) |  | 1,156 |  |
| Non-U.S. government and agency securities | 282 |  |  | — |  |  | (1 | ) |  | 281 |  |
| Corporate debt securities | 29,639 |  |  | 53 |  |  | (454 | ) |  | 29,238 |  |
| U.S. agency mortgage-backed securities | 2,009 |  |  | — |  |  | (73 | ) |  | 1,936 |  |
| Commercial paper | 195 |  |  | — |  |  | — |  |  | 195 |  |
| Certificates of deposit | 50 |  |  | — |  |  | — |  |  | 50 |  |
| Total fixed income securities | 47,013 |  |  | 53 |  |  | (679 | ) |  | 46,387 |  |
| Publicly traded equity securities | 843 |  |  | 486 |  |  | (4 | ) |  | 1,325 |  |
| Total (1) | $ | 47,856 |  |  | $ | 539 |  |  | $ | (683 | ) |  | $ | 47,712 |  |

- changed (2018-11-20):
[0000858877-18-000015:note_history:139]
| July 28, 2018 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 7,318 |  |  | $ | — |  |  | $ | (43 | ) |  | $ | 7,275 |  |
| U.S. government agency securities | 732 |  |  | — |  |  | (5 | ) |  | 727 |  |
| Non-U.S. government and agency securities | 209 |  |  | — |  |  | (1 | ) |  | 208 |  |
| Corporate debt securities | 27,765 |  |  | 44 |  |  | (445 | ) |  | 27,364 |  |
| U.S. agency mortgage-backed securities | 1,488 |  |  | — |  |  | (53 | ) |  | 1,435 |  |
| Total (1) | $ | 37,512 |  |  | $ | 44 |  |  | $ | (547 | ) |  | $ | 37,009 |  |
  (was, 2018-05-22, similarity 0.7746):
[0000858877-18-000007:note_history:139]
| July 29, 2017 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 19,880 |  |  | $ | 3 |  |  | $ | (60 | ) |  | $ | 19,823 |  |
| U.S. government agency securities | 2,057 |  |  | — |  |  | (5 | ) |  | 2,052 |  |
| Non-U.S. government and agency securities | 389 |  |  | — |  |  | (1 | ) |  | 388 |  |
| Corporate debt securities | 31,626 |  |  | 202 |  |  | (93 | ) |  | 31,735 |  |
| U.S. agency mortgage-backed securities | 2,037 |  |  | 3 |  |  | (17 | ) |  | 2,023 |  |
| Commercial paper | 996 |  |  | — |  |  | — |  |  | 996 |  |
| Certificates of deposit | 60 |  |  | — |  |  | — |  |  | 60 |  |
| Total fixed income securities | 57,045 |  |  | 208 |  |  | (176 | ) |  | 57,077 |  |
| Publicly traded equity securities | 1,180 |  |  | 554 |  |  | (27 | ) |  | 1,707 |  |
| Total (1) | $ | 58,225 |  |  | $ | 762 |  |  | $ | (203 | ) |  | $ | 58,784 |  |

- added (2018-11-20):
[0000858877-18-000015:note_history:140]
(1) Net unsettled investment purchases were $1 million and net unsettled investment sales were $1.5 billion as of October 27, 2018 and July 28, 2018, respectively and were included in other current assets and other current liabilities.

- changed (2018-11-20):
[0000858877-18-000015:note_history:141]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):
  (was, 2018-05-22, similarity 0.8073):
[0000858877-18-000007:note_history:141]
The following table presents the realized net gains (losses) related to available-for-sale investments by security type (in millions):

- changed (2018-11-20):
[0000858877-18-000015:note_history:142]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Gross realized gains | $ | 2 |  |  | $ | 8 |  |
| Gross realized losses | (8 | ) |  | (4 | ) |
| Total | $ | (6 | ) |  | $ | 4 |  |
  (was, 2018-05-22, similarity 0.6529):
[0000858877-18-000007:note_history:142]
|  | April 28, 2018 |  | July 29, 2017 |
| Equity method investments | $ | 118 |  |  | $ | 124 |  |
| Cost method investments | 851 |  |  | 859 |  |
| Total | $ | 969 |  |  | $ | 983 |  |

- changed (2018-11-20):
[0000858877-18-000015:note_history:143]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 27, 2018 and July 28, 2018 (in millions):
  (was, 2018-05-22, similarity 0.9592):
[0000858877-18-000007:note_history:143]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at April 28, 2018 and July 29, 2017 (in millions):

- changed (2018-11-20):
[0000858877-18-000015:note_history:144]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 27, 2018 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 516 |  |  | $ | (3 | ) |  | $ | 5,231 |  |  | $ | (26 | ) |  | $ | 5,747 |  |  | $ | (29 | ) |
| U.S. government agency securities | 4 |  |  | — |  |  | 427 |  |  | (4 | ) |  | 431 |  |  | (4 | ) |
| Non-U.S. government and agency securities | — |  |  | — |  |  | 153 |  |  | — |  |  | 153 |  |  | — |  |
| Corporate debt securities | 13,483 |  |  | (257 | ) |  | 6,738 |  |  | (189 | ) |  | 20,221 |  |  | (446 | ) |
| U.S. agency mortgage-backed securities | 456 |  |  | (12 | ) |  | 947 |  |  | (48 | ) |  | 1,403 |  |  | (60 | ) |
| Total | $ | 14,459 |  |  | $ | (272 | ) |  | $ | 13,496 |  |  | $ | (267 | ) |  | $ | 27,955 |  |  | $ | (539 | ) |
  (was, 2018-05-22, similarity 0.6743):
[0000858877-18-000007:note_history:144]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 28, 2018 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 7,585 |  |  | $ | (99 | ) |  | $ | 5,508 |  |  | $ | (42 | ) |  | $ | 13,093 |  |  | $ | (141 | ) |
| U.S. government agency securities | 473 |  |  | (5 | ) |  | 682 |  |  | (5 | ) |  | 1,155 |  |  | (10 | ) |
| Non-U.S. government and agency securities | 110 |  |  | — |  |  | 171 |  |  | (1 | ) |  | 281 |  |  | (1 | ) |
| Corporate debt securities | 18,094 |  |  | (348 | ) |  | 3,706 |  |  | (106 | ) |  | 21,800 |  |  | (454 | ) |
| U.S. agency mortgage-backed securities | 1,104 |  |  | (32 | ) |  | 827 |  |  | (41 | ) |  | 1,931 |  |  | (73 | ) |
| Total fixed income securities | 27,366 |  |  | (484 | ) |  | 10,894 |  |  | (195 | ) |  | 38,260 |  |  | (679 | ) |
| Publicly traded equity securities | 41 |  |  | (4 | ) |  | — |  |  | — |  |  | 41 |  |  | (4 | ) |
| Total | $ | 27,407 |  |  | $ | (488 | ) |  | $ | 10,894 |  |  | $ | (195 | ) |  | $ | 38,301 |  |  | $ | (683 | ) |

- changed (2018-11-20):
[0000858877-18-000015:note_history:145]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 28, 2018 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 2,966 |  |  | $ | (20 | ) |  | $ | 4,303 |  |  | $ | (23 | ) |  | $ | 7,269 |  |  | $ | (43 | ) |
| U.S. government agency securities | 206 |  |  | (2 | ) |  | 521 |  |  | (3 | ) |  | 727 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 105 |  |  | (1 | ) |  | 103 |  |  | — |  |  | 208 |  |  | (1 | ) |
| Corporate debt securities | 16,990 |  |  | (344 | ) |  | 3,511 |  |  | (101 | ) |  | 20,501 |  |  | (445 | ) |
| U.S. agency mortgage-backed securities | 826 |  |  | (24 | ) |  | 581 |  |  | (29 | ) |  | 1,407 |  |  | (53 | ) |
| Total | $ | 21,093 |  |  | $ | (391 | ) |  | $ | 9,019 |  |  | $ | (156 | ) |  | $ | 30,112 |  |  | $ | (547 | ) |
  (was, 2018-05-22, similarity 0.786):
[0000858877-18-000007:note_history:145]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2017 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 14,962 |  |  | $ | (55 | ) |  | $ | 771 |  |  | $ | (5 | ) |  | $ | 15,733 |  |  | $ | (60 | ) |
| U.S. government agency securities | 1,791 |  |  | (4 | ) |  | 130 |  |  | (1 | ) |  | 1,921 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 368 |  |  | (1 | ) |  | — |  |  | — |  |  | 368 |  |  | (1 | ) |
| Corporate debt securities | 9,487 |  |  | (92 | ) |  | 101 |  |  | (1 | ) |  | 9,588 |  |  | (93 | ) |
| U.S. agency mortgage-backed securities | 1,485 |  |  | (16 | ) |  | 38 |  |  | (1 | ) |  | 1,523 |  |  | (17 | ) |
| Total fixed income securities | 28,093 |  |  | (168 | ) |  | 1,040 |  |  | (8 | ) |  | 29,133 |  |  | (176 | ) |
| Publicly traded equity securities | 122 |  |  | (27 | ) |  | — |  |  | — |  |  | 122 |  |  | (27 | ) |
| Total | $ | 28,215 |  |  | $ | (195 | ) |  | $ | 1,040 |  |  | $ | (8 | ) |  | $ | 29,255 |  |  | $ | (203 | ) |

- added (2018-11-20):
[0000858877-18-000015:note_history:146]
During the first quarter of fiscal 2019 and fiscal 2018, respectively, we did not recognize any impairment charges on our available-for-sale debt investments. For available-for-sale debt investments that were in an unrealized loss position as of October 27, 2018, we have determined that no other-than-temporary impairments were required to be recognized.

- changed (2018-11-20):
[0000858877-18-000015:note_history:147]
The following table summarizes the maturities of our available-for-sale debt investments as of October 27, 2018 (in millions):
  (was, 2018-05-22, similarity 0.7227):
[0000858877-18-000007:note_history:147]
The following table summarizes the maturities of the Company’s fixed income securities as of April 28, 2018 (in millions):

- added (2018-11-20):
[0000858877-18-000015:note_history:148]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 12,283 |  |  | $ | 12,243 |  |
| After 1 year through 5 years | 19,248 |  |  | 18,922 |  |
| After 5 years through 10 years | 1,662 |  |  | 1,581 |  |
| After 10 years | 15 |  |  | 16 |  |
| Mortgage-backed securities with no single maturity | 1,481 |  |  | 1,421 |  |
| Total | $ | 34,689 |  |  | $ | 34,183 |  |

- added (2018-11-20):
[0000858877-18-000015:note_history:149]
| (b) | Summary of Equity Investments |

- added (2018-11-20):
[0000858877-18-000015:note_history:150]
We recorded adjustments to the carrying value of our non-marketable equity securities measured using the measurement alternative in the first quarter of fiscal 2019 as follows (in millions):

- added (2018-11-20):
[0000858877-18-000015:note_history:151]
|  | Three Months Ended |
|  | October 27, 2018 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |
| Upward adjustments | $ | 10 |  |
| Downward adjustments, including impairments | (16 | ) |
| Net downward adjustments | $ | (6 | ) |

- added (2018-11-20):
[0000858877-18-000015:note_history:152]
Gains and losses recognized on our marketable and non-marketable equity securities for the first quarter of fiscal 2019 are summarized below (in millions):

- added (2018-11-20):
[0000858877-18-000015:note_history:153]
|  | Three Months Ended |
|  | October 27, 2018 |
| Net gains and losses recognized during the period on equity investments | $ | 8 |  |
| Less: Net gains and losses recognized on equity investments sold | (12 | ) |
| Unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | (4 | ) |

- changed (2018-11-20):
[0000858877-18-000015:note_history:154]
| (c) | Securities Lending |
  (was, 2018-05-22, similarity 0.9643):
[0000858877-18-000007:note_history:154]
| (d) | Securities Lending |

- added (2018-11-20):
[0000858877-18-000015:note_history:155]
We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending was $0.5 billion as of each of the first quarters of fiscal 2019 and fiscal 2018, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 27, 2018 and July 28, 2018, we had no outstanding securities lending transactions.

- added (2018-11-20):
[0000858877-18-000015:note_history:156]
| (d) | Variable Interest Entities |

- added (2018-11-20):
[0000858877-18-000015:note_history:157]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 27, 2018, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in our Consolidated Financial Statements.

- changed (2018-11-20):
[0000858877-18-000015:note_history:158]
As of October 27, 2018, the carrying value of our non-marketable equity securities was $1.2 billion, of which $670 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, we have additional funding commitments of $204 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these variable interest entities.
  (was, 2018-05-22, similarity 0.905):
[0000858877-18-000007:note_history:158]
As of April 28, 2018, the carrying value of investments in privately held companies was $969 million, of which $511 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $212 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.

- removed (2018-11-20):
[0000858877-18-000007:note_history:159]
Investments

- removed (2018-11-20):
[0000858877-18-000007:note_history:160]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases (sales) were $(7) million and $(30) million as of April 28, 2018 and July 29, 2017, respectively.

- removed (2018-11-20):
[0000858877-18-000007:note_history:161]
| (b) | Gains and Losses on Available-for-Sale Investments |

- removed (2018-11-20):
[0000858877-18-000007:note_history:162]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Gross realized gains | $ | 101 |  |  | $ | 43 |  |  | $ | 333 |  |  | $ | 91 |  |
| Gross realized losses | (84 | ) |  | (119 | ) |  | (225 | ) |  | (182 | ) |
| Total | $ | 17 |  |  | $ | (76 | ) |  | $ | 108 |  |  | $ | (91 | ) |

- removed (2018-11-20):
[0000858877-18-000007:note_history:163]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 56 |  |  | $ | (59 | ) |  | $ | 239 |  |  | $ | (50 | ) |
| Net gains (losses) on investments in fixed income securities | (39 | ) |  | (17 | ) |  | (131 | ) |  | (41 | ) |
| Total | $ | 17 |  |  | $ | (76 | ) |  | $ | 108 |  |  | $ | (91 | ) |

- removed (2018-11-20):
[0000858877-18-000007:note_history:164]
The net realized losses related to the Company's available-for-sale investments included impairment charges of $26 million and $52 million for the three and nine months ended April 28, 2018, respectively. For the three and nine months ended April 29, 2017, the net realized losses related to the Company's available-for-sale investments included impairment charges of $73 million. These impairment charges related primarily to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary.

- removed (2018-11-20):
[0000858877-18-000007:note_history:165]
As of April 28, 2018, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of April 28, 2018, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the nine months ended April 28, 2018.

- removed (2018-11-20):
[0000858877-18-000007:note_history:166]
The Company has evaluated its publicly traded equity securities as of April 28, 2018 and has determined that there were no additional other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

- removed (2018-11-20):
[0000858877-18-000007:note_history:167]
| (c) | Maturities of Fixed Income Securities |

- removed (2018-11-20):
[0000858877-18-000007:note_history:168]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 13,959 |  |  | $ | 13,908 |  |
| Due in 1 to 2 years | 10,521 |  |  | 10,414 |  |
| Due in 2 to 5 years | 18,552 |  |  | 18,230 |  |
| Due after 5 years | 1,972 |  |  | 1,900 |  |
| Mortgage-backed securities with no single maturity | 2,009 |  |  | 1,935 |  |
| Total | $ | 47,013 |  |  | $ | 46,387 |  |

- removed (2018-11-20):
[0000858877-18-000007:note_history:169]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 28, 2018 and April 29, 2017 was $0.3 billion and $0.8 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of April 28, 2018 and July 29, 2017, the Company had no outstanding securities lending transactions.

- removed (2018-11-20):
[0000858877-18-000007:note_history:170]
| (e) | Investments in Privately Held Companies |

- removed (2018-11-20):
[0000858877-18-000007:note_history:171]
The carrying value of the investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of April 28, 2018 and July 29, 2017, the amounts are summarized in the following table (in millions):

- removed (2018-11-20):
[0000858877-18-000007:note_history:172]
For additional information on impairment charges related to investments in privately held companies, see Note 9.

- removed (2018-11-20):
[0000858877-18-000007:note_history:173]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of April 28, 2018, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-20):
[0000858877-18-000015:note_history:174]
The following table summarizes our long-term debt (in millions, except percentages):
  (was, 2018-05-22, similarity 0.9213):
[0000858877-18-000007:note_history:174]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

- changed (2018-11-20):
[0000858877-18-000015:note_history:175]
|  |  |  | October 27, 2018 |  | July 28, 2018 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | $ | 500 |  |  | 2.88% |  | $ | 500 |  |  | 2.86% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.72% |  | 500 |  |  | 2.71% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.22% |  | 2,000 |  |  | 5.17% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.87% |  | 1,750 |  |  | 2.71% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.68% |  | 2,500 |  |  | 4.52% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 3.05% |  | 500 |  |  | 2.86% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 3.32% |  | 500 |  |  | 3.11% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 3.17% |  | 1,000 |  |  | 2.98% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.48% |  | 500 |  |  | 3.27% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 25,750 |  |  |  |  | 25,750 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (112 | ) |  |  |  | (116 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (74 | ) |  |  |  | (65 | ) |  |  |
| Total |  |  | $ | 25,564 |  |  |  |  | $ | 25,569 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 7,241 |  |  |  |  | $ | 5,238 |  |  |  |
| Long-term debt |  |  | 18,323 |  |  |  |  | 20,331 |  |  |  |
| Total |  |  | $ | 25,564 |  |  |  |  | $ | 25,569 |  |  |  |
  (was, 2018-05-22, similarity 0.9202):
[0000858877-18-000007:note_history:175]
|  |  |  | April 28, 2018 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | — |  |  | — |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 2.50% |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 2.57% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.58% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | — |  |  | — |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.12% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.50% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.38% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.66% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.94% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.78% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.10% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 28,250 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (119 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (59 | ) |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 28,072 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 7,736 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 20,336 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 28,072 |  |  |  |  | $ | 30,472 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-20):
[0000858877-18-000015:note_history:176]
As of October 27, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2018-05-22, similarity 0.9627):
[0000858877-18-000007:note_history:176]
As of April 28, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2018-11-20):
[0000858877-18-000015:note_history:177]
| Fiscal Year | Amount |
| 2019 (remaining nine months) | $ | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| Thereafter | 8,500 |  |
| Total | $ | 25,750 |  |
  (was, 2018-05-22, similarity 0.9772):
[0000858877-18-000007:note_history:177]
| Fiscal Year | Amount |
| 2018 (remaining three months) | $ | 2,500 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 28,250 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-20):
[0000858877-18-000015:note_history:178]
The following table summarizes our short-term debt (in millions, except percentages):
  (was, 2018-05-22, similarity 0.9222):
[0000858877-18-000007:note_history:178]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

- changed (2018-11-20):
[0000858877-18-000015:note_history:179]
|  | October 27, 2018 |  | July 28, 2018 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 7,241 |  |  | 3.06 | % |  | $ | 5,238 |  |  | 3.46 | % |
  (was, 2018-05-22, similarity 0.7285):
[0000858877-18-000007:note_history:179]
|  | April 28, 2018 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 7,736 |  |  | 2.91 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | — |  |  | — | % |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 7,736 |  |  |  |  | $ | 7,992 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-11-20):
[0000858877-18-000015:note_history:180]
The following table presents this disaggregation of revenue (in millions):

- added (2018-11-20):
[0000858877-18-000015:note_history:181]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 7,642 |  |  | $ | 6,980 |  |
| Applications | 1,419 |  |  | 1,203 |  |
| Security | 651 |  |  | 585 |  |
| Other Products | 178 |  |  | 286 |  |
| Total Product | 9,890 |  |  | 9,054 |  |
| Services | 3,182 |  |  | 3,082 |  |
| Total | $ | 13,072 |  |  | $ | 12,136 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-11-20):
[0000858877-18-000015:note_history:182]
Revenue

- added (2018-11-20):
[0000858877-18-000015:note_history:183]
| (a) | Disaggregation of Revenue |

- added (2018-11-20):
[0000858877-18-000015:note_history:184]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. The following table presents this disaggregation of revenue (in millions):

- added (2018-11-20):
[0000858877-18-000015:note_history:185]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Revenue: |  |  |  |
| Infrastructure Platforms | $ | 7,642 |  |  | $ | 6,980 |  |
| Applications | 1,419 |  |  | 1,203 |  |
| Security | 651 |  |  | 585 |  |
| Other Products | 178 |  |  | 286 |  |
| Total Product | 9,890 |  |  | 9,054 |  |
| Services | 3,182 |  |  | 3,082 |  |
| Total | $ | 13,072 |  |  | $ | 12,136 |  |

- added (2018-11-20):
[0000858877-18-000015:note_history:186]
Amounts may not sum due to rounding.

- added (2018-11-20):
[0000858877-18-000015:note_history:187]
Infrastructure Platforms consist of our core networking technologies of switching, routing, data center products, and wireless that are designed to work together to deliver networking capabilities and transport and/or store data. These technologies consist of both hardware and software offerings, including software licenses and software-as-a-service (SaaS), that help our customers build networks, automate, orchestrate, integrate, and digitize data. We are shifting and expanding more of our business to software and subscriptions across our core networking portfolio. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2018-11-20):
[0000858877-18-000015:note_history:188]
Applications consists of offerings that utilize the core networking and data center platforms to provide their functions. The products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2018-11-20):
[0000858877-18-000015:note_history:189]
Security primarily includes our unified threat management, advanced threat security, and web security products. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers' network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2018-11-20):
[0000858877-18-000015:note_history:190]
Other Products primarily include our Service Provider Video Software Solutions, cloud and system management products. On May 1, 2018, we announced a definitive agreement to sell the SPVSS business. The sale was closed on October 28, 2018. These products include both hardware and software licenses. Our offerings in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control.

- added (2018-11-20):
[0000858877-18-000015:note_history:191]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and advanced services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Advanced services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

- added (2018-11-20):
[0000858877-18-000015:note_history:192]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for all of our hardware, software and service offerings. Refer to Note 8 for additional information. For these arrangements, cash is typically received over time.

- added (2018-11-20):
[0000858877-18-000015:note_history:193]
| (b) | Contract Balances |

- added (2018-11-20):
[0000858877-18-000015:note_history:194]
Accounts receivable, net was $4.5 billion as of October 27, 2018 compared to $5.6 billion as of July 28, 2018, as reported on the Consolidated Balance Sheet.

- added (2018-11-20):
[0000858877-18-000015:note_history:195]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of October 27, 2018 and July 29, 2018, our contract assets for these unbilled receivables were $447 million and $122 million, respectively, and were included in other current assets and other assets.

- added (2018-11-20):
[0000858877-18-000015:note_history:196]
Contract liabilities consist of deferred revenue. Deferred revenue was $16.8 billion as of October 27, 2018 compared to $19.7 billion as of July 28, 2018. In connection with the adoption of ASC 606, we recorded an adjustment to retained earnings to reduce deferred revenue by $2.8 billion. We recognized approximately $3.4 billion of revenue during the first quarter of fiscal 2019 that was included in the deferred revenue balance at July 29, 2018.

- added (2018-11-20):
[0000858877-18-000015:note_history:197]
| (c) | Remaining Performance Obligations |

- added (2018-11-20):
[0000858877-18-000015:note_history:198]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of October 27, 2018, the aggregate amount of RPO was $22.3 billion, comprised of $16.8 billion of deferred revenue and $5.5 billion of unbilled contract revenue. We expect approximately 55% of this amount to be recognized as revenue over the next year. Unbilled contract revenue represents non-cancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

- added (2018-11-20):
[0000858877-18-000015:note_history:199]
| (d) | Capitalized Contract Acquisition Costs |

- added (2018-11-20):
[0000858877-18-000015:note_history:200]
In connection with the adoption of ASC 606, we began to capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $673 million and $644 million as of October 27, 2018 and July 29, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $112 million for the first quarter of fiscal 2019 and was included in sales and marketing expenses.
