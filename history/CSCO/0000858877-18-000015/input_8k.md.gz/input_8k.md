# CSCO 8-K — 0001193125-18-326716 filed 2018-11-14

## item codes, every 8-K on or before 2018-11-20

- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2018-11-20

- none on or before 2018-11-20

## item 2.02 — earnings release, exhibit 99.1

[0001193125-18-326716:8k_2_02:1]
EX-99.1
2
d602856dex991.htm
EXHIBIT 99.1

[0001193125-18-326716:8k_2_02:2]
Exhibit 99.1

[0001193125-18-326716:8k_2_02:3]
Exhibit 99.1

[0001193125-18-326716:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-18-326716:8k_2_02:5]
CISCO REPORTS FIRST QUARTER EARNINGS

[0001193125-18-326716:8k_2_02:6]
|  | • |  | Q1 Results: |

[0001193125-18-326716:8k_2_02:7]
|  | • |  | Revenue: $13.1 billion |

[0001193125-18-326716:8k_2_02:8]
|  | • |  | Increase of 8% year over year |

[0001193125-18-326716:8k_2_02:9]
|  | • |  | Earnings per Share: GAAP: $0.77; Non-GAAP: $0.75 |

[0001193125-18-326716:8k_2_02:10]
|  | • |  | Non-GAAP EPS increased 23% year over year |

[0001193125-18-326716:8k_2_02:11]
|  | • |  | Q2 FY 2019 Guidance (normalized to exclude SPVSS business): |

[0001193125-18-326716:8k_2_02:12]
|  | • |  | Revenue: 5% to 7% growth year over year |

[0001193125-18-326716:8k_2_02:13]
|  | • |  | Earnings per Share: GAAP: $0.56 to $0.61; Non-GAAP: $0.71 to $0.73 |

[0001193125-18-326716:8k_2_02:14]
SAN JOSE, Calif. — November 14, 2018 — Cisco today reported first quarter results for the period ended October 27, 2018. Cisco reported
first quarter revenue of $13.1 billion, net income on a generally accepted accounting principles (GAAP) basis of $3.5 billion or $0.77 per share, and non-GAAP net income of $3.5 billion or $0.75
per share.

[0001193125-18-326716:8k_2_02:15]
“We had a strong start to fiscal 2019 and we believe our opportunity has never been greater,” said Chuck Robbins, chairman and CEO
of Cisco. “Our customers are looking to Cisco as a trusted partner to help them operate in a multi-cloud world and to transform their businesses. Our strategy is working and we are well positioned with our growing and differentiated
portfolio across multiple domains to bring our customers a more secure, automated and simple IT infrastructure.”

[0001193125-18-326716:8k_2_02:16]
GAAP Results

[0001193125-18-326716:8k_2_02:17]
|  |  | Q1 FY 2019 |  |  | Q1 FY 2018 |  |  | Vs. Q1 FY 2018 |  |
| Revenue |  | $ | 13.1 billion |  |  | $ | 12.1 billion |  |  |  | 8 | % |
| Net Income |  | $ | 3.5 billion |  |  | $ | 2.4 billion |  |  |  | 48 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.77 |  |  | $ | 0.48 |  |  |  | 60 | % |

[0001193125-18-326716:8k_2_02:18]
Non-GAAP Results

[0001193125-18-326716:8k_2_02:19]
|  |  | Q1 FY 2019 |  |  | Q1 FY 2018 |  |  | Vs. Q1 FY 2018 |  |
| Net Income |  | $ | 3.5 billion |  |  | $ | 3.0 billion |  |  |  | 14 | % |
| EPS |  | $ | 0.75 |  |  | $ | 0.61 |  |  |  | 23 | % |

[0001193125-18-326716:8k_2_02:20]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP basis are provided in the tables located in
the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-18-326716:8k_2_02:21]
“We executed well, with broad-based growth across all of our
geographies, product categories and customer segments, and delivered 8% revenue growth and 23% non-GAAP EPS growth,” said Kelly Kramer, CFO of Cisco. “We are seeing the returns on our investments in innovation as we continue to
transform our business model.”

[0001193125-18-326716:8k_2_02:22]
1

[0001193125-18-326716:8k_2_02:23]
Financial Summary

[0001193125-18-326716:8k_2_02:24]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-18-326716:8k_2_02:25]
Q1 FY 2019 Highlights

[0001193125-18-326716:8k_2_02:26]
Revenue — Total
revenue was $13.1 billion, up 8%, with product revenue up 9% and service revenue up 3%. Revenue by geographic segment was: Americas up 5%, EMEA up 11%, and APJC up 12%. Product revenue performance was generally broad based with growth in
Applications, up 18%, Security, up 11%, and Infrastructure Platforms, up 9%.

[0001193125-18-326716:8k_2_02:27]
Gross Margin — On a GAAP basis, total gross
margin, product gross margin, and service gross margin were 62.3%, 61.6%, and 64.6%, respectively, as compared with 61.2%, 60.1%, and 64.5%, respectively, in the first quarter of fiscal 2018.

[0001193125-18-326716:8k_2_02:28]
On a non-GAAP basis, total gross margin, product gross margin, and service gross margin were 63.8%, 63.2%, and 65.7%, respectively, as compared with 63.7%,
63.0%, and 65.6%, respectively in the first quarter of fiscal 2018.

[0001193125-18-326716:8k_2_02:29]
Total gross margins by geographic segment were: 65.4% for the Americas, 64.2% for
EMEA and 57.2% for APJC.

[0001193125-18-326716:8k_2_02:30]
Operating Expenses — On a GAAP basis, operating expenses were $4.3 billion, down 7%. Non-GAAP
operating expenses were $4.2 billion, up 3%, and were 31.9% of revenue.

[0001193125-18-326716:8k_2_02:31]
Operating Income — GAAP operating income was
$3.8 billion, up 38%, with GAAP operating margin of 29.1%. Non-GAAP operating income was $4.2 billion, up 13%, with non-GAAP operating margin at 31.9%.

[0001193125-18-326716:8k_2_02:32]
Provision for Income Taxes — The GAAP tax provision rate was 9.2%. The non-GAAP tax provision rate was 19.0%.

[0001193125-18-326716:8k_2_02:33]
Net Income and EPS — On a GAAP basis, net income was $3.5 billion and EPS was $0.77. On a non-GAAP basis, net income was
$3.5 billion, an increase of 14%, and EPS was $0.75, an increase of 23%.

[0001193125-18-326716:8k_2_02:34]
Cash Flow from Operating Activities — $3.8 billion
for the first quarter of fiscal 2019, an increase of 22% compared with $3.1 billion for the first quarter of fiscal 2018. Operating cash flow includes the receipt of $0.4 billion in relation to the litigation settlement with Arista
Networks. Operating cash flow increased 9%, normalized for this receipt.

[0001193125-18-326716:8k_2_02:35]
Balance Sheet and Other Financial Highlights

[0001193125-18-326716:8k_2_02:36]
Cash and Cash Equivalents and Investments — $42.6 billion at the end of the first quarter of fiscal 2019, compared with
$46.5 billion at the end of fiscal 2018.

[0001193125-18-326716:8k_2_02:37]
Deferred Revenue — $16.8 billion, down 9% in total, with deferred product revenue
down 24%. Deferred service revenue was up 1%.

[0001193125-18-326716:8k_2_02:38]
Capital Allocation — For the first quarter of fiscal 2019, Cisco returned
$6.5 billion to shareholders through share buybacks and dividends. Cisco declared and paid a cash dividend of $0.33 per common share, or $1.5 billion. Cisco repurchased approximately 109 million shares of common stock under its stock
repurchase program at an average price of $46.01 per share for an aggregate purchase price of $5.0 billion. The remaining authorized amount for stock repurchases under the program is $14.0 billion with no termination date.

[0001193125-18-326716:8k_2_02:39]
Acquisitions and Divestitures

[0001193125-18-326716:8k_2_02:40]
In the first quarter of
fiscal 2019, we closed the acquisition of Duo Security, a privately held company that provides unified access security and multi-factor authentication delivered through the cloud. We also closed the acquisition of July Systems, Inc., a privately
held company that provides an enterprise-grade location platform through cloud-based subscription offerings.

[0001193125-18-326716:8k_2_02:41]
In the fourth quarter of fiscal 2018, we
announced an agreement to sell our Service Provider Video Software Solutions (SPVSS) business. This transaction closed in the second quarter of fiscal 2019.

[0001193125-18-326716:8k_2_02:42]
2

[0001193125-18-326716:8k_2_02:43]
Guidance for Q2 FY 2019

[0001193125-18-326716:8k_2_02:44]
In the second quarter of fiscal 2019 on October 28, 2018, Cisco completed its divestiture of the SPVSS business. In order to provide a clear view of
Cisco’s continuing expected performance, the revenue outlook for the second quarter of fiscal 2019 is normalized to exclude the SPVSS business for the second quarter of fiscal 2018. The corresponding revenue in the second quarter of fiscal 2018
for the SPVSS business was $230 million.

[0001193125-18-326716:8k_2_02:45]
Cisco expects to achieve the following results for the second quarter of fiscal 2019 (normalized to exclude
SPVSS business):

[0001193125-18-326716:8k_2_02:46]
| Q2 FY 2019 |  |  |
| Revenue |  | 5% - 7% growth Y/Y |
| Non-GAAP gross margin rate |  | 63.5% - 64.5% |
| Non-GAAP operating margin rate |  | 30.5% - 31.5% |
| Non-GAAP tax provision rate |  | 19% |
| Non-GAAP EPS |  | $0.71 - $0.73 |

[0001193125-18-326716:8k_2_02:47]
Cisco estimates that GAAP EPS will be $0.56 to $0.61 in the second quarter of fiscal 2019.

[0001193125-18-326716:8k_2_02:48]
A reconciliation between the Guidance for Q2 FY 2019 on a GAAP and non-GAAP basis is provided in the table entitled “GAAP to non-GAAP Guidance for Q2 FY
2019” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-18-326716:8k_2_02:49]
Editor’s Notes:

[0001193125-18-326716:8k_2_02:50]
|  | • |  | Q1 fiscal year 2019 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, November 14, 2018 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-18-326716:8k_2_02:51]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, November 14, 2018 to 4:00 p.m. Pacific Time, November 21, 2018 at 1-866-501-5114 (United States) or 1-203-369-1838 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-18-326716:8k_2_02:52]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, November 14, 2018. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-18-326716:8k_2_02:53]
3

[0001193125-18-326716:8k_2_02:54]
CISCO SYSTEMS, INC.

[0001193125-18-326716:8k_2_02:55]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-18-326716:8k_2_02:56]
(In millions, except per-share amounts)

[0001193125-18-326716:8k_2_02:57]
(Unaudited)

[0001193125-18-326716:8k_2_02:58]
|  |  | Three Months Ended |  |
|  |  | October 27,2018 |  |  | October 28,2017 |  |
| REVENUE: |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,890 |  |  | $ | 9,054 |  |
| Service |  |  | 3,182 |  |  |  | 3,082 |  |
| Total revenue |  |  | 13,072 |  |  |  | 12,136 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |
| Product |  |  | 3,799 |  |  |  | 3,615 |  |
| Service |  |  | 1,127 |  |  |  | 1,094 |  |
| Total cost of sales |  |  | 4,926 |  |  |  | 4,709 |  |
| GROSS MARGIN |  |  | 8,146 |  |  |  | 7,427 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,608 |  |  |  | 1,567 |  |
| Sales and marketing |  |  | 2,410 |  |  |  | 2,334 |  |
| General and administrative |  |  | 211 |  |  |  | 557 |  |
| Amortization of purchased intangible assets |  |  | 34 |  |  |  | 61 |  |
| Restructuring and other charges |  |  | 78 |  |  |  | 152 |  |
| Total operating expenses |  |  | 4,341 |  |  |  | 4,671 |  |
| OPERATING INCOME |  |  | 3,805 |  |  |  | 2,756 |  |
| Interest income |  |  | 344 |  |  |  | 379 |  |
| Interest expense |  |  | (221 | ) |  |  | (235 | ) |
| Other income (loss), net |  |  | (19 | ) |  |  | 62 |  |
| Interest and other income (loss), net |  |  | 104 |  |  |  | 206 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,909 |  |  |  | 2,962 |  |
| Provision for income taxes |  |  | 360 |  |  |  | 568 |  |
| NET INCOME |  | $ | 3,549 |  |  | $ | 2,394 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.78 |  |  | $ | 0.48 |  |
| Diluted |  | $ | 0.77 |  |  | $ | 0.48 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,565 |  |  |  | 4,959 |  |
| Diluted |  |  | 4,614 |  |  |  | 4,994 |  |
| Cash dividends declared per common share |  | $ | 0.33 |  |  | $ | 0.29 |  |

[0001193125-18-326716:8k_2_02:59]
4

[0001193125-18-326716:8k_2_02:60]
CISCO SYSTEMS, INC.

[0001193125-18-326716:8k_2_02:61]
REVENUE BY SEGMENT

[0001193125-18-326716:8k_2_02:62]
(In
millions, except percentages)

[0001193125-18-326716:8k_2_02:63]
|  |  | Three Months Ended |  |
|  |  | October 27, 2018 |  |
|  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,751 |  |  |  | 5 | % |
| EMEA |  |  | 3,224 |  |  |  | 11 | % |
| APJC |  |  | 2,096 |  |  |  | 12 | % |
| Total |  | $ | 13,072 |  |  |  | 8 | % |

[0001193125-18-326716:8k_2_02:64]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-18-326716:8k_2_02:65]
CISCO SYSTEMS, INC.

[0001193125-18-326716:8k_2_02:66]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-18-326716:8k_2_02:67]
(In percentages)

[0001193125-18-326716:8k_2_02:68]
|  |  | Three Months Ended |  |
|  |  | October 27, 2018 |  |
| Gross Margin Percentage: |  |  |  |  |
| Americas |  |  | 65.4 | % |
| EMEA |  |  | 64.2 | % |
| APJC |  |  | 57.2 | % |

[0001193125-18-326716:8k_2_02:69]
CISCO SYSTEMS, INC.

[0001193125-18-326716:8k_2_02:70]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-18-326716:8k_2_02:71]
(In millions, except percentages)

[0001193125-18-326716:8k_2_02:72]
|  |  | Three Months Ended |  |
|  |  | October 27, 2018 |  |
|  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,642 |  |  |  | 9 | % |
| Applications |  |  | 1,419 |  |  |  | 18 | % |
| Security |  |  | 651 |  |  |  | 11 | % |
| Other Products |  |  | 178 |  |  |  | (38 | )% |
| Total Product |  |  | 9,890 |  |  |  | 9 | % |
| Services |  |  | 3,182 |  |  |  | 3 | % |
| Total |  | $ | 13,072 |  |  |  | 8 | % |

[0001193125-18-326716:8k_2_02:73]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-18-326716:8k_2_02:74]
5

[0001193125-18-326716:8k_2_02:75]
CISCO SYSTEMS, INC.

[0001193125-18-326716:8k_2_02:76]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-18-326716:8k_2_02:77]
(In millions)

[0001193125-18-326716:8k_2_02:78]
(Unaudited)

[0001193125-18-326716:8k_2_02:79]
|  |  | October 27,2018 |  |  | July 28,2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 8,410 |  |  | $ | 8,934 |  |
| Investments |  |  | 34,183 |  |  |  | 37,614 |  |
| Accounts receivable, net of allowance for doubtful accounts of $130 at October 27, 2018 and $129 at July 28, 2018 |  |  | 4,536 |  |  |  | 5,554 |  |
| Inventories |  |  | 1,572 |  |  |  | 1,846 |  |
| Financing receivables, net |  |  | 4,851 |  |  |  | 4,949 |  |
| Other current assets |  |  | 2,134 |  |  |  | 2,940 |  |
| Total current assets |  |  | 55,686 |  |  |  | 61,837 |  |
| Property and equipment, net |  |  | 2,956 |  |  |  | 3,006 |  |
| Financing receivables, net |  |  | 4,644 |  |  |  | 4,882 |  |
| Goodwill |  |  | 33,386 |  |  |  | 31,706 |  |
| Purchased intangible assets, net |  |  | 2,716 |  |  |  | 2,552 |  |
| Deferred tax assets |  |  | 3,960 |  |  |  | 3,219 |  |
| Other assets |  |  | 2,081 |  |  |  | 1,582 |  |
| TOTAL ASSETS |  | $ | 105,429 |  |  | $ | 108,784 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 7,241 |  |  | $ | 5,238 |  |
| Accounts payable |  |  | 1,805 |  |  |  | 1,904 |  |
| Income taxes payable |  |  | 1,084 |  |  |  | 1,004 |  |
| Accrued compensation |  |  | 2,622 |  |  |  | 2,986 |  |
| Deferred revenue |  |  | 9,637 |  |  |  | 11,490 |  |
| Other current liabilities |  |  | 4,025 |  |  |  | 4,413 |  |
| Total current liabilities |  |  | 26,414 |  |  |  | 27,035 |  |
| Long-term debt |  |  | 18,323 |  |  |  | 20,331 |  |
| Income taxes payable |  |  | 8,216 |  |  |  | 8,585 |  |
| Deferred revenue |  |  | 7,177 |  |  |  | 8,195 |  |
| Other long-term liabilities |  |  | 1,451 |  |  |  | 1,434 |  |
| Total liabilities |  |  | 61,581 |  |  |  | 65,580 |  |
| Total equity |  |  | 43,848 |  |  |  | 43,204 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 105,429 |  |  | $ | 108,784 |  |

[0001193125-18-326716:8k_2_02:80]
6

[0001193125-18-326716:8k_2_02:81]
CISCO SYSTEMS, INC.

[0001193125-18-326716:8k_2_02:82]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-18-326716:8k_2_02:83]
(In millions)

[0001193125-18-326716:8k_2_02:84]
(Unaudited)

[0001193125-18-326716:8k_2_02:85]
|  |  | Three Months Ended |  |
|  |  | October 27,2018 |  |  | October 28,2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,549 |  |  | $ | 2,394 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 465 |  |  |  | 566 |  |
| Share-based compensation expense |  |  | 403 |  |  |  | 392 |  |
| Provision (benefit) for receivables |  |  | 8 |  |  |  | (17 | ) |
| Deferred income taxes |  |  | (72 | ) |  |  | 178 |  |
| (Gains) losses on divestitures, investments and other, net |  |  | 7 |  |  |  | (56 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 892 |  |  |  | 957 |  |
| Inventories |  |  | (34 | ) |  |  | (80 | ) |
| Financing receivables |  |  | 273 |  |  |  | (333 | ) |
| Other assets |  |  | (295 | ) |  |  | 8 |  |
| Accounts payable |  |  | (153 | ) |  |  | (235 | ) |
| Income taxes, net |  |  | (437 | ) |  |  | (419 | ) |
| Accrued compensation |  |  | (348 | ) |  |  | (215 | ) |
| Deferred revenue |  |  | (309 | ) |  |  | 77 |  |
| Other liabilities |  |  | (186 | ) |  |  | (137 | ) |
| Net cash provided by operating activities |  |  | 3,763 |  |  |  | 3,080 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (484 | ) |  |  | (8,275 | ) |
| Proceeds from sales of investments |  |  | 2,805 |  |  |  | 2,682 |  |
| Proceeds from maturities of investments |  |  | 2,541 |  |  |  | 3,929 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (1,964 | ) |  |  | (725 | ) |
| Purchases of investments in privately held companies |  |  | (29 | ) |  |  | (20 | ) |
| Return of investments in privately held companies |  |  | 16 |  |  |  | 81 |  |
| Acquisition of property and equipment |  |  | (212 | ) |  |  | (168 | ) |
| Proceeds from sales of property and equipment |  |  | 2 |  |  |  | 1 |  |
| Other |  |  | — |  |  |  | (10 | ) |
| Net cash provided by (used in) investing activities |  |  | 2,675 |  |  |  | (2,505 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 8 |  |  |  | 9 |  |
| Repurchases of common stock—repurchase program |  |  | (5,076 | ) |  |  | (1,686 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (318 | ) |  |  | (342 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | — |  |  |  | (2,498 | ) |
| Issuances of debt |  |  | — |  |  |  | 5,482 |  |
| Repayments of debt |  |  | — |  |  |  | (748 | ) |
| Dividends paid |  |  | (1,500 | ) |  |  | (1,436 | ) |
| Other |  |  | (59 | ) |  |  | (31 | ) |
| Net cash used in financing activities |  |  | (6,945 | ) |  |  | (1,250 | ) |
| Net increase (decrease) in cash, cash equivalents, and restricted cash |  |  | (507 | ) |  |  | (675 | ) |
| Cash, cash equivalents, and restricted cash, beginning of period |  |  | 8,993 |  |  |  | 11,773 |  |
| Cash, cash equivalents, and restricted cash, end of period |  | $ | 8,486 |  |  | $ | 11,098 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 269 |  |  | $ | 283 |  |
| Cash paid for income taxes, net |  | $ | 869 |  |  | $ | 810 |  |

[0001193125-18-326716:8k_2_02:86]
Prior period information has been retrospectively adjusted due to the adoption of ASU
2016-18, Statement of Cash Flows, Restricted Cash in the beginning of the first quarter of fiscal 2019.

[0001193125-18-326716:8k_2_02:87]
7

[0001193125-18-326716:8k_2_02:88]
CISCO SYSTEMS, INC.

[0001193125-18-326716:8k_2_02:89]
DEFERRED REVENUE

[0001193125-18-326716:8k_2_02:90]
(In
millions)

[0001193125-18-326716:8k_2_02:91]
|  |  | October 27,2018 |  |  | July 28,2018 |  |  | October 28,2017 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 11,062 |  |  | $ | 11,431 |  |  | $ | 10,991 |  |
| Product |  |  | 5,752 |  |  |  | 8,254 |  |  |  | 7,574 |  |
| Total |  | $ | 16,814 |  |  | $ | 19,685 |  |  | $ | 18,565 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 9,637 |  |  | $ | 11,490 |  |  | $ | 10,920 |  |
| Noncurrent |  |  | 7,177 |  |  |  | 8,195 |  |  |  | 7,645 |  |
| Total |  | $ | 16,814 |  |  | $ | 19,685 |  |  | $ | 18,565 |  |

[0001193125-18-326716:8k_2_02:92]
CISCO SYSTEMS, INC.

[0001193125-18-326716:8k_2_02:93]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-18-326716:8k_2_02:94]
(In millions, except per-share amounts)

[0001193125-18-326716:8k_2_02:95]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| October 27, 2018 |  | $ | 0.33 |  |  | $ | 1,500 |  |  |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |  | $ | 6,526 |  |
| Fiscal 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 28, 2018 |  | $ | 0.33 |  |  | $ | 1,535 |  |  |  | 138 |  |  | $ | 43.58 |  |  | $ | 6,015 |  |  | $ | 7,550 |  |
| April 28, 2018 |  | $ | 0.33 |  |  | $ | 1,572 |  |  |  | 140 |  |  | $ | 42.83 |  |  | $ | 6,015 |  |  | $ | 7,587 |  |
| January 27, 2018 |  | $ | 0.29 |  |  | $ | 1,425 |  |  |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |  | $ | 5,436 |  |
| October 28, 2017 |  | $ | 0.29 |  |  | $ | 1,436 |  |  |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |  | $ | 3,056 |  |

[0001193125-18-326716:8k_2_02:96]
8

[0001193125-18-326716:8k_2_02:97]
CISCO SYSTEMS, INC.

[0001193125-18-326716:8k_2_02:98]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-18-326716:8k_2_02:99]
GAAP TO NON-GAAP NET INCOME

[0001193125-18-326716:8k_2_02:100]
(In millions, except per-share amounts)

[0001193125-18-326716:8k_2_02:101]
|  |  | Three Months Ended |  |
|  |  | October 27,2018 |  |  | October 28,2017 |  |
| GAAP net income |  | $ | 3,549 |  |  | $ | 2,394 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 56 |  |  |  | 57 |  |
| Amortization of acquisition-related intangible assets |  |  | 136 |  |  |  | 139 |  |
| Supplier component remediation charge (adjustment), net |  |  | (1 | ) |  |  | (19 | ) |
| Acquisition-related/divestiture costs |  |  | 4 |  |  |  | — |  |
| Legal and indemnification settlements |  |  | — |  |  |  | 122 |  |
| Total adjustments to GAAP cost of sales |  |  | 195 |  |  |  | 299 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 329 |  |  |  | 335 |  |
| Amortization of acquisition-related intangible assets |  |  | 34 |  |  |  | 61 |  |
| Acquisition-related/divestiture costs |  |  | 121 |  |  |  | 83 |  |
| Legal and indemnification settlements |  |  | (395 | ) |  |  | — |  |
| Significant asset impairments and restructurings |  |  | 78 |  |  |  | 152 |  |
| Total adjustments to GAAP operating expenses |  |  | 167 |  |  |  | 631 |  |
| Adjustments to GAAP interest and other income (loss), net: |  |  |  |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | (9 | ) |  |  | — |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 353 |  |  |  | 930 |  |
| Income tax effect of non-GAAP adjustments |  |  | (185 | ) |  |  | (288 | ) |
| Significant tax matters |  |  | (265 | ) |  |  | — |  |
| Total adjustments to GAAP provision for income taxes |  |  | (450 | ) |  |  | (288 | ) |
| Non-GAAP net income |  | $ | 3,452 |  |  | $ | 3,036 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.77 |  |  | $ | 0.48 |  |
| Non-GAAP |  | $ | 0.75 |  |  | $ | 0.61 |  |

[0001193125-18-326716:8k_2_02:102]
9

[0001193125-18-326716:8k_2_02:103]
CISCO SYSTEMS, INC.

[0001193125-18-326716:8k_2_02:104]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-18-326716:8k_2_02:105]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-18-326716:8k_2_02:106]
(In millions, except percentages)

[0001193125-18-326716:8k_2_02:107]
|  |  | Three Months Ended |  |
|  |  | October 27, 2018 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestand otherincome(loss),net |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 6,091 |  |  | $ | 2,055 |  |  | $ | 8,146 |  |  | $ | 4,341 |  |  |  | (7 | )% |  | $ | 3,805 |  |  |  | 38 | % |  | $ | 104 |  |  |  | (50 | )% |  | $ | 3,549 |  |  |  | 48 | % |
| % of revenue |  |  | 61.6 | % |  |  | 64.6 | % |  |  | 62.3 | % |  |  | 33.2 | % |  |  |  |  |  |  | 29.1 | % |  |  |  |  |  |  | 0.8 | % |  |  |  |  |  |  | 27.1 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 23 |  |  |  | 33 |  |  |  | 56 |  |  |  | 329 |  |  |  |  |  |  |  | 385 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 385 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 136 |  |  |  | — |  |  |  | 136 |  |  |  | 34 |  |  |  |  |  |  |  | 170 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 170 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (395 | ) |  |  |  |  |  |  | (395 | ) |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (395 | ) |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 2 |  |  |  | 2 |  |  |  | 4 |  |  |  | 121 |  |  |  |  |  |  |  | 125 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 125 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 78 |  |  |  |  |  |  |  | 78 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 78 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (9 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (450 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 6,251 |  |  | $ | 2,090 |  |  | $ | 8,341 |  |  | $ | 4,174 |  |  |  | 3 | % |  | $ | 4,167 |  |  |  | 13 | % |  | $ | 95 |  |  |  | (54 | )% |  | $ | 3,452 |  |  |  | 14 | % |
| % of revenue |  |  | 63.2 | % |  |  | 65.7 | % |  |  | 63.8 | % |  |  | 31.9 | % |  |  |  |  |  |  | 31.9 | % |  |  |  |  |  |  | 0.7 | % |  |  |  |  |  |  | 26.4 | % |  |  |  |  |

[0001193125-18-326716:8k_2_02:108]
|  |  | Three Months Ended |  |
|  |  | October 28, 2017 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | NetIncome |  |
| GAAP amount |  | $ | 5,439 |  |  | $ | 1,988 |  |  | $ | 7,427 |  |  | $ | 4,671 |  |  | $ | 2,756 |  |  | $ | 2,394 |  |
| % of revenue |  |  | 60.1 | % |  |  | 64.5 | % |  |  | 61.2 | % |  |  | 38.5 | % |  |  | 22.7 | % |  |  | 19.7 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 23 |  |  |  | 34 |  |  |  | 57 |  |  |  | 335 |  |  |  | 392 |  |  |  | 392 |  |
| Amortization of acquisition-related intangible assets |  |  | 139 |  |  |  | — |  |  |  | 139 |  |  |  | 61 |  |  |  | 200 |  |  |  | 200 |  |
| Supplier component remediation charge (adjustment), net |  |  | (19 | ) |  |  | — |  |  |  | (19 | ) |  |  | — |  |  |  | (19 | ) |  |  | (19 | ) |
| Legal and indemnification settlements |  |  | 122 |  |  |  | — |  |  |  | 122 |  |  |  | — |  |  |  | 122 |  |  |  | 122 |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 83 |  |  |  | 83 |  |  |  | 83 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 152 |  |  |  | 152 |  |  |  | 152 |  |
| Income tax effect |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (288 | ) |
| Non-GAAP amount |  | $ | 5,704 |  |  | $ | 2,022 |  |  | $ | 7,726 |  |  | $ | 4,040 |  |  | $ | 3,686 |  |  | $ | 3,036 |  |
| % of revenue |  |  | 63.0 | % |  |  | 65.6 | % |  |  | 63.7 | % |  |  | 33.3 | % |  |  | 30.4 | % |  |  | 25.0 | % |

[0001193125-18-326716:8k_2_02:109]
10

[0001193125-18-326716:8k_2_02:110]
CISCO SYSTEMS, INC.

[0001193125-18-326716:8k_2_02:111]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-18-326716:8k_2_02:112]
EFFECTIVE TAX RATE

[0001193125-18-326716:8k_2_02:113]
(In
percentages)

[0001193125-18-326716:8k_2_02:114]
|  |  | Three Months Ended |  |
|  |  | October 27, 2018 |  |  | October 28, 2017 |  |
| GAAP effective tax rate |  |  | 9.2 | % |  |  | 19.2 | % |
| Total adjustments to GAAP provision for income taxes |  |  | 9.8 | % |  |  | 2.8 | % |
| Non-GAAP effective tax rate |  |  | 19.0 | % |  |  | 22.0 | % |

[0001193125-18-326716:8k_2_02:115]
GAAP TO NON-GAAP GUIDANCE FOR Q2 FY 2019

[0001193125-18-326716:8k_2_02:116]
| Q2 FY 2019 |  | Gross MarginRate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (2) |
| GAAP |  | 62% - 63% |  | 24.5% - 25.5% |  | 17% |  | $0.56 - $0.61 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.0% |  | — |  | $0.06 - $0.07 |
| Amortization of purchased intangible assets and other acquisition-related/divestiture costs |  | 1.0% |  | 1.0% |  | — |  | $0.02 - $0.03 |
| Restructuring and other charges (1) |  | — |  | 2.0% |  | — |  | $0.04 - $0.05 |
| Income tax effect of non-GAAP adjustments |  |  |  |  |  | 2% |  |  |
| Non-GAAP |  | 63.5% - 64.5% |  | 30.5% - 31.5% |  | 19% |  | $0.71 - $0.73 |

[0001193125-18-326716:8k_2_02:117]
| (1) | In the third quarter of fiscal 2018, we initiated a restructuring plan in order to realign the organization and enable further investment in key priority areas with estimated pretax charges of approximately $300 million. In the first quarter of fiscal 2019, we expanded the restructuring plan to include an additional $300 million of estimated additional pretax charges. We have recognized pretax charges of $186 million to our GAAP financial results in relation to this restructuring plan since its inception. We expect to recognize approximately $250 million of pretax charges under this plan in the second quarter of fiscal 2019. |

[0001193125-18-326716:8k_2_02:118]
| (2) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-18-326716:8k_2_02:119]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and significant
tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-18-326716:8k_2_02:120]
11

[0001193125-18-326716:8k_2_02:121]
Forward Looking Statements, Non-GAAP Information and Additional Information

[0001193125-18-326716:8k_2_02:122]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax
rates, non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-18-326716:8k_2_02:123]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles
and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they
do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the
corresponding GAAP measures.

[0001193125-18-326716:8k_2_02:124]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP measures,
provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-18-326716:8k_2_02:125]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other contingencies, gains and losses on equity investments, the
income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco
has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its
financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities
and Exchange Commission.

[0001193125-18-326716:8k_2_02:126]
12

[0001193125-18-326716:8k_2_02:127]
About Cisco

[0001193125-18-326716:8k_2_02:128]
Cisco (Nasdaq: CSCO) is the worldwide technology leader that has been making the Internet work since 1984. Our people, products and partners help society
securely connect and seize tomorrow’s digital opportunity today. Discover more at thenetwork.cisco.com and follow us on Twitter at @Cisco.

[0001193125-18-326716:8k_2_02:129]
Copyright
© 2018 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To
view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco
and any other company. This document is Cisco Public Information.

[0001193125-18-326716:8k_2_02:130]
13
