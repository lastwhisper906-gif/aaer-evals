# CSCO MD&A — 0000858877-18-000015


## mdna

[0000858877-18-000015:mdna:1]
[same as prior period, unchanged from 0000858877-18-000007:mdna:1]

[0000858877-18-000015:mdna:2]
[same as prior period, unchanged from 0000858877-18-000007:mdna:2]

[0000858877-18-000015:mdna:3]
[same as prior period, unchanged from 0000858877-18-000007:mdna:3]

[0000858877-18-000015:mdna:4]
Cisco designs and sells a broad range of technologies that have been powering the Internet since 1984. Across networking, security, collaboration, applications and the cloud, our evolving intent-based technologies are constantly learning and adapting to provide customers with a highly secure, intelligent platform for their digital business.

[0000858877-18-000015:mdna:5]
[same as prior period, unchanged from 0000858877-18-000007:mdna:5]

[0000858877-18-000015:mdna:6]
|  | Three Months Ended |  |
|  | October 27, 2018 |  | October 28, 2017 |  | Variance |  |
| Revenue | $ | 13,072 |  |  | $ | 12,136 |  |  | 8 | % |  |
| Gross margin percentage | 62.3 | % |  | 61.2 | % |  | 1.1 |  | pts |
| Research and development | $ | 1,608 |  |  | $ | 1,567 |  |  | 3 | % |  |
| Sales and marketing | $ | 2,410 |  |  | $ | 2,334 |  |  | 3 | % |  |
| General and administrative | $ | 211 |  |  | $ | 557 |  |  | (62 | )% |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,229 |  |  | $ | 4,458 |  |  | (5 | )% |  |
| Total as a percentage of revenue | 32.4 | % |  | 36.7 | % |  | (4.3 | ) | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 34 |  |  | $ | 61 |  |  | (44 | )% |  |
| Restructuring and other charges included in operating expenses | $ | 78 |  |  | $ | 152 |  |  | (49 | )% |  |
| Operating income as a percentage of revenue | 29.1 | % |  | 22.7 | % |  | 6.4 |  | pts |
| Income tax percentage | 9.2 | % |  | 19.2 | % |  | (10.0 | ) | pts |
| Net income | $ | 3,549 |  |  | $ | 2,394 |  |  | 48 | % |  |
| Net income as a percentage of revenue | 27.1 | % |  | 19.7 | % |  | 7.4 |  | pts |
| Earnings per share—diluted | $ | 0.77 |  |  | $ | 0.48 |  |  | 60 | % |  |

[0000858877-18-000015:mdna:7]
We adopted ASC 606 in the first quarter of fiscal 2019 using the modified retrospective method. See Note 2 to the Consolidated Financial Statements for impact of this adoption on our operating results for the first quarter of fiscal 2019.

[0000858877-18-000015:mdna:8]
[same as prior period, unchanged from 0000858877-18-000007:mdna:7]

[0000858877-18-000015:mdna:9]
[same as prior period, unchanged from 0000858877-18-000007:mdna:8]

[0000858877-18-000015:mdna:10]
[same as prior period, unchanged from 0000858877-18-000007:mdna:9]

[0000858877-18-000015:mdna:11]
Three Months Ended October 27, 2018 Compared with Three Months Ended October 28, 2017

[0000858877-18-000015:mdna:12]
In the first quarter of fiscal 2019, we saw broad-based growth across the business and delivered solid revenue growth, margins and operating cash flow.  We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. Our product revenue reflected solid growth in Infrastructure Platforms, Applications and Security, and we continued to make progress in the transition of our business model to increased software and subscriptions. Notwithstanding the first quarter fiscal 2019 results, we continue to operate in a challenging and highly competitive environment. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-18-000015:mdna:13]
Total revenue increased by 8% compared with the first quarter of fiscal 2018. Within total revenue, product revenue increased by 9% and service revenue increased by 3%. Total gross margin increased by 1.1 percentage points, driven primarily by productivity improvements and the $122 million legal and indemnification settlement charge recorded in the first quarter of fiscal 2018, partially offset by unfavorable impacts from pricing. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 4.3 percentage points primarily due to lower general and administrative expenses. General and administrative expenses decreased due to a benefit from the $400 million litigation settlement with Arista. Operating income as a percentage of revenue increased by 6.4 percentage points. The effective tax rate decreased 10.0 percentage points. Diluted earnings per share increased by 60%, driven by a 48% increase in net income and a decrease in diluted share count of 380 million shares.

[0000858877-18-000015:mdna:14]
In terms of our geographic segments, revenue from the Americas increased $401 million, EMEA revenue increased by $315 million, and revenue in our APJC segment increased by $219 million. These increases reflect broad strength across several countries within these segments. The “BRICM” countries experienced product revenue growth of 24% in the aggregate, driven by increased product revenue in the emerging countries of Mexico, India, Russia and Brazil of 64%, 55%, 23% and 1%, respectively, while product revenue in China was flat.

[0000858877-18-000015:mdna:15]
From a customer market standpoint, we experienced solid product revenue growth in the enterprise and service provider markets and, to a lesser extent, in the public sector and commercial markets.

[0000858877-18-000015:mdna:16]
From a product category perspective, we saw broad-based growth across the portfolio. The product revenue increase of 9% was driven by a 9% product revenue increase in Infrastructure Platforms and solid product revenue growth in Applications and Security, which grew by 18% and 11% respectively.

[0000858877-18-000015:mdna:17]
[same as prior period, unchanged from 0000858877-18-000007:mdna:16]

[0000858877-18-000015:mdna:18]
[same as prior period, unchanged from 0000858877-18-000007:mdna:17]

[0000858877-18-000015:mdna:19]
[same as prior period, unchanged from 0000858877-18-000007:mdna:20]

[0000858877-18-000015:mdna:20]
As our customers add billions of new connections to their enterprises, and as more applications move to a multi-cloud environment, we believe the network continues to be extremely critical. We believe that our customers are looking for intent-based networks that provide meaningful business value through automation, security, and analytics across private, hybrid, and multi-cloud environments. Our vision is to deliver highly secure, software-defined, automated and intelligent platforms for our customers. Our strategic priorities include the following: accelerating our pace of innovation, increasing the value of the network, and transforming our business model.

[0000858877-18-000015:mdna:21]
For additional discussion of our strategy and priorities, see Item 1. Business in our Annual Report on Form 10-K for the year ended July 28, 2018.

[0000858877-18-000015:mdna:22]
[same as prior period, unchanged from 0000858877-18-000007:mdna:23]

[0000858877-18-000015:mdna:23]
The following is a summary of our other key financial measures for the first quarter of fiscal 2019 (in millions):

[0000858877-18-000015:mdna:24]
|  |  | October 27, 2018 |  | July 28, 2018 |
| Cash and cash equivalents and investments |  | $ | 42,593 |  |  | $ | 46,548 |  |
| Deferred revenue |  | $ | 16,814 |  |  | $ | 19,685 |  |
| Inventories |  | $ | 1,572 |  |  | $ | 1,846 |  |

[0000858877-18-000015:mdna:25]
|  |  | Three Months Ended |
|  |  | October 27, 2018 |  | October 28, 2017 |
| Cash provided by operating activities |  | $ | 3,763 |  |  | $ | 3,080 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 5,026 |  |  | $ | 1,620 |  |
| Dividends |  | $ | 1,500 |  |  | $ | 1,436 |  |

[0000858877-18-000015:mdna:26]
[same as prior period, unchanged from 0000858877-18-000007:mdna:27]

[0000858877-18-000015:mdna:27]
[same as prior period, unchanged from 0000858877-18-000007:mdna:28]

[0000858877-18-000015:mdna:28]
[same as prior period, unchanged from 0000858877-18-000007:mdna:29]

[0000858877-18-000015:mdna:29]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements in our Annual Report on Form 10-K for the year ended July 28, 2018, as updated as applicable in Note 2 to the Consolidated Financial Statements herein, describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-18-000015:mdna:30]
[same as prior period, unchanged from 0000858877-18-000007:mdna:31]

[0000858877-18-000015:mdna:31]
In May 2014, the FASB issued ASC 606, Revenue from Contracts with Customers, a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP on revenue recognition and eliminated industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services.

[0000858877-18-000015:mdna:32]
ASC 606 allowed two methods of adoption: i) retrospectively to each prior period presented (“full retrospective method”), or ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption (“modified retrospective method”). At the beginning of our first quarter of fiscal 2019, we adopted ASC 606 using the modified retrospective method to those contracts that were not completed as of July 28, 2018.

[0000858877-18-000015:mdna:33]
ASC 606 primarily impacted our revenue recognition for software arrangements and sales to two-tier distributors. In both areas, the new standard accelerates the recognition of revenue.

[0000858877-18-000015:mdna:34]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis.

[0000858877-18-000015:mdna:35]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or once delivery and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-18-000015:mdna:36]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-18-000015:mdna:37]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes various rebate, cooperative marketing, and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable. If actual credits received by distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-18-000015:mdna:38]
See Notes 2 and 3 to the Consolidated Financial Statements for more details.

[0000858877-18-000015:mdna:39]
[same as prior period, unchanged from 0000858877-18-000007:mdna:41]

[0000858877-18-000015:mdna:40]
[same as prior period, unchanged from 0000858877-18-000007:mdna:42]

[0000858877-18-000015:mdna:41]
[same as prior period, unchanged from 0000858877-18-000007:mdna:43]

[0000858877-18-000015:mdna:42]
[same as prior period, unchanged from 0000858877-18-000007:mdna:44]

[0000858877-18-000015:mdna:43]
[same as prior period, unchanged from 0000858877-18-000007:mdna:45]

[0000858877-18-000015:mdna:44]
|  |  | October 27, 2018 |  | July 28, 2018 |
| Allowance for doubtful accounts |  | $ | 130 |  |  | $ | 129 |  |
| Percentage of gross accounts receivable |  | 2.8 | % |  | 2.3 | % |
| Allowance for credit loss—lease receivables |  | $ | 131 |  |  | $ | 135 |  |
| Percentage of gross lease receivables(1) |  | 4.9 | % |  | 4.7 | % |
| Allowance for credit loss—loan receivables |  | $ | 60 |  |  | $ | 60 |  |
| Percentage of gross loan receivables |  | 1.2 | % |  | 1.2 | % |

[0000858877-18-000015:mdna:45]
[same as prior period, unchanged from 0000858877-18-000007:mdna:47]

[0000858877-18-000015:mdna:46]
[same as prior period, unchanged from 0000858877-18-000007:mdna:48]

[0000858877-18-000015:mdna:47]
[same as prior period, unchanged from 0000858877-18-000007:mdna:49]

[0000858877-18-000015:mdna:48]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of October 27, 2018 and July 28, 2018 was $112 million and $123 million, respectively, and was recorded as a reduction of our accounts receivable and revenue. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-18-000015:mdna:49]
[same as prior period, unchanged from 0000858877-18-000007:mdna:51]

[0000858877-18-000015:mdna:50]
[same as prior period, unchanged from 0000858877-18-000007:mdna:52]

[0000858877-18-000015:mdna:51]
[same as prior period, unchanged from 0000858877-18-000007:mdna:53]

[0000858877-18-000015:mdna:52]
Our provision for inventory was $6 million and $15 million for the first quarter of fiscal 2019 and 2018, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $18 million and $21 million for the first quarter of fiscal 2019 and 2018, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments.

[0000858877-18-000015:mdna:53]
[same as prior period, unchanged from 0000858877-18-000007:mdna:54]

[0000858877-18-000015:mdna:54]
[same as prior period, unchanged from 0000858877-18-000007:mdna:55]

[0000858877-18-000015:mdna:55]
Loss Contingencies and Product Warranties

[0000858877-18-000015:mdna:56]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-18-000015:mdna:57]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-18-000015:mdna:58]
[same as prior period, unchanged from 0000858877-18-000007:mdna:62]

[0000858877-18-000015:mdna:59]
[same as prior period, unchanged from 0000858877-18-000007:mdna:63]

[0000858877-18-000015:mdna:60]
Impairment of Investments

[0000858877-18-000015:mdna:61]
We recognize an impairment charge when the declines in the fair values of our available-for-sale debt investments below their cost basis are judged to be other than temporary. The ultimate value realized on these securities, to the extent unhedged, is subject to market price volatility until they are sold.

[0000858877-18-000015:mdna:62]
[same as prior period, unchanged from 0000858877-18-000007:mdna:73]

[0000858877-18-000015:mdna:63]
We hold non-marketable equity and other investments, some of which are in the startup or development stages. As of October 27, 2018, our non-marketable equity and other investments were $1.2 billion, compared with $1.1 billion as of July 28, 2018, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize.

[0000858877-18-000015:mdna:64]
[same as prior period, unchanged from 0000858877-18-000007:mdna:78]

[0000858877-18-000015:mdna:65]
[same as prior period, unchanged from 0000858877-18-000007:mdna:79]

[0000858877-18-000015:mdna:66]
[same as prior period, unchanged from 0000858877-18-000007:mdna:66]

[0000858877-18-000015:mdna:67]
[same as prior period, unchanged from 0000858877-18-000007:mdna:67]

[0000858877-18-000015:mdna:68]
The goodwill recorded in the Consolidated Balance Sheets as of October 27, 2018 and July 28, 2018 was $33.4 billion and $31.7 billion, respectively. In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first quarters of fiscal 2019 and 2018.

[0000858877-18-000015:mdna:69]
[same as prior period, unchanged from 0000858877-18-000007:mdna:81]

[0000858877-18-000015:mdna:70]
[same as prior period, unchanged from 0000858877-18-000007:mdna:82]

[0000858877-18-000015:mdna:71]
There were no impairment charges related to purchased intangible assets for the first quarter of fiscal 2019 and 2018. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-18-000015:mdna:72]
[same as prior period, unchanged from 0000858877-18-000007:mdna:84]

[0000858877-18-000015:mdna:73]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 9.2% and 19.2% in the first quarter of fiscal 2019 and 2018, respectively.

[0000858877-18-000015:mdna:74]
On December 22, 2017, the Tax Cuts and Jobs Act (the "Tax Act") was enacted. The Tax Act significantly revises the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (“federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries.  As a result of the Tax Act enactment, we recorded a provisional tax expense of $10.4 billion in fiscal 2018.

[0000858877-18-000015:mdna:75]
In December 2017, the Securities and Exchange Commission staff issued Staff Accounting Bulletin No. 118, which addresses how a company recognizes provisional estimates when it does not have the necessary information available, prepared or analyzed (including computations) in reasonable detail to complete its accounting for the effect of the changes in the Tax Act. The measurement period ends when a company has obtained, prepared, and analyzed the information necessary to finalize its accounting, but cannot extend beyond one year. The final impact of the Tax Act may differ from the provisional estimates due to changes in interpretations of the Tax Act, any legislative action to address questions that arise because of the Tax Act, by changes in accounting standard for income taxes and related interpretations in response to the Tax Act, and any updates or changes to estimates used in the provisional amounts. We have determined that the $8.1 billion of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries, the $1.2 billion of foreign withholding tax, and the $1.1 billion of tax expense for DTA re-measurement were each provisional amounts and reasonable estimates as of October 27, 2018. Estimates used in the provisional amounts include: the anticipated reversal pattern of the gross DTAs; and earnings, cash positions, foreign taxes and withholding taxes attributable to foreign subsidiaries. The provisional tax expense related to the U.S. transition tax on accumulated earnings in foreign subsidiaries includes an $863 million benefit related to the U.S. taxation of deemed foreign dividends in the transition fiscal year. This benefit may be reduced or eliminated in future legislation. If such legislation is enacted, we will record the impact of the legislation in the quarter of enactment.

[0000858877-18-000015:mdna:76]
[same as prior period, unchanged from 0000858877-18-000007:mdna:76]

[0000858877-18-000015:mdna:77]
[same as prior period, unchanged from 0000858877-18-000007:mdna:77]

[0000858877-18-000015:mdna:78]
[same as prior period, unchanged from 0000858877-18-000007:mdna:90]

[0000858877-18-000015:mdna:79]
[same as prior period, unchanged from 0000858877-18-000007:mdna:91]

[0000858877-18-000015:mdna:80]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to domestic manufacturing deduction, foreign-derived intangible income, global intangible low-tax income and base erosion and anti-abuse tax laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 36 countries, including the United States, has made changes to numerous long-standing tax principles. There can be no assurance that these changes, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-18-000015:mdna:81]
55

[0000858877-18-000015:mdna:82]
[same as prior period, unchanged from 0000858877-18-000007:mdna:88]

[0000858877-18-000015:mdna:83]
[same as prior period, unchanged from 0000858877-18-000007:mdna:89]

[0000858877-18-000015:mdna:84]
[same as prior period, unchanged from 0000858877-18-000007:mdna:96]

[0000858877-18-000015:mdna:85]
[same as prior period, unchanged from 0000858877-18-000007:mdna:97]

[0000858877-18-000015:mdna:86]
[same as prior period, unchanged from 0000858877-18-000007:mdna:98]

[0000858877-18-000015:mdna:87]
|  |  | Three Months Ended |
|  |  | October 27, 2018 |  | October 28, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,890 |  |  | $ | 9,054 |  |  | $ | 836 |  |  | 9 | % |
| Percentage of revenue |  | 75.7 | % |  | 74.6 | % |  |  |  |  |  |  |
| Service |  | 3,182 |  |  | 3,082 |  |  | 100 |  |  | 3 | % |
| Percentage of revenue |  | 24.3 | % |  | 25.4 | % |  |  |  |  |  |  |
| Total |  | $ | 13,072 |  |  | $ | 12,136 |  |  | $ | 936 |  |  | 8 | % |

[0000858877-18-000015:mdna:88]
[same as prior period, unchanged from 0000858877-18-000007:mdna:100]

[0000858877-18-000015:mdna:89]
|  |  | Three Months Ended |
|  |  | October 27, 2018 |  | October 28, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,751 |  |  | $ | 7,350 |  |  | $ | 401 |  |  | 5 | % |
| Percentage of revenue |  | 59.3 | % |  | 60.5 | % |  |  |  |  |
| EMEA |  | 3,224 |  |  | 2,909 |  |  | 315 |  |  | 11 | % |
| Percentage of revenue |  | 24.7 | % |  | 24.0 | % |  |  |  |  |
| APJC |  | 2,096 |  |  | 1,877 |  |  | 219 |  |  | 12 | % |
| Percentage of revenue |  | 16.0 | % |  | 15.5 | % |  |  |  |  |
| Total |  | $ | 13,072 |  |  | $ | 12,136 |  |  | $ | 936 |  |  | 8 | % |

[0000858877-18-000015:mdna:90]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-18-000015:mdna:91]
Three Months Ended October 27, 2018 Compared with Three Months Ended October 28, 2017

[0000858877-18-000015:mdna:92]
Total revenue increased by 8%. Product revenue increased by 9% and service revenue increased by 3%. Our total revenue reflected growth across each of our geographic segments. Product revenue for the emerging countries of BRICM, in the aggregate, experienced 24% product revenue growth, with increases in Mexico, India, Russia and Brazil and product revenue in China being flat.

[0000858877-18-000015:mdna:93]
In addition to the impact of macroeconomic factors, including a reduced IT spending environment and reductions in spending by government entities, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple-element arrangements; the mix of financing arrangements provided to channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment. As has been the case in certain emerging countries from time to time, certain customers require greater levels of financing arrangements, service, and support, and these activities may occur in future periods, which may also impact the timing of the recognition of revenue.

[0000858877-18-000015:mdna:94]
[same as prior period, unchanged from 0000858877-18-000007:mdna:93]

[0000858877-18-000015:mdna:95]
[same as prior period, unchanged from 0000858877-18-000007:mdna:94]

[0000858877-18-000015:mdna:96]
[same as prior period, unchanged from 0000858877-18-000007:mdna:95]

[0000858877-18-000015:mdna:97]
[same as prior period, unchanged from 0000858877-18-000007:mdna:110]

[0000858877-18-000015:mdna:98]
[same as prior period, unchanged from 0000858877-18-000007:mdna:111]

[0000858877-18-000015:mdna:99]
|  |  | Three Months Ended |
|  |  | October 27, 2018 |  | October 28, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,712 |  |  | $ | 5,392 |  |  | $ | 320 |  |  | 6 | % |
| Percentage of product revenue |  | 57.8 | % |  | 59.6 | % |  |  |  |  |
| EMEA |  | 2,527 |  |  | 2,239 |  |  | 288 |  |  | 13 | % |
| Percentage of product revenue |  | 25.5 | % |  | 24.7 | % |  |  |  |  |
| APJC |  | 1,652 |  |  | 1,423 |  |  | 229 |  |  | 16 | % |
| Percentage of product revenue |  | 16.7 | % |  | 15.7 | % |  |  |  |  |
| Total |  | $ | 9,890 |  |  | $ | 9,054 |  |  | $ | 836 |  |  | 9 | % |

[0000858877-18-000015:mdna:100]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-18-000015:mdna:101]
Three Months Ended October 27, 2018 Compared with Three Months Ended October 28, 2017

[0000858877-18-000015:mdna:102]
[same as prior period, unchanged from 0000858877-18-000007:mdna:113]

[0000858877-18-000015:mdna:103]
Product revenue in the Americas segment increased by 6%, led by solid growth in the enterprise market and, to a lesser extent, in the commercial, service provider and public sector markets. From a country perspective, product revenue increased by 7% in United States, 22% in Canada, 64% in Mexico and 1% in Brazil.

[0000858877-18-000015:mdna:104]
[same as prior period, unchanged from 0000858877-18-000007:mdna:118]

[0000858877-18-000015:mdna:105]
Product revenue in the EMEA segment increased by 13%, with solid growth in the enterprise, service provider and public sector markets. Product revenue in the commercial market in this geographic segment was flat. Product revenue from emerging countries within EMEA increased by 9% and product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, increased by 14%.

[0000858877-18-000015:mdna:106]
[same as prior period, unchanged from 0000858877-18-000007:mdna:125]

[0000858877-18-000015:mdna:107]
Product revenue in the APJC segment increased by 16%, with solid growth across each of the customer markets in this geographic segment. From a country perspective, product revenue increased by 55% in India and 8% in Japan while product revenue in China was flat.

[0000858877-18-000015:mdna:108]
[same as prior period, unchanged from 0000858877-18-000007:mdna:107]

[0000858877-18-000015:mdna:109]
[same as prior period, unchanged from 0000858877-18-000007:mdna:108]

[0000858877-18-000015:mdna:110]
[same as prior period, unchanged from 0000858877-18-000007:mdna:109]

[0000858877-18-000015:mdna:111]
[same as prior period, unchanged from 0000858877-18-000007:mdna:130]

[0000858877-18-000015:mdna:112]
In addition to the primary view on a geographic basis, we also prepare financial information related to groups of similar products and customer markets for various purposes. We report our product revenue in the following categories: Infrastructure Platforms, Applications, Security, and Other Products. This aligns our product categories with our evolving business model. Prior period amounts have been reclassified to conform to the current period’s presentation.

[0000858877-18-000015:mdna:113]
[same as prior period, unchanged from 0000858877-18-000007:mdna:132]

[0000858877-18-000015:mdna:114]
|  |  | Three Months Ended |
|  |  | October 27, 2018 |  | October 28, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,642 |  |  | $ | 6,980 |  |  | $ | 662 |  |  | 9 | % |
| Applications |  | 1,419 |  |  | 1,203 |  |  | 216 |  |  | 18 | % |
| Security |  | 651 |  |  | 585 |  |  | 66 |  |  | 11 | % |
| Other Products |  | 178 |  |  | 286 |  |  | (108 | ) |  | (38 | )% |
| Total |  | $ | 9,890 |  |  | $ | 9,054 |  |  | $ | 836 |  |  | 9 | % |

[0000858877-18-000015:mdna:115]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-18-000015:mdna:116]
Three Months Ended October 27, 2018 Compared with Three Months Ended October 28, 2017

[0000858877-18-000015:mdna:117]
[same as prior period, unchanged from 0000858877-18-000007:mdna:134]

[0000858877-18-000015:mdna:118]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center. Infrastructure Platforms revenue increased by 9%, or $662 million, with strength across the portfolio. Switching had solid growth, with solid revenue growth in campus switching driven by an increase in sales of our intent-based networking Catalyst 9000 Series, and with revenue growth in data center switching driven by increased revenue from our Nexus 9000 Series.  Routing returned to growth driven by growth in the service provider market. We experienced double digit revenue growth from wireless products driven by our Wave 2 offerings as well as Meraki. Our revenue from data center increased driven by higher sales of server products and our hyperconverged data center offering, HyperFlex.

[0000858877-18-000015:mdna:119]
[same as prior period, unchanged from 0000858877-18-000007:mdna:142]

[0000858877-18-000015:mdna:120]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as the Internet of Things (IoT) and analytics software offerings from Jasper and AppDynamics, respectively. Revenue in our Applications product category increased by 18%, or $216 million, with growth across all of the business. We had solid revenue growth in unified communications, Telepresence and analytics from AppDynamics.

[0000858877-18-000015:mdna:121]
[same as prior period, unchanged from 0000858877-18-000007:mdna:147]

[0000858877-18-000015:mdna:122]
Revenue in our Security product category increased 11%, or $66 million, driven by higher sales of identity and access, advance threat security and unified threat management products.

[0000858877-18-000015:mdna:123]
[same as prior period, unchanged from 0000858877-18-000007:mdna:152]

[0000858877-18-000015:mdna:124]
The decrease in revenue from our Other Products category was primarily driven by a decrease in revenue from Service Provider Video Software Solutions (“SPVSS”). On May 1, 2018, we announced a definitive agreement to sell the SPVSS business. We closed the sale on October 28, 2018.

[0000858877-18-000015:mdna:125]
[same as prior period, unchanged from 0000858877-18-000007:mdna:123]

[0000858877-18-000015:mdna:126]
[same as prior period, unchanged from 0000858877-18-000007:mdna:124]

[0000858877-18-000015:mdna:127]
[same as prior period, unchanged from 0000858877-18-000007:mdna:157]

[0000858877-18-000015:mdna:128]
[same as prior period, unchanged from 0000858877-18-000007:mdna:158]

[0000858877-18-000015:mdna:129]
|  |  | Three Months Ended |
|  |  | October 27, 2018 |  | October 28, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,040 |  |  | $ | 1,958 |  |  | $ | 82 |  |  | 4 | % |
| Percentage of service revenue |  | 64.1 | % |  | 63.5 | % |  |  |  |  |
| EMEA |  | 697 |  |  | 670 |  |  | 27 |  |  | 4 | % |
| Percentage of service revenue |  | 21.9 | % |  | 21.8 | % |  |  |  |  |
| APJC |  | 445 |  |  | 454 |  |  | (9 | ) |  | (2 | )% |
| Percentage of service revenue |  | 14.0 | % |  | 14.7 | % |  |  |  |  |
| Total |  | $ | 3,182 |  |  | $ | 3,082 |  |  | $ | 100 |  |  | 3 | % |

[0000858877-18-000015:mdna:130]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-18-000015:mdna:131]
Three Months Ended October 27, 2018 Compared with Three Months Ended October 28, 2017

[0000858877-18-000015:mdna:132]
Service revenue increased 3%, driven by an increase in software and solution support offerings. Service revenue increased in the Americas and EMEA segments, partially offset by decreased revenue in our APJC segment.

[0000858877-18-000015:mdna:133]
[same as prior period, unchanged from 0000858877-18-000007:mdna:164]

[0000858877-18-000015:mdna:134]
[same as prior period, unchanged from 0000858877-18-000007:mdna:165]

[0000858877-18-000015:mdna:135]
|  |  | Three Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |
|  |  | October 27, 2018 |  | October 28, 2017 |  | October 27, 2018 |  | October 28, 2017 |
| Gross margin: |  |  |  |  |  |  |  |  |
| Product |  | $ | 6,091 |  |  | $ | 5,439 |  |  | 61.6 | % |  | 60.1 | % |
| Service |  | 2,055 |  |  | 1,988 |  |  | 64.6 | % |  | 64.5 | % |
| Total |  | $ | 8,146 |  |  | $ | 7,427 |  |  | 62.3 | % |  | 61.2 | % |

[0000858877-18-000015:mdna:136]
[same as prior period, unchanged from 0000858877-18-000007:mdna:140]

[0000858877-18-000015:mdna:137]
[same as prior period, unchanged from 0000858877-18-000007:mdna:141]

[0000858877-18-000015:mdna:138]
[same as prior period, unchanged from 0000858877-18-000007:mdna:170]

[0000858877-18-000015:mdna:139]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the first quarter of fiscal 2019 as compared with the corresponding prior year period:

[0000858877-18-000015:mdna:140]
|  |  | Product Gross Margin Percentage |
| Fiscal 2018 |  | 60.1 | % |
| Product pricing |  | (1.9 | )% |
| Mix of products sold |  | 0.3 | % |
| Productivity (1) |  | 1.7 | % |
| Legal and indemnification settlements |  | 1.4 | % |
| Amortization of purchased intangible assets |  | 0.2 | % |
| Other |  | (0.2 | )% |
| Fiscal 2019 |  | 61.6 | % |

[0000858877-18-000015:mdna:141]
[same as prior period, unchanged from 0000858877-18-000007:mdna:173]

[0000858877-18-000015:mdna:142]
Three Months Ended October 27, 2018 Compared with Three Months Ended October 28, 2017

[0000858877-18-000015:mdna:143]
Product gross margin increased by 1.5 percentage points driven by productivity improvements and favorable product mix, partially offset by unfavorable impacts from product pricing.  A charge of $122 million to product cost of sales recorded in the first quarter of fiscal 2018 related to legal and indemnification settlements also contributed to the increase.

[0000858877-18-000015:mdna:144]
Productivity improvements were driven by cost reductions including value engineering efforts (e.g. component redesign, board configuration, test processes, and transformation processes) and continued operational efficiency in manufacturing operations. The increase in product gross margin was also due to a favorable mix of products sold, driven by favorability from the decrease in revenue from SPVSS products. The negative pricing impact, which was lower than the year-over-year impact we experienced in the first quarter of fiscal 2018, was driven by typical market factors and impacted each of our geographic segments and customer markets.

[0000858877-18-000015:mdna:145]
[same as prior period, unchanged from 0000858877-18-000007:mdna:183]

[0000858877-18-000015:mdna:146]
Three Months Ended October 27, 2018 Compared with Three Months Ended October 28, 2017

[0000858877-18-000015:mdna:147]
Our service gross margin percentage increased by 0.1 percentage points due to higher sales volume, partially offset by unfavorable mix and, to a lesser extent, increased headcount-related costs. The mix impacts were due to our lower gross margin advanced services offerings contributing a higher proportion of service revenue for the first quarter of fiscal 2019 compared to the first quarter of fiscal 2018.

[0000858877-18-000015:mdna:148]
[same as prior period, unchanged from 0000858877-18-000007:mdna:186]

[0000858877-18-000015:mdna:149]
60

[0000858877-18-000015:mdna:150]
[same as prior period, unchanged from 0000858877-18-000007:mdna:155]

[0000858877-18-000015:mdna:151]
[same as prior period, unchanged from 0000858877-18-000007:mdna:156]

[0000858877-18-000015:mdna:152]
[same as prior period, unchanged from 0000858877-18-000007:mdna:189]

[0000858877-18-000015:mdna:153]
[same as prior period, unchanged from 0000858877-18-000007:mdna:190]

[0000858877-18-000015:mdna:154]
|  | Three Months Ended |
|  | AMOUNT |  | PERCENTAGE |
|  | October 27, 2018 |  | October 28, 2017 |  | October 27, 2018 |  | October 28, 2017 |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 5,070 |  |  | $ | 4,722 |  |  | 65.4 | % |  | 64.2 | % |
| EMEA | 2,070 |  |  | 1,839 |  |  | 64.2 | % |  | 63.2 | % |
| APJC | 1,200 |  |  | 1,165 |  |  | 57.2 | % |  | 62.1 | % |
| Segment total | 8,341 |  |  | 7,726 |  |  | 63.8 | % |  | 63.7 | % |
| Unallocated corporate items (1) | (195 | ) |  | (299 | ) |  |  |  |  |
| Total | $ | 8,146 |  |  | $ | 7,427 |  |  | 62.3 | % |  | 61.2 | % |

[0000858877-18-000015:mdna:155]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-18-000015:mdna:156]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-18-000015:mdna:157]
Three Months Ended October 27, 2018 Compared with Three Months Ended October 28, 2017

[0000858877-18-000015:mdna:158]
We experienced a gross margin percentage increase in our Americas segment due to productivity improvements, partially offset by unfavorable impacts from pricing.

[0000858877-18-000015:mdna:159]
The gross margin percentage increase in our EMEA segment was due primarily to productivity improvements, partially offset by negative impacts from pricing.

[0000858877-18-000015:mdna:160]
The APJC segment gross margin percentage decreased due primarily to negative impacts from pricing and mix.

[0000858877-18-000015:mdna:161]
The gross margin percentage for a particular segment may fluctuate, and period-to-period changes in such percentages may or may not be indicative of a trend for that segment.

[0000858877-18-000015:mdna:162]
[same as prior period, unchanged from 0000858877-18-000007:mdna:167]

[0000858877-18-000015:mdna:163]
[same as prior period, unchanged from 0000858877-18-000007:mdna:168]

[0000858877-18-000015:mdna:164]
[same as prior period, unchanged from 0000858877-18-000007:mdna:169]

[0000858877-18-000015:mdna:165]
[same as prior period, unchanged from 0000858877-18-000007:mdna:203]

[0000858877-18-000015:mdna:166]
[same as prior period, unchanged from 0000858877-18-000007:mdna:204]

[0000858877-18-000015:mdna:167]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,608 |  |  | $ | 1,567 |  |  | $ | 41 |  |  | 3 | % |
| Percentage of revenue | 12.3 | % |  | 12.9 | % |  |  |  |  |
| Sales and marketing | 2,410 |  |  | 2,334 |  |  | 76 |  |  | 3 | % |
| Percentage of revenue | 18.4 | % |  | 19.2 | % |  |  |  |  |
| General and administrative | 211 |  |  | 557 |  |  | (346 | ) |  | (62 | )% |
| Percentage of revenue | 1.6 | % |  | 4.6 | % |  |  |  |  |
| Total | $ | 4,229 |  |  | $ | 4,458 |  |  | $ | (229 | ) |  | (5 | )% |
| Percentage of revenue | 32.4 | % |  | 36.7 | % |  |  |  |  |

[0000858877-18-000015:mdna:168]
Three Months Ended October 27, 2018 Compared with Three Months Ended October 28, 2017

[0000858877-18-000015:mdna:169]
[same as prior period, unchanged from 0000858877-18-000007:mdna:206]

[0000858877-18-000015:mdna:170]
R&D expenses increased primarily due to increases in headcount-related expenses, discretionary spending and contracted services.

[0000858877-18-000015:mdna:171]
[same as prior period, unchanged from 0000858877-18-000007:mdna:209]

[0000858877-18-000015:mdna:172]
[same as prior period, unchanged from 0000858877-18-000007:mdna:210]

[0000858877-18-000015:mdna:173]
Sales and marketing expenses increased due to higher discretionary spending, higher headcount-related expenses and, to a lesser extent, higher acquisition-related costs.

[0000858877-18-000015:mdna:174]
[same as prior period, unchanged from 0000858877-18-000007:mdna:213]

[0000858877-18-000015:mdna:175]
G&A expenses decreased due to a benefit from the $400 million litigation settlement with Arista, partially offset by higher acquisition-related/divestiture costs and higher discretionary spending.

[0000858877-18-000015:mdna:176]
[same as prior period, unchanged from 0000858877-18-000007:mdna:218]

[0000858877-18-000015:mdna:177]
In the first quarter of fiscal 2019, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $50 million, or 1.1%, compared with the first quarter of fiscal 2018.

[0000858877-18-000015:mdna:178]
[same as prior period, unchanged from 0000858877-18-000007:mdna:180]

[0000858877-18-000015:mdna:179]
[same as prior period, unchanged from 0000858877-18-000007:mdna:181]

[0000858877-18-000015:mdna:180]
[same as prior period, unchanged from 0000858877-18-000007:mdna:182]

[0000858877-18-000015:mdna:181]
[same as prior period, unchanged from 0000858877-18-000007:mdna:221]

[0000858877-18-000015:mdna:182]
[same as prior period, unchanged from 0000858877-18-000007:mdna:222]

[0000858877-18-000015:mdna:183]
|  |  | Three Months Ended |
|  |  | October 27, 2018 |  | October 28, 2017 |
| Cost of sales—product |  | $ | 23 |  |  | $ | 23 |  |
| Cost of sales—service |  | 33 |  |  | 34 |  |
| Share-based compensation expense in cost of sales |  | 56 |  |  | 57 |  |
| Research and development |  | 130 |  |  | 136 |  |
| Sales and marketing |  | 137 |  |  | 135 |  |
| General and administrative |  | 62 |  |  | 64 |  |
| Restructuring and other charges |  | 23 |  |  | 6 |  |
| Share-based compensation expense in operating expenses |  | 352 |  |  | 341 |  |
| Total share-based compensation expense |  | $ | 408 |  |  | $ | 398 |  |

[0000858877-18-000015:mdna:184]
Three Months Ended October 27, 2018 Compared with Three Months Ended October 28, 2017

[0000858877-18-000015:mdna:185]
The increase in share-based compensation expense was due primarily to higher restructuring charges.

[0000858877-18-000015:mdna:186]
[same as prior period, unchanged from 0000858877-18-000007:mdna:225]

[0000858877-18-000015:mdna:187]
The following table presents the amortization of purchased intangible assets including impairment charges (in millions):

[0000858877-18-000015:mdna:188]
|  |  | Three Months Ended |
|  |  | October 27, 2018 |  | October 28, 2017 |
| Amortization of purchased intangible assets: |  |  |  |  |
| Cost of sales |  | $ | 151 |  |  | $ | 154 |  |
| Operating expenses |  | 34 |  |  | 61 |  |
| Total |  | $ | 185 |  |  | $ | 215 |  |

[0000858877-18-000015:mdna:189]
Three Months Ended October 27, 2018 Compared with Three Months Ended October 28, 2017

[0000858877-18-000015:mdna:190]
Amortization of purchased intangible assets decreased due to SPVSS purchased intangibles which were held for sale, partially offset by amortization from our recent acquisitions.

[0000858877-18-000015:mdna:191]
[same as prior period, unchanged from 0000858877-18-000007:mdna:232]

[0000858877-18-000015:mdna:192]
We initiated a restructuring plan during fiscal 2018 in order to realign our organization and enable further investment in key priority areas, with estimated pretax charges of approximately $300 million. In the first quarter of fiscal 2019, we expanded the restructuring plan to include an additional $300 million of estimated additional pretax charges. In connection with this restructuring plan, we incurred charges of $78 million during the first quarter of fiscal 2019 and have incurred cumulative charges of $186 million since inception. We expect this restructuring plan to be substantially completed in fiscal 2019.

[0000858877-18-000015:mdna:193]
We incurred restructuring and other charges of $152 million during the first quarter of fiscal 2018 in connection with the restructuring plan announced in August 2016.

[0000858877-18-000015:mdna:194]
These charges were primarily cash-based and consisted of employee severance and other one-time termination benefits, and other associated costs. We expect to reinvest substantially all of the cost savings from these restructuring actions in our key priority areas.  As a result, the overall cost savings from these restructuring actions are not expected to be material for future periods.

[0000858877-18-000015:mdna:195]
[same as prior period, unchanged from 0000858877-18-000007:mdna:197]

[0000858877-18-000015:mdna:196]
[same as prior period, unchanged from 0000858877-18-000007:mdna:198]

[0000858877-18-000015:mdna:197]
[same as prior period, unchanged from 0000858877-18-000007:mdna:236]

[0000858877-18-000015:mdna:198]
[same as prior period, unchanged from 0000858877-18-000007:mdna:237]

[0000858877-18-000015:mdna:199]
|  |  | Three Months Ended |
|  |  | October 27, 2018 |  | October 28, 2017 |
| Operating income |  | $ | 3,805 |  |  | $ | 2,756 |  |
| Operating income as a percentage of revenue |  | 29.1 | % |  | 22.7 | % |

[0000858877-18-000015:mdna:200]
Three Months Ended October 27, 2018 Compared with Three Months Ended October 28, 2017

[0000858877-18-000015:mdna:201]
Operating income increased by 38% and as a percentage of revenue operating income increased by 6.4 percentage points. These increases resulted primarily from: a revenue increase, a gross margin percentage increase (driven primarily by productivity improvements and a charge of $122 million to product cost of sales recorded in the first quarter of fiscal 2018 related to legal and indemnification settlements), a benefit from the $400 million litigation settlement with Arista and lower restructuring and other charges.

[0000858877-18-000015:mdna:202]
[same as prior period, unchanged from 0000858877-18-000007:mdna:241]

[0000858877-18-000015:mdna:203]
[same as prior period, unchanged from 0000858877-18-000007:mdna:242]

[0000858877-18-000015:mdna:204]
|  |  | Three Months Ended |
|  |  | October 27, 2018 |  | October 28, 2017 |  | Variancein Dollars |
| Interest income |  | $ | 344 |  |  | $ | 379 |  |  | $ | (35 | ) |
| Interest expense |  | (221 | ) |  | (235 | ) |  | 14 |  |
| Interest income (expense), net |  | $ | 123 |  |  | $ | 144 |  |  | $ | (21 | ) |

[0000858877-18-000015:mdna:205]
Three Months Ended October 27, 2018 Compared with Three Months Ended October 28, 2017

[0000858877-18-000015:mdna:206]
Interest income decreased, driven by a decrease in the average balance of available-or-sale debt investments. The decrease in interest expense was driven by a lower average debt balance, partially offset by the impact of higher effective interest rates.

[0000858877-18-000015:mdna:207]
[same as prior period, unchanged from 0000858877-18-000007:mdna:247]

[0000858877-18-000015:mdna:208]
|  |  | Three Months Ended |
|  |  | October 27, 2018 |  | October 28, 2017 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | (6 | ) |  | $ | 4 |  |  | $ | (10 | ) |
| Marketable equity investments |  | (4 | ) |  | 29 |  |  | (33 | ) |
| Non-marketable equity and other investments |  | 4 |  |  | 35 |  |  | (31 | ) |
| Net gains (losses) on investments |  | (6 | ) |  | 68 |  |  | (74 | ) |
| Other gains (losses), net |  | (13 | ) |  | (6 | ) |  | (7 | ) |
| Other income (loss), net |  | $ | (19 | ) |  | $ | 62 |  |  | $ | (81 | ) |

[0000858877-18-000015:mdna:209]
Three Months Ended October 27, 2018 Compared with Three Months Ended October 28, 2017

[0000858877-18-000015:mdna:210]
The total change in net gains (losses) on available-for-sale debt investments and marketable equity investments was primarily attributable to higher realized losses as a result of market conditions, and the timing of sales of these investments.

[0000858877-18-000015:mdna:211]
The change in net gains (losses) on non-marketable equity and other investments was primarily due to lower realized gains, partially offset by higher unrealized gains and lower impairment charges.

[0000858877-18-000015:mdna:212]
The change in other gains (losses), net was primarily driven by lower gains from customer lease terminations.

[0000858877-18-000015:mdna:213]
64

[0000858877-18-000015:mdna:214]
[same as prior period, unchanged from 0000858877-18-000007:mdna:215]

[0000858877-18-000015:mdna:215]
[same as prior period, unchanged from 0000858877-18-000007:mdna:216]

[0000858877-18-000015:mdna:216]
[same as prior period, unchanged from 0000858877-18-000007:mdna:260]

[0000858877-18-000015:mdna:217]
The provision for income taxes resulted in an effective tax rate of 9.2% for the first quarter of fiscal 2019 compared with 19.2% for the first quarter of fiscal 2018, a net 10.0 percentage point decrease for the first quarter of fiscal 2019 as compared with the first quarter of fiscal 2018.  The decrease in the effective tax rate was primarily due to a decrease of the U.S. federal tax rate from 35% in the first quarter of fiscal 2018 to 21% in the first quarter of fiscal 2019 as the result of enactment of Tax Act and the recognition of a $152 million tax benefit relating to indirect effects from the adoption of ASC 606 at the beginning of our first quarter of fiscal 2019.

[0000858877-18-000015:mdna:218]
Our effective tax rate will increase or decrease based upon the tax effect of the difference between the share-based compensation expenses and the benefits taken on the company's tax returns. We recognize excess tax benefits on a discrete basis and therefore anticipate the effective tax rate to vary from quarter to quarter depending on our share price in each period.

[0000858877-18-000015:mdna:219]
[same as prior period, unchanged from 0000858877-18-000007:mdna:271]

[0000858877-18-000015:mdna:220]
[same as prior period, unchanged from 0000858877-18-000007:mdna:272]

[0000858877-18-000015:mdna:221]
[same as prior period, unchanged from 0000858877-18-000007:mdna:273]

[0000858877-18-000015:mdna:222]
[same as prior period, unchanged from 0000858877-18-000007:mdna:274]

[0000858877-18-000015:mdna:223]
|  | October 27, 2018 |  | July 28, 2018 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 8,410 |  |  | $ | 8,934 |  |  | $ | (524 | ) |
| Available-for-sale debt investments | 34,183 |  |  | 37,009 |  |  | (2,826 | ) |
| Marketable equity securities | — |  |  | 605 |  |  | (605 | ) |
| Total | $ | 42,593 |  |  | $ | 46,548 |  |  | $ | (3,955 | ) |

[0000858877-18-000015:mdna:224]
The decrease in cash and cash equivalents and investments in the first quarter of fiscal 2019 was primarily driven by cash returned to shareholders in the form of repurchases of common stock of $5.1 billion under the stock repurchase program and cash dividends of $1.5 billion; net cash paid for acquisitions of $2.0 billion; and capital expenditures of $0.2 billion. These uses of cash were partially offset by cash provided by operating activities of $3.8 billion and timing of settlements of investments and other of $1.4 billion.

[0000858877-18-000015:mdna:225]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our available-for-sale debt investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-18-000015:mdna:226]
[same as prior period, unchanged from 0000858877-18-000007:mdna:283]

[0000858877-18-000015:mdna:227]
[same as prior period, unchanged from 0000858877-18-000007:mdna:284]

[0000858877-18-000015:mdna:228]
|  | Three Months Ended |
|  | October 27, 2018 |  | October 28, 2017 |
| Net cash provided by operating activities | $ | 3,763 |  |  | $ | 3,080 |  |
| Acquisition of property and equipment | (212 | ) |  | (168 | ) |
| Free cash flow | $ | 3,551 |  |  | $ | 2,912 |  |

[0000858877-18-000015:mdna:229]
[same as prior period, unchanged from 0000858877-18-000007:mdna:230]

[0000858877-18-000015:mdna:230]
[same as prior period, unchanged from 0000858877-18-000007:mdna:231]

[0000858877-18-000015:mdna:231]
[same as prior period, unchanged from 0000858877-18-000007:mdna:286]

[0000858877-18-000015:mdna:232]
[same as prior period, unchanged from 0000858877-18-000007:mdna:287]

[0000858877-18-000015:mdna:233]
[same as prior period, unchanged from 0000858877-18-000007:mdna:288]

[0000858877-18-000015:mdna:234]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2019 |  |  |  |  |  |  |  |  |  |  |  |  |
| October 27, 2018 |  | $ | 0.33 |  |  | $ | 1,500 |  |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |  | $ | 6,526 |  |
| Fiscal 2018 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 28, 2018 |  | $ | 0.33 |  |  | $ | 1,535 |  |  | 138 |  |  | $ | 43.58 |  |  | $ | 6,015 |  |  | $ | 7,550 |  |
| April 28, 2018 |  | $ | 0.33 |  |  | $ | 1,572 |  |  | 140 |  |  | $ | 42.83 |  |  | $ | 6,015 |  |  | $ | 7,587 |  |
| January 27, 2018 |  | $ | 0.29 |  |  | $ | 1,425 |  |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |  | $ | 5,436 |  |
| October 28, 2017 |  | $ | 0.29 |  |  | $ | 1,436 |  |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |  | $ | 3,056 |  |

[0000858877-18-000015:mdna:235]
[same as prior period, unchanged from 0000858877-18-000007:mdna:290]

[0000858877-18-000015:mdna:236]
On February 14, 2018, our Board of Directors authorized a $25 billion increase to the stock repurchase program. The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $14.0 billion, with no termination date.  We expect to utilize this remaining authorized amount for stock repurchases over the next 9 to 15 months.

[0000858877-18-000015:mdna:237]
The purchase price for the shares of our stock repurchased is reflected as a reduction to shareholders’ equity. We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings and (ii) a reduction of common stock and additional paid-in capital. As a result of future stock repurchases, we may report an accumulated deficit in future periods in shareholders’ equity.

[0000858877-18-000015:mdna:238]
[same as prior period, unchanged from 0000858877-18-000007:mdna:295]

[0000858877-18-000015:mdna:239]
|  | October 27, 2018 |  | July 28, 2018 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,536 |  |  | $ | 5,554 |  |  | $ | (1,018 | ) |

[0000858877-18-000015:mdna:240]
Our accounts receivable net, as of October 27, 2018 decreased by approximately 18%, as compared with the end of fiscal 2018, primarily due to the amount and timing of service billings, and also due to product billings being more linear in the first quarter of fiscal 2019 compared with the fourth quarter of fiscal 2018.

[0000858877-18-000015:mdna:241]
66

[0000858877-18-000015:mdna:242]
[same as prior period, unchanged from 0000858877-18-000007:mdna:245]

[0000858877-18-000015:mdna:243]
[same as prior period, unchanged from 0000858877-18-000007:mdna:246]

[0000858877-18-000015:mdna:244]
[same as prior period, unchanged from 0000858877-18-000007:mdna:298]

[0000858877-18-000015:mdna:245]
|  | October 27, 2018 |  | July 28, 2018 |  | Increase (Decrease) |
| Inventories | $ | 1,572 |  |  | $ | 1,846 |  |  | $ | (274 | ) |

[0000858877-18-000015:mdna:246]
Inventory as of October 27, 2018 decreased by 15% from our inventory balance at the end of fiscal 2018. The decrease in inventory was due primarily to lower deferred cost of sales related to the adoption of ASC 606 in the beginning of our first quarter of fiscal 2019.

[0000858877-18-000015:mdna:247]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity.

[0000858877-18-000015:mdna:248]
Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.  The following table summarizes our purchase commitments with contract manufacturers and suppliers as of the respective period ends (in millions):

[0000858877-18-000015:mdna:249]
| Commitments by Period | October 27, 2018 |  | July 28, 2018 |
| Less than 1 year | $ | 5,500 |  |  | $ | 5,407 |  |
| 1 to 3 years | 704 |  |  | 710 |  |
| 3 to 5 years | 270 |  |  | 360 |  |
| Total | $ | 6,474 |  |  | $ | 6,477 |  |

[0000858877-18-000015:mdna:250]
Purchase commitments with contract manufacturers and suppliers was flat compared to the end of fiscal 2018.  On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers decreased by 3% compared with the end of fiscal 2018.

[0000858877-18-000015:mdna:251]
[same as prior period, unchanged from 0000858877-18-000007:mdna:306]

[0000858877-18-000015:mdna:252]
[same as prior period, unchanged from 0000858877-18-000007:mdna:309]

[0000858877-18-000015:mdna:253]
|  | October 27, 2018 |  | July 28, 2018 |  | Increase (Decrease) |
| Lease receivables, net | $ | 2,399 |  |  | $ | 2,576 |  |  | $ | (177 | ) |
| Loan receivables, net | 4,864 |  |  | 4,939 |  |  | (75 | ) |
| Financed service contracts, net | 2,232 |  |  | 2,316 |  |  | (84 | ) |
| Total, net | $ | 9,495 |  |  | $ | 9,831 |  |  | $ | (336 | ) |

[0000858877-18-000015:mdna:254]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type and direct-financing leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services.  The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed.  Financing receivables decreased by 3%. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-18-000015:mdna:255]
[same as prior period, unchanged from 0000858877-18-000007:mdna:258]

[0000858877-18-000015:mdna:256]
[same as prior period, unchanged from 0000858877-18-000007:mdna:259]

[0000858877-18-000015:mdna:257]
[same as prior period, unchanged from 0000858877-18-000007:mdna:312]

[0000858877-18-000015:mdna:258]
The volume of channel partner financing was $7.2 billion and $6.7 billion for the first quarter of fiscal 2019 and 2018, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $931 million and $953 million as of October 27, 2018 and July 28, 2018, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of October 27, 2018, the total maximum potential future payments related to these guarantees was approximately $335 million, of which approximately $98 million was recorded as deferred revenue.

[0000858877-18-000015:mdna:259]
[same as prior period, unchanged from 0000858877-18-000007:mdna:316]

[0000858877-18-000015:mdna:260]
[same as prior period, unchanged from 0000858877-18-000007:mdna:317]

[0000858877-18-000015:mdna:261]
|  | Maturity Date |  | October 27, 2018 |  | July 28, 2018 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | $ | 500 |  |  | $ | 500 |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1,000 |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1,500 |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 25,750 |  |  | $ | 25,750 |  |

[0000858877-18-000015:mdna:262]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of October 27, 2018.

[0000858877-18-000015:mdna:263]
[same as prior period, unchanged from 0000858877-18-000007:mdna:268]

[0000858877-18-000015:mdna:264]
[same as prior period, unchanged from 0000858877-18-000007:mdna:269]

[0000858877-18-000015:mdna:265]
[same as prior period, unchanged from 0000858877-18-000007:mdna:270]

[0000858877-18-000015:mdna:266]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.  We had no commercial paper notes outstanding as of October 27, 2018 and July 28, 2018.

[0000858877-18-000015:mdna:267]
Credit Facility On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.  As of October 27, 2018, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-18-000015:mdna:268]
[same as prior period, unchanged from 0000858877-18-000007:mdna:326]

[0000858877-18-000015:mdna:269]
|  | October 27, 2018 |  | July 28, 2018 |  | Increase (Decrease) |
| Service | $ | 11,062 |  |  | $ | 11,431 |  |  | $ | (369 | ) |
| Product | 5,752 |  |  | 8,254 |  |  | (2,502 | ) |
| Total | $ | 16,814 |  |  | $ | 19,685 |  |  | $ | (2,871 | ) |
| Reported as: |  |  |  |  |  |
| Current | $ | 9,637 |  |  | $ | 11,490 |  |  | $ | (1,853 | ) |
| Noncurrent | 7,177 |  |  | 8,195 |  |  | (1,018 | ) |
| Total | $ | 16,814 |  |  | $ | 19,685 |  |  | $ | (2,871 | ) |

[0000858877-18-000015:mdna:270]
Deferred revenue decreased primarily due to the adoption of ASC 606 in the beginning of our first quarter of fiscal 2019. Of the total deferred revenue decrease related to ASC 606 of $2.8 billion, $2.6 billion relates to deferred product revenue and $0.2 billion relates to deferred service revenue. Of the adjustment to deferred product revenue, $1.3 billion relates to our recurring software and subscription offers, $0.6 billion relates to two-tier distribution, and the remainder relates to non-recurring software and other adjustments.

[0000858877-18-000015:mdna:271]
[same as prior period, unchanged from 0000858877-18-000007:mdna:329]

[0000858877-18-000015:mdna:272]
[same as prior period, unchanged from 0000858877-18-000007:mdna:330]

[0000858877-18-000015:mdna:273]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, Germany, India, Israel, Japan, Mexico, Poland and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of October 27, 2018 were $1.2 billion.

[0000858877-18-000015:mdna:274]
Transition Tax Payable

[0000858877-18-000015:mdna:275]
In connection with the Tax Act, we recorded an income tax payable of $8.1 billion for the U.S. transition tax on accumulated earnings of foreign subsidiaries. Amounts associated with the Tax Act are considered provisional and may be subject to further adjustment during the measurement period. We plan to pay the transition tax in installments over eight years in accordance with the Tax Act. Approximately $0.8 billion is payable in less than one year; $1.3 billion is payable between 1 to 3 years; another $1.3 billion is payable between 3 to 5 years; and the remaining $4.7 billion is payable in more than 5 years. See Note 17 to the Consolidated Financial Statements.

[0000858877-18-000015:mdna:276]
[same as prior period, unchanged from 0000858877-18-000007:mdna:281]

[0000858877-18-000015:mdna:277]
[same as prior period, unchanged from 0000858877-18-000007:mdna:282]

[0000858877-18-000015:mdna:278]
[same as prior period, unchanged from 0000858877-18-000007:mdna:332]

[0000858877-18-000015:mdna:279]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or the continued employment with us of certain employees of the acquired entities. See Note 13 to the Consolidated Financial Statements.

[0000858877-18-000015:mdna:280]
Other Funding Commitments  We also have certain funding commitments primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $378 million as of October 27, 2018, compared with $223 million as of July 28, 2018.

[0000858877-18-000015:mdna:281]
[same as prior period, unchanged from 0000858877-18-000007:mdna:335]

[0000858877-18-000015:mdna:282]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have non-marketable equity and other investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our non-marketable equity and other investments and customer financings, and we have determined that as of October 27, 2018 there were no material unconsolidated variable interest entities.

[0000858877-18-000015:mdna:283]
On an ongoing basis, we reassess our non-marketable equity and other investments and customer financings to determine if they are variable interest entities and if we would be regarded as the primary beneficiary pursuant to the applicable accounting guidance. As a result of this ongoing assessment, we may be required to make additional disclosures or consolidate these entities. Because we may not control these entities, we may not have the ability to influence these events.

[0000858877-18-000015:mdna:284]
[same as prior period, unchanged from 0000858877-18-000007:mdna:341]

[0000858877-18-000015:mdna:285]
[same as prior period, unchanged from 0000858877-18-000007:mdna:344]

[0000858877-18-000015:mdna:286]
[same as prior period, unchanged from 0000858877-18-000007:mdna:345]
