# CSCO 8-K — 0001193125-23-277891 filed 2023-11-15

## item codes, every 8-K on or before 2023-11-21

- 2023-11-15 0001193125-23-277891 — 2.02, 9.01
- 2023-10-10 0000858877-23-000025 — 5.02
- 2023-09-25 0001193125-23-240975 — 7.01
- 2023-09-21 0001193125-23-239165 — 1.01, 7.01, 8.01, 9.01
- 2023-08-16 0001193125-23-214316 — 2.02, 9.01
- 2023-07-19 0000858877-23-000016 — 5.02
- 2023-05-17 0001193125-23-147021 — 2.02, 9.01
- 2023-03-10 0000858877-23-000009 — 5.03, 9.01
- 2023-02-21 0000858877-23-000006 — 5.02
- 2023-02-15 0001193125-23-040212 — 2.02, 9.01
- 2022-12-16 0000858877-22-000029 — 8.01
- 2022-12-09 0000858877-22-000027 — 5.07
- 2022-11-16 0001628280-22-030151 — 5.02
- 2022-11-16 0001193125-22-286782 — 2.02, 2.05, 9.01
- 2022-10-04 0000858877-22-000018 — 1.01, 1.02, 9.01
- 2022-09-15 0000858877-22-000015 — 8.01
- 2022-08-24 0001193125-22-228572 — 5.02
- 2022-08-17 0001193125-22-223250 — 2.02, 9.01
- 2022-06-17 0001193125-22-176552 — 8.01
- 2022-05-18 0001193125-22-154039 — 2.02, 9.01
- 2022-03-28 0001193125-22-086807 — 8.01
- 2022-02-16 0001193125-22-044372 — 2.02, 9.01
- 2022-02-11 0001193125-22-037227 — 5.02
- 2022-01-31 0001193125-22-023458 — 5.02
- 2021-12-17 0001193125-21-361182 — 8.01
- 2021-12-14 0001193125-21-356837 — 5.07, 8.01
- 2021-11-17 0001193125-21-332467 — 2.02, 9.01
- 2021-09-27 0001193125-21-284199 — 8.01
- 2021-08-18 0001193125-21-250360 — 2.02, 9.01
- 2021-06-29 0001193125-21-203324 — 8.01
- 2021-05-19 0001193125-21-166614 — 2.02, 9.01
- 2021-05-14 0001193125-21-162081 — 1.01, 2.03, 9.01
- 2021-03-08 0001193125-21-073328 — 5.02
- 2021-02-25 0001193125-21-056977 — 5.02
- 2021-02-09 0001193125-21-034339 — 2.02, 9.01
- 2021-01-07 0001193125-21-004250 — 5.02
- 2020-12-17 0001193125-20-320092 — 5.02, 8.01
- 2020-12-11 0001193125-20-315999 — 5.02, 5.07, 9.01
- 2020-11-30 0001193125-20-305352 — 5.02
- 2020-11-13 0001193125-20-293020 — 5.02, 9.01
- 2020-11-12 0001193125-20-291658 — 2.02, 9.01
- 2020-10-09 0001193125-20-267248 — 5.03, 9.01
- 2020-09-23 0001193125-20-252356 — 8.01
- 2020-08-12 0001193125-20-217756 — 5.02
- 2020-08-12 0001193125-20-217658 — 2.02, 2.05, 9.01
- 2020-06-22 0001193125-20-175641 — 8.01
- 2020-05-13 0001193125-20-141598 — 2.02, 9.01
- 2020-03-13 0001193125-20-072960 — 5.02
- 2020-03-06 0001193125-20-065138 — 5.02
- 2020-02-12 0001193125-20-033208 — 2.02, 9.01
- 2020-01-27 0001193125-20-015453 — 5.02
- 2019-12-23 0001193125-19-322662 — 8.01
- 2019-12-12 0001193125-19-312796 — 8.01
- 2019-12-11 0001193125-19-311525 — 5.07
- 2019-12-04 0001193125-19-306229 — 8.01
- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2023-11-21

- none on or before 2023-11-21

## item 2.02 — earnings release, exhibit 99.1

[0001193125-23-277891:8k_2_02:1]
EX-99.1
2
d850595dex991.htm
EX-99.1

[0001193125-23-277891:8k_2_02:2]
EX-99.1

[0001193125-23-277891:8k_2_02:3]
Exhibit 99.1

[0001193125-23-277891:8k_2_02:4]
| Press Contact: |  |  |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  |  |  | Sami Badri |
| Cisco |  |  |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  |  |  | 1 (469) 420-4834 |
| rojenkin@cisco.com |  |  |  |  |  | sambadri@cisco.com |

[0001193125-23-277891:8k_2_02:5]
CISCO REPORTS FIRST QUARTER EARNINGS

[0001193125-23-277891:8k_2_02:6]
News Summary:

[0001193125-23-277891:8k_2_02:7]
|  | • |  | Strongest first quarter results in Cisco’s history in terms of revenue and profitability with $14.7 billion in revenue, up 8% year over year; GAAP EPS $0.89, up 37% year over year, and Non-GAAP EPS $1.11, up 29% year over year |

[0001193125-23-277891:8k_2_02:8]
|  | • |  | Progress on business model transformation in Q1 FY 2024: |

[0001193125-23-277891:8k_2_02:9]
|  | • |  | Total software revenue up 13% year over year and software subscription revenue up 13% year over year |

[0001193125-23-277891:8k_2_02:10]
|  | • |  | Total annualized recurring revenue (ARR) at $24.5 billion, up 5% year over year and product ARR up 10% year over year |

[0001193125-23-277891:8k_2_02:11]
|  | • |  | Remaining performance obligations (RPO) at $34.8 billion, up 12% year over year and product RPO up 14% year over year |

[0001193125-23-277891:8k_2_02:12]
|  | • |  | Strong Q1 revenue across Cisco product portfolio, driven by customers’ investments in Generative AI, Cloud, Security, and Full Stack Observability |

[0001193125-23-277891:8k_2_02:13]
| • |  | Q1 FY 2024 Results: |

[0001193125-23-277891:8k_2_02:14]
|  | • |  | Revenue: $14.7 billion |

[0001193125-23-277891:8k_2_02:15]
|  | • |  | Increase of 8% year over year |

[0001193125-23-277891:8k_2_02:16]
|  | • |  | Earnings per Share: GAAP: $0.89; Non-GAAP: $1.11 |

[0001193125-23-277891:8k_2_02:17]
|  | • |  | GAAP EPS increased 37% year over year |

[0001193125-23-277891:8k_2_02:18]
|  | • |  | Non-GAAP EPS increased 29% year over year |

[0001193125-23-277891:8k_2_02:19]
| • |  | Q2 FY 2024 Guidance: |

[0001193125-23-277891:8k_2_02:20]
|  | • |  | Revenue: $12.6 billion to $12.8 billion |

[0001193125-23-277891:8k_2_02:21]
|  | • |  | Earnings per Share: GAAP: $0.59 to $0.64; Non-GAAP: $0.82 to $0.84 |

[0001193125-23-277891:8k_2_02:22]
| • |  | FY 2024 Guidance: |

[0001193125-23-277891:8k_2_02:23]
|  | • |  | Revenue: $53.8 billion to $55.0 billion |

[0001193125-23-277891:8k_2_02:24]
|  | • |  | Earnings per Share: GAAP: $2.97 to $3.08; Non-GAAP: $3.87 to $3.93 |

[0001193125-23-277891:8k_2_02:25]
SAN JOSE, Calif. — November 15, 2023 — Cisco today reported first quarter results for the period ended October 28,
2023. Cisco reported first quarter revenue of $14.7 billion, net income on a generally accepted accounting principles (GAAP) basis of $3.6 billion or $0.89 per share, and non-GAAP net income of
$4.5 billion or $1.11 per share.

[0001193125-23-277891:8k_2_02:26]
“We had a solid start to fiscal 2024 with the strongest Q1 results in our history on both revenue and
profitability,” said Chuck Robbins, chair and CEO of Cisco. “We are confident in the foundational strength of our business and future growth opportunities fueled by AI, Security, Cloud, and Observability.”

[0001193125-23-277891:8k_2_02:27]
“In Q1, we delivered revenue and EPS at the high end or above our guidance range, generating strong operating leverage,” said Scott Herren, CFO of
Cisco. “We also saw double-digit year-over-year growth in software revenue, product ARR and total RPO. After customers implement large amounts of recently shipped product, we expect to see product order growth rates accelerate in the second
half of the year. We are committed to delivering operating leverage and increasing capital returns to our shareholders.”

[0001193125-23-277891:8k_2_02:28]
1

[0001193125-23-277891:8k_2_02:29]
GAAP Results

[0001193125-23-277891:8k_2_02:30]
|  |  | Q1 FY 2024 |  |  | Q1 FY 2023 |  |  | Vs. Q1 FY 2023 |  |
| Revenue |  | $ | 14.7 billion |  |  | $ | 13.6 billion |  |  |  | 8 | % |
| Net Income |  | $ | 3.6 billion |  |  | $ | 2.7 billion |  |  |  | 36 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.89 |  |  | $ | 0.65 |  |  |  | 37 | % |

[0001193125-23-277891:8k_2_02:31]
Non-GAAP Results

[0001193125-23-277891:8k_2_02:32]
|  |  | Q1 FY 2024 |  |  | Q1 FY 2023 |  |  | Vs. Q1 FY 2023 |  |
| Net Income |  | $ | 4.5 billion |  |  | $ | 3.5 billion |  |  |  | 28 | % |
| EPS |  | $ | 1.11 |  |  | $ | 0.86 |  |  |  | 29 | % |

[0001193125-23-277891:8k_2_02:33]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-23-277891:8k_2_02:34]
Cisco Declares Quarterly Dividend

[0001193125-23-277891:8k_2_02:35]
Cisco has declared a
quarterly dividend of $0.39 per common share to be paid on January 24, 2024, to all stockholders of record as of the close of business on January 4, 2024. Future dividends will be subject to Board approval.

[0001193125-23-277891:8k_2_02:36]
2

[0001193125-23-277891:8k_2_02:37]
Financial Summary

[0001193125-23-277891:8k_2_02:38]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-23-277891:8k_2_02:39]
Q1 FY 2024 Highlights

[0001193125-23-277891:8k_2_02:40]
Revenue — Total
revenue was $14.7 billion, up 8%, with product revenue up 9% and service revenue up 4%. Revenue by geographic segment was: Americas up 14%, EMEA flat, and APJC was down 3%. Product revenue performance reflected growth in Networking up 10%,
Security up 4%, Observability up 21% and Collaboration up 3%.

[0001193125-23-277891:8k_2_02:41]
Gross Margin — On a GAAP basis, total gross margin, product gross
margin, and service gross margin were 65.2%, 64.5%, and 67.3%, respectively, as compared with 61.2%, 59.2%, and 67.3%, respectively, in the first quarter of fiscal 2023.

[0001193125-23-277891:8k_2_02:42]
On a non-GAAP basis, total gross margin, product gross margin, and service gross margin were 67.1%, 66.5%, and 69.0%,
respectively, as compared with 63.0%, 61.0%, and 68.8%, respectively, in the first quarter of fiscal 2023.

[0001193125-23-277891:8k_2_02:43]
Total gross margins by geographic segment
were: 66.2% for the Americas, 69.5% for EMEA and 67.0% for APJC.

[0001193125-23-277891:8k_2_02:44]
Operating Expenses — On a GAAP basis, operating expenses were
$5.3 billion, up 10%, and were 36.0% of revenue. Non-GAAP operating expenses were $4.5 billion, up 5%, and were 30.5% of revenue.

[0001193125-23-277891:8k_2_02:45]
Operating Income — GAAP operating income was $4.3 billion, up 21%, with GAAP operating margin of 29.2%.
Non-GAAP operating income was $5.4 billion, up 24%, with non-GAAP operating margin at 36.6%.

[0001193125-23-277891:8k_2_02:46]
Provision for Income Taxes — The GAAP tax provision rate was 18.1%. The non-GAAP tax provision rate
was 19.0%.

[0001193125-23-277891:8k_2_02:47]
Net Income and EPS — On a GAAP basis, net income was $3.6 billion, an increase of 36%, and EPS was $0.89, an increase
of 37%. On a non-GAAP basis, net income was $4.5 billion, an increase of 28%, and EPS was $1.11, an increase of 29%.

[0001193125-23-277891:8k_2_02:48]
Cash Flow from Operating Activities — $2.4 billion for the first quarter of fiscal 2024, a decrease of 40% compared with
$4.0 billion for the first quarter of fiscal 2023, primarily due to the timing of tax payments.

[0001193125-23-277891:8k_2_02:49]
Balance Sheet and Other Financial Highlights

[0001193125-23-277891:8k_2_02:50]
Cash and Cash Equivalents and Investments — $23.5 billion at the end of the first quarter of fiscal 2024, compared with
$26.1 billion at the end of fiscal 2023.

[0001193125-23-277891:8k_2_02:51]
Remaining Performance Obligations (RPO) — $34.8 billion, up 12% in
total, with 51% of this amount to be recognized as revenue over the next 12 months. Product RPO were up 14% and service RPO were up 11%.

[0001193125-23-277891:8k_2_02:52]
Deferred Revenue — $25.7 billion, up 11% in total, with deferred product revenue up 12%. Deferred service revenue was up 11%.

[0001193125-23-277891:8k_2_02:53]
Capital Allocation — In the first quarter of fiscal 2024, we returned $2.8 billion to stockholders through share buybacks and
dividends. We declared and paid a cash dividend of $0.39 per common share, or $1.6 billion, and repurchased approximately 23 million shares of common stock under our stock repurchase program at an average price of $54.53 per share for an
aggregate purchase price of $1.3 billion. The remaining authorized amount for stock repurchases under the program is $9.7 billion with no termination date.

[0001193125-23-277891:8k_2_02:54]
Acquisitions

[0001193125-23-277891:8k_2_02:55]
In the first quarter of fiscal 2024, our
closed acquisitions include:

[0001193125-23-277891:8k_2_02:56]
|  | • |  | Accedian, a privately held network performance monitoring company |

[0001193125-23-277891:8k_2_02:57]
|  | • |  | Working Group Two, a privately held company that developed a cloud native mobile services platform |

[0001193125-23-277891:8k_2_02:58]
|  | • |  | Oort, Inc., a privately held company focused on identity threat detection and response technology |

[0001193125-23-277891:8k_2_02:59]
|  | • |  | SamKnows, a privately held broadband network monitoring company |

[0001193125-23-277891:8k_2_02:60]
|  | • |  | Code BGP, Inc., a privately held border gateway protocol monitoring company |

[0001193125-23-277891:8k_2_02:61]
Cisco’s Intent to Acquire Splunk

[0001193125-23-277891:8k_2_02:62]
On
September 21, 2023, we announced our intent to acquire Splunk Inc., a public cybersecurity and observability company. The acquisition is expected to close by the end of the third quarter of calendar year 2024, subject to regulatory approval and
other customary closing conditions including approval by Splunk shareholders.

[0001193125-23-277891:8k_2_02:63]
3

[0001193125-23-277891:8k_2_02:64]
Guidance

[0001193125-23-277891:8k_2_02:65]
Cisco saw a slowdown of new product orders in the first quarter of fiscal 2024 and believes the primary reason is that customers are currently focused on
installing and implementing products in their environments following exceptionally strong product delivery over the past three quarters. Cisco estimates there are one to two quarters of shipped product orders still waiting to be implemented by its
customers.

[0001193125-23-277891:8k_2_02:66]
Cisco expects to achieve the following results for the second quarter of fiscal 2024:

[0001193125-23-277891:8k_2_02:67]
| Q2 FY 2024 |  |  |
| Revenue |  | $12.6 billion - $12.8 billion |
| Non-GAAP gross margin rate |  | 65% – 66% |
| Non-GAAP operating margin rate |  | 31.5% – 32.5% |
| Non-GAAP EPS |  | $0.82 – $0.84 |

[0001193125-23-277891:8k_2_02:68]
Cisco estimates that GAAP EPS will be $0.59 to $0.64 for the second quarter of fiscal 2024.

[0001193125-23-277891:8k_2_02:69]
Cisco expects to achieve the following results for fiscal 2024:

[0001193125-23-277891:8k_2_02:70]
| FY 2024 |  |  |
| Revenue |  | $53.8 billion - $55.0 billion |
| Non-GAAP EPS |  | $3.87 – $3.93 |

[0001193125-23-277891:8k_2_02:71]
Cisco estimates that GAAP EPS will be $2.97 to $3.08 for fiscal 2024.

[0001193125-23-277891:8k_2_02:72]
Our Q2 FY 2024 guidance assumes an effective tax provision rate of 17% for GAAP and 19% for non-GAAP results. Our FY
2024 guidance assumes an effective tax provision rate of 18% for GAAP and 19% for non-GAAP results.

[0001193125-23-277891:8k_2_02:73]
A
reconciliation between the Guidance on a GAAP and non-GAAP basis is provided in the tables entitled “GAAP to non-GAAP Guidance” located in the section entitled
“Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-23-277891:8k_2_02:74]
Editor’s Notes:

[0001193125-23-277891:8k_2_02:75]
|  | • |  | Q1 fiscal year 2024 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, November 15, 2023 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-23-277891:8k_2_02:76]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, November 15, 2023 to 4:00 p.m. Pacific Time, November 22, 2023 at 1-800-834-5839 (United States) or 1-203-369-3351 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-23-277891:8k_2_02:77]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, November 15, 2023. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-23-277891:8k_2_02:78]
4

[0001193125-23-277891:8k_2_02:79]
CISCO SYSTEMS, INC.

[0001193125-23-277891:8k_2_02:80]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-23-277891:8k_2_02:81]
(In millions, except per-share amounts)

[0001193125-23-277891:8k_2_02:82]
(Unaudited)

[0001193125-23-277891:8k_2_02:83]
|  |  | Three Months Ended |  |
|  |  | October 28,2023 |  |  | October 29,2022 |  |
| REVENUE: |  |  |  |  |  |  |  |  |
| Product |  | $ | 11,139 |  |  | $ | 10,245 |  |
| Service |  |  | 3,529 |  |  |  | 3,387 |  |
| Total revenue |  |  | 14,668 |  |  |  | 13,632 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |
| Product |  |  | 3,957 |  |  |  | 4,179 |  |
| Service |  |  | 1,154 |  |  |  | 1,107 |  |
| Total cost of sales |  |  | 5,111 |  |  |  | 5,286 |  |
| GROSS MARGIN |  |  | 9,557 |  |  |  | 8,346 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,913 |  |  |  | 1,781 |  |
| Sales and marketing |  |  | 2,506 |  |  |  | 2,391 |  |
| General and administrative |  |  | 672 |  |  |  | 565 |  |
| Amortization of purchased intangible assets |  |  | 67 |  |  |  | 71 |  |
| Restructuring and other charges |  |  | 123 |  |  |  | (2 | ) |
| Total operating expenses |  |  | 5,281 |  |  |  | 4,806 |  |
| OPERATING INCOME |  |  | 4,276 |  |  |  | 3,540 |  |
| Interest income |  |  | 360 |  |  |  | 169 |  |
| Interest expense |  |  | (111 | ) |  |  | (100 | ) |
| Other income (loss), net |  |  | (83 | ) |  |  | (134 | ) |
| Interest and other income (loss), net |  |  | 166 |  |  |  | (65 | ) |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 4,442 |  |  |  | 3,475 |  |
| Provision for income taxes |  |  | 804 |  |  |  | 805 |  |
| NET INCOME |  | $ | 3,638 |  |  | $ | 2,670 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.90 |  |  | $ | 0.65 |  |
| Diluted |  | $ | 0.89 |  |  | $ | 0.65 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,057 |  |  |  | 4,108 |  |
| Diluted |  |  | 4,087 |  |  |  | 4,116 |  |

[0001193125-23-277891:8k_2_02:84]
5

[0001193125-23-277891:8k_2_02:85]
CISCO SYSTEMS, INC.

[0001193125-23-277891:8k_2_02:86]
REVENUE BY SEGMENT

[0001193125-23-277891:8k_2_02:87]
(In
millions, except percentages)

[0001193125-23-277891:8k_2_02:88]
|  |  | Three Months EndedOctober 28, 2023 |  |
|  |  | Amount |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 9,022 |  |  |  | 14 | % |
| EMEA |  |  | 3,664 |  |  |  | — | % |
| APJC |  |  | 1,982 |  |  |  | (3 | )% |
| Total |  | $ | 14,668 |  |  |  | 8 | % |

[0001193125-23-277891:8k_2_02:89]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-23-277891:8k_2_02:90]
CISCO SYSTEMS, INC.

[0001193125-23-277891:8k_2_02:91]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-23-277891:8k_2_02:92]
(In percentages)

[0001193125-23-277891:8k_2_02:93]
|  |  | Three Months EndedOctober 28, 2023 |  |
| Gross Margin Percentage: |  |  |  |  |
| Americas |  |  | 66.2 | % |
| EMEA |  |  | 69.5 | % |
| APJC |  |  | 67.0 | % |

[0001193125-23-277891:8k_2_02:94]
CISCO SYSTEMS, INC.

[0001193125-23-277891:8k_2_02:95]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-23-277891:8k_2_02:96]
(In millions, except percentages)

[0001193125-23-277891:8k_2_02:97]
|  |  | Three Months EndedOctober 28, 2023 |  |
|  |  | Amount |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Networking |  | $ | 8,822 |  |  |  | 10 | % |
| Security |  |  | 1,010 |  |  |  | 4 | % |
| Collaboration |  |  | 1,117 |  |  |  | 3 | % |
| Observability |  |  | 190 |  |  |  | 21 | % |
| Total Product |  |  | 11,139 |  |  |  | 9 | % |
| Services |  |  | 3,529 |  |  |  | 4 | % |
| Total |  | $ | 14,668 |  |  |  | 8 | % |

[0001193125-23-277891:8k_2_02:98]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-23-277891:8k_2_02:99]
Effective for the first quarter of fiscal 2024, we began reporting our revenue in the following categories: Networking, Security, Collaboration, Observability
and Services. The reclassified product category revenue by quarter for fiscal 2021 through fiscal 2023, as well as other information is available on Cisco’s Investor Relations website at
https://investor.cisco.com/investor-relations/financial-information/Financial-Results/default.aspx.

[0001193125-23-277891:8k_2_02:100]
CISCO SYSTEMS, INC.

[0001193125-23-277891:8k_2_02:101]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-23-277891:8k_2_02:102]
(In millions)

[0001193125-23-277891:8k_2_02:103]
(Unaudited)

[0001193125-23-277891:8k_2_02:104]
|  |  | October 28, 2023 |  |  | July 29, 2023 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,602 |  |  | $ | 10,123 |  |
| Investments |  |  | 13,921 |  |  |  | 16,023 |  |
| Accounts receivable, net of allowance of $82 at October 28, 2023 and $85 at July 29, 2023 |  |  | 4,833 |  |  |  | 5,854 |  |
| Inventories |  |  | 3,342 |  |  |  | 3,644 |  |
| Financing receivables, net |  |  | 3,414 |  |  |  | 3,352 |  |
| Other current assets |  |  | 4,547 |  |  |  | 4,352 |  |
| Total current assets |  |  | 39,659 |  |  |  | 43,348 |  |
| Property and equipment, net |  |  | 2,004 |  |  |  | 2,085 |  |
| Financing receivables, net |  |  | 3,324 |  |  |  | 3,483 |  |
| Goodwill |  |  | 38,900 |  |  |  | 38,535 |  |
| Purchased intangible assets, net |  |  | 1,914 |  |  |  | 1,818 |  |
| Deferred tax assets |  |  | 7,102 |  |  |  | 6,576 |  |
| Other assets |  |  | 5,879 |  |  |  | 6,007 |  |
| TOTAL ASSETS |  | $ | 98,782 |  |  | $ | 101,852 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 990 |  |  | $ | 1,733 |  |
| Accounts payable |  |  | 2,084 |  |  |  | 2,313 |  |
| Income taxes payable |  |  | 2,380 |  |  |  | 4,235 |  |
| Accrued compensation |  |  | 3,039 |  |  |  | 3,984 |  |
| Deferred revenue |  |  | 13,812 |  |  |  | 13,908 |  |
| Other current liabilities |  |  | 4,730 |  |  |  | 5,136 |  |
| Total current liabilities |  |  | 27,035 |  |  |  | 31,309 |  |
| Long-term debt |  |  | 6,660 |  |  |  | 6,658 |  |
| Income taxes payable |  |  | 5,790 |  |  |  | 5,756 |  |
| Deferred revenue |  |  | 11,847 |  |  |  | 11,642 |  |
| Other long-term liabilities |  |  | 2,240 |  |  |  | 2,134 |  |
| Total liabilities |  |  | 53,572 |  |  |  | 57,499 |  |
| Total equity |  |  | 45,210 |  |  |  | 44,353 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 98,782 |  |  | $ | 101,852 |  |

[0001193125-23-277891:8k_2_02:105]
7

[0001193125-23-277891:8k_2_02:106]
CISCO SYSTEMS, INC.

[0001193125-23-277891:8k_2_02:107]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-23-277891:8k_2_02:108]
(In millions)

[0001193125-23-277891:8k_2_02:109]
(Unaudited)

[0001193125-23-277891:8k_2_02:110]
|  |  | Three Months Ended |  |
|  |  | October 28,2023 |  |  | October 29,2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,638 |  |  | $ | 2,670 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 401 |  |  |  | 415 |  |
| Share-based compensation expense |  |  | 661 |  |  |  | 496 |  |
| Provision (benefit) for receivables |  |  | 4 |  |  |  | 7 |  |
| Deferred income taxes |  |  | (513 | ) |  |  | (366 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | 89 |  |  |  | 131 |  |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 979 |  |  |  | 1,119 |  |
| Inventories |  |  | 307 |  |  |  | (108 | ) |
| Financing receivables |  |  | 25 |  |  |  | 556 |  |
| Other assets |  |  | (290 | ) |  |  | (316 | ) |
| Accounts payable |  |  | (235 | ) |  |  | 42 |  |
| Income taxes, net |  |  | (1,773 | ) |  |  | 20 |  |
| Accrued compensation |  |  | (908 | ) |  |  | (384 | ) |
| Deferred revenue |  |  | 259 |  |  |  | (78 | ) |
| Other liabilities |  |  | (273 | ) |  |  | (242 | ) |
| Net cash provided by operating activities |  |  | 2,371 |  |  |  | 3,962 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (1,850 | ) |  |  | (1,943 | ) |
| Proceeds from sales of investments |  |  | 1,280 |  |  |  | 407 |  |
| Proceeds from maturities of investments |  |  | 2,497 |  |  |  | 971 |  |
| Acquisitions, net of cash and cash equivalents acquired and divestitures |  |  | (876 | ) |  |  | — |  |
| Purchases of investments in privately held companies |  |  | (13 | ) |  |  | (48 | ) |
| Return of investments in privately held companies |  |  | 47 |  |  |  | 10 |  |
| Acquisition of property and equipment |  |  | (134 | ) |  |  | (176 | ) |
| Other |  |  | 1 |  |  |  | (20 | ) |
| Net cash provided by (used in) provided by investing activities |  |  | 952 |  |  |  | (799 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Repurchases of common stock - repurchase program |  |  | (1,300 | ) |  |  | (556 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (153 | ) |  |  | (108 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | — |  |  |  | (602 | ) |
| Repayments of debt |  |  | (750 | ) |  |  | — |  |
| Dividends paid |  |  | (1,580 | ) |  |  | (1,560 | ) |
| Other |  |  | (17 | ) |  |  | (29 | ) |
| Net cash used in financing activities |  |  | (3,800 | ) |  |  | (2,855 | ) |
| Effect of foreign currency exchange rate changes on cash, cash equivalents, restricted cash and restricted cash equivalents |  |  | (45 | ) |  |  | (95 | ) |
| Net increase (decrease) in cash, cash equivalents, restricted cash and restricted cash equivalents |  |  | (522 | ) |  |  | 213 |  |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, beginning of period |  |  | 11,627 |  |  |  | 8,579 |  |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, end of period |  | $ | 11,105 |  |  | $ | 8,792 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 128 |  |  | $ | 114 |  |
| Cash paid for income taxes, net |  | $ | 3,090 |  |  | $ | 1,150 |  |

[0001193125-23-277891:8k_2_02:111]
8

[0001193125-23-277891:8k_2_02:112]
CISCO SYSTEMS, INC.

[0001193125-23-277891:8k_2_02:113]
REMAINING PERFORMANCE OBLIGATIONS

[0001193125-23-277891:8k_2_02:114]
(In millions, except percentages)

[0001193125-23-277891:8k_2_02:115]
|  |  | October 28, 2023 |  |  | July 29, 2023 |  |  | October 29, 2022 |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Product |  | $ | 16,011 |  |  |  | 14 | % |  | $ | 15,802 |  |  |  | 12 | % |  | $ | 14,013 |  |  |  | 5 | % |
| Service |  |  | 18,742 |  |  |  | 11 | % |  |  | 19,066 |  |  |  | 9 | % |  |  | 16,897 |  |  |  | 1 | % |
| Total |  | $ | 34,753 |  |  |  | 12 | % |  | $ | 34,868 |  |  |  | 11 | % |  | $ | 30,910 |  |  |  | 3 | % |

[0001193125-23-277891:8k_2_02:116]
We expect 51% of total RPO at October 28, 2023 will be recognized as revenue over the next 12 months.

[0001193125-23-277891:8k_2_02:117]
CISCO SYSTEMS, INC.

[0001193125-23-277891:8k_2_02:118]
DEFERRED REVENUE

[0001193125-23-277891:8k_2_02:119]
(In
millions)

[0001193125-23-277891:8k_2_02:120]
|  |  | October 28,2023 |  |  | July 29,2023 |  |  | October 29,2022 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 11,689 |  |  | $ | 11,505 |  |  | $ | 10,404 |  |
| Service |  |  | 13,970 |  |  |  | 14,045 |  |  |  | 12,615 |  |
| Total |  | $ | 25,659 |  |  | $ | 25,550 |  |  | $ | 23,019 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 13,812 |  |  | $ | 13,908 |  |  | $ | 12,578 |  |
| Noncurrent |  |  | 11,847 |  |  |  | 11,642 |  |  |  | 10,441 |  |
| Total |  | $ | 25,659 |  |  | $ | 25,550 |  |  | $ | 23,019 |  |

[0001193125-23-277891:8k_2_02:121]
CISCO SYSTEMS, INC.

[0001193125-23-277891:8k_2_02:122]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-23-277891:8k_2_02:123]
(In millions, except per-share amounts)

[0001193125-23-277891:8k_2_02:124]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASEPROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2024 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| October 28, 2023 |  | $ | 0.39 |  |  | $ | 1,580 |  |  |  | 23 |  |  | $ | 54.53 |  |  | $ | 1,252 |  |  | $ | 2,832 |  |
| Fiscal 2023 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 29, 2023 |  | $ | 0.39 |  |  | $ | 1,589 |  |  |  | 25 |  |  | $ | 50.49 |  |  | $ | 1,254 |  |  | $ | 2,843 |  |
| April 29, 2023 |  | $ | 0.39 |  |  | $ | 1,593 |  |  |  | 25 |  |  | $ | 49.45 |  |  | $ | 1,259 |  |  | $ | 2,852 |  |
| January 28, 2023 |  | $ | 0.38 |  |  | $ | 1,560 |  |  |  | 26 |  |  | $ | 47.72 |  |  | $ | 1,256 |  |  | $ | 2,816 |  |
| October 29, 2022 |  | $ | 0.38 |  |  | $ | 1,560 |  |  |  | 12 |  |  | $ | 43.76 |  |  | $ | 502 |  |  | $ | 2,062 |  |

[0001193125-23-277891:8k_2_02:125]
9

[0001193125-23-277891:8k_2_02:126]
CISCO SYSTEMS, INC.

[0001193125-23-277891:8k_2_02:127]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-23-277891:8k_2_02:128]
GAAP TO NON-GAAP NET INCOME

[0001193125-23-277891:8k_2_02:129]
(In millions)

[0001193125-23-277891:8k_2_02:130]
|  |  | Three Months Ended |  |
|  |  | October 28,2023 |  |  | October 29,2022 |  |
| GAAP net income |  | $ | 3,638 |  |  | $ | 2,670 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 103 |  |  |  | 81 |  |
| Amortization of acquisition-related intangible assets |  |  | 181 |  |  |  | 153 |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | 2 |  |
| Total adjustments to GAAP cost of sales |  |  | 284 |  |  |  | 236 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 550 |  |  |  | 415 |  |
| Amortization of acquisition-related intangible assets |  |  | 67 |  |  |  | 71 |  |
| Acquisition-related/divestiture costs |  |  | 75 |  |  |  | 75 |  |
| Russia-Ukraine war costs |  |  | (2 | ) |  |  | 3 |  |
| Significant asset impairments and restructurings |  |  | 123 |  |  |  | (2 | ) |
| Total adjustments to GAAP operating expenses |  |  | 813 |  |  |  | 562 |  |
| Adjustments to interest and other income (loss), net: |  |  |  |  |  |  |  |  |
| (Gains) and losses on investments |  |  | 51 |  |  |  | 109 |  |
| Total adjustments to GAAP interest and other income (loss), net |  |  | 51 |  |  |  | 109 |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 1,148 |  |  |  | 907 |  |
| Income tax effect of non-GAAP adjustments |  |  | (258 | ) |  |  | (192 | ) |
| Significant tax matters |  |  | — |  |  |  | 164 |  |
| Total adjustments to GAAP provision for income taxes |  |  | (258 | ) |  |  | (28 | ) |
| Non-GAAP net income |  | $ | 4,528 |  |  | $ | 3,549 |  |

[0001193125-23-277891:8k_2_02:131]
10

[0001193125-23-277891:8k_2_02:132]
CISCO SYSTEMS, INC.

[0001193125-23-277891:8k_2_02:133]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-23-277891:8k_2_02:134]
GAAP TO NON-GAAP EPS

[0001193125-23-277891:8k_2_02:135]
|  |  | Three Months Ended |  |
|  |  | October 28,2023 |  |  | October 29,2022 |  |
| GAAP EPS |  | $ | 0.89 |  |  | $ | 0.65 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.16 |  |  |  | 0.12 |  |
| Amortization of acquisition-related intangible assets |  |  | 0.06 |  |  |  | 0.05 |  |
| Acquisition-related/divestiture costs |  |  | 0.02 |  |  |  | 0.02 |  |
| Significant asset impairments and restructurings |  |  | 0.03 |  |  |  | — |  |
| (Gains) and losses on investments |  |  | 0.01 |  |  |  | 0.03 |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.06 | ) |  |  | (0.05 | ) |
| Significant tax matters |  |  | — |  |  |  | 0.04 |  |
| Non-GAAP EPS |  | $ | 1.11 |  |  | $ | 0.86 |  |

[0001193125-23-277891:8k_2_02:136]
Amounts may not sum due to rounding.

[0001193125-23-277891:8k_2_02:137]
11

[0001193125-23-277891:8k_2_02:138]
CISCO SYSTEMS, INC.

[0001193125-23-277891:8k_2_02:139]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-23-277891:8k_2_02:140]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET,

[0001193125-23-277891:8k_2_02:141]
AND NET INCOME

[0001193125-23-277891:8k_2_02:142]
(In
millions, except percentages)

[0001193125-23-277891:8k_2_02:143]
|  |  | Three Months Ended |  |
|  |  | October 28, 2023 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 7,182 |  |  | $ | 2,375 |  |  | $ | 9,557 |  |  | $ | 5,281 |  |  |  | 10% |  |  | $ | 4,276 |  |  |  | 21% |  |  | $ | 166 |  |  | $ | 3,638 |  |  |  | 36% |  |
| % of revenue |  |  | 64.5 | % |  |  | 67.3 | % |  |  | 65.2 | % |  |  | 36.0 | % |  |  |  |  |  |  | 29.2 | % |  |  |  |  |  |  | 1.1 | % |  |  | 24.8 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 42 |  |  |  | 61 |  |  |  | 103 |  |  |  | 550 |  |  |  |  |  |  |  | 653 |  |  |  |  |  |  |  | — |  |  |  | 653 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 181 |  |  |  | — |  |  |  | 181 |  |  |  | 67 |  |  |  |  |  |  |  | 248 |  |  |  |  |  |  |  | — |  |  |  | 248 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 75 |  |  |  |  |  |  |  | 75 |  |  |  |  |  |  |  | — |  |  |  | 75 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 123 |  |  |  |  |  |  |  | 123 |  |  |  |  |  |  |  | — |  |  |  | 123 |  |  |  |  |  |
| Russia-Ukraine war costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  |  |  |  |  | (2 | ) |  |  |  |  |  |  | — |  |  |  | (2 | ) |  |  |  |  |
| (Gains) and losses on investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 51 |  |  |  | 51 |  |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (258 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 7,405 |  |  | $ | 2,436 |  |  | $ | 9,841 |  |  | $ | 4,468 |  |  |  | 5% |  |  | $ | 5,373 |  |  |  | 24% |  |  | $ | 217 |  |  | $ | 4,528 |  |  |  | 28% |  |
| % of revenue |  |  | 66.5 | % |  |  | 69.0 | % |  |  | 67.1 | % |  |  | 30.5 | % |  |  |  |  |  |  | 36.6 | % |  |  |  |  |  |  | 1.5 | % |  |  | 30.9 | % |  |  |  |  |

[0001193125-23-277891:8k_2_02:144]
|  |  | Three Months Ended |  |
|  |  | October 29, 2022 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | Total GrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 6,066 |  |  | $ | 2,280 |  |  | $ | 8,346 |  |  | $ | 4,806 |  |  | $ | 3,540 |  |  | $ | (65 | ) |  | $ | 2,670 |  |
| % of revenue |  |  | 59.2 | % |  |  | 67.3 | % |  |  | 61.2 | % |  |  | 35.3 | % |  |  | 26.0 | % |  |  | (0.5 | )% |  |  | 19.6 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 31 |  |  |  | 50 |  |  |  | 81 |  |  |  | 415 |  |  |  | 496 |  |  |  | — |  |  |  | 496 |  |
| Amortization of acquisition-related intangible assets |  |  | 153 |  |  |  | — |  |  |  | 153 |  |  |  | 71 |  |  |  | 224 |  |  |  | — |  |  |  | 224 |  |
| Acquisition/divestiture-related costs |  |  | 2 |  |  |  | — |  |  |  | 2 |  |  |  | 75 |  |  |  | 77 |  |  |  | — |  |  |  | 77 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  | (2 | ) |  |  | — |  |  |  | (2 | ) |
| Russia-Ukraine war costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | 3 |  |  |  | — |  |  |  | 3 |  |
| (Gains) and losses on investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 109 |  |  |  | 109 |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (28 | ) |
| Non-GAAP amount |  | $ | 6,252 |  |  | $ | 2,330 |  |  | $ | 8,582 |  |  | $ | 4,244 |  |  | $ | 4,338 |  |  | $ | 44 |  |  | $ | 3,549 |  |
| % of revenue |  |  | 61.0 | % |  |  | 68.8 | % |  |  | 63.0 | % |  |  | 31.1 | % |  |  | 31.8 | % |  |  | 0.3 | % |  |  | 26.0 | % |

[0001193125-23-277891:8k_2_02:145]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-23-277891:8k_2_02:146]
12

[0001193125-23-277891:8k_2_02:147]
CISCO SYSTEMS, INC.

[0001193125-23-277891:8k_2_02:148]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-23-277891:8k_2_02:149]
EFFECTIVE TAX RATE

[0001193125-23-277891:8k_2_02:150]
(In
percentages)

[0001193125-23-277891:8k_2_02:151]
|  |  | Three Months Ended |  |
|  |  | October 28,2023 |  |  | October 29,2022 |  |
| GAAP effective tax rate |  |  | 18.1 | % |  |  | 23.2 | % |
| Total adjustments to GAAP provision for income taxes |  |  | 0.9 | % |  |  | (4.2 | )% |
| Non-GAAP effective tax rate |  |  | 19.0 | % |  |  | 19.0 | % |

[0001193125-23-277891:8k_2_02:152]
GAAP TO NON-GAAP GUIDANCE

[0001193125-23-277891:8k_2_02:153]
| Q2 FY 2024 |  | Gross MarginRate |  | Operating MarginRate |  | Earnings perShare (1) |
| GAAP |  | 62.5% –63.5% |  | 22.5% – 23.5% |  | $0.59 – $0.64 |
| Estimated adjustments for: |  |  |  |  |  |  |
| Share-based compensation expense |  | 1.0% |  | 6.0% |  | $0.14 – $0.15 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 1.5% |  | 2.5% |  | $0.05 – $0.06 |
| Significant asset impairments and restructurings |  | — |  | 0.5% |  | $0.01 – $0.02 |
| Non-GAAP |  | 65% – 66% |  | 31.5% – 32.5% |  | $0.82 – $0.84 |

[0001193125-23-277891:8k_2_02:154]
| FY 2024 |  | Earnings perShare (1) |
| GAAP |  | $2.97 – $3.08 |
| Estimated adjustments for: |  |  |
| Share-based compensation expense |  | $0.59 – $0.61 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | $0.22 – $0.24 |
| Significant asset impairments and restructurings |  | $0.03 – $0.04 |
| (Gains) and losses on investments |  | $0.01 |
| Non-GAAP |  | $3.87 – $3.93 |

[0001193125-23-277891:8k_2_02:155]
| (1) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-23-277891:8k_2_02:156]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, Russia-Ukraine war costs,
restructurings, (gains) and losses on investments and significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-23-277891:8k_2_02:157]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-23-277891:8k_2_02:158]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax rates,
non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross
margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-23-277891:8k_2_02:159]
These
non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles and may be different from
non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes
that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should
only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-23-277891:8k_2_02:160]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition
and its historical and projected results of operations.

[0001193125-23-277891:8k_2_02:161]
For its internal budgeting process, Cisco’s management uses financial statements that do not
include, when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other
contingencies, Russia-Ukraine war costs, gains and losses on investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures,
in addition to the corresponding GAAP measures, in reviewing the financial

[0001193125-23-277891:8k_2_02:162]
14

[0001193125-23-277891:8k_2_02:163]
results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to
time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-23-277891:8k_2_02:164]
Annualized recurring revenue represents the annualized revenue run-rate of active subscriptions, term licenses,
operating leases and maintenance contracts at the end of a reporting period, net of rebates to customers and partners as well as certain other revenue adjustments. Includes both revenue recognized ratably as well as upfront on an annualized basis.

[0001193125-23-277891:8k_2_02:165]
About Cisco

[0001193125-23-277891:8k_2_02:166]
Cisco (Nasdaq: CSCO) is the worldwide
technology leader that securely connects everything to make anything possible. Our purpose is to power an inclusive future for all by helping our customers reimagine their applications, power hybrid work, secure their enterprise, transform their
infrastructure, and meet their sustainability goals. Discover more at newsroom.cisco.com and follow us on X at @Cisco.

[0001193125-23-277891:8k_2_02:167]
Copyright © 2023 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a
list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any
other company. This document is Cisco Public Information.

[0001193125-23-277891:8k_2_02:168]
RSS Feed for
Cisco: https://newsroom.cisco.com/rss-feeds
