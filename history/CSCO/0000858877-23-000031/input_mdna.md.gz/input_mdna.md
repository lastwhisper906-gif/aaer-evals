# CSCO MD&A — 0000858877-23-000031


## mdna

[0000858877-23-000031:mdna:1]
[same as prior period, unchanged from 0000858877-23-000013:mdna:1]

[0000858877-23-000031:mdna:2]
[same as prior period, unchanged from 0000858877-23-000013:mdna:2]

[0000858877-23-000031:mdna:3]
[same as prior period, unchanged from 0000858877-23-000013:mdna:3]

[0000858877-23-000031:mdna:4]
Cisco designs and sells a broad range of technologies that power the Internet. We are integrating our product portfolios across networking, security, collaboration, applications and the cloud to create highly secure, intelligent platforms for our customers’ digital businesses. These platforms are designed to help our customers manage more users, devices and things connecting to their networks. This will enable us to provide customers with a highly secure, intelligent platform for their digital business.

[0000858877-23-000031:mdna:5]
[same as prior period, unchanged from 0000858877-23-000013:mdna:5]

[0000858877-23-000031:mdna:6]
|  | Three Months Ended |  |
|  | October 28,2023 |  | October 29,2022 |  | % Variance |  |
| Revenue | $ | 14,668 |  |  | $ | 13,632 |  |  | 8 | % |  |
| Gross margin percentage | 65.2 | % |  | 61.2 | % |  | 4.0 |  | pts |
| Research and development | $ | 1,913 |  |  | $ | 1,781 |  |  | 7 | % |  |
| Sales and marketing | $ | 2,506 |  |  | $ | 2,391 |  |  | 5 | % |  |
| General and administrative | $ | 672 |  |  | $ | 565 |  |  | 19 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 5,091 |  |  | $ | 4,737 |  |  | 7 | % |  |
| Total as a percentage of revenue | 34.7 | % |  | 34.7 | % |  | — |  | pts |
| Restructuring and other charges included in operating expenses | $ | 123 |  |  | $ | (2) |  |  | NM |  |
| Operating income as a percentage of revenue | 29.2 | % |  | 26.0 | % |  | 3.2 |  | pts |
| Interest and other income (loss), net | $ | 166 |  |  | $ | (65) |  |  | NM |  |
| Income tax percentage | 18.1 | % |  | 23.2 | % |  | (5.1) |  | pts |
| Net income | $ | 3,638 |  |  | $ | 2,670 |  |  | 36 | % |  |
| Net income as a percentage of revenue | 24.8 | % |  | 19.6 | % |  | 5.2 |  | pts |
| Earnings per share—diluted | $ | 0.89 |  |  | $ | 0.65 |  |  | 37 | % |  |

[0000858877-23-000031:mdna:7]
[same as prior period, unchanged from 0000858877-23-000013:mdna:7]

[0000858877-23-000031:mdna:8]
[same as prior period, unchanged from 0000858877-23-000013:mdna:8]

[0000858877-23-000031:mdna:9]
[same as prior period, unchanged from 0000858877-23-000013:mdna:9]

[0000858877-23-000031:mdna:10]
[same as prior period, unchanged from 0000858877-23-000013:mdna:10]

[0000858877-23-000031:mdna:11]
Three Months Ended October 28, 2023 Compared with Three Months Ended October 29, 2022

[0000858877-23-000031:mdna:12]
In the first quarter of fiscal 2024, we delivered solid results with growth in revenue, margins and profitability. The challenges we previously saw with supply constraints have now shifted downstream to implementation by our customers and third-party resellers. Our customer lead times have largely returned to normal levels. We were able to increase the delivery of products to our customers, which positively impacted product revenue during the first quarter of fiscal 2024. Although product revenue increased, we saw a decline in product demand in the first quarter of fiscal 2024. While we recognize that challenging macroeconomic factors continue to exist, we believe the decline in product demand is primarily due to customers needing additional time to implement elevated levels of product shipments from prior quarters. We believe these elevated levels represent one to two quarters of product shipments that our customers have not yet deployed. We saw this dynamic primarily with our larger enterprise, service provider and cloud customers.

[0000858877-23-000031:mdna:13]
Total revenue increased by 8% compared with the first quarter of fiscal 2023. Within total revenue, product revenue increased by 9% and service revenue increased by 4%. In the first quarter of fiscal 2024, total software revenue was $4.4 billion across all product areas and service, an increase of 13%. Within total software revenue, subscription revenue increased 13%.

[0000858877-23-000031:mdna:14]
Total gross margin increased by 4.0 percentage points. Product gross margin increased by 5.3 percentage points, largely driven by productivity improvements, favorable pricing and favorable product mix. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, was flat. Operating income as a percentage of revenue increased by 3.2 percentage points driven by higher product gross margin partially offset by restructuring and other charges of $123 million in the first quarter of fiscal 2024. Diluted earnings per share increased 37%, driven by an increase of 36% in net income and a decrease in diluted share count of 29 million shares.

[0000858877-23-000031:mdna:15]
In terms of our geographic segments, revenue from the Americas increased $1.1 billion, EMEA revenue decreased by $11 million and APJC revenue decreased by $61 million. From a customer market standpoint, we experienced product revenue growth in the enterprise and public sector markets, partially offset by a decline in the service provider and cloud market. From a product category perspective, the product revenue increase of 9% was driven by growth in revenue for Networking of 10%, Security of 4%, Collaboration of 3% and Observability of 21%.

[0000858877-23-000031:mdna:16]
We remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformations. Further, we made progress in the transition of our business model delivering increased software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we are making progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-23-000031:mdna:17]
39

[0000858877-23-000031:mdna:18]
[same as prior period, unchanged from 0000858877-23-000013:mdna:16]

[0000858877-23-000031:mdna:19]
[same as prior period, unchanged from 0000858877-23-000013:mdna:17]

[0000858877-23-000031:mdna:20]
[same as prior period, unchanged from 0000858877-23-000013:mdna:20]

[0000858877-23-000031:mdna:21]
As our customers add billions of new connections to their enterprises, and as more applications move to a multicloud environment, the network becomes even more critical. Our customers are navigating change at an unprecedented pace. In this dynamic environment, we believe their priorities are to transform infrastructure, secure the enterprise, power hybrid work, reimagine applications, and drive toward sustainability. Our strategy is to securely connect everything. We are committed to driving a trusted customer experience, through our innovation, solutions, choice, and people.

[0000858877-23-000031:mdna:22]
For additional discussion of our strategy and priorities, see Item 1. Business in our Annual Report on Form 10-K for the fiscal year ended July 29, 2023.

[0000858877-23-000031:mdna:23]
[same as prior period, unchanged from 0000858877-23-000013:mdna:23]

[0000858877-23-000031:mdna:24]
The following is a summary of our other key financial measures for the first quarter of fiscal 2024 (in millions):

[0000858877-23-000031:mdna:25]
|  |  | October 28,2023 |  | July 29,2023 |
| Cash and cash equivalents and investments |  | $ | 23,523 |  |  | $ | 26,146 |  |
| Remaining performance obligations |  | $ | 34,753 |  |  | $ | 34,868 |  |
| Inventories |  | $ | 3,342 |  |  | $ | 3,644 |  |

[0000858877-23-000031:mdna:26]
|  |  | Three Months Ended |
|  |  | October 28,2023 |  | October 29,2022 |
| Cash provided by operating activities |  | $ | 2,371 |  |  | $ | 3,962 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 1,252 |  |  | $ | 502 |  |
| Dividends paid |  | $ | 1,580 |  |  | $ | 1,560 |  |

[0000858877-23-000031:mdna:27]
[same as prior period, unchanged from 0000858877-23-000013:mdna:27]

[0000858877-23-000031:mdna:28]
[same as prior period, unchanged from 0000858877-23-000013:mdna:28]

[0000858877-23-000031:mdna:29]
[same as prior period, unchanged from 0000858877-23-000013:mdna:29]

[0000858877-23-000031:mdna:30]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements in our Annual Report on Form 10-K for the fiscal year ended July 29, 2023, as updated as applicable in Note 2 to the Consolidated Financial Statements herein, describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-23-000031:mdna:31]
[same as prior period, unchanged from 0000858877-23-000013:mdna:31]

[0000858877-23-000031:mdna:32]
[same as prior period, unchanged from 0000858877-23-000013:mdna:32]

[0000858877-23-000031:mdna:33]
[same as prior period, unchanged from 0000858877-23-000013:mdna:33]

[0000858877-23-000031:mdna:34]
[same as prior period, unchanged from 0000858877-23-000013:mdna:34]

[0000858877-23-000031:mdna:35]
[same as prior period, unchanged from 0000858877-23-000013:mdna:35]

[0000858877-23-000031:mdna:36]
[same as prior period, unchanged from 0000858877-23-000013:mdna:36]

[0000858877-23-000031:mdna:37]
[same as prior period, unchanged from 0000858877-23-000013:mdna:37]

[0000858877-23-000031:mdna:38]
[same as prior period, unchanged from 0000858877-23-000013:mdna:38]

[0000858877-23-000031:mdna:39]
[same as prior period, unchanged from 0000858877-23-000013:mdna:40]

[0000858877-23-000031:mdna:40]
[same as prior period, unchanged from 0000858877-23-000013:mdna:41]

[0000858877-23-000031:mdna:41]
[same as prior period, unchanged from 0000858877-23-000013:mdna:42]

[0000858877-23-000031:mdna:42]
Our provision for inventory was $133 million and $38 million for the first quarter of fiscal 2024 and 2023, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $43 million and $83 million for the first quarter of fiscal 2024 and 2023, respectively. If there were to be a sudden and significant decrease in demand for our products, if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, or if supply constraints were to continue, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. For further discussion around the Supply Constraints Impacts and Risks, see “—Results of Operations—Gross Margin—Supply Constraints Impacts and Risks” and “—Liquidity and Capital Resources—Inventory Supply Chain.”

[0000858877-23-000031:mdna:43]
Loss Contingencies

[0000858877-23-000031:mdna:44]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-23-000031:mdna:45]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-23-000031:mdna:46]
[same as prior period, unchanged from 0000858877-23-000013:mdna:47]

[0000858877-23-000031:mdna:47]
[same as prior period, unchanged from 0000858877-23-000013:mdna:48]

[0000858877-23-000031:mdna:48]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first quarters of fiscal 2024 and 2023.

[0000858877-23-000031:mdna:49]
[same as prior period, unchanged from 0000858877-23-000013:mdna:50]

[0000858877-23-000031:mdna:50]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. Our ongoing consideration of all the factors described previously could result in impairment charges in the future, which could adversely affect our net income.

[0000858877-23-000031:mdna:51]
[same as prior period, unchanged from 0000858877-23-000013:mdna:52]

[0000858877-23-000031:mdna:52]
[same as prior period, unchanged from 0000858877-23-000013:mdna:53]

[0000858877-23-000031:mdna:53]
[same as prior period, unchanged from 0000858877-23-000013:mdna:55]

[0000858877-23-000031:mdna:54]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was 18.1% and 23.2% in the first quarter of fiscal 2024 and 2023, respectively.

[0000858877-23-000031:mdna:55]
[same as prior period, unchanged from 0000858877-23-000013:mdna:57]

[0000858877-23-000031:mdna:56]
[same as prior period, unchanged from 0000858877-23-000013:mdna:58]

[0000858877-23-000031:mdna:57]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to foreign-derived intangible income deduction, global intangible low-tax income and base erosion and anti-abuse tax, research and development capitalization and amortization, and corporate alternative minimum tax laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 38 countries, including the United States, has made changes and is contemplating additional changes to numerous long-standing tax principles. There can be no assurance that these changes and any contemplated changes if finalized, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries was subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-23-000031:mdna:58]
[same as prior period, unchanged from 0000858877-23-000013:mdna:60]

[0000858877-23-000031:mdna:59]
[same as prior period, unchanged from 0000858877-23-000013:mdna:61]

[0000858877-23-000031:mdna:60]
[same as prior period, unchanged from 0000858877-23-000013:mdna:62]

[0000858877-23-000031:mdna:61]
[same as prior period, unchanged from 0000858877-23-000013:mdna:63]

[0000858877-23-000031:mdna:62]
[same as prior period, unchanged from 0000858877-23-000013:mdna:64]

[0000858877-23-000031:mdna:63]
|  |  | Three Months Ended |
|  |  | October 28,2023 |  | October 29,2022 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 11,139 |  |  | $ | 10,245 |  |  | $ | 894 |  |  | 9 | % |
| Percentage of revenue |  | 75.9 | % |  | 75.2 | % |  |  |  |  |
| Service |  | 3,529 |  |  | 3,387 |  |  | 142 |  |  | 4 | % |
| Percentage of revenue |  | 24.1 | % |  | 24.8 | % |  |  |  |  |
| Total |  | $ | 14,668 |  |  | $ | 13,632 |  |  | $ | 1,036 |  |  | 8 | % |

[0000858877-23-000031:mdna:64]
[same as prior period, unchanged from 0000858877-23-000013:mdna:66]

[0000858877-23-000031:mdna:65]
|  |  | Three Months Ended |
|  |  | October 28,2023 |  | October 29,2022 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 9,022 |  |  | $ | 7,914 |  |  | $ | 1,108 |  |  | 14 | % |
| Percentage of revenue |  | 61.5 | % |  | 58.0 | % |  |  |  |  |
| EMEA |  | 3,664 |  |  | 3,675 |  |  | (11) |  |  | — | % |
| Percentage of revenue |  | 25.0 | % |  | 27.0 | % |  |  |  |  |
| APJC |  | 1,982 |  |  | 2,043 |  |  | (61) |  |  | (3) | % |
| Percentage of revenue |  | 13.5 | % |  | 15.0 | % |  |  |  |  |
| Total |  | $ | 14,668 |  |  | $ | 13,632 |  |  | $ | 1,036 |  |  | 8 | % |

[0000858877-23-000031:mdna:66]
[same as prior period, unchanged from 0000858877-23-000013:mdna:68]

[0000858877-23-000031:mdna:67]
Three Months Ended October 28, 2023 Compared with Three Months Ended October 29, 2022

[0000858877-23-000031:mdna:68]
Total revenue increased by 8%. Product revenue increased by 9% and service revenue increased by 4%. Our total revenue reflected growth in the Americas segment partially offset by a decline in the APJC segment. Total revenue in the EMEA segment was flat.

[0000858877-23-000031:mdna:69]
In addition to the impact of macroeconomic factors, including the IT spending environment and the level of spending by government entities, revenue by segment in a particular period may be significantly impacted by the timing of revenue recognition for complex transactions with multiple performance obligations. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment.

[0000858877-23-000031:mdna:70]
[same as prior period, unchanged from 0000858877-23-000013:mdna:75]

[0000858877-23-000031:mdna:71]
[same as prior period, unchanged from 0000858877-23-000013:mdna:76]

[0000858877-23-000031:mdna:72]
[same as prior period, unchanged from 0000858877-23-000013:mdna:77]

[0000858877-23-000031:mdna:73]
[same as prior period, unchanged from 0000858877-23-000013:mdna:78]

[0000858877-23-000031:mdna:74]
|  |  | Three Months Ended |
|  |  | October 28,2023 |  | October 29,2022 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 6,852 |  |  | $ | 5,846 |  |  | $ | 1,006 |  |  | 17 | % |
| Percentage of product revenue |  | 61.5 | % |  | 57.0 | % |  |  |  |  |
| EMEA |  | 2,840 |  |  | 2,886 |  |  | (46) |  |  | (2) | % |
| Percentage of product revenue |  | 25.5 | % |  | 28.2 | % |  |  |  |  |
| APJC |  | 1,448 |  |  | 1,513 |  |  | (65) |  |  | (4) | % |
| Percentage of product revenue |  | 13.0 | % |  | 14.8 | % |  |  |  |  |
| Total |  | $ | 11,139 |  |  | $ | 10,245 |  |  | $ | 894 |  |  | 9 | % |

[0000858877-23-000031:mdna:75]
[same as prior period, unchanged from 0000858877-23-000013:mdna:80]

[0000858877-23-000031:mdna:76]
Three Months Ended October 28, 2023 Compared with Three Months Ended October 29, 2022

[0000858877-23-000031:mdna:77]
[same as prior period, unchanged from 0000858877-23-000013:mdna:81]

[0000858877-23-000031:mdna:78]
Product revenue in the Americas segment increased by 17%, with growth across all customer markets, led by the public sector market. From a country perspective, product revenue increased in the United States, Mexico and Brazil by 19%, 4% and 8%, respectively, partially offset by a decline in product revenue in Canada of 1%.

[0000858877-23-000031:mdna:79]
[same as prior period, unchanged from 0000858877-23-000013:mdna:86]

[0000858877-23-000031:mdna:80]
Product revenue in the EMEA segment decreased by 2%, driven by declines in the service provider and cloud and the enterprise markets, partially offset by growth in the public sector market. From a country perspective, product revenue increased in Germany by 2%, partially offset by product revenue declines in the United Kingdom and France by 5% and 20%, respectively.

[0000858877-23-000031:mdna:81]
[same as prior period, unchanged from 0000858877-23-000013:mdna:91]

[0000858877-23-000031:mdna:82]
Product revenue in the APJC segment decreased by 4%, driven by a decline in the service provider and cloud market, partially offset by growth in the public sector market. Product revenue in the enterprise market was flat. From a country perspective, product revenue increased in India by 14%, partially offset by a decline of 13% in Japan, 5% in Australia and 39% in China.

[0000858877-23-000031:mdna:83]
[same as prior period, unchanged from 0000858877-23-000013:mdna:96]

[0000858877-23-000031:mdna:84]
[same as prior period, unchanged from 0000858877-23-000013:mdna:97]

[0000858877-23-000031:mdna:85]
[same as prior period, unchanged from 0000858877-23-000013:mdna:98]

[0000858877-23-000031:mdna:86]
In addition to the primary view on a geographic basis, we also prepare financial information related to product categories and customer markets for various purposes. Effective in the first quarter of fiscal 2024, we began reporting our product revenue in the following categories: Networking, Security, Collaboration, and Observability and conformed our product revenue for prior periods to the current period presentation.

[0000858877-23-000031:mdna:87]
[same as prior period, unchanged from 0000858877-23-000013:mdna:100]

[0000858877-23-000031:mdna:88]
|  |  | Three Months Ended |
|  |  | October 28,2023 |  | October 29,2022 |  | Variancein Dollars |  | Variance in Percent |
| Product Revenue |  |  |  |  |  |  |  |  |
| Networking |  | $ | 8,822 |  |  | $ | 8,031 |  |  | $ | 791 |  |  | 10 | % |
| Security |  | 1,010 |  |  | 971 |  |  | 39 |  |  | 4 | % |
| Collaboration |  | 1,117 |  |  | 1,086 |  |  | 31 |  |  | 3 | % |
| Observability |  | 190 |  |  | 157 |  |  | 33 |  |  | 21 | % |
| Total |  | $ | 11,139 |  |  | $ | 10,245 |  |  | $ | 894 |  |  | 9 | % |

[0000858877-23-000031:mdna:89]
[same as prior period, unchanged from 0000858877-23-000013:mdna:102]

[0000858877-23-000031:mdna:90]
Three Months Ended October 28, 2023 Compared with Three Months Ended October 29, 2022

[0000858877-23-000031:mdna:91]
Networking

[0000858877-23-000031:mdna:92]
The Networking product category represents our core networking technologies of switching, routing, wireless, 5G, silicon, optics solutions and compute products. Networking revenue increased by 10%, or $791 million. Revenue grew in both campus switching and data center switching primarily driven by strong growth in our Catalyst 9000 and Nexus 9000 series offerings. The increase was partially offset by a decline in wireless.

[0000858877-23-000031:mdna:93]
Security

[0000858877-23-000031:mdna:94]
The Security product category consists of our Cloud and Application Security, Industrial Security, Network Security, and User and Device Security offerings. Revenue in our Security product category increased by 4%, or $39 million, primarily driven by growth in our Zero Trust and Threat Intelligence and Detection and Response offerings.

[0000858877-23-000031:mdna:95]
[same as prior period, unchanged from 0000858877-23-000013:mdna:113]

[0000858877-23-000031:mdna:96]
The Collaboration product category consists of our Meetings, Collaboration Devices, Calling, Contact Center and CPaaS offerings. Revenue in our Collaboration product category increased by 3%, or $31 million, primarily driven by growth in our Calling and Contact Center offerings and partially offset by a decline in Meetings.

[0000858877-23-000031:mdna:97]
Observability

[0000858877-23-000031:mdna:98]
The Observability product category consists of our full stack observability offerings. Revenue in our Observability product category increased 21%, or $33 million, driven by growth across the portfolio, including double-digit growth in our ThousandEyes and AppDynamics offerings.

[0000858877-23-000031:mdna:99]
[same as prior period, unchanged from 0000858877-23-000013:mdna:116]

[0000858877-23-000031:mdna:100]
[same as prior period, unchanged from 0000858877-23-000013:mdna:117]

[0000858877-23-000031:mdna:101]
[same as prior period, unchanged from 0000858877-23-000013:mdna:130]

[0000858877-23-000031:mdna:102]
[same as prior period, unchanged from 0000858877-23-000013:mdna:131]

[0000858877-23-000031:mdna:103]
|  |  | Three Months Ended |
|  |  | October 28,2023 |  | October 29,2022 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,171 |  |  | $ | 2,067 |  |  | $ | 104 |  |  | 5 | % |
| Percentage of service revenue |  | 61.5 | % |  | 61.0 | % |  |  |  |  |
| EMEA |  | 824 |  |  | 789 |  |  | 35 |  |  | 4 | % |
| Percentage of service revenue |  | 23.3 | % |  | 23.3 | % |  |  |  |  |
| APJC |  | 534 |  |  | 530 |  |  | 4 |  |  | 1 | % |
| Percentage of service revenue |  | 15.2 | % |  | 15.7 | % |  |  |  |  |
| Total |  | $ | 3,529 |  |  | $ | 3,387 |  |  | $ | 142 |  |  | 4 | % |

[0000858877-23-000031:mdna:104]
[same as prior period, unchanged from 0000858877-23-000013:mdna:133]

[0000858877-23-000031:mdna:105]
Service revenue increased 4% in the first quarter of fiscal 2024 compared with the first quarter of fiscal 2023, primarily driven by revenue growth in our solution support, maintenance business offerings and advisory services. Service revenue increased across each of our geographic segments for the first quarter of fiscal 2024.

[0000858877-23-000031:mdna:106]
[same as prior period, unchanged from 0000858877-23-000013:mdna:138]

[0000858877-23-000031:mdna:107]
[same as prior period, unchanged from 0000858877-23-000013:mdna:139]

[0000858877-23-000031:mdna:108]
|  |  | Three Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |
|  |  | October 28,2023 |  | October 29,2022 |  | October 28,2023 |  | October 29,2022 |
| Gross margin: |  |  |  |  |  |  |  |  |
| Product |  | $ | 7,182 |  |  | $ | 6,066 |  |  | 64.5 | % |  | 59.2 | % |
| Service |  | 2,375 |  |  | 2,280 |  |  | 67.3 | % |  | 67.3 | % |
| Total |  | $ | 9,557 |  |  | $ | 8,346 |  |  | 65.2 | % |  | 61.2 | % |

[0000858877-23-000031:mdna:109]
[same as prior period, unchanged from 0000858877-23-000013:mdna:141]

[0000858877-23-000031:mdna:110]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the first quarter of fiscal 2024, as compared with the corresponding prior year periods:

[0000858877-23-000031:mdna:111]
|  |  | Product Gross Margin Percentage |
| Fiscal 2023 |  | 59.2 | % |
| Productivity (1) |  | 3.1 | % |
| Product pricing |  | 1.2 | % |
| Mix of products sold |  | 1.2 | % |
| Others |  | (0.2) | % |
| Fiscal 2024 |  | 64.5 | % |

[0000858877-23-000031:mdna:112]
[same as prior period, unchanged from 0000858877-23-000013:mdna:144]

[0000858877-23-000031:mdna:113]
Three Months Ended October 28, 2023 Compared with Three Months Ended October 29, 2022

[0000858877-23-000031:mdna:114]
Product gross margin increased by 5.3 percentage points primarily driven by productivity improvements, largely driven by lower freight, logistics and components costs. We also saw favorable pricing and favorable impacts from product mix.

[0000858877-23-000031:mdna:115]
[same as prior period, unchanged from 0000858877-23-000013:mdna:136]

[0000858877-23-000031:mdna:116]
[same as prior period, unchanged from 0000858877-23-000013:mdna:137]

[0000858877-23-000031:mdna:117]
[same as prior period, unchanged from 0000858877-23-000013:mdna:149]

[0000858877-23-000031:mdna:118]
In past periods, we took multiple actions in order to mitigate component shortages and address significant supply constraints. These supply constraints resulted in significant increased costs (i.e., component and other commodity costs, expedite fees, etc.) which had, and may continue to have, a negative impact on our product gross margin and resulted in extended lead times for us and our customers. The mitigating actions we took included: partnering with several of our key suppliers utilizing our volume purchasing ability and extending supply coverage, including, in certain cases, revising supplier arrangements; paying and committing to pay in the future significantly higher costs for certain components; modifying our product designs in order to leverage alternate suppliers, where possible; and continually optimizing our inventory build and customer delivery plans, among others. These mitigating actions have resulted in increased inventory balances, inventory purchase commitments, and inventory deposits and prepayments compared to prior fiscal years, which, in turn, has increased our supply chain exposure, which could result in negative impacts to our product gross margin in future periods, including material excess and obsolete charges, if product demand significantly decreases for a sustained duration or we are unable to continue to mitigate the remaining supply chain exposures. We believe these mitigating actions have helped us to optimize our access to critical components and meet customer demand for our products as a result of the component shortages and significant supply constraints we saw in past periods. While these mitigating actions have resulted in a decrease of our overall supply chain balances, these balances continue to be higher as compared to prior fiscal years.

[0000858877-23-000031:mdna:119]
[same as prior period, unchanged from 0000858877-23-000013:mdna:155]

[0000858877-23-000031:mdna:120]
Our service gross margin percentage was flat compared to the first quarter of fiscal 2023 primarily due to higher sales volume offset by higher headcount-related and delivery costs.

[0000858877-23-000031:mdna:121]
[same as prior period, unchanged from 0000858877-23-000013:mdna:158]

[0000858877-23-000031:mdna:122]
[same as prior period, unchanged from 0000858877-23-000013:mdna:161]

[0000858877-23-000031:mdna:123]
[same as prior period, unchanged from 0000858877-23-000013:mdna:162]

[0000858877-23-000031:mdna:124]
|  | Three Months Ended |
|  | AMOUNT |  | PERCENTAGE |
|  | October 28,2023 |  | October 29,2022 |  | October 28,2023 |  | October 29,2022 |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 5,968 |  |  | $ | 4,984 |  |  | 66.2 | % |  | 63.0 | % |
| EMEA | 2,545 |  |  | 2,325 |  |  | 69.5 | % |  | 63.3 | % |
| APJC | 1,328 |  |  | 1,274 |  |  | 67.0 | % |  | 62.3 | % |
| Segment total | 9,841 |  |  | 8,582 |  |  | 67.1 | % |  | 63.0 | % |
| Unallocated corporate items (1) | (284) |  |  | (236) |  |  |  |  |  |
| Total | $ | 9,557 |  |  | $ | 8,346 |  |  | 65.2 | % |  | 61.2 | % |

[0000858877-23-000031:mdna:125]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-23-000031:mdna:126]
[same as prior period, unchanged from 0000858877-23-000013:mdna:165]

[0000858877-23-000031:mdna:127]
Three Months Ended October 28, 2023 Compared with Three Months Ended October 29, 2022

[0000858877-23-000031:mdna:128]
We experienced a gross margin percentage increase in our Americas segment due to positive impacts from productivity improvements and favorable pricing, slightly offset by unfavorable product mix.

[0000858877-23-000031:mdna:129]
Gross margin percentage in our EMEA segment increased primarily due to positive impacts from productivity improvements, favorable product mix, and favorable pricing.

[0000858877-23-000031:mdna:130]
48

[0000858877-23-000031:mdna:131]
[same as prior period, unchanged from 0000858877-23-000013:mdna:152]

[0000858877-23-000031:mdna:132]
[same as prior period, unchanged from 0000858877-23-000013:mdna:153]

[0000858877-23-000031:mdna:133]
The APJC segment gross margin percentage increase was primarily due to positive impacts from productivity improvements, favorable product mix and favorable pricing, partially offset by lower service gross margin.

[0000858877-23-000031:mdna:134]
[same as prior period, unchanged from 0000858877-23-000013:mdna:177]

[0000858877-23-000031:mdna:135]
[same as prior period, unchanged from 0000858877-23-000013:mdna:178]

[0000858877-23-000031:mdna:136]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,913 |  |  | $ | 1,781 |  |  | $ | 132 |  |  | 7 | % |
| Percentage of revenue | 13.0 | % |  | 13.1 | % |  |  |  |  |
| Sales and marketing | 2,506 |  |  | 2,391 |  |  | 115 |  |  | 5 | % |
| Percentage of revenue | 17.1 | % |  | 17.5 | % |  |  |  |  |
| General and administrative | 672 |  |  | 565 |  |  | 107 |  |  | 19 | % |
| Percentage of revenue | 4.6 | % |  | 4.1 | % |  |  |  |  |
| Total | $ | 5,091 |  |  | $ | 4,737 |  |  | $ | 354 |  |  | 7 | % |
| Percentage of revenue | 34.7 | % |  | 34.7 | % |  |  |  |  |

[0000858877-23-000031:mdna:137]
Three Months Ended October 28, 2023 Compared with Three Months Ended October 29, 2022

[0000858877-23-000031:mdna:138]
[same as prior period, unchanged from 0000858877-23-000013:mdna:180]

[0000858877-23-000031:mdna:139]
R&D expenses increased due to higher headcount-related expenses, higher share-based compensation expense and higher discretionary spending, partially offset by lower acquisition and divestitures related costs.

[0000858877-23-000031:mdna:140]
[same as prior period, unchanged from 0000858877-23-000013:mdna:183]

[0000858877-23-000031:mdna:141]
[same as prior period, unchanged from 0000858877-23-000013:mdna:186]

[0000858877-23-000031:mdna:142]
Sales and marketing expenses increased primarily due to higher headcount-related expenses, higher discretionary spending and higher share-based compensation expense.

[0000858877-23-000031:mdna:143]
[same as prior period, unchanged from 0000858877-23-000013:mdna:191]

[0000858877-23-000031:mdna:144]
G&A expenses increased due to higher headcount-related expenses, higher share-based compensation expense, higher discretionary spending, higher acquisition and divestitures related costs and higher contracted services spending.

[0000858877-23-000031:mdna:145]
[same as prior period, unchanged from 0000858877-23-000013:mdna:200]

[0000858877-23-000031:mdna:146]
In the first quarter of fiscal 2024, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $26 million, or 0.6%, compared with the first quarter of fiscal 2023.

[0000858877-23-000031:mdna:147]
[same as prior period, unchanged from 0000858877-23-000013:mdna:203]

[0000858877-23-000031:mdna:148]
[same as prior period, unchanged from 0000858877-23-000013:mdna:204]

[0000858877-23-000031:mdna:149]
|  |  | Three Months Ended |
|  |  | October 28,2023 |  | October 29,2022 |
| Amortization of purchased intangible assets: |  |  |  |  |
| Cost of sales |  | $ | 186 |  |  | $ | 158 |  |
| Operating expenses |  | 67 |  |  | 71 |  |
| Total |  | $ | 253 |  |  | $ | 229 |  |

[0000858877-23-000031:mdna:150]
For the first quarter of fiscal 2024, the increase in amortization of purchased intangible assets was primarily due to amortization of purchased intangibles from our recent acquisitions, partially offset by certain purchased intangible assets that became fully amortized.

[0000858877-23-000031:mdna:151]
[same as prior period, unchanged from 0000858877-23-000013:mdna:171]

[0000858877-23-000031:mdna:152]
[same as prior period, unchanged from 0000858877-23-000013:mdna:172]

[0000858877-23-000031:mdna:153]
[same as prior period, unchanged from 0000858877-23-000013:mdna:207]

[0000858877-23-000031:mdna:154]
In the second quarter of fiscal 2023, we announced a restructuring plan in order to rebalance the organization and enable further investment in key priority areas, of which approximately 5% of the global workforce would be impacted. In connection with this restructuring plan, we incurred charges of $123 million in the first quarter of fiscal 2024 and have incurred cumulative charges of $658 million to date. We have substantially completed this restructuring plan in the first quarter of fiscal 2024. We expect to reinvest substantially all of the cost savings from this restructuring plan in our key priority areas. As a result, the overall cost savings from this restructuring plan are not expected to be material for future periods.

[0000858877-23-000031:mdna:155]
[same as prior period, unchanged from 0000858877-23-000013:mdna:209]

[0000858877-23-000031:mdna:156]
[same as prior period, unchanged from 0000858877-23-000013:mdna:210]

[0000858877-23-000031:mdna:157]
|  |  | Three Months Ended |
|  |  | October 28,2023 |  | October 29,2022 |
| Operating income |  | $ | 4,276 |  |  | $ | 3,540 |  |
| Operating income as a percentage of revenue |  | 29.2 | % |  | 26.0 | % |

[0000858877-23-000031:mdna:158]
Three Months Ended October 28, 2023 Compared with Three Months Ended October 29, 2022

[0000858877-23-000031:mdna:159]
Operating income increased by 21%, and operating income as a percentage of revenue increased by 3.2 percentage points. These changes resulted primarily from a revenue increase and a gross margin percentage increase (driven by productivity improvements, favorable pricing and favorable product mix), partially offset by higher restructuring and other charges.

[0000858877-23-000031:mdna:160]
[same as prior period, unchanged from 0000858877-23-000013:mdna:219]

[0000858877-23-000031:mdna:161]
[same as prior period, unchanged from 0000858877-23-000013:mdna:220]

[0000858877-23-000031:mdna:162]
|  |  | Three Months Ended |
|  |  | October 28,2023 |  | October 29,2022 |  | Variancein Dollars |
| Interest income |  | $ | 360 |  |  | $ | 169 |  |  | $ | 191 |  |
| Interest expense |  | (111) |  |  | (100) |  |  | (11) |  |
| Interest income (expense), net |  | $ | 249 |  |  | $ | 69 |  |  | $ | 180 |  |

[0000858877-23-000031:mdna:163]
For the first quarter of fiscal 2024, the increase in interest income was driven by higher average balance of cash and available-for-sale debt investments and higher interest rates. The increase in interest expense was primarily driven by higher interest rates, partially offset by a lower average debt balance.

[0000858877-23-000031:mdna:164]
[same as prior period, unchanged from 0000858877-23-000013:mdna:223]

[0000858877-23-000031:mdna:165]
|  |  | Three Months Ended |
|  |  | October 28,2023 |  | October 29,2022 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | (20) |  |  | $ | (6) |  |  | $ | (14) |  |
| Marketable equity investments |  | (46) |  |  | (21) |  |  | (25) |  |
| Privately held investments |  | (5) |  |  | (92) |  |  | 87 |  |
| Net gains (losses) on investments |  | (71) |  |  | (119) |  |  | 48 |  |
| Other gains (losses), net |  | (12) |  |  | (15) |  |  | 3 |  |
| Other income (loss), net |  | $ | (83) |  |  | $ | (134) |  |  | $ | 51 |  |

[0000858877-23-000031:mdna:166]
[same as prior period, unchanged from 0000858877-23-000013:mdna:195]

[0000858877-23-000031:mdna:167]
[same as prior period, unchanged from 0000858877-23-000013:mdna:196]

[0000858877-23-000031:mdna:168]
Three Months Ended October 28, 2023 Compared with Three Months Ended October 29, 2022

[0000858877-23-000031:mdna:169]
The increase in our other income (loss), net was primarily driven by lower realized losses and impairment charges on our privately held investments and changes in net gains (losses) on available-for-sale debt investments and marketable equity investments.

[0000858877-23-000031:mdna:170]
[same as prior period, unchanged from 0000858877-23-000013:mdna:229]

[0000858877-23-000031:mdna:171]
Three Months Ended October 28, 2023 Compared with Three Months Ended October 29, 2022

[0000858877-23-000031:mdna:172]
The provision for income taxes resulted in an effective tax rate of 18.1% for the first quarter of fiscal 2024 compared with 23.2% for the first quarter of fiscal 2023. The decrease in the effective tax rate was primarily due to a decrease in net discrete tax expenses.

[0000858877-23-000031:mdna:173]
[same as prior period, unchanged from 0000858877-23-000013:mdna:151]

[0000858877-23-000031:mdna:174]
[same as prior period, unchanged from 0000858877-23-000013:mdna:215]

[0000858877-23-000031:mdna:175]
[same as prior period, unchanged from 0000858877-23-000013:mdna:216]

[0000858877-23-000031:mdna:176]
[same as prior period, unchanged from 0000858877-23-000013:mdna:240]

[0000858877-23-000031:mdna:177]
[same as prior period, unchanged from 0000858877-23-000013:mdna:241]

[0000858877-23-000031:mdna:178]
[same as prior period, unchanged from 0000858877-23-000013:mdna:242]

[0000858877-23-000031:mdna:179]
[same as prior period, unchanged from 0000858877-23-000013:mdna:243]

[0000858877-23-000031:mdna:180]
|  | October 28,2023 |  | July 29,2023 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 9,602 |  |  | $ | 10,123 |  |  | $ | (521) |  |
| Available-for-sale debt investments | 13,512 |  |  | 15,592 |  |  | (2,080) |  |
| Marketable equity securities | 409 |  |  | 431 |  |  | (22) |  |
| Total | $ | 23,523 |  |  | $ | 26,146 |  |  | $ | (2,623) |  |

[0000858877-23-000031:mdna:181]
The net decrease in cash and cash equivalents and investments in the first quarter of fiscal 2024 was primarily driven by cash returned to stockholders in the form of cash dividends of $1.6 billion and repurchases of common stock of $1.3 billion, net cash paid for acquisitions and divestitures of $0.9 billion, a net decrease of debt of $0.8 billion and capital expenditures of $0.1 billion. These uses of cash were partially offset by net cash provided by operating activities of $2.4 billion. The net cash provided by operating activities for the first quarter of fiscal 2024 includes a fiscal 2023 federal tax payment of $2.8 billion that was deferred by the IRS as a result of the California floods.

[0000858877-23-000031:mdna:182]
In addition to cash requirements in the normal course of business, on September 21, 2023, we announced our intent to acquire Splunk. Under the terms of the agreement, we have agreed to pay $157 per share in cash, representing approximately $28 billion in equity value. See further discussion of liquidity and future payments under “Liquidity and Capital Resource Requirements” below.

[0000858877-23-000031:mdna:183]
[same as prior period, unchanged from 0000858877-23-000013:mdna:247]

[0000858877-23-000031:mdna:184]
Securities Lending   We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 28, 2023 and July 29, 2023, we had no outstanding securities lending transactions.

[0000858877-23-000031:mdna:185]
[same as prior period, unchanged from 0000858877-23-000013:mdna:249]

[0000858877-23-000031:mdna:186]
[same as prior period, unchanged from 0000858877-23-000013:mdna:250]

[0000858877-23-000031:mdna:187]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |
| Net cash provided by operating activities | $ | 2,371 |  |  | $ | 3,962 |  |
| Acquisition of property and equipment | (134) |  |  | (176) |  |
| Free cash flow | $ | 2,237 |  |  | $ | 3,786 |  |

[0000858877-23-000031:mdna:188]
[same as prior period, unchanged from 0000858877-23-000013:mdna:234]

[0000858877-23-000031:mdna:189]
[same as prior period, unchanged from 0000858877-23-000013:mdna:235]

[0000858877-23-000031:mdna:190]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue, and the timing and amount of tax and other payments. We will pay approximately $1.4 billion of the U.S. transition tax in the second quarter of fiscal 2024. For additional discussion, see “Part II, Item 1A. Risk Factors” in this report.

[0000858877-23-000031:mdna:191]
[same as prior period, unchanged from 0000858877-23-000013:mdna:255]

[0000858877-23-000031:mdna:192]
[same as prior period, unchanged from 0000858877-23-000013:mdna:256]

[0000858877-23-000031:mdna:193]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| October 28, 2023 |  | $ | 0.39 |  |  | $ | 1,580 |  |  | 23 |  |  | $ | 54.53 |  |  | $ | 1,252 |  |  | $ | 2,832 |  |
| Fiscal 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 29, 2023 |  | $ | 0.39 |  |  | $ | 1,589 |  |  | 25 |  |  | $ | 50.49 |  |  | $ | 1,254 |  |  | $ | 2,843 |  |
| April 29, 2023 |  | $ | 0.39 |  |  | $ | 1,593 |  |  | 25 |  |  | $ | 49.45 |  |  | $ | 1,259 |  |  | $ | 2,852 |  |
| January 28, 2023 |  | $ | 0.38 |  |  | $ | 1,560 |  |  | 26 |  |  | $ | 47.72 |  |  | $ | 1,256 |  |  | $ | 2,816 |  |
| October 29, 2022 |  | $ | 0.38 |  |  | $ | 1,560 |  |  | 12 |  |  | $ | 43.76 |  |  | $ | 502 |  |  | $ | 2,062 |  |

[0000858877-23-000031:mdna:194]
On November 15, 2023, our Board of Directors declared a quarterly dividend of $0.39 per common share to be paid on January 24, 2024, to all stockholders of record as of the close of business on January 4, 2024. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-23-000031:mdna:195]
The remaining authorized amount for stock repurchases under this program is approximately $9.7 billion, with no termination date.

[0000858877-23-000031:mdna:196]
[same as prior period, unchanged from 0000858877-23-000013:mdna:260]

[0000858877-23-000031:mdna:197]
|  | October 28,2023 |  | July 29,2023 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,833 |  |  | $ | 5,854 |  |  | $ | (1,021) |  |

[0000858877-23-000031:mdna:198]
Our accounts receivable net, as of October 28, 2023 decreased by approximately 17%, as compared with the end of fiscal 2023, primarily due to timing and amount of product and service billings in the first quarter of fiscal 2024 compared with the fourth quarter of fiscal 2023.

[0000858877-23-000031:mdna:199]
[same as prior period, unchanged from 0000858877-23-000013:mdna:238]

[0000858877-23-000031:mdna:200]
[same as prior period, unchanged from 0000858877-23-000013:mdna:239]

[0000858877-23-000031:mdna:201]
[same as prior period, unchanged from 0000858877-23-000013:mdna:265]

[0000858877-23-000031:mdna:202]
|  | October 28,2023 |  | July 29,2023 |  | July 30,2022 |  | Variance vs. July 29, 2023 |  | Variance vs. July 30, 2022 |
| Inventories | $ | 3,342 |  |  | $ | 3,644 |  |  | $ | 2,568 |  |  | $ | (302) |  |  | $ | 774 |  |
| Inventory purchase commitments | $ | 6,504 |  |  | $ | 7,253 |  |  | $ | 12,964 |  |  | $ | (749) |  |  | $ | (6,460) |  |
| Inventory deposits and prepayments | $ | 1,032 |  |  | $ | 1,109 |  |  | $ | 1,484 |  |  | $ | (77) |  |  | $ | (452) |  |

[0000858877-23-000031:mdna:203]
[same as prior period, unchanged from 0000858877-23-000013:mdna:267]

[0000858877-23-000031:mdna:204]
|  | October 28,2023 |  | July 29,2023 |  | July 30,2022 |  | Variance vs. July 29, 2023 |  | Variance vs.July 30, 2022 |
| Less than 1 year | $ | 4,731 |  |  | $ | 5,270 |  |  | $ | 9,954 |  |  | $ | (539) |  |  | $ | (5,223) |  |
| 1 to 3 years | 1,646 |  |  | 1,783 |  |  | 2,240 |  |  | (137) |  |  | (594) |  |
| 3 to 5 years | 127 |  |  | 200 |  |  | 770 |  |  | (73) |  |  | (643) |  |
| Total | $ | 6,504 |  |  | $ | 7,253 |  |  | $ | 12,964 |  |  | $ | (749) |  |  | $ | (6,460) |  |

[0000858877-23-000031:mdna:205]
Inventory as of October 28, 2023 decreased by 8% and inventory purchase commitments with contract manufacturers and suppliers decreased by 10% from our balances at the end of fiscal 2023. The combined decrease of 10% in our inventory and inventory purchase commitments as compared with the end of fiscal 2023 was primarily due to fulfillment of customer demand as overall supply constraints improved and our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitment levels.

[0000858877-23-000031:mdna:206]
We increased our balances in prior fiscal years in order to address significant supply constraints seen industry-wide. The increases were primarily due to arrangements to secure supply and pricing for certain product components and commitments with contract manufacturers to meet customer demand and to address extended lead times, as well as advance payments with suppliers to secure future supply, as a result of the supply constraints. As discussed, our risks of future material excess and obsolete inventory and related losses are further outlined in the Result of Operations—Product Gross Margin section.

[0000858877-23-000031:mdna:207]
[same as prior period, unchanged from 0000858877-23-000013:mdna:271]

[0000858877-23-000031:mdna:208]
[same as prior period, unchanged from 0000858877-23-000013:mdna:272]

[0000858877-23-000031:mdna:209]
[same as prior period, unchanged from 0000858877-23-000013:mdna:273]

[0000858877-23-000031:mdna:210]
[same as prior period, unchanged from 0000858877-23-000013:mdna:274]

[0000858877-23-000031:mdna:211]
|  | October 28,2023 |  | July 29,2023 |  | Increase (Decrease) |
| Loan receivables, net | $ | 5,671 |  |  | $ | 5,857 |  |  | $ | (186) |  |
| Lease receivables, net | 1,067 |  |  | 978 |  |  | 89 |  |
| Total, net | $ | 6,738 |  |  | $ | 6,835 |  |  | $ | (97) |  |

[0000858877-23-000031:mdna:212]
Financing Receivables  Our financing arrangements include loans and leases. Our loan receivables include customer financing for purchases of our hardware, software and services (including technical support and advanced services), and also may include

[0000858877-23-000031:mdna:213]
[same as prior period, unchanged from 0000858877-23-000013:mdna:252]

[0000858877-23-000031:mdna:214]
[same as prior period, unchanged from 0000858877-23-000013:mdna:253]

[0000858877-23-000031:mdna:215]
additional funds for other costs associated with network installation and integration of our products and services. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Financing receivables decreased by 1%, as compared with the end of fiscal 2023.

[0000858877-23-000031:mdna:216]
[same as prior period, unchanged from 0000858877-23-000013:mdna:279]

[0000858877-23-000031:mdna:217]
The volume of channel partner financing was $8.2 billion and $7.6 billion for the first quarter of fiscal 2024 and 2023, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.5 billion and $1.7 billion as of October 28, 2023 and July 29, 2023, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of October 28, 2023, the total maximum potential future payments related to these guarantees was approximately $142 million, of which approximately $29 million was recorded as deferred revenue.

[0000858877-23-000031:mdna:218]
[same as prior period, unchanged from 0000858877-23-000013:mdna:281]

[0000858877-23-000031:mdna:219]
[same as prior period, unchanged from 0000858877-23-000013:mdna:282]

[0000858877-23-000031:mdna:220]
|  | Maturity Date |  | October 28,2023 |  | July 29,2023 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | $ | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 7,750 |  |  | $ | 8,500 |  |

[0000858877-23-000031:mdna:221]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of October 28, 2023.

[0000858877-23-000031:mdna:222]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of October 28, 2023 and July 29, 2023.

[0000858877-23-000031:mdna:223]
Credit Facility  On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of October 28, 2023, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement. On April 18, 2023, we entered into an amendment to the credit agreement to replace the LIBOR index with Term SOFR.

[0000858877-23-000031:mdna:224]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) Term SOFR (plus a 0.10% credit spread adjustment) or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) Term SOFR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%.

[0000858877-23-000031:mdna:225]
[same as prior period, unchanged from 0000858877-23-000013:mdna:263]

[0000858877-23-000031:mdna:226]
[same as prior period, unchanged from 0000858877-23-000013:mdna:264]

[0000858877-23-000031:mdna:227]
We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

[0000858877-23-000031:mdna:228]
[same as prior period, unchanged from 0000858877-23-000013:mdna:291]

[0000858877-23-000031:mdna:229]
|  | October 28,2023 |  | July 29,2023 |  | Increase (Decrease) |
| Product | $ | 16,011 |  |  | $ | 15,802 |  |  | $ | 209 |  |
| Service | 18,742 |  |  | 19,066 |  |  | (324) |  |
| Total | $ | 34,753 |  |  | $ | 34,868 |  |  | $ | (115) |  |
| Short-term RPO | $ | 17,617 |  |  | $ | 17,910 |  |  | $ | (293) |  |
| Long-term RPO | 17,136 |  |  | 16,958 |  |  | 178 |  |
| Total | $ | 34,753 |  |  | $ | 34,868 |  |  | $ | (115) |  |

[0000858877-23-000031:mdna:230]
Total remaining performance obligations as of October 28, 2023 were flat compared to the end of fiscal 2023. Remaining performance obligations for product increased by 1% compared to the end of fiscal 2023. Remaining performance obligations for service decreased by 2%. We expect approximately 51% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-23-000031:mdna:231]
[same as prior period, unchanged from 0000858877-23-000013:mdna:294]

[0000858877-23-000031:mdna:232]
|  | October 28,2023 |  | July 29,2023 |  | Increase (Decrease) |
| Product | $ | 11,689 |  |  | $ | 11,505 |  |  | $ | 184 |  |
| Service | 13,970 |  |  | 14,045 |  |  | (75) |  |
| Total | $ | 25,659 |  |  | $ | 25,550 |  |  | $ | 109 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 13,812 |  |  | $ | 13,908 |  |  | $ | (96) |  |
| Noncurrent | 11,847 |  |  | 11,642 |  |  | 205 |  |
| Total | $ | 25,659 |  |  | $ | 25,550 |  |  | $ | 109 |  |

[0000858877-23-000031:mdna:233]
Total deferred revenue was flat compared to the end of fiscal 2023. The increase in deferred product revenue of 2% was primarily due to increased deferrals related to our recurring software offerings. The decrease in deferred service revenue of 1% was driven by the impact of ongoing amortization of deferred service revenue.

[0000858877-23-000031:mdna:234]
[same as prior period, unchanged from 0000858877-23-000013:mdna:297]

[0000858877-23-000031:mdna:235]
[same as prior period, unchanged from 0000858877-23-000013:mdna:298]

[0000858877-23-000031:mdna:236]
The income tax payable outstanding as of October 28, 2023 for the U.S. transition tax on accumulated earnings for foreign subsidiaries was $5.5 billion. Approximately $1.4 billion is payable in less than one year and $4.1 billion is payable between 1 to 3 years.

[0000858877-23-000031:mdna:237]
For our Contractual Obligations see our Annual Report on Form 10-K for the fiscal year ended July 29, 2023.

[0000858877-23-000031:mdna:238]
[same as prior period, unchanged from 0000858877-23-000013:mdna:276]

[0000858877-23-000031:mdna:239]
[same as prior period, unchanged from 0000858877-23-000013:mdna:277]

[0000858877-23-000031:mdna:240]
[same as prior period, unchanged from 0000858877-23-000013:mdna:303]

[0000858877-23-000031:mdna:241]
[same as prior period, unchanged from 0000858877-23-000013:mdna:304]

[0000858877-23-000031:mdna:242]
We also have certain funding commitments primarily related to our privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion as of each of October 28, 2023 and July 29, 2023.

[0000858877-23-000031:mdna:243]
In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of October 28, 2023 there were no material unconsolidated variable interest entities.

[0000858877-23-000031:mdna:244]
[same as prior period, unchanged from 0000858877-23-000013:mdna:307]

[0000858877-23-000031:mdna:245]
[same as prior period, unchanged from 0000858877-23-000013:mdna:308]

[0000858877-23-000031:mdna:246]
[same as prior period, unchanged from 0000858877-23-000013:mdna:309]

[0000858877-23-000031:mdna:247]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs (including inventory and other supply related payments), capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. We recently announced our intent to acquire Splunk. Under the terms of the agreement, we have agreed to pay $157 per share in cash, representing approximately $28 billion in equity value. We anticipate this transaction will be financed with a combination of cash and debt. The acquisition is expected to close by the end of the third quarter of calendar year 2024, subject to regulatory approval and other customary closing conditions, including approval by Splunk shareholders. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.
