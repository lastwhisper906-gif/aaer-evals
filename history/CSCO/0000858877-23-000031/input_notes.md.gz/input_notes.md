# CSCO notes — 0000858877-23-000031


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-23-000031:notes:1]
Organization and Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2024 and fiscal 2023 are each 52-week fiscal years. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-23-000031:notes:2]
We have prepared the accompanying financial data as of October 28, 2023 and for the first quarter of fiscal 2024 and 2023, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 29, 2023 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 29, 2023.

[0000858877-23-000031:notes:3]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of October 28, 2023, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2024 and 2023, as applicable, have been made. The results of operations for the first quarter of fiscal 2024 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-23-000031:notes:4]
[same as prior period, unchanged from 0000858877-23-000013:notes:4]

[0000858877-23-000031:notes:5]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-23-000031:notes:6]
Recent Accounting PronouncementsThere have been no recent accounting pronouncements issued that we believe will have a material impact on our Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-23-000031:notes:7]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

[0000858877-23-000031:notes:8]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized

[0000858877-23-000031:notes:9]
upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-23-000031:notes:10]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 28, 2023 and July 29, 2023 was $37 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-23-000031:notes:11]
[same as prior period, unchanged from 0000858877-23-000013:notes:10]

[0000858877-23-000031:notes:12]
[same as prior period, unchanged from 0000858877-23-000013:notes:11]

[0000858877-23-000031:notes:13]
[same as prior period, unchanged from 0000858877-23-000013:notes:12]

[0000858877-23-000031:notes:14]
[same as prior period, unchanged from 0000858877-23-000013:notes:13]

[0000858877-23-000031:notes:15]
[same as prior period, unchanged from 0000858877-23-000013:notes:14]

[0000858877-23-000031:notes:16]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. Effective in the first quarter of fiscal 2024, we began reporting our product and service revenue in the following categories: Networking, Security, Collaboration, Observability, and Services and conformed our product revenue for prior periods to the current period presentation. The following table presents this disaggregation of revenue (in millions):

[0000858877-23-000031:notes:17]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |
| Product revenue: |  |  |  |
| Networking | $ | 8,822 |  |  | $ | 8,031 |  |
| Security | 1,010 |  |  | 971 |  |
| Collaboration | 1,117 |  |  | 1,086 |  |
| Observability | 190 |  |  | 157 |  |
| Total Product | 11,139 |  |  | 10,245 |  |
| Services | 3,529 |  |  | 3,387 |  |
| Total | $ | 14,668 |  |  | $ | 13,632 |  |

[0000858877-23-000031:notes:18]
Amounts may not sum due to rounding.

[0000858877-23-000031:notes:19]
Networking consists of our core networking technologies of switching, routing, wireless, 5G, silicon, optics solutions and compute products. These technologies consist of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-23-000031:notes:20]
Security consists of our Cloud and Application Security, Industrial Security, Network Security, and User and Device Security offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-23-000031:notes:21]
[same as prior period, unchanged from 0000858877-23-000013:notes:20]

[0000858877-23-000031:notes:22]
Observability consists of our full stack observability offerings. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-23-000031:notes:23]
[same as prior period, unchanged from 0000858877-23-000013:notes:23]

[0000858877-23-000031:notes:24]
[same as prior period, unchanged from 0000858877-23-000013:notes:24]

[0000858877-23-000031:notes:25]
[same as prior period, unchanged from 0000858877-23-000013:notes:25]

[0000858877-23-000031:notes:26]
[same as prior period, unchanged from 0000858877-23-000013:notes:26]

[0000858877-23-000031:notes:27]
Accounts receivable, net was $4.8 billion as of October 28, 2023 compared to $5.9 billion as of July 29, 2023, as reported on the Consolidated Balance Sheets.

[0000858877-23-000031:notes:28]
[same as prior period, unchanged from 0000858877-23-000013:notes:28]

[0000858877-23-000031:notes:29]
|  | Three Months Ended |
|  | October 28, 2023 |  | October 29, 2022 |
| Allowance for credit loss at beginning of period | $ | 85 |  |  | $ | 83 |  |
| Provisions (benefits) | 2 |  |  | 11 |  |
| Recoveries (write-offs), net | (5) |  |  | (6) |  |
| Allowance for credit loss at end of period | $ | 82 |  |  | $ | 88 |  |

[0000858877-23-000031:notes:30]
[same as prior period, unchanged from 0000858877-23-000013:notes:30]

[0000858877-23-000031:notes:31]
[same as prior period, unchanged from 0000858877-23-000013:notes:31]

[0000858877-23-000031:notes:32]
|  | October 28,2023 |  | July 29,2023 |
| 1 to 4 | $ | 650 |  |  | $ | 672 |  |
| 5 to 6 | 1,015 |  |  | 954 |  |
| 7 and Higher | 68 |  |  | 60 |  |
| Total | $ | 1,733 |  |  | $ | 1,686 |  |

[0000858877-23-000031:notes:33]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of October 28, 2023 and July 29, 2023, our contract assets for these unbilled receivables, net of allowances, were $1.7 billion and $1.6 billion, respectively, and were included in other current assets and other assets.

[0000858877-23-000031:notes:34]
Contract liabilities consist of deferred revenue. Deferred revenue was $25.7 billion as of October 28, 2023 compared to $25.6 billion as of July 29, 2023. We recognized approximately $4.7 billion of revenue during the first quarter of fiscal 2024 that was included in the deferred revenue balance at July 29, 2023.

[0000858877-23-000031:notes:35]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Capitalized contract acquisition costs were $1.2 billion and $1.1 billion as of October 28, 2023 and July 29, 2023, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $158 million and $176 million for the first quarter of fiscal 2024 and 2023, respectively, and was included in sales and marketing expenses.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-23-000031:notes:36]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-23-000031:notes:37]
[same as prior period, unchanged from 0000858877-23-000013:notes:36]

[0000858877-23-000031:notes:38]
[same as prior period, unchanged from 0000858877-23-000013:notes:37]

[0000858877-23-000031:notes:39]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |
| Revenue: |  |  |  |
| Networking | $ | 8,822 |  |  | $ | 8,031 |  |
| Security | 1,010 |  |  | 971 |  |
| Collaboration | 1,117 |  |  | 1,086 |  |
| Observability | 190 |  |  | 157 |  |
| Total Product | 11,139 |  |  | 10,245 |  |
| Services | 3,529 |  |  | 3,387 |  |
| Total | $ | 14,668 |  |  | $ | 13,632 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-23-000031:notes:40]
Acquisitions and Divestitures
A summary of the allocation of the total purchase consideration of our completed acquisitions during the first quarter of fiscal 2024 is presented as follows (in millions):

[0000858877-23-000031:notes:41]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions | $ | 896 |  |  | $ | (73) |  |  | $ | 354 |  |  | $ | 615 |  |

[0000858877-23-000031:notes:42]
The total purchase consideration related to our acquisitions completed during the first quarter of fiscal 2024 consisted primarily of cash consideration. The total cash and cash equivalents acquired from these acquisitions was approximately $16 million. Total transaction costs related to acquisition and divestiture activities were $31 million and $2 million for the first quarter of fiscal 2024 and 2023, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-23-000031:notes:43]
The purchase price allocation for acquisitions completed during recent periods is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information that existed as of the acquisition date but at that time was unknown to us may become known during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date.

[0000858877-23-000031:notes:44]
The goodwill generated from acquisitions completed during the first quarter of fiscal 2024 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-23-000031:notes:45]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first quarter of fiscal 2024 have not been presented because the effects of the acquisitions were not material to our financial results.
Intent to Acquire Splunk     On September 21, 2023, we announced our intent to acquire Splunk Inc. (“Splunk”), a public cybersecurity and observability company. Under the terms of the agreement, we have agreed to pay $157 per share in cash, representing approximately $28 billion in equity value. The acquisition is expected to close by the end of the third quarter of calendar year 2024, subject to regulatory approval and other customary closing conditions, including approval by Splunk shareholders. We anticipate this transaction will be financed with a combination of cash and debt.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-23-000031:notes:46]
[same as prior period, unchanged from 0000858877-23-000013:notes:44]

[0000858877-23-000031:notes:47]
The following table presents the goodwill allocated to our reportable segments as of October 28, 2023 and during the first quarter of fiscal 2024 (in millions):

[0000858877-23-000031:notes:48]
|  | Balance at July 29, 2023 |  | Acquisitions |  | Foreign Currency Translation and Other |  | Balance at October 28, 2023 |
| Americas | $ | 24,035 |  |  | $ | 381 |  |  | $ | (156) |  |  | $ | 24,260 |  |
| EMEA | 9,118 |  |  | 126 |  |  | (59) |  |  | 9,185 |  |
| APJC | 5,382 |  |  | 108 |  |  | (35) |  |  | 5,455 |  |
| Total | $ | 38,535 |  |  | $ | 615 |  |  | $ | (250) |  |  | $ | 38,900 |  |

[0000858877-23-000031:notes:49]
[same as prior period, unchanged from 0000858877-23-000013:notes:47]

[0000858877-23-000031:notes:50]
The following table presents details of our intangible assets acquired through acquisitions completed during the first quarter of fiscal 2024 (in millions, except years):

[0000858877-23-000031:notes:51]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions | 4.8 |  | $ | 280 |  |  | 4.8 |  | $ | 58 |  |  | 1.0 |  | $ | 2 |  |  | $ | 14 |  |  | $ | 354 |  |

[0000858877-23-000031:notes:52]
[same as prior period, unchanged from 0000858877-23-000013:notes:50]

[0000858877-23-000031:notes:53]
| October 28, 2023 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,051 |  |  | $ | (1,654) |  |  | $ | 1,397 |  |
| Customer relationships |  | 1,186 |  |  | (870) |  |  | 316 |  |
| Other |  | 42 |  |  | (25) |  |  | 17 |  |
| Total purchased intangible assets with finite lives |  | 4,279 |  |  | (2,549) |  |  | 1,730 |  |
| In-process research and development, with indefinite lives |  | 184 |  |  | — |  |  | 184 |  |
| Total |  | $ | 4,463 |  |  | $ | (2,549) |  |  | $ | 1,914 |  |

[0000858877-23-000031:notes:54]
| July 29, 2023 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 2,998 |  |  | $ | (1,691) |  |  | $ | 1,307 |  |
| Customer relationships |  | 1,228 |  |  | (905) |  |  | 323 |  |
| Other |  | 40 |  |  | (22) |  |  | 18 |  |
| Total purchased intangible assets with finite lives |  | 4,266 |  |  | (2,618) |  |  | 1,648 |  |
| In-process research and development, with indefinite lives |  | 170 |  |  | — |  |  | 170 |  |
| Total |  | $ | 4,436 |  |  | $ | (2,618) |  |  | $ | 1,818 |  |

[0000858877-23-000031:notes:55]
[same as prior period, unchanged from 0000858877-23-000013:notes:53]

[0000858877-23-000031:notes:56]
[same as prior period, unchanged from 0000858877-23-000013:notes:54]

[0000858877-23-000031:notes:57]
|  | Three Months Ended |
|  | October 28, 2023 |  | October 29, 2022 |
| Amortization of purchased intangible assets: |  |  |  |
| Cost of sales | $ | 186 |  |  | $ | 158 |  |
| Operating expenses | 67 |  |  | 71 |  |
| Total | $ | 253 |  |  | $ | 229 |  |

[0000858877-23-000031:notes:58]
The estimated future amortization expense of purchased intangible assets with finite lives as of October 28, 2023 is as follows (in millions):

[0000858877-23-000031:notes:59]
| Fiscal Year | Amount |
| 2024 (remaining nine months) | $ | 684 |  |
| 2025 | $ | 573 |  |
| 2026 | $ | 225 |  |
| 2027 | $ | 140 |  |
| 2028 | $ | 98 |  |
| Thereafter | $ | 10 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-23-000031:notes:60]
Restructuring and Other Charges
In the second quarter of fiscal 2023, we announced a restructuring plan (the “Fiscal 2023 Plan”) in order to rebalance the organization and enable further investment in key priority areas, of which approximately 5% of the global workforce would be impacted. This rebalancing includes talent movement options and restructuring. Additionally, we began optimizing our real estate portfolio, aligned to the broader hybrid work strategy. In connection with the Fiscal 2023 Plan, we incurred charges of $123 million for the first quarter of fiscal 2024 and have incurred cumulative charges of $658 million to date. These aggregate pretax charges are primarily cash-based and consist of severance and other one-time termination benefits, real estate-related charges, and other costs. We have substantially completed the Fiscal 2023 Plan in the first quarter of fiscal 2024.

[0000858877-23-000031:notes:61]
The following table summarizes the activities related to the Fiscal 2023 Plan (in millions):

[0000858877-23-000031:notes:62]
|  |  | FISCAL 2023 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 29, 2023 |  | $ | 166 |  |  | $ | 44 |  |  | $ | 210 |  |
| Charges |  | 103 |  |  | 20 |  |  | 123 |  |
| Cash payments |  | (99) |  |  | (6) |  |  | (105) |  |
| Non-cash items |  | (2) |  |  | (11) |  |  | (13) |  |
| Liability as of October 28, 2023 |  | $ | 168 |  |  | $ | 47 |  |  | $ | 215 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-23-000031:notes:63]
[same as prior period, unchanged from 0000858877-23-000013:notes:62]

[0000858877-23-000031:notes:64]
[same as prior period, unchanged from 0000858877-23-000013:notes:63]

[0000858877-23-000031:notes:65]
|  |  | October 28,2023 |  | July 29,2023 |
| Cash and cash equivalents |  | $ | 9,602 |  |  | $ | 10,123 |  |
| Restricted cash and restricted cash equivalents included in other current assets |  | 378 |  |  | 191 |  |
| Restricted cash and restricted cash equivalents included in other assets |  | 1,125 |  |  | 1,313 |  |
| Total |  | $ | 11,105 |  |  | $ | 11,627 |  |

[0000858877-23-000031:notes:66]
[same as prior period, unchanged from 0000858877-23-000013:notes:65]

[0000858877-23-000031:notes:67]
[same as prior period, unchanged from 0000858877-23-000013:notes:66]

[0000858877-23-000031:notes:68]
|  |  | October 28,2023 |  | July 29,2023 |
| Raw materials |  | $ | 1,854 |  |  | $ | 1,685 |  |
| Work in process |  | 194 |  |  | 264 |  |
| Finished goods |  | 1,093 |  |  | 1,493 |  |
| Service-related spares |  | 188 |  |  | 186 |  |
| Demonstration systems |  | 13 |  |  | 16 |  |
| Total |  | $ | 3,342 |  |  | $ | 3,644 |  |

[0000858877-23-000031:notes:69]
[same as prior period, unchanged from 0000858877-23-000013:notes:68]

[0000858877-23-000031:notes:70]
|  |  | October 28,2023 |  | July 29,2023 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,194 |  |  | $ | 4,229 |  |
| Computer equipment and related software |  | 682 |  |  | 744 |  |
| Production, engineering, and other equipment |  | 4,465 |  |  | 4,611 |  |
| Operating lease assets |  | 123 |  |  | 135 |  |
| Furniture, fixtures and other |  | 338 |  |  | 339 |  |
| Total gross property and equipment |  | 9,802 |  |  | 10,058 |  |
| Less: accumulated depreciation and amortization |  | (7,798) |  |  | (7,973) |  |
| Total |  | $ | 2,004 |  |  | $ | 2,085 |  |

[0000858877-23-000031:notes:71]
[same as prior period, unchanged from 0000858877-23-000013:notes:70]

[0000858877-23-000031:notes:72]
|  |  | October 28,2023 |  | July 29,2023 |
| Product |  | $ | 16,011 |  |  | $ | 15,802 |  |
| Service |  | 18,742 |  |  | 19,066 |  |
| Total |  | $ | 34,753 |  |  | $ | 34,868 |  |
| Short-term RPO |  | $ | 17,617 |  |  | $ | 17,910 |  |
| Long-term RPO |  | 17,136 |  |  | 16,958 |  |
| Total |  | $ | 34,753 |  |  | $ | 34,868 |  |
| Amount to be recognized as revenue over the next 12 months |  | 51 | % |  | 51 | % |
| Deferred revenue |  | $ | 25,659 |  |  | $ | 25,550 |  |
| Unbilled contract revenue |  | 9,094 |  |  | 9,318 |  |
| Total |  | $ | 34,753 |  |  | $ | 34,868 |  |

[0000858877-23-000031:notes:73]
[same as prior period, unchanged from 0000858877-23-000013:notes:72]

[0000858877-23-000031:notes:74]
[same as prior period, unchanged from 0000858877-23-000013:notes:73]

[0000858877-23-000031:notes:75]
|  |  | October 28,2023 |  | July 29,2023 |
| Product |  | $ | 11,689 |  |  | $ | 11,505 |  |
| Service |  | 13,970 |  |  | 14,045 |  |
| Total |  | $ | 25,659 |  |  | $ | 25,550 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 13,812 |  |  | $ | 13,908 |  |
| Noncurrent |  | 11,847 |  |  | 11,642 |  |
| Total |  | $ | 25,659 |  |  | $ | 25,550 |  |

[0000858877-23-000031:notes:76]
[same as prior period, unchanged from 0000858877-23-000013:notes:75]

[0000858877-23-000031:notes:77]
[same as prior period, unchanged from 0000858877-23-000013:notes:76]

[0000858877-23-000031:notes:78]
|  |  | October 28,2023 |  | July 29,2023 |
| Current |  | $ | 1,364 |  |  | $ | 1,364 |  |
| Noncurrent |  | 4,092 |  |  | 4,092 |  |
| Total |  | $ | 5,456 |  |  | $ | 5,456 |  |


## us-gaap:OperatingLeasesOfLessorDisclosureTextBlock

[0000858877-23-000031:notes:79]
Leases 
(a)Lessee Arrangements

[0000858877-23-000031:notes:80]
The following table presents our operating lease balances (in millions):

[0000858877-23-000031:notes:81]
|  | Balance Sheet Line Item |  | October 28, 2023 |  | July 29, 2023 |
| Operating lease right-of-use assets | Other assets |  | $ | 997 |  |  | $ | 971 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 302 |  |  | $ | 313 |  |
| Operating lease liabilities | Other long-term liabilities |  | 741 |  |  | 707 |  |
| Total operating lease liabilities |  |  | $ | 1,043 |  |  | $ | 1,020 |  |

[0000858877-23-000031:notes:82]
The components of our lease expenses were as follows (in millions):

[0000858877-23-000031:notes:83]
|  | Three Months Ended |
|  | October 28, 2023 |  | October 29, 2022 |
| Operating lease expense | $ | 100 |  |  | $ | 96 |  |
| Short-term lease expense | 11 |  |  | 17 |  |
| Variable lease expense | 56 |  |  | 58 |  |
| Total lease expense | $ | 167 |  |  | $ | 171 |  |

[0000858877-23-000031:notes:84]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-23-000031:notes:85]
|  | Three Months Ended |
|  | October 28, 2023 |  | October 29, 2022 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 88 |  |  | $ | 96 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 126 |  |  | $ | 35 |  |

[0000858877-23-000031:notes:86]
The weighted-average lease term was 4.8 years and 4.6 years as of October 28, 2023 and July 29, 2023, respectively. The weighted-average discount rate was 3.5% and 3.1% as of October 28, 2023 and July 29, 2023, respectively.

[0000858877-23-000031:notes:87]
The maturities of our operating leases (undiscounted) as of October 28, 2023 are as follows (in millions):

[0000858877-23-000031:notes:88]
| Fiscal Year | Amount |
| 2024 (remaining nine months) | $ | 258 |  |
| 2025 | 278 |  |
| 2026 | 189 |  |
| 2027 | 116 |  |
| 2028 | 88 |  |
| Thereafter | 227 |  |
| Total lease payments | 1,156 |  |
| Less interest | (113) |  |
| Total | $ | 1,043 |  |

[0000858877-23-000031:notes:89]
(b)Lessor Arrangements

[0000858877-23-000031:notes:90]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income was $14 million and $12 million for the first quarter of fiscal 2024 and 2023, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-23-000031:notes:91]
Future minimum lease payments on our lease receivables as of October 28, 2023 are summarized as follows (in millions):

[0000858877-23-000031:notes:92]
| Fiscal Year | Amount |
| 2024 (remaining nine months) | $ | 433 |  |
| 2025 | 166 |  |
| 2026 | 182 |  |
| 2027 | 160 |  |
| 2028 | 126 |  |
| Thereafter | 45 |  |
| Total | 1,112 |  |
| Less: Present value of lease payments | (1,015) |  |
| Unearned income | $ | 97 |  |

[0000858877-23-000031:notes:93]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-23-000031:notes:94]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-23-000031:notes:95]
|  | October 28, 2023 |  | July 29, 2023 |
| Operating lease assets | $ | 123 |  |  | $ | 135 |  |
| Accumulated depreciation | (72) |  |  | (78) |  |
| Operating lease assets, net | $ | 51 |  |  | $ | 57 |  |

[0000858877-23-000031:notes:96]
Our operating lease income was $16 million and $21 million for the first quarter of fiscal 2024 and 2023, respectively, and was included in product revenue in the Consolidated Statements of Operations.

[0000858877-23-000031:notes:97]
Minimum future rentals on noncancelable operating leases as of October 28, 2023 are summarized as follows (in millions):

[0000858877-23-000031:notes:98]
| Fiscal Year | Amount |
| 2024 (remaining nine months) | $ | 18 |  |
| 2025 | 12 |  |
| 2026 | 6 |  |
| Total | $ | 36 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-23-000031:notes:99]
[same as prior period, unchanged from 0000858877-23-000013:notes:98]

[0000858877-23-000031:notes:100]
[same as prior period, unchanged from 0000858877-23-000013:notes:99]

[0000858877-23-000031:notes:101]
[same as prior period, unchanged from 0000858877-23-000013:notes:100]

[0000858877-23-000031:notes:102]
| October 28, 2023 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,729 |  |  | $ | 1,112 |  |  | $ | 6,841 |  |
| Residual value | — |  |  | 68 |  |  | 68 |  |
| Unearned income | — |  |  | (97) |  |  | (97) |  |
| Allowance for credit loss | (58) |  |  | (16) |  |  | (74) |  |
| Total, net | $ | 5,671 |  |  | $ | 1,067 |  |  | $ | 6,738 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 2,986 |  |  | $ | 428 |  |  | $ | 3,414 |  |
| Noncurrent | 2,685 |  |  | 639 |  |  | 3,324 |  |
| Total, net | $ | 5,671 |  |  | $ | 1,067 |  |  | $ | 6,738 |  |

[0000858877-23-000031:notes:103]
| July 29, 2023 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,910 |  |  | $ | 1,015 |  |  | $ | 6,925 |  |
| Residual value | — |  |  | 70 |  |  | 70 |  |
| Unearned income | — |  |  | (88) |  |  | (88) |  |
| Allowance for credit loss | (53) |  |  | (19) |  |  | (72) |  |
| Total, net | $ | 5,857 |  |  | $ | 978 |  |  | $ | 6,835 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 2,988 |  |  | $ | 364 |  |  | $ | 3,352 |  |
| Noncurrent | 2,869 |  |  | 614 |  |  | 3,483 |  |
| Total, net | $ | 5,857 |  |  | $ | 978 |  |  | $ | 6,835 |  |

[0000858877-23-000031:notes:104]
[same as prior period, unchanged from 0000858877-23-000013:notes:103]

[0000858877-23-000031:notes:105]
[same as prior period, unchanged from 0000858877-23-000013:notes:104]

[0000858877-23-000031:notes:106]
| October 28, 2023 |  |  | Fiscal Year |  | Three Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 25, 2020 |  | July 31, 2021 |  | July 30, 2022 |  | July 29, 2023 |  | October 28, 2023 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 40 |  |  | $ | 205 |  |  | $ | 637 |  |  | $ | 910 |  |  | $ | 1,371 |  |  | $ | 543 |  |  | $ | 3,706 |  |
| 5 to 6 | 9 |  |  | 109 |  |  | 193 |  |  | 327 |  |  | 733 |  |  | 513 |  |  | 1,884 |  |
| 7 and Higher | 7 |  |  | 10 |  |  | 15 |  |  | 91 |  |  | 15 |  |  | 1 |  |  | 139 |  |
| Total Loan Receivables | $ | 56 |  |  | $ | 324 |  |  | $ | 845 |  |  | $ | 1,328 |  |  | $ | 2,119 |  |  | $ | 1,057 |  |  | $ | 5,729 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 13 |  |  | $ | 46 |  |  | $ | 99 |  |  | $ | 82 |  |  | $ | 250 |  |  | $ | 111 |  |  | $ | 601 |  |
| 5 to 6 | 9 |  |  | 38 |  |  | 51 |  |  | 85 |  |  | 183 |  |  | 30 |  |  | 396 |  |
| 7 and Higher | 1 |  |  | 2 |  |  | 3 |  |  | 5 |  |  | 5 |  |  | 2 |  |  | 18 |  |
| Total Lease Receivables | $ | 23 |  |  | $ | 86 |  |  | $ | 153 |  |  | $ | 172 |  |  | $ | 438 |  |  | $ | 143 |  |  | $ | 1,015 |  |
| Total | $ | 79 |  |  | $ | 410 |  |  | $ | 998 |  |  | $ | 1,500 |  |  | $ | 2,557 |  |  | $ | 1,200 |  |  | $ | 6,744 |  |

[0000858877-23-000031:notes:107]
| July 29, 2023 |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | July 30, 2022 |  | July 29, 2023 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 10 |  |  | $ | 53 |  |  | $ | 251 |  |  | $ | 791 |  |  | $ | 1,077 |  |  | $ | 1,784 |  |  | $ | 3,966 |  |
| 5 to 6 | 3 |  |  | 14 |  |  | 131 |  |  | 287 |  |  | 465 |  |  | 936 |  |  | 1,836 |  |
| 7 and Higher | 1 |  |  | 7 |  |  | 15 |  |  | 17 |  |  | 29 |  |  | 39 |  |  | 108 |  |
| Total Loan Receivables | $ | 14 |  |  | $ | 74 |  |  | $ | 397 |  |  | $ | 1,095 |  |  | $ | 1,571 |  |  | $ | 2,759 |  |  | $ | 5,910 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 20 |  |  | $ | 57 |  |  | $ | 111 |  |  | $ | 84 |  |  | $ | 235 |  |  | $ | 509 |  |
| 5 to 6 | 2 |  |  | 13 |  |  | 44 |  |  | 58 |  |  | 87 |  |  | 191 |  |  | 395 |  |
| 7 and Higher | — |  |  | 1 |  |  | 2 |  |  | 4 |  |  | 5 |  |  | 11 |  |  | 23 |  |
| Total Lease Receivables | $ | 4 |  |  | $ | 34 |  |  | $ | 103 |  |  | $ | 173 |  |  | $ | 176 |  |  | $ | 437 |  |  | $ | 927 |  |
| Total | $ | 18 |  |  | $ | 108 |  |  | $ | 500 |  |  | $ | 1,268 |  |  | $ | 1,747 |  |  | $ | 3,196 |  |  | $ | 6,837 |  |

[0000858877-23-000031:notes:108]
The following tables present the aging analysis of gross receivables as of October 28, 2023 and July 29, 2023 (in millions):

[0000858877-23-000031:notes:109]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| October 28, 2023 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 73 |  |  | $ | 58 |  |  | $ | 45 |  |  | $ | 176 |  |  | $ | 5,553 |  |  | $ | 5,729 |  |  | $ | 16 |  |  | $ | 12 |  |  | $ | 12 |  |
| Lease receivables | 18 |  |  | 12 |  |  | 15 |  |  | 45 |  |  | 970 |  |  | 1,015 |  |  | 5 |  |  | 2 |  |  | 2 |  |
| Total | $ | 91 |  |  | $ | 70 |  |  | $ | 60 |  |  | $ | 221 |  |  | $ | 6,523 |  |  | $ | 6,744 |  |  | $ | 21 |  |  | $ | 14 |  |  | $ | 14 |  |

[0000858877-23-000031:notes:110]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| July 29, 2023 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 47 |  |  | $ | 20 |  |  | $ | 37 |  |  | $ | 104 |  |  | $ | 5,806 |  |  | $ | 5,910 |  |  | $ | 17 |  |  | $ | 12 |  |  | $ | 12 |  |
| Lease receivables | 16 |  |  | 4 |  |  | 23 |  |  | 43 |  |  | 884 |  |  | 927 |  |  | 6 |  |  | 3 |  |  | 3 |  |
| Total | $ | 63 |  |  | $ | 24 |  |  | $ | 60 |  |  | $ | 147 |  |  | $ | 6,690 |  |  | $ | 6,837 |  |  | $ | 23 |  |  | $ | 15 |  |  | $ | 15 |  |

[0000858877-23-000031:notes:111]
[same as prior period, unchanged from 0000858877-23-000013:notes:110]

[0000858877-23-000031:notes:112]
[same as prior period, unchanged from 0000858877-23-000013:notes:111]

[0000858877-23-000031:notes:113]
[same as prior period, unchanged from 0000858877-23-000013:notes:112]

[0000858877-23-000031:notes:114]
| Three Months Ended October 28, 2023 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 29, 2023 | $ | 53 |  |  | $ | 19 |  |  | $ | 72 |  |
| Provisions (benefits) | 5 |  |  | (3) |  |  | 2 |  |
| Allowance for credit loss as of October 28, 2023 | $ | 58 |  |  | $ | 16 |  |  | $ | 74 |  |

[0000858877-23-000031:notes:115]
| Three Months Ended October 29, 2022 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 30, 2022 | $ | 103 |  |  | $ | 23 |  |  | $ | 126 |  |
| Provisions (benefits) | (1) |  |  | (3) |  |  | (4) |  |
| Other | (1) |  |  | (1) |  |  | (2) |  |
| Allowance for credit loss as of October 29, 2022 | $ | 101 |  |  | $ | 19 |  |  | $ | 120 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-23-000031:notes:116]
Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-23-000031:notes:117]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-23-000031:notes:118]
| October 28, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,596 |  |  | $ | — |  |  | $ | (72) |  |  | $ | 2,524 |  |
| U.S. government agency securities | 421 |  |  | — |  |  | (6) |  |  | 415 |  |
| Non-U.S. government and agency securities | 351 |  |  | — |  |  | — |  |  | 351 |  |
| Corporate debt securities | 6,862 |  |  | 1 |  |  | (363) |  |  | 6,500 |  |
| U.S. agency mortgage-backed securities | 2,431 |  |  | — |  |  | (318) |  |  | 2,113 |  |
| Commercial paper | 943 |  |  | — |  |  | — |  |  | 943 |  |
| Certificates of deposit | 666 |  |  | — |  |  | — |  |  | 666 |  |
| Total | $ | 14,270 |  |  | $ | 1 |  |  | $ | (759) |  |  | $ | 13,512 |  |

[0000858877-23-000031:notes:119]
| July 29, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 3,587 |  |  | $ | 1 |  |  | $ | (62) |  |  | $ | 3,526 |  |
| U.S. government agency securities | 428 |  |  | — |  |  | (5) |  |  | 423 |  |
| Non-U.S. government and agency securities | 364 |  |  | — |  |  | (1) |  |  | 363 |  |
| Corporate debt securities | 7,238 |  |  | 3 |  |  | (327) |  |  | 6,914 |  |
| U.S. agency mortgage-backed securities | 2,421 |  |  | 14 |  |  | (230) |  |  | 2,205 |  |
| Commercial paper | 1,484 |  |  | — |  |  | — |  |  | 1,484 |  |
| Certificates of deposit | 677 |  |  | — |  |  | — |  |  | 677 |  |
| Total | $ | 16,199 |  |  | $ | 18 |  |  | $ | (625) |  |  | $ | 15,592 |  |

[0000858877-23-000031:notes:120]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-23-000031:notes:121]
|  | Three Months Ended |
|  | October 28, 2023 |  | October 29, 2022 |
| Gross realized gains | $ | — |  |  | $ | — |  |
| Gross realized losses | (20) |  |  | (6) |  |
| Total | $ | (20) |  |  | $ | (6) |  |

[0000858877-23-000031:notes:122]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 28, 2023 and July 29, 2023 (in millions):

[0000858877-23-000031:notes:123]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 28, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,844 |  |  | $ | (38) |  |  | $ | 680 |  |  | $ | (34) |  |  | $ | 2,524 |  |  | $ | (72) |  |
| U.S. government agency securities | 377 |  |  | (3) |  |  | 38 |  |  | (3) |  |  | 415 |  |  | (6) |  |
| Non-U.S. government and agency securities | 324 |  |  | — |  |  | — |  |  | — |  |  | 324 |  |  | — |  |
| Corporate debt securities | 1,679 |  |  | (29) |  |  | 4,275 |  |  | (304) |  |  | 5,954 |  |  | (333) |  |
| U.S. agency mortgage-backed securities | 798 |  |  | (45) |  |  | 1,315 |  |  | (273) |  |  | 2,113 |  |  | (318) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Certificates of deposit | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 5,042 |  |  | $ | (115) |  |  | $ | 6,308 |  |  | $ | (614) |  |  | $ | 11,350 |  |  | $ | (729) |  |

[0000858877-23-000031:notes:124]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 2,394 |  |  | $ | (26) |  |  | $ | 931 |  |  | $ | (36) |  |  | $ | 3,325 |  |  | $ | (62) |  |
| U.S. government agency securities | 343 |  |  | (2) |  |  | 72 |  |  | (3) |  |  | 415 |  |  | (5) |  |
| Non-U.S. government and agency securities | 363 |  |  | (1) |  |  | — |  |  | — |  |  | 363 |  |  | (1) |  |
| Corporate debt securities | 1,736 |  |  | (22) |  |  | 4,315 |  |  | (275) |  |  | 6,051 |  |  | (297) |  |
| U.S. agency mortgage-backed securities | 658 |  |  | (13) |  |  | 1,438 |  |  | (217) |  |  | 2,096 |  |  | (230) |  |
| Commercial paper | 97 |  |  | — |  |  | — |  |  | — |  |  | 97 |  |  | — |  |
| Certificates of deposit | 2 |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |
| Total | $ | 5,593 |  |  | $ | (64) |  |  | $ | 6,756 |  |  | $ | (531) |  |  | $ | 12,349 |  |  | $ | (595) |  |

[0000858877-23-000031:notes:125]
The following table summarizes the maturities of our available-for-sale debt investments as of October 28, 2023 (in millions):

[0000858877-23-000031:notes:126]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 4,201 |  |  | $ | 4,152 |  |
| After 1 year through 5 years | 7,627 |  |  | 7,236 |  |
| After 5 years through 10 years | 9 |  |  | 9 |  |
| After 10 years | 2 |  |  | 2 |  |
| Mortgage-backed securities with no single maturity | 2,431 |  |  | 2,113 |  |
| Total | $ | 14,270 |  |  | $ | 13,512 |  |

[0000858877-23-000031:notes:127]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-23-000031:notes:128]
(b)Summary of Equity Investments

[0000858877-23-000031:notes:129]
We held marketable equity securities of $409 million and $431 million as of October 28, 2023 and July 29, 2023, respectively. We recognized a net unrealized loss of $42 million and $20 million during the first quarter of fiscal 2024 and 2023, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $12 million for the first quarter of fiscal 2023. These adjustments were not material for the first quarter of fiscal 2024. We held equity interests in certain private equity funds of $0.9 billion as of each of October 28, 2023 and July 29, 2023, which are accounted for under the NAV practical expedient.

[0000858877-23-000031:notes:130]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 28, 2023, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-23-000031:notes:131]
The carrying value of our investments in privately held companies was $1.8 billion as of each of October 28, 2023 and July 29, 2023. Of the total carrying value of our investments in privately held companies as of October 28, 2023, $0.9 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of October 28, 2023, we have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-23-000031:notes:132]
[same as prior period, unchanged from 0000858877-23-000013:notes:134]

[0000858877-23-000031:notes:133]
[same as prior period, unchanged from 0000858877-23-000013:notes:135]

[0000858877-23-000031:notes:134]
|  | OCTOBER 28, 2023 |  | JULY 29, 2023 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 6,650 |  |  | $ | — |  |  | $ | 6,650 |  |  | $ | 6,496 |  |  | $ | — |  |  | $ | 6,496 |  |
| Commercial paper | — |  |  | 738 |  |  | 738 |  |  | — |  |  | 1,090 |  |  | 1,090 |  |
| Certificates of deposit | — |  |  | 12 |  |  | 12 |  |  | — |  |  | 47 |  |  | 47 |  |
| Corporate debt securities | — |  |  | 16 |  |  | 16 |  |  | — |  |  | 25 |  |  | 25 |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 2,524 |  |  | 2,524 |  |  | — |  |  | 3,526 |  |  | 3,526 |  |
| U.S. government agency securities | — |  |  | 415 |  |  | 415 |  |  | — |  |  | 423 |  |  | 423 |  |
| Non-U.S. government and agency securities | — |  |  | 351 |  |  | 351 |  |  | — |  |  | 363 |  |  | 363 |  |
| Corporate debt securities | — |  |  | 6,500 |  |  | 6,500 |  |  | — |  |  | 6,914 |  |  | 6,914 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,113 |  |  | 2,113 |  |  | — |  |  | 2,205 |  |  | 2,205 |  |
| Commercial paper | — |  |  | 943 |  |  | 943 |  |  | — |  |  | 1,484 |  |  | 1,484 |  |
| Certificates of deposit | — |  |  | 666 |  |  | 666 |  |  | — |  |  | 677 |  |  | 677 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 409 |  |  | — |  |  | 409 |  |  | 431 |  |  | — |  |  | 431 |  |
| Other current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 375 |  |  | — |  |  | 375 |  |  | 188 |  |  | — |  |  | 188 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 1,125 |  |  | — |  |  | 1,125 |  |  | 1,313 |  |  | — |  |  | 1,313 |  |
| Derivative assets | — |  |  | 58 |  |  | 58 |  |  | — |  |  | 32 |  |  | 32 |  |
| Total | $ | 8,559 |  |  | $ | 14,336 |  |  | $ | 22,895 |  |  | $ | 8,428 |  |  | $ | 16,786 |  |  | $ | 25,214 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 92 |  |  | $ | 92 |  |  | $ | — |  |  | $ | 75 |  |  | $ | 75 |  |
| Total | $ | — |  |  | $ | 92 |  |  | $ | 92 |  |  | $ | — |  |  | $ | 75 |  |  | $ | 75 |  |

[0000858877-23-000031:notes:135]
[same as prior period, unchanged from 0000858877-23-000013:notes:137]

[0000858877-23-000031:notes:136]
[same as prior period, unchanged from 0000858877-23-000013:notes:138]

[0000858877-23-000031:notes:137]
[same as prior period, unchanged from 0000858877-23-000013:notes:139]

[0000858877-23-000031:notes:138]
[same as prior period, unchanged from 0000858877-23-000013:notes:140]

[0000858877-23-000031:notes:139]
The fair value of our short-term loan receivables approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables as of October 28, 2023 and July 29, 2023 was $2.7 billion and $2.9 billion, respectively. The estimated fair value of our long-term loan receivables approximates their carrying value. We use unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables, and therefore they are categorized as Level 3.
As of October 28, 2023, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of October 28, 2023, the fair value of our senior notes was $7.5 billion with a carrying amount of $7.7 billion. This compares to a fair value of $8.7 billion and a carrying amount of $8.4 billion as of July 29, 2023. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2.


## us-gaap:DebtDisclosureTextBlock

[0000858877-23-000031:notes:140]
Borrowings 
(a)Short-Term Debt

[0000858877-23-000031:notes:141]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-23-000031:notes:142]
|  | October 28, 2023 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 990 |  |  | 6.33 | % |  | $ | 1,733 |  |  | 4.45 | % |

[0000858877-23-000031:notes:143]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-23-000031:notes:144]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-23-000031:notes:145]
(b)Long-Term Debt

[0000858877-23-000031:notes:146]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-23-000031:notes:147]
|  |  |  | October 28, 2023 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 6.33% |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.63% |  | 500 |  |  | 6.38% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 7,750 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (68) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (32) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 7,650 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 990 |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 6,660 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 7,650 |  |  |  |  | $ | 8,391 |  |  |  |

[0000858877-23-000031:notes:148]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $1.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on Secured Overnight Financing Rate (SOFR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-23-000031:notes:149]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 28, 2023, we were in compliance with all debt covenants.

[0000858877-23-000031:notes:150]
As of October 28, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-23-000031:notes:151]
| Fiscal Year | Amount |
| 2024 (remaining nine months) | $ | 1,000 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 7,750 |  |

[0000858877-23-000031:notes:152]
(c)Credit Facility

[0000858877-23-000031:notes:153]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of October 28, 2023, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement. On April 18, 2023, we entered into an amendment to the credit agreement to replace the LIBOR index with Term SOFR.
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) Term SOFR (plus a 0.10% credit spread adjustment) or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) Term SOFR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-23-000031:notes:154]
[same as prior period, unchanged from 0000858877-23-000013:notes:158]

[0000858877-23-000031:notes:155]
[same as prior period, unchanged from 0000858877-23-000013:notes:159]

[0000858877-23-000031:notes:156]
[same as prior period, unchanged from 0000858877-23-000013:notes:160]

[0000858877-23-000031:notes:157]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | October 28,2023 |  | July 29,2023 |  | Balance Sheet Line Item |  | October 28,2023 |  | July 29,2023 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 38 |  |  | $ | 22 |  |  | Other current liabilities |  | $ | — |  |  | $ | — |  |
| Foreign currency derivatives | Other assets |  | 19 |  |  | 9 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 10 |  |  | 17 |  |
| Interest rate derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 22 |  |  | 24 |  |
| Total |  |  | 57 |  |  | 31 |  |  |  |  | 32 |  |  | 41 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 1 |  |  | 1 |  |  | Other current liabilities |  | 41 |  |  | 25 |  |
| Foreign currency derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 19 |  |  | 9 |  |
| Total |  |  | 1 |  |  | 1 |  |  |  |  | 60 |  |  | 34 |  |
| Total |  |  | $ | 58 |  |  | $ | 32 |  |  |  |  | $ | 92 |  |  | $ | 75 |  |

[0000858877-23-000031:notes:158]
[same as prior period, unchanged from 0000858877-23-000013:notes:162]

[0000858877-23-000031:notes:159]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | October 28,2023 |  | July 29,2023 |  | October 28,2023 |  | July 29,2023 |
| Short-term debt |  | $ | (990) |  |  | $ | (983) |  |  | $ | 10 |  |  | $ | 17 |  |
| Long-term debt |  | $ | (478) |  |  | $ | (476) |  |  | $ | 22 |  |  | $ | 24 |  |

[0000858877-23-000031:notes:160]
[same as prior period, unchanged from 0000858877-23-000013:notes:164]

[0000858877-23-000031:notes:161]
|  |  | GAINS (LOSSES) FOR THE THREE MONTHS ENDED |
|  |  | October 28, 2023 |  | October 29, 2022 |
| Interest rate derivatives: |  |  |  |  |
| Hedged items |  | $ | (9) |  |  | $ | 39 |  |
| Derivatives designated as hedging instruments |  | 9 |  |  | (39) |  |
| Total |  | $ | — |  |  | $ | — |  |

[0000858877-23-000031:notes:162]
[same as prior period, unchanged from 0000858877-23-000013:notes:166]

[0000858877-23-000031:notes:163]
|  |  |  |  | GAINS (LOSSES) FOR THE THREE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | October 28,2023 |  | October 29,2022 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (130) |  |  | $ | (72) |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | (77) |  |  | (25) |  |
| Equity derivatives |  | Other income (loss), net |  | 2 |  |  | (1) |  |
| Total |  |  |  | $ | (205) |  |  | $ | (98) |  |

[0000858877-23-000031:notes:164]
[same as prior period, unchanged from 0000858877-23-000013:notes:168]

[0000858877-23-000031:notes:165]
|  | October 28,2023 |  | July 29,2023 |
| Foreign currency derivatives | $ | 5,672 |  |  | $ | 5,419 |  |
| Interest rate derivatives | 1,500 |  |  | 1,500 |  |
| Total return swaps—deferred compensation | 783 |  |  | 792 |  |
| Total | $ | 7,955 |  |  | $ | 7,711 |  |

[0000858877-23-000031:notes:166]
[same as prior period, unchanged from 0000858877-23-000013:notes:170]

[0000858877-23-000031:notes:167]
[same as prior period, unchanged from 0000858877-23-000013:notes:171]

[0000858877-23-000031:notes:168]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral provided for was $9 million and $40 million as of October 28, 2023 and July 29, 2023, respectively.

[0000858877-23-000031:notes:169]
[same as prior period, unchanged from 0000858877-23-000013:notes:173]

[0000858877-23-000031:notes:170]
[same as prior period, unchanged from 0000858877-23-000013:notes:174]

[0000858877-23-000031:notes:171]
[same as prior period, unchanged from 0000858877-23-000013:notes:175]

[0000858877-23-000031:notes:172]
[same as prior period, unchanged from 0000858877-23-000013:notes:176]

[0000858877-23-000031:notes:173]
[same as prior period, unchanged from 0000858877-23-000013:notes:177]

[0000858877-23-000031:notes:174]
[same as prior period, unchanged from 0000858877-23-000013:notes:178]

[0000858877-23-000031:notes:175]
We hold interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2024 through 2025. Under these interest rate swaps, we receive fixed-rate interest payments and make interest payments based on SOFR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on SOFR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.

[0000858877-23-000031:notes:176]
[same as prior period, unchanged from 0000858877-23-000013:notes:180]

[0000858877-23-000031:notes:177]
We hold marketable equity securities in our portfolio that are subject to price risk. To diversify our overall portfolio, we also hold equity derivatives that are not designated as accounting hedges. The change in the fair value of each of these investment types are included in other income (loss), net. 
We are also exposed to variability in compensation charges related to certain deferred compensation obligations to employees and directors. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure and offset the related compensation expense.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-23-000031:notes:178]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-23-000031:notes:179]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-23-000031:notes:180]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-23-000031:notes:181]
|  | October 28,2023 |  | July 29,2023 |
| Less than 1 year | $ | 4,731 |  |  | $ | 5,270 |  |
| 1 to 3 years | 1,646 |  |  | 1,783 |  |
| 3 to 5 years | 127 |  |  | 200 |  |
| Total | $ | 6,504 |  |  | $ | 7,253 |  |

[0000858877-23-000031:notes:182]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 28, 2023 and July 29, 2023, the liability for these purchase commitments was $510 million and $529 million, respectively, and was included in other current liabilities.

[0000858877-23-000031:notes:183]
(b)Other Commitments

[0000858877-23-000031:notes:184]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-23-000031:notes:185]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-23-000031:notes:186]
|  | Three Months Ended |
|  | October 28, 2023 |  | October 29, 2022 |
| Compensation expense related to acquisitions | $ | 49 |  |  | $ | 74 |  |

[0000858877-23-000031:notes:187]
As of October 28, 2023, we estimated that future cash compensation expense of up to $437 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-23-000031:notes:188]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion as of each of October 28, 2023 and July 29, 2023.

[0000858877-23-000031:notes:189]
(c)Product Warranties

[0000858877-23-000031:notes:190]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-23-000031:notes:191]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |
| Balance at beginning of period | $ | 329 |  |  | $ | 333 |  |
| Provisions for warranties issued | 98 |  |  | 97 |  |
| Adjustments for pre-existing warranties | 3 |  |  | 1 |  |
| Settlements | (100) |  |  | (108) |  |
| Balance at end of period | $ | 330 |  |  | $ | 323 |  |

[0000858877-23-000031:notes:192]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-23-000031:notes:193]
(d)Financing and Other Guarantees

[0000858877-23-000031:notes:194]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-23-000031:notes:195]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $8.2 billion and $7.6 billion for the first quarter of fiscal 2024 and 2023, respectively. The balance of the channel partner financing subject to guarantees was $1.5 billion and $1.7 billion as of October 28, 2023 and July 29, 2023, respectively.

[0000858877-23-000031:notes:196]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at October 28, 2023 and July 29, 2023, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-23-000031:notes:197]
|  | October 28,2023 |  | July 29,2023 |
| Maximum potential future payments | $ | 142 |  |  | $ | 159 |  |
| Deferred revenue | (29) |  |  | (34) |  |
| Total | $ | 113 |  |  | $ | 125 |  |

[0000858877-23-000031:notes:198]
(e)Indemnifications

[0000858877-23-000031:notes:199]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-23-000031:notes:200]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-23-000031:notes:201]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-23-000031:notes:202]
(f)Legal Proceedings

[0000858877-23-000031:notes:203]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $162 million for the alleged evasion of import and other taxes, $943 million for interest, and $402 million for various penalties, all determined using an exchange rate as of October 28, 2023.

[0000858877-23-000031:notes:204]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-23-000031:notes:205]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. The district court case went to trial on five asserted patents. Subsequently, on October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent and awarded $1.9 billion in damages and $14 million in pre-judgment interest, declined to issue an injunction but, instead, awarded Centripetal a royalty against future revenue for an initial three-year term at a 10% rate, with a minimum and maximum annual royalty of $168 million and $300 million, respectively, and for a second three-year term at a 5% rate, with a minimum and maximum annual royalty of $84 million and $150 million, respectively. We appealed and, on June 23, 2022, the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”) vacated the district court’s final judgment, remanded the case back to the district court to be assigned to a new judge and ordered the district court to conduct additional proceedings. The district court held a hearing on these additional proceedings over three days beginning on June 22, 2023, and a decision is pending. Prior to the hearing, on May 24, 2023, the Patent Trial and Appeal Board cancelled all claims of one of the Centripetal patents that was the subject of the hearing. On August 9, 2022, Centripetal filed a petition for writ of certiorari in the U.S. Supreme Court challenging the Federal Circuit’s decision. The Supreme Court denied Centripetal’s petition on December 5, 2022.

[0000858877-23-000031:notes:206]
Between April 2020 and February 2022, Centripetal filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. On December 10, 2021, the German Court rejected Centripetal’s complaints on two patents, and Centripetal has appealed. A hearing for a Cisco nullity action in the Federal Patent Court in Germany on one of those two patents occurred on August 1, 2022, and we are waiting for the Court’s opinion. On December 21, 2021, the German Court stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. On May 17, 2022, Centripetal withdrew its complaint for infringement of the German utility model. The German Court conducted a hearing on the remaining two Centripetal complaints on November 22, 2022. The German Court found no infringement on one patent and stayed the decision in the final case pending a decision by the European Patent Office in a related opposition proceeding.

[0000858877-23-000031:notes:207]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement.

[0000858877-23-000031:notes:208]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of the litigations at this time. If we do not prevail in these litigations, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-23-000031:notes:209]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. We challenged the validity of all three patents in the U.S. Patent and Trademark Office (“PTO”) by way of ex parte reexamination proceedings and the pending District Court case has been stayed. On July 6, 2023, the PTO issued a reexamination certificate for one of the three patents. On August 29, 2023, Cisco filed a second ex parte reexamination request against that same patent.

[0000858877-23-000031:notes:210]
On October 30, 2023, the PTO issued a reexamination certificate for a second of the three patents. The third asserted patent remains the subject of a pending reexamination proceeding.

[0000858877-23-000031:notes:211]
On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) in the District of Delaware (“D. Del.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot asserted in the E.D. Tex. case and this case is also stayed pending the reexamination proceedings referenced above.

[0000858877-23-000031:notes:212]
On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents in the same family as those involved in the pending cases above. Ramot is asserting counterclaims for infringement of the same patents and seeks damages, including enhanced damages, and a royalty on future sales. While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-23-000031:notes:213]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward (“Viasat 2019”). In May 2023, a judgment was entered against Cisco in Viasat 2019 for an amount that did not have a material effect on our Consolidated Financial Statements. Acacia filed an appeal with the California Court of Appeal.

[0000858877-23-000031:notes:214]
On June 9, 2020, Viasat filed another suit in SDSC alleging contract and trade secret claims for sales of additional Acacia products (“Viasat 2020”). In October 2022, an amended complaint was filed in Viasat 2020 asserting the same claims but alleging additional information. The parties have since resolved both the Viasat 2019 appeal and Viasat 2020, with dismissals entered in each matter in October 2023. The amounts paid by us to resolve these matters did not have a material effect on our Consolidated Financial Statements.

[0000858877-23-000031:notes:215]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023 and those proceedings are ongoing.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-23-000031:notes:216]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-23-000031:notes:217]
[same as prior period, unchanged from 0000858877-23-000013:notes:219]

[0000858877-23-000031:notes:218]
In September 2001, our Board of Directors authorized a stock repurchase program. As of October 28, 2023, the remaining authorized amount for stock repurchases under this program was approximately $9.7 billion with no termination date. A summary of the stock repurchase activity for fiscal 2024 and 2023 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-23-000031:notes:219]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2024 |  |  |  |  |  |  |
| October 28, 2023 |  | 23 |  |  | $ | 54.53 |  |  | $ | 1,252 |  |
| Fiscal 2023 |  |  |  |  |  |  |
| July 29, 2023 |  | 25 |  |  | $ | 50.49 |  |  | $ | 1,254 |  |
| April 29, 2023 |  | 25 |  |  | $ | 49.45 |  |  | $ | 1,259 |  |
| January 28, 2023 |  | 26 |  |  | $ | 47.72 |  |  | $ | 1,256 |  |
| October 29, 2022 |  | 12 |  |  | $ | 43.76 |  |  | $ | 502 |  |

[0000858877-23-000031:notes:220]
There were stock repurchases of $48 million that were pending settlement as of July 29, 2023.

[0000858877-23-000031:notes:221]
[same as prior period, unchanged from 0000858877-23-000013:notes:223]

[0000858877-23-000031:notes:222]
[same as prior period, unchanged from 0000858877-23-000013:notes:224]

[0000858877-23-000031:notes:223]
On November 15, 2023, our Board of Directors declared a quarterly dividend of $0.39 per common share to be paid on January 24, 2024, to all stockholders of record as of the close of business on January 4, 2024. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-23-000031:notes:224]
[same as prior period, unchanged from 0000858877-23-000013:notes:226]

[0000858877-23-000031:notes:225]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock in one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights, if any, of such series, and any qualifications, limitations or restrictions thereof, of the shares of such series. As of October 28, 2023, we had not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-23-000031:notes:226]
[same as prior period, unchanged from 0000858877-23-000013:notes:228]

[0000858877-23-000031:notes:227]
[same as prior period, unchanged from 0000858877-23-000013:notes:229]

[0000858877-23-000031:notes:228]
[same as prior period, unchanged from 0000858877-23-000013:notes:230]

[0000858877-23-000031:notes:229]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant

[0000858877-23-000031:notes:230]
to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of October 28, 2023, 114 million shares were authorized for future grant under the 2005 Plan.

[0000858877-23-000031:notes:231]
[same as prior period, unchanged from 0000858877-23-000013:notes:232]

[0000858877-23-000031:notes:232]
We have an Employee Stock Purchase Plan under which eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. No shares were issued under the Employee Stock Purchase Plan during each of the first quarters of fiscal 2024 and 2023. As of October 28, 2023, 88 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-23-000031:notes:233]
[same as prior period, unchanged from 0000858877-23-000013:notes:234]

[0000858877-23-000031:notes:234]
[same as prior period, unchanged from 0000858877-23-000013:notes:235]

[0000858877-23-000031:notes:235]
|  | Three Months Ended |
|  | October 28, 2023 |  | October 29, 2022 |
| Cost of sales—product | $ | 42 |  |  | $ | 31 |  |
| Cost of sales—service | 61 |  |  | 50 |  |
| Share-based compensation expense in cost of sales | 103 |  |  | 81 |  |
| Research and development | 274 |  |  | 204 |  |
| Sales and marketing | 186 |  |  | 153 |  |
| General and administrative | 90 |  |  | 58 |  |
| Restructuring and other charges | 8 |  |  | — |  |
| Share-based compensation expense in operating expenses | 558 |  |  | 415 |  |
| Total share-based compensation expense | $ | 661 |  |  | $ | 496 |  |
| Income tax benefit for share-based compensation | $ | 143 |  |  | $ | 99 |  |

[0000858877-23-000031:notes:236]
As of October 28, 2023, the total compensation cost related to unvested share-based awards not yet recognized was $4.5 billion which is expected to be recognized over approximately 2.1 years on a weighted-average basis.

[0000858877-23-000031:notes:237]
[same as prior period, unchanged from 0000858877-23-000013:notes:238]

[0000858877-23-000031:notes:238]
[same as prior period, unchanged from 0000858877-23-000013:notes:239]

[0000858877-23-000031:notes:239]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| Unvested balance at July 30, 2022 | 97 |  |  | $ | 46.67 |  |  |  |
| Granted and assumed | 72 |  |  | 42.08 |  |  |  |
| Vested | (39) |  |  | 46.69 |  |  | $ | 1,746 |  |
| Canceled/forfeited/other | (8) |  |  | 45.17 |  |  |  |
| Unvested balance at July 29, 2023 | 122 |  |  | $ | 44.04 |  |  |  |
| Granted and assumed | 11 |  |  | 51.70 |  |  |  |
| Vested | (9) |  |  | 44.86 |  |  | $ | 460 |  |
| Canceled/forfeited/other | (1) |  |  | 41.31 |  |  |  |
| Unvested balance at October 28, 2023 | 123 |  |  | $ | 44.69 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-23-000031:notes:240]
Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first quarter of fiscal 2024 and 2023 are summarized as follows (in millions):

[0000858877-23-000031:notes:241]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 29, 2023 | $ | (440) |  |  | $ | 18 |  |  | $ | (1,153) |  |  | $ | (1,575) |  |
| Other comprehensive income (loss) before reclassifications | (170) |  |  | 38 |  |  | (356) |  |  | (488) |  |
| (Gains) losses reclassified out of AOCI | 20 |  |  | (12) |  |  | (1) |  |  | 7 |  |
| Tax benefit (expense) | 36 |  |  | (6) |  |  | 1 |  |  | 31 |  |
| Balance at October 28, 2023 | $ | (554) |  |  | $ | 38 |  |  | $ | (1,509) |  |  | $ | (2,025) |  |

[0000858877-23-000031:notes:242]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 30, 2022 | $ | (379) |  |  | $ | 44 |  |  | $ | (1,287) |  |  | $ | (1,622) |  |
| Other comprehensive income (loss) before reclassifications | (329) |  |  | 32 |  |  | (282) |  |  | (579) |  |
| (Gains) losses reclassified out of AOCI | 6 |  |  | (19) |  |  | — |  |  | (13) |  |
| Tax benefit (expense) | 77 |  |  | (3) |  |  | 22 |  |  | 96 |  |
| Balance at October 29, 2022 | $ | (625) |  |  | $ | 54 |  |  | $ | (1,547) |  |  | $ | (2,118) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-23-000031:notes:243]
[same as prior period, unchanged from 0000858877-23-000013:notes:244]

[0000858877-23-000031:notes:244]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |
| Income before provision for income taxes | $ | 4,442 |  |  | $ | 3,475 |  |
| Provision for income taxes | $ | 804 |  |  | $ | 805 |  |
| Effective tax rate | 18.1 | % |  | 23.2 | % |

[0000858877-23-000031:notes:245]
As of October 28, 2023, we had $1.9 billion of unrecognized tax benefits, of which $1.5 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-23-000031:notes:246]
[same as prior period, unchanged from 0000858877-23-000013:notes:247]

[0000858877-23-000031:notes:247]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-23-000031:notes:248]
Summarized financial information by segment for the first quarter of fiscal 2024 and 2023, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-23-000031:notes:249]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |
| Revenue: |  |  |  |
| Americas | $ | 9,022 |  |  | $ | 7,914 |  |
| EMEA | 3,664 |  |  | 3,675 |  |
| APJC | 1,982 |  |  | 2,043 |  |
| Total | $ | 14,668 |  |  | $ | 13,632 |  |
| Gross margin: |  |  |  |
| Americas | $ | 5,968 |  |  | $ | 4,984 |  |
| EMEA | 2,545 |  |  | 2,325 |  |
| APJC | 1,328 |  |  | 1,274 |  |
| Segment total | 9,841 |  |  | 8,582 |  |
| Unallocated corporate items | (284) |  |  | (236) |  |
| Total | $ | 9,557 |  |  | $ | 8,346 |  |

[0000858877-23-000031:notes:250]
Revenue in the United States was $8.1 billion and $7.1 billion for the first quarter of fiscal 2024 and 2023, respectively.

[0000858877-23-000031:notes:251]
[same as prior period, unchanged from 0000858877-23-000013:notes:253]

[0000858877-23-000031:notes:252]
We design and sell Internet Protocol (IP)-based networking and other products related to the communications and IT industry and provide services associated with these products and their use. Effective in the first quarter of fiscal 2024, we began reporting our product and service revenue in the following categories: Networking, Security, Collaboration, Observability, and Services and conformed our product revenue for prior periods to the current period presentation.


## us-gaap:EarningsPerShareTextBlock

[0000858877-23-000031:notes:253]
[same as prior period, unchanged from 0000858877-23-000013:notes:255]

[0000858877-23-000031:notes:254]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |
| Net income | $ | 3,638 |  |  | $ | 2,670 |  |
| Weighted-average shares—basic | 4,057 |  |  | 4,108 |  |
| Effect of dilutive potential common shares | 30 |  |  | 8 |  |
| Weighted-average shares—diluted | 4,087 |  |  | 4,116 |  |
| Net income per share—basic | $ | 0.90 |  |  | $ | 0.65 |  |
| Net income per share—diluted | $ | 0.89 |  |  | $ | 0.65 |  |
| Antidilutive employee share-based awards, excluded | 16 |  |  | 38 |  |
