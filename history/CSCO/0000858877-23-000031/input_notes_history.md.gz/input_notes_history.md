# CSCO note change history — 0000858877-23-000013 → 0000858877-23-000031


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-11-21):
[0000858877-23-000031:note_history:1]
|  | October 28,2023 |  | July 29,2023 |
| Less than 1 year | $ | 4,731 |  |  | $ | 5,270 |  |
| 1 to 3 years | 1,646 |  |  | 1,783 |  |
| 3 to 5 years | 127 |  |  | 200 |  |
| Total | $ | 6,504 |  |  | $ | 7,253 |  |
  (was, 2023-05-24, similarity 0.9691):
[0000858877-23-000013:note_history:1]
|  | April 29,2023 |  | July 30,2022 |
| Less than 1 year | $ | 7,073 |  |  | $ | 9,954 |  |
| 1 to 3 years | 1,618 |  |  | 2,240 |  |
| 3 to 5 years | 368 |  |  | 770 |  |
| Total | $ | 9,059 |  |  | $ | 12,964 |  |

- changed (2023-11-21):
[0000858877-23-000031:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 28, 2023 and July 29, 2023, the liability for these purchase commitments was $510 million and $529 million, respectively, and was included in other current liabilities.
  (was, 2023-05-24, similarity 0.984):
[0000858877-23-000013:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 29, 2023 and July 30, 2022, the liability for these purchase commitments was $525 million and $313 million, respectively, and was included in other current liabilities.

- changed (2023-11-21):
[0000858877-23-000031:note_history:3]
|  | Three Months Ended |
|  | October 28, 2023 |  | October 29, 2022 |
| Compensation expense related to acquisitions | $ | 49 |  |  | $ | 74 |  |
  (was, 2023-05-24, similarity 0.7134):
[0000858877-23-000013:note_history:3]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2023 |  | April 30, 2022 |  | April 29, 2023 |  | April 30, 2022 |
| Compensation expense related to acquisitions | $ | 53 |  |  | $ | 56 |  |  | $ | 176 |  |  | $ | 220 |  |

- changed (2023-11-21):
[0000858877-23-000031:note_history:4]
As of October 28, 2023, we estimated that future cash compensation expense of up to $437 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2023-05-24, similarity 0.9722):
[0000858877-23-000013:note_history:4]
As of April 29, 2023, we estimated that future cash compensation expense of up to $310 million may be required to be recognized pursuant to the applicable business combination agreements.

- changed (2023-11-21):
[0000858877-23-000031:note_history:5]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion as of each of October 28, 2023 and July 29, 2023.
  (was, 2023-05-24, similarity 0.9048):
[0000858877-23-000013:note_history:5]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion and $0.4 billion as of April 29, 2023 and July 30, 2022, respectively.

- changed (2023-11-21):
[0000858877-23-000031:note_history:6]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |
| Balance at beginning of period | $ | 329 |  |  | $ | 333 |  |
| Provisions for warranties issued | 98 |  |  | 97 |  |
| Adjustments for pre-existing warranties | 3 |  |  | 1 |  |
| Settlements | (100) |  |  | (108) |  |
| Balance at end of period | $ | 330 |  |  | $ | 323 |  |
  (was, 2023-05-24, similarity 0.8628):
[0000858877-23-000013:note_history:6]
|  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |
| Balance at beginning of period | $ | 333 |  |  | $ | 336 |  |
| Provisions for warranties issued | 285 |  |  | 320 |  |
| Adjustments for pre-existing warranties | 15 |  |  | 1 |  |
| Settlements | (321) |  |  | (322) |  |
| Balance at end of period | $ | 312 |  |  | $ | 335 |  |

- changed (2023-11-21):
[0000858877-23-000031:note_history:7]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $8.2 billion and $7.6 billion for the first quarter of fiscal 2024 and 2023, respectively. The balance of the channel partner financing subject to guarantees was $1.5 billion and $1.7 billion as of October 28, 2023 and July 29, 2023, respectively.
  (was, 2023-05-24, similarity 0.9206):
[0000858877-23-000013:note_history:7]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $8.3 billion and $6.9 billion for the third quarter of fiscal 2023 and 2022, respectively, and $23.4 billion and $20.3 billion for the first nine months of fiscal 2023 and 2022, respectively. The balance of the channel partner financing subject to guarantees was $1.8 billion and $1.4 billion as of April 29, 2023 and July 30, 2022, respectively.

- changed (2023-11-21):
[0000858877-23-000031:note_history:8]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at October 28, 2023 and July 29, 2023, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2023-05-24, similarity 0.9817):
[0000858877-23-000013:note_history:8]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at April 29, 2023 and July 30, 2022, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2023-11-21):
[0000858877-23-000031:note_history:9]
|  | October 28,2023 |  | July 29,2023 |
| Maximum potential future payments | $ | 142 |  |  | $ | 159 |  |
| Deferred revenue | (29) |  |  | (34) |  |
| Total | $ | 113 |  |  | $ | 125 |  |
  (was, 2023-05-24, similarity 0.9679):
[0000858877-23-000013:note_history:9]
|  | April 29,2023 |  | July 30,2022 |
| Maximum potential future payments | $ | 177 |  |  | $ | 188 |  |
| Deferred revenue | (40) |  |  | (9) |  |
| Total | $ | 137 |  |  | $ | 179 |  |

- changed (2023-11-21):
[0000858877-23-000031:note_history:10]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $162 million for the alleged evasion of import and other taxes, $943 million for interest, and $402 million for various penalties, all determined using an exchange rate as of October 28, 2023.
  (was, 2023-05-24, similarity 0.995):
[0000858877-23-000013:note_history:10]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $162 million for the alleged evasion of import and other taxes, $908 million for interest, and $401 million for various penalties, all determined using an exchange rate as of April 29, 2023.

- changed (2023-11-21):
[0000858877-23-000031:note_history:11]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. The district court case went to trial on five asserted patents. Subsequently, on October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent and awarded $1.9 billion in damages and $14 million in pre-judgment interest, declined to issue an injunction but, instead, awarded Centripetal a royalty against future revenue for an initial three-year term at a 10% rate, with a minimum and maximum annual royalty of $168 million and $300 million, respectively, and for a second three-year term at a 5% rate, with a minimum and maximum annual royalty of $84 million and $150 million, respectively. We appealed and, on June 23, 2022, the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”) vacated the district court’s final judgment, remanded the case back to the district court to be assigned to a new judge and ordered the district court to conduct additional proceedings. The district court held a hearing on these additional proceedings over three days beginning on June 22, 2023, and a decision is pending. Prior to the hearing, on May 24, 2023, the Patent Trial and Appeal Board cancelled all claims of one of the Centripetal patents that was the subject of the hearing. On August 9, 2022, Centripetal filed a petition for writ of certiorari in the U.S. Supreme Court challenging the Federal Circuit’s decision. The Supreme Court denied Centripetal’s petition on December 5, 2022.
  (was, 2023-05-24, similarity 0.7704):
[0000858877-23-000013:note_history:11]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. The district court case went to trial on five asserted patents. Subsequently, on October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent and awarded $1.9 billion in damages and $14 million in pre-judgment interest, declined to issue an injunction but, instead, awarded Centripetal a royalty against future revenue for an initial three-year term at a 10% rate, with a minimum and maximum annual royalty of $168 million and $300 million, respectively, and for a second three-year term at a 5% rate, with a minimum and maximum annual royalty of $84 million and $150 million, respectively. We appealed and, on June 23, 2022, the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”) vacated the district court’s final judgment, remanded the case back to the district court to be assigned to a new judge and ordered the district court to conduct additional proceedings and the district court set a hearing to commence on June 22, 2023. On May 24, 2023, the Patent Trial and Appeal Board cancelled all claims of one of the Centripetal patents that is the subject of the hearing set for June 22, 2023. On August 9, 2022, Centripetal filed a petition for writ of certiorari in the U.S. Supreme Court challenging the Federal Circuit’s decision. The Supreme Court denied Centripetal’s petition on December 5, 2022.

- changed (2023-11-21):
[0000858877-23-000031:note_history:12]
Between April 2020 and February 2022, Centripetal filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. On December 10, 2021, the German Court rejected Centripetal’s complaints on two patents, and Centripetal has appealed. A hearing for a Cisco nullity action in the Federal Patent Court in Germany on one of those two patents occurred on August 1, 2022, and we are waiting for the Court’s opinion. On December 21, 2021, the German Court stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. On May 17, 2022, Centripetal withdrew its complaint for infringement of the German utility model. The German Court conducted a hearing on the remaining two Centripetal complaints on November 22, 2022. The German Court found no infringement on one patent and stayed the decision in the final case pending a decision by the European Patent Office in a related opposition proceeding.
  (was, 2023-05-24, similarity 0.9981):
[0000858877-23-000013:note_history:12]
Between April 2020 and February 2022, Centripetal filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. On December 10, 2021, the German Court rejected Centripetal’s complaints on two patents, and Centripetal appealed. A hearing for a Cisco nullity action in the Federal Patent Court in Germany on one of those two patents occurred on August 1, 2022, and we are waiting for the Court’s opinion. On December 21, 2021, the German Court stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. On May 17, 2022, Centripetal withdrew its complaint for infringement of the German utility model. The German Court conducted a hearing on the remaining two Centripetal complaints on November 22, 2022. The German Court found no infringement on one patent and stayed the decision in the final case pending a decision by the European Patent Office in a related opposition proceeding.

- added (2023-11-21):
[0000858877-23-000031:note_history:13]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement.

- changed (2023-11-21):
[0000858877-23-000031:note_history:14]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of the litigations at this time. If we do not prevail in these litigations, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.
  (was, 2023-05-24, similarity 0.9499):
[0000858877-23-000013:note_history:14]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of the litigations at this time. If we do not prevail in either litigation, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

- added (2023-11-21):
[0000858877-23-000031:note_history:15]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. We challenged the validity of all three patents in the U.S. Patent and Trademark Office (“PTO”) by way of ex parte reexamination proceedings and the pending District Court case has been stayed. On July 6, 2023, the PTO issued a reexamination certificate for one of the three patents. On August 29, 2023, Cisco filed a second ex parte reexamination request against that same patent.

- added (2023-11-21):
[0000858877-23-000031:note_history:16]
On October 30, 2023, the PTO issued a reexamination certificate for a second of the three patents. The third asserted patent remains the subject of a pending reexamination proceeding.

- added (2023-11-21):
[0000858877-23-000031:note_history:17]
On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) in the District of Delaware (“D. Del.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot asserted in the E.D. Tex. case and this case is also stayed pending the reexamination proceedings referenced above.

- changed (2023-11-21):
[0000858877-23-000031:note_history:18]
On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents in the same family as those involved in the pending cases above. Ramot is asserting counterclaims for infringement of the same patents and seeks damages, including enhanced damages, and a royalty on future sales. While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.
  (was, 2023-05-24, similarity 0.842):
[0000858877-23-000013:note_history:18]
counterclaims for infringement of the same patents and seeks damages, including enhanced damages, and a royalty on future sales. While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

- changed (2023-11-21):
[0000858877-23-000031:note_history:19]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward (“Viasat 2019”). In May 2023, a judgment was entered against Cisco in Viasat 2019 for an amount that did not have a material effect on our Consolidated Financial Statements. Acacia filed an appeal with the California Court of Appeal.
  (was, 2023-05-24, similarity 0.9302):
[0000858877-23-000013:note_history:19]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward (“Viasat 2019”). In May 2023, a judgment was entered against Cisco in Viasat 2019 for an amount that did not have a material effect on our Consolidated Financial Statements.

- changed (2023-11-21):
[0000858877-23-000031:note_history:20]
On June 9, 2020, Viasat filed another suit in SDSC alleging contract and trade secret claims for sales of additional Acacia products (“Viasat 2020”). In October 2022, an amended complaint was filed in Viasat 2020 asserting the same claims but alleging additional information. The parties have since resolved both the Viasat 2019 appeal and Viasat 2020, with dismissals entered in each matter in October 2023. The amounts paid by us to resolve these matters did not have a material effect on our Consolidated Financial Statements.
  (was, 2023-05-24, similarity 0.6464):
[0000858877-23-000013:note_history:20]
On June 9, 2020, Viasat filed a third suit in SDSC alleging contract and trade secrets claims for sales of additional Acacia products (“Viasat 2020”). In October 2022, an amended complaint was filed in Viasat 2020 asserting the same claims but alleging additional information. We are unable to reasonably estimate the ultimate outcome of Viasat 2020 at this time due to uncertainties in the litigation processes. If we do not prevail, we believe that any relief ultimately assessed in Viasat 2020 will not have a material effect on our Consolidated Financial Statements.

- removed (2023-11-21):
[0000858877-23-000013:note_history:21]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. The U.S. Patent and Trademark Office (“PTO”) preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings and the pending District Court case has been stayed. On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) in the District of Delaware (“D. Del.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot asserted in the E.D. Tex. case and this case is also stayed pending reexamination proceedings.

- removed (2023-11-21):
[0000858877-23-000013:note_history:22]
On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents in the same family as those involved in the pending cases above. Ramot is asserting


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-11-21):
[0000858877-23-000031:note_history:23]
We have prepared the accompanying financial data as of October 28, 2023 and for the first quarter of fiscal 2024 and 2023, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 29, 2023 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 29, 2023.
  (was, 2023-05-24, similarity 0.9779):
[0000858877-23-000013:note_history:23]
We have prepared the accompanying financial data as of April 29, 2023 and for the third quarter and first nine months of fiscal 2023 and 2022, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 30, 2022 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 30, 2022.

- added (2023-11-21):
[0000858877-23-000031:note_history:24]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of October 28, 2023, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2024 and 2023, as applicable, have been made. The results of operations for the first quarter of fiscal 2024 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2023-11-21):
[0000858877-23-000013:note_history:25]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of April 29, 2023, the results of operations, the statements of comprehensive income and the statements of equity for the third quarter and first nine months of fiscal 2023 and 2022, and the statements of cash flows for the first nine months of fiscal 2023 and 2022, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2023 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-11-21):
[0000858877-23-000031:note_history:26]
Recent Accounting PronouncementsThere have been no recent accounting pronouncements issued that we believe will have a material impact on our Consolidated Financial Statements.

- removed (2023-11-21):
[0000858877-23-000013:note_history:27]
Recent Accounting Pronouncements
(a)Recent Accounting Standards or Updates Not Yet Effective

- removed (2023-11-21):
[0000858877-23-000013:note_history:28]
Reference Rate Reform  In March 2020, the Financial Accounting Standards Board issued an accounting standard update and subsequent amendments that provide optional expedients and exceptions to the current guidance on contract modification and hedging relationships to ease the financial reporting burden of the expected market transition from the London InterBank Offered Rate (LIBOR) and other interbank offered rates to alternative reference rates. This accounting standard update was effective upon issuance and may be applied prospectively through December 31, 2024. We do not expect this accounting standard update will have a material impact on our Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-21):
[0000858877-23-000031:note_history:29]
|  | October 28, 2023 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 990 |  |  | 6.33 | % |  | $ | 1,733 |  |  | 4.45 | % |
  (was, 2023-05-24, similarity 0.7586):
[0000858877-23-000013:note_history:29]
|  | April 29, 2023 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,731 |  |  | 4.26 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,731 |  |  |  |  | $ | 1,099 |  |  |  |

- changed (2023-11-21):
[0000858877-23-000031:note_history:30]
|  |  |  | October 28, 2023 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 6.33% |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.63% |  | 500 |  |  | 6.38% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 7,750 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (68) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (32) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 7,650 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 990 |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 6,660 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 7,650 |  |  |  |  | $ | 8,391 |  |  |  |
  (was, 2023-05-24, similarity 0.9489):
[0000858877-23-000013:note_history:30]
|  |  |  | April 29, 2023 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 5.75% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.15% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 8,500 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (70) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (36) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,394 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,731 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 6,663 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,394 |  |  |  |  | $ | 8,915 |  |  |  |

- changed (2023-11-21):
[0000858877-23-000031:note_history:31]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $1.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on Secured Overnight Financing Rate (SOFR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.
  (was, 2023-05-24, similarity 0.9488):
[0000858877-23-000013:note_history:31]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $1.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

- changed (2023-11-21):
[0000858877-23-000031:note_history:32]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 28, 2023, we were in compliance with all debt covenants.
  (was, 2023-05-24, similarity 0.9863):
[0000858877-23-000013:note_history:32]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 29, 2023, we were in compliance with all debt covenants.

- changed (2023-11-21):
[0000858877-23-000031:note_history:33]
As of October 28, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2023-05-24, similarity 0.9627):
[0000858877-23-000013:note_history:33]
As of April 29, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2023-11-21):
[0000858877-23-000031:note_history:34]
| Fiscal Year | Amount |
| 2024 (remaining nine months) | $ | 1,000 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 7,750 |  |
  (was, 2023-05-24, similarity 0.9356):
[0000858877-23-000013:note_history:34]
| Fiscal Year | Amount |
| 2023 (remaining three months) | $ | — |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 8,500 |  |

- changed (2023-11-21):
[0000858877-23-000031:note_history:35]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of October 28, 2023, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement. On April 18, 2023, we entered into an amendment to the credit agreement to replace the LIBOR index with Term SOFR.
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) Term SOFR (plus a 0.10% credit spread adjustment) or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) Term SOFR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.
  (was, 2023-05-24, similarity 0.8785):
[0000858877-23-000013:note_history:35]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) Term SOFR (plus a 0.10% credit spread adjustment) or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) Term SOFR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

- removed (2023-11-21):
[0000858877-23-000013:note_history:36]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of April 29, 2023, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit

- removed (2023-11-21):
[0000858877-23-000013:note_history:37]
agreement. On April 18, 2023, we entered into an amendment to the credit agreement to replace the LIBOR index with Term Secured Overnight Financing Rate (SOFR).


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-21):
[0000858877-23-000031:note_history:38]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 28, 2023 and July 29, 2023 (in millions):
  (was, 2023-05-24, similarity 0.9716):
[0000858877-23-000013:note_history:38]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 29, 2023 and July 30, 2022 (in millions):

- changed (2023-11-21):
[0000858877-23-000031:note_history:39]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 28, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,844 |  |  | $ | (38) |  |  | $ | 680 |  |  | $ | (34) |  |  | $ | 2,524 |  |  | $ | (72) |  |
| U.S. government agency securities | 377 |  |  | (3) |  |  | 38 |  |  | (3) |  |  | 415 |  |  | (6) |  |
| Non-U.S. government and agency securities | 324 |  |  | — |  |  | — |  |  | — |  |  | 324 |  |  | — |  |
| Corporate debt securities | 1,679 |  |  | (29) |  |  | 4,275 |  |  | (304) |  |  | 5,954 |  |  | (333) |  |
| U.S. agency mortgage-backed securities | 798 |  |  | (45) |  |  | 1,315 |  |  | (273) |  |  | 2,113 |  |  | (318) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Certificates of deposit | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 5,042 |  |  | $ | (115) |  |  | $ | 6,308 |  |  | $ | (614) |  |  | $ | 11,350 |  |  | $ | (729) |  |
  (was, 2023-05-24, similarity 0.9935):
[0000858877-23-000013:note_history:39]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 29, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 360 |  |  | $ | (2) |  |  | $ | 1,125 |  |  | $ | (40) |  |  | $ | 1,485 |  |  | $ | (42) |  |
| U.S. government agency securities | 148 |  |  | (1) |  |  | 110 |  |  | (3) |  |  | 258 |  |  | (4) |  |
| Non-U.S. government and agency securities | 291 |  |  | — |  |  | — |  |  | — |  |  | 291 |  |  | — |  |
| Corporate debt securities | 1,387 |  |  | (14) |  |  | 4,869 |  |  | (261) |  |  | 6,256 |  |  | (275) |  |
| U.S. agency mortgage-backed securities | 343 |  |  | (5) |  |  | 1,514 |  |  | (203) |  |  | 1,857 |  |  | (208) |  |
| Commercial paper | 69 |  |  | — |  |  | — |  |  | — |  |  | 69 |  |  | — |  |
| Certificates of deposit | 5 |  |  | — |  |  | — |  |  | — |  |  | 5 |  |  | — |  |
| Total | $ | 2,603 |  |  | $ | (22) |  |  | $ | 7,618 |  |  | $ | (507) |  |  | $ | 10,221 |  |  | $ | (529) |  |

- changed (2023-11-21):
[0000858877-23-000031:note_history:40]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 2,394 |  |  | $ | (26) |  |  | $ | 931 |  |  | $ | (36) |  |  | $ | 3,325 |  |  | $ | (62) |  |
| U.S. government agency securities | 343 |  |  | (2) |  |  | 72 |  |  | (3) |  |  | 415 |  |  | (5) |  |
| Non-U.S. government and agency securities | 363 |  |  | (1) |  |  | — |  |  | — |  |  | 363 |  |  | (1) |  |
| Corporate debt securities | 1,736 |  |  | (22) |  |  | 4,315 |  |  | (275) |  |  | 6,051 |  |  | (297) |  |
| U.S. agency mortgage-backed securities | 658 |  |  | (13) |  |  | 1,438 |  |  | (217) |  |  | 2,096 |  |  | (230) |  |
| Commercial paper | 97 |  |  | — |  |  | — |  |  | — |  |  | 97 |  |  | — |  |
| Certificates of deposit | 2 |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |
| Total | $ | 5,593 |  |  | $ | (64) |  |  | $ | 6,756 |  |  | $ | (531) |  |  | $ | 12,349 |  |  | $ | (595) |  |
  (was, 2023-05-24, similarity 0.7977):
[0000858877-23-000013:note_history:40]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 30, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,110 |  |  | $ | (44) |  |  | $ | 120 |  |  | $ | (5) |  |  | $ | 1,230 |  |  | $ | (49) |  |
| U.S. government agency securities | 114 |  |  | (2) |  |  | 24 |  |  | (2) |  |  | 138 |  |  | (4) |  |
| Non-U.S. government and agency securities | 264 |  |  | — |  |  | — |  |  | — |  |  | 264 |  |  | — |  |
| Corporate debt securities | 6,920 |  |  | (240) |  |  | 422 |  |  | (37) |  |  | 7,342 |  |  | (277) |  |
| U.S. agency mortgage-backed securities | 1,305 |  |  | (96) |  |  | 615 |  |  | (62) |  |  | 1,920 |  |  | (158) |  |
| Total | $ | 9,713 |  |  | $ | (382) |  |  | $ | 1,181 |  |  | $ | (106) |  |  | $ | 10,894 |  |  | $ | (488) |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-21):
[0000858877-23-000031:note_history:41]
Investments
(a)Summary of Available-for-Sale Debt Investments
  (was, 2023-05-24, similarity 0.7771):
[0000858877-23-000013:note_history:41]
Available-for-Sale Debt and Equity Investments
(a)Summary of Available-for-Sale Debt Investments

- changed (2023-11-21):
[0000858877-23-000031:note_history:42]
| October 28, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,596 |  |  | $ | — |  |  | $ | (72) |  |  | $ | 2,524 |  |
| U.S. government agency securities | 421 |  |  | — |  |  | (6) |  |  | 415 |  |
| Non-U.S. government and agency securities | 351 |  |  | — |  |  | — |  |  | 351 |  |
| Corporate debt securities | 6,862 |  |  | 1 |  |  | (363) |  |  | 6,500 |  |
| U.S. agency mortgage-backed securities | 2,431 |  |  | — |  |  | (318) |  |  | 2,113 |  |
| Commercial paper | 943 |  |  | — |  |  | — |  |  | 943 |  |
| Certificates of deposit | 666 |  |  | — |  |  | — |  |  | 666 |  |
| Total | $ | 14,270 |  |  | $ | 1 |  |  | $ | (759) |  |  | $ | 13,512 |  |
  (was, 2023-05-24, similarity 0.9913):
[0000858877-23-000013:note_history:42]
| July 30, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,287 |  |  | $ | — |  |  | $ | (49) |  |  | $ | 1,238 |  |
| U.S. government agency securities | 142 |  |  | — |  |  | (4) |  |  | 138 |  |
| Non-U.S. government and agency securities | 272 |  |  | — |  |  | — |  |  | 272 |  |
| Corporate debt securities | 8,127 |  |  | 2 |  |  | (311) |  |  | 7,818 |  |
| U.S. agency mortgage-backed securities | 2,134 |  |  | — |  |  | (158) |  |  | 1,976 |  |
| Commercial paper | 255 |  |  | — |  |  | — |  |  | 255 |  |
| Certificates of deposit | 250 |  |  | — |  |  | — |  |  | 250 |  |
| Total | $ | 12,467 |  |  | $ | 2 |  |  | $ | (522) |  |  | $ | 11,947 |  |

- added (2023-11-21):
[0000858877-23-000031:note_history:43]
| July 29, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 3,587 |  |  | $ | 1 |  |  | $ | (62) |  |  | $ | 3,526 |  |
| U.S. government agency securities | 428 |  |  | — |  |  | (5) |  |  | 423 |  |
| Non-U.S. government and agency securities | 364 |  |  | — |  |  | (1) |  |  | 363 |  |
| Corporate debt securities | 7,238 |  |  | 3 |  |  | (327) |  |  | 6,914 |  |
| U.S. agency mortgage-backed securities | 2,421 |  |  | 14 |  |  | (230) |  |  | 2,205 |  |
| Commercial paper | 1,484 |  |  | — |  |  | — |  |  | 1,484 |  |
| Certificates of deposit | 677 |  |  | — |  |  | — |  |  | 677 |  |
| Total | $ | 16,199 |  |  | $ | 18 |  |  | $ | (625) |  |  | $ | 15,592 |  |

- added (2023-11-21):
[0000858877-23-000031:note_history:44]
|  | Three Months Ended |
|  | October 28, 2023 |  | October 29, 2022 |
| Gross realized gains | $ | — |  |  | $ | — |  |
| Gross realized losses | (20) |  |  | (6) |  |
| Total | $ | (20) |  |  | $ | (6) |  |

- changed (2023-11-21):
[0000858877-23-000031:note_history:45]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 28, 2023 and July 29, 2023 (in millions):
  (was, 2023-05-24, similarity 0.9716):
[0000858877-23-000013:note_history:45]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 29, 2023 and July 30, 2022 (in millions):

- changed (2023-11-21):
[0000858877-23-000031:note_history:46]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 28, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,844 |  |  | $ | (38) |  |  | $ | 680 |  |  | $ | (34) |  |  | $ | 2,524 |  |  | $ | (72) |  |
| U.S. government agency securities | 377 |  |  | (3) |  |  | 38 |  |  | (3) |  |  | 415 |  |  | (6) |  |
| Non-U.S. government and agency securities | 324 |  |  | — |  |  | — |  |  | — |  |  | 324 |  |  | — |  |
| Corporate debt securities | 1,679 |  |  | (29) |  |  | 4,275 |  |  | (304) |  |  | 5,954 |  |  | (333) |  |
| U.S. agency mortgage-backed securities | 798 |  |  | (45) |  |  | 1,315 |  |  | (273) |  |  | 2,113 |  |  | (318) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Certificates of deposit | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 5,042 |  |  | $ | (115) |  |  | $ | 6,308 |  |  | $ | (614) |  |  | $ | 11,350 |  |  | $ | (729) |  |
  (was, 2023-05-24, similarity 0.9935):
[0000858877-23-000013:note_history:46]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 29, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 360 |  |  | $ | (2) |  |  | $ | 1,125 |  |  | $ | (40) |  |  | $ | 1,485 |  |  | $ | (42) |  |
| U.S. government agency securities | 148 |  |  | (1) |  |  | 110 |  |  | (3) |  |  | 258 |  |  | (4) |  |
| Non-U.S. government and agency securities | 291 |  |  | — |  |  | — |  |  | — |  |  | 291 |  |  | — |  |
| Corporate debt securities | 1,387 |  |  | (14) |  |  | 4,869 |  |  | (261) |  |  | 6,256 |  |  | (275) |  |
| U.S. agency mortgage-backed securities | 343 |  |  | (5) |  |  | 1,514 |  |  | (203) |  |  | 1,857 |  |  | (208) |  |
| Commercial paper | 69 |  |  | — |  |  | — |  |  | — |  |  | 69 |  |  | — |  |
| Certificates of deposit | 5 |  |  | — |  |  | — |  |  | — |  |  | 5 |  |  | — |  |
| Total | $ | 2,603 |  |  | $ | (22) |  |  | $ | 7,618 |  |  | $ | (507) |  |  | $ | 10,221 |  |  | $ | (529) |  |

- changed (2023-11-21):
[0000858877-23-000031:note_history:47]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 2,394 |  |  | $ | (26) |  |  | $ | 931 |  |  | $ | (36) |  |  | $ | 3,325 |  |  | $ | (62) |  |
| U.S. government agency securities | 343 |  |  | (2) |  |  | 72 |  |  | (3) |  |  | 415 |  |  | (5) |  |
| Non-U.S. government and agency securities | 363 |  |  | (1) |  |  | — |  |  | — |  |  | 363 |  |  | (1) |  |
| Corporate debt securities | 1,736 |  |  | (22) |  |  | 4,315 |  |  | (275) |  |  | 6,051 |  |  | (297) |  |
| U.S. agency mortgage-backed securities | 658 |  |  | (13) |  |  | 1,438 |  |  | (217) |  |  | 2,096 |  |  | (230) |  |
| Commercial paper | 97 |  |  | — |  |  | — |  |  | — |  |  | 97 |  |  | — |  |
| Certificates of deposit | 2 |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |
| Total | $ | 5,593 |  |  | $ | (64) |  |  | $ | 6,756 |  |  | $ | (531) |  |  | $ | 12,349 |  |  | $ | (595) |  |
  (was, 2023-05-24, similarity 0.7977):
[0000858877-23-000013:note_history:47]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 30, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,110 |  |  | $ | (44) |  |  | $ | 120 |  |  | $ | (5) |  |  | $ | 1,230 |  |  | $ | (49) |  |
| U.S. government agency securities | 114 |  |  | (2) |  |  | 24 |  |  | (2) |  |  | 138 |  |  | (4) |  |
| Non-U.S. government and agency securities | 264 |  |  | — |  |  | — |  |  | — |  |  | 264 |  |  | — |  |
| Corporate debt securities | 6,920 |  |  | (240) |  |  | 422 |  |  | (37) |  |  | 7,342 |  |  | (277) |  |
| U.S. agency mortgage-backed securities | 1,305 |  |  | (96) |  |  | 615 |  |  | (62) |  |  | 1,920 |  |  | (158) |  |
| Total | $ | 9,713 |  |  | $ | (382) |  |  | $ | 1,181 |  |  | $ | (106) |  |  | $ | 10,894 |  |  | $ | (488) |  |

- changed (2023-11-21):
[0000858877-23-000031:note_history:48]
The following table summarizes the maturities of our available-for-sale debt investments as of October 28, 2023 (in millions):
  (was, 2023-05-24, similarity 0.9583):
[0000858877-23-000013:note_history:48]
The following table summarizes the maturities of our available-for-sale debt investments as of April 29, 2023 (in millions):

- added (2023-11-21):
[0000858877-23-000031:note_history:49]
We held marketable equity securities of $409 million and $431 million as of October 28, 2023 and July 29, 2023, respectively. We recognized a net unrealized loss of $42 million and $20 million during the first quarter of fiscal 2024 and 2023, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $12 million for the first quarter of fiscal 2023. These adjustments were not material for the first quarter of fiscal 2024. We held equity interests in certain private equity funds of $0.9 billion as of each of October 28, 2023 and July 29, 2023, which are accounted for under the NAV practical expedient.

- changed (2023-11-21):
[0000858877-23-000031:note_history:50]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 28, 2023, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2023-05-24, similarity 0.8244):
[0000858877-23-000013:note_history:50]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 29, 2023, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- changed (2023-11-21):
[0000858877-23-000031:note_history:51]
The carrying value of our investments in privately held companies was $1.8 billion as of each of October 28, 2023 and July 29, 2023. Of the total carrying value of our investments in privately held companies as of October 28, 2023, $0.9 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of October 28, 2023, we have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.
  (was, 2023-05-24, similarity 0.9421):
[0000858877-23-000013:note_history:51]
The carrying value of our investments in privately held companies was $1.8 billion and $1.9 billion as of April 29, 2023 and July 30, 2022, respectively. Of the total carrying value of our investments in privately held companies as of April 29, 2023, $1.0 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of April 29, 2023, we have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.

- removed (2023-11-21):
[0000858877-23-000013:note_history:52]
| April 29, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,833 |  |  | $ | 9 |  |  | $ | (42) |  |  | $ | 2,800 |  |
| U.S. government agency securities | 365 |  |  | 1 |  |  | (4) |  |  | 362 |  |
| Non-U.S. government and agency securities | 352 |  |  | — |  |  | — |  |  | 352 |  |
| Corporate debt securities | 7,587 |  |  | 8 |  |  | (305) |  |  | 7,290 |  |
| U.S. agency mortgage-backed securities | 2,221 |  |  | 1 |  |  | (208) |  |  | 2,014 |  |
| Commercial paper | 1,595 |  |  | — |  |  | — |  |  | 1,595 |  |
| Certificates of deposit | 485 |  |  | — |  |  | — |  |  | 485 |  |
| Total | $ | 15,438 |  |  | $ | 19 |  |  | $ | (559) |  |  | $ | 14,898 |  |

- removed (2023-11-21):
[0000858877-23-000013:note_history:53]
Net unsettled investment purchases were $9 million and net unsettled investment sales were $70 million as of April 29, 2023 and July 30, 2022, respectively, and were included in other current assets and other current liabilities.

- removed (2023-11-21):
[0000858877-23-000013:note_history:54]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2023 |  | April 30, 2022 |  | April 29, 2023 |  | April 30, 2022 |
| Gross realized gains | $ | 1 |  |  | $ | 8 |  |  | $ | 4 |  |  | $ | 27 |  |
| Gross realized losses | (7) |  |  | (6) |  |  | (19) |  |  | (9) |  |
| Total | $ | (6) |  |  | $ | 2 |  |  | $ | (15) |  |  | $ | 18 |  |

- removed (2023-11-21):
[0000858877-23-000013:note_history:55]
We held marketable equity securities of $346 million and $241 million as of April 29, 2023 and July 30, 2022, respectively. We recognized a net unrealized loss of $2 million and $11 million during the third quarter and first nine months of fiscal 2023, respectively, and a net unrealized loss of $19 million and $32 million during the corresponding periods of fiscal 2022, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $7 million and a net loss of $2 million for the third quarter and first nine months of fiscal 2023, respectively, and a net gain of $11 million and $28 million for the corresponding periods of fiscal 2022, respectively. We held equity interests in certain private equity funds of $0.9 billion and $1.1 billion as of April 29, 2023 and July 30, 2022, respectively, which are accounted for under the NAV practical expedient.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-21):
[0000858877-23-000031:note_history:56]
|  |  |  | October 28, 2023 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 6.33% |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.63% |  | 500 |  |  | 6.38% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 7,750 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (68) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (32) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 7,650 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 990 |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 6,660 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 7,650 |  |  |  |  | $ | 8,391 |  |  |  |
  (was, 2023-05-24, similarity 0.9489):
[0000858877-23-000013:note_history:56]
|  |  |  | April 29, 2023 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 5.75% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.15% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 8,500 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (70) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (36) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,394 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,731 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 6,663 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,394 |  |  |  |  | $ | 8,915 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-21):
[0000858877-23-000031:note_history:57]
As of October 28, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2023-05-24, similarity 0.9627):
[0000858877-23-000013:note_history:57]
As of April 29, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2023-11-21):
[0000858877-23-000031:note_history:58]
| Fiscal Year | Amount |
| 2024 (remaining nine months) | $ | 1,000 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 7,750 |  |
  (was, 2023-05-24, similarity 0.9356):
[0000858877-23-000013:note_history:58]
| Fiscal Year | Amount |
| 2023 (remaining three months) | $ | — |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 8,500 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-21):
[0000858877-23-000031:note_history:59]
|  | October 28, 2023 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 990 |  |  | 6.33 | % |  | $ | 1,733 |  |  | 4.45 | % |
  (was, 2023-05-24, similarity 0.7586):
[0000858877-23-000013:note_history:59]
|  | April 29, 2023 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,731 |  |  | 4.26 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,731 |  |  |  |  | $ | 1,099 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-11-21):
[0000858877-23-000031:note_history:60]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |
| Product revenue: |  |  |  |
| Networking | $ | 8,822 |  |  | $ | 8,031 |  |
| Security | 1,010 |  |  | 971 |  |
| Collaboration | 1,117 |  |  | 1,086 |  |
| Observability | 190 |  |  | 157 |  |
| Total Product | 11,139 |  |  | 10,245 |  |
| Services | 3,529 |  |  | 3,387 |  |
| Total | $ | 14,668 |  |  | $ | 13,632 |  |

- added (2023-11-21):
[0000858877-23-000031:note_history:61]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |
| Revenue: |  |  |  |
| Networking | $ | 8,822 |  |  | $ | 8,031 |  |
| Security | 1,010 |  |  | 971 |  |
| Collaboration | 1,117 |  |  | 1,086 |  |
| Observability | 190 |  |  | 157 |  |
| Total Product | 11,139 |  |  | 10,245 |  |
| Services | 3,529 |  |  | 3,387 |  |
| Total | $ | 14,668 |  |  | $ | 13,632 |  |

- removed (2023-11-21):
[0000858877-23-000013:note_history:62]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |  | April 29, 2023 |  | April 30, 2022 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 7,550 |  |  | $ | 5,870 |  |  | $ | 20,980 |  |  | $ | 17,737 |  |
| Internet for the Future | 1,392 |  |  | 1,324 |  |  | 4,007 |  |  | 4,019 |  |
| Collaboration | 985 |  |  | 1,132 |  |  | 3,029 |  |  | 3,308 |  |
| End-to-End Security | 958 |  |  | 938 |  |  | 2,872 |  |  | 2,716 |  |
| Optimized Application Experiences | 204 |  |  | 183 |  |  | 597 |  |  | 544 |  |
| Other Products | 3 |  |  | 2 |  |  | 7 |  |  | 7 |  |
| Total Product | 11,092 |  |  | 9,448 |  |  | 31,492 |  |  | 28,330 |  |
| Services | 3,479 |  |  | 3,387 |  |  | 10,303 |  |  | 10,125 |  |
| Total | $ | 14,571 |  |  | $ | 12,835 |  |  | $ | 41,795 |  |  | $ | 38,455 |  |

- removed (2023-11-21):
[0000858877-23-000013:note_history:63]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |  | April 29,2023 |  | April 30,2022 |
| Revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 7,550 |  |  | $ | 5,870 |  |  | $ | 20,980 |  |  | $ | 17,737 |  |
| Internet for the Future | 1,392 |  |  | 1,324 |  |  | 4,007 |  |  | 4,019 |  |
| Collaboration | 985 |  |  | 1,132 |  |  | 3,029 |  |  | 3,308 |  |
| End-to-End Security | 958 |  |  | 938 |  |  | 2,872 |  |  | 2,716 |  |
| Optimized Application Experiences | 204 |  |  | 183 |  |  | 597 |  |  | 544 |  |
| Other Products | 3 |  |  | 2 |  |  | 7 |  |  | 7 |  |
| Total Product | 11,092 |  |  | 9,448 |  |  | 31,492 |  |  | 28,330 |  |
| Services | 3,479 |  |  | 3,387 |  |  | 10,303 |  |  | 10,125 |  |
| Total | $ | 14,571 |  |  | $ | 12,835 |  |  | $ | 41,795 |  |  | $ | 38,455 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-11-21):
[0000858877-23-000031:note_history:64]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

- added (2023-11-21):
[0000858877-23-000031:note_history:65]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized

- added (2023-11-21):
[0000858877-23-000031:note_history:66]
upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

- changed (2023-11-21):
[0000858877-23-000031:note_history:67]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 28, 2023 and July 29, 2023 was $37 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2023-05-24, similarity 0.9793):
[0000858877-23-000013:note_history:67]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 29, 2023 and July 30, 2022 was $38 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- removed (2023-11-21):
[0000858877-23-000013:note_history:68]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-11-21):
[0000858877-23-000031:note_history:69]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

- added (2023-11-21):
[0000858877-23-000031:note_history:70]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized

- added (2023-11-21):
[0000858877-23-000031:note_history:71]
upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

- changed (2023-11-21):
[0000858877-23-000031:note_history:72]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 28, 2023 and July 29, 2023 was $37 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2023-05-24, similarity 0.9793):
[0000858877-23-000013:note_history:72]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 29, 2023 and July 30, 2022 was $38 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2023-11-21):
[0000858877-23-000031:note_history:73]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. Effective in the first quarter of fiscal 2024, we began reporting our product and service revenue in the following categories: Networking, Security, Collaboration, Observability, and Services and conformed our product revenue for prior periods to the current period presentation. The following table presents this disaggregation of revenue (in millions):
  (was, 2023-05-24, similarity 0.7629):
[0000858877-23-000013:note_history:73]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. The following table presents this disaggregation of revenue (in millions):

- added (2023-11-21):
[0000858877-23-000031:note_history:74]
|  | Three Months Ended |
|  | October 28,2023 |  | October 29,2022 |
| Product revenue: |  |  |  |
| Networking | $ | 8,822 |  |  | $ | 8,031 |  |
| Security | 1,010 |  |  | 971 |  |
| Collaboration | 1,117 |  |  | 1,086 |  |
| Observability | 190 |  |  | 157 |  |
| Total Product | 11,139 |  |  | 10,245 |  |
| Services | 3,529 |  |  | 3,387 |  |
| Total | $ | 14,668 |  |  | $ | 13,632 |  |

- added (2023-11-21):
[0000858877-23-000031:note_history:75]
Amounts may not sum due to rounding.

- changed (2023-11-21):
[0000858877-23-000031:note_history:76]
Networking consists of our core networking technologies of switching, routing, wireless, 5G, silicon, optics solutions and compute products. These technologies consist of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.
  (was, 2023-05-24, similarity 0.8859):
[0000858877-23-000013:note_history:76]
Secure, Agile Networks consists of our core networking technologies of switching, enterprise routing, wireless, and compute products. These technologies consist of both hardware and software offerings, including software licenses and SaaS, that help our customers build networks, automate, orchestrate, integrate, and digitize data. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2023-11-21):
[0000858877-23-000031:note_history:77]
Security consists of our Cloud and Application Security, Industrial Security, Network Security, and User and Device Security offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2023-11-21):
[0000858877-23-000031:note_history:78]
Observability consists of our full stack observability offerings. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- changed (2023-11-21):
[0000858877-23-000031:note_history:79]
Accounts receivable, net was $4.8 billion as of October 28, 2023 compared to $5.9 billion as of July 29, 2023, as reported on the Consolidated Balance Sheets.
  (was, 2023-05-24, similarity 0.9648):
[0000858877-23-000013:note_history:79]
Accounts receivable, net was $5.1 billion as of April 29, 2023 compared to $6.6 billion as of July 30, 2022, as reported on the Consolidated Balance Sheets.

- added (2023-11-21):
[0000858877-23-000031:note_history:80]
|  | Three Months Ended |
|  | October 28, 2023 |  | October 29, 2022 |
| Allowance for credit loss at beginning of period | $ | 85 |  |  | $ | 83 |  |
| Provisions (benefits) | 2 |  |  | 11 |  |
| Recoveries (write-offs), net | (5) |  |  | (6) |  |
| Allowance for credit loss at end of period | $ | 82 |  |  | $ | 88 |  |

- changed (2023-11-21):
[0000858877-23-000031:note_history:81]
|  | October 28,2023 |  | July 29,2023 |
| 1 to 4 | $ | 650 |  |  | $ | 672 |  |
| 5 to 6 | 1,015 |  |  | 954 |  |
| 7 and Higher | 68 |  |  | 60 |  |
| Total | $ | 1,733 |  |  | $ | 1,686 |  |
  (was, 2023-05-24, similarity 0.9658):
[0000858877-23-000013:note_history:81]
|  | April 29,2023 |  | July 30,2022 |
| 1 to 4 | $ | 456 |  |  | $ | 414 |  |
| 5 to 6 | 933 |  |  | 814 |  |
| 7 and Higher | 71 |  |  | 158 |  |
| Total | $ | 1,460 |  |  | $ | 1,386 |  |

- changed (2023-11-21):
[0000858877-23-000031:note_history:82]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of October 28, 2023 and July 29, 2023, our contract assets for these unbilled receivables, net of allowances, were $1.7 billion and $1.6 billion, respectively, and were included in other current assets and other assets.
  (was, 2023-05-24, similarity 0.7314):
[0000858877-23-000013:note_history:82]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, was $1.4 billion as of April 29, 2023 and $1.3 billion as of  July 30, 2022, and were included in other current assets and other assets.

- added (2023-11-21):
[0000858877-23-000031:note_history:83]
Contract liabilities consist of deferred revenue. Deferred revenue was $25.7 billion as of October 28, 2023 compared to $25.6 billion as of July 29, 2023. We recognized approximately $4.7 billion of revenue during the first quarter of fiscal 2024 that was included in the deferred revenue balance at July 29, 2023.

- added (2023-11-21):
[0000858877-23-000031:note_history:84]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Capitalized contract acquisition costs were $1.2 billion and $1.1 billion as of October 28, 2023 and July 29, 2023, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $158 million and $176 million for the first quarter of fiscal 2024 and 2023, respectively, and was included in sales and marketing expenses.

- removed (2023-11-21):
[0000858877-23-000013:note_history:85]
Revenue We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

- removed (2023-11-21):
[0000858877-23-000013:note_history:86]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |  | April 29, 2023 |  | April 30, 2022 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 7,550 |  |  | $ | 5,870 |  |  | $ | 20,980 |  |  | $ | 17,737 |  |
| Internet for the Future | 1,392 |  |  | 1,324 |  |  | 4,007 |  |  | 4,019 |  |
| Collaboration | 985 |  |  | 1,132 |  |  | 3,029 |  |  | 3,308 |  |
| End-to-End Security | 958 |  |  | 938 |  |  | 2,872 |  |  | 2,716 |  |
| Optimized Application Experiences | 204 |  |  | 183 |  |  | 597 |  |  | 544 |  |
| Other Products | 3 |  |  | 2 |  |  | 7 |  |  | 7 |  |
| Total Product | 11,092 |  |  | 9,448 |  |  | 31,492 |  |  | 28,330 |  |
| Services | 3,479 |  |  | 3,387 |  |  | 10,303 |  |  | 10,125 |  |
| Total | $ | 14,571 |  |  | $ | 12,835 |  |  | $ | 41,795 |  |  | $ | 38,455 |  |

- removed (2023-11-21):
[0000858877-23-000013:note_history:87]
Amounts may not sum due to rounding. We have made certain reclassifications to the product revenue amounts for prior periods to conform to the current year presentation.

- removed (2023-11-21):
[0000858877-23-000013:note_history:88]
Internet for the Future consists of our routed optical networking, 5G, silicon, and optics solutions. These products consist primarily of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2023-11-21):
[0000858877-23-000013:note_history:89]
End-to-End Security consists of our Network Security, Cloud Security, Security Endpoints, Unified Threat Management and Zero Trust offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2023-11-21):
[0000858877-23-000013:note_history:90]
Optimized Application Experiences consists of our full stack observability and cloud-native platform offerings. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2023-11-21):
[0000858877-23-000013:note_history:91]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2023 |  | April 30, 2022 |  | April 29, 2023 |  | April 30, 2022 |
| Allowance for credit loss at beginning of period | $ | 86 |  |  | $ | 70 |  |  | $ | 83 |  |  | $ | 109 |  |
| Provisions (benefits) | 9 |  |  | 17 |  |  | 23 |  |  | 53 |  |
| Recoveries (write-offs), net | (12) |  |  | (9) |  |  | (23) |  |  | (75) |  |
| Foreign exchange and other | — |  |  | — |  |  | — |  |  | (9) |  |
| Allowance for credit loss at end of period | $ | 83 |  |  | $ | 78 |  |  | $ | 83 |  |  | $ | 78 |  |

- removed (2023-11-21):
[0000858877-23-000013:note_history:92]
Contract liabilities consist of deferred revenue. Deferred revenue was $24.3 billion as of April 29, 2023 compared to $23.3 billion as of July 30, 2022. We recognized approximately $2.7 billion and $10.6 billion of revenue during the third quarter and first nine months of fiscal 2023, respectively, that was included in the deferred revenue balance at July 30, 2022. 
(c)Capitalized Contract Acquisition CostsWe capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $1.0 billion as of each of April 29, 2023 and July 30, 2022, and were included in other current assets and other assets. The amortization expense associated with these costs was $172 million and $549 million for the third quarter and first nine months of fiscal 2023, respectively, and $175 million and $492 million for the corresponding periods of fiscal 2022, respectively, and was included in sales and marketing expenses.
