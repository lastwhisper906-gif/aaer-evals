# CSCO 10-K controls and the auditor's report


## auditors_report

[0000858877-24-000017:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0000858877-24-000017:auditors_report:2]
To the Board of Directors and Stockholders of Cisco Systems, Inc.

[0000858877-24-000017:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0000858877-24-000017:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Cisco Systems, Inc. and its subsidiaries (the “Company”) as of July 27, 2024 and July 29, 2023, and the related consolidated statements of operations, of comprehensive income, of equity and of cash flows for each of the three years in the period ended July 27, 2024, including the related notes (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of July 27, 2024, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0000858877-24-000017:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of July 27, 2024 and July 29, 2023, and the results of its operations and its cash flows for each of the three years in the period ended July 27, 2024 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of July 27, 2024, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0000858877-24-000017:auditors_report:6]
Basis for Opinions

[0000858877-24-000017:auditors_report:7]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000858877-24-000017:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0000858877-24-000017:auditors_report:9]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0000858877-24-000017:auditors_report:10]
As described in Management’s Report on Internal Control over Financial Reporting, management has excluded Splunk Inc. (“Splunk”) from its assessment of internal control over financial reporting as of July 27, 2024, because it was acquired by the Company in a purchase business combination during 2024. We have also excluded Splunk from our audit of internal control over financial reporting. Splunk is a wholly-owned subsidiary whose total assets and total revenues excluded from management’s assessment and our audit of internal control over financial reporting represent approximately 3% and 3%, respectively, of the related consolidated financial statement amounts as of and for the year ended July 27, 2024.

[0000858877-24-000017:auditors_report:11]
Definition and Limitations of Internal Control over Financial Reporting

[0000858877-24-000017:auditors_report:12]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000858877-24-000017:auditors_report:13]
54

[0000858877-24-000017:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000858877-24-000017:auditors_report:15]
Critical Audit Matters

[0000858877-24-000017:auditors_report:16]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that (i) relate to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0000858877-24-000017:auditors_report:17]
Revenue Recognition for Certain Product and Services Revenue

[0000858877-24-000017:auditors_report:18]
As described in Note 2 to the consolidated financial statements, the Company derives revenue from contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. The Company recognizes revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration the Company expects to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. In certain customer arrangements, management applies judgment in identifying contractual terms and determining the transaction price and management may be required to estimate variable consideration when determining the amount of revenue to recognize. For the year ended July 27, 2024, the Company’s total revenue was $53.8 billion, of which the majority relates to certain product and services revenue.

[0000858877-24-000017:auditors_report:19]
The principal considerations for our determination that performing procedures relating to revenue recognition for certain product and services revenue is a critical audit matter are the significant judgment by management in identifying contractual terms in certain customer arrangements and a high degree of auditor judgment and effort in performing procedures and evaluating audit evidence relating to revenue recognition for certain product and services revenue.

[0000858877-24-000017:auditors_report:20]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the revenue recognition process, including obtaining an understanding of management’s process for identifying and evaluating terms and conditions in certain customer arrangements and evaluating management’s determination of the impact of those terms and conditions on revenue recognition. These procedures also included, among others, testing, on a sample basis, (a) the completeness and accuracy of management’s identification and evaluation of terms and conditions by examining customer arrangements; (b) management’s process for determining the appropriate amount and timing of revenue recognition based on the contractual terms identified in customer arrangements; (c) revenue transactions by obtaining and inspecting source documents, such as contracts, purchase orders, invoices, and proof of delivery; and (d) the timing of recognition of revenue transactions.

[0000858877-24-000017:auditors_report:21]
Acquisition of Splunk — Valuation of Customer Contracts and Related Relationships Asset and the Technology Asset Acquired

[0000858877-24-000017:auditors_report:22]
As described in Note 4 to the consolidated financial statements, on March 18, 2024, the Company completed the acquisition of Splunk for total consideration of approximately $27 billion. The Company acquired $10.6 billion of intangible assets in connection with the acquisition. Of these acquired intangible assets, $6.1 billion of customer-related assets were recorded, of which the majority relates to customer contracts and related relationships, and $3.9 billion for a technology asset was recorded.  The customer contracts and related relationships asset was valued using the with-and-without method under the income approach. The technology asset was valued using the multi-period excess earnings method under the income approach. The present value of projected future cash flows included significant judgment and assumptions regarding projected future revenues, projected expenses, attrition rates, the revenue build up period, and the discount rate for the customer contracts and related relationships asset and projected future revenues, projected expenses, the technology obsolescence rate, and the discount rate for the technology asset.

[0000858877-24-000017:auditors_report:23]
The principal considerations for our determination that performing procedures relating to the valuation of the customer contracts and related relationships asset and the technology asset acquired in connection with the acquisition of Splunk is a critical audit matter are (i) the significant judgment by management when developing the fair value estimate of the customer-related and technology assets acquired; (ii) a high degree of auditor judgment, subjectivity, and effort in performing procedures and evaluating management’s significant assumptions related to projected future revenues, projected expenses, attrition rates, the revenue build up period, and the discount rate for the customer contracts and related relationships asset and projected future revenues, projected expenses, the technology obsolescence rate, and the discount rate for the technology asset; and (iii) the audit effort involved the use of professionals with specialized skill and knowledge.

[0000858877-24-000017:auditors_report:24]
55

[0000858877-24-000017:auditors_report:25]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the acquisition accounting, including controls over management’s valuation of the customer contracts and related relationships asset and the technology asset acquired. These procedures also included, among others, (i) reading the purchase agreement; (ii) testing management’s process for developing the fair value estimate of the customer contracts and related relationships asset and the technology asset; (iii) evaluating the appropriateness of the income approach methods used by management; (iv) testing the completeness and accuracy of the underlying data used in the income approach methods; and (v) evaluating the reasonableness of significant assumptions used by management related to projected future revenues, projected expenses, attrition rates, the revenue build up period, and the discount rate for the  customer contracts and related relationships asset and projected future revenues, projected expenses, the technology obsolescence rate, and the discount rate for the technology asset. Evaluating management’s assumptions related to projected future revenues, projected expenses, attrition rates, the revenue build up period, and the technology obsolescence rate involved considering (i) the current and past performance of Splunk; (ii) the consistency with external market and industry data; and (iii) whether the assumptions were consistent with evidence obtained in other areas of the audit. Professionals with specialized skill and knowledge were used to assist in evaluating (i) the appropriateness of the income approach methods and (ii) the reasonableness of the discount rate assumptions for the customer contracts and related relationships asset and the technology asset.

[0000858877-24-000017:auditors_report:26]
/s/ PricewaterhouseCoopers LLP

[0000858877-24-000017:auditors_report:27]
San Jose, California

[0000858877-24-000017:auditors_report:28]
September 5, 2024

[0000858877-24-000017:auditors_report:29]
We have served as the Company’s auditor since 1988.

[0000858877-24-000017:auditors_report:30]
56


## item_9a

[0000858877-24-000017:item_9a:1]
| Item 9A. | Controls and Procedures |

[0000858877-24-000017:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000858877-24-000017:item_9a:3]
Based on our management’s evaluation (with the participation of our principal executive officer and principal financial officer), as of the end of the period covered by this report, our principal executive officer and principal financial officer have concluded that our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”)), are effective to ensure that information required to be disclosed by us in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in Securities and Exchange Commission rules and forms and is accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0000858877-24-000017:item_9a:4]
Internal Control over Financial Reporting

[0000858877-24-000017:item_9a:5]
Management’s report on our internal control over financial reporting and the report of our independent registered public accounting firm on our internal control over financial reporting are set forth, respectively, on page 57 under the caption “Management’s Report on Internal Control Over Financial Reporting” and on page 54 of this report.

[0000858877-24-000017:item_9a:6]
There was no change in our internal control over financial reporting during our fourth quarter of fiscal 2024 that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.

[0000858877-24-000017:item_9a:7]
In accordance with guidance issued by the Securities and Exchange Commission staff, companies are permitted to exclude acquisitions from their assessment of internal control over financial reporting for a period not to exceed one year from the date of the acquisition. Management’s assessment of the effectiveness of our internal control over financial reporting as of July 27, 2024 did not include the internal controls of Splunk, which we acquired on March 18, 2024. We have included the financial results of Splunk in our Consolidated Financial Statements since the date of acquisition. Total assets and total revenues of Splunk represented approximately 3 percent of each of our total consolidated assets and total consolidated revenue as of and for the year ended July 27, 2024.
