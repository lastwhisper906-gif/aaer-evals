# CSCO notes — 0000858877-24-000017


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000858877-24-000017:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to the 2024 Annual Meeting of Stockholders, to be held on December 9, 2024, are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-24-000017:notes:2]
Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2024, fiscal 2023 and fiscal 2022 were each 52-week fiscal years. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-24-000017:notes:3]
Our consolidated financial statements include our accounts and investments consolidated under the voting interest model. The noncontrolling interests attributed to these investments are not presented as a separate component in the equity section of the Consolidated Balance Sheets as these amounts are not material for any of the fiscal periods presented. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-24-000017:notes:4]
Certain reclassifications have been made to the amounts for prior years in order to conform to the current year’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-24-000017:notes:5]
Summary of Significant Accounting Policies
(a) Cash and Cash Equivalents   We consider all highly liquid investments purchased with an original or remaining maturity of three months or less at the date of purchase to be cash equivalents. Cash and cash equivalents are maintained with various financial institutions.

[0000858877-24-000017:notes:6]
(b) Available-for-Sale Debt Investments   We classify our investments in fixed income securities as available-for-sale debt investments. Our available-for-sale debt investments primarily consist of U.S. government, U.S. government agency, non-U.S. government and agency, corporate debt, U.S. agency mortgage-backed securities, commercial paper and certificates of deposit. These available-for-sale debt investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of available-for-sale debt investments sold. These investments are recorded in the Consolidated Balance Sheets at fair value. Unrealized gains and losses on these investments are included as a separate component of accumulated other comprehensive income (loss) (AOCI), net of tax. We classify our investments as current based on the nature of the investments and their availability for use in current operations.

[0000858877-24-000017:notes:7]
(c) Equity Instruments   Our equity investments are accounted for as follows:

[0000858877-24-000017:notes:8]
•Marketable equity securities have readily determinable fair value (RDFV) that are measured and recorded at fair value through income.

[0000858877-24-000017:notes:9]
•Non-marketable equity securities do not have RDFV and are measured using a measurement alternative recorded at cost less any impairment, plus or minus changes resulting from qualifying observable price changes. For certain of these securities, we have elected to apply the net asset value (NAV) practical expedient. The NAV is the estimated fair value of these investments.

[0000858877-24-000017:notes:10]
•Equity method investments are securities we do not control, but are able to exert significant influence over the investee. These investments are measured at cost less any impairment, plus or minus our share of equity method investee income or loss.

[0000858877-24-000017:notes:11]
(d) Impairments of Investments   For our available-for-sale debt securities in an unrealized loss position, we determine whether a credit loss exists. In this assessment, among other factors, we consider the extent to which the fair value is less than the amortized cost, any changes to the rating of the security by a rating agency, and adverse conditions specifically related to the security. If factors indicate a credit loss exists, an allowance for credit loss is recorded to other income (loss), net, limited by the amount that the fair value is less than the amortized cost basis. The amount of fair value change relating to all other factors is recognized in other comprehensive income (OCI).

[0000858877-24-000017:notes:12]
We hold non-marketable equity and other investments (“privately held investments”) which are included in other assets in the Consolidated Balance Sheets. We monitor these investments for impairments and make reductions in carrying values if we determine that an impairment charge is required based primarily on the financial condition and near-term prospects of these companies.

[0000858877-24-000017:notes:13]
(e) Inventories   Inventories are stated at the lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. We provide inventory write-downs based on excess and obsolete inventories determined primarily by future demand forecasts. The write-down is measured as the difference between the cost of the inventory and net realizable value based upon assumptions about future demand and charged to the provision for inventory, which is a component of cost of sales. At the point of loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In addition, we record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0000858877-24-000017:notes:14]
(f) Allowance for Accounts Receivable, Contract Assets and Financing Receivables   We estimate our allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, we determine collectibility by pooling our assets with similar characteristics.

[0000858877-24-000017:notes:15]
The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. Our internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality. Assets that do not share risk characteristics are evaluated on an individual basis. The allowances for credit losses are each measured by multiplying the exposure probability of default, the probability the asset will default within a given time frame, by the loss given default rate, the percentage of the asset not expected to be collected due to default, based on the pool of assets.

[0000858877-24-000017:notes:16]
Probability of default rates are published quarterly by third-party credit agencies. Adjustments to our internal credit risk ratings may take into account including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000858877-24-000017:notes:17]
(g) Financing Receivables and Guarantees   We provide financing arrangements, including loan receivables and lease receivables, for certain qualified end-user customers to build, maintain, and upgrade their networks. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services (including technical support and advanced services), and also may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables have terms of one year to three years on average. Lease receivables represent sales-type leases resulting from the sale of Cisco’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average.

[0000858877-24-000017:notes:18]
Outstanding financing receivables that are aged 31 days or more from the contractual payment date are considered past due. We do not accrue interest on financing receivables that are considered impaired and more than 120 days past due unless either the receivable has not been collected due to administrative reasons or the receivable is well secured and in the process of collection. Financing receivables may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain. After a financing receivable has been categorized as nonaccrual, interest will be recognized when cash is received. A financing receivable may be returned to accrual status after all of the customer’s delinquent balances of principal and interest have been settled, and the customer remains current for an appropriate period.

[0000858877-24-000017:notes:19]
We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive a payment for the receivables from the third party based on our standard payment terms. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Deferred revenue relating to these financing arrangements is recorded in accordance with revenue recognition policies or for the fair value of the financing guarantees.

[0000858877-24-000017:notes:20]
(h) Leases   We lease real estate, information technology (IT) and other equipment and vehicles. We also have arrangements with certain suppliers and contract manufacturers which includes the leasing of dedicated space and equipment costs. Our leases have the option to extend or terminate the lease when it is reasonably certain that we will exercise that option.

[0000858877-24-000017:notes:21]
As a lessee, we determine if an arrangement is a lease at commencement. Our ROU lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments related to the lease. Operating lease ROU assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. We use incremental borrowing rates based on information available at the commencement date to determine the present value of our lease payments. Certain of our lease agreements contain variable lease payments. Our

[0000858877-24-000017:notes:22]
variable lease payments can fluctuate depending on the level of activity or the cost of certain services where we have elected to combine lease and non-lease components. While these payments are not included as part of our lease liabilities, they are recognized as variable lease expense in the period they are incurred.

[0000858877-24-000017:notes:23]
We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. As a lessor, we determine if an arrangement is a lease at inception. We provide leasing arrangements for our equipment to certain qualified customers. Our lease portfolio primarily consists of sales-type leases. We allocate the consideration in a bundled contract with our customers based on relative standalone selling prices of our lease and non-lease components. The residual value on our leased equipment is determined at the inception of the lease based on an analysis of estimates of the value of equipment, market factors and historical customer behavior. Residual value estimates are reviewed on a periodic basis and other-than-temporary declines are expensed in the period they occur. Our leases generally provide an end-of-term option for the customer to extend the lease under mutually-agreed terms, return the leased equipment, or purchase the equipment for either the then-market value of the equipment or a pre-determined purchase price. If a customer chooses to terminate their lease prior to the original end of termination date, the customer is required to pay all remaining lease payments in full.

[0000858877-24-000017:notes:24]
(i) Depreciation and Amortization   Property and equipment are stated at cost, less accumulated depreciation or amortization, whenever applicable. Depreciation and amortization expenses for property and equipment were approximately $0.7 billion, $0.7 billion, and $0.8 billion for fiscal 2024, 2023, and 2022, respectively. Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-24-000017:notes:25]
| Asset Category |  | Period |
| Buildings |  | 25 years |
| Building improvements |  | Up to 15 years |
| Leasehold improvements |  | Shorter of remaining lease term or up to 15 years |
| Production, engineering, computer and other equipment and related software |  | Up to 5 years |
| Operating lease assets |  | Based on lease term |
| Furniture and fixtures |  | 5 years |

[0000858877-24-000017:notes:26]
(j) Business Combinations We allocate the fair value of the purchase consideration of our acquisitions to the tangible assets, liabilities, and intangible assets acquired, including in-process research and development (IPR&D), based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life. Acquisition-related expenses and related restructuring costs are recognized separately from the business combination and are expensed as incurred.

[0000858877-24-000017:notes:27]
(k) Goodwill and Purchased Intangible Assets   Goodwill is tested for impairment on an annual basis in the fourth fiscal quarter and, when specific circumstances dictate, between annual tests. When impaired, the carrying value of goodwill is written down to fair value. Identifying a potential impairment consists of comparing the fair value of a reporting unit with its carrying amount, including goodwill. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. See “Long-Lived Assets” for our policy regarding impairment testing of purchased intangible assets with finite lives. Purchased intangible assets with indefinite lives are assessed for potential impairment annually or when events or circumstances indicate that their carrying amounts might be impaired.

[0000858877-24-000017:notes:28]
(l) Long-Lived Assets   Long-lived assets that are held and used by us are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability of long-lived assets is based on an estimate of the undiscounted future cash flows resulting from the use of the asset and its eventual disposition. Measurement of an impairment loss for long-lived assets that management expects to hold and use is based on the difference between the fair value of the asset and its carrying value. Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0000858877-24-000017:notes:29]
(m) Fair Value   Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, we consider the principal or most

[0000858877-24-000017:notes:30]
advantageous market in which we would transact, and we also consider assumptions that market participants would use when pricing the asset or liability.

[0000858877-24-000017:notes:31]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. The standard establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement.

[0000858877-24-000017:notes:32]
The fair value hierarchy is as follows:

[0000858877-24-000017:notes:33]
Level 1 applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000858877-24-000017:notes:34]
Level 2 applies to assets or liabilities for which there are inputs other than quoted prices that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets); or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of assets or liabilities.

[0000858877-24-000017:notes:35]
Level 3 applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities. The fair values are determined based on model-based techniques such as discounted cash flow models using inputs that we could not corroborate with market data.

[0000858877-24-000017:notes:36]
(n) Derivative Instruments   We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.

[0000858877-24-000017:notes:37]
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.

[0000858877-24-000017:notes:38]
(o) Foreign Currency Translation   Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated to U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of AOCI. Income and expense accounts are translated at average exchange rates during the year. Remeasurement adjustments are recorded in other income (loss), net.

[0000858877-24-000017:notes:39]
(p) Concentrations of Risk   Cash and cash equivalents are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. We seek to mitigate our credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties.

[0000858877-24-000017:notes:40]
We perform ongoing credit evaluations of our customers and, with the exception of certain financing transactions, do not require collateral from our customers. We receive certain of our components from sole suppliers. Additionally, we rely on a limited number of contract manufacturers and suppliers to provide manufacturing services for our products. The inability of a contract manufacturer or supplier to fulfill our supply requirements could materially impact future operating results.

[0000858877-24-000017:notes:41]
(q) Revenue Recognition   We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers. Revenue from subscription offers includes revenue recognized over time as well as upfront.

[0000858877-24-000017:notes:42]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-24-000017:notes:43]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of July 27, 2024 and July 29, 2023 was $37 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-24-000017:notes:44]
Significant Judgments

[0000858877-24-000017:notes:45]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-24-000017:notes:46]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.

[0000858877-24-000017:notes:47]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license’s utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

[0000858877-24-000017:notes:48]
(r) Advertising Costs   We expense advertising costs as incurred. Advertising costs included within sales and marketing expenses were approximately $210 million, $205 million, and $219 million for fiscal 2024, 2023, and 2022, respectively.

[0000858877-24-000017:notes:49]
(s) Share-Based Compensation Expense   We measure and recognize the compensation expense for all share-based awards made to employees and directors, including employee stock options, restricted stock units (RSUs), performance-based restricted stock units (PRSUs), and employee stock purchases related to the Employee Stock Purchase Plan (Employee Stock Purchase Rights) based on estimated fair values. Share-based compensation expense is reduced for forfeitures as they occur.

[0000858877-24-000017:notes:50]
(t) Software Development Costs   Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized. Costs incurred during the application development stage for internal-use software and cloud-based applications are capitalized. Such software development costs capitalized during the periods presented were not material.

[0000858877-24-000017:notes:51]
(u) Income Taxes   Income tax expense is based on pretax financial accounting income. Deferred tax assets and liabilities are recognized for the expected tax consequences of temporary differences between the tax bases of assets and liabilities and their reported amounts. Valuation allowances are recorded to reduce deferred tax assets to the amount that will more likely than not be realized.

[0000858877-24-000017:notes:52]
We account for uncertainty in income taxes using a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. We classify the liability for unrecognized tax benefits as current to the extent that we anticipate payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.

[0000858877-24-000017:notes:53]
(v) Computation of Net Income per Share   Basic net income per share is computed using the weighted-average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted-average number of common shares and dilutive potential common shares outstanding during the period. Diluted shares outstanding includes the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares.

[0000858877-24-000017:notes:54]
(w) Consolidation of Variable Interest Entities   Our approach in assessing the consolidation requirement for variable interest entities focuses on identifying which enterprise has the power to direct the activities that most significantly impact the variable interest entity’s economic performance and which enterprise has the obligation to absorb losses or the right to receive benefits from the variable interest entity. Should we conclude that we are the primary beneficiary of a variable interest entity, the assets, liabilities, and results of operations of the variable interest entity will be included in our Consolidated Financial Statements.

[0000858877-24-000017:notes:55]
(x) Use of Estimates   The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Estimates are used for the following, among others:

[0000858877-24-000017:notes:56]
▪Revenue recognition

[0000858877-24-000017:notes:57]
▪Allowances for accounts receivable, sales returns, and financing receivables

[0000858877-24-000017:notes:58]
▪Inventory valuation and liability for purchase commitments with contract manufacturers and suppliers

[0000858877-24-000017:notes:59]
▪Loss contingencies and product warranties

[0000858877-24-000017:notes:60]
▪Fair value measurements

[0000858877-24-000017:notes:61]
▪Valuation of goodwill and purchased intangible assets

[0000858877-24-000017:notes:62]
▪Income taxes

[0000858877-24-000017:notes:63]
The actual results that we experience may differ materially from our estimates.

[0000858877-24-000017:notes:64]
(y) Recent Accounting Standards or Updates Not Yet Effective as of Fiscal Year End

[0000858877-24-000017:notes:65]
Segment Reporting     In November 2023, the Financial Accounting Standards Board (FASB) issued an accounting standard update that expands the disclosure requirements for reportable segments, primarily through enhanced disclosures around significant segment expenses. The accounting standard update will be effective for our fiscal 2025 Form 10-K on a retrospective basis, and early adoption is permitted. We are currently evaluating the impact of this accounting standard update on our segment disclosures.

[0000858877-24-000017:notes:66]
Improvements on Income Tax Disclosures     In December 2023, the FASB issued an accounting standard update expanding the requirements for disclosure of disaggregated information about the effective tax rate reconciliation and income taxes paid. The accounting standard update will be effective for our fiscal 2026 Form 10-K. We are currently evaluating the impact of this accounting standard update on our income tax disclosures.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-24-000017:notes:67]
Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-24-000017:notes:68]
Property and Equipment, Net

[0000858877-24-000017:notes:69]
|  |  | July 27, 2024 |  | July 29, 2023 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,247 |  |  | $ | 4,229 |  |
| Production, engineering, computer and other equipment and related software |  | 5,160 |  |  | 5,355 |  |
| Operating lease assets |  | 115 |  |  | 135 |  |
| Furniture, fixtures and other |  | 351 |  |  | 339 |  |
| Total gross property and equipment |  | 9,873 |  |  | 10,058 |  |
| Less: accumulated depreciation and amortization |  | (7,783) |  |  | (7,973) |  |
| Total |  | $ | 2,090 |  |  | $ | 2,085 |  |


## us-gaap:DerivativesPolicyTextBlock

[0000858877-24-000017:notes:70]
(n) Derivative Instruments   We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risks by limiting our counterparties to major financial institutions and requiring collateral in certain cases. In addition, the potential risk of loss with any one counterparty resulting from credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-24-000017:notes:71]
Revenue
(a)Disaggregation of Revenue

[0000858877-24-000017:notes:72]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. Effective in the first quarter of fiscal 2024, we began reporting our product and service revenue in the following categories: Networking, Security, Collaboration, Observability, and Services and conformed our product revenue for prior periods to the current year presentation.

[0000858877-24-000017:notes:73]
The following table presents this disaggregation of revenue (in millions):

[0000858877-24-000017:notes:74]
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Product revenue: |  |  |  |  |  |
| Networking | $ | 29,229 |  |  | $ | 34,570 |  |  | $ | 29,265 |  |
| Security | 5,075 |  |  | 3,859 |  |  | 3,699 |  |
| Collaboration | 4,113 |  |  | 4,052 |  |  | 4,472 |  |
| Observability | 837 |  |  | 661 |  |  | 581 |  |
| Total Product | 39,253 |  |  | 43,142 |  |  | 38,018 |  |
| Services | 14,550 |  |  | 13,856 |  |  | 13,539 |  |
| Total | $ | 53,803 |  |  | $ | 56,998 |  |  | $ | 51,557 |  |

[0000858877-24-000017:notes:75]
Amounts may not sum due to rounding.

[0000858877-24-000017:notes:76]
Networking consists of our core networking technologies of switching, routing, wireless, and servers. These technologies consist of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-24-000017:notes:77]
Security consists of our Network Security, Identity and Access Management, SASE and Threat Intelligence, Detection, and Response offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-24-000017:notes:78]
Collaboration consists of our Webex Suite, Collaboration Devices, Contact Center and CPaaS offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-24-000017:notes:79]
Observability consists of our network assurance, monitoring and analytics and observability suite offerings. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-24-000017:notes:80]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and advanced services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Advanced services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

[0000858877-24-000017:notes:81]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.

[0000858877-24-000017:notes:82]
Subscription revenue includes revenue recognized from our term software licenses, security software licenses, SaaS, and associated service arrangements. Our subscription revenue is recorded in product and services revenue in our Consolidated Statements of Operations as follows (in millions):

[0000858877-24-000017:notes:83]
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Product | $ | 14,078 |  |  | $ | 11,931 |  |  | $ | 10,030 |  |
| Services | 13,302 |  |  | 12,709 |  |  | 12,363 |  |
| Total | $ | 27,380 |  |  | $ | 24,640 |  |  | $ | 22,393 |  |

[0000858877-24-000017:notes:84]
The majority of our product subscription revenue is recognized over time and the remainder is recognized upfront. Substantially all of our services subscription revenue is recognized over time based on the contract term.

[0000858877-24-000017:notes:85]
(b)Contract Balances

[0000858877-24-000017:notes:86]
Accounts Receivable

[0000858877-24-000017:notes:87]
Accounts receivable, net was $6.7 billion as of July 27, 2024 compared to $5.9 billion as of July 29, 2023, as reported on the Consolidated Balance Sheets.

[0000858877-24-000017:notes:88]
The allowances for credit loss for our accounts receivable are summarized as follows (in millions):

[0000858877-24-000017:notes:89]
|  |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Allowance for credit loss at beginning of fiscal year |  | $ | 85 |  |  | $ | 83 |  |  | $ | 109 |  |
| Provisions (benefits) |  | 36 |  |  | 39 |  |  | 64 |  |
| Recoveries (write-offs), net |  | (34) |  |  | (37) |  |  | (81) |  |
| Foreign exchange and other |  | — |  |  | — |  |  | (9) |  |
| Allowance for credit loss at end of fiscal year |  | $ | 87 |  |  | $ | 85 |  |  | $ | 83 |  |

[0000858877-24-000017:notes:90]
Contract Assets and Liabilities

[0000858877-24-000017:notes:91]
Gross contract assets by our internal risk ratings are summarized as follows (in millions):

[0000858877-24-000017:notes:92]
|  | July 27, 2024 |  | July 29, 2023 |
| 1 to 4 | $ | 1,266 |  |  | $ | 672 |  |
| 5 to 6 | 1,456 |  |  | 954 |  |
| 7 and Higher | 72 |  |  | 60 |  |
| Total | $ | 2,794 |  |  | $ | 1,686 |  |

[0000858877-24-000017:notes:93]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of July 27, 2024 and July 29, 2023, our contract assets for these unbilled receivables, net of allowances, were $2.7 billion and $1.6 billion, respectively, and were included in other current assets and other assets.

[0000858877-24-000017:notes:94]
Contract liabilities consist of deferred revenue. Deferred revenue was $28.5 billion as of July 27, 2024 compared to $25.6 billion as of July 29, 2023. We recognized approximately $13.8 billion of revenue during fiscal 2024 that was included in the deferred revenue balance at July 29, 2023.

[0000858877-24-000017:notes:95]
(c)Capitalized Contract Acquisition Costs

[0000858877-24-000017:notes:96]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Capitalized contract acquisition costs were $1.3 billion and $1.1 billion as of July 27, 2024 and July 29, 2023, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $742 million, $723 million, and $679 million for fiscal 2024, 2023, and 2022, respectively, and was included in sales and marketing expenses.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-24-000017:notes:97]
Our subscription revenue is recorded in product and services revenue in our Consolidated Statements of Operations as follows (in millions):

[0000858877-24-000017:notes:98]
The following table presents revenue for groups of similar products and services (in millions):

[0000858877-24-000017:notes:99]
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Revenue: |  |  |  |  |  |
| Networking | $ | 29,229 |  |  | $ | 34,570 |  |  | $ | 29,265 |  |
| Security | 5,075 |  |  | 3,859 |  |  | 3,699 |  |
| Collaboration | 4,113 |  |  | 4,052 |  |  | 4,472 |  |
| Observability | 837 |  |  | 661 |  |  | 581 |  |
| Total Product | 39,253 |  |  | 43,142 |  |  | 38,018 |  |
| Services | 14,550 |  |  | 13,856 |  |  | 13,539 |  |
| Total | $ | 53,803 |  |  | $ | 56,998 |  |  | $ | 51,557 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-24-000017:notes:100]
Acquisitions 
Acquisition of Splunk Inc.

[0000858877-24-000017:notes:101]
On March 18, 2024, we completed the acquisition of Splunk Inc. (“Splunk”), a public cybersecurity and observability company. Under the terms of the agreement, we agreed to pay $157 per share in cash, representing approximately $27 billion in merger consideration.

[0000858877-24-000017:notes:102]
Purchase Consideration

[0000858877-24-000017:notes:103]
The following table summarizes the purchase consideration for the Splunk acquisition (in millions):

[0000858877-24-000017:notes:104]
|  |  | Amount |
| Cash paid for outstanding Splunk common stock |  | $ | 26,950 |  |
| Fair value of converted Splunk equity awards attributable to pre-acquisition services |  | 137 |  |
| Settlement of pre-existing relationships |  | 3 |  |
| Total purchase consideration |  | $ | 27,090 |  |

[0000858877-24-000017:notes:105]
A summary of the preliminary allocation of the total purchase consideration for Splunk is presented as follows (in millions):

[0000858877-24-000017:notes:106]
|  |  | Amount |
| Cash and cash equivalents |  | $ | 2,422 |  |
| Investments |  | 285 |  |
| Accounts receivable, net |  | 623 |  |
| Goodwill |  | 19,301 |  |
| Purchased intangible assets |  | 10,550 |  |
| Deferred tax assets |  | 1,308 |  |
| Other current and noncurrent assets |  | 1,176 |  |
| Accounts payable |  | (39) |  |
| Accrued compensation |  | (337) |  |
| Current portion of deferred revenue |  | (1,768) |  |
| Splunk convertible notes |  | (3,344) |  |
| Deferred tax liabilities |  | (2,523) |  |
| Noncurrent portion of deferred revenue |  | (86) |  |
| Other current and other noncurrent liabilities |  | (478) |  |
| Total |  | $ | 27,090 |  |

[0000858877-24-000017:notes:107]
The purchase price allocation for Splunk is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information that existed as of the acquisition date but is currently unknown to us may become known during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date.

[0000858877-24-000017:notes:108]
Our Consolidated Statements of Operations for fiscal 2024 includes revenue of approximately $1.4 billion and a net loss of $557 million attributable to Splunk since the date of acquisition.

[0000858877-24-000017:notes:109]
We incurred $82 million of transaction costs related to the Splunk acquisition and these costs were expensed as incurred in general and administrative expenses (“G&A”) expenses in the Consolidated Statements of Operations. We incurred $79 million of these transaction costs in fiscal 2024.

[0000858877-24-000017:notes:110]
In connection with the Splunk acquisition, we assumed $3.1 billion aggregate principal amount of notes consisting of Splunk's 1.125% Convertible Senior Notes due 2025, 0.75% Convertible Senior Notes due 2026 and 1.125% Convertible Senior Notes due 2027 (collectively, the “Splunk Convertible Notes”). The Splunk Convertible Notes had an aggregate fair value of $3.3 billion as of the acquisition date. The Splunk Convertible Notes are convertible and may be settled into cash based on a defined conversion ratio for each note. On the date of the acquisition, we notified holders of their right to convert their notes. In addition, we assumed Splunk’s capped call contracts which were intended to reduce potential dilution or offset any cash payments. The capped calls were settled in full in the third quarter of fiscal 2024, which resulted in receipt of aggregate cash proceeds of $202 million, and were included in other current assets in total purchase consideration noted above. As of July 27, 2024, we have settled $3.1 billion of the Splunk Convertible Notes, net of capped calls.

[0000858877-24-000017:notes:111]
The goodwill generated from Splunk is primarily related to expected synergies. Goodwill is not deductible for income tax purposes.

[0000858877-24-000017:notes:112]
Purchased Intangible Assets

[0000858877-24-000017:notes:113]
The following table presents as of the acquisition date details of the purchased intangible assets acquired (in millions, except years):

[0000858877-24-000017:notes:114]
|  |  | Weighted-Average Useful Life (in Years) |  | Amount |
| Customer related |  | 9.1 |  | $ | 6,140 |  |
| Technology |  | 6.0 |  | 3,900 |  |
| Trade name |  | 12.0 |  | 510 |  |
| Total |  |  |  | $ | 10,550 |  |

[0000858877-24-000017:notes:115]
The majority of customer-related intangible assets relates to customer contracts and related relationships. The customer contracts and related relationships intangible asset represents the fair value of future projected revenue that will be derived from sales of products to existing customers of Splunk. The asset was valued using the with-and-without method under the income approach. In the with-and-without method, the fair value was measured by the difference between the present values of the cash flows with and without the existing customers in place over the period of time necessary to reacquire the customers. The present value of projected future cash flows included significant judgment and assumptions regarding projected future revenues, projected expenses, attrition rates, the revenue build up period, and the discount rate.

[0000858877-24-000017:notes:116]
Technology represents the preliminary estimated fair value of Splunk’s security and observability technologies. The technology intangible asset was valued using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the technology asset less charges representing the contribution of other assets to those cash flows. The present value of projected future cash flows included significant judgment and assumptions regarding projected future revenues, projected expenses, the technology obsolescence rate, and the discount rate.

[0000858877-24-000017:notes:117]
Trade name represents the preliminary estimated fair value of the Splunk trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name.

[0000858877-24-000017:notes:118]
Compensation Expense Related to Splunk

[0000858877-24-000017:notes:119]
In connection with the Splunk acquisition, we have agreed to pay certain additional amounts contingent upon the continued employment with Cisco of certain Splunk employees. For fiscal 2024, the compensation expense was $413 million. As of July 27, 2024, we estimated that future cash compensation expense of up to $1.1 billion may be required to be recognized pursuant to acquisition-related agreements.

[0000858877-24-000017:notes:120]
Pro forma Financial Information

[0000858877-24-000017:notes:121]
The unaudited pro forma financial information in the table below summarizes the combined results of our operations and Splunk’s operations, as though the acquisition of Splunk had been completed as of the beginning of fiscal 2023. The pro forma financial information for fiscal 2024 combines our results for this period with the results of Splunk for the period beginning August 1, 2023 through July 27, 2024. The pro forma financial information for fiscal 2023 combines our historical results for that period with the historical results of Splunk for the year ended July 31, 2023.

[0000858877-24-000017:notes:122]
The following table summarizes the pro forma financial information (in millions):

[0000858877-24-000017:notes:123]
| Years Ended | July 27, 2024 |  | July 29, 2023 |
| Total revenue | $ | 56,761 |  |  | $ | 60,841 |  |
| Net income | $ | 9,280 |  |  | $ | 10,078 |  |

[0000858877-24-000017:notes:124]
The pro forma financial information is presented for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition and the cost of financing the acquisition had taken place at the beginning of fiscal 2023. The financial information for the periods presented above includes pro forma adjustments for amortization of purchased intangible assets, costs related to financing the acquisition and transaction costs.

[0000858877-24-000017:notes:125]
The above pro forma financial information includes only the impacts of the Splunk acquisition because the effects of the other acquisitions detailed below, individually and in the aggregate, were not material to our financial results.

[0000858877-24-000017:notes:126]
Other Acquisitions

[0000858877-24-000017:notes:127]
We completed several additional acquisitions during fiscal 2024 for an aggregate cash consideration of $1.4 billion. A summary of the allocation of the total purchase consideration of these additional acquisitions is presented as follows (in millions):

[0000858877-24-000017:notes:128]
| Fiscal 2024 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total other acquisitions | $ | 1,370 |  |  | $ | (47) |  |  | $ | 500 |  |  | $ | 917 |  |

[0000858877-24-000017:notes:129]
The total purchase consideration related to these other acquisitions completed during fiscal 2024 consisted primarily of cash consideration. The total cash and cash equivalents acquired from these acquisitions was approximately $24 million. Total transaction costs related to these acquisition activities were $25 million, $24 million, and $49 million for fiscal 2024, 2023, and 2022, respectively. These transaction costs were expensed as incurred in G&A in the Consolidated Statements of Operations.

[0000858877-24-000017:notes:130]
The purchase price allocation for these acquisitions completed during recent periods is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information that existed as of the acquisition date but is currently unknown to us may become known during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date.

[0000858877-24-000017:notes:131]
The goodwill generated from these acquisitions completed during fiscal 2024 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-24-000017:notes:132]
Fiscal 2023 Acquisitions

[0000858877-24-000017:notes:133]
Allocation of the purchase consideration for acquisitions completed in fiscal 2023 is summarized as follows (in millions):

[0000858877-24-000017:notes:134]
| Fiscal 2023 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions | $ | 315 |  |  | $ | (18) |  |  | $ | 150 |  |  | $ | 183 |  |

[0000858877-24-000017:notes:135]
The total purchase consideration related to our acquisitions completed during fiscal 2023 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately  $7 million.

[0000858877-24-000017:notes:136]
Fiscal 2022 Acquisitions

[0000858877-24-000017:notes:137]
In fiscal 2022, we paid total purchase consideration of $364 million for our acquisitions.

[0000858877-24-000017:notes:138]
Compensation Expense Related to Acquisitions including Splunk

[0000858877-24-000017:notes:139]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-24-000017:notes:140]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-24-000017:notes:141]
|  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Compensation expense related to acquisitions | $ | 618 |  |  | $ | 222 |  |  | $ | 271 |  |

[0000858877-24-000017:notes:142]
Total compensation expense related to acquisitions for fiscal 2024 include $413 million related to the Splunk acquisition.
As of July 27, 2024, we estimated that future cash compensation expense of up to $1.6 billion may be required to be recognized pursuant to these applicable acquisition agreements, which includes up to $1.1 billion related to the Splunk acquisition.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0000858877-24-000017:notes:143]
A summary of the allocation of the total purchase consideration of these additional acquisitions is presented as follows (in millions):


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-24-000017:notes:144]
Goodwill and Purchased Intangible Assets 
(a)Goodwill

[0000858877-24-000017:notes:145]
The following tables present the goodwill allocated to our reportable segments as of July 27, 2024 and July 29, 2023, as well as the changes to goodwill during fiscal 2024 and 2023 (in millions):

[0000858877-24-000017:notes:146]
|  | Balance at July 29, 2023 |  | Splunk |  | Other Acquisitions |  | Foreign Currency Translation and Other |  | Balance at July 27, 2024 |
| Americas | $ | 24,035 |  |  | $ | 11,619 |  |  | $ | 573 |  |  | $ | (58) |  |  | $ | 36,169 |  |
| EMEA | 9,118 |  |  | 4,980 |  |  | 207 |  |  | (22) |  |  | 14,283 |  |
| APJC | 5,382 |  |  | 2,702 |  |  | 137 |  |  | (13) |  |  | 8,208 |  |
| Total | $ | 38,535 |  |  | $ | 19,301 |  |  | $ | 917 |  |  | $ | (93) |  |  | $ | 58,660 |  |

[0000858877-24-000017:notes:147]
|  | Balance at July 30, 2022 |  | Acquisitions |  | Foreign Currency Translation and Other |  | Balance at July 29, 2023 |
| Americas | $ | 23,882 |  |  | $ | 123 |  |  | $ | 30 |  |  | $ | 24,035 |  |
| EMEA | 9,062 |  |  | 44 |  |  | 12 |  |  | 9,118 |  |
| APJC | 5,360 |  |  | 16 |  |  | 6 |  |  | 5,382 |  |
| Total | $ | 38,304 |  |  | $ | 183 |  |  | $ | 48 |  |  | $ | 38,535 |  |

[0000858877-24-000017:notes:148]
(b)Purchased Intangible Assets

[0000858877-24-000017:notes:149]
The following tables present details of our intangible assets acquired through acquisitions completed during fiscal 2024 and 2023 (in millions, except years):

[0000858877-24-000017:notes:150]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATED |  | TRADE NAME |  | IPR&D |  |
| Fiscal 2024 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Splunk | 6.0 |  | $ | 3,900 |  |  | 9.1 |  | $ | 6,140 |  |  | 12.0 |  | $ | 510 |  |  | $ | — |  |  | $ | 10,550 |  |
| Others | 4.8 |  | 400 |  |  | 4.9 |  | 83 |  |  | 1.3 |  | 3 |  |  | 14 |  |  | 500 |  |
| Total |  |  | $ | 4,300 |  |  |  |  | $ | 6,223 |  |  |  |  | $ | 513 |  |  | $ | 14 |  |  | $ | 11,050 |  |

[0000858877-24-000017:notes:151]
|  | FINITE LIVES | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | IPR&D |  |
| Fiscal 2023 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions | 3.7 |  | $ | 138 |  |  | 1.8 |  | $ | 12 |  |  | $ | — |  |  | $ | 150 |  |

[0000858877-24-000017:notes:152]
The following tables present details of our purchased intangible assets (in millions):

[0000858877-24-000017:notes:153]
| July 27, 2024 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Customer related |  | $ | 6,844 |  |  | $ | (829) |  |  | $ | 6,015 |  |
| Technology |  | 6,680 |  |  | (2,006) |  |  | 4,674 |  |
| Trade name |  | 553 |  |  | (49) |  |  | 504 |  |
| Total purchased intangible assets with finite lives |  | 14,077 |  |  | (2,884) |  |  | 11,193 |  |
| In-process research and development, with indefinite lives |  | 26 |  |  | — |  |  | 26 |  |
| Total |  | $ | 14,103 |  |  | $ | (2,884) |  |  | $ | 11,219 |  |

[0000858877-24-000017:notes:154]
| July 29, 2023 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 2,998 |  |  | $ | (1,691) |  |  | $ | 1,307 |  |
| Customer related |  | 1,228 |  |  | (905) |  |  | 323 |  |
| Other |  | 40 |  |  | (22) |  |  | 18 |  |
| Total purchased intangible assets with finite lives |  | 4,266 |  |  | (2,618) |  |  | 1,648 |  |
| In-process research and development, with indefinite lives |  | 170 |  |  | — |  |  | 170 |  |
| Total |  | $ | 4,436 |  |  | $ | (2,618) |  |  | $ | 1,818 |  |

[0000858877-24-000017:notes:155]
Purchased intangible assets include intangible assets acquired through acquisitions as well as through direct purchases or licenses.

[0000858877-24-000017:notes:156]
Impairment charges related to purchased intangible assets were $145 million for fiscal 2024. Impairment charges were as a result of declines in estimated fair value resulting from the reductions in or the elimination of expected future cash flows associated with certain of our IPR&D intangible assets.

[0000858877-24-000017:notes:157]
The following table presents the amortization of purchased intangible assets, including impairment charges (in millions):

[0000858877-24-000017:notes:158]
| Years Ended |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 955 |  |  | $ | 649 |  |  | $ | 749 |  |
| Operating expenses |  | 698 |  |  | 282 |  |  | 328 |  |
| Total |  | $ | 1,653 |  |  | $ | 931 |  |  | $ | 1,077 |  |

[0000858877-24-000017:notes:159]
The estimated future amortization expense of purchased intangible assets with finite lives as of July 27, 2024 is as follows (in millions):

[0000858877-24-000017:notes:160]
| Fiscal Year | Amount |
| 2025 | $ | 2,138 |  |
| 2026 | $ | 1,789 |  |
| 2027 | $ | 1,445 |  |
| 2028 | $ | 1,365 |  |
| 2029 | $ | 1,265 |  |
| Thereafter | $ | 3,191 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-24-000017:notes:161]
Restructuring and Other Charges
In the first quarter of fiscal 2025, we announced a restructuring plan (the “Fiscal 2025 Plan”), in order to allow us to invest in key growth opportunities and drive more efficiencies in our business. The Fiscal 2025 Plan is expected to impact approximately 7% of our global workforce, with estimated pre-tax charges of up to $1 billion consisting of severance and other one-time termination benefits, and other costs. We expect this plan to be substantially completed by the end of fiscal 2025.

[0000858877-24-000017:notes:162]
In the third quarter of fiscal 2024, we initiated a restructuring plan (the “Fiscal 2024 Plan”), in order to realign the organization and enable further investment in key priority areas, of which approximately 5% of our global workforce would be impacted. In connection with the Fiscal 2024 Plan, we incurred charges of $654 million for fiscal 2024 and the plan is substantially complete. The aggregate pretax charges related to this plan were primarily cash-based and consist of severance and other one-time termination benefits and other costs.

[0000858877-24-000017:notes:163]
We initiated a restructuring plan in fiscal 2023 (the “Fiscal 2023 Plan”), which was completed in fiscal 2024. In connection with the Fiscal 2023 Plan, we incurred cumulative charges of $670 million. The aggregate pretax charges related to this plan were primarily cash-based and consist of severance and other one-time termination benefits, real estate-related charges, and other costs.

[0000858877-24-000017:notes:164]
The following table summarizes the activities related to the restructuring and other charges, as discussed above (in millions):

[0000858877-24-000017:notes:165]
|  |  | FISCAL 2024 PLAN |  | FISCAL 2023 AND PRIOR PLANS |  |  |
|  |  | Employee Severance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 31, 2021 |  | $ | — |  |  | $ | — |  |  | $ | 16 |  |  | $ | 18 |  |  | $ | 34 |  |
| Charges |  | — |  |  | — |  |  | 9 |  |  | (3) |  |  | 6 |  |
| Cash payments |  | — |  |  | — |  |  | (23) |  |  | (2) |  |  | (25) |  |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (6) |  |  | (6) |  |
| Liability as of July 30, 2022 |  | — |  |  | — |  |  | 2 |  |  | 7 |  |  | 9 |  |
| Charges |  | — |  |  | — |  |  | 465 |  |  | 66 |  |  | 531 |  |
| Cash payments |  | — |  |  | — |  |  | (302) |  |  | (12) |  |  | (314) |  |
| Non-cash items |  | — |  |  | — |  |  | 2 |  |  | (15) |  |  | (13) |  |
| Liability as of July 29, 2023 |  | — |  |  | — |  |  | 167 |  |  | 46 |  |  | 213 |  |
| Charges |  | 627 |  |  | 27 |  |  | 104 |  |  | 31 |  |  | 789 |  |
| Cash payments |  | (426) |  |  | (3) |  |  | (251) |  |  | (11) |  |  | (691) |  |
| Non-cash items |  | — |  |  | (15) |  |  | — |  |  | (22) |  |  | (37) |  |
| Liability as of July 27, 2024 |  | $ | 201 |  |  | $ | 9 |  |  | $ | 20 |  |  | $ | 44 |  |  | $ | 274 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-24-000017:notes:166]
Balance Sheet and Other Details 
The following tables provide details of selected balance sheet and other items (in millions, except percentages):

[0000858877-24-000017:notes:167]
Cash, Cash Equivalents, Restricted Cash and Restricted Cash Equivalents

[0000858877-24-000017:notes:168]
|  |  | July 27, 2024 |  | July 29, 2023 |
| Cash and cash equivalents |  | $ | 7,508 |  |  | $ | 10,123 |  |
| Restricted cash and restricted cash equivalents included in other current assets |  | 765 |  |  | 191 |  |
| Restricted cash and restricted cash equivalents included in other assets |  | 569 |  |  | 1,313 |  |
| Total |  | $ | 8,842 |  |  | $ | 11,627 |  |

[0000858877-24-000017:notes:169]
Our restricted cash and restricted cash equivalents are funds primarily related to contractual obligations with suppliers.

[0000858877-24-000017:notes:170]
Inventories

[0000858877-24-000017:notes:171]
|  |  | July 27, 2024 |  | July 29, 2023 |
| Raw materials |  | $ | 2,039 |  |  | $ | 1,685 |  |
| Work in process |  | 83 |  |  | 264 |  |
| Finished goods |  | 1,027 |  |  | 1,493 |  |
| Service-related spares |  | 216 |  |  | 186 |  |
| Demonstration systems |  | 8 |  |  | 16 |  |
| Total |  | $ | 3,373 |  |  | $ | 3,644 |  |

[0000858877-24-000017:notes:172]
Remaining Performance Obligations (RPO)

[0000858877-24-000017:notes:173]
|  |  | July 27, 2024 |  | July 29, 2023 |
| Product |  | $ | 20,055 |  |  | $ | 15,802 |  |
| Services |  | 20,993 |  |  | 19,066 |  |
| Total |  | $ | 41,048 |  |  | $ | 34,868 |  |
| Short-term RPO |  | $ | 20,882 |  |  | $ | 17,910 |  |
| Long-term RPO |  | 20,166 |  |  | 16,958 |  |
| Total |  | $ | 41,048 |  |  | $ | 34,868 |  |
| Amount to be recognized as revenue over the next 12 months |  | 51 | % |  | 51 | % |
| Deferred revenue |  | $ | 28,475 |  |  | $ | 25,550 |  |
| Unbilled contract revenue |  | 12,573 |  |  | 9,318 |  |
| Total |  | $ | 41,048 |  |  | $ | 34,868 |  |

[0000858877-24-000017:notes:174]
Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

[0000858877-24-000017:notes:175]
Deferred Revenue

[0000858877-24-000017:notes:176]
|  |  | July 27, 2024 |  | July 29, 2023 |
| Product |  | $ | 13,219 |  |  | $ | 11,505 |  |
| Services |  | 15,256 |  |  | 14,045 |  |
| Total |  | $ | 28,475 |  |  | $ | 25,550 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 16,249 |  |  | $ | 13,908 |  |
| Noncurrent |  | 12,226 |  |  | 11,642 |  |
| Total |  | $ | 28,475 |  |  | $ | 25,550 |  |

[0000858877-24-000017:notes:177]
Transition Tax Payable

[0000858877-24-000017:notes:178]
Our income tax payable associated with the one-time U.S. transition tax on accumulated earnings for foreign subsidiaries as a result of the Tax Act is as follows (in millions):

[0000858877-24-000017:notes:179]
|  |  | July 27, 2024 |  | July 29, 2023 |
| Current |  | $ | 1,819 |  |  | $ | 1,364 |  |
| Noncurrent |  | 2,273 |  |  | 4,092 |  |
| Total |  | $ | 4,092 |  |  | $ | 5,456 |  |

[0000858877-24-000017:notes:180]
Our noncurrent transition tax payable of $2.3 billion as of July 27, 2024 will be due in fiscal 2026.


## us-gaap:OperatingLeasesOfLessorDisclosureTextBlock

[0000858877-24-000017:notes:181]
Leases
(a)Lessee Arrangements

[0000858877-24-000017:notes:182]
The following table presents our operating lease balances (in millions):

[0000858877-24-000017:notes:183]
|  | Balance Sheet Line Item |  | July 27, 2024 |  | July 29, 2023 |
| Operating lease right-of-use assets | Other assets |  | $ | 1,066 |  |  | $ | 971 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 364 |  |  | $ | 313 |  |
| Operating lease liabilities | Other long-term liabilities |  | 906 |  |  | 707 |  |
| Total operating lease liabilities |  |  | $ | 1,270 |  |  | $ | 1,020 |  |

[0000858877-24-000017:notes:184]
The components of our lease expenses were as follows (in millions):

[0000858877-24-000017:notes:185]
| Years Ended |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Operating lease expense |  | $ | 420 |  |  | $ | 425 |  |  | $ | 390 |  |
| Short-term lease expense |  | 75 |  |  | 65 |  |  | 66 |  |
| Variable lease expense |  | 194 |  |  | 242 |  |  | 173 |  |
| Total lease expense |  | $ | 689 |  |  | $ | 732 |  |  | $ | 629 |  |

[0000858877-24-000017:notes:186]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-24-000017:notes:187]
| Years Ended |  | July 27, 2024 |  | July 29, 2023 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows |  | $ | 394 |  |  | $ | 387 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities |  | $ | 459 |  |  | $ | 326 |  |

[0000858877-24-000017:notes:188]
The weighted-average lease term was 4.9 years and 4.6 years as of July 27, 2024 and July 29, 2023, respectively. The weighted-average discount rate was 4.0% and 3.1% as of July 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000017:notes:189]
The maturities of our operating leases (undiscounted) as of July 27, 2024 are as follows (in millions):

[0000858877-24-000017:notes:190]
| Fiscal Year | Amount |
| 2025 | $ | 409 |  |
| 2026 | 295 |  |
| 2027 | 207 |  |
| 2028 | 144 |  |
| 2029 | 112 |  |
| Thereafter | 253 |  |
| Total lease payments | 1,420 |  |
| Less interest | (150) |  |
| Total | $ | 1,270 |  |

[0000858877-24-000017:notes:191]
(b)Lessor Arrangements

[0000858877-24-000017:notes:192]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income for fiscal 2024, 2023, and 2022 was $65 million, $51 million and $54 million, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-24-000017:notes:193]
Future minimum lease payments on our lease receivables as of July 27, 2024 are summarized as follows (in millions):

[0000858877-24-000017:notes:194]
| Fiscal Year | Amount |
| 2025 | $ | 314 |  |
| 2026 | 246 |  |
| 2027 | 156 |  |
| 2028 | 146 |  |
| 2029 | 97 |  |
| Thereafter | 6 |  |
| Total | 965 |  |
| Less: Present value of lease payments | 854 |  |
| Unearned income | $ | 111 |  |

[0000858877-24-000017:notes:195]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-24-000017:notes:196]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-24-000017:notes:197]
|  | July 27, 2024 |  | July 29, 2023 |
| Operating lease assets | $ | 115 |  |  | $ | 135 |  |
| Accumulated depreciation | (61) |  |  | (78) |  |
| Operating lease assets, net | $ | 54 |  |  | $ | 57 |  |

[0000858877-24-000017:notes:198]
Our operating lease income for fiscal 2024, 2023, and 2022 was $58 million, $73 million and $107 million, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-24-000017:notes:199]
Minimum future rentals on noncancelable operating leases as of July 27, 2024 are summarized as follows (in millions):

[0000858877-24-000017:notes:200]
| Fiscal Year | Amount |
| 2025 | $ | 22 |  |
| 2026 | 14 |  |
| 2027 | 3 |  |
| Total | $ | 39 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-24-000017:notes:201]
Financing Receivables  
(a)Financing Receivables

[0000858877-24-000017:notes:202]
Financing receivables primarily consist of loan receivables and lease receivables. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services (including technical support and advanced services), and also may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables have terms of one year to three years on average. Lease receivables represent sales-type leases resulting from the sale of Cisco’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average.

[0000858877-24-000017:notes:203]
A summary of our financing receivables is presented as follows (in millions):

[0000858877-24-000017:notes:204]
| July 27, 2024 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,858 |  |  | $ | 965 |  |  | $ | 6,823 |  |
| Residual value | — |  |  | 67 |  |  | 67 |  |
| Unearned income | — |  |  | (111) |  |  | (111) |  |
| Allowance for credit loss | (50) |  |  | (15) |  |  | (65) |  |
| Total, net | $ | 5,808 |  |  | $ | 906 |  |  | $ | 6,714 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 3,071 |  |  | $ | 267 |  |  | $ | 3,338 |  |
| Noncurrent | 2,737 |  |  | 639 |  |  | 3,376 |  |
| Total, net | $ | 5,808 |  |  | $ | 906 |  |  | $ | 6,714 |  |

[0000858877-24-000017:notes:205]
| July 29, 2023 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,910 |  |  | $ | 1,015 |  |  | $ | 6,925 |  |
| Residual value | — |  |  | 70 |  |  | 70 |  |
| Unearned income | — |  |  | (88) |  |  | (88) |  |
| Allowance for credit loss | (53) |  |  | (19) |  |  | (72) |  |
| Total, net | $ | 5,857 |  |  | $ | 978 |  |  | $ | 6,835 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 2,988 |  |  | $ | 364 |  |  | $ | 3,352 |  |
| Noncurrent | 2,869 |  |  | 614 |  |  | 3,483 |  |
| Total, net | $ | 5,857 |  |  | $ | 978 |  |  | $ | 6,835 |  |

[0000858877-24-000017:notes:206]
(b)Credit Quality of Financing Receivables

[0000858877-24-000017:notes:207]
The tables below present our gross financing receivables, excluding residual value, less unearned income, categorized by our internal credit risk rating by period of origination (in millions):

[0000858877-24-000017:notes:208]
| July 27, 2024 |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 25, 2020 |  | July 31, 2021 |  | July 30, 2022 |  | July 29, 2023 |  | July 27, 2024 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 78 |  |  | $ | 341 |  |  | $ | 555 |  |  | $ | 945 |  |  | $ | 1,803 |  |  | $ | 3,724 |  |
| 5 to 6 | 2 |  |  | 29 |  |  | 127 |  |  | 130 |  |  | 426 |  |  | 1,314 |  |  | 2,028 |  |
| 7 and Higher | 3 |  |  | 1 |  |  | 10 |  |  | 74 |  |  | 14 |  |  | 4 |  |  | 106 |  |
| Total Loan Receivables | $ | 7 |  |  | $ | 108 |  |  | $ | 478 |  |  | $ | 759 |  |  | $ | 1,385 |  |  | $ | 3,121 |  |  | $ | 5,858 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 1 |  |  | $ | 8 |  |  | $ | 38 |  |  | $ | 46 |  |  | $ | 176 |  |  | $ | 341 |  |  | $ | 610 |  |
| 5 to 6 | 1 |  |  | 11 |  |  | 22 |  |  | 44 |  |  | 129 |  |  | 21 |  |  | 228 |  |
| 7 and Higher | — |  |  | — |  |  | 1 |  |  | 3 |  |  | 4 |  |  | 8 |  |  | 16 |  |
| Total Lease Receivables | $ | 2 |  |  | $ | 19 |  |  | $ | 61 |  |  | $ | 93 |  |  | $ | 309 |  |  | $ | 370 |  |  | $ | 854 |  |
| Total | $ | 9 |  |  | $ | 127 |  |  | $ | 539 |  |  | $ | 852 |  |  | $ | 1,694 |  |  | $ | 3,491 |  |  | $ | 6,712 |  |

[0000858877-24-000017:notes:209]
| July 29, 2023 |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | July 30, 2022 |  | July 29, 2023 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 10 |  |  | $ | 53 |  |  | $ | 251 |  |  | $ | 791 |  |  | $ | 1,077 |  |  | $ | 1,784 |  |  | $ | 3,966 |  |
| 5 to 6 | 3 |  |  | 14 |  |  | 131 |  |  | 287 |  |  | 465 |  |  | 936 |  |  | 1,836 |  |
| 7 and Higher | 1 |  |  | 7 |  |  | 15 |  |  | 17 |  |  | 29 |  |  | 39 |  |  | 108 |  |
| Total Loan Receivables | $ | 14 |  |  | $ | 74 |  |  | $ | 397 |  |  | $ | 1,095 |  |  | $ | 1,571 |  |  | $ | 2,759 |  |  | $ | 5,910 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 20 |  |  | $ | 57 |  |  | $ | 111 |  |  | $ | 84 |  |  | $ | 235 |  |  | $ | 509 |  |
| 5 to 6 | 2 |  |  | 13 |  |  | 44 |  |  | 58 |  |  | 87 |  |  | 191 |  |  | 395 |  |
| 7 and Higher | — |  |  | 1 |  |  | 2 |  |  | 4 |  |  | 5 |  |  | 11 |  |  | 23 |  |
| Total Lease Receivables | $ | 4 |  |  | $ | 34 |  |  | $ | 103 |  |  | $ | 173 |  |  | $ | 176 |  |  | $ | 437 |  |  | $ | 927 |  |
| Total | $ | 18 |  |  | $ | 108 |  |  | $ | 500 |  |  | $ | 1,268 |  |  | $ | 1,747 |  |  | $ | 3,196 |  |  | $ | 6,837 |  |

[0000858877-24-000017:notes:210]
The following tables present the aging analysis of gross receivables as of July 27, 2024 and July 29, 2023 (in millions):

[0000858877-24-000017:notes:211]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| July 27, 2024 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 34 |  |  | $ | 17 |  |  | $ | 35 |  |  | $ | 86 |  |  | $ | 5,772 |  |  | $ | 5,858 |  |  | $ | 14 |  |  | $ | 7 |  |  | $ | 7 |  |
| Lease receivables | 14 |  |  | 4 |  |  | 5 |  |  | 23 |  |  | 831 |  |  | 854 |  |  | 1 |  |  | — |  |  | — |  |
| Total | $ | 48 |  |  | $ | 21 |  |  | $ | 40 |  |  | $ | 109 |  |  | $ | 6,603 |  |  | $ | 6,712 |  |  | $ | 15 |  |  | $ | 7 |  |  | $ | 7 |  |

[0000858877-24-000017:notes:212]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| July 29, 2023 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 47 |  |  | $ | 20 |  |  | $ | 37 |  |  | $ | 104 |  |  | $ | 5,806 |  |  | $ | 5,910 |  |  | $ | 17 |  |  | $ | 12 |  |  | $ | 12 |  |
| Lease receivables | 16 |  |  | 4 |  |  | 23 |  |  | 43 |  |  | 884 |  |  | 927 |  |  | 6 |  |  | 3 |  |  | 3 |  |
| Total | $ | 63 |  |  | $ | 24 |  |  | $ | 60 |  |  | $ | 147 |  |  | $ | 6,690 |  |  | $ | 6,837 |  |  | $ | 23 |  |  | $ | 15 |  |  | $ | 15 |  |

[0000858877-24-000017:notes:213]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract.

[0000858877-24-000017:notes:214]
(c)Allowance for Credit Loss Rollforward

[0000858877-24-000017:notes:215]
The allowances for credit loss and the related financing receivables are summarized as follows (in millions):

[0000858877-24-000017:notes:216]
|  | CREDIT LOSS ALLOWANCES |
|  | LoanReceivables |  | LeaseReceivables |  | Total |
| Allowance for credit loss as of July 29, 2023 | $ | 53 |  |  | $ | 19 |  |  | $ | 72 |  |
| Provisions (benefits) | 1 |  |  | (3) |  |  | (2) |  |
| Recoveries (write-offs), net | (4) |  |  | (1) |  |  | (5) |  |
| Allowance for credit loss as of July 27, 2024 | $ | 50 |  |  | $ | 15 |  |  | $ | 65 |  |

[0000858877-24-000017:notes:217]
|  | CREDIT LOSS ALLOWANCES |
|  | LoanReceivables |  | LeaseReceivables |  | Total |
| Allowance for credit loss as of July 30, 2022 | $ | 103 |  |  | $ | 23 |  |  | $ | 126 |  |
| Provisions (benefits) | (7) |  |  | (1) |  |  | (8) |  |
| Recoveries (write-offs), net | (38) |  |  | (3) |  |  | (41) |  |
| Foreign exchange and other | (5) |  |  | — |  |  | (5) |  |
| Allowance for credit loss as of July 29, 2023 | $ | 53 |  |  | $ | 19 |  |  | $ | 72 |  |

[0000858877-24-000017:notes:218]
|  | CREDIT LOSS ALLOWANCES |
|  | LoanReceivables |  | LeaseReceivables |  | Total |
| Allowance for credit loss as of July 31, 2021 | $ | 89 |  |  | $ | 38 |  |  | $ | 127 |  |
| Provisions (benefits) | 4 |  |  | (13) |  |  | (9) |  |
| Recoveries (write-offs), net | — |  |  | (2) |  |  | (2) |  |
| Foreign exchange and other | 10 |  |  | — |  |  | 10 |  |
| Allowance for credit loss as of July 30, 2022 | $ | 103 |  |  | $ | 23 |  |  | $ | 126 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-24-000017:notes:219]
Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-24-000017:notes:220]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-24-000017:notes:221]
| July 27, 2024 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,380 |  |  | $ | 1 |  |  | $ | (28) |  |  | $ | 2,353 |  |
| U.S. government agency securities | 223 |  |  | — |  |  | (2) |  |  | 221 |  |
| Non-U.S. government and agency securities | 370 |  |  | 1 |  |  | — |  |  | 371 |  |
| Corporate debt securities | 3,818 |  |  | 5 |  |  | (146) |  |  | 3,677 |  |
| U.S. agency mortgage-backed securities | 1,959 |  |  | — |  |  | (178) |  |  | 1,781 |  |
| Commercial paper | 1,023 |  |  | — |  |  | — |  |  | 1,023 |  |
| Certificates of deposit | 439 |  |  | — |  |  | — |  |  | 439 |  |
| Total | $ | 10,212 |  |  | $ | 7 |  |  | $ | (354) |  |  | $ | 9,865 |  |

[0000858877-24-000017:notes:222]
| July 29, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 3,587 |  |  | $ | 1 |  |  | $ | (62) |  |  | $ | 3,526 |  |
| U.S. government agency securities | 428 |  |  | — |  |  | (5) |  |  | 423 |  |
| Non-U.S. government and agency securities | 364 |  |  | — |  |  | (1) |  |  | 363 |  |
| Corporate debt securities | 7,238 |  |  | 3 |  |  | (327) |  |  | 6,914 |  |
| U.S. agency mortgage-backed securities | 2,421 |  |  | 14 |  |  | (230) |  |  | 2,205 |  |
| Commercial paper | 1,484 |  |  | — |  |  | — |  |  | 1,484 |  |
| Certificates of deposit | 677 |  |  | — |  |  | — |  |  | 677 |  |
| Total | $ | 16,199 |  |  | $ | 18 |  |  | $ | (625) |  |  | $ | 15,592 |  |

[0000858877-24-000017:notes:223]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-24-000017:notes:224]
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Gross realized gains | $ | 7 |  |  | $ | 4 |  |  | $ | 27 |  |
| Gross realized losses | (74) |  |  | (25) |  |  | (18) |  |
| Total | $ | (67) |  |  | $ | (21) |  |  | $ | 9 |  |

[0000858877-24-000017:notes:225]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at July 27, 2024 and July 29, 2023 (in millions):

[0000858877-24-000017:notes:226]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 598 |  |  | $ | (2) |  |  | $ | 1,399 |  |  | $ | (26) |  |  | $ | 1,997 |  |  | $ | (28) |  |
| U.S. government agency securities | 89 |  |  | — |  |  | 109 |  |  | (2) |  |  | 198 |  |  | (2) |  |
| Non-U.S. government and agency securities | 17 |  |  | — |  |  | — |  |  | — |  |  | 17 |  |  | — |  |
| Corporate debt securities | 276 |  |  | (1) |  |  | 2,818 |  |  | (115) |  |  | 3,094 |  |  | (116) |  |
| U.S. agency mortgage-backed securities | 238 |  |  | (1) |  |  | 1,438 |  |  | (177) |  |  | 1,676 |  |  | (178) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 1,228 |  |  | $ | (4) |  |  | $ | 5,764 |  |  | $ | (320) |  |  | $ | 6,992 |  |  | $ | (324) |  |

[0000858877-24-000017:notes:227]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 2,394 |  |  | $ | (26) |  |  | $ | 931 |  |  | $ | (36) |  |  | $ | 3,325 |  |  | $ | (62) |  |
| U.S. government agency securities | 343 |  |  | (2) |  |  | 72 |  |  | (3) |  |  | 415 |  |  | (5) |  |
| Non-U.S. government and agency securities | 363 |  |  | (1) |  |  | — |  |  | — |  |  | 363 |  |  | (1) |  |
| Corporate debt securities | 1,736 |  |  | (22) |  |  | 4,315 |  |  | (275) |  |  | 6,051 |  |  | (297) |  |
| U.S. agency mortgage-backed securities | 658 |  |  | (13) |  |  | 1,438 |  |  | (217) |  |  | 2,096 |  |  | (230) |  |
| Commercial paper | 97 |  |  | — |  |  | — |  |  | — |  |  | 97 |  |  | — |  |
| Certificates of deposit | 2 |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |
| Total | $ | 5,593 |  |  | $ | (64) |  |  | $ | 6,756 |  |  | $ | (531) |  |  | $ | 12,349 |  |  | $ | (595) |  |

[0000858877-24-000017:notes:228]
The following table summarizes the maturities of our available-for-sale debt investments as of July 27, 2024 (in millions):

[0000858877-24-000017:notes:229]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 3,715 |  |  | $ | 3,674 |  |
| After 1 year through 5 years | 4,538 |  |  | 4,410 |  |
| Mortgage-backed securities with no single maturity | 1,959 |  |  | 1,781 |  |
| Total | $ | 10,212 |  |  | $ | 9,865 |  |

[0000858877-24-000017:notes:230]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-24-000017:notes:231]
(b)Summary of Equity Investments

[0000858877-24-000017:notes:232]
We held marketable equity securities of $481 million and $431 million as of July 27, 2024 and July 29, 2023, respectively. We recognized a net unrealized gain of $71 million and $36 million for fiscal 2024 and 2023, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $165 million and $8 million for fiscal 2024 and 2023, respectively. We held equity interests in certain private equity funds of $0.8 billion and $0.9 billion as of July 27, 2024 and July 29, 2023, respectively, which are accounted for under the NAV practical expedient.

[0000858877-24-000017:notes:233]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of July 27, 2024, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
As of July 27, 2024, the carrying value of our investments in privately held companies was $1.8 billion. Of the total carrying value of our investments in privately held companies as of July 27, 2024, $0.9 billion of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $0.2 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-24-000017:notes:234]
Fair Value 
(a)Assets and Liabilities Measured at Fair Value on a Recurring Basis

[0000858877-24-000017:notes:235]
Assets and liabilities measured at fair value on a recurring basis were as follows (in millions):

[0000858877-24-000017:notes:236]
|  | JULY 27, 2024 |  | JULY 29, 2023 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 3,334 |  |  | $ | — |  |  | $ | 3,334 |  |  | $ | 6,496 |  |  | $ | — |  |  | $ | 6,496 |  |
| Commercial paper | — |  |  | 468 |  |  | 468 |  |  | — |  |  | 1,090 |  |  | 1,090 |  |
| Certificates of deposit | — |  |  | 14 |  |  | 14 |  |  | — |  |  | 47 |  |  | 47 |  |
| Corporate debt securities | — |  |  | 25 |  |  | 25 |  |  | — |  |  | 25 |  |  | 25 |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 2,353 |  |  | 2,353 |  |  | — |  |  | 3,526 |  |  | 3,526 |  |
| U.S. government agency securities | — |  |  | 221 |  |  | 221 |  |  | — |  |  | 423 |  |  | 423 |  |
| Non-U.S. government and agency securities | — |  |  | 371 |  |  | 371 |  |  | — |  |  | 363 |  |  | 363 |  |
| Corporate debt securities | — |  |  | 3,677 |  |  | 3,677 |  |  | — |  |  | 6,914 |  |  | 6,914 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,781 |  |  | 1,781 |  |  | — |  |  | 2,205 |  |  | 2,205 |  |
| Commercial paper | — |  |  | 1,023 |  |  | 1,023 |  |  | — |  |  | 1,484 |  |  | 1,484 |  |
| Certificates of deposit | — |  |  | 439 |  |  | 439 |  |  | — |  |  | 677 |  |  | 677 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 481 |  |  | — |  |  | 481 |  |  | 431 |  |  | — |  |  | 431 |  |
| Other current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 750 |  |  | — |  |  | 750 |  |  | 188 |  |  | — |  |  | 188 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 563 |  |  | — |  |  | 563 |  |  | 1,313 |  |  | — |  |  | 1,313 |  |
| Derivative assets | — |  |  | 64 |  |  | 64 |  |  | — |  |  | 32 |  |  | 32 |  |
| Total | $ | 5,128 |  |  | $ | 10,436 |  |  | $ | 15,564 |  |  | $ | 8,428 |  |  | $ | 16,786 |  |  | $ | 25,214 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |  | $ | — |  |  | $ | 75 |  |  | $ | 75 |  |
| Total | $ | — |  |  | $ | 74 |  |  | $ | 74 |  |  | $ | — |  |  | $ | 75 |  |  | $ | 75 |  |

[0000858877-24-000017:notes:237]
(b)Assets Measured at Fair Value on a Nonrecurring Basis

[0000858877-24-000017:notes:238]
Our non-marketable equity securities using the measurement alternative are adjusted to fair value on a non-recurring basis. Adjustments are made when observable transactions for identical or similar investments of the same issuer occur, or due to impairment. These securities are classified as Level 3 in the fair value hierarchy because we estimate the value based on valuation methods using the observable transaction price at the transaction date and other unobservable inputs such as volatility, rights, and obligations of the securities we hold.

[0000858877-24-000017:notes:239]
The fair value for purchased intangible assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation. Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable. See Note 5.

[0000858877-24-000017:notes:240]
(c)  Other Fair Value Disclosures

[0000858877-24-000017:notes:241]
The fair value of our short-term loan receivables approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables as of July 27, 2024 and July 29, 2023 was $2.7 billion and $2.9 billion, respectively. The estimated fair value of our long-term loan receivables approximates their carrying value. We use unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables, and therefore they are categorized as Level 3.
As of July 27, 2024 and July 29, 2023, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of July 27, 2024, the fair value of our senior notes was $20.4 billion, with a carrying amount of $20.1 billion. This compares to a fair value of $8.7 billion and a carrying amount of $8.4 billion as of July 29, 2023. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2.


## us-gaap:DebtDisclosureTextBlock

[0000858877-24-000017:notes:242]
Borrowings 
(a)Short-Term Debt

[0000858877-24-000017:notes:243]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-24-000017:notes:244]
|  | July 27, 2024 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 488 |  |  | 6.66 | % |  | $ | 1,733 |  |  | 4.45 | % |
| Commercial paper | 10,853 |  |  | 5.43 | % |  | — |  |  | — |  |
| Total | $ | 11,341 |  |  |  |  | $ | 1,733 |  |  |  |

[0000858877-24-000017:notes:245]
We have a short-term debt financing program of up to $15.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-24-000017:notes:246]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-24-000017:notes:247]
(b)Long-Term Debt

[0000858877-24-000017:notes:248]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-24-000017:notes:249]
|  |  |  | July 27, 2024 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | — |  |  | — |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.66% |  | 500 |  |  | 6.38% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | — |  |  | — |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | — |  |  | — |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | — |  |  | — |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | — |  |  | — |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | — |  |  | — |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | — |  |  | — |
| Other long-term debt |  |  | 3 |  |  | 1.13% |  | — |  |  | — |
| Total |  |  | 20,253 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (133) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (11) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 20,109 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 488 |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 19,621 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 20,109 |  |  |  |  | $ | 8,391 |  |  |  |

[0000858877-24-000017:notes:250]
In February 2024, we issued senior notes for an aggregate principal amount of $13.5 billion.

[0000858877-24-000017:notes:251]
We entered into an interest rate swap in a prior period with an aggregate notional amount of $0.5 billion designated as a fair value hedge of certain of our fixed-rate senior notes. This swap converts the fixed interest rate of the fixed-rate note to a floating interest rate based on Secured Overnight Financing Rate (SOFR). The gain and loss related to the change in the fair value of the interest rate swap substantially offsets the change in the fair value of the hedged portion of the underlying debt that is attributable to the change in market interest rates. For additional information, see Note 13.

[0000858877-24-000017:notes:252]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of July 27, 2024, we were in compliance with all debt covenants.

[0000858877-24-000017:notes:253]
As of July 27, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-24-000017:notes:254]
| Fiscal Year | Amount |
| 2025 | $ | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | — |  |
| 2029 | 2,500 |  |
| Thereafter | 12,000 |  |
| Total | $ | 20,253 |  |

[0000858877-24-000017:notes:255]
(c)Credit Facility

[0000858877-24-000017:notes:256]
On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of July 27, 2024, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-24-000017:notes:257]
Derivative Instruments 
(a)Summary of Derivative Instruments

[0000858877-24-000017:notes:258]
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risks by limiting our counterparties to major financial institutions and requiring collateral in certain cases. In addition, the potential risk of loss with any one counterparty resulting from credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-24-000017:notes:259]
The fair values of our derivative instruments and the line items on the Consolidated Balance Sheets to which they were recorded are summarized as follows (in millions):

[0000858877-24-000017:notes:260]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | July 27, 2024 |  | July 29, 2023 |  | Balance Sheet Line Item |  | July 27, 2024 |  | July 29, 2023 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 47 |  |  | $ | 22 |  |  | Other current liabilities |  | $ | 1 |  |  | $ | — |  |
| Foreign currency derivatives | Other assets |  | 15 |  |  | 9 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 11 |  |  | 17 |  |
| Interest rate derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | — |  |  | 24 |  |
| Total |  |  | 62 |  |  | 31 |  |  |  |  | 12 |  |  | 41 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 2 |  |  | 1 |  |  | Other current liabilities |  | 47 |  |  | 25 |  |
| Foreign currency derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 15 |  |  | 9 |  |
| Total |  |  | 2 |  |  | 1 |  |  |  |  | 62 |  |  | 34 |  |
| Total |  |  | $ | 64 |  |  | $ | 32 |  |  |  |  | $ | 74 |  |  | $ | 75 |  |

[0000858877-24-000017:notes:261]
The following amounts were recorded on the Consolidated Balance Sheets related to cumulative basis adjustments for our fair value hedges (in millions):

[0000858877-24-000017:notes:262]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | July 27,2024 |  | July 29,2023 |  | July 27,2024 |  | July 29,2023 |
| Short-term debt |  | $ | (488) |  |  | $ | (983) |  |  | $ | 11 |  |  | $ | 17 |  |
| Long-term debt |  | $ | — |  |  | $ | (476) |  |  | $ | — |  |  | $ | 24 |  |

[0000858877-24-000017:notes:263]
The effect of derivative instruments designated as fair value hedges, recognized in interest and other income (loss), net is summarized as follows (in millions):

[0000858877-24-000017:notes:264]
|  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
|  |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Interest rate derivatives: |  |  |  |  |  |  |
| Hedged items |  | $ | (30) |  |  | $ | 31 |  |  | $ | 116 |  |
| Derivatives designated as hedging instruments |  | 30 |  |  | (31) |  |  | (118) |  |
| Total |  | $ | — |  |  | $ | — |  |  | $ | (2) |  |

[0000858877-24-000017:notes:265]
The effect on the Consolidated Statements of Operations of derivative instruments not designated as hedges is summarized as follows (in millions):

[0000858877-24-000017:notes:266]
|  |  |  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (162) |  |  | $ | 1 |  |  | $ | (237) |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | 91 |  |  | 58 |  |  | (92) |  |
| Equity derivatives |  | Other income (loss), net |  | 2 |  |  | 13 |  |  | 9 |  |
| Total |  |  |  | $ | (69) |  |  | $ | 72 |  |  | $ | (320) |  |

[0000858877-24-000017:notes:267]
The notional amounts of our outstanding derivatives are summarized as follows (in millions):

[0000858877-24-000017:notes:268]
|  | July 27, 2024 |  | July 29, 2023 |
| Foreign currency derivatives | $ | 7,434 |  |  | $ | 5,419 |  |
| Interest rate derivatives | 500 |  |  | 1,500 |  |
| Total return swaps—deferred compensation | 985 |  |  | 792 |  |
| Total | $ | 8,919 |  |  | $ | 7,711 |  |

[0000858877-24-000017:notes:269]
(b)Offsetting of Derivative Instruments

[0000858877-24-000017:notes:270]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty.

[0000858877-24-000017:notes:271]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral provided for was $11 million and $40 million as of July 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000017:notes:272]
(c)Foreign Currency Exchange Risk

[0000858877-24-000017:notes:273]
We conduct business globally in numerous currencies. Therefore, we are exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, we enter into foreign currency contracts. We do not enter into such contracts for speculative purposes.

[0000858877-24-000017:notes:274]
We hedge forecasted foreign currency transactions related to certain revenues, operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The derivative instrument’s gain or loss is initially reported as a component of accumulated other comprehensive income (AOCI) and subsequently reclassified into earnings when the hedged exposure affects earnings.

[0000858877-24-000017:notes:275]
We enter into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, long-term customer financings and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of monetary assets and liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-24-000017:notes:276]
We hedge certain net investments in our foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on our net investment in those foreign subsidiaries. These derivative instruments generally have maturities of up to six months.

[0000858877-24-000017:notes:277]
(d)Interest Rate Risk

[0000858877-24-000017:notes:278]
We hold an interest rate swap designated as a fair value hedge related to a fixed-rate senior note that is due in fiscal 2025. Under the interest rate swap, we receive fixed-rate interest payments and make interest payments based on SOFR plus a fixed number of basis points. The effect of the swap is to convert the fixed interest rate of the senior fixed-rate note to a floating interest rate based on SOFR. The gain and loss related to the change in the fair value of the interest rate swap is included in interest expense and substantially offsets the change in the fair value of the hedged portion of the underlying debt attributable to the change in market interest rates.

[0000858877-24-000017:notes:279]
(e)Equity Price Risk

[0000858877-24-000017:notes:280]
We hold marketable equity securities in our portfolio that are subject to price risk. To diversify our overall portfolio, we also hold equity derivatives that are not designated as accounting hedges. The change in the fair value of each of these investment types are included in other income (loss), net. 
We are also exposed to variability in compensation charges related to certain deferred compensation obligations to employees and directors. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure and offset the related compensation expense.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-24-000017:notes:281]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-24-000017:notes:282]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments are directly with suppliers, and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-24-000017:notes:283]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-24-000017:notes:284]
| Commitments by Period | July 27,2024 |  | July 29,2023 |
| Less than 1 year | $ | 3,952 |  |  | $ | 5,270 |  |
| 1 to 3 years | 1,085 |  |  | 1,783 |  |
| 3 to 5 years | 121 |  |  | 200 |  |
| Total | $ | 5,158 |  |  | $ | 7,253 |  |

[0000858877-24-000017:notes:285]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 27, 2024 and July 29, 2023, the liability for these purchase commitments was $498 million and $529 million, respectively, and was included in other current liabilities.

[0000858877-24-000017:notes:286]
(b)Other Commitments

[0000858877-24-000017:notes:287]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.2 billion and $0.3 billion as of July 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000017:notes:288]
(c)Product Warranties

[0000858877-24-000017:notes:289]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-24-000017:notes:290]
|  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Balance at beginning of fiscal year | $ | 329 |  |  | $ | 333 |  |  | $ | 336 |  |
| Provisions for warranties issued | 425 |  |  | 386 |  |  | 415 |  |
| Adjustments for pre-existing warranties | 22 |  |  | 18 |  |  | 3 |  |
| Settlements | (414) |  |  | (408) |  |  | (421) |  |
| Balance at end of fiscal year | $ | 362 |  |  | $ | 329 |  |  | $ | 333 |  |

[0000858877-24-000017:notes:291]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-24-000017:notes:292]
(d)Financing and Other Guarantees

[0000858877-24-000017:notes:293]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-24-000017:notes:294]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $27.1 billion, $32.1 billion, and $27.9 billion in fiscal 2024, 2023, and 2022, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.7 billion as of July 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000017:notes:295]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at July 27, 2024 and July 29, 2023, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-24-000017:notes:296]
|  | July 27, 2024 |  | July 29, 2023 |
| Maximum potential future payments | $ | 127 |  |  | $ | 159 |  |
| Deferred revenue | (13) |  |  | (34) |  |
| Total | $ | 114 |  |  | $ | 125 |  |

[0000858877-24-000017:notes:297]
(e)Indemnifications

[0000858877-24-000017:notes:298]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-24-000017:notes:299]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-24-000017:notes:300]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-24-000017:notes:301]
(f)Legal Proceedings

[0000858877-24-000017:notes:302]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-24-000017:notes:303]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $143 million for the alleged evasion of import and other taxes, $830 million for interest, and $325 million for various penalties, all determined using an exchange rate as of July 27, 2024.

[0000858877-24-000017:notes:304]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-24-000017:notes:305]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. After two bench trials and various administrative actions and appeals, we have been found either to not have infringed any of the patents or the patents have been invalidated. Centripetal has appealed one of the invalidity decisions and it has also appealed the non-infringement judgment of the District Court and both of those proceedings are ongoing.

[0000858877-24-000017:notes:306]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringed three patents, one patent was invalidated, the utility model was invalidated, and the infringement action on the final patent is stayed due to an invalidity action heard on June 6, 2024 in the Federal Patent Court, in which all claims, aside from one auxiliary claim, were found invalid, for which we are awaiting the entry of judgment from the Federal Patent Court. Centripetal’s appeals of two of the non-infringement findings remain pending and, on March 27, 2024, the Court of Appeals rejected Centripetal’s appeal of the third non-infringement finding.

[0000858877-24-000017:notes:307]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement. We have filed our response and defenses to the complaint and we anticipate that in October 2024, the Court will set a schedule for the remainder of the proceedings.

[0000858877-24-000017:notes:308]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of the litigations at this time. If we do not prevail in these litigations, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-24-000017:notes:309]
Ramot     On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents and those proceedings are ongoing.

[0000858877-24-000017:notes:310]
While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-24-000017:notes:311]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023, the appeal is fully briefed and we are awaiting a hearing date from the Federal Circuit.

[0000858877-24-000017:notes:312]
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. 
For additional information regarding intellectual property litigation, see “Part I, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-24-000017:notes:313]
Stockholders’ Equity 
(a)Stock Repurchase Program

[0000858877-24-000017:notes:314]
In September 2001, our Board of Directors authorized a stock repurchase program. As of July 27, 2024, the remaining authorized amount for stock repurchases under this program was approximately $5.2 billion with no termination date.

[0000858877-24-000017:notes:315]
Our stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-24-000017:notes:316]
| Years Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| July 27, 2024 |  | 117 |  |  | $ | 49.45 |  |  | $ | 5,764 |  |
| July 29, 2023 |  | 88 |  |  | $ | 48.49 |  |  | $ | 4,271 |  |
| July 30, 2022 |  | 146 |  |  | $ | 52.82 |  |  | $ | 7,734 |  |

[0000858877-24-000017:notes:317]
There were $25 million, $48 million and $70 million in stock repurchases that were pending settlement as of July 27, 2024, July 29, 2023 and July 30, 2022, respectively.

[0000858877-24-000017:notes:318]
The purchase price for the shares of our stock repurchased is reflected as a reduction to stockholders’ equity.

[0000858877-24-000017:notes:319]
We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings or an increase to accumulated deficit and (ii) a reduction of common stock and additional paid-in capital.

[0000858877-24-000017:notes:320]
(b)Dividends Declared

[0000858877-24-000017:notes:321]
On August 14, 2024, our Board of Directors declared a quarterly dividend of $0.40 per common share to be paid on October 23, 2024, to all stockholders of record as of the close of business on October 2, 2024. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-24-000017:notes:322]
(c)Preferred Stock

[0000858877-24-000017:notes:323]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock in one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights, if any, of such series, and any qualifications, limitations or restrictions thereof, of the shares of such series. As of July 27, 2024, we have not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-24-000017:notes:324]
Employee Benefit Plans  
(a)Employee Stock Incentive Plans

[0000858877-24-000017:notes:325]
We have one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with us. The number and frequency of share-based awards are based on competitive practices, our operating results, government regulations, and other factors.

[0000858877-24-000017:notes:326]
The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions. Time-based and performance-based RSUs generally vest over three years with certain awards containing retirement eligible provisions. Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. The 2005 Plan may be terminated by our Board of Directors at any time and for any reason, and is currently set to terminate at the 2030 Annual Meeting unless re-adopted or extended by our stockholders prior to or on such date.

[0000858877-24-000017:notes:327]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of July 27, 2024, 156 million shares were authorized for future grant under the 2005 Plan.

[0000858877-24-000017:notes:328]
(b)Employee Stock Purchase Plan

[0000858877-24-000017:notes:329]
We have an Employee Stock Purchase Plan under which eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. We issued 20 million, 19 million, and 18 million shares under the Employee Stock Purchase Plan in fiscal 2024, 2023, and 2022, respectively. As of July 27, 2024, 68 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-24-000017:notes:330]
(c)Summary of Share-Based Compensation Expense

[0000858877-24-000017:notes:331]
Share-based compensation expense consists of expenses for RSUs, stock purchase rights, and stock options, granted to employees or assumed from acquisitions. The following table summarizes share-based compensation expense (in millions):

[0000858877-24-000017:notes:332]
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Cost of sales—product | $ | 214 |  |  | $ | 151 |  |  | $ | 112 |  |
| Cost of sales—services | 300 |  |  | 245 |  |  | 199 |  |
| Share-based compensation expense in cost of sales | 514 |  |  | 396 |  |  | 311 |  |
| Research and development | 1,316 |  |  | 1,008 |  |  | 790 |  |
| Sales and marketing | 846 |  |  | 673 |  |  | 572 |  |
| General and administrative | 375 |  |  | 270 |  |  | 212 |  |
| Restructuring and other charges | 23 |  |  | 6 |  |  | 1 |  |
| Share-based compensation expense in operating expenses | 2,560 |  |  | 1,957 |  |  | 1,575 |  |
| Total share-based compensation expense | $ | 3,074 |  |  | $ | 2,353 |  |  | $ | 1,886 |  |
| Income tax benefit for share-based compensation | $ | 696 |  |  | $ | 449 |  |  | $ | 457 |  |

[0000858877-24-000017:notes:333]
As of July 27, 2024, the total compensation cost related to unvested share-based awards not yet recognized was $4.6 billion, which is expected to be recognized over approximately 1.8 years on a weighted-average basis.

[0000858877-24-000017:notes:334]
(d)Restricted Stock Unit Awards

[0000858877-24-000017:notes:335]
A summary of the restricted stock and stock unit activity, which includes time-based and performance-based or market-based RSUs, is as follows (in millions, except per-share amounts):

[0000858877-24-000017:notes:336]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 31, 2021 | 94 |  |  | $ | 42.93 |  |  |  |
| Granted and assumed | 52 |  |  | 50.06 |  |  |  |
| Vested | (37) |  |  | 42.27 |  |  | $ | 1,979 |  |
| Canceled/forfeited/other | (12) |  |  | 45.63 |  |  |  |
| UNVESTED BALANCE AT JULY 30, 2022 | 97 |  |  | 46.67 |  |  |  |
| Granted and assumed | 72 |  |  | 42.08 |  |  |  |
| Vested | (39) |  |  | 46.69 |  |  | $ | 1,746 |  |
| Canceled/forfeited/other | (8) |  |  | 45.17 |  |  |  |
| UNVESTED BALANCE AT JULY 29, 2023 | 122 |  |  | 44.04 |  |  |  |
| Granted and assumed | 63 |  |  | 48.97 |  |  |  |
| Vested | (58) |  |  | 43.46 |  |  | $ | 2,906 |  |
| Canceled/forfeited/other | (10) |  |  | 45.65 |  |  |  |
| UNVESTED BALANCE AT JULY 27, 2024 | 117 |  |  | $ | 46.86 |  |  |  |

[0000858877-24-000017:notes:337]
(e)Valuation of Employee Share-Based Awards

[0000858877-24-000017:notes:338]
Time-based restricted stock units and PRSUs that are based on our financial performance metrics or non-financial operating goals are valued using the market value of our common stock on the date of grant, discounted for the present value of expected dividends. Starting in fiscal 2023, for PRSUs granted, we included a relative total shareholder return (TSR) modifier to determine the number of shares earned at the end of the performance period. The TSR modifier is determined using a Monte Carlo simulation model. For PRSUs granted in fiscal 2022, on the date of grant, we estimated the fair value of the TSR component of the PRSUs using a Monte Carlo simulation model. The PRSUs granted during the fiscal years presented are contingent on the achievement of our financial performance metrics, our comparative market-based returns, or the achievement of financial and non-financial operating goals.

[0000858877-24-000017:notes:339]
The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-24-000017:notes:340]
|  | RESTRICTED STOCK UNITS |
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Number of shares granted (in millions) | 60 |  |  | 70 |  |  | 50 |  |
| Grant date fair value per share | $ | 48.71 |  |  | $ | 42.13 |  |  | $ | 49.68 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 3.0 | % |  | 3.4 | % |  | 2.9 | % |
| Range of risk-free interest rates | 4.2% – 5.6% |  | 3.7% – 5.7% |  | 0.0% – 3.0% |

[0000858877-24-000017:notes:341]
|  | PERFORMANCE BASED RESTRICTED STOCK UNITS |
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Number of shares granted (in millions) | 3 |  |  | 2 |  |  | 2 |  |
| Grant date fair value per share | $ | 59.31 |  |  | $ | 40.44 |  |  | $ | 59.64 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | N/A |  | N/A |  | 0.4 | % |
| Range of risk-free interest rates | N/A |  | N/A |  | 0.0% – 0.7% |

[0000858877-24-000017:notes:342]
The assumptions for the valuation of employee stock purchase rights are summarized as follows:

[0000858877-24-000017:notes:343]
|  | EMPLOYEE STOCK PURCHASE RIGHTS |
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Weighted-average assumptions: |  |  |  |  |  |
| Expected volatility | 28.3 | % |  | 28.7 | % |  | 27.9 | % |
| Risk-free interest rate | 2.9 | % |  | 2.8 | % |  | 0.1 | % |
| Expected dividend | 3.5 | % |  | 3.6 | % |  | 3.2 | % |
| Expected life (in years) | 1.2 |  | 1.2 |  | 1.2 |
| Weighted-average estimated grant date fair value per share | $ | 11.59 |  |  | $ | 12.40 |  |  | $ | 12.90 |  |

[0000858877-24-000017:notes:344]
The valuation of employee stock purchase rights and the related assumptions are for the employee stock purchases made during the respective fiscal years.

[0000858877-24-000017:notes:345]
We used the implied volatility for traded options (with contract terms corresponding to the expected life of the employee stock purchase rights) on our stock as the expected volatility assumption required in the Black-Scholes model. The implied volatility is more representative of future stock price trends than historical volatility. The risk-free interest rate assumption is based upon observed interest rates appropriate for the term of our employee stock purchase rights. The dividend yield assumption is based on the history and expectation of dividend payouts at the grant date.

[0000858877-24-000017:notes:346]
(f)Employee 401(k) Plans

[0000858877-24-000017:notes:347]
We sponsor the Cisco Systems, Inc. 401(k) Plan (the “Plan”) to provide retirement benefits for our employees. As allowed under Section 401(k) of the Internal Revenue Code, the Plan provides for tax-deferred salary contributions and after-tax contributions for eligible employees. The Plan allows employees to contribute up to 75% of their annual eligible earnings to the Plan on a pretax and after-tax basis, including Roth contributions. Employee contributions are limited to a maximum annual amount as set periodically by the Internal Revenue Code. We match pretax and Roth employee contributions up to 100% of the first 4.5% of eligible earnings that are contributed by employees. Therefore, the maximum matching contribution that we may allocate to each participant’s account will not exceed $15,525 for the 2024 calendar year due to the $345,000 annual limit on eligible earnings imposed by the Internal Revenue Code. All matching contributions vest immediately. Our matching contributions to the Plan totaled $358 million, $342 million, and $306 million in fiscal 2024, 2023, and 2022, respectively.

[0000858877-24-000017:notes:348]
The Plan allows employees who meet the age requirements and reach the Plan contribution limits to make catch-up contributions (pretax or Roth) not to exceed the lesser of 75% of their annual eligible earnings or the limit set forth in the Internal Revenue Code. Catch-up contributions are not eligible for matching contributions. In addition, the Plan provides for discretionary profit-sharing contributions as determined by the Board of Directors. Such contributions to the Plan are allocated among eligible participants in the proportion of their salaries to the total salaries of all participants. There were no discretionary profit-sharing contributions made in fiscal 2024, 2023, and 2022.

[0000858877-24-000017:notes:349]
We also sponsor other 401(k) plans as a result of acquisitions of other companies. Our contributions to these plans were not material to Cisco on either an individual or aggregate basis for any of the fiscal years presented.

[0000858877-24-000017:notes:350]
(g)Deferred Compensation Plans
The Cisco Systems, Inc. Deferred Compensation Plan (the “Deferred Compensation Plan”), a nonqualified deferred compensation plan, became effective in 2007. As required by applicable law, participation in the Deferred Compensation Plan is limited to a select group of our management employees. Under the Deferred Compensation Plan, which is an unfunded and unsecured deferred compensation arrangement, a participant may elect to defer base salary, bonus, and/or commissions, pursuant to such rules as may be established by Cisco, up to the maximum percentages for each deferral election as described in the plan. We may also, at our discretion, make a matching contribution to the employee under the Deferred Compensation Plan. A matching contribution equal to 4.5% of eligible compensation in excess of the Internal Revenue Code limit for qualified plans for calendar year 2024 that is deferred by participants under the Deferred Compensation Plan (with a $1.5 million cap on eligible compensation) will be made to eligible participants’ accounts at the end of calendar year 2024. The total deferred compensation liability under the Deferred Compensation Plan, together with deferred compensation plans assumed from acquired companies, was approximately $1.1 billion and $910 million as of July 27, 2024 and July 29, 2023, respectively, and was recorded primarily in other long-term liabilities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-24-000017:notes:351]
Accumulated Other Comprehensive Income (Loss)  
The components of AOCI, net of tax, and the other comprehensive income (loss) are summarized as follows (in millions):

[0000858877-24-000017:notes:352]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 31, 2021 | $ | 182 |  |  | $ | (1) |  |  | $ | (598) |  |  | $ | (417) |  |
| Other comprehensive income (loss) before reclassifications | (731) |  |  | 87 |  |  | (647) |  |  | (1,291) |  |
| (Gains) losses reclassified out of AOCI | (9) |  |  | (29) |  |  | 2 |  |  | (36) |  |
| Tax benefit (expense) | 179 |  |  | (13) |  |  | (44) |  |  | 122 |  |
| BALANCE AT JULY 30, 2022 | (379) |  |  | 44 |  |  | (1,287) |  |  | (1,622) |  |
| Other comprehensive income (loss) before reclassifications | (113) |  |  | 29 |  |  | 116 |  |  | 32 |  |
| (Gains) losses reclassified out of AOCI | 21 |  |  | (63) |  |  | (1) |  |  | (43) |  |
| Tax benefit (expense) | 31 |  |  | 8 |  |  | 19 |  |  | 58 |  |
| BALANCE AT JULY 29, 2023 | (440) |  |  | 18 |  |  | (1,153) |  |  | (1,575) |  |
| Other comprehensive income (loss) before reclassifications | 193 |  |  | 128 |  |  | (115) |  |  | 206 |  |
| (Gains) losses reclassified out of AOCI | 67 |  |  | (49) |  |  | (2) |  |  | 16 |  |
| Tax benefit (expense) | (61) |  |  | (18) |  |  | 2 |  |  | (77) |  |
| BALANCE AT JULY 27, 2024 | $ | (241) |  |  | $ | 79 |  |  | $ | (1,268) |  |  | $ | (1,430) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-24-000017:notes:353]
Income Taxes
(a)Provision for Income Taxes

[0000858877-24-000017:notes:354]
The provision for income taxes consists of the following (in millions):

[0000858877-24-000017:notes:355]
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Federal: |  |  |  |  |  |
| Current | $ | 1,939 |  |  | $ | 3,754 |  |  | $ | 2,203 |  |
| Deferred | (883) |  |  | (1,955) |  |  | (176) |  |
|  | 1,056 |  |  | 1,799 |  |  | 2,027 |  |
| State: |  |  |  |  |  |
| Current | 388 |  |  | 623 |  |  | 458 |  |
| Deferred | 11 |  |  | (175) |  |  | (156) |  |
|  | 399 |  |  | 448 |  |  | 302 |  |
| Foreign: |  |  |  |  |  |
| Current | 559 |  |  | 412 |  |  | 313 |  |
| Deferred | (100) |  |  | 46 |  |  | 23 |  |
|  | 459 |  |  | 458 |  |  | 336 |  |
| Total | $ | 1,914 |  |  | $ | 2,705 |  |  | $ | 2,665 |  |

[0000858877-24-000017:notes:356]
Income before provision for income taxes consists of the following (in millions):

[0000858877-24-000017:notes:357]
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| United States | $ | 10,790 |  |  | $ | 14,074 |  |  | $ | 13,550 |  |
| International | 1,444 |  |  | 1,244 |  |  | 927 |  |
| Total | $ | 12,234 |  |  | $ | 15,318 |  |  | $ | 14,477 |  |

[0000858877-24-000017:notes:358]
The items accounting for the difference between income taxes computed at the federal statutory rate and the provision for income taxes consist of the following:

[0000858877-24-000017:notes:359]
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Federal statutory rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 2.8 |  |  | 2.4 |  |  | 1.7 |  |
| Foreign income at other than U.S. rates | (0.3) |  |  | (0.1) |  |  | 0.8 |  |
| Tax credits | (2.4) |  |  | (0.3) |  |  | (1.6) |  |
| Foreign-derived intangible income deduction | (5.5) |  |  | (5.8) |  |  | (3.9) |  |
| Stock-based compensation | 0.7 |  |  | 1.1 |  |  | 0.3 |  |
| Other, net | (0.7) |  |  | (0.6) |  |  | 0.1 |  |
| Total | 15.6 | % |  | 17.7 | % |  | 18.4 | % |

[0000858877-24-000017:notes:360]
On August 26, 2024, the U.S. Tax Court issued a ruling in Varian Medical Systems, Inc. v. Commissioner. The ruling related to the U.S. taxation of deemed foreign dividends in the transition year of the Tax Act (our fiscal 2018). We are currently evaluating the potential benefit of this ruling to our provision for income taxes.

[0000858877-24-000017:notes:361]
During fiscal 2023, we resolved certain items with the Internal Revenue Service (IRS) related to the audit of our federal income tax returns for the fiscal years ended July 26, 2014 through July 30, 2016. As a result of this resolution, we recognized a net benefit to the provision for income taxes of $145 million, which included a reduction of interest expense of $53 million. During fiscal 2024, we resolved all remaining items with the IRS related to the audit of our federal income tax returns for the fiscal years ended July 26, 2014 through July 30, 2016. As a result of this resolution, we recognized a net benefit to the provision for income taxes of $55 million, which included a reduction of interest expense of $18 million.

[0000858877-24-000017:notes:362]
Foreign taxes associated with the repatriation of earnings of foreign subsidiaries were not provided on a cumulative total of $6.5 billion of undistributed earnings for certain foreign subsidiaries as of the end of fiscal 2024. We intend to reinvest these

[0000858877-24-000017:notes:363]
earnings indefinitely in such foreign subsidiaries. If these earnings were distributed in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, we could be subject to additional income and withholding taxes. The amount of potential unrecognized deferred income tax liability related to these earnings is approximately $681 million.

[0000858877-24-000017:notes:364]
Unrecognized Tax Benefits

[0000858877-24-000017:notes:365]
The aggregate changes in the balance of gross unrecognized tax benefits were as follows (in millions):

[0000858877-24-000017:notes:366]
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Beginning balance | $ | 2,137 |  |  | $ | 3,101 |  |  | $ | 3,106 |  |
| Additions based on tax positions related to the current year | 205 |  |  | 159 |  |  | 157 |  |
| Additions for tax positions of prior years | 256 |  |  | 261 |  |  | 74 |  |
| Reductions for tax positions of prior years | (344) |  |  | (265) |  |  | (81) |  |
| Settlements | (53) |  |  | (1,063) |  |  | (69) |  |
| Lapse of statute of limitations | (45) |  |  | (56) |  |  | (86) |  |
| Ending balance | $ | 2,156 |  |  | $ | 2,137 |  |  | $ | 3,101 |  |

[0000858877-24-000017:notes:367]
As a result of the resolution of the IRS audit of our federal tax income tax returns for the fiscal years ended July 26, 2014 through July 30, 2016, the amount of gross unrecognized tax benefits was reduced by approximately $1.1 billion in fiscal 2023 and $245 million in fiscal 2024.

[0000858877-24-000017:notes:368]
As of July 27, 2024, $1.5 billion of the unrecognized tax benefits would affect the effective tax rate if realized. We recognized net interest expense of $21 million, $27 million and $33 million during fiscal 2024, 2023, and 2022, respectively. Our net penalty expense for fiscal 2024, 2023, and 2022 was not material. Our total accrual for interest and penalties was $401 million, $523 million, and $486 million as of the end of fiscal 2024, 2023, and 2022, respectively. We are no longer subject to U.S. federal income tax audit for returns covering tax years through fiscal 2016. We are no longer subject to foreign or state income tax audits for returns covering tax years through fiscal 2003 and fiscal 2008, respectively.

[0000858877-24-000017:notes:369]
We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters. We estimate that the unrecognized tax benefits at July 27, 2024 could be reduced by $100 million in the next 12 months.

[0000858877-24-000017:notes:370]
(b)Deferred Tax Assets and Liabilities

[0000858877-24-000017:notes:371]
The following table presents the breakdown for net deferred tax assets (in millions):

[0000858877-24-000017:notes:372]
|  | July 27, 2024 |  | July 29, 2023 |
| Deferred tax assets | $ | 6,262 |  |  | $ | 6,576 |  |
| Deferred tax liabilities | (76) |  |  | (62) |  |
| Total net deferred tax assets | $ | 6,186 |  |  | $ | 6,514 |  |

[0000858877-24-000017:notes:373]
The following table presents the components of the deferred tax assets and liabilities (in millions):

[0000858877-24-000017:notes:374]
|  | July 27, 2024 |  | July 29, 2023 |
| ASSETS |  |  |  |
| Allowance for accounts receivable and returns | $ | 94 |  |  | $ | 81 |  |
| Sales-type and direct-financing leases | 23 |  |  | 22 |  |
| Inventory write-downs and capitalization | 530 |  |  | 452 |  |
| Deferred foreign income | 277 |  |  | 218 |  |
| IPR&D and purchased intangible assets | 1,039 |  |  | 1,082 |  |
| Depreciation | 184 |  |  | 16 |  |
| Deferred revenue | 2,034 |  |  | 1,801 |  |
| Credits and net operating loss carryforwards | 1,863 |  |  | 1,218 |  |
| Share-based compensation expense | 297 |  |  | 198 |  |
| Accrued compensation | 275 |  |  | 328 |  |
| Lease liabilities | 308 |  |  | 246 |  |
| Capitalized research expenditures | 3,030 |  |  | 2,042 |  |
| Other | 442 |  |  | 484 |  |
| Gross deferred tax assets | 10,396 |  |  | 8,188 |  |
| Valuation allowance | (1,024) |  |  | (754) |  |
| Total deferred tax assets | 9,372 |  |  | 7,434 |  |
| LIABILITIES |  |  |  |
| Goodwill and purchased intangible assets | (2,808) |  |  | (602) |  |
| ROU lease assets | (259) |  |  | (234) |  |
| Other | (119) |  |  | (84) |  |
| Total deferred tax liabilities | (3,186) |  |  | (920) |  |
| Total net deferred tax assets | $ | 6,186 |  |  | $ | 6,514 |  |

[0000858877-24-000017:notes:375]
The changes in the valuation allowance for deferred tax assets are summarized as follows (in millions):

[0000858877-24-000017:notes:376]
|  |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Balance at beginning of fiscal year |  | $ | 754 |  |  | $ | 834 |  |  | $ | 771 |  |
| Additions |  | 148 |  |  | 35 |  |  | 84 |  |
| Additions from Splunk |  | 147 |  |  | — |  |  | — |  |
| Deductions |  | (4) |  |  | (18) |  |  | (10) |  |
| Write-offs |  | (20) |  |  | (93) |  |  | (12) |  |
| Foreign exchange and other |  | (1) |  |  | (4) |  |  | 1 |  |
| Balance at end of fiscal year |  | $ | 1,024 |  |  | $ | 754 |  |  | $ | 834 |  |

[0000858877-24-000017:notes:377]
As of July 27, 2024, our federal, state, and foreign net operating loss carryforwards before valuation allowance for income tax purposes were $1.4 billion, $1.9 billion, and $531 million, respectively. A significant amount of the net operating loss carryforwards relates to acquisitions and, as a result, is limited in the amount that can be recognized in any one year. If not utilized, the federal, state, and foreign net operating loss carryforwards will begin to expire in fiscal 2025. We have provided a valuation allowance of $86 million and $10 million for deferred tax assets related to foreign and state net operating losses respectively that are not expected to be realized.
As of July 27, 2024, our federal, state, and foreign tax credit carryforwards for income tax purposes before valuation allowance were approximately $309 million, $1.9 billion, and $11 million, respectively. The federal tax credit carryforwards will begin to expire in fiscal 2026. The majority of state and foreign tax credits can be carried forward indefinitely. We have provided a valuation allowance of $878 million for deferred tax assets related to state and foreign tax credits carryforwards that are not expected to be realized.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-24-000017:notes:378]
Segment Information and Major Customers 
(a)Revenue and Gross Margin by Segment

[0000858877-24-000017:notes:379]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-24-000017:notes:380]
Summarized financial information by segment for fiscal 2024, 2023, and 2022, based on our internal management system and as utilized by our Chief Operating Decision Maker (CODM), is as follows (in millions):

[0000858877-24-000017:notes:381]
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Revenue: |  |  |  |  |  |
| Americas | $ | 31,971 |  |  | $ | 33,447 |  |  | $ | 29,814 |  |
| EMEA | 14,117 |  |  | 15,135 |  |  | 13,715 |  |
| APJC | 7,716 |  |  | 8,417 |  |  | 8,027 |  |
| Total | $ | 53,803 |  |  | $ | 56,998 |  |  | $ | 51,557 |  |
| Gross margin: |  |  |  |  |  |
| Americas | $ | 21,372 |  |  | $ | 21,350 |  |  | $ | 19,117 |  |
| EMEA | 9,755 |  |  | 10,016 |  |  | 8,969 |  |
| APJC | 5,187 |  |  | 5,424 |  |  | 5,241 |  |
| Segment total | 36,312 |  |  | 36,788 |  |  | 33,326 |  |
| Unallocated corporate items | (1,484) |  |  | (1,035) |  |  | (1,078) |  |
| Total | $ | 34,828 |  |  | $ | 35,753 |  |  | $ | 32,248 |  |

[0000858877-24-000017:notes:382]
Revenue in the United States was $28.7 billion, $29.9 billion, and $26.7 billion for fiscal 2024, 2023, and 2022, respectively.

[0000858877-24-000017:notes:383]
(b)Revenue for Groups of Similar Products and Services

[0000858877-24-000017:notes:384]
We design and sell IP-based networking and other products related to the communications and IT industry and provide services associated with these products and their use. Effective fiscal 2024, we began reporting our product and services revenue in the following categories: Networking, Security, Collaboration, Observability, and Services and conformed our product revenue for prior years to the current year presentation.

[0000858877-24-000017:notes:385]
(c)Additional Segment Information

[0000858877-24-000017:notes:386]
No single customer accounted for 10% or more of revenue in fiscal 2024, 2023, and 2022.

[0000858877-24-000017:notes:387]
The majority of our assets as of July 27, 2024 and July 29, 2023 were attributable to our U.S. operations. Our long-lived assets are based on the physical location of the assets. The following table presents our long-lived assets, which consists of property and equipment, net and operating lease right-of-use assets information for geographic areas (in millions):

[0000858877-24-000017:notes:388]
|  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Long-lived assets: |  |  |  |  |  |
| United States | $ | 2,253 |  |  | $ | 2,113 |  |  | $ | 2,004 |  |
| International | 903 |  |  | 943 |  |  | 997 |  |
| Total | $ | 3,156 |  |  | $ | 3,056 |  |  | $ | 3,001 |  |


## us-gaap:EarningsPerShareTextBlock

[0000858877-24-000017:notes:389]
Net Income per Share 
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-24-000017:notes:390]
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Net income | $ | 10,320 |  |  | $ | 12,613 |  |  | $ | 11,812 |  |
| Weighted-average shares—basic | 4,043 |  |  | 4,093 |  |  | 4,170 |  |
| Effect of dilutive potential common shares | 19 |  |  | 12 |  |  | 22 |  |
| Weighted-average shares—diluted | 4,062 |  |  | 4,105 |  |  | 4,192 |  |
| Net income per share—basic | $ | 2.55 |  |  | $ | 3.08 |  |  | $ | 2.83 |  |
| Net income per share—diluted | $ | 2.54 |  |  | $ | 3.07 |  |  | $ | 2.82 |  |
| Antidilutive employee share-based awards, excluded | 82 |  |  | 86 |  |  | 70 |  |
