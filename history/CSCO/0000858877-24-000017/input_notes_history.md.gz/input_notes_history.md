# CSCO note change history — 0000858877-24-000003 → 0000858877-24-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-21):
[0000858877-24-000007:note_history:1]
|  | April 27,2024 |  | July 29,2023 |
| Less than 1 year | $ | 4,581 |  |  | $ | 5,270 |  |
| 1 to 3 years | 1,368 |  |  | 1,783 |  |
| 3 to 5 years | 55 |  |  | 200 |  |
| Total | $ | 6,004 |  |  | $ | 7,253 |  |
  (was, 2024-02-20, similarity 0.9753):
[0000858877-24-000003:note_history:1]
|  | January 27,2024 |  | July 29,2023 |
| Less than 1 year | $ | 4,711 |  |  | $ | 5,270 |  |
| 1 to 3 years | 1,456 |  |  | 1,783 |  |
| 3 to 5 years | 26 |  |  | 200 |  |
| Total | $ | 6,193 |  |  | $ | 7,253 |  |

- changed (2024-05-21):
[0000858877-24-000007:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 27, 2024 and July 29, 2023, the liability for these purchase commitments was $550 million and $529 million, respectively, and was included in other current liabilities.
  (was, 2024-02-20, similarity 0.6941):
[0000858877-24-000003:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 27, 2024 and July 29, 2023, the liability for these purchase commitments was $538 million and $529 million, respectively, and was included in other current liabilities.

- changed (2024-05-21):
[0000858877-24-000007:note_history:3]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.2 billion and $0.3 billion as of April 27, 2024 and July 29, 2023, respectively.
  (was, 2024-02-20, similarity 0.9659):
[0000858877-24-000003:note_history:3]
We also have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.2 billion and $0.3 billion as of January 27, 2024 and July 29, 2023, respectively.

- changed (2024-05-21):
[0000858877-24-000007:note_history:4]
|  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |
| Balance at beginning of period | $ | 329 |  |  | $ | 333 |  |
| Provisions for warranties issued | 316 |  |  | 285 |  |
| Adjustments for pre-existing warranties | 20 |  |  | 15 |  |
| Settlements | (302) |  |  | (321) |  |
| Balance at end of period | $ | 363 |  |  | $ | 312 |  |
  (was, 2024-02-20, similarity 0.9254):
[0000858877-24-000003:note_history:4]
|  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |
| Balance at beginning of period | $ | 329 |  |  | $ | 333 |  |
| Provisions for warranties issued | 198 |  |  | 188 |  |
| Adjustments for pre-existing warranties | 5 |  |  | 13 |  |
| Settlements | (205) |  |  | (218) |  |
| Balance at end of period | $ | 327 |  |  | $ | 316 |  |

- changed (2024-05-21):
[0000858877-24-000007:note_history:5]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.1 billion and $8.3 billion for the third quarter of fiscal 2024 and 2023, respectively, and $20.9 billion and $23.4 billion for the first nine months of fiscal 2024 and 2023, respectively. The balance of the channel partner financing subject to guarantees was $1.1 billion and $1.7 billion as of April 27, 2024 and July 29, 2023, respectively.
  (was, 2024-02-20, similarity 0.9688):
[0000858877-24-000003:note_history:5]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.6 billion and $7.5 billion for the second quarter of fiscal 2024 and 2023, respectively, and $14.8 billion and $15.1 billion for the first six months of fiscal 2024 and 2023, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.7 billion as of January 27, 2024 and July 29, 2023, respectively.

- changed (2024-05-21):
[0000858877-24-000007:note_history:6]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at April 27, 2024 and July 29, 2023, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2024-02-20, similarity 0.9817):
[0000858877-24-000003:note_history:6]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at January 27, 2024 and July 29, 2023, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2024-05-21):
[0000858877-24-000007:note_history:7]
|  | April 27,2024 |  | July 29,2023 |
| Maximum potential future payments | $ | 126 |  |  | $ | 159 |  |
| Deferred revenue | (25) |  |  | (34) |  |
| Total | $ | 101 |  |  | $ | 125 |  |
  (was, 2024-02-20, similarity 0.9744):
[0000858877-24-000003:note_history:7]
|  | January 27,2024 |  | July 29,2023 |
| Maximum potential future payments | $ | 138 |  |  | $ | 159 |  |
| Deferred revenue | (23) |  |  | (34) |  |
| Total | $ | 115 |  |  | $ | 125 |  |

- changed (2024-05-21):
[0000858877-24-000007:note_history:8]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $157 million for the alleged evasion of import and other taxes, $902 million for interest, and $357 million for various penalties, all determined using an exchange rate as of April 27, 2024.
  (was, 2024-02-20, similarity 0.995):
[0000858877-24-000003:note_history:8]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $165 million for the alleged evasion of import and other taxes, $929 million for interest, and $373 million for various penalties, all determined using an exchange rate as of January 27, 2024.

- changed (2024-05-21):
[0000858877-24-000007:note_history:9]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringed three patents, one patent was invalidated, the utility model was invalidated, and the infringement action on the final patent is stayed due to a pending invalidity action, which has a hearing set for June 6, 2024. Centripetal’s appeals of two of the non-infringement findings remain pending and, on March 27, 2024, the Court of Appeals rejected Centripetal’s appeal of the third non-infringement finding.
  (was, 2024-02-20, similarity 0.7603):
[0000858877-24-000003:note_history:9]
Between April 2020 and February 2022, Centripetal also filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. In various proceedings in 2021, 2022, and 2023, we have been found to have not infringe three patents, one patent was invalidated, the utility model was invalidated, and the infringement action on the final patent is stayed due to a pending invalidity action. There are appeals pending and the next proceeding is expected in the second half of fiscal 2024.

- changed (2024-05-21):
[0000858877-24-000007:note_history:10]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement. We
  (was, 2024-02-20, similarity 0.8548):
[0000858877-24-000003:note_history:10]
On July 10, 2023, Centripetal filed a complaint in the Paris Judiciary Court asserting the French counterpart of a European Patent. Centripetal seeks damages and injunctive relief in the case. Centripetal previously asserted the German counterpart of the same European Patent in Germany and the German Court rejected Centripetal’s complaint finding no infringement. We have filed our response and defenses to the complaint and the next proceedings are expected in the second half of fiscal 2024.

- added (2024-05-21):
[0000858877-24-000007:note_history:11]
have filed our response and defenses to the complaint and, on May 24, 2024, we expect the Paris Judiciary Court to decide our motion to dismiss and, if denied, it will set the schedule for the remainder of the proceedings.

- changed (2024-05-21):
[0000858877-24-000007:note_history:12]
Ramot     On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents and those proceedings are ongoing.
  (was, 2024-02-20, similarity 0.7514):
[0000858877-24-000003:note_history:12]
Ramot     On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the

- changed (2024-05-21):
[0000858877-24-000007:note_history:13]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023, the appeal is fully briefed and we are awaiting a hearing date from the Federal Circuit.
  (was, 2024-02-20, similarity 0.9095):
[0000858877-24-000003:note_history:13]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023 and the next proceedings are expected in the second half of fiscal 2024.

- changed (2024-05-21):
[0000858877-24-000007:note_history:14]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward. On June 9, 2020, Viasat filed another suit in SDSC alleging contract and trade secret claims for sales of additional Acacia products. Both matters have been formally dismissed and resolved during fiscal 2024 through a settlement for an amount that did not have a material effect on our Consolidated Financial Statements.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.
  (was, 2024-02-20, similarity 0.9929):
[0000858877-24-000003:note_history:14]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward. On June 9, 2020, Viasat filed another suit in SDSC alleging contract and trade secret claims for sales of additional Acacia products. Both matters have been formally dismissed and resolved through a settlement for an amount that did not have a material effect on our Consolidated Financial Statements.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.

- removed (2024-05-21):
[0000858877-24-000003:note_history:15]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

- removed (2024-05-21):
[0000858877-24-000003:note_history:16]
The following table summarizes the compensation expense related to acquisitions (in millions):

- removed (2024-05-21):
[0000858877-24-000003:note_history:17]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2024 |  | January 28, 2023 |  | January 27, 2024 |  | January 28, 2023 |
| Compensation expense related to acquisitions | $ | 45 |  |  | $ | 49 |  |  | $ | 94 |  |  | $ | 123 |  |

- removed (2024-05-21):
[0000858877-24-000003:note_history:18]
As of January 27, 2024, we estimated that future cash compensation expense of up to $397 million may be required to be recognized pursuant to the applicable business combination agreements.

- removed (2024-05-21):
[0000858877-24-000003:note_history:19]
validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents. The next proceedings are expected in the first half of fiscal 2025.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-21):
[0000858877-24-000007:note_history:20]
We have prepared the accompanying financial data as of April 27, 2024 and for the third quarter and first nine months of fiscal 2024 and 2023, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 29, 2023 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 29, 2023.
  (was, 2024-02-20, similarity 0.9861):
[0000858877-24-000003:note_history:20]
We have prepared the accompanying financial data as of January 27, 2024 and for the second quarter and first six months of fiscal 2024 and 2023, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 29, 2023 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 29, 2023.

- changed (2024-05-21):
[0000858877-24-000007:note_history:21]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of April 27, 2024, the results of operations, the statements of comprehensive income and the statements of equity for the third quarter and first nine months of fiscal 2024 and 2023, and the statements of cash flows for the first nine months of fiscal 2024 and 2023, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2024 are not necessarily indicative of the operating results for the full fiscal year or any future periods.
  (was, 2024-02-20, similarity 0.9565):
[0000858877-24-000003:note_history:21]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of January 27, 2024, the results of operations, the statements of comprehensive income and the statements of equity for the second quarter and first six months of fiscal 2024 and 2023, and the statements of cash flows for the first six months of fiscal 2024 and 2023, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2024 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-05-21):
[0000858877-24-000007:note_history:22]
|  | April 27, 2024 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | — |  |  | — |  |  | $ | 1,733 |  |  | 4.45 | % |
| Commercial paper | 11,891 |  |  | 5.42 | % |  | — |  |  | — |  |
| Total | $ | 11,891 |  |  |  |  | $ | 1,733 |  |  |  |

- added (2024-05-21):
[0000858877-24-000007:note_history:23]
We have a short-term debt financing program of up to $15.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

- added (2024-05-21):
[0000858877-24-000007:note_history:24]
|  |  |  | April 27, 2024 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | — |  |  | — |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.64% |  | 500 |  |  | 6.38% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | — |  |  | — |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | — |  |  | — |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | — |  |  | — |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | — |  |  | — |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | — |  |  | — |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | — |  |  | — |
| Other long-term debt |  |  | 3 |  |  | 1.13% |  | — |  |  | — |
| Total |  |  | 20,253 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (135) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (16) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 20,102 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | — |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 20,102 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 20,102 |  |  |  |  | $ | 8,391 |  |  |  |

- added (2024-05-21):
[0000858877-24-000007:note_history:25]
In February 2024, we issued senior notes for an aggregate principal amount of $13.5 billion.

- changed (2024-05-21):
[0000858877-24-000007:note_history:26]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 27, 2024, we were in compliance with all debt covenants.
  (was, 2024-02-20, similarity 0.9363):
[0000858877-24-000003:note_history:26]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 27, 2024, we were in compliance with all debt covenants.

- changed (2024-05-21):
[0000858877-24-000007:note_history:27]
As of April 27, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2024-02-20, similarity 0.9701):
[0000858877-24-000003:note_history:27]
As of January 27, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2024-05-21):
[0000858877-24-000007:note_history:28]
| Fiscal Year | Amount |
| 2024 (remaining three months) | $ | — |  |
| 2025 | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | — |  |
| Thereafter | 14,500 |  |
| Total | $ | 20,253 |  |
  (was, 2024-02-20, similarity 0.9252):
[0000858877-24-000003:note_history:28]
| Fiscal Year | Amount |
| 2024 (remaining six months) | $ | 1,000 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 7,750 |  |

- changed (2024-05-21):
[0000858877-24-000007:note_history:29]
On May 13, 2021, we entered into a 5-year $3.0 billion unsecured revolving credit agreement, as amended on April 18, 2023. On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of April 27, 2024, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.
  (was, 2024-02-20, similarity 0.9642):
[0000858877-24-000003:note_history:29]
On May 13, 2021, we entered into a 5-year $3.0 billion unsecured revolving credit agreement, as amended on April 18, 2023. On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of January 27, 2024, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.

- removed (2024-05-21):
[0000858877-24-000003:note_history:30]
|  | January 27, 2024 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 997 |  |  | 6.35 | % |  | $ | 1,733 |  |  | 4.45 | % |
| Commercial paper | 3,939 |  |  | 5.39 | % |  | — |  |  | — | % |
| Total | $ | 4,936 |  |  |  |  | $ | 1,733 |  |  |  |

- removed (2024-05-21):
[0000858877-24-000003:note_history:31]
Effective February 6, 2024, we increased our borrowing capacity under our existing commercial paper program from $10.0 billion to $15.0 billion. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. As of February 19, 2024, we had approximately $6.9 billion of commercial paper notes outstanding.

- removed (2024-05-21):
[0000858877-24-000003:note_history:32]
|  |  |  | January 27, 2024 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 6.35% |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.66% |  | 500 |  |  | 6.38% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 7,750 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (66) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (18) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 7,666 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 997 |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 6,669 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 7,666 |  |  |  |  | $ | 8,391 |  |  |  |


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-21):
[0000858877-24-000007:note_history:33]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 27, 2024 and July 29, 2023 (in millions):
  (was, 2024-02-20, similarity 0.9716):
[0000858877-24-000003:note_history:33]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 27, 2024 and July 29, 2023 (in millions):

- changed (2024-05-21):
[0000858877-24-000007:note_history:34]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,740 |  |  | $ | (25) |  |  | $ | 570 |  |  | $ | (24) |  |  | $ | 2,310 |  |  | $ | (49) |  |
| U.S. government agency securities | 175 |  |  | (1) |  |  | 65 |  |  | (2) |  |  | 240 |  |  | (3) |  |
| Non-U.S. government and agency securities | 239 |  |  | — |  |  | — |  |  | — |  |  | 239 |  |  | — |  |
| Corporate debt securities | 629 |  |  | (7) |  |  | 2,967 |  |  | (161) |  |  | 3,596 |  |  | (168) |  |
| U.S. agency mortgage-backed securities | 486 |  |  | (13) |  |  | 1,344 |  |  | (215) |  |  | 1,830 |  |  | (228) |  |
| Commercial paper | 91 |  |  | — |  |  | — |  |  | — |  |  | 91 |  |  | — |  |
| Total | $ | 3,360 |  |  | $ | (46) |  |  | $ | 4,946 |  |  | $ | (402) |  |  | $ | 8,306 |  |  | $ | (448) |  |
  (was, 2024-02-20, similarity 0.9906):
[0000858877-24-000003:note_history:34]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,145 |  |  | $ | (9) |  |  | $ | 550 |  |  | $ | (25) |  |  | $ | 1,695 |  |  | $ | (34) |  |
| U.S. government agency securities | 224 |  |  | — |  |  | 39 |  |  | (2) |  |  | 263 |  |  | (2) |  |
| Non-U.S. government and agency securities | 200 |  |  | — |  |  | — |  |  | — |  |  | 200 |  |  | — |  |
| Corporate debt securities | 557 |  |  | (2) |  |  | 3,527 |  |  | (178) |  |  | 4,084 |  |  | (180) |  |
| U.S. agency mortgage-backed securities | 415 |  |  | (6) |  |  | 1,320 |  |  | (191) |  |  | 1,735 |  |  | (197) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 2,551 |  |  | $ | (17) |  |  | $ | 5,436 |  |  | $ | (396) |  |  | $ | 7,987 |  |  | $ | (413) |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-21):
[0000858877-24-000007:note_history:35]
| April 27, 2024 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,411 |  |  | $ | — |  |  | $ | (49) |  |  | $ | 2,362 |  |
| U.S. government agency securities | 248 |  |  | — |  |  | (3) |  |  | 245 |  |
| Non-U.S. government and agency securities | 390 |  |  | — |  |  | — |  |  | 390 |  |
| Corporate debt securities | 3,985 |  |  | 1 |  |  | (198) |  |  | 3,788 |  |
| U.S. agency mortgage-backed securities | 2,058 |  |  | — |  |  | (228) |  |  | 1,830 |  |
| Commercial paper | 563 |  |  | — |  |  | — |  |  | 563 |  |
| Certificates of deposit | 229 |  |  | — |  |  | — |  |  | 229 |  |
| Total | $ | 9,884 |  |  | $ | 1 |  |  | $ | (478) |  |  | $ | 9,407 |  |
  (was, 2024-02-20, similarity 0.7594):
[0000858877-24-000003:note_history:35]
| January 27, 2024 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,428 |  |  | $ | 3 |  |  | $ | (34) |  |  | $ | 2,397 |  |
| U.S. government agency securities | 354 |  |  | — |  |  | (2) |  |  | 352 |  |
| Non-U.S. government and agency securities | 364 |  |  | — |  |  | — |  |  | 364 |  |
| Corporate debt securities | 5,343 |  |  | 7 |  |  | (210) |  |  | 5,140 |  |
| U.S. agency mortgage-backed securities | 2,127 |  |  | 1 |  |  | (197) |  |  | 1,931 |  |
| Commercial paper | 828 |  |  | — |  |  | — |  |  | 828 |  |
| Certificates of deposit | 518 |  |  | — |  |  | — |  |  | 518 |  |
| Total | $ | 11,962 |  |  | $ | 11 |  |  | $ | (443) |  |  | $ | 11,530 |  |

- changed (2024-05-21):
[0000858877-24-000007:note_history:36]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2024 |  | April 29, 2023 |  | April 27, 2024 |  | April 29, 2023 |
| Gross realized gains | $ | 2 |  |  | $ | 1 |  |  | $ | 7 |  |  | $ | 4 |  |
| Gross realized losses | (16) |  |  | (7) |  |  | (64) |  |  | (19) |  |
| Total | $ | (14) |  |  | $ | (6) |  |  | $ | (57) |  |  | $ | (15) |  |
  (was, 2024-02-20, similarity 0.8254):
[0000858877-24-000003:note_history:36]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2024 |  | January 28, 2023 |  | January 27, 2024 |  | January 28, 2023 |
| Gross realized gains | $ | 5 |  |  | $ | 3 |  |  | $ | 5 |  |  | $ | 3 |  |
| Gross realized losses | (28) |  |  | (6) |  |  | (48) |  |  | (12) |  |
| Total | $ | (23) |  |  | $ | (3) |  |  | $ | (43) |  |  | $ | (9) |  |

- changed (2024-05-21):
[0000858877-24-000007:note_history:37]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 27, 2024 and July 29, 2023 (in millions):
  (was, 2024-02-20, similarity 0.9716):
[0000858877-24-000003:note_history:37]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 27, 2024 and July 29, 2023 (in millions):

- changed (2024-05-21):
[0000858877-24-000007:note_history:38]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,740 |  |  | $ | (25) |  |  | $ | 570 |  |  | $ | (24) |  |  | $ | 2,310 |  |  | $ | (49) |  |
| U.S. government agency securities | 175 |  |  | (1) |  |  | 65 |  |  | (2) |  |  | 240 |  |  | (3) |  |
| Non-U.S. government and agency securities | 239 |  |  | — |  |  | — |  |  | — |  |  | 239 |  |  | — |  |
| Corporate debt securities | 629 |  |  | (7) |  |  | 2,967 |  |  | (161) |  |  | 3,596 |  |  | (168) |  |
| U.S. agency mortgage-backed securities | 486 |  |  | (13) |  |  | 1,344 |  |  | (215) |  |  | 1,830 |  |  | (228) |  |
| Commercial paper | 91 |  |  | — |  |  | — |  |  | — |  |  | 91 |  |  | — |  |
| Total | $ | 3,360 |  |  | $ | (46) |  |  | $ | 4,946 |  |  | $ | (402) |  |  | $ | 8,306 |  |  | $ | (448) |  |
  (was, 2024-02-20, similarity 0.9906):
[0000858877-24-000003:note_history:38]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 27, 2024 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,145 |  |  | $ | (9) |  |  | $ | 550 |  |  | $ | (25) |  |  | $ | 1,695 |  |  | $ | (34) |  |
| U.S. government agency securities | 224 |  |  | — |  |  | 39 |  |  | (2) |  |  | 263 |  |  | (2) |  |
| Non-U.S. government and agency securities | 200 |  |  | — |  |  | — |  |  | — |  |  | 200 |  |  | — |  |
| Corporate debt securities | 557 |  |  | (2) |  |  | 3,527 |  |  | (178) |  |  | 4,084 |  |  | (180) |  |
| U.S. agency mortgage-backed securities | 415 |  |  | (6) |  |  | 1,320 |  |  | (191) |  |  | 1,735 |  |  | (197) |  |
| Commercial paper | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 2,551 |  |  | $ | (17) |  |  | $ | 5,436 |  |  | $ | (396) |  |  | $ | 7,987 |  |  | $ | (413) |  |

- changed (2024-05-21):
[0000858877-24-000007:note_history:39]
The following table summarizes the maturities of our available-for-sale debt investments as of April 27, 2024 (in millions):
  (was, 2024-02-20, similarity 0.9667):
[0000858877-24-000003:note_history:39]
The following table summarizes the maturities of our available-for-sale debt investments as of January 27, 2024 (in millions):

- added (2024-05-21):
[0000858877-24-000007:note_history:40]
We held marketable equity securities of $450 million and $431 million as of April 27, 2024 and July 29, 2023, respectively. We recognized a net unrealized gain of $20 million and $40 million during the third quarter and first nine months of fiscal 2024, respectively, and a net unrealized loss of $2 million and $11 million during the corresponding periods of fiscal 2023, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $21 million and $155 million for the third quarter and first nine months of fiscal 2024, respectively, and a net gain of $7 million and a net loss of $2 million for the corresponding periods of fiscal 2023, respectively. We held equity interests in certain private equity funds of $0.8 billion and $0.9 billion as of April 27, 2024 and July 29, 2023, respectively, which are accounted for under the NAV practical expedient.

- changed (2024-05-21):
[0000858877-24-000007:note_history:41]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 27, 2024, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2024-02-20, similarity 0.9895):
[0000858877-24-000003:note_history:41]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 27, 2024, there were no additional significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- changed (2024-05-21):
[0000858877-24-000007:note_history:42]
The carrying value of our investments in privately held companies was $1.6 billion and $1.8 billion as of April 27, 2024 and July 29, 2023, respectively. Of the total carrying value of our investments in privately held companies as of April 27, 2024, $0.9 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of April 27, 2024, we have total funding commitments of $0.2 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.
  (was, 2024-02-20, similarity 0.9555):
[0000858877-24-000003:note_history:42]
The carrying value of our investments in privately held companies was $1.6 billion and $1.8 billion as of January 27, 2024 and July 29, 2023, respectively. Of the total carrying value of our investments in privately held companies as of January 27, 2024, $0.9 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of January 27, 2024, we have total funding commitments of $0.2 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.

- removed (2024-05-21):
[0000858877-24-000003:note_history:43]
We held marketable equity securities of $426 million and $431 million as of January 27, 2024 and July 29, 2023, respectively. We recognized a net unrealized gain of $55 million and $17 million during the second quarter and first six months of fiscal 2024, respectively, and a net unrealized gain of $11 million and a net unrealized loss of $9 million during the corresponding periods of fiscal 2023, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $134 million for the second quarter and first six months of fiscal 2024, and a net gain of $3 million and a net loss of $8 million for the corresponding periods of fiscal 2023, respectively. We held equity interests in certain private equity funds of $0.8 billion and $0.9 billion as of January 27, 2024 and July 29, 2023, respectively, which are accounted for under the NAV practical expedient.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-05-21):
[0000858877-24-000007:note_history:44]
|  |  |  | April 27, 2024 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | — |  |  | — |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.64% |  | 500 |  |  | 6.38% |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | 5.00% |  | — |  |  | — |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | — |  |  | — |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | — |  |  | — |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | — |  |  | — |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | — |  |  | — |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | — |  |  | — |
| Other long-term debt |  |  | 3 |  |  | 1.13% |  | — |  |  | — |
| Total |  |  | 20,253 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (135) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (16) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 20,102 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | — |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 20,102 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 20,102 |  |  |  |  | $ | 8,391 |  |  |  |

- removed (2024-05-21):
[0000858877-24-000003:note_history:45]
|  |  |  | January 27, 2024 |  | July 29, 2023 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | — |  | $ | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 6.35% |  | 1,000 |  |  | 6.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.66% |  | 500 |  |  | 6.38% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 7,750 |  |  |  |  | 8,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (66) |  |  |  |  | (68) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (18) |  |  |  |  | (41) |  |  |  |
| Total |  |  | $ | 7,666 |  |  |  |  | $ | 8,391 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 997 |  |  |  |  | $ | 1,733 |  |  |  |
| Long-term debt |  |  | 6,669 |  |  |  |  | 6,658 |  |  |  |
| Total |  |  | $ | 7,666 |  |  |  |  | $ | 8,391 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-21):
[0000858877-24-000007:note_history:46]
As of April 27, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2024-02-20, similarity 0.9701):
[0000858877-24-000003:note_history:46]
As of January 27, 2024, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2024-05-21):
[0000858877-24-000007:note_history:47]
| Fiscal Year | Amount |
| 2024 (remaining three months) | $ | — |  |
| 2025 | 500 |  |
| 2026 | 1,751 |  |
| 2027 | 3,502 |  |
| 2028 | — |  |
| Thereafter | 14,500 |  |
| Total | $ | 20,253 |  |
  (was, 2024-02-20, similarity 0.9252):
[0000858877-24-000003:note_history:47]
| Fiscal Year | Amount |
| 2024 (remaining six months) | $ | 1,000 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 7,750 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-05-21):
[0000858877-24-000007:note_history:48]
|  | April 27, 2024 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | — |  |  | — |  |  | $ | 1,733 |  |  | 4.45 | % |
| Commercial paper | 11,891 |  |  | 5.42 | % |  | — |  |  | — |  |
| Total | $ | 11,891 |  |  |  |  | $ | 1,733 |  |  |  |

- removed (2024-05-21):
[0000858877-24-000003:note_history:49]
|  | January 27, 2024 |  | July 29, 2023 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 997 |  |  | 6.35 | % |  | $ | 1,733 |  |  | 4.45 | % |
| Commercial paper | 3,939 |  |  | 5.39 | % |  | — |  |  | — | % |
| Total | $ | 4,936 |  |  |  |  | $ | 1,733 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-21):
[0000858877-24-000007:note_history:50]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 6,522 |  |  | $ | 8,982 |  |  | $ | 22,425 |  |  | $ | 25,105 |  |
| Security | 1,304 |  |  | 958 |  |  | 3,288 |  |  | 2,872 |  |
| Collaboration | 987 |  |  | 985 |  |  | 3,093 |  |  | 3,029 |  |
| Observability | 211 |  |  | 167 |  |  | 589 |  |  | 486 |  |
| Total Product | 9,024 |  |  | 11,092 |  |  | 29,395 |  |  | 31,492 |  |
| Services | 3,678 |  |  | 3,479 |  |  | 10,766 |  |  | 10,303 |  |
| Total | $ | 12,702 |  |  | $ | 14,571 |  |  | $ | 40,161 |  |  | $ | 41,795 |  |
  (was, 2024-02-20, similarity 0.8775):
[0000858877-24-000003:note_history:50]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,081 |  |  | $ | 8,092 |  |  | $ | 15,904 |  |  | $ | 16,123 |  |
| Security | 973 |  |  | 943 |  |  | 1,984 |  |  | 1,914 |  |
| Collaboration | 989 |  |  | 958 |  |  | 2,106 |  |  | 2,044 |  |
| Observability | 188 |  |  | 162 |  |  | 378 |  |  | 319 |  |
| Total Product | 9,232 |  |  | 10,155 |  |  | 20,371 |  |  | 20,400 |  |
| Services | 3,559 |  |  | 3,437 |  |  | 7,088 |  |  | 6,824 |  |
| Total | $ | 12,791 |  |  | $ | 13,592 |  |  | $ | 27,459 |  |  | $ | 27,224 |  |

- changed (2024-05-21):
[0000858877-24-000007:note_history:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Revenue: |  |  |  |  |  |  |  |
| Networking | $ | 6,522 |  |  | $ | 8,982 |  |  | $ | 22,425 |  |  | $ | 25,105 |  |
| Security | 1,304 |  |  | 958 |  |  | 3,288 |  |  | 2,872 |  |
| Collaboration | 987 |  |  | 985 |  |  | 3,093 |  |  | 3,029 |  |
| Observability | 211 |  |  | 167 |  |  | 589 |  |  | 486 |  |
| Total Product | 9,024 |  |  | 11,092 |  |  | 29,395 |  |  | 31,492 |  |
| Services | 3,678 |  |  | 3,479 |  |  | 10,766 |  |  | 10,303 |  |
| Total | $ | 12,702 |  |  | $ | 14,571 |  |  | $ | 40,161 |  |  | $ | 41,795 |  |
  (was, 2024-02-20, similarity 0.8448):
[0000858877-24-000003:note_history:51]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,081 |  |  | $ | 8,092 |  |  | $ | 15,904 |  |  | $ | 16,123 |  |
| Security | 973 |  |  | 943 |  |  | 1,984 |  |  | 1,914 |  |
| Collaboration | 989 |  |  | 958 |  |  | 2,106 |  |  | 2,044 |  |
| Observability | 188 |  |  | 162 |  |  | 378 |  |  | 319 |  |
| Total Product | 9,232 |  |  | 10,155 |  |  | 20,371 |  |  | 20,400 |  |
| Services | 3,559 |  |  | 3,437 |  |  | 7,088 |  |  | 6,824 |  |
| Total | $ | 12,791 |  |  | $ | 13,592 |  |  | 27,459 |  |  | 27,224 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-21):
[0000858877-24-000007:note_history:52]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 27, 2024 and July 29, 2023 was $35 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2024-02-20, similarity 0.9793):
[0000858877-24-000003:note_history:52]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 27, 2024 and July 29, 2023 was $36 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2024-05-21):
[0000858877-24-000007:note_history:53]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.
  (was, 2024-02-20, similarity 0.9919):
[0000858877-24-000003:note_history:53]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for all of our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-21):
[0000858877-24-000007:note_history:54]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 27, 2024 and July 29, 2023 was $35 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2024-02-20, similarity 0.9793):
[0000858877-24-000003:note_history:54]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 27, 2024 and July 29, 2023 was $36 million and $39 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2024-05-21):
[0000858877-24-000007:note_history:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27,2024 |  | April 29,2023 |  | April 27,2024 |  | April 29,2023 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 6,522 |  |  | $ | 8,982 |  |  | $ | 22,425 |  |  | $ | 25,105 |  |
| Security | 1,304 |  |  | 958 |  |  | 3,288 |  |  | 2,872 |  |
| Collaboration | 987 |  |  | 985 |  |  | 3,093 |  |  | 3,029 |  |
| Observability | 211 |  |  | 167 |  |  | 589 |  |  | 486 |  |
| Total Product | 9,024 |  |  | 11,092 |  |  | 29,395 |  |  | 31,492 |  |
| Services | 3,678 |  |  | 3,479 |  |  | 10,766 |  |  | 10,303 |  |
| Total | $ | 12,702 |  |  | $ | 14,571 |  |  | $ | 40,161 |  |  | $ | 41,795 |  |
  (was, 2024-02-20, similarity 0.8628):
[0000858877-24-000003:note_history:55]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27,2024 |  | January 28,2023 |  | January 27,2024 |  | January 28,2023 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 7,081 |  |  | $ | 8,092 |  |  | $ | 15,904 |  |  | $ | 16,123 |  |
| Security | 973 |  |  | 943 |  |  | 1,984 |  |  | 1,914 |  |
| Collaboration | 989 |  |  | 958 |  |  | 2,106 |  |  | 2,044 |  |
| Observability | 188 |  |  | 162 |  |  | 378 |  |  | 319 |  |
| Total Product | 9,232 |  |  | 10,155 |  |  | 20,371 |  |  | 20,400 |  |
| Services | 3,559 |  |  | 3,437 |  |  | 7,088 |  |  | 6,824 |  |
| Total | $ | 12,791 |  |  | $ | 13,592 |  |  | 27,459 |  |  | 27,224 |  |

- added (2024-05-21):
[0000858877-24-000007:note_history:56]
Security consists of our Cloud and Application Security, Industrial Security, Network Security, and User and Device Security offerings. This product category includes the Splunk Platform and Splunk Security offerings after our acquisition of Splunk, although the Splunk Platform has use cases that can also be applicable for observability offerings. See Note 4. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2024-05-21):
[0000858877-24-000007:note_history:57]
Observability consists of our full stack observability offerings. This product category includes the Splunk Observability Suite after our acquisition of Splunk. This product category excludes the Splunk Platform which includes use cases that can also be associated with observability offerings. See Note 4. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- changed (2024-05-21):
[0000858877-24-000007:note_history:58]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.
  (was, 2024-02-20, similarity 0.9919):
[0000858877-24-000003:note_history:58]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for all of our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.

- changed (2024-05-21):
[0000858877-24-000007:note_history:59]
Accounts receivable, net was $5.1 billion as of April 27, 2024 compared to $5.9 billion as of July 29, 2023, as reported on the Consolidated Balance Sheets.
  (was, 2024-02-20, similarity 0.9718):
[0000858877-24-000003:note_history:59]
Accounts receivable, net was $4.9 billion as of January 27, 2024 compared to $5.9 billion as of July 29, 2023, as reported on the Consolidated Balance Sheets.

- added (2024-05-21):
[0000858877-24-000007:note_history:60]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2024 |  | April 29, 2023 |  | April 27, 2024 |  | April 29, 2023 |
| Allowance for credit loss at beginning of period | $ | 79 |  |  | $ | 86 |  |  | $ | 85 |  |  | $ | 83 |  |
| Provisions | 10 |  |  | 9 |  |  | 21 |  |  | 23 |  |
| Recoveries (write-offs), net | (8) |  |  | (12) |  |  | (25) |  |  | (23) |  |
| Allowance for credit loss at end of period | $ | 81 |  |  | $ | 83 |  |  | $ | 81 |  |  | $ | 83 |  |

- changed (2024-05-21):
[0000858877-24-000007:note_history:61]
|  | April 27,2024 |  | July 29,2023 |
| 1 to 4 | $ | 1,176 |  |  | $ | 672 |  |
| 5 to 6 | 1,383 |  |  | 954 |  |
| 7 and Higher | 70 |  |  | 60 |  |
| Total | $ | 2,629 |  |  | $ | 1,686 |  |
  (was, 2024-02-20, similarity 0.9726):
[0000858877-24-000003:note_history:61]
|  | January 27,2024 |  | July 29,2023 |
| 1 to 4 | $ | 693 |  |  | $ | 672 |  |
| 5 to 6 | 1,042 |  |  | 954 |  |
| 7 and Higher | 62 |  |  | 60 |  |
| Total | $ | 1,797 |  |  | $ | 1,686 |  |

- changed (2024-05-21):
[0000858877-24-000007:note_history:62]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $2.6 billion as of April 27, 2024 and $1.6 billion as of July 29, 2023, and were included in other current assets and other assets.
  (was, 2024-02-20, similarity 0.9874):
[0000858877-24-000003:note_history:62]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $1.8 billion as of January 27, 2024 and $1.6 billion as of July 29, 2023, and were included in other current assets and other assets.

- changed (2024-05-21):
[0000858877-24-000007:note_history:63]
Contract liabilities consist of deferred revenue. Deferred revenue was $27.5 billion as of April 27, 2024 compared to $25.6 billion as of July 29, 2023. We recognized approximately $3.0 billion and $11.5 billion of revenue during the third quarter and first nine months of fiscal 2024 that was included in the deferred revenue balance at July 29, 2023.
  (was, 2024-02-20, similarity 0.7826):
[0000858877-24-000003:note_history:63]
Contract liabilities consist of deferred revenue. Deferred revenue was $25.8 billion as of January 27, 2024 compared to $25.6 billion as of July 29, 2023. We recognized approximately $3.8 billion and $8.4 billion of revenue during the second quarter and first six months of fiscal 2024 that was included in the deferred revenue balance at July 29, 2023.

- changed (2024-05-21):
[0000858877-24-000007:note_history:64]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Capitalized contract acquisition costs were $1.3 billion and $1.1 billion as of April 27, 2024 and July 29, 2023, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $201 million and $525 million for the third quarter and first nine months fiscal 2024, respectively, and $172 million and $549 million for the corresponding periods of fiscal 2023, respectively, and was included in sales and marketing expenses.
  (was, 2024-02-20, similarity 0.9845):
[0000858877-24-000003:note_history:64]
(c)Capitalized Contract Acquisition Costs
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Capitalized contract acquisition costs were $1.2 billion and $1.1 billion as of January 27, 2024 and July 29, 2023, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $166 million and $324 million for the second quarter and first six months fiscal 2024, respectively, and $201 million and $377 million for the corresponding periods of fiscal 2023, respectively, and was included in sales and marketing expenses.

- removed (2024-05-21):
[0000858877-24-000003:note_history:65]
Security consists of our Cloud and Application Security, Industrial Security, Network Security, and User and Device Security offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2024-05-21):
[0000858877-24-000003:note_history:66]
Observability consists of our full stack observability offerings. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2024-05-21):
[0000858877-24-000003:note_history:67]
|  | Three Months Ended |  | Six Months Ended |
|  | January 27, 2024 |  | January 28, 2023 |  | January 27, 2024 |  | January 28, 2023 |
| Allowance for credit loss at beginning of period | $ | 82 |  |  | $ | 88 |  |  | $ | 85 |  |  | $ | 83 |  |
| Provisions (benefits) | 9 |  |  | 3 |  |  | 11 |  |  | 14 |  |
| Recoveries (write-offs), net | (12) |  |  | (5) |  |  | (17) |  |  | (11) |  |
| Allowance for credit loss at end of period | $ | 79 |  |  | $ | 86 |  |  | $ | 79 |  |  | $ | 86 |  |
