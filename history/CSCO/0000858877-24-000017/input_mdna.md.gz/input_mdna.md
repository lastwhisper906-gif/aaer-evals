# CSCO MD&A — 0000858877-24-000017


## mdna

[0000858877-24-000017:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000858877-24-000017:mdna:2]
Forward-Looking Statements

[0000858877-24-000017:mdna:3]
OVERVIEW

[0000858877-24-000017:mdna:4]
Cisco designs and sells a broad range of technologies that help to power, secure, and draw insights from the Internet. We are integrating artificial intelligence (AI) into our product portfolios across networking, security, collaboration and observability to simplify how our technology is delivered, managed and optimized and to help customers maximize the business value of their technology investments and accelerate their digital transformation.

[0000858877-24-000017:mdna:5]
A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-24-000017:mdna:6]
|  | Three Months Ended |  | Years Ended |  |
|  | July 27, 2024 |  | July 29, 2023 |  | Variance |  | July 27, 2024 |  | July 29, 2023 |  | Variance |  |
| Revenue | $ | 13,642 |  |  | $ | 15,203 |  |  | (10) | % |  | $ | 53,803 |  |  | $ | 56,998 |  |  | (6) | % |  |
| Gross margin percentage | 64.4 | % |  | 64.1 | % |  | 0.3 |  | pts | 64.7 | % |  | 62.7 | % |  | 2.0 |  | pts |
| Research and development | $ | 2,179 |  |  | $ | 1,953 |  |  | 12 | % |  | $ | 7,983 |  |  | $ | 7,551 |  |  | 6 | % |  |
| Sales and marketing | $ | 2,841 |  |  | $ | 2,579 |  |  | 10 | % |  | $ | 10,364 |  |  | $ | 9,880 |  |  | 5 | % |  |
| General and administrative | $ | 763 |  |  | $ | 690 |  |  | 11 | % |  | $ | 2,813 |  |  | $ | 2,478 |  |  | 14 | % |  |
| Total R&D, sales and marketing, general and administrative | $ | 5,783 |  |  | $ | 5,222 |  |  | 11 | % |  | $ | 21,160 |  |  | $ | 19,909 |  |  | 6 | % |  |
| Total as a percentage of revenue | 42.4 | % |  | 34.3 | % |  | 8.1 |  | pts | 39.3 | % |  | 34.9 | % |  | 4.4 |  | pts |
| Restructuring and other charges included in operating expenses | $ | 112 |  |  | $ | 203 |  |  | (45) | % |  | $ | 789 |  |  | $ | 531 |  |  | 49 | % |  |
| Operating income as a percentage of revenue | 19.2 | % |  | 28.0 | % |  | (8.8) |  | pts | 22.6 | % |  | 26.4 | % |  | (3.8) |  | pts |
| Interest and other income (loss), net | $ | (222) |  |  | $ | 218 |  |  | NM |  | $ | 53 |  |  | $ | 287 |  |  | (82) | % |  |
| Income tax percentage | 9.8 | % |  | 11.5 | % |  | (1.7) |  | pts | 15.6 | % |  | 17.7 | % |  | (2.1) |  | pts |
| Net income | $ | 2,162 |  |  | $ | 3,958 |  |  | (45) | % |  | $ | 10,320 |  |  | $ | 12,613 |  |  | (18) | % |  |
| Net income as a percentage of revenue | 15.8 | % |  | 26.0 | % |  | (10.2) |  | pts | 19.2 | % |  | 22.1 | % |  | (2.9) |  | pts |
| Earnings per share—diluted | $ | 0.54 |  |  | $ | 0.97 |  |  | (44) | % |  | $ | 2.54 |  |  | $ | 3.07 |  |  | (17) | % |  |

[0000858877-24-000017:mdna:7]
Percentages may not recalculate due to rounding.

[0000858877-24-000017:mdna:8]
NM — Not meaningful

[0000858877-24-000017:mdna:9]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:10]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:11]
Fiscal 2024 Compared with Fiscal 2023

[0000858877-24-000017:mdna:12]
In fiscal 2024, total revenue decreased by 6% compared with fiscal 2023. In March 2024, we completed the acquisition of Splunk Inc. (“Splunk”), which contributed approximately $1.4 billion in total revenue for fiscal 2024. Within total revenue, product revenue decreased by 9% and services revenue increased by 5%. In fiscal 2024, total software revenue was $18.4 billion across all product areas and services, an increase of 9%, driven by the contribution of Splunk. Total subscription revenue increased 11%, partially driven by the contribution of Splunk.

[0000858877-24-000017:mdna:13]
During the first nine months of fiscal 2024, we experienced a decline in product demand as customers continued to scrutinize spend as they needed additional time to implement elevated levels of product shipments received in prior quarters. In the fourth quarter of fiscal 2024 we saw improvement in product demand across all geographic segments and customer markets as customers largely completed the installation of their product shipments. While we continue to operate in a highly competitive environment and the overall macroeconomic environment remains challenging and uncertain, we plan to continue to invest in key priority areas with the objective of driving profitable growth over the long term.

[0000858877-24-000017:mdna:14]
Total gross margin increased by 2.0 percentage points. Product gross margin increased by 2.0 percentage points, largely driven by favorable product mix, productivity benefits and benefits from Splunk, partially offset by negative impacts from pricing. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 4.4 percentage points. Operating income as a percentage of revenue decreased by 3.8 percentage points driven primarily by incremental operating expenses from Splunk, higher restructuring and other charges and higher amortization of purchased intangible assets in fiscal 2024. Diluted earnings per share decreased by 17%, driven by a decrease of 18% in net income partially offset by a decrease in diluted share count of 43 million shares.

[0000858877-24-000017:mdna:15]
In terms of our geographic segments, revenue from the Americas decreased by $1.5 billion, EMEA revenue decreased by $1.0 billion and revenue in our APJC segment decreased by $0.7 billion. We experienced a product revenue decline in the enterprise and service provider and cloud markets. Product revenue in the public sector market was flat. From a product category perspective, total product revenue decreased 9% year over year, driven by a decline in revenue in Networking of 15%, partially offset by growth in Security of 32% and Observability of 27%, each driven in large part by the contribution of Splunk. Product revenue grew in Collaboration by 2%.

[0000858877-24-000017:mdna:16]
We remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformations and on accelerating innovation across our portfolio. We believe that we are making progress on our strategic priorities.

[0000858877-24-000017:mdna:17]
32

[0000858877-24-000017:mdna:18]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:19]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:20]
Fourth Quarter Snapshot

[0000858877-24-000017:mdna:21]
For the fourth quarter of fiscal 2024, as compared with the fourth quarter of fiscal 2023, total revenue decreased by 10%. Within total revenue, product revenue decreased by 15% and services revenue increased by 6%. With regard to our geographic segment performance, on a year-over-year basis, revenue in Americas decreased by 11%, EMEA decreased by 11% and APJC decreased by 6%. From a product category perspective, we experienced a product revenue decline in Networking, partially offset by growth in Security and Observability, driven in large part by the contribution of Splunk. Product revenue in Collaboration was flat. Total gross margin increased by 0.3 percentage points, driven by favorable product mix and the contribution from Splunk, partially offset by negative impacts from pricing. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 8.1 percentage points. Operating income as a percentage of revenue decreased by 8.8 percentage points primarily driven by incremental operating expenses from Splunk and higher amortization of purchased intangible assets. Diluted earnings per share decreased by 44%, driven by a decrease in net income of 45%, partially offset by a decrease in diluted share count of 58 million shares.

[0000858877-24-000017:mdna:22]
Strategy and Priorities

[0000858877-24-000017:mdna:23]
Across the globe, businesses and organizations of every size are leveraging Cisco technology to transform and drive better outcomes and experiences. We also help customers navigate emerging technological shifts. Our strategy is to securely connect everything to make those desired outcomes and experiences possible for our customers.

[0000858877-24-000017:mdna:24]
For a full discussion of our strategy and priorities, see “Item 1. Business.”

[0000858877-24-000017:mdna:25]
Other Key Financial Measures

[0000858877-24-000017:mdna:26]
The following is a summary of our other key financial measures for fiscal 2024 compared with fiscal 2023 (in millions):

[0000858877-24-000017:mdna:27]
|  |  | Fiscal 2024 |  | Fiscal 2023 |
| Cash and cash equivalents and investments |  | $17,854 |  | $26,146 |
| Cash provided by operating activities |  | $10,880 |  | $19,886 |
| Remaining performance obligations |  | $41,048 |  | $34,868 |
| Repurchases of common stock—stock repurchase program |  | $5,764 |  | $4,271 |
| Dividends paid |  | $6,384 |  | $6,302 |
| Inventories |  | $3,373 |  | $3,644 |
| Total debt |  | $30,962 |  | $8,391 |

[0000858877-24-000017:mdna:28]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:29]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:30]
CRITICAL ACCOUNTING ESTIMATES

[0000858877-24-000017:mdna:31]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-24-000017:mdna:32]
Revenue Recognition

[0000858877-24-000017:mdna:33]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis.

[0000858877-24-000017:mdna:34]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-24-000017:mdna:35]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-24-000017:mdna:36]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable. If actual credits received by distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-24-000017:mdna:37]
See Note 3 to the Consolidated Financial Statements for more details.

[0000858877-24-000017:mdna:38]
Inventory Valuation and Liability for Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-24-000017:mdna:39]
Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and net realizable value, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At

[0000858877-24-000017:mdna:40]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:41]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:42]
the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-24-000017:mdna:43]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.

[0000858877-24-000017:mdna:44]
Our provision for inventory was $576 million, $307 million, and $102 million in fiscal 2024, 2023, and 2022, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $243 million, $423 million, and $227 million in fiscal 2024, 2023, and 2022, respectively. If there were to be a sudden and significant decrease in demand for our products, if there were a higher incidence of inventory obsolescence because of rapidly changing technology or customer requirements, or if supply constraints were to continue, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs, and the adequacy of our liability for purchase commitments. For further discussion around the supply chain impacts and risks, see “—Results of Operations—Gross Margin—Supply Chain Impacts and Risks” and “—Liquidity and Capital Resources—Inventory Supply Chain” under Item 7 of this report.

[0000858877-24-000017:mdna:45]
Loss Contingencies

[0000858877-24-000017:mdna:46]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-24-000017:mdna:47]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-24-000017:mdna:48]
Valuation of Goodwill and Purchased Intangible Assets

[0000858877-24-000017:mdna:49]
Goodwill

[0000858877-24-000017:mdna:50]
Our methodology for allocating the purchase price relating to purchase acquisitions is determined through established valuation techniques. Goodwill represents a residual value as of the acquisition date, which in most cases results in measuring goodwill as an excess of the purchase consideration transferred plus the fair value of any noncontrolling interest in the acquired company over the fair value of net assets acquired, including contingent consideration. We perform goodwill impairment tests on an annual basis in the fourth fiscal quarter and between annual tests in certain circumstances for each reporting unit. The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the guidance for the fair value measurement of nonfinancial assets.

[0000858877-24-000017:mdna:51]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in fiscal 2024, 2023, and 2022. For the annual impairment testing in fiscal 2024, the excess of the fair value over the carrying value for each of our reporting units was $47.0 billion for the Americas, $65.9 billion for EMEA, and $25.3 billion for APJC.

[0000858877-24-000017:mdna:52]
During the fourth quarter of fiscal 2024, we performed a sensitivity analysis for goodwill impairment with respect to each of our respective reporting units and determined that a hypothetical 10% decline in the fair value of each reporting unit would not result in an impairment of goodwill for any reporting unit.

[0000858877-24-000017:mdna:53]
Purchased Intangible Assets

[0000858877-24-000017:mdna:54]
The accounting for acquisitions requires significant estimates and judgments in the valuation of purchased intangible assets. Critical estimates used in the valuation of purchased intangible assets include, but are not limited to, the amount and timing of expected future cash flows, useful lives and discount rates. While our estimates of fair value are based on assumptions that are

[0000858877-24-000017:mdna:55]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:56]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:57]
believed to be reasonable, these assumptions are inherently uncertain and unpredictable and would not reflect unanticipated events and circumstances that may occur.

[0000858877-24-000017:mdna:58]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset group to the future undiscounted cash flows the asset group is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. Our ongoing consideration of all the factors described previously could result in impairment charges in the future, which could adversely affect our net income.

[0000858877-24-000017:mdna:59]
Income Taxes

[0000858877-24-000017:mdna:60]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was 15.6%, 17.7%, and 18.4% in fiscal 2024, 2023, and 2022, respectively.

[0000858877-24-000017:mdna:61]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.

[0000858877-24-000017:mdna:62]
Significant judgment is also required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. If we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000858877-24-000017:mdna:63]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to foreign-derived intangible income deduction, global intangible low-tax income and base erosion and anti-abuse tax, research and development capitalization and amortization, and corporate alternative minimum tax laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The OECD, an international association comprised of 38 countries, including the United States, has made changes, including a Pillar Two framework that imposes a minimum tax rate of 15% in each taxing jurisdiction, and is contemplating additional changes to numerous long-standing tax principles. There can be no assurance that these changes and any contemplated changes if finalized, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries was subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the IRS and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-24-000017:mdna:64]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:65]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:66]
RESULTS OF OPERATIONS

[0000858877-24-000017:mdna:67]
A discussion regarding our financial condition and results of operations for fiscal 2024 compared to fiscal 2023 is presented below. A discussion regarding our financial condition and results of operations for fiscal 2023 compared to fiscal 2022, with the exception of Product Revenue by Category, which is discussed herein, can be found under Item 7 in our Annual Report on Form 10-K for the fiscal year ended July 29, 2023, filed with the SEC on September 7, 2023.

[0000858877-24-000017:mdna:68]
Revenue

[0000858877-24-000017:mdna:69]
The following table presents the breakdown of revenue between product and services (in millions, except percentages):

[0000858877-24-000017:mdna:70]
|  |  | Years Ended |  | 2024 vs. 2023 |
|  |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 39,253 |  |  | $ | 43,142 |  |  | $ | 38,018 |  |  | $ | (3,889) |  |  | (9) | % |
| Percentage of revenue |  | 73.0 | % |  | 75.7 | % |  | 73.7 | % |  |  |  |  |
| Services |  | 14,550 |  |  | 13,856 |  |  | 13,539 |  |  | 694 |  |  | 5 | % |
| Percentage of revenue |  | 27.0 | % |  | 24.3 | % |  | 26.3 | % |  |  |  |  |
| Total |  | $ | 53,803 |  |  | $ | 56,998 |  |  | $ | 51,557 |  |  | $ | (3,195) |  |  | (6) | % |

[0000858877-24-000017:mdna:71]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-24-000017:mdna:72]
Total revenue for fiscal 2024 includes approximately $1.4 billion relating to the acquisition of Splunk, which consisted of approximately $1.1 billion in product revenue and approximately $240 million in services revenue.

[0000858877-24-000017:mdna:73]
We manage our business primarily on a geographic basis, organized into three geographic segments. Our revenue, which includes product and services for each segment, is summarized in the following table (in millions, except percentages):

[0000858877-24-000017:mdna:74]
|  |  | Years Ended |  | 2024 vs. 2023 |
|  |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 31,971 |  |  | $ | 33,447 |  |  | $ | 29,814 |  |  | $ | (1,476) |  |  | (4) | % |
| Percentage of revenue |  | 59.4 | % |  | 58.7 | % |  | 57.8 | % |  |  |  |  |
| EMEA |  | 14,117 |  |  | 15,135 |  |  | 13,715 |  |  | (1,018) |  |  | (7) | % |
| Percentage of revenue |  | 26.2 | % |  | 26.6 | % |  | 26.6 | % |  |  |  |  |
| APJC |  | 7,716 |  |  | 8,417 |  |  | 8,027 |  |  | (701) |  |  | (8) | % |
| Percentage of revenue |  | 14.3 | % |  | 14.8 | % |  | 15.6 | % |  |  |  |  |
| Total |  | $ | 53,803 |  |  | $ | 56,998 |  |  | $ | 51,557 |  |  | $ | (3,195) |  |  | (6) | % |

[0000858877-24-000017:mdna:75]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-24-000017:mdna:76]
Total revenue in fiscal 2024 decreased by 6% compared with fiscal 2023. Product revenue decreased by 9% and services revenue increased by 5%. Our total revenue reflected declines across each of our geographic segments.

[0000858877-24-000017:mdna:77]
In addition to the impact of macroeconomic factors, including the IT spending environment and the level of spending by government entities, revenue by segment in a particular period may be significantly impacted by the timing of revenue recognition for complex transactions with multiple performance obligations. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment.

[0000858877-24-000017:mdna:78]
37

[0000858877-24-000017:mdna:79]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:80]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:81]
Product Revenue by Segment

[0000858877-24-000017:mdna:82]
The following table presents the breakdown of product revenue by segment (in millions, except percentages):

[0000858877-24-000017:mdna:83]
|  |  | Years Ended |  | 2024 vs. 2023 |
|  |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 23,142 |  |  | $ | 25,019 |  |  | $ | 21,620 |  |  | $ | (1,877) |  |  | (8) | % |
| Percentage of product revenue |  | 59.0 | % |  | 58.0 | % |  | 56.9 | % |  |  |  |  |
| EMEA |  | 10,645 |  |  | 11,866 |  |  | 10,545 |  |  | (1,221) |  |  | (10) | % |
| Percentage of product revenue |  | 27.1 | % |  | 27.5 | % |  | 27.7 | % |  |  |  |  |
| APJC |  | 5,466 |  |  | 6,257 |  |  | 5,854 |  |  | (791) |  |  | (13) | % |
| Percentage of product revenue |  | 13.9 | % |  | 14.5 | % |  | 15.4 | % |  |  |  |  |
| Total |  | $ | 39,253 |  |  | $ | 43,142 |  |  | $ | 38,018 |  |  | $ | (3,889) |  |  | (9) | % |

[0000858877-24-000017:mdna:84]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-24-000017:mdna:85]
Americas

[0000858877-24-000017:mdna:86]
Product revenue in the Americas segment decreased by 8%. The product revenue decrease was driven by declines in the enterprise and service provider and cloud markets, partially offset by growth in the public sector market. The acquisition of Splunk contributed $784 million of product revenue to the Americas segment in fiscal 2024. From a country perspective, product revenue decreased by 7% in the United States, 11% in Canada, 10% in Mexico and 11% in Brazil.

[0000858877-24-000017:mdna:87]
EMEA

[0000858877-24-000017:mdna:88]
The decrease in product revenue in the EMEA segment of 10% was driven by declines across each of our customer markets. The acquisition of Splunk contributed $228 million of product revenue to the EMEA segment for fiscal 2024. From a country perspective, product revenue decreased by 10% in the United Kingdom, 14% in Germany and 11% in France.

[0000858877-24-000017:mdna:89]
APJC

[0000858877-24-000017:mdna:90]
Product revenue in the APJC segment decreased by 13%, driven by declines across each of our customer markets. The acquisition of Splunk contributed $122 million of product revenue to the APJC segment in fiscal 2024. From a country perspective, product revenue decreased by 8% in Japan, 5% in Australia, 17% in India and 35% in China.

[0000858877-24-000017:mdna:91]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:92]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:93]
Product Revenue by Category

[0000858877-24-000017:mdna:94]
In addition to the primary view on a geographic basis, we also prepare financial information related to product categories and customer markets for various purposes. Effective fiscal 2024, we began reporting our product revenue in the following categories: Networking, Security, Collaboration, and Observability and conformed our product revenue for prior periods to the current year presentation.

[0000858877-24-000017:mdna:95]
The following table presents product revenue by category (in millions, except percentages):

[0000858877-24-000017:mdna:96]
|  |  | Years Ended |  | 2024 vs. 2023 |  | 2023 vs. 2022 |
|  |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking |  | $ | 29,229 |  |  | $ | 34,570 |  |  | $ | 29,265 |  |  | $ | (5,341) |  |  | (15) | % |  | $ | 5,305 |  |  | 18 | % |
| Security |  | 5,075 |  |  | 3,859 |  |  | 3,699 |  |  | 1,216 |  |  | 32 | % |  | 160 |  |  | 4 | % |
| Collaboration |  | 4,113 |  |  | 4,052 |  |  | 4,472 |  |  | 61 |  |  | 2 | % |  | (420) |  |  | (9) | % |
| Observability |  | 837 |  |  | 661 |  |  | 581 |  |  | 176 |  |  | 27 | % |  | 80 |  |  | 14 | % |
| Total |  | $ | 39,253 |  |  | $ | 43,142 |  |  | $ | 38,018 |  |  | $ | (3,889) |  |  | (9) | % |  | $ | 5,124 |  |  | 13 | % |

[0000858877-24-000017:mdna:97]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-24-000017:mdna:98]
Networking

[0000858877-24-000017:mdna:99]
Fiscal 2024 Compared with Fiscal 2023

[0000858877-24-000017:mdna:100]
The Networking product category consists of our core networking technologies of switching, routing, wireless, and servers. Revenue from the Networking product category decreased by 15%, or $5.3 billion. During fiscal 2024, we saw customers scrutinizing spend and needing additional time to implement elevated levels of product shipments received in prior quarters. Revenue declined in both campus switching and data center switching, primarily driven by declines in our Catalyst 9000 series and Nexus 9000 series offerings. We experienced a revenue decline in enterprise routing, although we saw revenue growth in our SD-WAN offerings. The decrease in wireless was primarily driven by our WiFi-6 products and Meraki offerings. We also saw a revenue decline in routed optical networking.

[0000858877-24-000017:mdna:101]
Fiscal 2023 Compared with Fiscal 2022

[0000858877-24-000017:mdna:102]
Revenue from the Networking product category increased by 18%, or $5.3 billion. Revenue grew in both campus switching and data center switching. This was primarily driven by strong growth in our Catalyst 9000 series, Nexus 9000 series and Meraki switching offerings. The increase in enterprise routing was primarily driven by growth in Catalyst 8000 routers, SD-WAN and IoT routing offerings. Wireless grew primarily driven by our WiFi-6 products and Meraki offerings. Revenue in routed optical networking was flat, primarily driven by growth in our Core routing portfolio, including our Cisco 8000 series offerings and growth in our webscale provider market.

[0000858877-24-000017:mdna:103]
Security

[0000858877-24-000017:mdna:104]
Fiscal 2024 Compared with Fiscal 2023

[0000858877-24-000017:mdna:105]
The Security product category consists of our Network Security, Identity and Access Management, SASE and Threat Intelligence, Detection, and Response offerings. Revenue in our Security product category increased by 32%, or $1.2 billion, primarily driven by the contribution of Splunk offerings and growth across the portfolio. The Security product category grew 4%, not including the contribution from Splunk offerings.

[0000858877-24-000017:mdna:106]
Fiscal 2023 Compared with Fiscal 2022

[0000858877-24-000017:mdna:107]
Revenue in the Security product category increased by 4%, or $160 million, primarily driven by growth in our Secure Access Service Edge and Zero Trust offerings.

[0000858877-24-000017:mdna:108]
Collaboration

[0000858877-24-000017:mdna:109]
Fiscal 2024 Compared with Fiscal 2023

[0000858877-24-000017:mdna:110]
The Collaboration product category consists of our Webex Suite, Collaboration Devices, Contact Center and CPaaS offerings. Revenue in our Collaboration product category increased 2%, or $61 million, primarily driven by growth across the portfolio, except our Meetings offering.

[0000858877-24-000017:mdna:111]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:112]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:113]
Fiscal 2023 Compared with Fiscal 2022

[0000858877-24-000017:mdna:114]
Revenue in the Collaboration product category decreased 9%, or $420 million, primarily driven by declines in Collaboration Devices and Meetings, partially offset by growth in our Calling and Contact Center offerings.

[0000858877-24-000017:mdna:115]
Observability

[0000858877-24-000017:mdna:116]
Fiscal 2024 Compared with Fiscal 2023

[0000858877-24-000017:mdna:117]
The Observability product category consists of our network assurance, monitoring and analytics and observability suite offerings. Revenue in our Observability product category increased by 27%, or $176 million, driven by growth in our ThousandEyes offering and the contribution from Observability Suite, our Splunk offering. Product revenue in the Observability product category increased 15%, not including the contribution from Splunk.

[0000858877-24-000017:mdna:118]
Fiscal 2023 Compared with Fiscal 2022

[0000858877-24-000017:mdna:119]
Revenue in our Observability product category increased 14%, or $80 million, driven by growth in our ThousandEyes and monitoring and analytics offerings.

[0000858877-24-000017:mdna:120]
Services Revenue by Segment

[0000858877-24-000017:mdna:121]
The following table presents the breakdown of services revenue by segment (in millions, except percentages):

[0000858877-24-000017:mdna:122]
|  | Years Ended |  | 2024 vs. 2023 |
|  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |  | Variance in Dollars |  | Variance in Percent |
| Services revenue: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 8,829 |  |  | $ | 8,427 |  |  | $ | 8,194 |  |  | $ | 402 |  |  | 5 | % |
| Percentage of service revenue | 60.7 | % |  | 60.8 | % |  | 60.5 | % |  |  |  |  |
| EMEA | 3,472 |  |  | 3,269 |  |  | 3,171 |  |  | 203 |  |  | 6 | % |
| Percentage of service revenue | 23.9 | % |  | 23.6 | % |  | 23.4 | % |  |  |  |  |
| APJC | 2,249 |  |  | 2,160 |  |  | 2,173 |  |  | 89 |  |  | 4 | % |
| Percentage of service revenue | 15.5 | % |  | 15.6 | % |  | 16.0 | % |  |  |  |  |
| Total | $ | 14,550 |  |  | $ | 13,856 |  |  | $ | 13,539 |  |  | $ | 694 |  |  | 5 | % |

[0000858877-24-000017:mdna:123]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-24-000017:mdna:124]
Services revenue increased 5%, driven by growth in our solution support, advisory services and software support offerings. The acquisition of Splunk also contributed to the growth in services revenue for fiscal 2024. Services revenue increased across all of our geographic segments. Services revenue grew 3%, not including the contribution from Splunk.

[0000858877-24-000017:mdna:125]
Gross Margin

[0000858877-24-000017:mdna:126]
The following table presents the gross margin for products and services (in millions, except percentages):

[0000858877-24-000017:mdna:127]
|  | AMOUNT |  | PERCENTAGE |
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 24,914 |  |  | $ | 26,552 |  |  | $ | 23,204 |  |  | 63.5 | % |  | 61.5 | % |  | 61.0 | % |
| Services | 9,914 |  |  | 9,201 |  |  | 9,044 |  |  | 68.1 | % |  | 66.4 | % |  | 66.8 | % |
| Total | $ | 34,828 |  |  | $ | 35,753 |  |  | $ | 32,248 |  |  | 64.7 | % |  | 62.7 | % |  | 62.5 | % |

[0000858877-24-000017:mdna:128]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:129]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:130]
Product Gross Margin

[0000858877-24-000017:mdna:131]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2023 to fiscal 2024:

[0000858877-24-000017:mdna:132]
|  |  | Product Gross Margin Percentage |
| Fiscal 2023 |  | 61.5 | % |
| Productivity (1) |  | 1.7 | % |
| Product pricing |  | (0.6) | % |
| Mix of products sold |  | 2.0 | % |
| Amortization of purchased intangible assets |  | (0.9) | % |
| Others |  | (0.2) | % |
| Fiscal 2024 |  | 63.5 | % |

[0000858877-24-000017:mdna:133]
(1) Productivity includes overall manufacturing-related costs, such as component costs, warranty expense, provision for inventory, freight, logistics, shipment volume, and other items not categorized elsewhere.

[0000858877-24-000017:mdna:134]
Product gross margin increased by 2.0 percentage points primarily driven by favorable product mix, productivity benefits, largely driven by lower freight and other costs, and benefits from Splunk. This was partially offset by the amortization of purchased intangible assets primarily related to Splunk, and negative impacts from pricing.

[0000858877-24-000017:mdna:135]
Supply Chain Impacts and Risks

[0000858877-24-000017:mdna:136]
In past periods, we took multiple actions in order to mitigate component shortages and address significant supply constraints. These supply constraints resulted in the need to secure long-term supply and increased inventory supply chain balances compared to historical levels. This in turn has significantly increased our supply chain exposure, which has resulted in negative impacts to our product gross margin in recent periods and may result in further negative impacts in future periods. This exposure includes potential material excess and obsolete or other charges if product demand significantly decreases for a sustained duration, we are unable to generate demand for certain products planned for development, or we are unable to mitigate the remaining supply chain exposures.

[0000858877-24-000017:mdna:137]
Services Gross Margin

[0000858877-24-000017:mdna:138]
Our services gross margin percentage increased by 1.7 percentage points primarily due to higher sales volume, lower headcount-related and delivery costs, lower variable compensation expense and favorable mix of service offerings.

[0000858877-24-000017:mdna:139]
Our services gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-24-000017:mdna:140]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:141]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:142]
Gross Margin by Segment

[0000858877-24-000017:mdna:143]
The following table presents the total gross margin for each segment (in millions, except percentages):

[0000858877-24-000017:mdna:144]
|  |  | AMOUNT |  | PERCENTAGE |
| Years Ended |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 21,372 |  |  | $ | 21,350 |  |  | $ | 19,117 |  |  | 66.8 | % |  | 63.8 | % |  | 64.1 | % |
| EMEA |  | 9,755 |  |  | 10,016 |  |  | 8,969 |  |  | 69.1 | % |  | 66.2 | % |  | 65.4 | % |
| APJC |  | 5,187 |  |  | 5,424 |  |  | 5,241 |  |  | 67.2 | % |  | 64.4 | % |  | 65.3 | % |
| Segment total |  | 36,312 |  |  | 36,788 |  |  | 33,326 |  |  | 67.5 | % |  | 64.5 | % |  | 64.6 | % |
| Unallocated corporate items (1) |  | (1,484) |  |  | (1,035) |  |  | (1,078) |  |  |  |  |  |  |  |
| Total |  | $ | 34,828 |  |  | $ | 35,753 |  |  | $ | 32,248 |  |  | 64.7 | % |  | 62.7 | % |  | 62.5 | % |

[0000858877-24-000017:mdna:145]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-24-000017:mdna:146]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-24-000017:mdna:147]
We experienced a gross margin percentage increase in our Americas segment due to productivity benefits, favorable product mix and higher services gross margin, partially offset by negative impacts from pricing.

[0000858877-24-000017:mdna:148]
Gross margin in our EMEA segment increased due to favorable product mix, productivity benefits and higher services gross margin, partially offset by negative impacts from pricing.

[0000858877-24-000017:mdna:149]
The APJC segment gross margin percentage increase was due to favorable product mix and productivity benefits, partially offset by negative impacts from pricing.

[0000858877-24-000017:mdna:150]
Research and Development (“R&D”), Sales and Marketing, and General and Administrative (“G&A”) Expenses

[0000858877-24-000017:mdna:151]
R&D, sales and marketing, and G&A expenses are summarized in the following table (in millions, except percentages):

[0000858877-24-000017:mdna:152]
|  |  | Years Ended |  | 2024 vs. 2023 |
|  |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |  | Variance in Dollars |  | Variance in Percent |
| Research and development |  | $ | 7,983 |  |  | $ | 7,551 |  |  | $ | 6,774 |  |  | $ | 432 |  |  | 6 | % |
| Percentage of revenue |  | 14.8 | % |  | 13.2 | % |  | 13.1 | % |  |  |  |  |
| Sales and marketing |  | 10,364 |  |  | 9,880 |  |  | 9,085 |  |  | 484 |  |  | 5 | % |
| Percentage of revenue |  | 19.3 | % |  | 17.3 | % |  | 17.6 | % |  |  |  |  |
| General and administrative |  | 2,813 |  |  | 2,478 |  |  | 2,101 |  |  | 335 |  |  | 14 | % |
| Percentage of revenue |  | 5.2 | % |  | 4.3 | % |  | 4.1 | % |  |  |  |  |
| Total |  | $ | 21,160 |  |  | $ | 19,909 |  |  | $ | 17,960 |  |  | $ | 1,251 |  |  | 6 | % |
| Percentage of revenue |  | 39.3 | % |  | 34.9 | % |  | 34.8 | % |  |  |  |  |

[0000858877-24-000017:mdna:153]
R&D Expenses

[0000858877-24-000017:mdna:154]
R&D expenses increased due to higher share-based compensation expense, incremental expenses from Splunk, higher cash compensation from acquisitions and higher discretionary spending, partially offset by lower headcount-related expenses and lower variable compensation expense.

[0000858877-24-000017:mdna:155]
We continue to invest in R&D in order to bring a broad range of products to market in a timely fashion. If we believe that we are unable to enter a particular market in a timely manner with internally developed products, we may purchase or license technology from other businesses, or we may partner with or acquire businesses as an alternative to internal R&D.

[0000858877-24-000017:mdna:156]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:157]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:158]
Sales and Marketing Expenses

[0000858877-24-000017:mdna:159]
Sales and marketing expenses increased primarily due to incremental expenses from Splunk, higher share-based compensation expense, higher discretionary spending, higher headcount-related expenses and higher cash compensation from acquisitions, partially offset by lower contracted services spending and lower variable compensation expense.

[0000858877-24-000017:mdna:160]
G&A Expenses

[0000858877-24-000017:mdna:161]
G&A expenses increased due to higher acquisition-related costs, incremental expenses from Splunk, higher share-based compensation expense, higher discretionary spending and higher headcount-related expenses, partially offset by lower contracted services spending and lower variable compensation expense.

[0000858877-24-000017:mdna:162]
Effect of Foreign Currency

[0000858877-24-000017:mdna:163]
In fiscal 2024, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $30 million, or 0.2%, compared with fiscal 2023.

[0000858877-24-000017:mdna:164]
Amortization of Purchased Intangible Assets

[0000858877-24-000017:mdna:165]
The following table presents the amortization of purchased intangible assets including impairment charges (in millions):

[0000858877-24-000017:mdna:166]
| Years Ended |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 955 |  |  | $ | 649 |  |  | $ | 749 |  |
| Operating expenses |  | 698 |  |  | 282 |  |  | 328 |  |
| Total |  | $ | 1,653 |  |  | $ | 931 |  |  | $ | 1,077 |  |

[0000858877-24-000017:mdna:167]
The increase in amortization of purchased intangible assets was primarily due to amortization of purchased intangibles from our recent acquisitions, including $569 million due to the acquisition of Splunk, and impairment charges of $145 million in fiscal 2024. These increases were partially offset by certain purchased intangible assets that became fully amortized. The impairment charges were primarily due to declines in estimated fair value resulting from reductions in or the elimination of expected future cash flows associated with certain of our IPR&D intangible assets.

[0000858877-24-000017:mdna:168]
Restructuring and Other Charges

[0000858877-24-000017:mdna:169]
We recognized total restructuring and other charges, included in operating expenses, of $789 million and $531 million in fiscal 2024 and 2023, respectively.

[0000858877-24-000017:mdna:170]
In the first quarter of fiscal 2025, we announced a restructuring plan in order to allow us to invest in key growth opportunities and drive more efficiencies in our business. This restructuring plan is expected to impact approximately 7% of our global workforce. The total pre-tax charges are estimated to be up to $1 billion. We expect this plan to be substantially completed by the end of fiscal 2025.

[0000858877-24-000017:mdna:171]
In the third quarter of fiscal 2024, we initiated a restructuring plan in order to realign the organization and enable further investment in key priority areas, of which approximately 5% of our global workforce would be impacted. In connection with this plan, we incurred charges of $654 million for fiscal 2024 and the plan is substantially complete.

[0000858877-24-000017:mdna:172]
In fiscal 2023, we announced a restructuring plan in order to rebalance the organization and enable further investment in key priority areas. We incurred cumulative charges of $670 million and completed this plan in fiscal 2024.

[0000858877-24-000017:mdna:173]
We expect to reinvest substantially all of the cost savings from these restructuring plans in our key priority areas and key growth opportunities. As a result, the overall cost savings from these restructuring plans are not expected to be material for future periods.

[0000858877-24-000017:mdna:174]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:175]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:176]
Operating Income

[0000858877-24-000017:mdna:177]
The following table presents our operating income and our operating income as a percentage of revenue (in millions, except percentages):

[0000858877-24-000017:mdna:178]
| Years Ended |  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Operating income |  | $ | 12,181 |  |  | $ | 15,031 |  |  | $ | 13,969 |  |
| Operating income as a percentage of revenue |  | 22.6 | % |  | 26.4 | % |  | 27.1 | % |

[0000858877-24-000017:mdna:179]
Operating income decreased by 19%, and as a percentage of revenue operating income decreased by 3.8 percentage points. These changes were primarily from a revenue decrease, incremental operating expenses from Splunk, higher restructuring and other charges and higher amortization of purchased intangible assets, partially offset by a gross margin percentage increase (driven by favorable product mix, productivity benefits, partially offset by negative impacts from pricing).

[0000858877-24-000017:mdna:180]
Interest and Other Income (Loss), Net

[0000858877-24-000017:mdna:181]
Interest Income (Expense), Net   The following table summarizes interest income and interest expense (in millions):

[0000858877-24-000017:mdna:182]
|  | Years Ended |  | 2024 vs. 2023 |
|  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |  | Variance in Dollars |
| Interest income | $ | 1,365 |  |  | $ | 962 |  |  | $ | 476 |  |  | $ | 403 |  |
| Interest expense | (1,006) |  |  | (427) |  |  | (360) |  |  | (579) |  |
| Interest income (expense), net | $ | 359 |  |  | $ | 535 |  |  | $ | 116 |  |  | $ | (176) |  |

[0000858877-24-000017:mdna:183]
Interest income increased driven by a higher average balance of cash and available-for-sale debt investments and higher interest rates. The increase in interest expense was primarily driven by higher interest rates and the issuances of senior notes and commercial paper during fiscal 2024. We incurred incremental net interest expense of approximately $500 million during fiscal 2024 to finance the acquisition of Splunk. We expect lower interest income in future periods due to a lower average balance of cash and available-for-sale debt investments and higher interest expense due to the higher outstanding balance of debt.

[0000858877-24-000017:mdna:184]
Other Income (Loss), Net   The components of other income (loss), net, are summarized as follows (in millions):

[0000858877-24-000017:mdna:185]
|  | Years Ended |  | 2024 vs. 2023 |
|  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |
| Available-for-sale debt investments | $ | (67) |  |  | $ | (21) |  |  | $ | 9 |  |  | $ | (46) |  |
| Marketable equity investments | 65 |  |  | 37 |  |  | (38) |  |  | 28 |  |
| Privately held investments | (164) |  |  | (193) |  |  | 486 |  |  | 29 |  |
| Net gains (losses) on investments | (166) |  |  | (177) |  |  | 457 |  |  | 11 |  |
| Other gains (losses), net | (140) |  |  | (71) |  |  | (65) |  |  | (69) |  |
| Other income (loss), net | $ | (306) |  |  | $ | (248) |  |  | $ | 392 |  |  | $ | (58) |  |

[0000858877-24-000017:mdna:186]
The change in our other income (loss), net was primarily driven by higher losses in our available-for-sale debt investments and unfavorable impacts from foreign exchange, partially offset by higher gains on our marketable equity investments and lower net losses on our privately held investments.

[0000858877-24-000017:mdna:187]
Provision for Income Taxes

[0000858877-24-000017:mdna:188]
The provision for income taxes resulted in an effective tax rate of 15.6% for fiscal 2024, compared with 17.7% for fiscal 2023. The net 2.1 percentage points decrease in the effective tax rate was primarily due to an increase in discrete tax benefits relating to prior year return-to-provision true up and an increase in stock-based compensation windfall benefit.

[0000858877-24-000017:mdna:189]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 21% and for further explanation of our provision for income taxes, see Note 18 to the Consolidated Financial Statements.

[0000858877-24-000017:mdna:190]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:191]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:192]
LIQUIDITY AND CAPITAL RESOURCES

[0000858877-24-000017:mdna:193]
The following sections discuss the effects of changes in our balance sheet, our capital allocation strategy including stock repurchase program and dividends, our contractual obligations, and certain other commitments and activities on our liquidity and capital resources.

[0000858877-24-000017:mdna:194]
Balance Sheet and Cash Flows

[0000858877-24-000017:mdna:195]
Cash and Cash Equivalents and Investments  The following table summarizes our cash and cash equivalents and investments (in millions):

[0000858877-24-000017:mdna:196]
|  | July 27, 2024 |  | July 29, 2023 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 7,508 |  |  | $ | 10,123 |  |  | $ | (2,615) |  |
| Available-for-sale debt investments | 9,865 |  |  | 15,592 |  |  | (5,727) |  |
| Marketable equity securities | 481 |  |  | 431 |  |  | 50 |  |
| Total | $ | 17,854 |  |  | $ | 26,146 |  |  | $ | (8,292) |  |

[0000858877-24-000017:mdna:197]
The net decrease in cash and cash equivalents and investments from fiscal 2023 to fiscal 2024 was primarily driven by a net outflow for the acquisition of Splunk of $27.5 billion, cash returned to stockholders in the form of cash dividends of $6.4 billion and repurchases of common stock of $5.8 billion, repayment of debt of $1.8 billion, net cash paid for our other acquisitions, excluding Splunk, of $1.3 billion and capital expenditures of $0.7 billion. These uses of cash were partially offset by the issuance of senior notes for net proceeds of $13.4 billion, net cash provided by operating activities of $10.9 billion and net issuances of commercial paper notes of $10.8 billion. The net cash provided by operating activities during fiscal 2024 includes the fiscal 2023 federal tax payment of $2.8 billion that was deferred by the IRS as a result of the California floods and the U.S. transition tax payment of $1.4 billion.

[0000858877-24-000017:mdna:198]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our available-for-sale debt investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-24-000017:mdna:199]
Securities Lending  We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of July 27, 2024 and July 29, 2023, we had no outstanding securities lending transactions.

[0000858877-24-000017:mdna:200]
Free Cash Flow and Capital Allocation  As part of our capital allocation strategy, we target to return a minimum of 50% of our free cash flow annually to our stockholders through cash dividends and repurchases of common stock.

[0000858877-24-000017:mdna:201]
We define free cash flow as net cash provided by operating activities less cash used to acquire property and equipment. The following table reconciles our net cash provided by operating activities to free cash flow (in millions):

[0000858877-24-000017:mdna:202]
| Years Ended | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |
| Net cash provided by operating activities | $ | 10,880 |  |  | $ | 19,886 |  |  | $ | 13,226 |  |
| Acquisition of property and equipment | (670) |  |  | (849) |  |  | (477) |  |
| Free cash flow | $ | 10,210 |  |  | $ | 19,037 |  |  | $ | 12,749 |  |

[0000858877-24-000017:mdna:203]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management,

[0000858877-24-000017:mdna:204]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:205]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:206]
deferred revenue and the timing and amount of tax and other payments. For additional discussion, see “Part I, Item 1A. Risk Factors” in this report.

[0000858877-24-000017:mdna:207]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to stockholders in the form of dividends and stock repurchases. We further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness. Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net cash provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-24-000017:mdna:208]
The following table summarizes the dividends paid and stock repurchases (in millions, except per-share amounts):

[0000858877-24-000017:mdna:209]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  | TOTAL |
| Years Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | Amount |
| July 27, 2024 |  | $ | 1.58 |  |  | $ | 6,384 |  |  | 117 |  |  | $ | 49.45 |  |  | $ | 5,764 |  |  | $ | 12,148 |  |
| July 29, 2023 |  | $ | 1.54 |  |  | $ | 6,302 |  |  | 88 |  |  | $ | 48.49 |  |  | $ | 4,271 |  |  | $ | 10,573 |  |
| July 30, 2022 |  | $ | 1.50 |  |  | $ | 6,224 |  |  | 146 |  |  | $ | 52.82 |  |  | $ | 7,734 |  |  | $ | 13,958 |  |

[0000858877-24-000017:mdna:210]
On August 14, 2024, our Board of Directors declared a quarterly dividend of $0.40 per common share to be paid on October 23, 2024, to all stockholders of record as of the close of business on October 2, 2024. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-24-000017:mdna:211]
The remaining authorized amount for stock repurchases under this program is approximately $5.2 billion, with no termination date.

[0000858877-24-000017:mdna:212]
Accounts Receivable, Net  The following table summarizes our accounts receivable, net (in millions):

[0000858877-24-000017:mdna:213]
|  | July 27, 2024 |  | July 29, 2023 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 6,685 |  |  | $ | 5,854 |  |  | $ | 831 |  |

[0000858877-24-000017:mdna:214]
Our accounts receivable net, as of July 27, 2024 increased by approximately 14% compared with the end of fiscal 2023, primarily due to timing and amount of product and service billings at the end of fiscal 2024 compared with the end of fiscal 2023.

[0000858877-24-000017:mdna:215]
Inventory Supply Chain  The following table summarizes our inventories and inventory purchase commitments with contract manufacturers and suppliers (in millions):

[0000858877-24-000017:mdna:216]
|  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |  | Variance vs. July 29, 2023 |  | Variance vs. July 30, 2022 |
| Inventories | $ | 3,373 |  |  | $ | 3,644 |  |  | $ | 2,568 |  |  | $ | (271) |  |  | $ | 805 |  |
| Inventory purchase commitments | $ | 5,158 |  |  | $ | 7,253 |  |  | $ | 12,964 |  |  | $ | (2,095) |  |  | $ | (7,806) |  |
| Inventory deposits and prepayments | $ | 973 |  |  | $ | 1,109 |  |  | $ | 1,484 |  |  | $ | (136) |  |  | $ | (511) |  |

[0000858877-24-000017:mdna:217]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-24-000017:mdna:218]
|  | July 27, 2024 |  | July 29, 2023 |  | July 30, 2022 |  | Variance vs. July 29, 2023 |  | Variance vs. July 30, 2022 |
| Less than 1 year | $ | 3,952 |  |  | $ | 5,270 |  |  | $ | 9,954 |  |  | $ | (1,318) |  |  | $ | (6,002) |  |
| 1 to 3 years | 1,085 |  |  | 1,783 |  |  | 2,240 |  |  | (698) |  |  | (1,155) |  |
| 3 to 5 years | 121 |  |  | 200 |  |  | 770 |  |  | (79) |  |  | (649) |  |
| Total | $ | 5,158 |  |  | $ | 7,253 |  |  | $ | 12,964 |  |  | $ | (2,095) |  |  | $ | (7,806) |  |

[0000858877-24-000017:mdna:219]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:220]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:221]
Inventory as of July 27, 2024 decreased by 7% and inventory purchase commitments with contract manufacturers and suppliers decreased by 29% from our balances at the end of fiscal 2023. The combined decrease of 22% in our inventory and inventory purchase commitments as compared with the end of fiscal 2023 was primarily due to our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitment levels.

[0000858877-24-000017:mdna:222]
We have increased our levels of inventory in order to help mitigate risks in our supply chain. We also began increasing our inventory supply chain balances starting in fiscal 2021 in order to address significant supply constraints seen industry-wide. The increases were primarily due to arrangements to secure supply and pricing for certain product components and commitments with contract manufacturers to meet customer demand and to address extended lead times, as well as advance payments with suppliers to secure future supply, as a result of the supply constraints. Our risks of future material excess and obsolete inventory and related losses are further outlined in the Result of Operations—Product Gross Margin section.

[0000858877-24-000017:mdna:223]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity.

[0000858877-24-000017:mdna:224]
Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments are entered into directly with suppliers and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-24-000017:mdna:225]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of supply constraints, rapidly changing technology and customer requirements. We believe the amount of our inventory and inventory purchase commitments is appropriate for our current and expected customer demand and revenue levels.

[0000858877-24-000017:mdna:226]
Financing Receivables and Guarantees  The following table summarizes our financing receivables (in millions):

[0000858877-24-000017:mdna:227]
|  | July 27, 2024 |  | July 29, 2023 |  | Increase (Decrease) |
| Loan receivables, net | $ | 5,808 |  |  | $ | 5,857 |  |  | $ | (49) |  |
| Lease receivables, net | 906 |  |  | 978 |  |  | (72) |  |
| Total, net | $ | 6,714 |  |  | $ | 6,835 |  |  | $ | (121) |  |

[0000858877-24-000017:mdna:228]
Financing Receivables  Our financing arrangements include loans and leases. Our loan receivables include customer financing for purchases of our hardware, software and services (including technical support and advanced services), and also may include additional funds for other costs associated with network installation and integration of our products and services. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Financing receivables decreased by 2% as compared with the end of fiscal 2023.

[0000858877-24-000017:mdna:229]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, with payment terms generally ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-24-000017:mdna:230]
The volume of channel partner financing was $27.1 billion, $32.1 billion, and $27.9 billion in fiscal 2024, 2023, and 2022, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.7 billion as of July 27, 2024 and July 29, 2023, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of July 27, 2024,

[0000858877-24-000017:mdna:231]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:232]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:233]
the total maximum potential future payments related to these guarantees was approximately $127 million, of which approximately $13 million was recorded as deferred revenue.

[0000858877-24-000017:mdna:234]
Borrowings

[0000858877-24-000017:mdna:235]
Senior Notes  The following table summarizes the principal amount of our senior notes (in millions):

[0000858877-24-000017:mdna:236]
|  | Maturity Date |  | July 27, 2024 |  | July 29, 2023 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 2.20% | September 20, 2023 |  | $ | — |  |  | $ | 750 |  |
| 3.625% | March 4, 2024 |  | — |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 4.90% | February 26, 2026 |  | 1,000 |  |  | — |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | — |  |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | — |  |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | — |  |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | — |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | — |  |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | — |  |
| Total |  |  | $ | 20,250 |  |  | $ | 8,500 |  |

[0000858877-24-000017:mdna:237]
In February 2024, we issued senior notes for an aggregate principal amount of $13.5 billion.

[0000858877-24-000017:mdna:238]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of July 27, 2024.

[0000858877-24-000017:mdna:239]
Commercial Paper  We have a short-term debt financing program in which up to $15.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had $10.9 billion in commercial paper notes outstanding as of July 27, 2024, and no commercial paper notes outstanding as of July 29, 2023.

[0000858877-24-000017:mdna:240]
Credit Facility  On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of July 27, 2024, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.

[0000858877-24-000017:mdna:241]
Remaining Performance Obligations   The following table presents the breakdown of remaining performance obligations (in millions):

[0000858877-24-000017:mdna:242]
|  | July 27, 2024 |  | July 29, 2023 |  | Increase (Decrease) |
| Product | $ | 20,055 |  |  | $ | 15,802 |  |  | $ | 4,253 |  |
| Services | 20,993 |  |  | 19,066 |  |  | 1,927 |  |
| Total | $ | 41,048 |  |  | $ | 34,868 |  |  | $ | 6,180 |  |
| Short-term RPO | $ | 20,882 |  |  | $ | 17,910 |  |  | $ | 2,972 |  |
| Long-term RPO | 20,166 |  |  | 16,958 |  |  | 3,208 |  |
| Total | $ | 41,048 |  |  | $ | 34,868 |  |  | $ | 6,180 |  |

[0000858877-24-000017:mdna:243]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:244]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:245]
Total remaining performance obligations increased 18% in fiscal 2024. Total remaining performance obligations as of July 27, 2024 includes $3.5 billion related to the acquisition of Splunk. Remaining performance obligations for product increased 27% and remaining performance obligations for services increased 10%, compared to fiscal 2023. We expect approximately 51% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-24-000017:mdna:246]
Deferred Revenue   The following table presents the breakdown of deferred revenue (in millions):

[0000858877-24-000017:mdna:247]
|  | July 27, 2024 |  | July 29, 2023 |  | Increase (Decrease) |
| Product | $ | 13,219 |  |  | $ | 11,505 |  |  | $ | 1,714 |  |
| Services | 15,256 |  |  | 14,045 |  |  | 1,211 |  |
| Total | $ | 28,475 |  |  | $ | 25,550 |  |  | $ | 2,925 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 16,249 |  |  | $ | 13,908 |  |  | $ | 2,341 |  |
| Noncurrent | 12,226 |  |  | 11,642 |  |  | 584 |  |
| Total | $ | 28,475 |  |  | $ | 25,550 |  |  | $ | 2,925 |  |

[0000858877-24-000017:mdna:248]
Total deferred revenue increased 11% in fiscal 2024. The increase in deferred product revenue of 15% was primarily due to the contribution from the Splunk acquisition of $1.7 billion and increased deferrals related to our recurring software offerings. The increase in deferred services revenue of 9% was driven by higher business volume and the impact of contract renewals and the contribution of the Splunk acquisition, partially offset by ongoing amortization of deferred services revenue.

[0000858877-24-000017:mdna:249]
Contractual Obligations

[0000858877-24-000017:mdna:250]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. In addition, we plan for and measure our liquidity and capital resources through an annual budgeting process. The following table summarizes our contractual obligations at July 27, 2024 (in millions):

[0000858877-24-000017:mdna:251]
|  | PAYMENTS DUE BY PERIOD |
| July 27, 2024 | Total |  | Less than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than 5 Years |
| Operating leases | $ | 1,420 |  |  | $ | 409 |  |  | $ | 502 |  |  | $ | 256 |  |  | $ | 253 |  |
| Purchase commitments with contract manufacturers and suppliers | 5,158 |  |  | 3,952 |  |  | 1,085 |  |  | 121 |  |  | — |  |
| Other purchase obligations | 3,998 |  |  | 1,295 |  |  | 1,736 |  |  | 822 |  |  | 145 |  |
| Senior notes | 20,253 |  |  | 500 |  |  | 5,253 |  |  | 2,500 |  |  | 12,000 |  |
| Transition tax payable | 4,092 |  |  | 1,819 |  |  | 2,273 |  |  | — |  |  | — |  |
| Other long-term liabilities | 1,557 |  |  | — |  |  | 232 |  |  | 178 |  |  | 1,147 |  |
| Total by period | $ | 36,478 |  |  | $ | 7,975 |  |  | $ | 11,081 |  |  | $ | 3,877 |  |  | $ | 13,545 |  |
| Other long-term liabilities (uncertainty in the timing of future payments) | 1,789 |  |  |  |  |  |  |  |  |  |
| Total | $ | 38,267 |  |  |  |  |  |  |  |  |  |

[0000858877-24-000017:mdna:252]
Operating Leases  For more information on our operating leases, see Note 8 to the Consolidated Financial Statements.

[0000858877-24-000017:mdna:253]
Purchase Commitments with Contract Manufacturers and Suppliers  We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments are directly with suppliers and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. See further discussion in “Inventory Supply Chain.”

[0000858877-24-000017:mdna:254]
49

[0000858877-24-000017:mdna:255]
CISCO SYSTEMS, INC.

[0000858877-24-000017:mdna:256]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-24-000017:mdna:257]
Other Purchase Obligations  Other purchase obligations represent an estimate of all contractual obligations in the ordinary course of business, other than operating leases and commitments with contract manufacturers and suppliers, for which we have not received the goods or services. Purchase orders are not included in the preceding table as they typically represent our authorization to purchase rather than binding contractual purchase obligations.

[0000858877-24-000017:mdna:258]
Long-Term Debt  The amount of long-term debt in the preceding table represents the principal amount of the respective debt instruments. See Note 12 to the Consolidated Financial Statements.

[0000858877-24-000017:mdna:259]
Transition Tax Payable  Transition tax payable represents future cash tax payments associated with the one-time U.S. transition tax on accumulated earnings for foreign subsidiaries as a result of the Tax Cuts and Jobs Act (“the Tax Act”).

[0000858877-24-000017:mdna:260]
Other Long-Term Liabilities  Other long-term liabilities primarily include noncurrent income taxes payable, accrued liabilities for deferred compensation, deferred tax liabilities, and certain other long-term liabilities. Due to the uncertainty in the timing of future payments, our noncurrent income taxes payable of approximately $1.7 billion and deferred tax liabilities of $76 million were presented as one aggregated amount in the total column on a separate line in the preceding table. Noncurrent income taxes payable include uncertain tax positions. See Note 18 to the Consolidated Financial Statements.

[0000858877-24-000017:mdna:261]
Other Commitments

[0000858877-24-000017:mdna:262]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the continued employment with us of certain employees of the acquired entities. See Note 4 to the Consolidated Financial Statements.

[0000858877-24-000017:mdna:263]
We also have certain funding commitments primarily related to our privately held investments. The funding commitments were $0.2 billion and $0.3 billion as of July 27, 2024 and July 29, 2023, respectively.

[0000858877-24-000017:mdna:264]
In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of July 27, 2024 there were no material unconsolidated variable interest entities.

[0000858877-24-000017:mdna:265]
On an ongoing basis, we reassess our privately held investments and customer financings to determine if they are variable interest entities and if we would be regarded as the primary beneficiary pursuant to the applicable accounting guidance. As a result of this ongoing assessment, we may be required to make additional disclosures or consolidate these entities. Because we may not control these entities, we may not have the ability to influence these events.

[0000858877-24-000017:mdna:266]
We provide financing guarantees, which are generally for various third-party financing arrangements extended to our channel partners. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. See the previous discussion of these financing guarantees under “Financing Receivables and Guarantees.”

[0000858877-24-000017:mdna:267]
Liquidity and Capital Resource Requirements

[0000858877-24-000017:mdna:268]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs (including inventory and other supply related payments), capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.

[0000858877-24-000017:mdna:269]
50
