# CSCO notes — 0000858877-14-000029


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000858877-14-000029:notes:1]
(p) Advertising Costs   The Company expenses all advertising costs as incurred. Advertising costs included within sales and marketing expenses were approximately $196 million, $218 million, and $218 million for fiscal 2014, 2013, and 2012, respectively.


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-14-000029:notes:2]
The allowances for credit loss and the related financing receivables are summarized as follows (in millions):

[0000858877-14-000029:notes:3]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 27, 2013 | $ | 238 |  |  | $ | 86 |  |  | $ | 20 |  |  | $ | 344 |  |
| Provisions | 4 |  |  | 9 |  |  | 1 |  |  | 14 |  |
| Recoveries (write-offs), net | (11 | ) |  | 5 |  |  | (3 | ) |  | (9 | ) |
| Foreign exchange and other | 2 |  |  | (2 | ) |  | — |  |  | — |  |
| Allowance for credit loss as of July 26, 2014 | $ | 233 |  |  | $ | 98 |  |  | $ | 18 |  |  | $ | 349 |  |
| Financing receivables as of July 26, 2014 (1) | $ | 3,527 |  |  | $ | 1,683 |  |  | $ | 3,210 |  |  | $ | 8,420 |  |

[0000858877-14-000029:notes:4]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 28, 2012 | $ | 247 |  |  | $ | 122 |  |  | $ | 11 |  |  | $ | 380 |  |
| Provisions | 21 |  |  | (20 | ) |  | 10 |  |  | 11 |  |
| Recoveries (write-offs), net | (30 | ) |  | (15 | ) |  | (1 | ) |  | (46 | ) |
| Foreign exchange and other | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Allowance for credit loss as of July 27, 2013 | $ | 238 |  |  | $ | 86 |  |  | $ | 20 |  |  | $ | 344 |  |
| Financing receivables as of July 27, 2013 (1) | $ | 3,507 |  |  | $ | 1,649 |  |  | $ | 3,136 |  |  | $ | 8,292 |  |

[0000858877-14-000029:notes:5]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 30, 2011 | $ | 237 |  |  | $ | 103 |  |  | $ | 27 |  |  | $ | 367 |  |
| Provisions | 22 |  |  | 22 |  |  | (13 | ) |  | 31 |  |
| Recoveries (write-offs), net | (2 | ) |  | — |  |  | (1 | ) |  | (3 | ) |
| Foreign exchange and other | (10 | ) |  | (3 | ) |  | (2 | ) |  | (15 | ) |
| Allowance for credit loss as of July 28, 2012 | $ | 247 |  |  | $ | 122 |  |  | $ | 11 |  |  | $ | 380 |  |
| Financing receivables as of July 28, 2012 (1) | $ | 3,179 |  |  | $ | 1,796 |  |  | $ | 2,651 |  |  | $ | 7,626 |  |

[0000858877-14-000029:notes:6]
(1) Total financing receivables before allowance for credit loss.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-14-000029:notes:7]
| 3. | Business Combinations |

[0000858877-14-000029:notes:8]
| (a) | Acquisition Summary |

[0000858877-14-000029:notes:9]
The Company completed eight business combinations during fiscal 2014.  A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-14-000029:notes:10]
| Fiscal 2014 | Purchase Consideration |  | Net TangibleAssets Acquired(LiabilitiesAssumed) |  | Purchased Intangible Assets |  | Goodwill |
| Composite Software, Inc. | $ | 160 |  |  | $ | (10 | ) |  | $ | 75 |  |  | $ | 95 |  |
| Sourcefire, Inc. | 2,449 |  |  | 81 |  |  | 577 |  |  | 1,791 |  |
| WhipTail Technologies, Inc. | 351 |  |  | (34 | ) |  | 105 |  |  | 280 |  |
| Tail-f Systems | 167 |  |  | (7 | ) |  | 61 |  |  | 113 |  |
| All others (four in total) | 54 |  |  | (5 | ) |  | 20 |  |  | 39 |  |
| Total acquisitions | $ | 3,181 |  |  | $ | 25 |  |  | $ | 838 |  |  | $ | 2,318 |  |

[0000858877-14-000029:notes:11]
On July 29, 2013, the Company completed its acquisition of privately held Composite Software, Inc. (“Composite Software”), a provider of data virtualization software and services.  Composite Software provides technology that connects many types of data from across the network and makes it appear as if the data is in one place.  With its acquisition of Composite Software, the Company intends to extend its next-generation services platform by connecting data and infrastructure. Revenue from the Composite Software acquisition has been included in the Company's Service category.

[0000858877-14-000029:notes:12]
On October 7, 2013, the Company completed its acquisition of Sourcefire, Inc. (“Sourcefire”), a provider of intelligent cybersecurity solutions.  Sourcefire delivers innovative, highly automated security through continuous awareness, threat detection, and protection across its portfolio, including next-generation intrusion prevention systems, next-generation firewalls, and advanced malware protection.  With the Sourcefire acquisition, the Company aims to accelerate its security strategy of defending, discovering, and remediating advanced threats to provide continuous security solutions to the Company’s customers in more places across the network. Product revenue from the Sourcefire acquisition has been included in the Company's Security product category.

[0000858877-14-000029:notes:13]
On October 28, 2013, the Company completed its acquisition of privately held WhipTail Technologies, Inc. (“WhipTail”), a provider of high-performance, scalable solid state memory systems. With its WhipTail acquisition, the Company aims to strengthen its Unified Computing System (UCS) strategy and enhance application performance by integrating scalable solid-state memory into the UCS’s fabric computing architecture. Product revenue from the WhipTail acquisition has been included in the Company's Data Center product category.

[0000858877-14-000029:notes:14]
On July 8, 2014, the Company completed its acquisition of privately held Tail-f Systems ("Tail-f"), a provider of multi-vendor network service orchestration solutions for traditional and virtualized networks.  Tail-f's products help customers implement applications, network services, and solutions across networking devices.  With the Tail-f acquisition, the Company intends to advance its cloud virtualization strategy.

[0000858877-14-000029:notes:15]
The total purchase consideration related to the Company’s business combinations completed during fiscal 2014 consisted of either cash consideration or cash consideration along with vested share-based awards assumed. The total cash and cash equivalents acquired from these business combinations was approximately $134 million.

[0000858877-14-000029:notes:16]
Fiscal 2013 Business Combinations

[0000858877-14-000029:notes:17]
Allocation of the purchase consideration for business combinations completed in fiscal 2013 is summarized as follows (in millions):

[0000858877-14-000029:notes:18]
| Fiscal 2013 | PurchaseConsideration |  | Net LiabilitiesAssumed |  | PurchasedIntangibleAssets |  | Goodwill |
| NDS Group Limited | $ | 5,005 |  |  | $ | (185 | ) |  | $ | 1,746 |  |  | $ | 3,444 |  |
| Meraki, Inc. | 974 |  |  | (59 | ) |  | 289 |  |  | 744 |  |
| Intucell, Ltd. | 360 |  |  | (23 | ) |  | 106 |  |  | 277 |  |
| Ubiquisys Limited | 280 |  |  | (30 | ) |  | 123 |  |  | 187 |  |
| All others (nine in total) | 363 |  |  | (25 | ) |  | 127 |  |  | 261 |  |
| Total acquisitions | $ | 6,982 |  |  | $ | (322 | ) |  | $ | 2,391 |  |  | $ | 4,913 |  |

[0000858877-14-000029:notes:19]
Acquisition of NDS Group Limited

[0000858877-14-000029:notes:20]
On July 30, 2012, the Company completed its acquisition of NDS Group Limited (“NDS”), a provider of video software and content security solutions that enable service providers and media companies to securely deliver and monetize new video entertainment experiences. The acquisition of NDS will be combined with the delivery of Cisco Videoscape, the Company’s comprehensive content delivery platform that enables service providers and media companies to deliver next-generation entertainment experiences.  The Company has included revenue from the NDS acquisition, subsequent to the acquisition date, in its Service Provider Video product category.

[0000858877-14-000029:notes:21]
Under the terms of the acquisition agreement, the Company paid total cash consideration of approximately $5.0 billion, which included the repayment of $993 million of pre-existing NDS debt to third party creditors at the closing of the acquisition. The following table summarizes the purchase consideration for the NDS acquisition (in millions):

[0000858877-14-000029:notes:22]
|  |  | Fair Value |
| Cash consideration to seller |  | $ | 4,012 |  |
| Repayment of NDS debt to third party creditors |  | 993 |  |
| Total purchase consideration |  | $ | 5,005 |  |

[0000858877-14-000029:notes:23]
The payment of the total purchase consideration of approximately $5.0 billion shown above, net of cash and cash equivalents acquired, is classified as a use of cash under investing activities in the Consolidated Statements of Cash Flows.

[0000858877-14-000029:notes:24]
The total purchase allocation for NDS is summarized as follows (in millions):

[0000858877-14-000029:notes:25]
|  |  | Fair Value |
| Cash and cash equivalents |  | $ | 98 |  |
| Accounts receivable, net |  | 199 |  |
| Other tangible assets |  | 268 |  |
| Goodwill |  | 3,444 |  |
| Purchased intangible assets |  | 1,746 |  |
| Deferred tax liabilities, net |  | (378 | ) |
| Liabilities assumed |  | (372 | ) |
| Total purchase consideration |  | $ | 5,005 |  |

[0000858877-14-000029:notes:26]
Other Fiscal 2013 Business Combinations

[0000858877-14-000029:notes:27]
The Company acquired privately held Meraki, Inc. (“Meraki”) in the second quarter of fiscal 2013. Prior to its acquisition, Meraki offered mid-market customers on-premise networking solutions centrally managed from the cloud. With its acquisition of Meraki, the Company intends to address the shift to cloud networking as a key part of the Company’s overall strategy to accelerate the adoption of software-based business models that provide new consumption options for customers and revenue opportunities for partners.   The Company has included revenue from the Meraki acquisition, subsequent to the acquisition date, in its Wireless product category.

[0000858877-14-000029:notes:28]
The Company acquired privately held Intucell, Ltd. (“Intucell”) in the third quarter of fiscal 2013. Prior to its acquisition, Intucell provided advanced self-optimizing network software for mobile carriers. With its acquisition of Intucell, the Company intends to enhance its commitment to global service providers by adding a critical network intelligence layer to manage and optimize spectrum, coverage, and capacity, and ultimately the quality of the mobile experience. The Company has included revenue from the Intucell acquisition, subsequent to the acquisition date, in its NGN Routing product category.

[0000858877-14-000029:notes:29]
The Company acquired privately held Ubiquisys Limited (“Ubiquisys”) in the fourth quarter of fiscal 2013. Prior to its acquisition, Ubiquisys offered service providers intelligent 3G and long-term evolution (LTE) small-cell technologies for seamless connectivity across mobile networks. With its acquisition of Ubiquisys, the Company intends to strengthen its commitment to global service providers by enabling a comprehensive small-cell solution that supports the transition to next-generation radio access networks. The Company has included revenue from the Ubiquisys acquisition, subsequent to the acquisition date, in its NGN Routing product category.

[0000858877-14-000029:notes:30]
The total purchase consideration related to the Company’s business combinations completed during fiscal 2013 consisted of cash consideration, repayment of debt, and vested share-based awards assumed. The total cash and cash equivalents acquired from these business combinations was approximately $156 million.

[0000858877-14-000029:notes:31]
Fiscal 2012 Business Combinations

[0000858877-14-000029:notes:32]
Allocation of the purchase consideration for business combinations completed in fiscal 2012 is summarized as follows (in millions):

[0000858877-14-000029:notes:33]
| Fiscal 2012 | PurchaseConsideration |  | Net LiabilitiesAssumed |  | PurchasedIntangibleAssets |  | Goodwill |
| Total acquisitions (seven in total) | $ | 398 |  |  | $ | (39 | ) |  | $ | 200 |  |  | $ | 237 |  |

[0000858877-14-000029:notes:34]
| (b) | Other Acquisition/Divestiture Information |

[0000858877-14-000029:notes:35]
Total transaction costs related to the Company’s business combination activities during fiscal 2014, 2013, and 2012 were $7 million, $40 million, and $15 million, respectively. These transaction costs were expensed as incurred in general and administrative (G&A) expenses in the Consolidated Statements of Operations.

[0000858877-14-000029:notes:36]
The Company’s purchase price allocation for business combinations completed during recent periods is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information, which existed as of the acquisition date but at that time was unknown to the Company, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date. Adjustments in the purchase price allocation may require a recasting of the amounts allocated to goodwill retroactive to the period in which the acquisition occurred.

[0000858877-14-000029:notes:37]
The goodwill generated from the Company’s business combinations completed during fiscal 2014 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-14-000029:notes:38]
The Consolidated Financial Statements include the operating results of each business combination from the date of acquisition. Pro forma results of operations for the acquisitions completed during the fiscal years presented have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.

[0000858877-14-000029:notes:39]
During the third quarter of fiscal 2013, the Company completed the sale of its Linksys product line to a third party. The financial statement impact of the Company’s Linksys product line and its resulting sale were not material for any of the fiscal years presented.

[0000858877-14-000029:notes:40]
| (c) | Insieme Networks, Inc. |

[0000858877-14-000029:notes:41]
In the second quarter of fiscal 2014, the Company acquired the remaining interest in Insieme Networks, Inc.  See Note 12.


## us-gaap:BusinessCombinationsAndOtherPurchaseOfBusinessTransactionsPolicyTextBlock

[0000858877-14-000029:notes:42]
(h) Business Combinations The Company allocates the fair value of the purchase consideration of its acquisitions to the tangible assets, liabilities, and intangible assets acquired, including in-process research and development (IPR&D), based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When a project underlying reported IPR&D is completed, the corresponding amount of IPR&D is reclassified as an amortizable purchased intangible asset and is amortized over the asset’s estimated useful life. Acquisition-related expenses and restructuring costs are recognized separately from the business combination and are expensed as incurred.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000858877-14-000029:notes:43]
(a) Cash and Cash Equivalents   The Company considers all highly liquid investments purchased with an original or remaining maturity of three months or less at the date of purchase to be cash equivalents. Cash and cash equivalents are maintained with various financial institutions.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-14-000029:notes:44]
| 12. | Commitments and Contingencies |

[0000858877-14-000029:notes:45]
| (a) | Operating Leases |

[0000858877-14-000029:notes:46]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in China, France, Germany, India, Israel, Italy, Japan, Netherlands, Norway, and the United Kingdom.  The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of July 26, 2014 are as follows (in millions):

[0000858877-14-000029:notes:47]
| Fiscal Year | Amount |
| 2015 | $ | 399 |  |
| 2016 | 277 |  |
| 2017 | 180 |  |
| 2018 | 131 |  |
| 2019 | 65 |  |
| Thereafter | 187 |  |
| Total | $ | 1,239 |  |

[0000858877-14-000029:notes:48]
Rent expense for office space and equipment totaled $413 million, $416 million, and $404 million in fiscal 2014, 2013, and 2012, respectively.

[0000858877-14-000029:notes:49]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-14-000029:notes:50]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed. As of July 26, 2014 and July 27, 2013, the Company had total purchase commitments for inventory of $4,169 million and $4,033 million, respectively.

[0000858877-14-000029:notes:51]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of July 26, 2014 and July 27, 2013, the liability for these purchase commitments was $162 million and $172 million, respectively, and was included in other current liabilities.

[0000858877-14-000029:notes:52]
| (c) | Other Commitments |

[0000858877-14-000029:notes:53]
In connection with the Company’s business combinations, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-14-000029:notes:54]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-14-000029:notes:55]
|  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Compensation expense related to acquisitions | $ | 607 |  |  | $ | 123 |  |  | $ | 50 |  |

[0000858877-14-000029:notes:56]
As of July 26, 2014, the Company estimated that future cash compensation expense of up to $574 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc., as more fully discussed immediately below.

[0000858877-14-000029:notes:57]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme Networks, Inc. ("Insieme"), an early stage company focused on research and development in the data center market.  As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology.  Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements.  In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

[0000858877-14-000029:notes:58]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  During fiscal 2014, the Company recorded compensation expense of $416 million related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $855 million, net of forfeitures and including the $416 million that has been expensed in fiscal 2014.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.

[0000858877-14-000029:notes:59]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $255 million and $263 million as of July 26, 2014 and July 27, 2013, respectively.

[0000858877-14-000029:notes:60]
| (d) | Product Warranties |

[0000858877-14-000029:notes:61]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-14-000029:notes:62]
|  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Balance at beginning of fiscal year | $ | 402 |  |  | $ | 373 |  |  | $ | 340 |  |
| Provision for warranties issued | 704 |  |  | 649 |  |  | 617 |  |
| Payments | (660 | ) |  | (620 | ) |  | (584 | ) |
| Balance at end of fiscal year | $ | 446 |  |  | $ | 402 |  |  | $ | 373 |  |

[0000858877-14-000029:notes:63]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-14-000029:notes:64]
| (e) | Financing and Other Guarantees |

[0000858877-14-000029:notes:65]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-14-000029:notes:66]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $24.6 billion, $23.8 billion, and $21.3 billion for fiscal 2014, 2013, and 2012, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.4 billion as of July 26, 2014 and July 27, 2013, respectively.

[0000858877-14-000029:notes:67]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $129 million for fiscal 2014, $185 million for fiscal 2013, and $227 million for fiscal 2012.

[0000858877-14-000029:notes:68]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at July 26, 2014 and July 27, 2013, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-14-000029:notes:69]
|  | July 26, 2014 |  | July 27, 2013 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 263 |  |  | $ | 438 |  |
| End user | 202 |  |  | 237 |  |
| Total | $ | 465 |  |  | $ | 675 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (127 | ) |  | $ | (225 | ) |
| End user | (166 | ) |  | (191 | ) |
| Total | $ | (293 | ) |  | $ | (416 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 172 |  |  | $ | 259 |  |

[0000858877-14-000029:notes:70]
Other Guarantees   The Company’s other guarantee arrangements as of July 26, 2014 and July 27, 2013 that were subject to recognition and disclosure requirements were not material.

[0000858877-14-000029:notes:71]
| (f) | Supplier Component Remediation Liability |

[0000858877-14-000029:notes:72]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components are widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low. However, recently the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products are beyond the Company's warranty terms, the Company is proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in an additional charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  As of July 26, 2014, the remaining supplier component remediation liability was $670 million.

[0000858877-14-000029:notes:73]
| (g) | Indemnifications |

[0000858877-14-000029:notes:74]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-14-000029:notes:75]
The Company has an obligation to indemnify certain expenses pursuant to such agreements in a case involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) in the United States District Court for the District of Kansas filed on December 19, 2011 (including one case that was later transferred to the District of Delaware).  Sprint alleges that the service providers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers.  Sprint is seeking monetary damages.  Trial dates have been set for the first half of calendar year 2015.  The parties intend to conduct a mediation later this calendar year, and the Company may be asked to participate.  The mediation could result in a resolution of the case for some or all of the Company's service provider customers.  The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should the plaintiff prevail in litigation, mediation, or settlement, the Company may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

[0000858877-14-000029:notes:76]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-14-000029:notes:77]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-14-000029:notes:78]
| (h) | Legal Proceedings |

[0000858877-14-000029:notes:79]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. In the first quarter of fiscal 2013, the Brazilian federal tax authorities asserted an additional claim against the Company’s Brazilian subsidiary based on a theory of joint liability with respect to an alleged underpayment of income taxes, social taxes, interest, and penalties by a Brazilian distributor.

[0000858877-14-000029:notes:80]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $389 million for the alleged evasion of import and other taxes, approximately $1.3 billion for interest, and approximately $1.7 billion for various penalties, all determined using an exchange rate as of July 26, 2014. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

[0000858877-14-000029:notes:81]
Russia and the Commonwealth of Independent States    At the request of the U.S. Securities and Exchange Commission (SEC) and the U.S. Department of Justice, the Company is conducting an investigation into allegations which the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries.  The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the SEC and the Department of Justice.  While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows. The countries that are the subject of the investigation collectively comprise less than 2% of the Company’s revenues.

[0000858877-14-000029:notes:82]
Rockstar    The Company and some of its service provider customers are subject to patent claims asserted in December 2013 in the Eastern District of Texas and the District of Delaware by subsidiaries of the Rockstar Consortium ("Rockstar").  Rockstar, whose members include Apple, Microsoft, LM Ericsson, Sony, and Blackberry, purchased a portfolio of patents out of the Nortel Networks’ bankruptcy proceedings (the “Nortel Portfolio”). Rockstar’s subsidiaries allege that some of the Company’s NGN Routing, Switching and Collaboration products, as well as video solutions deployed by its service provider customers, infringe some of the patents in the Nortel Portfolio.  Rockstar seeks monetary damages.  A trial date for one service provider customer has been set for October 2015; no other trial dates have been set.  The Company has various defenses to the patent infringement allegations, and has various offensive claims against Rockstar and some of its consortium members available to it as well, and the Company will also explore alternative means of resolution.   Due to the uncertainty surrounding the litigation process, which involves numerous lawsuits and parties, the Company is unable to reasonably estimate the ultimate outcome and a range of loss, if any, of these litigations at this time.

[0000858877-14-000029:notes:83]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0000858877-14-000029:notes:84]
(q) Share-Based Compensation Expense   The Company measures and recognizes the compensation expense for all share-based awards made to employees and directors, including employee stock options, stock grants, stock units, and employee stock purchases related to the Employee Stock Purchase Plan (“Employee Stock Purchase Rights”) based on estimated fair values. The fair value of employee stock options is estimated on the date of grant using a lattice-binomial option-pricing model (“Lattice-Binomial Model”) or the Black-Scholes model, and for employee stock purchase rights the Company estimates the fair value using the Black-Scholes model. The fair value for time-based stock awards and stock awards that are contingent upon the achievement of financial performance metrics is based on the grant date share price reduced by the present value of the expected dividend yield prior to vesting. The fair value of market-based stock awards is estimated using an option-pricing model on the date of grant. Share-based compensation expense is reduced for forfeitures.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-14-000029:notes:85]
| 15. | Comprehensive Income |

[0000858877-14-000029:notes:86]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest are summarized as follows (in millions):

[0000858877-14-000029:notes:87]
|  | Net Unrealized Gains on Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Other |  | Accumulated Other Comprehensive Income |
| BALANCE AT JULY 30, 2011 | $ | 487 |  |  | $ | 6 |  |  | $ | 801 |  |  | $ | 1,294 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (19 | ) |  | (131 | ) |  | (532 | ) |  | (682 | ) |
| (Gains) losses reclassified out of other comprehensive income | (101 | ) |  | 72 |  |  | — |  |  | (29 | ) |
| Tax benefit (expense) | 42 |  |  | — |  |  | 36 |  |  | 78 |  |
| BALANCE AT JULY 28, 2012 | 409 |  |  | (53 | ) |  | 305 |  |  | 661 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 3 |  |  | 74 |  |  | (83 | ) |  | (6 | ) |
| (Gains) losses reclassified out of other comprehensive income | (48 | ) |  | (12 | ) |  | — |  |  | (60 | ) |
| Tax benefit (expense) | 15 |  |  | (1 | ) |  | (1 | ) |  | 13 |  |
| BALANCE AT JULY 27, 2013 | 379 |  |  | 8 |  |  | 221 |  |  | 608 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 380 |  |  | 48 |  |  | 49 |  |  | 477 |  |
| (Gains) losses reclassified out of other comprehensive income | (300 | ) |  | (68 | ) |  | — |  |  | (368 | ) |
| Tax benefit (expense) | (35 | ) |  | — |  |  | (5 | ) |  | (40 | ) |
| BALANCE AT JULY 26, 2014 | $ | 424 |  |  | $ | (12 | ) |  | $ | 265 |  |  | $ | 677 |  |

[0000858877-14-000029:notes:88]
The net gains (losses) reclassified out of other comprehensive income into the Consolidated Statements of Operations, with line item location, during each period were as follows (in millions):

[0000858877-14-000029:notes:89]
|  |  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains on available-for-sale investments |  |  |  |  |  |  |  |  |
|  |  | $ | 300 |  |  | $ | 48 |  |  | $ | 101 |  |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | 55 |  |  | 10 |  |  | (59 | ) |  | Operating expenses |
| Foreign currency derivatives |  | 13 |  |  | 2 |  |  | (14 | ) |  | Cost of sales—service |
| Interest rate derivatives |  | — |  |  | — |  |  | 1 |  |  | Interest expense |
|  |  | 68 |  |  | 12 |  |  | (72 | ) |  |  |
| Total amounts reclassified out of other comprehensive income |  | $ | 368 |  |  | $ | 60 |  |  | $ | 29 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-14-000029:notes:90]
| 10. | Borrowings |

[0000858877-14-000029:notes:91]
| (a) | Short-Term Debt |

[0000858877-14-000029:notes:92]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-14-000029:notes:93]
|  | July 26, 2014 |  | July 27, 2013 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 500 |  |  | 3.11 | % |  | $ | 3,273 |  |  | 0.63 | % |
| Other notes and borrowings | 8 |  |  | 2.67 | % |  | 10 |  |  | 2.52 | % |
| Total short-term debt | $ | 508 |  |  |  |  | $ | 3,283 |  |  |  |

[0000858877-14-000029:notes:94]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. In the third quarter of fiscal 2014, the Company issued and repaid $1.0 billion of indebtedness under commercial paper and had no commercial paper notes outstanding as of each of July 26, 2014 and July 27, 2013.

[0000858877-14-000029:notes:95]
The effective interest rate on the current portion of long-term debt includes the impact of interest rate swaps, as discussed further in "

[0000858877-14-000029:notes:96]
| (b) | Long-Term Debt |

[0000858877-14-000029:notes:97]
."  The Company repaid senior floating-rate and fixed-rate notes upon their maturity in the third quarter of fiscal 2014 for an aggregate principal amount of $3.3 billion.  Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements.  These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.

[0000858877-14-000029:notes:98]
(b)

[0000858877-14-000029:notes:99]
Long-Term Debt

[0000858877-14-000029:notes:100]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-14-000029:notes:101]
|  |  |  | July 26, 2014 |  | July 27, 2013 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.25% | March 14, 2014 |  | $ | — |  |  | — |  | $ | 1,250 |  |  | 0.62% |
| Three-month LIBOR plus 0.05% | September 3, 2015 | (1) | 850 |  |  | 0.35% |  | — |  |  | — |
| Three-month LIBOR plus 0.28% | March 3, 2017 | (1) | 1,000 |  |  | 0.56% |  | — |  |  | — |
| Three-month LIBOR plus 0.50% | March 1, 2019 | (1) | 500 |  |  | 0.78% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.625% | March 14, 2014 |  | — |  |  | — |  | 2,000 |  |  | 0.64% |
| 2.90% | November 17, 2014 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.04% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 | (1) | 2,400 |  |  | 0.56% |  | — |  |  | — |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.79% |  | 750 |  |  | 0.84% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 | (1) | 1,750 |  |  | 0.77% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2.98% |  | 2,500 |  |  | 4.15% |
| 2.90% | March 4, 2021 | (1) | 500 |  |  | 0.93% |  | — |  |  | — |
| 3.625% | March 4, 2024 | (1) | 1,000 |  |  | 1.05% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 4 |  |  | 2.39% |  | 21 |  |  | 1.46% |
| Total |  |  | 20,754 |  |  |  |  | 16,021 |  |  |  |
| Unaccreted discount |  |  | (63 | ) |  |  |  | (65 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 210 |  |  |  |  | 245 |  |  |  |
| Total |  |  | $ | 20,901 |  |  |  |  | $ | 16,201 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 500 |  |  |  |  | $ | 3,273 |  |  |  |
| Long-term debt |  |  | 20,401 |  |  |  |  | 12,928 |  |  |  |
| Total |  |  | $ | 20,901 |  |  |  |  | $ | 16,201 |  |  |  |

[0000858877-14-000029:notes:102]
(1) In March 2014, the Company issued senior notes for an aggregate principal amount of $8.0 billion.

[0000858877-14-000029:notes:103]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps with an aggregate notional amount of $10.4 billion designated as fair value hedges of certain of its fixed-rate senior notes. In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 11.

[0000858877-14-000029:notes:104]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount, and, if applicable, adjustments related to hedging. Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

[0000858877-14-000029:notes:105]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of July 26, 2014, the Company was in compliance with all debt covenants.

[0000858877-14-000029:notes:106]
As of July 26, 2014, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-14-000029:notes:107]
| Fiscal Year | Amount |
| 2015 | $ | 500 |  |
| 2016 | 3,853 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| 2019 | 4,250 |  |
| Thereafter | 8,000 |  |
| Total | $ | 20,754 |  |

[0000858877-14-000029:notes:108]
| (c) | Credit Facility |

[0000858877-14-000029:notes:109]
On February 17, 2012, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on February 17, 2017. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the higher of the Federal Funds rate plus 0.50%, Bank of America’s “prime rate” as announced from time to time, or one-month LIBOR plus 1.00% or (ii) LIBOR plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc. The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement. As of July 26, 2014, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.

[0000858877-14-000029:notes:110]
The Company may also, upon the agreement of either the existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility by up to two additional years, or up to February 17, 2019.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-14-000029:notes:111]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 9,640 |  |  | $ | 9,403 |  |
| Product: |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  | 3,924 |  |  | 3,340 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  | 578 |  |  | 680 |  |
| Total product deferred revenue |  | 4,502 |  |  | 4,020 |  |
| Total |  | $ | 14,142 |  |  | $ | 13,423 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,478 |  |  | $ | 9,262 |  |
| Noncurrent |  | 4,664 |  |  | 4,161 |  |
| Total |  | $ | 14,142 |  |  | $ | 13,423 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-14-000029:notes:112]
| 11. | Derivative Instruments |

[0000858877-14-000029:notes:113]
| (a) | Summary of Derivative Instruments |

[0000858877-14-000029:notes:114]
The Company uses derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. The Company’s primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. The Company’s derivatives expose it to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. The Company does, however, seek to mitigate such risks by limiting its counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-14-000029:notes:115]
The fair values of the Company’s derivative instruments and the line items on the Consolidated Balance Sheets to which they were recorded are summarized as follows (in millions):

[0000858877-14-000029:notes:116]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | July 26, 2014 |  | July 27, 2013 |  | Balance Sheet Line Item |  | July 26, 2014 |  | July 27, 2013 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 7 |  |  | $ | 33 |  |  | Other current liabilities |  | $ | 6 |  |  | $ | 7 |  |
| Interest rate derivatives | Other assets |  | 148 |  |  | 147 |  |  | Other long-term liabilities |  | 3 |  |  | 2 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 56 |  |  | 155 |  |
| Total |  |  | 155 |  |  | 180 |  |  |  |  | 65 |  |  | 164 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 3 |  |  | 2 |  |  | Other current liabilities |  | 2 |  |  | 7 |  |
| Equity derivatives | Other assets |  | 2 |  |  | — |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 5 |  |  | 2 |  |  |  |  | 2 |  |  | 7 |  |
| Total |  |  | $ | 160 |  |  | $ | 182 |  |  |  |  | $ | 67 |  |  | $ | 171 |  |

[0000858877-14-000029:notes:117]
The effects of the Company’s cash flow and net investment hedging instruments on other comprehensive income (OCI) and the Consolidated Statements of Operations are summarized as follows (in millions):

[0000858877-14-000029:notes:118]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FORTHE YEARS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FORTHE YEARS ENDED (EFFECTIVE PORTION) |
|  |  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |  | Line Item in Statements of Operations |  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 48 |  |  | $ | 73 |  |  | $ | (131 | ) |  | Operating expenses |  | $ | 55 |  |  | $ | 10 |  |  | $ | (59 | ) |
|  |  |  |  |  |  |  |  | Cost of sales—service |  | 13 |  |  | 2 |  |  | (14 | ) |
| Interest rate derivatives |  | — |  |  | — |  |  | — |  |  | Interest expense |  | — |  |  | — |  |  | 1 |  |
| Total |  | $ | 48 |  |  | $ | 73 |  |  | $ | (131 | ) |  |  |  | $ | 68 |  |  | $ | 12 |  |  | $ | (72 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (15 | ) |  | $ | (1 | ) |  | $ | 23 |  |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000858877-14-000029:notes:119]
As of July 26, 2014, the Company estimates that approximately $0.2 million of net derivative losses related to its cash flow hedges included in accumulated other comprehensive income (AOCI) will be reclassified into earnings within the next 12 months.

[0000858877-14-000029:notes:120]
The effect on the Consolidated Statements of Operations of derivative instruments designated as fair value hedges and the underlying hedged items is summarized as follows (in millions):

[0000858877-14-000029:notes:121]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THEYEARS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE YEARSENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Equity derivatives |  | Other income (loss), net |  | $ | (72 | ) |  | $ | (155 | ) |  | $ | (4 | ) |  | $ | 72 |  |  | $ | 155 |  |  | $ | 4 |  |
| Interest rate derivatives |  | Interest expense |  | (2 | ) |  | (78 | ) |  | 78 |  |  | — |  |  | 78 |  |  | (80 | ) |
| Total |  |  |  | $ | (74 | ) |  | $ | (233 | ) |  | $ | 74 |  |  | $ | 72 |  |  | $ | 233 |  |  | $ | (76 | ) |

[0000858877-14-000029:notes:122]
The effect on the Consolidated Statements of Operations of derivative instruments not designated as hedges is summarized as follows (in millions):

[0000858877-14-000029:notes:123]
|  |  |  |  | GAINS (LOSSES) FOR THEYEARS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | 23 |  |  | $ | (74 | ) |  | $ | (206 | ) |
| Total return swaps—deferred compensation |  | Cost of sales—product |  | — |  |  | — |  |  | 4 |  |
| Total return swaps—deferred compensation |  | Operating expenses |  | 47 |  |  | 61 |  |  | 3 |  |
| Equity derivatives |  | Other income (loss), net |  | 34 |  |  | — |  |  | 6 |  |
| Total |  |  |  | $ | 104 |  |  | $ | (13 | ) |  | $ | (193 | ) |

[0000858877-14-000029:notes:124]
The notional amounts of the Company’s outstanding derivatives are summarized as follows (in millions):

[0000858877-14-000029:notes:125]
|  | July 26, 2014 |  | July 27, 2013 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 1,618 |  |  | $ | 1,885 |  |
| Interest rate derivatives | 10,400 |  |  | 5,250 |  |
| Net investment hedging instruments | 345 |  |  | 662 |  |
| Equity derivatives | 238 |  |  | 1,098 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,528 |  |  | 3,739 |  |
| Total return swaps—deferred compensation | 428 |  |  | 358 |  |
| Total | $ | 15,557 |  |  | $ | 12,992 |  |

[0000858877-14-000029:notes:126]
| (b) | Offsetting of Derivative Instruments |

[0000858877-14-000029:notes:127]
The Company presents its derivative instruments at gross fair values in the Consolidated Balance Sheets.  However, the Company’s master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty.  To further limit credit risk, the Company also enters into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument.   Information related to these offsetting arrangements is summarized as follows (in millions):

[0000858877-14-000029:notes:128]
|  | OFFSETTING OF DERIVATIVE ASSETS |
|  | Gross Amounts Offset in Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
| July 26, 2014 | Gross Amount of Recognized Assets |  | Gross Amounts Offset in Consolidated Balance Sheets |  | Net Amount Presented on Consolidated Balance Sheets |  | Gross Derivative Amounts with Legal Rights to Offset |  | Cash Collateral Received |  | Net Amount |
| Derivatives | $ | 160 |  |  | $ | — |  |  | $ | 160 |  |  | $ | (39 | ) |  | $ | (60 | ) |  | $ | 61 |  |

[0000858877-14-000029:notes:129]
|  | OFFSETTING OF DERIVATIVE LIABILITIES |
|  | Gross Amounts Offset in Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
| July 26, 2014 | Gross Amount of Recognized Liabilities |  | Gross Amounts Offset in Consolidated Balance Sheets |  | Net Amount Presented on Consolidated Balance Sheets |  | Gross Derivative Amounts with Legal Rights to Offset |  | Cash Collateral Pledged |  | Net Amount |
| Derivatives | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |  | $ | (39 | ) |  | $ | (1 | ) |  | $ | 27 |  |

[0000858877-14-000029:notes:130]
|  | OFFSETTING OF DERIVATIVE ASSETS |
|  | Gross Amounts Offset in Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
| July 27, 2013 | Gross Amount of Recognized Assets |  | Gross Amounts Offset in Consolidated Balance Sheets |  | Net Amount Presented on Consolidated Balance Sheets |  | Gross Derivative Amounts with Legal Rights to Offset |  | Cash Collateral Received |  | Net Amount |
| Derivatives | $ | 182 |  |  | $ | — |  |  | $ | 182 |  |  | $ | (120 | ) |  | $ | — |  |  | $ | 62 |  |

[0000858877-14-000029:notes:131]
|  | OFFSETTING OF DERIVATIVE LIABILITIES |
|  | Gross Amounts Offset in Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
| July 27, 2013 | Gross Amount of Recognized Liabilities |  | Gross Amounts Offset in Consolidated Balance Sheets |  | Net Amount Presented on Consolidated Balance Sheets |  | Gross Derivative Amounts with Legal Rights to Offset |  | Cash Collateral Pledged |  | Net Amount |
| Derivatives | $ | 171 |  |  | $ | — |  |  | $ | 171 |  |  | $ | (120 | ) |  | $ | — |  |  | $ | 51 |  |

[0000858877-14-000029:notes:132]
| (c) | Foreign Currency Exchange Risk |

[0000858877-14-000029:notes:133]
The Company conducts business globally in numerous currencies. Therefore, it is exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, the Company enters into foreign currency contracts. The Company does not enter into such contracts for trading purposes.

[0000858877-14-000029:notes:134]
The Company hedges forecasted foreign currency transactions related to certain operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 18 months. The Company assesses effectiveness based on changes in total fair value of the derivatives. The effective portion of the derivative instrument’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion, if any, of the gain or loss is reported in earnings immediately. During the fiscal years presented, the Company did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-14-000029:notes:135]
The Company enters into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, including long-term customer financings, investments, and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of intercompany balances or other current assets, investments, or liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-14-000029:notes:136]
The Company hedges certain net investments in its foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on the Company’s net investment in those foreign subsidiaries. These derivative instruments generally have maturities of up to six months.

[0000858877-14-000029:notes:137]
| (d) | Interest Rate Risk |

[0000858877-14-000029:notes:138]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of July 26, 2014 and July 27, 2013, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-14-000029:notes:139]
Interest Rate Derivatives Designated as Fair Value Hedge, Long-Term Debt   In fiscal 2014 and 2013, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due on various dates from 2017 through 2024. In the previous periods, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in 2016 and 2017. Under these interest rate swaps, the Company receives fixed-rate interest payments and makes interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps was reflected in other assets and other long-term liabilities.

[0000858877-14-000029:notes:140]
| (e) | Equity Price Risk |

[0000858877-14-000029:notes:141]
The Company may hold equity securities for strategic purposes or to diversify its overall investment portfolio. The publicly traded equity securities in the Company’s portfolio are subject to price risk. To manage its exposure to changes in the fair value of certain equity securities, the Company has entered into equity derivatives that are designated as fair value hedges. The changes in the value of the hedging instruments are included in other income (loss), net, and offset the change in the fair value of the underlying hedged investment. In addition, the Company periodically enters into equity derivatives that are not designated as accounting hedges. The changes in the fair value of these derivatives are also included in other income (loss), net.

[0000858877-14-000029:notes:142]
The Company is also exposed to variability in compensation charges related to certain deferred compensation obligations to employees. Although not designated as accounting hedges, the Company utilizes derivatives such as total return swaps to economically hedge this exposure.

[0000858877-14-000029:notes:143]
| (f) | Hedge Effectiveness |

[0000858877-14-000029:notes:144]
For the fiscal years presented, amounts excluded from the assessment of hedge effectiveness were not material for fair value, cash flow, and net investment hedges. In addition, hedge ineffectiveness for fair value, cash flow, and net investment hedges was not material for any of the fiscal years presented.

[0000858877-14-000029:notes:145]
| (g) | Collateral and Credit-Risk-Related Contingent Features |

[0000858877-14-000029:notes:146]
For certain derivative instruments, the Company and its counterparties have entered into arrangements requiring the party that is in a liability position from a mark-to-market standpoint to post cash collateral to the other party.  See further discussion under "(b) Offsetting of Derivative Instruments" above.

[0000858877-14-000029:notes:147]
In addition, certain derivative instruments are executed under agreements that have provisions requiring the Company and the counterparty to maintain a specified credit rating from certain credit-rating agencies. Under such agreements, if the Company’s or the counterparty’s credit rating falls below a specified credit rating, either party has the right to request collateral on the derivatives’ net liability position. The fair market value of these derivatives that are in a net liability position as of July 26, 2014 was $3 million.  There was no such balance as of July 27, 2013.


## us-gaap:DerivativesPolicyTextBlock

[0000858877-14-000029:notes:148]
(l) Derivative Instruments   The Company recognizes derivative instruments as either assets or liabilities and measures those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the effective portion of the derivative’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion of the gain or loss is reported in earnings immediately.  For a derivative instrument designated as a net investment hedge of the Company’s foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. Any ineffective portion of the net investment hedges is reported in earnings during the period of change. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. The Company records derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.

[0000858877-14-000029:notes:149]
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item.  Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item.   For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value.  Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-14-000029:notes:150]
| 14. | Employee Benefit Plans |

[0000858877-14-000029:notes:151]
| (a) | Employee Stock Incentive Plans |

[0000858877-14-000029:notes:152]
Stock Incentive Plan Program Description    As of July 26, 2014, the Company had four stock incentive plans: the 2005 Stock Incentive Plan (the “2005 Plan”); the 1996 Stock Incentive Plan (the “1996 Plan”); the Cisco Systems, Inc. SA Acquisition Long-Term Incentive Plan (the “SA Acquisition Plan”); and the Cisco Systems, Inc. WebEx Acquisition Long-Term Incentive Plan (the “WebEx Acquisition Plan”). In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company. The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors. Since the inception of the stock incentive plans, the Company has granted share-based awards to a significant percentage of its employees, and the majority has been granted to employees below the vice president level. The Company’s primary stock incentive plans are summarized as follows:

[0000858877-14-000029:notes:153]
2005 Plan    As of July 26, 2014, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus the number of any shares underlying awards outstanding on November 15, 2007 under the 1996 Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that are forfeited or are terminated for any other reason before being

[0000858877-14-000029:notes:154]
exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan.  Starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-14-000029:notes:155]
Pursuant to an amendment approved by the Company’s shareholders on November 12, 2009, the number of shares available for issuance under the 2005 Plan is reduced by 1.5 shares for each share awarded as a stock grant or a stock unit, and any shares underlying awards outstanding under the 1996 Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that expire unexercised at the end of their maximum terms become available for reissuance under the 2005 Plan. The 2005 Plan permits the granting of stock options, restricted stock, and restricted stock units (RSUs), the vesting of which may be performance-based or market-based along with the requisite service requirement, and stock appreciation rights to employees (including employee directors and officers), consultants of the Company and its subsidiaries and affiliates, and non-employee directors of the Company. Stock options and stock appreciation rights granted under the 2005 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date and prior to November 12, 2009 have an expiration date no later than nine years from the grant date. The expiration date for stock options and stock appreciation rights granted subsequent to the amendment approved on November 12, 2009 shall be no later than 10 years from the grant date.

[0000858877-14-000029:notes:156]
The stock options will generally become exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively. Time-based stock grants and time-based RSUs will generally vest with respect to 20% or 25% of the shares or share units covered by the grant on each of the first through fifth or fourth anniversaries of the date of the grant, respectively. Performance-based and market-based RSUs typically vest at the end of the three-year requisite service period or earlier if the award recipient meets certain retirement eligibility conditions. The Compensation and Management Development Committee of the Board of Directors has the discretion to use different vesting schedules. Stock appreciation rights may be awarded in combination with stock options or stock grants, and such awards shall provide that the stock appreciation rights will not be exercisable unless the related stock options or stock grants are forfeited. Stock grants may be awarded in combination with non-statutory stock options, and such awards may provide that the stock grants will be forfeited in the event that the related non-statutory stock options are exercised.

[0000858877-14-000029:notes:157]
1996 Plan   The 1996 Plan expired on December 31, 2006, and the Company can no longer make equity awards under the 1996 Plan. The maximum number of shares issuable over the term of the 1996 Plan was 2.5 billion shares. Stock options granted under the 1996 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date and expire no later than nine years from the grant date. The stock options generally became exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively.  Certain other grants utilized a 60-month ratable vesting schedule. In addition, the Board of Directors, or other committees administering the 1996 Plan, had the discretion to use a different vesting schedule and did so from time to time.

[0000858877-14-000029:notes:158]
Acquisition Plans In connection with the Company’s acquisitions of Scientific-Atlanta, Inc. (“Scientific-Atlanta”) and WebEx Communications, Inc. (“WebEx”), the Company adopted the SA Acquisition Plan and the WebEx Acquisition Plan, respectively, each effective upon completion of the applicable acquisition. These plans constitute assumptions, amendments, restatements, and renamings of the 2003 Long-Term Incentive Plan of Scientific-Atlanta and the WebEx Communications, Inc. Amended and Restated 2000 Stock Incentive Plan, respectively. The plans permit the grant of stock options, stock, stock units, and stock appreciation rights to certain employees of the Company and its subsidiaries and affiliates who had been employed by Scientific-Atlanta or its subsidiaries or WebEx or its subsidiaries, as applicable. As a result of the shareholder approval of the amendment and extension of the 2005 Plan, as of November 15, 2007, the Company will no longer make stock option grants or direct share issuances under either the SA Acquisition Plan or the WebEx Acquisition Plan.

[0000858877-14-000029:notes:159]
| (b) | Employee Stock Purchase Plan |

[0000858877-14-000029:notes:160]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 471.4 million shares of the Company’s common stock have been reserved for issuance as of July 26, 2014. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. The Purchase Plan is scheduled to terminate on January 3, 2020. The Company issued 27 million, 36 million, and 35 million shares under the Purchase Plan in fiscal 2014, 2013, and 2012, respectively. As of July 26, 2014, 25 million shares were available for issuance under the Purchase Plan.

[0000858877-14-000029:notes:161]
| (c) | Summary of Share-Based Compensation Expense |

[0000858877-14-000029:notes:162]
Share-based compensation expense consists primarily of expenses for stock options, stock purchase rights, restricted stock, and restricted stock units granted to employees. The following table summarizes share-based compensation expense (in millions):

[0000858877-14-000029:notes:163]
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Cost of sales—product | $ | 45 |  |  | $ | 40 |  |  | $ | 53 |  |
| Cost of sales—service | 150 |  |  | 138 |  |  | 156 |  |
| Share-based compensation expense in cost of sales | 195 |  |  | 178 |  |  | 209 |  |
| Research and development | 411 |  |  | 286 |  |  | 401 |  |
| Sales and marketing | 549 |  |  | 484 |  |  | 588 |  |
| General and administrative | 198 |  |  | 175 |  |  | 203 |  |
| Restructuring and other charges | (5 | ) |  | (3 | ) |  | — |  |
| Share-based compensation expense in operating expenses | 1,153 |  |  | 942 |  |  | 1,192 |  |
| Total share-based compensation expense | $ | 1,348 |  |  | $ | 1,120 |  |  | $ | 1,401 |  |
| Income tax benefit for share-based compensation | $ | 324 |  |  | $ | 285 |  |  | $ | 335 |  |

[0000858877-14-000029:notes:164]
As of July 26, 2014, the total compensation cost related to unvested share-based awards not yet recognized was $2.4 billion, which is expected to be recognized over approximately 2.3 years on a weighted-average basis.

[0000858877-14-000029:notes:165]
| (d) | Share-Based Awards Available for Grant |

[0000858877-14-000029:notes:166]
A summary of share-based awards available for grant is as follows (in millions):

[0000858877-14-000029:notes:167]
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Balance at beginning of fiscal year | 228 |  |  | 218 |  |  | 255 |  |
| Restricted stock, stock units, and other share-based awards granted | (98 | ) |  | (102 | ) |  | (95 | ) |
| Share-based awards canceled/forfeited/expired | 36 |  |  | 115 |  |  | 64 |  |
| Additional shares reserved | 135 |  |  | — |  |  | — |  |
| Shares withheld for taxes and not issued | 6 |  |  | — |  |  | — |  |
| Other | 3 |  |  | (3 | ) |  | (6 | ) |
| Balance at end of fiscal year | 310 |  |  | 228 |  |  | 218 |  |

[0000858877-14-000029:notes:168]
As reflected in the preceding table, for each share awarded as restricted stock or subject to a restricted stock unit award under the 2005 Plan, an equivalent of 1.5 shares was deducted from the available share-based award balance. For restricted stock units that were awarded with vesting contingent upon the achievement of future financial performance or market-based metrics, the maximum awards that can be achieved upon full vesting of such awards were reflected in the preceding table.

[0000858877-14-000029:notes:169]
| (e) | Restricted Stock and Stock Unit Awards |

[0000858877-14-000029:notes:170]
A summary of the restricted stock and stock unit activity, which includes time-based and performance-based or market-based restricted stock units, is as follows (in millions, except per-share amounts):

[0000858877-14-000029:notes:171]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregated FairMarket Value |
| UNVESTED BALANCE AT JULY 30, 2011 | 116 |  |  | $ | 21.50 |  |  |  |
| Granted and assumed | 65 |  |  | 17.45 |  |  |  |
| Vested | (35 | ) |  | 21.94 |  |  | $ | 580 |  |
| Canceled/forfeited | (18 | ) |  | 20.38 |  |  |  |
| UNVESTED BALANCE AT JULY 28, 2012 | 128 |  |  | 19.46 |  |  |  |
| Granted and assumed | 72 |  |  | 18.52 |  |  |  |
| Vested | (46 | ) |  | 20.17 |  |  | $ | 932 |  |
| Canceled/forfeited | (11 | ) |  | 18.91 |  |  |  |
| UNVESTED BALANCE AT JULY 27, 2013 | 143 |  |  | 18.80 |  |  |  |
| Granted and assumed | 72 |  |  | 20.85 |  |  |  |
| Vested | (53 | ) |  | 19.55 |  |  | $ | 1,229 |  |
| Canceled/forfeited | (13 | ) |  | 18.61 |  |  |  |
| UNVESTED BALANCE AT JULY 26, 2014 | 149 |  |  | $ | 19.54 |  |  |  |

[0000858877-14-000029:notes:172]
| (f) | Stock Option Awards |

[0000858877-14-000029:notes:173]
A summary of the stock option activity is as follows (in millions, except per-share amounts):

[0000858877-14-000029:notes:174]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 30, 2011 | 621 |  |  | $ | 21.79 |  |
| Assumed from acquisitions | 1 |  |  | 2.08 |  |
| Exercised | (66 | ) |  | 13.51 |  |
| Canceled/forfeited/expired | (36 | ) |  | 23.40 |  |
| BALANCE AT JULY 28, 2012 | 520 |  |  | 22.68 |  |
| Assumed from acquisitions | 10 |  |  | 0.77 |  |
| Exercised | (154 | ) |  | 18.51 |  |
| Canceled/forfeited/expired | (100 | ) |  | 22.18 |  |
| BALANCE AT JULY 27, 2013 | 276 |  |  | 24.44 |  |
| Assumed from acquisitions | 6 |  |  | 3.60 |  |
| Exercised | (78 | ) |  | 18.30 |  |
| Canceled/forfeited/expired | (17 | ) |  | 27.53 |  |
| BALANCE AT JULY 26, 2014 | 187 |  |  | $ | 26.03 |  |

[0000858877-14-000029:notes:175]
The total pretax intrinsic value of stock options exercised during fiscal 2014, 2013, and 2012 was $458 million, $661 million, and $333 million, respectively.

[0000858877-14-000029:notes:176]
The following table summarizes significant ranges of outstanding and exercisable stock options as of July 26, 2014 (in millions, except years and share prices):

[0000858877-14-000029:notes:177]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 15.00 |  | 8 |  |  | 5.2 |  | $ | 4.00 |  |  | $ | 172 |  |  | 4 |  |  | $ | 5.54 |  |  | $ | 85 |  |
| 15.01 – 18.00 |  | 11 |  |  | 0.3 |  | 17.79 |  |  | 93 |  |  | 11 |  |  | 17.79 |  |  | 93 |  |
| 18.01 – 20.00 |  | 3 |  |  | 0.7 |  | 19.38 |  |  | 20 |  |  | 3 |  |  | 19.38 |  |  | 20 |  |
| 20.01 – 25.00 |  | 62 |  |  | 1.2 |  | 22.86 |  |  | 192 |  |  | 62 |  |  | 22.86 |  |  | 192 |  |
| 25.01 – 30.00 |  | 27 |  |  | 1.9 |  | 26.59 |  |  | 4 |  |  | 27 |  |  | 26.59 |  |  | 4 |  |
| 30.01 – 35.00 |  | 76 |  |  | 2.0 |  | 32.16 |  |  | — |  |  | 76 |  |  | 32.16 |  |  | — |  |
| Total |  | 187 |  |  | 1.7 |  | $ | 26.03 |  |  | $ | 481 |  |  | 183 |  |  | $ | 26.50 |  |  | $ | 394 |  |

[0000858877-14-000029:notes:178]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on the Company’s closing stock price of $25.97 as of July 25, 2014, that would have been received by the option holders had those option holders exercised their stock options as of that date. The total number of in-the-money stock options exercisable as of July 26, 2014 was 94 million. As of July 27, 2013, 271 million outstanding stock options were exercisable and the weighted-average exercise price was $24.84.

[0000858877-14-000029:notes:179]
| (g) | Valuation of Employee Share-Based Awards |

[0000858877-14-000029:notes:180]
Time-based restricted stock units and performance-based restricted stock units (PRSUs) that are based on the Company’s financial performance metrics or non-financial operating goals are valued using the market value of the Company’s common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, the Company estimated the fair value of the total shareholder return (TSR) component of the PRSUs using a Monte Carlo simulation model. The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-14-000029:notes:181]
|  | RESTRICTED STOCK UNITS |
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Number of shares granted (in millions) | 56 |  |  | 64 |  |  | 62 |  |
| Grant date fair value per share | $ | 20.61 |  |  | $ | 18.39 |  |  | $ | 17.26 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 3.1 | % |  | 3.0 | % |  | 1.5 | % |
| Range of risk-free interest rates | 0.0% – 1.7% |  |  | 0.0% – 1.1% |  |  | 0.0% – 1.1% |  |

[0000858877-14-000029:notes:182]
|  | PERFORMANCE RESTRICTED STOCK UNITS |
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Number of shares granted (in millions) | 7 |  |  | 4 |  |  | 2 |  |
| Grant date fair value per share | $ | 21.90 |  |  | $ | 19.73 |  |  | $ | 22.17 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 3.0 | % |  | 2.9 | % |  | 1.3 | % |
| Range of risk-free interest rates | 0.0% – 1.7% |  |  | 0.1% – 0.7% |  |  | 0.0% – 0.9% |  |
| Range of expected volatilities for index | 14.2% – 70.5% |  |  | 18.3% – 78.3% |  |  | 19.8% – 60.8% |  |

[0000858877-14-000029:notes:183]
The PRSUs granted during fiscal 2014, 2013, and 2012 are contingent on the achievement of the Company’s financial performance metrics, its comparative market-based returns, or the achievement of non-financial operating goals.  For the awards based on financial performance metrics or its comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period. Generally, the remaining 50% of the PRSUs are earned based on the Company’s TSR measured against the benchmark TSR of a peer group over the same period. Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of the Company's financial performance metrics or its comparative market-based returns, and 0% or 100% of the target shares granted contingent on the achievement of non-financial operating goals.

[0000858877-14-000029:notes:184]
The assumptions for the valuation of employee stock purchase rights are summarized as follows:

[0000858877-14-000029:notes:185]
|  | EMPLOYEE STOCK PURCHASE RIGHTS |
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Weighted-average assumptions: |  |  |  |  |  |
| Expected volatility | 25.1 | % |  | 28.7 | % |  | 27.2 | % |
| Risk-free interest rate | 0.1 | % |  | 0.4 | % |  | 0.2 | % |
| Expected dividend | 2.8 | % |  | 1.5 | % |  | 1.5 | % |
| Expected life (in years) | 0.8 |  |  | 1.8 |  |  | 0.8 |  |
| Weighted-average estimated grant date fair value per share | $ | 5.54 |  |  | $ | 4.68 |  |  | $ | 3.81 |  |

[0000858877-14-000029:notes:186]
The valuation of employee stock purchase rights and the related assumptions are for the employee stock purchases made during the respective fiscal years.

[0000858877-14-000029:notes:187]
The Company uses third-party analyses to assist in developing the assumptions used in, as well as calibrating, its lattice-binomial and Black-Scholes models. The Company is responsible for determining the assumptions used in estimating the fair value of its share-based payment awards.

[0000858877-14-000029:notes:188]
The Company used the implied volatility for traded options (with contract terms corresponding to the expected life of the employee stock purchase rights) on the Company’s stock as the expected volatility assumption required in the Black-Scholes model. The implied volatility is more representative of future stock price trends than historical volatility. The risk-free interest rate assumption is based upon observed interest rates appropriate for the term of the Company’s employee stock purchase rights. The dividend yield assumption is based on the history and expectation of dividend payouts at the grant date.

[0000858877-14-000029:notes:189]
| (h) | Employee 401(k) Plans |

[0000858877-14-000029:notes:190]
The Company sponsors the Cisco Systems, Inc. 401(k) Plan (the “Plan”) to provide retirement benefits for its employees. As allowed under Section 401(k) of the Internal Revenue Code, the Plan provides for tax-deferred salary contributions and after-tax contributions for eligible employees. The Plan allows employees to contribute from 1% to 75% of their annual compensation to the Plan on a pretax and after-tax basis including Roth contributions. Employee contributions are limited to a maximum annual amount as set periodically by the Internal Revenue Code. The Company matches pretax employee contributions up to 100% of the first 4.5% of eligible earnings that are contributed by employees. Therefore, the maximum matching contribution that the Company may allocate to each participant’s account will not exceed $11,700 for the 2014 calendar year due to the $260,000 annual limit on eligible earnings imposed by the Internal Revenue Code. All matching contributions vest immediately. The Company’s matching contributions to the Plan totaled $236 million, $234 million, and $231 million in fiscal 2014, 2013, and 2012, respectively.

[0000858877-14-000029:notes:191]
The Plan allows employees who meet the age requirements and reach the Plan contribution limits to make a catch-up contribution not to exceed the lesser of 75% of their eligible compensation or the limit set forth in the Internal Revenue Code. The catch-up contributions are not eligible for matching contributions. In addition, the Plan provides for discretionary profit-sharing contributions as determined by the Board of Directors. Such contributions to the Plan are allocated among eligible participants in the proportion of their salaries to the total salaries of all participants. There were no discretionary profit-sharing contributions made in fiscal 2014, 2013, and 2012.

[0000858877-14-000029:notes:192]
The Company also sponsors other 401(k) plans that arose from acquisitions of other companies. The Company’s contributions to these plans were not material to the Company on either an individual or aggregate basis for any of the fiscal years presented.

[0000858877-14-000029:notes:193]
| (i) | Deferred Compensation Plans |

[0000858877-14-000029:notes:194]
The Cisco Systems, Inc. Deferred Compensation Plan (the “Deferred Compensation Plan”), a nonqualified deferred compensation plan, became effective in 2007. As required by applicable law, participation in the Deferred Compensation Plan is limited to a select group of the Company’s management employees. Under the Deferred Compensation Plan, which is an unfunded and unsecured deferred compensation arrangement, a participant may elect to defer base salary, bonus, and/or commissions, pursuant to such rules as may be established by the Company, up to the maximum percentages for each deferral election as described in the plan. The Company may also, at its discretion, make a matching contribution to the employee under the Deferred Compensation Plan. A matching contribution equal to 4.5% of eligible compensation in excess of the Internal Revenue Code limit for qualified plans for calendar year 2014 that is deferred by participants under the Deferred Compensation Plan (with a $1.5 million cap on eligible compensation) will be made to eligible participants’ accounts at the end of calendar year 2014. The deferred compensation liability under the Deferred Compensation Plan, together with a deferred compensation plan assumed from Scientific-Atlanta, was approximately $509 million and $441 million as of July 26, 2014 and July 27, 2013, respectively, and was recorded primarily in other long-term liabilities.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000858877-14-000029:notes:195]
(t) Computation of Net Income per Share   Basic net income per share is computed using the weighted-average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted-average number of common shares and dilutive potential common shares outstanding during the period. Diluted shares outstanding includes the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options, the amount of compensation cost for future service that the Company has not yet recognized, and the amount of tax benefits that would be recorded in additional paid-in capital when the award becomes deductible are collectively assumed to be used to repurchase shares.


## us-gaap:EarningsPerShareTextBlock

[0000858877-14-000029:notes:196]
| 18. | Net Income per Share |

[0000858877-14-000029:notes:197]
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-14-000029:notes:198]
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Net income | $ | 7,853 |  |  | $ | 9,983 |  |  | $ | 8,041 |  |
| Weighted-average shares—basic | 5,234 |  |  | 5,329 |  |  | 5,370 |  |
| Effect of dilutive potential common shares | 47 |  |  | 51 |  |  | 34 |  |
| Weighted-average shares—diluted | 5,281 |  |  | 5,380 |  |  | 5,404 |  |
| Net income per share—basic | $ | 1.50 |  |  | $ | 1.87 |  |  | $ | 1.50 |  |
| Net income per share—diluted | $ | 1.49 |  |  | $ | 1.86 |  |  | $ | 1.49 |  |
| Antidilutive employee share-based awards, excluded | 254 |  |  | 407 |  |  | 591 |  |

[0000858877-14-000029:notes:199]
Employee equity share options, unvested shares, and similar equity instruments granted by the Company are treated as potential common shares outstanding in computing diluted earnings per share. Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options, the amount of compensation cost for future service that the Company has not yet recognized, and the amount of tax benefits that would be recorded in additional paid-in capital when the award becomes deductible are collectively assumed to be used to repurchase shares.


## us-gaap:EquityMethodInvestmentsTextBlock

[0000858877-14-000029:notes:200]
|  | July 26, 2014 |  | July 27, 2013 |
| Equity method investments | $ | 630 |  |  | $ | 591 |  |
| Cost method investments | 269 |  |  | 242 |  |
| Total | $ | 899 |  |  | $ | 833 |  |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-14-000029:notes:201]
The following table presents the Company’s financial instruments and nonfinancial assets that were measured at fair value on a nonrecurring basis during the indicated periods and the related recognized gains and losses for the periods (in millions):

[0000858877-14-000029:notes:202]
|  |  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
|  |  | Net CarryingValue as of Year End |  | Total Gains (Losses) for the Year Ended |  | Net CarryingValue as of Year End |  | Total Gains (Losses) for the Year Ended |  | Net CarryingValue as of Year End |  | Total Gains (Losses) for the Year Ended |
| Assets held for sale |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | (1 | ) |  | $ | 63 |  |  | $ | (413 | ) |
| Investments in privately held companies (impaired) |  | $ | 28 |  |  | (21 | ) |  | $ | 63 |  |  | (31 | ) |  | $ | 47 |  |  | (23 | ) |
| Purchased intangible assets |  | $ | — |  |  | — |  |  | $ | — |  |  | — |  |  | $ | — |  |  | (12 | ) |
| Gains (losses) on assets no longer held at end of fiscal year |  |  |  | (2 | ) |  |  |  | 75 |  |  |  |  | 14 |  |
| Total gains (losses) for nonrecurring measurements |  |  |  | $ | (23 | ) |  |  |  | $ | 43 |  |  |  |  | $ | (434 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-14-000029:notes:203]
| 9. | Fair Value |

[0000858877-14-000029:notes:204]
| (a) | Assets and Liabilities Measured at Fair Value on a Recurring Basis |

[0000858877-14-000029:notes:205]
Assets and liabilities measured at fair value on a recurring basis as of July 26, 2014 and July 27, 2013 were as follows (in millions):

[0000858877-14-000029:notes:206]
|  | JULY 26, 2014FAIR VALUE MEASUREMENTS |  | JULY 27, 2013FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,935 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,935 |  |  | $ | 6,045 |  |  | $ | — |  |  | $ | 6,045 |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 31,734 |  |  | — |  |  | 31,734 |  |  | — |  |  | 27,823 |  |  | 27,823 |  |
| U.S. government agency securities | — |  |  | 1,063 |  |  | — |  |  | 1,063 |  |  | — |  |  | 3,089 |  |  | 3,089 |  |
| Non-U.S. government and agency securities | — |  |  | 861 |  |  | — |  |  | 861 |  |  | — |  |  | 1,095 |  |  | 1,095 |  |
| Corporate debt securities | — |  |  | 9,159 |  |  | — |  |  | 9,159 |  |  | — |  |  | 7,881 |  |  | 7,881 |  |
| U.S. agency mortgage-backed securities | — |  |  | 579 |  |  | — |  |  | 579 |  |  | — |  |  | — |  |  | — |  |
| Publicly traded equity securities | 1,952 |  |  | — |  |  | — |  |  | 1,952 |  |  | 2,797 |  |  | — |  |  | 2,797 |  |
| Derivative assets | — |  |  | 158 |  |  | 2 |  |  | 160 |  |  | — |  |  | 182 |  |  | 182 |  |
| Total | $ | 6,887 |  |  | $ | 43,554 |  |  | $ | 2 |  |  | $ | 50,443 |  |  | $ | 8,842 |  |  | $ | 40,070 |  |  | $ | 48,912 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 171 |  |  | $ | 171 |  |
| Total | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 171 |  |  | $ | 171 |  |

[0000858877-14-000029:notes:207]
Level 1 publicly traded equity securities are determined by using quoted prices in active markets for identical assets.  Level 2 fixed income securities are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. The Company uses inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of these assets and liabilities. The Company uses such pricing data as the primary input to

[0000858877-14-000029:notes:208]
make its assessments and determinations as to the ultimate valuation of its investment portfolio and has not made, during the periods presented, any material adjustments to such inputs. The Company is ultimately responsible for the financial statements and underlying estimates. The Company’s derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs. The Company did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.

[0000858877-14-000029:notes:209]
Level 3 assets include certain derivative instruments, the values of which are determined based on discounted cash flow models using inputs that the Company could not corroborate with market data.

[0000858877-14-000029:notes:210]
| (b) | Assets Measured at Fair Value on a Nonrecurring Basis |

[0000858877-14-000029:notes:211]
The assets in the preceding table were measured at fair value due to events or circumstances the Company identified as having significant impact on their fair value during the respective periods.  To arrive at the valuation of these assets, the Company considers any significant changes in the financial metrics and economic variables and also uses third-party valuation reports to assist in the valuation as necessary. These assets were classified as Level 3 assets because the Company used unobservable inputs to value them.

[0000858877-14-000029:notes:212]
The assets held for sale represent land and buildings that met the criteria to be classified as held for sale. The fair value of assets held for sale was measured with the assistance of third-party valuation models, which used discounted cash flow techniques as part of their analysis. The fair value measurement was categorized as Level 3 as significant unobservable inputs were used in the valuation report. The impairment charges as a result of the valuations, which represented the difference between the fair value less cost to sell and the carrying amount of the assets held for sale, were included in G&A expenses.

[0000858877-14-000029:notes:213]
The fair value measurement of the impaired investments was classified as Level 3 because significant unobservable inputs were used in the valuation due to the absence of quoted market prices and inherent lack of liquidity. Significant unobservable inputs, which included financial metrics of comparable private and public companies, financial condition and near-term prospects of the investees, recent  financing activities of the investees, and the investees’ capital structure as well as other economic variables, reflected the assumptions market participants would use in pricing these assets. The impairment charges, representing the difference between the net book value and the fair value as a result of the evaluation, were recorded to other income (loss), net.

[0000858877-14-000029:notes:214]
The fair value of purchased intangible assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation.  Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets.  The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge. There was no impairment charge related to purchased intangible assets during the fiscal years ended July 26, 2014 and July 27, 2013.  For the fiscal year ended July 28, 2012, such impairment charges were recorded in cost of sales and operating expenses as appropriate. See Note 4.

[0000858877-14-000029:notes:215]
| (c) | Other Fair Value Disclosures |

[0000858877-14-000029:notes:216]
The carrying value of the Company’s investments in privately held companies that were accounted for under the cost method was $269 million and $242 million as of July 26, 2014 and July 27, 2013, respectively. It was not practicable to estimate the fair value of this portfolio.

[0000858877-14-000029:notes:217]
The fair value of the Company’s short-term loan receivables and financed service contracts approximates their carrying value due to their short duration.  The aggregate carrying value of the Company’s long-term loan receivables and financed service contracts and other as of July 26, 2014 and July 27, 2013 was $2.1 billion.  The estimated fair value of the Company’s long-

[0000858877-14-000029:notes:218]
term loan receivables and financed service contracts and other approximates their carrying value. The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-14-000029:notes:219]
As of July 26, 2014 and July 27, 2013, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.  As of July 26, 2014, the fair value of the Company’s senior notes and other long-term debt was $22.4 billion with a carrying amount of $20.9 billion.  This compares to a fair value of $17.6 billion and a carrying amount of $16.2 billion as of July 27, 2013.  The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-14-000029:notes:220]
Gross receivables less unearned income categorized by the Company’s internal credit risk rating as of July 26, 2014 and July 27, 2013 are summarized as follows (in millions):

[0000858877-14-000029:notes:221]
|  | INTERNAL CREDIT RISK RATING |
| July 26, 2014 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,615 |  |  | $ | 1,538 |  |  | $ | 141 |  |  | $ | 3,294 |  |
| Loan receivables | 953 |  |  | 593 |  |  | 137 |  |  | 1,683 |  |
| Financed service contracts and other | 1,744 |  |  | 1,367 |  |  | 99 |  |  | 3,210 |  |
| Total | $ | 4,312 |  |  | $ | 3,498 |  |  | $ | 377 |  |  | $ | 8,187 |  |

[0000858877-14-000029:notes:222]
|  | INTERNAL CREDIT RISK RATING |
| July 27, 2013 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,681 |  |  | $ | 1,482 |  |  | $ | 93 |  |  | $ | 3,256 |  |
| Loan receivables | 842 |  |  | 777 |  |  | 30 |  |  | 1,649 |  |
| Financed service contracts and other | 1,876 |  |  | 1,141 |  |  | 119 |  |  | 3,136 |  |
| Total | $ | 4,399 |  |  | $ | 3,400 |  |  | $ | 242 |  |  | $ | 8,041 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-14-000029:notes:223]
| 7. | Financing Receivables and Operating Leases |

[0000858877-14-000029:notes:224]
| (a) | Financing Receivables |

[0000858877-14-000029:notes:225]
Financing receivables primarily consist of lease receivables, loan receivables, and financed service contracts and other. Lease receivables represent sales-type and direct-financing leases resulting from the sale of the Company’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Loan receivables represent financing arrangements related to the sale of the Company’s products and services, which may include additional funding for other costs associated with network installation and integration of the Company’s products and services. Lease receivables consist of arrangements with terms of four years on average, while loan receivables generally have terms of up to three years. The financed service contracts and other category includes financing receivables related to technical support and advanced services, as well as receivables related to financing of certain indirect costs associated with leases. Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one to three years.

[0000858877-14-000029:notes:226]
A summary of the Company's financing receivables is presented as follows (in millions):

[0000858877-14-000029:notes:227]
| July 26, 2014 | LeaseReceivables |  | LoanReceivables |  | FinancedServiceContracts and Other |  | Total |
| Gross | $ | 3,532 |  |  | $ | 1,683 |  |  | $ | 3,210 |  |  | $ | 8,425 |  |
| Residual value | 233 |  |  | — |  |  | — |  |  | 233 |  |
| Unearned income | (238 | ) |  | — |  |  | — |  |  | (238 | ) |
| Allowance for credit loss | (233 | ) |  | (98 | ) |  | (18 | ) |  | (349 | ) |
| Total, net | $ | 3,294 |  |  | $ | 1,585 |  |  | $ | 3,192 |  |  | $ | 8,071 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,476 |  |  | $ | 728 |  |  | $ | 1,949 |  |  | $ | 4,153 |  |
| Noncurrent | 1,818 |  |  | 857 |  |  | 1,243 |  |  | 3,918 |  |
| Total, net | $ | 3,294 |  |  | $ | 1,585 |  |  | $ | 3,192 |  |  | $ | 8,071 |  |

[0000858877-14-000029:notes:228]
| July 27, 2013 | LeaseReceivables |  | LoanReceivables |  | FinancedServiceContracts and Other |  | Total |
| Gross | $ | 3,529 |  |  | $ | 1,649 |  |  | $ | 3,136 |  |  | $ | 8,314 |  |
| Residual value | 251 |  |  | — |  |  | — |  |  | 251 |  |
| Unearned income | (273 | ) |  | — |  |  | — |  |  | (273 | ) |
| Allowance for credit loss | (238 | ) |  | (86 | ) |  | (20 | ) |  | (344 | ) |
| Total, net | $ | 3,269 |  |  | $ | 1,563 |  |  | $ | 3,116 |  |  | $ | 7,948 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,418 |  |  | $ | 898 |  |  | $ | 1,721 |  |  | $ | 4,037 |  |
| Noncurrent | 1,851 |  |  | 665 |  |  | 1,395 |  |  | 3,911 |  |
| Total, net | $ | 3,269 |  |  | $ | 1,563 |  |  | $ | 3,116 |  |  | $ | 7,948 |  |

[0000858877-14-000029:notes:229]
As of July 26, 2014 and July 27, 2013, the deferred service revenue related to the financed service contracts and other was $1,843 million and $2,036 million, respectively.

[0000858877-14-000029:notes:230]
Future minimum lease payments at July 26, 2014 are summarized as follows (in millions):

[0000858877-14-000029:notes:231]
| Fiscal Year | Amount |
| 2015 | $ | 1,608 |  |
| 2016 | 1,049 |  |
| 2017 | 590 |  |
| 2018 | 227 |  |
| 2019 | 58 |  |
| Total | $ | 3,532 |  |

[0000858877-14-000029:notes:232]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-14-000029:notes:233]
| (b) | Credit Quality of Financing Receivables |

[0000858877-14-000029:notes:234]
The Company determines the adequacy of its allowance for credit loss by assessing the risks and losses inherent in its financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by the Company to its customers, which consist of the following: lease receivables, loan receivables, and financed service contracts and other.

[0000858877-14-000029:notes:235]
The Company’s internal credit risk ratings of 1 through 4 correspond to investment-grade ratings, while credit risk ratings of 5 and 6 correspond to non-investment grade ratings. Credit risk ratings of 7 and higher correspond to substandard ratings.

[0000858877-14-000029:notes:236]
In circumstances when collectibility is not deemed reasonably assured, the associated revenue is deferred in accordance with the Company’s revenue recognition policies, and the related allowance for credit loss, if any, is included in deferred revenue. The Company also records deferred revenue associated with financing receivables when there are remaining performance obligations, as it does for financed service contracts. Total allowances for credit loss and deferred revenue as of July 26, 2014 and July 27, 2013 were $2,220 million and $2,453 million, respectively, and they were associated with total financing receivables before allowance for credit loss of $8,420 million and $8,292 million as of their respective period ends.

[0000858877-14-000029:notes:237]
The following tables present the aging analysis of gross receivables less unearned income as of July 26, 2014 and July 27, 2013 (in millions):

[0000858877-14-000029:notes:238]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 26, 2014 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 104 |  |  | $ | 43 |  |  | $ | 165 |  |  | $ | 312 |  |  | $ | 2,982 |  |  | $ | 3,294 |  |  | $ | 48 |  |  | $ | 41 |  |
| Loan receivables | 2 |  |  | 1 |  |  | 16 |  |  | 19 |  |  | 1,664 |  |  | 1,683 |  |  | 19 |  |  | 19 |  |
| Financed service contracts and other | 301 |  |  | 238 |  |  | 230 |  |  | 769 |  |  | 2,441 |  |  | 3,210 |  |  | 12 |  |  | 9 |  |
| Total | $ | 407 |  |  | $ | 282 |  |  | $ | 411 |  |  | $ | 1,100 |  |  | $ | 7,087 |  |  | $ | 8,187 |  |  | $ | 79 |  |  | $ | 69 |  |

[0000858877-14-000029:notes:239]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 27, 2013 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 85 |  |  | $ | 48 |  |  | $ | 124 |  |  | $ | 257 |  |  | $ | 2,999 |  |  | $ | 3,256 |  |  | $ | 27 |  |  | $ | 22 |  |
| Loan receivables | 6 |  |  | 3 |  |  | 11 |  |  | 20 |  |  | 1,629 |  |  | 1,649 |  |  | 11 |  |  | 9 |  |
| Financed service contracts and other | 75 |  |  | 48 |  |  | 392 |  |  | 515 |  |  | 2,621 |  |  | 3,136 |  |  | 18 |  |  | 11 |  |
| Total | $ | 166 |  |  | $ | 99 |  |  | $ | 527 |  |  | $ | 792 |  |  | $ | 7,249 |  |  | $ | 8,041 |  |  | $ | 56 |  |  | $ | 42 |  |

[0000858877-14-000029:notes:240]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables are presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract. The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $296 million and $406 million as of July 26, 2014 and July 27, 2013, respectively.

[0000858877-14-000029:notes:241]
As of July 26, 2014, the Company had financing receivables of $116 million, net of unbilled or current receivables from the same contract, that were in the category of 91 days plus past due but remained on accrual status. Such balance was $87 million as of July 27, 2013. A financing receivable may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain.

[0000858877-14-000029:notes:242]
| (c) | Allowance for Credit Loss Rollforward |

[0000858877-14-000029:notes:243]
| (d) | Operating Leases |

[0000858877-14-000029:notes:244]
The Company provides financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets.  Amounts relating to equipment on operating lease assets and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-14-000029:notes:245]
|  | July 26, 2014 |  | July 27, 2013 |
| Operating lease assets | $ | 362 |  |  | $ | 326 |  |
| Accumulated depreciation | (202 | ) |  | (203 | ) |
| Operating lease assets, net | $ | 160 |  |  | $ | 123 |  |

[0000858877-14-000029:notes:246]
Minimum future rentals on non-cancelable operating leases at July 26, 2014 are approximately $0.2 billion per year for fiscal 2015, $0.1 billion for fiscal 2016, and less than $0.1 billion per year for each of fiscal 2017 through fiscal 2019.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000858877-14-000029:notes:247]
(m) Foreign Currency Translation   Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated to U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of AOCI. Income and expense accounts are translated at average exchange rates during the year.  Remeasurement adjustments are recorded in other income (loss), net. The effect of foreign currency exchange rates on cash and cash equivalents was not material for any of the fiscal years presented.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-14-000029:notes:248]
| 4. | Goodwill and Purchased Intangible Assets |

[0000858877-14-000029:notes:249]
| (a) | Goodwill |

[0000858877-14-000029:notes:250]
The following tables present the goodwill allocated to the Company’s reportable segments as of July 26, 2014 and July 27, 2013, as well as the changes to goodwill during fiscal 2014 and 2013 (in millions):

[0000858877-14-000029:notes:251]
|  | Balance at July 27, 2013 |  |  |  | Acquisitions |  | Other |  | Balance at July 26, 2014 |
| Americas | $ | 13,800 |  |  |  |  | $ | 1,275 |  |  | $ | 5 |  |  | $ | 15,080 |  |
| EMEA | 5,037 |  |  |  |  | 681 |  |  | (3 | ) |  | 5,715 |  |
| APJC | 3,082 |  |  |  |  | 362 |  |  | — |  |  | 3,444 |  |
| Total | $ | 21,919 |  |  |  |  | $ | 2,318 |  |  | $ | 2 |  |  | $ | 24,239 |  |

[0000858877-14-000029:notes:252]
|  | Balance at July 28, 2012 |  | NDS Acquisition |  | Other Acquisitions |  | Other |  | Balance at July 27, 2013 |
| Americas | $ | 11,755 |  |  | $ | 1,230 |  |  | $ | 828 |  |  | $ | (13 | ) |  | $ | 13,800 |  |
| EMEA | 3,287 |  |  | 1,327 |  |  | 411 |  |  | 12 |  |  | 5,037 |  |
| APJC | 1,956 |  |  | 887 |  |  | 230 |  |  | 9 |  |  | 3,082 |  |
| Total | $ | 16,998 |  |  | $ | 3,444 |  |  | $ | 1,469 |  |  | $ | 8 |  |  | $ | 21,919 |  |

[0000858877-14-000029:notes:253]
| (b) | Purchased Intangible Assets |

[0000858877-14-000029:notes:254]
The following tables present details of the Company’s intangible assets acquired through business combinations completed during fiscal 2014 and 2013 (in millions, except years):

[0000858877-14-000029:notes:255]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2014 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Composite Software, Inc. | 6.0 |  | $ | 60 |  |  | 3.9 |  | $ | 14 |  |  | 0.0 |  | $ | — |  |  | $ | 1 |  |  | $ | 75 |  |
| Sourcefire, Inc. | 7.0 |  | 400 |  |  | 5.0 |  | 129 |  |  | 3.0 |  | 26 |  |  | 22 |  |  | 577 |  |
| WhipTail Technologies, Inc. | 5.0 |  | 63 |  |  | 5.0 |  | 1 |  |  | 2.7 |  | 3 |  |  | 38 |  |  | 105 |  |
| Tail-f Systems | 7.0 |  | 55 |  |  | 6.8 |  | 6 |  |  | 0.0 |  | — |  |  | — |  |  | 61 |  |
| All others (four in total) | 3.6 |  | 18 |  |  | 4.0 |  | 2 |  |  | 0.0 |  | — |  |  | — |  |  | 20 |  |
| Total |  |  | $ | 596 |  |  |  |  | $ | 152 |  |  |  |  | $ | 29 |  |  | $ | 61 |  |  | $ | 838 |  |

[0000858877-14-000029:notes:256]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2013 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| NDS Group Limited | 6.4 |  | $ | 807 |  |  | 6.7 |  | $ | 818 |  |  | 7.4 |  |  | $ | 27 |  |  | $ | 94 |  |  | $ | 1,746 |  |
| Meraki, Inc. | 8.0 |  | 259 |  |  | 6.0 |  | 30 |  |  | — |  |  | — |  |  | — |  |  | 289 |  |
| Intucell, Ltd. | 5.0 |  | 59 |  |  | 5.0 |  | 11 |  |  | — |  |  | — |  |  | 36 |  |  | 106 |  |
| Ubiquisys Limited | 4.0 |  | 66 |  |  | 5.0 |  | 7 |  |  | — |  |  | — |  |  | 50 |  |  | 123 |  |
| All others (nine in total) | 4.7 |  | 95 |  |  | 5.8 |  | 17 |  |  | 5.0 |  |  | 1 |  |  | 14 |  |  | 127 |  |
| Total |  |  | $ | 1,286 |  |  |  |  | $ | 883 |  |  |  |  | $ | 28 |  |  | $ | 194 |  |  | $ | 2,391 |  |

[0000858877-14-000029:notes:257]
The following tables present details of the Company’s purchased intangible assets (in millions):

[0000858877-14-000029:notes:258]
| July 26, 2014 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 4,100 |  |  | $ | (1,976 | ) |  | $ | 2,124 |  |
| Customer relationships |  | 1,706 |  |  | (720 | ) |  | 986 |  |
| Other |  | 51 |  |  | (13 | ) |  | 38 |  |
| Total purchased intangible assets with finite lives |  | 5,857 |  |  | (2,709 | ) |  | 3,148 |  |
| In-process research and development, with indefinite lives |  | 132 |  |  | — |  |  | 132 |  |
| Total |  | $ | 5,989 |  |  | $ | (2,709 | ) |  | $ | 3,280 |  |

[0000858877-14-000029:notes:259]
| July 27, 2013 |  | Gross |  | AccumulatedAmortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,563 |  |  | $ | (1,366 | ) |  | $ | 2,197 |  |
| Customer relationships |  | 1,566 |  |  | (466 | ) |  | 1,100 |  |
| Other |  | 30 |  |  | (10 | ) |  | 20 |  |
| Total purchased intangible assets with finite lives |  | 5,159 |  |  | (1,842 | ) |  | 3,317 |  |
| In-process research and development, with indefinite lives |  | 86 |  |  | — |  |  | 86 |  |
| Total |  | $ | 5,245 |  |  | $ | (1,842 | ) |  | $ | 3,403 |  |

[0000858877-14-000029:notes:260]
Purchased intangible assets include intangible assets acquired through business combinations as well as through direct purchases or licenses.

[0000858877-14-000029:notes:261]
The following table presents the amortization of purchased intangible assets (in millions):

[0000858877-14-000029:notes:262]
| Years Ended |  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 742 |  |  | $ | 606 |  |  | $ | 424 |  |
| Operating expenses |  | 275 |  |  | 395 |  |  | 383 |  |
| Total |  | $ | 1,017 |  |  | $ | 1,001 |  |  | $ | 807 |  |

[0000858877-14-000029:notes:263]
There were no impairment charges related to purchased intangible assets during fiscal 2014 and 2013.  For fiscal 2012, amortization of purchased intangible assets included impairment charges of approximately $12 million as a result of declines in estimated fair value resulting from reductions in expected future cash flows associated with certain of the Company’s technology assets.

[0000858877-14-000029:notes:264]
The estimated future amortization expense of purchased intangible assets with finite lives as of July 26, 2014 is as follows (in millions):

[0000858877-14-000029:notes:265]
| Fiscal Year | Amount |
| 2015 | $ | 979 |  |
| 2016 | 743 |  |
| 2017 | 567 |  |
| 2018 | 407 |  |
| 2019 | 307 |  |
| Thereafter | 145 |  |
| Total | $ | 3,148 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000858877-14-000029:notes:266]
(i) Goodwill and Purchased Intangible Assets   Goodwill is tested for impairment on an annual basis in the fourth fiscal quarter and, when specific circumstances dictate, between annual tests. When impaired, the carrying value of goodwill is written down to fair value. The goodwill impairment test involves a two-step process. The first step, identifying a potential impairment, compares the fair value of a reporting unit with its carrying amount, including goodwill. If the carrying value of the reporting unit exceeds its fair value, the second step would need to be conducted; otherwise, no further steps are necessary as no potential impairment exists. If necessary, the second step to measure the impairment loss would be to compare the implied fair value of the reporting unit goodwill with the carrying amount of that goodwill. Any excess of the reporting unit goodwill carrying value over the respective implied fair value is recognized as an impairment loss. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. See “Long-Lived Assets” for the Company’s policy regarding impairment testing of purchased intangible assets with finite lives. Purchased intangible assets with indefinite lives are assessed for potential impairment annually or when events or circumstances indicate that their carrying amounts might be impaired.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000858877-14-000029:notes:267]
(j) Long-Lived Assets   Long-lived assets that are held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability of long-lived assets is based on an estimate of the undiscounted future cash flows resulting from the use of the asset and its eventual disposition. Measurement of an impairment loss for long-lived assets that management expects to hold and use is based on the difference between the fair value of the asset and its carrying value. Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-14-000029:notes:268]
| 16. | Income Taxes |

[0000858877-14-000029:notes:269]
| (a) | Provision for Income Taxes |

[0000858877-14-000029:notes:270]
The provision for income taxes consists of the following (in millions):

[0000858877-14-000029:notes:271]
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Federal: |  |  |  |  |  |
| Current | $ | 1,672 |  |  | $ | 601 |  |  | $ | 1,836 |  |
| Deferred | (383 | ) |  | 152 |  |  | (270 | ) |
|  | 1,289 |  |  | 753 |  |  | 1,566 |  |
| State: |  |  |  |  |  |
| Current | 176 |  |  | 81 |  |  | 119 |  |
| Deferred | (64 | ) |  | 48 |  |  | (53 | ) |
|  | 112 |  |  | 129 |  |  | 66 |  |
| Foreign: |  |  |  |  |  |
| Current | 692 |  |  | 599 |  |  | 477 |  |
| Deferred | (231 | ) |  | (237 | ) |  | 9 |  |
|  | 461 |  |  | 362 |  |  | 486 |  |
| Total | $ | 1,862 |  |  | $ | 1,244 |  |  | $ | 2,118 |  |

[0000858877-14-000029:notes:272]
Income before provision for income taxes consists of the following (in millions):

[0000858877-14-000029:notes:273]
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| United States | $ | 2,734 |  |  | $ | 3,716 |  |  | $ | 3,235 |  |
| International | 6,981 |  |  | 7,511 |  |  | 6,924 |  |
| Total | $ | 9,715 |  |  | $ | 11,227 |  |  | $ | 10,159 |  |

[0000858877-14-000029:notes:274]
The items accounting for the difference between income taxes computed at the federal statutory rate and the provision for income taxes consist of the following:

[0000858877-14-000029:notes:275]
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Federal statutory rate | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 0.5 |  |  | 0.8 |  |  | 0.4 |  |
| Foreign income at other than U.S. rates | (16.4 | ) |  | (16.4 | ) |  | (15.6 | ) |
| Tax credits | (0.7 | ) |  | (1.6 | ) |  | (0.4 | ) |
| Domestic manufacturing deduction | (0.9 | ) |  | (1.0 | ) |  | (1.1 | ) |
| Nondeductible compensation | 3.3 |  |  | 1.3 |  |  | 1.8 |  |
| Tax audit settlement | — |  |  | (7.1 | ) |  | — |  |
| Other, net | (1.6 | ) |  | 0.1 |  |  | 0.7 |  |
| Total | 19.2 | % |  | 11.1 | % |  | 20.8 | % |

[0000858877-14-000029:notes:276]
During fiscal 2013, the Internal Revenue Service (IRS) and the Company settled all outstanding items related to the audit of the Company’s federal income tax returns for the fiscal years ended July 27, 2002 through July 28, 2007.  As a result of the settlement, the Company recognized a net benefit to the provision for income taxes of $794 million.  In addition, the American Taxpayer Relief Act reinstated the U.S. federal R&D credit through December 2013, retroactive to January 1, 2012. As a result, the tax provision in fiscal 2013 included a tax benefit of $184 million related to the U.S. federal R&D tax credit, of which $72 million was attributable to fiscal 2012.

[0000858877-14-000029:notes:277]
U.S. income taxes and foreign withholding taxes associated with the repatriation of earnings of foreign subsidiaries were not provided for on a cumulative total of $52.7 billion of undistributed earnings for certain foreign subsidiaries as of the end of fiscal 2014. The Company intends to reinvest these earnings indefinitely in its foreign subsidiaries. If these earnings were distributed to the United States in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, the Company would be subject to additional U.S. income taxes (subject to an adjustment for

[0000858877-14-000029:notes:278]
foreign tax credits) and foreign withholding taxes. Determination of the amount of unrecognized deferred income tax liability related to these earnings is not practicable.

[0000858877-14-000029:notes:279]
As a result of certain employment and capital investment actions, the Company’s income in certain foreign countries is subject to reduced tax rates and in some cases is wholly exempt from taxes. A portion of these tax incentives will expire at the end of fiscal 2015, and the majority of the remaining balance will expire at the end of fiscal 2025.  The gross income tax benefit attributable to tax incentives was estimated to be $1.3 billion ($0.25 per diluted share) in fiscal 2014, of which approximately $0.5 billion ($0.10 per diluted share) is based on tax incentives that will expire at the end of fiscal 2015.  As of the end of fiscal 2013 and fiscal 2012, the gross income tax benefits attributable to tax incentives were estimated to be $1.4 billion and $1.3 billion ($0.26 and $0.24 per diluted share) for each of the respective years. The gross income tax benefits were partially offset by accruals of U.S. income taxes on undistributed earnings.

[0000858877-14-000029:notes:280]
Unrecognized Tax Benefits

[0000858877-14-000029:notes:281]
The aggregate changes in the balance of gross unrecognized tax benefits were as follows (in millions):

[0000858877-14-000029:notes:282]
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Beginning balance | $ | 1,775 |  |  | $ | 2,819 |  |  | $ | 2,948 |  |
| Additions based on tax positions related to the current year | 262 |  |  | 138 |  |  | 155 |  |
| Additions for tax positions of prior years | 64 |  |  | 187 |  |  | 54 |  |
| Reductions for tax positions of prior years | (13 | ) |  | (1,027 | ) |  | (226 | ) |
| Settlements | (17 | ) |  | (199 | ) |  | (41 | ) |
| Lapse of statute of limitations | (133 | ) |  | (143 | ) |  | (71 | ) |
| Ending balance | $ | 1,938 |  |  | $ | 1,775 |  |  | $ | 2,819 |  |

[0000858877-14-000029:notes:283]
As of July 26, 2014, $1.7 billion of the unrecognized tax benefits would affect the effective tax rate if realized. During fiscal 2014 the Company recognized $29 million of net interest expense and $8 million of penalties.  During fiscal 2013, the Company recognized $115 million of net interest expense and $2 million of penalties.  During fiscal 2012, the Company recognized $146 million of net interest expense and $21 million of penalties. The Company’s total accrual for interest and penalties was $304 million, $268 million, and $381 million as of the end of fiscal 2014, 2013, and 2012, respectively. The Company is no longer subject to U.S. federal income tax audit for returns covering tax years through fiscal 2007. With limited exceptions, the Company is no longer subject to foreign, state, or local income tax audits for returns covering tax years through fiscal 2002.

[0000858877-14-000029:notes:284]
The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. The Company believes it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters. The Company estimates that the unrecognized tax benefits at July 26, 2014 could be reduced by approximately $300 million in the next 12 months.

[0000858877-14-000029:notes:285]
| (b) | Deferred Tax Assets and Liabilities |

[0000858877-14-000029:notes:286]
The following table presents the breakdown between current and noncurrent net deferred tax assets (in millions):

[0000858877-14-000029:notes:287]
|  | July 26, 2014 |  | July 27, 2013 |
| Deferred tax assets—current | $ | 2,808 |  |  | $ | 2,616 |  |
| Deferred tax liabilities—current | (134 | ) |  | (114 | ) |
| Deferred tax assets—noncurrent | 1,700 |  |  | 1,539 |  |
| Deferred tax liabilities—noncurrent | (369 | ) |  | (399 | ) |
| Total net deferred tax assets | $ | 4,005 |  |  | $ | 3,642 |  |

[0000858877-14-000029:notes:288]
The components of the deferred tax assets and liabilities are as follows (in millions):

[0000858877-14-000029:notes:289]
|  | July 26, 2014 |  | July 27, 2013 |
| ASSETS |  |  |  |
| Allowance for doubtful accounts and returns | $ | 464 |  |  | $ | 390 |  |
| Sales-type and direct-financing leases | 231 |  |  | 167 |  |
| Inventory write-downs and capitalization | 307 |  |  | 216 |  |
| Investment provisions | 212 |  |  | 214 |  |
| IPR&D, goodwill, and purchased intangible assets | 135 |  |  | 123 |  |
| Deferred revenue | 1,689 |  |  | 1,624 |  |
| Credits and net operating loss carryforwards | 796 |  |  | 681 |  |
| Share-based compensation expense | 661 |  |  | 783 |  |
| Accrued compensation | 496 |  |  | 486 |  |
| Other | 676 |  |  | 560 |  |
| Gross deferred tax assets | 5,667 |  |  | 5,244 |  |
| Valuation allowance | (114 | ) |  | (98 | ) |
| Total deferred tax assets | 5,553 |  |  | 5,146 |  |
| LIABILITIES |  |  |  |
| Purchased intangible assets | (1,229 | ) |  | (1,101 | ) |
| Depreciation | (48 | ) |  | (169 | ) |
| Unrealized gains on investments | (245 | ) |  | (211 | ) |
| Other | (26 | ) |  | (23 | ) |
| Total deferred tax liabilities | (1,548 | ) |  | (1,504 | ) |
| Total net deferred tax assets | $ | 4,005 |  |  | $ | 3,642 |  |

[0000858877-14-000029:notes:290]
As of July 26, 2014, the Company’s federal, state, and foreign net operating loss carryforwards for income tax purposes were $233 million, $658 million, and $699 million, respectively. A significant amount of the federal net operating loss carryforwards relates to acquisitions and, as a result, is limited in the amount that can be recognized in any one year. If not utilized, the federal net operating loss will begin to expire in fiscal 2018, and the foreign and state net operating loss carryforwards will begin to expire in fiscal 2015. The Company has provided a valuation allowance of $71 million for deferred tax assets related to foreign net operating losses that are not expected to be realized.

[0000858877-14-000029:notes:291]
As of July 26, 2014, the Company’s federal, state, and foreign tax credit carryforwards for income tax purposes were approximately $8 million, $710 million, and $13 million, respectively. The federal and foreign tax credit carryforwards will begin to expire in fiscal 2014 and 2027, respectively.  The majority of state tax credits can be carried forward indefinitely; however, the Company has provided a valuation allowance of $43 million for deferred tax assets related to state tax credits that are not expected to be realized.


## us-gaap:IncomeTaxPolicyTextBlock

[0000858877-14-000029:notes:292]
(s) Income Taxes   Income tax expense is based on pretax financial accounting income. Deferred tax assets and liabilities are recognized for the expected tax consequences of temporary differences between the tax bases of assets and liabilities and their reported amounts. Valuation allowances are recorded to reduce deferred tax assets to the amount that will more likely than not be realized.

[0000858877-14-000029:notes:293]
The Company accounts for uncertainty in income taxes using a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. The Company classifies the liability for unrecognized tax benefits as current to the extent that the Company anticipates payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.


## us-gaap:InventoryDisclosureTextBlock

[0000858877-14-000029:notes:294]
The following tables provide details of selected balance sheet items (in millions):

[0000858877-14-000029:notes:295]
|  |  | July 26, 2014 |  | July 27, 2013 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 77 |  |  | $ | 105 |  |
| Work in process |  | 5 |  |  | 24 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 595 |  |  | 572 |  |
| Manufactured finished goods |  | 606 |  |  | 480 |  |
| Total finished goods |  | 1,201 |  |  | 1,052 |  |
| Service-related spares |  | 273 |  |  | 256 |  |
| Demonstration systems |  | 35 |  |  | 39 |  |
| Total |  | $ | 1,591 |  |  | $ | 1,476 |  |


## us-gaap:InventoryPolicyTextBlock

[0000858877-14-000029:notes:296]
(d) Inventories   Inventories are stated at the lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company provides inventory write-downs based on excess and obsolete inventories determined primarily by future demand forecasts. The write-down is measured as the difference between the cost of the inventory and market based upon assumptions about future demand and charged to the provision for inventory, which is a component of cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and

[0000858877-14-000029:notes:297]
subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In addition, the Company records a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of the Company’s future demand forecasts consistent with its valuation of excess and obsolete inventory.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-14-000029:notes:298]
The following table summarizes the maturities of the Company’s fixed income securities at July 26, 2014 (in millions):

[0000858877-14-000029:notes:299]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 15,444 |  |  | $ | 15,457 |  |
| Due in 1 to 2 years | 13,449 |  |  | 13,484 |  |
| Due in 2 to 5 years | 13,711 |  |  | 13,743 |  |
| Due after 5 years | 701 |  |  | 712 |  |
| Total | $ | 43,305 |  |  | $ | 43,396 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-14-000029:notes:300]
| 8. | Investments |

[0000858877-14-000029:notes:301]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-14-000029:notes:302]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-14-000029:notes:303]
| July 26, 2014 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 31,717 |  |  | $ | 29 |  |  | $ | (12 | ) |  | $ | 31,734 |  |
| U.S. government agency securities | 1,062 |  |  | 1 |  |  | — |  |  | 1,063 |  |
| Non-U.S. government and agency securities | 860 |  |  | 2 |  |  | (1 | ) |  | 861 |  |
| Corporate debt securities | 9,092 |  |  | 74 |  |  | (7 | ) |  | 9,159 |  |
| U.S. agency mortgage-backed securities | 574 |  |  | 5 |  |  | — |  |  | 579 |  |
| Total fixed income securities | 43,305 |  |  | 111 |  |  | (20 | ) |  | 43,396 |  |
| Publicly traded equity securities | 1,314 |  |  | 648 |  |  | (10 | ) |  | 1,952 |  |
| Total | $ | 44,619 |  |  | $ | 759 |  |  | $ | (30 | ) |  | $ | 45,348 |  |
| July 27, 2013 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 27,814 |  |  | $ | 22 |  |  | $ | (13 | ) |  | $ | 27,823 |  |
| U.S. government agency securities | 3,083 |  |  | 7 |  |  | (1 | ) |  | 3,089 |  |
| Non-U.S. government and agency securities | 1,094 |  |  | 3 |  |  | (2 | ) |  | 1,095 |  |
| Corporate debt securities | 7,876 |  |  | 55 |  |  | (50 | ) |  | 7,881 |  |
| Total fixed income securities | 39,867 |  |  | 87 |  |  | (66 | ) |  | 39,888 |  |
| Publicly traded equity securities | 2,063 |  |  | 738 |  |  | (4 | ) |  | 2,797 |  |
| Total | $ | 41,930 |  |  | $ | 825 |  |  | $ | (70 | ) |  | $ | 42,685 |  |

[0000858877-14-000029:notes:304]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-14-000029:notes:305]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-14-000029:notes:306]
The following table presents the gross realized gains and gross realized losses related to the Company’s available-for-sale investments (in millions):

[0000858877-14-000029:notes:307]
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Gross realized gains | $ | 341 |  |  | $ | 264 |  |  | $ | 561 |  |
| Gross realized losses | (41 | ) |  | (216 | ) |  | (460 | ) |
| Total | $ | 300 |  |  | $ | 48 |  |  | $ | 101 |  |

[0000858877-14-000029:notes:308]
The following table presents the realized net gains related to the Company’s available-for-sale investments by security type (in millions):

[0000858877-14-000029:notes:309]
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Net gains on investments in publicly traded equity securities | $ | 253 |  |  | $ | 17 |  |  | $ | 43 |  |
| Net gains on investments in fixed income securities | 47 |  |  | 31 |  |  | 58 |  |
| Total | $ | 300 |  |  | $ | 48 |  |  | $ | 101 |  |

[0000858877-14-000029:notes:310]
For fiscal 2014, the realized net gains related to the Company's available-for-sale investments included impairment charges of $11 million.  These impairment charges related to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for fiscal 2013 and 2012.

[0000858877-14-000029:notes:311]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at July 26, 2014 and July 27, 2013 (in millions):

[0000858877-14-000029:notes:312]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 26, 2014 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 7,676 |  |  | $ | (12 | ) |  | $ | 45 |  |  | $ | — |  |  | $ | 7,721 |  |  | $ | (12 | ) |
| Non-U.S. government and agency securities | 361 |  |  | (1 | ) |  | 22 |  |  | — |  |  | 383 |  |  | (1 | ) |
| Corporate debt securities | 1,875 |  |  | (3 | ) |  | 491 |  |  | (4 | ) |  | 2,366 |  |  | (7 | ) |
| Total fixed income securities | 9,912 |  |  | (16 | ) |  | 558 |  |  | (4 | ) |  | 10,470 |  |  | (20 | ) |
| Publicly traded equity securities | 132 |  |  | (10 | ) |  | — |  |  | — |  |  | 132 |  |  | (10 | ) |
| Total | $ | 10,044 |  |  | $ | (26 | ) |  | $ | 558 |  |  | $ | (4 | ) |  | $ | 10,602 |  |  | $ | (30 | ) |

[0000858877-14-000029:notes:313]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2013 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 7,865 |  |  | $ | (13 | ) |  | $ | — |  |  | $ | — |  |  | $ | 7,865 |  |  | $ | (13 | ) |
| U.S. government agency securities | 294 |  |  | (1 | ) |  | — |  |  | — |  |  | 294 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 432 |  |  | (2 | ) |  | — |  |  | — |  |  | 432 |  |  | (2 | ) |
| Corporate debt securities | 3,704 |  |  | (50 | ) |  | 4 |  |  | — |  |  | 3,708 |  |  | (50 | ) |
| Total fixed income securities | 12,295 |  |  | (66 | ) |  | 4 |  |  | — |  |  | 12,299 |  |  | (66 | ) |
| Publicly traded equity securities | 278 |  |  | (4 | ) |  | — |  |  | — |  |  | 278 |  |  | (4 | ) |
| Total | $ | 12,573 |  |  | $ | (70 | ) |  | $ | 4 |  |  | $ | — |  |  | $ | 12,577 |  |  | $ | (70 | ) |

[0000858877-14-000029:notes:314]
As of July 26, 2014, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments, and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of July 26, 2014, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the year ended July 26, 2014.

[0000858877-14-000029:notes:315]
The Company has evaluated its publicly traded equity securities as of July 26, 2014 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-14-000029:notes:316]
| (c) | Maturities of Fixed Income Securities |

[0000858877-14-000029:notes:317]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.  The remaining contractual principal maturities for mortgage-backed securities were allocated assuming no prepayments.

[0000858877-14-000029:notes:318]
| (d) | Securities Lending |

[0000858877-14-000029:notes:319]
The Company periodically engages in securities lending activities with certain of its available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for fiscal 2014 and 2013 was $1.5 billion and $0.7 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of July 26, 2014 and July 27, 2013, the Company had no outstanding securities lending transactions.

[0000858877-14-000029:notes:320]
| (e) | Investments in Privately Held Companies |

[0000858877-14-000029:notes:321]
The carrying value of the Company’s investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of July 26, 2014 and July 27, 2013, the amounts are summarized in the table below (in millions):

[0000858877-14-000029:notes:322]
Variable Interest Entities

[0000858877-14-000029:notes:323]
VCE Joint Venture   VCE is a joint venture that the Company formed in fiscal 2010 with EMC Corporation (“EMC”), with investments from VMware, Inc. (“VMware”) and Intel Corporation. VCE helps organizations leverage best-in-class technologies and disciplines from Cisco, EMC, and VMware to enable the transformation to cloud computing.

[0000858877-14-000029:notes:324]
As of July 26, 2014, the Company’s cumulative gross investment in VCE was approximately $716 million, inclusive of accrued interest, and its ownership percentage was approximately 35%.  The Company invested $185 million in VCE during fiscal 2014, $93 million during fiscal 2013, and $276 million during fiscal 2012.

[0000858877-14-000029:notes:325]
For the period presented, the Company accounted for its investment in VCE under the equity method, and its portion of VCE’s net loss is recognized in other income (loss), net.  The Company’s share of VCE’s losses, based upon its portion of the overall funding, was approximately 36.8% for each of the fiscal years ended July 26, 2014, July 27, 2013, and July 28, 2012. As of July 26, 2014, the Company had recorded cumulative losses from VCE of $644 million since inception, of which losses of $223 million, $183 million, and $160 million were recorded for the fiscal years ended July 26, 2014, July 27, 2013, and July 28, 2012, respectively.  The Company’s carrying value in VCE as of July 26, 2014 was $72 million.

[0000858877-14-000029:notes:326]
Over the next 12 months, as VCE scales its operations, the Company may make additional investments in VCE and may incur additional losses proportionate with the Company’s share ownership.

[0000858877-14-000029:notes:327]
From time to time, EMC and Cisco may enter into guarantee agreements on behalf of VCE to indemnify third parties, such as customers, for monetary damages. Such guarantees were not material as of July 26, 2014.

[0000858877-14-000029:notes:328]
Other Variable Interest Entities    In the ordinary course of business, the Company has investments in other privately held companies and provides financing to certain customers. These other privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these other privately held companies and its customer financings, and has determined that as of July 26, 2014 there were no other variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-14-000029:notes:329]
| 1. | Basis of Presentation |

[0000858877-14-000029:notes:330]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2014, fiscal 2013, and fiscal 2012 are each 52-week fiscal years. The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated. The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-14-000029:notes:331]
The Company consolidates its investments in a venture fund managed by SOFTBANK Corp. and its affiliates (“SOFTBANK”) as this is a variable interest entity and the Company is the primary beneficiary.  The noncontrolling interests attributed to SOFTBANK are presented as a separate component from the Company’s equity in the equity section of the Consolidated Balance Sheets. SOFTBANK’s share of the earnings in the venture fund are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-14-000029:notes:332]
Certain reclassifications have been made to the amounts for prior years in order to conform to the current year’s presentation.  The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000858877-14-000029:notes:333]
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 1,700 |  |  | $ | 1,539 |  |
| Investments in privately held companies |  | 899 |  |  | 833 |  |
| Other |  | 732 |  |  | 743 |  |
| Total |  | $ | 3,331 |  |  | $ | 3,115 |  |


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000858877-14-000029:notes:334]
(g) Depreciation and Amortization   Property and equipment are stated at cost, less accumulated depreciation or amortization, whenever applicable. Depreciation and amortization expenses for property and equipment were approximately $1.2 billion, $1.2 billion, and $1.1 billion for fiscal 2014, 2013, and 2012, respectively. Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-14-000029:notes:335]
| Asset Category |  | Period |
| Buildings |  | 25 years |
| Building improvements |  | 10 years |
| Leasehold improvements |  | Shorter of remaining lease term or up to 10 years |
| Computer equipment and related software |  | 30 to 36 months |
| Production, engineering, and other equipment |  | Up to 5 years |
| Operating lease assets |  | Based on lease term |
| Furniture and fixtures |  | 5 years |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-14-000029:notes:336]
| Property and equipment, net: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,468 |  |  | $ | 4,426 |  |
| Computer equipment and related software |  | 1,425 |  |  | 1,416 |  |
| Production, engineering, and other equipment |  | 5,756 |  |  | 5,721 |  |
| Operating lease assets |  | 362 |  |  | 326 |  |
| Furniture and fixtures |  | 509 |  |  | 497 |  |
|  |  | 12,520 |  |  | 12,386 |  |
| Less accumulated depreciation and amortization |  | (9,268 | ) |  | (9,064 | ) |
| Total |  | $ | 3,252 |  |  | $ | 3,322 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000858877-14-000029:notes:337]
(r) Software Development Costs   Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-14-000029:notes:338]
| 5. | Restructuring and Other Charges |

[0000858877-14-000029:notes:339]
Fiscal 2014 Plan and Fiscal 2011 Plans

[0000858877-14-000029:notes:340]
In August 2013, the Company announced a workforce reduction plan that would impact up to 4,000 employees, or 5% of the Company’s global workforce. In connection with this restructuring action, the Company incurred charges of $418 million during fiscal 2014 (included as part of the charges discussed below).  The Company has completed the Fiscal 2014 restructuring and does not expect any remaining charges related to this action.

[0000858877-14-000029:notes:341]
The Fiscal 2011 Plans consist primarily of the realignment and restructuring of the Company’s business announced in July 2011 and of certain consumer product lines as announced during April 2011.  The Company completed the Fiscal 2011 Plans at the end of fiscal 2013. The Company incurred cumulative charges of approximately $1.1 billion in connection with these plans.

[0000858877-14-000029:notes:342]
As part of the Fiscal 2011 Plans, other charges incurred during fiscal 2012 were primarily for the consolidation of excess facilities, as well as an incremental charge related to the sale of the Company’s Juarez, Mexico manufacturing operations, which sale was completed in the first quarter of fiscal 2012.

[0000858877-14-000029:notes:343]
The following table summarizes the activities related to the restructuring and other charges pursuant to the Company’s Fiscal 2014 Plan and the Fiscal 2011 Plans related to the realignment and restructuring of the Company’s business (in millions):

[0000858877-14-000029:notes:344]
|  |  | Fiscal 2011 Plans |  | Fiscal 2014 Plan |  |  |
|  |  | Voluntary Early Retirement Program |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 30, 2011 |  | $ | 17 |  |  | $ | 234 |  |  | $ | 11 |  |  | $ | — |  |  | $ | — |  |  | $ | 262 |  |
| Gross charges in fiscal 2012 |  | — |  |  | 299 |  |  | 54 |  |  | — |  |  | — |  |  | 353 |  |
| Change in estimate related to fiscal 2011 charges |  | — |  |  | (49 | ) |  | — |  |  | — |  |  | — |  |  | (49 | ) |
| Cash payments |  | (17 | ) |  | (401 | ) |  | (18 | ) |  | — |  |  | — |  |  | (436 | ) |
| Non-cash items |  | — |  |  | — |  |  | (20 | ) |  | — |  |  | — |  |  | (20 | ) |
| Liability as of July 28, 2012 |  | — |  |  | 83 |  |  | 27 |  |  | — |  |  | — |  |  | 110 |  |
| Gross charges in fiscal 2013 |  | — |  |  | 111 |  |  | (6 | ) |  | — |  |  | — |  |  | 105 |  |
| Cash payments |  | — |  |  | (173 | ) |  | (11 | ) |  | — |  |  | — |  |  | (184 | ) |
| Non-cash items |  | — |  |  | — |  |  | (3 | ) |  | — |  |  | — |  |  | (3 | ) |
| Liability as of July 27, 2013 |  | — |  |  | 21 |  |  | 7 |  |  | — |  |  | — |  |  | 28 |  |
| Gross charges in fiscal 2014 |  | — |  |  | — |  |  | — |  |  | 366 |  |  | 52 |  |  | 418 |  |
| Cash payments |  | — |  |  | (19 | ) |  | (3 | ) |  | (326 | ) |  | (4 | ) |  | (352 | ) |
| Non-cash items |  | — |  |  | (2 | ) |  | (1 | ) |  | — |  |  | (22 | ) |  | (25 | ) |
| Liability as of July 26, 2014 |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | 40 |  |  | $ | 26 |  |  | $ | 69 |  |

[0000858877-14-000029:notes:345]
Fiscal 2015 Plan

[0000858877-14-000029:notes:346]
In August 2014 the Company announced a restructuring plan that will impact up to 6,000 employees, representing approximately 8% of its global workforce.  The Company expects to take action under this plan beginning in the first quarter of fiscal 2015.  The Company currently estimates that it will recognize pre-tax charges in an amount not expected to exceed $700 million, consisting of severance and other one-time termination benefits and other associated costs.  These charges are primarily cash-based. The Company expects that approximately $250 million to $350 million of these charges will be recognized during the first quarter of fiscal 2015, with the remaining amount to be recognized during the rest of fiscal 2015.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000858877-14-000029:notes:347]
(o) Revenue Recognition  The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is reasonably assured. In instances where final acceptance of the product, system, or solution is specified by the customer, revenue is deferred until all acceptance criteria have been met. For hosting arrangements, the Company recognizes subscription revenue ratably over the subscription period, while usage revenue is recognized based on utilization. Software subscription revenue is deferred and recognized ratably over the subscription term upon delivery of the first product and commencement of the term.  Technical support services revenue is deferred and recognized ratably over the period during which the services are to be performed, which is typically from one to three years.  Advanced services transactional revenue is recognized upon delivery or completion of performance.

[0000858877-14-000029:notes:348]
The Company uses distributors that stock inventory and typically sell to systems integrators, service providers, and other resellers.     The Company refers to this as its two-tier system of sales to the end customer. Revenue from distributors is recognized based on a sell-through method using information provided by them. Distributors and other partners participate in various rebate, cooperative marketing and other programs, and the Company maintains estimated accruals and allowances for these programs. The ending liability for these programs was included in other current liabilities and the balance as of July 26, 2014 and July 27, 2013 was $1.3 billion and $1.1 billion, respectively.  The Company accrues for warranty costs, sales returns,

[0000858877-14-000029:notes:349]
and other allowances based on its historical experience. Shipping and handling fees billed to customers are included in revenue, with the associated costs included in cost of sales.

[0000858877-14-000029:notes:350]
Many of the Company’s products have both software and nonsoftware components that function together to deliver the products’ essential functionality. The Company’s product offerings fall into the following categories: Switching, Next-Generation Network (NGN) Routing, Service Provider Video, Collaboration, Data Center, Wireless, Security, and Other Products. The Company also provides technical support and advanced services. The Company has a broad customer base that encompasses virtually all types of public and private entities, including enterprise businesses, service providers, and commercial customers.  The Company and its salesforce are not organized by product divisions, and the Company’s products and services can be sold standalone or together in various combinations across the Company’s geographic segments or customer markets. For example, service provider arrangements are typically larger in scale with longer deployment schedules and involve the delivery of a variety of product technologies, including high-end routing, video and network management software, and other product technologies along with technical support and advanced services. The Company’s enterprise and commercial arrangements are unique for each customer and smaller in scale and may include network infrastructure products such as routers and switches or collaboration technologies such as Unified Communications and Cisco TelePresence systems products along with technical support services.

[0000858877-14-000029:notes:351]
The Company enters into revenue arrangements that may consist of multiple deliverables of its product and service offerings due to the needs of its customers. For example, a customer may purchase routing products along with a contract for technical support services. This arrangement would consist of multiple elements, with the products delivered in one reporting period and the technical support services delivered across multiple reporting periods. Another customer may purchase networking products along with advanced service offerings, in which all the elements are delivered within the same reporting period. In addition, distributors purchase products or technical support services on a standalone basis for resale to an end user or for purposes of stocking certain products, and these transactions would not result in a multiple-element arrangement.

[0000858877-14-000029:notes:352]
In many instances, products are sold separately in standalone arrangements as customers may support the products themselves or purchase support on a time-and-materials basis. Advanced services are sometimes sold in standalone engagements such as general consulting, network management, or security advisory projects, and technical support services are sold separately through renewals of annual contracts.  The Company determines its vendor-specific objective evidence (VSOE) based on its normal pricing and discounting practices for the specific product or service when sold separately. VSOE determination requires that a substantial majority of the historical standalone transactions have the selling prices for a product or service that fall within a reasonably narrow pricing range, generally evidenced by approximately 80% of such historical standalone transactions falling within plus or minus 15% of the median rates. In addition, the Company considers the geographies in which the products or services are sold, major product and service groups and customer classifications, and other environmental or marketing variables in determining VSOE.

[0000858877-14-000029:notes:353]
When the Company is not able to establish VSOE for all deliverables in an arrangement with multiple elements, which may be due to the Company infrequently selling each element separately, not pricing products within a narrow range, or only having a limited sales history, such as in the case of certain newly introduced product categories, the Company attempts to determine the selling price of each element based on third-party evidence of selling price (TPE). TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, the Company’s go-to-market strategy differs from that of its peers, and its offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, the Company is unable to reliably determine what similar competitor products’ selling prices are on a standalone basis. Therefore, the Company is typically not able to determine TPE.

[0000858877-14-000029:notes:354]
When the Company is unable to establish fair value using VSOE or TPE, the Company uses estimated selling prices (ESP) in its allocation of arrangement consideration. The objective of ESP is to determine the price at which the Company would transact a sale if the product or service were regularly sold on a standalone basis. ESP is generally used for new or highly proprietary offerings and solutions or for offerings not priced within a reasonably narrow range. The Company determines ESP for a product or service by considering multiple factors, including, but not limited to, geographies, market conditions, competitive landscape, internal costs, gross margin objectives, and pricing practices. The determination of ESP is made through consultation with and formal approval by the Company’s management, taking into consideration the go-to-market strategy.

[0000858877-14-000029:notes:355]
The Company regularly reviews VSOE, TPE, and ESP and maintains internal controls over the establishment and updates of these estimates. There were no material impacts during the fiscal year, nor does the Company currently expect a material impact in the near term from changes in VSOE, TPE, or ESP.

[0000858877-14-000029:notes:356]
The Company’s arrangements with multiple deliverables may have a standalone software deliverable that is subject to the software revenue recognition guidance. In these cases, revenue for the software is generally recognized upon shipment or electronic delivery and granting of the license. The revenue for these multiple-element arrangements is allocated to the software deliverable and the nonsoftware deliverables based on the relative selling prices of all of the deliverables in the arrangement using the hierarchy in the applicable accounting guidance. In the circumstances where the Company cannot

[0000858877-14-000029:notes:357]
determine VSOE or TPE of the selling price for all of the deliverables in the arrangement, including the software deliverable, ESP is used for the purposes of performing this allocation.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0000858877-14-000029:notes:358]
A summary of the allocation of the total purchase consideration is presented as follows (in millions):


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000858877-14-000029:notes:359]
Summarized financial information by segment for fiscal 2014, 2013, and 2012, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-14-000029:notes:360]
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Revenue: |  |  |  |  |  |
| Americas | $ | 27,781 |  |  | $ | 28,639 |  |  | $ | 26,501 |  |
| EMEA | 12,006 |  |  | 12,210 |  |  | 12,075 |  |
| APJC | 7,355 |  |  | 7,758 |  |  | 7,485 |  |
| Total | $ | 47,142 |  |  | $ | 48,607 |  |  | $ | 46,061 |  |
| Gross margin: |  |  |  |  |  |
| Americas | $ | 17,379 |  |  | $ | 17,887 |  |  | $ | 16,639 |  |
| EMEA | 7,700 |  |  | 7,876 |  |  | 7,605 |  |
| APJC | 4,252 |  |  | 4,637 |  |  | 4,519 |  |
| Segment total | 29,331 |  |  | 30,400 |  |  | 28,763 |  |
| Unallocated corporate items | (1,562 | ) |  | (960 | ) |  | (554 | ) |
| Total | $ | 27,769 |  |  | $ | 29,440 |  |  | $ | 28,209 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000858877-14-000029:notes:361]
SCHEDULE II

[0000858877-14-000029:notes:362]
VALUATION AND QUALIFYING ACCOUNTS

[0000858877-14-000029:notes:363]
(in millions)

[0000858877-14-000029:notes:364]
|  | Allowances For |
|  | FinancingReceivables |  | AccountsReceivable |
| Year ended July 28, 2012: |  |  |  |
| Balance at beginning of fiscal year | $ | 367 |  |  | $ | 204 |  |
| Provisions | 31 |  |  | 19 |  |
| Recoveries (write-offs), net | (3 | ) |  | (16 | ) |
| Foreign exchange and other | (15 | ) |  | — |  |
| Balance at end of fiscal year | $ | 380 |  |  | $ | 207 |  |
| Year ended July 27, 2013: |  |  |  |
| Balance at beginning of fiscal year | $ | 380 |  |  | $ | 207 |  |
| Provisions | 11 |  |  | 33 |  |
| Recoveries (write-offs), net | (46 | ) |  | (12 | ) |
| Foreign exchange and other | (1 | ) |  | — |  |
| Balance at end of fiscal year | $ | 344 |  |  | $ | 228 |  |
| Year ended July 26, 2014: |  |  |  |
| Balance at beginning of fiscal year | $ | 344 |  |  | $ | 228 |  |
| Provisions | 14 |  |  | 65 |  |
| Recoveries (write-offs), net | (9 | ) |  | (28 | ) |
| Balance at end of fiscal year | $ | 349 |  |  | $ | 265 |  |

[0000858877-14-000029:notes:365]
Foreign exchange and other includes the impact of foreign exchange and certain immaterial reclassifications.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-14-000029:notes:366]
| 2. | Summary of Significant Accounting Policies |

[0000858877-14-000029:notes:367]
(b) Available-for-Sale Investments   The Company classifies its investments in both fixed income securities and publicly traded equity securities as available-for-sale investments. Fixed income securities primarily consist of U.S. government securities, U.S. government agency securities, non-U.S. government and agency securities, corporate debt securities, and U.S. agency mortgage-backed securities. These available-for-sale investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of fixed income and public equity securities sold. These investments are recorded in the Consolidated Balance Sheets at fair value. Unrealized gains and losses on these investments, to the extent the investments are unhedged, are included as a separate component of accumulated other comprehensive income (AOCI), net of tax. The Company classifies its investments as current based on the nature of the investments and their availability for use in current operations.

[0000858877-14-000029:notes:368]
(c) Other-than-Temporary Impairments on Investments  When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and the Company will assess whether the impairment is other than temporary. An impairment is considered other than temporary if (i) the Company has the intent to sell the security, (ii) it is more likely than not that the Company will be required to sell the security before recovery of the entire amortized cost basis, or (iii) the Company does not expect to recover the entire amortized cost basis of the security. If impairment is considered other than temporary based on condition (i) or (ii) described earlier, the entire difference between the amortized cost and the fair value of the debt security is recognized in earnings. If an impairment is considered other than temporary based on condition (iii), the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) will be recognized in earnings, and the amount relating to all other factors will be recognized in other comprehensive income (OCI).

[0000858877-14-000029:notes:369]
The Company recognizes an impairment charge on publicly traded equity securities when a decline in the fair value of a security below the respective cost basis is judged to be other than temporary. The Company considers various factors in determining whether a decline in the fair value of these investments is other than temporary, including the length of time and extent to which the fair value of the security has been less than the Company’s cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the investment for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-14-000029:notes:370]
Investments in privately held companies are included in other assets in the Consolidated Balance Sheets and are primarily accounted for using either the cost or equity method. The Company monitors these investments for impairments and makes reductions in carrying values if the Company determines that an impairment charge is required based primarily on the financial condition and near-term prospects of these companies.

[0000858877-14-000029:notes:371]
(e) Allowance for Doubtful Accounts   The allowance for doubtful accounts is based on the Company’s assessment of the collectibility of customer accounts. The Company regularly reviews the allowance by considering factors such as historical experience, credit quality, age of the accounts receivable balances, economic conditions that may affect a customer’s ability to pay, and expected default frequency rates. Trade receivables are written off at the point when they are considered uncollectible.

[0000858877-14-000029:notes:372]
(f) Financing Receivables and Guarantees   The Company provides financing arrangements, including leases, financed service contracts, and loans, for certain qualified end-user customers to build, maintain, and upgrade their networks. Lease receivables primarily represent sales-type and direct-financing leases. Leases have on average a four-year term and are usually collateralized by a security interest in the underlying assets, while loan receivables generally have terms of up to three years. Financed service contracts typically have terms of one to three years and primarily relate to technical support services.

[0000858877-14-000029:notes:373]
The Company determines the adequacy of its allowance for credit loss by assessing the risks and losses inherent in its financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by the Company to its customers: lease receivables, loan receivables, and financed service contracts and other.

[0000858877-14-000029:notes:374]
The Company assesses the allowance for credit loss related to financing receivables on either an individual or a collective basis. The Company considers various factors in evaluating lease and loan receivables and the earned portion of financed service contracts for possible impairment on an individual basis. These factors include the Company’s historical experience, credit quality and age of the receivable balances, and economic conditions that may affect a customer’s ability to pay. When the evaluation indicates that it is probable that all amounts due pursuant to the contractual terms of the financing agreement, including scheduled interest payments, are unable to be collected, the financing receivable is considered impaired. All such outstanding amounts, including any accrued interest, will be assessed and fully reserved at the customer level. The Company’s internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality financing receivables. Typically, the Company also considers receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. The Company evaluates the remainder of its financing receivables portfolio for impairment on a collective basis and records an allowance for credit loss at the portfolio segment level. When evaluating the financing receivables on a collective basis, the Company uses expected default frequency rates published by a major third-party credit-rating agency as well as its own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk, and correlation.

[0000858877-14-000029:notes:375]
Expected default frequency rates are published quarterly by a major third-party credit-rating agency, and the internal credit risk rating is derived by taking into consideration various customer-specific factors and macroeconomic conditions. These factors, which include the strength of the customer’s business and financial performance, the quality of the customer’s banking relationships, the Company’s specific historical experience with the customer, the performance and outlook of the customer’s industry, the customer’s legal and regulatory environment, the potential sovereign risk of the geographic locations in which the customer is operating, and independent third-party evaluations, are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000858877-14-000029:notes:376]
Financing receivables are written off at the point when they are considered uncollectible, and all outstanding balances, including any previously earned but uncollected interest income, will be reversed and charged against the allowance for credit loss. The Company does not typically have any partially written-off financing receivables.

[0000858877-14-000029:notes:377]
Outstanding financing receivables that are aged 31 days or more from the contractual payment date are considered past due. The Company does not accrue interest on financing receivables that are considered impaired or more than 90 days past due unless either the receivable has not been collected due to administrative reasons or the receivable is well secured and in the process of collection.  Financing receivables may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain. After a financing receivable has been categorized as nonaccrual, interest will be recognized when cash is received. A financing receivable may be returned to accrual status after all of the customer’s delinquent balances of principal and interest have been settled, and the customer remains current for an appropriate period.

[0000858877-14-000029:notes:378]
The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of the Company’s receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and the Company receives a payment for the receivables from the third party based on the Company’s standard payment terms. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically

[0000858877-14-000029:notes:379]
have terms of up to three years. The Company could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Deferred revenue relating to these financing arrangements is recorded in accordance with revenue recognition policies or for the fair value of the financing guarantees.

[0000858877-14-000029:notes:380]
(k) Fair Value   Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, the Company considers the principal or most advantageous market in which it would transact, and it also considers assumptions that market participants would use when pricing the asset or liability.

[0000858877-14-000029:notes:381]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. The standard establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000858877-14-000029:notes:382]
Level 1 applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000858877-14-000029:notes:383]
Level 2 applies to assets or liabilities for which there are inputs other than quoted prices that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets); or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000858877-14-000029:notes:384]
Level 3 applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0000858877-14-000029:notes:385]
(n) Concentrations of Risk   Cash and cash equivalents are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties.

[0000858877-14-000029:notes:386]
The Company performs ongoing credit evaluations of its customers and, with the exception of certain financing transactions, does not require collateral from its customers. The Company receives certain of its components from sole suppliers. Additionally, the Company relies on a limited number of contract manufacturers and suppliers to provide manufacturing services for its products. The inability of a contract manufacturer or supplier to fulfill supply requirements of the Company could materially impact future operating results.

[0000858877-14-000029:notes:387]
(u) Consolidation of Variable Interest Entities  The Company uses a qualitative approach in assessing the consolidation requirement for  variable interest entities. The approach focuses on identifying which enterprise has the power to direct the activities that most significantly impact the variable interest entity’s economic performance and which enterprise has the obligation to absorb losses or the right to receive benefits from the variable interest entity. In the event that the Company is the primary beneficiary of a variable interest entity, the assets, liabilities, and results of operations of the variable interest entity will be included in the Company’s Consolidated Financial Statements.

[0000858877-14-000029:notes:388]
(v) Use of Estimates   The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Estimates are used for the following, among others:

[0000858877-14-000029:notes:389]
| ▪ | Revenue recognition |

[0000858877-14-000029:notes:390]
| ▪ | Allowances for accounts receivable, sales returns, and financing receivables |

[0000858877-14-000029:notes:391]
| ▪ | Inventory valuation and liability for purchase commitments with contract manufacturers and suppliers |

[0000858877-14-000029:notes:392]
| ▪ | Loss contingencies and product warranties |

[0000858877-14-000029:notes:393]
| ▪ | Fair value measurements and other-than-temporary impairments |

[0000858877-14-000029:notes:394]
| ▪ | Goodwill and purchased intangible asset impairments |

[0000858877-14-000029:notes:395]
| ▪ | Income taxes |

[0000858877-14-000029:notes:396]
The actual results experienced by the Company may differ materially from management’s estimates.

[0000858877-14-000029:notes:397]
(w) New Accounting Updates Recently Adopted

[0000858877-14-000029:notes:398]
In December 2011, the Financial Accounting Standards Board (FASB) issued an accounting standard update requiring enhanced disclosures about certain financial instruments and derivative instruments that are offset in the statement of financial position or that are subject to enforceable master netting arrangements or similar agreements. This accounting standard became effective for the Company in the first quarter of fiscal 2014.  As a result of the application of this accounting standard update, the Company has provided additional disclosures in Note 11.

[0000858877-14-000029:notes:399]
In July 2012, the FASB issued an accounting standard update intended to simplify how an entity tests indefinite-lived intangible assets other than goodwill for impairment by providing entities with an option to perform a qualitative assessment to determine whether further impairment testing is necessary. This accounting standard update became effective for the Company beginning in the first quarter of fiscal 2014, and its adoption did not have any impact on the Company’s Consolidated Financial Statements.

[0000858877-14-000029:notes:400]
In February 2013, the FASB issued an accounting standard update to require reclassification adjustments from other comprehensive income to be presented either in the financial statements or in the notes to the financial statements. This accounting standard became effective for the Company in the first quarter of fiscal 2014.  As a result of the application of this accounting standard update, the Company has provided additional disclosures in Note 15.

[0000858877-14-000029:notes:401]
(x) Recent Accounting Standards or Updates Not Yet Effective

[0000858877-14-000029:notes:402]
In March 2013, the FASB issued an accounting standard update requiring an entity to release into net income the entire amount of a cumulative translation adjustment related to its investment in a foreign entity when as a parent it sells either a part or all of its investment in the foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within the foreign entity.  This accounting standard update was effective for the Company beginning in the first quarter of fiscal 2015. Upon adoption, the application of this accounting standard update did not have any impact to the Company's Consolidated Financial Statements.

[0000858877-14-000029:notes:403]
In July 2013, the FASB issued an accounting standard update that provides explicit guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists. Under the new standard update, an unrecognized tax benefit, or a portion of an unrecognized tax benefit, is to be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward or a tax credit carryforward.  This accounting standard update was effective for the Company beginning in the first quarter of fiscal 2015 and applied prospectively with early adoption permitted.  Upon adoption, the application of this accounting standard update did not have a material impact to the Company's Consolidated Financial Statements.

[0000858877-14-000029:notes:404]
In April 2014, the FASB issued an accounting standard update that changes the criteria for reporting discontinued operations.  This accounting standard update raises the threshold for a disposal transaction to qualify as a discontinued operation and requires additional disclosures about discontinued operations and disposals of individually significant components that do not qualify as discontinued operations.  This accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2016.  Early adoption is permitted, but only for disposals that have not been reported in financial statements previously issued.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-14-000029:notes:405]
In May 2014, the FASB issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance.  The underlying principle is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. This accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2018. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption.  Early adoption is not permitted.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-14-000029:notes:406]
| 13. | Shareholders’ Equity |

[0000858877-14-000029:notes:407]
| (a) | Cash Dividends on Shares of Common Stock |

[0000858877-14-000029:notes:408]
During fiscal 2014, the Company declared and paid cash dividends of $0.72 per common share, or $3.8 billion, on the Company’s outstanding common stock.  During fiscal 2013, the Company declared and paid cash dividends of $0.62 per common share, or  $3.3 billion, on the Company’s outstanding common stock.

[0000858877-14-000029:notes:409]
On August 26, 2014, the Company’s Board of Directors declared a quarterly dividend of $0.19 per common share to be paid on October 22, 2014 to all shareholders of record as of the close of business on October 2, 2014.  Any future dividends will be subject to the approval of the Company’s Board of Directors.

[0000858877-14-000029:notes:410]
| (b) | Stock Repurchase Program |

[0000858877-14-000029:notes:411]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of July 26, 2014, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program, and the remaining authorized repurchase amount was $8.6 billion, with no termination date. A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-14-000029:notes:412]
|  | SharesRepurchased |  | Weighted-Average Priceper Share |  | AmountRepurchased |
| Cumulative balance at July 28, 2012 | 3,740 |  |  | $ | 20.36 |  |  | $ | 76,133 |  |
| Repurchase of common stock under the stock repurchase program (1) | 128 |  |  | 21.63 |  |  | 2,773 |  |
| Cumulative balance at July 27, 2013 | 3,868 |  |  | 20.40 |  |  | 78,906 |  |
| Repurchase of common stock under the stock repurchase program (1) | 420 |  |  | 22.71 |  |  | 9,539 |  |
| Cumulative balance at July 26, 2014 | 4,288 |  |  | $ | 20.63 |  |  | $ | 88,445 |  |

[0000858877-14-000029:notes:413]
(1) Includes stock repurchases of $126 million, which were pending settlement as of July 26, 2014. There were no stock repurchases pending settlement as of July 27, 2013.

[0000858877-14-000029:notes:414]
The purchase price for the shares of the Company’s stock repurchased is reflected as a reduction to shareholders’ equity. The Company is required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings and (ii) a reduction of common stock and additional paid-in capital. Issuance of common stock and the tax benefit related to employee stock incentive plans are recorded as an increase to common stock and additional paid-in capital.

[0000858877-14-000029:notes:415]
| (c) | Restricted Stock Unit Withholdings |

[0000858877-14-000029:notes:416]
For the years ended July 26, 2014 and July 27, 2013, the Company repurchased approximately 18 million and 16 million shares, or $430 million and $330 million, of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.

[0000858877-14-000029:notes:417]
| (d) | Preferred Stock |

[0000858877-14-000029:notes:418]
Under the terms of the Company’s Articles of Incorporation, the Board of Directors may determine the rights, preferences, and terms of the Company’s authorized but unissued shares of preferred stock.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-14-000029:notes:419]
| 6. | Balance Sheet Details |


## us-gaap:TreasuryStockTextBlock

[0000858877-14-000029:notes:420]
Supplemental Information

[0000858877-14-000029:notes:421]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of July 26, 2014, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program with no termination date. The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):

[0000858877-14-000029:notes:422]
|  | Shares ofCommonStock |  | Common Stockand AdditionalPaid-In Capital |  | RetainedEarnings |  | Total CiscoShareholders’Equity |
| Repurchases of common stock under the repurchase program | 4,288 |  |  | $ | 21,324 |  |  | $ | 67,121 |  |  | $ | 88,445 |  |


## csco:EntityWideDisclosureOnGeographicAreasLongLivedAssetsTableTextBlock

[0000858877-14-000029:notes:423]
Property and equipment information is based on the physical location of the assets. The following table presents property and equipment information for geographic areas (in millions):

[0000858877-14-000029:notes:424]
|  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Property and equipment, net: |  |  |  |  |  |
| United States | $ | 2,697 |  |  | $ | 2,780 |  |  | $ | 2,842 |  |
| International | 555 |  |  | 542 |  |  | 560 |  |
| Total | $ | 3,252 |  |  | $ | 3,322 |  |  | $ | 3,402 |  |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-14-000029:notes:425]
The following table presents revenue for groups of similar products and services (in millions):

[0000858877-14-000029:notes:426]
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Revenue: |  |  |  |  |  |
| Switching | $ | 14,056 |  |  | $ | 14,767 |  |  | $ | 14,634 |  |
| NGN Routing | 7,662 |  |  | 8,243 |  |  | 8,395 |  |
| Service Provider Video | 3,969 |  |  | 4,855 |  |  | 3,869 |  |
| Collaboration | 3,734 |  |  | 3,956 |  |  | 4,194 |  |
| Data Center | 2,640 |  |  | 2,074 |  |  | 1,298 |  |
| Wireless | 2,265 |  |  | 2,228 |  |  | 1,697 |  |
| Security | 1,566 |  |  | 1,348 |  |  | 1,341 |  |
| Other | 280 |  |  | 558 |  |  | 898 |  |
| Product | 36,172 |  |  | 38,029 |  |  | 36,326 |  |
| Service | 10,970 |  |  | 10,578 |  |  | 9,735 |  |
| Total | $ | 47,142 |  |  | $ | 48,607 |  |  | $ | 46,061 |  |


## csco:PurchaseConsiderationSummaryNDSTableTextBlock

[0000858877-14-000029:notes:427]
The following table summarizes the purchase consideration for the NDS acquisition (in millions):


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-14-000029:notes:428]
| 17. | Segment Information and Major Customers |

[0000858877-14-000029:notes:429]
| (a) | Revenue and Gross Margin by Segment |

[0000858877-14-000029:notes:430]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system. Sales are attributed to a segment based on the ordering location of the customer. The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments. In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, impacts to cost of sales from purchase accounting adjustments to inventory, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-14-000029:notes:431]
Revenue in the United States was $24.3 billion, $24.6 billion, and $22.6 billion for fiscal 2014, 2013, and 2012, respectively.

[0000858877-14-000029:notes:432]
| (b) | Revenue for Groups of Similar Products and Services |

[0000858877-14-000029:notes:433]
The Company designs, manufactures, and sells Internet Protocol (IP)-based networking and other products related to the communications and IT industry and provides services associated with these products and their use. The Company groups its products and technologies into the following categories: Switching, NGN Routing, Service Provider Video, Collaboration, Data Center, Wireless, Security, and Other Products. These products, primarily integrated by Cisco IOS Software, link geographically dispersed local-area networks (LANs), metropolitan-area networks (MANs), and wide-area networks (WANs).

[0000858877-14-000029:notes:434]
The Company has made certain reclassifications to the product revenue amounts for prior years to conform to the current year’s presentation.

[0000858877-14-000029:notes:435]
| (c) | Additional Segment Information |

[0000858877-14-000029:notes:436]
The majority of the Company’s assets, excluding cash and cash equivalents and investments, as of July 26, 2014 and July 27, 2013 were attributable to its U.S. operations. The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $47.4 billion and $40.4 billion as of July 26, 2014 and July 27, 2013, respectively, and the remaining $4.7 billion and $10.2 billion at the respective fiscal year ends were available in the United States. In fiscal 2014, 2013, and 2012, no single customer accounted for 10% or more of the Company’s revenue.
