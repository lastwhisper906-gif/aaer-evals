# CSCO MD&A — 0000858877-14-000029


## mdna

[0000858877-14-000029:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000858877-14-000029:mdna:2]
Forward-Looking Statements

[0000858877-14-000029:mdna:3]
OVERVIEW

[0000858877-14-000029:mdna:4]
We design, manufacture, and sell Internet Protocol (IP) based networking products and services related to the communications and information technology (IT) industry. Our customers include businesses of all sizes, public institutions, telecommunications companies, other service providers and individuals. We connect people, process, data and things with products that transport data, voice, and video within buildings, across campuses, and around the world. We are a key strategic partner to companies that helps them as they seek to make the most of the Internet of Everything (IoE) and connect the unconnected.

[0000858877-14-000029:mdna:5]
A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-14-000029:mdna:6]
|  | Three Months Ended |  | Fiscal Year Ended |  |
|  | July 26, 2014 |  | July 27, 2013 |  | Variance |  | July 26, 2014 |  | July 27, 2013 |  | Variance |  |
| Revenue | $ | 12,357 |  |  | $ | 12,417 |  |  | (0.5 | )% |  | $ | 47,142 |  |  | $ | 48,607 |  |  | (3.0 | )% |  |
| Gross margin percentage | 59.9 | % |  | 59.2 | % |  | 0.7 |  | pts | 58.9 | % |  | 60.6 | % |  | (1.7 | ) | pts |
| Research and development | $ | 1,593 |  |  | $ | 1,517 |  |  | 5.0 | % |  | $ | 6,294 |  |  | $ | 5,942 |  |  | 5.9 | % |  |
| Sales and marketing | $ | 2,473 |  |  | $ | 2,360 |  |  | 4.8 | % |  | $ | 9,503 |  |  | $ | 9,538 |  |  | (0.4 | )% |  |
| General and administrative | $ | 508 |  |  | $ | 590 |  |  | (13.9 | )% |  | $ | 1,934 |  |  | $ | 2,264 |  |  | (14.6 | )% |  |
| Total R&D, sales and marketing, general and administrative | $ | 4,574 |  |  | $ | 4,467 |  |  | 2.4 | % |  | $ | 17,731 |  |  | $ | 17,744 |  |  | (0.1 | )% |  |
| Total as a percentage of revenue | 37.0 | % |  | 36.0 | % |  | 1.0 |  | pts | 37.6 | % |  | 36.5 | % |  | 1.1 |  | pts |
| Amortization of purchased intangible assets | $ | 68 |  |  | $ | 66 |  |  | 3.0 | % |  | $ | 275 |  |  | $ | 395 |  |  | (30.4 | )% |  |
| Restructuring and other charges | $ | 82 |  |  | $ | — |  |  | NM* |  | $ | 418 |  |  | $ | 105 |  |  | 298.1 | % |  |
| Operating income as a percentage of revenue | 21.7 | % |  | 22.7 | % |  | (1.0 | ) | pts | 19.8 | % |  | 23.0 | % |  | (3.2 | ) | pts |
| Income tax percentage | 19.1 | % |  | 20.9 | % |  | (1.8 | ) | pts | 19.2 | % |  | 11.1 | % |  | 8.1 |  | pts |
| Net income | $ | 2,247 |  |  | $ | 2,270 |  |  | (1.0 | )% |  | $ | 7,853 |  |  | $ | 9,983 |  |  | (21.3 | )% |  |
| Net income as a percentage of revenue | 18.2 | % |  | 18.3 | % |  | (0.1 | ) | pts | 16.7 | % |  | 20.5 | % |  | (3.8 | ) | pts |
| Earnings per share—diluted | $ | 0.43 |  |  | $ | 0.42 |  |  | 2.4 | % |  | $ | 1.49 |  |  | $ | 1.86 |  |  | (19.9 | )% |  |

[0000858877-14-000029:mdna:7]
* Not meaningful

[0000858877-14-000029:mdna:8]
36

[0000858877-14-000029:mdna:9]
Fiscal 2014 Compared with Fiscal 2013—Financial Performance

[0000858877-14-000029:mdna:10]
Total revenue decreased by 3% as compared with fiscal 2013. Within the total revenue change, product revenue decreased 5% and service revenue increased 4%. Total gross margin decreased by 1.7 percentage points,  driven by unfavorable impacts from pricing and mix partially offset by productivity improvements and also due to the $655 million charge to product cost of sales recorded in fiscal 2014 related to the expected cost of remediation of issues with memory components in certain products sold in prior fiscal years. Despite a slight year-over-year decline in absolute dollars, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 1.1 percentage points as a percentage of revenue due to the decline in revenue. Operating income as a percentage of revenue decreased by 3.2 percentage points. Diluted earnings per share decreased by 20% from the prior year, driven by a 21% decrease in net income. The decrease in net income in fiscal 2014 compared with fiscal 2013 was also attributable to net tax benefits in fiscal 2013 related to a settlement with the IRS and reinstatement of the U.S. Federal R&D tax credit.

[0000858877-14-000029:mdna:11]
Fiscal 2014 Compared with Fiscal 2013—Business Summary

[0000858877-14-000029:mdna:12]
In fiscal 2014, revenue decreased by $1.5 billion as compared with fiscal 2013. Revenue from the Americas decreased by $0.9 billion, driven by lower product revenue in most countries in this segment including the United States. While we experienced relative stability across Europe, EMEA revenue decreased $0.2 billion, led by product revenue declines in Russia as well as various other countries in this segment.  Revenue in our APJC segment decreased $0.4 billion, led by product revenue declines in Japan and India. The weakness we encountered in emerging countries throughout the world in the later part of fiscal 2013 continued during fiscal 2014.  The emerging countries of Brazil, Russia, India, China, and Mexico (“BRICM”), in the aggregate, experienced an 11% product revenue decline, with declines across all of our customer markets. We believe that the product revenue declines in many of these emerging countries were driven by the impact of economic and geopolitical challenges in these countries. While we saw some improvement in our business momentum in emerging countries in the second and third quarters of fiscal 2014, we experienced a decline in our business momentum in these countries during the fourth quarter of fiscal 2014.

[0000858877-14-000029:mdna:13]
In fiscal 2014, product revenue declined across all customer markets, with the most significant decline in the service provider market. Within the service provider market, the largest impacts came from the continued product revenue decline in our Service Provider Video category and the ongoing decline of product revenue in the emerging countries.

[0000858877-14-000029:mdna:14]
From a product category perspective, the product revenue decrease of 5% year-over-year was driven in large part by the lower product revenue within our core routing and switching product categories. While we saw improvement in business momentum with respect to high-end routers during the second half of fiscal 2014, there was only a limited revenue contribution related to some of our recently introduced products, as product transitions in this area are still in their early stages. The effects of these product transitions, combined with other challenges, led to a decrease in NGN Routing revenue of 7%. We also experienced a 5% decrease in revenue from our Switching products. The other major product categories experienced revenue changes ranging from an 18% decrease in Service Provider Video to a 27% increase in Data Center.  The decrease in revenue from our Service Provider Video products was driven largely by a decrease in revenue from sales of set-top boxes. Partially offsetting the decline in product revenue was an increase in service revenue. Service revenue increased by 4%, reflecting continued slower growth compared with prior years, which we believe was attributable to the impact of the declines in product revenue in recent periods.

[0000858877-14-000029:mdna:15]
As we continue to focus on investing in growth, innovation, and talent, while managing costs and driving efficiencies, we announced a restructuring plan that will impact up to 6,000 employees, representing approximately 8% of our global workforce. We expect to reinvest substantially all of the cost savings from the restructuring actions in our key growth areas such as data center, software, security, and cloud.

[0000858877-14-000029:mdna:16]
In summary, while we saw some improved business momentum in the second half of fiscal 2014, we experienced many challenges during fiscal 2014 including reduced spending by our service provider customers, weakness in emerging countries, the impact of product transitions, and a conservative approach to IT-related capital spending by customers. We expect that the challenges in the emerging countries, the service provider customer market, and product transitions in Switching and NGN Routing may continue for at least the next several quarters.

[0000858877-14-000029:mdna:17]
37

[0000858877-14-000029:mdna:18]
Fourth Quarter Snapshot

[0000858877-14-000029:mdna:19]
For the fourth quarter of fiscal 2014, as compared with the corresponding period in fiscal 2013, total revenue was flat. Within the total revenue change, product revenue declined by 2% and service revenue increased by 5%. With regard to our geographic segment performance, on a year-over-year basis, revenue in the Americas and in EMEA both decreased by 1% while we experienced a slight increase by 1% in our APJC segment. Total gross margin increased by 0.7 percentage points, primarily due to the TiVo patent litigation settlement in the fourth quarter of fiscal 2013. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively increased by 1.0 percentage points. Operating income as a percentage of revenue decreased by 1.0 percentage points, primarily as a result of higher restructuring and other charges, and also the impact of our revenue decrease. Diluted earnings per share increased by 2% from the prior year, primarily as a result of a decrease in our diluted share count.

[0000858877-14-000029:mdna:20]
Strategy and Focus Areas

[0000858877-14-000029:mdna:21]
Our strategy is to deliver the integrated architectures, solutions, and outcomes to help our customers grow, manage costs, and mitigate risk. We see our customers, in almost every industry, becoming increasingly reliant on technology—and specifically the network—to meet their business objectives and compete successfully in the market.

[0000858877-14-000029:mdna:22]
Our focus continues to be on capitalizing on market transitions to maintain leadership in our core markets and to enter new markets where the network is foundational.  We believe this focus best positions us to become a more relevant and trusted partner to our customers and to expand our share of our customers’ IT spending.  We are focused on driving the innovation, speed, agility, and efficiencies in our company required to deliver leading technology solutions for our customers and shareholder value for our investors.

[0000858877-14-000029:mdna:23]
Over the last few years, we have been working to transform our business to move from selling individual products and services to selling products and services integrated into architectures and solutions, as well as to meet customers' business outcomes. As a part of this transformation, we are making changes to how we are organized and how we deliver our technology.  We believe these changes enable us to better meet our customers’ requirements and help them stay ahead of market transitions.

[0000858877-14-000029:mdna:24]
For a full discussion of our strategy and focus areas, see Item 1. Business.

[0000858877-14-000029:mdna:25]
Other Key Financial Measures

[0000858877-14-000029:mdna:26]
The following is a summary of our other key financial measures for fiscal 2014 compared with fiscal 2013 (in millions, except days sales outstanding in accounts receivable (DSO) and annualized inventory turns):

[0000858877-14-000029:mdna:27]
|  |  | Fiscal 2014 |  | Fiscal 2013 |
| Cash and cash equivalents and investments |  | $52,074 |  | $50,610 |
| Cash provided by operating activities |  | $12,332 |  | $12,894 |
| Deferred revenue |  | $14,142 |  | $13,423 |
| Repurchases of common stock—stock repurchase program |  | $9,539 |  | $2,773 |
| Dividends |  | $3,758 |  | $3,310 |
| DSO |  | 38 days |  | 40 days |
| Inventories |  | $1,591 |  | $1,476 |
| Annualized inventory turns |  | 12.7 |  | 13.8 |

[0000858877-14-000029:mdna:28]
Our product backlog at the end of fiscal 2014 was $5.4 billion, or 12% of fiscal 2014 total revenue, compared with $4.9 billion at the end of fiscal 2013, or 10% of fiscal 2013 total revenue.

[0000858877-14-000029:mdna:29]
38

[0000858877-14-000029:mdna:30]
CRITICAL ACCOUNTING ESTIMATES

[0000858877-14-000029:mdna:31]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes.  Note 2 to the Consolidated Financial Statements describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements.  The accounting policies described below are significantly affected by critical accounting estimates.  Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-14-000029:mdna:32]
Revenue Recognition

[0000858877-14-000029:mdna:33]
Revenue is recognized when all of the following criteria have been met:

[0000858877-14-000029:mdna:34]
| • | Persuasive evidence of an arrangement exists. Contracts, Internet commerce agreements, and customer purchase orders are generally used to determine the existence of an arrangement. |

[0000858877-14-000029:mdna:35]
| • | Delivery has occurred. Shipping documents and customer acceptance, when applicable, are used to verify delivery. |

[0000858877-14-000029:mdna:36]
| • | The fee is fixed or determinable. We assess whether the fee is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. |

[0000858877-14-000029:mdna:37]
| • | Collectibility is reasonably assured. We assess collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer’s payment history. |

[0000858877-14-000029:mdna:38]
In instances where final acceptance of the product, system, or solution is specified by the customer, revenue is deferred until all acceptance criteria have been met.  When a sale involves multiple deliverables, such as sales of products that include services, the multiple deliverables are evaluated to determine the unit of accounting, and the entire fee from the arrangement is allocated to each unit of accounting based on the relative selling price.  Revenue is recognized when the revenue recognition criteria for each unit of accounting are met.  For hosting arrangements, we recognize subscription revenue ratably over the subscription period, while usage revenue is recognized based on utilization. Software subscription revenue is deferred and recognized ratably over the subscription term upon delivery of the first product and commencement of the term.

[0000858877-14-000029:mdna:39]
The amount of product and service revenue recognized in a given period is affected by our judgment as to whether an arrangement includes multiple deliverables and, if so, our valuation of the units of accounting for multiple deliverables. According to the accounting guidance prescribed in Accounting Standards Codification (ASC) 605, Revenue Recognition, we use vendor-specific objective evidence of selling price (VSOE) for each of those units, when available. We determine VSOE based on our normal pricing and discounting practices for the specific product or service when sold separately.  In determining VSOE, we require that a substantial majority of the historical standalone transactions have the selling prices for a product or service fall within a reasonably narrow pricing range, generally evidenced by approximately 80% of such historical standalone transactions falling within plus or minus 15% of the median rates. When VSOE does not exist, we apply the selling price hierarchy to applicable multiple-deliverable arrangements.  Under the selling price hierarchy, third-party evidence of selling price (TPE) will be considered if VSOE does not exist, and estimated selling price (ESP) will be used if neither VSOE nor TPE is available.  Generally, we are not able to determine TPE because our go-to-market strategy differs from that of others in our markets, and the extent of our proprietary technology varies among comparable products or services from those of our peers.  In determining ESP, we apply significant judgment as we weigh a variety of factors, based on the facts and circumstances of the arrangement.  We typically arrive at an ESP for a product or service that is not sold separately by considering company-specific factors such as geographies, competitive landscape, internal costs, profitability objectives, pricing practices used to establish bundled pricing, and existing portfolio pricing and discounting.

[0000858877-14-000029:mdna:40]
Some of our sales arrangements have multiple deliverables containing software and related software support components. Such sales arrangements are subject to the accounting guidance in ASC 985-605, Software-Revenue Recognition.

[0000858877-14-000029:mdna:41]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during fiscal 2014, nor do we currently expect a material impact in the next 12 months on our revenue recognition due to any changes in our VSOE, TPE, or ESP.

[0000858877-14-000029:mdna:42]
Revenue deferrals relate to the timing of revenue recognition for specific transactions based on financing arrangements, service, support, and other factors. Financing arrangements may include sales-type, direct-financing, and operating leases, loans, and guarantees of third-party financing. Our deferred revenue for products was $4.5 billion and $4.0 billion as of July 26, 2014 and July 27, 2013, respectively. Technical support services revenue is deferred and recognized ratably over the period during which the services are to be performed, which typically is from one to three years. Advanced services revenue is recognized upon delivery or completion of performance. Our deferred revenue for services was $9.6 billion and $9.4 billion as of July 26, 2014 and July 27, 2013, respectively.

[0000858877-14-000029:mdna:43]
We make sales to distributors which we refer to as two-tier systems of sales to the end customer.  Revenue from distributors is recognized based on a sell-through method using information provided by them.  Our distributors participate in various cooperative marketing and other programs, and we maintain estimated accruals and allowances for these programs.  If actual credits received by our distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-14-000029:mdna:44]
Allowances for Receivables and Sales Returns

[0000858877-14-000029:mdna:45]
The allowances for receivables were as follows (in millions, except percentages):

[0000858877-14-000029:mdna:46]
|  |  | July 26, 2014 |  |  | July 27, 2013 |  |
| Allowance for doubtful accounts |  | $ | 265 |  |  | $ | 228 |  |
| Percentage of gross accounts receivable |  | 4.9 | % |  | 4.0 | % |
| Allowance for credit loss—lease receivables |  | $ | 233 |  |  | $ | 238 |  |
| Percentage of gross lease receivables |  | 6.2 | % |  | 6.3 | % |
| Allowance for credit loss—loan receivables |  | $ | 98 |  |  | $ | 86 |  |
| Percentage of gross loan receivables |  | 5.8 | % |  | 5.2 | % |

[0000858877-14-000029:mdna:47]
The allowance for doubtful accounts is based on our assessment of the collectibility of customer accounts. We regularly review the adequacy of these allowances by considering internal factors such as historical experience, credit quality and age of the receivable balances as well as external factors such as economic conditions that may affect a customer’s ability to pay and expected default frequency rates, which are published by major third-party credit-rating agencies and are generally updated on a quarterly basis. We also consider the concentration of receivables outstanding with a particular customer in assessing the adequacy of our allowances for doubtful accounts. If a major customer’s creditworthiness deteriorates, if actual defaults are higher than our historical experience, or if other circumstances arise, our estimates of the recoverability of amounts due to us could be overstated, and additional allowances could be required, which could have an adverse impact on our operating results.

[0000858877-14-000029:mdna:48]
The allowance for credit loss on financing receivables is also based on the assessment of collectibility of customer accounts. We regularly review the adequacy of the credit allowances determined either on an individual or a collective basis. When evaluating the financing receivables on an individual basis, we consider historical experience, credit quality and age of receivable balances, and economic conditions that may affect a customer’s ability to pay.   When evaluating financing receivables on a collective basis, we use expected default frequency rates published by a major third-party credit-rating agency as well as our own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk and correlation.  Determining expected default frequency rates and loss factors associated with internal credit risk ratings, as well as assessing factors such as economic conditions, concentration of risk, and correlation, are complex and subjective. Our ongoing consideration of all these factors could result in an increase in our allowance for credit loss in the future, which could adversely affect our operating results.  Both accounts receivable and financing receivables are charged off at the point when they are considered uncollectible.

[0000858877-14-000029:mdna:49]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of July 26, 2014 and July 27, 2013 was $135 million and $119 million, respectively, and was recorded as a reduction of our accounts receivable.  If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-14-000029:mdna:50]
Inventory Valuation and Liability for Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-14-000029:mdna:51]
Our inventory balance was $1.6 billion and $1.5 billion as of July 26, 2014 and July 27, 2013, respectively. Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and market, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-14-000029:mdna:52]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 26, 2014, the liability for these purchase commitments was $162 million, compared with $172 million as of July 27, 2013, and was included in other current liabilities.

[0000858877-14-000029:mdna:53]
40

[0000858877-14-000029:mdna:54]
Our provision for inventory was $67 million, $114 million, and $115 million for fiscal 2014, 2013, and 2012, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $124 million, $106 million, and $151 million in fiscal 2014, 2013, and 2012, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence, particularly in light of current macroeconomic uncertainties and conditions and the resulting potential for changes in future demand forecast.

[0000858877-14-000029:mdna:55]
Loss Contingencies and Product Warranties

[0000858877-14-000029:mdna:56]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-14-000029:mdna:57]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-14-000029:mdna:58]
We have recorded a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. In February 2014, on the basis of the growing number of failures as described in Note 12 (f) to the Consolidated Financial Statements, we decided to expand our approach, which resulted in an additional charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  Estimating this liability is complex and subjective, and if we experience changes in a number of underlying assumptions and estimates such as a change in claims compared with our expectations, or if the cost of servicing these claims is different than expected, our estimated liability may be impacted.

[0000858877-14-000029:mdna:59]
Our liability for product warranties, included in other current liabilities, was $446 million as of July 26, 2014, compared with $402 million as of July 27, 2013. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty. We accrue for warranty costs as part of our cost of sales based on associated material costs, technical support labor costs, and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends in the rate of customer cases and the cost to support the customer cases within the warranty period. Overhead cost is applied based on estimated time to support warranty activities.

[0000858877-14-000029:mdna:60]
The provision for product warranties during fiscal 2014, 2013, and 2012 was $704 million, $649 million, and $617 million, respectively. If we experience an increase in warranty claims compared with our historical experience, or if the cost of servicing warranty claims is greater than expected, our profitability could be adversely affected.

[0000858877-14-000029:mdna:61]
Fair Value Measurements

[0000858877-14-000029:mdna:62]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $45.3 billion as of July 26, 2014, compared with $42.7 billion as of July 27, 2013. Our fixed income investment portfolio, as of July 26, 2014, consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-14-000029:mdna:63]
As described more fully in Note 2 to the Consolidated Financial Statements, a valuation hierarchy is based on the level of independent, objective evidence available regarding the value of the investments. It encompasses three classes of investments: Level 1 consists of securities for which there are quoted prices in active markets for identical securities; Level 2 consists of securities for which observable inputs other than Level 1 inputs are used, such as quoted prices for similar securities in active markets or quoted prices for identical securities in less active markets and model-derived valuations for which the variables are derived from, or corroborated by, observable market data; and Level 3 consists of securities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value.

[0000858877-14-000029:mdna:64]
Our Level 2 securities are valued using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from independent pricing vendors, quoted market prices, or other sources to determine the ultimate fair value of our assets and liabilities. We use such pricing data as the primary input, to which we have not made any material adjustments during fiscal 2014 and 2013, to make our assessments and determinations as to the ultimate valuation of our investment portfolio. We are ultimately responsible for the financial statements and underlying estimates.

[0000858877-14-000029:mdna:65]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of July 26, 2014. Level 3 assets do not represent a significant portion of our total assets measured at fair value on a recurring basis as of July 26, 2014.

[0000858877-14-000029:mdna:66]
Other-than-Temporary Impairments

[0000858877-14-000029:mdna:67]
We recognize an impairment charge when the declines in the fair values of our fixed income or publicly traded equity securities below their cost basis are judged to be other than temporary. The ultimate value realized on these securities, to the extent unhedged, is subject to market price volatility until they are sold.

[0000858877-14-000029:mdna:68]
If the fair value of a debt security is less than its amortized cost, we assess whether the impairment is other than temporary. An impairment is considered other than temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of its entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost of the security. If an impairment is considered other than temporary based on (i) or (ii) described in the prior sentence, the entire difference between the amortized cost and the fair value of the security is recognized in earnings. If an impairment is considered other than temporary based on condition (iii), the amount representing credit loss, defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security, will be recognized in earnings, and the amount relating to all other factors will be recognized in other comprehensive income (OCI). In estimating the amount and timing of cash flows expected to be collected, we consider all available information, including past events, current conditions, the remaining payment terms of the security, the financial condition of the issuer, expected defaults, and the value of underlying collateral.

[0000858877-14-000029:mdna:69]
For publicly traded equity securities, we consider various factors in determining whether we should recognize an impairment charge, including the length of time and extent to which the fair value has been less than our cost basis, the financial condition and near-term prospects of the issuer, and our intent and ability to hold the investment for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-14-000029:mdna:70]
For fiscal 2014, impairment charges of $11 million on our investments in publicly traded equity securities were recognized in earnings, while there were no such impairment charges in fiscal 2013 and 2012. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-14-000029:mdna:71]
We also have investments in privately held companies, some of which are in the startup or development stages. As of July 26, 2014, our investments in privately held companies were $899 million, compared with $833 million as of July 27, 2013, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize. Our impairment charges on investments in privately held companies were $23 million, $33 million, and $23 million in fiscal 2014, 2013, and 2012, respectively.

[0000858877-14-000029:mdna:72]
Goodwill and Purchased Intangible Asset Impairments

[0000858877-14-000029:mdna:73]
Our methodology for allocating the purchase price relating to purchase acquisitions is determined through established valuation techniques. Goodwill represents a residual value as of the acquisition date, which in most cases results in measuring goodwill as an excess of the purchase consideration transferred plus the fair value of any noncontrolling interest in the acquired company over the fair value of net assets acquired, including contingent consideration. We perform goodwill impairment tests on an annual basis in the fourth fiscal quarter and between annual tests in certain circumstances for each reporting unit. The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the new accounting guidance for the fair value measurement of nonfinancial assets.

[0000858877-14-000029:mdna:74]
The goodwill recorded in the Consolidated Balance Sheets as of July 26, 2014 and July 27, 2013 was $24.2 billion and $21.9 billion, respectively. The increase in goodwill for fiscal 2014 was due in large part to our acquisition of Sourcefire, Inc. In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill resulting from our annual impairment testing in fiscal 2014, 2013, and 2012. For the annual impairment testing in fiscal 2014, the excess of the fair value over the carrying value for each of our reporting units was $32.0 billion for the Americas, $22.0 billion for EMEA, and $16.2 billion for APJC.  During the fourth quarter of fiscal 2014, we performed a sensitivity analysis for goodwill impairment with respect to each of our respective reporting units and determined that a hypothetical 10% decline in the fair value of each reporting unit would not result in an impairment of goodwill for any reporting unit.

[0000858877-14-000029:mdna:75]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. There were no impairment charges related to purchased intangible assets during fiscal 2014 and fiscal 2013. Our impairment charges related to purchased intangible assets were $12 million during fiscal 2012. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-14-000029:mdna:76]
Income Taxes

[0000858877-14-000029:mdna:77]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 19.2%, 11.1%, and 20.8% in fiscal 2014, 2013, and 2012, respectively.

[0000858877-14-000029:mdna:78]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.

[0000858877-14-000029:mdna:79]
Significant judgment is also required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000858877-14-000029:mdna:80]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by expiration of or lapses in the R&D tax credit or domestic manufacturing deduction laws; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our intercompany R&D cost-sharing arrangement and legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including possible changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, or the foreign tax credit rules.  Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes.  The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 34 countries, including the United States, is contemplating changes to numerous long-standing tax principles.  These contemplated changes, if finalized and adopted by countries, will increase tax uncertainty and may adversely affect our provision for income taxes.  As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates and in some cases is wholly exempt from tax. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the IRS and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-14-000029:mdna:81]
43

[0000858877-14-000029:mdna:82]
RESULTS OF OPERATIONS

[0000858877-14-000029:mdna:83]
Revenue

[0000858877-14-000029:mdna:84]
The following table presents the breakdown of revenue between product and service (in millions, except percentages):

[0000858877-14-000029:mdna:85]
| Years Ended |  | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | July 27, 2013 |  | July 28, 2012 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 36,172 |  |  | $ | 38,029 |  |  | $ | (1,857 | ) |  | (4.9 | )% |  | $ | 38,029 |  |  | $ | 36,326 |  |  | $ | 1,703 |  |  | 4.7 | % |
| Percentage of revenue |  | 76.7 | % |  | 78.2 | % |  |  |  |  |  |  |  | 78.2 | % |  | 78.9 | % |  |  |  |  |  |  |
| Service |  | 10,970 |  |  | 10,578 |  |  | 392 |  |  | 3.7 | % |  | 10,578 |  |  | 9,735 |  |  | 843 |  |  | 8.7 | % |
| Percentage of revenue |  | 23.3 | % |  | 21.8 | % |  |  |  |  |  |  |  | 21.8 | % |  | 21.1 | % |  |  |  |  |  |  |
| Total |  | $ | 47,142 |  |  | $ | 48,607 |  |  | $ | (1,465 | ) |  | (3.0 | )% |  | $ | 48,607 |  |  | $ | 46,061 |  |  | $ | 2,546 |  |  | 5.5 | % |

[0000858877-14-000029:mdna:86]
We manage our business primarily on a geographic basis, organized into three geographic segments. Our revenue, which includes product and service for each segment, is summarized in the following table (in millions, except percentages):

[0000858877-14-000029:mdna:87]
| Years Ended |  | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | July 27, 2013 |  | July 28, 2012 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 27,781 |  |  | $ | 28,639 |  |  | $ | (858 | ) |  | (3.0 | )% |  | $ | 28,639 |  |  | $ | 26,501 |  |  | $ | 2,138 |  |  | 8.1 | % |
| Percentage of revenue |  | 58.9 | % |  | 58.9 | % |  |  |  |  |  | 58.9 | % |  | 57.5 | % |  |  |  |  |
| EMEA |  | 12,006 |  |  | 12,210 |  |  | (204 | ) |  | (1.7 | )% |  | 12,210 |  |  | 12,075 |  |  | 135 |  |  | 1.1 | % |
| Percentage of revenue |  | 25.5 | % |  | 25.1 | % |  |  |  |  |  | 25.1 | % |  | 26.2 | % |  |  |  |  |
| APJC |  | 7,355 |  |  | 7,758 |  |  | (403 | ) |  | (5.2 | )% |  | 7,758 |  |  | 7,485 |  |  | 273 |  |  | 3.6 | % |
| Percentage of revenue |  | 15.6 | % |  | 16.0 | % |  |  |  |  |  | 16.0 | % |  | 16.3 | % |  |  |  |  |
| Total |  | $ | 47,142 |  |  | $ | 48,607 |  |  | $ | (1,465 | ) |  | (3.0 | )% |  | $ | 48,607 |  |  | $ | 46,061 |  |  | $ | 2,546 |  |  | 5.5 | % |

[0000858877-14-000029:mdna:88]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:89]
For fiscal 2014, as compared with fiscal 2013, total revenue decreased by 3%. Product revenue decreased by 5%, while service revenue increased by 4%.  The decrease in product revenue reflected declines across all geographic segments as well as across all customer markets. Service revenues experienced slower growth in our Americas and APJC geographic segments while we experienced slightly faster growth in the EMEA segment.

[0000858877-14-000029:mdna:90]
Across our geographic segments, product revenue for most of our emerging countries experienced a decline. The emerging countries of BRICM, in the aggregate, experienced an 11% product revenue decline, with declines across all of our customer markets.

[0000858877-14-000029:mdna:91]
We conduct business globally in numerous currencies. The direct effect of foreign currency fluctuations on revenue has not been material because our revenue is primarily denominated in U.S. dollars. However, if the U.S. dollar strengthens relative to other currencies, such strengthening could have an indirect effect on our revenue to the extent it raises the cost of our products to non-U.S. customers and thereby reduces demand. A weaker U.S. dollar could have the opposite effect. However, the precise indirect effect of currency fluctuations is difficult to measure or predict because our revenue is influenced by many factors in addition to the impact of such currency fluctuations. Our revenue in fiscal 2014 may have been adversely affected by the depreciation of the local currency relative to the U.S. dollar in certain emerging countries, although such indirect effects are difficult to measure, as noted.

[0000858877-14-000029:mdna:92]
In addition to the impact of macroeconomic factors, including a reduced IT spending environment and budget-driven reductions in spending by government entities, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple-element arrangements; the mix of financing arrangements provided to our channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment. As has been the case in certain of our emerging countries from time to time, customers require greater levels of financing arrangements, service, and support, and these activities may occur in future periods, which may also impact the timing of the recognition of revenue.

[0000858877-14-000029:mdna:93]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:94]
For fiscal 2013, as compared with fiscal 2012, total revenue increased by 6%. Within total revenue growth, product revenue increased by 5%, while service revenue increased by 9%. Our product and service revenue totals reflected revenue growth across each of our geographic segments. The revenue increase was primarily due to the following: the solid performance of our Service offerings, our acquisition of NDS at the beginning of fiscal 2013, and increased demand for our Data Center and Wireless products.

[0000858877-14-000029:mdna:95]
Product Revenue by Segment

[0000858877-14-000029:mdna:96]
The following table presents the breakdown of product revenue by segment (in millions, except percentages):

[0000858877-14-000029:mdna:97]
| Years Ended |  | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | July 27, 2013 |  | July 28, 2012 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 20,631 |  |  | $ | 21,653 |  |  | $ | (1,022 | ) |  | (4.7 | )% |  | $ | 21,653 |  |  | $ | 20,168 |  |  | $ | 1,485 |  |  | 7.4 | % |
| Percentage of product revenue |  | 57.0 | % |  | 57.0 | % |  |  |  |  |  | 57.0 | % |  | 55.5 | % |  |  |  |  |
| EMEA |  | 9,655 |  |  | 10,049 |  |  | (394 | ) |  | (3.9 | )% |  | 10,049 |  |  | 10,024 |  |  | 25 |  |  | 0.2 | % |
| Percentage of product revenue |  | 26.7 | % |  | 26.4 | % |  |  |  |  |  | 26.4 | % |  | 27.6 | % |  |  |  |  |
| APJC |  | 5,886 |  |  | 6,327 |  |  | (441 | ) |  | (7.0 | )% |  | 6,327 |  |  | 6,134 |  |  | 193 |  |  | 3.1 | % |
| Percentage of product revenue |  | 16.3 | % |  | 16.6 | % |  |  |  |  |  | 16.6 | % |  | 16.9 | % |  |  |  |  |
| Total |  | $ | 36,172 |  |  | $ | 38,029 |  |  | $ | (1,857 | ) |  | (4.9 | )% |  | $ | 38,029 |  |  | $ | 36,326 |  |  | $ | 1,703 |  |  | 4.7 | % |

[0000858877-14-000029:mdna:98]
Americas

[0000858877-14-000029:mdna:99]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:100]
Product revenue in the Americas segment decreased by 5%, led by a significant decline in the service provider market and, to a lesser extent, declines in the public sector and commercial markets.  Product revenue declined in the U.S. public sector market, led by lower sales to the U.S. federal government.  From a country perspective, product revenue decreased by 5% in the United States, 10% in Canada, and 13% in Brazil, partially offset by an increase of 2% in Mexico.

[0000858877-14-000029:mdna:101]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:102]
For fiscal 2013, as compared with fiscal 2012, product revenue in the Americas segment increased by 7%. The increase in product revenue was across most of our customer markets in the Americas segment, led by solid growth in the service provider and commercial markets and, to a lesser degree, growth in the enterprise market. The growth in product revenue in the service provider market was due in large part to our acquisition of NDS at the beginning of fiscal 2013. Within the Americas segment, we experienced a product revenue decline in the public sector market, driven by lower sales to the public sector in the United States.  From a country perspective, product revenue increased by 9% in the United States, 13% in Brazil, and 7% in Mexico.  During the fourth quarter of fiscal 2013, we experienced some weakness in our business momentum in certain countries within Latin America.

[0000858877-14-000029:mdna:103]
EMEA

[0000858877-14-000029:mdna:104]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:105]
Product revenue in the EMEA segment decreased by 4%, led by a decline in the service provider market and, to a lesser extent, declines in the enterprise and public sector markets. Product revenue from emerging countries within EMEA decreased by 11%, led by a 24% decrease in Russia.  Product revenue for the remainder of EMEA, which is primarily composed of countries in western Europe, declined by 2%.

[0000858877-14-000029:mdna:106]
45

[0000858877-14-000029:mdna:107]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:108]
In fiscal 2013, we experienced a continuation of many of the macroeconomic challenges we faced in EMEA in fiscal 2012.  While we did see some improvements in most of the European economy as the fiscal year progressed, we continued to see weakness in southern Europe throughout fiscal 2013.  For fiscal 2013, as compared with fiscal 2012, product revenue in the EMEA segment was flat, as growth in the commercial, service provider and public sector markets was offset by a decline in the enterprise market. The growth in product revenue in the service provider market was due to our acquisition of NDS at the beginning of fiscal 2013. From a country perspective, product revenue increased by 1% in the United Kingdom, 11% in Russia, 4% in Switzerland, and 3% in Spain. These increases were offset by product revenue declines of 3% in each of Germany and France and 13% in the Netherlands. Product revenue for Italy was flat year over year.

[0000858877-14-000029:mdna:109]
APJC

[0000858877-14-000029:mdna:110]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:111]
Product revenue in the APJC segment decreased by 7%, led by declines in the service provider and enterprise markets and, to a lesser extent, a decline in the commercial market. We continued to experience declines in many of the emerging countries within this segment, most notably in India which experienced a year-over-year product revenue decline of 15%.  Other countries that contributed to the weakness in this segment included Japan, Australia, and China, which experienced year-over-year product revenue declines of 11%, 7%, and 6%, respectively.

[0000858877-14-000029:mdna:112]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:113]
For fiscal 2013, as compared with fiscal 2012, product revenue in the APJC segment increased by 3%. We experienced solid product revenue growth in the commercial and service provider markets and, to a lesser degree, in the public sector market. The growth in product revenue in the service provider market was due primarily to our acquisition of NDS at the beginning of fiscal 2013. From a country perspective, product revenue increased by 3% in Australia, 34% in India, and 10% in South Korea.  These increases were partially offset by product revenue declines of 5% in China and 7% in Japan, reflecting certain challenges that we faced in these countries during portions of fiscal 2013, most notably in the fourth quarter of fiscal 2013.

[0000858877-14-000029:mdna:114]
Product Revenue by Groups of Similar Products

[0000858877-14-000029:mdna:115]
In addition to the primary view on a geographic basis, we also prepare financial information related to groups of similar products and customer markets for various purposes. Our product categories consist of the following categories (with subcategories in parentheses): Switching (fixed switching, modular switching, and storage); NGN Routing (high-end routers, mid-range and low-end routers, and other NGN Routing products); Service Provider Video (infrastructure, video software and solutions); Collaboration (unified communications, Cisco TelePresence, and conferencing); Data Center; Wireless; Security; and Other Products. The Other Products category consists primarily of emerging technology products and other networking products.

[0000858877-14-000029:mdna:116]
The following table presents revenue for groups of similar products (in millions, except percentages):

[0000858877-14-000029:mdna:117]
| Years Ended |  | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | July 27, 2013 |  | July 28, 2012 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 14,056 |  |  | $ | 14,767 |  |  | $ | (711 | ) |  | (4.8 | )% |  | $ | 14,767 |  |  | $ | 14,634 |  |  | $ | 133 |  |  | 0.9 | % |
| Percentage of product revenue |  | 38.9 | % |  | 38.8 | % |  |  |  |  |  |  |  | 38.8 | % |  | 40.3 | % |  |  |  |  |  |  |
| NGN Routing |  | 7,662 |  |  | 8,243 |  |  | (581 | ) |  | (7.0 | )% |  | 8,243 |  |  | 8,395 |  |  | (152 | ) |  | (1.8 | )% |
| Percentage of product revenue |  | 21.2 | % |  | 21.7 | % |  |  |  |  |  |  |  | 21.7 | % |  | 23.1 | % |  |  |  |  |  |  |
| Service Provider Video |  | 3,969 |  |  | 4,855 |  |  | (886 | ) |  | (18.2 | )% |  | 4,855 |  |  | 3,869 |  |  | 986 |  |  | 25.5 | % |
| Percentage of product revenue |  | 11.0 | % |  | 12.8 | % |  |  |  |  |  |  |  | 12.8 | % |  | 10.7 | % |  |  |  |  |  |  |
| Collaboration |  | 3,734 |  |  | 3,956 |  |  | (222 | ) |  | (5.6 | )% |  | 3,956 |  |  | 4,194 |  |  | (238 | ) |  | (5.7 | )% |
| Percentage of product revenue |  | 10.3 | % |  | 10.4 | % |  |  |  |  |  |  |  | 10.4 | % |  | 11.5 | % |  |  |  |  |  |  |
| Data Center |  | 2,640 |  |  | 2,074 |  |  | 566 |  |  | 27.3 | % |  | 2,074 |  |  | 1,298 |  |  | 776 |  |  | 59.8 | % |
| Percentage of product revenue |  | 7.3 | % |  | 5.5 | % |  |  |  |  |  | 5.5 | % |  | 3.6 | % |  |  |  |  |
| Wireless |  | 2,265 |  |  | 2,228 |  |  | 37 |  |  | 1.7 | % |  | 2,228 |  |  | 1,697 |  |  | 531 |  |  | 31.3 | % |
| Percentage of product revenue |  | 6.3 | % |  | 5.9 | % |  |  |  |  |  |  |  | 5.9 | % |  | 4.7 | % |  |  |  |  |  |  |
| Security |  | 1,566 |  |  | 1,348 |  |  | 218 |  |  | 16.2 | % |  | 1,348 |  |  | 1,341 |  |  | 7 |  |  | 0.5 | % |
| Percentage of product revenue |  | 4.3 | % |  | 3.5 | % |  |  |  |  |  |  |  | 3.5 | % |  | 3.7 | % |  |  |  |  |  |  |
| Other |  | 280 |  |  | 558 |  |  | (278 | ) |  | (49.8 | )% |  | 558 |  |  | 898 |  |  | (340 | ) |  | (37.9 | )% |
| Percentage of product revenue |  | 0.7 | % |  | 1.4 | % |  |  |  |  |  |  |  | 1.4 | % |  | 2.4 | % |  |  |  |  |  |  |
| Total |  | $ | 36,172 |  |  | $ | 38,029 |  |  | $ | (1,857 | ) |  | (4.9 | )% |  | $ | 38,029 |  |  | $ | 36,326 |  |  | $ | 1,703 |  |  | 4.7 | % |

[0000858877-14-000029:mdna:118]
Switching

[0000858877-14-000029:mdna:119]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:120]
Revenue in our Switching product category decreased by 5%, or $711 million, driven by a 12%, or $656 million, decrease in revenue from our modular switches. Revenue from our modular switches decreased due to lower sales of Cisco Catalyst 6000 Series Switches. We also experienced a 3% decrease in sales of storage products within this category. Revenue from our LAN fixed-configuration switches was relatively flat year over year, as lower sales of most of our fixed-configuration Cisco Catalyst Series Switches and fixed-configuration Cisco Nexus Series Switches were offset by the continued adoption of Cisco Catalyst 3850 Series Switches and Cisco Nexus 6000 Series Switches.

[0000858877-14-000029:mdna:121]
47

[0000858877-14-000029:mdna:122]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:123]
Product revenue in our Switching category increased by 1%, or $133 million as higher sales of LAN fixed-configuration switches were partially offset by lower sales of modular switches and storage products. Sales of LAN fixed-configuration switches increased by 4%, or $347 million, while sales of modular switches decreased by 1%, or approximately $76 million. The increase in sales of LAN fixed-configuration switches was primarily due to higher sales of Cisco Nexus Series Switches, partially offset by sales declines in certain of our Cisco Catalyst product families. Sales of modular switches decreased due to lower sales of Cisco Catalyst 6000 Series Switches, partially offset by higher sales in Cisco Nexus 7000 Series Switches. Product revenue in the Switching category was also negatively impacted by a 24% decrease in sales of storage products.

[0000858877-14-000029:mdna:124]
NGN Routing

[0000858877-14-000029:mdna:125]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:126]
The decrease in revenue in our NGN Routing product category of 7%, or $581 million, was driven by a 6%, or $278 million, decrease in revenue from high-end router products; a 9%, or $249 million, decrease in revenue from our midrange and low-end router products; and an 8%, or $54 million, decrease in revenue from other NGN Routing products. Revenue from our high-end products decreased due to lower sales of Cisco CRS-3 Carrier Routing System products and our legacy high-end router products, partially offset by increased sales of our Cisco Aggregation Services Routers (ASR) edge products. The decrease in revenue from our midrange and low-end router products was driven by lower sales of our Cisco Integrated Services Routers (ISR) products. Revenue from other NGN Routing products decreased due to lower sales of certain optical networking products.

[0000858877-14-000029:mdna:127]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:128]
Sales in our NGN Routing product category decreased by 2%, or $152 million, driven by a 3%, or $141 million, decrease in sales of high-end router products and an 8%, or $58 million, decrease in sales of other NGN Routing products. These decreases were partially offset by a 2%, or $47 million, increase in sales of our midrange and low-end router products. Within the high-end router product category, we experienced lower sales of our Cisco CRS-1 and CRS-3 Carrier Routing System products and our legacy high-end router products, partially offset by continued adoption of our Cisco ASR products. Higher sales in our midrange and low-end router products were driven by the continued adoption of our Cisco ISR platform. The decline in sales of other NGN Routing products was due to decreased sales of certain other routing and optical networking products.

[0000858877-14-000029:mdna:129]
Service Provider Video

[0000858877-14-000029:mdna:130]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:131]
Revenue in our Service Provider Video product category decreased by 18%, or $886 million,  with the largest driver of the decline being a 21%, or $812 million, decrease in sales of our Service Provider Video infrastructure products. The revenue decline in Service Provider Video infrastructure products, which includes connected devices products, was due primarily to lower sales of set-top boxes.

[0000858877-14-000029:mdna:132]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:133]
Our Service Provider Video products category grew by 25%, or $986 million, due primarily to the acquisition of NDS at the beginning of fiscal 2013. Higher revenue from our Service Provider Video infrastructure products also contributed to the increase. The increase in sales of our Service Provider Video infrastructure products was primarily due to increased sales of set-top boxes.

[0000858877-14-000029:mdna:134]
Collaboration

[0000858877-14-000029:mdna:135]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:136]
We continue to increase the proportion of recurring revenue in our Collaboration product category. Overall, revenue in our Collaboration product category decreased by 6%, or $222 million, primarily due to decreased revenue from our Cisco TelePresence and Unified Communications products, driven by weakness in endpoint products such as phones. These decreases were partially offset by higher revenue from our conferencing products.

[0000858877-14-000029:mdna:137]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:138]
Sales of Collaboration products decreased by 6%, or $238 million, primarily due to a decline in sales of Cisco TelePresence Systems and, to a lesser degree, a decline in sales of Unified Communications products. Lower public sector spending in the United States, as well as demand weakness in Europe, were significant drivers of the decline in sales of Cisco TelePresence Systems. We also experienced a decline in sales of Unified Communications products, which was due primarily to lower sales of Unified Communications infrastructure products as a result of our sales emphasis on shifting towards products with recurring revenue streams.

[0000858877-14-000029:mdna:139]
48

[0000858877-14-000029:mdna:140]
Data Center

[0000858877-14-000029:mdna:141]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:142]
We continue to experience solid growth in our Data Center product category, which grew by 27%, or $566 million, with sales growth of our Cisco Unified Computing System products across all geographic segments and customer markets. The increase was due in large part to the continued momentum we are experiencing in both data center and cloud environments, as current customers increase their data center build-outs, and as new customers deploy these offerings.

[0000858877-14-000029:mdna:143]
To the extent our data center business grows and further penetrates the market, we expect that, in comparison to what we experienced during the initial rapid growth of this business, the growth rates for our data center product sales will experience more normal seasonality consistent with the overall server market.

[0000858877-14-000029:mdna:144]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:145]
We experienced strong growth in our Data Center product category, which grew by 60%, or $776 million, with strong sales growth of our Cisco Unified Computing System products across all geographic segments and customer markets. The increase was due in large part to the continued momentum we are experiencing with our products for both data center and cloud environments, as current customers increase their data center build-outs and as new customers deploy these offerings.

[0000858877-14-000029:mdna:146]
Wireless

[0000858877-14-000029:mdna:147]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:148]
We continue to increase the proportion of recurring revenue in our Wireless product category. Revenue in our Wireless product category increased by 2%, or $37 million, due to an increase in sales of Meraki products, which we acquired in the second quarter of fiscal 2013, partially offset by lower sales of other wireless products.

[0000858877-14-000029:mdna:149]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:150]
Sales of Wireless products increased by 31%, or $531 million. This increase reflects the continued customer adoption of and migration to the unified access architecture of the Cisco Unified Wireless Network, and also reflects increased sales of new products in this category as well as sales of products related to our acquisition of Meraki.

[0000858877-14-000029:mdna:151]
Security

[0000858877-14-000029:mdna:152]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:153]
We continue to increase the proportion of recurring revenue in our Security product category. Revenue in our Security product category was up 16%, or $218 million, driven primarily by sales of Sourcefire products, which company we acquired in the first quarter of fiscal 2014 and, to a lesser degree, by both higher sales of our high-end firewall products within our network security product portfolio and slightly higher sales of our content security products.

[0000858877-14-000029:mdna:154]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:155]
Sales of Security products were flat as higher sales in high-end firewall products within our network security product portfolio were offset by lower sales of our content security products.

[0000858877-14-000029:mdna:156]
Other Products

[0000858877-14-000029:mdna:157]
We experienced a year-over-year decrease in revenue in our Other Products category for both fiscal 2014 and 2013, due in large part to the sale of our Linksys product line in the third quarter of fiscal 2013.

[0000858877-14-000029:mdna:158]
Service Revenue by Segment

[0000858877-14-000029:mdna:159]
The following table presents the breakdown of service revenue by segment (in millions, except percentages):

[0000858877-14-000029:mdna:160]
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | July 27, 2013 |  | July 28, 2012 |  | Variance in Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 7,150 |  |  | $ | 6,986 |  |  | $ | 164 |  |  | 2.3 | % |  | $ | 6,986 |  |  | $ | 6,333 |  |  | $ | 653 |  |  | 10.3 | % |
| Percentage of service revenue | 65.2 | % |  | 66.1 | % |  |  |  |  |  | 66.1 | % |  | 65.0 | % |  |  |  |  |
| EMEA | 2,351 |  |  | 2,161 |  |  | 190 |  |  | 8.8 | % |  | 2,161 |  |  | 2,051 |  |  | 110 |  |  | 5.4 | % |
| Percentage of service revenue | 21.4 | % |  | 20.4 | % |  |  |  |  |  | 20.4 | % |  | 21.1 | % |  |  |  |  |
| APJC | 1,469 |  |  | 1,431 |  |  | 38 |  |  | 2.7 | % |  | 1,431 |  |  | 1,351 |  |  | 80 |  |  | 5.9 | % |
| Percentage of service revenue | 13.4 | % |  | 13.5 | % |  |  |  |  |  | 13.5 | % |  | 13.9 | % |  |  |  |  |
| Total | $ | 10,970 |  |  | $ | 10,578 |  |  | $ | 392 |  |  | 3.7 | % |  | $ | 10,578 |  |  | $ | 9,735 |  |  | $ | 843 |  |  | 8.7 | % |

[0000858877-14-000029:mdna:161]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:162]
Service revenue continued to experience slower growth than in prior fiscal years, with varying levels of growth across our geographic segments. Worldwide technical support services revenue increased by 4% while worldwide advanced services revenue experienced 3% growth. Technical support service revenue experienced growth across all geographic segments. Renewals and technical support service contract initiations associated with product sales provided an installed base of equipment being serviced which, in concert with new service offerings, were the primary factors driving the revenue increases. Advanced services revenue, which relates to consulting support services for specific customer network needs, slightly declined in the Americas segment but had solid growth in the EMEA and APJC segments due to growth in subscription revenues.

[0000858877-14-000029:mdna:163]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:164]
Service revenue experienced solid growth across all of our geographic segments. Worldwide technical support services revenue increased by 6%, and worldwide advanced services experienced 16% revenue growth. Technical support service experienced growth across all of our geographic segments, led by growth in our Americas segment. Renewals and technical support service contract initiations associated with product sales provided an installed base of equipment being serviced which, in concert with new service offerings, were the primary factors driving these increases. We experienced revenue growth in advanced services across all geographic segments, led by growth in the Americas segment. Advanced services revenue growth was driven by solid growth in both transaction and subscription revenues.

[0000858877-14-000029:mdna:165]
Gross Margin

[0000858877-14-000029:mdna:166]
The following table presents the gross margin for products and services (in millions, except percentages):

[0000858877-14-000029:mdna:167]
|  | AMOUNT |  | PERCENTAGE |
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 20,531 |  |  | $ | 22,488 |  |  | $ | 21,821 |  |  | 56.8 | % |  | 59.1 | % |  | 60.1 | % |
| Service | 7,238 |  |  | 6,952 |  |  | 6,388 |  |  | 66.0 | % |  | 65.7 | % |  | 65.6 | % |
| Total | $ | 27,769 |  |  | $ | 29,440 |  |  | $ | 28,209 |  |  | 58.9 | % |  | 60.6 | % |  | 61.2 | % |

[0000858877-14-000029:mdna:168]
Product Gross Margin

[0000858877-14-000029:mdna:169]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:170]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2013 to fiscal 2014:

[0000858877-14-000029:mdna:171]
|  |  | Product Gross Margin Percentage |
| Fiscal 2013 |  | 59.1 | % |
| Product pricing |  | (3.1 | )% |
| Supplier component remediation charge |  | (1.8 | )% |
| Mix of products sold |  | (0.5 | )% |
| Amortization of purchased intangible assets |  | (0.5 | )% |
| Productivity (1) |  | 3.0 | % |
| TiVo patent litigation settlement |  | 0.5 | % |
| Acquisition fair value adjustment to inventory and other |  | 0.1 | % |
| Fiscal 2014 |  | 56.8 | % |

[0000858877-14-000029:mdna:172]
(1) Productivity includes overall manufacturing-related costs, shipment volume, and other items not categorized elsewhere.

[0000858877-14-000029:mdna:173]
Product gross margin decreased by 2.3 percentage points compared with fiscal 2013.

[0000858877-14-000029:mdna:174]
The decrease in product gross margin was driven by unfavorable impacts from product pricing, which were driven by typical market factors and impacted each of our geographic segments and customer markets. The decrease was also due, in part, to the charge of $655 million to product cost of sales recorded in fiscal 2014 related to the expected cost of remediation of issues with memory components in certain products sold in prior fiscal years. In addition, the shift in the mix of products sold decreased our product gross margin, primarily as a result of a revenue increase in our relatively lower margin Cisco Unified Computing System products and decreased revenue from our higher margin core products, partially offset by decreased revenue from our relatively lower margin Service Provider Video products. Our product gross margin for fiscal 2014 was also negatively impacted by higher amortization expense of purchased intangible assets. For further explanation of the increase in amortization of purchased intangible assets, see “Amortization of Purchased Intangible Assets” below.

[0000858877-14-000029:mdna:175]
These amounts were partially offset by productivity benefits and the absence of charges related to the TiVo patent litigation settlement which we incurred in the fourth quarter of fiscal 2013. The productivity benefits we experienced in fiscal 2014 were driven by value engineering efforts; favorable component pricing; and continued operational efficiency in manufacturing operations. Value engineering is the process by which production costs are reduced through component redesign, board configuration, test processes, and transformation processes.

[0000858877-14-000029:mdna:176]
Our future gross margins could be impacted by our product mix and could be adversely affected by further growth in sales of products that have lower gross margins, such as Cisco Unified Computing System products. Our gross margins may also be impacted by the geographic mix of our revenue and, as was the case in fiscal 2014, fiscal 2013 and fiscal 2012, may be adversely affected by product pricing attributable to competitive factors. Additionally, our manufacturing-related costs may be negatively impacted by constraints in our supply chain, which in turn could negatively affect gross margin. If any of the preceding factors that in the past have negatively impacted our gross margins arise in future periods, our gross margins could continue to decline.

[0000858877-14-000029:mdna:177]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:178]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2012 to fiscal 2013:

[0000858877-14-000029:mdna:179]
|  |  | Product Gross Margin Percentage |
| Fiscal 2012 |  | 60.1 | % |
| Product pricing |  | (2.9 | )% |
| Mix of products sold |  | (0.7 | )% |
| Productivity |  | 3.7 | % |
| TiVo patent litigation settlement |  | (0.5 | )% |
| Amortization of purchased intangible assets |  | (0.5 | )% |
| Acquisition fair value adjustment to inventory and other |  | (0.1 | )% |
| Fiscal 2013 |  | 59.1 | % |

[0000858877-14-000029:mdna:180]
Product gross margin decreased by 1.0 percentage points compared with fiscal 2012. Unfavorable impacts from product pricing contributed to our decreased product gross margin percentage in fiscal 2013.  These factors impacted most of our customer markets and all of our geographic segments. Additionally, our product gross margin for fiscal 2013 was negatively impacted by the shift in the mix of products sold, primarily as a result of revenue increases for our relatively lower margin Cisco Unified Computing System products. These impacts were offset by continued productivity improvements. The productivity improvements were in large part due to increased benefits from cost savings, particularly in certain of our Switching and NGN Routing categories in which product transitions have been taking place, and were driven by value engineering efforts, favorable component pricing, and continued operational efficiency in manufacturing operations. Because the preceding factors largely offset each other, the decline in our product gross margin percentage was largely driven by our acquisition of NDS, which resulted in higher amortization expense from purchased intangible assets along with costs resulting from a fair value adjustment to inventory acquired as part of that acquisition. In addition, during fiscal 2013 we incurred charges related to the TiVo patent litigation settlement in the fourth quarter that were included as part of cost of sales. The combined effect of these items was a negative impact to our product gross margin of 1.1 percentage points for fiscal 2013.

[0000858877-14-000029:mdna:181]
Service Gross Margin

[0000858877-14-000029:mdna:182]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:183]
Our service gross margin percentage increased slightly by 0.3 percentage points for fiscal 2014, as compared with fiscal 2013. The increase was primarily due to higher sales volume in both advanced services and technical support services.  The benefits to gross margin of increased sales volume were partially offset by increased cost impacts such as outside service costs, partner delivery costs, and headcount-related costs.

[0000858877-14-000029:mdna:184]
Our service gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-14-000029:mdna:185]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:186]
Our service gross margin percentage increased slightly by 0.1 percentage points for fiscal 2013, as compared with fiscal 2012. Although we experienced higher sales volume from growth in both advanced services and in technical support services, the resulting benefit to gross margin was offset by increased cost impacts such as headcount-related costs, partner delivery costs, and unfavorable mix. The mix impacts were due to our lower gross margin advanced services business contributing a higher proportion of service revenue for fiscal 2013, as compared with fiscal 2012.

[0000858877-14-000029:mdna:187]
Gross Margin by Segment

[0000858877-14-000029:mdna:188]
The following table presents the total gross margin for each segment (in millions, except percentages):

[0000858877-14-000029:mdna:189]
|  |  | AMOUNT |  | PERCENTAGE |
| Years Ended |  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 17,379 |  |  | $ | 17,887 |  |  | $ | 16,639 |  |  | 62.6 | % |  | 62.5 | % |  | 62.8 | % |
| EMEA |  | 7,700 |  |  | 7,876 |  |  | 7,605 |  |  | 64.1 | % |  | 64.5 | % |  | 63.0 | % |
| APJC |  | 4,252 |  |  | 4,637 |  |  | 4,519 |  |  | 57.8 | % |  | 59.8 | % |  | 60.4 | % |
| Segment total |  | 29,331 |  |  | 30,400 |  |  | 28,763 |  |  | 62.2 | % |  | 62.5 | % |  | 62.4 | % |
| Unallocated corporate items (1) |  | (1,562 | ) |  | (960 | ) |  | (554 | ) |  |  |  |  |  |  |
| Total |  | $ | 27,769 |  |  | $ | 29,440 |  |  | $ | 28,209 |  |  | 58.9 | % |  | 60.6 | % |  | 61.2 | % |

[0000858877-14-000029:mdna:190]
(1) The unallocated corporate items for the years presented include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, impacts to cost of sales from purchase accounting adjustments to inventory, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-14-000029:mdna:191]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:192]
The Americas segment experienced a slight gross margin percentage increase due to the impact of productivity improvements in this geographic segment. Partially offsetting this favorable impact to gross margin were negative impacts from pricing and an unfavorable mix. The unfavorable mix impact was driven by revenue increases in our relatively lower margin Cisco Unified Computing System products and lower sales of our higher margin core products, partially offset by decreased revenue from our relatively lower margin Service Provider Video products.

[0000858877-14-000029:mdna:193]
The gross margin percentage decrease in our EMEA segment was due primarily to the unfavorable impacts from pricing, as well as an unfavorable mix impact, partially offset by productivity improvements in this geographic segment. The unfavorable mix impact was driven by an increase in revenue from our lower margin Cisco Unified Computing System products.

[0000858877-14-000029:mdna:194]
Our APJC segment gross margin percentage decreased primarily as a result of unfavorable impacts from pricing, and also as a result of an unfavorable mix. The unfavorable mix impact was driven by an increase in revenue from our lower margin Cisco Unified Computing System products. Partially offsetting these factors were impacts from productivity improvements and higher service gross margin in this geographic segment.

[0000858877-14-000029:mdna:195]
The gross margin percentage for a particular segment may fluctuate, and period-to-period changes in such percentages may or may not be indicative of a trend for that segment. Our product and service gross margins may be impacted by economic downturns or uncertain economic conditions as well as our movement into new market opportunities, and could decline if any of the factors that impact our gross margins are adversely affected in future periods.

[0000858877-14-000029:mdna:196]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:197]
We experienced a gross margin percentage decrease in our Americas and APJC segments, while our EMEA segment experienced a gross margin percentage increase.

[0000858877-14-000029:mdna:198]
The Americas segment experienced a slight gross margin percentage decline due to the unfavorable impacts from pricing, and also due to unfavorable mix impacts, partially offset by productivity improvements.

[0000858877-14-000029:mdna:199]
The gross margin percentage increase in our EMEA segment was primarily the result of productivity improvements from lower overall manufacturing costs and, to a lesser degree, favorable mix impacts and higher service gross margin.  Partially offsetting these favorable impacts to gross margin were negative impacts from pricing.

[0000858877-14-000029:mdna:200]
The APJC segment gross margin percentage declined due primarily to the unfavorable impacts from pricing, lower service gross margin, and unfavorable mix impacts. Partially offsetting these factors were productivity improvements, driven in large part by lower overall manufacturing costs and higher volume.

[0000858877-14-000029:mdna:201]
53

[0000858877-14-000029:mdna:202]
Factors That May Impact Revenue and Gross Margin

[0000858877-14-000029:mdna:203]
Product revenue may continue to be affected by factors, including global economic downturns and related market uncertainty, that have resulted in reduced IT-related capital spending in certain segments within our enterprise, service provider, public sector, and commercial markets; changes in the geopolitical environment and global economic conditions; competition, including price-focused competitors from Asia, especially from China; new product introductions; sales cycles and product implementation cycles; changes in the mix of our customers between service provider and enterprise markets; changes in the mix of direct sales and indirect sales; variations in sales channels; and final acceptance criteria of the product, system, or solution as specified by the customer. Sales to the service provider market have been and may be in the future characterized by large and sporadic purchases, especially relating to our router sales and sales of certain products within our Collaboration, Data Center, and Service Provider Video product categories. In addition, service provider customers typically have longer implementation cycles; require a broader range of services, including network design services; and often have acceptance provisions that can lead to a delay in revenue recognition. Certain of our customers in certain emerging countries also tend to make large and sporadic purchases, and the revenue related to these transactions may similarly be affected by the timing of revenue recognition. As we focus on new market opportunities, customers may require greater levels of financing arrangements, service, and support, especially in certain emerging countries, which in turn may result in a delay in the timing of revenue recognition. To improve customer satisfaction, we continue to focus on managing our manufacturing lead-time performance, which may result in corresponding reductions in order backlog. A decline in backlog levels could result in more variability and less predictability in our quarter-to-quarter revenue and operating results.

[0000858877-14-000029:mdna:204]
Product revenue may also be adversely affected by fluctuations in demand for our products, especially with respect to telecommunications service providers and Internet businesses, whether or not driven by any slowdown in capital expenditures in the service provider market; price and product competition in the communications and information technology industry; introduction and market acceptance of new technologies and products; adoption of new networking standards; and financial difficulties experienced by our customers. We may, from time to time, experience manufacturing issues that create a delay in our suppliers’ ability to provide specific components, resulting in delayed shipments. To the extent that manufacturing issues and any related component shortages result in delayed shipments in the future, and particularly in periods when we and our suppliers are operating at higher levels of capacity, it is possible that revenue for a quarter could be adversely affected if such matters are not remediated within the same quarter. For additional factors that may impact product revenue, see “Part I, Item 1A. Risk Factors.”

[0000858877-14-000029:mdna:205]
Our distributors participate in various cooperative marketing and other programs. Increased sales to our distributors generally result in greater difficulty in forecasting the mix of our products and, to a certain degree, the timing of orders from our customers. We recognize revenue for sales to our distributors generally based on a sell-through method using information provided by them, and we maintain estimated accruals and allowances for all cooperative marketing and other programs.

[0000858877-14-000029:mdna:206]
Product gross margin may be adversely affected in the future by changes in the mix of products sold, including periods of increased growth of some of our lower margin products; introduction of new products, including products with price-performance advantages and new business models for our offerings such as XaaS; our ability to reduce production costs; entry into new markets, including markets with different pricing structures and cost structures, as a result of internal development or through acquisitions; changes in distribution channels; price competition, including competitors from Asia, especially those from China; changes in geographic mix of our product revenue; the timing of revenue recognition and revenue deferrals; sales discounts; increases in material or labor costs, including share-based compensation expense; excess inventory and obsolescence charges; warranty costs; changes in shipment volume; loss of cost savings due to changes in component pricing; effects of value engineering; inventory holding charges; and the extent to which we successfully execute on our strategy and operating plans. Additionally, our manufacturing-related costs may be negatively impacted by constraints in our supply chain. Service gross margin may be impacted by various factors such as the change in mix between technical support services and advanced services; the timing of technical support service contract initiations and renewals; share-based compensation expense; and the timing of our strategic investments in headcount and resources to support this business.

[0000858877-14-000029:mdna:207]
54

[0000858877-14-000029:mdna:208]
Research and Development (“R&D”), Sales and Marketing, and General and Administrative (“G&A”) Expenses

[0000858877-14-000029:mdna:209]
R&D, sales and marketing, and G&A expenses are summarized in the following table (in millions, except percentages):

[0000858877-14-000029:mdna:210]
| Years Ended |  | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | July 27, 2013 |  | July 28, 2012 |  | Variance in Dollars |  | Variance in Percent |
| Research and development |  | $ | 6,294 |  |  | $ | 5,942 |  |  | $ | 352 |  |  | 5.9 | % |  | $ | 5,942 |  |  | $ | 5,488 |  |  | $ | 454 |  |  | 8.3 | % |
| Percentage of revenue |  | 13.4 | % |  | 12.2 | % |  |  |  |  |  | 12.2 | % |  | 11.9 | % |  |  |  |  |
| Sales and marketing |  | 9,503 |  |  | 9,538 |  |  | (35 | ) |  | (0.4 | )% |  | 9,538 |  |  | 9,647 |  |  | (109 | ) |  | (1.1 | )% |
| Percentage of revenue |  | 20.2 | % |  | 19.6 | % |  |  |  |  |  | 19.6 | % |  | 20.9 | % |  |  |  |  |
| General and administrative |  | 1,934 |  |  | 2,264 |  |  | (330 | ) |  | (14.6 | )% |  | 2,264 |  |  | 2,322 |  |  | (58 | ) |  | (2.5 | )% |
| Percentage of revenue |  | 4.1 | % |  | 4.7 | % |  |  |  |  |  | 4.7 | % |  | 5.0 | % |  |  |  |  |
| Total |  | $ | 17,731 |  |  | $ | 17,744 |  |  | $ | (13 | ) |  | (0.1 | )% |  | $ | 17,744 |  |  | $ | 17,457 |  |  | $ | 287 |  |  | 1.6 | % |
| Percentage of revenue |  | 37.6 | % |  | 36.5 | % |  |  |  |  |  | 36.5 | % |  | 37.9 | % |  |  |  |  |

[0000858877-14-000029:mdna:211]
R&D Expenses

[0000858877-14-000029:mdna:212]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:213]
R&D expenses increased for fiscal 2014, as compared with fiscal 2013, primarily due to compensation expense recorded in fiscal 2014 in connection with our acquisition of the remaining interest in Insieme Networks, Inc. (“Insieme”). See Note 12 to the Consolidated Financial Statements. Higher share-based compensation expense and higher contracted services also contributed to the increase.  These increases were partially offset by reduced variable compensation expense as a result of our financial performance and efficiencies related to our workforce reduction plan announced in August 2013.

[0000858877-14-000029:mdna:214]
We continue to invest in R&D in order to bring a broad range of products to market in a timely fashion. If we believe that we are unable to enter a particular market in a timely manner with internally developed products, we may purchase or license technology from other businesses, or we may partner with or acquire businesses as an alternative to internal R&D.

[0000858877-14-000029:mdna:215]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:216]
The increase in R&D expenses for fiscal 2013, as compared with fiscal 2012, was primarily due to higher headcount-related expenses attributable in large part to our acquisitions. Partially offsetting these costs was lower share-based compensation expense.

[0000858877-14-000029:mdna:217]
Sales and Marketing Expenses

[0000858877-14-000029:mdna:218]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:219]
Sales and marketing expenses for fiscal 2014, as compared with fiscal 2013, decreased slightly due to lower advertising expenses, reductions in other discretionary spending, and lower expenses in other areas such as depreciation expense. These decreases were substantially offset by higher share based compensation expense and higher acquisition- related costs.

[0000858877-14-000029:mdna:220]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:221]
For fiscal 2013, as compared with fiscal 2012, sales and marketing expenses decreased by $109 million, primarily due to lower share-based compensation expense and, to a lesser degree, lower discretionary spending and contracted services. These items were partially offset by higher headcount-related expense resulting largely from our acquisitions.

[0000858877-14-000029:mdna:222]
G&A Expenses

[0000858877-14-000029:mdna:223]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:224]
G&A expenses decreased in fiscal 2014, as compared with fiscal 2013, due to lower contracted services, lower corporate-level expenses, and lower headcount-related expenses.  The lower headcount-related expenses were due to efficiencies related to our workforce reduction plan announced in August 2013, and also due to reduced variable compensation expense as a result of our lower financial performance.

[0000858877-14-000029:mdna:225]
55

[0000858877-14-000029:mdna:226]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:227]
G&A expenses decreased in fiscal 2013, as compared with fiscal 2012, primarily due to the absence in fiscal 2013 of $202 million of impairment charges on real estate held for sale recorded in the fourth quarter of fiscal 2012. Lower share-based compensation expense in fiscal 2013 and a recovery in the market value of property held for sale recorded during fiscal 2013 also contributed to the decrease.  These decreases were partially offset by higher headcount-related expenses resulting in part from our acquisitions and also by higher corporate-level expenses. Corporate-level expenses, which tend to vary from period to period, included operational infrastructure activities such as IT project implementations, which included investments in our global data center infrastructure, and investments related to operational and financial systems.

[0000858877-14-000029:mdna:228]
Effect of Foreign Currency

[0000858877-14-000029:mdna:229]
In fiscal 2014, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by $153 million, or approximately 0.9%, compared with fiscal 2013. In fiscal 2013, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by $227 million, or approximately 1.3%, compared with fiscal 2012.

[0000858877-14-000029:mdna:230]
Headcount

[0000858877-14-000029:mdna:231]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:232]
Our headcount decreased by approximately 1,000 employees in fiscal 2014.  The decrease was due to headcount reductions from attrition and from our workforce reduction plan announced in August 2013. These headcount reductions were partially offset by the increase in headcount from targeted hiring in engineering, services, sales, and also by increased headcount from our recent acquisitions.

[0000858877-14-000029:mdna:233]
In August 2014, we announced a restructuring plan that will impact up to 6,000 employees, representing approximately 8% of our global workforce. We expect to reinvest substantially all of the cost savings from the restructuring actions in our key growth areas such as data center, software, security, and cloud.

[0000858877-14-000029:mdna:234]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:235]
Our headcount increased by 8,410 employees in fiscal 2013. The increase was attributable to the headcount from acquisitions, the largest of which was NDS, as well as targeted hiring in engineering and services.

[0000858877-14-000029:mdna:236]
Share-Based Compensation Expense

[0000858877-14-000029:mdna:237]
The following table presents share-based compensation expense (in millions):

[0000858877-14-000029:mdna:238]
| Years Ended |  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Cost of sales—product |  | $ | 45 |  |  | $ | 40 |  |  | $ | 53 |  |
| Cost of sales—service |  | 150 |  |  | 138 |  |  | 156 |  |
| Share-based compensation expense in cost of sales |  | 195 |  |  | 178 |  |  | 209 |  |
| Research and development |  | 411 |  |  | 286 |  |  | 401 |  |
| Sales and marketing |  | 549 |  |  | 484 |  |  | 588 |  |
| General and administrative |  | 198 |  |  | 175 |  |  | 203 |  |
| Restructuring and other charges |  | (5 | ) |  | (3 | ) |  | — |  |
| Share-based compensation expense in operating expenses |  | 1,153 |  |  | 942 |  |  | 1,192 |  |
| Total share-based compensation expense |  | $ | 1,348 |  |  | $ | 1,120 |  |  | $ | 1,401 |  |

[0000858877-14-000029:mdna:239]
The increase in share-based compensation expense for fiscal 2014, as compared with fiscal 2013, was due primarily to share-based compensation expense attributable to equity awards assumed with respect to our recent acquisitions and higher forfeiture credits in fiscal 2013.

[0000858877-14-000029:mdna:240]
The decrease in share-based compensation expense for fiscal 2013, as compared with fiscal 2012, was due primarily to a decrease in the aggregate value of share-based awards granted in recent periods, higher forfeiture credits in fiscal 2013, and the effect of stock options awards from prior years becoming fully amortized and replaced with restricted stock units with a lower aggregate value.

[0000858877-14-000029:mdna:241]
56

[0000858877-14-000029:mdna:242]
Amortization of Purchased Intangible Assets

[0000858877-14-000029:mdna:243]
The following table presents the amortization of purchased intangible assets (in millions):

[0000858877-14-000029:mdna:244]
| Years Ended |  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 742 |  |  | $ | 606 |  |  | $ | 424 |  |
| Operating expenses |  | 275 |  |  | 395 |  |  | 383 |  |
| Total |  | $ | 1,017 |  |  | $ | 1,001 |  |  | $ | 807 |  |

[0000858877-14-000029:mdna:245]
Amortization of purchased intangible assets increased in both fiscal 2014 and fiscal 2013 as compared with the respective prior  fiscal years. The increases were primarily due to amortization of purchased intangible assets from our recent acquisitions partially offset by certain purchased intangible assets having become fully amortized.

[0000858877-14-000029:mdna:246]
The fair value of acquired technology and patents, as well as acquired technology under development, is determined at acquisition date primarily using the income approach, which discounts expected future cash flows to present value. The discount rates used in the present value calculations are typically derived from a weighted-average cost of capital analysis and then adjusted to reflect risks inherent in the development lifecycle as appropriate. We consider the pricing model for products related to these acquisitions to be standard within the high-technology communications industry, and the applicable discount rates represent the rates that market participants would use for valuation of such intangible assets.

[0000858877-14-000029:mdna:247]
Restructuring and Other Charges

[0000858877-14-000029:mdna:248]
Fiscal 2014 Plan and Fiscal 2011 Plans

[0000858877-14-000029:mdna:249]
In August 2013, we announced a workforce reduction plan that would impact up to 4,000 employees, or 5%, of our global workforce. In connection with this Fiscal 2014 Plan, during fiscal 2014 we incurred within operating expenses restructuring and other charges of approximately $418 million which were related primarily to employee severance charges for employees impacted by our workforce reduction plan under the Fiscal 2014 Plan.  We have completed the Fiscal 2014 Plan and we do not expect any remaining charges related to this action.  In fiscal 2013 and fiscal 2012, we incurred within operating expenses net restructuring and other charges of $105 million and $304 million, respectively, which were related primarily to employee severance charges for employees impacted by our workforce reduction under Fiscal 2011 Plans.

[0000858877-14-000029:mdna:250]
Fiscal 2015 Plan

[0000858877-14-000029:mdna:251]
In August 2014, we announced a restructuring plan that will impact up to 6,000 employees, representing approximately 8% of our global workforce. We expect to take action under this plan beginning in the first quarter of fiscal 2015.  We currently estimate that we will recognize pre-tax charges in an amount not expected to exceed $700 million consisting of severance and other one-time termination benefits, and other associated costs.

[0000858877-14-000029:mdna:252]
Operating Income

[0000858877-14-000029:mdna:253]
The following table presents our operating income and our operating income as a percentage of revenue (in millions, except percentages):

[0000858877-14-000029:mdna:254]
| Years Ended |  | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Operating income |  | $ | 9,345 |  |  | $ | 11,196 |  |  | $ | 10,065 |  |
| Operating income as a percentage of revenue |  | 19.8 | % |  | 23.0 | % |  | 21.9 | % |

[0000858877-14-000029:mdna:255]
For fiscal 2014, as compared with fiscal 2013, operating income decreased by 17%, and as a percentage of revenue operating income decreased by 3.2 percentage points. The decrease resulted from the following: a decrease in revenue; a gross margin percentage decline, driven in part by the $655 million supplier component remediation charge (or 1.4 percentage points); the $416 million compensation expense recorded in fiscal 2014 in connection with our acquisition of the remaining interest in Insieme; and an increase in restructuring and other charges related to the workforce reduction under the Fiscal 2014 Plan.

[0000858877-14-000029:mdna:256]
In fiscal 2013 our results reflected solid execution on delivering profitable growth, as we grew operating income faster than revenue.  In fiscal 2013, as compared with fiscal 2012, operating income increased by 11%, and as a percentage of revenue operating income increased by 1.1 percentage points. The increases resulted from the following: revenue growth of 6%; continuing focus on expense management, which resulted in lower sales and marketing and G&A expenses as a percentage of revenue; and lower restructuring and other charges.

[0000858877-14-000029:mdna:257]
Interest and Other Income (Loss), Net

[0000858877-14-000029:mdna:258]
Interest Income (Expense), Net   The following table summarizes interest income and interest expense (in millions):

[0000858877-14-000029:mdna:259]
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | July 27, 2013 |  | July 28, 2012 |  | Variance in Dollars |
| Interest income | $ | 691 |  |  | $ | 654 |  |  | $ | 37 |  |  | $ | 654 |  |  | $ | 650 |  |  | $ | 4 |  |
| Interest expense | (564 | ) |  | (583 | ) |  | 19 |  |  | (583 | ) |  | (596 | ) |  | 13 |  |
| Interest income (expense), net | $ | 127 |  |  | $ | 71 |  |  | $ | 56 |  |  | $ | 71 |  |  | $ | 54 |  |  | $ | 17 |  |

[0000858877-14-000029:mdna:260]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:261]
Interest income increased in fiscal 2014 as compared with fiscal 2013 due to the increase in our portfolio of cash, cash equivalents, and fixed income investments. The decrease in interest expense in fiscal 2014 as compared with the prior fiscal year was primarily attributable to the favorable impact of incremental interest rate swaps entered into during fiscal 2014 and the fourth quarter of fiscal 2013. This decrease was partially offset by additional interest expense due to the increase in long-term debt in fiscal 2014.

[0000858877-14-000029:mdna:262]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:263]
Interest income increased slightly in fiscal 2013 as compared with prior fiscal year due primarily to increased interest income earned on financing receivables, partially offset by lower interest income from our portfolio of cash, cash equivalents, and fixed income investments as a result of lower average interest rates. The decrease in interest expense in fiscal 2013 as compared with fiscal 2012 was attributable to the favorable impact of interest rate swaps and lower expense on our floating-rate notes as the benchmark London InterBank Offered Rate (LIBOR) decreased.

[0000858877-14-000029:mdna:264]
Other Income (Loss), Net   The components of other income (loss), net, are summarized as follows (in millions):

[0000858877-14-000029:mdna:265]
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | July 27, 2013 |  | July 28, 2012 |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |
| Publicly traded equity securities | $ | 253 |  |  | $ | 17 |  |  | $ | 236 |  |  | $ | 17 |  |  | $ | 43 |  |  | $ | (26 | ) |
| Fixed income securities | 47 |  |  | 31 |  |  | 16 |  |  | 31 |  |  | 58 |  |  | (27 | ) |
| Total available-for-sale investments | 300 |  |  | 48 |  |  | 252 |  |  | 48 |  |  | 101 |  |  | (53 | ) |
| Privately held companies | (60 | ) |  | (57 | ) |  | (3 | ) |  | (57 | ) |  | (70 | ) |  | 13 |  |
| Net gains (losses) on investments | 240 |  |  | (9 | ) |  | 249 |  |  | (9 | ) |  | 31 |  |  | (40 | ) |
| Other gains (losses), net | 3 |  |  | (31 | ) |  | 34 |  |  | (31 | ) |  | 9 |  |  | (40 | ) |
| Other income (loss), net | $ | 243 |  |  | $ | (40 | ) |  | $ | 283 |  |  | $ | (40 | ) |  | $ | 40 |  |  | $ | (80 | ) |

[0000858877-14-000029:mdna:266]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:267]
The increase in total net gains on available-for-sale investments in fiscal 2014 compared with fiscal 2013 was primarily attributable to higher gains on publicly traded equity securities in the current period as a result of market conditions and the timing of sales of these securities.

[0000858877-14-000029:mdna:268]
The change in net losses on investments in privately held companies for the fiscal 2014 as compared with fiscal 2013 was primarily due to an increase of $40 million in our proportional share of losses from our VCE joint venture, partially offset by higher realized gains from various investments in privately held companies.

[0000858877-14-000029:mdna:269]
The change in other gains (losses), net in fiscal 2014 as compared with fiscal 2013 was primarily due to higher gains on equity derivative instruments and lower donation expenses, partially offset by unfavorable foreign exchange impacts in fiscal 2014.

[0000858877-14-000029:mdna:270]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:271]
The decrease in net gains on available-for-sale investments in fiscal 2013 compared with fiscal 2012 was attributable to lower gains on fixed income and publicly traded equity securities in fiscal 2013 as a result of market conditions and the timing of sales of these securities. For fiscal 2013 as compared with fiscal 2012, the change in net losses on investments in privately held companies was primarily due to higher realized gains from various private investments, partially offset by an increase of $23 million in our proportional share of losses from our VCE joint venture. The change in other gains (losses), net for fiscal 2013 as compared with fiscal 2012, was primarily due to an increase in donations and less favorable foreign exchange impacts in fiscal 2013.

[0000858877-14-000029:mdna:272]
58

[0000858877-14-000029:mdna:273]
Provision for Income Taxes

[0000858877-14-000029:mdna:274]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates, higher than anticipated in countries that have higher tax rates, and expiration of or lapses in tax incentives. Our provision for income taxes does not include provisions for U.S. income taxes and foreign withholding taxes associated with the repatriation of undistributed earnings of certain foreign subsidiaries that we intend to reinvest indefinitely in our foreign subsidiaries. If these earnings were distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. Further, as a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates and in some cases is wholly exempt from tax. Our failure to meet these commitments could adversely impact our provision for income taxes.

[0000858877-14-000029:mdna:275]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-14-000029:mdna:276]
The provision for income taxes resulted in an effective tax rate of 19.2% for fiscal 2014, compared with 11.1% for fiscal 2013. The net 8.1 percentage point increase in the effective tax rate between fiscal years was primarily attributable to a non-recurring net tax benefit of $794 million, or 7.1 percentage points, due to a tax settlement with the IRS in fiscal 2013.

[0000858877-14-000029:mdna:277]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 35% and for further explanation of our provision for income taxes, see Note 16 to the Consolidated Financial Statements.

[0000858877-14-000029:mdna:278]
Fiscal 2013 Compared with Fiscal 2012

[0000858877-14-000029:mdna:279]
The provision for income taxes resulted in an effective tax rate of 11.1% for fiscal 2013, compared with 20.8% for fiscal 2012. The net 9.7 percentage point decrease in the effective tax rate between fiscal years was primarily attributable to a net tax benefit of $794 million, or 7.1 percentage points, due to a tax settlement with the IRS and an increase in tax benefits of $144 million, or 1.2 percentage points, due to the retroactive reinstatement of the U.S. federal R&D tax credit in fiscal 2013.

[0000858877-14-000029:mdna:280]
LIQUIDITY AND CAPITAL RESOURCES

[0000858877-14-000029:mdna:281]
The following sections discuss the effects of changes in our balance sheet, our capital allocation strategy including stock repurchase program and dividends, our contractual obligations, and certain other commitments and activities on our liquidity and capital resources.

[0000858877-14-000029:mdna:282]
Balance Sheet and Cash Flows

[0000858877-14-000029:mdna:283]
Cash and Cash Equivalents and Investments  The following table summarizes our cash and cash equivalents and investments (in millions):

[0000858877-14-000029:mdna:284]
|  | July 26, 2014 |  | July 27, 2013 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 6,726 |  |  | $ | 7,925 |  |  | $ | (1,199 | ) |
| Fixed income securities | 43,396 |  |  | 39,888 |  |  | 3,508 |  |
| Publicly traded equity securities | 1,952 |  |  | 2,797 |  |  | (845 | ) |
| Total | $ | 52,074 |  |  | $ | 50,610 |  |  | $ | 1,464 |  |

[0000858877-14-000029:mdna:285]
The net increase in cash and cash equivalents and investments from fiscal 2013 to fiscal 2014 was primarily the result of cash provided by operating activities of $12.3 billion, a net increase in debt of $4.7 billion and the issuance of common stock of $1.9 billion pursuant to employee stock incentive and purchase plans. These sources of cash were partially offset by the repurchase of common stock of $9.4 billion under the stock repurchase program, cash dividends paid of $3.8 billion, net cash paid for acquisitions of $3.0 billion, and capital expenditures of $1.3 billion.

[0000858877-14-000029:mdna:286]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $47.4 billion and $40.4 billion as of July 26, 2014 and July 27, 2013, respectively. Under current tax laws and regulations, if these assets were to be distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. The balance of cash and cash equivalents and investments available in the United States as of July 26, 2014 and July 27, 2013 was $4.7 billion and $10.2 billion, respectively.

[0000858877-14-000029:mdna:287]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our fixed income investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-14-000029:mdna:288]
Free Cash Flow and Capital Allocation   As part of our capital allocation strategy, we intend to return a minimum of 50% of our free cash flow annually to our shareholders through cash dividends and repurchases of common stock.

[0000858877-14-000029:mdna:289]
We define free cash flow as net cash provided by operating activities less cash used to acquire property and equipment. The following table reconciles our net cash provided by operating activities to free cash flow (in millions):

[0000858877-14-000029:mdna:290]
| Years Ended | July 26, 2014 |  | July 27, 2013 |  | July 28, 2012 |
| Net cash provided by operating activities | $ | 12,332 |  |  | $ | 12,894 |  |  | $ | 11,491 |  |
| Acquisition of property and equipment | (1,275 | ) |  | (1,160 | ) |  | (1,126 | ) |
| Free cash flow | $ | 11,057 |  |  | $ | 11,734 |  |  | $ | 10,365 |  |

[0000858877-14-000029:mdna:291]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue, excess tax benefits resulting from share-based compensation, and the timing and amount of tax and other payments. For additional discussion, see “Part I, Item 1A. Risk Factors” in this report.

[0000858877-14-000029:mdna:292]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases.  We further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period.  In addition, we have other

[0000858877-14-000029:mdna:293]
required uses of cash, including repaying the principal of our outstanding indebtedness.  Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net income provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-14-000029:mdna:294]
The following table summarizes the dividends paid and stock repurchases (in millions, except per-share amounts):

[0000858877-14-000029:mdna:295]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  | TOTAL |
| Years Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | Amount |
| July 26, 2014 |  | $ | 0.72 |  |  | $ | 3,758 |  |  | 420 |  |  | $ | 22.71 |  |  | $ | 9,539 |  |  | $ | 13,297 |  |
| July 27, 2013 |  | $ | 0.62 |  |  | $ | 3,310 |  |  | 128 |  |  | $ | 21.63 |  |  | $ | 2,773 |  |  | $ | 6,083 |  |
| July 28, 2012 |  | $ | 0.28 |  |  | $ | 1,501 |  |  | 262 |  |  | $ | 16.64 |  |  | $ | 4,360 |  |  | $ | 5,861 |  |

[0000858877-14-000029:mdna:296]
On August 26, 2014, our Board of Directors declared a quarterly dividend of $0.19 per common share to be paid on October 22, 2014 to all shareholders of record as of the close of business on October 2, 2014. Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-14-000029:mdna:297]
Accounts Receivable, Net The following table summarizes our accounts receivable, net (in millions), and DSO:

[0000858877-14-000029:mdna:298]
|  | July 26, 2014 |  | July 27, 2013 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,157 |  |  | $ | 5,470 |  |  | $ | (313 | ) |
| DSO | 38 |  |  | 40 |  |  | (2 | ) |

[0000858877-14-000029:mdna:299]
Our accounts receivable net, as of July 26, 2014 decreased by approximately 6% compared with the end of fiscal 2013. Our DSO as of July 26, 2014 was lower by 2 days compared with the end of fiscal 2013, primarily due to an improvement in the linearity of shipments.

[0000858877-14-000029:mdna:300]
Inventory Supply Chain  The following table summarizes our inventories and purchase commitments with contract manufacturers and suppliers (in millions, except annualized inventory turns):

[0000858877-14-000029:mdna:301]
|  | July 26, 2014 |  | July 27, 2013 |  | Increase (Decrease) |
| Inventories | $ | 1,591 |  |  | $ | 1,476 |  |  | $ | 115 |  |
| Annualized inventory turns | 12.7 |  |  | 13.8 |  |  | (1.1 | ) |
| Purchase commitments with contract manufacturers and suppliers | $ | 4,169 |  |  | $ | 4,033 |  |  | $ | 136 |  |

[0000858877-14-000029:mdna:302]
Inventory as of July 26, 2014 increased by 8% from our inventory balance at the end of fiscal 2013, and for the same period purchase commitments with contract manufacturers and suppliers increased by approximately 3%. On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers increased by 5% compared with the end of fiscal 2013. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-14-000029:mdna:303]
Our finished goods consist of distributor inventory and deferred cost of sales and manufactured finished goods. Distributor inventory and deferred cost of sales are related to unrecognized revenue on shipments to distributors and retail partners as well as shipments to customers. Manufactured finished goods consist primarily of build-to-order and build-to-stock products.

[0000858877-14-000029:mdna:304]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity.

[0000858877-14-000029:mdna:305]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of rapidly changing technology and customer requirements. We believe the amount of our inventory and purchase commitments is appropriate for our revenue levels.

[0000858877-14-000029:mdna:306]
Financing Receivables and Guarantees We measure our net balance sheet exposure position related to our financing receivables and financing guarantees by reducing the total of gross financing receivables and financing guarantees by the associated allowances for credit loss and deferred revenue. As of July 26, 2014, our net balance sheet exposure position related to financing receivables and financing guarantees was as follows (in millions):

[0000858877-14-000029:mdna:307]
|  | FINANCING RECEIVABLES |  | FINANCING GUARANTEES |  |  |
| July 26, 2014 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |  | Channel Partner |  | End-User Customers |  | Total |  | TOTAL |
| Financing receivables less unearned income | $ | 3,527 |  |  | $ | 1,683 |  |  | $ | 3,210 |  |  | $ | 8,420 |  |  | $ | 263 |  |  | $ | 202 |  |  | $ | 465 |  |  | $ | 8,885 |  |
| Allowance for credit loss | (233 | ) |  | (98 | ) |  | (18 | ) |  | (349 | ) |  | — |  |  | — |  |  | — |  |  | (349 | ) |
| Deferred revenue | (23 | ) |  | (5 | ) |  | (1,843 | ) |  | (1,871 | ) |  | (127 | ) |  | (166 | ) |  | (293 | ) |  | (2,164 | ) |
| Net balance sheet exposure | $ | 3,271 |  |  | $ | 1,580 |  |  | $ | 1,349 |  |  | $ | 6,200 |  |  | $ | 136 |  |  | $ | 36 |  |  | $ | 172 |  |  | $ | 6,372 |  |

[0000858877-14-000029:mdna:308]
Financing Receivables  Financing receivables less unearned income increased by 2% compared with the end of fiscal 2013. The change was primarily due to a 2% increase in both loan receivables and financed service contracts and other, and also due to 1% increase in lease receivables. We provide financing to certain end-user customers and channel partners to enable sales of our products, services, and networking solutions. These financing arrangements include leases, financed service contracts, and loans. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Lease receivables include sales-type and direct-financing leases. We also provide certain qualified customers financing for long-term service contracts, which primarily relate to technical support services and advanced services. Our loan financing arrangements may include not only financing the acquisition of our products and services but also providing additional funds for other costs associated with network installation and integration of our products and services. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-14-000029:mdna:309]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements to customers provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed.

[0000858877-14-000029:mdna:310]
Deferred Revenue Related to Financing Receivables and Guarantees The majority of the deferred revenue in the preceding table is related to financed service contracts. The majority of the revenue related to financed service contracts, which primarily relates to technical support services, is deferred as the revenue related to financed service contracts is recognized ratably over the period during which the related services are to be performed. A portion of the revenue related to lease and loan receivables is also deferred and included in deferred product revenue based on revenue recognition criteria not currently having been met.

[0000858877-14-000029:mdna:311]
62

[0000858877-14-000029:mdna:312]
Borrowings

[0000858877-14-000029:mdna:313]
Senior Notes  The following table summarizes the principal amount of our senior notes (in millions):

[0000858877-14-000029:mdna:314]
|  | Maturity Date |  | July 26, 2014 |  | July 27, 2013 |  |
| Senior notes: |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |
| Three-month LIBOR plus 0.25% | March 14, 2014 |  | $ | — |  |  | $ | 1,250 |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 | (1) | 850 |  |  | — |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 | (1) | 1,000 |  |  | — |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 | (1) | 500 |  |  | — |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |
| 1.625% | March 14, 2014 |  | — |  |  | 2,000 |  |  |
| 2.90% | November 17, 2014 |  | 500 |  |  | 500 |  |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3,000 |  |  |
| 1.10% | March 3, 2017 | (1) | 2,400 |  |  | — |  |  |
| 3.15% | March 14, 2017 |  | 750 |  |  | 750 |  |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |  |
| 2.125% | March 1, 2019 | (1) | 1,750 |  |  | — |  |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |  |
| 2.90% | March 4, 2021 | (1) | 500 |  |  | — |  |  |
| 3.625% | March 4, 2024 | (1) | 1,000 |  |  | — |  |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |  |
| Total |  |  | $ | 20,750 |  |  | $ | 16,000 |  |  |

[0000858877-14-000029:mdna:315]
(1) In March 2014, we issued senior notes with an aggregate principal amount of $8.0 billion.

[0000858877-14-000029:mdna:316]
We repaid senior floating-rate and fixed-rate notes upon their maturity in the third quarter of fiscal 2014 for an aggregate principal amount of $3.3 billion.

[0000858877-14-000029:mdna:317]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of July 26, 2014.

[0000858877-14-000029:mdna:318]
Other Debt  Other debt as of July 26, 2014 and July 27, 2013 includes secured borrowings associated with customer financing arrangements. As of July 27, 2013, we also had outstanding notes related to our investment in Insieme. The amount of borrowings outstanding under these arrangements was $12 million and $31 million as of July 26, 2014 and July 27, 2013, respectively.

[0000858877-14-000029:mdna:319]
Commercial Paper  In fiscal 2011, we established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. In fiscal 2014, we issued and repaid $1.0 billion of indebtedness under commercial paper and had no commercial paper notes outstanding as of each of July 26, 2014 and July 27, 2013.

[0000858877-14-000029:mdna:320]
Credit Facility  On February 17, 2012, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on February 17, 2017. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the higher of the Federal Funds rate plus 0.50%, Bank of America’s “prime rate” as announced from time to time, or one-month LIBOR plus 1.00% or (ii) LIBOR plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of July 26, 2014, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-14-000029:mdna:321]
We may also, upon the agreement of either the existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility by up to two additional years, or up to February 17, 2019.

[0000858877-14-000029:mdna:322]
Deferred Revenue   The following table presents the breakdown of deferred revenue (in millions):

[0000858877-14-000029:mdna:323]
|  | July 26, 2014 |  | July 27, 2013 |  | Increase (Decrease) |
| Service | $ | 9,640 |  |  | $ | 9,403 |  |  | $ | 237 |  |
| Product | 4,502 |  |  | 4,020 |  |  | 482 |  |
| Total | $ | 14,142 |  |  | $ | 13,423 |  |  | $ | 719 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 9,478 |  |  | $ | 9,262 |  |  | $ | 216 |  |
| Noncurrent | 4,664 |  |  | 4,161 |  |  | 503 |  |
| Total | $ | 14,142 |  |  | $ | 13,423 |  |  | $ | 719 |  |

[0000858877-14-000029:mdna:324]
The increase in deferred service revenue in fiscal 2014 reflects the impact of new contract initiations and renewals, partially offset by an increase in customers paying technical support service contracts over time and the impact of ongoing amortization of deferred service revenue.  The increase in deferred product revenue was primarily due to increased deferrals related to subscription revenue arrangements and to a lesser extent, due to an increase in shipments not having met revenue recognition criteria as of July 26, 2014.

[0000858877-14-000029:mdna:325]
Contractual Obligations

[0000858877-14-000029:mdna:326]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. In addition, we plan for and measure our liquidity and capital resources through an annual budgeting process. The following table summarizes our contractual obligations at July 26, 2014 (in millions):

[0000858877-14-000029:mdna:327]
|  | PAYMENTS DUE BY PERIOD |
| July 26, 2014 | Total |  | Less than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than 5 Years |
| Operating leases | $ | 1,239 |  |  | $ | 399 |  |  | $ | 457 |  |  | $ | 196 |  |  | $ | 187 |  |
| Purchase commitments with contract manufacturers and suppliers | 4,169 |  |  | 4,169 |  |  | — |  |  | — |  |  | — |  |
| Other purchase obligations | 896 |  |  | 534 |  |  | 316 |  |  | 45 |  |  | 1 |  |
| Long-term debt | 20,754 |  |  | 500 |  |  | 8,004 |  |  | 4,250 |  |  | 8,000 |  |
| Other long-term liabilities | 1,379 |  |  | — |  |  | 505 |  |  | 55 |  |  | 819 |  |
| Total by period | $ | 28,437 |  |  | $ | 5,602 |  |  | $ | 9,282 |  |  | $ | 4,546 |  |  | $ | 9,007 |  |
| Other long-term liabilities (uncertainty in the timing of future payments) | 2,220 |  |  |  |  |  |  |  |  |  |
| Total | $ | 30,657 |  |  |  |  |  |  |  |  |  |

[0000858877-14-000029:mdna:328]
Operating Leases  For more information on our operating leases, see Note 12 to the Consolidated Financial Statements.

[0000858877-14-000029:mdna:329]
Purchase Commitments with Contract Manufacturers and Suppliers   We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. A significant portion of our reported estimated purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. See further discussion in “Inventory Supply Chain.” As of July 26, 2014, the liability for these purchase commitments was $162 million and is recorded in other current liabilities and is not included in the preceding table.

[0000858877-14-000029:mdna:330]
Other Purchase Obligations   Other purchase obligations represent an estimate of all contractual obligations in the ordinary course of business, other than operating leases and commitments with contract manufacturers and suppliers, for which we have not received the goods or services.  Purchase orders are not included in the preceding table as they typically represent our authorization to purchase rather than binding contractual purchase obligations.

[0000858877-14-000029:mdna:331]
Long-Term Debt   The amount of long-term debt in the preceding table represents the principal amount of the respective debt instruments. See Note 10 to the Consolidated Financial Statements.

[0000858877-14-000029:mdna:332]
Other Long-Term Liabilities   Other long-term liabilities primarily include noncurrent income taxes payable, accrued liabilities for deferred compensation, noncurrent deferred tax liabilities, and certain other long-term liabilities. Due to the uncertainty in the timing of future payments, our noncurrent income taxes payable of approximately $1,851 million  and noncurrent deferred tax liabilities of $369 million were presented as one aggregated amount in the total column on a separate line in the preceding table. Noncurrent income taxes payable include uncertain tax positions (see Note 16 to the Consolidated Financial Statements).

[0000858877-14-000029:mdna:333]
Other Commitments

[0000858877-14-000029:mdna:334]
In connection with our business combinations and asset purchases, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or the continued employment with us of certain employees of the acquired entities. See Note 12 to the Consolidated Financial Statements.

[0000858877-14-000029:mdna:335]
Insieme Networks, Inc.  In the third quarter of fiscal 2012, we made an investment in Insieme, an early stage company focused on research and development in the data center market.  As set forth in the agreement between Cisco and Insieme, this investment included $100 million of funding and a license to certain of our technology.  Immediately prior to the call option exercise and acquisition described below, we owned approximately 83% of Insieme as a result of these investments and have consolidated the results of Insieme in our Consolidated Financial Statements. In connection with this investment, we entered into a put/call option agreement that provided us with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require us to purchase their shares upon the occurrence of certain events.

[0000858877-14-000029:mdna:336]
During the first quarter of fiscal 2014, we exercised our call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  During fiscal 2014, we recorded compensation expense of $416 million, related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders. Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods. Based on the terms of the agreement, we have determined that the maximum amount that could be recorded as compensation expense by us is approximately $855 million, net of forfeitures and including the $416 million that has been expensed during fiscal 2014.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.

[0000858877-14-000029:mdna:337]
Other Funding Commitments  We also have certain funding commitments primarily related to our investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $255 million as of July 26, 2014, compared with $263 million as of July 27, 2013.

[0000858877-14-000029:mdna:338]
Off-Balance Sheet Arrangements

[0000858877-14-000029:mdna:339]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and customer financings, and we have determined that as of July 26, 2014 there were no material unconsolidated variable interest entities.

[0000858877-14-000029:mdna:340]
VCE is a joint venture that we formed in fiscal 2010 with EMC Corporation (“EMC”), with investments from VMware, Inc. (“VMware”) and Intel Corporation. VCE helps organizations leverage best-in-class technologies and disciplines from Cisco, EMC, and VMware to enable the transformation to cloud computing.  As of July 26, 2014, our cumulative gross investment in VCE was approximately $716 million, inclusive of accrued interest, and our ownership percentage was approximately 35%. During fiscal 2014, we invested approximately $185 million in VCE.  We account for our investment in VCE under the equity method, and our portion of VCE’s net loss is recognized in other income (loss), net.  As of July 26, 2014, we have recorded cumulative losses from VCE of $644 million since inception. Our carrying value in VCE as of July 26, 2014 was $72 million. Over the next 12 months, as VCE scales its operations, we may make additional investments in VCE and may incur additional losses proportionate with our share ownership.

[0000858877-14-000029:mdna:341]
From time to time, EMC and Cisco may enter into guarantee agreements on behalf of VCE to indemnify third parties, such as customers, for monetary damages. Such guarantees were not material as of July 26, 2014.

[0000858877-14-000029:mdna:342]
On an ongoing basis, we reassess our investments in privately held companies and customer financings to determine if they are variable interest entities and if we would be regarded as the primary beneficiary pursuant to the applicable accounting guidance. As a result of this ongoing assessment, we may be required to make additional disclosures or consolidate these entities. Because we may not control these entities, we may not have the ability to influence these events.

[0000858877-14-000029:mdna:343]
We provide financing guarantees, which are generally for various third-party financing arrangements extended to our channel partners and end-user customers. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. See the previous discussion of these financing guarantees under “Financing Receivables and Guarantees.”

[0000858877-14-000029:mdna:344]
Securities Lending

[0000858877-14-000029:mdna:345]
We periodically engage in securities lending activities with certain of our available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for fiscal 2014 and 2013 was $1.5 billion and $0.7 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of July 26, 2014 and July 27, 2013, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-14-000029:mdna:346]
Liquidity and Capital Resource Requirements

[0000858877-14-000029:mdna:347]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.

[0000858877-14-000029:mdna:348]
66
