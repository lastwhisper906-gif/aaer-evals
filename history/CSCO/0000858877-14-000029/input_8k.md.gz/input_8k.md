# CSCO 8-K — 0001193125-14-308403 filed 2014-08-13

## item codes, every 8-K on or before 2014-09-09

- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2014-09-09

- none on or before 2014-09-09

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-308403:8k_2_02:1]
EX-99.1
2
d773086dex991.htm
EX-99.1

[0001193125-14-308403:8k_2_02:2]
EX-99.1

[0001193125-14-308403:8k_2_02:3]
Exhibit 99.1

[0001193125-14-308403:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Jenkins-Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 853-9848 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-14-308403:8k_2_02:5]
CISCO REPORTS FOURTH QUARTER AND FISCAL YEAR 2014 EARNINGS

[0001193125-14-308403:8k_2_02:6]
Cisco transformation delivers record year and quarter of non-GAAP EPS

[0001193125-14-308403:8k_2_02:7]
|  | • |  | Q4 Revenue: $12.4 billion (flat year over year) |

[0001193125-14-308403:8k_2_02:8]
|  | • |  | Q4 Earnings per Share: $0.43 GAAP; $0.55 non-GAAP |

[0001193125-14-308403:8k_2_02:9]
|  | • |  | FY 2014 Revenue: $47.1 billion (decrease of 3% year over year) |

[0001193125-14-308403:8k_2_02:10]
|  | • |  | FY 2014 Earnings per Share: $1.49 GAAP; $2.06 non-GAAP |

[0001193125-14-308403:8k_2_02:11]
SAN JOSE, Calif. — August 13, 2014
— Cisco, the worldwide leader in networking that transforms how people connect, communicate and collaborate, today reported its fourth quarter and fiscal year results for the period ended July 26, 2014. Cisco reported fourth quarter
revenue of $12.4 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.2 billion or $0.43 per share, and non-GAAP net income of $2.8 billion or $0.55 per share.

[0001193125-14-308403:8k_2_02:12]
“We are executing well in a tough environment and delivered our best non-GAAP earnings per share quarter in our history. I’m pleased with
how we are transforming our company over the past several years and that journey continues,” stated John Chambers, Cisco chairman and chief executive officer. “We are focused on growth, innovation and talent, especially in the areas of
security, data center, software, cloud and internet of everything. Our strategy is sound, our financials are strong, and our market leadership is secure. We have the team in place to deliver and are uniquely positioned to help our customers solve
their biggest business problems.”

[0001193125-14-308403:8k_2_02:13]
Q4 GAAP Results

[0001193125-14-308403:8k_2_02:14]
|  |  | Q4 2014 |  |  | Q4 2013 |  |  | Vs. Q4 2013 |  |
| Revenue |  | $ | 12.4 billion |  |  | $ | 12.4 billion |  |  |  | (0.5 | )% |
| Net Income |  | $ | 2.2 billion |  |  | $ | 2.3 billion |  |  |  | (1.0 | )% |
| Earnings per Share |  | $ | 0.43 |  |  | $ | 0.42 |  |  |  | 2.4 | % |

[0001193125-14-308403:8k_2_02:15]
Q4 Non-GAAP Results

[0001193125-14-308403:8k_2_02:16]
|  |  | Q4 2014 |  |  | Q4 2013 |  |  | Vs. Q4 2013 |  |
| Net Income |  | $ | 2.8 billion |  |  | $ | 2.8 billion |  |  |  | (0.4 | )% |
| Earnings per Share |  | $ | 0.55 |  |  | $ | 0.52 |  |  |  | 5.8 | % |

[0001193125-14-308403:8k_2_02:17]
Fiscal Year GAAP Results

[0001193125-14-308403:8k_2_02:18]
|  |  | FY 2014 |  |  | FY 2013 |  |  | Vs. FY 2013 |  |
| Revenue |  | $ | 47.1 billion |  |  | $ | 48.6 billion |  |  |  | (3.0 | )% |
| Net Income |  | $ | 7.9 billion |  |  | $ | 10.0 billion |  |  |  | (21.3 | )% |
| Earnings per Share |  | $ | 1.49 |  |  | $ | 1.86 |  |  |  | (19.9 | )% |

[0001193125-14-308403:8k_2_02:19]
Fiscal Year Non-GAAP Results

[0001193125-14-308403:8k_2_02:20]
|  |  | FY 2014 |  |  | FY 2013 |  |  | Vs. FY 2013 |  |
| Net Income |  | $ | 10.9 billion |  |  | $ | 10.9 billion |  |  |  | — | % |
| Earnings per Share |  | $ | 2.06 |  |  | $ | 2.02 |  |  |  | 2.0 | % |

[0001193125-14-308403:8k_2_02:21]
A reconciliation between net income on a GAAP basis and non-GAAP net income is provided in the table following the
Consolidated Statements of Operations.

[0001193125-14-308403:8k_2_02:22]
1

[0001193125-14-308403:8k_2_02:23]
Cisco will discuss fourth quarter and fiscal year 2014 results and business outlook on a conference call and
webcast at 1:30 p.m. Pacific Time today. Call information and related charts are available at http://investor.cisco.com.

[0001193125-14-308403:8k_2_02:24]
Cash and Cash Equivalents and
Investments

[0001193125-14-308403:8k_2_02:25]
|  | • |  | Cash flows from operations were $3.6 billion for the fourth quarter of fiscal 2014, compared with $3.2 billion for the third quarter of fiscal 2014, and compared with $4.0 billion for the fourth quarter of fiscal 2013. Cash flows from operations were $12.3 billion for fiscal 2014, compared with $12.9 billion for fiscal 2013. |

[0001193125-14-308403:8k_2_02:26]
|  | • |  | Cash and cash equivalents and investments were $52.1 billion at the end of the fourth quarter of fiscal 2014, compared with $50.5 billion at the end of the third quarter of fiscal 2014, and compared with $50.6 billion at the end of the fourth quarter of fiscal 2013. |

[0001193125-14-308403:8k_2_02:27]
Dividends and Stock Repurchase Program

[0001193125-14-308403:8k_2_02:28]
|  | • |  | During the fourth quarter of fiscal 2014: |

[0001193125-14-308403:8k_2_02:29]
|  | • |  | Cisco paid a cash dividend of $0.19 per common share, or $974 million. |

[0001193125-14-308403:8k_2_02:30]
|  | • |  | Cisco repurchased approximately 61 million shares of common stock under the stock repurchase program at an average price of $25.11 per share for an aggregate purchase price of $1.5 billion. |

[0001193125-14-308403:8k_2_02:31]
|  | • |  | During fiscal year 2014: |

[0001193125-14-308403:8k_2_02:32]
|  | • |  | Cisco paid cash dividends of $0.72 per common share, or $3.8 billion. |

[0001193125-14-308403:8k_2_02:33]
|  | • |  | Cisco repurchased approximately 420 million shares of common stock under the stock repurchase program at an average price of $22.71 per share for an aggregate purchase price of $9.5 billion. As of July 26, 2014, Cisco had repurchased and retired 4.3 billion shares of Cisco common stock at an average price of $20.63 per share for an aggregate purchase price of approximately $88.4 billion since the inception of the stock repurchase program. The remaining authorized amount for stock repurchases under this program is approximately $8.6 billion with no termination date. |

[0001193125-14-308403:8k_2_02:34]
“We
returned a record $13.3 billion to shareholders this fiscal year through share buybacks and dividends,” stated Frank Calderoni, Cisco executive vice president and chief financial officer. “We remain committed to delivering value to our
shareholders through our capital allocation strategy and continued investment in our long-term growth opportunities.”

[0001193125-14-308403:8k_2_02:35]
Internet of Everything

[0001193125-14-308403:8k_2_02:36]
|  | • |  | Cisco and leaders of the city of Hamburg signed a Memorandum of Understanding to create specific pilot projects around smart traffic, smart street lighting, infrastructure sensing and remote citizen services. |

[0001193125-14-308403:8k_2_02:37]
|  | • |  | Cisco and leaders of the city of Kansas City, Missouri signed a letter of intent to launch a plan to enhance connectivity and innovation through the Smart+Connected Communities™ framework. |

[0001193125-14-308403:8k_2_02:38]
|  | • |  | Cisco collaborated with the municipalities of Copenhagen, Albertslund and Frederikssund in Denmark, to research and develop tomorrow’s digital infrastructure, the Internet of Everything (IoE), with the goal of strengthening services for citizens while supporting Copenhagen’s climate targets. |

[0001193125-14-308403:8k_2_02:39]
|  | • |  | Cisco and the Barcelona City Council announced plans to open a Cisco Global IoE Innovation Center in Barcelona to provide a platform for research, technological development and new market opportunities related to the IoE for smart cities. |

[0001193125-14-308403:8k_2_02:40]
Fast IT

[0001193125-14-308403:8k_2_02:41]
|  | • |  | Cisco continued to implement its vision for Application Centric Infrastructure (ACI) with plans to release the Application Policy Infrastructure Controller (APIC), ACI fabric mode for Cisco Nexus® 9000 Series switches, UCS Director support for ACI, industry-leading hardware and software innovations across its portfolio, and a market strategy that includes a robust ecosystem, Cisco validated designs, and new Cisco Services for ACI. |

[0001193125-14-308403:8k_2_02:42]
|  | • |  | Cisco added the Cisco WAN Automation Engine (WAE) to its Evolved Services Platform (ESP), marking another key milestone in Cisco’s network function virtualization (NFV) and software-defined networking (SDN) strategy. |

[0001193125-14-308403:8k_2_02:43]
|  | • |  | Cisco unveiled three new personal collaboration tools, the DX70, DX80 and Cisco Collaboration Meeting Rooms, designed to help customers quickly and simply connect people, conversations and data. |

[0001193125-14-308403:8k_2_02:44]
2

[0001193125-14-308403:8k_2_02:45]
|  | • |  | Cisco launched Cisco Small Cell Enterprise Select, a program designed to enable mobile network operators to effectively scale small cell deployments for enterprises that need cost-effective mobility solutions. The program provides a mutually beneficial model for partners, mobile operators and enterprises to enable a seamless, scalable and intelligent solution. |

[0001193125-14-308403:8k_2_02:46]
|  | • |  | Cisco estimates that global Internet Protocol (IP) traffic will increase nearly three-fold over the next five years due to more Internet users and devices, faster broadband speeds and more video viewing, according to a report entitled “Cisco Visual Networking Index: Forecast and Methodology, 2013 to 2018.” |

[0001193125-14-308403:8k_2_02:47]
|  | • |  | IDC ranked Cisco the number one provider of x86 blade servers in the Americas, measured by revenue market share, according to the IDC Worldwide Quarterly Server Tracker, 2014 Q1, May 2014. |

[0001193125-14-308403:8k_2_02:48]
Innovation

[0001193125-14-308403:8k_2_02:49]
|  | • |  | Cisco acquired ThreatGRID, a provider of dynamic malware analysis and threat intelligence technology, both on-premise and in the cloud, designed to help organizations and security teams defend proactively against and quickly respond to advanced cyber-attacks and malware outbreaks. |

[0001193125-14-308403:8k_2_02:50]
|  | • |  | Cisco acquired Assemblage, a company that provides tools and infrastructure designed to enable simple, one-click browser-to-browser collaboration without the need for downloads, plugins or installations. |

[0001193125-14-308403:8k_2_02:51]
|  | • |  | Cisco acquired Tail-f Systems, a leader in multivendor network service orchestration solutions for traditional and virtualized networks, to accelerate Cisco’s cloud virtualization strategy of delivering software that increases value of customer applications and services. |

[0001193125-14-308403:8k_2_02:52]
|  | • |  | Cisco Investments, the corporate venture capital arm of Cisco, announced it is allocating an additional $150 million to fund early-stage companies focused on next horizon “themes” to accelerate the development of disruptive technology markets, including big data and analytics, the Internet of Things, connected mobility, storage, silicon, the content technology ecosystem and India innovation. |

[0001193125-14-308403:8k_2_02:53]
|  | • |  | Cisco Investments announced the Cisco Canada Innovation Program, a strategy to invest CAD $150 million to support and accelerate innovation in Canada. |

[0001193125-14-308403:8k_2_02:54]
|  | • |  | Cisco Investments announced an additional allocation of $40 million to fund early-stage firms in India focused on products and technologies that are unique and relevant to India and other emerging markets. |

[0001193125-14-308403:8k_2_02:55]
Editor’s Notes:

[0001193125-14-308403:8k_2_02:56]
|  | • |  | The Q4 and fiscal year 2014 conference call to discuss Cisco’s results along with its business outlook will be held on Wednesday, August 13, 2014 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-14-308403:8k_2_02:57]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, August 13, 2014 to 11:59 p.m. Pacific Time, on September 1, 2014 at 1-888-403-4665 (United States) or 1-203-369-3148 (international). The replay will also be available via webcast from August 13, 2014 through October 17, 2014 on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-14-308403:8k_2_02:58]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, August 13, 2014. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with GAAP reconciliation information, will be available on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-14-308403:8k_2_02:59]
About
Cisco

[0001193125-14-308403:8k_2_02:60]
Cisco (NASDAQ: CSCO) is the worldwide leader in IT that helps companies seize the opportunities of tomorrow by proving that amazing things can
happen when you connect the previously unconnected. For ongoing news, please go to http://thenetwork.cisco.com.

[0001193125-14-308403:8k_2_02:61]
###

[0001193125-14-308403:8k_2_02:62]
technological and market change; manufacturing and sourcing risks; product defects and returns; litigation involving patents, intellectual property, antitrust, shareholder and other matters, and
governmental investigations; natural catastrophic events; a pandemic or epidemic; our ability to achieve the benefits anticipated from our investments in sales, engineering, service, marketing and manufacturing activities; our ability to recruit and
retain key personnel; our ability to manage financial risk, and to manage expenses during economic downturns; risks related to the global nature of our operations, including our operations in emerging markets; currency fluctuations and other
international factors; changes in provision for income taxes, including changes in tax laws and regulations or adverse outcomes resulting from examinations of our income tax returns; potential volatility in operating results; and other factors
listed in Cisco’s most recent reports on Forms 10-Q and 10-K filed on May 22, 2014 and September 10, 2013, respectively. The financial information contained in this release should be read in conjunction with the consolidated financial
statements and notes thereto included in Cisco’s most recent reports on Forms 10-Q and 10-K as each may be amended from time to time. Cisco’s results of operations for the three months and the year ended July 26, 2014 are not
necessarily indicative of Cisco’s operating results for any future periods. Any projections in this release are based on limited information currently available to Cisco, which is subject to change. Although any such projections and the factors
influencing them will likely change, Cisco will not necessarily update the information, since Cisco will only provide guidance at certain points during the year. Such information speaks only as of the date of this release.

[0001193125-14-308403:8k_2_02:63]
This release includes non-GAAP net income, non-GAAP effective tax rates, non-GAAP net income per share data, non-GAAP inventory turns and free cash flow.

[0001193125-14-308403:8k_2_02:64]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles and
may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do
not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding
GAAP measures.

[0001193125-14-308403:8k_2_02:65]
Cisco believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP net income per share data, when
shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. In addition, Cisco believes
that the presentation of non-GAAP inventory turns provides useful information to investors and management regarding financial and business trends relating to inventory management based on the operating activities of the periods presented. Cisco
believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and
investors because of its intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases. Cisco further regards free cash flow as a useful measure because it reflects cash that can be used to,
among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock, after deducting capital investments.

[0001193125-14-308403:8k_2_02:66]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, impact to cost of sales from purchase accounting adjustments to inventory, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation and
other contingencies (such as the supplier component remediation charge in the second quarter of fiscal 2014 and the patent litigation settlement with TiVo, Inc. incurred in the fourth quarter of fiscal 2013), the income tax effects of the foregoing,
and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no
longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional
information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-14-308403:8k_2_02:67]
Copyright © 2014 Cisco and/or its affiliates. All rights reserved. Cisco, the Cisco logo, Cisco
Nexus, Cisco Visual Networking Index and Smart+Connected Communities are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks.
Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-14-308403:8k_2_02:68]
4

[0001193125-14-308403:8k_2_02:69]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-14-308403:8k_2_02:70]
(In millions, except per-share amounts)

[0001193125-14-308403:8k_2_02:71]
(Unaudited)

[0001193125-14-308403:8k_2_02:72]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 26,2014 |  |  | July 27,2013 |  |  | July 26,2014 |  |  | July 27,2013 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,532 |  |  | $ | 9,736 |  |  | $ | 36,172 |  |  | $ | 38,029 |  |
| Service |  |  | 2,825 |  |  |  | 2,681 |  |  |  | 10,970 |  |  |  | 10,578 |  |
| Total revenue |  |  | 12,357 |  |  |  | 12,417 |  |  |  | 47,142 |  |  |  | 48,607 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,976 |  |  |  | 4,154 |  |  |  | 15,641 |  |  |  | 15,541 |  |
| Service |  |  | 976 |  |  |  | 916 |  |  |  | 3,732 |  |  |  | 3,626 |  |
| Total cost of sales |  |  | 4,952 |  |  |  | 5,070 |  |  |  | 19,373 |  |  |  | 19,167 |  |
| GROSS MARGIN |  |  | 7,405 |  |  |  | 7,347 |  |  |  | 27,769 |  |  |  | 29,440 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,593 |  |  |  | 1,517 |  |  |  | 6,294 |  |  |  | 5,942 |  |
| Sales and marketing |  |  | 2,473 |  |  |  | 2,360 |  |  |  | 9,503 |  |  |  | 9,538 |  |
| General and administrative |  |  | 508 |  |  |  | 590 |  |  |  | 1,934 |  |  |  | 2,264 |  |
| Amortization of purchased intangible assets |  |  | 68 |  |  |  | 66 |  |  |  | 275 |  |  |  | 395 |  |
| Restructuring and other charges |  |  | 82 |  |  |  | — |  |  |  | 418 |  |  |  | 105 |  |
| Total operating expenses |  |  | 4,724 |  |  |  | 4,533 |  |  |  | 18,424 |  |  |  | 18,244 |  |
| OPERATING INCOME |  |  | 2,681 |  |  |  | 2,814 |  |  |  | 9,345 |  |  |  | 11,196 |  |
| Interest income |  |  | 183 |  |  |  | 171 |  |  |  | 691 |  |  |  | 654 |  |
| Interest expense |  |  | (142 | ) |  |  | (143 | ) |  |  | (564 | ) |  |  | (583 | ) |
| Other income (loss), net |  |  | 56 |  |  |  | 29 |  |  |  | 243 |  |  |  | (40 | ) |
| Interest and other income (loss), net |  |  | 97 |  |  |  | 57 |  |  |  | 370 |  |  |  | 31 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 2,778 |  |  |  | 2,871 |  |  |  | 9,715 |  |  |  | 11,227 |  |
| Provision for income taxes |  |  | 531 |  |  |  | 601 |  |  |  | 1,862 |  |  |  | 1,244 |  |
| NET INCOME |  | $ | 2,247 |  |  | $ | 2,270 |  |  | $ | 7,853 |  |  | $ | 9,983 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.44 |  |  | $ | 0.42 |  |  | $ | 1.50 |  |  | $ | 1.87 |  |
| Diluted |  | $ | 0.43 |  |  | $ | 0.42 |  |  | $ | 1.49 |  |  | $ | 1.86 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,121 |  |  |  | 5,367 |  |  |  | 5,234 |  |  |  | 5,329 |  |
| Diluted |  |  | 5,172 |  |  |  | 5,437 |  |  |  | 5,281 |  |  |  | 5,380 |  |
| Cash dividends declared per common share |  | $ | 0.19 |  |  | $ | 0.17 |  |  | $ | 0.72 |  |  | $ | 0.62 |  |

[0001193125-14-308403:8k_2_02:73]
5

[0001193125-14-308403:8k_2_02:74]
RECONCILIATION OF GAAP TO NON-GAAP NET INCOME

[0001193125-14-308403:8k_2_02:75]
(In millions, except per-share amounts)

[0001193125-14-308403:8k_2_02:76]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 26,2014 |  |  | July 27,2013 |  |  | July 26,2014 |  |  | July 27,2013 |  |
| GAAP net income |  | $ | 2,247 |  |  | $ | 2,270 |  |  | $ | 7,853 |  |  | $ | 9,983 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 49 |  |  |  | 42 |  |  |  | 195 |  |  |  | 178 |  |
| Amortization of acquisition-related intangible assets |  |  | 180 |  |  |  | 153 |  |  |  | 710 |  |  |  | 569 |  |
| Supplier component remediation charge |  |  | — |  |  |  | — |  |  |  | 655 |  |  |  | — |  |
| Impact to cost of sales from purchase accounting adjustments to inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 40 |  |
| TiVo patent litigation settlement |  |  | — |  |  |  | 172 |  |  |  | — |  |  |  | 172 |  |
| Acquisition-related/divestiture costs |  |  | 1 |  |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |
| Total adjustments to GAAP cost of sales |  |  | 230 |  |  |  | 368 |  |  |  | 1,562 |  |  |  | 960 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 291 |  |  |  | 198 |  |  |  | 1,158 |  |  |  | 947 |  |
| Amortization of acquisition-related intangible assets |  |  | 68 |  |  |  | 66 |  |  |  | 275 |  |  |  | 395 |  |
| Acquisition-related/divestiture costs |  |  | 102 |  |  |  | 59 |  |  |  | 585 |  |  |  | 129 |  |
| Significant asset impairments and restructurings |  |  | 82 |  |  |  | — |  |  |  | 418 |  |  |  | 55 |  |
| Total adjustments to GAAP operating expenses |  |  | 543 |  |  |  | 323 |  |  |  | 2,436 |  |  |  | 1,526 |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 773 |  |  |  | 691 |  |  |  | 3,998 |  |  |  | 2,486 |  |
| Income tax effect of non-GAAP adjustments |  |  | (185 | ) |  |  | (114 | ) |  |  | (834 | ) |  |  | (620 | ) |
| Significant tax matters |  |  | — |  |  |  | — |  |  |  | (154 | ) |  |  | (983 | ) |
| Total adjustments to GAAP provision for income taxes |  |  | (185 | ) |  |  | (114 | ) |  |  | (988 | ) |  |  | (1,603 | ) |
| Non-GAAP net income |  | $ | 2,835 |  |  | $ | 2,847 |  |  | $ | 10,863 |  |  | $ | 10,866 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.43 |  |  | $ | 0.42 |  |  | $ | 1.49 |  |  | $ | 1.86 |  |
| Non-GAAP |  | $ | 0.55 |  |  | $ | 0.52 |  |  | $ | 2.06 |  |  | $ | 2.02 |  |

[0001193125-14-308403:8k_2_02:77]
RECONCILIATION OF GAAP TO NON-GAAP EFFECTIVE TAX RATE

[0001193125-14-308403:8k_2_02:78]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 26,2014 |  |  | July 27,2013 |  |  | July 26,2014 |  |  | July 27,2013 |  |
| GAAP effective tax rate |  |  | 19.1 | % |  |  | 20.9 | % |  |  | 19.2 | % |  |  | 11.1 | % |
| Tax effect of non-GAAP adjustments to net income |  |  | 1.1 | % |  |  | (0.8 | )% |  |  | 1.6 | % |  |  | 9.7 | % |
| Non-GAAP effective tax rate |  |  | 20.2 | % |  |  | 20.1 | % |  |  | 20.8 | % |  |  | 20.8 | % |

[0001193125-14-308403:8k_2_02:79]
6

[0001193125-14-308403:8k_2_02:80]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-14-308403:8k_2_02:81]
(In millions)

[0001193125-14-308403:8k_2_02:82]
(Unaudited)

[0001193125-14-308403:8k_2_02:83]
|  |  | July 26,2014 |  |  | July 27,2013 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 6,726 |  |  | $ | 7,925 |  |
| Investments |  |  | 45,348 |  |  |  | 42,685 |  |
| Accounts receivable, net of allowance for doubtful accounts of $265 at July 26, 2014 and $228 at July 27, 2013 |  |  | 5,157 |  |  |  | 5,470 |  |
| Inventories |  |  | 1,591 |  |  |  | 1,476 |  |
| Financing receivables, net |  |  | 4,153 |  |  |  | 4,037 |  |
| Deferred tax assets |  |  | 2,808 |  |  |  | 2,616 |  |
| Other current assets |  |  | 1,331 |  |  |  | 1,312 |  |
| Total current assets |  |  | 67,114 |  |  |  | 65,521 |  |
| Property and equipment, net |  |  | 3,252 |  |  |  | 3,322 |  |
| Financing receivables, net |  |  | 3,918 |  |  |  | 3,911 |  |
| Goodwill |  |  | 24,239 |  |  |  | 21,919 |  |
| Purchased intangible assets, net |  |  | 3,280 |  |  |  | 3,403 |  |
| Other assets |  |  | 3,331 |  |  |  | 3,115 |  |
| TOTAL ASSETS |  | $ | 105,134 |  |  | $ | 101,191 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 508 |  |  | $ | 3,283 |  |
| Accounts payable |  |  | 1,032 |  |  |  | 1,029 |  |
| Income taxes payable |  |  | 159 |  |  |  | 192 |  |
| Accrued compensation |  |  | 3,181 |  |  |  | 3,182 |  |
| Deferred revenue |  |  | 9,478 |  |  |  | 9,262 |  |
| Other current liabilities |  |  | 5,451 |  |  |  | 5,048 |  |
| Total current liabilities |  |  | 19,809 |  |  |  | 21,996 |  |
| Long-term debt |  |  | 20,401 |  |  |  | 12,928 |  |
| Income taxes payable |  |  | 1,851 |  |  |  | 1,748 |  |
| Deferred revenue |  |  | 4,664 |  |  |  | 4,161 |  |
| Other long-term liabilities |  |  | 1,748 |  |  |  | 1,230 |  |
| Total liabilities |  |  | 48,473 |  |  |  | 42,063 |  |
| Total equity |  |  | 56,661 |  |  |  | 59,128 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 105,134 |  |  | $ | 101,191 |  |

[0001193125-14-308403:8k_2_02:84]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-14-308403:8k_2_02:85]
(In millions)

[0001193125-14-308403:8k_2_02:86]
(Unaudited)

[0001193125-14-308403:8k_2_02:87]
|  |  | Fiscal Year Ended |  |
|  |  | July 26,2014 |  |  | July 27,2013 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 7,853 |  |  | $ | 9,983 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 2,432 |  |  |  | 2,451 |  |
| Share-based compensation expense |  |  | 1,348 |  |  |  | 1,120 |  |
| Provision for receivables |  |  | 79 |  |  |  | 44 |  |
| Deferred income taxes |  |  | (678 | ) |  |  | (37 | ) |
| Excess tax benefits from share-based compensation |  |  | (118 | ) |  |  | (92 | ) |
| (Gains) losses on investments and other, net |  |  | (299 | ) |  |  | (91 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 340 |  |  |  | (1,001 | ) |
| Inventories |  |  | (109 | ) |  |  | 218 |  |
| Financing receivables |  |  | (119 | ) |  |  | (723 | ) |
| Other assets |  |  | 33 |  |  |  | (27 | ) |
| Accounts payable |  |  | (23 | ) |  |  | 164 |  |
| Income taxes, net |  |  | 191 |  |  |  | (239 | ) |
| Accrued compensation |  |  | (42 | ) |  |  | 134 |  |
| Deferred revenue |  |  | 659 |  |  |  | 598 |  |
| Other liabilities |  |  | 785 |  |  |  | 392 |  |
| Net cash provided by operating activities |  |  | 12,332 |  |  |  | 12,894 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (36,317 | ) |  |  | (36,608 | ) |
| Proceeds from sales of investments |  |  | 18,193 |  |  |  | 14,799 |  |
| Proceeds from maturities of investments |  |  | 15,660 |  |  |  | 17,909 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (2,989 | ) |  |  | (6,766 | ) |
| Purchases of investments in privately held companies |  |  | (384 | ) |  |  | (225 | ) |
| Return of investments in privately held companies |  |  | 213 |  |  |  | 209 |  |
| Acquisition of property and equipment |  |  | (1,275 | ) |  |  | (1,160 | ) |
| Proceeds from sales of property and equipment |  |  | 232 |  |  |  | 141 |  |
| Other |  |  | 24 |  |  |  | (67 | ) |
| Net cash used in investing activities |  |  | (6,643 | ) |  |  | (11,768 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 1,907 |  |  |  | 3,338 |  |
| Repurchases of common stock - repurchase program |  |  | (9,413 | ) |  |  | (2,773 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (430 | ) |  |  | (330 | ) |
| Short-term borrowings, original maturities less than 90 days, net |  |  | (2 | ) |  |  | (20 | ) |
| Issuances of debt |  |  | 8,001 |  |  |  | 24 |  |
| Repayments of debt |  |  | (3,276 | ) |  |  | (16 | ) |
| Excess tax benefits from share-based compensation |  |  | 118 |  |  |  | 92 |  |
| Dividends paid |  |  | (3,758 | ) |  |  | (3,310 | ) |
| Other |  |  | (35 | ) |  |  | (5 | ) |
| Net cash used in financing activities |  |  | (6,888 | ) |  |  | (3,000 | ) |
| Net decrease in cash and cash equivalents |  |  | (1,199 | ) |  |  | (1,874 | ) |
| Cash and cash equivalents, beginning of fiscal year |  |  | 7,925 |  |  |  | 9,799 |  |
| Cash and cash equivalents, end of fiscal year |  | $ | 6,726 |  |  | $ | 7,925 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 682 |  |  | $ | 682 |  |
| Cash paid for income taxes, net |  | $ | 2,349 |  |  | $ | 1,519 |  |

[0001193125-14-308403:8k_2_02:88]
Certain reclassifications have been made to prior year amounts to conform to the current year’s
presentation.

[0001193125-14-308403:8k_2_02:89]
8

[0001193125-14-308403:8k_2_02:90]
CASH AND CASH EQUIVALENTS AND INVESTMENTS

[0001193125-14-308403:8k_2_02:91]
(In millions)

[0001193125-14-308403:8k_2_02:92]
|  |  | July 26,2014 |  |  | July 27,2013 |  |
| Cash and cash equivalents and investments: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 6,726 |  |  | $ | 7,925 |  |
| Fixed income securities |  |  | 43,396 |  |  |  | 39,888 |  |
| Publicly traded equity securities |  |  | 1,952 |  |  |  | 2,797 |  |
| Total |  | $ | 52,074 |  |  | $ | 50,610 |  |

[0001193125-14-308403:8k_2_02:93]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES

[0001193125-14-308403:8k_2_02:94]
TO FREE CASH FLOW (NON-GAAP)

[0001193125-14-308403:8k_2_02:95]
(In millions)

[0001193125-14-308403:8k_2_02:96]
|  |  | Three Months Ended |  |
|  |  | July 26,2014 |  |  | April 26,2014 |  |  | July 27,2013 |  |
| Net cash provided by operating activities |  | $ | 3,612 |  |  | $ | 3,198 |  |  | $ | 3,986 |  |
| Acquisition of property and equipment |  |  | (325 | ) |  |  | (373 | ) |  |  | (317 | ) |
| Free cash flow |  | $ | 3,287 |  |  | $ | 2,825 |  |  | $ | 3,669 |  |

[0001193125-14-308403:8k_2_02:97]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-14-308403:8k_2_02:98]
(In millions, except per-share amounts)

[0001193125-14-308403:8k_2_02:99]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 26, 2014 |  | $ | 0.19 |  |  | $ | 974 |  |  |  | 61 |  |  | $ | 25.11 |  |  | $ | 1,514 |  |  | $ | 2,488 |  |
| April 26, 2014 |  |  | 0.19 |  |  |  | 974 |  |  |  | 90 |  |  | $ | 22.24 |  |  |  | 2,005 |  |  |  | 2,979 |  |
| January 25, 2014 |  |  | 0.17 |  |  |  | 896 |  |  |  | 185 |  |  | $ | 21.73 |  |  |  | 4,020 |  |  |  | 4,916 |  |
| October 26, 2013 |  |  | 0.17 |  |  |  | 914 |  |  |  | 84 |  |  | $ | 23.65 |  |  |  | 2,000 |  |  |  | 2,914 |  |
| Total |  | $ | 0.72 |  |  | $ | 3,758 |  |  |  | 420 |  |  | $ | 22.71 |  |  | $ | 9,539 |  |  | $ | 13,297 |  |
| Fiscal 2013 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 27, 2013 |  | $ | 0.17 |  |  | $ | 918 |  |  |  | 47 |  |  | $ | 24.80 |  |  | $ | 1,160 |  |  | $ | 2,078 |  |
| April 27, 2013 |  |  | 0.17 |  |  |  | 905 |  |  |  | 41 |  |  | $ | 20.85 |  |  |  | 860 |  |  |  | 1,765 |  |
| January 26, 2013 |  |  | 0.14 |  |  |  | 743 |  |  |  | 25 |  |  | $ | 20.15 |  |  |  | 500 |  |  |  | 1,243 |  |
| October 27, 2012 |  |  | 0.14 |  |  |  | 744 |  |  |  | 15 |  |  | $ | 16.44 |  |  |  | 253 |  |  |  | 997 |  |
| Total |  | $ | 0.62 |  |  | $ | 3,310 |  |  |  | 128 |  |  | $ | 21.63 |  |  | $ | 2,773 |  |  | $ | 6,083 |  |

[0001193125-14-308403:8k_2_02:100]
9

[0001193125-14-308403:8k_2_02:101]
ACCOUNTS RECEIVABLE AND DSO

[0001193125-14-308403:8k_2_02:102]
(In millions, except DSO)

[0001193125-14-308403:8k_2_02:103]
|  |  | July 26,2014 |  |  | April 26,2014 |  |  | July 27,2013 |  |
| Accounts receivable, net |  | $ | 5,157 |  |  | $ | 4,443 |  |  | $ | 5,470 |  |
| Days sales outstanding in accounts receivable (DSO) |  |  | 38 |  |  |  | 35 |  |  |  | 40 |  |

[0001193125-14-308403:8k_2_02:104]
INVENTORIES

[0001193125-14-308403:8k_2_02:105]
(In millions)

[0001193125-14-308403:8k_2_02:106]
|  |  | July 26,2014 |  |  | April 26,2014 |  |  | July 27,2013 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 77 |  |  | $ | 57 |  |  | $ | 105 |  |
| Work in process |  |  | 5 |  |  |  | 5 |  |  |  | 24 |  |
| Finished goods: |  |  |  |  |  |  |  |  |  |  |  |  |
| Distributor inventory and deferred cost of sales |  |  | 595 |  |  |  | 623 |  |  |  | 572 |  |
| Manufactured finished goods |  |  | 606 |  |  |  | 550 |  |  |  | 480 |  |
| Total finished goods |  |  | 1,201 |  |  |  | 1,173 |  |  |  | 1,052 |  |
| Service-related spares |  |  | 273 |  |  |  | 255 |  |  |  | 256 |  |
| Demonstration systems |  |  | 35 |  |  |  | 38 |  |  |  | 39 |  |
| Total |  | $ | 1,591 |  |  | $ | 1,528 |  |  | $ | 1,476 |  |

[0001193125-14-308403:8k_2_02:107]
INVENTORY TURNS AND RECONCILIATION OF GAAP TO NON-GAAP

[0001193125-14-308403:8k_2_02:108]
COST OF SALES USED IN INVENTORY TURNS

[0001193125-14-308403:8k_2_02:109]
(In millions, except annualized inventory turns)

[0001193125-14-308403:8k_2_02:110]
|  |  | Three Months Ended |  |
|  |  | July 26,2014 |  |  | April 26,2014 |  |  | July 27,2013 |  |
| Annualized inventory turns - GAAP |  |  | 12.7 |  |  |  | 11.8 |  |  |  | 13.8 |  |
| Cost of sales adjustments |  |  | (0.6 | ) |  |  | (0.6 | ) |  |  | (1.0 | ) |
| Annualized inventory turns - non-GAAP |  |  | 12.1 |  |  |  | 11.2 |  |  |  | 12.8 |  |
| GAAP cost of sales |  | $ | 4,952 |  |  | $ | 4,539 |  |  | $ | 5,070 |  |
| Cost of sales adjustments: |  |  |  |  |
| Share-based compensation expense |  |  | (49 | ) |  |  | (51 | ) |  |  | (42 | ) |
| Amortization of acquisition-related intangible assets |  |  | (180 | ) |  |  | (181 | ) |  |  | (153 | ) |
| TiVo patent litigation settlement |  |  | — |  |  |  | — |  |  |  | (172 | ) |
| Acquisition-related/divestiture costs |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of sales |  | $ | 4,722 |  |  | $ | 4,306 |  |  | $ | 4,702 |  |

[0001193125-14-308403:8k_2_02:111]
DEFERRED REVENUE

[0001193125-14-308403:8k_2_02:112]
(In millions)

[0001193125-14-308403:8k_2_02:113]
|  |  | July 26,2014 |  |  | April 26,2014 |  |  | July 27,2013 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 9,640 |  |  | $ | 8,746 |  |  | $ | 9,403 |  |
| Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  |  | 3,924 |  |  |  | 3,669 |  |  |  | 3,340 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  |  | 578 |  |  |  | 736 |  |  |  | 680 |  |
| Total product deferred revenue |  |  | 4,502 |  |  |  | 4,405 |  |  |  | 4,020 |  |
| Total |  | $ | 14,142 |  |  | $ | 13,151 |  |  | $ | 13,423 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,478 |  |  | $ | 9,198 |  |  | $ | 9,262 |  |
| Noncurrent |  |  | 4,664 |  |  |  | 3,953 |  |  |  | 4,161 |  |
| Total |  | $ | 14,142 |  |  | $ | 13,151 |  |  | $ | 13,423 |  |

[0001193125-14-308403:8k_2_02:114]
SUMMARY OF SHARE-BASED COMPENSATION EXPENSE

[0001193125-14-308403:8k_2_02:115]
(In millions)

[0001193125-14-308403:8k_2_02:116]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 26,2014 |  |  | July 27,2013 |  |  | July 26,2014 |  |  | July 27,2013 |  |
| Cost of sales - product |  | $ | 11 |  |  | $ | 9 |  |  | $ | 45 |  |  | $ | 40 |  |
| Cost of sales - service |  |  | 38 |  |  |  | 33 |  |  |  | 150 |  |  |  | 138 |  |
| Share-based compensation expense in cost of sales |  |  | 49 |  |  |  | 42 |  |  |  | 195 |  |  |  | 178 |  |
| Research and development |  |  | 105 |  |  |  | 58 |  |  |  | 411 |  |  |  | 286 |  |
| Sales and marketing |  |  | 141 |  |  |  | 101 |  |  |  | 549 |  |  |  | 484 |  |
| General and administrative |  |  | 45 |  |  |  | 39 |  |  |  | 198 |  |  |  | 175 |  |
| Restructuring and other charges |  |  | (1 | ) |  |  | — |  |  |  | (5 | ) |  |  | (3 | ) |
| Share-based compensation expense in operating expenses |  |  | 290 |  |  |  | 198 |  |  |  | 1,153 |  |  |  | 942 |  |
| Total share-based compensation expense |  | $ | 339 |  |  | $ | 240 |  |  | $ | 1,348 |  |  | $ | 1,120 |  |
| Income tax benefit for share-based compensation |  | $ | 78 |  |  | $ | 53 |  |  | $ | 324 |  |  | $ | 285 |  |

[0001193125-14-308403:8k_2_02:117]
11
