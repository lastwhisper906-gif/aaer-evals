# CSCO MD&A — 0000858877-26-000021


## mdna

[0000858877-26-000021:mdna:1]
[same as prior period, unchanged from 0000858877-25-000171:mdna:1]

[0000858877-26-000021:mdna:2]
[same as prior period, unchanged from 0000858877-25-000171:mdna:2]

[0000858877-26-000021:mdna:3]
[same as prior period, unchanged from 0000858877-25-000171:mdna:3]

[0000858877-26-000021:mdna:4]
[same as prior period, unchanged from 0000858877-25-000171:mdna:4]

[0000858877-26-000021:mdna:5]
[same as prior period, unchanged from 0000858877-25-000171:mdna:5]

[0000858877-26-000021:mdna:6]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | January 24,2026 |  | January 25,2025 |  | % Variance |  |  | January 24,2026 |  | January 25,2025 |  | % Variance |  |
| Revenue | $ | 15,349 |  |  | $ | 13,991 |  |  | 10 | % |  |  | $ | 30,232 |  |  | $ | 27,832 |  |  | 9 | % |  |
| Gross margin percentage | 65.0 | % |  | 65.1 | % |  | (0.1) |  | pts |  | 65.2 | % |  | 65.5 | % |  | (0.3) |  | pts |
| Research and development | $ | 2,355 |  |  | $ | 2,299 |  |  | 2 | % |  |  | $ | 4,755 |  |  | $ | 4,585 |  |  | 4 | % |  |
| Sales and marketing | $ | 2,881 |  |  | $ | 2,672 |  |  | 8 | % |  |  | $ | 5,752 |  |  | $ | 5,424 |  |  | 6 | % |  |
| General and administrative | $ | 688 |  |  | $ | 752 |  |  | (9) | % |  |  | $ | 1,421 |  |  | $ | 1,547 |  |  | (8) | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 5,924 |  |  | $ | 5,723 |  |  | 4 | % |  |  | $ | 11,928 |  |  | $ | 11,556 |  |  | 3 | % |  |
| Total as a percentage of revenue | 38.6 | % |  | 40.9 | % |  | (2.3) |  | pts |  | 39.5 | % |  | 41.5 | % |  | (2.0) |  | pts |
| Operating income as a percentage of revenue | 24.6 | % |  | 22.3 | % |  | 2.3 |  | pts |  | 23.6 | % |  | 19.7 | % |  | 3.9 |  | pts |
| Interest and other income (loss), net | $ | (135) |  |  | $ | (226) |  |  | (40) | % |  |  | $ | (107) |  |  | $ | (317) |  |  | (66) | % |  |
| Income tax percentage | 12.9 | % |  | 15.9 | % |  | (3.0) |  | pts |  | 14.2 | % |  | 0.3 | % |  | 13.9 |  | pts |
| Net income | $ | 3,175 |  |  | $ | 2,428 |  |  | 31 | % |  |  | $ | 6,035 |  |  | $ | 5,139 |  |  | 17 | % |  |
| Net income as a percentage of revenue | 20.7 | % |  | 17.4 | % |  | 3.3 |  | pts |  | 20.0 | % |  | 18.5 | % |  | 1.5 |  | pts |
| Earnings per share—diluted | $ | 0.80 |  |  | $ | 0.61 |  |  | 31 | % |  |  | $ | 1.51 |  |  | $ | 1.28 |  |  | 18 | % |  |

[0000858877-26-000021:mdna:7]
[same as prior period, unchanged from 0000858877-25-000171:mdna:8]

[0000858877-26-000021:mdna:8]
[same as prior period, unchanged from 0000858877-25-000171:mdna:10]

[0000858877-26-000021:mdna:9]
[same as prior period, unchanged from 0000858877-25-000171:mdna:11]

[0000858877-26-000021:mdna:10]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:11]
In the second quarter of fiscal 2026, we delivered strong revenue growth and profitability as we saw a continued positive demand environment. Total revenue increased by 10% compared with the second quarter of fiscal 2025. Within total revenue, product revenue increased by 14% and services revenue decreased by 1%. In the second quarter of fiscal 2026, total software revenue was $5.7 billion across all product areas and services, an increase of 2%. Total subscription revenue was flat.

[0000858877-26-000021:mdna:12]
Total gross margin decreased by 0.1 percentage points. Product gross margin increased by 0.2 percentage points, primarily driven by productivity improvements and lower amortization of purchased intangible assets, partially offset by negative impacts from product mix and pricing. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 2.3 percentage points. Operating income as a percentage of revenue increased by 2.3 percentage points, primarily driven by revenue growth and lower amortization of purchased intangible assets in the second quarter of fiscal 2026. Diluted earnings per share increased 31%, driven by revenue growth and operating margin improvement.

[0000858877-26-000021:mdna:13]
In terms of our geographic segments, revenue from the Americas increased by $0.6 billion, EMEA revenue increased by $0.6 billion and APJC revenue increased by $0.1 billion. From a customer market standpoint, we experienced product revenue growth across all of our customer markets.

[0000858877-26-000021:mdna:14]
From a product category perspective, the product revenue increase of 14% was driven by growth in Networking of 21%, particularly within our AI Infrastructure and Campus Networking solutions where we expect to continue to see positive business momentum. We saw a decline in Security of 4%, primarily driven by declines in our prior generation products and our Splunk business where we continued to see a change in how our customers consumed Splunk offerings, shifting from fewer on-premise deals to more cloud subscriptions. We expect this trend to continue in the second half of fiscal 2026.

[0000858877-26-000021:mdna:15]
We continue to operate in a highly competitive and complex environment, especially as it relates to memory constraints and costs, and trade policy. Notwithstanding these challenges, we believe that we are making progress on our strategic priorities. We continue to invest in key priority areas with the objective of driving profitable growth over the long term. We remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformations and on accelerating innovation across our portfolio.

[0000858877-26-000021:mdna:16]
37

[0000858877-26-000021:mdna:17]
[same as prior period, unchanged from 0000858877-25-000171:mdna:24]

[0000858877-26-000021:mdna:18]
[same as prior period, unchanged from 0000858877-25-000171:mdna:25]

[0000858877-26-000021:mdna:19]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:20]
Total revenue increased 9%, with product revenue increasing 12% and services revenue was flat. Total gross margin decreased 0.3 percentage points, primarily driven by negative impacts from product mix and pricing, partially offset by productivity improvements and lower amortization of purchased intangible assets. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 2.0 percentage points. Operating income as a percentage of revenue increased by 3.9 percentage points, primarily driven by higher revenue, lower restructuring and other charges and lower amortization of purchased intangible assets in the first six months of fiscal 2026. Diluted earnings per share increased 18%, driven by revenue growth and operating margin improvement, partially offset by the income tax benefit of $720 million we had in the first six months of fiscal 2025.

[0000858877-26-000021:mdna:21]
[same as prior period, unchanged from 0000858877-25-000171:mdna:17]

[0000858877-26-000021:mdna:22]
[same as prior period, unchanged from 0000858877-25-000171:mdna:18]

[0000858877-26-000021:mdna:23]
[same as prior period, unchanged from 0000858877-25-000171:mdna:19]

[0000858877-26-000021:mdna:24]
[same as prior period, unchanged from 0000858877-25-000171:mdna:20]

[0000858877-26-000021:mdna:25]
The following is a summary of our other key financial measures for the second quarter of fiscal 2026 (in millions):

[0000858877-26-000021:mdna:26]
|  |  | January 24,2026 |  | July 26,2025 |
| Cash and cash equivalents and investments |  | $ | 15,777 |  |  | $ | 16,110 |  |
| Remaining performance obligations |  | $ | 43,406 |  |  | $ | 43,533 |  |
| Inventories |  | $ | 3,920 |  |  | $ | 3,164 |  |
| Total debt |  | $ | 30,086 |  |  | $ | 28,093 |  |

[0000858877-26-000021:mdna:27]
|  |  | Six Months Ended |
|  |  | January 24,2026 |  | January 25,2025 |
| Cash provided by operating activities |  | $ | 5,034 |  |  | $ | 5,902 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 3,352 |  |  | $ | 3,239 |  |
| Dividends paid |  | $ | 3,234 |  |  | $ | 3,185 |  |

[0000858877-26-000021:mdna:28]
[same as prior period, unchanged from 0000858877-25-000171:mdna:36]

[0000858877-26-000021:mdna:29]
[same as prior period, unchanged from 0000858877-25-000171:mdna:37]

[0000858877-26-000021:mdna:30]
[same as prior period, unchanged from 0000858877-25-000171:mdna:26]

[0000858877-26-000021:mdna:31]
[same as prior period, unchanged from 0000858877-25-000171:mdna:27]

[0000858877-26-000021:mdna:32]
[same as prior period, unchanged from 0000858877-25-000171:mdna:28]

[0000858877-26-000021:mdna:33]
[same as prior period, unchanged from 0000858877-25-000171:mdna:29]

[0000858877-26-000021:mdna:34]
[same as prior period, unchanged from 0000858877-25-000171:mdna:30]

[0000858877-26-000021:mdna:35]
[same as prior period, unchanged from 0000858877-25-000171:mdna:31]

[0000858877-26-000021:mdna:36]
[same as prior period, unchanged from 0000858877-25-000171:mdna:32]

[0000858877-26-000021:mdna:37]
[same as prior period, unchanged from 0000858877-25-000171:mdna:33]

[0000858877-26-000021:mdna:38]
[same as prior period, unchanged from 0000858877-25-000171:mdna:34]

[0000858877-26-000021:mdna:39]
[same as prior period, unchanged from 0000858877-25-000171:mdna:35]

[0000858877-26-000021:mdna:40]
[same as prior period, unchanged from 0000858877-25-000171:mdna:50]

[0000858877-26-000021:mdna:41]
[same as prior period, unchanged from 0000858877-25-000171:mdna:51]

[0000858877-26-000021:mdna:42]
[same as prior period, unchanged from 0000858877-25-000171:mdna:38]

[0000858877-26-000021:mdna:43]
Our total provisions for inventory and the liability related to purchase commitments with contract manufacturers and suppliers were $104 million and $357 million for the first six months of fiscal 2026 and 2025, respectively. If there were to be a sudden and significant decrease in demand for our products, or a higher incidence of inventory obsolescence because of rapidly changing technology or customer requirements, then we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. For further discussion around the supply chain impacts and risks, see “—Results of Operations—Gross Margin—Supply Chain Impacts and Risks” and “—Liquidity and Capital Resources—Inventory Supply Chain.”

[0000858877-26-000021:mdna:44]
Loss Contingencies

[0000858877-26-000021:mdna:45]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-26-000021:mdna:46]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-26-000021:mdna:47]
[same as prior period, unchanged from 0000858877-25-000171:mdna:43]

[0000858877-26-000021:mdna:48]
[same as prior period, unchanged from 0000858877-25-000171:mdna:44]

[0000858877-26-000021:mdna:49]
[same as prior period, unchanged from 0000858877-25-000171:mdna:45]

[0000858877-26-000021:mdna:50]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first six months of fiscal 2026 and 2025.

[0000858877-26-000021:mdna:51]
[same as prior period, unchanged from 0000858877-25-000171:mdna:47]

[0000858877-26-000021:mdna:52]
[same as prior period, unchanged from 0000858877-25-000171:mdna:48]

[0000858877-26-000021:mdna:53]
[same as prior period, unchanged from 0000858877-25-000171:mdna:49]

[0000858877-26-000021:mdna:54]
[same as prior period, unchanged from 0000858877-25-000171:mdna:71]

[0000858877-26-000021:mdna:55]
[same as prior period, unchanged from 0000858877-25-000171:mdna:58]

[0000858877-26-000021:mdna:56]
[same as prior period, unchanged from 0000858877-25-000171:mdna:59]

[0000858877-26-000021:mdna:57]
[same as prior period, unchanged from 0000858877-25-000171:mdna:52]

[0000858877-26-000021:mdna:58]
[same as prior period, unchanged from 0000858877-25-000171:mdna:53]

[0000858877-26-000021:mdna:59]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was 12.9% and 15.9% in the second quarter of fiscal 2026 and 2025, respectively and 14.2% and 0.3% in the first six months of fiscal 2026 and 2025, respectively.

[0000858877-26-000021:mdna:60]
[same as prior period, unchanged from 0000858877-25-000171:mdna:55]

[0000858877-26-000021:mdna:61]
[same as prior period, unchanged from 0000858877-25-000171:mdna:56]

[0000858877-26-000021:mdna:62]
[same as prior period, unchanged from 0000858877-25-000171:mdna:57]

[0000858877-26-000021:mdna:63]
[same as prior period, unchanged from 0000858877-25-000171:mdna:72]

[0000858877-26-000021:mdna:64]
[same as prior period, unchanged from 0000858877-25-000171:mdna:73]

[0000858877-26-000021:mdna:65]
[same as prior period, unchanged from 0000858877-25-000171:mdna:60]

[0000858877-26-000021:mdna:66]
[same as prior period, unchanged from 0000858877-25-000171:mdna:61]

[0000858877-26-000021:mdna:67]
[same as prior period, unchanged from 0000858877-25-000171:mdna:62]

[0000858877-26-000021:mdna:68]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |  | Variance in Percent |  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 11,642 |  |  | $ | 10,234 |  |  | $ | 1,408 |  |  | 14 | % |  | $ | 22,719 |  |  | $ | 20,348 |  |  | $ | 2,371 |  |  | 12 | % |
| Percentage of revenue |  | 75.8 | % |  | 73.1 | % |  |  |  |  |  | 75.1 | % |  | 73.1 | % |  |  |  |  |
| Services |  | 3,707 |  |  | 3,757 |  |  | (50) |  |  | (1) | % |  | 7,513 |  |  | 7,484 |  |  | 29 |  |  | — | % |
| Percentage of revenue |  | 24.2 | % |  | 26.9 | % |  |  |  |  |  | 24.9 | % |  | 26.9 | % |  |  |  |  |
| Total |  | $ | 15,349 |  |  | $ | 13,991 |  |  | $ | 1,358 |  |  | 10 | % |  | $ | 30,232 |  |  | $ | 27,832 |  |  | $ | 2,400 |  |  | 9 | % |

[0000858877-26-000021:mdna:69]
[same as prior period, unchanged from 0000858877-25-000171:mdna:64]

[0000858877-26-000021:mdna:70]
[same as prior period, unchanged from 0000858877-25-000171:mdna:65]

[0000858877-26-000021:mdna:71]
|  |  | Three Months Ended |  | Six Months Ended |  |  |
|  |  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |  | Variance in Percent |  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |  | Variance in Percent |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 8,845 |  |  | $ | 8,202 |  |  | $ | 643 |  |  | 8 | % |  | $ | 17,834 |  |  | $ | 16,454 |  |  | $ | 1,380 |  |  | 8 | % |  |  |  |  |  |  |  |  |
| Percentage of revenue |  | 57.6 | % |  | 58.6 | % |  |  |  |  |  | 58.9 | % |  | 59.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| EMEA |  | 4,425 |  |  | 3,855 |  |  | 570 |  |  | 15 | % |  | 8,208 |  |  | 7,444 |  |  | 764 |  |  | 10 | % |  |  |  |  |  |  |  |  |
| Percentage of revenue |  | 28.8 | % |  | 27.6 | % |  |  |  |  |  | 27.2 | % |  | 26.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| APJC |  | 2,080 |  |  | 1,934 |  |  | 146 |  |  | 8 | % |  | 4,191 |  |  | 3,934 |  |  | 257 |  |  | 7 | % |  |  |  |  |  |  |  |  |
| Percentage of revenue |  | 13.6 | % |  | 13.8 | % |  |  |  |  |  | 13.9 | % |  | 14.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 15,349 |  |  | $ | 13,991 |  |  | $ | 1,358 |  |  | 10 | % |  | $ | 30,232 |  |  | $ | 27,832 |  |  | $ | 2,400 |  |  | 9 | % |  |  |  |  |  |  |  |  |

[0000858877-26-000021:mdna:72]
[same as prior period, unchanged from 0000858877-25-000171:mdna:67]

[0000858877-26-000021:mdna:73]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:74]
Total revenue increased by 10%. Product revenue increased by 14% and services revenue decreased by 1%. Our total revenue reflected growth across each of our geographic segments.

[0000858877-26-000021:mdna:75]
[same as prior period, unchanged from 0000858877-25-000171:mdna:70]

[0000858877-26-000021:mdna:76]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:77]
Total revenue increased by 9%. Product revenue increased by 12% and services revenue was flat. Our total revenue reflected growth across each of our geographic segments.

[0000858877-26-000021:mdna:78]
[same as prior period, unchanged from 0000858877-25-000171:mdna:86]

[0000858877-26-000021:mdna:79]
[same as prior period, unchanged from 0000858877-25-000171:mdna:87]

[0000858877-26-000021:mdna:80]
[same as prior period, unchanged from 0000858877-25-000171:mdna:74]

[0000858877-26-000021:mdna:81]
[same as prior period, unchanged from 0000858877-25-000171:mdna:75]

[0000858877-26-000021:mdna:82]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |  | Variance in Percent |  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 6,650 |  |  | $ | 5,947 |  |  | $ | 703 |  |  | 12 | % |  | $ | 13,356 |  |  | $ | 11,950 |  |  | $ | 1,406 |  |  | 12 | % |
| Percentage of product revenue |  | 57.1 | % |  | 58.1 | % |  |  |  |  |  | 58.8 | % |  | 58.7 | % |  |  |  |  |
| EMEA |  | 3,487 |  |  | 2,926 |  |  | 561 |  |  | 19 | % |  | 6,332 |  |  | 5,612 |  |  | 720 |  |  | 13 | % |
| Percentage of product revenue |  | 30.0 | % |  | 28.6 | % |  |  |  |  |  | 27.9 | % |  | 27.6 | % |  |  |  |  |
| APJC |  | 1,506 |  |  | 1,360 |  |  | 146 |  |  | 11 | % |  | 3,031 |  |  | 2,786 |  |  | 245 |  |  | 9 | % |
| Percentage of product revenue |  | 12.9 | % |  | 13.3 | % |  |  |  |  |  | 13.3 | % |  | 13.7 | % |  |  |  |  |
| Total |  | $ | 11,642 |  |  | $ | 10,234 |  |  | $ | 1,408 |  |  | 14 | % |  | $ | 22,719 |  |  | $ | 20,348 |  |  | $ | 2,371 |  |  | 12 | % |

[0000858877-26-000021:mdna:83]
[same as prior period, unchanged from 0000858877-25-000171:mdna:77]

[0000858877-26-000021:mdna:84]
[same as prior period, unchanged from 0000858877-25-000171:mdna:79]

[0000858877-26-000021:mdna:85]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:86]
Product revenue in the Americas segment increased by 12%, with growth across each of our customer markets, led by the Service Provider and Cloud customer market which was largely driven by revenue from our AI Infrastructure solutions. From a country perspective, product revenue increased in the United States, Canada, Mexico and Brazil by 12%, 5%, 36%, and 6%, respectively.

[0000858877-26-000021:mdna:87]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:88]
Product revenue in the Americas segment increased by 12%, with growth across each of our customer markets, led by the Service Provider and Cloud customer market which was largely driven by revenue from our AI Infrastructure solutions. From a country perspective, product revenue increased in the United States, Canada and Mexico by 13%, 1%, and 31%, respectively, partially offset by a decline in Brazil of 14%.

[0000858877-26-000021:mdna:89]
[same as prior period, unchanged from 0000858877-25-000171:mdna:81]

[0000858877-26-000021:mdna:90]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:91]
Product revenue in the EMEA segment increased by 19%, with growth across each of our customer markets. From a country perspective, product revenue increased in Germany and the United Kingdom by 23% and 41%, respectively.

[0000858877-26-000021:mdna:92]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:93]
Product revenue in the EMEA segment increased by 13%, with growth across each of our customer markets. From a country perspective, product revenue increased in Germany and the United Kingdom by 12% and 22%, respectively.

[0000858877-26-000021:mdna:94]
[same as prior period, unchanged from 0000858877-25-000171:mdna:83]

[0000858877-26-000021:mdna:95]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:96]
Product revenue in the APJC segment increased by 11%, with growth across each of our customer markets. From a country perspective, product revenue increased in Japan and India by 27% and 2%, respectively, partially offset by declines in Australia and China of 1% and 4%, respectively.

[0000858877-26-000021:mdna:97]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:98]
Product revenue in the APJC segment increased by 9%, with growth across each of our customer markets. From a country perspective, product revenue increased in Japan, India and China by 19%, 1%, and 5%, respectively, partially offset by a decline in Australia of 6%.

[0000858877-26-000021:mdna:99]
[same as prior period, unchanged from 0000858877-25-000171:mdna:102]

[0000858877-26-000021:mdna:100]
[same as prior period, unchanged from 0000858877-25-000171:mdna:103]

[0000858877-26-000021:mdna:101]
[same as prior period, unchanged from 0000858877-25-000171:mdna:88]

[0000858877-26-000021:mdna:102]
[same as prior period, unchanged from 0000858877-25-000171:mdna:89]

[0000858877-26-000021:mdna:103]
[same as prior period, unchanged from 0000858877-25-000171:mdna:90]

[0000858877-26-000021:mdna:104]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |  | Variance in Percent |  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking |  | $ | 8,294 |  |  | $ | 6,850 |  |  | $ | 1,444 |  |  | 21 | % |  | $ | 16,061 |  |  | $ | 13,603 |  |  | $ | 2,458 |  |  | 18 | % |
| Security |  | 2,018 |  |  | 2,111 |  |  | (93) |  |  | (4) | % |  | 3,998 |  |  | 4,129 |  |  | (131) |  |  | (3) | % |
| Collaboration |  | 1,054 |  |  | 996 |  |  | 58 |  |  | 6 | % |  | 2,109 |  |  | 2,081 |  |  | 28 |  |  | 1 | % |
| Observability |  | 277 |  |  | 277 |  |  | — |  |  | — | % |  | 550 |  |  | 535 |  |  | 15 |  |  | 3 | % |
| Total |  | $ | 11,642 |  |  | $ | 10,234 |  |  | $ | 1,408 |  |  | 14 | % |  | $ | 22,719 |  |  | $ | 20,348 |  |  | $ | 2,371 |  |  | 12 | % |

[0000858877-26-000021:mdna:105]
[same as prior period, unchanged from 0000858877-25-000171:mdna:92]

[0000858877-26-000021:mdna:106]
[same as prior period, unchanged from 0000858877-25-000171:mdna:94]

[0000858877-26-000021:mdna:107]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:108]
The Networking product category consists of our core networking technologies of switching, routing, wireless, and servers. Revenue from the Networking product category increased by 21%, or $1.4 billion primarily driven by our AI Infrastructure and Campus Networking solutions. The increase was primarily driven by double digit revenue growth in Service Provider Routing, Data Center Switching, Campus Switching, Enterprise Routing, Wireless and Compute.

[0000858877-26-000021:mdna:109]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:110]
Revenue from the Networking product category increased by 18%, or $2.5 billion. The increase was primarily driven by double digit revenue growth in Service Provider Routing, particularly within our AI Infrastructure solutions, Data Center Switching and Enterprise Routing. We also experienced revenue growth in Campus Switching and Wireless.

[0000858877-26-000021:mdna:111]
[same as prior period, unchanged from 0000858877-25-000171:mdna:96]

[0000858877-26-000021:mdna:112]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:113]
The Security product category consists of our Network Security, Identity and Access Management, SASE and Threat Intelligence, Detection, and Response offerings. Revenue in our Security product category decreased by 4%, or $93 million. The decline was primarily driven by our prior generation products and Splunk offerings. We continued to see a change in how our customers consumed Splunk offerings, shifting from fewer on-premise deals to more cloud subscriptions. These declines were partially offset by growth in new and refreshed products.

[0000858877-26-000021:mdna:114]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:115]
Revenue from the Security product category decreased by 3%, or $131 million, primarily driven by Threat Intelligence, Detection, and Response offerings and our prior generation products, partially offset by growth in SASE and Duo offerings.

[0000858877-26-000021:mdna:116]
[same as prior period, unchanged from 0000858877-25-000171:mdna:98]

[0000858877-26-000021:mdna:117]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:118]
The Collaboration product category consists of our Webex Suite, Collaboration Devices, Contact Center and CPaaS offerings. Revenue in our Collaboration product category increased by 6%, or $58 million, primarily driven by double digit revenue growth in our Collaboration Devices, Cloud Contact Center and CPaaS offerings. We also experienced growth in our Webex Suite offerings.

[0000858877-26-000021:mdna:119]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:120]
Revenue from the Collaboration product category increased by 1%, or $28 million, primarily driven by revenue growth in our Collaboration Devices and CPaaS offerings.

[0000858877-26-000021:mdna:121]
44

[0000858877-26-000021:mdna:122]
[same as prior period, unchanged from 0000858877-25-000171:mdna:116]

[0000858877-26-000021:mdna:123]
[same as prior period, unchanged from 0000858877-25-000171:mdna:117]

[0000858877-26-000021:mdna:124]
[same as prior period, unchanged from 0000858877-25-000171:mdna:100]

[0000858877-26-000021:mdna:125]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:126]
The Observability product category consists of our network assurance, monitoring and analytics and observability suite offerings. Revenue in our Observability product category was flat, primarily due to growth in ThousandEyes offset by a decline in Splunk offerings.

[0000858877-26-000021:mdna:127]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:128]
Revenue from Observability product category increased by 3%, or $15 million, primarily driven by growth in ThousandEyes.

[0000858877-26-000021:mdna:129]
[same as prior period, unchanged from 0000858877-25-000171:mdna:104]

[0000858877-26-000021:mdna:130]
[same as prior period, unchanged from 0000858877-25-000171:mdna:105]

[0000858877-26-000021:mdna:131]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |  | Variance in Percent |  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |  | Variance in Percent |
| Services revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,195 |  |  | $ | 2,255 |  |  | $ | (60) |  |  | (3) | % |  | $ | 4,478 |  |  | $ | 4,505 |  |  | $ | (27) |  |  | (1) | % |
| Percentage of service revenue |  | 59.2 | % |  | 60.0 | % |  |  |  |  |  | 59.6 | % |  | 60.2 | % |  |  |  |  |
| EMEA |  | 938 |  |  | 929 |  |  | 9 |  |  | 1 | % |  | 1,876 |  |  | 1,832 |  |  | 44 |  |  | 2 | % |
| Percentage of service revenue |  | 25.3 | % |  | 24.7 | % |  |  |  |  |  | 25.0 | % |  | 24.5 | % |  |  |  |  |
| APJC |  | 574 |  |  | 573 |  |  | 1 |  |  | — | % |  | 1,160 |  |  | 1,148 |  |  | 12 |  |  | 1 | % |
| Percentage of service revenue |  | 15.5 | % |  | 15.3 | % |  |  |  |  |  | 15.4 | % |  | 15.3 | % |  |  |  |  |
| Total |  | $ | 3,707 |  |  | $ | 3,757 |  |  | $ | (50) |  |  | (1) | % |  | $ | 7,513 |  |  | $ | 7,484 |  |  | $ | 29 |  |  | — | % |

[0000858877-26-000021:mdna:132]
[same as prior period, unchanged from 0000858877-25-000171:mdna:107]

[0000858877-26-000021:mdna:133]
Services revenue decreased by 1% in the second quarter of fiscal 2026 compared with the second quarter of fiscal 2025, with the decline primarily driven by lower revenue from support services, partially offset by higher professional services. Services revenue declined in the Americas segment, partially offset by an increase in the EMEA segment for the second quarter of fiscal 2026. Service revenue in the APJC segment was flat.

[0000858877-26-000021:mdna:134]
Services revenue was flat in the first six months of fiscal 2026 compared to the first six months of fiscal 2025. Services revenue increased in the EMEA and APJC segments, offset by a decline in the Americas segment.

[0000858877-26-000021:mdna:135]
[same as prior period, unchanged from 0000858877-25-000171:mdna:109]

[0000858877-26-000021:mdna:136]
[same as prior period, unchanged from 0000858877-25-000171:mdna:110]

[0000858877-26-000021:mdna:137]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | January 24,2026 |  | January 25,2025 |  | January 24,2026 |  | January 25,2025 |  | January 24,2026 |  | January 25,2025 |  | January 24,2026 |  | January 25,2025 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 7,437 |  |  | $ | 6,521 |  |  | 63.9 | % |  | 63.7 | % |  | $ | 14,580 |  |  | $ | 13,109 |  |  | 64.2 | % |  | 64.4 | % |
| Services |  | 2,535 |  |  | 2,590 |  |  | 68.4 | % |  | 68.9 | % |  | 5,137 |  |  | 5,123 |  |  | 68.4 | % |  | 68.5 | % |
| Total |  | $ | 9,972 |  |  | $ | 9,111 |  |  | 65.0 | % |  | 65.1 | % |  | $ | 19,717 |  |  | $ | 18,232 |  |  | 65.2 | % |  | 65.5 | % |

[0000858877-26-000021:mdna:138]
45

[0000858877-26-000021:mdna:139]
[same as prior period, unchanged from 0000858877-25-000171:mdna:135]

[0000858877-26-000021:mdna:140]
[same as prior period, unchanged from 0000858877-25-000171:mdna:136]

[0000858877-26-000021:mdna:141]
[same as prior period, unchanged from 0000858877-25-000171:mdna:112]

[0000858877-26-000021:mdna:142]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the second quarter and first six months of fiscal 2026, as compared with the corresponding prior year periods:

[0000858877-26-000021:mdna:143]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Six Months Ended |
| Fiscal 2025 |  | 63.7 | % |  | 64.4 | % |
| Productivity (1) |  | 2.7 | % |  | 2.5 | % |
| Product pricing |  | (0.9) | % |  | (1.0) | % |
| Mix of products sold |  | (3.1) | % |  | (3.0) | % |
| Amortization of purchased intangible assets |  | 1.3 | % |  | 1.2 | % |
| Others |  | 0.2 | % |  | 0.1 | % |
| Fiscal 2026 |  | 63.9 | % |  | 64.2 | % |

[0000858877-26-000021:mdna:144]
[same as prior period, unchanged from 0000858877-25-000171:mdna:115]

[0000858877-26-000021:mdna:145]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:146]
Product gross margin increased by 0.2 percentage points primarily driven by productivity improvements and lower amortization of purchased intangible assets, partially offset by negative impacts from product mix and pricing. Productivity benefits were adversely impacted by higher memory costs. The negative impacts from product mix were primarily due to higher Networking revenue and lower Security revenue.

[0000858877-26-000021:mdna:147]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:148]
Product gross margin decreased by 0.2 percentage points primarily driven by negative impacts from product mix and pricing, partially offset by productivity improvements and lower amortization of purchased intangible assets.

[0000858877-26-000021:mdna:149]
[same as prior period, unchanged from 0000858877-25-000171:mdna:120]

[0000858877-26-000021:mdna:150]
We regularly enter into purchase commitments with contract manufacturers and suppliers and in recent periods have increased such commitments related to manufacturing Cisco Silicon One and other products to meet demand from hyperscalers and other customers. We expect to continue entering into these additional purchase commitments in fiscal 2026, including purchase commitments to help secure memory. These purchase commitments have in turn significantly increased our supply chain exposure. This exposure includes potential material excess and obsolete or other charges if product demand significantly decreases for a sustained duration, we are unable to generate demand for certain products, or we are otherwise unable to mitigate this exposure. Additionally, while we are exposed to new and proposed tariffs and other trade policies, the extent of such exposure is uncertain but could be significant if the exposure remains and we are unable to mitigate it.

[0000858877-26-000021:mdna:151]
[same as prior period, unchanged from 0000858877-25-000171:mdna:122]

[0000858877-26-000021:mdna:152]
Our services gross margin percentage decreased by 0.5 percentage points in the second quarter of fiscal 2026 and decreased by 0.1 percentage points in the first six months of fiscal 2026. For each of the second quarter and first six months of fiscal 2026, the decrease in services gross margin was primarily driven by higher headcount costs and mix of service offerings.

[0000858877-26-000021:mdna:153]
[same as prior period, unchanged from 0000858877-25-000171:mdna:125]

[0000858877-26-000021:mdna:154]
[same as prior period, unchanged from 0000858877-25-000171:mdna:155]

[0000858877-26-000021:mdna:155]
[same as prior period, unchanged from 0000858877-25-000171:mdna:156]

[0000858877-26-000021:mdna:156]
[same as prior period, unchanged from 0000858877-25-000171:mdna:126]

[0000858877-26-000021:mdna:157]
[same as prior period, unchanged from 0000858877-25-000171:mdna:127]

[0000858877-26-000021:mdna:158]
|  | Three Months Ended |  | Six Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | January 24,2026 |  | January 25,2025 |  | January 24,2026 |  | January 25,2025 |  | January 24,2026 |  | January 25,2025 |  | January 24,2026 |  | January 25,2025 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 5,816 |  |  | $ | 5,545 |  |  | 65.8 | % |  | 67.6 | % |  | $ | 11,817 |  |  | $ | 11,285 |  |  | 66.3 | % |  | 68.6 | % |
| EMEA | 3,173 |  |  | 2,750 |  |  | 71.7 | % |  | 71.3 | % |  | 5,895 |  |  | 5,272 |  |  | 71.8 | % |  | 70.8 | % |
| APJC | 1,368 |  |  | 1,320 |  |  | 65.8 | % |  | 68.3 | % |  | 2,781 |  |  | 2,648 |  |  | 66.4 | % |  | 67.3 | % |
| Segment total | 10,357 |  |  | 9,614 |  |  | 67.5 | % |  | 68.7 | % |  | 20,493 |  |  | 19,204 |  |  | 67.8 | % |  | 69.0 | % |
| Unallocated corporate items (1) | (385) |  |  | (503) |  |  |  |  |  |  | (776) |  |  | (972) |  |  |  |  |  |
| Total | $ | 9,972 |  |  | $ | 9,111 |  |  | 65.0 | % |  | 65.1 | % |  | $ | 19,717 |  |  | $ | 18,232 |  |  | 65.2 | % |  | 65.5 | % |

[0000858877-26-000021:mdna:159]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-26-000021:mdna:160]
[same as prior period, unchanged from 0000858877-25-000171:mdna:130]

[0000858877-26-000021:mdna:161]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:162]
We experienced a gross margin percentage decrease in our Americas segment due to negative impacts from product mix, pricing and lower services gross margin, partially offset by positive impacts from productivity improvements.

[0000858877-26-000021:mdna:163]
Gross margin percentage in our EMEA segment increased primarily due to productivity improvements, partially offset by negative impacts from product mix and pricing.

[0000858877-26-000021:mdna:164]
The decrease in the APJC segment gross margin percentage was primarily due to product mix and pricing, partially offset by productivity improvements.

[0000858877-26-000021:mdna:165]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:166]
[same as prior period, unchanged from 0000858877-25-000171:mdna:132]

[0000858877-26-000021:mdna:167]
Gross margin percentage in our EMEA segment increased primarily due to productivity improvements, partially offset by negative impacts from product mix and pricing.

[0000858877-26-000021:mdna:168]
The decrease in the APJC segment gross margin percentage was primarily due to negative impacts from product mix and pricing, partially offset by productivity improvements.

[0000858877-26-000021:mdna:169]
[same as prior period, unchanged from 0000858877-25-000171:mdna:137]

[0000858877-26-000021:mdna:170]
[same as prior period, unchanged from 0000858877-25-000171:mdna:138]

[0000858877-26-000021:mdna:171]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |  | Variance in Percent |  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 2,355 |  |  | $ | 2,299 |  |  | $ | 56 |  |  | 2 | % |  | $ | 4,755 |  |  | $ | 4,585 |  |  | $ | 170 |  |  | 4 | % |
| Percentage of revenue | 15.3 | % |  | 16.4 | % |  |  |  |  |  | 15.7 | % |  | 16.5 | % |  |  |  |  |
| Sales and marketing | 2,881 |  |  | 2,672 |  |  | 209 |  |  | 8 | % |  | 5,752 |  |  | 5,424 |  |  | 328 |  |  | 6 | % |
| Percentage of revenue | 18.8 | % |  | 19.1 | % |  |  |  |  |  | 19.0 | % |  | 19.5 | % |  |  |  |  |
| General and administrative | 688 |  |  | 752 |  |  | (64) |  |  | (9) | % |  | 1,421 |  |  | 1,547 |  |  | (126) |  |  | (8) | % |
| Percentage of revenue | 4.5 | % |  | 5.4 | % |  |  |  |  |  | 4.7 | % |  | 5.6 | % |  |  |  |  |
| Total | $ | 5,924 |  |  | $ | 5,723 |  |  | $ | 201 |  |  | 4 | % |  | $ | 11,928 |  |  | $ | 11,556 |  |  | $ | 372 |  |  | 3 | % |
| Percentage of revenue | 38.6 | % |  | 40.9 | % |  |  |  |  |  | 39.5 | % |  | 41.5 | % |  |  |  |  |

[0000858877-26-000021:mdna:172]
47

[0000858877-26-000021:mdna:173]
[same as prior period, unchanged from 0000858877-25-000171:mdna:175]

[0000858877-26-000021:mdna:174]
[same as prior period, unchanged from 0000858877-25-000171:mdna:176]

[0000858877-26-000021:mdna:175]
[same as prior period, unchanged from 0000858877-25-000171:mdna:141]

[0000858877-26-000021:mdna:176]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:177]
R&D expenses increased primarily due to higher headcount-related expenses reflecting our investments in AI and higher discretionary spending, partially offset by lower acquisition-related costs.

[0000858877-26-000021:mdna:178]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:179]
R&D expenses increased primarily due to higher headcount-related expenses reflecting our investments in AI, higher share-based compensation expense and higher discretionary spending, partially offset by lower acquisition-related costs.

[0000858877-26-000021:mdna:180]
[same as prior period, unchanged from 0000858877-25-000171:mdna:143]

[0000858877-26-000021:mdna:181]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:182]
Sales and marketing expenses increased primarily due to higher headcount-related expenses, higher contracted services and higher discretionary spending.

[0000858877-26-000021:mdna:183]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:184]
Sales and marketing expenses increased primarily due to higher headcount-related expenses, higher share-based compensation expense, higher contracted services spending, and higher discretionary spending.

[0000858877-26-000021:mdna:185]
[same as prior period, unchanged from 0000858877-25-000171:mdna:145]

[0000858877-26-000021:mdna:186]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:187]
G&A expenses decreased primarily due to lower headcount-related expenses and lower acquisition-related costs.

[0000858877-26-000021:mdna:188]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:189]
[same as prior period, unchanged from 0000858877-25-000171:mdna:146]

[0000858877-26-000021:mdna:190]
[same as prior period, unchanged from 0000858877-25-000171:mdna:147]

[0000858877-26-000021:mdna:191]
In the second quarter of fiscal 2026, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $56 million, or 1.0%, compared with the second quarter of fiscal 2025.

[0000858877-26-000021:mdna:192]
In the first six months of fiscal 2026, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $91 million, or 0.8%, compared with the first six months of fiscal 2025.

[0000858877-26-000021:mdna:193]
[same as prior period, unchanged from 0000858877-25-000171:mdna:149]

[0000858877-26-000021:mdna:194]
[same as prior period, unchanged from 0000858877-25-000171:mdna:150]

[0000858877-26-000021:mdna:195]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24,2026 |  | January 25,2025 |  | January 24,2026 |  | January 25,2025 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 235 |  |  | $ | 340 |  |  | $ | 475 |  |  | $ | 665 |  |
| Operating expenses |  | 231 |  |  | 265 |  |  | 462 |  |  | 530 |  |
| Total |  | $ | 466 |  |  | $ | 605 |  |  | $ | 937 |  |  | $ | 1,195 |  |

[0000858877-26-000021:mdna:196]
For each of the second quarter and first six months of fiscal 2026, the decrease in amortization of purchased intangible assets was primarily due to certain purchased intangible assets that became fully amortized and impairment charges of $19 million recognized in the corresponding periods of fiscal 2025. Impairment charges were as a result of declines in estimated fair value resulting from the reductions in or the elimination of expected future cash flows associated with certain technology intangible assets.

[0000858877-26-000021:mdna:197]
[same as prior period, unchanged from 0000858877-25-000171:mdna:153]

[0000858877-26-000021:mdna:198]
In the first quarter of fiscal 2025, we announced a restructuring plan in order to allow us to invest in key growth opportunities and drive more efficiencies in our business. In connection with this restructuring plan, we incurred charges of $36 million and $183 million in the second quarter and first six months of fiscal 2026. We completed this restructuring plan in the second quarter of fiscal 2026.

[0000858877-26-000021:mdna:199]
[same as prior period, unchanged from 0000858877-25-000171:mdna:189]

[0000858877-26-000021:mdna:200]
[same as prior period, unchanged from 0000858877-25-000171:mdna:190]

[0000858877-26-000021:mdna:201]
[same as prior period, unchanged from 0000858877-25-000171:mdna:157]

[0000858877-26-000021:mdna:202]
[same as prior period, unchanged from 0000858877-25-000171:mdna:158]

[0000858877-26-000021:mdna:203]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24,2026 |  | January 25,2025 |  | January 24,2026 |  | January 25,2025 |
| Operating income |  | $ | 3,781 |  |  | $ | 3,113 |  |  | $ | 7,144 |  |  | $ | 5,471 |  |
| Operating income as a percentage of revenue |  | 24.6 | % |  | 22.3 | % |  | 23.6 | % |  | 19.7 | % |

[0000858877-26-000021:mdna:204]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:205]
Operating income increased by 21%, and operating income as a percentage of revenue increased by 2.3 percentage points. These changes primarily resulted from revenue growth and lower amortization of purchased intangible assets in the second quarter of fiscal 2026.

[0000858877-26-000021:mdna:206]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:207]
Operating income increased by 31%, and operating income as a percentage of revenue increased by 3.9 percentage points. These changes primarily resulted from revenue growth, lower restructuring and other charges and lower amortization of purchased intangible assets in the first six months of fiscal 2026.

[0000858877-26-000021:mdna:208]
[same as prior period, unchanged from 0000858877-25-000171:mdna:162]

[0000858877-26-000021:mdna:209]
[same as prior period, unchanged from 0000858877-25-000171:mdna:163]

[0000858877-26-000021:mdna:210]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |
| Interest income |  | $ | 210 |  |  | $ | 238 |  |  | $ | (28) |  |  | $ | 432 |  |  | $ | 524 |  |  | $ | (92) |  |
| Interest expense |  | (370) |  |  | (404) |  |  | 34 |  |  | (720) |  |  | (822) |  |  | 102 |  |
| Interest income (expense), net |  | $ | (160) |  |  | $ | (166) |  |  | $ | 6 |  |  | $ | (288) |  |  | $ | (298) |  |  | $ | 10 |  |

[0000858877-26-000021:mdna:211]
For the second quarter and first six months of fiscal 2026, the decrease in interest income was driven by a lower average balance of cash and available-for-sale debt investments and lower interest rates. The decrease in interest expense was driven by a lower average balance of debt outstanding and lower effective interest rate on commercial paper during the respective periods.

[0000858877-26-000021:mdna:212]
[same as prior period, unchanged from 0000858877-25-000171:mdna:167]

[0000858877-26-000021:mdna:213]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |  | January 24,2026 |  | January 25,2025 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | (4) |  |  | $ | (20) |  |  | $ | 16 |  |  | $ | (8) |  |  | $ | (45) |  |  | $ | 37 |  |
| Marketable equity investments |  | (34) |  |  | 21 |  |  | (55) |  |  | (3) |  |  | 45 |  |  | (48) |  |
| Privately held investments |  | 97 |  |  | (27) |  |  | 124 |  |  | 260 |  |  | 47 |  |  | 213 |  |
| Net gains (losses) on investments |  | 59 |  |  | (26) |  |  | 85 |  |  | 249 |  |  | 47 |  |  | 202 |  |
| Other gains (losses), net |  | (34) |  |  | (34) |  |  | — |  |  | (68) |  |  | (66) |  |  | (2) |  |
| Other income (loss), net |  | $ | 25 |  |  | $ | (60) |  |  | $ | 85 |  |  | $ | 181 |  |  | $ | (19) |  |  | $ | 200 |  |

[0000858877-26-000021:mdna:214]
For each of the second quarter and first six months of fiscal 2026, the change in our other income (loss), net was primarily driven by higher gains on privately held investments.

[0000858877-26-000021:mdna:215]
[same as prior period, unchanged from 0000858877-25-000171:mdna:199]

[0000858877-26-000021:mdna:216]
[same as prior period, unchanged from 0000858877-25-000171:mdna:200]

[0000858877-26-000021:mdna:217]
Provision for Income Taxes

[0000858877-26-000021:mdna:218]
Three Months Ended January 24, 2026 Compared with Three Months Ended January 25, 2025

[0000858877-26-000021:mdna:219]
The provision for income taxes resulted in an effective tax rate of 12.9% for the second quarter of fiscal 2026, compared with an effective tax rate of 15.9% for the second quarter of fiscal 2025. The decrease in the effective tax rate was primarily due to an increase in stock-based compensation windfall benefit.

[0000858877-26-000021:mdna:220]
Six Months Ended January 24, 2026 Compared with Six Months Ended January 25, 2025

[0000858877-26-000021:mdna:221]
The provision for income taxes resulted in an effective tax rate of 14.2% for the first six months of fiscal 2026, compared with an effective tax rate of 0.3% for the first six months of fiscal 2025. The increase in the effective tax rate was primarily due to a $720 million tax benefit related to the U.S. Tax Court opinion issued during the first quarter of fiscal 2025 regarding the U.S. taxation of deemed foreign dividends in the transition year of the Tax Cut and Job Act (our fiscal 2018).

[0000858877-26-000021:mdna:222]
[same as prior period, unchanged from 0000858877-25-000171:mdna:212]

[0000858877-26-000021:mdna:223]
[same as prior period, unchanged from 0000858877-25-000171:mdna:213]

[0000858877-26-000021:mdna:224]
[same as prior period, unchanged from 0000858877-25-000171:mdna:177]

[0000858877-26-000021:mdna:225]
[same as prior period, unchanged from 0000858877-25-000171:mdna:178]

[0000858877-26-000021:mdna:226]
[same as prior period, unchanged from 0000858877-25-000171:mdna:179]

[0000858877-26-000021:mdna:227]
[same as prior period, unchanged from 0000858877-25-000171:mdna:180]

[0000858877-26-000021:mdna:228]
|  | January 24,2026 |  | July 26,2025 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 7,458 |  |  | $ | 8,346 |  |  | $ | (888) |  |
| Available-for-sale debt investments | 7,960 |  |  | 7,381 |  |  | 579 |  |
| Marketable equity securities | 359 |  |  | 383 |  |  | (24) |  |
| Total | $ | 15,777 |  |  | $ | 16,110 |  |  | $ | (333) |  |

[0000858877-26-000021:mdna:229]
The net decrease in cash and cash equivalents and investments in the first six months of fiscal 2026 was primarily driven by cash returned to stockholders in the form of repurchases of common stock of $3.4 billion and cash dividends of $3.2 billion, shares repurchased for tax withholdings on vesting of restricted stock units of $1.1 billion and capital expenditures of $0.6 billion. These uses of cash were partially offset by net cash provided by operating activities of $5.0 billion, $2.0 billion net issuance of commercial paper, and the release to us of approximately $0.6 billion of restricted cash previously held in escrow.

[0000858877-26-000021:mdna:230]
[same as prior period, unchanged from 0000858877-25-000171:mdna:183]

[0000858877-26-000021:mdna:231]
Securities Lending   We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 24, 2026 and July 26, 2025, we had no outstanding securities lending transactions.

[0000858877-26-000021:mdna:232]
[same as prior period, unchanged from 0000858877-25-000171:mdna:185]

[0000858877-26-000021:mdna:233]
[same as prior period, unchanged from 0000858877-25-000171:mdna:186]

[0000858877-26-000021:mdna:234]
|  | Six Months Ended |
|  | January 24,2026 |  | January 25,2025 |
| Net cash provided by operating activities | $ | 5,034 |  |  | $ | 5,902 |  |
| Acquisition of property and equipment | (606) |  |  | (427) |  |
| Free cash flow | $ | 4,428 |  |  | $ | 5,475 |  |

[0000858877-26-000021:mdna:235]
The net cash provided by operating activities in the first six months of fiscal 2026 includes our final U.S. transition tax payment of $2.3 billion.

[0000858877-26-000021:mdna:236]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management,

[0000858877-26-000021:mdna:237]
[same as prior period, unchanged from 0000858877-25-000171:mdna:221]

[0000858877-26-000021:mdna:238]
[same as prior period, unchanged from 0000858877-25-000171:mdna:222]

[0000858877-26-000021:mdna:239]
deferred revenue, and the timing and amount of tax and other payments. For additional discussion, see “Part II, Item 1A. Risk Factors” in this report.

[0000858877-26-000021:mdna:240]
[same as prior period, unchanged from 0000858877-25-000171:mdna:191]

[0000858877-26-000021:mdna:241]
[same as prior period, unchanged from 0000858877-25-000171:mdna:192]

[0000858877-26-000021:mdna:242]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2026 |  |  |  |  |  |  |  |  |  |  |  |  |
| January 24, 2026 |  | $ | 0.41 |  |  | $ | 1,617 |  |  | 18 |  |  | $ | 76.29 |  |  | $ | 1,351 |  |  | $ | 2,968 |  |
| October 25, 2025 |  | $ | 0.41 |  |  | $ | 1,617 |  |  | 29 |  |  | $ | 68.28 |  |  | $ | 2,001 |  |  | $ | 3,618 |  |
| Fiscal 2025 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 26, 2025 |  | $ | 0.41 |  |  | $ | 1,625 |  |  | 19 |  |  | $ | 64.65 |  |  | $ | 1,252 |  |  | $ | 2,877 |  |
| April 26, 2025 |  | $ | 0.41 |  |  | $ | 1,627 |  |  | 25 |  |  | $ | 59.78 |  |  | $ | 1,504 |  |  | $ | 3,131 |  |
| January 25, 2025 |  | $ | 0.40 |  |  | $ | 1,593 |  |  | 21 |  |  | $ | 58.58 |  |  | $ | 1,236 |  |  | $ | 2,829 |  |
| October 26, 2024 |  | $ | 0.40 |  |  | $ | 1,592 |  |  | 40 |  |  | $ | 49.56 |  |  | $ | 2,003 |  |  | $ | 3,595 |  |

[0000858877-26-000021:mdna:243]
On February 11, 2026, our Board of Directors declared a quarterly dividend of $0.42 per common share to be paid on April 22, 2026, to all stockholders of record as of the close of business on April 2, 2026. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-26-000021:mdna:244]
As of January 24, 2026, the remaining authorized amount for stock repurchases under this program is approximately $10.8 billion, with no termination date.

[0000858877-26-000021:mdna:245]
[same as prior period, unchanged from 0000858877-25-000171:mdna:196]

[0000858877-26-000021:mdna:246]
|  | January 24,2026 |  | July 26,2025 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 6,606 |  |  | $ | 6,701 |  |  | $ | (95) |  |

[0000858877-26-000021:mdna:247]
Our accounts receivable net, as of January 24, 2026 decreased by approximately 1%, as compared with the end of fiscal 2025, primarily due to timing and amount of product and service billings in the second quarter of fiscal 2026 compared with the fourth quarter of fiscal 2025.

[0000858877-26-000021:mdna:248]
[same as prior period, unchanged from 0000858877-25-000171:mdna:231]

[0000858877-26-000021:mdna:249]
[same as prior period, unchanged from 0000858877-25-000171:mdna:232]

[0000858877-26-000021:mdna:250]
[same as prior period, unchanged from 0000858877-25-000171:mdna:201]

[0000858877-26-000021:mdna:251]
|  | January 24,2026 |  | July 26,2025 |  | Variance vs. July 26, 2025 |
| Inventories | $ | 3,920 |  |  | $ | 3,164 |  |  | $ | 756 |  |
| Inventory purchase commitments | $ | 10,055 |  |  | $ | 7,599 |  |  | $ | 2,456 |  |
| Inventory deposits and prepayments | $ | 913 |  |  | $ | 825 |  |  | $ | 88 |  |

[0000858877-26-000021:mdna:252]
[same as prior period, unchanged from 0000858877-25-000171:mdna:203]

[0000858877-26-000021:mdna:253]
|  | January 24,2026 |  | July 26,2025 |  | Variance vs. July 26, 2025 |
| Less than 1 year | $ | 9,615 |  |  | $ | 7,202 |  |  | $ | 2,413 |  |
| 1 to 3 years | 417 |  |  | 320 |  |  | 97 |  |
| 3 to 5 years | 23 |  |  | 77 |  |  | (54) |  |
| Total | $ | 10,055 |  |  | $ | 7,599 |  |  | $ | 2,456 |  |

[0000858877-26-000021:mdna:254]
Inventory as of January 24, 2026 increased by 24% and inventory purchase commitments with contract manufacturers and suppliers increased by 32% from our balances at the end of fiscal 2025. The combined increase of 30% in our inventory and inventory purchase commitments as compared with the end of fiscal 2025 was primarily related to commitments with contract manufacturers and suppliers related to manufacturing Cisco Silicon One and other products, and helping to secure memory, to meet the demand from hyperscalers and other customers. We expect our inventory balances may increase in future quarters as we work to fulfill this demand.

[0000858877-26-000021:mdna:255]
In recent periods, we have increased our levels of inventory and purchase commitments with contract manufacturers and suppliers primarily related to Cisco Silicon One. In the second quarter of fiscal 2026, we increased our purchase commitments with suppliers to help secure memory. The increases during the first six months of fiscal 2026 were primarily due to arrangements to secure supply and pricing for certain product components, including memory, and commitments with contract manufacturers to meet customer demand and help manage lead times. Our risks of future material excess and obsolete inventory and related losses are further outlined in the Result of Operations—Product Gross Margin section.

[0000858877-26-000021:mdna:256]
[same as prior period, unchanged from 0000858877-25-000171:mdna:207]

[0000858877-26-000021:mdna:257]
[same as prior period, unchanged from 0000858877-25-000171:mdna:208]

[0000858877-26-000021:mdna:258]
[same as prior period, unchanged from 0000858877-25-000171:mdna:209]

[0000858877-26-000021:mdna:259]
[same as prior period, unchanged from 0000858877-25-000171:mdna:210]

[0000858877-26-000021:mdna:260]
|  | January 24,2026 |  | July 26,2025 |  | Increase (Decrease) |
| Loan receivables, net | $ | 5,791 |  |  | $ | 5,591 |  |  | $ | 200 |  |
| Lease receivables, net | 851 |  |  | 936 |  |  | (85) |  |
| Total, net | $ | 6,642 |  |  | $ | 6,527 |  |  | $ | 115 |  |

[0000858877-26-000021:mdna:261]
CISCO SYSTEMS, INC.

[0000858877-26-000021:mdna:262]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000021:mdna:263]
Financing Receivables  Our financing arrangements include loans and leases. Our loan receivables include customer financing for purchases of our hardware, software and services (including technical support and advanced services), and also may include additional funds for other costs associated with network installation and integration of our products and services. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Financing receivables increased by 2% as compared with the end of fiscal 2025.

[0000858877-26-000021:mdna:264]
[same as prior period, unchanged from 0000858877-25-000171:mdna:215]

[0000858877-26-000021:mdna:265]
The volume of channel partner financing was $14.0 billion and $12.2 billion for the first six months of fiscal 2026 and 2025, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.3 billion as of each of January 24, 2026 and July 26, 2025. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of January 24, 2026, the total maximum potential future payments related to these guarantees was approximately $126 million, of which approximately $13 million was recorded as deferred revenue.

[0000858877-26-000021:mdna:266]
[same as prior period, unchanged from 0000858877-25-000171:mdna:217]

[0000858877-26-000021:mdna:267]
Senior Fixed-Rate Notes  The following table summarizes the principal amount of our senior fixed-rate notes (in millions):

[0000858877-26-000021:mdna:268]
|  | Maturity Date |  | January 24,2026 |  | July 26,2025 |
| Senior fixed-rate notes: |  |  |  |  |  |
| 4.90% | February 26, 2026 |  | $ | 1,000 |  |  | $ | 1,000 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 2,000 |  |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | 1,000 |  |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 2,500 |  |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | 1,000 |  |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 2,500 |  |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | 1,000 |  |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 2,500 |  |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | 1,250 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | February 24, 2055 |  | 750 |  |  | 750 |  |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 1,000 |  |
| Total |  |  | $ | 24,750 |  |  | $ | 24,750 |  |

[0000858877-26-000021:mdna:269]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of January 24, 2026.

[0000858877-26-000021:mdna:270]
CISCO SYSTEMS, INC.

[0000858877-26-000021:mdna:271]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000021:mdna:272]
Commercial Paper  We have a short-term debt financing program in which up to $15.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had $5.5 billion and $3.5 billion in commercial paper notes outstanding as of January 24, 2026 and July 26, 2025, respectively.

[0000858877-26-000021:mdna:273]
Credit Facility  On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of January 24, 2026, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.

[0000858877-26-000021:mdna:274]
[same as prior period, unchanged from 0000858877-25-000171:mdna:225]

[0000858877-26-000021:mdna:275]
|  | January 24,2026 |  | July 26,2025 |  | Increase (Decrease) |
| Product | $ | 21,977 |  |  | $ | 21,572 |  |  | $ | 405 |  |
| Services | 21,429 |  |  | 21,961 |  |  | (532) |  |
| Total | $ | 43,406 |  |  | $ | 43,533 |  |  | $ | (127) |  |
| Short-term RPO | $ | 21,370 |  |  | $ | 21,723 |  |  | $ | (353) |  |
| Long-term RPO | 22,036 |  |  | 21,810 |  |  | 226 |  |
| Total | $ | 43,406 |  |  | $ | 43,533 |  |  | $ | (127) |  |

[0000858877-26-000021:mdna:276]
Total remaining performance obligations as of January 24, 2026 were flat compared to the end of fiscal 2025. Remaining performance obligations for product increased by 2% compared to the end of fiscal 2025, of which long-term product RPO was $11.8 billion, up 3%. Remaining performance obligations for services decreased 2%.

[0000858877-26-000021:mdna:277]
[same as prior period, unchanged from 0000858877-25-000171:mdna:228]

[0000858877-26-000021:mdna:278]
|  | January 24,2026 |  | July 26,2025 |  | Increase (Decrease) |
| Product | $ | 13,371 |  |  | $ | 13,490 |  |  | $ | (119) |  |
| Services | 15,032 |  |  | 15,289 |  |  | (257) |  |
| Total | $ | 28,403 |  |  | $ | 28,779 |  |  | $ | (376) |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 16,199 |  |  | $ | 16,416 |  |  | $ | (217) |  |
| Noncurrent | 12,204 |  |  | 12,363 |  |  | (159) |  |
| Total | $ | 28,403 |  |  | $ | 28,779 |  |  | $ | (376) |  |

[0000858877-26-000021:mdna:279]
Total deferred revenue decreased 1% compared to the end of fiscal 2025. The decrease in deferred product revenue of 1% was primarily due to lower business volume. The decrease in deferred services revenue of 2% was driven by lower business volume and ongoing amortization of deferred services revenue.

[0000858877-26-000021:mdna:280]
[same as prior period, unchanged from 0000858877-25-000171:mdna:233]

[0000858877-26-000021:mdna:281]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed herein. In addition, we plan for and measure our liquidity and capital resources through an annual budgeting process. Our contractual obligations consist of operating leases, purchase commitments with contract manufacturers and suppliers, other purchase obligations, long-term debt, and other long-term liabilities. For additional information on our contractual obligations see our Annual Report on Form 10-K for the fiscal year ended July 26, 2025.

[0000858877-26-000021:mdna:282]
CISCO SYSTEMS, INC.

[0000858877-26-000021:mdna:283]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000021:mdna:284]
[same as prior period, unchanged from 0000858877-25-000171:mdna:237]

[0000858877-26-000021:mdna:285]
[same as prior period, unchanged from 0000858877-25-000171:mdna:238]

[0000858877-26-000021:mdna:286]
Of the total carrying value of our investments in privately held companies as of January 24, 2026, $0.8 billion of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $0.7 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments. See Note 10 to the Consolidated Financial Statements.

[0000858877-26-000021:mdna:287]
[same as prior period, unchanged from 0000858877-25-000171:mdna:240]

[0000858877-26-000021:mdna:288]
[same as prior period, unchanged from 0000858877-25-000171:mdna:241]

[0000858877-26-000021:mdna:289]
[same as prior period, unchanged from 0000858877-25-000171:mdna:242]

[0000858877-26-000021:mdna:290]
56
