# CSCO notes — 0000858877-26-000021


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-26-000021:notes:1]
[same as prior period, unchanged from 0000858877-25-000171:notes:1]

[0000858877-26-000021:notes:2]
We have prepared the accompanying financial data as of January 24, 2026 and for the second quarter and first six months of fiscal 2026 and 2025, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 26, 2025 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 26, 2025.

[0000858877-26-000021:notes:3]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of January 24, 2026, the results of operations, the statements of comprehensive income and the statements of equity for the second quarter and first six months of fiscal 2026 and 2025, and the statements of cash flows for the first six months of fiscal 2026 and 2025, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2026 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-26-000021:notes:4]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-26-000021:notes:5]
[same as prior period, unchanged from 0000858877-25-000171:notes:4]

[0000858877-26-000021:notes:6]
[same as prior period, unchanged from 0000858877-25-000171:notes:5]

[0000858877-26-000021:notes:7]
[same as prior period, unchanged from 0000858877-25-000171:notes:6]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-26-000021:notes:8]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses

[0000858877-26-000021:notes:9]
represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers. Revenue from subscription offers includes revenue recognized over time as well as upfront.

[0000858877-26-000021:notes:10]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes. An allowance for future sales returns is established based on historical trends in product return rates and the related provision is recorded as a reduction to revenue.

[0000858877-26-000021:notes:11]
Significant Judgments

[0000858877-26-000021:notes:12]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-26-000021:notes:13]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and direct sale customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.

[0000858877-26-000021:notes:14]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license’s utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

[0000858877-26-000021:notes:15]
[same as prior period, unchanged from 0000858877-25-000171:notes:16]

[0000858877-26-000021:notes:16]
[same as prior period, unchanged from 0000858877-25-000171:notes:17]

[0000858877-26-000021:notes:17]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2026 |  | January 25, 2025 |  | January 24, 2026 |  | January 25, 2025 |
| Product revenue: |  |  |  |  |  |  |  |
| Networking | $ | 8,294 |  |  | $ | 6,850 |  |  | $ | 16,061 |  |  | $ | 13,603 |  |
| Security | 2,018 |  |  | 2,111 |  |  | 3,998 |  |  | 4,129 |  |
| Collaboration | 1,054 |  |  | 996 |  |  | 2,109 |  |  | 2,081 |  |
| Observability | 277 |  |  | 277 |  |  | 550 |  |  | 535 |  |
| Total Product | 11,642 |  |  | 10,234 |  |  | 22,719 |  |  | 20,348 |  |
| Services | 3,707 |  |  | 3,757 |  |  | 7,513 |  |  | 7,484 |  |
| Total revenue | $ | 15,349 |  |  | $ | 13,991 |  |  | $ | 30,232 |  |  | $ | 27,832 |  |

[0000858877-26-000021:notes:18]
[same as prior period, unchanged from 0000858877-25-000171:notes:19]

[0000858877-26-000021:notes:19]
[same as prior period, unchanged from 0000858877-25-000171:notes:20]

[0000858877-26-000021:notes:20]
[same as prior period, unchanged from 0000858877-25-000171:notes:21]

[0000858877-26-000021:notes:21]
[same as prior period, unchanged from 0000858877-25-000171:notes:22]

[0000858877-26-000021:notes:22]
[same as prior period, unchanged from 0000858877-25-000171:notes:23]

[0000858877-26-000021:notes:23]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and advanced services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Advanced services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

[0000858877-26-000021:notes:24]
[same as prior period, unchanged from 0000858877-25-000171:notes:24]

[0000858877-26-000021:notes:25]
[same as prior period, unchanged from 0000858877-25-000171:notes:25]

[0000858877-26-000021:notes:26]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2026 |  | January 25, 2025 |  | January 24, 2026 |  | January 25, 2025 |
| Product | $ | 4,474 |  |  | $ | 4,432 |  |  | $ | 8,974 |  |  | $ | 8,851 |  |
| Services | 3,362 |  |  | 3,430 |  |  | 6,862 |  |  | 6,855 |  |
| Total | $ | 7,836 |  |  | $ | 7,862 |  |  | $ | 15,836 |  |  | $ | 15,706 |  |

[0000858877-26-000021:notes:27]
[same as prior period, unchanged from 0000858877-25-000171:notes:27]

[0000858877-26-000021:notes:28]
[same as prior period, unchanged from 0000858877-25-000171:notes:28]

[0000858877-26-000021:notes:29]
[same as prior period, unchanged from 0000858877-25-000171:notes:29]

[0000858877-26-000021:notes:30]
Accounts receivable, net was $6.6 billion as of January 24, 2026 compared to $6.7 billion as of July 26, 2025, as reported on the Consolidated Balance Sheets.

[0000858877-26-000021:notes:31]
[same as prior period, unchanged from 0000858877-25-000171:notes:31]

[0000858877-26-000021:notes:32]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2026 |  | January 25, 2025 |  | January 24, 2026 |  | January 25, 2025 |
| Allowance for credit loss at beginning of period | $ | 62 |  |  | $ | 78 |  |  | $ | 69 |  |  | $ | 87 |  |
| Provisions | 18 |  |  | 12 |  |  | 14 |  |  | 12 |  |
| Write-offs, net of recoveries | (4) |  |  | (10) |  |  | (7) |  |  | (19) |  |
| Allowance for credit loss at end of period | $ | 76 |  |  | $ | 80 |  |  | $ | 76 |  |  | $ | 80 |  |

[0000858877-26-000021:notes:33]
[same as prior period, unchanged from 0000858877-25-000171:notes:33]

[0000858877-26-000021:notes:34]
[same as prior period, unchanged from 0000858877-25-000171:notes:34]

[0000858877-26-000021:notes:35]
|  | January 24, 2026 |  | July 26, 2025 |
| 1 to 4 | $ | 1,326 |  |  | $ | 1,358 |  |
| 5 to 6 | 2,004 |  |  | 1,868 |  |
| 7 and Higher | 84 |  |  | 73 |  |
| Total | $ | 3,414 |  |  | $ | 3,299 |  |

[0000858877-26-000021:notes:36]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, were $3.4 billion as of January 24, 2026 and $3.2 billion as of July 26, 2025, of which $1.8 billion and $1.7 billion, respectively, were included in other current assets, with remaining balances included in other assets.

[0000858877-26-000021:notes:37]
Contract liabilities consist of deferred revenue. Deferred revenue was $28.4 billion as of January 24, 2026 compared to $28.8 billion as of July 26, 2025. We recognized approximately $4.5 billion and $9.9 billion of revenue during the second quarter and first six months of fiscal 2026 that was included in the deferred revenue balance at July 26, 2025.

[0000858877-26-000021:notes:38]
[same as prior period, unchanged from 0000858877-25-000171:notes:38]

[0000858877-26-000021:notes:39]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to 
the period of benefit. Capitalized contract acquisition costs were $1.5 billion as of each of January 24, 2026 and July 26, 2025, and were included in other current assets and other assets. The amortization expense associated with these costs was $249 million and $483 million for the second quarter and first six months of fiscal 2026, respectively, and $238 million and $446 million for the corresponding periods of fiscal 2025, respectively, and was included in sales and marketing expenses.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-26-000021:notes:40]
[same as prior period, unchanged from 0000858877-25-000171:notes:15]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-26-000021:notes:41]
[same as prior period, unchanged from 0000858877-25-000171:notes:40]

[0000858877-26-000021:notes:42]
[same as prior period, unchanged from 0000858877-25-000171:notes:41]

[0000858877-26-000021:notes:43]
[same as prior period, unchanged from 0000858877-25-000171:notes:42]

[0000858877-26-000021:notes:44]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24,2026 |  | January 25,2025 |  | January 24,2026 |  | January 25,2025 |
| Revenue: |  |  |  |  |  |
| Networking | $ | 8,294 |  |  | $ | 6,850 |  |  | $ | 16,061 |  |  | $ | 13,603 |  |
| Security | 2,018 |  |  | 2,111 |  |  | 3,998 |  |  | 4,129 |  |
| Collaboration | 1,054 |  |  | 996 |  |  | 2,109 |  |  | 2,081 |  |
| Observability | 277 |  |  | 277 |  |  | 550 |  |  | 535 |  |
| Total Product | 11,642 |  |  | 10,234 |  |  | 22,719 |  |  | 20,348 |  |
| Services | 3,707 |  |  | 3,757 |  |  | 7,513 |  |  | 7,484 |  |
| Total | $ | 15,349 |  |  | $ | 13,991 |  |  | $ | 30,232 |  |  | $ | 27,832 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-26-000021:notes:45]
Acquisitions
Allocation of the total purchase consideration for acquisitions we completed during the first six months of fiscal 2026 is summarized as follows (in millions):

[0000858877-26-000021:notes:46]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions | $ | 49 |  |  | $ | — |  |  | $ | 14 |  |  | $ | 35 |  |

[0000858877-26-000021:notes:47]
The total purchase consideration related to acquisitions consisted primarily of cash consideration. Total transaction costs related to acquisition activities were $9 million and $11 million for the first six months of fiscal 2026 and 2025, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-26-000021:notes:48]
[same as prior period, unchanged from 0000858877-25-000171:notes:47]

[0000858877-26-000021:notes:49]
The goodwill generated from the acquisitions completed during the first six months of fiscal 2026 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-26-000021:notes:50]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first six months of fiscal 2026 have not been presented because the effects of the acquisitions were not material to our financial results.

[0000858877-26-000021:notes:51]
[same as prior period, unchanged from 0000858877-25-000171:notes:50]

[0000858877-26-000021:notes:52]
[same as prior period, unchanged from 0000858877-25-000171:notes:51]

[0000858877-26-000021:notes:53]
[same as prior period, unchanged from 0000858877-25-000171:notes:52]

[0000858877-26-000021:notes:54]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2026 |  | January 25, 2025 |  | January 24, 2026 |  | January 25, 2025 |
| Compensation expense related to acquisitions | $ | 98 |  |  | $ | 222 |  |  | $ | 208 |  |  | $ | 519 |  |

[0000858877-26-000021:notes:55]
As of January 24, 2026, we estimated that future cash compensation expense of up to $400 million may be required to be recognized pursuant to applicable acquisition agreements.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-26-000021:notes:56]
[same as prior period, unchanged from 0000858877-25-000171:notes:55]

[0000858877-26-000021:notes:57]
The following table presents the goodwill allocated to our reportable segments as of January 24, 2026 and changes to goodwill during the first six months of fiscal 2026 (in millions):

[0000858877-26-000021:notes:58]
|  | Balance at July 26, 2025 |  | Acquisitions |  | Foreign Currency Translation and Other |  | Balance at January 24, 2026 |
| Americas | $ | 36,468 |  |  | $ | 21 |  |  | $ | 39 |  |  | $ | 36,528 |  |
| EMEA | 14,397 |  |  | 9 |  |  | 15 |  |  | 14,421 |  |
| APJC | 8,271 |  |  | 5 |  |  | 9 |  |  | 8,285 |  |
| Total | $ | 59,136 |  |  | $ | 35 |  |  | $ | 63 |  |  | $ | 59,234 |  |

[0000858877-26-000021:notes:59]
[same as prior period, unchanged from 0000858877-25-000171:notes:58]

[0000858877-26-000021:notes:60]
The following table presents details of our intangible assets acquired through acquisitions completed during the first six months of fiscal 2026 (in millions, except years):

[0000858877-26-000021:notes:61]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | CUSTOMER RELATED |  | TECHNOLOGY |  | TRADE NAME |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total | — |  |  | $ | — |  |  | 2.5 |  | $ | 14 |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 14 |  |

[0000858877-26-000021:notes:62]
[same as prior period, unchanged from 0000858877-25-000171:notes:61]

[0000858877-26-000021:notes:63]
| January 24, 2026 |  | Gross |  | Accumulated Amortization |  | Net |
| Customer related |  | $ | 6,340 |  |  | $ | (1,707) |  |  | $ | 4,633 |  |
| Technology |  | 5,213 |  |  | (1,970) |  |  | 3,243 |  |
| Trade name |  | 526 |  |  | (95) |  |  | 431 |  |
| Total |  | $ | 12,079 |  |  | $ | (3,772) |  |  | $ | 8,307 |  |

[0000858877-26-000021:notes:64]
[same as prior period, unchanged from 0000858877-25-000171:notes:63]

[0000858877-26-000021:notes:65]
[same as prior period, unchanged from 0000858877-25-000171:notes:64]

[0000858877-26-000021:notes:66]
Impairment charges related to purchased intangible assets were $19 million for the second quarter and first six months of fiscal 2025. Impairment charges were as a result of declines in estimated fair value resulting from the reductions in or the elimination of expected future cash flows associated with certain technology intangible assets.

[0000858877-26-000021:notes:67]
[same as prior period, unchanged from 0000858877-25-000171:notes:65]

[0000858877-26-000021:notes:68]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2026 |  | January 25, 2025 |  | January 24, 2026 |  | January 25, 2025 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 235 |  |  | $ | 340 |  |  | $ | 475 |  |  | $ | 665 |  |
| Operating expenses | 231 |  |  | 265 |  |  | 462 |  |  | 530 |  |
| Total | $ | 466 |  |  | $ | 605 |  |  | $ | 937 |  |  | $ | 1,195 |  |

[0000858877-26-000021:notes:69]
The estimated future amortization expense of purchased intangible assets with finite lives as of January 24, 2026 is as follows (in millions):

[0000858877-26-000021:notes:70]
| Fiscal Year | Amount |
| 2026 (remaining six months) | $ | 904 |  |
| 2027 | 1,495 |  |
| 2028 | 1,415 |  |
| 2029 | 1,287 |  |
| 2030 | 1,003 |  |
| Thereafter | 2,203 |  |
| Total | $ | 8,307 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-26-000021:notes:71]
Restructuring and Other Charges
In the first quarter of fiscal 2025, we announced a restructuring plan (the “Fiscal 2025 Plan”), in order to allow us to invest in key growth opportunities and drive more efficiencies in our business. In connection with the Fiscal 2025 Plan, we incurred charges of $36 million and $183 million in the second quarter and first six months of fiscal 2026. These aggregate pre-tax charges were primarily cash-based and consisted of severance and other one-time termination benefits, and other costs. In connection with the Fiscal 2025 Plan, we incurred cumulative charges of $927 million and completed the plan in the second quarter of fiscal 2026.

[0000858877-26-000021:notes:72]
[same as prior period, unchanged from 0000858877-25-000171:notes:70]

[0000858877-26-000021:notes:73]
|  |  | FISCAL 2025 PLAN |  |  |
|  |  | Employee Severance |  | Other |  | Total |
| Liability as of July 26, 2025 |  | $ | 66 |  |  | $ | 46 |  |  | $ | 112 |  |
| Charges |  | 142 |  |  | 41 |  |  | 183 |  |
| Cash payments |  | (143) |  |  | (25) |  |  | (168) |  |
| Non-cash and other |  | (1) |  |  | (38) |  |  | (39) |  |
| Liability as of January 24, 2026 |  | $ | 64 |  |  | $ | 24 |  |  | $ | 88 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-26-000021:notes:74]
[same as prior period, unchanged from 0000858877-25-000171:notes:72]

[0000858877-26-000021:notes:75]
[same as prior period, unchanged from 0000858877-25-000171:notes:73]

[0000858877-26-000021:notes:76]
|  |  | January 24, 2026 |  | July 26, 2025 |
| Cash and cash equivalents |  | $ | 7,458 |  |  | $ | 8,346 |  |
| Restricted cash and restricted cash equivalents included in other current assets |  | 1 |  |  | 564 |  |
| Total |  | $ | 7,459 |  |  | $ | 8,910 |  |

[0000858877-26-000021:notes:77]
[same as prior period, unchanged from 0000858877-25-000171:notes:75]

[0000858877-26-000021:notes:78]
[same as prior period, unchanged from 0000858877-25-000171:notes:76]

[0000858877-26-000021:notes:79]
|  |  | January 24, 2026 |  | July 26, 2025 |
| Raw materials |  | $ | 2,016 |  |  | $ | 1,744 |  |
| Work in process |  | 684 |  |  | 261 |  |
| Finished goods |  | 987 |  |  | 933 |  |
| Service-related spares |  | 227 |  |  | 220 |  |
| Demonstration systems |  | 6 |  |  | 6 |  |
| Total |  | $ | 3,920 |  |  | $ | 3,164 |  |

[0000858877-26-000021:notes:80]
[same as prior period, unchanged from 0000858877-25-000171:notes:78]

[0000858877-26-000021:notes:81]
|  |  | January 24, 2026 |  | July 26, 2025 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,060 |  |  | $ | 4,045 |  |
| Production, engineering, computer and other equipment and related software |  | 5,293 |  |  | 5,178 |  |
| Operating lease assets |  | 51 |  |  | 51 |  |
| Furniture, fixtures and other |  | 301 |  |  | 316 |  |
| Total gross property and equipment |  | 9,705 |  |  | 9,590 |  |
| Less: accumulated depreciation and amortization |  | (7,354) |  |  | (7,477) |  |
| Total |  | $ | 2,351 |  |  | $ | 2,113 |  |

[0000858877-26-000021:notes:82]
[same as prior period, unchanged from 0000858877-25-000171:notes:80]

[0000858877-26-000021:notes:83]
|  |  | January 24, 2026 |  | July 26, 2025 |
| Product |  | $ | 21,977 |  |  | $ | 21,572 |  |
| Services |  | 21,429 |  |  | 21,961 |  |
| Total |  | $ | 43,406 |  |  | $ | 43,533 |  |
| Short-term RPO |  | $ | 21,370 |  |  | $ | 21,723 |  |
| Long-term RPO |  | 22,036 |  |  | 21,810 |  |
| Total |  | $ | 43,406 |  |  | $ | 43,533 |  |
| Amount to be recognized as revenue over the next 12 months |  | 49 | % |  | 50 | % |
| Deferred revenue |  | $ | 28,403 |  |  | $ | 28,779 |  |
| Unbilled contract revenue |  | 15,003 |  |  | 14,754 |  |
| Total |  | $ | 43,406 |  |  | $ | 43,533 |  |

[0000858877-26-000021:notes:84]
[same as prior period, unchanged from 0000858877-25-000171:notes:82]

[0000858877-26-000021:notes:85]
[same as prior period, unchanged from 0000858877-25-000171:notes:83]

[0000858877-26-000021:notes:86]
|  |  | January 24, 2026 |  | July 26, 2025 |
| Product |  | $ | 13,371 |  |  | $ | 13,490 |  |
| Services |  | 15,032 |  |  | 15,289 |  |
| Total |  | $ | 28,403 |  |  | $ | 28,779 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 16,199 |  |  | $ | 16,416 |  |
| Noncurrent |  | 12,204 |  |  | 12,363 |  |
| Total |  | $ | 28,403 |  |  | $ | 28,779 |  |


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000858877-26-000021:notes:87]
Leases 
(a)Lessee Arrangements

[0000858877-26-000021:notes:88]
The following table presents our operating lease balances (in millions):

[0000858877-26-000021:notes:89]
|  | Balance Sheet Line Item |  | January 24, 2026 |  | July 26, 2025 |
| Operating lease right-of-use assets | Other assets |  | $ | 1,408 |  |  | $ | 1,301 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 405 |  |  | $ | 375 |  |
| Operating lease liabilities | Other long-term liabilities |  | 1,249 |  |  | 1,175 |  |
| Total operating lease liabilities |  |  | $ | 1,654 |  |  | $ | 1,550 |  |

[0000858877-26-000021:notes:90]
The components of our lease expenses were as follows (in millions):

[0000858877-26-000021:notes:91]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2026 |  | January 25, 2025 |  | January 24, 2026 |  | January 25, 2025 |
| Operating lease expense | $ | 132 |  |  | $ | 149 |  |  | $ | 263 |  |  | $ | 263 |  |
| Short-term lease expense | 26 |  |  | 16 |  |  | 51 |  |  | 34 |  |
| Variable lease expense | 77 |  |  | 47 |  |  | 149 |  |  | 93 |  |
| Total lease expense | $ | 235 |  |  | $ | 212 |  |  | $ | 463 |  |  | $ | 390 |  |

[0000858877-26-000021:notes:92]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-26-000021:notes:93]
|  | Six Months Ended |
|  | January 24, 2026 |  | January 25, 2025 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 259 |  |  | $ | 228 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 351 |  |  | $ | 326 |  |

[0000858877-26-000021:notes:94]
The weighted-average lease term was 5.8 years and 5.7 years as of January 24, 2026 and July 26, 2025, respectively. The weighted-average discount rate was 4.0% and 4.1% as of January 24, 2026 and July 26, 2025, respectively.

[0000858877-26-000021:notes:95]
The maturities of our operating leases (undiscounted) as of January 24, 2026 are as follows (in millions):

[0000858877-26-000021:notes:96]
| Fiscal Year | Amount |
| 2026 (remaining six months) | $ | 256 |  |
| 2027 | 385 |  |
| 2028 | 286 |  |
| 2029 | 228 |  |
| 2030 | 198 |  |
| Thereafter | 536 |  |
| Total lease payments | 1,889 |  |
| Less: interest | (235) |  |
| Total | $ | 1,654 |  |

[0000858877-26-000021:notes:97]
(b)Lessor Arrangements

[0000858877-26-000021:notes:98]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income was $15 million and $31 million for the second quarter and first six months of fiscal 2026, respectively, and $16 million and $33 million for the corresponding periods of fiscal 2025, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-26-000021:notes:99]
Future minimum lease payments on our lease receivables as of January 24, 2026 are summarized as follows (in millions):

[0000858877-26-000021:notes:100]
| Fiscal Year | Amount |
| 2026 (remaining six months) | $ | 157 |  |
| 2027 | 310 |  |
| 2028 | 125 |  |
| 2029 | 151 |  |
| 2030 | 144 |  |
| Total | 887 |  |
| Less: Present value of lease payments | (795) |  |
| Unearned income | $ | 92 |  |

[0000858877-26-000021:notes:101]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.


## us-gaap:FinancingReceivablesTextBlock

[0000858877-26-000021:notes:102]
[same as prior period, unchanged from 0000858877-25-000171:notes:104]

[0000858877-26-000021:notes:103]
[same as prior period, unchanged from 0000858877-25-000171:notes:105]

[0000858877-26-000021:notes:104]
[same as prior period, unchanged from 0000858877-25-000171:notes:106]

[0000858877-26-000021:notes:105]
| January 24, 2026 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,825 |  |  | $ | 887 |  |  | $ | 6,712 |  |
| Residual value | — |  |  | 67 |  |  | 67 |  |
| Unearned income | — |  |  | (92) |  |  | (92) |  |
| Allowance for credit loss | (34) |  |  | (11) |  |  | (45) |  |
| Total, net | $ | 5,791 |  |  | $ | 851 |  |  | $ | 6,642 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 2,634 |  |  | $ | 310 |  |  | $ | 2,944 |  |
| Noncurrent | 3,157 |  |  | 541 |  |  | 3,698 |  |
| Total, net | $ | 5,791 |  |  | $ | 851 |  |  | $ | 6,642 |  |

[0000858877-26-000021:notes:106]
[same as prior period, unchanged from 0000858877-25-000171:notes:108]

[0000858877-26-000021:notes:107]
[same as prior period, unchanged from 0000858877-25-000171:notes:109]

[0000858877-26-000021:notes:108]
[same as prior period, unchanged from 0000858877-25-000171:notes:110]

[0000858877-26-000021:notes:109]
| January 24, 2026 |  |  | Fiscal Year |  | Six Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 30, 2022 |  | July 29, 2023 |  | July 27, 2024 |  | July 26, 2025 |  | January 24, 2026 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 45 |  |  | $ | 112 |  |  | $ | 273 |  |  | $ | 937 |  |  | $ | 1,391 |  |  | $ | 1,116 |  |  | $ | 3,874 |  |
| 5 to 6 | 22 |  |  | 20 |  |  | 89 |  |  | 283 |  |  | 862 |  |  | 647 |  |  | 1,923 |  |
| 7 and Higher | — |  |  | 2 |  |  | 2 |  |  | 4 |  |  | 18 |  |  | 2 |  |  | 28 |  |
| Total Loan Receivables | $ | 67 |  |  | $ | 134 |  |  | $ | 364 |  |  | $ | 1,224 |  |  | $ | 2,271 |  |  | $ | 1,765 |  |  | $ | 5,825 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 13 |  |  | $ | 81 |  |  | $ | 150 |  |  | $ | 176 |  |  | $ | 67 |  |  | $ | 489 |  |
| 5 to 6 | 2 |  |  | 13 |  |  | 51 |  |  | 89 |  |  | 80 |  |  | 61 |  |  | 296 |  |
| 7 and Higher | — |  |  | 1 |  |  | 2 |  |  | 6 |  |  | 1 |  |  | — |  |  | 10 |  |
| Total Lease Receivables | $ | 4 |  |  | $ | 27 |  |  | $ | 134 |  |  | $ | 245 |  |  | $ | 257 |  |  | $ | 128 |  |  | $ | 795 |  |
| Total | $ | 71 |  |  | $ | 161 |  |  | $ | 498 |  |  | $ | 1,469 |  |  | $ | 2,528 |  |  | $ | 1,893 |  |  | $ | 6,620 |  |

[0000858877-26-000021:notes:110]
[same as prior period, unchanged from 0000858877-25-000171:notes:112]

[0000858877-26-000021:notes:111]
The following tables present the aging analysis of gross receivables as of January 24, 2026 and July 26, 2025 (in millions):

[0000858877-26-000021:notes:112]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| January 24, 2026 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 31 |  |  | $ | 18 |  |  | $ | 53 |  |  | $ | 102 |  |  | $ | 5,723 |  |  | $ | 5,825 |  |  | $ | 4 |  |  | $ | 1 |  |  | $ | 1 |  |
| Lease receivables | 13 |  |  | 8 |  |  | 6 |  |  | 27 |  |  | 768 |  |  | 795 |  |  | 5 |  |  | 1 |  |  | 1 |  |
| Total | $ | 44 |  |  | $ | 26 |  |  | $ | 59 |  |  | $ | 129 |  |  | $ | 6,491 |  |  | $ | 6,620 |  |  | $ | 9 |  |  | $ | 2 |  |  | $ | 2 |  |

[0000858877-26-000021:notes:113]
[same as prior period, unchanged from 0000858877-25-000171:notes:115]

[0000858877-26-000021:notes:114]
[same as prior period, unchanged from 0000858877-25-000171:notes:116]

[0000858877-26-000021:notes:115]
[same as prior period, unchanged from 0000858877-25-000171:notes:117]

[0000858877-26-000021:notes:116]
[same as prior period, unchanged from 0000858877-25-000171:notes:118]

[0000858877-26-000021:notes:117]
| Three Months Ended January 24, 2026 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of October 25, 2025 | $ | 37 |  |  | $ | 14 |  |  | $ | 51 |  |
| Provisions (benefits) | (3) |  |  | (3) |  |  | (6) |  |
| Allowance for credit loss as of January 24, 2026 | $ | 34 |  |  | $ | 11 |  |  | $ | 45 |  |

[0000858877-26-000021:notes:118]
| Three Months Ended January 25, 2025 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of October 26, 2024 | $ | 49 |  |  | $ | 15 |  |  | $ | 64 |  |
| Provisions (benefits) | (2) |  |  | (2) |  |  | (4) |  |
| Recoveries (write-offs), net | (3) |  |  | — |  |  | (3) |  |
| Foreign exchange and other | 1 |  |  | 1 |  |  | 2 |  |
| Allowance for credit loss as of January 25, 2025 | $ | 45 |  |  | $ | 14 |  |  | $ | 59 |  |

[0000858877-26-000021:notes:119]
| Six Months Ended January 24, 2026 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 26, 2025 | $ | 37 |  |  | $ | 13 |  |  | $ | 50 |  |
| Provisions (benefits) | (3) |  |  | (2) |  |  | (5) |  |
| Allowance for credit loss as of January 24, 2026 | $ | 34 |  |  | $ | 11 |  |  | $ | 45 |  |

[0000858877-26-000021:notes:120]
| Six Months Ended January 25, 2025 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 27, 2024 | $ | 50 |  |  | $ | 15 |  |  | $ | 65 |  |
| Provisions (benefits) | (3) |  |  | (2) |  |  | (5) |  |
| Recoveries (write-offs), net | (3) |  |  | — |  |  | (3) |  |
| Foreign exchange and other | 1 |  |  | 1 |  |  | 2 |  |
| Allowance for credit loss as of January 25, 2025 | $ | 45 |  |  | $ | 14 |  |  | $ | 59 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-26-000021:notes:121]
Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-26-000021:notes:122]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-26-000021:notes:123]
| January 24, 2026 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,756 |  |  | $ | 4 |  |  | $ | (4) |  |  | $ | 1,756 |  |
| U.S. government agency securities | 49 |  |  | — |  |  | — |  |  | 49 |  |
| Non-U.S. government and agency securities | 442 |  |  | 1 |  |  | — |  |  | 443 |  |
| Corporate debt securities | 3,106 |  |  | 10 |  |  | (37) |  |  | 3,079 |  |
| Mortgage- and asset-backed securities | 247 |  |  | — |  |  | (11) |  |  | 236 |  |
| Commercial paper | 1,337 |  |  | — |  |  | — |  |  | 1,337 |  |
| Certificates of deposit | 1,060 |  |  | — |  |  | — |  |  | 1,060 |  |
| Total | $ | 7,997 |  |  | $ | 15 |  |  | $ | (52) |  |  | $ | 7,960 |  |

[0000858877-26-000021:notes:124]
| July 26, 2025 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,971 |  |  | $ | 2 |  |  | $ | (12) |  |  | $ | 1,961 |  |
| U.S. government agency securities | 67 |  |  | — |  |  | — |  |  | 67 |  |
| Non-U.S. government and agency securities | 458 |  |  | — |  |  | — |  |  | 458 |  |
| Corporate debt securities | 3,138 |  |  | 13 |  |  | (61) |  |  | 3,090 |  |
| Mortgage- and asset-backed securities | 320 |  |  | — |  |  | (34) |  |  | 286 |  |
| Commercial paper | 950 |  |  | — |  |  | — |  |  | 950 |  |
| Certificates of deposit | 569 |  |  | — |  |  | — |  |  | 569 |  |
| Total | $ | 7,473 |  |  | $ | 15 |  |  | $ | (107) |  |  | $ | 7,381 |  |

[0000858877-26-000021:notes:125]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-26-000021:notes:126]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2026 |  | January 25, 2025 |  | January 24, 2026 |  | January 25, 2025 |
| Gross realized gains | $ | 1 |  |  | $ | — |  |  | $ | 11 |  |  | $ | 8 |  |
| Gross realized losses | (5) |  |  | (20) |  |  | (19) |  |  | (53) |  |
| Total | $ | (4) |  |  | $ | (20) |  |  | $ | (8) |  |  | $ | (45) |  |

[0000858877-26-000021:notes:127]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 24, 2026 and July 26, 2025 (in millions):

[0000858877-26-000021:notes:128]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 24, 2026 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 710 |  |  | $ | (2) |  |  | $ | 244 |  |  | $ | (2) |  |  | $ | 954 |  |  | $ | (4) |  |
| Non-U.S. government and agency securities | 116 |  |  | — |  |  | — |  |  | — |  |  | 116 |  |  | — |  |
| Corporate debt securities | 422 |  |  | (1) |  |  | 1,409 |  |  | (10) |  |  | 1,831 |  |  | (11) |  |
| Mortgage- and asset-backed securities | 33 |  |  | — |  |  | 105 |  |  | (11) |  |  | 138 |  |  | (11) |  |
| Total | $ | 1,281 |  |  | $ | (3) |  |  | $ | 1,758 |  |  | $ | (23) |  |  | $ | 3,039 |  |  | $ | (26) |  |

[0000858877-26-000021:notes:129]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 26, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,076 |  |  | $ | (6) |  |  | $ | 302 |  |  | $ | (6) |  |  | $ | 1,378 |  |  | $ | (12) |  |
| U.S. government agency securities | 8 |  |  | — |  |  | 21 |  |  | — |  |  | 29 |  |  | — |  |
| Non-U.S. government and agency securities | 292 |  |  | — |  |  | — |  |  | — |  |  | 292 |  |  | — |  |
| Corporate debt securities | 106 |  |  | — |  |  | 1,800 |  |  | (35) |  |  | 1,906 |  |  | (35) |  |
| Mortgage- and asset-backed securities | 5 |  |  | — |  |  | 279 |  |  | (34) |  |  | 284 |  |  | (34) |  |
| Commercial paper | 30 |  |  | — |  |  | — |  |  | — |  |  | 30 |  |  | — |  |
| Total | $ | 1,517 |  |  | $ | (6) |  |  | $ | 2,402 |  |  | $ | (75) |  |  | $ | 3,919 |  |  | $ | (81) |  |

[0000858877-26-000021:notes:130]
The following table summarizes the maturities of our available-for-sale debt investments as of January 24, 2026 (in millions):

[0000858877-26-000021:notes:131]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 4,696 |  |  | $ | 4,660 |  |
| After 1 year through 5 years | 2,982 |  |  | 2,992 |  |
| After 5 years through 10 years | 72 |  |  | 72 |  |
| Mortgage- and asset-backed securities with no single maturity | 247 |  |  | 236 |  |
| Total | $ | 7,997 |  |  | $ | 7,960 |  |

[0000858877-26-000021:notes:132]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-26-000021:notes:133]
(b)Marketable Equity Securities

[0000858877-26-000021:notes:134]
We held marketable equity securities of $359 million and $383 million as of January 24, 2026 and July 26, 2025, respectively. We recognized net unrealized losses of $34 million and $4 million during the second quarter and first six months of fiscal 2026, respectively, and net unrealized gains of $16 million and $36 million for the corresponding periods of fiscal 2025, respectively, on our marketable securities still held as of the reporting date.

[0000858877-26-000021:notes:135]
(c)Investments in Privately Held Companies

[0000858877-26-000021:notes:136]
The carrying value of our investments in privately held companies was $2.1 billion and $1.9 billion as of January 24, 2026 and July 26, 2025, respectively. As of January 24, 2026, we have total funding commitments of $0.7 billion related to privately held investments. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.

[0000858877-26-000021:notes:137]
Investments in privately held companies measured using the measurement alternative had a carrying value of $0.7 billion and $0.6 billion as of January 24, 2026 and July 26, 2025, respectively. We have recorded cumulative adjustments to the carrying value of our investments in privately held companies measured using the measurement alternative as follows (in millions):

[0000858877-26-000021:notes:138]
|  | January 24, 2026 |  | July 26, 2025 |
| Cumulative upward adjustments | $ | 278 |  |  | $ | 195 |  |
| Cumulative downward adjustments, including impairments | (601) |  |  | (597) |  |
| Net adjustments | $ | (323) |  |  | $ | (402) |  |

[0000858877-26-000021:notes:139]
We held equity interests in certain private equity funds of $0.7 billion as of each of January 24, 2026 and July 26, 2025, which are accounted for under the NAV practical expedient.

[0000858877-26-000021:notes:140]
Of the total carrying value of our investments in privately held companies as of January 24, 2026, $0.8 billion of such investments are considered to be in variable interest entities which are unconsolidated.

[0000858877-26-000021:notes:141]
Certain of our investments in privately held companies are required to be consolidated under the voting interest entity model. The noncontrolling interest attributed to these investments was $221 million and $162 million as of January 24, 2026 and July 26, 2025, respectively, and is included in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interest attributed to these investments is not material for any of the periods presented and is included in other income (loss), net in the Consolidated Statements of Operations.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-26-000021:notes:142]
[same as prior period, unchanged from 0000858877-25-000171:notes:142]

[0000858877-26-000021:notes:143]
[same as prior period, unchanged from 0000858877-25-000171:notes:143]

[0000858877-26-000021:notes:144]
|  | JANUARY 24, 2026 |  | JULY 26, 2025 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 5,348 |  |  | $ | — |  |  | $ | 5,348 |  |  | $ | 5,885 |  |  | $ | — |  |  | $ | 5,885 |  |
| Commercial paper | — |  |  | 134 |  |  | 134 |  |  | — |  |  | 336 |  |  | 336 |  |
| Corporate debt securities | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 1,756 |  |  | 1,756 |  |  | — |  |  | 1,961 |  |  | 1,961 |  |
| U.S. government agency securities | — |  |  | 49 |  |  | 49 |  |  | — |  |  | 67 |  |  | 67 |  |
| Non-U.S. government and agency securities | — |  |  | 443 |  |  | 443 |  |  | — |  |  | 458 |  |  | 458 |  |
| Corporate debt securities | — |  |  | 3,079 |  |  | 3,079 |  |  | — |  |  | 3,090 |  |  | 3,090 |  |
| Mortgage- and asset-backed securities | — |  |  | 236 |  |  | 236 |  |  | — |  |  | 286 |  |  | 286 |  |
| Commercial paper | — |  |  | 1,337 |  |  | 1,337 |  |  | — |  |  | 950 |  |  | 950 |  |
| Certificates of deposit | — |  |  | 1,060 |  |  | 1,060 |  |  | — |  |  | 569 |  |  | 569 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 359 |  |  | — |  |  | 359 |  |  | 383 |  |  | — |  |  | 383 |  |
| Other current assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | — |  |  | — |  |  | — |  |  | 563 |  |  | — |  |  | 563 |  |
| Derivative assets | — |  |  | 90 |  |  | 90 |  |  | — |  |  | 32 |  |  | 32 |  |
| Total | $ | 5,707 |  |  | $ | 8,184 |  |  | $ | 13,891 |  |  | $ | 6,831 |  |  | $ | 7,750 |  |  | $ | 14,581 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 83 |  |  | $ | 83 |  |  | $ | — |  |  | $ | 31 |  |  | $ | 31 |  |
| Total | $ | — |  |  | $ | 83 |  |  | $ | 83 |  |  | $ | — |  |  | $ | 31 |  |  | $ | 31 |  |

[0000858877-26-000021:notes:145]
[same as prior period, unchanged from 0000858877-25-000171:notes:145]

[0000858877-26-000021:notes:146]
[same as prior period, unchanged from 0000858877-25-000171:notes:146]

[0000858877-26-000021:notes:147]
[same as prior period, unchanged from 0000858877-25-000171:notes:147]

[0000858877-26-000021:notes:148]
The fair value for purchased intangible assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation. Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales. See Note 5.

[0000858877-26-000021:notes:149]
[same as prior period, unchanged from 0000858877-25-000171:notes:148]

[0000858877-26-000021:notes:150]
The fair value of our short-term loan receivables approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables was $3.2 billion and $2.9 billion as of January 24, 2026 and July 26, 2025, respectively. The estimated fair value of our long-term loan receivables approximates their carrying value. We use unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables, and therefore they are categorized as Level 3.
As of January 24, 2026, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of January 24, 2026, the fair value of our senior fixed-rate notes was $25.2 billion, with a carrying amount of $24.6 billion. This compares to a fair value of $25.0 billion and a carrying amount of $24.6 billion as of July 26, 2025. The fair value of the senior fixed-rate notes was determined based on observable market prices in a less active market and was categorized as Level 2.


## us-gaap:DebtDisclosureTextBlock

[0000858877-26-000021:notes:151]
Borrowings 
(a)Short-Term Debt

[0000858877-26-000021:notes:152]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-26-000021:notes:153]
|  | January 24, 2026 |  | July 26, 2025 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior fixed-rate notes | $ | 3,250 |  |  | 3.41 | % |  | $ | 1,749 |  |  | 4.15 | % |
| Commercial paper | 5,469 |  |  | 3.88 | % |  | 3,482 |  |  | 4.37 | % |
| Current portion of other debt | — |  |  | — |  |  | 1 |  |  | 1.13 | % |
| Total | $ | 8,719 |  |  |  |  | $ | 5,232 |  |  |  |

[0000858877-26-000021:notes:154]
We have a short-term debt financing program of up to $15.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-26-000021:notes:155]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-26-000021:notes:156]
(b)Long-Term Debt

[0000858877-26-000021:notes:157]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-26-000021:notes:158]
|  |  |  | January 24, 2026 |  | July 26, 2025 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.90% | February 26, 2026 |  | $ | 1,000 |  |  | 5.00% |  | $ | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | 4.61% |  | 1,000 |  |  | 4.61% |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | 4.73% |  | 1,000 |  |  | 4.73% |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | 4.94% |  | 1,000 |  |  | 4.94% |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | 5.11% |  | 1,250 |  |  | 5.11% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.50% | February 24, 2055 |  | 750 |  |  | 5.49% |  | 750 |  |  | 5.49% |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 2 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 24,752 |  |  |  |  | 24,753 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (135) |  |  |  |  | (142) |  |  |  |
| Total |  |  | $ | 24,617 |  |  |  |  | $ | 24,611 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,250 |  |  |  |  | $ | 1,750 |  |  |  |
| Long-term debt |  |  | 21,367 |  |  |  |  | 22,861 |  |  |  |
| Total |  |  | $ | 24,617 |  |  |  |  | $ | 24,611 |  |  |  |

[0000858877-26-000021:notes:159]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior fixed-rate notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 24, 2026, we were in compliance with all debt covenants.

[0000858877-26-000021:notes:160]
As of January 24, 2026, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-26-000021:notes:161]
| Fiscal Year | Amount |
| 2026 (remaining six months) | $ | 1,750 |  |
| 2027 | 3,502 |  |
| 2028 | 1,000 |  |
| 2029 | 2,500 |  |
| 2030 | 1,000 |  |
| Thereafter | 15,000 |  |
| Total | $ | 24,752 |  |

[0000858877-26-000021:notes:162]
(c)Credit Facility

[0000858877-26-000021:notes:163]
On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of January 24, 2026, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-26-000021:notes:164]
[same as prior period, unchanged from 0000858877-25-000171:notes:163]

[0000858877-26-000021:notes:165]
[same as prior period, unchanged from 0000858877-25-000171:notes:164]

[0000858877-26-000021:notes:166]
[same as prior period, unchanged from 0000858877-25-000171:notes:165]

[0000858877-26-000021:notes:167]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | January 24,2026 |  | July 26,2025 |  | Balance Sheet Line Item |  | January 24,2026 |  | July 26,2025 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 40 |  |  | $ | 17 |  |  | Other current liabilities |  | $ | 4 |  |  | $ | 2 |  |
| Foreign currency derivatives | Other assets |  | 43 |  |  | 10 |  |  | Other long-term liabilities |  | — |  |  | 2 |  |
| Total |  |  | 83 |  |  | 27 |  |  |  |  | 4 |  |  | 4 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 7 |  |  | 3 |  |  | Other current liabilities |  | 36 |  |  | 17 |  |
| Foreign currency derivatives | Other assets |  | — |  |  | 2 |  |  | Other long-term liabilities |  | 43 |  |  | 10 |  |
| Total |  |  | 7 |  |  | 5 |  |  |  |  | 79 |  |  | 27 |  |
| Total |  |  | $ | 90 |  |  | $ | 32 |  |  |  |  | $ | 83 |  |  | $ | 31 |  |

[0000858877-26-000021:notes:168]
[same as prior period, unchanged from 0000858877-25-000171:notes:167]

[0000858877-26-000021:notes:169]
|  |  |  |  | GAINS (LOSSES) FOR THE THREE MONTHS ENDED |  | GAINS (LOSSES) FOR THE SIX MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | January 24, 2026 |  | January 25, 2025 |  | January 24, 2026 |  | January 25, 2025 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (3) |  |  | $ | (63) |  |  | $ | (49) |  |  | $ | (95) |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | 14 |  |  | 11 |  |  | 68 |  |  | 33 |  |
| Total |  |  |  | $ | 11 |  |  | $ | (52) |  |  | $ | 19 |  |  | $ | (62) |  |

[0000858877-26-000021:notes:170]
[same as prior period, unchanged from 0000858877-25-000171:notes:169]

[0000858877-26-000021:notes:171]
|  | January 24, 2026 |  | July 26, 2025 |
| Foreign currency derivatives | $ | 8,518 |  |  | $ | 8,978 |  |
| Total return swaps—deferred compensation | 1,202 |  |  | 1,087 |  |
| Total | $ | 9,720 |  |  | $ | 10,065 |  |

[0000858877-26-000021:notes:172]
[same as prior period, unchanged from 0000858877-25-000171:notes:171]

[0000858877-26-000021:notes:173]
[same as prior period, unchanged from 0000858877-25-000171:notes:172]

[0000858877-26-000021:notes:174]
[same as prior period, unchanged from 0000858877-25-000171:notes:173]

[0000858877-26-000021:notes:175]
[same as prior period, unchanged from 0000858877-25-000171:notes:174]

[0000858877-26-000021:notes:176]
[same as prior period, unchanged from 0000858877-25-000171:notes:175]

[0000858877-26-000021:notes:177]
[same as prior period, unchanged from 0000858877-25-000171:notes:176]

[0000858877-26-000021:notes:178]
[same as prior period, unchanged from 0000858877-25-000171:notes:177]

[0000858877-26-000021:notes:179]
[same as prior period, unchanged from 0000858877-25-000171:notes:178]

[0000858877-26-000021:notes:180]
[same as prior period, unchanged from 0000858877-25-000171:notes:179]

[0000858877-26-000021:notes:181]
[same as prior period, unchanged from 0000858877-25-000171:notes:180]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-26-000021:notes:182]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-26-000021:notes:183]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments are directly with suppliers, and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-26-000021:notes:184]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-26-000021:notes:185]
|  | January 24, 2026 |  | July 26, 2025 |
| Less than 1 year | $ | 9,615 |  |  | $ | 7,202 |  |
| 1 to 3 years | 417 |  |  | 320 |  |
| 3 to 5 years | 23 |  |  | 77 |  |
| Total | $ | 10,055 |  |  | $ | 7,599 |  |

[0000858877-26-000021:notes:186]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 24, 2026 and July 26, 2025, the liability for these purchase commitments was $185 million and $206 million, respectively, and was included in other current liabilities.

[0000858877-26-000021:notes:187]
(b)Other Commitments

[0000858877-26-000021:notes:188]
We have certain funding commitments, primarily related to our privately held investments. The funding commitments were $0.7 billion and $0.3 billion as of January 24, 2026 and July 26, 2025, respectively.

[0000858877-26-000021:notes:189]
(c)Product Warranties

[0000858877-26-000021:notes:190]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-26-000021:notes:191]
|  | Six Months Ended |
|  | January 24, 2026 |  | January 25, 2025 |
| Balance at beginning of period | $ | 399 |  |  | $ | 362 |  |
| Provisions for warranties issued | 209 |  |  | 198 |  |
| Adjustments for pre-existing warranties | — |  |  | 37 |  |
| Settlements | (231) |  |  | (203) |  |
| Balance at end of period | $ | 377 |  |  | $ | 394 |  |

[0000858877-26-000021:notes:192]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-26-000021:notes:193]
(d)Financing and Other Guarantees

[0000858877-26-000021:notes:194]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-26-000021:notes:195]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.4 billion and $6.2 billion for the second quarter of fiscal 2026 and 2025, respectively, and $14.0 billion and $12.2 billion for the first six months of fiscal 2026 and 2025, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion as of each of January 24, 2026 and July 26, 2025.

[0000858877-26-000021:notes:196]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at January 24, 2026 and July 26, 2025, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-26-000021:notes:197]
|  | January 24, 2026 |  | July 26, 2025 |
| Maximum potential future payments | $ | 126 |  |  | $ | 123 |  |
| Deferred revenue | (13) |  |  | (13) |  |
| Total | $ | 113 |  |  | $ | 110 |  |

[0000858877-26-000021:notes:198]
(e)Indemnifications

[0000858877-26-000021:notes:199]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-26-000021:notes:200]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-26-000021:notes:201]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-26-000021:notes:202]
(f)Legal Proceedings

[0000858877-26-000021:notes:203]
Brazil  Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The remaining asserted claims by Brazilian federal tax authorities are for calendar years 2004 through 2007, and the remaining asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total remaining asserted claims by Brazilian state and federal tax authorities aggregate to $148 million for the alleged evasion of import and other taxes, $902 million for interest, and $303 million for various penalties, all determined using an exchange rate as of January 24, 2026.

[0000858877-26-000021:notes:204]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-26-000021:notes:205]
Centripetal  Centripetal Networks, Inc. (“Centripetal”) filed various patent litigations in the U.S., Germany, and France. These cases have either concluded with findings of non-infringement or invalidity or are in various stages of appeals. In the U.S., there is an appeal from our win in the Eastern District of Virginia that is pending in the Federal Circuit Court of Appeals, and one Patent Trial and Appeal Board ("PTAB") inter partes review decision that was remanded to the PTAB for further proceedings. In Germany, there is an infringement hearing on one patent set for April 2, 2026, and an appeal hearing in a related invalidity proceeding set for November 10, 2026. In France, Centripetal also filed an infringement case alleging infringement of the French counterpart to U.S. and German patents previously found to not be infringed. Those proceedings are ongoing and a final hearing date has not been set.

[0000858877-26-000021:notes:206]
Ramot  On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del. on other Ramot patents. The Court rescheduled the trial date in the D. Del. cases for December 1, 2025. Prior to trial, the D. Del. Court granted our motion for summary judgment of non-infringement of all patents-in suit. Ramot appealed that decision to the Federal Circuit and those proceedings are ongoing.

[0000858877-26-000021:notes:207]
While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-26-000021:notes:208]
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-26-000021:notes:209]
Purchase Commitments with Contract Manufacturers and Suppliers We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments are directly with suppliers, and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-26-000021:notes:210]
[same as prior period, unchanged from 0000858877-25-000171:notes:214]

[0000858877-26-000021:notes:211]
In September 2001, our Board of Directors authorized a stock repurchase program. As of January 24, 2026, the remaining authorized amount for stock repurchases under this program was approximately $10.8 billion, with no termination date. The stock repurchase activity for fiscal 2026 and 2025 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-26-000021:notes:212]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2026 |  |  |  |  |  |  |
| January 24, 2026 |  | 18 |  |  | $ | 76.29 |  |  | $ | 1,351 |  |
| October 25, 2025 |  | 29 |  |  | $ | 68.28 |  |  | $ | 2,001 |  |
| Fiscal 2025 |  |  |  |  |  |  |
| July 26, 2025 |  | 19 |  |  | $ | 64.65 |  |  | $ | 1,252 |  |
| April 26, 2025 |  | 25 |  |  | $ | 59.78 |  |  | $ | 1,504 |  |
| January 25, 2025 |  | 21 |  |  | $ | 58.58 |  |  | $ | 1,236 |  |
| October 26, 2024 |  | 40 |  |  | $ | 49.56 |  |  | $ | 2,003 |  |

[0000858877-26-000021:notes:213]
There were stock repurchases of $17 million and $20 million that were pending settlement January 24, 2026 and July 26, 2025, respectively.

[0000858877-26-000021:notes:214]
[same as prior period, unchanged from 0000858877-25-000171:notes:218]

[0000858877-26-000021:notes:215]
[same as prior period, unchanged from 0000858877-25-000171:notes:219]

[0000858877-26-000021:notes:216]
On February 11, 2026, our Board of Directors declared a quarterly dividend of $0.42 per common share to be paid on April 22, 2026, to all stockholders of record as of the close of business on April 2, 2026. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-26-000021:notes:217]
[same as prior period, unchanged from 0000858877-25-000171:notes:221]

[0000858877-26-000021:notes:218]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock in one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights, if any, of such series, and any qualifications, limitations or restrictions thereof, of the shares of such series. As of January 24, 2026, we have not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-26-000021:notes:219]
[same as prior period, unchanged from 0000858877-25-000171:notes:223]

[0000858877-26-000021:notes:220]
[same as prior period, unchanged from 0000858877-25-000171:notes:224]

[0000858877-26-000021:notes:221]
[same as prior period, unchanged from 0000858877-25-000171:notes:225]

[0000858877-26-000021:notes:222]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of January 24, 2026, 124 million shares were authorized for future grant under the 2005 Plan.

[0000858877-26-000021:notes:223]
[same as prior period, unchanged from 0000858877-25-000171:notes:227]

[0000858877-26-000021:notes:224]
We have an Employee Stock Purchase Plan under which eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. Under the Employee Stock Purchase Plan, we issued 8 million shares during each of the second quarters and first six months of fiscal 2026 and fiscal 2025. As of January 24, 2026, 42 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-26-000021:notes:225]
[same as prior period, unchanged from 0000858877-25-000171:notes:229]

[0000858877-26-000021:notes:226]
[same as prior period, unchanged from 0000858877-25-000171:notes:230]

[0000858877-26-000021:notes:227]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2026 |  | January 25, 2025 |  | January 24, 2026 |  | January 25, 2025 |
| Cost of sales—product | $ | 63 |  |  | $ | 65 |  |  | $ | 131 |  |  | $ | 122 |  |
| Cost of sales—services | 88 |  |  | 86 |  |  | 170 |  |  | 160 |  |
| Share-based compensation expense in cost of sales | 151 |  |  | 151 |  |  | 301 |  |  | 282 |  |
| Research and development | 420 |  |  | 413 |  |  | 904 |  |  | 767 |  |
| Sales and marketing | 244 |  |  | 231 |  |  | 513 |  |  | 441 |  |
| General and administrative | 118 |  |  | 121 |  |  | 249 |  |  | 236 |  |
| Restructuring and other charges | 1 |  |  | 5 |  |  | 22 |  |  | 22 |  |
| Share-based compensation expense in operating expenses | 783 |  |  | 770 |  |  | 1,688 |  |  | 1,466 |  |
| Total share-based compensation expense | $ | 934 |  |  | $ | 921 |  |  | $ | 1,989 |  |  | $ | 1,748 |  |
| Income tax benefit for share-based compensation | $ | 298 |  |  | $ | 224 |  |  | $ | 539 |  |  | $ | 398 |  |

[0000858877-26-000021:notes:228]
As of January 24, 2026, the total compensation cost related to unvested share-based awards not yet recognized was $5.4 billion which is expected to be recognized over approximately 1.9 years on a weighted-average basis.

[0000858877-26-000021:notes:229]
[same as prior period, unchanged from 0000858877-25-000171:notes:233]

[0000858877-26-000021:notes:230]
[same as prior period, unchanged from 0000858877-25-000171:notes:234]

[0000858877-26-000021:notes:231]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| Unvested balance at July 27, 2024 | 117 |  |  | $ | 46.86 |  |  |  |
| Granted and assumed | 70 |  |  | 55.73 |  |  |  |
| Vested | (65) |  |  | 46.95 |  |  | $ | 3,707 |  |
| Canceled/forfeited/other | (9) |  |  | 48.04 |  |  |  |
| Unvested balance at July 26, 2025 | 113 |  |  | 52.26 |  |  |  |
| Granted and assumed | 44 |  |  | 68.04 |  |  |  |
| Vested | (43) |  |  | 49.40 |  |  | $ | 3,047 |  |
| Canceled/forfeited/other | 3 |  |  | 40.84 |  |  |  |
| Unvested balance at January 24, 2026 | 117 |  |  | $ | 58.94 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-26-000021:notes:232]
Accumulated Other Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first six months of fiscal 2026 and 2025 are summarized as follows (in millions):

[0000858877-26-000021:notes:233]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 26, 2025 | $ | (57) |  |  | $ | 65 |  |  | $ | (962) |  |  | $ | (954) |  |
| Other comprehensive income (loss) before reclassifications | 46 |  |  | 76 |  |  | 33 |  |  | 155 |  |
| (Gains) losses reclassified out of AOCI | 8 |  |  | (22) |  |  | — |  |  | (14) |  |
| Tax benefit (expense) | (9) |  |  | (13) |  |  | (1) |  |  | (23) |  |
| Balance at January 24, 2026 | $ | (12) |  |  | $ | 106 |  |  | $ | (930) |  |  | $ | (836) |  |

[0000858877-26-000021:notes:234]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 27, 2024 | $ | (241) |  |  | $ | 79 |  |  | $ | (1,268) |  |  | $ | (1,430) |  |
| Other comprehensive income (loss) before reclassifications | 75 |  |  | 65 |  |  | (174) |  |  | (34) |  |
| (Gains) losses reclassified out of AOCI | 45 |  |  | (24) |  |  | — |  |  | 21 |  |
| Tax benefit (expense) | (40) |  |  | (10) |  |  | — |  |  | (50) |  |
| Balance at January 25, 2025 | $ | (161) |  |  | $ | 110 |  |  | $ | (1,442) |  |  | $ | (1,493) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-26-000021:notes:235]
[same as prior period, unchanged from 0000858877-25-000171:notes:239]

[0000858877-26-000021:notes:236]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24,2026 |  | January 25,2025 |  | January 24,2026 |  | January 25,2025 |
| Income before provision for income taxes | $ | 3,646 |  |  | $ | 2,887 |  |  | $ | 7,037 |  |  | $ | 5,154 |  |
| Provision for income taxes | 471 |  |  | 459 |  |  | 1,002 |  |  | 15 |  |
| Effective tax rate | 12.9 | % |  | 15.9 | % |  | 14.2 | % |  | 0.3 | % |

[0000858877-26-000021:notes:237]
As of January 24, 2026, we had $2.4 billion of unrecognized tax benefits, of which $1.6 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.

[0000858877-26-000021:notes:238]
We made our final transition tax payment of $2.3 billion in the second quarter of fiscal 2026 associated with the one-time U.S. transition tax on accumulated earnings for foreign subsidiaries as a result of the Tax Cuts and Jobs Act. On August 26, 2024, the U.S. Tax Court issued an opinion in Varian Medical Systems, Inc. v. Commissioner. The opinion related to the U.S. taxation of deemed foreign dividends in the transition year of the Tax Cuts and Jobs Act (our fiscal 2018). While we were not a party to the case, the opinion resulted in a change to our tax position. As such, we recorded a tax benefit of $720 million as a reduction to the provision for income taxes in the first quarter of fiscal 2025 due to this U.S. Tax Court opinion. The income tax receivable associated with this tax benefit was included in other assets in the Consolidated Balance Sheets.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-26-000021:notes:239]
[same as prior period, unchanged from 0000858877-25-000171:notes:243]

[0000858877-26-000021:notes:240]
[same as prior period, unchanged from 0000858877-25-000171:notes:244]

[0000858877-26-000021:notes:241]
We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because the CODM does not include this information in our measurement of performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the cost of sales and gross margin for each segment because the CODM does not include this information in the measurement of the performance of our operating segments.

[0000858877-26-000021:notes:242]
[same as prior period, unchanged from 0000858877-25-000171:notes:246]

[0000858877-26-000021:notes:243]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24,2026 |  | January 25,2025 |  | January 24,2026 |  | January 25,2025 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 8,845 |  |  | $ | 8,202 |  |  | $ | 17,834 |  |  | $ | 16,454 |  |
| EMEA | 4,425 |  |  | 3,855 |  |  | 8,208 |  |  | 7,444 |  |
| APJC | 2,080 |  |  | 1,934 |  |  | 4,191 |  |  | 3,934 |  |
| Total | $ | 15,349 |  |  | $ | 13,991 |  |  | $ | 30,232 |  |  | $ | 27,832 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 5,816 |  |  | $ | 5,545 |  |  | $ | 11,817 |  |  | $ | 11,285 |  |
| EMEA | 3,173 |  |  | 2,750 |  |  | 5,895 |  |  | 5,272 |  |
| APJC | 1,368 |  |  | 1,320 |  |  | 2,781 |  |  | 2,648 |  |
| Segment total | 10,357 |  |  | 9,614 |  |  | 20,493 |  |  | 19,204 |  |
| Unallocated corporate items | (385) |  |  | (503) |  |  | (776) |  |  | (972) |  |
| Total | $ | 9,972 |  |  | $ | 9,111 |  |  | $ | 19,717 |  |  | $ | 18,232 |  |
| Supplemental information about our significant expenses: |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| Cost of sales — product | $ | 2,416 |  |  | $ | 1,877 |  |  | $ | 4,765 |  |  | $ | 3,928 |  |
| Cost of sales — services | 612 |  |  | 635 |  |  | 1,251 |  |  | 1,242 |  |
| Segment total | $ | 3,029 |  |  | $ | 2,512 |  |  | $ | 6,016 |  |  | $ | 5,170 |  |
| EMEA: |  |  |  |  |  |  |  |
| Cost of sales — product | $ | 962 |  |  | $ | 778 |  |  | $ | 1,730 |  |  | $ | 1,602 |  |
| Cost of sales — services | 289 |  |  | 288 |  |  | 583 |  |  | 570 |  |
| Segment total | $ | 1,252 |  |  | $ | 1,066 |  |  | $ | 2,314 |  |  | $ | 2,172 |  |
| APJC: |  |  |  |  |  |  |  |
| Cost of sales — product | $ | 533 |  |  | $ | 490 |  |  | $ | 1,047 |  |  | $ | 926 |  |
| Cost of sales — services | 179 |  |  | 183 |  |  | 362 |  |  | 360 |  |
| Segment total | $ | 712 |  |  | $ | 673 |  |  | $ | 1,410 |  |  | $ | 1,286 |  |

[0000858877-26-000021:notes:244]
Revenue in the United States was $8.0 billion and $7.4 billion for the second quarter of fiscal 2026 and 2025, respectively, and $16.1 billion and $14.8 billion for the first six months of fiscal 2026 and 2025, respectively.

[0000858877-26-000021:notes:245]
[same as prior period, unchanged from 0000858877-25-000171:notes:249]

[0000858877-26-000021:notes:246]
We design and sell Internet Protocol (IP)-based networking and other products related to the communications and IT industry and provide services associated with these products and their use.


## us-gaap:EarningsPerShareTextBlock

[0000858877-26-000021:notes:247]
[same as prior period, unchanged from 0000858877-25-000171:notes:251]

[0000858877-26-000021:notes:248]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2026 |  | January 25, 2025 |  | January 24, 2026 |  | January 25, 2025 |
| Net income | $ | 3,175 |  |  | $ | 2,428 |  |  | $ | 6,035 |  |  | $ | 5,139 |  |
| Weighted-average shares—basic | 3,955 |  |  | 3,981 |  |  | 3,955 |  |  | 3,986 |  |
| Effect of dilutive potential common shares | 29 |  |  | 24 |  |  | 32 |  |  | 22 |  |
| Weighted-average shares—diluted | 3,984 |  |  | 4,005 |  |  | 3,987 |  |  | 4,008 |  |
| Net income per share—basic | $ | 0.80 |  |  | $ | 0.61 |  |  | $ | 1.53 |  |  | $ | 1.29 |  |
| Net income per share—diluted | $ | 0.80 |  |  | $ | 0.61 |  |  | $ | 1.51 |  |  | $ | 1.28 |  |
| Antidilutive employee share-based awards, excluded | — |  |  | 22 |  |  | — |  |  | 59 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000858877-26-000021:notes:249]
On December 16, 2025, Deborah L. Stahlkopf, Cisco’s Executive Vice President and Chief Legal Officer, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Ms. Stahlkopf’s trading plan provides for the sale of approximately 149,243 gross shares (with any shares underlying performance-based equity awards being calculated at target), plus any related dividend-equivalent shares earned with respect to such shares and excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Ms. Stahlkopf’s trading plan is scheduled to terminate on December 19, 2026, subject to early termination for certain specified events set forth therein.

[0000858877-26-000021:notes:250]
On December 17, 2025, Oliver Tuszik, Cisco's Executive Vice President, Global Sales and Chief Sales Officer, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Mr. Tuszik’s trading plan provides for the sale of approximately 44,768 gross shares (with any shares underlying performance-based equity awards being calculated at target), plus any related dividend-equivalent shares earned with respect to such shares and excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Mr. Tuszik’s trading plan is scheduled to terminate on December 19, 2026, subject to early termination for certain specified events set forth therein.

[0000858877-26-000021:notes:251]
On December 19, 2025, Jeetendra I. Patel, Cisco's President and Chief Product Officer, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Mr. Patel’s trading plan provides for the sale of approximately 163,293 gross shares (with any shares underlying performance-based equity awards being calculated at target), plus any related dividend-equivalent shares earned with respect to such shares and excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Mr. Patel’s trading plan is scheduled to terminate on December 19, 2026, subject to early termination for certain specified events set forth therein.

[0000858877-26-000021:notes:252]
On December 19, 2025, Mark Patterson, Cisco's Executive Vice President and Chief Financial Officer, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Mr. Patterson’s trading plan provides for the sale of approximately 87,228 gross shares (with any shares underlying performance-based equity awards being calculated at target), plus any related dividend-equivalent shares earned with respect to such shares and excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Mr. Patterson’s trading plan is scheduled to terminate on December 19, 2026, subject to early termination for certain specified events set forth therein.
