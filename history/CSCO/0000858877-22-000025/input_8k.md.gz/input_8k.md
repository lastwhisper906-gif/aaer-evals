# CSCO 8-K — 0001193125-22-286782 filed 2022-11-16

## item codes, every 8-K on or before 2022-11-22

- 2022-11-16 0001628280-22-030151 — 5.02
- 2022-11-16 0001193125-22-286782 — 2.02, 2.05, 9.01
- 2022-10-04 0000858877-22-000018 — 1.01, 1.02, 9.01
- 2022-09-15 0000858877-22-000015 — 8.01
- 2022-08-24 0001193125-22-228572 — 5.02
- 2022-08-17 0001193125-22-223250 — 2.02, 9.01
- 2022-06-17 0001193125-22-176552 — 8.01
- 2022-05-18 0001193125-22-154039 — 2.02, 9.01
- 2022-03-28 0001193125-22-086807 — 8.01
- 2022-02-16 0001193125-22-044372 — 2.02, 9.01
- 2022-02-11 0001193125-22-037227 — 5.02
- 2022-01-31 0001193125-22-023458 — 5.02
- 2021-12-17 0001193125-21-361182 — 8.01
- 2021-12-14 0001193125-21-356837 — 5.07, 8.01
- 2021-11-17 0001193125-21-332467 — 2.02, 9.01
- 2021-09-27 0001193125-21-284199 — 8.01
- 2021-08-18 0001193125-21-250360 — 2.02, 9.01
- 2021-06-29 0001193125-21-203324 — 8.01
- 2021-05-19 0001193125-21-166614 — 2.02, 9.01
- 2021-05-14 0001193125-21-162081 — 1.01, 2.03, 9.01
- 2021-03-08 0001193125-21-073328 — 5.02
- 2021-02-25 0001193125-21-056977 — 5.02
- 2021-02-09 0001193125-21-034339 — 2.02, 9.01
- 2021-01-07 0001193125-21-004250 — 5.02
- 2020-12-17 0001193125-20-320092 — 5.02, 8.01
- 2020-12-11 0001193125-20-315999 — 5.02, 5.07, 9.01
- 2020-11-30 0001193125-20-305352 — 5.02
- 2020-11-13 0001193125-20-293020 — 5.02, 9.01
- 2020-11-12 0001193125-20-291658 — 2.02, 9.01
- 2020-10-09 0001193125-20-267248 — 5.03, 9.01
- 2020-09-23 0001193125-20-252356 — 8.01
- 2020-08-12 0001193125-20-217756 — 5.02
- 2020-08-12 0001193125-20-217658 — 2.02, 2.05, 9.01
- 2020-06-22 0001193125-20-175641 — 8.01
- 2020-05-13 0001193125-20-141598 — 2.02, 9.01
- 2020-03-13 0001193125-20-072960 — 5.02
- 2020-03-06 0001193125-20-065138 — 5.02
- 2020-02-12 0001193125-20-033208 — 2.02, 9.01
- 2020-01-27 0001193125-20-015453 — 5.02
- 2019-12-23 0001193125-19-322662 — 8.01
- 2019-12-12 0001193125-19-312796 — 8.01
- 2019-12-11 0001193125-19-311525 — 5.07
- 2019-12-04 0001193125-19-306229 — 8.01
- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2022-11-22

- none on or before 2022-11-22

## item 2.02 — earnings release, exhibit 99.1

[0001193125-22-286782:8k_2_02:1]
EX-99.1
2
d385857dex991.htm
EX-99.1

[0001193125-22-286782:8k_2_02:2]
EX-99.1

[0001193125-22-286782:8k_2_02:3]
Exhibit 99.1

[0001193125-22-286782:8k_2_02:4]
| Press Contact: |  | Investor Relations Contact: |
| Robyn Blum |  | Marilyn Mora |
| Cisco |  | Cisco |
| 1 (408) 930-8548 |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  | marilmor@cisco.com |

[0001193125-22-286782:8k_2_02:5]
CISCO REPORTS FIRST QUARTER EARNINGS

[0001193125-22-286782:8k_2_02:6]
News Summary:

[0001193125-22-286782:8k_2_02:7]
|  | • |  | $13.6 billion in revenue, up 6% year over year; GAAP EPS $0.65, down 7% year over year, and Non-GAAP EPS $0.86, up 5% year over year |

[0001193125-22-286782:8k_2_02:8]
|  | • |  | Continued progress on business model transformation: |

[0001193125-22-286782:8k_2_02:9]
|  | • |  | Total annualized recurring revenue (ARR) at $23.2 billion, up 7% year over year and product ARR up 12% year over year |

[0001193125-22-286782:8k_2_02:10]
|  | • |  | Total software revenue up 5% year over year and software subscription revenue up 11% year over year |

[0001193125-22-286782:8k_2_02:11]
|  | • |  | Remaining performance obligations (RPO) at $30.9 billion, up 3% year over year and product RPO up 5% year over year |

[0001193125-22-286782:8k_2_02:12]
| • |  | Q1 FY 2023 Results: |

[0001193125-22-286782:8k_2_02:13]
|  | • |  | Revenue: $13.6 billion |

[0001193125-22-286782:8k_2_02:14]
|  | • |  | Increase of 6% year over year |

[0001193125-22-286782:8k_2_02:15]
|  | • |  | Earnings per Share: GAAP: $0.65; Non-GAAP: $0.86 |

[0001193125-22-286782:8k_2_02:16]
|  | • |  | GAAP EPS decreased (7)% year over year |

[0001193125-22-286782:8k_2_02:17]
|  | • |  | Non-GAAP EPS increased 5% year over year |

[0001193125-22-286782:8k_2_02:18]
| • |  | Q2 FY 2023 Guidance: |

[0001193125-22-286782:8k_2_02:19]
|  | • |  | Revenue: 4.5% to 6.5% growth year over year |

[0001193125-22-286782:8k_2_02:20]
|  | • |  | Earnings per Share: GAAP: $0.59 to $0.64; Non-GAAP: $0.84 to $0.86 |

[0001193125-22-286782:8k_2_02:21]
| • |  | FY 2023 Guidance: |

[0001193125-22-286782:8k_2_02:22]
|  | • |  | Revenue: 4.5% to 6.5% growth year over year |

[0001193125-22-286782:8k_2_02:23]
|  | • |  | Earnings per Share: GAAP: $2.63 to $2.76; Non-GAAP: $3.51 to $3.58 |

[0001193125-22-286782:8k_2_02:24]
SAN JOSE, Calif. — November 16, 2022 — Cisco today reported first quarter results for the period ended October 29,
2022. Cisco reported first quarter revenue of $13.6 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.7 billion or $0.65 per share, and non-GAAP net income of
$3.5 billion or $0.86 per share.

[0001193125-22-286782:8k_2_02:25]
“Our fiscal 2023 is off to a good start as we delivered the largest quarterly revenue and second highest
quarterly non-GAAP earnings per share in our history,” said Chuck Robbins, chair and CEO of Cisco. “These results demonstrate the relevance of our strategy, our differentiated innovation, and our
unique position to help our customers become more resilient.”

[0001193125-22-286782:8k_2_02:26]
“We delivered strong results in Q1 and continued to make progress on our business
transformation,” said Scott Herren, CFO of Cisco. “Our annualized recurring revenue increased to more than $23 billion, with product ARR growing 12%. This, together with our significant backlog, strong RPO, and easing supply
situation, provides us with great visibility and predictability, and supports our increased full year guidance.”

[0001193125-22-286782:8k_2_02:27]
1

[0001193125-22-286782:8k_2_02:28]
GAAP Results

[0001193125-22-286782:8k_2_02:29]
|  |  | Q1 FY 2023 |  |  | Q1 FY 2022 |  |  | Vs. Q1 FY 2022 |  |
| Revenue |  | $ | 13.6 billion |  |  | $ | 12.9 billion |  |  |  | 6 | % |
| Net Income |  | $ | 2.7 billion |  |  | $ | 3.0 billion |  |  |  | (10 | )% |
| Diluted Earnings per Share (EPS) |  | $ | 0.65 |  |  | $ | 0.70 |  |  |  | (7 | )% |

[0001193125-22-286782:8k_2_02:30]
Non-GAAP Results

[0001193125-22-286782:8k_2_02:31]
|  |  | Q1 FY 2023 |  |  | Q1 FY 2022 |  |  | Vs. Q1 FY 2022 |  |
| Net Income |  | $ | 3.5 billion |  |  | $ | 3.5 billion |  |  |  | 2 | % |
| EPS |  | $ | 0.86 |  |  | $ | 0.82 |  |  |  | 5 | % |

[0001193125-22-286782:8k_2_02:32]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-22-286782:8k_2_02:33]
2

[0001193125-22-286782:8k_2_02:34]
Financial Summary

[0001193125-22-286782:8k_2_02:35]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-22-286782:8k_2_02:36]
Q1 FY 2023 Highlights

[0001193125-22-286782:8k_2_02:37]
Revenue —
Total revenue was up 6% at $13.6 billion, with product revenue up 8% and service revenue was flat. Revenue by geographic segment was: Americas up 5%, EMEA up 11%, and APJC was flat. Product revenue performance was led by growth in
Secure, Agile Networks up 12%, End-to-End Security up 9%, and Optimized Application Experiences up 7%. Internet for the Future was down 5% and Collaboration was down 2%.

[0001193125-22-286782:8k_2_02:38]
Gross Margin — On a GAAP basis, total gross margin, product gross margin, and service gross margin were 61.2%, 59.2%, and
67.3%, respectively, as compared with 62.4%, 61.5%, and 65.2%, respectively, in the first quarter of fiscal 2022.

[0001193125-22-286782:8k_2_02:39]
On a
non-GAAP basis, total gross margin, product gross margin, and service gross margin were 63.0%, 61.0%, and 68.8%, respectively, as compared with 64.5%, 63.8%, and 66.5%, respectively, in the first quarter of
fiscal 2022.

[0001193125-22-286782:8k_2_02:40]
Total gross margins by geographic segment were: 63.0% for the Americas, 63.3% for EMEA and 62.3% for APJC.

[0001193125-22-286782:8k_2_02:41]
Operating Expenses — On a GAAP basis, operating expenses were $4.8 billion, up 4%, and were 35.3% of revenue. Non-GAAP operating expenses were $4.2 billion, up 5%, and were 31.1% of revenue.

[0001193125-22-286782:8k_2_02:42]
Operating Income
— GAAP operating income was $3.5 billion, up 3%, with GAAP operating margin of 26.0%. Non-GAAP operating income was $4.3 billion, up 1%, with
non-GAAP operating margin at 31.8%.

[0001193125-22-286782:8k_2_02:43]
Provision for Income Taxes — The GAAP tax provision rate
was 23.2%. The non-GAAP tax provision rate was 19.0%.

[0001193125-22-286782:8k_2_02:44]
Net Income and EPS — On a GAAP basis,
net income was $2.7 billion, a decrease of 10%, and EPS was $0.65, a decrease of 7%. On a non-GAAP basis, net income was $3.5 billion, an increase of 2%, and EPS was $0.86, an increase of 5%.

[0001193125-22-286782:8k_2_02:45]
Cash Flow from Operating Activities — $4.0 billion for the first quarter of fiscal 2023, an increase of 16% compared with
$3.4 billion for the first quarter of fiscal 2022.

[0001193125-22-286782:8k_2_02:46]
Balance Sheet and Other Financial Highlights

[0001193125-22-286782:8k_2_02:47]
Cash and Cash Equivalents and Investments — $19.8 billion at the end of the first quarter of fiscal 2023, compared with
$19.3 billion at the end of fiscal 2022.

[0001193125-22-286782:8k_2_02:48]
Remaining Performance Obligations (RPO) — $30.9 billion, up 3% in
total, with 53% of this amount to be recognized as revenue over the next 12 months. Product RPO were up 5% and service RPO were up 1%.

[0001193125-22-286782:8k_2_02:49]
Deferred
Revenue — $23.0 billion, up 4% in total, with deferred product revenue up 7%. Deferred service revenue was up 2%.

[0001193125-22-286782:8k_2_02:50]
Capital
Allocation — In the first quarter of fiscal 2023, we returned $2.1 billion to stockholders through share buybacks and dividends. We declared and paid a cash dividend of $0.38 per common share, or $1.6 billion, and repurchased
approximately 12 million shares of common stock under our stock repurchase program at an average price of $43.76 per share for an aggregate purchase price of $0.5 billion. The remaining authorized amount for stock repurchases under the
program is $14.7 billion with no termination date.

[0001193125-22-286782:8k_2_02:51]
3

[0001193125-22-286782:8k_2_02:52]
Guidance

[0001193125-22-286782:8k_2_02:53]
Cisco expects to achieve the following results for the second quarter of fiscal 2023:

[0001193125-22-286782:8k_2_02:54]
| Q2 FY 2023 |  |  |
| Revenue |  | 4.5% - 6.5% growth Y/Y |
| Non-GAAP gross margin rate |  | 63% - 64% |
| Non-GAAP operating margin rate |  | 31.5% - 32.5% |
| Non-GAAP EPS |  | $0.84 - $0.86 |

[0001193125-22-286782:8k_2_02:55]
Cisco estimates that GAAP EPS will be $0.59 to $0.64 for the second quarter of fiscal 2023.

[0001193125-22-286782:8k_2_02:56]
Cisco expects to achieve the following results for fiscal 2023:

[0001193125-22-286782:8k_2_02:57]
| FY 2023 |  |  |  |  |
| Revenue |  |  | 4.5% - 6.5% growth Y/Y |  |
| Non-GAAP EPS |  |  | $3.51 - $3.58 |  |

[0001193125-22-286782:8k_2_02:58]
Cisco estimates that GAAP EPS will be $2.63 to $2.76 for fiscal 2023.

[0001193125-22-286782:8k_2_02:59]
Our Q2 FY 2023 guidance assumes an effective tax provision rate of 19% for GAAP and non-GAAP results. Our FY 2023
guidance assumes an effective tax provision rate of 20% for GAAP and 19% for non-GAAP results.

[0001193125-22-286782:8k_2_02:60]
A reconciliation
between the Guidance on a GAAP and non-GAAP basis is provided in the tables entitled “GAAP to non-GAAP Guidance” located in the section entitled
“Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-22-286782:8k_2_02:61]
Editor’s Notes:

[0001193125-22-286782:8k_2_02:62]
|  | • |  | Q1 fiscal year 2023 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, November 16, 2022 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-22-286782:8k_2_02:63]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, November 16, 2022 to 4:00 p.m. Pacific Time, November 23, 2022 at 1-800-835-5808 (United States) or 1-203-369-3353 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-22-286782:8k_2_02:64]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, November 16, 2022. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-22-286782:8k_2_02:65]
4

[0001193125-22-286782:8k_2_02:66]
CISCO SYSTEMS, INC.

[0001193125-22-286782:8k_2_02:67]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-22-286782:8k_2_02:68]
(In millions, except per-share amounts)

[0001193125-22-286782:8k_2_02:69]
(Unaudited)

[0001193125-22-286782:8k_2_02:70]
|  |  | Three Months Ended |  |
|  |  | October 29,2022 |  |  | October 30,2021 |  |
| REVENUE: |  |  |  |  |  |  |  |  |
| Product |  | $ | 10,245 |  |  | $ | 9,529 |  |
| Service |  |  | 3,387 |  |  |  | 3,371 |  |
| Total revenue |  |  | 13,632 |  |  |  | 12,900 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |
| Product |  |  | 4,179 |  |  |  | 3,673 |  |
| Service |  |  | 1,107 |  |  |  | 1,174 |  |
| Total cost of sales |  |  | 5,286 |  |  |  | 4,847 |  |
| GROSS MARGIN |  |  | 8,346 |  |  |  | 8,053 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,781 |  |  |  | 1,714 |  |
| Sales and marketing |  |  | 2,391 |  |  |  | 2,261 |  |
| General and administrative |  |  | 565 |  |  |  | 551 |  |
| Amortization of purchased intangible assets |  |  | 71 |  |  |  | 84 |  |
| Restructuring and other charges |  |  | (2 | ) |  |  | 5 |  |
| Total operating expenses |  |  | 4,806 |  |  |  | 4,615 |  |
| OPERATING INCOME |  |  | 3,540 |  |  |  | 3,438 |  |
| Interest income |  |  | 169 |  |  |  | 121 |  |
| Interest expense |  |  | (100 | ) |  |  | (89 | ) |
| Other income (loss), net |  |  | (134 | ) |  |  | 187 |  |
| Interest and other income (loss), net |  |  | (65 | ) |  |  | 219 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,475 |  |  |  | 3,657 |  |
| Provision for income taxes |  |  | 805 |  |  |  | 677 |  |
| NET INCOME |  | $ | 2,670 |  |  | $ | 2,980 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.65 |  |  | $ | 0.71 |  |
| Diluted |  | $ | 0.65 |  |  | $ | 0.70 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,108 |  |  |  | 4,218 |  |
| Diluted |  |  | 4,116 |  |  |  | 4,243 |  |

[0001193125-22-286782:8k_2_02:71]
5

[0001193125-22-286782:8k_2_02:72]
CISCO SYSTEMS, INC.

[0001193125-22-286782:8k_2_02:73]
REVENUE BY SEGMENT

[0001193125-22-286782:8k_2_02:74]
(In
millions, except percentages)

[0001193125-22-286782:8k_2_02:75]
|  |  | Three Months EndedOctober 29, 2022 |  |
|  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,914 |  |  |  | 5 | % |
| EMEA |  |  | 3,675 |  |  |  | 11 | % |
| APJC |  |  | 2,043 |  |  |  | — | % |
| Total |  | $ | 13,632 |  |  |  | 6 | % |

[0001193125-22-286782:8k_2_02:76]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-22-286782:8k_2_02:77]
CISCO SYSTEMS, INC.

[0001193125-22-286782:8k_2_02:78]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-22-286782:8k_2_02:79]
(In percentages)

[0001193125-22-286782:8k_2_02:80]
|  |  | Three Months EndedOctober 29, 2022 |  |
| Gross Margin Percentage: |  |  |  |  |
| Americas |  |  | 63.0% |  |
| EMEA |  |  | 63.3% |  |
| APJC |  |  | 62.3% |  |

[0001193125-22-286782:8k_2_02:81]
CISCO SYSTEMS, INC.

[0001193125-22-286782:8k_2_02:82]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-22-286782:8k_2_02:83]
(In millions, except percentages)

[0001193125-22-286782:8k_2_02:84]
|  |  | Three Months EndedOctober 29, 2022 |  |
|  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Secure, Agile Networks |  | $ | 6,684 |  |  |  | 12 | % |
| Internet for the Future |  |  | 1,310 |  |  |  | (5 | )% |
| Collaboration |  |  | 1,086 |  |  |  | (2 | )% |
| End-to-End Security |  |  | 971 |  |  |  | 9 | % |
| Optimized Application Experiences |  |  | 193 |  |  |  | 7 | % |
| Other Products |  |  | 2 |  |  |  | (47 | )% |
| Total Product |  |  | 10,245 |  |  |  | 8 | % |
| Services |  |  | 3,387 |  |  |  | — | % |
| Total |  | $ | 13,632 |  |  |  | 6 | % |

[0001193125-22-286782:8k_2_02:85]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-22-286782:8k_2_02:86]
6

[0001193125-22-286782:8k_2_02:87]
CISCO SYSTEMS, INC.

[0001193125-22-286782:8k_2_02:88]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-22-286782:8k_2_02:89]
(In millions)

[0001193125-22-286782:8k_2_02:90]
(Unaudited)

[0001193125-22-286782:8k_2_02:91]
|  |  | October 29,2022 |  |  | July 30,2022 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 7,292 |  |  | $ | 7,079 |  |
| Investments |  |  | 12,492 |  |  |  | 12,188 |  |
| Accounts receivable, net of allowance of $88 at October 29, 2022 and $83 at July 30, 2022 |  |  | 5,439 |  |  |  | 6,622 |  |
| Inventories |  |  | 2,664 |  |  |  | 2,568 |  |
| Financing receivables, net |  |  | 3,683 |  |  |  | 3,905 |  |
| Other current assets |  |  | 4,571 |  |  |  | 4,355 |  |
| Total current assets |  |  | 36,141 |  |  |  | 36,717 |  |
| Property and equipment, net |  |  | 1,972 |  |  |  | 1,997 |  |
| Financing receivables, net |  |  | 3,618 |  |  |  | 4,009 |  |
| Goodwill |  |  | 38,160 |  |  |  | 38,304 |  |
| Purchased intangible assets, net |  |  | 2,360 |  |  |  | 2,569 |  |
| Deferred tax assets |  |  | 4,891 |  |  |  | 4,449 |  |
| Other assets |  |  | 5,912 |  |  |  | 5,957 |  |
| TOTAL ASSETS |  | $ | 93,054 |  |  | $ | 94,002 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 1,249 |  |  | $ | 1,099 |  |
| Accounts payable |  |  | 2,316 |  |  |  | 2,281 |  |
| Income taxes payable |  |  | 890 |  |  |  | 961 |  |
| Accrued compensation |  |  | 2,907 |  |  |  | 3,316 |  |
| Deferred revenue |  |  | 12,578 |  |  |  | 12,784 |  |
| Other current liabilities |  |  | 4,956 |  |  |  | 5,199 |  |
| Total current liabilities |  |  | 24,896 |  |  |  | 25,640 |  |
| Long-term debt |  |  | 7,629 |  |  |  | 8,416 |  |
| Income taxes payable |  |  | 7,835 |  |  |  | 7,725 |  |
| Deferred revenue |  |  | 10,441 |  |  |  | 10,480 |  |
| Other long-term liabilities |  |  | 1,981 |  |  |  | 1,968 |  |
| Total liabilities |  |  | 52,782 |  |  |  | 54,229 |  |
| Total equity |  |  | 40,272 |  |  |  | 39,773 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 93,054 |  |  | $ | 94,002 |  |

[0001193125-22-286782:8k_2_02:92]
7

[0001193125-22-286782:8k_2_02:93]
CISCO SYSTEMS, INC.

[0001193125-22-286782:8k_2_02:94]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-22-286782:8k_2_02:95]
(In millions)

[0001193125-22-286782:8k_2_02:96]
(Unaudited)

[0001193125-22-286782:8k_2_02:97]
|  |  | Three Months Ended |  |
|  |  | October 29,2022 |  |  | October 30,2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 2,670 |  |  | $ | 2,980 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 415 |  |  |  | 533 |  |
| Share-based compensation expense |  |  | 496 |  |  |  | 453 |  |
| Provision (benefit) for receivables |  |  | 7 |  |  |  | 1 |  |
| Deferred income taxes |  |  | (366 | ) |  |  | (98 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | 131 |  |  |  | (211 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,119 |  |  |  | 427 |  |
| Inventories |  |  | (108 | ) |  |  | (275 | ) |
| Financing receivables |  |  | 556 |  |  |  | 672 |  |
| Other assets |  |  | (316 | ) |  |  | (170 | ) |
| Accounts payable |  |  | 42 |  |  |  | (93 | ) |
| Income taxes, net |  |  | 20 |  |  |  | 17 |  |
| Accrued compensation |  |  | (384 | ) |  |  | (585 | ) |
| Deferred revenue |  |  | (78 | ) |  |  | (95 | ) |
| Other liabilities |  |  | (242 | ) |  |  | (129 | ) |
| Net cash provided by operating activities |  |  | 3,962 |  |  |  | 3,427 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (1,943 | ) |  |  | (2,951 | ) |
| Proceeds from sales of investments |  |  | 407 |  |  |  | 580 |  |
| Proceeds from maturities of investments |  |  | 971 |  |  |  | 1,856 |  |
| Acquisitions, net of cash and cash equivalents acquired and divestitures |  |  | — |  |  |  | (336 | ) |
| Purchases of investments in privately held companies |  |  | (48 | ) |  |  | (101 | ) |
| Return of investments in privately held companies |  |  | 10 |  |  |  | 53 |  |
| Acquisition of property and equipment |  |  | (176 | ) |  |  | (122 | ) |
| Proceeds from sales of property and equipment |  |  | — |  |  |  | 1 |  |
| Other |  |  | (20 | ) |  |  | — |  |
| Net cash used in investing activities |  |  | (799 | ) |  |  | (1,020 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Repurchases of common stock - repurchase program |  |  | (556 | ) |  |  | (273 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (108 | ) |  |  | (133 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | (602 | ) |  |  | — |  |
| Repayments of debt |  |  | — |  |  |  | (2,000 | ) |
| Dividends paid |  |  | (1,560 | ) |  |  | (1,561 | ) |
| Other |  |  | (29 | ) |  |  | (3 | ) |
| Net cash used in financing activities |  |  | (2,855 | ) |  |  | (3,970 | ) |
| Effect of foreign currency exchange rate changes on cash, cash equivalents, restricted cash and restricted cash equivalents |  |  | (95 | ) |  |  | — |  |
| Net increase (decrease) in cash, cash equivalents, restricted cash and restricted cash equivalents |  |  | 213 |  |  |  | (1,563 | ) |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, beginning of period |  |  | 8,579 |  |  |  | 9,942 |  |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, end of period |  | $ | 8,792 |  |  | $ | 8,379 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 114 |  |  | $ | 124 |  |
| Cash paid for income taxes, net |  | $ | 1,150 |  |  | $ | 758 |  |

[0001193125-22-286782:8k_2_02:98]
8

[0001193125-22-286782:8k_2_02:99]
CISCO SYSTEMS, INC.

[0001193125-22-286782:8k_2_02:100]
REMAINING PERFORMANCE OBLIGATIONS

[0001193125-22-286782:8k_2_02:101]
(In millions, except percentages)

[0001193125-22-286782:8k_2_02:102]
|  |  | October 29, 2022 |  |  | July 30, 2022 |  |  | October 30, 2021 |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Product |  | $ | 14,013 |  |  |  | 5 | % |  | $ | 14,090 |  |  |  | 6 | % |  | $ | 13,384 |  |  |  | 18 | % |
| Service |  |  | 16,897 |  |  |  | 1 | % |  |  | 17,449 |  |  |  | (1 | )% |  |  | 16,751 |  |  |  | 4 | % |
| Total |  | $ | 30,910 |  |  |  | 3 | % |  | $ | 31,539 |  |  |  | 2 | % |  | $ | 30,135 |  |  |  | 10 | % |

[0001193125-22-286782:8k_2_02:103]
We expect 53% of total RPO at October 29, 2022 will be recognized as revenue over the next 12 months.

[0001193125-22-286782:8k_2_02:104]
CISCO SYSTEMS, INC.

[0001193125-22-286782:8k_2_02:105]
DEFERRED REVENUE

[0001193125-22-286782:8k_2_02:106]
(In
millions)

[0001193125-22-286782:8k_2_02:107]
|  |  | October 29,2022 |  |  | July 30,2022 |  |  | October 30,2021 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 10,404 |  |  | $ | 10,427 |  |  | $ | 9,681 |  |
| Service |  |  | 12,615 |  |  |  | 12,837 |  |  |  | 12,391 |  |
| Total |  | $ | 23,019 |  |  | $ | 23,264 |  |  | $ | 22,072 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 12,578 |  |  | $ | 12,784 |  |  | $ | 12,017 |  |
| Noncurrent |  |  | 10,441 |  |  |  | 10,480 |  |  |  | 10,055 |  |
| Total |  | $ | 23,019 |  |  | $ | 23,264 |  |  | $ | 22,072 |  |

[0001193125-22-286782:8k_2_02:108]
CISCO SYSTEMS, INC.

[0001193125-22-286782:8k_2_02:109]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-22-286782:8k_2_02:110]
(In millions, except per-share amounts)

[0001193125-22-286782:8k_2_02:111]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2023 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| October 29, 2022 |  | $ | 0.38 |  |  | $ | 1,560 |  |  |  | 12 |  |  | $ | 43.76 |  |  | $ | 502 |  |  | $ | 2,062 |  |
| Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 30, 2022 |  | $ | 0.38 |  |  | $ | 1,567 |  |  |  | 54 |  |  | $ | 44.02 |  |  | $ | 2,402 |  |  | $ | 3,969 |  |
| April 30, 2022 |  | $ | 0.38 |  |  | $ | 1,555 |  |  |  | 5 |  |  | $ | 54.20 |  |  | $ | 252 |  |  | $ | 1,807 |  |
| January 29, 2022 |  | $ | 0.37 |  |  | $ | 1,541 |  |  |  | 82 |  |  | $ | 58.36 |  |  | $ | 4,824 |  |  | $ | 6,365 |  |
| October 30, 2021 |  | $ | 0.37 |  |  | $ | 1,561 |  |  |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |  | $ | 1,817 |  |

[0001193125-22-286782:8k_2_02:112]
9

[0001193125-22-286782:8k_2_02:113]
CISCO SYSTEMS, INC.

[0001193125-22-286782:8k_2_02:114]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-22-286782:8k_2_02:115]
GAAP TO NON-GAAP NET INCOME

[0001193125-22-286782:8k_2_02:116]
(In millions)

[0001193125-22-286782:8k_2_02:117]
|  |  | Three Months Ended |  |
|  |  | October 29,2022 |  |  | October 30,2021 |  |
| GAAP net income |  | $ | 2,670 |  |  | $ | 2,980 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 81 |  |  |  | 69 |  |
| Amortization of acquisition-related intangible assets |  |  | 153 |  |  |  | 198 |  |
| Acquisition-related/divestiture costs |  |  | 2 |  |  |  | 1 |  |
| Total adjustments to GAAP cost of sales |  |  | 236 |  |  |  | 268 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 415 |  |  |  | 383 |  |
| Amortization of acquisition-related intangible assets |  |  | 71 |  |  |  | 84 |  |
| Acquisition-related/divestiture costs |  |  | 75 |  |  |  | 112 |  |
| Russia-Ukraine war costs |  |  | 3 |  |  |  | — |  |
| Significant asset impairments and restructurings |  |  | (2 | ) |  |  | 5 |  |
| Total adjustments to GAAP operating expenses |  |  | 562 |  |  |  | 584 |  |
| Adjustments to interest and other income (loss), net: |  |  |  |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | 109 |  |  |  | (219 | ) |
| Total adjustments to GAAP interest and other income (loss), net |  |  | 109 |  |  |  | (219 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 907 |  |  |  | 633 |  |
| Income tax effect of non-GAAP adjustments |  |  | (192 | ) |  |  | (138 | ) |
| Significant tax matters |  |  | 164 |  |  |  | — |  |
| Total adjustments to GAAP provision for income taxes |  |  | (28 | ) |  |  | (138 | ) |
| Non-GAAP net income |  | $ | 3,549 |  |  | $ | 3,475 |  |

[0001193125-22-286782:8k_2_02:118]
10

[0001193125-22-286782:8k_2_02:119]
CISCO SYSTEMS, INC.

[0001193125-22-286782:8k_2_02:120]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-22-286782:8k_2_02:121]
GAAP TO NON-GAAP EPS

[0001193125-22-286782:8k_2_02:122]
|  |  | Three Months Ended |  |
|  |  | October 29,2022 |  |  | October 30,2021 |  |
| GAAP EPS |  | $ | 0.65 |  |  | $ | 0.70 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.12 |  |  |  | 0.11 |  |
| Amortization of acquisition-related intangible assets |  |  | 0.05 |  |  |  | 0.07 |  |
| Acquisition-related/divestiture costs |  |  | 0.02 |  |  |  | 0.03 |  |
| (Gains) and losses on equity investments |  |  | 0.03 |  |  |  | (0.05 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.05 | ) |  |  | (0.03 | ) |
| Significant tax matters |  |  | 0.04 |  |  |  | — |  |
| Non-GAAP EPS |  | $ | 0.86 |  |  | $ | 0.82 |  |

[0001193125-22-286782:8k_2_02:123]
Amounts may not sum due to rounding.

[0001193125-22-286782:8k_2_02:124]
11

[0001193125-22-286782:8k_2_02:125]
CISCO SYSTEMS, INC.

[0001193125-22-286782:8k_2_02:126]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-22-286782:8k_2_02:127]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET,

[0001193125-22-286782:8k_2_02:128]
AND NET INCOME

[0001193125-22-286782:8k_2_02:129]
(In
millions, except percentages)

[0001193125-22-286782:8k_2_02:130]
|  |  | Three Months Ended |  |
|  |  | October 29, 2022 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 6,066 |  |  | $ | 2,280 |  |  | $ | 8,346 |  |  | $ | 4,806 |  |  |  | 4 | % |  | $ | 3,540 |  |  |  | 3 | % |  | $ | (65 | ) |  | $ | 2,670 |  |  |  | (10 | )% |
| % of revenue |  |  | 59.2 | % |  |  | 67.3 | % |  |  | 61.2 | % |  |  | 35.3 | % |  |  |  |  |  |  | 26.0 | % |  |  |  |  |  |  | (0.5 | )% |  |  | 19.6 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 31 |  |  |  | 50 |  |  |  | 81 |  |  |  | 415 |  |  |  |  |  |  |  | 496 |  |  |  |  |  |  |  | — |  |  |  | 496 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 153 |  |  |  | — |  |  |  | 153 |  |  |  | 71 |  |  |  |  |  |  |  | 224 |  |  |  |  |  |  |  | — |  |  |  | 224 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 2 |  |  |  | — |  |  |  | 2 |  |  |  | 75 |  |  |  |  |  |  |  | 77 |  |  |  |  |  |  |  | — |  |  |  | 77 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  |  |  |  |  | (2 | ) |  |  |  |  |  |  | — |  |  |  | (2 | ) |  |  |  |  |
| Russia-Ukraine war costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  |  |  |  |  | 3 |  |  |  |  |  |  |  | — |  |  |  | 3 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 109 |  |  |  | 109 |  |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (28 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 6,252 |  |  | $ | 2,330 |  |  | $ | 8,582 |  |  | $ | 4,244 |  |  |  | 5 | % |  | $ | 4,338 |  |  |  | 1 | % |  | $ | 44 |  |  | $ | 3,549 |  |  |  | 2 | % |
| % of revenue |  |  | 61.0 | % |  |  | 68.8 | % |  |  | 63.0 | % |  |  | 31.1 | % |  |  |  |  |  |  | 31.8 | % |  |  |  |  |  |  | 0.3 | % |  |  | 26.0 | % |  |  |  |  |

[0001193125-22-286782:8k_2_02:131]
|  |  | Three Months Ended |  |
|  |  | October 30, 2021 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 5,856 |  |  | $ | 2,197 |  |  | $ | 8,053 |  |  | $ | 4,615 |  |  | $ | 3,438 |  |  | $ | 219 |  |  | $ | 2,980 |  |
| % of revenue |  |  | 61.5 | % |  |  | 65.2 | % |  |  | 62.4 | % |  |  | 35.8 | % |  |  | 26.7 | % |  |  | 1.7 | % |  |  | 23.1 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 25 |  |  |  | 44 |  |  |  | 69 |  |  |  | 383 |  |  |  | 452 |  |  |  | — |  |  |  | 452 |  |
| Amortization of acquisition-related intangible assets |  |  | 198 |  |  |  | — |  |  |  | 198 |  |  |  | 84 |  |  |  | 282 |  |  |  | — |  |  |  | 282 |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 112 |  |  |  | 113 |  |  |  | — |  |  |  | 113 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | 5 |  |  |  | — |  |  |  | 5 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (219 | ) |  |  | (219 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (138 | ) |
| Non-GAAP amount |  | $ | 6,080 |  |  | $ | 2,241 |  |  | $ | 8,321 |  |  | $ | 4,031 |  |  | $ | 4,290 |  |  | $ | — |  |  | $ | 3,475 |  |
| % of revenue |  |  | 63.8 | % |  |  | 66.5 | % |  |  | 64.5 | % |  |  | 31.2 | % |  |  | 33.3 | % |  |  | — | % |  |  | 26.9 | % |

[0001193125-22-286782:8k_2_02:132]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-22-286782:8k_2_02:133]
12

[0001193125-22-286782:8k_2_02:134]
CISCO SYSTEMS, INC.

[0001193125-22-286782:8k_2_02:135]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-22-286782:8k_2_02:136]
EFFECTIVE TAX RATE

[0001193125-22-286782:8k_2_02:137]
(In
percentages)

[0001193125-22-286782:8k_2_02:138]
|  |  | Three Months Ended |  |
|  |  | October 29,2022 |  |  | October 30,2021 |  |
| GAAP effective tax rate |  |  | 23.2 | % |  |  | 18.5 | % |
| Total adjustments to GAAP provision for income taxes |  |  | (4.2 | )% |  |  | 0.5 | % |
| Non-GAAP effective tax rate |  |  | 19.0 | % |  |  | 19.0 | % |

[0001193125-22-286782:8k_2_02:139]
GAAP TO NON-GAAP GUIDANCE

[0001193125-22-286782:8k_2_02:140]
| Q2 FY 2023 |  | Gross MarginRate |  | Operating MarginRate |  | Earnings perShare (2) |
| GAAP |  | 61% - 62% |  | 22.5% - 23.5% |  | $0.59 - $0.64 |
| Estimated adjustments for: |  |  |  |  |  |  |
| Share-based compensation expense |  | 1.0% |  | 4.5% |  | $0.12 - $0.13 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 1.0% |  | 2.0% |  | $0.05 - $0.06 |
| Significant asset impairments and restructurings (1) |  | — |  | 2.5% |  | $0.05 - $0.06 |
| Non-GAAP |  | 63% - 64% |  | 31.5% -32.5% |  | $0.84 - $0.86 |

[0001193125-22-286782:8k_2_02:141]
| FY 2023 |  | Earnings perShare (2) |
| GAAP |  | $2.63 - $2.76 |
| Estimated adjustments for: |  |  |
| Share-based compensation expense |  | $0.46 - $0.48 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | $0.21 - $0.23 |
| Significant asset impairments and restructurings (1) |  | $0.09 - $0.11 |
| (Gains) and losses on equity investments |  | $0.02 |
| Significant tax matters |  | $0.04 |
| Non-GAAP |  | $3.51 - $3.58 |

[0001193125-22-286782:8k_2_02:142]
| (1) | On November 16, 2022, Cisco announced a restructuring plan in order to rebalance the organization and enable further investment in key priority areas. This rebalancing will include talent movement options and restructuring. Additionally, Cisco will optimize its real estate portfolio, aligned to the broader hybrid work strategy. Cisco will take action under this plan beginning in the second quarter of fiscal 2023. Cisco currently estimates that it will recognize pre-tax charges to its GAAP financial results of approximately $600 million consisting of severance and other one-time termination benefits, real estate-related charges, and other costs. These charges are primarily cash-based. Cisco expects to recognize approximately $300 million of these charges in the second quarter of fiscal 2023, approximately $200 million of these charges during the second half of fiscal 2023, and the remaining amount of these charges primarily through the first quarter of fiscal 2024. |

[0001193125-22-286782:8k_2_02:143]
| (2) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-22-286782:8k_2_02:144]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, Russia-Ukraine war costs,
restructurings, (gains) and losses on equity investments and significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-22-286782:8k_2_02:145]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-22-286782:8k_2_02:146]
This release includes non-GAAP net income, non-GAAP gross
margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax rates, non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross margin,
operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-22-286782:8k_2_02:147]
These
non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles and may be different from
non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes
that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should
only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-22-286782:8k_2_02:148]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition
and its historical and projected results of operations.

[0001193125-22-286782:8k_2_02:149]
For its internal budgeting process, Cisco’s management uses financial statements that do not
include, when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other
contingencies, Russia-Ukraine war costs, gains and losses on equity investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP
measures, in addition to the corresponding GAAP measures, in reviewing the

[0001193125-22-286782:8k_2_02:150]
14

[0001193125-22-286782:8k_2_02:151]
financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures.
From time to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-22-286782:8k_2_02:152]
Annualized recurring revenue represents the annualized revenue run-rate of active subscriptions, term licenses, and
maintenance contracts at the end of a reporting period, net of rebates to customers and partners as well as certain other revenue adjustments. Includes both revenue recognized ratably as well as upfront on an annualized basis.

[0001193125-22-286782:8k_2_02:153]
About Cisco

[0001193125-22-286782:8k_2_02:154]
Cisco (Nasdaq: CSCO) is the worldwide
leader in technology that powers the Internet. Cisco inspires new possibilities by reimagining your applications, securing your data, transforming your infrastructure, and empowering your teams for a global and inclusive future.
Discover more at newsroom.cisco.com and follow us on Twitter at @Cisco.

[0001193125-22-286782:8k_2_02:155]
Copyright © 2022 Cisco
and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks.
Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-22-286782:8k_2_02:156]
RSS Feed for Cisco: https://newsroom.cisco.com/rss-feeds
