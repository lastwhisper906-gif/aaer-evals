# CSCO MD&A — 0000858877-22-000025


## mdna

[0000858877-22-000025:mdna:1]
[same as prior period, unchanged from 0000858877-22-000009:mdna:1]

[0000858877-22-000025:mdna:2]
[same as prior period, unchanged from 0000858877-22-000009:mdna:2]

[0000858877-22-000025:mdna:3]
[same as prior period, unchanged from 0000858877-22-000009:mdna:3]

[0000858877-22-000025:mdna:4]
[same as prior period, unchanged from 0000858877-22-000009:mdna:4]

[0000858877-22-000025:mdna:5]
[same as prior period, unchanged from 0000858877-22-000009:mdna:5]

[0000858877-22-000025:mdna:6]
|  | Three Months Ended |  |
|  | October 29,2022 |  | October 30,2021 |  | % Variance |  |
| Revenue | $ | 13,632 |  |  | $ | 12,900 |  |  | 6 | % |  |
| Gross margin percentage | 61.2 | % |  | 62.4 | % |  | (1.2) |  | pts |
| Research and development | $ | 1,781 |  |  | $ | 1,714 |  |  | 4 | % |  |
| Sales and marketing | $ | 2,391 |  |  | $ | 2,261 |  |  | 6 | % |  |
| General and administrative | $ | 565 |  |  | $ | 551 |  |  | 3 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,737 |  |  | $ | 4,526 |  |  | 5 | % |  |
| Total as a percentage of revenue | 34.7 | % |  | 35.1 | % |  | (0.4) |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 71 |  |  | $ | 84 |  |  | (15) | % |  |
| Restructuring and other charges included in operating expenses | $ | (2) |  |  | $ | 5 |  |  | (132) | % |  |
| Operating income as a percentage of revenue | 26.0 | % |  | 26.7 | % |  | (0.7) |  | pts |
| Interest and other income (loss), net | $ | (65) |  |  | $ | 219 |  |  | (130) | % |  |
| Income tax percentage | 23.2 | % |  | 18.5 | % |  | 4.7 |  | pts |
| Net income | $ | 2,670 |  |  | $ | 2,980 |  |  | (10) | % |  |
| Net income as a percentage of revenue | 19.6 | % |  | 23.1 | % |  | (3.5) |  | pts |
| Earnings per share—diluted | $ | 0.65 |  |  | $ | 0.70 |  |  | (7) | % |  |

[0000858877-22-000025:mdna:7]
Percentages may not recalculate due to rounding.

[0000858877-22-000025:mdna:8]
[same as prior period, unchanged from 0000858877-22-000009:mdna:7]

[0000858877-22-000025:mdna:9]
[same as prior period, unchanged from 0000858877-22-000009:mdna:8]

[0000858877-22-000025:mdna:10]
Three Months Ended October 29, 2022 Compared with Three Months Ended October 30, 2021

[0000858877-22-000025:mdna:11]
In the first quarter of fiscal 2023, we delivered strong results with growth in total revenue. We remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformations. We have, and continue to take, multiple steps in order to mitigate the component shortages and deliver products to our customers in order to address supply constraints seen industry-wide. While we did see continued modest easing of the supply constraints during the first quarter of fiscal 2023, we expect the constraints to continue and the duration is uncertain. We continued to make progress in the transition of our business model delivering increased software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-22-000025:mdna:12]
Total revenue increased by 6% compared with the first quarter of fiscal 2022. Within total revenue, product revenue increased by 8% and service revenue was flat. In the first quarter of fiscal 2023, total software revenue was $3.9 billion across all product areas and service, an increase of 5%. Within total software revenue, subscription revenue increased 11%. Total gross margin decreased by 1.2 percentage points. Product gross margin decreased by 2.3 percentage points, largely driven by increased costs related to supply constraints, partially offset by favorable pricing and product mix. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 0.4 percentage points. Operating income as a percentage of revenue decreased by 0.7 percentage points. Diluted earnings per share decreased 7%, driven by a decrease of 10% in net income, partially offset by a decrease in diluted share count of 127 million shares.

[0000858877-22-000025:mdna:13]
In terms of our geographic segments, revenue from the Americas increased $353 million, EMEA revenue increased by $372 million and APJC revenue increased by $7 million. Although total revenue increased, we saw a decline in product demand compared to the first quarter of fiscal 2022. The decline was against the comparable prior year period in which we experienced unusually high demand.

[0000858877-22-000025:mdna:14]
From a customer market standpoint, we experienced product revenue growth in the commercial, enterprise and public sector markets. The service provider market was flat.

[0000858877-22-000025:mdna:15]
From a product category perspective, the product revenue increase of 8% was driven by growth in revenue for Secure, Agile Networks of 12%; End-to-End Security of 9%; and Optimized Application Experiences of 7%; partially offset by a product revenue decline in Internet for the Future of 5% and Collaboration of 2%.

[0000858877-22-000025:mdna:16]
[same as prior period, unchanged from 0000858877-22-000009:mdna:18]

[0000858877-22-000025:mdna:17]
[same as prior period, unchanged from 0000858877-22-000009:mdna:19]

[0000858877-22-000025:mdna:18]
[same as prior period, unchanged from 0000858877-22-000009:mdna:26]

[0000858877-22-000025:mdna:19]
As our customers add billions of new connections to their enterprises, and as more applications move to a multicloud environment, the network becomes even more critical. Our customers are navigating change at an unprecedented pace. In this dynamic environment, we believe their priorities are to reimagine applications, power hybrid work, transform infrastructure, and secure the enterprise. Our strategy is to help our customers connect, secure, and automate to accelerate their digital agility in a cloud-first world. We are committed to driving a trusted customer experience, through our innovation, choice, and people.

[0000858877-22-000025:mdna:20]
For additional discussion of our strategy and priorities, see Item 1. Business in our Annual Report on Form 10-K for the year ended July 30, 2022.

[0000858877-22-000025:mdna:21]
[same as prior period, unchanged from 0000858877-22-000009:mdna:29]

[0000858877-22-000025:mdna:22]
The following is a summary of our other key financial measures for the first quarter of fiscal 2023 (in millions):

[0000858877-22-000025:mdna:23]
|  |  | October 29,2022 |  | July 30,2022 |
| Cash and cash equivalents and investments |  | $ | 19,784 |  |  | $ | 19,267 |  |
| Remaining performance obligations |  | $ | 30,910 |  |  | $ | 31,539 |  |
| Inventories |  | $ | 2,664 |  |  | $ | 2,568 |  |

[0000858877-22-000025:mdna:24]
|  |  | Three Months Ended |
|  |  | October 29,2022 |  | October 30,2021 |
| Cash provided by operating activities |  | $ | 3,962 |  |  | $ | 3,427 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 502 |  |  | $ | 256 |  |
| Dividends paid |  | $ | 1,560 |  |  | $ | 1,561 |  |

[0000858877-22-000025:mdna:25]
[same as prior period, unchanged from 0000858877-22-000009:mdna:33]

[0000858877-22-000025:mdna:26]
[same as prior period, unchanged from 0000858877-22-000009:mdna:34]

[0000858877-22-000025:mdna:27]
[same as prior period, unchanged from 0000858877-22-000009:mdna:35]

[0000858877-22-000025:mdna:28]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements in our Annual Report on Form 10-K for the year ended July 30, 2022, as updated as applicable in Note 2 to the Consolidated Financial Statements herein, describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-22-000025:mdna:29]
[same as prior period, unchanged from 0000858877-22-000009:mdna:38]

[0000858877-22-000025:mdna:30]
[same as prior period, unchanged from 0000858877-22-000009:mdna:39]

[0000858877-22-000025:mdna:31]
[same as prior period, unchanged from 0000858877-22-000009:mdna:40]

[0000858877-22-000025:mdna:32]
[same as prior period, unchanged from 0000858877-22-000009:mdna:41]

[0000858877-22-000025:mdna:33]
[same as prior period, unchanged from 0000858877-22-000009:mdna:42]

[0000858877-22-000025:mdna:34]
[same as prior period, unchanged from 0000858877-22-000009:mdna:46]

[0000858877-22-000025:mdna:35]
[same as prior period, unchanged from 0000858877-22-000009:mdna:47]

[0000858877-22-000025:mdna:36]
Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and net realizable value, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-22-000025:mdna:37]
[same as prior period, unchanged from 0000858877-22-000009:mdna:44]

[0000858877-22-000025:mdna:38]
[same as prior period, unchanged from 0000858877-22-000009:mdna:45]

[0000858877-22-000025:mdna:39]
[same as prior period, unchanged from 0000858877-22-000009:mdna:49]

[0000858877-22-000025:mdna:40]
Our provision for inventory was $38 million and $22 million for the first quarter of fiscal 2023 and 2022, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $83 million and $47 million for the first quarter of fiscal 2023 and 2022, respectively. If there were to be a sudden and significant decrease in demand for our products, if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, or if supply constraints were to continue, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. While we have seen modest easing, we continue to manage through significant supply constraints seen industry-wide due to component shortages caused, in part, by the COVID-19 pandemic. For further discussion around the Supply Constraints Impacts and Risks, see “Result of Operations—Gross Margin—Supply Constraints Impact and Risks” and “Liquidity and Capital Resources—Inventory Supply Chain.”

[0000858877-22-000025:mdna:41]
Loss Contingencies

[0000858877-22-000025:mdna:42]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-22-000025:mdna:43]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-22-000025:mdna:44]
[same as prior period, unchanged from 0000858877-22-000009:mdna:54]

[0000858877-22-000025:mdna:45]
[same as prior period, unchanged from 0000858877-22-000009:mdna:55]

[0000858877-22-000025:mdna:46]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in the first quarters of fiscal 2023 and 2022.

[0000858877-22-000025:mdna:47]
[same as prior period, unchanged from 0000858877-22-000009:mdna:57]

[0000858877-22-000025:mdna:48]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business

[0000858877-22-000025:mdna:49]
[same as prior period, unchanged from 0000858877-22-000009:mdna:58]

[0000858877-22-000025:mdna:50]
[same as prior period, unchanged from 0000858877-22-000009:mdna:59]

[0000858877-22-000025:mdna:51]
strategy and our internal forecasts. Our ongoing consideration of all the factors described previously could result in impairment charges in the future, which could adversely affect our net income.

[0000858877-22-000025:mdna:52]
[same as prior period, unchanged from 0000858877-22-000009:mdna:62]

[0000858877-22-000025:mdna:53]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was 23.2% and 18.5% in the first quarter of fiscal 2023 and 2022, respectively.

[0000858877-22-000025:mdna:54]
[same as prior period, unchanged from 0000858877-22-000009:mdna:64]

[0000858877-22-000025:mdna:55]
[same as prior period, unchanged from 0000858877-22-000009:mdna:65]

[0000858877-22-000025:mdna:56]
[same as prior period, unchanged from 0000858877-22-000009:mdna:66]

[0000858877-22-000025:mdna:57]
[same as prior period, unchanged from 0000858877-22-000009:mdna:67]

[0000858877-22-000025:mdna:58]
[same as prior period, unchanged from 0000858877-22-000009:mdna:68]

[0000858877-22-000025:mdna:59]
[same as prior period, unchanged from 0000858877-22-000009:mdna:69]

[0000858877-22-000025:mdna:60]
[same as prior period, unchanged from 0000858877-22-000009:mdna:70]

[0000858877-22-000025:mdna:61]
[same as prior period, unchanged from 0000858877-22-000009:mdna:71]

[0000858877-22-000025:mdna:62]
|  |  | Three Months Ended |
|  |  | October 29,2022 |  | October 30,2021 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 10,245 |  |  | $ | 9,529 |  |  | $ | 716 |  |  | 8 | % |
| Percentage of revenue |  | 75.2 | % |  | 73.9 | % |  |  |  |  |
| Service |  | 3,387 |  |  | 3,371 |  |  | 16 |  |  | — | % |
| Percentage of revenue |  | 24.8 | % |  | 26.1 | % |  |  |  |  |
| Total |  | $ | 13,632 |  |  | $ | 12,900 |  |  | $ | 732 |  |  | 6 | % |

[0000858877-22-000025:mdna:63]
[same as prior period, unchanged from 0000858877-22-000009:mdna:73]

[0000858877-22-000025:mdna:64]
|  |  | Three Months Ended |
|  |  | October 29,2022 |  | October 30,2021 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,914 |  |  | $ | 7,561 |  |  | $ | 353 |  |  | 5 | % |
| Percentage of revenue |  | 58.0 | % |  | 58.6 | % |  |  |  |  |
| EMEA |  | 3,675 |  |  | 3,303 |  |  | 372 |  |  | 11 | % |
| Percentage of revenue |  | 27.0 | % |  | 25.6 | % |  |  |  |  |
| APJC |  | 2,043 |  |  | 2,036 |  |  | 7 |  |  | — | % |
| Percentage of revenue |  | 15.0 | % |  | 15.8 | % |  |  |  |  |
| Total |  | $ | 13,632 |  |  | $ | 12,900 |  |  | $ | 732 |  |  | 6 | % |

[0000858877-22-000025:mdna:65]
[same as prior period, unchanged from 0000858877-22-000009:mdna:75]

[0000858877-22-000025:mdna:66]
Three Months Ended October 29, 2022 Compared with Three Months Ended October 30, 2021

[0000858877-22-000025:mdna:67]
Total revenue increased by 6%. Product revenue increased by 8% and service revenue was flat. Our total revenue reflected growth in the Americas and EMEA segments. The APJC segment was flat.

[0000858877-22-000025:mdna:68]
[same as prior period, unchanged from 0000858877-22-000009:mdna:79]

[0000858877-22-000025:mdna:69]
[same as prior period, unchanged from 0000858877-22-000009:mdna:82]

[0000858877-22-000025:mdna:70]
[same as prior period, unchanged from 0000858877-22-000009:mdna:83]

[0000858877-22-000025:mdna:71]
[same as prior period, unchanged from 0000858877-22-000009:mdna:84]

[0000858877-22-000025:mdna:72]
[same as prior period, unchanged from 0000858877-22-000009:mdna:85]

[0000858877-22-000025:mdna:73]
|  |  | Three Months Ended |
|  |  | October 29,2022 |  | October 30,2021 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,846 |  |  | $ | 5,522 |  |  | $ | 324 |  |  | 6 | % |
| Percentage of product revenue |  | 57.0 | % |  | 57.9 | % |  |  |  |  |
| EMEA |  | 2,886 |  |  | 2,513 |  |  | 373 |  |  | 15 | % |
| Percentage of product revenue |  | 28.2 | % |  | 26.4 | % |  |  |  |  |
| APJC |  | 1,513 |  |  | 1,495 |  |  | 18 |  |  | 1 | % |
| Percentage of product revenue |  | 14.8 | % |  | 15.7 | % |  |  |  |  |
| Total |  | $ | 10,245 |  |  | $ | 9,529 |  |  | $ | 716 |  |  | 8 | % |

[0000858877-22-000025:mdna:74]
[same as prior period, unchanged from 0000858877-22-000009:mdna:87]

[0000858877-22-000025:mdna:75]
Three Months Ended October 29, 2022 Compared with Three Months Ended October 30, 2021

[0000858877-22-000025:mdna:76]
[same as prior period, unchanged from 0000858877-22-000009:mdna:88]

[0000858877-22-000025:mdna:77]
Product revenue in the Americas segment increased by 6%, with growth in the commercial, enterprise and service provider markets, partially offset by a decline in the public sector market. From a country perspective, product revenue increased in the United States, Canada, Mexico and Brazil by 5%, 14%, 24% and 15%, respectively.

[0000858877-22-000025:mdna:78]
[same as prior period, unchanged from 0000858877-22-000009:mdna:93]

[0000858877-22-000025:mdna:79]
Product revenue in the EMEA segment increased by 15%, driven by growth across all customer markets. From a country perspective, product revenue increased in Germany, the United Kingdom and France by 19%, 6% and 30%, respectively.

[0000858877-22-000025:mdna:80]
[same as prior period, unchanged from 0000858877-22-000009:mdna:98]

[0000858877-22-000025:mdna:81]
Product revenue in the APJC segment increased by 1%, driven by growth in the commercial market, partially offset by declines in the enterprise, service provider and public sector markets. From a country perspective, product revenue increased in India and China by 40% and 33%, respectively, partially offset by declines in Japan and Australia of 10% and 6%, respectively.

[0000858877-22-000025:mdna:82]
[same as prior period, unchanged from 0000858877-22-000009:mdna:101]

[0000858877-22-000025:mdna:83]
[same as prior period, unchanged from 0000858877-22-000009:mdna:102]

[0000858877-22-000025:mdna:84]
[same as prior period, unchanged from 0000858877-22-000009:mdna:105]

[0000858877-22-000025:mdna:85]
In addition to the primary view on a geographic basis, we also prepare financial information related to product categories and customer markets for various purposes.

[0000858877-22-000025:mdna:86]
[same as prior period, unchanged from 0000858877-22-000009:mdna:107]

[0000858877-22-000025:mdna:87]
|  |  | Three Months Ended |
|  |  | October 29,2022 |  | October 30,2021 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Secure, Agile Networks |  | $ | 6,684 |  |  | $ | 5,968 |  |  | $ | 716 |  |  | 12 | % |
| Internet for the Future |  | 1,310 |  |  | 1,373 |  |  | (63) |  |  | (5) | % |
| Collaboration |  | 1,086 |  |  | 1,109 |  |  | (23) |  |  | (2) | % |
| End-to-End Security |  | 971 |  |  | 895 |  |  | 76 |  |  | 9 | % |
| Optimized Application Experiences |  | 193 |  |  | 181 |  |  | 12 |  |  | 7 | % |
| Other Products |  | 2 |  |  | 3 |  |  | (1) |  |  | (47) | % |
| Total |  | $ | 10,245 |  |  | $ | 9,529 |  |  | $ | 716 |  |  | 8 | % |

[0000858877-22-000025:mdna:88]
[same as prior period, unchanged from 0000858877-22-000009:mdna:109]

[0000858877-22-000025:mdna:89]
Three Months Ended October 29, 2022 Compared with Three Months Ended October 30, 2021

[0000858877-22-000025:mdna:90]
[same as prior period, unchanged from 0000858877-22-000009:mdna:110]

[0000858877-22-000025:mdna:91]
The Secure, Agile Networks product category represents our core networking offerings related to switching, enterprise routing, wireless, and compute. Secure, Agile Networks revenue increased by 12%, or $716 million, with growth in switching and wireless, partially offset by declines in enterprise routing and servers. Revenue grew in campus switching, primarily driven by strong growth in our Catalyst 9000 series and Meraki switching offerings. Data center revenue declined, although we had revenue growth in our Nexus 9000 series. We experienced a decrease in sales of our enterprise routing products primarily driven by declines related to the product transition taking place within our ASR 1000 offerings as well as supply constraints. Wireless had double-digit growth driven by our WiFi-6 products and Meraki offerings.

[0000858877-22-000025:mdna:92]
[same as prior period, unchanged from 0000858877-22-000009:mdna:115]

[0000858877-22-000025:mdna:93]
The Internet for the Future product category includes our routed optical networking, public 5G, silicon and optics offerings. Revenue in our Internet for the Future product category decreased by 5%, or $63 million, primarily driven by declines in our Cable, Optical and Edge portfolio. We saw growth in the webscale provider market and in our Cisco 8000 series offerings.

[0000858877-22-000025:mdna:94]
[same as prior period, unchanged from 0000858877-22-000009:mdna:122]

[0000858877-22-000025:mdna:95]
The Collaboration product category consists of our Collaboration Devices, Meetings, Calling and contact center offerings. Revenue in our Collaboration product category decreased by 2%, or $23 million, driven by declines in Meetings, partially offset by growth in Calling.

[0000858877-22-000025:mdna:96]
[same as prior period, unchanged from 0000858877-22-000009:mdna:127]

[0000858877-22-000025:mdna:97]
Revenue in our End-to-End Security product category increased 9%, or $76 million primarily driven by growth in our Unified Threat Management and Zero Trust offerings. The double-digit growth in our Zero Trust portfolio was driven by strong growth in our Duo offerings.

[0000858877-22-000025:mdna:98]
[same as prior period, unchanged from 0000858877-22-000009:mdna:132]

[0000858877-22-000025:mdna:99]
The Optimized Application Experiences product category includes our full stack observability and cloud-native platforms offerings. Revenue in our Optimized Application Experiences product category increased 7%, or $12 million, driven by growth in our ThousandEyes offerings.

[0000858877-22-000025:mdna:100]
[same as prior period, unchanged from 0000858877-22-000009:mdna:118]

[0000858877-22-000025:mdna:101]
[same as prior period, unchanged from 0000858877-22-000009:mdna:119]

[0000858877-22-000025:mdna:102]
[same as prior period, unchanged from 0000858877-22-000009:mdna:140]

[0000858877-22-000025:mdna:103]
[same as prior period, unchanged from 0000858877-22-000009:mdna:141]

[0000858877-22-000025:mdna:104]
|  |  | Three Months Ended |
|  |  | October 29,2022 |  | October 30,2021 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,067 |  |  | $ | 2,039 |  |  | $ | 28 |  |  | 1 | % |
| Percentage of service revenue |  | 61.0 | % |  | 60.5 | % |  |  |  |  |
| EMEA |  | 789 |  |  | 790 |  |  | (1) |  |  | — | % |
| Percentage of service revenue |  | 23.3 | % |  | 23.4 | % |  |  |  |  |
| APJC |  | 530 |  |  | 541 |  |  | (11) |  |  | (2) | % |
| Percentage of service revenue |  | 15.7 | % |  | 16.1 | % |  |  |  |  |
| Total |  | $ | 3,387 |  |  | $ | 3,371 |  |  | $ | 16 |  |  | — | % |

[0000858877-22-000025:mdna:105]
[same as prior period, unchanged from 0000858877-22-000009:mdna:143]

[0000858877-22-000025:mdna:106]
Service revenue was flat in the first quarter of fiscal 2023 compared with the first quarter of fiscal 2022, primarily driven by revenue growth in our solution support offerings and maintenance business, offset by declines in our advisory services and software support offerings. Service revenue increased in the Americas segment, offset by a decline in the APJC segment. Service revenue in the EMEA segment was flat.

[0000858877-22-000025:mdna:107]
[same as prior period, unchanged from 0000858877-22-000009:mdna:146]

[0000858877-22-000025:mdna:108]
[same as prior period, unchanged from 0000858877-22-000009:mdna:147]

[0000858877-22-000025:mdna:109]
|  |  | Three Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |
|  |  | October 29,2022 |  | October 30,2021 |  | October 29,2022 |  | October 30,2021 |
| Gross margin: |  |  |  |  |  |  |  |  |
| Product |  | $ | 6,066 |  |  | $ | 5,856 |  |  | 59.2 | % |  | 61.5 | % |
| Service |  | 2,280 |  |  | 2,197 |  |  | 67.3 | % |  | 65.2 | % |
| Total |  | $ | 8,346 |  |  | $ | 8,053 |  |  | 61.2 | % |  | 62.4 | % |

[0000858877-22-000025:mdna:110]
[same as prior period, unchanged from 0000858877-22-000009:mdna:151]

[0000858877-22-000025:mdna:111]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the first quarter of fiscal 2023, as compared with the corresponding prior year periods:

[0000858877-22-000025:mdna:112]
|  |  | Product Gross Margin Percentage |
| Fiscal 2022 |  | 61.5 | % |
| Productivity (1) |  | (4.4) | % |
| Product pricing |  | 1.3 | % |
| Mix of products sold |  | 0.4 | % |
| Others |  | 0.4 | % |
| Fiscal 2023 |  | 59.2 | % |

[0000858877-22-000025:mdna:113]
[same as prior period, unchanged from 0000858877-22-000009:mdna:154]

[0000858877-22-000025:mdna:114]
Three Months Ended October 29, 2022 Compared with Three Months Ended October 30, 2021

[0000858877-22-000025:mdna:115]
Product gross margin decreased by 2.3 percentage points primarily driven by negative impacts from productivity, largely driven by increased costs related to supply constraints from component, freight and logistics costs. These impacts were partially offset

[0000858877-22-000025:mdna:116]
[same as prior period, unchanged from 0000858877-22-000009:mdna:138]

[0000858877-22-000025:mdna:117]
[same as prior period, unchanged from 0000858877-22-000009:mdna:139]

[0000858877-22-000025:mdna:118]
by favorable pricing. The benefit we saw from favorable pricing was primarily driven by price increases implemented during fiscal 2022, to partially offset increases in components and commodity costs, freight and logistics costs, driven by supply constraints. We also saw benefits from product mix.

[0000858877-22-000025:mdna:119]
[same as prior period, unchanged from 0000858877-22-000009:mdna:159]

[0000858877-22-000025:mdna:120]
While we have seen modest easing, we continue to manage through significant supply constraints seen industry-wide due to component shortages caused, in part, by the COVID-19 pandemic, and for which the duration of such constraints is uncertain. These shortages have resulted in increased costs (i.e., component and other commodity costs, freight, expedite fees, etc.) which have had a negative impact on our product gross margin and have resulted in extended lead times for us and our customers. We have taken a number of steps in order to mitigate the supply constraint related impacts including: partnering with several of our key suppliers utilizing our volume purchasing ability and extending supply coverage, including, in certain cases, revising supplier arrangements; paying significantly higher component and logistics costs to secure supply; modifying our product designs in order to leverage alternate suppliers, where possible; and continually optimizing our inventory build and customer delivery plans, among others. We believe these actions are helping us to optimize our access to critical components and meet customer demand for our products. As a result, in order to secure supply to meet customer demand, we have increased our inventory balances, inventory purchase commitments, and inventory deposits and prepayments (see “Liquidity and Capital Resources—Inventory Supply Chain”), which, in turn, has increased our supply chain exposure. Additionally, in certain situations, we have prepaid or made deposits with suppliers to secure future supply. These actions significantly increase the risk of future material excess and obsolete inventory and related losses if customer demand were to suddenly and significantly decrease in future periods. While we believe we are taking the right strategic and operational actions to address the supply situation, we recognize the increased risks.

[0000858877-22-000025:mdna:121]
[same as prior period, unchanged from 0000858877-22-000009:mdna:161]

[0000858877-22-000025:mdna:122]
Three Months Ended October 29, 2022 Compared with Three Months Ended October 30, 2021

[0000858877-22-000025:mdna:123]
Our service gross margin percentage increased by 2.1 percentage points primarily due to lower headcount-related and delivery costs, favorable mix of service offerings, and to a lesser extent, higher sales volume.

[0000858877-22-000025:mdna:124]
Our service gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-22-000025:mdna:125]
[same as prior period, unchanged from 0000858877-22-000009:mdna:170]

[0000858877-22-000025:mdna:126]
[same as prior period, unchanged from 0000858877-22-000009:mdna:171]

[0000858877-22-000025:mdna:127]
|  | Three Months Ended |
|  | AMOUNT |  | PERCENTAGE |
|  | October 29,2022 |  | October 30,2021 |  | October 29,2022 |  | October 30,2021 |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,984 |  |  | $ | 4,875 |  |  | 63.0 | % |  | 64.5 | % |
| EMEA | 2,325 |  |  | 2,128 |  |  | 63.3 | % |  | 64.4 | % |
| APJC | 1,274 |  |  | 1,317 |  |  | 62.3 | % |  | 64.7 | % |
| Segment total | 8,582 |  |  | 8,321 |  |  | 63.0 | % |  | 64.5 | % |
| Unallocated corporate items (1) | (236) |  |  | (268) |  |  |  |  |  |
| Total | $ | 8,346 |  |  | $ | 8,053 |  |  | 61.2 | % |  | 62.4 | % |

[0000858877-22-000025:mdna:128]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-22-000025:mdna:129]
[same as prior period, unchanged from 0000858877-22-000009:mdna:174]

[0000858877-22-000025:mdna:130]
48

[0000858877-22-000025:mdna:131]
[same as prior period, unchanged from 0000858877-22-000009:mdna:149]

[0000858877-22-000025:mdna:132]
[same as prior period, unchanged from 0000858877-22-000009:mdna:150]

[0000858877-22-000025:mdna:133]
Three Months Ended October 29, 2022 Compared with Three Months Ended October 30, 2021

[0000858877-22-000025:mdna:134]
We experienced a gross margin percentage decrease in our Americas segment due to negative impacts from productivity, partially offset by favorable pricing and favorable product mix.

[0000858877-22-000025:mdna:135]
Gross margin in our EMEA segment decreased primarily due to negative impacts from productivity, and to a lesser extent, unfavorable impacts from product mix, partially offset by favorable pricing.

[0000858877-22-000025:mdna:136]
The APJC segment gross margin percentage decrease was primarily due to negative impacts from productivity.

[0000858877-22-000025:mdna:137]
[same as prior period, unchanged from 0000858877-22-000009:mdna:179]

[0000858877-22-000025:mdna:138]
[same as prior period, unchanged from 0000858877-22-000009:mdna:186]

[0000858877-22-000025:mdna:139]
[same as prior period, unchanged from 0000858877-22-000009:mdna:187]

[0000858877-22-000025:mdna:140]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,781 |  |  | $ | 1,714 |  |  | $ | 67 |  |  | 4 | % |
| Percentage of revenue | 13.1 | % |  | 13.3 | % |  |  |  |  |
| Sales and marketing | 2,391 |  |  | 2,261 |  |  | 130 |  |  | 6 | % |
| Percentage of revenue | 17.5 | % |  | 17.5 | % |  |  |  |  |
| General and administrative | 565 |  |  | 551 |  |  | 14 |  |  | 3 | % |
| Percentage of revenue | 4.1 | % |  | 4.3 | % |  |  |  |  |
| Total | $ | 4,737 |  |  | $ | 4,526 |  |  | $ | 211 |  |  | 5 | % |
| Percentage of revenue | 34.7 | % |  | 35.1 | % |  |  |  |  |

[0000858877-22-000025:mdna:141]
Three Months Ended October 29, 2022 Compared with Three Months Ended October 30, 2021

[0000858877-22-000025:mdna:142]
[same as prior period, unchanged from 0000858877-22-000009:mdna:190]

[0000858877-22-000025:mdna:143]
R&D expenses increased due to higher headcount-related expenses, higher discretionary spending and higher share-based compensation expense, partially offset by lower contracted services spending.

[0000858877-22-000025:mdna:144]
[same as prior period, unchanged from 0000858877-22-000009:mdna:193]

[0000858877-22-000025:mdna:145]
[same as prior period, unchanged from 0000858877-22-000009:mdna:196]

[0000858877-22-000025:mdna:146]
Sales and marketing expenses increased primarily due to higher discretionary spending and higher headcount-related expenses, partially offset by lower contracted services spending.

[0000858877-22-000025:mdna:147]
[same as prior period, unchanged from 0000858877-22-000009:mdna:201]

[0000858877-22-000025:mdna:148]
G&A expenses increased due to higher headcount-related expenses and higher discretionary spending, partially offset by lower contracted services spending and lower acquisition and divestitures related costs.

[0000858877-22-000025:mdna:149]
[same as prior period, unchanged from 0000858877-22-000009:mdna:165]

[0000858877-22-000025:mdna:150]
[same as prior period, unchanged from 0000858877-22-000009:mdna:166]

[0000858877-22-000025:mdna:151]
[same as prior period, unchanged from 0000858877-22-000009:mdna:208]

[0000858877-22-000025:mdna:152]
In the first quarter of fiscal 2023, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $142 million, or 3.1%, compared with the first quarter of fiscal 2022.

[0000858877-22-000025:mdna:153]
[same as prior period, unchanged from 0000858877-22-000009:mdna:211]

[0000858877-22-000025:mdna:154]
[same as prior period, unchanged from 0000858877-22-000009:mdna:212]

[0000858877-22-000025:mdna:155]
|  |  | Three Months Ended |
|  |  | October 29,2022 |  | October 30,2021 |
| Amortization of purchased intangible assets: |  |  |  |  |
| Cost of sales |  | $ | 158 |  |  | $ | 202 |  |
| Operating expenses |  | 71 |  |  | 84 |  |
| Total |  | $ | 229 |  |  | $ | 286 |  |

[0000858877-22-000025:mdna:156]
For the first quarter of fiscal 2023, the decrease in amortization of purchased intangible assets was primarily due to certain purchased intangible assets that became fully amortized, partially offset by amortization of purchased intangibles from our recent acquisitions.

[0000858877-22-000025:mdna:157]
[same as prior period, unchanged from 0000858877-22-000009:mdna:215]

[0000858877-22-000025:mdna:158]
In the second quarter of fiscal 2023, we announced a restructuring plan in order to rebalance the organization and enable further investment in key priority areas. This rebalancing will include talent movement options and restructuring. Additionally, we will optimize our real estate portfolio, aligned to the broader hybrid work strategy. The total pretax charges are estimated to be approximately $600 million and is expected to impact approximately 5% of our global workforce. We expect the plan to be substantially completed by the end of the first quarter of fiscal 2024. We expect to reinvest substantially all of the cost savings from this restructuring plan in our key priority areas. As a result, the overall cost savings from this restructuring plan are not expected to be material for future periods.

[0000858877-22-000025:mdna:159]
[same as prior period, unchanged from 0000858877-22-000009:mdna:217]

[0000858877-22-000025:mdna:160]
[same as prior period, unchanged from 0000858877-22-000009:mdna:218]

[0000858877-22-000025:mdna:161]
|  |  | Three Months Ended |
|  |  | October 29,2022 |  | October 30,2021 |
| Operating income |  | $ | 3,540 |  |  | $ | 3,438 |  |
| Operating income as a percentage of revenue |  | 26.0 | % |  | 26.7 | % |

[0000858877-22-000025:mdna:162]
Three Months Ended October 29, 2022 Compared with Three Months Ended October 30, 2021

[0000858877-22-000025:mdna:163]
Operating income increased by 3%, and operating income as a percentage of revenue decreased by 0.7 percentage points. The increase in operating income was primarily due to a revenue increase partially offset by a gross margin percentage decrease (driven by negative impacts from productivity partially offset by favorable pricing and favorable product mix) and an increase in operating expenses. The decrease in operating income as a percentage of revenue was primarily due to a gross margin percentage decrease.

[0000858877-22-000025:mdna:164]
[same as prior period, unchanged from 0000858877-22-000009:mdna:184]

[0000858877-22-000025:mdna:165]
[same as prior period, unchanged from 0000858877-22-000009:mdna:185]

[0000858877-22-000025:mdna:166]
[same as prior period, unchanged from 0000858877-22-000009:mdna:226]

[0000858877-22-000025:mdna:167]
[same as prior period, unchanged from 0000858877-22-000009:mdna:227]

[0000858877-22-000025:mdna:168]
|  |  | Three Months Ended |
|  |  | October 29,2022 |  | October 30,2021 |  | Variancein Dollars |
| Interest income |  | $ | 169 |  |  | $ | 121 |  |  | $ | 48 |  |
| Interest expense |  | (100) |  |  | (89) |  |  | (11) |  |
| Interest income (expense), net |  | $ | 69 |  |  | $ | 32 |  |  | $ | 37 |  |

[0000858877-22-000025:mdna:169]
For the first quarter of fiscal 2023, the increase in interest income was driven by higher interest rates. The increase in interest expense was primarily driven by higher interest rates, partially offset by a lower average debt balance.

[0000858877-22-000025:mdna:170]
[same as prior period, unchanged from 0000858877-22-000009:mdna:230]

[0000858877-22-000025:mdna:171]
|  |  | Three Months Ended |
|  |  | October 29,2022 |  | October 30,2021 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | (6) |  |  | $ | 6 |  |  | $ | (12) |  |
| Marketable equity investments |  | (21) |  |  | 5 |  |  | (26) |  |
| Privately held investments |  | (92) |  |  | 205 |  |  | (297) |  |
| Net gains (losses) on investments |  | (119) |  |  | 216 |  |  | (335) |  |
| Other gains (losses), net |  | (15) |  |  | (29) |  |  | 14 |  |
| Other income (loss), net |  | $ | (134) |  |  | $ | 187 |  |  | $ | (321) |  |

[0000858877-22-000025:mdna:172]
Three Months Ended October 29, 2022 Compared with Three Months Ended October 30, 2021

[0000858877-22-000025:mdna:173]
The decrease in our other income (loss), net was primarily driven by lower realized and unrealized gains on our privately held investments and changes in net gains (losses) on available-for-sale debt investments and marketable equity investments.

[0000858877-22-000025:mdna:174]
[same as prior period, unchanged from 0000858877-22-000009:mdna:236]

[0000858877-22-000025:mdna:175]
Three Months Ended October 29, 2022 Compared with Three Months Ended October 30, 2021

[0000858877-22-000025:mdna:176]
The provision for income taxes resulted in an effective tax rate of 23.2% for the first quarter of fiscal 2023 compared with 18.5% for the first quarter of fiscal 2022. The increase in the effective tax rate was primarily due to an increase in net discrete tax expenses and the impact of new U.S. foreign tax credit regulations effective for fiscal 2023. The increase was partially offset by a U.S. foreign-derived intangible income deduction benefit driven by the capitalization and amortization of R&D expenses starting in fiscal 2023 as required by the Tax Cuts and Jobs Act.

[0000858877-22-000025:mdna:177]
[same as prior period, unchanged from 0000858877-22-000009:mdna:204]

[0000858877-22-000025:mdna:178]
[same as prior period, unchanged from 0000858877-22-000009:mdna:205]

[0000858877-22-000025:mdna:179]
[same as prior period, unchanged from 0000858877-22-000009:mdna:247]

[0000858877-22-000025:mdna:180]
[same as prior period, unchanged from 0000858877-22-000009:mdna:248]

[0000858877-22-000025:mdna:181]
[same as prior period, unchanged from 0000858877-22-000009:mdna:249]

[0000858877-22-000025:mdna:182]
[same as prior period, unchanged from 0000858877-22-000009:mdna:250]

[0000858877-22-000025:mdna:183]
|  | October 29,2022 |  | July 30,2022 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 7,292 |  |  | $ | 7,079 |  |  | $ | 213 |  |
| Available-for-sale debt investments | 12,247 |  |  | 11,947 |  |  | 300 |  |
| Marketable equity securities | 245 |  |  | 241 |  |  | 4 |  |
| Total | $ | 19,784 |  |  | $ | 19,267 |  |  | $ | 517 |  |

[0000858877-22-000025:mdna:184]
The net increase in cash and cash equivalents and investments in the first quarter of fiscal 2023 was primarily driven by cash provided by operating activities of $4.0 billion. This source of cash was partially offset by cash returned to stockholders in the form of repurchases of common stock of $0.6 billion and cash dividends of $1.6 billion, a net decrease of debt of $0.6 billion and capital expenditures of $0.2 billion.

[0000858877-22-000025:mdna:185]
[same as prior period, unchanged from 0000858877-22-000009:mdna:253]

[0000858877-22-000025:mdna:186]
Securities Lending   We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 29, 2022 and July 30, 2022, we had no outstanding securities lending transactions.

[0000858877-22-000025:mdna:187]
Free Cash Flow and Capital Allocation   As part of our capital allocation strategy, we target to return a minimum of 50% of our free cash flow annually to our stockholders through cash dividends and repurchases of common stock.

[0000858877-22-000025:mdna:188]
[same as prior period, unchanged from 0000858877-22-000009:mdna:256]

[0000858877-22-000025:mdna:189]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |
| Net cash provided by operating activities | $ | 3,962 |  |  | $ | 3,427 |  |
| Acquisition of property and equipment | (176) |  |  | (122) |  |
| Free cash flow | $ | 3,786 |  |  | $ | 3,305 |  |

[0000858877-22-000025:mdna:190]
[same as prior period, unchanged from 0000858877-22-000009:mdna:258]

[0000858877-22-000025:mdna:191]
[same as prior period, unchanged from 0000858877-22-000009:mdna:224]

[0000858877-22-000025:mdna:192]
[same as prior period, unchanged from 0000858877-22-000009:mdna:225]

[0000858877-22-000025:mdna:193]
[same as prior period, unchanged from 0000858877-22-000009:mdna:261]

[0000858877-22-000025:mdna:194]
[same as prior period, unchanged from 0000858877-22-000009:mdna:262]

[0000858877-22-000025:mdna:195]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| October 29, 2022 |  | $ | 0.38 |  |  | $ | 1,560 |  |  | 12 |  |  | $ | 43.76 |  |  | 502 |  |  | $ | 2,062 |  |
| Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 30, 2022 |  | $ | 0.38 |  |  | $ | 1,567 |  |  | 54 |  |  | $ | 44.02 |  |  | $ | 2,402 |  |  | $ | 3,969 |  |
| April 30, 2022 |  | $ | 0.38 |  |  | $ | 1,555 |  |  | 5 |  |  | $ | 54.20 |  |  | $ | 252 |  |  | $ | 1,807 |  |
| January 29, 2022 |  | $ | 0.37 |  |  | $ | 1,541 |  |  | 82 |  |  | $ | 58.36 |  |  | $ | 4,824 |  |  | $ | 6,365 |  |
| October 30, 2021 |  | $ | 0.37 |  |  | $ | 1,561 |  |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |  | $ | 1,817 |  |

[0000858877-22-000025:mdna:196]
[same as prior period, unchanged from 0000858877-22-000009:mdna:264]

[0000858877-22-000025:mdna:197]
The remaining authorized amount for stock repurchases under this program is approximately $14.7 billion, with no termination date.

[0000858877-22-000025:mdna:198]
[same as prior period, unchanged from 0000858877-22-000009:mdna:266]

[0000858877-22-000025:mdna:199]
|  | October 29,2022 |  | July 30,2022 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,439 |  |  | $ | 6,622 |  |  | $ | (1,183) |  |

[0000858877-22-000025:mdna:200]
Our accounts receivable net, as of October 29, 2022 decreased by approximately 18%, as compared with the end of fiscal 2022, primarily due to timing and amount of product and service billings in the first quarter of fiscal 2023 compared with the fourth quarter of fiscal 2022.

[0000858877-22-000025:mdna:201]
[same as prior period, unchanged from 0000858877-22-000009:mdna:239]

[0000858877-22-000025:mdna:202]
[same as prior period, unchanged from 0000858877-22-000009:mdna:240]

[0000858877-22-000025:mdna:203]
[same as prior period, unchanged from 0000858877-22-000009:mdna:272]

[0000858877-22-000025:mdna:204]
|  | October 29,2022 |  | July 30,2022 |  | July 31,2021 |  | Variance vs. July 30, 2022 |  | Variance vs. July 31, 2021 |
| Inventories | $ | 2,664 |  |  | $ | 2,568 |  |  | $ | 1,559 |  |  | $ | 96 |  |  | $ | 1,105 |  |
| Inventory purchase commitments | $ | 12,608 |  |  | $ | 12,964 |  |  | $ | 10,254 |  |  | $ | (356) |  |  | $ | 2,354 |  |
| Inventory deposits and prepayments | $ | 1,748 |  |  | $ | 1,484 |  |  | $ | 162 |  |  | $ | 264 |  |  | $ | 1,586 |  |

[0000858877-22-000025:mdna:205]
[same as prior period, unchanged from 0000858877-22-000009:mdna:274]

[0000858877-22-000025:mdna:206]
|  | October 29,2022 |  | July 30,2022 |  | July 31,2021 |  | Variance vs. July 30, 2022 |  | Variance vs.July 31, 2021 |
| Less than 1 year | $ | 10,160 |  |  | $ | 9,954 |  |  | $ | 6,903 |  |  | $ | 206 |  |  | $ | 3,257 |  |
| 1 to 3 years | 1,606 |  |  | 2,240 |  |  | 1,806 |  |  | (634) |  |  | (200) |  |
| 3 to 5 years | 842 |  |  | 770 |  |  | 1,545 |  |  | 72 |  |  | (703) |  |
| Total | $ | 12,608 |  |  | $ | 12,964 |  |  | $ | 10,254 |  |  | $ | (356) |  |  | $ | 2,354 |  |

[0000858877-22-000025:mdna:207]
Inventory as of October 29, 2022 increased by 4% and 71% from our inventory balances at the end of fiscal 2022 and fiscal 2021, respectively. Inventory purchase commitments with contract manufacturers and suppliers decreased by 3% and increased by 23% from our balances at the end of fiscal 2022 and fiscal 2021, respectively. We increased our balances in inventories, inventory purchase commitments, and inventory deposits and prepayments as compared to prior fiscal years in order to address significant supply constraints seen industry-wide. The increases were primarily due to arrangements to secure supply and pricing for certain product components and commitments with contract manufacturers to meet customer demand and to address extended lead times, as well as advance payments with suppliers to secure future supply, as a result of the supply constraints. We have partnered with several of our key suppliers utilizing our volume purchasing and extending supply coverage, including revising supplier arrangements. As discussed, our risks of future material excess and obsolete inventory and related losses are further outlined in the Result of Operations—Product Gross Margin section.

[0000858877-22-000025:mdna:208]
[same as prior period, unchanged from 0000858877-22-000009:mdna:277]

[0000858877-22-000025:mdna:209]
[same as prior period, unchanged from 0000858877-22-000009:mdna:278]

[0000858877-22-000025:mdna:210]
[same as prior period, unchanged from 0000858877-22-000009:mdna:279]

[0000858877-22-000025:mdna:211]
[same as prior period, unchanged from 0000858877-22-000009:mdna:280]

[0000858877-22-000025:mdna:212]
|  | October 29,2022 |  | July 30,2022 |  | Increase (Decrease) |
| Loan receivables, net | $ | 6,176 |  |  | $ | 6,739 |  |  | $ | (563) |  |
| Lease receivables, net | 1,125 |  |  | 1,175 |  |  | (50) |  |
| Total, net | $ | 7,301 |  |  | $ | 7,914 |  |  | $ | (613) |  |

[0000858877-22-000025:mdna:213]
Financing Receivables  Our financing arrangements include loans and leases. Our loan receivables include customer financing for purchases of our hardware, software and services (including technical support and advanced services), and also may include additional funds for other costs associated with network installation and integration of our products and services. Lease

[0000858877-22-000025:mdna:214]
54

[0000858877-22-000025:mdna:215]
[same as prior period, unchanged from 0000858877-22-000009:mdna:245]

[0000858877-22-000025:mdna:216]
[same as prior period, unchanged from 0000858877-22-000009:mdna:246]

[0000858877-22-000025:mdna:217]
receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Financing receivables decreased by 8%, as compared with the end of fiscal 2022.

[0000858877-22-000025:mdna:218]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, with payment terms generally ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-22-000025:mdna:219]
The volume of channel partner financing was $7.6 billion and $6.6 billion for the first quarter of fiscal 2023 and 2022, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.5 billion and $1.4 billion as of October 29, 2022 and July 30, 2022, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of October 29, 2022, the total maximum potential future payments related to these guarantees was approximately $162 million, of which approximately $19 million was recorded as deferred revenue.

[0000858877-22-000025:mdna:220]
[same as prior period, unchanged from 0000858877-22-000009:mdna:288]

[0000858877-22-000025:mdna:221]
[same as prior period, unchanged from 0000858877-22-000009:mdna:289]

[0000858877-22-000025:mdna:222]
|  | Maturity Date |  | October 29,2022 |  | July 30,2022 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | 500 |  |  | $ | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 9,000 |  |  | $ | 9,000 |  |

[0000858877-22-000025:mdna:223]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of October 29, 2022.

[0000858877-22-000025:mdna:224]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of October 29, 2022 and $0.6 billion in commercial paper outstanding as of July 30, 2022.

[0000858877-22-000025:mdna:225]
Credit Facility  On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of October 29, 2022, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.

[0000858877-22-000025:mdna:226]
[same as prior period, unchanged from 0000858877-22-000009:mdna:259]

[0000858877-22-000025:mdna:227]
[same as prior period, unchanged from 0000858877-22-000009:mdna:260]

[0000858877-22-000025:mdna:228]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

[0000858877-22-000025:mdna:229]
[same as prior period, unchanged from 0000858877-22-000009:mdna:297]

[0000858877-22-000025:mdna:230]
|  | October 29,2022 |  | July 30,2022 |  | Increase (Decrease) |
| Product | $ | 14,013 |  |  | $ | 14,090 |  |  | $ | (77) |  |
| Service | 16,897 |  |  | 17,449 |  |  | (552) |  |
| Total | $ | 30,910 |  |  | $ | 31,539 |  |  | $ | (629) |  |
| Short-term RPO | $ | 16,380 |  |  | $ | 16,936 |  |  | $ | (556) |  |
| Long-term RPO | 14,530 |  |  | 14,603 |  |  | (73) |  |
| Total | $ | 30,910 |  |  | $ | 31,539 |  |  | $ | (629) |  |

[0000858877-22-000025:mdna:231]
Total remaining performance obligations as of October 29, 2022 decreased 2% compared to the end of fiscal 2022. Remaining performance obligations for product decreased slightly by 1% compared to the end of fiscal 2022. Remaining performance obligations for service decreased 3%. We expect approximately 53% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-22-000025:mdna:232]
[same as prior period, unchanged from 0000858877-22-000009:mdna:300]

[0000858877-22-000025:mdna:233]
|  | October 29,2022 |  | July 30,2022 |  | Increase (Decrease) |
| Product | $ | 10,404 |  |  | $ | 10,427 |  |  | $ | (23) |  |
| Service | 12,615 |  |  | 12,837 |  |  | (222) |  |
| Total | $ | 23,019 |  |  | $ | 23,264 |  |  | $ | (245) |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 12,578 |  |  | $ | 12,784 |  |  | $ | (206) |  |
| Noncurrent | 10,441 |  |  | 10,480 |  |  | (39) |  |
| Total | $ | 23,019 |  |  | $ | 23,264 |  |  | $ | (245) |  |

[0000858877-22-000025:mdna:234]
Total deferred revenue decreased 1% compared to the end of fiscal 2022. The slight decrease in deferred product revenue was primarily due to lower business volume partially offset by increased deferrals related to our recurring software offerings. The decrease in deferred service revenue of 2% was driven by the impact of ongoing amortization of deferred service revenue.

[0000858877-22-000025:mdna:235]
[same as prior period, unchanged from 0000858877-22-000009:mdna:303]

[0000858877-22-000025:mdna:236]
[same as prior period, unchanged from 0000858877-22-000009:mdna:304]

[0000858877-22-000025:mdna:237]
The income tax payable outstanding as of October 29, 2022 for the U.S. transition tax on accumulated earnings for foreign subsidiaries is $6.2 billion. Approximately $0.7 billion is payable in less than one year; $3.2 billion is payable between 1 to 3 years; and $2.3 billion is payable between 3 to 5 years.

[0000858877-22-000025:mdna:238]
For our Contractual Obligations see our Annual Report on Form 10-K for the year ended July 30, 2022.

[0000858877-22-000025:mdna:239]
[same as prior period, unchanged from 0000858877-22-000009:mdna:270]

[0000858877-22-000025:mdna:240]
[same as prior period, unchanged from 0000858877-22-000009:mdna:271]

[0000858877-22-000025:mdna:241]
[same as prior period, unchanged from 0000858877-22-000009:mdna:309]

[0000858877-22-000025:mdna:242]
[same as prior period, unchanged from 0000858877-22-000009:mdna:310]

[0000858877-22-000025:mdna:243]
We also have certain funding commitments primarily related to our privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion and $0.4 billion as of October 29, 2022 and July 30, 2022, respectively.

[0000858877-22-000025:mdna:244]
In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of October 29, 2022 there were no material unconsolidated variable interest entities.

[0000858877-22-000025:mdna:245]
[same as prior period, unchanged from 0000858877-22-000009:mdna:313]

[0000858877-22-000025:mdna:246]
We provide financing guarantees, which are generally for various third-party financing arrangements extended to our channel partners. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. See the previous discussion of these financing guarantees under “Financing Receivables and Guarantees.”

[0000858877-22-000025:mdna:247]
[same as prior period, unchanged from 0000858877-22-000009:mdna:315]

[0000858877-22-000025:mdna:248]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs (including inventory and other supply related payments), capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. We expect increased payments related to inventory and other supply related payments through at least the next 12 months. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.
