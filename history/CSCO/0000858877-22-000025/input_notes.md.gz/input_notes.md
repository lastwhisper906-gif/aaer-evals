# CSCO notes — 0000858877-22-000025


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-22-000025:notes:1]
Organization and Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2023 and fiscal 2022 are each 52-week fiscal years. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-22-000025:notes:2]
We have prepared the accompanying financial data as of October 29, 2022 and for the first quarter of fiscal 2023 and 2022, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 30, 2022 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 30, 2022.

[0000858877-22-000025:notes:3]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of October 29, 2022, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2023 and 2022, as applicable, have been made. The results of operations for the first quarter of fiscal 2023 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-22-000025:notes:4]
Our consolidated financial statements include our accounts and investments consolidated under the variable interest and voting models. The noncontrolling interests attributed to these investments are not presented as a separate component in the equity section of the Consolidated Balance Sheets as these amounts are not material for any of the fiscal periods presented. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-22-000025:notes:5]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-22-000025:notes:6]
Recent Accounting Pronouncements
(a)Recent Accounting Standards or Updates Not Yet Effective

[0000858877-22-000025:notes:7]
Reference Rate Reform  In March 2020, the FASB issued an accounting standard update and subsequent amendments that provide optional expedients and exceptions to the current guidance on contract modification and hedging relationships to ease the financial reporting burden of the expected market transition from the London InterBank Offered Rate (LIBOR) and other interbank offered rates to alternative reference rates. This accounting standard update was effective upon issuance and may be applied prospectively through December 31, 2022. We do not expect this accounting standard update will have a material impact on our Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-22-000025:notes:8]
Revenue We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-22-000025:notes:9]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 29, 2022 and July 30, 2022 was $47 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-22-000025:notes:10]
[same as prior period, unchanged from 0000858877-22-000009:notes:14]

[0000858877-22-000025:notes:11]
[same as prior period, unchanged from 0000858877-22-000009:notes:15]

[0000858877-22-000025:notes:12]
[same as prior period, unchanged from 0000858877-22-000009:notes:16]

[0000858877-22-000025:notes:13]
[same as prior period, unchanged from 0000858877-22-000009:notes:17]

[0000858877-22-000025:notes:14]
[same as prior period, unchanged from 0000858877-22-000009:notes:18]

[0000858877-22-000025:notes:15]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. The following table presents this disaggregation of revenue (in millions):

[0000858877-22-000025:notes:16]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |
| Product revenue: |  |  |  |
| Secure, Agile Networks | $ | 6,684 |  |  | $ | 5,968 |  |
| Internet for the Future | 1,310 |  |  | 1,373 |  |
| Collaboration | 1,086 |  |  | 1,109 |  |
| End-to-End Security | 971 |  |  | 895 |  |
| Optimized Application Experiences | 193 |  |  | 181 |  |
| Other Products | 2 |  |  | 3 |  |
| Total Product | 10,245 |  |  | 9,529 |  |
| Services | 3,387 |  |  | 3,371 |  |
| Total | $ | 13,632 |  |  | $ | 12,900 |  |

[0000858877-22-000025:notes:17]
Amounts may not sum due to rounding. We have made certain reclassifications to the product revenue amounts for prior period to conform to the current year presentation.

[0000858877-22-000025:notes:18]
[same as prior period, unchanged from 0000858877-22-000009:notes:22]

[0000858877-22-000025:notes:19]
Internet for the Future consists of our routed optical networking, 5G, silicon, and optics solutions. These products consist primarily of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-22-000025:notes:20]
Collaboration consists of our Meetings, Collaboration Devices, Calling, Contact Center and Communication Platform as a Service (CPaaS) offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-22-000025:notes:21]
End-to-End Security consists of our Network Security, Cloud Security, Security Endpoints, Unified Threat Management and Zero Trust offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-22-000025:notes:22]
[same as prior period, unchanged from 0000858877-22-000009:notes:27]

[0000858877-22-000025:notes:23]
[same as prior period, unchanged from 0000858877-22-000009:notes:28]

[0000858877-22-000025:notes:24]
[same as prior period, unchanged from 0000858877-22-000009:notes:29]

[0000858877-22-000025:notes:25]
[same as prior period, unchanged from 0000858877-22-000009:notes:30]

[0000858877-22-000025:notes:26]
[same as prior period, unchanged from 0000858877-22-000009:notes:31]

[0000858877-22-000025:notes:27]
Accounts receivable, net was $5.4 billion as of October 29, 2022 compared to $6.6 billion as of July 30, 2022, as reported on the Consolidated Balance Sheets.

[0000858877-22-000025:notes:28]
[same as prior period, unchanged from 0000858877-22-000009:notes:33]

[0000858877-22-000025:notes:29]
|  | Three Months Ended |
|  | October 29, 2022 |  | October 30, 2021 |
| Allowance for credit loss at beginning of period | $ | 83 |  |  | $ | 109 |  |
| Provisions (benefits) | 11 |  |  | 19 |  |
| Recoveries (write-offs), net | (6) |  |  | (14) |  |
| Allowance for credit loss at end of period | $ | 88 |  |  | $ | 114 |  |

[0000858877-22-000025:notes:30]
[same as prior period, unchanged from 0000858877-22-000009:notes:35]

[0000858877-22-000025:notes:31]
[same as prior period, unchanged from 0000858877-22-000009:notes:36]

[0000858877-22-000025:notes:32]
|  | October 29,2022 |  | July 30,2022 |
| 1 to 4 | $ | 356 |  |  | $ | 414 |  |
| 5 to 6 | 898 |  |  | 814 |  |
| 7 and Higher | 87 |  |  | 158 |  |
| Total | $ | 1,341 |  |  | $ | 1,386 |  |

[0000858877-22-000025:notes:33]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, was $1.3 billion as of each of October 29, 2022 and July 30, 2022, and were included in other current assets and other assets.

[0000858877-22-000025:notes:34]
Contract liabilities consist of deferred revenue. Deferred revenue was $23.0 billion as of October 29, 2022 compared to $23.3 billion as of July 30, 2022. We recognized approximately $4.4 billion of revenue during the first quarter of fiscal 2023 that was included in the deferred revenue balance at July 30, 2022. 
(c)Capitalized Contract Acquisition CostsWe capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $1.1 billion and $1.0 billion as of October 29, 2022 and July 30, 2022, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $176 million and $170 million for the first quarter of fiscal 2023 and 2022, respectively, and was included in sales and marketing expenses.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-22-000025:notes:35]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-22-000025:notes:36]
[same as prior period, unchanged from 0000858877-22-000009:notes:41]

[0000858877-22-000025:notes:37]
[same as prior period, unchanged from 0000858877-22-000009:notes:42]

[0000858877-22-000025:notes:38]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |
| Revenue: |  |  |  |
| Secure, Agile Networks | $ | 6,684 |  |  | $ | 5,968 |  |
| Internet for the Future | 1,310 |  |  | 1,373 |  |
| Collaboration | 1,086 |  |  | 1,109 |  |
| End-to-End Security | 971 |  |  | 895 |  |
| Optimized Application Experiences | 193 |  |  | 181 |  |
| Other Products | 2 |  |  | 3 |  |
| Total Product | 10,245 |  |  | 9,529 |  |
| Services | 3,387 |  |  | 3,371 |  |
| Total | $ | 13,632 |  |  | $ | 12,900 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-22-000025:notes:39]
Acquisitions and DivestituresTotal transaction costs related to acquisition and divestiture activities were $2 million and $19 million for the first quarter of fiscal 2023 and 2022, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-22-000025:notes:40]
[same as prior period, unchanged from 0000858877-22-000009:notes:48]

[0000858877-22-000025:notes:41]
The following table presents the goodwill allocated to our reportable segments as of October 29, 2022 and during the first quarter of fiscal 2023 (in millions):

[0000858877-22-000025:notes:42]
|  | Balance at July 30, 2022 |  | Foreign Currency Translation and Other |  | Balance at October 29, 2022 |
| Americas | $ | 23,882 |  |  | $ | (90) |  |  | $ | 23,792 |  |
| EMEA | 9,062 |  |  | (34) |  |  | 9,028 |  |
| APJC | 5,360 |  |  | (20) |  |  | 5,340 |  |
| Total | $ | 38,304 |  |  | $ | (144) |  |  | $ | 38,160 |  |

[0000858877-22-000025:notes:43]
[same as prior period, unchanged from 0000858877-22-000009:notes:52]

[0000858877-22-000025:notes:44]
[same as prior period, unchanged from 0000858877-22-000009:notes:55]

[0000858877-22-000025:notes:45]
| October 29, 2022 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 2,642 |  |  | $ | (1,250) |  |  | $ | 1,392 |  |
| Customer relationships |  | 1,332 |  |  | (819) |  |  | 513 |  |
| Other |  | 40 |  |  | (15) |  |  | 25 |  |
| Total purchased intangible assets with finite lives |  | 4,014 |  |  | (2,084) |  |  | 1,930 |  |
| In-process research and development, with indefinite lives |  | 430 |  |  | — |  |  | 430 |  |
| Total |  | $ | 4,444 |  |  | $ | (2,084) |  |  | $ | 2,360 |  |

[0000858877-22-000025:notes:46]
| July 30, 2022 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 2,631 |  |  | $ | (1,102) |  |  | $ | 1,529 |  |
| Customer relationships |  | 1,354 |  |  | (769) |  |  | 585 |  |
| Other |  | 41 |  |  | (16) |  |  | 25 |  |
| Total purchased intangible assets with finite lives |  | 4,026 |  |  | (1,887) |  |  | 2,139 |  |
| In-process research and development, with indefinite lives |  | 430 |  |  | — |  |  | 430 |  |
| Total |  | $ | 4,456 |  |  | $ | (1,887) |  |  | $ | 2,569 |  |

[0000858877-22-000025:notes:47]
[same as prior period, unchanged from 0000858877-22-000009:notes:58]

[0000858877-22-000025:notes:48]
[same as prior period, unchanged from 0000858877-22-000009:notes:60]

[0000858877-22-000025:notes:49]
|  | Three Months Ended |
|  | October 29, 2022 |  | October 30, 2021 |
| Amortization of purchased intangible assets: |  |  |  |
| Cost of sales | $ | 158 |  |  | $ | 202 |  |
| Operating expenses | 71 |  |  | 84 |  |
| Total | $ | 229 |  |  | $ | 286 |  |

[0000858877-22-000025:notes:50]
The estimated future amortization expense of purchased intangible assets with finite lives as of October 29, 2022 is as follows (in millions):

[0000858877-22-000025:notes:51]
| Fiscal Year | Amount |
| 2023 (remaining nine months) | $ | 677 |  |
| 2024 | $ | 777 |  |
| 2025 | $ | 406 |  |
| 2026 | $ | 65 |  |
| 2027 | $ | 5 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-22-000025:notes:52]
Restructuring and Other Charges
In the second quarter of fiscal 2023, we announced a restructuring plan (the “Fiscal 2023 Plan”), in order to rebalance the organization and enable further investment in key priority areas. This rebalancing will include talent movement options and restructuring. Additionally, we will optimize our real estate portfolio, aligned to the broader hybrid work strategy. The total pretax charges are estimated to be approximately $600 million and is expected to impact approximately 5% of our global workforce. These aggregate pretax charges will be primarily cash-based and will consist of severance and other one-time termination benefits, real estate-related charges, and other costs. We expect the plan to be substantially completed by the end of the first quarter of fiscal 2024.

[0000858877-22-000025:notes:53]
[same as prior period, unchanged from 0000858877-22-000009:notes:67]

[0000858877-22-000025:notes:54]
|  |  | FISCAL 2020 AND PRIOR PLANS |  | FISCAL 2021 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 30, 2022 |  | $ | — |  |  | $ | 3 |  |  | $ | 2 |  |  | $ | 4 |  |  | $ | 9 |  |
| Charges |  | — |  |  | — |  |  | — |  |  | (2) |  |  | (2) |  |
| Cash payments |  | — |  |  | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Liability as of October 29, 2022 |  | $ | — |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 6 |  |

[0000858877-22-000025:notes:55]
|  |  | FISCAL 2020 AND PRIOR PLANS |  | FISCAL 2021 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | Employee Severance |  | Other |  | Total |
| Liability as of July 31, 2021 |  | $ | — |  |  | $ | 10 |  |  | $ | 16 |  |  | $ | 8 |  |  | $ | 34 |  |
| Charges |  | — |  |  | (1) |  |  | 4 |  |  | 2 |  |  | 5 |  |
| Cash payments |  | — |  |  | (1) |  |  | (8) |  |  | — |  |  | (9) |  |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (4) |  |  | (4) |  |
| Liability as of October 30, 2021 |  | $ | — |  |  | $ | 8 |  |  | $ | 12 |  |  | $ | 6 |  |  | $ | 26 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-22-000025:notes:56]
[same as prior period, unchanged from 0000858877-22-000009:notes:70]

[0000858877-22-000025:notes:57]
[same as prior period, unchanged from 0000858877-22-000009:notes:71]

[0000858877-22-000025:notes:58]
|  |  | October 29,2022 |  | July 30,2022 |
| Cash and cash equivalents |  | $ | 7,292 |  |  | $ | 7,079 |  |
| Restricted cash and restricted cash equivalents included in other assets |  | 1,500 |  |  | 1,500 |  |
| Total |  | $ | 8,792 |  |  | $ | 8,579 |  |

[0000858877-22-000025:notes:59]
[same as prior period, unchanged from 0000858877-22-000009:notes:73]

[0000858877-22-000025:notes:60]
[same as prior period, unchanged from 0000858877-22-000009:notes:74]

[0000858877-22-000025:notes:61]
|  |  | October 29,2022 |  | July 30,2022 |
| Raw materials |  | $ | 1,458 |  |  | $ | 1,601 |  |
| Work in process |  | 165 |  |  | 150 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales |  | 79 |  |  | 86 |  |
| Manufactured finished goods |  | 850 |  |  | 631 |  |
| Total finished goods |  | 929 |  |  | 717 |  |
| Service-related spares |  | 99 |  |  | 90 |  |
| Demonstration systems |  | 13 |  |  | 10 |  |
| Total |  | $ | 2,664 |  |  | $ | 2,568 |  |

[0000858877-22-000025:notes:62]
[same as prior period, unchanged from 0000858877-22-000009:notes:76]

[0000858877-22-000025:notes:63]
|  |  | October 29,2022 |  | July 30,2022 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,193 |  |  | $ | 4,219 |  |
| Computer equipment and related software |  | 751 |  |  | 779 |  |
| Production, engineering, and other equipment |  | 4,588 |  |  | 4,647 |  |
| Operating lease assets |  | 161 |  |  | 185 |  |
| Furniture, fixtures and other |  | 334 |  |  | 335 |  |
| Total gross property and equipment |  | 10,027 |  |  | 10,165 |  |
| Less: accumulated depreciation and amortization |  | (8,055) |  |  | (8,168) |  |
| Total |  | $ | 1,972 |  |  | $ | 1,997 |  |

[0000858877-22-000025:notes:64]
[same as prior period, unchanged from 0000858877-22-000009:notes:78]

[0000858877-22-000025:notes:65]
|  |  | October 29,2022 |  | July 30,2022 |
| Product |  | $ | 14,013 |  |  | $ | 14,090 |  |
| Service |  | 16,897 |  |  | 17,449 |  |
| Total |  | $ | 30,910 |  |  | $ | 31,539 |  |
| Short-term RPO |  | $ | 16,380 |  |  | $ | 16,936 |  |
| Long-term RPO |  | 14,530 |  |  | 14,603 |  |
| Total |  | $ | 30,910 |  |  | $ | 31,539 |  |
| Amount to be recognized as revenue over the next 12 months |  | 53 | % |  | 54 | % |
| Deferred revenue |  | $ | 23,019 |  |  | $ | 23,264 |  |
| Unbilled contract revenue |  | 7,891 |  |  | 8,275 |  |
| Total |  | $ | 30,910 |  |  | $ | 31,539 |  |

[0000858877-22-000025:notes:66]
[same as prior period, unchanged from 0000858877-22-000009:notes:80]

[0000858877-22-000025:notes:67]
[same as prior period, unchanged from 0000858877-22-000009:notes:81]

[0000858877-22-000025:notes:68]
|  |  | October 29,2022 |  | July 30,2022 |
| Product |  | $ | 10,404 |  |  | $ | 10,427 |  |
| Service |  | 12,615 |  |  | 12,837 |  |
| Total |  | $ | 23,019 |  |  | $ | 23,264 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 12,578 |  |  | $ | 12,784 |  |
| Noncurrent |  | 10,441 |  |  | 10,480 |  |
| Total |  | $ | 23,019 |  |  | $ | 23,264 |  |

[0000858877-22-000025:notes:69]
Transition Tax Payable

[0000858877-22-000025:notes:70]
Our income tax payable associated with the one-time U.S. transition tax on accumulated earnings for foreign subsidiaries as a result of the Tax Cuts and Jobs Act is as follows (in millions):

[0000858877-22-000025:notes:71]
|  |  | October 29,2022 |  | July 30,2022 |
| Current |  | $ | 727 |  |  | $ | 727 |  |
| Noncurrent |  | 5,456 |  |  | 5,456 |  |
| Total |  | $ | 6,183 |  |  | $ | 6,183 |  |


## us-gaap:OperatingLeasesOfLessorDisclosureTextBlock

[0000858877-22-000025:notes:72]
Leases 
(a)Lessee Arrangements

[0000858877-22-000025:notes:73]
The following table presents our operating lease balances (in millions):

[0000858877-22-000025:notes:74]
|  | Balance Sheet Line Item |  | October 29, 2022 |  | July 30, 2022 |
| Operating lease right-of-use assets | Other assets |  | $ | 929 |  |  | $ | 1,003 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 308 |  |  | $ | 322 |  |
| Operating lease liabilities | Other long-term liabilities |  | 667 |  |  | 724 |  |
| Total operating lease liabilities |  |  | $ | 975 |  |  | $ | 1,046 |  |

[0000858877-22-000025:notes:75]
The components of our lease expenses were as follows (in millions):

[0000858877-22-000025:notes:76]
|  | Three Months Ended |
|  | October 29, 2022 |  | October 30, 2021 |
| Operating lease expense | $ | 96 |  |  | $ | 95 |  |
| Short-term lease expense | 17 |  |  | 17 |  |
| Variable lease expense | 58 |  |  | 49 |  |
| Total lease expense | $ | 171 |  |  | $ | 161 |  |

[0000858877-22-000025:notes:77]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-22-000025:notes:78]
|  | Three Months Ended |
|  | October 29, 2022 |  | October 30, 2021 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 96 |  |  | $ | 98 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 35 |  |  | $ | 120 |  |

[0000858877-22-000025:notes:79]
The weighted-average lease term was 4.6 years and 4.7 years as of October 29, 2022 and July 30, 2022, respectively. The weighted-average discount rate was 2.3% and 2.2% as of October 29, 2022 and July 30, 2022, respectively.

[0000858877-22-000025:notes:80]
The maturities of our operating leases (undiscounted) as of October 29, 2022 are as follows (in millions):

[0000858877-22-000025:notes:81]
| Fiscal Year | Amount |
| 2023 (remaining nine months) | $ | 254 |  |
| 2024 | 262 |  |
| 2025 | 183 |  |
| 2026 | 106 |  |
| 2027 | 63 |  |
| Thereafter | 181 |  |
| Total lease payments | 1,049 |  |
| Less interest | (74) |  |
| Total | $ | 975 |  |

[0000858877-22-000025:notes:82]
(b)Lessor Arrangements

[0000858877-22-000025:notes:83]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income was $12 million and $15 million for the first quarter of fiscal 2023 and 2022, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-22-000025:notes:84]
Future minimum lease payments on our lease receivables as of October 29, 2022 are summarized as follows (in millions):

[0000858877-22-000025:notes:85]
| Fiscal Year | Amount |
| 2023 (remaining nine months) | $ | 461 |  |
| 2024 | 329 |  |
| 2025 | 182 |  |
| 2026 | 90 |  |
| 2027 | 63 |  |
| Thereafter | 4 |  |
| Total | 1,129 |  |
| Less: Present value of lease payments | 1,074 |  |
| Unearned income | $ | 55 |  |

[0000858877-22-000025:notes:86]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-22-000025:notes:87]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-22-000025:notes:88]
|  | October 29, 2022 |  | July 30, 2022 |
| Operating lease assets | $ | 161 |  |  | $ | 185 |  |
| Accumulated depreciation | (97) |  |  | (111) |  |
| Operating lease assets, net | $ | 64 |  |  | $ | 74 |  |

[0000858877-22-000025:notes:89]
Our operating lease income was $21 million and $32 million for the first quarter of fiscal 2023 and 2022, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-22-000025:notes:90]
Minimum future rentals on noncancelable operating leases as of October 29, 2022 are summarized as follows (in millions):

[0000858877-22-000025:notes:91]
| Fiscal Year | Amount |
| 2023 (remaining nine months) | $ | 23 |  |
| 2024 | 17 |  |
| 2025 | 5 |  |
| Total | $ | 45 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-22-000025:notes:92]
[same as prior period, unchanged from 0000858877-22-000009:notes:103]

[0000858877-22-000025:notes:93]
Financing receivables primarily consist of loan receivables and lease receivables. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services (including technical support and advanced services), and also may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables have terms of one year to three years on average. Lease receivables represent sales-type leases resulting from the sale of Cisco’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average.

[0000858877-22-000025:notes:94]
[same as prior period, unchanged from 0000858877-22-000009:notes:105]

[0000858877-22-000025:notes:95]
| October 29, 2022 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 6,277 |  |  | $ | 1,129 |  |  | $ | 7,406 |  |
| Residual value | — |  |  | 70 |  |  | 70 |  |
| Unearned income | — |  |  | (55) |  |  | (55) |  |
| Allowance for credit loss | (101) |  |  | (19) |  |  | (120) |  |
| Total, net | $ | 6,176 |  |  | $ | 1,125 |  |  | $ | 7,301 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 3,144 |  |  | $ | 539 |  |  | $ | 3,683 |  |
| Noncurrent | 3,032 |  |  | 586 |  |  | 3,618 |  |
| Total, net | $ | 6,176 |  |  | $ | 1,125 |  |  | $ | 7,301 |  |

[0000858877-22-000025:notes:96]
| July 30, 2022 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 6,842 |  |  | $ | 1,176 |  |  | $ | 8,018 |  |
| Residual value | — |  |  | 76 |  |  | 76 |  |
| Unearned income | — |  |  | (54) |  |  | (54) |  |
| Allowance for credit loss | (103) |  |  | (23) |  |  | (126) |  |
| Total, net | $ | 6,739 |  |  | $ | 1,175 |  |  | $ | 7,914 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 3,327 |  |  | $ | 578 |  |  | $ | 3,905 |  |
| Noncurrent | 3,412 |  |  | 597 |  |  | 4,009 |  |
| Total, net | $ | 6,739 |  |  | $ | 1,175 |  |  | $ | 7,914 |  |

[0000858877-22-000025:notes:97]
[same as prior period, unchanged from 0000858877-22-000009:notes:108]

[0000858877-22-000025:notes:98]
[same as prior period, unchanged from 0000858877-22-000009:notes:109]

[0000858877-22-000025:notes:99]
| October 29, 2022 |  |  | Fiscal Year |  | Three Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | July 30, 2022 |  | October 29, 2022 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 33 |  |  | $ | 146 |  |  | $ | 451 |  |  | $ | 1,265 |  |  | $ | 1,542 |  |  | $ | 656 |  |  | $ | 4,093 |  |
| 5 to 6 | 10 |  |  | 96 |  |  | 263 |  |  | 555 |  |  | 768 |  |  | 325 |  |  | 2,017 |  |
| 7 and Higher | 2 |  |  | 19 |  |  | 40 |  |  | 38 |  |  | 66 |  |  | 2 |  |  | 167 |  |
| Total Loan Receivables | $ | 45 |  |  | $ | 261 |  |  | $ | 754 |  |  | $ | 1,858 |  |  | $ | 2,376 |  |  | $ | 983 |  |  | $ | 6,277 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 16 |  |  | $ | 72 |  |  | $ | 124 |  |  | $ | 189 |  |  | $ | 112 |  |  | $ | 30 |  |  | $ | 543 |  |
| 5 to 6 | 7 |  |  | 32 |  |  | 90 |  |  | 106 |  |  | 124 |  |  | 146 |  |  | 505 |  |
| 7 and Higher | 1 |  |  | 3 |  |  | 10 |  |  | 2 |  |  | 4 |  |  | 6 |  |  | 26 |  |
| Total Lease Receivables | $ | 24 |  |  | $ | 107 |  |  | $ | 224 |  |  | $ | 297 |  |  | $ | 240 |  |  | $ | 182 |  |  | $ | 1,074 |  |
| Total | $ | 69 |  |  | $ | 368 |  |  | $ | 978 |  |  | $ | 2,155 |  |  | $ | 2,616 |  |  | $ | 1,165 |  |  | $ | 7,351 |  |

[0000858877-22-000025:notes:100]
| July 30, 2022 |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 28, 2018 |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | July 30, 2022 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 49 |  |  | $ | 173 |  |  | $ | 536 |  |  | $ | 1,458 |  |  | $ | 2,287 |  |  | $ | 4,505 |  |
| 5 to 6 | 1 |  |  | 17 |  |  | 115 |  |  | 345 |  |  | 709 |  |  | 1,030 |  |  | 2,217 |  |
| 7 and Higher | 1 |  |  | 1 |  |  | 22 |  |  | 45 |  |  | 39 |  |  | 12 |  |  | 120 |  |
| Total Loan Receivables | $ | 4 |  |  | $ | 67 |  |  | $ | 310 |  |  | $ | 926 |  |  | $ | 2,206 |  |  | $ | 3,329 |  |  | $ | 6,842 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 25 |  |  | $ | 74 |  |  | $ | 124 |  |  | $ | 176 |  |  | $ | 152 |  |  | $ | 553 |  |
| 5 to 6 | 1 |  |  | 10 |  |  | 67 |  |  | 146 |  |  | 165 |  |  | 151 |  |  | 540 |  |
| 7 and Higher | — |  |  | 1 |  |  | 4 |  |  | 12 |  |  | 2 |  |  | 10 |  |  | 29 |  |
| Total Lease Receivables | $ | 3 |  |  | $ | 36 |  |  | $ | 145 |  |  | $ | 282 |  |  | $ | 343 |  |  | $ | 313 |  |  | $ | 1,122 |  |
| Total | $ | 7 |  |  | $ | 103 |  |  | $ | 455 |  |  | $ | 1,208 |  |  | $ | 2,549 |  |  | $ | 3,642 |  |  | $ | 7,964 |  |

[0000858877-22-000025:notes:101]
The following tables present the aging analysis of gross receivables as of October 29, 2022 and July 30, 2022 (in millions):

[0000858877-22-000025:notes:102]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| October 29, 2022 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 143 |  |  | $ | 26 |  |  | $ | 118 |  |  | $ | 287 |  |  | $ | 5,990 |  |  | $ | 6,277 |  |  | $ | 16 |  |  | $ | 60 |  |  | $ | 60 |  |
| Lease receivables | 17 |  |  | 14 |  |  | 27 |  |  | 58 |  |  | 1,016 |  |  | 1,074 |  |  | 7 |  |  | 10 |  |  | 10 |  |
| Total | $ | 160 |  |  | $ | 40 |  |  | $ | 145 |  |  | $ | 345 |  |  | $ | 7,006 |  |  | $ | 7,351 |  |  | $ | 23 |  |  | $ | 70 |  |  | $ | 70 |  |

[0000858877-22-000025:notes:103]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| July 30, 2022 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 98 |  |  | $ | 62 |  |  | $ | 129 |  |  | $ | 289 |  |  | $ | 6,553 |  |  | $ | 6,842 |  |  | $ | 14 |  |  | $ | 60 |  |  | $ | 60 |  |
| Lease receivables | 8 |  |  | 6 |  |  | 26 |  |  | 40 |  |  | 1,082 |  |  | 1,122 |  |  | 7 |  |  | 11 |  |  | 11 |  |
| Total | $ | 106 |  |  | $ | 68 |  |  | $ | 155 |  |  | $ | 329 |  |  | $ | 7,635 |  |  | $ | 7,964 |  |  | $ | 21 |  |  | $ | 71 |  |  | $ | 71 |  |

[0000858877-22-000025:notes:104]
[same as prior period, unchanged from 0000858877-22-000009:notes:115]

[0000858877-22-000025:notes:105]
[same as prior period, unchanged from 0000858877-22-000009:notes:116]

[0000858877-22-000025:notes:106]
[same as prior period, unchanged from 0000858877-22-000009:notes:117]

[0000858877-22-000025:notes:107]
| Three Months Ended October 29, 2022 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 30, 2022 | $ | 103 |  |  | $ | 23 |  |  | $ | 126 |  |
| Provisions (benefits) | (1) |  |  | (3) |  |  | (4) |  |
| Other | (1) |  |  | (1) |  |  | (2) |  |
| Allowance for credit loss as of October 29, 2022 | $ | 101 |  |  | $ | 19 |  |  | $ | 120 |  |

[0000858877-22-000025:notes:108]
| Three Months Ended October 30, 2021 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 31, 2021 | $ | 89 |  |  | $ | 38 |  |  | $ | 127 |  |
| Provisions (benefits) | (13) |  |  | (5) |  |  | (18) |  |
| Allowance for credit loss as of October 30, 2021 | $ | 76 |  |  | $ | 33 |  |  | $ | 109 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-22-000025:notes:109]
Available-for-Sale Debt and Equity Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-22-000025:notes:110]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-22-000025:notes:111]
| October 29, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,545 |  |  | $ | — |  |  | $ | (70) |  |  | $ | 1,475 |  |
| U.S. government agency securities | 171 |  |  | — |  |  | (6) |  |  | 165 |  |
| Non-U.S. government and agency securities | 275 |  |  | — |  |  | (1) |  |  | 274 |  |
| Corporate debt securities | 7,808 |  |  | — |  |  | (492) |  |  | 7,316 |  |
| U.S. agency mortgage-backed securities | 2,071 |  |  | — |  |  | (273) |  |  | 1,798 |  |
| Commercial paper | 798 |  |  | — |  |  | — |  |  | 798 |  |
| Certificates of deposit | 421 |  |  | — |  |  | — |  |  | 421 |  |
| Total | $ | 13,089 |  |  | $ | — |  |  | $ | (842) |  |  | $ | 12,247 |  |

[0000858877-22-000025:notes:112]
| July 30, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,287 |  |  | $ | — |  |  | $ | (49) |  |  | $ | 1,238 |  |
| U.S. government agency securities | 142 |  |  | — |  |  | (4) |  |  | 138 |  |
| Non-U.S. government and agency securities | 272 |  |  | — |  |  | — |  |  | 272 |  |
| Corporate debt securities | 8,127 |  |  | 2 |  |  | (311) |  |  | 7,818 |  |
| U.S. agency mortgage-backed securities | 2,134 |  |  | — |  |  | (158) |  |  | 1,976 |  |
| Commercial paper | 255 |  |  | — |  |  | — |  |  | 255 |  |
| Certificates of deposit | 250 |  |  | — |  |  | — |  |  | 250 |  |
| Total | $ | 12,467 |  |  | $ | 2 |  |  | $ | (522) |  |  | $ | 11,947 |  |

[0000858877-22-000025:notes:113]
Net unsettled investment purchases were $42 million and net unsettled investment sales were $70 million as of October 29, 2022 and July 30, 2022, respectively, and were included in other current assets and other current liabilities.

[0000858877-22-000025:notes:114]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-22-000025:notes:115]
|  | Three Months Ended |
|  | October 29, 2022 |  | October 30, 2021 |
| Gross realized gains | $ | — |  |  | $ | 6 |  |
| Gross realized losses | (6) |  |  | — |  |
| Total | $ | (6) |  |  | $ | 6 |  |

[0000858877-22-000025:notes:116]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 29, 2022 and July 30, 2022 (in millions):

[0000858877-22-000025:notes:117]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 29, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 530 |  |  | $ | (12) |  |  | $ | 944 |  |  | $ | (58) |  |  | $ | 1,474 |  |  | $ | (70) |  |
| U.S. government agency securities | 101 |  |  | (2) |  |  | 64 |  |  | (4) |  |  | 165 |  |  | (6) |  |
| Non-U.S. government and agency securities | 257 |  |  | (1) |  |  | — |  |  | — |  |  | 257 |  |  | (1) |  |
| Corporate debt securities | 5,065 |  |  | (252) |  |  | 2,090 |  |  | (206) |  |  | 7,155 |  |  | (458) |  |
| U.S. agency mortgage-backed securities | 651 |  |  | (76) |  |  | 1,136 |  |  | (197) |  |  | 1,787 |  |  | (273) |  |
| Commercial paper | 45 |  |  | — |  |  | — |  |  | — |  |  | 45 |  |  | — |  |
| Total | $ | 6,649 |  |  | $ | (343) |  |  | $ | 4,234 |  |  | $ | (465) |  |  | $ | 10,883 |  |  | $ | (808) |  |

[0000858877-22-000025:notes:118]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 30, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,110 |  |  | $ | (44) |  |  | $ | 120 |  |  | $ | (5) |  |  | $ | 1,230 |  |  | $ | (49) |  |
| U.S. government agency securities | 114 |  |  | (2) |  |  | 24 |  |  | (2) |  |  | 138 |  |  | (4) |  |
| Non-U.S. government and agency securities | 264 |  |  | — |  |  | — |  |  | — |  |  | 264 |  |  | — |  |
| Corporate debt securities | 6,920 |  |  | (240) |  |  | 422 |  |  | (37) |  |  | 7,342 |  |  | (277) |  |
| U.S. agency mortgage-backed securities | 1,305 |  |  | (96) |  |  | 615 |  |  | (62) |  |  | 1,920 |  |  | (158) |  |
| Total | $ | 9,713 |  |  | $ | (382) |  |  | $ | 1,181 |  |  | $ | (106) |  |  | $ | 10,894 |  |  | $ | (488) |  |

[0000858877-22-000025:notes:119]
The following table summarizes the maturities of our available-for-sale debt investments as of October 29, 2022 (in millions):

[0000858877-22-000025:notes:120]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 4,483 |  |  | $ | 4,399 |  |
| After 1 year through 5 years | 6,478 |  |  | 6,002 |  |
| After 5 years through 10 years | 56 |  |  | 47 |  |
| After 10 years | 1 |  |  | 1 |  |
| Mortgage-backed securities with no single maturity | 2,071 |  |  | 1,798 |  |
| Total | $ | 13,089 |  |  | $ | 12,247 |  |

[0000858877-22-000025:notes:121]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-22-000025:notes:122]
(b)Summary of Equity Investments

[0000858877-22-000025:notes:123]
We held marketable equity securities of $245 million and $241 million as of October 29, 2022 and July 30, 2022, respectively. We recognized a net unrealized loss of $20 million and a net unrealized gain of $5 million during the first quarter of fiscal 2023 and 2022, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $12 million and a net gain of $2 million for the first quarter of fiscal 2023 and 2022, respectively. We held equity interests in certain private equity funds of $1.0 billion and $1.1 billion as of October 29, 2022 and July 30, 2022, respectively, which are accounted for under the NAV practical expedient.

[0000858877-22-000025:notes:124]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 29, 2022, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-22-000025:notes:125]
The carrying value of our investments in privately held companies was $1.8 billion and $1.9 billion as of October 29, 2022 and July 30, 2022, respectively. Of the total carrying value of our investments in privately held companies as of October 29, 2022, $1.1 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of October 29, 2022, we have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-22-000025:notes:126]
Fair Value 
(a)Assets and Liabilities Measured at Fair Value on a Recurring Basis

[0000858877-22-000025:notes:127]
[same as prior period, unchanged from 0000858877-22-000009:notes:146]

[0000858877-22-000025:notes:128]
|  | OCTOBER 29, 2022 |  | JULY 30, 2022 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 3,144 |  |  | $ | — |  |  | $ | 3,144 |  |  | $ | 3,930 |  |  | $ | — |  |  | $ | 3,930 |  |
| Commercial paper | — |  |  | 1,017 |  |  | 1,017 |  |  | — |  |  | 72 |  |  | 72 |  |
| Certificates of deposit | — |  |  | 215 |  |  | 215 |  |  | — |  |  | 32 |  |  | 32 |  |
| U.S. government securities | — |  |  | 47 |  |  | 47 |  |  | — |  |  | 12 |  |  | 12 |  |
| Corporate debt securities | — |  |  | 52 |  |  | 52 |  |  | — |  |  | 1 |  |  | 1 |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 1,475 |  |  | 1,475 |  |  | — |  |  | 1,238 |  |  | 1,238 |  |
| U.S. government agency securities | — |  |  | 165 |  |  | 165 |  |  | — |  |  | 138 |  |  | 138 |  |
| Non-U.S. government and agency securities | — |  |  | 274 |  |  | 274 |  |  | — |  |  | 272 |  |  | 272 |  |
| Corporate debt securities | — |  |  | 7,316 |  |  | 7,316 |  |  | — |  |  | 7,818 |  |  | 7,818 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,798 |  |  | 1,798 |  |  | — |  |  | 1,976 |  |  | 1,976 |  |
| Commercial paper | — |  |  | 798 |  |  | 798 |  |  | — |  |  | 255 |  |  | 255 |  |
| Certificates of deposit | — |  |  | 421 |  |  | 421 |  |  | — |  |  | 250 |  |  | 250 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 245 |  |  | — |  |  | 245 |  |  | 241 |  |  | — |  |  | 241 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 1,500 |  |  | — |  |  | 1,500 |  |  | 1,500 |  |  | — |  |  | 1,500 |  |
| Derivative assets | — |  |  | 97 |  |  | 97 |  |  | — |  |  | 78 |  |  | 78 |  |
| Total | $ | 4,889 |  |  | $ | 13,675 |  |  | $ | 18,564 |  |  | $ | 5,671 |  |  | $ | 12,142 |  |  | $ | 17,813 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 138 |  |  | $ | 138 |  |  | $ | — |  |  | $ | 89 |  |  | $ | 89 |  |
| Total | $ | — |  |  | $ | 138 |  |  | $ | 138 |  |  | $ | — |  |  | $ | 89 |  |  | $ | 89 |  |

[0000858877-22-000025:notes:129]
[same as prior period, unchanged from 0000858877-22-000009:notes:148]

[0000858877-22-000025:notes:130]
(b)Assets Measured at Fair Value on a Nonrecurring Basis

[0000858877-22-000025:notes:131]
[same as prior period, unchanged from 0000858877-22-000009:notes:150]

[0000858877-22-000025:notes:132]
(c)  Other Fair Value Disclosures

[0000858877-22-000025:notes:133]
The fair value of our short-term loan receivables approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables as of October 29, 2022 and July 30, 2022 was $3.0 billion and $3.4 billion, respectively. The estimated fair value of our long-term loan receivables approximates their carrying value. We use unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables, and therefore they are categorized as Level 3.
As of October 29, 2022, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of October 29, 2022, the fair value of our senior notes was $8.8 billion with a carrying amount of $8.9 billion. This compares to a fair value of $9.7 billion and a carrying amount of $8.9 billion as of July 30, 2022. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:DebtDisclosureTextBlock

[0000858877-22-000025:notes:134]
Borrowings 
(a)Short-Term Debt

[0000858877-22-000025:notes:135]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-22-000025:notes:136]
|  | October 29, 2022 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,249 |  |  | 2.44 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,249 |  |  |  |  | $ | 1,099 |  |  |  |

[0000858877-22-000025:notes:137]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-22-000025:notes:138]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-22-000025:notes:139]
(b)Long-Term Debt

[0000858877-22-000025:notes:140]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-22-000025:notes:141]
|  |  |  | October 29, 2022 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | 500 |  |  | 2.68% |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 4.04% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 4.61% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,000 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (73) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (49) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,878 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,249 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 7,629 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,878 |  |  |  |  | $ | 8,915 |  |  |  |

[0000858877-22-000025:notes:142]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $1.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-22-000025:notes:143]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 29, 2022, we were in compliance with all debt covenants.

[0000858877-22-000025:notes:144]
As of October 29, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-22-000025:notes:145]
| Fiscal Year | Amount |
| 2023 (remaining nine months) | $ | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 9,000 |  |

[0000858877-22-000025:notes:146]
(c)Credit Facility

[0000858877-22-000025:notes:147]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of October 29, 2022, we were in compliance

[0000858877-22-000025:notes:148]
with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.

[0000858877-22-000025:notes:149]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-22-000025:notes:150]
[same as prior period, unchanged from 0000858877-22-000009:notes:168]

[0000858877-22-000025:notes:151]
[same as prior period, unchanged from 0000858877-22-000009:notes:169]

[0000858877-22-000025:notes:152]
[same as prior period, unchanged from 0000858877-22-000009:notes:170]

[0000858877-22-000025:notes:153]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | October 29,2022 |  | July 30,2022 |  | Balance Sheet Line Item |  | October 29,2022 |  | July 30,2022 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 61 |  |  | $ | 55 |  |  | Other current liabilities |  | $ | — |  |  | $ | — |  |
| Foreign currency derivatives | Other assets |  | 15 |  |  | 9 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 49 |  |  | 10 |  |
| Total |  |  | 76 |  |  | 64 |  |  |  |  | 49 |  |  | 10 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 21 |  |  | 14 |  |  | Other current liabilities |  | 73 |  |  | 69 |  |
| Foreign currency derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 16 |  |  | 9 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | — |  |  | 1 |  |
| Total |  |  | 21 |  |  | 14 |  |  |  |  | 89 |  |  | 79 |  |
| Total |  |  | $ | 97 |  |  | $ | 78 |  |  |  |  | $ | 138 |  |  | $ | 89 |  |

[0000858877-22-000025:notes:154]
[same as prior period, unchanged from 0000858877-22-000009:notes:172]

[0000858877-22-000025:notes:155]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | October 29,2022 |  | July 30,2022 |  | October 29,2022 |  | July 30,2022 |
| Long-term debt |  | $ | (1,448) |  |  | $ | (1,487) |  |  | $ | 49 |  |  | $ | 10 |  |

[0000858877-22-000025:notes:156]
[same as prior period, unchanged from 0000858877-22-000009:notes:174]

[0000858877-22-000025:notes:157]
|  |  | GAINS (LOSSES) FOR THE THREE MONTHS ENDED |
|  |  | October 29, 2022 |  | October 30, 2021 |
| Interest rate derivatives: |  |  |  |  |
| Hedged items |  | $ | 39 |  |  | $ | 26 |  |
| Derivatives designated as hedging instruments |  | (39) |  |  | (27) |  |
| Total |  | $ | — |  |  | $ | (1) |  |

[0000858877-22-000025:notes:158]
[same as prior period, unchanged from 0000858877-22-000009:notes:176]

[0000858877-22-000025:notes:159]
|  |  |  |  | GAINS (LOSSES) FOR THE THREE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | October 29,2022 |  | October 30,2021 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (72) |  |  | $ | (20) |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | (25) |  |  | 21 |  |
| Equity derivatives |  | Other income (loss), net |  | (1) |  |  | 4 |  |
| Total |  |  |  | $ | (98) |  |  | $ | 5 |  |

[0000858877-22-000025:notes:160]
[same as prior period, unchanged from 0000858877-22-000009:notes:178]

[0000858877-22-000025:notes:161]
|  | October 29,2022 |  | July 30,2022 |
| Foreign currency derivatives | $ | 4,183 |  |  | $ | 4,521 |  |
| Interest rate derivatives | 1,500 |  |  | 1,500 |  |
| Total return swaps—deferred compensation | 676 |  |  | 651 |  |
| Total | $ | 6,359 |  |  | $ | 6,672 |  |

[0000858877-22-000025:notes:162]
[same as prior period, unchanged from 0000858877-22-000009:notes:180]

[0000858877-22-000025:notes:163]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty.

[0000858877-22-000025:notes:164]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral provided for was $53 million and $14 million as of October 29, 2022 and July 30, 2022, respectively.

[0000858877-22-000025:notes:165]
[same as prior period, unchanged from 0000858877-22-000009:notes:183]

[0000858877-22-000025:notes:166]
[same as prior period, unchanged from 0000858877-22-000009:notes:184]

[0000858877-22-000025:notes:167]
[same as prior period, unchanged from 0000858877-22-000009:notes:185]

[0000858877-22-000025:notes:168]
[same as prior period, unchanged from 0000858877-22-000009:notes:186]

[0000858877-22-000025:notes:169]
[same as prior period, unchanged from 0000858877-22-000009:notes:187]

[0000858877-22-000025:notes:170]
[same as prior period, unchanged from 0000858877-22-000009:notes:188]

[0000858877-22-000025:notes:171]
We hold interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2024 through 2025. Under these interest rate swaps, we receive fixed-rate interest payments and make interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.

[0000858877-22-000025:notes:172]
[same as prior period, unchanged from 0000858877-22-000009:notes:190]

[0000858877-22-000025:notes:173]
[same as prior period, unchanged from 0000858877-22-000009:notes:191]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-22-000025:notes:174]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-22-000025:notes:175]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-22-000025:notes:176]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-22-000025:notes:177]
|  | October 29,2022 |  | July 30,2022 |
| Less than 1 year | $ | 10,160 |  |  | $ | 9,954 |  |
| 1 to 3 years | 1,606 |  |  | 2,240 |  |
| 3 to 5 years | 842 |  |  | 770 |  |
| Total | $ | 12,608 |  |  | $ | 12,964 |  |

[0000858877-22-000025:notes:178]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 29, 2022 and July 30, 2022, the liability for these purchase commitments was $380 million and $313 million, respectively, and was included in other current liabilities.

[0000858877-22-000025:notes:179]
(b)Other Commitments

[0000858877-22-000025:notes:180]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-22-000025:notes:181]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-22-000025:notes:182]
|  | Three Months Ended |
|  | October 29, 2022 |  | October 30, 2021 |
| Compensation expense related to acquisitions | $ | 74 |  |  | $ | 89 |  |

[0000858877-22-000025:notes:183]
As of October 29, 2022, we estimated that future cash compensation expense of up to $388 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-22-000025:notes:184]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion and $0.4 billion as of October 29, 2022 and July 30, 2022, respectively.

[0000858877-22-000025:notes:185]
(c)Product Warranties

[0000858877-22-000025:notes:186]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-22-000025:notes:187]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |
| Balance at beginning of period | $ | 333 |  |  | $ | 336 |  |
| Provisions for warranties issued | 97 |  |  | 114 |  |
| Adjustments for pre-existing warranties | 1 |  |  | 2 |  |
| Settlements | (108) |  |  | (111) |  |
| Balance at end of period | $ | 323 |  |  | $ | 341 |  |

[0000858877-22-000025:notes:188]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-22-000025:notes:189]
(d)Financing and Other Guarantees

[0000858877-22-000025:notes:190]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-22-000025:notes:191]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.6 billion and $6.6 billion for the first quarter of fiscal 2023 and 2022, respectively. The balance of the channel partner financing subject to guarantees was $1.5 billion and $1.4 billion as of October 29, 2022 and July 30, 2022, respectively.

[0000858877-22-000025:notes:192]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at October 29, 2022 and July 30, 2022, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-22-000025:notes:193]
|  | October 29,2022 |  | July 30,2022 |
| Maximum potential future payments | $ | 162 |  |  | $ | 188 |  |
| Deferred revenue | (19) |  |  | (9) |  |
| Total | $ | 143 |  |  | $ | 179 |  |

[0000858877-22-000025:notes:194]
(e)Indemnifications

[0000858877-22-000025:notes:195]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-22-000025:notes:196]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-22-000025:notes:197]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-22-000025:notes:198]
(f)Legal Proceedings

[0000858877-22-000025:notes:199]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $153 million for the alleged evasion of import and other taxes, $820 million for interest, and $378 million for various penalties, all determined using an exchange rate as of October 29, 2022.

[0000858877-22-000025:notes:200]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-22-000025:notes:201]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. The district court case went to trial on five asserted patents. Subsequently, on October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent and awarded $1.9 billion in damages and $14 million in pre-judgment interest, declined to issue an injunction but, instead, awarded Centripetal a royalty against future revenue for an initial three-year term at a 10% rate, with a minimum and maximum annual royalty of $168 million and $300 million, respectively, and for a second three-year term at a 5% rate, with a minimum and maximum annual royalty of $84 million and $150 million, respectively. We appealed and, on June 23, 2022, the Federal Circuit vacated the district court’s final judgment, remanded the case back to the district court to be assigned to a new judge and ordered the district court to conduct additional proceedings. On August 9, 2022, Centripetal filed a petition for writ of certiorari in the U.S. Supreme Court challenging the Federal Circuit’s decision. Cisco filed its opposition brief on October 26, 2022 and the proceedings are ongoing.

[0000858877-22-000025:notes:202]
Between April 2020 and February 2022, Centripetal filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. On December 10, 2021, the German Court rejected Centripetal’s complaints on two patents, and Centripetal appealed. A hearing for a Cisco nullity action in the Federal Patent Court in Germany on one of those two patents occurred on August 1, 2022, and we are waiting for the Court’s opinion. On December 21, 2021, the German Court stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. On May 17, 2022, Centripetal withdrew its complaint for infringement of the German utility model. The German Court has set a hearing on the remaining two Centripetal complaints for November 22, 2022.

[0000858877-22-000025:notes:203]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of the litigations at this time. If we do not prevail in either litigation, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-22-000025:notes:204]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. The PTO preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings and the pending District Court case has been stayed. On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) in the District of Delaware (“D. Del.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot asserted in the E.D. Tex. case and this case is also stayed pending reexamination proceedings.

[0000858877-22-000025:notes:205]
On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents in the same family as those involved in the pending cases above. Ramot counterclaimed and filed another suit in E.D. Tex. for infringement of the same patents and seeks damages, including enhanced damages, and a royalty on future sales. While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do

[0000858877-22-000025:notes:206]
not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-22-000025:notes:207]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward (“Viasat 2”). Viasat 2 is similar to a previous suit Viasat filed against Acacia and which resolved in July 2022 for an immaterial amount (“Viasat 1”). On June 9, 2020, Viasat filed a third suit in SDSC alleging contract and trade secrets claims for sales of additional Acacia products (“Viasat 3”, together with Viasat 2, the “Viasat Cases”). In October 2022, an amended complaint was filed in Viasat 3 asserting the same claims but alleging additional information.

[0000858877-22-000025:notes:208]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court against Viasat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation (the “Massachusetts Action”). On April 5, 2018, Viasat counterclaimed with contract, trade secret, and unfair competition claims. Following resolution of Viasat 1, Acacia and Viasat jointly agreed to dismiss the Massachusetts Action in October 2022, thereby resolving the case.

[0000858877-22-000025:notes:209]
We are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If we do not prevail, we believe that any relief ultimately assessed in any of the Viasat Cases would not have a material effect on our Consolidated Financial Statements.

[0000858877-22-000025:notes:210]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. On October 27, 2022, Egenera filed a motion for judgment of infringement and a motion for new trial. Cisco opposed those motions and the post-trial proceedings are ongoing.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-22-000025:notes:211]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-22-000025:notes:212]
Stockholders’ Equity 
(a)Stock Repurchase Program

[0000858877-22-000025:notes:213]
In September 2001, our Board of Directors authorized a stock repurchase program. As of October 29, 2022, the remaining authorized amount for stock repurchases under this program was approximately $14.7 billion with no termination date. A summary of the stock repurchase activity for fiscal 2023 and 2022 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-22-000025:notes:214]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2023 |  |  |  |  |  |  |
| October 29, 2022 |  | 12 |  | $ | 43.76 |  |  | $ | 502 |  |
| Fiscal 2022 |  |  |  |  |  |  |
| July 30, 2022 |  | 54 |  |  | $ | 44.02 |  |  | $ | 2,402 |  |
| April 30, 2022 |  | 5 |  |  | $ | 54.20 |  |  | $ | 252 |  |
| January 29, 2022 |  | 82 |  |  | $ | 58.36 |  |  | $ | 4,824 |  |
| October 30, 2021 |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |

[0000858877-22-000025:notes:215]
There were stock repurchases of $16 million and $70 million that were pending settlement as of October 29, 2022 and July 30, 2022, respectively.

[0000858877-22-000025:notes:216]
[same as prior period, unchanged from 0000858877-22-000009:notes:245]

[0000858877-22-000025:notes:217]
(b)   Preferred Stock

[0000858877-22-000025:notes:218]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock in one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights, if any, of such series, and any qualifications, limitations or restrictions thereof, of the shares of such series. As of October 29, 2022, we had not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-22-000025:notes:219]
[same as prior period, unchanged from 0000858877-22-000009:notes:248]

[0000858877-22-000025:notes:220]
[same as prior period, unchanged from 0000858877-22-000009:notes:249]

[0000858877-22-000025:notes:221]
The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions. Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. The 2005 Plan may be terminated by our Board of Directors at any time and for any reason, and is currently set to terminate at the 2030 Annual Meeting unless re-adopted or extended by our stockholders prior to or on such date.

[0000858877-22-000025:notes:222]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of October 29, 2022, 189 million shares were authorized for future grant under the 2005 Plan.

[0000858877-22-000025:notes:223]
[same as prior period, unchanged from 0000858877-22-000009:notes:252]

[0000858877-22-000025:notes:224]
We have an Employee Stock Purchase Plan under which eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. No shares were issued under the Employee Stock Purchase Plan during each of the first quarters of fiscal 2023 and 2022. As of October 29, 2022, 107 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-22-000025:notes:225]
[same as prior period, unchanged from 0000858877-22-000009:notes:254]

[0000858877-22-000025:notes:226]
[same as prior period, unchanged from 0000858877-22-000009:notes:255]

[0000858877-22-000025:notes:227]
|  | Three Months Ended |
|  | October 29, 2022 |  | October 30, 2021 |
| Cost of sales—product | $ | 31 |  |  | $ | 25 |  |
| Cost of sales—service | 50 |  |  | 44 |  |
| Share-based compensation expense in cost of sales | 81 |  |  | 69 |  |
| Research and development | 204 |  |  | 181 |  |
| Sales and marketing | 153 |  |  | 140 |  |
| General and administrative | 58 |  |  | 62 |  |
| Restructuring and other charges | — |  |  | 1 |  |
| Share-based compensation expense in operating expenses | 415 |  |  | 384 |  |
| Total share-based compensation expense | $ | 496 |  |  | $ | 453 |  |
| Income tax benefit for share-based compensation | $ | 99 |  |  | $ | 104 |  |

[0000858877-22-000025:notes:228]
As of October 29, 2022, the total compensation cost related to unvested share-based awards not yet recognized was $4.2 billion which is expected to be recognized over approximately 2.5 years on a weighted-average basis.

[0000858877-22-000025:notes:229]
[same as prior period, unchanged from 0000858877-22-000009:notes:258]

[0000858877-22-000025:notes:230]
[same as prior period, unchanged from 0000858877-22-000009:notes:259]

[0000858877-22-000025:notes:231]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| Unvested balance at July 31, 2021 | 94 |  |  | $ | 42.93 |  |  |  |
| Granted and assumed | 52 |  |  | 50.06 |  |  |  |
| Vested | (37) |  |  | 42.27 |  |  | $ | 1,979 |  |
| Canceled/forfeited/other | (12) |  |  | 45.63 |  |  |  |
| Unvested balance at July 30, 2022 | 97 |  |  | $ | 46.67 |  |  |  |
| Granted and assumed | 13 |  |  | 37.70 |  |  |  |
| Vested | (8) |  |  | 45.28 |  |  | $ | 321 |  |
| Canceled/forfeited/other | (2) |  |  | 47.09 |  |  |  |
| Unvested balance at October 29, 2022 | 100 |  |  | $ | 45.60 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-22-000025:notes:232]
Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first quarter of fiscal 2023 and 2022 are summarized as follows (in millions):

[0000858877-22-000025:notes:233]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 30, 2022 | $ | (379) |  |  | $ | 44 |  |  | $ | (1,287) |  |  | $ | (1,622) |  |
| Other comprehensive income (loss) before reclassifications | (329) |  |  | 32 |  |  | (282) |  |  | (579) |  |
| (Gains) losses reclassified out of AOCI | 6 |  |  | (19) |  |  | — |  |  | (13) |  |
| Tax benefit (expense) | 77 |  |  | (3) |  |  | 22 |  |  | 96 |  |
| Balance at October 29, 2022 | $ | (625) |  |  | $ | 54 |  |  | $ | (1,547) |  |  | $ | (2,118) |  |

[0000858877-22-000025:notes:234]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 31, 2021 | $ | 182 |  |  | $ | (1) |  |  | $ | (598) |  |  | $ | (417) |  |
| Other comprehensive income (loss) before reclassifications | (111) |  |  | 8 |  |  | 16 |  |  | (87) |  |
| (Gains) losses reclassified out of AOCI | (6) |  |  | (1) |  |  | — |  |  | (7) |  |
| Tax benefit (expense) | 30 |  |  | (1) |  |  | 9 |  |  | 38 |  |
| Balance at October 30, 2021 | $ | 95 |  |  | $ | 5 |  |  | $ | (573) |  |  | $ | (473) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-22-000025:notes:235]
[same as prior period, unchanged from 0000858877-22-000009:notes:264]

[0000858877-22-000025:notes:236]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |
| Income before provision for income taxes | $ | 3,475 |  |  | $ | 3,657 |  |
| Provision for income taxes | $ | 805 |  |  | $ | 677 |  |
| Effective tax rate | 23.2 | % |  | 18.5 | % |

[0000858877-22-000025:notes:237]
As of October 29, 2022, we had $3.3 billion of unrecognized tax benefits, of which $2.4 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-22-000025:notes:238]
[same as prior period, unchanged from 0000858877-22-000009:notes:267]

[0000858877-22-000025:notes:239]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-22-000025:notes:240]
Summarized financial information by segment for the first quarter of fiscal 2023 and 2022, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-22-000025:notes:241]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |
| Revenue: |  |  |  |
| Americas | $ | 7,914 |  |  | $ | 7,561 |  |
| EMEA | 3,675 |  |  | 3,303 |  |
| APJC | 2,043 |  |  | 2,036 |  |
| Total | $ | 13,632 |  |  | $ | 12,900 |  |
| Gross margin: |  |  |  |
| Americas | $ | 4,984 |  |  | $ | 4,875 |  |
| EMEA | 2,325 |  |  | 2,128 |  |
| APJC | 1,274 |  |  | 1,317 |  |
| Segment total | 8,582 |  |  | 8,321 |  |
| Unallocated corporate items | (236) |  |  | (268) |  |
| Total | $ | 8,346 |  |  | $ | 8,053 |  |

[0000858877-22-000025:notes:242]
Amounts may not sum due to rounding.

[0000858877-22-000025:notes:243]
Revenue in the United States was $7.1 billion and $6.8 billion for the first quarter of fiscal 2023 and 2022, respectively.

[0000858877-22-000025:notes:244]
[same as prior period, unchanged from 0000858877-22-000009:notes:273]

[0000858877-22-000025:notes:245]
We design and sell Internet Protocol (IP)-based networking and other products related to the communications and IT industry and provide services associated with these products and their use.


## us-gaap:EarningsPerShareTextBlock

[0000858877-22-000025:notes:246]
[same as prior period, unchanged from 0000858877-22-000009:notes:275]

[0000858877-22-000025:notes:247]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |
| Net income | $ | 2,670 |  |  | $ | 2,980 |  |
| Weighted-average shares—basic | 4,108 |  |  | 4,218 |  |
| Effect of dilutive potential common shares | 8 |  |  | 25 |  |
| Weighted-average shares—diluted | 4,116 |  |  | 4,243 |  |
| Net income per share—basic | $ | 0.65 |  |  | $ | 0.71 |  |
| Net income per share—diluted | $ | 0.65 |  |  | $ | 0.70 |  |
| Antidilutive employee share-based awards, excluded | 38 |  |  | 12 |  |
