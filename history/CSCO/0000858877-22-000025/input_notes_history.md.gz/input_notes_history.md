# CSCO note change history — 0000858877-22-000009 → 0000858877-22-000025


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-11-22):
[0000858877-22-000025:note_history:1]
|  | October 29,2022 |  | July 30,2022 |
| Less than 1 year | $ | 10,160 |  |  | $ | 9,954 |  |
| 1 to 3 years | 1,606 |  |  | 2,240 |  |
| 3 to 5 years | 842 |  |  | 770 |  |
| Total | $ | 12,608 |  |  | $ | 12,964 |  |
  (was, 2022-05-25, similarity 0.963):
[0000858877-22-000009:note_history:1]
|  | April 30,2022 |  | July 31,2021 |
| Less than 1 year | $ | 10,698 |  |  | $ | 6,903 |  |
| 1 to 3 years | 2,401 |  |  | 1,806 |  |
| 3 to 5 years | — |  |  | 1,545 |  |
| Total | $ | 13,099 |  |  | $ | 10,254 |  |

- changed (2022-11-22):
[0000858877-22-000025:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 29, 2022 and July 30, 2022, the liability for these purchase commitments was $380 million and $313 million, respectively, and was included in other current liabilities.
  (was, 2022-05-25, similarity 0.7957):
[0000858877-22-000009:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 30, 2022 and July 31, 2021, the liability for these purchase commitments was $236 million and $151 million, respectively, and was included in other current liabilities. For further discussion around the Supply Constraints Impacts and Risks, see Result of Operations—Product Gross Margin and Liquidity and Capital Resources—Inventory Supply Chain.

- changed (2022-11-22):
[0000858877-22-000025:note_history:3]
|  | Three Months Ended |
|  | October 29, 2022 |  | October 30, 2021 |
| Compensation expense related to acquisitions | $ | 74 |  |  | $ | 89 |  |
  (was, 2022-05-25, similarity 0.7222):
[0000858877-22-000009:note_history:3]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2022 |  | May 1, 2021 |  | April 30, 2022 |  | May 1, 2021 |
| Compensation expense related to acquisitions | $ | 56 |  |  | $ | 66 |  |  | $ | 220 |  |  | $ | 182 |  |

- changed (2022-11-22):
[0000858877-22-000025:note_history:4]
As of October 29, 2022, we estimated that future cash compensation expense of up to $388 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2022-05-25, similarity 0.9722):
[0000858877-22-000009:note_history:4]
As of April 30, 2022, we estimated that future cash compensation expense of up to $534 million may be required to be recognized pursuant to the applicable business combination agreements.

- changed (2022-11-22):
[0000858877-22-000025:note_history:5]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion and $0.4 billion as of October 29, 2022 and July 30, 2022, respectively.
  (was, 2022-05-25, similarity 0.9806):
[0000858877-22-000009:note_history:5]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.4 billion and $0.2 billion as of April 30, 2022 and July 31, 2021, respectively.

- changed (2022-11-22):
[0000858877-22-000025:note_history:6]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |
| Balance at beginning of period | $ | 333 |  |  | $ | 336 |  |
| Provisions for warranties issued | 97 |  |  | 114 |  |
| Adjustments for pre-existing warranties | 1 |  |  | 2 |  |
| Settlements | (108) |  |  | (111) |  |
| Balance at end of period | $ | 323 |  |  | $ | 341 |  |
  (was, 2022-05-25, similarity 0.8657):
[0000858877-22-000009:note_history:6]
|  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |
| Balance at beginning of period | $ | 336 |  |  | $ | 331 |  |
| Provisions for warranties issued | 320 |  |  | 382 |  |
| Adjustments for pre-existing warranties | 1 |  |  | 1 |  |
| Settlements | (322) |  |  | (373) |  |
| Balance at end of period | $ | 335 |  |  | $ | 341 |  |

- changed (2022-11-22):
[0000858877-22-000025:note_history:7]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners customers. Payments under these financing guarantee arrangements were not material for the periods presented.
  (was, 2022-05-25, similarity 0.975):
[0000858877-22-000009:note_history:7]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

- changed (2022-11-22):
[0000858877-22-000025:note_history:8]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.6 billion and $6.6 billion for the first quarter of fiscal 2023 and 2022, respectively. The balance of the channel partner financing subject to guarantees was $1.5 billion and $1.4 billion as of October 29, 2022 and July 30, 2022, respectively.
  (was, 2022-05-25, similarity 0.8824):
[0000858877-22-000009:note_history:8]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.9 billion and $6.6 billion for the third quarter of fiscal 2022 and 2021, respectively, and was $20.3 billion and $19.5 billion for the first nine months of fiscal 2022 and 2021, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion as of each of April 30, 2022 and July 31, 2021.

- changed (2022-11-22):
[0000858877-22-000025:note_history:9]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at October 29, 2022 and July 30, 2022, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2022-05-25, similarity 0.8464):
[0000858877-22-000009:note_history:9]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 30, 2022 and July 31, 2021, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- added (2022-11-22):
[0000858877-22-000025:note_history:10]
|  | October 29,2022 |  | July 30,2022 |
| Maximum potential future payments | $ | 162 |  |  | $ | 188 |  |
| Deferred revenue | (19) |  |  | (9) |  |
| Total | $ | 143 |  |  | $ | 179 |  |

- added (2022-11-22):
[0000858877-22-000025:note_history:11]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

- changed (2022-11-22):
[0000858877-22-000025:note_history:12]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $153 million for the alleged evasion of import and other taxes, $820 million for interest, and $378 million for various penalties, all determined using an exchange rate as of October 29, 2022.
  (was, 2022-05-25, similarity 0.995):
[0000858877-22-000009:note_history:12]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $163 million for the alleged evasion of import and other taxes, $840 million for interest, and $402 million for various penalties, all determined using an exchange rate as of April 30, 2022.

- added (2022-11-22):
[0000858877-22-000025:note_history:13]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. The district court case went to trial on five asserted patents. Subsequently, on October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent and awarded $1.9 billion in damages and $14 million in pre-judgment interest, declined to issue an injunction but, instead, awarded Centripetal a royalty against future revenue for an initial three-year term at a 10% rate, with a minimum and maximum annual royalty of $168 million and $300 million, respectively, and for a second three-year term at a 5% rate, with a minimum and maximum annual royalty of $84 million and $150 million, respectively. We appealed and, on June 23, 2022, the Federal Circuit vacated the district court’s final judgment, remanded the case back to the district court to be assigned to a new judge and ordered the district court to conduct additional proceedings. On August 9, 2022, Centripetal filed a petition for writ of certiorari in the U.S. Supreme Court challenging the Federal Circuit’s decision. Cisco filed its opposition brief on October 26, 2022 and the proceedings are ongoing.

- added (2022-11-22):
[0000858877-22-000025:note_history:14]
Between April 2020 and February 2022, Centripetal filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. On December 10, 2021, the German Court rejected Centripetal’s complaints on two patents, and Centripetal appealed. A hearing for a Cisco nullity action in the Federal Patent Court in Germany on one of those two patents occurred on August 1, 2022, and we are waiting for the Court’s opinion. On December 21, 2021, the German Court stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. On May 17, 2022, Centripetal withdrew its complaint for infringement of the German utility model. The German Court has set a hearing on the remaining two Centripetal complaints for November 22, 2022.

- changed (2022-11-22):
[0000858877-22-000025:note_history:15]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of the litigations at this time. If we do not prevail in either litigation, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.
  (was, 2022-05-25, similarity 0.9529):
[0000858877-22-000009:note_history:15]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of either litigation at this time. If we do not prevail in either litigation, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

- added (2022-11-22):
[0000858877-22-000025:note_history:16]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. The PTO preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings and the pending District Court case has been stayed. On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) in the District of Delaware (“D. Del.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot asserted in the E.D. Tex. case and this case is also stayed pending reexamination proceedings.

- added (2022-11-22):
[0000858877-22-000025:note_history:17]
On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents in the same family as those involved in the pending cases above. Ramot counterclaimed and filed another suit in E.D. Tex. for infringement of the same patents and seeks damages, including enhanced damages, and a royalty on future sales. While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do

- changed (2022-11-22):
[0000858877-22-000025:note_history:18]
not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.
  (was, 2022-05-25, similarity 0.7082):
[0000858877-22-000009:note_history:18]
believe that any relief ultimately assessed in any of the Viasat Cases would not have a material effect on our Consolidated Financial Statements.

- added (2022-11-22):
[0000858877-22-000025:note_history:19]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward (“Viasat 2”). Viasat 2 is similar to a previous suit Viasat filed against Acacia and which resolved in July 2022 for an immaterial amount (“Viasat 1”). On June 9, 2020, Viasat filed a third suit in SDSC alleging contract and trade secrets claims for sales of additional Acacia products (“Viasat 3”, together with Viasat 2, the “Viasat Cases”). In October 2022, an amended complaint was filed in Viasat 3 asserting the same claims but alleging additional information.

- added (2022-11-22):
[0000858877-22-000025:note_history:20]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court against Viasat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation (the “Massachusetts Action”). On April 5, 2018, Viasat counterclaimed with contract, trade secret, and unfair competition claims. Following resolution of Viasat 1, Acacia and Viasat jointly agreed to dismiss the Massachusetts Action in October 2022, thereby resolving the case.

- added (2022-11-22):
[0000858877-22-000025:note_history:21]
We are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If we do not prevail, we believe that any relief ultimately assessed in any of the Viasat Cases would not have a material effect on our Consolidated Financial Statements.

- added (2022-11-22):
[0000858877-22-000025:note_history:22]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. On October 27, 2022, Egenera filed a motion for judgment of infringement and a motion for new trial. Cisco opposed those motions and the post-trial proceedings are ongoing.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.

- removed (2022-11-22):
[0000858877-22-000009:note_history:23]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $3 million and $1 million for the third quarter of fiscal 2022 and 2021, respectively, and was $9 million and $8 million for the first nine months of fiscal 2022 and 2021, respectively.

- removed (2022-11-22):
[0000858877-22-000009:note_history:24]
|  | April 30,2022 |  | July 31,2021 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 144 |  |  | $ | 155 |  |
| End user | 4 |  |  | 5 |  |
| Total | $ | 148 |  |  | $ | 160 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (15) |  |  | $ | (16) |  |
| End user | (4) |  |  | (5) |  |
| Total | $ | (19) |  |  | $ | (21) |  |
| Total | $ | 129 |  |  | $ | 139 |  |

- removed (2022-11-22):
[0000858877-22-000009:note_history:25]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations discussed in this section (e) due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these cases, and the unique facts and circumstances involved in each particular case and agreement. We are unable to reasonably estimate the ultimate outcome of the cases discussed below in this section (e), but we do not believe that any potential indemnity liability would be material, and historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

- removed (2022-11-22):
[0000858877-22-000009:note_history:26]
We were asked by seven of our customers to indemnify them in connection with patent infringement claims asserted against them by Estech Systems, Inc. (“Estech”) in the Eastern District of Texas (“E.D. Tex.”) court and the Western District of Texas court between April 24, 2020 and August 25, 2020. Estech alleged that the customer defendants infringe three patents generally related to IP telephony by using collaboration technology from us and other providers. Estech was seeking monetary damages from the customer defendants. Estech and the customer defendants resolved Estech’s claims, and we resolved the customer defendants’ indemnity claims for an amount that did not have a material effect on our Consolidated Financial Statements.

- removed (2022-11-22):
[0000858877-22-000009:note_history:27]
China     We have completed our investigation into allegations of a self-enrichment scheme involving now-former employees in China, and shared the results of the investigation with the Securities and Exchange Commission (“SEC”) and the Department of Justice (“DOJ”). Based on the investigation results, both the SEC and the DOJ have informed the Company that they do not plan to take any action against the Company in connection with these allegations.

- removed (2022-11-22):
[0000858877-22-000009:note_history:28]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted claims against us in the U.S. District Court for the District of Delaware (“D. Del.”), accusing our products and services related to network intrusion detection of infringing two patents. After a trial, SRI obtained a verdict against us, and we appealed to the United States Court of Appeals for the Federal Circuit (“Federal Circuit”) which was ultimately unsuccessful. In resolution of this matter, we have paid the SRI judgments, including attorneys’ fees and post-judgment royalties and interest, in the aggregate amount of approximately $60 million. On May 17, 2022, the District Court entered a final order in the case requiring us to pay SRI additional post-judgment interest of approximately $1 million. We made the payment and the case is now concluded.

- removed (2022-11-22):
[0000858877-22-000009:note_history:29]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services (including our Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal U.S. patents. We thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office (“PTO”) to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. The PTAB’s findings of unpatentability have been affirmed on appeal.

- removed (2022-11-22):
[0000858877-22-000009:note_history:30]
For the five asserted U.S. patents not subject to the IPR Proceedings, the district court conducted a bench trial by videoconference from May 6, 2020 to June 25, 2020. On October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The district court awarded Centripetal $1.9 billion, comprised of $756 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $14 million. The district court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $168 million and a maximum annual royalty of $300 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $84 million and a maximum annual royalty of $150 million. We believe that the district court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We have appealed the district court’s judgment as to the four patents found valid and infringed to the Federal Circuit. On October 28, 2020, by agreement of the parties, the district court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment.

- removed (2022-11-22):
[0000858877-22-000009:note_history:31]
Centripetal has submitted complaints in the District Court of Dusseldorf in Germany (“German Court”) against Cisco Systems GmbH and Cisco Systems, Inc., asserting a total of six patents. On April 29, 2020 and April 30, 2020, Centripetal asserted three European patents, seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. district court proceedings, one of which has been invalidated by the PTAB.

- removed (2022-11-22):
[0000858877-22-000009:note_history:32]
On June 22, 2021, Centripetal amended one of its complaints to assert one additional European patent and one additional German Utility Model patent. On December 10, 2021, the German Court rejected Centripetal’s complaints on two patents. Centripetal has appealed. On December 21, 2021, the German Court stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. On May 17, 2022, Centripetal withdrew its complaint for infringement of the German Utility Model patent. The proceedings on Centripetal’s European patent filed on June 22, 2021 remains pending.

- removed (2022-11-22):
[0000858877-22-000009:note_history:33]
On February 14, 2022, Centripetal filed an additional complaint asserting infringement of a sixth patent issued by the European Patent Office. Centripetal seeks both injunctive relief and damages on these patents. We are assessing the complaint and are preparing our defense.

- removed (2022-11-22):
[0000858877-22-000009:note_history:34]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in E.D. Tex., seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. As of November 27, 2020, the PTO preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings. On January 13, 2021, the court entered an order staying the case pending the conclusion of the ex parte reexamination proceedings (“Reexamination Proceedings”). While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in court, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

- removed (2022-11-22):
[0000858877-22-000009:note_history:35]
On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) (which we subsequently acquired) in D. Del, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot has asserted in its E.D. Tex. case. On September 3, 2021, the court stayed the case pending the ultimate resolution of the Reexamination Proceedings. Due to the early stage of the litigation as well as uncertainties in the litigation processes, we are unable, at this time, to reasonably estimate a potential range of loss, if any, or the ultimate outcome of this litigation.

- removed (2022-11-22):
[0000858877-22-000009:note_history:36]
Viasat     On January 21, 2016, Viasat, Inc. (“Viasat”) filed suit against Acacia (which we subsequently acquired) in the California Superior Court for San Diego County (“SDSC”) seeking unpaid royalties for breach of contract and the implied covenant of good faith and fair dealing, and damages for trade secret misappropriation for certain products (“Viasat 1”). Acacia counterclaimed for patent and trade secret misappropriation, contract, and unfair competition claims. On July 17, 2019, the jury found for Viasat on its contract claims, and awarded Viasat approximately $49 million for unpaid royalties through 2018. The jury further found that Acacia willfully misappropriated Viasat’s trade secrets and awarded Viasat $1. On Acacia’s counterclaims, the jury found for Acacia on its contract and trade secret claims and awarded Acacia $1. Both Acacia and Viasat appealed to the California Court of Appeal, Fourth Appellate District (“CCA”). On May 23, 2022, the CCA affirmed the judgment of approximately $49 million, plus post-judgment interest and costs, for Viasat on its breach of contract claim for unpaid royalties, but reversed the judgments for Viasat for breach of the implied covenant of good faith and fair dealing, and for trade secret misappropriation. We are currently reviewing the decision of the CCA and assessing whether to seek additional appellate review.

- removed (2022-11-22):
[0000858877-22-000009:note_history:37]
On November 6, 2019, Viasat filed a second suit in SDSC, alleging contract and trade secret claims for Acacia products sold from January 1, 2019 forward (“Viasat 2”). On February 28, 2020, the court stayed Viasat 2 pending the appeal in Viasat 1. On June 9, 2020, Viasat filed a third suit in SDSC (“Viasat 3”). In Viasat 3, Viasat alleges contract and trade secrets claims for sales of additional Acacia products. On August 11, 2020, the court stayed Viasat 3 pending the appeal in Viasat 1.

- removed (2022-11-22):
[0000858877-22-000009:note_history:38]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court - Business Litigation Session against ViaSat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation. On April 5, 2018, ViaSat counterclaimed with contract, trade secret, and unfair competition claims (collectively, with Viasat 2 and Viasat 3, the “Viasat Cases”). On December 13, 2018, the Massachusetts court entered an order staying the Massachusetts litigation, which has been extended to June 30, 2022.

- removed (2022-11-22):
[0000858877-22-000009:note_history:39]
While we believe Acacia has strong defenses in each of the Viasat Cases, we are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If Acacia does not prevail, we

- removed (2022-11-22):
[0000858877-22-000009:note_history:40]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager product infringes three U.S. patents. Egenera seeks damages, including enhanced damages for allegations of willful infringement, and an injunction. Two of the asserted patents have been dismissed, leaving Egenera’s infringement claim based on one asserted patent. The court has scheduled a jury trial on the remaining patent to commence on August 2, 2022. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. While we believe that we have strong non-infringement and invalidity arguments, and that Egenera’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation process. If we do not prevail in court, we believe at this time that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.
In addition, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-11-22):
[0000858877-22-000025:note_history:41]
Organization and Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2023 and fiscal 2022 are each 52-week fiscal years. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).
  (was, 2022-05-25, similarity 0.9481):
[0000858877-22-000009:note_history:41]
Organization and Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2022 is a 52-week fiscal year and fiscal 2021 was a 53-week fiscal year. The Consolidated Financial Statements include our accounts and those of our subsidiaries. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

- changed (2022-11-22):
[0000858877-22-000025:note_history:42]
We have prepared the accompanying financial data as of October 29, 2022 and for the first quarter of fiscal 2023 and 2022, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 30, 2022 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 30, 2022.
  (was, 2022-05-25, similarity 0.9779):
[0000858877-22-000009:note_history:42]
We have prepared the accompanying financial data as of April 30, 2022 and for the third quarter and first nine months of fiscal 2022 and 2021, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 31, 2021 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021.

- added (2022-11-22):
[0000858877-22-000025:note_history:43]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of October 29, 2022, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2023 and 2022, as applicable, have been made. The results of operations for the first quarter of fiscal 2023 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- added (2022-11-22):
[0000858877-22-000025:note_history:44]
Our consolidated financial statements include our accounts and investments consolidated under the variable interest and voting models. The noncontrolling interests attributed to these investments are not presented as a separate component in the equity section of the Consolidated Balance Sheets as these amounts are not material for any of the fiscal periods presented. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

- removed (2022-11-22):
[0000858877-22-000009:note_history:45]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic, including the associated impact of supply constraints, on our critical and significant accounting estimates. The actual results that we experience may differ materially from our estimates. As these events continue, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

- removed (2022-11-22):
[0000858877-22-000009:note_history:46]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of April 30, 2022, the results of operations, the statements of comprehensive income and the statements of equity for the third quarter and first nine months of fiscal 2022 and 2021, and the statements of cash flows for the first nine months of fiscal 2022 and 2021, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2022 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2022-11-22):
[0000858877-22-000009:note_history:47]
Our consolidated financial statements include our accounts and entities consolidated under the variable interest and voting models. The noncontrolling interests attributed to these investments, if material, are presented as a separate component from our equity in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-11-22):
[0000858877-22-000025:note_history:48]
Recent Accounting Pronouncements
(a)Recent Accounting Standards or Updates Not Yet Effective
  (was, 2022-05-25, similarity 0.7682):
[0000858877-22-000009:note_history:48]
(b)Recent Accounting Standards or Updates Not Yet Effective

- changed (2022-11-22):
[0000858877-22-000025:note_history:49]
Reference Rate Reform  In March 2020, the FASB issued an accounting standard update and subsequent amendments that provide optional expedients and exceptions to the current guidance on contract modification and hedging relationships to ease the financial reporting burden of the expected market transition from the London InterBank Offered Rate (LIBOR) and other interbank offered rates to alternative reference rates. This accounting standard update was effective upon issuance and may be applied prospectively through December 31, 2022. We do not expect this accounting standard update will have a material impact on our Consolidated Financial Statements.
  (was, 2022-05-25, similarity 0.8906):
[0000858877-22-000009:note_history:49]
Reference Rate Reform  In March 2020, the FASB issued an accounting standard update and subsequent amendments that provide optional expedients and exceptions to the current guidance on contract modification and hedging relationships to ease the financial reporting burden of the expected market transition from the London InterBank Offered Rate (LIBOR) and other 
interbank offered rates to alternative reference rates. This accounting standard update was effective upon issuance and may be applied prospectively through December 31, 2022. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.

- removed (2022-11-22):
[0000858877-22-000009:note_history:50]
Recent Accounting Pronouncements
(a)New Accounting Updates Recently Adopted

- removed (2022-11-22):
[0000858877-22-000009:note_history:51]
Acquired Revenue Contracts with Customers in Business Combination  In October 2021, the Financial Accounting Standards Board (FASB) issued an accounting standard update that requires companies to apply Accounting Standards Codification 606 to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination. We early adopted this accounting standard update beginning in the first quarter of fiscal 2022 and it did not have a material impact on our Consolidated Financial Statements. The ongoing impact of this standard will be fact dependent on the transactions within its scope.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-22):
[0000858877-22-000025:note_history:52]
|  | October 29, 2022 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,249 |  |  | 2.44 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,249 |  |  |  |  | $ | 1,099 |  |  |  |
  (was, 2022-05-25, similarity 0.7632):
[0000858877-22-000009:note_history:52]
|  | April 30, 2022 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,000 |  |  | 2.13 | % |  | $ | 2,508 |  |  | 1.75 | % |

- changed (2022-11-22):
[0000858877-22-000025:note_history:53]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.
  (was, 2022-05-25, similarity 0.8589):
[0000858877-22-000009:note_history:53]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of April 30, 2022 and July 31, 2021.

- changed (2022-11-22):
[0000858877-22-000025:note_history:54]
|  |  |  | October 29, 2022 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | 500 |  |  | 2.68% |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 4.04% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 4.61% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,000 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (73) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (49) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,878 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,249 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 7,629 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,878 |  |  |  |  | $ | 8,915 |  |  |  |
  (was, 2022-05-25, similarity 0.8902):
[0000858877-22-000009:note_history:54]
|  |  |  | April 30, 2022 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.59% |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.35% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.75% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,500 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (76) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (6) |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 9,418 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,000 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,418 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 9,418 |  |  |  |  | $ | 11,526 |  |  |  |

- changed (2022-11-22):
[0000858877-22-000025:note_history:55]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 29, 2022, we were in compliance with all debt covenants.
  (was, 2022-05-25, similarity 0.9863):
[0000858877-22-000009:note_history:55]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 30, 2022, we were in compliance with all debt covenants.

- changed (2022-11-22):
[0000858877-22-000025:note_history:56]
As of October 29, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2022-05-25, similarity 0.9627):
[0000858877-22-000009:note_history:56]
As of April 30, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2022-11-22):
[0000858877-22-000025:note_history:57]
| Fiscal Year | Amount |
| 2023 (remaining nine months) | $ | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 9,000 |  |
  (was, 2022-05-25, similarity 0.9772):
[0000858877-22-000009:note_history:57]
| Fiscal Year | Amount |
| 2022 (remaining three months) | $ | 500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 9,500 |  |

- changed (2022-11-22):
[0000858877-22-000025:note_history:58]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of October 29, 2022, we were in compliance
  (was, 2022-05-25, similarity 0.6779):
[0000858877-22-000009:note_history:58]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of April 30, 2022, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.

- added (2022-11-22):
[0000858877-22-000025:note_history:59]
with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2022-11-22):
[0000858877-22-000025:note_history:60]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 29, 2022 and July 30, 2022 (in millions):

- added (2022-11-22):
[0000858877-22-000025:note_history:61]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 29, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 530 |  |  | $ | (12) |  |  | $ | 944 |  |  | $ | (58) |  |  | $ | 1,474 |  |  | $ | (70) |  |
| U.S. government agency securities | 101 |  |  | (2) |  |  | 64 |  |  | (4) |  |  | 165 |  |  | (6) |  |
| Non-U.S. government and agency securities | 257 |  |  | (1) |  |  | — |  |  | — |  |  | 257 |  |  | (1) |  |
| Corporate debt securities | 5,065 |  |  | (252) |  |  | 2,090 |  |  | (206) |  |  | 7,155 |  |  | (458) |  |
| U.S. agency mortgage-backed securities | 651 |  |  | (76) |  |  | 1,136 |  |  | (197) |  |  | 1,787 |  |  | (273) |  |
| Commercial paper | 45 |  |  | — |  |  | — |  |  | — |  |  | 45 |  |  | — |  |
| Total | $ | 6,649 |  |  | $ | (343) |  |  | $ | 4,234 |  |  | $ | (465) |  |  | $ | 10,883 |  |  | $ | (808) |  |

- added (2022-11-22):
[0000858877-22-000025:note_history:62]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 30, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,110 |  |  | $ | (44) |  |  | $ | 120 |  |  | $ | (5) |  |  | $ | 1,230 |  |  | $ | (49) |  |
| U.S. government agency securities | 114 |  |  | (2) |  |  | 24 |  |  | (2) |  |  | 138 |  |  | (4) |  |
| Non-U.S. government and agency securities | 264 |  |  | — |  |  | — |  |  | — |  |  | 264 |  |  | — |  |
| Corporate debt securities | 6,920 |  |  | (240) |  |  | 422 |  |  | (37) |  |  | 7,342 |  |  | (277) |  |
| U.S. agency mortgage-backed securities | 1,305 |  |  | (96) |  |  | 615 |  |  | (62) |  |  | 1,920 |  |  | (158) |  |
| Total | $ | 9,713 |  |  | $ | (382) |  |  | $ | 1,181 |  |  | $ | (106) |  |  | $ | 10,894 |  |  | $ | (488) |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-11-22):
[0000858877-22-000025:note_history:63]
| October 29, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,545 |  |  | $ | — |  |  | $ | (70) |  |  | $ | 1,475 |  |
| U.S. government agency securities | 171 |  |  | — |  |  | (6) |  |  | 165 |  |
| Non-U.S. government and agency securities | 275 |  |  | — |  |  | (1) |  |  | 274 |  |
| Corporate debt securities | 7,808 |  |  | — |  |  | (492) |  |  | 7,316 |  |
| U.S. agency mortgage-backed securities | 2,071 |  |  | — |  |  | (273) |  |  | 1,798 |  |
| Commercial paper | 798 |  |  | — |  |  | — |  |  | 798 |  |
| Certificates of deposit | 421 |  |  | — |  |  | — |  |  | 421 |  |
| Total | $ | 13,089 |  |  | $ | — |  |  | $ | (842) |  |  | $ | 12,247 |  |

- changed (2022-11-22):
[0000858877-22-000025:note_history:64]
| July 30, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,287 |  |  | $ | — |  |  | $ | (49) |  |  | $ | 1,238 |  |
| U.S. government agency securities | 142 |  |  | — |  |  | (4) |  |  | 138 |  |
| Non-U.S. government and agency securities | 272 |  |  | — |  |  | — |  |  | 272 |  |
| Corporate debt securities | 8,127 |  |  | 2 |  |  | (311) |  |  | 7,818 |  |
| U.S. agency mortgage-backed securities | 2,134 |  |  | — |  |  | (158) |  |  | 1,976 |  |
| Commercial paper | 255 |  |  | — |  |  | — |  |  | 255 |  |
| Certificates of deposit | 250 |  |  | — |  |  | — |  |  | 250 |  |
| Total | $ | 12,467 |  |  | $ | 2 |  |  | $ | (522) |  |  | $ | 11,947 |  |
  (was, 2022-05-25, similarity 0.9945):
[0000858877-22-000009:note_history:64]
| April 30, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,346 |  |  | $ | — |  |  | $ | (46) |  |  | $ | 1,300 |  |
| U.S. government agency securities | 150 |  |  | — |  |  | (4) |  |  | 146 |  |
| Non-U.S. government and agency securities | 171 |  |  | — |  |  | — |  |  | 171 |  |
| Corporate debt securities | 8,770 |  |  | 5 |  |  | (296) |  |  | 8,479 |  |
| U.S. agency mortgage-backed securities | 2,234 |  |  | — |  |  | (176) |  |  | 2,058 |  |
| Commercial paper | 548 |  |  | — |  |  | — |  |  | 548 |  |
| Certificates of deposit | 212 |  |  | — |  |  | — |  |  | 212 |  |
| Total | $ | 13,431 |  |  | $ | 5 |  |  | $ | (522) |  |  | $ | 12,914 |  |

- added (2022-11-22):
[0000858877-22-000025:note_history:65]
Net unsettled investment purchases were $42 million and net unsettled investment sales were $70 million as of October 29, 2022 and July 30, 2022, respectively, and were included in other current assets and other current liabilities.

- added (2022-11-22):
[0000858877-22-000025:note_history:66]
|  | Three Months Ended |
|  | October 29, 2022 |  | October 30, 2021 |
| Gross realized gains | $ | — |  |  | $ | 6 |  |
| Gross realized losses | (6) |  |  | — |  |
| Total | $ | (6) |  |  | $ | 6 |  |

- changed (2022-11-22):
[0000858877-22-000025:note_history:67]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 29, 2022 and July 30, 2022 (in millions):
  (was, 2022-05-25, similarity 0.9716):
[0000858877-22-000009:note_history:67]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 30, 2022 and July 31, 2021 (in millions):

- changed (2022-11-22):
[0000858877-22-000025:note_history:68]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 29, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 530 |  |  | $ | (12) |  |  | $ | 944 |  |  | $ | (58) |  |  | $ | 1,474 |  |  | $ | (70) |  |
| U.S. government agency securities | 101 |  |  | (2) |  |  | 64 |  |  | (4) |  |  | 165 |  |  | (6) |  |
| Non-U.S. government and agency securities | 257 |  |  | (1) |  |  | — |  |  | — |  |  | 257 |  |  | (1) |  |
| Corporate debt securities | 5,065 |  |  | (252) |  |  | 2,090 |  |  | (206) |  |  | 7,155 |  |  | (458) |  |
| U.S. agency mortgage-backed securities | 651 |  |  | (76) |  |  | 1,136 |  |  | (197) |  |  | 1,787 |  |  | (273) |  |
| Commercial paper | 45 |  |  | — |  |  | — |  |  | — |  |  | 45 |  |  | — |  |
| Total | $ | 6,649 |  |  | $ | (343) |  |  | $ | 4,234 |  |  | $ | (465) |  |  | $ | 10,883 |  |  | $ | (808) |  |
  (was, 2022-05-25, similarity 0.8269):
[0000858877-22-000009:note_history:68]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 30, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,185 |  |  | $ | (43) |  |  | $ | 96 |  |  | $ | (3) |  |  | $ | 1,281 |  |  | $ | (46) |  |
| U.S. government agency securities | 121 |  |  | (2) |  |  | 24 |  |  | (2) |  |  | 145 |  |  | (4) |  |
| Non-U.S. government and agency securities | 171 |  |  | — |  |  | — |  |  | — |  |  | 171 |  |  | — |  |
| Corporate debt securities | 6,185 |  |  | (225) |  |  | 367 |  |  | (35) |  |  | 6,552 |  |  | (260) |  |
| U.S. agency mortgage-backed securities | 1,505 |  |  | (118) |  |  | 547 |  |  | (58) |  |  | 2,052 |  |  | (176) |  |
| Total | $ | 9,167 |  |  | $ | (388) |  |  | $ | 1,034 |  |  | $ | (98) |  |  | $ | 10,201 |  |  | $ | (486) |  |

- added (2022-11-22):
[0000858877-22-000025:note_history:69]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 30, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,110 |  |  | $ | (44) |  |  | $ | 120 |  |  | $ | (5) |  |  | $ | 1,230 |  |  | $ | (49) |  |
| U.S. government agency securities | 114 |  |  | (2) |  |  | 24 |  |  | (2) |  |  | 138 |  |  | (4) |  |
| Non-U.S. government and agency securities | 264 |  |  | — |  |  | — |  |  | — |  |  | 264 |  |  | — |  |
| Corporate debt securities | 6,920 |  |  | (240) |  |  | 422 |  |  | (37) |  |  | 7,342 |  |  | (277) |  |
| U.S. agency mortgage-backed securities | 1,305 |  |  | (96) |  |  | 615 |  |  | (62) |  |  | 1,920 |  |  | (158) |  |
| Total | $ | 9,713 |  |  | $ | (382) |  |  | $ | 1,181 |  |  | $ | (106) |  |  | $ | 10,894 |  |  | $ | (488) |  |

- changed (2022-11-22):
[0000858877-22-000025:note_history:70]
The following table summarizes the maturities of our available-for-sale debt investments as of October 29, 2022 (in millions):
  (was, 2022-05-25, similarity 0.9583):
[0000858877-22-000009:note_history:70]
The following table summarizes the maturities of our available-for-sale debt investments as of April 30, 2022 (in millions):

- added (2022-11-22):
[0000858877-22-000025:note_history:71]
We held marketable equity securities of $245 million and $241 million as of October 29, 2022 and July 30, 2022, respectively. We recognized a net unrealized loss of $20 million and a net unrealized gain of $5 million during the first quarter of fiscal 2023 and 2022, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $12 million and a net gain of $2 million for the first quarter of fiscal 2023 and 2022, respectively. We held equity interests in certain private equity funds of $1.0 billion and $1.1 billion as of October 29, 2022 and July 30, 2022, respectively, which are accounted for under the NAV practical expedient.

- changed (2022-11-22):
[0000858877-22-000025:note_history:72]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 29, 2022, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2022-05-25, similarity 0.6175):
[0000858877-22-000009:note_history:72]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest

- changed (2022-11-22):
[0000858877-22-000025:note_history:73]
The carrying value of our investments in privately held companies was $1.8 billion and $1.9 billion as of October 29, 2022 and July 30, 2022, respectively. Of the total carrying value of our investments in privately held companies as of October 29, 2022, $1.1 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of October 29, 2022, we have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.
  (was, 2022-05-25, similarity 0.9752):
[0000858877-22-000009:note_history:73]
The carrying value of our investments in privately held companies was $1.9 billion and $1.5 billion as of April 30, 2022 and July 31, 2021, respectively. Of the total carrying value of our investments in privately held companies as of April 30, 2022, $1.2 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of April 30, 2022, we have total funding commitments of $0.4 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.

- removed (2022-11-22):
[0000858877-22-000009:note_history:74]
| July 31, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,773 |  |  | $ | 21 |  |  | $ | — |  |  | $ | 1,794 |  |
| U.S. government agency securities | 152 |  |  | — |  |  | — |  |  | 152 |  |
| Non-U.S. government and agency securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Corporate debt securities | 8,727 |  |  | 213 |  |  | (30) |  |  | 8,910 |  |
| U.S. agency mortgage-backed securities | 2,838 |  |  | 34 |  |  | (10) |  |  | 2,862 |  |
| Commercial paper | 1,190 |  |  | — |  |  | — |  |  | 1,190 |  |
| Certificates of deposit | 295 |  |  | — |  |  | — |  |  | 295 |  |
| Total | $ | 14,978 |  |  | $ | 268 |  |  | $ | (40) |  |  | $ | 15,206 |  |

- removed (2022-11-22):
[0000858877-22-000009:note_history:75]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2022 |  | May 1, 2021 |  | April 30, 2022 |  | May 1, 2021 |
| Gross realized gains | $ | 8 |  |  | $ | 24 |  |  | $ | 27 |  |  | $ | 48 |  |
| Gross realized losses | (6) |  |  | (2) |  |  | (9) |  |  | (2) |  |
| Total | $ | 2 |  |  | $ | 22 |  |  | $ | 18 |  |  | $ | 46 |  |

- removed (2022-11-22):
[0000858877-22-000009:note_history:76]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 31, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 468 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 468 |  |  | $ | — |  |
| U.S. government agency securities | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |
| Corporate debt securities | 1,086 |  |  | (5) |  |  | 6 |  |  | — |  |  | 1,092 |  |  | (5) |  |
| U.S. agency mortgage-backed securities | 1,293 |  |  | (10) |  |  | 13 |  |  | — |  |  | 1,306 |  |  | (10) |  |
| Commercial paper | 37 |  |  | — |  |  | — |  |  | — |  |  | 37 |  |  | — |  |
| Total | $ | 2,910 |  |  | $ | (15) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 2,929 |  |  | $ | (15) |  |

- removed (2022-11-22):
[0000858877-22-000009:note_history:77]
We held marketable equity securities of $242 million and $137 million as of April 30, 2022 and July 31, 2021, respectively. We recognized a net unrealized loss of $19 million and $32 million during the third quarter and first nine months of fiscal 2022, respectively, and net unrealized gains of $3 million for each of the third quarter and first nine months of fiscal 2021, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $11 million and $28 million for the third quarter and first nine months of fiscal 2022, respectively. These adjustments were a net loss of $3 million and a net gain of $1 million for the corresponding periods of fiscal 2021, respectively. We held equity interests in certain private equity funds of $1.2 billion and $0.9 billion as of April 30, 2022 and July 31, 2021, respectively, which are accounted for under the NAV practical expedient.

- removed (2022-11-22):
[0000858877-22-000009:note_history:78]
entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 30, 2022, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-22):
[0000858877-22-000025:note_history:79]
|  |  |  | October 29, 2022 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | 500 |  |  | 2.68% |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 4.04% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 4.61% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,000 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (73) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (49) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,878 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,249 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 7,629 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,878 |  |  |  |  | $ | 8,915 |  |  |  |
  (was, 2022-05-25, similarity 0.8902):
[0000858877-22-000009:note_history:79]
|  |  |  | April 30, 2022 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.59% |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.35% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.75% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,500 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (76) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (6) |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 9,418 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,000 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,418 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 9,418 |  |  |  |  | $ | 11,526 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-22):
[0000858877-22-000025:note_history:80]
As of October 29, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2022-05-25, similarity 0.9627):
[0000858877-22-000009:note_history:80]
As of April 30, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2022-11-22):
[0000858877-22-000025:note_history:81]
| Fiscal Year | Amount |
| 2023 (remaining nine months) | $ | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 9,000 |  |
  (was, 2022-05-25, similarity 0.9772):
[0000858877-22-000009:note_history:81]
| Fiscal Year | Amount |
| 2022 (remaining three months) | $ | 500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 9,500 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-22):
[0000858877-22-000025:note_history:82]
|  | October 29, 2022 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,249 |  |  | 2.44 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,249 |  |  |  |  | $ | 1,099 |  |  |  |
  (was, 2022-05-25, similarity 0.7632):
[0000858877-22-000009:note_history:82]
|  | April 30, 2022 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,000 |  |  | 2.13 | % |  | $ | 2,508 |  |  | 1.75 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-22):
[0000858877-22-000025:note_history:83]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |
| Product revenue: |  |  |  |
| Secure, Agile Networks | $ | 6,684 |  |  | $ | 5,968 |  |
| Internet for the Future | 1,310 |  |  | 1,373 |  |
| Collaboration | 1,086 |  |  | 1,109 |  |
| End-to-End Security | 971 |  |  | 895 |  |
| Optimized Application Experiences | 193 |  |  | 181 |  |
| Other Products | 2 |  |  | 3 |  |
| Total Product | 10,245 |  |  | 9,529 |  |
| Services | 3,387 |  |  | 3,371 |  |
| Total | $ | 13,632 |  |  | $ | 12,900 |  |
  (was, 2022-05-25, similarity 0.6383):
[0000858877-22-000009:note_history:83]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,869 |  |  | $ | 5,620 |  |  | $ | 17,735 |  |  | $ | 16,543 |  |
| Internet for the Future | 1,324 |  |  | 1,249 |  |  | 4,021 |  |  | 3,121 |  |
| Collaboration | 1,132 |  |  | 1,220 |  |  | 3,308 |  |  | 3,580 |  |
| End-to-End Security | 938 |  |  | 876 |  |  | 2,716 |  |  | 2,559 |  |
| Optimized Application Experiences | 183 |  |  | 170 |  |  | 544 |  |  | 483 |  |
| Other Products | 2 |  |  | 5 |  |  | 7 |  |  | 11 |  |
| Total Product | 9,448 |  |  | 9,139 |  |  | 28,330 |  |  | 26,298 |  |
| Services | 3,387 |  |  | 3,664 |  |  | 10,125 |  |  | 10,394 |  |
| Total | $ | 12,835 |  |  | $ | 12,803 |  |  | $ | 38,455 |  |  | $ | 36,692 |  |

- added (2022-11-22):
[0000858877-22-000025:note_history:84]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |
| Revenue: |  |  |  |
| Secure, Agile Networks | $ | 6,684 |  |  | $ | 5,968 |  |
| Internet for the Future | 1,310 |  |  | 1,373 |  |
| Collaboration | 1,086 |  |  | 1,109 |  |
| End-to-End Security | 971 |  |  | 895 |  |
| Optimized Application Experiences | 193 |  |  | 181 |  |
| Other Products | 2 |  |  | 3 |  |
| Total Product | 10,245 |  |  | 9,529 |  |
| Services | 3,387 |  |  | 3,371 |  |
| Total | $ | 13,632 |  |  | $ | 12,900 |  |

- removed (2022-11-22):
[0000858877-22-000009:note_history:85]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,869 |  |  | $ | 5,620 |  |  | $ | 17,735 |  |  | $ | 16,543 |  |
| Internet for the Future | 1,324 |  |  | 1,249 |  |  | 4,021 |  |  | 3,121 |  |
| Collaboration | 1,132 |  |  | 1,220 |  |  | 3,308 |  |  | 3,580 |  |
| End-to-End Security | 938 |  |  | 876 |  |  | 2,716 |  |  | 2,559 |  |
| Optimized Application Experiences | 183 |  |  | 170 |  |  | 544 |  |  | 483 |  |
| Other Products | 2 |  |  | 5 |  |  | 7 |  |  | 11 |  |
| Total Product | 9,448 |  |  | 9,139 |  |  | 28,330 |  |  | 26,298 |  |
| Services | 3,387 |  |  | 3,664 |  |  | 10,125 |  |  | 10,394 |  |
| Total | $ | 12,835 |  |  | $ | 12,803 |  |  | $ | 38,455 |  |  | $ | 36,692 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-22):
[0000858877-22-000025:note_history:86]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.
  (was, 2022-05-25, similarity 0.7301):
[0000858877-22-000009:note_history:86]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

- changed (2022-11-22):
[0000858877-22-000025:note_history:87]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 29, 2022 and July 30, 2022 was $47 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2022-05-25, similarity 0.9793):
[0000858877-22-000009:note_history:87]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 30, 2022 and July 31, 2021 was $42 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- removed (2022-11-22):
[0000858877-22-000009:note_history:88]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-22):
[0000858877-22-000025:note_history:89]
Revenue We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.
  (was, 2022-05-25, similarity 0.7287):
[0000858877-22-000009:note_history:89]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

- changed (2022-11-22):
[0000858877-22-000025:note_history:90]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 29, 2022 and July 30, 2022 was $47 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2022-05-25, similarity 0.9793):
[0000858877-22-000009:note_history:90]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 30, 2022 and July 31, 2021 was $42 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- changed (2022-11-22):
[0000858877-22-000025:note_history:91]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. The following table presents this disaggregation of revenue (in millions):
  (was, 2022-05-25, similarity 0.7273):
[0000858877-22-000009:note_history:91]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. Effective fiscal 2022, we began reporting our product and service revenue in the following categories: Secure, Agile Networks; Internet for the Future; Collaboration; End-to-End Security; Optimized Application Experiences; Other Products; and Services. This change will better align our product categories with our strategic priorities. The following table presents this disaggregation of revenue (in millions):

- added (2022-11-22):
[0000858877-22-000025:note_history:92]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |
| Product revenue: |  |  |  |
| Secure, Agile Networks | $ | 6,684 |  |  | $ | 5,968 |  |
| Internet for the Future | 1,310 |  |  | 1,373 |  |
| Collaboration | 1,086 |  |  | 1,109 |  |
| End-to-End Security | 971 |  |  | 895 |  |
| Optimized Application Experiences | 193 |  |  | 181 |  |
| Other Products | 2 |  |  | 3 |  |
| Total Product | 10,245 |  |  | 9,529 |  |
| Services | 3,387 |  |  | 3,371 |  |
| Total | $ | 13,632 |  |  | $ | 12,900 |  |

- added (2022-11-22):
[0000858877-22-000025:note_history:93]
Amounts may not sum due to rounding. We have made certain reclassifications to the product revenue amounts for prior period to conform to the current year presentation.

- changed (2022-11-22):
[0000858877-22-000025:note_history:94]
Internet for the Future consists of our routed optical networking, 5G, silicon, and optics solutions. These products consist primarily of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.
  (was, 2022-05-25, similarity 0.9847):
[0000858877-22-000009:note_history:94]
Internet for the Future consists of our routed optical networking, public 5G, silicon, and optics offerings. These products consist primarily of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- added (2022-11-22):
[0000858877-22-000025:note_history:95]
Collaboration consists of our Meetings, Collaboration Devices, Calling, Contact Center and Communication Platform as a Service (CPaaS) offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- changed (2022-11-22):
[0000858877-22-000025:note_history:96]
End-to-End Security consists of our Network Security, Cloud Security, Security Endpoints, Unified Threat Management and Zero Trust offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.
  (was, 2022-05-25, similarity 0.8625):
[0000858877-22-000009:note_history:96]
End-to-End Security consists of our overall security offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements

- changed (2022-11-22):
[0000858877-22-000025:note_history:97]
Accounts receivable, net was $5.4 billion as of October 29, 2022 compared to $6.6 billion as of July 30, 2022, as reported on the Consolidated Balance Sheets.
  (was, 2022-05-25, similarity 0.839):
[0000858877-22-000009:note_history:97]
Accounts receivable, net was $5.8 billion as of each of April 30, 2022 and July 31, 2021, as reported on the Consolidated Balance Sheets.

- added (2022-11-22):
[0000858877-22-000025:note_history:98]
|  | Three Months Ended |
|  | October 29, 2022 |  | October 30, 2021 |
| Allowance for credit loss at beginning of period | $ | 83 |  |  | $ | 109 |  |
| Provisions (benefits) | 11 |  |  | 19 |  |
| Recoveries (write-offs), net | (6) |  |  | (14) |  |
| Allowance for credit loss at end of period | $ | 88 |  |  | $ | 114 |  |

- changed (2022-11-22):
[0000858877-22-000025:note_history:99]
|  | October 29,2022 |  | July 30,2022 |
| 1 to 4 | $ | 356 |  |  | $ | 414 |  |
| 5 to 6 | 898 |  |  | 814 |  |
| 7 and Higher | 87 |  |  | 158 |  |
| Total | $ | 1,341 |  |  | $ | 1,386 |  |
  (was, 2022-05-25, similarity 0.9658):
[0000858877-22-000009:note_history:99]
|  | April 30,2022 |  | July 31,2021 |
| 1 to 4 | $ | 422 |  |  | $ | 521 |  |
| 5 to 6 | 807 |  |  | 770 |  |
| 7 and Higher | 169 |  |  | 166 |  |
| Total | $ | 1,398 |  |  | $ | 1,457 |  |

- changed (2022-11-22):
[0000858877-22-000025:note_history:100]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, was $1.3 billion as of each of October 29, 2022 and July 30, 2022, and were included in other current assets and other assets.
  (was, 2022-05-25, similarity 0.9383):
[0000858877-22-000009:note_history:100]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, was $1.3 billion and $1.4 billion as of April 30, 2022 and July 31, 2021, respectively, and were included in other current assets and other assets.

- added (2022-11-22):
[0000858877-22-000025:note_history:101]
Contract liabilities consist of deferred revenue. Deferred revenue was $23.0 billion as of October 29, 2022 compared to $23.3 billion as of July 30, 2022. We recognized approximately $4.4 billion of revenue during the first quarter of fiscal 2023 that was included in the deferred revenue balance at July 30, 2022. 
(c)Capitalized Contract Acquisition CostsWe capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $1.1 billion and $1.0 billion as of October 29, 2022 and July 30, 2022, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $176 million and $170 million for the first quarter of fiscal 2023 and 2022, respectively, and was included in sales and marketing expenses.

- removed (2022-11-22):
[0000858877-22-000009:note_history:102]
Revenue 
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations. As a result, our contracts may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and software-as-a-service (SaaS) as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers.

- removed (2022-11-22):
[0000858877-22-000009:note_history:103]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,869 |  |  | $ | 5,620 |  |  | $ | 17,735 |  |  | $ | 16,543 |  |
| Internet for the Future | 1,324 |  |  | 1,249 |  |  | 4,021 |  |  | 3,121 |  |
| Collaboration | 1,132 |  |  | 1,220 |  |  | 3,308 |  |  | 3,580 |  |
| End-to-End Security | 938 |  |  | 876 |  |  | 2,716 |  |  | 2,559 |  |
| Optimized Application Experiences | 183 |  |  | 170 |  |  | 544 |  |  | 483 |  |
| Other Products | 2 |  |  | 5 |  |  | 7 |  |  | 11 |  |
| Total Product | 9,448 |  |  | 9,139 |  |  | 28,330 |  |  | 26,298 |  |
| Services | 3,387 |  |  | 3,664 |  |  | 10,125 |  |  | 10,394 |  |
| Total | $ | 12,835 |  |  | $ | 12,803 |  |  | $ | 38,455 |  |  | $ | 36,692 |  |

- removed (2022-11-22):
[0000858877-22-000009:note_history:104]
Amounts may not sum due to rounding.

- removed (2022-11-22):
[0000858877-22-000009:note_history:105]
Collaboration consists of our Collaboration Devices, Meetings, Calling and contact center offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2022-11-22):
[0000858877-22-000009:note_history:106]
in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

- removed (2022-11-22):
[0000858877-22-000009:note_history:107]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2022 |  | May 1, 2021 |  | April 30, 2022 |  | May 1, 2021 |
| Allowance for credit loss at beginning of period | $ | 70 |  |  | $ | 102 |  |  | $ | 109 |  |  | $ | 143 |  |
| Provisions (benefits) | 17 |  |  | 16 |  |  | 53 |  |  | 15 |  |
| Recoveries (write-offs), net | (9) |  |  | (8) |  |  | (75) |  |  | (22) |  |
| Foreign exchange and other | — |  |  | — |  |  | (9) |  |  | (26) |  |
| Allowance for credit loss at end of period | $ | 78 |  |  | $ | 110 |  |  | $ | 78 |  |  | $ | 110 |  |

- removed (2022-11-22):
[0000858877-22-000009:note_history:108]
Contract liabilities consist of deferred revenue. Deferred revenue was $22.3 billion as of April 30, 2022 compared to $22.2 billion as of July 31, 2021. We recognized approximately $2.5 billion and $9.9 billion of revenue during the third quarter and first nine months of fiscal 2022, respectively, that was included in the deferred revenue balance at July 31, 2021. 
(c)Capitalized Contract Acquisition CostsWe capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $1.0 billion and $967 million as of April 30, 2022 and July 31, 2021, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $175 million and $492 million for the third quarter and first nine months of fiscal 2022, respectively, and $134 million and $386 million for the corresponding periods of fiscal 2021, respectively, and was included in sales and marketing expenses.
