# CSCO MD&A — 0000858877-20-000006


## mdna

[0000858877-20-000006:mdna:1]
[same as prior period, unchanged from 0000858877-20-000004:mdna:1]

[0000858877-20-000006:mdna:2]
[same as prior period, unchanged from 0000858877-20-000004:mdna:2]

[0000858877-20-000006:mdna:3]
[same as prior period, unchanged from 0000858877-20-000004:mdna:3]

[0000858877-20-000006:mdna:4]
[same as prior period, unchanged from 0000858877-20-000004:mdna:4]

[0000858877-20-000006:mdna:5]
[same as prior period, unchanged from 0000858877-20-000004:mdna:5]

[0000858877-20-000006:mdna:6]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | April 25, 2020 |  | April 27, 2019 |  | % Variance |  | April 25, 2020 |  | April 27, 2019 |  | % Variance |  |
| Revenue (1) | $ | 11,983 |  |  | $ | 12,958 |  |  | (8 | )% |  | $ | 37,147 |  |  | $ | 38,476 |  |  | (3 | )% |  |
| Gross margin percentage | 64.9 | % |  | 63.1 | % |  | 1.8 |  | pts | 64.6 | % |  | 62.6 | % |  | 2.0 |  | pts |
| Research and development | $ | 1,546 |  |  | $ | 1,659 |  |  | (7 | )% |  | $ | 4,782 |  |  | $ | 4,824 |  |  | (1 | )% |  |
| Sales and marketing | $ | 2,192 |  |  | $ | 2,403 |  |  | (9 | )% |  | $ | 6,951 |  |  | $ | 7,084 |  |  | (2 | )% |  |
| General and administrative | $ | 457 |  |  | $ | 541 |  |  | (16 | )% |  | $ | 1,431 |  |  | $ | 1,261 |  |  | 13 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,195 |  |  | $ | 4,603 |  |  | (9 | )% |  | $ | 13,164 |  |  | $ | 13,169 |  |  | — | % |  |
| Total as a percentage of revenue | 35.0 | % |  | 35.5 | % |  | (0.5 | ) | pts | 35.4 | % |  | 34.2 | % |  | 1.2 |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 34 |  |  | $ | 39 |  |  | (13 | )% |  | $ | 108 |  |  | $ | 112 |  |  | (4 | )% |  |
| Restructuring and other charges included in operating expenses | $ | 128 |  |  | $ | 18 |  |  | 611 | % |  | $ | 354 |  |  | $ | 282 |  |  | 26 | % |  |
| Operating income as a percentage of revenue | 28.5 | % |  | 27.1 | % |  | 1.4 |  | pts | 27.9 | % |  | 27.4 | % |  | 0.5 |  | pts |
| Interest and other income (loss), net | $ | 30 |  |  | $ | 102 |  |  | (71 | )% |  | $ | 291 |  |  | $ | 338 |  |  | (14 | )% |  |
| Income tax percentage | 19.4 | % |  | 15.8 | % |  | 3.6 |  | pts | 19.6 | % |  | 13.4 | % |  | 6.2 |  | pts |
| Net income | $ | 2,774 |  |  | $ | 3,044 |  |  | (9 | )% |  | $ | 8,578 |  |  | $ | 9,415 |  |  | (9 | )% |  |
| Net income as a percentage of revenue | 23.1 | % |  | 23.5 | % |  | (0.4 | ) | pts | 23.1 | % |  | 24.5 | % |  | (1.4 | ) | pts |
| Earnings per share—diluted | $ | 0.65 |  |  | $ | 0.69 |  |  | (6 | )% |  | $ | 2.01 |  |  | $ | 2.09 |  |  | (4 | )% |  |

[0000858877-20-000006:mdna:7]
(1) During the second quarter of fiscal 2019, we completed the sale of our Service Provider Video Software Solutions (“SPVSS”) business. As a result, revenue from this business will not recur in future periods. Includes SPVSS business revenue of $168 million for the first nine months of fiscal 2019.

[0000858877-20-000006:mdna:8]
[same as prior period, unchanged from 0000858877-20-000004:mdna:9]

[0000858877-20-000006:mdna:9]
[same as prior period, unchanged from 0000858877-20-000004:mdna:10]

[0000858877-20-000006:mdna:10]
COVID-19 Pandemic Response Summary

[0000858877-20-000006:mdna:11]
During this extraordinary time, our priority has been supporting our employees, customers, partners and communities, while positioning Cisco for the future. The pandemic has driven organizations across the globe to digitize their operations and support remote workforces at a faster speed and greater scale than ever before. We remain focused on providing the technology and solutions our customers need to accelerate their digital organizations. The actions we are taking include:

[0000858877-20-000006:mdna:12]
Employees

[0000858877-20-000006:mdna:13]
| • | 95% of our global workforce working from home. |

[0000858877-20-000006:mdna:14]
| • | Seamless transition to work from home with a long-standing flexible work policy, and we build the technologies that allow organizations to stay connected, secure and productive. |

[0000858877-20-000006:mdna:15]
| • | For the 5% who must be in the office to perform their roles, we are focused on their health and safety, and are taking all of the necessary precautions. |

[0000858877-20-000006:mdna:16]
Customer and Partners

[0000858877-20-000006:mdna:17]
| • | Introduced a variety of free offers and trials for our Webex and security technologies as they dramatically shifted entire workforces to be remote. |

[0000858877-20-000006:mdna:18]
| • | Announced a new Cisco Capital $2.5 billion Business Resiliency Program leveraging currently available funds to provide organizations with access to financing solutions to offer financial flexibility and support business continuity. This will help customers and partners access the technology they need now, invest for recovery, and defer most of the payments until early 2021. |

[0000858877-20-000006:mdna:19]
Communities

[0000858877-20-000006:mdna:20]
| • | Committed nearly $300 million to date to support both global and local pandemic response efforts. |

[0000858877-20-000006:mdna:21]
| • | Providing technology and financial support for non-profits, first responders, and governments. |

[0000858877-20-000006:mdna:22]
| • | Donating personal protective equipment to hospital workers including N95 masks and face shields 3D-printed by Cisco volunteers around the world. |

[0000858877-20-000006:mdna:23]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:24]
In the third quarter of fiscal 2020, in a very challenging environment with the COVID-19 pandemic, we delivered strong profitability. In the third quarter of fiscal 2020, COVID-19 had an impact on our financial results and business operations, with a significant impact in our supply chain where we saw manufacturing challenges and component constraints. Total revenue decreased by 8% compared with the third quarter of fiscal 2019. Our product revenue declined in Infrastructure Platforms and Applications, partially offset by growth in Security, and we continued to make progress in the transition of our business model to increased software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities.  We continue to operate in a challenging macroeconomic and highly competitive environment. We experienced continuing weakness in the service provider market and emerging countries, and we expect ongoing uncertainty in these markets. We also continued to see a more broad-based weakening in the global macroeconomic environment during the quarter which impacted our enterprise and commercial markets. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-20-000006:mdna:25]
Within total revenue, product revenue decreased by 12% and service revenue increased by 5%. Total gross margin increased by 1.8 percentage points, driven by productivity improvements and product mix, partially offset by unfavorable impacts from pricing. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 0.5 percentage points. Operating income as a percentage of revenue increased by 1.4 percentage points. Diluted earnings per share decreased by 6%, driven by a 9% decrease in net income and a decrease in diluted share count of 172 million shares.

[0000858877-20-000006:mdna:26]
In terms of our geographic segments, revenue from the Americas decreased $579 million, EMEA revenue decreased by $220 million and APJC revenue decreased by $177 million. The “BRICM” countries experienced a product revenue decline of 25% in the aggregate, driven by decreased product revenue in the emerging countries of China, India, Mexico and Brazil.

[0000858877-20-000006:mdna:27]
From a customer market standpoint, we experienced product revenue declines across all customer segments. During the third quarter of fiscal 2020, we saw a decline in business momentum in the enterprise and commercial markets, which we believe was significantly related to weakness in the global macroeconomic environment.

[0000858877-20-000006:mdna:28]
From a product category perspective, the product revenue decrease of 12% was driven by declines in revenue in Infrastructure Platforms of 15% and Applications of 5%. These declines were partially offset by a product revenue increase in Security of 6%.

[0000858877-20-000006:mdna:29]
[same as prior period, unchanged from 0000858877-20-000004:mdna:17]

[0000858877-20-000006:mdna:30]
[same as prior period, unchanged from 0000858877-20-000004:mdna:18]

[0000858877-20-000006:mdna:31]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:32]
Total revenue decreased 3%, with product revenue decreasing 6% and service revenue increasing 4%. Total gross margin increased by 2.0 percentage points due to productivity benefits and product mix, partially offset by unfavorable impacts from pricing. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively increased by 1.2 percentage points due to higher general and administrative expenses. General and administrative expenses increased due to the impact of the benefit from the $400 million litigation settlement with Arista Networks, Inc. (“Arista”) in the first quarter of fiscal 2019. Operating income as a percentage of revenue increased by 0.5 percentage points.

[0000858877-20-000006:mdna:33]
[same as prior period, unchanged from 0000858877-20-000004:mdna:21]

[0000858877-20-000006:mdna:34]
[same as prior period, unchanged from 0000858877-20-000004:mdna:22]

[0000858877-20-000006:mdna:35]
[same as prior period, unchanged from 0000858877-20-000004:mdna:23]

[0000858877-20-000006:mdna:36]
[same as prior period, unchanged from 0000858877-20-000004:mdna:24]

[0000858877-20-000006:mdna:37]
The following is a summary of our other key financial measures for the third quarter of fiscal 2020 (in millions):

[0000858877-20-000006:mdna:38]
|  |  | April 25, 2020 |  | July 27, 2019 |
| Cash and cash equivalents and investments |  | $ | 28,574 |  |  | $ | 33,413 |  |
| Deferred revenue |  | $ | 18,648 |  |  | $ | 18,467 |  |
| Inventories |  | $ | 1,212 |  |  | $ | 1,383 |  |

[0000858877-20-000006:mdna:39]
|  |  | Nine Months Ended |
|  |  | April 25, 2020 |  | April 27, 2019 |
| Cash provided by operating activities |  | $ | 11,624 |  |  | $ | 11,889 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 2,619 |  |  | $ | 16,062 |  |
| Dividends |  | $ | 4,491 |  |  | $ | 4,489 |  |

[0000858877-20-000006:mdna:40]
[same as prior period, unchanged from 0000858877-20-000004:mdna:28]

[0000858877-20-000006:mdna:41]
[same as prior period, unchanged from 0000858877-20-000004:mdna:29]

[0000858877-20-000006:mdna:42]
[same as prior period, unchanged from 0000858877-20-000004:mdna:30]

[0000858877-20-000006:mdna:43]
[same as prior period, unchanged from 0000858877-20-000004:mdna:31]

[0000858877-20-000006:mdna:44]
The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The COVID-19 pandemic did not have a material impact on our significant judgments, assumptions and estimates that are reflected in our results for the third quarter and first nine months of fiscal 2020. These estimates are listed in our Annual Report on Form 10-K for the year ending July 27, 2019, and include: allowance for accounts receivable, allowances for credit losses on financing receivables, inventory valuation and liability for purchase commitments with contract manufacturers and suppliers, impairments on our publicly traded and privately held investments, goodwill and identified purchased intangible assets, and income taxes, among other items. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues to develop, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-20-000006:mdna:45]
[same as prior period, unchanged from 0000858877-20-000004:mdna:32]

[0000858877-20-000006:mdna:46]
[same as prior period, unchanged from 0000858877-20-000004:mdna:33]

[0000858877-20-000006:mdna:47]
[same as prior period, unchanged from 0000858877-20-000004:mdna:34]

[0000858877-20-000006:mdna:48]
[same as prior period, unchanged from 0000858877-20-000004:mdna:35]

[0000858877-20-000006:mdna:49]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable. If actual credits received by distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-20-000006:mdna:50]
[same as prior period, unchanged from 0000858877-20-000004:mdna:37]

[0000858877-20-000006:mdna:51]
[same as prior period, unchanged from 0000858877-20-000004:mdna:38]

[0000858877-20-000006:mdna:52]
[same as prior period, unchanged from 0000858877-20-000004:mdna:39]

[0000858877-20-000006:mdna:53]
[same as prior period, unchanged from 0000858877-20-000004:mdna:40]

[0000858877-20-000006:mdna:54]
[same as prior period, unchanged from 0000858877-20-000004:mdna:41]

[0000858877-20-000006:mdna:55]
[same as prior period, unchanged from 0000858877-20-000004:mdna:42]

[0000858877-20-000006:mdna:56]
|  |  | April 25, 2020 |  | July 27, 2019 |
| Allowance for doubtful accounts |  | $ | 130 |  |  | $ | 136 |  |
| Percentage of gross accounts receivable |  | 2.8 | % |  | 2.4 | % |
| Allowance for credit loss—lease receivables |  | $ | 36 |  |  | $ | 46 |  |
| Percentage of gross lease receivables(1) |  | 1.6 | % |  | 1.8 | % |
| Allowance for credit loss—loan receivables |  | $ | 86 |  |  | $ | 71 |  |
| Percentage of gross loan receivables |  | 1.6 | % |  | 1.3 | % |

[0000858877-20-000006:mdna:57]
[same as prior period, unchanged from 0000858877-20-000004:mdna:44]

[0000858877-20-000006:mdna:58]
[same as prior period, unchanged from 0000858877-20-000004:mdna:45]

[0000858877-20-000006:mdna:59]
[same as prior period, unchanged from 0000858877-20-000004:mdna:46]

[0000858877-20-000006:mdna:60]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of April 25, 2020 and July 27, 2019 was $90 million and $84 million, respectively, and was recorded as a reduction of our accounts receivable and revenue. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-20-000006:mdna:61]
[same as prior period, unchanged from 0000858877-20-000004:mdna:48]

[0000858877-20-000006:mdna:62]
[same as prior period, unchanged from 0000858877-20-000004:mdna:49]

[0000858877-20-000006:mdna:63]
[same as prior period, unchanged from 0000858877-20-000004:mdna:50]

[0000858877-20-000006:mdna:64]
Our provision for inventory was $49 million and $55 million for the first nine months of fiscal 2020 and 2019, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $98 million and $65 million for the first nine months of fiscal 2020 and 2019, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments.

[0000858877-20-000006:mdna:65]
[same as prior period, unchanged from 0000858877-20-000004:mdna:52]

[0000858877-20-000006:mdna:66]
[same as prior period, unchanged from 0000858877-20-000004:mdna:53]

[0000858877-20-000006:mdna:67]
[same as prior period, unchanged from 0000858877-20-000004:mdna:54]

[0000858877-20-000006:mdna:68]
Loss Contingencies and Product Warranties

[0000858877-20-000006:mdna:69]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-20-000006:mdna:70]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-20-000006:mdna:71]
[same as prior period, unchanged from 0000858877-20-000004:mdna:58]

[0000858877-20-000006:mdna:72]
[same as prior period, unchanged from 0000858877-20-000004:mdna:59]

[0000858877-20-000006:mdna:73]
[same as prior period, unchanged from 0000858877-20-000004:mdna:60]

[0000858877-20-000006:mdna:74]
[same as prior period, unchanged from 0000858877-20-000004:mdna:61]

[0000858877-20-000006:mdna:75]
[same as prior period, unchanged from 0000858877-20-000004:mdna:62]

[0000858877-20-000006:mdna:76]
[same as prior period, unchanged from 0000858877-20-000004:mdna:63]

[0000858877-20-000006:mdna:77]
[same as prior period, unchanged from 0000858877-20-000004:mdna:64]

[0000858877-20-000006:mdna:78]
[same as prior period, unchanged from 0000858877-20-000004:mdna:65]

[0000858877-20-000006:mdna:79]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first nine months of fiscal 2020 and 2019.

[0000858877-20-000006:mdna:80]
[same as prior period, unchanged from 0000858877-20-000004:mdna:67]

[0000858877-20-000006:mdna:81]
[same as prior period, unchanged from 0000858877-20-000004:mdna:68]

[0000858877-20-000006:mdna:82]
[same as prior period, unchanged from 0000858877-20-000004:mdna:69]

[0000858877-20-000006:mdna:83]
[same as prior period, unchanged from 0000858877-20-000004:mdna:70]

[0000858877-20-000006:mdna:84]
[same as prior period, unchanged from 0000858877-20-000004:mdna:71]

[0000858877-20-000006:mdna:85]
[same as prior period, unchanged from 0000858877-20-000004:mdna:72]

[0000858877-20-000006:mdna:86]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 19.4% and 15.8% in the third quarter of fiscal 2020 and 2019, respectively. Our effective tax rate was 19.6% and 13.4% in the first nine months of fiscal 2020 and 2019, respectively.

[0000858877-20-000006:mdna:87]
[same as prior period, unchanged from 0000858877-20-000004:mdna:74]

[0000858877-20-000006:mdna:88]
[same as prior period, unchanged from 0000858877-20-000004:mdna:75]

[0000858877-20-000006:mdna:89]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to domestic manufacturing deduction, foreign-derived intangible income deduction, global intangible low-tax income and base erosion and anti-abuse tax laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 37 countries, including the United States, has made changes to numerous long-standing tax principles. There can be no assurance that these changes, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-20-000006:mdna:90]
49

[0000858877-20-000006:mdna:91]
[same as prior period, unchanged from 0000858877-20-000004:mdna:77]

[0000858877-20-000006:mdna:92]
[same as prior period, unchanged from 0000858877-20-000004:mdna:78]

[0000858877-20-000006:mdna:93]
[same as prior period, unchanged from 0000858877-20-000004:mdna:79]

[0000858877-20-000006:mdna:94]
[same as prior period, unchanged from 0000858877-20-000004:mdna:80]

[0000858877-20-000006:mdna:95]
[same as prior period, unchanged from 0000858877-20-000004:mdna:81]

[0000858877-20-000006:mdna:96]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2020 |  | April 27, 2019 |  | Variancein Dollars |  | Variance in Percent |  | April 25, 2020 |  | April 27, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,597 |  |  | $ | 9,722 |  |  | $ | (1,125 | ) |  | (12 | )% |  | $ | 27,146 |  |  | $ | 28,885 |  |  | $ | (1,739 | ) |  | (6 | )% |
| Percentage of revenue |  | 71.7 | % |  | 75.0 | % |  |  |  |  |  |  |  | 73.1 | % |  | 75.1 | % |  |  |  |  |  |
| Service |  | 3,386 |  |  | 3,236 |  |  | 150 |  |  | 5 | % |  | 10,001 |  |  | 9,591 |  |  | 410 |  |  | 4 | % |
| Percentage of revenue |  | 28.3 | % |  | 25.0 | % |  |  |  |  |  |  |  | 26.9 | % |  | 24.9 | % |  |  |  |  |  |
| Total |  | $ | 11,983 |  |  | $ | 12,958 |  |  | $ | (975 | ) |  | (8 | )% |  | $ | 37,147 |  |  | $ | 38,476 |  |  | $ | (1,329 | ) |  | (3 | )% |

[0000858877-20-000006:mdna:97]
[same as prior period, unchanged from 0000858877-20-000004:mdna:83]

[0000858877-20-000006:mdna:98]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2020 |  | April 27, 2019 |  | Variancein Dollars |  | Variance in Percent |  | April 25, 2020 |  | April 27, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,116 |  |  | $ | 7,695 |  |  | $ | (579 | ) |  | (8 | )% |  | $ | 22,106 |  |  | $ | 22,798 |  |  | $ | (692 | ) |  | (3 | )% |
| Percentage of revenue |  | 59.4 | % |  | 59.4 | % |  |  |  |  |  | 59.5 | % |  | 59.2 | % |  |  |  |  |
| EMEA |  | 3,136 |  |  | 3,356 |  |  | (220 | ) |  | (7 | )% |  | 9,553 |  |  | 9,803 |  |  | (250 | ) |  | (3 | )% |
| Percentage of revenue |  | 26.2 | % |  | 25.9 | % |  |  |  |  |  | 25.7 | % |  | 25.5 | % |  |  |  |  |
| APJC |  | 1,730 |  |  | 1,907 |  |  | (177 | ) |  | (9 | )% |  | 5,489 |  |  | 5,875 |  |  | (386 | ) |  | (7 | )% |
| Percentage of revenue |  | 14.4 | % |  | 14.7 | % |  |  |  |  |  | 14.8 | % |  | 15.3 | % |  |  |  |  |
| Total |  | $ | 11,983 |  |  | $ | 12,958 |  |  | $ | (975 | ) |  | (8 | )% |  | $ | 37,147 |  |  | $ | 38,476 |  |  | $ | (1,329 | ) |  | (3 | )% |

[0000858877-20-000006:mdna:99]
[same as prior period, unchanged from 0000858877-20-000004:mdna:85]

[0000858877-20-000006:mdna:100]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:101]
Total revenue decreased by 8%. Product revenue decreased by 12% and service revenue increased by 5%. Our total revenue reflected declines across each of our geographic segments.  Product revenue for the emerging countries of BRICM, in the aggregate, experienced a 25% product revenue decline, with decreases in China, India, Mexico and Brazil.

[0000858877-20-000006:mdna:102]
[same as prior period, unchanged from 0000858877-20-000004:mdna:88]

[0000858877-20-000006:mdna:103]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:104]
Total revenue decreased by 3%. Product revenue decreased by 6% and service revenue increased by 4%. Our total revenue reflected declines across each of our geographic segments. Product revenue for the emerging countries of BRICM, in the aggregate, experienced a 28% product revenue decline, with decreases primarily in China, India, Mexico and Brazil.

[0000858877-20-000006:mdna:105]
[same as prior period, unchanged from 0000858877-20-000004:mdna:91]

[0000858877-20-000006:mdna:106]
[same as prior period, unchanged from 0000858877-20-000004:mdna:92]

[0000858877-20-000006:mdna:107]
[same as prior period, unchanged from 0000858877-20-000004:mdna:93]

[0000858877-20-000006:mdna:108]
[same as prior period, unchanged from 0000858877-20-000004:mdna:94]

[0000858877-20-000006:mdna:109]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2020 |  | April 27, 2019 |  | Variancein Dollars |  | Variance in Percent |  | April 25, 2020 |  | April 27, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,029 |  |  | $ | 5,658 |  |  | $ | (629 | ) |  | (11 | )% |  | $ | 15,871 |  |  | $ | 16,719 |  |  | $ | (848 | ) |  | (5 | )% |
| Percentage of product revenue |  | 58.5 | % |  | 58.2 | % |  |  |  |  |  | 58.5 | % |  | 57.9 | % |  |  |  |  |  |  |
| EMEA |  | 2,357 |  |  | 2,642 |  |  | (285 | ) |  | (11 | )% |  | 7,308 |  |  | 7,681 |  |  | (373 | ) |  | (5 | )% |
| Percentage of product revenue |  | 27.4 | % |  | 27.2 | % |  |  |  |  |  | 26.9 | % |  | 26.6 | % |  |  |  |  |  |  |
| APJC |  | 1,211 |  |  | 1,422 |  |  | (211 | ) |  | (15 | )% |  | 3,967 |  |  | 4,486 |  |  | (519 | ) |  | (12 | )% |
| Percentage of product revenue |  | 14.1 | % |  | 14.6 | % |  |  |  |  |  | 14.6 | % |  | 15.5 | % |  |  |  |  |  |  |
| Total |  | $ | 8,597 |  |  | $ | 9,722 |  |  | $ | (1,125 | ) |  | (12 | )% |  | $ | 27,146 |  |  | $ | 28,885 |  |  | $ | (1,739 | ) |  | (6 | )% |

[0000858877-20-000006:mdna:110]
[same as prior period, unchanged from 0000858877-20-000004:mdna:96]

[0000858877-20-000006:mdna:111]
In the third quarter of fiscal 2020, COVID-19 had an impact on our financial results and business operations, with a significant impact in our supply chain where we saw manufacturing challenges and component constraints.

[0000858877-20-000006:mdna:112]
[same as prior period, unchanged from 0000858877-20-000004:mdna:97]

[0000858877-20-000006:mdna:113]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:114]
Product revenue in the Americas segment decreased by 11%. The product revenue decrease was across all of our customer segments. From a country perspective, product revenue decreased by 11% in the United States, 6% in Canada, 9% in Mexico and 13% in Brazil.

[0000858877-20-000006:mdna:115]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:116]
The decrease in product revenue in the Americas segment was driven by declines in the service provider, commercial and enterprise markets. The decreases were partially offset by product revenue growth in the public sector market. From a country perspective, product revenue decreased in the United States, Canada, Mexico and Brazil by 4%, 8%, 35% and 11%, respectively.

[0000858877-20-000006:mdna:117]
[same as prior period, unchanged from 0000858877-20-000004:mdna:102]

[0000858877-20-000006:mdna:118]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:119]
Product revenue in the EMEA segment decreased by 11%, with declines in the enterprise, public sector and commercial markets, partially offset by growth in the service provider market. Product revenue from emerging countries within EMEA decreased by 13% and product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, decreased by 10%. From a country perspective, product revenue decreased in United Kingdom and France by 22% and 18%, respectively, and was flat in Germany.

[0000858877-20-000006:mdna:120]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:121]
Product revenue in the EMEA segment decreased by 5%, with declines in the service provider, enterprise and commercial markets, partially offset by growth in the public sector market. Product revenue from emerging countries within EMEA decreased by 2% and product revenue for the remainder of the EMEA segment decreased by 6%. From a country perspective, product revenue declined 13% in the United Kingdom and 8% in France, partially offset by a product revenue increase of 1% in Germany.

[0000858877-20-000006:mdna:122]
[same as prior period, unchanged from 0000858877-20-000004:mdna:107]

[0000858877-20-000006:mdna:123]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:124]
Product revenue in the APJC segment decreased by 15%, driven by declines across all customer segments. From a country perspective, product revenue decreased in China, India and Australia by 32%, 36%, and 25%, respectively. Product revenue in Japan was flat.

[0000858877-20-000006:mdna:125]
51

[0000858877-20-000006:mdna:126]
[same as prior period, unchanged from 0000858877-20-000004:mdna:110]

[0000858877-20-000006:mdna:127]
[same as prior period, unchanged from 0000858877-20-000004:mdna:111]

[0000858877-20-000006:mdna:128]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:129]
Product revenue in the APJC segment decreased by 12%, with declines across each of the customer markets in this geographic segment. From a country perspective, product revenue decreased in China, India and Australia by 34%, 34% and 16%, respectively, partially offset by a product revenue increase of 12% in Japan.

[0000858877-20-000006:mdna:130]
[same as prior period, unchanged from 0000858877-20-000004:mdna:114]

[0000858877-20-000006:mdna:131]
[same as prior period, unchanged from 0000858877-20-000004:mdna:115]

[0000858877-20-000006:mdna:132]
[same as prior period, unchanged from 0000858877-20-000004:mdna:116]

[0000858877-20-000006:mdna:133]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2020 |  | April 27, 2019 |  | Variancein Dollars |  | Variance in Percent |  | April 25, 2020 |  | April 27, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 6,429 |  |  | $ | 7,523 |  |  | $ | (1,094 | ) |  | (15 | )% |  | $ | 20,496 |  |  | $ | 22,247 |  |  | $ | (1,751 | ) |  | (8 | )% |
| Applications |  | 1,363 |  |  | 1,431 |  |  | (68 | ) |  | (5 | )% |  | 4,211 |  |  | 4,315 |  |  | (104 | ) |  | (2 | )% |
| Security |  | 776 |  |  | 729 |  |  | 47 |  |  | 6 | % |  | 2,340 |  |  | 2,083 |  |  | 257 |  |  | 12 | % |
| Other Products |  | 28 |  |  | 39 |  |  | (11 | ) |  | (27 | )% |  | 100 |  |  | 239 |  |  | (139 | ) |  | (58 | )% |
| Total |  | $ | 8,597 |  |  | $ | 9,722 |  |  | $ | (1,125 | ) |  | (12 | )% |  | $ | 27,146 |  |  | $ | 28,885 |  |  | $ | (1,739 | ) |  | (6 | )% |

[0000858877-20-000006:mdna:134]
[same as prior period, unchanged from 0000858877-20-000004:mdna:118]

[0000858877-20-000006:mdna:135]
In the third quarter of fiscal 2020, COVID-19 had an impact on our financial results and business operations, with a significant impact in our supply chain where we saw manufacturing challenges and component constraints.

[0000858877-20-000006:mdna:136]
[same as prior period, unchanged from 0000858877-20-000004:mdna:119]

[0000858877-20-000006:mdna:137]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:138]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center. Infrastructure Platforms revenue decreased by 15%, or $1.1 billion.  Infrastructure Platforms was most impacted by the supply chain challenges. Switching revenue declined in both campus switching and data center switching, although we had revenue growth in our intent-based networking Catalyst 9000 Series. We experienced a decrease in sales of routing products, with declines in both service provider and enterprise markets. We experienced a revenue decline from wireless products, although we saw revenue growth in our Meraki and WiFi6 products. Revenue from data center declined driven by continued market contraction impacting both our servers and Hyperflex offerings.

[0000858877-20-000006:mdna:139]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:140]
Revenue from the Infrastructure Platforms product category decreased 8%, or $1.8 billion. Switching revenue declined in both campus switching and data center switching, although we saw revenue growth in our intent-based networking Catalyst 9000 Series. Routing revenue decreased driven by continued weakness in the service provider market. We experienced a revenue decline from wireless products, although we saw revenue growth in Meraki and WiFi6 products. Revenue from data center declined driven by server products.

[0000858877-20-000006:mdna:141]
[same as prior period, unchanged from 0000858877-20-000004:mdna:124]

[0000858877-20-000006:mdna:142]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:143]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as the Internet of Things (IoT) and AppDynamics analytics software offerings. Revenue in our Applications product category decreased by 5%, or $68 million, with a decline in Unified Communications and Cisco TelePresence partially offset by double digit growth in AppDynamics and IoT software offerings and growth in conferencing.

[0000858877-20-000006:mdna:144]
52

[0000858877-20-000006:mdna:145]
[same as prior period, unchanged from 0000858877-20-000004:mdna:129]

[0000858877-20-000006:mdna:146]
[same as prior period, unchanged from 0000858877-20-000004:mdna:130]

[0000858877-20-000006:mdna:147]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:148]
Revenue in our Applications product category decreased by 2%, or $104 million, with declines in Unified Communications and Cisco TelePresence partially offset by double digit growth in AppDynamics.

[0000858877-20-000006:mdna:149]
[same as prior period, unchanged from 0000858877-20-000004:mdna:131]

[0000858877-20-000006:mdna:150]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:151]
Revenue in our Security product category increased 6%, or $47 million, driven by strong sales of our unified threat management, identity and access, advanced threat security products. Our cloud security portfolio reflected strong double-digit growth and continued momentum with our Duo and Umbrella offerings.

[0000858877-20-000006:mdna:152]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:153]
Revenue in our Security product category increased by 12%, or $257 million, driven by higher sales of identity and access, unified threat management, advanced threat security, and web security products.

[0000858877-20-000006:mdna:154]
[same as prior period, unchanged from 0000858877-20-000004:mdna:136]

[0000858877-20-000006:mdna:155]
The decrease in revenue from our Other Products category for the third quarter of fiscal 2020 was primarily driven by a decrease in revenue from our cloud and system management products. The decrease in revenue from our Other Products category for the first nine months of fiscal 2020 was primarily driven by a decrease in revenue from the SPVSS business which we divested in the second quarter of fiscal 2019.

[0000858877-20-000006:mdna:156]
[same as prior period, unchanged from 0000858877-20-000004:mdna:138]

[0000858877-20-000006:mdna:157]
[same as prior period, unchanged from 0000858877-20-000004:mdna:139]

[0000858877-20-000006:mdna:158]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2020 |  | April 27, 2019 |  | Variancein Dollars |  | Variance in Percent |  | April 25, 2020 |  | April 27, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,088 |  |  | $ | 2,036 |  |  | $ | 52 |  |  | 3 | % |  | $ | 6,235 |  |  | $ | 6,079 |  |  | $ | 156 |  |  | 3 | % |
| Percentage of service revenue |  | 61.7 | % |  | 62.9 | % |  |  |  |  |  | 62.3 | % |  | 63.4 | % |  |  |  |  |  |  |
| EMEA |  | 779 |  |  | 715 |  |  | 64 |  |  | 9 | % |  | 2,245 |  |  | 2,123 |  |  | 122 |  |  | 6 | % |
| Percentage of service revenue |  | 23.0 | % |  | 22.1 | % |  |  |  |  |  | 22.4 | % |  | 22.1 | % |  |  |  |  |  |  |
| APJC |  | 520 |  |  | 485 |  |  | 35 |  |  | 7 | % |  | 1,521 |  |  | 1,389 |  |  | 132 |  |  | 10 | % |
| Percentage of service revenue |  | 15.3 | % |  | 15.0 | % |  |  |  |  |  | 15.3 | % |  | 14.5 | % |  |  |  |  |  |  |
| Total |  | $ | 3,386 |  |  | $ | 3,236 |  |  | $ | 150 |  |  | 5 | % |  | $ | 10,001 |  |  | $ | 9,591 |  |  | $ | 410 |  |  | 4 | % |

[0000858877-20-000006:mdna:159]
[same as prior period, unchanged from 0000858877-20-000004:mdna:141]

[0000858877-20-000006:mdna:160]
Service revenue increased 5% in the third quarter of fiscal 2020 and increased 4% in the first nine months of fiscal 2020 compared to the corresponding periods of fiscal 2019. The increases in both periods were driven by an increase in software and solution support offerings. Service revenue increased across all geographic segments.

[0000858877-20-000006:mdna:161]
[same as prior period, unchanged from 0000858877-20-000004:mdna:147]

[0000858877-20-000006:mdna:162]
[same as prior period, unchanged from 0000858877-20-000004:mdna:148]

[0000858877-20-000006:mdna:163]
[same as prior period, unchanged from 0000858877-20-000004:mdna:143]

[0000858877-20-000006:mdna:164]
[same as prior period, unchanged from 0000858877-20-000004:mdna:144]

[0000858877-20-000006:mdna:165]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,477 |  |  | $ | 6,029 |  |  | 63.7 | % |  | 62.0 | % |  | $ | 17,376 |  |  | $ | 17,779 |  |  | 64.0 | % |  | 61.6 | % |
| Service |  | 2,294 |  |  | 2,144 |  |  | 67.7 | % |  | 66.3 | % |  | 6,623 |  |  | 6,313 |  |  | 66.2 | % |  | 65.8 | % |
| Total |  | $ | 7,771 |  |  | $ | 8,173 |  |  | 64.9 | % |  | 63.1 | % |  | $ | 23,999 |  |  | $ | 24,092 |  |  | 64.6 | % |  | 62.6 | % |

[0000858877-20-000006:mdna:166]
[same as prior period, unchanged from 0000858877-20-000004:mdna:149]

[0000858877-20-000006:mdna:167]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the third quarter and first nine months of fiscal 2020, as compared with the corresponding prior year periods:

[0000858877-20-000006:mdna:168]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Nine Months Ended |
| Fiscal 2019 |  | 62.0 | % |  | 61.6 | % |
| Productivity (1) |  | 3.2 | % |  | 2.9 | % |
| Product pricing |  | (1.9 | )% |  | (1.0 | )% |
| Mix of products sold |  | 0.7 | % |  | 0.6 | % |
| Impact from divestiture of SPVSS business |  | — | % |  | 0.1 | % |
| Others |  | (0.3 | )% |  | (0.2 | )% |
| Fiscal 2020 |  | 63.7 | % |  | 64.0 | % |

[0000858877-20-000006:mdna:169]
[same as prior period, unchanged from 0000858877-20-000004:mdna:152]

[0000858877-20-000006:mdna:170]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:171]
Product gross margin increased by 1.7 percentage points driven by productivity improvements and product mix, partially offset by unfavorable impacts from product pricing.

[0000858877-20-000006:mdna:172]
Productivity improvements were driven by continued memory cost savings and other cost reductions including value engineering efforts (e.g. component redesign, board configuration, test processes and transformation processes) and continued operational efficiency in manufacturing operations. The negative pricing impact was driven by typical market factors and impacted each of our geographic segments. The favorable product mix was driven by impacts from each of our product categories.

[0000858877-20-000006:mdna:173]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:174]
Product gross margin increased by 2.4 percentage points driven by productivity improvements and product mix, partially offset by unfavorable impacts from product pricing. Our product gross margin also benefited from the sale of our lower margin SPVSS business during the second quarter of fiscal 2019.  Productivity improvements were similar factors as indicated above.

[0000858877-20-000006:mdna:175]
[same as prior period, unchanged from 0000858877-20-000004:mdna:159]

[0000858877-20-000006:mdna:176]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:177]
Our service gross margin percentage increased by 1.4 percentage points primarily due to higher sales volume.

[0000858877-20-000006:mdna:178]
[same as prior period, unchanged from 0000858877-20-000004:mdna:162]

[0000858877-20-000006:mdna:179]
[same as prior period, unchanged from 0000858877-20-000004:mdna:165]

[0000858877-20-000006:mdna:180]
[same as prior period, unchanged from 0000858877-20-000004:mdna:166]

[0000858877-20-000006:mdna:181]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:182]
Service gross margin percentage increased by 0.4 percentage points due to higher sales volume offset by increased delivery costs and to a lesser extent higher headcount-related costs.

[0000858877-20-000006:mdna:183]
[same as prior period, unchanged from 0000858877-20-000004:mdna:167]

[0000858877-20-000006:mdna:184]
[same as prior period, unchanged from 0000858877-20-000004:mdna:168]

[0000858877-20-000006:mdna:185]
|  | Three Months Ended |  | Nine Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,828 |  |  | $ | 5,046 |  |  | 67.8 | % |  | 65.6 | % |  | $ | 14,836 |  |  | $ | 14,911 |  |  | 67.1 | % |  | 65.4 | % |
| EMEA | 2,061 |  |  | 2,166 |  |  | 65.7 | % |  | 64.5 | % |  | 6,289 |  |  | 6,307 |  |  | 65.8 | % |  | 64.3 | % |
| APJC | 1,098 |  |  | 1,158 |  |  | 63.5 | % |  | 60.7 | % |  | 3,511 |  |  | 3,467 |  |  | 64.0 | % |  | 59.0 | % |
| Segment total | 7,986 |  |  | 8,370 |  |  | 66.6 | % |  | 64.6 | % |  | 24,636 |  |  | 24,686 |  |  | 66.3 | % |  | 64.2 | % |
| Unallocated corporate items (1) | (215 | ) |  | (197 | ) |  |  |  |  |  | (637 | ) |  | (594 | ) |  |  |  |  |
| Total | $ | 7,771 |  |  | $ | 8,173 |  |  | 64.9 | % |  | 63.1 | % |  | $ | 23,999 |  |  | $ | 24,092 |  |  | 64.6 | % |  | 62.6 | % |

[0000858877-20-000006:mdna:186]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-20-000006:mdna:187]
[same as prior period, unchanged from 0000858877-20-000004:mdna:171]

[0000858877-20-000006:mdna:188]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:189]
[same as prior period, unchanged from 0000858877-20-000004:mdna:173]

[0000858877-20-000006:mdna:190]
[same as prior period, unchanged from 0000858877-20-000004:mdna:174]

[0000858877-20-000006:mdna:191]
The APJC segment gross margin percentage increase was due to favorable impacts from productivity improvements and to a lesser extent, from product mix, partially offset by negative impacts from pricing.

[0000858877-20-000006:mdna:192]
[same as prior period, unchanged from 0000858877-20-000004:mdna:176]

[0000858877-20-000006:mdna:193]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:194]
The Americas segment had a gross margin percentage increase driven by productivity improvements and product mix, partially offset by unfavorable impacts from pricing.

[0000858877-20-000006:mdna:195]
[same as prior period, unchanged from 0000858877-20-000004:mdna:179]

[0000858877-20-000006:mdna:196]
The APJC segment gross margin percentage increase was driven by productivity improvements and, to a lesser extent, product mix, partially offset by negative impacts from pricing.

[0000858877-20-000006:mdna:197]
[same as prior period, unchanged from 0000858877-20-000004:mdna:181]

[0000858877-20-000006:mdna:198]
[same as prior period, unchanged from 0000858877-20-000004:mdna:182]

[0000858877-20-000006:mdna:199]
[same as prior period, unchanged from 0000858877-20-000004:mdna:183]

[0000858877-20-000006:mdna:200]
[same as prior period, unchanged from 0000858877-20-000004:mdna:184]

[0000858877-20-000006:mdna:201]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | Variancein Dollars |  | Variance in Percent |  | April 25, 2020 |  | April 27, 2019 |  | Variance in Dollars |  | Variance in Percent |
| Research and development | $ | 1,546 |  |  | $ | 1,659 |  |  | $ | (113 | ) |  | (7 | )% |  | $ | 4,782 |  |  | $ | 4,824 |  |  | $ | (42 | ) |  | (1 | )% |
| Percentage of revenue | 12.9 | % |  | 12.8 | % |  |  |  |  |  | 12.9 | % |  | 12.5 | % |  |  |  |  |
| Sales and marketing | 2,192 |  |  | 2,403 |  |  | (211 | ) |  | (9 | )% |  | 6,951 |  |  | 7,084 |  |  | (133 | ) |  | (2 | )% |
| Percentage of revenue | 18.3 | % |  | 18.5 | % |  |  |  |  |  | 18.7 | % |  | 18.4 | % |  |  |  |  |
| General and administrative | 457 |  |  | 541 |  |  | (84 | ) |  | (16 | )% |  | 1,431 |  |  | 1,261 |  |  | 170 |  |  | 13 | % |
| Percentage of revenue | 3.8 | % |  | 4.2 | % |  |  |  |  |  | 3.9 | % |  | 3.3 | % |  |  |  |  |
| Total | $ | 4,195 |  |  | $ | 4,603 |  |  | $ | (408 | ) |  | (9 | )% |  | $ | 13,164 |  |  | $ | 13,169 |  |  | $ | (5 | ) |  | — | % |
| Percentage of revenue | 35.0 | % |  | 35.5 | % |  |  |  |  |  | 35.4 | % |  | 34.2 | % |  |  |  |  |

[0000858877-20-000006:mdna:202]
[same as prior period, unchanged from 0000858877-20-000004:mdna:186]

[0000858877-20-000006:mdna:203]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:204]
R&D expenses decreased due to lower headcount-related expenses, discretionary spending and contracted services spending.

[0000858877-20-000006:mdna:205]
[same as prior period, unchanged from 0000858877-20-000004:mdna:189]

[0000858877-20-000006:mdna:206]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:207]
R&D expenses decreased primarily due to lower contracted services and discretionary spending. These decreases were partially offset by higher share-based compensation expense.

[0000858877-20-000006:mdna:208]
[same as prior period, unchanged from 0000858877-20-000004:mdna:192]

[0000858877-20-000006:mdna:209]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:210]
Sales and marketing expenses decreased due to lower discretionary spending, contracted services spending and headcount-related expenses.

[0000858877-20-000006:mdna:211]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:212]
Sales and marketing expenses decreased due to lower discretionary spending and contracted services spending, partially offset by higher headcount-related expenses.

[0000858877-20-000006:mdna:213]
[same as prior period, unchanged from 0000858877-20-000004:mdna:197]

[0000858877-20-000006:mdna:214]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:215]
G&A expenses decreased due to gains recognized on the sale of property that had been held for sale, lower headcount-related expenses and lower contracted services spending, partially offset by higher discretionary spending.

[0000858877-20-000006:mdna:216]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:217]
G&A expenses increased due to the impact of the benefit from the $400 million litigation settlement with Arista from the first quarter of fiscal 2019 and higher discretionary spending, partially offset by lower contracted services spending, gains recognized on the sale of property that had been held for sale, lower acquisition-related/divestiture costs and lower share-based compensation expense.

[0000858877-20-000006:mdna:218]
[same as prior period, unchanged from 0000858877-20-000004:mdna:202]

[0000858877-20-000006:mdna:219]
In the third quarter of fiscal 2020, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $48 million, or 1.0%, compared with the third quarter of fiscal 2019.

[0000858877-20-000006:mdna:220]
In the first nine months of fiscal 2020, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $105 million, or 0.8%, compared with the first nine months of fiscal 2019.

[0000858877-20-000006:mdna:221]
[same as prior period, unchanged from 0000858877-20-000004:mdna:206]

[0000858877-20-000006:mdna:222]
[same as prior period, unchanged from 0000858877-20-000004:mdna:207]

[0000858877-20-000006:mdna:223]
[same as prior period, unchanged from 0000858877-20-000004:mdna:208]

[0000858877-20-000006:mdna:224]
[same as prior period, unchanged from 0000858877-20-000004:mdna:209]

[0000858877-20-000006:mdna:225]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 163 |  |  | $ | 157 |  |  | $ | 494 |  |  | $ | 464 |  |
| Operating expenses |  | 34 |  |  | 39 |  |  | 108 |  |  | 112 |  |
| Total |  | $ | 197 |  |  | $ | 196 |  |  | $ | 602 |  |  | $ | 576 |  |

[0000858877-20-000006:mdna:226]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:227]
The increase in amortization of purchased intangible assets in the third quarter of fiscal 2020 was due largely to the amortization of purchased intangibles from our recent acquisitions.

[0000858877-20-000006:mdna:228]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:229]
Amortization of purchased intangible assets increased due largely to the amortization of purchased intangibles from our recent acquisitions.

[0000858877-20-000006:mdna:230]
[same as prior period, unchanged from 0000858877-20-000004:mdna:215]

[0000858877-20-000006:mdna:231]
We initiated a restructuring plan in the third quarter of fiscal 2020 in order to realign the organization and enable further investment in key priority areas. In connection with this restructuring plan, we incurred charges of $128 million for the third quarter and first nine months of fiscal 2020. We expect this restructuring plan to be substantially completed in fiscal 2021.

[0000858877-20-000006:mdna:232]
We initiated a restructuring plan during fiscal 2018 in order to realign our organization and enable further investment in key priority areas. In connection with this restructuring plan, we incurred charges of $226 million for the first nine months of fiscal 2020 and have incurred cumulative charges of $656 million. We completed the Fiscal 2018 Plan in the second quarter of fiscal 2020.

[0000858877-20-000006:mdna:233]
We incurred restructuring and other charges of $128 million and $354 million for the third quarter and first nine months of fiscal 2020, respectively, in connection with the above mentioned restructuring plans.

[0000858877-20-000006:mdna:234]
[same as prior period, unchanged from 0000858877-20-000004:mdna:218]

[0000858877-20-000006:mdna:235]
[same as prior period, unchanged from 0000858877-20-000004:mdna:219]

[0000858877-20-000006:mdna:236]
[same as prior period, unchanged from 0000858877-20-000004:mdna:220]

[0000858877-20-000006:mdna:237]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Operating income |  | $ | 3,414 |  |  | $ | 3,513 |  |  | $ | 10,373 |  |  | $ | 10,529 |  |
| Operating income as a percentage of revenue |  | 28.5 | % |  | 27.1 | % |  | 27.9 | % |  | 27.4 | % |

[0000858877-20-000006:mdna:238]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:239]
Operating income decreased by 3%, and as a percentage of revenue operating income increased by 1.4 percentage points. These changes resulted primarily from a revenue decrease and higher restructuring and other charges, partially offset by a gross margin percentage increase (driven by productivity improvements and product mix, partially offset by unfavorable impacts from pricing).

[0000858877-20-000006:mdna:240]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:241]
Operating income decreased by 1%, and as a percentage of revenue operating income increased by 0.5 percentage points. These changes resulted primarily from: a revenue decrease and the impact of the benefit from the $400 million litigation settlement with Arista in the first quarter of fiscal 2019, partially offset by a gross margin percentage increase (driven by productivity improvements and product mix, partially offset by unfavorable impacts from pricing).

[0000858877-20-000006:mdna:242]
[same as prior period, unchanged from 0000858877-20-000004:mdna:227]

[0000858877-20-000006:mdna:243]
[same as prior period, unchanged from 0000858877-20-000004:mdna:228]

[0000858877-20-000006:mdna:244]
[same as prior period, unchanged from 0000858877-20-000004:mdna:229]

[0000858877-20-000006:mdna:245]
[same as prior period, unchanged from 0000858877-20-000004:mdna:230]

[0000858877-20-000006:mdna:246]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2020 |  | April 27, 2019 |  | Variancein Dollars |  | April 25, 2020 |  | April 27, 2019 |  | Variance in Dollars |
| Interest income |  | $ | 218 |  |  | $ | 331 |  |  | $ | (113 | ) |  | $ | 733 |  |  | $ | 1,003 |  |  | $ | (270 | ) |
| Interest expense |  | (130 | ) |  | (211 | ) |  | 81 |  |  | (466 | ) |  | (655 | ) |  | 189 |  |
| Interest income (expense), net |  | $ | 88 |  |  | $ | 120 |  |  | $ | (32 | ) |  | $ | 267 |  |  | $ | 348 |  |  | $ | (81 | ) |

[0000858877-20-000006:mdna:247]
For each of the third quarter and first nine months of fiscal 2020, interest income decreased driven by a lower average balance of cash and available-for-sale debt investments and lower interest rates. The decrease in interest expense was driven by a lower average debt balance and the impact of lower effective interest rates.

[0000858877-20-000006:mdna:248]
[same as prior period, unchanged from 0000858877-20-000004:mdna:233]

[0000858877-20-000006:mdna:249]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 25, 2020 |  | April 27, 2019 |  | Variancein Dollars |  | April 25, 2020 |  | April 27, 2019 |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | (1 | ) |  | $ | (7 | ) |  | $ | 6 |  |  | $ | 20 |  |  | $ | (18 | ) |  | $ | 38 |  |
| Marketable equity investments |  | (6 | ) |  | (57 | ) |  | 51 |  |  | (6 | ) |  | — |  |  | (6 | ) |
| Non-marketable equity and other investments |  | 17 |  |  | 58 |  |  | (41 | ) |  | 108 |  |  | 59 |  |  | 49 |  |
| Net gains (losses) on investments |  | 10 |  |  | (6 | ) |  | 16 |  |  | 122 |  |  | 41 |  |  | 81 |  |
| Other gains (losses), net |  | (68 | ) |  | (12 | ) |  | (56 | ) |  | (98 | ) |  | (51 | ) |  | (47 | ) |
| Other income (loss), net |  | $ | (58 | ) |  | $ | (18 | ) |  | $ | (40 | ) |  | $ | 24 |  |  | $ | (10 | ) |  | $ | 34 |  |

[0000858877-20-000006:mdna:250]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:251]
The total change in net gains (losses) on marketable equity investments was attributable to market value fluctuations and the timing of recognition of gains and losses. The change in net gains (losses) on non-marketable equity and other investments was primarily due to lower net realized gains. The change in other gains (losses), net was driven primarily by higher donation expense as related to COVID-19 programs.

[0000858877-20-000006:mdna:252]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:253]
The total change in net gains (losses) on available-for-sale debt investments was primarily attributable to higher realized gains as a result of market conditions, and the timing of sales of these investments. The change in net gains (losses) on non-marketable equity and other investments was primarily due to higher realized gains and higher unrealized gains, partially offset by higher impairment charges. The change in other gains (losses), net was driven primarily by higher donation expense as related to COVID-19 programs.

[0000858877-20-000006:mdna:254]
[same as prior period, unchanged from 0000858877-20-000004:mdna:239]

[0000858877-20-000006:mdna:255]
Three Months Ended April 25, 2020 Compared with Three Months Ended April 27, 2019

[0000858877-20-000006:mdna:256]
The provision for income taxes resulted in an effective tax rate of 19.4% for the third quarter of fiscal 2020 compared with 15.8% for the third quarter of fiscal 2019. The increase in the effective tax rate was primarily due to a decrease in discrete net tax benefits in fiscal 2020 as compared to fiscal 2019.

[0000858877-20-000006:mdna:257]
[same as prior period, unchanged from 0000858877-20-000004:mdna:245]

[0000858877-20-000006:mdna:258]
[same as prior period, unchanged from 0000858877-20-000004:mdna:242]

[0000858877-20-000006:mdna:259]
[same as prior period, unchanged from 0000858877-20-000004:mdna:243]

[0000858877-20-000006:mdna:260]
[same as prior period, unchanged from 0000858877-20-000004:mdna:244]

[0000858877-20-000006:mdna:261]
Nine Months Ended April 25, 2020 Compared with Nine Months Ended April 27, 2019

[0000858877-20-000006:mdna:262]
The provision for income taxes resulted in an effective tax rate of 19.6% for the first nine months of fiscal 2020 compared with 13.4% for the first nine months of fiscal 2019. The increase in the effective tax rate was primarily due to a decrease in discrete net tax benefits in the first nine months of fiscal 2020 compared to the first nine months of fiscal 2019.

[0000858877-20-000006:mdna:263]
[same as prior period, unchanged from 0000858877-20-000004:mdna:248]

[0000858877-20-000006:mdna:264]
[same as prior period, unchanged from 0000858877-20-000004:mdna:249]

[0000858877-20-000006:mdna:265]
[same as prior period, unchanged from 0000858877-20-000004:mdna:250]

[0000858877-20-000006:mdna:266]
[same as prior period, unchanged from 0000858877-20-000004:mdna:251]

[0000858877-20-000006:mdna:267]
[same as prior period, unchanged from 0000858877-20-000004:mdna:252]

[0000858877-20-000006:mdna:268]
[same as prior period, unchanged from 0000858877-20-000004:mdna:253]

[0000858877-20-000006:mdna:269]
[same as prior period, unchanged from 0000858877-20-000004:mdna:254]

[0000858877-20-000006:mdna:270]
|  | April 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 10,366 |  |  | $ | 11,750 |  |  | $ | (1,384 | ) |
| Available-for-sale debt investments | 18,208 |  |  | 21,660 |  |  | (3,452 | ) |
| Marketable equity securities | — |  |  | 3 |  |  | (3 | ) |
| Total | $ | 28,574 |  |  | $ | 33,413 |  |  | $ | (4,839 | ) |

[0000858877-20-000006:mdna:271]
The decrease in cash and cash equivalents and investments in the first nine months of fiscal 2020 was primarily driven by a net decrease in debt of $8.7 billion; cash dividends of $4.5 billion; cash returned to shareholders in the form of repurchases of common stock of $2.7 billion under the stock repurchase program; capital expenditures of $0.6 billion; and net cash paid for acquisitions and divestitures of $0.2 billion. These uses of cash were partially offset by cash provided by operating activities of $11.6 billion.

[0000858877-20-000006:mdna:272]
In addition to cash requirements in the normal course of business, on July 9, 2019 we announced our intent to acquire Acacia for a net purchase consideration of approximately $2.6 billion in cash. In addition, approximately $0.7 billion of the U.S. transition tax on accumulated earnings for foreign subsidiaries is payable in less than one year. Also, $4.5 billion of long-term debt outstanding at April 25, 2020 will mature within the next 12 months from the balance sheet date. See further discussion of liquidity under “Liquidity and Capital Resource Requirements” below.

[0000858877-20-000006:mdna:273]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our available-for-sale debt investment portfolio consisting primarily of high quality investment-grade securities.  We believe that our strong cash and cash equivalents and investments position is critical at this time of uncertainty due to the COVID-19 pandemic and allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-20-000006:mdna:274]
[same as prior period, unchanged from 0000858877-20-000004:mdna:259]

[0000858877-20-000006:mdna:275]
[same as prior period, unchanged from 0000858877-20-000004:mdna:260]

[0000858877-20-000006:mdna:276]
[same as prior period, unchanged from 0000858877-20-000004:mdna:261]

[0000858877-20-000006:mdna:277]
|  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |
| Net cash provided by operating activities | $ | 11,624 |  |  | $ | 11,889 |  |
| Acquisition of property and equipment | (562 | ) |  | (701 | ) |
| Free cash flow | $ | 11,062 |  |  | $ | 11,188 |  |

[0000858877-20-000006:mdna:278]
[same as prior period, unchanged from 0000858877-20-000004:mdna:263]

[0000858877-20-000006:mdna:279]
[same as prior period, unchanged from 0000858877-20-000004:mdna:264]

[0000858877-20-000006:mdna:280]
[same as prior period, unchanged from 0000858877-20-000004:mdna:265]

[0000858877-20-000006:mdna:281]
[same as prior period, unchanged from 0000858877-20-000004:mdna:266]

[0000858877-20-000006:mdna:282]
[same as prior period, unchanged from 0000858877-20-000004:mdna:267]

[0000858877-20-000006:mdna:283]
[same as prior period, unchanged from 0000858877-20-000004:mdna:268]

[0000858877-20-000006:mdna:284]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2020 |  |  |  |  |  |  |  |  |  |  |  |  |
| April 25, 2020 |  | $ | 0.36 |  |  | $ | 1,519 |  |  | 25 |  |  | $ | 39.71 |  |  | $ | 981 |  |  | $ | 2,500 |  |
| January 25, 2020 |  | $ | 0.35 |  |  | $ | 1,486 |  |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |  | $ | 2,356 |  |
| October 26, 2019 |  | $ | 0.35 |  |  | $ | 1,486 |  |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |  | $ | 2,254 |  |
| Fiscal 2019 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 27, 2019 |  | $ | 0.35 |  |  | $ | 1,490 |  |  | 82 |  |  | $ | 54.99 |  |  | $ | 4,515 |  |  | $ | 6,005 |  |
| April 27, 2019 |  | $ | 0.35 |  |  | $ | 1,519 |  |  | 116 |  |  | $ | 52.14 |  |  | $ | 6,020 |  |  | $ | 7,539 |  |
| January 26, 2019 |  | $ | 0.33 |  |  | $ | 1,470 |  |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |  | $ | 6,486 |  |
| October 27, 2018 |  | $ | 0.33 |  |  | $ | 1,500 |  |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |  | $ | 6,526 |  |

[0000858877-20-000006:mdna:285]
Any future dividends are subject to the approval of our Board of Directors.

[0000858877-20-000006:mdna:286]
The remaining authorized amount for stock repurchases under this program is approximately $10.8 billion, with no termination date.

[0000858877-20-000006:mdna:287]
[same as prior period, unchanged from 0000858877-20-000004:mdna:272]

[0000858877-20-000006:mdna:288]
|  | April 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,569 |  |  | $ | 5,491 |  |  | $ | (922 | ) |

[0000858877-20-000006:mdna:289]
Our accounts receivable net, as of April 25, 2020 decreased by approximately 17%, as compared with the end of fiscal 2019, primarily due to timing and amount of product and service billings in the third quarter of fiscal 2020 compared with the fourth quarter of fiscal 2019.

[0000858877-20-000006:mdna:290]
[same as prior period, unchanged from 0000858877-20-000004:mdna:275]

[0000858877-20-000006:mdna:291]
|  | April 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Inventories | $ | 1,212 |  |  | $ | 1,383 |  |  | $ | (171 | ) |
| Purchase commitments with contract manufacturers and suppliers | $ | 5,140 |  |  | $ | 4,967 |  |  | $ | 173 |  |

[0000858877-20-000006:mdna:292]
Inventory as of April 25, 2020 decreased by 12% from our inventory balance at the end of fiscal 2019. The decrease in inventory was primarily due to a decrease in finished goods and lower deferred cost of sales, partially offset by an increase in raw materials. Purchase commitments with contract manufacturers and suppliers increased 3% compared to the end of fiscal 2019. On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers was flat compared with the end of fiscal 2019. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-20-000006:mdna:293]
[same as prior period, unchanged from 0000858877-20-000004:mdna:279]

[0000858877-20-000006:mdna:294]
[same as prior period, unchanged from 0000858877-20-000004:mdna:280]

[0000858877-20-000006:mdna:295]
[same as prior period, unchanged from 0000858877-20-000004:mdna:282]

[0000858877-20-000006:mdna:296]
[same as prior period, unchanged from 0000858877-20-000004:mdna:283]

[0000858877-20-000006:mdna:297]
[same as prior period, unchanged from 0000858877-20-000004:mdna:284]

[0000858877-20-000006:mdna:298]
[same as prior period, unchanged from 0000858877-20-000004:mdna:285]

[0000858877-20-000006:mdna:299]
|  | April 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Lease receivables, net | $ | 2,139 |  |  | $ | 2,326 |  |  | $ | (187 | ) |
| Loan receivables, net | 5,173 |  |  | 5,367 |  |  | (194 | ) |
| Financed service contracts, net | 2,161 |  |  | 2,360 |  |  | (199 | ) |
| Total, net | $ | 9,473 |  |  | $ | 10,053 |  |  | $ | (580 | ) |

[0000858877-20-000006:mdna:300]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services. The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed. Financing receivables decreased by 6%.

[0000858877-20-000006:mdna:301]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements to customers provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, with payment terms generally ranging from 60 to 90 days. At the end of the third quarter of fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic environment. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-20-000006:mdna:302]
The volume of channel partner financing was $20.5 billion and $21.7 billion for the first nine months of fiscal 2020 and 2019, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.4 billion as of April 25, 2020 and July 27, 2019, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of April 25, 2020, the total maximum potential future payments related to these guarantees was approximately $215 million, of which approximately $70 million was recorded as deferred revenue.

[0000858877-20-000006:mdna:303]
[same as prior period, unchanged from 0000858877-20-000004:mdna:290]

[0000858877-20-000006:mdna:304]
[same as prior period, unchanged from 0000858877-20-000004:mdna:291]

[0000858877-20-000006:mdna:305]
COVID-19 Business Resiliency Program  At the end of the third quarter of fiscal 2020, we initiated a new Business Resiliency Program designed to help customers and channel partners mitigate financial challenges resulting from the COVID-19 pandemic. This program includes $2.5 billion in currently available funds to provide organizations with access to financing solutions. The new Business Resiliency Program offered by us includes an up-front 90-day payment holiday and allows a customer to defer 95 percent of the payments for a new product or solution until calendar 2021, which in turn protects their business and increases their existing cash flow.

[0000858877-20-000006:mdna:306]
[same as prior period, unchanged from 0000858877-20-000004:mdna:292]

[0000858877-20-000006:mdna:307]
[same as prior period, unchanged from 0000858877-20-000004:mdna:293]

[0000858877-20-000006:mdna:308]
|  | Maturity Date |  | April 25, 2020 |  | July 27, 2019 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | $ | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | 1,500 |  |
| 4.45% | January 15, 2020 |  | — |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 16,000 |  |  | $ | 20,500 |  |

[0000858877-20-000006:mdna:309]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of April 25, 2020.

[0000858877-20-000006:mdna:310]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of April 25, 2020. We had $4.2 billion in commercial paper notes outstanding as of July 27, 2019.

[0000858877-20-000006:mdna:311]
Credit Facility On May 15, 2020, we entered into a 364-day credit agreement with certain institutional lenders that provides for a $2.75 billion unsecured revolving credit facility that is scheduled to expire on May 14, 2021. The credit agreement is structured as an amendment and restatement of our five-year credit facility which would have terminated on May 15, 2020, the end of its five-year term. As of April 25, 2020, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the five-year credit facility. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than 0.25%. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion. This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

[0000858877-20-000006:mdna:312]
[same as prior period, unchanged from 0000858877-20-000004:mdna:298]

[0000858877-20-000006:mdna:313]
[same as prior period, unchanged from 0000858877-20-000004:mdna:299]

[0000858877-20-000006:mdna:314]
[same as prior period, unchanged from 0000858877-20-000004:mdna:300]

[0000858877-20-000006:mdna:315]
|  | April 25, 2020 |  | July 27, 2019 |  | Increase (Decrease) |
| Service | $ | 11,423 |  |  | $ | 11,709 |  |  | $ | (286 | ) |
| Product | 7,225 |  |  | 6,758 |  |  | 467 |  |
| Total | $ | 18,648 |  |  | $ | 18,467 |  |  | $ | 181 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 10,710 |  |  | $ | 10,668 |  |  | $ | 42 |  |
| Noncurrent | 7,938 |  |  | 7,799 |  |  | 139 |  |
| Total | $ | 18,648 |  |  | $ | 18,467 |  |  | $ | 181 |  |

[0000858877-20-000006:mdna:316]
Deferred product revenue increased primarily due to increased deferrals related to our recurring software offerings. The 2% decrease in deferred service revenue was driven by the impact of ongoing amortization of deferred service revenue.

[0000858877-20-000006:mdna:317]
[same as prior period, unchanged from 0000858877-20-000004:mdna:303]

[0000858877-20-000006:mdna:318]
[same as prior period, unchanged from 0000858877-20-000004:mdna:304]

[0000858877-20-000006:mdna:319]
The income tax payable outstanding as of April 25, 2020 for the U.S. transition tax on accumulated earnings for foreign subsidiaries is $7.6 billion. Approximately $0.7 billion is payable in less than one year; $1.4 billion is payable between 1 to 3 years; $3.2 billion is payable between 3 to 5 years; and the remaining $2.3 billion is payable in more than 5 years.

[0000858877-20-000006:mdna:320]
[same as prior period, unchanged from 0000858877-20-000004:mdna:306]

[0000858877-20-000006:mdna:321]
[same as prior period, unchanged from 0000858877-20-000004:mdna:307]

[0000858877-20-000006:mdna:322]
[same as prior period, unchanged from 0000858877-20-000004:mdna:308]

[0000858877-20-000006:mdna:323]
We also have certain funding commitments primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $344 million as of April 25, 2020, compared with $326 million as of July 27, 2019.

[0000858877-20-000006:mdna:324]
[same as prior period, unchanged from 0000858877-20-000004:mdna:310]

[0000858877-20-000006:mdna:325]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have non-marketable equity and other investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our non-marketable equity and other investments and customer financings, and we have determined that as of April 25, 2020 there were no material unconsolidated variable interest entities.

[0000858877-20-000006:mdna:326]
[same as prior period, unchanged from 0000858877-20-000004:mdna:312]

[0000858877-20-000006:mdna:327]
[same as prior period, unchanged from 0000858877-20-000004:mdna:313]

[0000858877-20-000006:mdna:328]
[same as prior period, unchanged from 0000858877-20-000004:mdna:314]

[0000858877-20-000006:mdna:329]
While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to increased disruption and volatility in capital markets and credit markets. The pandemic and resulting economic uncertainty could adversely affect our liquidity and capital resources in the future. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity

[0000858877-20-000006:mdna:330]
[same as prior period, unchanged from 0000858877-20-000004:mdna:316]

[0000858877-20-000006:mdna:331]
CISCO SYSTEMS, INC.

[0000858877-20-000006:mdna:332]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-20-000006:mdna:333]
requirements associated with our operations. On May 15, 2020 we entered into a 364-day credit facility as discussed above. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.
