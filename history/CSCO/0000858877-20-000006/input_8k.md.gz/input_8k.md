# CSCO 8-K — 0001193125-20-141598 filed 2020-05-13

## item codes, every 8-K on or before 2020-05-18

- 2020-05-13 0001193125-20-141598 — 2.02, 9.01
- 2020-03-13 0001193125-20-072960 — 5.02
- 2020-03-06 0001193125-20-065138 — 5.02
- 2020-02-12 0001193125-20-033208 — 2.02, 9.01
- 2020-01-27 0001193125-20-015453 — 5.02
- 2019-12-23 0001193125-19-322662 — 8.01
- 2019-12-12 0001193125-19-312796 — 8.01
- 2019-12-11 0001193125-19-311525 — 5.07
- 2019-12-04 0001193125-19-306229 — 8.01
- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2020-05-18

- none on or before 2020-05-18

## item 2.02 — earnings release, exhibit 99.1

[0001193125-20-141598:8k_2_02:1]
EX-99.1
2
d932273dex991.htm
EX-99.1

[0001193125-20-141598:8k_2_02:2]
EX-99.1

[0001193125-20-141598:8k_2_02:3]
Exhibit 99.1

[0001193125-20-141598:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-20-141598:8k_2_02:5]
CISCO REPORTS THIRD QUARTER EARNINGS

[0001193125-20-141598:8k_2_02:6]
|  | • |  | Q3 Results: |

[0001193125-20-141598:8k_2_02:7]
|  | • |  | Revenue: $12.0 billion |

[0001193125-20-141598:8k_2_02:8]
|  | • |  | Decrease of (8)% year over year |

[0001193125-20-141598:8k_2_02:9]
|  | • |  | Earnings per Share: GAAP: $0.65; Non-GAAP: $0.79 |

[0001193125-20-141598:8k_2_02:10]
|  | • |  | GAAP EPS decreased (6)% year over year |

[0001193125-20-141598:8k_2_02:11]
|  | • |  | Non-GAAP EPS increased 1% year over year |

[0001193125-20-141598:8k_2_02:12]
|  | • |  | Q4 Guidance: |

[0001193125-20-141598:8k_2_02:13]
|  | • |  | Revenue: (8.5)% to (11.5)% decline year over year |

[0001193125-20-141598:8k_2_02:14]
|  | • |  | Earnings per Share: GAAP: $0.57 to $0.62; Non-GAAP: $0.72 to $0.74 |

[0001193125-20-141598:8k_2_02:15]
SAN JOSE, Calif. — May 13, 2020 — Cisco today reported third quarter results for the period ended April 25, 2020.
Cisco reported third quarter revenue of $12.0 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.8 billion or $0.65 per share, and non-GAAP net income of
$3.4 billion or $0.79 per share.

[0001193125-20-141598:8k_2_02:16]
“During this extraordinary time, our priority has been supporting our employees, customers, partners and
communities, while positioning Cisco for the future,” said Chuck Robbins, chairman and CEO of Cisco. “The pandemic has driven organizations across the globe to digitize their operations and support remote workforces at a faster speed and
greater scale than ever before. We remain focused on providing the technology and solutions our customers need to accelerate their digital organizations.”

[0001193125-20-141598:8k_2_02:17]
GAAP Results

[0001193125-20-141598:8k_2_02:18]
|  |  | Q3 FY 2020 |  |  | Q3 FY 2019 |  |  | Vs. Q3 FY 2019 |  |
| Revenue |  | $ | 12.0 billion |  |  | $ | 13.0 billion |  |  |  | (8 | )% |
| Net Income |  | $ | 2.8 billion |  |  | $ | 3.0 billion |  |  |  | (9 | )% |
| Diluted Earnings per Share (EPS) |  | $ | 0.65 |  |  | $ | 0.69 |  |  |  | (6 | )% |
| Non-GAAP Results |  |
|  |  | Q3 FY 2020 |  |  | Q3 FY 2019 |  |  | Vs. Q3 FY 2019 |  |
| Net Income |  | $ | 3.4 billion |  |  | $ | 3.5 billion |  |  |  | (2 | )% |
| EPS |  | $ | 0.79 |  |  | $ | 0.78 |  |  |  | 1 | % |

[0001193125-20-141598:8k_2_02:19]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-20-141598:8k_2_02:20]
“We executed well in Q3 in a very challenging environment, delivering strong margins and non-GAAP EPS growth,” said Kelly Kramer, CFO of Cisco.
“The resiliency that we have been building into our business model is paying off, with software subscriptions now at 74% of our software revenue, up 9 points year over year. We are focused on driving long-term profitable growth while delivering
shareholder value.”

[0001193125-20-141598:8k_2_02:21]
1

[0001193125-20-141598:8k_2_02:22]
COVID-19 Pandemic Response

[0001193125-20-141598:8k_2_02:23]
We have been focused on helping our employees, customers, partners and communities.

[0001193125-20-141598:8k_2_02:24]
Employees

[0001193125-20-141598:8k_2_02:25]
|  | • |  | 95% of our global workforce working from home. |

[0001193125-20-141598:8k_2_02:26]
|  | • |  | Seamless transition to work from home with a long-standing flexible work policy, and we build the technologies that allow organizations to stay connected, secure and productive. |

[0001193125-20-141598:8k_2_02:27]
|  | • |  | For the 5% who must be in the office to perform their roles, we are focused on their health and safety, and are taking all of the necessary precautions. |

[0001193125-20-141598:8k_2_02:28]
Customer and Partners

[0001193125-20-141598:8k_2_02:29]
|  | • |  | Introduced a variety of free offers and trials for our Webex and security technologies as they dramatically shifted entire workforces to be remote. |

[0001193125-20-141598:8k_2_02:30]
|  | • |  | Announced $2.5 billion in financing with a new Business Resiliency Program through Cisco Capital to offer financial flexibility and support their business continuity. This will help customers and partners access the technology they need now, invest for recovery, and defer most of the payments until early 2021. |

[0001193125-20-141598:8k_2_02:31]
Communities

[0001193125-20-141598:8k_2_02:32]
|  | • |  | Committed nearly $300 million to date to support both global and local pandemic response efforts. |

[0001193125-20-141598:8k_2_02:33]
|  | • |  | Providing technology and financial support for non-profits, first responders, and governments. |

[0001193125-20-141598:8k_2_02:34]
|  | • |  | Donating personal protective equipment to hospital workers including N95 masks and face shields 3D-printed by Cisco volunteers around the world. |

[0001193125-20-141598:8k_2_02:35]
2

[0001193125-20-141598:8k_2_02:36]
Financial Summary

[0001193125-20-141598:8k_2_02:37]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-20-141598:8k_2_02:38]
Q3 FY 2020 Highlights

[0001193125-20-141598:8k_2_02:39]
Revenue — Total
revenue was $12.0 billion, down 8%, with product revenue down 12% and service revenue up 5%. Revenue by geographic segment was: Americas down 8%, EMEA down 7%, and APJC down 9%. Product revenue was led by growth in Security, up 6%.
Infrastructure Platforms was down 15% and Applications was down 5%.

[0001193125-20-141598:8k_2_02:40]
Gross Margin — On a GAAP basis, total gross margin, product
gross margin, and service gross margin were 64.9%, 63.7%, and 67.7%, respectively, as compared with 63.1%, 62.0%, and 66.3%, respectively, in the third quarter of fiscal 2019.

[0001193125-20-141598:8k_2_02:41]
On a non-GAAP basis, total gross margin, product gross margin, and service gross margin were 66.6%, 65.8%, and 68.9%,
respectively, as compared with 64.6%, 63.7%, and 67.3%, respectively, in the third quarter of fiscal 2019.

[0001193125-20-141598:8k_2_02:42]
Total gross margins by geographic segment
were: 67.8% for the Americas, 65.7% for EMEA and 63.5% for APJC.

[0001193125-20-141598:8k_2_02:43]
Operating Expenses — On a GAAP basis, operating expenses were
$4.4 billion, down 6%, and were 36.4% of revenue. Non-GAAP operating expenses were $3.8 billion, down 9%, and were 31.8% of revenue.

[0001193125-20-141598:8k_2_02:44]
Operating Income — GAAP operating income was $3.4 billion, down 3%, with GAAP operating margin of 28.5%. Non-GAAP operating income was flat at $4.2 billion, with non-GAAP operating margin at 34.9%.

[0001193125-20-141598:8k_2_02:45]
Provision for Income Taxes — The GAAP tax provision rate was 19.4%. The non-GAAP tax provision rate
was 20.0%.

[0001193125-20-141598:8k_2_02:46]
Net Income and EPS — On a GAAP basis, net income was $2.8 billion, a decrease of 9%, and EPS was $0.65, a decrease of
6%. On a non-GAAP basis, net income was $3.4 billion, a decrease of 2%, and EPS was $0.79, an increase of 1%.

[0001193125-20-141598:8k_2_02:47]
Cash Flow from Operating Activities — $4.2 billion for the third quarter of fiscal 2020, a decrease of 2% compared with
$4.3 billion for the third quarter of fiscal 2019.

[0001193125-20-141598:8k_2_02:48]
Balance Sheet and Other Financial Highlights

[0001193125-20-141598:8k_2_02:49]
Cash and Cash Equivalents and Investments — $28.6 billion at the end of the third quarter of fiscal 2020, compared with
$33.4 billion at the end of fiscal 2019.

[0001193125-20-141598:8k_2_02:50]
Deferred Revenue — $18.6 billion, up 7% in total, with deferred product revenue up
17%. Deferred service revenue was up 1%.

[0001193125-20-141598:8k_2_02:51]
Remaining Performance Obligations — $25.5 billion at the end of the third
quarter of fiscal 2020, up 11%.

[0001193125-20-141598:8k_2_02:52]
Capital Allocation — In the third quarter of fiscal 2020, we returned $2.5 billion to
shareholders through share buybacks and dividends. We declared and paid a cash dividend of $0.36 per common share, or $1.5 billion, and repurchased approximately 25 million shares of common stock under our stock repurchase program at an
average price of $39.71 per share for an aggregate purchase price of $981 million. The remaining authorized amount for stock repurchases under the program is $10.8 billion with no termination date.

[0001193125-20-141598:8k_2_02:53]
Acquisitions

[0001193125-20-141598:8k_2_02:54]
In the third quarter of fiscal 2020, we
closed the acquisition of Exablaze, a privately held designer and manufacturer of advanced network devices aimed at reducing latency and improving network performance.

[0001193125-20-141598:8k_2_02:55]
3

[0001193125-20-141598:8k_2_02:56]
Guidance for Q4 FY 2020

[0001193125-20-141598:8k_2_02:57]
Cisco expects to achieve the following results for the fourth quarter of fiscal 2020:

[0001193125-20-141598:8k_2_02:58]
| Q4 FY 2020 |  |  |
| Revenue |  | (8.5)% - (11.5)% decline Y/Y |
| Non-GAAP gross margin rate |  | 64% - 65% |
| Non-GAAP operating margin rate |  | 31.5% - 32.5% |
| Non-GAAP tax provision rate |  | 20% |
| Non-GAAP EPS |  | $0.72 - $0.74 |

[0001193125-20-141598:8k_2_02:59]
Cisco estimates that GAAP EPS will be $0.57 to $0.62 in the fourth quarter of fiscal 2020.

[0001193125-20-141598:8k_2_02:60]
A reconciliation between the Guidance for Q4 FY 2020 on a GAAP and non-GAAP basis is provided in the table entitled
“GAAP to non-GAAP Guidance for Q4 FY 2020” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-20-141598:8k_2_02:61]
Editor’s Notes:

[0001193125-20-141598:8k_2_02:62]
|  | • |  | Q3 fiscal year 2020 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, May 13, 2020 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-20-141598:8k_2_02:63]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, May 13, 2020 to 4:00 p.m. Pacific Time, May 20, 2020 at 1-800-391-9847 (United States) or 1-402-220-3093 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-20-141598:8k_2_02:64]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, May 13, 2020. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-20-141598:8k_2_02:65]
4

[0001193125-20-141598:8k_2_02:66]
CISCO SYSTEMS, INC.

[0001193125-20-141598:8k_2_02:67]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-20-141598:8k_2_02:68]
(In millions, except per-share amounts)

[0001193125-20-141598:8k_2_02:69]
(Unaudited)

[0001193125-20-141598:8k_2_02:70]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 25,2020 |  |  | April 27,2019 |  |  | April 25,2020 |  |  | April 27,2019 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,597 |  |  | $ | 9,722 |  |  | $ | 27,146 |  |  | $ | 28,885 |  |
| Service |  |  | 3,386 |  |  |  | 3,236 |  |  |  | 10,001 |  |  |  | 9,591 |  |
| Total revenue |  |  | 11,983 |  |  |  | 12,958 |  |  |  | 37,147 |  |  |  | 38,476 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,120 |  |  |  | 3,693 |  |  |  | 9,770 |  |  |  | 11,106 |  |
| Service |  |  | 1,092 |  |  |  | 1,092 |  |  |  | 3,378 |  |  |  | 3,278 |  |
| Total cost of sales |  |  | 4,212 |  |  |  | 4,785 |  |  |  | 13,148 |  |  |  | 14,384 |  |
| GROSS MARGIN |  |  | 7,771 |  |  |  | 8,173 |  |  |  | 23,999 |  |  |  | 24,092 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,546 |  |  |  | 1,659 |  |  |  | 4,782 |  |  |  | 4,824 |  |
| Sales and marketing |  |  | 2,192 |  |  |  | 2,403 |  |  |  | 6,951 |  |  |  | 7,084 |  |
| General and administrative |  |  | 457 |  |  |  | 541 |  |  |  | 1,431 |  |  |  | 1,261 |  |
| Amortization of purchased intangible assets |  |  | 34 |  |  |  | 39 |  |  |  | 108 |  |  |  | 112 |  |
| Restructuring and other charges |  |  | 128 |  |  |  | 18 |  |  |  | 354 |  |  |  | 282 |  |
| Total operating expenses |  |  | 4,357 |  |  |  | 4,660 |  |  |  | 13,626 |  |  |  | 13,563 |  |
| OPERATING INCOME |  |  | 3,414 |  |  |  | 3,513 |  |  |  | 10,373 |  |  |  | 10,529 |  |
| Interest income |  |  | 218 |  |  |  | 331 |  |  |  | 733 |  |  |  | 1,003 |  |
| Interest expense |  |  | (130 | ) |  |  | (211 | ) |  |  | (466 | ) |  |  | (655 | ) |
| Other income (loss), net |  |  | (58 | ) |  |  | (18 | ) |  |  | 24 |  |  |  | (10 | ) |
| Interest and other income (loss), net |  |  | 30 |  |  |  | 102 |  |  |  | 291 |  |  |  | 338 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,444 |  |  |  | 3,615 |  |  |  | 10,664 |  |  |  | 10,867 |  |
| Provision for income taxes |  |  | 670 |  |  |  | 571 |  |  |  | 2,086 |  |  |  | 1,452 |  |
| NET INCOME |  | $ | 2,774 |  |  | $ | 3,044 |  |  | $ | 8,578 |  |  | $ | 9,415 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.66 |  |  | $ | 0.70 |  |  | $ | 2.02 |  |  | $ | 2.11 |  |
| Diluted |  | $ | 0.65 |  |  | $ | 0.69 |  |  | $ | 2.01 |  |  | $ | 2.09 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,230 |  |  |  | 4,370 |  |  |  | 4,239 |  |  |  | 4,468 |  |
| Diluted |  |  | 4,243 |  |  |  | 4,415 |  |  |  | 4,258 |  |  |  | 4,509 |  |

[0001193125-20-141598:8k_2_02:71]
The Consolidated Statements of Operations include the results of the divested Service Provider Video Software Solutions
(SPVSS) business for the nine months ended April 27, 2019.

[0001193125-20-141598:8k_2_02:72]
5

[0001193125-20-141598:8k_2_02:73]
CISCO SYSTEMS, INC.

[0001193125-20-141598:8k_2_02:74]
REVENUE BY SEGMENT

[0001193125-20-141598:8k_2_02:75]
(In
millions, except percentages)

[0001193125-20-141598:8k_2_02:76]
|  |  | April 25, 2020 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  |  |  |  |  |  |  |  |  |  | ExcludingSPVSSbusiness |  |  | IncludingSPVSSbusiness |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,116 |  |  |  | (8 | )% |  | $ | 22,106 |  |  |  | (3 | )% |  |  | (3 | )% |
| EMEA |  |  | 3,136 |  |  |  | (7 | )% |  |  | 9,553 |  |  |  | (2 | )% |  |  | (3 | )% |
| APJC |  |  | 1,730 |  |  |  | (9 | )% |  |  | 5,489 |  |  |  | (6 | )% |  |  | (7 | )% |
| Total |  | $ | 11,983 |  |  |  | (8 | )% |  | $ | 37,147 |  |  |  | (3 | )% |  |  | (3 | )% |

[0001193125-20-141598:8k_2_02:77]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-20-141598:8k_2_02:78]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. SPVSS business revenue for the nine
months ended April 27, 2019 was $168 million.

[0001193125-20-141598:8k_2_02:79]
CISCO SYSTEMS, INC.

[0001193125-20-141598:8k_2_02:80]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-20-141598:8k_2_02:81]
(In percentages)

[0001193125-20-141598:8k_2_02:82]
|  |  | April 25, 2020 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 67.8 | % |  |  | 67.1 | % |
| EMEA |  |  | 65.7 | % |  |  | 65.8 | % |
| APJC |  |  | 63.5 | % |  |  | 64.0 | % |

[0001193125-20-141598:8k_2_02:83]
6

[0001193125-20-141598:8k_2_02:84]
CISCO SYSTEMS, INC.

[0001193125-20-141598:8k_2_02:85]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-20-141598:8k_2_02:86]
(In millions, except percentages)

[0001193125-20-141598:8k_2_02:87]
|  |  | April 25, 2020 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  |  |  |  |  |  |  |  |  |  | ExcludingSPVSSbusiness |  |  | IncludingSPVSSbusiness |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 6,429 |  |  |  | (15 | )% |  | $ | 20,496 |  |  |  | (8 | )% |  |  | (8 | )% |
| Applications |  |  | 1,363 |  |  |  | (5 | )% |  |  | 4,211 |  |  |  | (2 | )% |  |  | (2 | )% |
| Security |  |  | 776 |  |  |  | 6 | % |  |  | 2,340 |  |  |  | 12 | % |  |  | 12 | % |
| Other Products |  |  | 28 |  |  |  | (27 | )% |  |  | 100 |  |  |  | 8 | % |  |  | (58 | )% |
| Total Product |  |  | 8,597 |  |  |  | (12 | )% |  |  | 27,146 |  |  |  | (6 | )% |  |  | (6 | )% |
| Services |  |  | 3,386 |  |  |  | 5 | % |  |  | 10,001 |  |  |  | 5 | % |  |  | 4 | % |
| Total |  | $ | 11,983 |  |  |  | (8 | )% |  | $ | 37,147 |  |  |  | (3 | )% |  |  | (3 | )% |

[0001193125-20-141598:8k_2_02:88]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-20-141598:8k_2_02:89]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. SPVSS business revenue for the nine
months ended April 27, 2019 was $168 million.

[0001193125-20-141598:8k_2_02:90]
7

[0001193125-20-141598:8k_2_02:91]
CISCO SYSTEMS, INC.

[0001193125-20-141598:8k_2_02:92]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-20-141598:8k_2_02:93]
(In millions)

[0001193125-20-141598:8k_2_02:94]
(Unaudited)

[0001193125-20-141598:8k_2_02:95]
|  |  | April 25, 2020 |  |  | July 27, 2019 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 10,366 |  |  | $ | 11,750 |  |
| Investments |  |  | 18,208 |  |  |  | 21,663 |  |
| Accounts receivable, net of allowance for doubtful accounts of $130 at April 25, 2020 and $136 at July 27, 2019 |  |  | 4,569 |  |  |  | 5,491 |  |
| Inventories |  |  | 1,212 |  |  |  | 1,383 |  |
| Financing receivables, net |  |  | 4,703 |  |  |  | 5,095 |  |
| Other current assets |  |  | 2,249 |  |  |  | 2,373 |  |
| Total current assets |  |  | 41,307 |  |  |  | 47,755 |  |
| Property and equipment, net |  |  | 2,535 |  |  |  | 2,789 |  |
| Financing receivables, net |  |  | 4,770 |  |  |  | 4,958 |  |
| Goodwill |  |  | 33,453 |  |  |  | 33,529 |  |
| Purchased intangible assets, net |  |  | 1,744 |  |  |  | 2,201 |  |
| Deferred tax assets |  |  | 3,909 |  |  |  | 4,065 |  |
| Other assets |  |  | 3,676 |  |  |  | 2,496 |  |
| TOTAL ASSETS |  | $ | 91,394 |  |  | $ | 97,793 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 4,506 |  |  | $ | 10,191 |  |
| Accounts payable |  |  | 2,393 |  |  |  | 2,059 |  |
| Income taxes payable |  |  | 1,047 |  |  |  | 1,149 |  |
| Accrued compensation |  |  | 2,940 |  |  |  | 3,221 |  |
| Deferred revenue |  |  | 10,710 |  |  |  | 10,668 |  |
| Other current liabilities |  |  | 4,341 |  |  |  | 4,424 |  |
| Total current liabilities |  |  | 25,937 |  |  |  | 31,712 |  |
| Long-term debt |  |  | 11,578 |  |  |  | 14,475 |  |
| Income taxes payable |  |  | 8,285 |  |  |  | 8,927 |  |
| Deferred revenue |  |  | 7,938 |  |  |  | 7,799 |  |
| Other long-term liabilities |  |  | 1,948 |  |  |  | 1,309 |  |
| Total liabilities |  |  | 55,686 |  |  |  | 64,222 |  |
| Total equity |  |  | 35,708 |  |  |  | 33,571 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 91,394 |  |  | $ | 97,793 |  |

[0001193125-20-141598:8k_2_02:96]
8

[0001193125-20-141598:8k_2_02:97]
CISCO SYSTEMS, INC.

[0001193125-20-141598:8k_2_02:98]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-20-141598:8k_2_02:99]
(In millions)

[0001193125-20-141598:8k_2_02:100]
(Unaudited)

[0001193125-20-141598:8k_2_02:101]
|  |  | Nine Months Ended |  |
|  |  | April 25,2020 |  |  | April 27,2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 8,578 |  |  | $ | 9,415 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,364 |  |  |  | 1,433 |  |
| Share-based compensation expense |  |  | 1,170 |  |  |  | 1,166 |  |
| Provision (benefit) for receivables |  |  | 60 |  |  |  | 32 |  |
| Deferred income taxes |  |  | 103 |  |  |  | (281 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (185 | ) |  |  | (79 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 774 |  |  |  | 1,560 |  |
| Inventories |  |  | 143 |  |  |  | (1 | ) |
| Financing receivables |  |  | 380 |  |  |  | (112 | ) |
| Other assets |  |  | 145 |  |  |  | (736 | ) |
| Accounts payable |  |  | 324 |  |  |  | 52 |  |
| Income taxes, net |  |  | (700 | ) |  |  | (759 | ) |
| Accrued compensation |  |  | (220 | ) |  |  | (68 | ) |
| Deferred revenue |  |  | 333 |  |  |  | 421 |  |
| Other liabilities |  |  | (645 | ) |  |  | (154 | ) |
| Net cash provided by operating activities |  |  | 11,624 |  |  |  | 11,889 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (6,880 | ) |  |  | (1,176 | ) |
| Proceeds from sales of investments |  |  | 4,737 |  |  |  | 5,391 |  |
| Proceeds from maturities of investments |  |  | 5,708 |  |  |  | 10,797 |  |
| Acquisitions and divestitures |  |  | (237 | ) |  |  | (2,175 | ) |
| Purchases of investments in privately held companies |  |  | (143 | ) |  |  | (118 | ) |
| Return of investments in privately held companies |  |  | 213 |  |  |  | 127 |  |
| Acquisition of property and equipment |  |  | (562 | ) |  |  | (701 | ) |
| Proceeds from sales of property and equipment |  |  | 175 |  |  |  | 15 |  |
| Other |  |  | (10 | ) |  |  | (12 | ) |
| Net cash provided by investing activities |  |  | 3,001 |  |  |  | 12,148 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 335 |  |  |  | 321 |  |
| Repurchases of common stock - repurchase program |  |  | (2,659 | ) |  |  | (16,042 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (519 | ) |  |  | (601 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | (3,470 | ) |  |  | 1,723 |  |
| Issuances of debt |  |  | — |  |  |  | 1,530 |  |
| Repayments of debt |  |  | (5,220 | ) |  |  | (5,250 | ) |
| Dividends paid |  |  | (4,491 | ) |  |  | (4,489 | ) |
| Other |  |  | (3 | ) |  |  | 51 |  |
| Net cash used in financing activities |  |  | (16,027 | ) |  |  | (22,757 | ) |
| Net increase (decrease) in cash, cash equivalents, and restricted cash |  |  | (1,402 | ) |  |  | 1,280 |  |
| Cash, cash equivalents, and restricted cash, beginning of period |  |  | 11,772 |  |  |  | 8,993 |  |
| Cash, cash equivalents, and restricted cash, end of period |  | $ | 10,370 |  |  | $ | 10,273 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 519 |  |  | $ | 707 |  |
| Cash paid for income taxes, net |  | $ | 2,683 |  |  | $ | 2,491 |  |

[0001193125-20-141598:8k_2_02:102]
9

[0001193125-20-141598:8k_2_02:103]
CISCO SYSTEMS, INC.

[0001193125-20-141598:8k_2_02:104]
DEFERRED REVENUE

[0001193125-20-141598:8k_2_02:105]
(In
millions)

[0001193125-20-141598:8k_2_02:106]
|  |  | April 25,2020 |  |  | January 25,2020 |  |  | April 27,2019 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 11,423 |  |  | $ | 11,526 |  |  | $ | 11,297 |  |
| Product |  |  | 7,225 |  |  |  | 7,160 |  |  |  | 6,159 |  |
| Total |  | $ | 18,648 |  |  | $ | 18,686 |  |  | $ | 17,456 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 10,710 |  |  | $ | 10,638 |  |  | $ | 10,117 |  |
| Noncurrent |  |  | 7,938 |  |  |  | 8,048 |  |  |  | 7,339 |  |
| Total |  | $ | 18,648 |  |  | $ | 18,686 |  |  | $ | 17,456 |  |

[0001193125-20-141598:8k_2_02:107]
CISCO SYSTEMS, INC.

[0001193125-20-141598:8k_2_02:108]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-20-141598:8k_2_02:109]
(In millions, except per-share amounts)

[0001193125-20-141598:8k_2_02:110]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| April 25, 2020 |  | $ | 0.36 |  |  | $ | 1,519 |  |  |  | 25 |  |  | $ | 39.71 |  |  | $ | 981 |  |  | $ | 2,500 |  |
| January 25, 2020 |  | $ | 0.35 |  |  | $ | 1,486 |  |  |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |  | $ | 2,356 |  |
| October 26, 2019 |  | $ | 0.35 |  |  | $ | 1,486 |  |  |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |  | $ | 2,254 |  |
| Fiscal 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 27, 2019 |  | $ | 0.35 |  |  | $ | 1,490 |  |  |  | 82 |  |  | $ | 54.99 |  |  | $ | 4,515 |  |  | $ | 6,005 |  |
| April 27, 2019 |  | $ | 0.35 |  |  | $ | 1,519 |  |  |  | 116 |  |  | $ | 52.14 |  |  | $ | 6,020 |  |  | $ | 7,539 |  |
| January 26, 2019 |  | $ | 0.33 |  |  | $ | 1,470 |  |  |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |  | $ | 6,486 |  |
| October 27, 2018 |  | $ | 0.33 |  |  | $ | 1,500 |  |  |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |  | $ | 6,526 |  |

[0001193125-20-141598:8k_2_02:111]
CISCO SYSTEMS, INC.

[0001193125-20-141598:8k_2_02:112]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-20-141598:8k_2_02:113]
GAAP TO NON-GAAP NET INCOME

[0001193125-20-141598:8k_2_02:114]
(In millions)

[0001193125-20-141598:8k_2_02:115]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 25,2020 |  |  | April 27,2019 |  |  | April 25,2020 |  |  | April 27,2019 |  |
| GAAP net income |  | $ | 2,774 |  |  | $ | 3,044 |  |  | $ | 8,578 |  |  | $ | 9,415 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 60 |  |  |  | 54 |  |  |  | 176 |  |  |  | 163 |  |
| Amortization of acquisition-related intangible assets |  |  | 154 |  |  |  | 141 |  |  |  | 454 |  |  |  | 418 |  |
| Supplier component remediation charge (adjustment), net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1 | ) |
| Acquisition-related/divestiture costs |  |  | 1 |  |  |  | 2 |  |  |  | 3 |  |  |  | 9 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | 4 |  |  |  | 5 |  |
| Total adjustments to GAAP cost of sales |  |  | 215 |  |  |  | 197 |  |  |  | 637 |  |  |  | 594 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 322 |  |  |  | 322 |  |  |  | 975 |  |  |  | 974 |  |
| Amortization of acquisition-related intangible assets |  |  | 34 |  |  |  | 39 |  |  |  | 108 |  |  |  | 112 |  |
| Acquisition-related/divestiture costs |  |  | 66 |  |  |  | 78 |  |  |  | 191 |  |  |  | 238 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | (396 | ) |
| Significant asset impairments and restructurings |  |  | 128 |  |  |  | 18 |  |  |  | 354 |  |  |  | 282 |  |
| Total adjustments to GAAP operating expenses |  |  | 550 |  |  |  | 456 |  |  |  | 1,628 |  |  |  | 1,210 |  |
| Adjustments to GAAP interest and other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | 1 |  |  |  | (4 | ) |  |  | (99 | ) |  |  | (77 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 766 |  |  |  | 649 |  |  |  | 2,166 |  |  |  | 1,727 |  |
| Income tax effect of non-GAAP adjustments |  |  | (172 | ) |  |  | (160 | ) |  |  | (547 | ) |  |  | (554 | ) |
| Significant tax matters |  |  | — |  |  |  | (79 | ) |  |  | 67 |  |  |  | (387 | ) |
| Total adjustments to GAAP provision for income taxes |  |  | (172 | ) |  |  | (239 | ) |  |  | (480 | ) |  |  | (941 | ) |
| Non-GAAP net income |  | $ | 3,368 |  |  | $ | 3,454 |  |  | $ | 10,264 |  |  | $ | 10,201 |  |

[0001193125-20-141598:8k_2_02:116]
11

[0001193125-20-141598:8k_2_02:117]
CISCO SYSTEMS, INC.

[0001193125-20-141598:8k_2_02:118]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-20-141598:8k_2_02:119]
GAAP TO NON-GAAP EPS

[0001193125-20-141598:8k_2_02:120]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 25,2020 |  |  | April 27,2019 |  |  | April 25,2020 |  |  | April 27,2019 |  |
| GAAP EPS |  | $ | 0.65 |  |  | $ | 0.69 |  |  | $ | 2.01 |  |  | $ | 2.09 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.09 |  |  |  | 0.09 |  |  |  | 0.27 |  |  |  | 0.25 |  |
| Amortization of acquisition-related intangible assets |  |  | 0.04 |  |  |  | 0.04 |  |  |  | 0.13 |  |  |  | 0.12 |  |
| Acquisition-related/divestiture costs |  |  | 0.02 |  |  |  | 0.02 |  |  |  | 0.05 |  |  |  | 0.05 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.09 | ) |
| Significant asset impairments and restructurings |  |  | 0.03 |  |  |  | — |  |  |  | 0.08 |  |  |  | 0.06 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | (0.02 | ) |  |  | (0.02 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.04 | ) |  |  | (0.04 | ) |  |  | (0.13 | ) |  |  | (0.12 | ) |
| Significant tax matters |  |  | — |  |  |  | (0.02 | ) |  |  | 0.02 |  |  |  | (0.09 | ) |
| Non-GAAP EPS |  | $ | 0.79 |  |  | $ | 0.78 |  |  | $ | 2.41 |  |  | $ | 2.26 |  |

[0001193125-20-141598:8k_2_02:121]
Amounts may not sum due to rounding.

[0001193125-20-141598:8k_2_02:122]
12

[0001193125-20-141598:8k_2_02:123]
CISCO SYSTEMS, INC.

[0001193125-20-141598:8k_2_02:124]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-20-141598:8k_2_02:125]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-20-141598:8k_2_02:126]
(In millions, except percentages)

[0001193125-20-141598:8k_2_02:127]
|  |  | Three Months Ended |  |
|  |  | April 25, 2020 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,477 |  |  | $ | 2,294 |  |  | $ | 7,771 |  |  | $ | 4,357 |  |  |  | (6 | )% |  | $ | 3,414 |  |  |  | (3 | )% |  | $ | 30 |  |  |  | (71 | )% |  | $ | 2,774 |  |  |  | (9 | )% |
| % of revenue |  |  | 63.7 | % |  |  | 67.7 | % |  |  | 64.9 | % |  |  | 36.4 | % |  |  |  |  |  |  | 28.5 | % |  |  |  |  |  |  | 0.3 | % |  |  |  |  |  |  | 23.1 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 23 |  |  |  | 37 |  |  |  | 60 |  |  |  | 322 |  |  |  |  |  |  |  | 382 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 382 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 154 |  |  |  | — |  |  |  | 154 |  |  |  | 34 |  |  |  |  |  |  |  | 188 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 188 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 66 |  |  |  |  |  |  |  | 67 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 67 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 128 |  |  |  |  |  |  |  | 128 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 128 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  | 1 |  |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (172 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 5,654 |  |  | $ | 2,332 |  |  | $ | 7,986 |  |  | $ | 3,807 |  |  |  | (9 | )% |  | $ | 4,179 |  |  |  | — | % |  | $ | 31 |  |  |  | (68 | )% |  | $ | 3,368 |  |  |  | (2 | )% |
| % of revenue |  |  | 65.8 | % |  |  | 68.9 | % |  |  | 66.6 | % |  |  | 31.8 | % |  |  |  |  |  |  | 34.9 | % |  |  |  |  |  |  | 0.3 | % |  |  |  |  |  |  | 28.1 | % |  |  |  |  |

[0001193125-20-141598:8k_2_02:128]
|  |  | Three Months Ended |  |
|  |  | April 27, 2019 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 6,029 |  |  | $ | 2,144 |  |  | $ | 8,173 |  |  | $ | 4,660 |  |  | $ | 3,513 |  |  | $ | 102 |  |  | $ | 3,044 |  |
| % of revenue |  |  | 62.0 | % |  |  | 66.3 | % |  |  | 63.1 | % |  |  | 36.0 | % |  |  | 27.1 | % |  |  | 0.8 | % |  |  | 23.5 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 22 |  |  |  | 32 |  |  |  | 54 |  |  |  | 322 |  |  |  | 376 |  |  |  | — |  |  |  | 376 |  |
| Amortization of acquisition-related intangible assets |  |  | 141 |  |  |  | — |  |  |  | 141 |  |  |  | 39 |  |  |  | 180 |  |  |  | — |  |  |  | 180 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | 1 |  |  |  | 2 |  |  |  | 78 |  |  |  | 80 |  |  |  | — |  |  |  | 80 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 18 |  |  |  | 18 |  |  |  | — |  |  |  | 18 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (4 | ) |  |  | (4 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (239 | ) |
| Non-GAAP amount |  | $ | 6,193 |  |  | $ | 2,177 |  |  | $ | 8,370 |  |  | $ | 4,204 |  |  | $ | 4,166 |  |  | $ | 98 |  |  | $ | 3,454 |  |
| % of revenue |  |  | 63.7 | % |  |  | 67.3 | % |  |  | 64.6 | % |  |  | 32.4 | % |  |  | 32.2 | % |  |  | 0.8 | % |  |  | 26.7 | % |

[0001193125-20-141598:8k_2_02:129]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-20-141598:8k_2_02:130]
13

[0001193125-20-141598:8k_2_02:131]
CISCO SYSTEMS, INC.

[0001193125-20-141598:8k_2_02:132]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-20-141598:8k_2_02:133]
EFFECTIVE TAX RATE

[0001193125-20-141598:8k_2_02:134]
(In
percentages)

[0001193125-20-141598:8k_2_02:135]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 25,2020 |  |  | April 27,2019 |  |  | April 25,2020 |  |  | April 27,2019 |  |
| GAAP effective tax rate |  |  | 19.4 | % |  |  | 15.8 | % |  |  | 19.6 | % |  |  | 13.4 | % |
| Total adjustments to GAAP provision for income taxes |  |  | 0.6 | % |  |  | 3.2 | % |  |  | 0.4 | % |  |  | 5.6 | % |
| Non-GAAP effective tax rate |  |  | 20.0 | % |  |  | 19.0 | % |  |  | 20.0 | % |  |  | 19.0 | % |

[0001193125-20-141598:8k_2_02:136]
GAAP TO NON-GAAP GUIDANCE FOR Q4 FY 2020

[0001193125-20-141598:8k_2_02:137]
| Q4 FY 2020 |  | Gross MarginRate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (1) |
| GAAP |  | 62% - 63% |  | 25.5% - 26.5% |  | 19% |  | $0.57 - $0.62 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.5% |  | — |  | $0.07 - $0.08 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 1.5% |  | 2.0% |  | — |  | $0.04 - $0.05 |
| Significant asset impairments and restructurings |  | — |  | 0.5% |  | — |  | $0.01 - $0.02 |
| Income tax effect of non-GAAP adjustments |  |  |  |  |  | 1% |  |  |
| Non-GAAP |  | 64% - 65% |  | 31.5% - 32.5% |  | 20% |  | $0.72 - $0.74 |

[0001193125-20-141598:8k_2_02:138]
| (1) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-20-141598:8k_2_02:139]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and significant
tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-20-141598:8k_2_02:140]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-20-141598:8k_2_02:141]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax rates,
non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross
margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-20-141598:8k_2_02:142]
These
non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles and may be different from
non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes
that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should
only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-20-141598:8k_2_02:143]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition
and its historical and projected results of operations.

[0001193125-20-141598:8k_2_02:144]
For its internal budgeting process, Cisco’s management uses financial statements that do not
include, when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other
contingencies, gains and losses on equity investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the
corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time
to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-20-141598:8k_2_02:145]
15

[0001193125-20-141598:8k_2_02:146]
Cisco divested its Service Provider Video Software Solutions business (SPVSS) during the second quarter of
fiscal 2019 on October 28, 2018. This release includes, where indicated, financial measures that exclude the SPVSS business. Cisco believes that the presentation of these measures provides useful information to investors and management
regarding financial and business trends relating to its financial condition and its historical and projected results of operations because the SPVSS business will not be part of Cisco on a go forward basis. Cisco’s management also uses the
financial measures excluding the SPVSS business in reviewing the financial results of Cisco.

[0001193125-20-141598:8k_2_02:147]
About Cisco

[0001193125-20-141598:8k_2_02:148]
Cisco (Nasdaq: CSCO) is the worldwide technology leader that has been making the Internet work since 1984. Our people, products and partners help society
securely connect and seize tomorrow’s digital opportunity today. Discover more at newsroom.cisco.com and follow us on Twitter at @Cisco.

[0001193125-20-141598:8k_2_02:149]
Copyright © 2020 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a
list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any
other company. This document is Cisco Public Information.

[0001193125-20-141598:8k_2_02:150]
RSS Feed for
Cisco: https://newsroom.cisco.com/rss-feeds

[0001193125-20-141598:8k_2_02:151]
16
