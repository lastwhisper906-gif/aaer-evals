# CSCO note change history — 0000858877-20-000004 → 0000858877-20-000006


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-18):
[0000858877-20-000006:note_history:1]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of April 25, 2020 and July 27, 2019, we had total purchase commitments for inventory of $5.1 billion and $5.0 billion, respectively.
  (was, 2020-02-18, similarity 0.7867):
[0000858877-20-000004:note_history:1]
based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of January 25, 2020 and July 27, 2019, we had total purchase commitments for inventory of $4.5 billion and $5.0 billion, respectively.

- changed (2020-05-18):
[0000858877-20-000006:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 25, 2020 and July 27, 2019, the liability for these purchase commitments was $131 million and $129 million, respectively, and was included in other current liabilities.
  (was, 2020-02-18, similarity 0.6941):
[0000858877-20-000004:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 25, 2020 and July 27, 2019, the liability for these purchase commitments was $126 million and $129 million, respectively, and was included in other current liabilities.

- changed (2020-05-18):
[0000858877-20-000006:note_history:3]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Compensation expense related to acquisitions | $ | 61 |  |  | $ | 76 |  |  | $ | 172 |  |  | $ | 251 |  |
  (was, 2020-02-18, similarity 0.7309):
[0000858877-20-000004:note_history:3]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Compensation expense related to acquisitions | $ | 50 |  |  | $ | 66 |  |  | $ | 111 |  |  | $ | 175 |  |

- changed (2020-05-18):
[0000858877-20-000006:note_history:4]
As of April 25, 2020, we estimated that future cash compensation expense of up to $292 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2020-02-18, similarity 0.9778):
[0000858877-20-000004:note_history:4]
As of January 25, 2020, we estimated that future cash compensation expense of up to $370 million may be required to be recognized pursuant to the applicable business combination agreements.

- changed (2020-05-18):
[0000858877-20-000006:note_history:5]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $344 million and $326 million as of April 25, 2020 and July 27, 2019, respectively.
  (was, 2020-02-18, similarity 0.9213):
[0000858877-20-000004:note_history:5]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $291 million and $326 million as of January 25, 2020 and July 27, 2019, respectively.

- changed (2020-05-18):
[0000858877-20-000006:note_history:6]
|  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |
| Balance at beginning of period | $ | 342 |  |  | $ | 359 |  |
| Provisions for warranties issued | 423 |  |  | 447 |  |
| Adjustments for pre-existing warranties | (5 | ) |  | (6 | ) |
| Settlements | (436 | ) |  | (449 | ) |
| Acquisitions and divestitures | — |  |  | (2 | ) |
| Balance at end of period | $ | 324 |  |  | $ | 349 |  |
  (was, 2020-02-18, similarity 0.9328):
[0000858877-20-000004:note_history:6]
|  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |
| Balance at beginning of period | $ | 342 |  |  | $ | 359 |  |
| Provisions for warranties issued | 283 |  |  | 297 |  |
| Adjustments for pre-existing warranties | (3 | ) |  | (5 | ) |
| Settlements | (291 | ) |  | (300 | ) |
| Acquisitions and divestitures | — |  |  | (2 | ) |
| Balance at end of period | $ | 331 |  |  | $ | 349 |  |

- added (2020-05-18):
[0000858877-20-000006:note_history:7]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. At the end of the third quarter of fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic environment. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.3 billion and $7.2 billion for the third quarter of fiscal 2020 and 2019, respectively, and was $20.5 billion and $21.7 billion for the first nine months of fiscal 2020 and 2019, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.4 billion as of April 25, 2020 and July 27, 2019, respectively.

- changed (2020-05-18):
[0000858877-20-000006:note_history:8]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $2 million and $1 million for the third quarter of fiscal 2020 and 2019, respectively, and was $8 million and $11 million for the first nine months of fiscal 2020 and 2019, respectively.
  (was, 2020-02-18, similarity 0.984):
[0000858877-20-000004:note_history:8]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $1 million and $6 million for the second quarter of fiscal 2020 and 2019, respectively, and was $6 million and $9 million for the first six months of fiscal 2020 and 2019, respectively.

- changed (2020-05-18):
[0000858877-20-000006:note_history:9]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 25, 2020 and July 27, 2019, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2020-02-18, similarity 0.9807):
[0000858877-20-000004:note_history:9]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 25, 2020 and July 27, 2019, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- added (2020-05-18):
[0000858877-20-000006:note_history:10]
|  | April 25, 2020 |  | July 27, 2019 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 203 |  |  | $ | 197 |  |
| End user | 12 |  |  | 21 |  |
| Total | $ | 215 |  |  | $ | 218 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (59 | ) |  | $ | (62 | ) |
| End user | (11 | ) |  | (15 | ) |
| Total | $ | (70 | ) |  | $ | (77 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 145 |  |  | $ | 141 |  |

- changed (2020-05-18):
[0000858877-20-000006:note_history:11]
Charter Communications, Inc. (“Charter”), which acquired Time Warner Cable (“TWC”) in May 2016, is seeking indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Sprint sought monetary damages, alleging that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. The Court awarded Sprint pre and post judgment interest of approximately $10 million and denied TWC’s post-trial motions and appeals. Charter reported that it paid the judgment in full. At this time, we are working with Charter to calculate the correct amount of indemnification. We do not believe that our indemnity obligations under our agreement will be material.
  (was, 2020-02-18, similarity 0.999):
[0000858877-20-000004:note_history:11]
Charter Communications, Inc. (“Charter”), which acquired Time Warner Cable (“TWC”) in May 2016, is seeking indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Sprint sought monetary damages, alleging that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. The Court awarded Sprint pre and post judgment interest of approximately $10 million and denied TWC's post-trial motions and appeals. Charter reported that it paid the judgment in full. At this time, we are working with Charter to calculate the correct amount of indemnification. We do not believe that our indemnity obligations under our agreement will be material.

- added (2020-05-18):
[0000858877-20-000006:note_history:12]
We also have been asked to indemnify certain of our service provider customers that have been subject to patent infringement claims asserted by Chanbond, LLC (“Chanbond”) in the United States District Court for the District of Delaware on September 21, 2015. Chanbond alleges that 13 service provider companies, including among others, Comcast Corporation (“Comcast”), Charter Communications, Inc. (“Charter”), Time Warner Cable, Inc. (“TWC”) (subsequently acquired by Charter), Cox Communications, Inc. (“Cox”), and Cablevision Systems Corporation (“Cablevision”), infringe three patents by providing high speed cable internet services to their customers utilizing cable modems and cable modem termination systems, consistent with the DOCSIS 3.0 standard, provided by us and other manufacturers generally used in combination with each other. Chanbond seeks monetary damages. Chanbond's case against Cox is currently set for a jury trial starting on August 18, 2020, and the other cases against the remaining service provider defendants have not yet been set for trial. We believe that the service provider defendants have strong non-infringement, invalidity and other defenses. Due to uncertainties surrounding the litigation processes, we are unable to reasonably estimate the ultimate outcome of the cases at this time, but should Chanbond prevail in its cases against the service provider defendants, we do not believe that any potential indemnity liability would be material.

- changed (2020-05-18):
[0000858877-20-000006:note_history:13]
During the second quarter of fiscal 2020, $0.8 billion of penalty and interest asserted by the Brazilian federal tax authorities against our Brazilian subsidiary on the theory of joint liability was dismissed on its merits. The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total remaining asserted claims by Brazilian state and federal tax authorities aggregate to $0.1 billion for the alleged evasion of import and other taxes, $0.7 billion for interest, and $0.4 billion for various penalties, all determined using an exchange rate as of April 25, 2020.
  (was, 2020-02-18, similarity 0.9859):
[0000858877-20-000004:note_history:13]
During the second quarter of fiscal 2020, $0.8 billion of penalty and interest asserted by the Brazilian federal tax authorities against our Brazilian subsidiary on the theory of joint liability was dismissed on its merits. The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total remaining asserted claims by Brazilian state and federal tax authorities aggregate to $0.2 billion for the alleged evasion of import and other taxes, $0.9 billion for interest, and $0.5 billion for various penalties, all determined using an exchange rate as of January 25, 2020.

- changed (2020-05-18):
[0000858877-20-000006:note_history:14]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial started on May 2, 2016, and, on May 12, 2016, the jury returned a verdict finding willful infringement. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the District Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit on various grounds, and after various proceedings, on July 12, 2019, the Federal Circuit vacated the enhanced damages award; vacated and remanded in part the willful infringement finding; vacated and remanded the attorneys’ fees award for further proceedings; and affirmed the District Court’s other findings. On April 1, 2020, the District Court issued a final judgment on the remanded issues, finding no evidence of willful infringement and reinstating the $8 million award of attorneys’ fees. SRI appealed the judgment of no willful infringement to the Federal Circuit on April 3, 2020, and Cisco filed a cross-appeal on the attorneys’ fees award on April 9, 2020. Cisco has paid SRI $28.1 million, representing the portion of the judgment that the Federal Circuit previously affirmed, plus interest and royalties on post-verdict sales. While the remaining proceedings may result in an additional loss, we do not expect it to be material.
  (was, 2020-02-18, similarity 0.6837):
[0000858877-20-000004:note_history:14]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and, on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit on various grounds, a panel of which, after various proceedings, on July 12, 2019, issued an opinion vacating the enhanced damages award; vacating and remanding in part the willful infringement finding; vacating and remanding the attorneys’ fees award for further proceedings; and affirming the district court's other findings. Cisco paid SRI $28.1 million, representing the portion of the judgment that the Federal Circuit affirmed, plus interest and royalties on post-verdict sales. This payment is subject to a refund if any portion of the affirmed judgment is reversed or vacated by the U.S. Supreme Court. On November 8, 2019, Cisco filed a petition for a writ of certiorari with the U.S. Supreme Court, seeking review of the judgment on the grounds that the asserted patents describe patent-ineligible subject matter. While the remanded proceedings may result in an additional loss, we do not expect it to be material.

- added (2020-05-18):
[0000858877-20-000006:note_history:15]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Centripetal alleges that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has thus far issued Final Written Decisions for five patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and a portion of the claims of a sixth patent have been found unpatentable. The District Court set a bench trial by videoconference, which started on May 6, 2020, on the claims in the five patents not subject to the IPR Proceedings, including claims in three for which the PTAB declined to institute Inter Partes Review. While we believe that we have strong non-infringement defenses and that the patents are invalid, as well as other arguments and defenses, if we do not prevail in the District Court, we believe that Centripetal will not be able to meet its burden required for injunctive relief and that any final damages ultimately assessed would not be material. On May 4, 2020, Centripetal instituted an action in the District Court of Dusseldorf in Germany against Cisco Systems GmbH asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two patents Centripetal has asserted against us in the U.S. District Court proceedings, one of which has been invalidated by the PTAB. We are currently assessing the case filed in Germany. Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of this litigation at this time.

- changed (2020-05-18):
[0000858877-20-000006:note_history:16]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the District Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path’s claims against us and cancelling a trial which had been set for March 12, 2018. Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit, and, on January 23, 2019, the District Court summarily affirmed the finding of non-infringement. On August 23, 2019, Straight Path filed a petition with the United States Supreme Court challenging the constitutionality of the Federal Circuit’s rule allowing summary affirmance, which was denied on November 18, 2019.
  (was, 2020-02-18, similarity 0.8879):
[0000858877-20-000004:note_history:16]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against us and cancelling a trial which had been set for March 12, 2018. Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit, and, on January 23, 2019, the court summarily affirmed the finding of non-infringement. On August 23,

- added (2020-05-18):
[0000858877-20-000006:note_history:17]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the District Court consolidated the cases alleging infringement of the ‘327 Patent. Oyster's cases against some of the defendants were resolved. The District Court vacated the November 4, 2018 trial date set for Oyster's claims against Cisco and one other remaining defendant, pending resolution of Oyster’s December 6, 2018 appeal of the District Court's summary judgment ruling dismissing certain of Oyster’s claims. On May 8, 2020, the Federal Circuit affirmed the District Court’s summary judgment ruling. While we

- added (2020-05-18):
[0000858877-20-000006:note_history:18]
believe that the District Court's summary judgment ruling will continue to be upheld if subject to further challenge and we have strong defenses for Oyster's remaining claims, if Oyster seeks further review of the District Court's summary judgment ruling and it is reversed and the dismissed claims are remanded, and if we do not prevail in the District Court on those claims and Oyster's remaining claims in a subsequent trial, we believe damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, we are unable to reasonably estimate the ultimate outcome of this litigation at this time.

- added (2020-05-18):
[0000858877-20-000006:note_history:19]
Finjan     On January 6, 2017, Finjan, Inc. (“Finjan”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Finjan alleges that Cisco’s AMP and ThreatGrid products and the URL rewrite feature of Cisco’s ESA Outbreak Filter product infringe five patents, four of which have expired. Finjan has conceded that they are not entitled to any pre-suit damages, accordingly it seeks approximately three weeks of damages for the alleged infringement of the 8,677,494 and 6,154,844 patents, approximately ten months of damages for the 6,804,780 patent, approximately three years of damages for the 7,647,633 patent, and approximately three-and-a-half years of past damages for the 8,141,154 patent and an ongoing royalty until its expiration on December 12, 2025. The case is currently set for jury trial starting June 22, 2020. While we believe that we have strong non-infringement arguments, that the patents are invalid, that Finjan’s damages theories are not supported by prevailing law and that Finjan will not be able to meet its burden required for injunctive relief, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.

- removed (2020-05-18):
[0000858877-20-000004:note_history:20]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory

- removed (2020-05-18):
[0000858877-20-000004:note_history:21]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.6 billion and $7.3 billion for the second quarter of fiscal

- removed (2020-05-18):
[0000858877-20-000004:note_history:22]
2020 and 2019, respectively, and was $14.2 billion and $14.5 billion for the first six months of fiscal 2020 and 2019, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.4 billion as of January 25, 2020 and July 27, 2019, respectively.

- removed (2020-05-18):
[0000858877-20-000004:note_history:23]
|  | January 25, 2020 |  | July 27, 2019 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 258 |  |  | $ | 197 |  |
| End user | 13 |  |  | 21 |  |
| Total | $ | 271 |  |  | $ | 218 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (69 | ) |  | $ | (62 | ) |
| End user | (13 | ) |  | (15 | ) |
| Total | $ | (82 | ) |  | $ | (77 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 189 |  |  | $ | 141 |  |

- removed (2020-05-18):
[0000858877-20-000004:note_history:24]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Centripetal alleges that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has thus far issued Final Written Decisions for four patents in the instituted IPR Proceedings, and all claims of three patents have been found unpatentable and a portion of the claims of a fourth patent have been found unpatentable. The court set a trial for April 7, 2020, on the claims in the five patents not subject to the IPR Proceedings, including claims in three for which the PTAB declined to institute Inter Partes Review. While we believe that we have strong non-infringement arguments and that the patents are invalid, as well as other defenses, if we do not prevail in the District Court, we believe that Centripetal will not be able to meet its burden required for injunctive relief and that any damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, however, we are unable to reasonably estimate the ultimate monetary outcome of this litigation at this time.

- removed (2020-05-18):
[0000858877-20-000004:note_history:25]
2019, Straight Path filed a petition with the United States Supreme Court challenging the constitutionality of the Federal Circuit’s rule allowing summary affirmance, which was denied on November 18, 2019.

- removed (2020-05-18):
[0000858877-20-000004:note_history:26]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the court consolidated the cases alleging infringement of the ‘327 Patent. Oyster's cases against some of the defendants were resolved. The court vacated the November 4, 2018 trial date set for Oyster's claims against Cisco and one other remaining defendant, pending resolution of Oyster's appeal of the court's summary judgment ruling dismissing certain of Oyster's claims. Oyster appealed the summary judgment ruling on December 6, 2018. While we believe that we have strong non-infringement arguments and that the patent is invalid, if Oyster prevails in its appeal of the summary judgment ruling, and if we do not prevail in the District Court in a subsequent trial, we believe damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, we are unable to reasonably estimate the ultimate outcome of this litigation at this time. However, we do not anticipate that any final outcome of the dispute would be material.
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-18):
[0000858877-20-000006:note_history:27]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.
  (was, 2020-02-18, similarity 0.9996):
[0000858877-20-000004:note_history:27]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory 
based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-18):
[0000858877-20-000006:note_history:28]
We have prepared the accompanying financial data as of April 25, 2020 and for the third quarter and first nine months of fiscal 2020 and 2019, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2019 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2019.
  (was, 2020-02-18, similarity 0.9862):
[0000858877-20-000004:note_history:28]
We have prepared the accompanying financial data as of January 25, 2020 and for the second quarter and first six months of fiscal 2020 and 2019, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2019 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2019.

- added (2020-05-18):
[0000858877-20-000006:note_history:29]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues to develop, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

- changed (2020-05-18):
[0000858877-20-000006:note_history:30]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of April 25, 2020, the results of operations, the statements of comprehensive income (loss) and the statements of equity for the third quarter and first nine months of fiscal 2020 and 2019; and the statements of cash flows for the first nine months of fiscal 2020 and 2019, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2020 are not necessarily indicative of the operating results for the full fiscal year or any future periods.
  (was, 2020-02-18, similarity 0.9573):
[0000858877-20-000004:note_history:30]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 25, 2020, the results of operations, the statements of comprehensive income (loss) and the statements of equity for the second quarter and first six months of fiscal 2020 and 2019; and the statements of cash flows for the first six months of fiscal 2020 and 2019, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2020 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-18):
[0000858877-20-000006:note_history:31]
We have elected to apply the package of practical expedients permitted under the transition guidance within ASC 842 which does not require reassessment of initial direct costs, classification of a lease and definition of a lease. We also elected additional practical
  (was, 2020-02-18, similarity 0.6431):
[0000858877-20-000004:note_history:31]
We have elected to apply the package of practical expedients permitted under the transition guidance within ASC 842 which does not require reassessment of initial direct costs, classification of a lease and definition of a lease. We also elected additional practical expedients which resulted in: i) allowing us not to reassess the accounting treatment for existing or expired land easements in transition; ii) combining lease and non-lease components and iii) not recording leases with an initial term of less than 12 months on our Consolidated Balance Sheet.

- added (2020-05-18):
[0000858877-20-000006:note_history:32]
expedients which resulted in: i) allowing us not to reassess the accounting treatment for existing or expired land easements in transition; ii) combining lease and non-lease components and iii) not recording leases with an initial term of less than 12 months on our Consolidated Balance Sheet.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-18):
[0000858877-20-000006:note_history:33]
|  | April 25, 2020 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,506 |  |  | 2.32 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 4,506 |  |  |  |  | $ | 10,191 |  |  |  |
  (was, 2020-02-18, similarity 0.9786):
[0000858877-20-000004:note_history:33]
|  | January 25, 2020 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,499 |  |  | 2.54 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 1,499 |  |  |  |  | $ | 10,191 |  |  |  |

- changed (2020-05-18):
[0000858877-20-000006:note_history:34]
|  |  |  | April 25, 2020 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | — |  |  | — |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.76% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.85% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.87% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.01% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 16,000 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (90 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 174 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 16,084 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,506 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 11,578 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 16,084 |  |  |  |  | $ | 20,473 |  |  |  |
  (was, 2020-02-18, similarity 0.996):
[0000858877-20-000004:note_history:34]
|  |  |  | January 25, 2020 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | — |  |  | — |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.51% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.71% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.63% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.88% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 16,000 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (94 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 87 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 15,993 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,499 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 14,494 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 15,993 |  |  |  |  | $ | 20,473 |  |  |  |

- changed (2020-05-18):
[0000858877-20-000006:note_history:35]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 25, 2020, we were in compliance with all debt covenants.
  (was, 2020-02-18, similarity 0.9863):
[0000858877-20-000004:note_history:35]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 25, 2020, we were in compliance with all debt covenants.

- changed (2020-05-18):
[0000858877-20-000006:note_history:36]
As of April 25, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2020-02-18, similarity 0.9701):
[0000858877-20-000004:note_history:36]
As of January 25, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2020-05-18):
[0000858877-20-000006:note_history:37]
| Fiscal Year | Amount |
| 2020 (remaining three months) | $ | 1,500 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 16,000 |  |
  (was, 2020-02-18, similarity 0.9739):
[0000858877-20-000004:note_history:37]
| Fiscal Year | Amount |
| 2020 (remaining six months) | $ | 1,500 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 16,000 |  |

- changed (2020-05-18):
[0000858877-20-000006:note_history:38]
On May 15, 2020, we entered into a 364-day credit agreement with certain institutional lenders that provides for a $2.75 billion unsecured revolving credit facility that is scheduled to expire on May 14, 2021. The credit agreement is structured as an amendment and restatement of our five-year credit facility which would have terminated on May 15, 2020, the end of its five-year term. As of April 25, 2020, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the five-year credit facility. 
Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than 0.25%. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.
  (was, 2020-02-18, similarity 0.7854):
[0000858877-20-000004:note_history:38]
On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.

- removed (2020-05-18):
[0000858877-20-000004:note_history:39]
This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of January 25, 2020, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under this credit facility.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-18):
[0000858877-20-000006:note_history:40]
|  | April 25, 2020 |  | July 27, 2019 |
| Available-for-sale debt investments | $ | 18,208 |  |  | $ | 21,660 |  |
| Marketable equity securities | — |  |  | 3 |  |
| Total investments | 18,208 |  |  | 21,663 |  |
| Non-marketable equity securities included in other assets | 1,186 |  |  | 1,113 |  |
| Equity method investments included in other assets | 68 |  |  | 87 |  |
| Total | $ | 19,462 |  |  | $ | 22,863 |  |
  (was, 2020-02-18, similarity 0.9829):
[0000858877-20-000004:note_history:40]
|  | January 25, 2020 |  | July 27, 2019 |
| Available-for-sale debt investments | $ | 18,587 |  |  | $ | 21,660 |  |
| Marketable equity securities | — |  |  | 3 |  |
| Total investments | 18,587 |  |  | 21,663 |  |
| Non-marketable equity securities included in other assets | 1,155 |  |  | 1,113 |  |
| Equity method investments included in other assets | 61 |  |  | 87 |  |
| Total | $ | 19,803 |  |  | $ | 22,863 |  |

- changed (2020-05-18):
[0000858877-20-000006:note_history:41]
| April 25, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 2,527 |  |  | $ | 83 |  |  | $ | — |  |  | $ | 2,610 |  |
| U.S. government agency securities | 54 |  |  | — |  |  | — |  |  | 54 |  |
| Corporate debt securities | 12,291 |  |  | 172 |  |  | (86 | ) |  | 12,377 |  |
| U.S. agency mortgage-backed securities | 1,617 |  |  | 50 |  |  | — |  |  | 1,667 |  |
| Commercial paper | 1,272 |  |  | — |  |  | — |  |  | 1,272 |  |
| Certificates of deposit | 228 |  |  | — |  |  | — |  |  | 228 |  |
| Total (1) | $ | 17,989 |  |  | $ | 305 |  |  | $ | (86 | ) |  | $ | 18,208 |  |
  (was, 2020-02-18, similarity 0.9809):
[0000858877-20-000004:note_history:41]
| January 25, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 2,218 |  |  | $ | 13 |  |  | $ | — |  |  | $ | 2,231 |  |
| U.S. government agency securities | 20 |  |  | — |  |  | — |  |  | 20 |  |
| Corporate debt securities | 13,405 |  |  | 196 |  |  | (4 | ) |  | 13,597 |  |
| U.S. agency mortgage-backed securities | 1,612 |  |  | 14 |  |  | (3 | ) |  | 1,623 |  |
| Commercial paper | 1,052 |  |  | — |  |  | — |  |  | 1,052 |  |
| Certificates of deposit | 64 |  |  | — |  |  | — |  |  | 64 |  |
| Total (1) | $ | 18,371 |  |  | $ | 223 |  |  | $ | (7 | ) |  | $ | 18,587 |  |

- changed (2020-05-18):
[0000858877-20-000006:note_history:42]
(1) Net unsettled investment sales were $12 million as of April 25, 2020 and were included in other current assets.
  (was, 2020-02-18, similarity 0.9636):
[0000858877-20-000004:note_history:42]
(1) Net unsettled investment sales were $13 million as of January 25, 2020 and were included in other current assets.

- changed (2020-05-18):
[0000858877-20-000006:note_history:43]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Gross realized gains | $ | 20 |  |  | $ | 7 |  |  | $ | 45 |  |  | $ | 10 |  |
| Gross realized losses | (21 | ) |  | (14 | ) |  | (25 | ) |  | (28 | ) |
| Total | $ | (1 | ) |  | $ | (7 | ) |  | $ | 20 |  |  | $ | (18 | ) |
  (was, 2020-02-18, similarity 0.671):
[0000858877-20-000004:note_history:43]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Gross realized gains | $ | 13 |  |  | $ | 1 |  |  | $ | 25 |  |  | $ | 3 |  |
| Gross realized losses | (2 | ) |  | (6 | ) |  | (4 | ) |  | (14 | ) |
| Total | $ | 11 |  |  | $ | (5 | ) |  | $ | 21 |  |  | $ | (11 | ) |

- changed (2020-05-18):
[0000858877-20-000006:note_history:44]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 25, 2020 and July 27, 2019 (in millions):
  (was, 2020-02-18, similarity 0.9716):
[0000858877-20-000004:note_history:44]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 25, 2020 and July 27, 2019 (in millions):

- added (2020-05-18):
[0000858877-20-000006:note_history:45]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 25, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 26 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |
| U.S. government agency securities | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Corporate debt securities | 3,529 |  |  | (86 | ) |  | 23 |  |  | — |  |  | 3,552 |  |  | (86 | ) |
| U.S. agency mortgage-backed securities | 19 |  |  | — |  |  | — |  |  | — |  |  | 19 |  |  | — |  |
| Commercial paper | 1,013 |  |  | — |  |  | — |  |  | — |  |  | 1,013 |  |  | — |  |
| Certificates of deposit | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 4,607 |  |  | $ | (86 | ) |  | $ | 23 |  |  | $ | — |  |  | $ | 4,630 |  |  | $ | (86 | ) |

- changed (2020-05-18):
[0000858877-20-000006:note_history:46]
For available-for-sale debt investments that were in an unrealized loss position as of April 25, 2020, we have determined that no other-than-temporary impairments were required to be recognized.
  (was, 2020-02-18, similarity 0.9788):
[0000858877-20-000004:note_history:46]
For available-for-sale debt investments that were in an unrealized loss position as of January 25, 2020, we have determined that no other-than-temporary impairments were required to be recognized.

- changed (2020-05-18):
[0000858877-20-000006:note_history:47]
The following table summarizes the maturities of our available-for-sale debt investments as of April 25, 2020 (in millions):
  (was, 2020-02-18, similarity 0.9667):
[0000858877-20-000004:note_history:47]
The following table summarizes the maturities of our available-for-sale debt investments as of January 25, 2020 (in millions):

- added (2020-05-18):
[0000858877-20-000006:note_history:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Net gains and losses recognized during the period on equity investments | $ | (7 | ) |  | $ | 3 |  |  | $ | 71 |  |  | $ | 78 |  |
| Less: Net gains and losses recognized on equity investments sold | 3 |  |  | (44 | ) |  | (71 | ) |  | (51 | ) |
| Net unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | (4 | ) |  | $ | (41 | ) |  | $ | — |  |  | $ | 27 |  |

- changed (2020-05-18):
[0000858877-20-000006:note_history:49]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |  |  |  |  |  |  |
| Upward adjustments | $ | 9 |  |  | $ | 9 |  |  | $ | 20 |  |  | $ | 25 |  |
| Downward adjustments, including impairments | (13 | ) |  | (4 | ) |  | (21 | ) |  | (22 | ) |
| Net adjustments | $ | (4 | ) |  | $ | 5 |  |  | $ | (1 | ) |  | $ | 3 |  |
  (was, 2020-02-18, similarity 0.7789):
[0000858877-20-000004:note_history:49]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |  |  |  |  |  |  |
| Upward adjustments | $ | 11 |  |  | $ | 14 |  |  | $ | 12 |  |  | $ | 24 |  |
| Downward adjustments, including impairments | (8 | ) |  | (2 | ) |  | (9 | ) |  | (18 | ) |
| Net adjustments | $ | 3 |  |  | $ | 12 |  |  | $ | 3 |  |  | $ | 6 |  |

- changed (2020-05-18):
[0000858877-20-000006:note_history:50]
As of April 25, 2020 and July 27, 2019, we held equity interests in certain private equity funds of $0.7 billion and $0.6 billion, respectively, which are accounted for under the NAV practical expedient.
  (was, 2020-02-18, similarity 0.9788):
[0000858877-20-000004:note_history:50]
As of January 25, 2020 and July 27, 2019, we held equity interests in certain private equity funds of $0.7 billion and $0.6 billion, respectively, which are accounted for under the NAV practical expedient.

- changed (2020-05-18):
[0000858877-20-000006:note_history:51]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 25, 2020, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2020-02-18, similarity 0.9898):
[0000858877-20-000004:note_history:51]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 25, 2020, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- changed (2020-05-18):
[0000858877-20-000006:note_history:52]
As of April 25, 2020, the carrying value of investments in privately held companies was $1.3 billion. $691 million of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $344 million related to these privately held investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these privately held investments.
  (was, 2020-02-18, similarity 0.9899):
[0000858877-20-000004:note_history:52]
As of January 25, 2020, the carrying value of investments in privately held companies was $1.2 billion. $669 million of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $291 million related to these privately held investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these privately held investments.

- removed (2020-05-18):
[0000858877-20-000004:note_history:53]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 25, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 44 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |
| U.S. government agency securities | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Corporate debt securities | 260 |  |  | (1 | ) |  | 439 |  |  | (3 | ) |  | 699 |  |  | (4 | ) |
| U.S. agency mortgage-backed securities | 56 |  |  | — |  |  | 374 |  |  | (3 | ) |  | 430 |  |  | (3 | ) |
| Commercial paper | 51 |  |  | — |  |  | — |  |  | — |  |  | 51 |  |  | — |  |
| Certificates of deposit | 36 |  |  | — |  |  | — |  |  | — |  |  | 36 |  |  | — |  |
| Total | $ | 447 |  |  | $ | (1 | ) |  | $ | 836 |  |  | $ | (6 | ) |  | $ | 1,283 |  |  | $ | (7 | ) |

- removed (2020-05-18):
[0000858877-20-000004:note_history:54]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Net gains and losses recognized during the period on equity investments | $ | 71 |  |  | $ | 67 |  |  | $ | 78 |  |  | $ | 75 |  |
| Less: Net gains and losses recognized on equity investments sold | (68 | ) |  | 5 |  |  | (75 | ) |  | (7 | ) |
| Net unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | 3 |  |  | $ | 72 |  |  | $ | 3 |  |  | $ | 68 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-18):
[0000858877-20-000006:note_history:55]
|  |  |  | April 25, 2020 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | — |  |  | — |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.76% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.85% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.87% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.01% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 16,000 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (90 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 174 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 16,084 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,506 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 11,578 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 16,084 |  |  |  |  | $ | 20,473 |  |  |  |
  (was, 2020-02-18, similarity 0.996):
[0000858877-20-000004:note_history:55]
|  |  |  | January 25, 2020 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | — |  |  | — |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.51% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.71% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.63% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.88% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 16,000 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (94 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 87 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 15,993 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,499 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 14,494 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 15,993 |  |  |  |  | $ | 20,473 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-18):
[0000858877-20-000006:note_history:56]
As of April 25, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2020-02-18, similarity 0.9701):
[0000858877-20-000004:note_history:56]
As of January 25, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2020-05-18):
[0000858877-20-000006:note_history:57]
| Fiscal Year | Amount |
| 2020 (remaining three months) | $ | 1,500 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 16,000 |  |
  (was, 2020-02-18, similarity 0.9739):
[0000858877-20-000004:note_history:57]
| Fiscal Year | Amount |
| 2020 (remaining six months) | $ | 1,500 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 16,000 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-18):
[0000858877-20-000006:note_history:58]
|  | April 25, 2020 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,506 |  |  | 2.32 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 4,506 |  |  |  |  | $ | 10,191 |  |  |  |
  (was, 2020-02-18, similarity 0.9786):
[0000858877-20-000004:note_history:58]
|  | January 25, 2020 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,499 |  |  | 2.54 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 1,499 |  |  |  |  | $ | 10,191 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-18):
[0000858877-20-000006:note_history:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,429 |  |  | $ | 7,523 |  |  | $ | 20,496 |  |  | $ | 22,247 |  |
| Applications | 1,363 |  |  | 1,431 |  |  | 4,211 |  |  | 4,315 |  |
| Security | 776 |  |  | 729 |  |  | 2,340 |  |  | 2,083 |  |
| Other Products | 28 |  |  | 39 |  |  | 100 |  |  | 239 |  |
| Total Product | 8,597 |  |  | 9,722 |  |  | 27,146 |  |  | 28,885 |  |
| Services | 3,386 |  |  | 3,236 |  |  | 10,001 |  |  | 9,591 |  |
| Total (1) | $ | 11,983 |  |  | $ | 12,958 |  |  | $ | 37,147 |  |  | $ | 38,476 |  |
  (was, 2020-02-18, similarity 0.8929):
[0000858877-20-000004:note_history:59]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,528 |  |  | $ | 7,102 |  |  | $ | 14,067 |  |  | $ | 14,724 |  |
| Applications | 1,349 |  |  | 1,465 |  |  | 2,847 |  |  | 2,884 |  |
| Security | 748 |  |  | 684 |  |  | 1,563 |  |  | 1,354 |  |
| Other Products | 46 |  |  | 22 |  |  | 72 |  |  | 200 |  |
| Total Product | 8,671 |  |  | 9,273 |  |  | 18,549 |  |  | 19,163 |  |
| Services | 3,334 |  |  | 3,173 |  |  | 6,615 |  |  | 6,355 |  |
| Total (1) | $ | 12,005 |  |  | $ | 12,446 |  |  | $ | 25,164 |  |  | $ | 25,518 |  |

- changed (2020-05-18):
[0000858877-20-000006:note_history:60]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (“SPVSS”) business. Total revenue includes SPVSS business revenue of $168 million for the first nine months of fiscal 2019.
  (was, 2020-02-18, similarity 0.9852):
[0000858877-20-000004:note_history:60]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (“SPVSS”) business. Total revenue includes SPVSS business revenue of $168 million for the first six months of fiscal 2019.

- changed (2020-05-18):
[0000858877-20-000006:note_history:61]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,429 |  |  | $ | 7,523 |  |  | $ | 20,496 |  |  | $ | 22,247 |  |
| Applications | 1,363 |  |  | 1,431 |  |  | 4,211 |  |  | 4,315 |  |
| Security | 776 |  |  | 729 |  |  | 2,340 |  |  | 2,083 |  |
| Other Products | 28 |  |  | 39 |  |  | 100 |  |  | 239 |  |
| Total Product | 8,597 |  |  | 9,722 |  |  | 27,146 |  |  | 28,885 |  |
| Services | 3,386 |  |  | 3,236 |  |  | 10,001 |  |  | 9,591 |  |
| Total (1) | $ | 11,983 |  |  | $ | 12,958 |  |  | $ | 37,147 |  |  | $ | 38,476 |  |
  (was, 2020-02-18, similarity 0.8929):
[0000858877-20-000004:note_history:61]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,528 |  |  | $ | 7,102 |  |  | $ | 14,067 |  |  | $ | 14,724 |  |
| Applications | 1,349 |  |  | 1,465 |  |  | 2,847 |  |  | 2,884 |  |
| Security | 748 |  |  | 684 |  |  | 1,563 |  |  | 1,354 |  |
| Other Products | 46 |  |  | 22 |  |  | 72 |  |  | 200 |  |
| Total Product | 8,671 |  |  | 9,273 |  |  | 18,549 |  |  | 19,163 |  |
| Services | 3,334 |  |  | 3,173 |  |  | 6,615 |  |  | 6,355 |  |
| Total (1) | $ | 12,005 |  |  | $ | 12,446 |  |  | $ | 25,164 |  |  | $ | 25,518 |  |

- changed (2020-05-18):
[0000858877-20-000006:note_history:62]
(1) Includes SPVSS business revenue of $168 million for the first nine months of fiscal 2019.
  (was, 2020-02-18, similarity 0.9711):
[0000858877-20-000004:note_history:62]
(1) Includes SPVSS business revenue of $168 million for the first six months of fiscal 2019.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-18):
[0000858877-20-000006:note_history:63]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or
  (was, 2020-02-18, similarity 0.7606):
[0000858877-20-000004:note_history:63]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

- added (2020-05-18):
[0000858877-20-000006:note_history:64]
service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

- changed (2020-05-18):
[0000858877-20-000006:note_history:65]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.
  (was, 2020-02-18, similarity 0.7683):
[0000858877-20-000004:note_history:65]
marketing and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

- removed (2020-05-18):
[0000858877-20-000004:note_history:66]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-18):
[0000858877-20-000006:note_history:67]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or
  (was, 2020-02-18, similarity 0.7606):
[0000858877-20-000004:note_history:67]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

- added (2020-05-18):
[0000858877-20-000006:note_history:68]
service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

- changed (2020-05-18):
[0000858877-20-000006:note_history:69]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.
  (was, 2020-02-18, similarity 0.7683):
[0000858877-20-000004:note_history:69]
marketing and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

- changed (2020-05-18):
[0000858877-20-000006:note_history:70]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,429 |  |  | $ | 7,523 |  |  | $ | 20,496 |  |  | $ | 22,247 |  |
| Applications | 1,363 |  |  | 1,431 |  |  | 4,211 |  |  | 4,315 |  |
| Security | 776 |  |  | 729 |  |  | 2,340 |  |  | 2,083 |  |
| Other Products | 28 |  |  | 39 |  |  | 100 |  |  | 239 |  |
| Total Product | 8,597 |  |  | 9,722 |  |  | 27,146 |  |  | 28,885 |  |
| Services | 3,386 |  |  | 3,236 |  |  | 10,001 |  |  | 9,591 |  |
| Total (1) | $ | 11,983 |  |  | $ | 12,958 |  |  | $ | 37,147 |  |  | $ | 38,476 |  |
  (was, 2020-02-18, similarity 0.8929):
[0000858877-20-000004:note_history:70]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2020 |  | January 26, 2019 |  | January 25, 2020 |  | January 26, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,528 |  |  | $ | 7,102 |  |  | $ | 14,067 |  |  | $ | 14,724 |  |
| Applications | 1,349 |  |  | 1,465 |  |  | 2,847 |  |  | 2,884 |  |
| Security | 748 |  |  | 684 |  |  | 1,563 |  |  | 1,354 |  |
| Other Products | 46 |  |  | 22 |  |  | 72 |  |  | 200 |  |
| Total Product | 8,671 |  |  | 9,273 |  |  | 18,549 |  |  | 19,163 |  |
| Services | 3,334 |  |  | 3,173 |  |  | 6,615 |  |  | 6,355 |  |
| Total (1) | $ | 12,005 |  |  | $ | 12,446 |  |  | $ | 25,164 |  |  | $ | 25,518 |  |

- changed (2020-05-18):
[0000858877-20-000006:note_history:71]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (“SPVSS”) business. Total revenue includes SPVSS business revenue of $168 million for the first nine months of fiscal 2019.
  (was, 2020-02-18, similarity 0.9852):
[0000858877-20-000004:note_history:71]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (“SPVSS”) business. Total revenue includes SPVSS business revenue of $168 million for the first six months of fiscal 2019.

- changed (2020-05-18):
[0000858877-20-000006:note_history:72]
Accounts receivable, net was $4.6 billion as of April 25, 2020 compared to $5.5 billion as of July 27, 2019, as reported on the Consolidated Balance Sheet.
  (was, 2020-02-18, similarity 0.9716):
[0000858877-20-000004:note_history:72]
Accounts receivable, net was $4.3 billion as of January 25, 2020 compared to $5.5 billion as of July 27, 2019, as reported on the Consolidated Balance Sheet.

- changed (2020-05-18):
[0000858877-20-000006:note_history:73]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of April 25, 2020 and July 27, 2019, our contract assets for these unbilled receivables were $1.1 billion and $860 million, respectively, and were included in other current assets and other assets.
  (was, 2020-02-18, similarity 0.9618):
[0000858877-20-000004:note_history:73]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of January 25, 2020 and July 27, 2019, our contract assets for these unbilled receivables were $966 million and $860 million, respectively, and were included in other current assets and other assets.

- changed (2020-05-18):
[0000858877-20-000006:note_history:74]
Contract liabilities consist of deferred revenue. Deferred revenue was $18.6 billion as of April 25, 2020 compared to $18.5 billion as of July 27, 2019. We recognized approximately $2.3 billion and $8.9 billion of revenue during the third quarter and first nine months of fiscal 2020, respectively, that was included in the deferred revenue balance at July 27, 2019.
  (was, 2020-02-18, similarity 0.75):
[0000858877-20-000004:note_history:74]
Contract liabilities consist of deferred revenue. Deferred revenue was $18.7 billion as of January 25, 2020 compared to $18.5 billion as of July 27, 2019. We recognized approximately $2.9 billion and $6.6 billion of revenue during the second quarter and first six months of fiscal 2020, respectively, that was included in the deferred revenue balance at July 27, 2019.

- changed (2020-05-18):
[0000858877-20-000006:note_history:75]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of April 25, 2020, the aggregate amount of RPO was $25.5 billion, comprised of $18.6 billion of deferred revenue and $6.9 billion of unbilled contract revenue. We expect approximately 56% of this amount to be recognized as revenue over the next year. As of July 27, 2019, the aggregate amount of RPO was $25.3 billion, comprised of $18.5 billion of deferred revenue and $6.8 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.
  (was, 2020-02-18, similarity 0.9913):
[0000858877-20-000004:note_history:75]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of January 25, 2020, the aggregate amount of RPO was $24.9 billion, comprised of $18.7 billion of deferred revenue and $6.2 billion of unbilled contract revenue. We expect approximately 55% of this amount to be recognized as revenue over the next year. As of July 27, 2019, the aggregate amount of RPO was $25.3 billion, comprised of $18.5 billion of deferred revenue and $6.8 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

- changed (2020-05-18):
[0000858877-20-000006:note_history:76]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $703 million and $750 million as of April 25, 2020 and July 27, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $118 million and $356 million for the third quarter and first nine months of fiscal 2020, respectively, and $124 million and $349 million for the corresponding periods of fiscal 2019, respectively, and was included in sales and marketing expenses.
  (was, 2020-02-18, similarity 0.9836):
[0000858877-20-000004:note_history:76]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $708 million and $750 million as of January 25, 2020 and July 27, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $122 million and $238 million for the second quarter and first six months of fiscal 2020, respectively, and $100 million and $212 million for the corresponding periods of fiscal 2019, respectively, and was included in sales and marketing expenses.

- removed (2020-05-18):
[0000858877-20-000004:note_history:77]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative
