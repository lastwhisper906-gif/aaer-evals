# CSCO notes — 0000858877-20-000006


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-20-000006:notes:1]
[same as prior period, unchanged from 0000858877-20-000004:notes:1]

[0000858877-20-000006:notes:2]
[same as prior period, unchanged from 0000858877-20-000004:notes:2]

[0000858877-20-000006:notes:3]
We have prepared the accompanying financial data as of April 25, 2020 and for the third quarter and first nine months of fiscal 2020 and 2019, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2019 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 27, 2019.

[0000858877-20-000006:notes:4]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic on our critical and significant accounting estimates. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues to develop, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-20-000006:notes:5]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of April 25, 2020, the results of operations, the statements of comprehensive income (loss) and the statements of equity for the third quarter and first nine months of fiscal 2020 and 2019; and the statements of cash flows for the first nine months of fiscal 2020 and 2019, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2020 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-20-000006:notes:6]
[same as prior period, unchanged from 0000858877-20-000004:notes:4]

[0000858877-20-000006:notes:7]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-20-000006:notes:8]
[same as prior period, unchanged from 0000858877-20-000004:notes:7]

[0000858877-20-000006:notes:9]
[same as prior period, unchanged from 0000858877-20-000004:notes:8]

[0000858877-20-000006:notes:10]
[same as prior period, unchanged from 0000858877-20-000004:notes:9]

[0000858877-20-000006:notes:11]
We have elected to apply the package of practical expedients permitted under the transition guidance within ASC 842 which does not require reassessment of initial direct costs, classification of a lease and definition of a lease. We also elected additional practical

[0000858877-20-000006:notes:12]
expedients which resulted in: i) allowing us not to reassess the accounting treatment for existing or expired land easements in transition; ii) combining lease and non-lease components and iii) not recording leases with an initial term of less than 12 months on our Consolidated Balance Sheet.

[0000858877-20-000006:notes:13]
[same as prior period, unchanged from 0000858877-20-000004:notes:11]

[0000858877-20-000006:notes:14]
[same as prior period, unchanged from 0000858877-20-000004:notes:12]

[0000858877-20-000006:notes:15]
[same as prior period, unchanged from 0000858877-20-000004:notes:13]

[0000858877-20-000006:notes:16]
[same as prior period, unchanged from 0000858877-20-000004:notes:14]

[0000858877-20-000006:notes:17]
[same as prior period, unchanged from 0000858877-20-000004:notes:15]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-20-000006:notes:18]
[same as prior period, unchanged from 0000858877-20-000004:notes:16]

[0000858877-20-000006:notes:19]
[same as prior period, unchanged from 0000858877-20-000004:notes:17]

[0000858877-20-000006:notes:20]
[same as prior period, unchanged from 0000858877-20-000004:notes:18]

[0000858877-20-000006:notes:21]
[same as prior period, unchanged from 0000858877-20-000004:notes:19]

[0000858877-20-000006:notes:22]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or

[0000858877-20-000006:notes:23]
service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-20-000006:notes:24]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes contractual potential penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers' right of return in determining the transaction price, where applicable.

[0000858877-20-000006:notes:25]
[same as prior period, unchanged from 0000858877-20-000004:notes:23]

[0000858877-20-000006:notes:26]
[same as prior period, unchanged from 0000858877-20-000004:notes:24]

[0000858877-20-000006:notes:27]
[same as prior period, unchanged from 0000858877-20-000004:notes:25]

[0000858877-20-000006:notes:28]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 6,429 |  |  | $ | 7,523 |  |  | $ | 20,496 |  |  | $ | 22,247 |  |
| Applications | 1,363 |  |  | 1,431 |  |  | 4,211 |  |  | 4,315 |  |
| Security | 776 |  |  | 729 |  |  | 2,340 |  |  | 2,083 |  |
| Other Products | 28 |  |  | 39 |  |  | 100 |  |  | 239 |  |
| Total Product | 8,597 |  |  | 9,722 |  |  | 27,146 |  |  | 28,885 |  |
| Services | 3,386 |  |  | 3,236 |  |  | 10,001 |  |  | 9,591 |  |
| Total (1) | $ | 11,983 |  |  | $ | 12,958 |  |  | $ | 37,147 |  |  | $ | 38,476 |  |

[0000858877-20-000006:notes:29]
[same as prior period, unchanged from 0000858877-20-000004:notes:27]

[0000858877-20-000006:notes:30]
(1) During the second quarter of fiscal 2019, we completed the divestiture of the Service Provider Video Software Solutions (“SPVSS”) business. Total revenue includes SPVSS business revenue of $168 million for the first nine months of fiscal 2019.

[0000858877-20-000006:notes:31]
[same as prior period, unchanged from 0000858877-20-000004:notes:29]

[0000858877-20-000006:notes:32]
[same as prior period, unchanged from 0000858877-20-000004:notes:30]

[0000858877-20-000006:notes:33]
[same as prior period, unchanged from 0000858877-20-000004:notes:31]

[0000858877-20-000006:notes:34]
[same as prior period, unchanged from 0000858877-20-000004:notes:32]

[0000858877-20-000006:notes:35]
[same as prior period, unchanged from 0000858877-20-000004:notes:33]

[0000858877-20-000006:notes:36]
[same as prior period, unchanged from 0000858877-20-000004:notes:34]

[0000858877-20-000006:notes:37]
[same as prior period, unchanged from 0000858877-20-000004:notes:35]

[0000858877-20-000006:notes:38]
Accounts receivable, net was $4.6 billion as of April 25, 2020 compared to $5.5 billion as of July 27, 2019, as reported on the Consolidated Balance Sheet.

[0000858877-20-000006:notes:39]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of April 25, 2020 and July 27, 2019, our contract assets for these unbilled receivables were $1.1 billion and $860 million, respectively, and were included in other current assets and other assets.

[0000858877-20-000006:notes:40]
Contract liabilities consist of deferred revenue. Deferred revenue was $18.6 billion as of April 25, 2020 compared to $18.5 billion as of July 27, 2019. We recognized approximately $2.3 billion and $8.9 billion of revenue during the third quarter and first nine months of fiscal 2020, respectively, that was included in the deferred revenue balance at July 27, 2019.

[0000858877-20-000006:notes:41]
[same as prior period, unchanged from 0000858877-20-000004:notes:39]

[0000858877-20-000006:notes:42]
Remaining Performance Obligations (RPO) are comprised of deferred revenue plus unbilled contract revenue. As of April 25, 2020, the aggregate amount of RPO was $25.5 billion, comprised of $18.6 billion of deferred revenue and $6.9 billion of unbilled contract revenue. We expect approximately 56% of this amount to be recognized as revenue over the next year. As of July 27, 2019, the aggregate amount of RPO was $25.3 billion, comprised of $18.5 billion of deferred revenue and $6.8 billion of unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

[0000858877-20-000006:notes:43]
[same as prior period, unchanged from 0000858877-20-000004:notes:41]

[0000858877-20-000006:notes:44]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $703 million and $750 million as of April 25, 2020 and July 27, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $118 million and $356 million for the third quarter and first nine months of fiscal 2020, respectively, and $124 million and $349 million for the corresponding periods of fiscal 2019, respectively, and was included in sales and marketing expenses.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-20-000006:notes:45]
[same as prior period, unchanged from 0000858877-20-000004:notes:43]

[0000858877-20-000006:notes:46]
[same as prior period, unchanged from 0000858877-20-000004:notes:44]

[0000858877-20-000006:notes:47]
(1) Includes SPVSS business revenue of $168 million for the first nine months of fiscal 2019.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-20-000006:notes:48]
[same as prior period, unchanged from 0000858877-20-000004:notes:46]

[0000858877-20-000006:notes:49]
We completed five acquisitions during the first nine months of fiscal 2020. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-20-000006:notes:50]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions (five in total) | $ | 262 |  |  | $ | (13 | ) |  | $ | 145 |  |  | $ | 130 |  |

[0000858877-20-000006:notes:51]
The total purchase consideration related to acquisitions completed during the first nine months of fiscal 2020 consisted of cash consideration. The total cash and cash equivalents acquired from these acquisitions was approximately $16 million. Total transaction costs related to acquisition and divestiture activities were $13 million and $15 million for the first nine months of fiscal 2020 and 2019, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-20-000006:notes:52]
The goodwill generated from acquisitions completed during the first nine months of fiscal 2020 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-20-000006:notes:53]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first nine months of fiscal 2020 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.

[0000858877-20-000006:notes:54]
[same as prior period, unchanged from 0000858877-20-000004:notes:52]

[0000858877-20-000006:notes:55]
[same as prior period, unchanged from 0000858877-20-000004:notes:53]

[0000858877-20-000006:notes:56]
Under the terms of the agreement, we have agreed to pay total consideration of approximately $2.6 billion, net of cash and marketable securities, to acquire Acacia. The acquisition is expected to close in the fourth quarter of fiscal 2020, subject to customary closing conditions and regulatory approvals. Upon close of the acquisition, revenue from Acacia will be included in our Infrastructure Platforms product category.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-20-000006:notes:57]
[same as prior period, unchanged from 0000858877-20-000004:notes:55]

[0000858877-20-000006:notes:58]
[same as prior period, unchanged from 0000858877-20-000004:notes:56]

[0000858877-20-000006:notes:59]
The following table presents the goodwill allocated to our reportable segments as of April 25, 2020 and during the first nine months of fiscal 2020 (in millions):

[0000858877-20-000006:notes:60]
|  | Balance at July 27, 2019 |  | Acquisitions |  | Foreign currency translation and Other |  | Balance at April 25, 2020 |
| Americas | $ | 21,120 |  |  | $ | 88 |  |  | $ | (128 | ) |  | $ | 21,080 |  |
| EMEA | 7,977 |  |  | 26 |  |  | (50 | ) |  | 7,953 |  |
| APJC | 4,432 |  |  | 16 |  |  | (28 | ) |  | 4,420 |  |
| Total | $ | 33,529 |  |  | $ | 130 |  |  | $ | (206 | ) |  | $ | 33,453 |  |

[0000858877-20-000006:notes:61]
[same as prior period, unchanged from 0000858877-20-000004:notes:60]

[0000858877-20-000006:notes:62]
The following table presents details of our intangible assets acquired through acquisitions completed during the first nine months of fiscal 2020 (in millions, except years):

[0000858877-20-000006:notes:63]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions (five in total) | 4.8 |  | $ | 137 |  |  | 4.0 |  | $ | 8 |  |  | — |  |  | $ | — |  |  | — |  |  | $ | 145 |  |

[0000858877-20-000006:notes:64]
[same as prior period, unchanged from 0000858877-20-000004:notes:63]

[0000858877-20-000006:notes:65]
| April 25, 2020 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,362 |  |  | $ | (2,261 | ) |  | $ | 1,101 |  |
| Customer relationships |  | 758 |  |  | (336 | ) |  | 422 |  |
| Other |  | 26 |  |  | (18 | ) |  | 8 |  |
| Total purchased intangible assets with finite lives |  | 4,146 |  |  | (2,615 | ) |  | 1,531 |  |
| In-process research and development, with indefinite lives |  | 213 |  |  | — |  |  | 213 |  |
| Total |  | $ | 4,359 |  |  | $ | (2,615 | ) |  | $ | 1,744 |  |

[0000858877-20-000006:notes:66]
[same as prior period, unchanged from 0000858877-20-000004:notes:65]

[0000858877-20-000006:notes:67]
[same as prior period, unchanged from 0000858877-20-000004:notes:66]

[0000858877-20-000006:notes:68]
[same as prior period, unchanged from 0000858877-20-000004:notes:67]

[0000858877-20-000006:notes:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 163 |  |  | $ | 157 |  |  | $ | 494 |  |  | $ | 464 |  |
| Operating expenses | 34 |  |  | 39 |  |  | 108 |  |  | 112 |  |
| Total | $ | 197 |  |  | $ | 196 |  |  | $ | 602 |  |  | $ | 576 |  |

[0000858877-20-000006:notes:70]
The estimated future amortization expense of purchased intangible assets with finite lives as of April 25, 2020 is as follows (in millions):

[0000858877-20-000006:notes:71]
| Fiscal Year | Amount |
| 2020 (remaining three months) | $ | 198 |  |
| 2021 | $ | 623 |  |
| 2022 | $ | 366 |  |
| 2023 | $ | 224 |  |
| 2024 | $ | 113 |  |
| Thereafter | $ | 7 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-20-000006:notes:72]
[same as prior period, unchanged from 0000858877-20-000004:notes:71]

[0000858877-20-000006:notes:73]
We initiated a restructuring plan in the third quarter of fiscal 2020 (the “Fiscal 2020 Plan”) in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $300 million. These aggregate pretax charges related to the Fiscal 2020 Plan are primarily cash-based and consist of employee severance and other one-time termination benefits, and other costs. In connection with the Fiscal 2020 Plan, we incurred charges of $128 million for the third quarter and first nine months of fiscal 2020. We expect the Fiscal 2020 Plan to be substantially completed in fiscal 2021.

[0000858877-20-000006:notes:74]
We initiated a restructuring plan during fiscal 2018 (the “Fiscal 2018 Plan”) in order to realign the organization and enable further investment in key priority areas. The aggregate pretax charges related to the Fiscal 2018 Plan were primarily cash-based and consisted of employee severance and other one-time termination benefits, and other associated costs. In connection with the Fiscal 2018 Plan, we incurred charges of $226 million in the first nine months of fiscal 2020 and have incurred cumulative charges of $656 million. We completed the Fiscal 2018 Plan in the second quarter of fiscal 2020.

[0000858877-20-000006:notes:75]
[same as prior period, unchanged from 0000858877-20-000004:notes:73]

[0000858877-20-000006:notes:76]
|  |  | FISCAL 2018 AND PRIOR PLANS |  | FISCAL 2020 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 27, 2019 |  | $ | 22 |  |  | $ | 11 |  |  | $ | — |  |  | $ | — |  |  | $ | 33 |  |
| Charges |  | 209 |  |  | 17 |  |  | 116 |  |  | 12 |  |  | 354 |  |
| Cash payments |  | (217 | ) |  | (2 | ) |  | (35 | ) |  | (6 | ) |  | (260 | ) |
| Non-cash items |  | — |  |  | (23 | ) |  | — |  |  | (6 | ) |  | (29 | ) |
| Liability as of April 25, 2020 |  | $ | 14 |  |  | $ | 3 |  |  | $ | 81 |  |  | $ | — |  |  | $ | 98 |  |

[0000858877-20-000006:notes:77]
|  |  | FISCAL 2017 AND PRIOR PLANS |  | FISCAL 2018 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 28, 2018 |  | $ | 41 |  |  | $ | 13 |  |  | $ | 19 |  |  | $ | — |  |  | $ | 73 |  |
| Charges |  | — |  |  | (1 | ) |  | 232 |  |  | 51 |  |  | 282 |  |
| Cash payments |  | (34 | ) |  | (7 | ) |  | (232 | ) |  | (2 | ) |  | (275 | ) |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (46 | ) |  | (46 | ) |
| Liability as of April 27, 2019 |  | $ | 7 |  |  | $ | 5 |  |  | $ | 19 |  |  | $ | 3 |  |  | $ | 34 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-20-000006:notes:78]
[same as prior period, unchanged from 0000858877-20-000004:notes:77]

[0000858877-20-000006:notes:79]
[same as prior period, unchanged from 0000858877-20-000004:notes:78]

[0000858877-20-000006:notes:80]
|  |  | April 25, 2020 |  | July 27, 2019 |
| Cash and cash equivalents |  | $ | 10,366 |  |  | $ | 11,750 |  |
| Restricted cash included in other current assets |  | 1 |  |  | 21 |  |
| Restricted cash included in other assets |  | 3 |  |  | 1 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 10,370 |  |  | $ | 11,772 |  |

[0000858877-20-000006:notes:81]
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 446 |  |  | $ | 374 |  |
| Work in process |  | 20 |  |  | 10 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales |  | 57 |  |  | 109 |  |
| Manufactured finished goods |  | 492 |  |  | 643 |  |
| Total finished goods |  | 549 |  |  | 752 |  |
| Service-related spares |  | 182 |  |  | 225 |  |
| Demonstration systems |  | 15 |  |  | 22 |  |
| Total |  | $ | 1,212 |  |  | $ | 1,383 |  |

[0000858877-20-000006:notes:82]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,405 |  |  | $ | 4,545 |  |
| Computer equipment and related software |  | 895 |  |  | 922 |  |
| Production, engineering, and other equipment |  | 5,093 |  |  | 5,711 |  |
| Operating lease assets |  | 348 |  |  | 485 |  |
| Furniture, fixtures and other |  | 396 |  |  | 376 |  |
| Total gross property and equipment |  | 11,137 |  |  | 12,039 |  |
| Less: accumulated depreciation and amortization |  | (8,602 | ) |  | (9,250 | ) |
| Total |  | $ | 2,535 |  |  | $ | 2,789 |  |

[0000858877-20-000006:notes:83]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 11,423 |  |  | $ | 11,709 |  |
| Product |  | 7,225 |  |  | 6,758 |  |
| Total |  | $ | 18,648 |  |  | $ | 18,467 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 10,710 |  |  | $ | 10,668 |  |
| Noncurrent |  | 7,938 |  |  | 7,799 |  |
| Total |  | $ | 18,648 |  |  | $ | 18,467 |  |


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000858877-20-000006:notes:84]
[same as prior period, unchanged from 0000858877-20-000004:notes:83]

[0000858877-20-000006:notes:85]
[same as prior period, unchanged from 0000858877-20-000004:notes:84]

[0000858877-20-000006:notes:86]
[same as prior period, unchanged from 0000858877-20-000004:notes:85]

[0000858877-20-000006:notes:87]
[same as prior period, unchanged from 0000858877-20-000004:notes:86]

[0000858877-20-000006:notes:88]
As of April 25, 2020, our operating lease right-of-use assets were $930 million and were recorded in other assets, and our operating lease liabilities were $998 million, of which $344 million was included in other current liabilities and $654 million was included in other long-term liabilities. The weighted-average lease term was 4.0 years and the weighted-average discount rate was 1.7% as of April 25, 2020.

[0000858877-20-000006:notes:89]
[same as prior period, unchanged from 0000858877-20-000004:notes:88]

[0000858877-20-000006:notes:90]
|  | April 25, 2020 |
|  | Three Months Ended |  | Nine Months Ended |
| Operating lease expense | $ | 101 |  |  | $ | 315 |  |
| Short-term lease expense | 18 |  |  | 51 |  |
| Variable lease expense | 37 |  |  | 116 |  |
| Total lease expense | $ | 156 |  |  | $ | 482 |  |

[0000858877-20-000006:notes:91]
[same as prior period, unchanged from 0000858877-20-000004:notes:90]

[0000858877-20-000006:notes:92]
|  | Nine Months Ended |
| In millions: | April 25, 2020 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 309 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 120 |  |

[0000858877-20-000006:notes:93]
The maturities of our operating leases (undiscounted) as of April 25, 2020 are as follows (in millions):

[0000858877-20-000006:notes:94]
| Fiscal Year | Amount |
| 2020 (remaining three months) | $ | 100 |  |
| 2021 | 328 |  |
| 2022 | 221 |  |
| 2023 | 171 |  |
| 2024 | 104 |  |
| Thereafter | 109 |  |
| Total lease payments | 1,033 |  |
| Less interest | (35 | ) |
| Total | $ | 998 |  |

[0000858877-20-000006:notes:95]
[same as prior period, unchanged from 0000858877-20-000004:notes:94]

[0000858877-20-000006:notes:96]
[same as prior period, unchanged from 0000858877-20-000004:notes:95]

[0000858877-20-000006:notes:97]
[same as prior period, unchanged from 0000858877-20-000004:notes:96]

[0000858877-20-000006:notes:98]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income for the third quarter and first nine months of fiscal 2020 was $23 million and $72 million, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-20-000006:notes:99]
Future minimum lease payments on our lease receivables as of April 25, 2020 are summarized as follows (in millions):

[0000858877-20-000006:notes:100]
| Fiscal Year | Amount |
| 2020 (remaining three months) | $ | 207 |  |
| 2021 | 923 |  |
| 2022 | 517 |  |
| 2023 | 302 |  |
| 2024 | 149 |  |
| Thereafter | 71 |  |
| Total | 2,169 |  |
| Less: Present value of lease payments | 2,048 |  |
| Difference between undiscounted cash flows and discounted cash flows | $ | 121 |  |

[0000858877-20-000006:notes:101]
[same as prior period, unchanged from 0000858877-20-000004:notes:100]

[0000858877-20-000006:notes:102]
[same as prior period, unchanged from 0000858877-20-000004:notes:101]

[0000858877-20-000006:notes:103]
[same as prior period, unchanged from 0000858877-20-000004:notes:102]

[0000858877-20-000006:notes:104]
[same as prior period, unchanged from 0000858877-20-000004:notes:103]

[0000858877-20-000006:notes:105]
|  | April 25, 2020 |  | July 27, 2019 |
| Operating lease assets | $ | 348 |  |  | $ | 485 |  |
| Accumulated depreciation | (197 | ) |  | (306 | ) |
| Operating lease assets, net | $ | 151 |  |  | $ | 179 |  |

[0000858877-20-000006:notes:106]
Our lease income for the third quarter and first nine months of fiscal 2020 was $49 million and $143 million, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-20-000006:notes:107]
Minimum future rentals on noncancelable operating leases as of April 25, 2020 are summarized as follows (in millions):

[0000858877-20-000006:notes:108]
| Fiscal Year | Amount |
| 2020 (remaining three months) | $ | 30 |  |
| 2021 | 74 |  |
| 2022 | 28 |  |
| 2023 | 6 |  |
| Total | $ | 138 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-20-000006:notes:109]
[same as prior period, unchanged from 0000858877-20-000004:notes:108]

[0000858877-20-000006:notes:110]
[same as prior period, unchanged from 0000858877-20-000004:notes:109]

[0000858877-20-000006:notes:111]
[same as prior period, unchanged from 0000858877-20-000004:notes:110]

[0000858877-20-000006:notes:112]
[same as prior period, unchanged from 0000858877-20-000004:notes:111]

[0000858877-20-000006:notes:113]
| April 25, 2020 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,169 |  |  | $ | 5,259 |  |  | $ | 2,167 |  |  | $ | 9,595 |  |
| Residual value | 127 |  |  | — |  |  | — |  |  | 127 |  |
| Unearned income | (121 | ) |  | — |  |  | — |  |  | (121 | ) |
| Allowance for credit loss | (36 | ) |  | (86 | ) |  | (6 | ) |  | (128 | ) |
| Total, net | $ | 2,139 |  |  | $ | 5,173 |  |  | $ | 2,161 |  |  | $ | 9,473 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 963 |  |  | $ | 2,474 |  |  | $ | 1,266 |  |  | $ | 4,703 |  |
| Noncurrent | 1,176 |  |  | 2,699 |  |  | 895 |  |  | 4,770 |  |
| Total, net | $ | 2,139 |  |  | $ | 5,173 |  |  | $ | 2,161 |  |  | $ | 9,473 |  |

[0000858877-20-000006:notes:114]
[same as prior period, unchanged from 0000858877-20-000004:notes:113]

[0000858877-20-000006:notes:115]
[same as prior period, unchanged from 0000858877-20-000004:notes:114]

[0000858877-20-000006:notes:116]
Gross receivables, excluding residual value, less unearned income categorized by our internal credit risk rating as of April 25, 2020 and July 27, 2019 are summarized as follows (in millions):

[0000858877-20-000006:notes:117]
|  | INTERNAL CREDIT RISK RATING |
| April 25, 2020 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,033 |  |  | $ | 969 |  |  | $ | 46 |  |  | $ | 2,048 |  |
| Loan receivables | 3,180 |  |  | 1,914 |  |  | 165 |  |  | 5,259 |  |
| Financed service contracts | 1,227 |  |  | 911 |  |  | 29 |  |  | 2,167 |  |
| Total | $ | 5,440 |  |  | $ | 3,794 |  |  | $ | 240 |  |  | $ | 9,474 |  |

[0000858877-20-000006:notes:118]
[same as prior period, unchanged from 0000858877-20-000004:notes:117]

[0000858877-20-000006:notes:119]
[same as prior period, unchanged from 0000858877-20-000004:notes:118]

[0000858877-20-000006:notes:120]
[same as prior period, unchanged from 0000858877-20-000004:notes:119]

[0000858877-20-000006:notes:121]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of April 25, 2020 and July 27, 2019 (in millions):

[0000858877-20-000006:notes:122]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| April 25, 2020 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 81 |  |  | $ | 18 |  |  | $ | 119 |  |  | $ | 218 |  |  | $ | 1,830 |  |  | $ | 2,048 |  |  | $ | 18 |  |  | $ | 18 |  |
| Loan receivables | 146 |  |  | 43 |  |  | 139 |  |  | 328 |  |  | 4,931 |  |  | 5,259 |  |  | 60 |  |  | 60 |  |
| Financed service contracts | 77 |  |  | 62 |  |  | 180 |  |  | 319 |  |  | 1,848 |  |  | 2,167 |  |  | 3 |  |  | 3 |  |
| Total | $ | 304 |  |  | $ | 123 |  |  | $ | 438 |  |  | $ | 865 |  |  | $ | 8,609 |  |  | $ | 9,474 |  |  | $ | 81 |  |  | $ | 81 |  |

[0000858877-20-000006:notes:123]
[same as prior period, unchanged from 0000858877-20-000004:notes:122]

[0000858877-20-000006:notes:124]
[same as prior period, unchanged from 0000858877-20-000004:notes:123]

[0000858877-20-000006:notes:125]
As of April 25, 2020, we had financing receivables of $116 million, net of unbilled or current receivables, that were greater than 120 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $215 million as of July 27, 2019.

[0000858877-20-000006:notes:126]
[same as prior period, unchanged from 0000858877-20-000004:notes:125]

[0000858877-20-000006:notes:127]
[same as prior period, unchanged from 0000858877-20-000004:notes:126]

[0000858877-20-000006:notes:128]
| Three months ended April 25, 2020 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of January 25, 2020 | $ | 42 |  |  | $ | 95 |  |  | $ | 8 |  |  | $ | 145 |  |
| Provisions (benefits) | (4 | ) |  | (5 | ) |  | (2 | ) |  | (11 | ) |
| Recoveries (write-offs), net | (1 | ) |  | (1 | ) |  | — |  |  | (2 | ) |
| Foreign exchange and other | (1 | ) |  | (3 | ) |  | — |  |  | (4 | ) |
| Allowance for credit loss as of April 25, 2020 | $ | 36 |  |  | $ | 86 |  |  | $ | 6 |  |  | $ | 128 |  |

[0000858877-20-000006:notes:129]
| Nine months ended April 25, 2020 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 27, 2019 | $ | 46 |  |  | $ | 71 |  |  | $ | 9 |  |  | $ | 126 |  |
| Provisions (benefits) | (8 | ) |  | 37 |  |  | (2 | ) |  | 27 |  |
| Recoveries (write-offs), net | (2 | ) |  | (18 | ) |  | — |  |  | (20 | ) |
| Foreign exchange and other | — |  |  | (4 | ) |  | (1 | ) |  | (5 | ) |
| Allowance for credit loss as of April 25, 2020 | $ | 36 |  |  | $ | 86 |  |  | $ | 6 |  |  | $ | 128 |  |

[0000858877-20-000006:notes:130]
| Three months ended April 27, 2019 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of January 26, 2019 | $ | 127 |  |  | $ | 64 |  |  | $ | 9 |  |  | $ | 200 |  |
| Provisions (benefits) | (41 | ) |  | 13 |  |  | 27 |  |  | (1 | ) |
| Recoveries (write-offs), net | 2 |  |  | — |  |  | (28 | ) |  | (26 | ) |
| Foreign exchange and other | (20 | ) |  | — |  |  | — |  |  | (20 | ) |
| Allowance for credit loss as of April 27, 2019 | $ | 68 |  |  | $ | 77 |  |  | $ | 8 |  |  | $ | 153 |  |

[0000858877-20-000006:notes:131]
| Nine months ended April 27, 2019 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 28, 2018 | $ | 135 |  |  | $ | 60 |  |  | $ | 10 |  |  | $ | 205 |  |
| Provisions (benefits) | (48 | ) |  | 17 |  |  | 26 |  |  | (5 | ) |
| Recoveries (write-offs), net | 2 |  |  | — |  |  | (28 | ) |  | (26 | ) |
| Foreign exchange and other | (21 | ) |  | — |  |  | — |  |  | (21 | ) |
| Allowance for credit loss as of April 27, 2019 | $ | 68 |  |  | $ | 77 |  |  | $ | 8 |  |  | $ | 153 |  |

[0000858877-20-000006:notes:132]
[same as prior period, unchanged from 0000858877-20-000004:notes:131]

[0000858877-20-000006:notes:133]
Typically, we also consider receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. These balances, as of April 25, 2020 and July 27, 2019, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-20-000006:notes:134]
We evaluate the remainder of our financing receivables portfolio for impairment on a collective basis and record an allowance for credit loss at the portfolio segment level. When evaluating the financing receivables on a collective basis, we use expected default frequency rates published by a major third-party credit-rating agency as well as our own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk, and correlation.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-20-000006:notes:135]
Available-for-Sale Debt Investments and Equity Investments

[0000858877-20-000006:notes:136]
The following table summarizes our available-for-sale debt investments and equity investments (in millions):

[0000858877-20-000006:notes:137]
|  | April 25, 2020 |  | July 27, 2019 |
| Available-for-sale debt investments | $ | 18,208 |  |  | $ | 21,660 |  |
| Marketable equity securities | — |  |  | 3 |  |
| Total investments | 18,208 |  |  | 21,663 |  |
| Non-marketable equity securities included in other assets | 1,186 |  |  | 1,113 |  |
| Equity method investments included in other assets | 68 |  |  | 87 |  |
| Total | $ | 19,462 |  |  | $ | 22,863 |  |

[0000858877-20-000006:notes:138]
| (a) | Summary of Available-for-Sale Debt Investments |

[0000858877-20-000006:notes:139]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-20-000006:notes:140]
| April 25, 2020 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 2,527 |  |  | $ | 83 |  |  | $ | — |  |  | $ | 2,610 |  |
| U.S. government agency securities | 54 |  |  | — |  |  | — |  |  | 54 |  |
| Corporate debt securities | 12,291 |  |  | 172 |  |  | (86 | ) |  | 12,377 |  |
| U.S. agency mortgage-backed securities | 1,617 |  |  | 50 |  |  | — |  |  | 1,667 |  |
| Commercial paper | 1,272 |  |  | — |  |  | — |  |  | 1,272 |  |
| Certificates of deposit | 228 |  |  | — |  |  | — |  |  | 228 |  |
| Total (1) | $ | 17,989 |  |  | $ | 305 |  |  | $ | (86 | ) |  | $ | 18,208 |  |

[0000858877-20-000006:notes:141]
| July 27, 2019 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| U.S. government securities | $ | 808 |  |  | $ | 1 |  |  | $ | (1 | ) |  | $ | 808 |  |
| U.S. government agency securities | 169 |  |  | — |  |  | — |  |  | 169 |  |
| Corporate debt securities | 19,188 |  |  | 103 |  |  | (29 | ) |  | 19,262 |  |
| U.S. agency mortgage-backed securities | 1,425 |  |  | 7 |  |  | (11 | ) |  | 1,421 |  |
| Total | $ | 21,590 |  |  | $ | 111 |  |  | $ | (41 | ) |  | $ | 21,660 |  |

[0000858877-20-000006:notes:142]
(1) Net unsettled investment sales were $12 million as of April 25, 2020 and were included in other current assets.

[0000858877-20-000006:notes:143]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-20-000006:notes:144]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Gross realized gains | $ | 20 |  |  | $ | 7 |  |  | $ | 45 |  |  | $ | 10 |  |
| Gross realized losses | (21 | ) |  | (14 | ) |  | (25 | ) |  | (28 | ) |
| Total | $ | (1 | ) |  | $ | (7 | ) |  | $ | 20 |  |  | $ | (18 | ) |

[0000858877-20-000006:notes:145]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 25, 2020 and July 27, 2019 (in millions):

[0000858877-20-000006:notes:146]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 25, 2020 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 26 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |
| U.S. government agency securities | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Corporate debt securities | 3,529 |  |  | (86 | ) |  | 23 |  |  | — |  |  | 3,552 |  |  | (86 | ) |
| U.S. agency mortgage-backed securities | 19 |  |  | — |  |  | — |  |  | — |  |  | 19 |  |  | — |  |
| Commercial paper | 1,013 |  |  | — |  |  | — |  |  | — |  |  | 1,013 |  |  | — |  |
| Certificates of deposit | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Total | $ | 4,607 |  |  | $ | (86 | ) |  | $ | 23 |  |  | $ | — |  |  | $ | 4,630 |  |  | $ | (86 | ) |

[0000858877-20-000006:notes:147]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2019 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 204 |  |  | $ | — |  |  | $ | 488 |  |  | $ | (1 | ) |  | $ | 692 |  |  | $ | (1 | ) |
| U.S. government agency securities | — |  |  | — |  |  | 169 |  |  | — |  |  | 169 |  |  | — |  |
| Corporate debt securities | 2,362 |  |  | (4 | ) |  | 5,271 |  |  | (25 | ) |  | 7,633 |  |  | (29 | ) |
| U.S. agency mortgage-backed securities | 123 |  |  | — |  |  | 847 |  |  | (11 | ) |  | 970 |  |  | (11 | ) |
| Total | $ | 2,689 |  |  | $ | (4 | ) |  | $ | 6,775 |  |  | $ | (37 | ) |  | $ | 9,464 |  |  | $ | (41 | ) |

[0000858877-20-000006:notes:148]
For available-for-sale debt investments that were in an unrealized loss position as of April 25, 2020, we have determined that no other-than-temporary impairments were required to be recognized.

[0000858877-20-000006:notes:149]
The following table summarizes the maturities of our available-for-sale debt investments as of April 25, 2020 (in millions):

[0000858877-20-000006:notes:150]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 6,277 |  |  | $ | 6,292 |  |
| After 1 year through 5 years | 8,014 |  |  | 8,065 |  |
| After 5 years through 10 years | 2,073 |  |  | 2,176 |  |
| After 10 years | 8 |  |  | 8 |  |
| Mortgage-backed securities with no single maturity | 1,617 |  |  | 1,667 |  |
| Total | $ | 17,989 |  |  | $ | 18,208 |  |

[0000858877-20-000006:notes:151]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-20-000006:notes:152]
| (b) | Summary of Equity Investments |

[0000858877-20-000006:notes:153]
Gains and losses recognized on our marketable and non-marketable equity securities are summarized below (in millions):

[0000858877-20-000006:notes:154]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Net gains and losses recognized during the period on equity investments | $ | (7 | ) |  | $ | 3 |  |  | $ | 71 |  |  | $ | 78 |  |
| Less: Net gains and losses recognized on equity investments sold | 3 |  |  | (44 | ) |  | (71 | ) |  | (51 | ) |
| Net unrealized gains and losses recognized during reporting period on equity securities still held at the reporting date | $ | (4 | ) |  | $ | (41 | ) |  | $ | — |  |  | $ | 27 |  |

[0000858877-20-000006:notes:155]
We recorded adjustments to the carrying value of our non-marketable equity securities measured using the measurement alternative as follows (in millions):

[0000858877-20-000006:notes:156]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Adjustments to non-marketable equity securities measured using the measurement alternative: |  |  |  |  |  |  |  |
| Upward adjustments | $ | 9 |  |  | $ | 9 |  |  | $ | 20 |  |  | $ | 25 |  |
| Downward adjustments, including impairments | (13 | ) |  | (4 | ) |  | (21 | ) |  | (22 | ) |
| Net adjustments | $ | (4 | ) |  | $ | 5 |  |  | $ | (1 | ) |  | $ | 3 |  |

[0000858877-20-000006:notes:157]
As of April 25, 2020 and July 27, 2019, we held equity interests in certain private equity funds of $0.7 billion and $0.6 billion, respectively, which are accounted for under the NAV practical expedient.

[0000858877-20-000006:notes:158]
| (c) | Variable Interest Entities |

[0000858877-20-000006:notes:159]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 25, 2020, except as disclosed herein, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-20-000006:notes:160]
As of April 25, 2020, the carrying value of investments in privately held companies was $1.3 billion. $691 million of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $344 million related to these privately held investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent our maximum exposure related to these privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-20-000006:notes:161]
[same as prior period, unchanged from 0000858877-20-000004:notes:161]

[0000858877-20-000006:notes:162]
[same as prior period, unchanged from 0000858877-20-000004:notes:162]

[0000858877-20-000006:notes:163]
[same as prior period, unchanged from 0000858877-20-000004:notes:163]

[0000858877-20-000006:notes:164]
[same as prior period, unchanged from 0000858877-20-000004:notes:164]

[0000858877-20-000006:notes:165]
[same as prior period, unchanged from 0000858877-20-000004:notes:165]

[0000858877-20-000006:notes:166]
[same as prior period, unchanged from 0000858877-20-000004:notes:166]

[0000858877-20-000006:notes:167]
[same as prior period, unchanged from 0000858877-20-000004:notes:167]

[0000858877-20-000006:notes:168]
[same as prior period, unchanged from 0000858877-20-000004:notes:168]

[0000858877-20-000006:notes:169]
|  | APRIL 25, 2020FAIR VALUE MEASUREMENTS |  | JULY 27, 2019FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 8,829 |  |  | $ | — |  |  | $ | 8,829 |  |  | $ | 10,083 |  |  | $ | — |  |  | $ | 10,083 |  |
| Commercial paper | — |  |  | 189 |  |  | 189 |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposit | — |  |  | 20 |  |  | 20 |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 2,610 |  |  | 2,610 |  |  | — |  |  | 808 |  |  | 808 |  |
| U.S. government agency securities | — |  |  | 54 |  |  | 54 |  |  | — |  |  | 169 |  |  | 169 |  |
| Corporate debt securities | — |  |  | 12,377 |  |  | 12,377 |  |  | — |  |  | 19,262 |  |  | 19,262 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,667 |  |  | 1,667 |  |  | — |  |  | 1,421 |  |  | 1,421 |  |
| Commercial paper | — |  |  | 1,272 |  |  | 1,272 |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposit | — |  |  | 228 |  |  | 228 |  |  | — |  |  | — |  |  | — |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Derivative assets | — |  |  | 200 |  |  | 200 |  |  | — |  |  | 89 |  |  | 89 |  |
| Total | $ | 8,829 |  |  | $ | 18,617 |  |  | $ | 27,446 |  |  | $ | 10,086 |  |  | $ | 21,749 |  |  | $ | 31,835 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 22 |  |  | $ | 22 |  |  | $ | — |  |  | $ | 15 |  |  | $ | 15 |  |
| Total | $ | — |  |  | $ | 22 |  |  | $ | 22 |  |  | $ | — |  |  | $ | 15 |  |  | $ | 15 |  |

[0000858877-20-000006:notes:170]
[same as prior period, unchanged from 0000858877-20-000004:notes:170]

[0000858877-20-000006:notes:171]
[same as prior period, unchanged from 0000858877-20-000004:notes:171]

[0000858877-20-000006:notes:172]
The carrying value of our non-marketable equity securities recorded to fair value on a non-recurring basis is adjusted for observable transactions for identical or similar investments of the same issuer or impairment. These securities are classified as Level 3 in the fair value hierarchy because we estimate the value based on valuation methods using the observable transaction price at the transaction date and other unobservable inputs such as volatility, rights, and obligations of the securities we hold.

[0000858877-20-000006:notes:173]
The fair value for purchased intangible assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation. Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating

[0000858877-20-000006:notes:174]
expenses as applicable. See Note 5. The remaining carrying value of the specific purchased intangible assets that were impaired was zero as of April 25, 2020.

[0000858877-20-000006:notes:175]
[same as prior period, unchanged from 0000858877-20-000004:notes:176]

[0000858877-20-000006:notes:176]
The fair value of short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of long-term loan receivables and financed service contracts as of April 25, 2020 and July 27, 2019 was $3.6 billion and $3.7 billion, respectively. The estimated fair value of long-term loan receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.
As of April 25, 2020, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of April 25, 2020, the fair value of our senior notes and other long-term debt was $18.5 billion with a carrying amount of $16.1 billion. This compares to a fair value of $22.1 billion and a carrying amount of $20.5 billion as of July 27, 2019. The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:DebtDisclosureTextBlock

[0000858877-20-000006:notes:177]
Borrowings

[0000858877-20-000006:notes:178]
| (a) | Short-Term Debt |

[0000858877-20-000006:notes:179]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-20-000006:notes:180]
|  | April 25, 2020 |  | July 27, 2019 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,506 |  |  | 2.32 | % |  | $ | 5,998 |  |  | 3.20 | % |
| Commercial paper | — |  |  | — |  |  | 4,193 |  |  | 2.34 | % |
| Total short-term debt | $ | 4,506 |  |  |  |  | $ | 10,191 |  |  |  |

[0000858877-20-000006:notes:181]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-20-000006:notes:182]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-20-000006:notes:183]
| (b) | Long-Term Debt |

[0000858877-20-000006:notes:184]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-20-000006:notes:185]
|  |  |  | April 25, 2020 |  | July 27, 2019 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.77% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | September 20, 2019 |  | — |  |  | — |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | — |  |  | — |  | 2,500 |  |  | 4.72% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.76% |  | 500 |  |  | 3.14% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.85% |  | 500 |  |  | 3.36% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.87% |  | 1,000 |  |  | 3.25% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.01% |  | 500 |  |  | 3.52% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 16,000 |  |  |  |  | 20,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (90 | ) |  |  |  | (100 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 174 |  |  |  |  | 73 |  |  |  |
| Total |  |  | $ | 16,084 |  |  |  |  | $ | 20,473 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,506 |  |  |  |  | $ | 5,998 |  |  |  |
| Long-term debt |  |  | 11,578 |  |  |  |  | 14,475 |  |  |  |
| Total |  |  | $ | 16,084 |  |  |  |  | $ | 20,473 |  |  |  |

[0000858877-20-000006:notes:186]
We entered into interest rate swaps in prior periods with an aggregate notional amount of $2.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (“LIBOR”). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-20-000006:notes:187]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 25, 2020, we were in compliance with all debt covenants.

[0000858877-20-000006:notes:188]
As of April 25, 2020, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-20-000006:notes:189]
| Fiscal Year | Amount |
| 2020 (remaining three months) | $ | 1,500 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| Thereafter | 6,750 |  |
| Total | $ | 16,000 |  |

[0000858877-20-000006:notes:190]
| (c) | Credit Facility |

[0000858877-20-000006:notes:191]
On May 15, 2020, we entered into a 364-day credit agreement with certain institutional lenders that provides for a $2.75 billion unsecured revolving credit facility that is scheduled to expire on May 14, 2021. The credit agreement is structured as an amendment and restatement of our five-year credit facility which would have terminated on May 15, 2020, the end of its five-year term. As of April 25, 2020, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the five-year credit facility. 
Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than 0.25%. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-20-000006:notes:192]
[same as prior period, unchanged from 0000858877-20-000004:notes:194]

[0000858877-20-000006:notes:193]
[same as prior period, unchanged from 0000858877-20-000004:notes:195]

[0000858877-20-000006:notes:194]
[same as prior period, unchanged from 0000858877-20-000004:notes:196]

[0000858877-20-000006:notes:195]
[same as prior period, unchanged from 0000858877-20-000004:notes:197]

[0000858877-20-000006:notes:196]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | April 25, 2020 |  | July 27, 2019 |  | Balance Sheet Line Item |  | April 25, 2020 |  | July 27, 2019 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 16 |  |  | $ | 5 |  |  | Other current liabilities |  | $ | 3 |  |  | $ | 8 |  |
| Interest rate derivatives | Other current assets |  | 9 |  |  | — |  |  | Other current liabilities |  | — |  |  | 1 |  |
| Interest rate derivatives | Other assets |  | 170 |  |  | 75 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 195 |  |  | 80 |  |  |  |  | 3 |  |  | 9 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 5 |  |  | 9 |  |  | Other current liabilities |  | 18 |  |  | 6 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 1 |  |  | — |  |
| Total |  |  | 5 |  |  | 9 |  |  |  |  | 19 |  |  | 6 |  |
| Total |  |  | $ | 200 |  |  | $ | 89 |  |  |  |  | $ | 22 |  |  | $ | 15 |  |

[0000858877-20-000006:notes:197]
[same as prior period, unchanged from 0000858877-20-000004:notes:199]

[0000858877-20-000006:notes:198]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | April 25, 2020 |  | July 27, 2019 |  | April 25, 2020 |  | July 27, 2019 |
| Short-term debt |  | $ | (508 | ) |  | $ | (2,000 | ) |  | $ | (8 | ) |  | $ | — |  |
| Long-term debt |  | $ | (2,160 | ) |  | $ | (2,565 | ) |  | $ | (166 | ) |  | $ | (73 | ) |

[0000858877-20-000006:notes:199]
[same as prior period, unchanged from 0000858877-20-000004:notes:201]

[0000858877-20-000006:notes:200]
[same as prior period, unchanged from 0000858877-20-000004:notes:202]

[0000858877-20-000006:notes:201]
|  | April 25, 2020 |
|  | Three Months Ended |  | Nine Months Ended |
|  | Revenue |  | Cost of sales |  | Operating expenses |  | Interest and other income (loss), net |  | Revenue |  | Cost of sales |  | Operating expenses |  | Interest and other income (loss), net |
| Total amounts presented in the Consolidated Statements of Operations in which the effects of fair value or cash flow hedges are recorded | $ | 11,983 |  |  | $ | 4,212 |  |  | $ | 4,357 |  |  | $ | 30 |  |  | $ | 37,147 |  |  | $ | 13,148 |  |  | $ | 13,626 |  |  | $ | 291 |  |
| The effects of fair value and cash flow hedging: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gains (losses) on fair value hedging relationships: |
| Interest rate derivatives |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hedged items | — |  |  | — |  |  | — |  |  | (87 | ) |  | — |  |  | — |  |  | — |  |  | (101 | ) |
| Derivatives designated as hedging instruments | — |  |  | — |  |  | — |  |  | 89 |  |  | — |  |  | — |  |  | — |  |  | 105 |  |
| Gains (losses) on cash flow hedging relationships: |
| Foreign currency derivatives |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amount of gains (losses) reclassified from AOCI to income | 1 |  |  | — |  |  | — |  |  | — |  |  | (4 | ) |  | 1 |  |  | 2 |  |  | — |  |
| Total gains (losses) | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | (4 | ) |  | $ | 1 |  |  | $ | 2 |  |  | $ | 4 |  |

[0000858877-20-000006:notes:202]
|  | April 27, 2019 |
|  | Three Months Ended |  | Nine Months Ended |
|  | Revenue |  | Cost of sales |  | Operating expenses |  | Interest and other income (loss), net |  | Revenue |  | Cost of sales |  | Operating expenses |  | Interest and other income (loss), net |
| Total amounts presented in the Consolidated Statements of Operations in which the effects of fair value or cash flow hedges are recorded | $ | 12,958 |  |  | $ | 4,785 |  |  | $ | 4,660 |  |  | $ | 102 |  |  | $ | 38,476 |  |  | $ | 14,384 |  |  | $ | 13,563 |  |  | $ | 338 |  |
| The effects of fair value and cash flow hedging: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gains (losses) on fair value hedging relationships: |
| Interest rate derivatives |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hedged items | — |  |  | — |  |  | — |  |  | (31 | ) |  | — |  |  | — |  |  | — |  |  | (83 | ) |
| Derivatives designated as hedging instruments | — |  |  | — |  |  | — |  |  | 33 |  |  | — |  |  | — |  |  | — |  |  | 88 |  |
| Gains (losses) on cash flow hedging relationships: |
| Foreign currency derivatives |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amount of gains (losses) reclassified from AOCI to income | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | (1 | ) |  | (1 | ) |  | — |  |
| Total gains (losses) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | (1 | ) |  | $ | (1 | ) |  | $ | 5 |  |

[0000858877-20-000006:notes:203]
[same as prior period, unchanged from 0000858877-20-000004:notes:205]

[0000858877-20-000006:notes:204]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES) FOR THENINE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (47 | ) |  | $ | (29 | ) |  | $ | (56 | ) |  | $ | (57 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | (93 | ) |  | 42 |  |  | (49 | ) |  | 9 |  |
|  |  | Cost of sales |  | (9 | ) |  | 4 |  |  | (5 | ) |  | 1 |  |
|  |  | Other income (loss), net |  | (2 | ) |  | (4 | ) |  | (9 | ) |  | (12 | ) |
| Equity derivatives |  | Other income (loss), net |  | (6 | ) |  | 1 |  |  | (1 | ) |  | 2 |  |
| Total |  |  |  | $ | (157 | ) |  | $ | 14 |  |  | $ | (120 | ) |  | $ | (57 | ) |

[0000858877-20-000006:notes:205]
[same as prior period, unchanged from 0000858877-20-000004:notes:207]

[0000858877-20-000006:notes:206]
|  | April 25, 2020 |  | July 27, 2019 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 610 |  |  | $ | 663 |  |
| Interest rate derivatives | 2,500 |  |  | 4,500 |  |
| Net investment hedging instruments | 210 |  |  | 309 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,645 |  |  | 2,708 |  |
| Total return swaps—deferred compensation | 508 |  |  | 574 |  |
| Total | $ | 6,473 |  |  | $ | 8,754 |  |

[0000858877-20-000006:notes:207]
[same as prior period, unchanged from 0000858877-20-000004:notes:209]

[0000858877-20-000006:notes:208]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty. As of April 25, 2020 and July 27, 2019, the potential effects of these rights of set-off associated with the derivative contracts would be a reduction to both derivative assets and derivative liabilities of $18 million and $13 million, respectively.

[0000858877-20-000006:notes:209]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral received as of April 25, 2020 and July 27, 2019 was $178 million and $76 million, respectively. Including the effects of collateral, this results in a net derivative liability of $2 million as of July 27, 2019.

[0000858877-20-000006:notes:210]
[same as prior period, unchanged from 0000858877-20-000004:notes:212]

[0000858877-20-000006:notes:211]
[same as prior period, unchanged from 0000858877-20-000004:notes:213]

[0000858877-20-000006:notes:212]
We hedge forecasted foreign currency transactions related to certain revenues, operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The derivative instrument’s gain or loss is initially reported as a component of accumulated other comprehensive income (“AOCI”) and subsequently reclassified into earnings when the hedged exposure affects earnings. During the periods presented, we did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-20-000006:notes:213]
[same as prior period, unchanged from 0000858877-20-000004:notes:215]

[0000858877-20-000006:notes:214]
[same as prior period, unchanged from 0000858877-20-000004:notes:216]

[0000858877-20-000006:notes:215]
[same as prior period, unchanged from 0000858877-20-000004:notes:217]

[0000858877-20-000006:notes:216]
[same as prior period, unchanged from 0000858877-20-000004:notes:218]

[0000858877-20-000006:notes:217]
[same as prior period, unchanged from 0000858877-20-000004:notes:219]

[0000858877-20-000006:notes:218]
[same as prior period, unchanged from 0000858877-20-000004:notes:220]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-20-000006:notes:219]
Commitments and Contingencies

[0000858877-20-000006:notes:220]
| (a) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-20-000006:notes:221]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. As of April 25, 2020 and July 27, 2019, we had total purchase commitments for inventory of $5.1 billion and $5.0 billion, respectively.

[0000858877-20-000006:notes:222]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 25, 2020 and July 27, 2019, the liability for these purchase commitments was $131 million and $129 million, respectively, and was included in other current liabilities.

[0000858877-20-000006:notes:223]
| (b) | Other Commitments |

[0000858877-20-000006:notes:224]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-20-000006:notes:225]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-20-000006:notes:226]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Compensation expense related to acquisitions | $ | 61 |  |  | $ | 76 |  |  | $ | 172 |  |  | $ | 251 |  |

[0000858877-20-000006:notes:227]
As of April 25, 2020, we estimated that future cash compensation expense of up to $292 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-20-000006:notes:228]
We also have certain funding commitments, primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $344 million and $326 million as of April 25, 2020 and July 27, 2019, respectively.

[0000858877-20-000006:notes:229]
| (c) | Product Warranties |

[0000858877-20-000006:notes:230]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-20-000006:notes:231]
|  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |
| Balance at beginning of period | $ | 342 |  |  | $ | 359 |  |
| Provisions for warranties issued | 423 |  |  | 447 |  |
| Adjustments for pre-existing warranties | (5 | ) |  | (6 | ) |
| Settlements | (436 | ) |  | (449 | ) |
| Acquisitions and divestitures | — |  |  | (2 | ) |
| Balance at end of period | $ | 324 |  |  | $ | 349 |  |

[0000858877-20-000006:notes:232]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-20-000006:notes:233]
| (d) | Financing and Other Guarantees |

[0000858877-20-000006:notes:234]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-20-000006:notes:235]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. At the end of the third quarter of fiscal 2020, we expanded the payment terms on certain of our channel partner financing programs by 30 days in response to the COVID-19 pandemic environment. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.3 billion and $7.2 billion for the third quarter of fiscal 2020 and 2019, respectively, and was $20.5 billion and $21.7 billion for the first nine months of fiscal 2020 and 2019, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.4 billion as of April 25, 2020 and July 27, 2019, respectively.

[0000858877-20-000006:notes:236]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $2 million and $1 million for the third quarter of fiscal 2020 and 2019, respectively, and was $8 million and $11 million for the first nine months of fiscal 2020 and 2019, respectively.

[0000858877-20-000006:notes:237]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 25, 2020 and July 27, 2019, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-20-000006:notes:238]
|  | April 25, 2020 |  | July 27, 2019 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 203 |  |  | $ | 197 |  |
| End user | 12 |  |  | 21 |  |
| Total | $ | 215 |  |  | $ | 218 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (59 | ) |  | $ | (62 | ) |
| End user | (11 | ) |  | (15 | ) |
| Total | $ | (70 | ) |  | $ | (77 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 145 |  |  | $ | 141 |  |

[0000858877-20-000006:notes:239]
| (e) | Indemnifications |

[0000858877-20-000006:notes:240]
In the normal course of business, we indemnify other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-20-000006:notes:241]
Charter Communications, Inc. (“Charter”), which acquired Time Warner Cable (“TWC”) in May 2016, is seeking indemnification from us for a final judgment obtained by Sprint Communications Company, L.P. (“Sprint”) against TWC in federal court in Kansas. Sprint sought monetary damages, alleging that TWC infringed certain Sprint patents by offering VoIP telephone services utilizing products provided by us generally in combination with those of other manufacturers. Following a trial on March 3, 2017, a jury in Kansas found that TWC willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. The Court awarded Sprint pre and post judgment interest of approximately $10 million and denied TWC’s post-trial motions and appeals. Charter reported that it paid the judgment in full. At this time, we are working with Charter to calculate the correct amount of indemnification. We do not believe that our indemnity obligations under our agreement will be material.

[0000858877-20-000006:notes:242]
We also have been asked to indemnify certain of our service provider customers that have been subject to patent infringement claims asserted by Chanbond, LLC (“Chanbond”) in the United States District Court for the District of Delaware on September 21, 2015. Chanbond alleges that 13 service provider companies, including among others, Comcast Corporation (“Comcast”), Charter Communications, Inc. (“Charter”), Time Warner Cable, Inc. (“TWC”) (subsequently acquired by Charter), Cox Communications, Inc. (“Cox”), and Cablevision Systems Corporation (“Cablevision”), infringe three patents by providing high speed cable internet services to their customers utilizing cable modems and cable modem termination systems, consistent with the DOCSIS 3.0 standard, provided by us and other manufacturers generally used in combination with each other. Chanbond seeks monetary damages. Chanbond's case against Cox is currently set for a jury trial starting on August 18, 2020, and the other cases against the remaining service provider defendants have not yet been set for trial. We believe that the service provider defendants have strong non-infringement, invalidity and other defenses. Due to uncertainties surrounding the litigation processes, we are unable to reasonably estimate the ultimate outcome of the cases at this time, but should Chanbond prevail in its cases against the service provider defendants, we do not believe that any potential indemnity liability would be material.

[0000858877-20-000006:notes:243]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-20-000006:notes:244]
It is not possible to determine the maximum potential amount under these indemnification agreements due to our limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by us under these agreements have not had a material effect on our operating results, financial position, or cash flows.

[0000858877-20-000006:notes:245]
| (f) | Legal Proceedings |

[0000858877-20-000006:notes:246]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-20-000006:notes:247]
During the second quarter of fiscal 2020, $0.8 billion of penalty and interest asserted by the Brazilian federal tax authorities against our Brazilian subsidiary on the theory of joint liability was dismissed on its merits. The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total remaining asserted claims by Brazilian state and federal tax authorities aggregate to $0.1 billion for the alleged evasion of import and other taxes, $0.7 billion for interest, and $0.4 billion for various penalties, all determined using an exchange rate as of April 25, 2020.

[0000858877-20-000006:notes:248]
We have completed a thorough review of the matters and believe the remaining asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-20-000006:notes:249]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against us in the U.S. District Court for the District of Delaware, accusing our products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial started on May 2, 2016, and, on May 12, 2016, the jury returned a verdict finding willful infringement. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the District Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. We appealed to the United States Court of Appeals for the Federal Circuit on various grounds, and after various proceedings, on July 12, 2019, the Federal Circuit vacated the enhanced damages award; vacated and remanded in part the willful infringement finding; vacated and remanded the attorneys’ fees award for further proceedings; and affirmed the District Court’s other findings. On April 1, 2020, the District Court issued a final judgment on the remanded issues, finding no evidence of willful infringement and reinstating the $8 million award of attorneys’ fees. SRI appealed the judgment of no willful infringement to the Federal Circuit on April 3, 2020, and Cisco filed a cross-appeal on the attorneys’ fees award on April 9, 2020. Cisco has paid SRI $28.1 million, representing the portion of the judgment that the Federal Circuit previously affirmed, plus interest and royalties on post-verdict sales. While the remaining proceedings may result in an additional loss, we do not expect it to be material.

[0000858877-20-000006:notes:250]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Centripetal alleges that several Cisco products and services (including Cisco’s Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal patents. Cisco thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has thus far issued Final Written Decisions for five patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and a portion of the claims of a sixth patent have been found unpatentable. The District Court set a bench trial by videoconference, which started on May 6, 2020, on the claims in the five patents not subject to the IPR Proceedings, including claims in three for which the PTAB declined to institute Inter Partes Review. While we believe that we have strong non-infringement defenses and that the patents are invalid, as well as other arguments and defenses, if we do not prevail in the District Court, we believe that Centripetal will not be able to meet its burden required for injunctive relief and that any final damages ultimately assessed would not be material. On May 4, 2020, Centripetal instituted an action in the District Court of Dusseldorf in Germany against Cisco Systems GmbH asserting three European patents seeking both injunctive relief and damages. Two of the three European patents are counterparts to two patents Centripetal has asserted against us in the U.S. District Court proceedings, one of which has been invalidated by the PTAB. We are currently assessing the case filed in Germany. Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, however, we are unable to reasonably estimate the ultimate outcome of this litigation at this time.

[0000858877-20-000006:notes:251]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, accusing our 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the District Court granted our motion for summary judgment of non-infringement, thereby dismissing Straight Path’s claims against us and cancelling a trial which had been set for March 12, 2018. Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit, and, on January 23, 2019, the District Court summarily affirmed the finding of non-infringement. On August 23, 2019, Straight Path filed a petition with the United States Supreme Court challenging the constitutionality of the Federal Circuit’s rule allowing summary affirmance, which was denied on November 18, 2019.

[0000858877-20-000006:notes:252]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the District Court consolidated the cases alleging infringement of the ‘327 Patent. Oyster's cases against some of the defendants were resolved. The District Court vacated the November 4, 2018 trial date set for Oyster's claims against Cisco and one other remaining defendant, pending resolution of Oyster’s December 6, 2018 appeal of the District Court's summary judgment ruling dismissing certain of Oyster’s claims. On May 8, 2020, the Federal Circuit affirmed the District Court’s summary judgment ruling. While we

[0000858877-20-000006:notes:253]
believe that the District Court's summary judgment ruling will continue to be upheld if subject to further challenge and we have strong defenses for Oyster's remaining claims, if Oyster seeks further review of the District Court's summary judgment ruling and it is reversed and the dismissed claims are remanded, and if we do not prevail in the District Court on those claims and Oyster's remaining claims in a subsequent trial, we believe damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, we are unable to reasonably estimate the ultimate outcome of this litigation at this time.

[0000858877-20-000006:notes:254]
Finjan     On January 6, 2017, Finjan, Inc. (“Finjan”) asserted patent infringement claims against us in the U.S. District Court for the Northern District of California, seeking injunctive relief and damages, including enhanced damages for allegations of willful infringement. Finjan alleges that Cisco’s AMP and ThreatGrid products and the URL rewrite feature of Cisco’s ESA Outbreak Filter product infringe five patents, four of which have expired. Finjan has conceded that they are not entitled to any pre-suit damages, accordingly it seeks approximately three weeks of damages for the alleged infringement of the 8,677,494 and 6,154,844 patents, approximately ten months of damages for the 6,804,780 patent, approximately three years of damages for the 7,647,633 patent, and approximately three-and-a-half years of past damages for the 8,141,154 patent and an ongoing royalty until its expiration on December 12, 2025. The case is currently set for jury trial starting June 22, 2020. While we believe that we have strong non-infringement arguments, that the patents are invalid, that Finjan’s damages theories are not supported by prevailing law and that Finjan will not be able to meet its burden required for injunctive relief, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in the District Court, we believe that any damages ultimately assessed would not be material.
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors-We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-20-000006:notes:255]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-20-000006:notes:256]
[same as prior period, unchanged from 0000858877-20-000004:notes:258]

[0000858877-20-000006:notes:257]
[same as prior period, unchanged from 0000858877-20-000004:notes:259]

[0000858877-20-000006:notes:258]
We declared and paid cash dividends of $0.36 and $0.35 per common share, or $1.5 billion, on our outstanding common stock for each of the third quarters of fiscal 2020 and 2019. We declared and paid cash dividends of $1.06 and $1.01 per common share, or $4.5 billion, on our outstanding common stock for each of the first nine months of fiscal 2020 and 2019.

[0000858877-20-000006:notes:259]
[same as prior period, unchanged from 0000858877-20-000004:notes:262]

[0000858877-20-000006:notes:260]
In September 2001, our Board of Directors authorized a stock repurchase program. As of April 25, 2020, the remaining authorized amount for stock repurchases under this program was approximately $10.8 billion with no termination date. A summary of the stock repurchase activity for fiscal 2020 and 2019 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-20-000006:notes:261]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2020 |  |  |  |  |  |  |
| April 25, 2020 |  | 25 |  |  | $ | 39.71 |  |  | $ | 981 |  |
| January 25, 2020 |  | 18 |  |  | $ | 46.71 |  |  | $ | 870 |  |
| October 26, 2019 |  | 16 |  |  | $ | 48.91 |  |  | $ | 768 |  |
| Fiscal 2019 |  |  |  |  |  |  |
| July 27, 2019 |  | 82 |  |  | $ | 54.99 |  |  | $ | 4,515 |  |
| April 27, 2019 |  | 116 |  |  | $ | 52.14 |  |  | $ | 6,020 |  |
| January 26, 2019 |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |
| October 27, 2018 |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |

[0000858877-20-000006:notes:262]
There were $40 million of stock repurchases that were pending settlement as of July 27, 2019.

[0000858877-20-000006:notes:263]
The purchase price for the shares of our stock repurchased is reflected as a reduction to shareholders’ equity. We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings/increase to accumulated deficit and (ii) a reduction of common stock and additional paid-in capital.

[0000858877-20-000006:notes:264]
[same as prior period, unchanged from 0000858877-20-000004:notes:267]

[0000858877-20-000006:notes:265]
[same as prior period, unchanged from 0000858877-20-000004:notes:268]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-20-000006:notes:266]
[same as prior period, unchanged from 0000858877-20-000004:notes:269]

[0000858877-20-000006:notes:267]
[same as prior period, unchanged from 0000858877-20-000004:notes:270]

[0000858877-20-000006:notes:268]
Stock Incentive Plan Program Description    As of April 25, 2020, we had one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with Cisco. The number and frequency of share-based awards are based on competitive practices, operating results of Cisco, government regulations, and other factors. Our primary stock incentive plan is summarized as follows:

[0000858877-20-000006:notes:269]
2005 Plan    The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions.  Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. As of April 25, 2020, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares. The 2005 Plan may be terminated by the Board of Directors at any time and for any reason, and is currently set to terminate at the 2021 Annual Meeting unless re-adopted or extended by the shareholders prior to or on such date.

[0000858877-20-000006:notes:270]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. For restricted stock units that were awarded with vesting contingent upon the achievement of future financial performance or market-based metrics, the maximum awards that can be achieved upon full vesting of such awards. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of April 25, 2020, 200 million shares were authorized for future grant under the 2005 Plan.

[0000858877-20-000006:notes:271]
[same as prior period, unchanged from 0000858877-20-000004:notes:274]

[0000858877-20-000006:notes:272]
We have an Employee Stock Purchase Plan under which 721.4 million shares of our common stock have been reserved for issuance as of April 25, 2020. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. No shares were issued under the Purchase Plan during each of the third quarters of fiscal 2020 and 2019. We issued 9 million shares during the first nine months of each of fiscal 2020 and fiscal 2019. As of April 25, 2020, 150 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-20-000006:notes:273]
[same as prior period, unchanged from 0000858877-20-000004:notes:276]

[0000858877-20-000006:notes:274]
[same as prior period, unchanged from 0000858877-20-000004:notes:277]

[0000858877-20-000006:notes:275]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Cost of sales—product | $ | 23 |  |  | $ | 22 |  |  | $ | 69 |  |  | $ | 67 |  |
| Cost of sales—service | 37 |  |  | 32 |  |  | 107 |  |  | 96 |  |
| Share-based compensation expense in cost of sales | 60 |  |  | 54 |  |  | 176 |  |  | 163 |  |
| Research and development | 148 |  |  | 135 |  |  | 440 |  |  | 398 |  |
| Sales and marketing | 125 |  |  | 124 |  |  | 371 |  |  | 386 |  |
| General and administrative | 49 |  |  | 63 |  |  | 164 |  |  | 190 |  |
| Restructuring and other charges | 5 |  |  | 3 |  |  | 18 |  |  | 45 |  |
| Share-based compensation expense in operating expenses | 327 |  |  | 325 |  |  | 993 |  |  | 1,019 |  |
| Total share-based compensation expense | $ | 387 |  |  | $ | 379 |  |  | $ | 1,169 |  |  | $ | 1,182 |  |
| Income tax benefit for share-based compensation | $ | 81 |  |  | $ | 98 |  |  | $ | 321 |  |  | $ | 389 |  |

[0000858877-20-000006:notes:276]
As of April 25, 2020, the total compensation cost related to unvested share-based awards not yet recognized was $3.4 billion which is expected to be recognized over approximately 2.6 years on a weighted-average basis.

[0000858877-20-000006:notes:277]
[same as prior period, unchanged from 0000858877-20-000004:notes:280]

[0000858877-20-000006:notes:278]
[same as prior period, unchanged from 0000858877-20-000004:notes:281]

[0000858877-20-000006:notes:279]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 28, 2018 | 119 |  |  | $ | 30.56 |  |  |  |
| Granted | 45 |  |  | 47.71 |  |  |  |
| Vested | (50 | ) |  | 29.25 |  |  | $ | 2,446 |  |
| Canceled/forfeited/other | (14 | ) |  | 32.01 |  |  |  |
| UNVESTED BALANCE AT JULY 27, 2019 | 100 |  |  | 38.66 |  |  |  |
| Granted | 31 |  |  | 41.70 |  |  |  |
| Vested | (31 | ) |  | 33.64 |  |  | $ | 1,448 |  |
| Canceled/forfeited/other | (8 | ) |  | 40.30 |  |  |  |
| UNVESTED BALANCE AT APRIL 25, 2020 | 92 |  |  | $ | 41.14 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-20-000006:notes:280]
[same as prior period, unchanged from 0000858877-20-000004:notes:283]

[0000858877-20-000006:notes:281]
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first nine months of fiscal 2020 and 2019 are summarized as follows (in millions):

[0000858877-20-000006:notes:282]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 27, 2019 | $ | — |  |  | $ | (14 | ) |  | $ | (778 | ) |  | $ | (792 | ) |
| Other comprehensive income (loss) before reclassifications | 169 |  |  | 14 |  |  | (472 | ) |  | (289 | ) |
| (Gains) losses reclassified out of AOCI | (20 | ) |  | 1 |  |  | 2 |  |  | (17 | ) |
| Tax benefit (expense) | (12 | ) |  | (1 | ) |  | 2 |  |  | (11 | ) |
| BALANCE AT APRIL 25, 2020 | $ | 137 |  |  | $ | — |  |  | $ | (1,246 | ) |  | $ | (1,109 | ) |

[0000858877-20-000006:notes:283]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 28, 2018 | $ | (310 | ) |  | $ | (11 | ) |  | $ | (528 | ) |  | $ | (849 | ) |
| Other comprehensive income (loss) before reclassifications | 382 |  |  | 3 |  |  | (224 | ) |  | 161 |  |
| (Gains) losses reclassified out of AOCI | 18 |  |  | (1 | ) |  | 4 |  |  | 21 |  |
| Tax benefit (expense) | (59 | ) |  | — |  |  | (2 | ) |  | (61 | ) |
| Total change for the period | 341 |  |  | 2 |  |  | (222 | ) |  | 121 |  |
| Effect of adoption of accounting standard | (168 | ) |  | — |  |  | — |  |  | (168 | ) |
| BALANCE AT APRIL 27, 2019 | $ | (137 | ) |  | $ | (9 | ) |  | $ | (750 | ) |  | $ | (896 | ) |

[0000858877-20-000006:notes:284]
[same as prior period, unchanged from 0000858877-20-000004:notes:287]

[0000858877-20-000006:notes:285]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |  |  |
| Comprehensive Income Components | Income Before Taxes |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains and losses on available-for-sale investments | $ | (1 | ) |  | $ | (7 | ) |  | $ | 20 |  |  | $ | (18 | ) |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | 1 |  |  | — |  |  | (4 | ) |  | 3 |  |  | Revenue |
| Foreign currency derivatives | — |  |  | — |  |  | 1 |  |  | (1 | ) |  | Cost of sales |
| Foreign currency derivatives | — |  |  | — |  |  | 2 |  |  | (1 | ) |  | Operating expenses |
|  | 1 |  |  | — |  |  | (1 | ) |  | 1 |  |  |  |
| Cumulative translation adjustment and actuarial gains and losses | — |  |  | (1 | ) |  | (2 | ) |  | (4 | ) |  | Other income (loss), net |
| Total amounts reclassified out of AOCI | $ | — |  |  | $ | (8 | ) |  | $ | 17 |  |  | $ | (21 | ) |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-20-000006:notes:286]
[same as prior period, unchanged from 0000858877-20-000004:notes:289]

[0000858877-20-000006:notes:287]
[same as prior period, unchanged from 0000858877-20-000004:notes:290]

[0000858877-20-000006:notes:288]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Income before provision for income taxes | $ | 3,444 |  |  | $ | 3,615 |  |  | $ | 10,664 |  |  | $ | 10,867 |  |
| Provision for income taxes | $ | 670 |  |  | $ | 571 |  |  | $ | 2,086 |  |  | $ | 1,452 |  |
| Effective tax rate | 19.4 | % |  | 15.8 | % |  | 19.6 | % |  | 13.4 | % |

[0000858877-20-000006:notes:289]
The effective tax rate for the first nine months of fiscal 2019 includes a $152 million tax benefit relating to indirect effects from adoption of ASC 606 at the beginning of fiscal 2019.

[0000858877-20-000006:notes:290]
In the first quarter of fiscal 2020, the Internal Revenue Service (IRS) and Cisco settled all outstanding items related to the audit of our federal income tax returns for the fiscal year ended July 30, 2011 through July 27, 2013. As a result of the settlement, we recognized a net benefit to the provision for income taxes of $102 million, which included a reduction in interest expense of $4 million. We are no longer subject to U.S. federal tax audit through fiscal 2013.
As of April 25, 2020, we had $2.1 billion of unrecognized tax benefits, of which $1.8 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters. We estimate that the unrecognized tax benefits at April 25, 2020 could be reduced by approximately $150 million in the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-20-000006:notes:291]
[same as prior period, unchanged from 0000858877-20-000004:notes:294]

[0000858877-20-000006:notes:292]
[same as prior period, unchanged from 0000858877-20-000004:notes:295]

[0000858877-20-000006:notes:293]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-20-000006:notes:294]
Summarized financial information by segment for the third quarter and the first nine months of fiscal 2020 and 2019, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-20-000006:notes:295]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 7,116 |  |  | $ | 7,695 |  |  | $ | 22,106 |  |  | $ | 22,798 |  |
| EMEA | 3,136 |  |  | 3,356 |  |  | 9,553 |  |  | 9,803 |  |
| APJC | 1,730 |  |  | 1,907 |  |  | 5,489 |  |  | 5,875 |  |
| Total | $ | 11,983 |  |  | $ | 12,958 |  |  | $ | 37,147 |  |  | $ | 38,476 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,828 |  |  | $ | 5,046 |  |  | $ | 14,836 |  |  | $ | 14,911 |  |
| EMEA | 2,061 |  |  | 2,166 |  |  | 6,289 |  |  | 6,307 |  |
| APJC | 1,098 |  |  | 1,158 |  |  | 3,511 |  |  | 3,467 |  |
| Segment total | 7,986 |  |  | 8,370 |  |  | 24,636 |  |  | 24,686 |  |
| Unallocated corporate items | (215 | ) |  | (197 | ) |  | (637 | ) |  | (594 | ) |
| Total | $ | 7,771 |  |  | $ | 8,173 |  |  | $ | 23,999 |  |  | $ | 24,092 |  |

[0000858877-20-000006:notes:296]
[same as prior period, unchanged from 0000858877-20-000004:notes:299]

[0000858877-20-000006:notes:297]
Revenue in the United States was $6.3 billion and $6.8 billion for the third quarter of fiscal 2020 and 2019, respectively, and $19.7 billion and $20.2 billion for the first nine months of fiscal 2020 and 2019, respectively.

[0000858877-20-000006:notes:298]
[same as prior period, unchanged from 0000858877-20-000004:notes:301]

[0000858877-20-000006:notes:299]
[same as prior period, unchanged from 0000858877-20-000004:notes:302]


## us-gaap:EarningsPerShareTextBlock

[0000858877-20-000006:notes:300]
[same as prior period, unchanged from 0000858877-20-000004:notes:303]

[0000858877-20-000006:notes:301]
[same as prior period, unchanged from 0000858877-20-000004:notes:304]

[0000858877-20-000006:notes:302]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 25, 2020 |  | April 27, 2019 |  | April 25, 2020 |  | April 27, 2019 |
| Net income | $ | 2,774 |  |  | $ | 3,044 |  |  | $ | 8,578 |  |  | $ | 9,415 |  |
| Weighted-average shares—basic | 4,230 |  |  | 4,370 |  |  | 4,239 |  |  | 4,468 |  |
| Effect of dilutive potential common shares | 13 |  |  | 45 |  |  | 19 |  |  | 41 |  |
| Weighted-average shares—diluted | 4,243 |  |  | 4,415 |  |  | 4,258 |  |  | 4,509 |  |
| Net income per share—basic | $ | 0.66 |  |  | $ | 0.70 |  |  | $ | 2.02 |  |  | $ | 2.11 |  |
| Net income per share—diluted | $ | 0.65 |  |  | $ | 0.69 |  |  | $ | 2.01 |  |  | $ | 2.09 |  |
| Antidilutive employee share-based awards, excluded | 14 |  |  | 5 |  |  | 42 |  |  | 32 |  |

[0000858877-20-000006:notes:303]
[same as prior period, unchanged from 0000858877-20-000004:notes:306]
